import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { logoutData } from "../redux/slices/authSlice.js";
import { resetOnBoard } from "../redux/slices/onBoabrdSlice.js";
import { resetloginSecurity } from "../redux/slices/loginAndSecurity";
import { resetPastClient } from "../redux/slices/pastClientSlice";
import { resetReferral } from "../redux/slices/referralSlice";
import { resetPass } from "../redux/slices/resetPassSlice";
import { resetSharedProfile } from "../redux/slices/sharedProfileSlice";
import { resetTemplate } from "../redux/slices/templateSlice.js";

export const ClearReduxData = () => {
  const dispatch = useDispatch();

  dispatch(logoutData());
  dispatch(resetOnBoard());
  dispatch(resetloginSecurity());
  dispatch(resetPastClient());
  dispatch(resetReferral());
  dispatch(resetPass());
  dispatch(resetSharedProfile());
  dispatch(resetTemplate());
};
