import React, { lazy, Suspense } from "react";
import { Routes, Route } from "react-router-dom";

const Login = lazy(() => import("../module/login/Login.jsx"));
const Signup = lazy(() => import("../module/login/Signup.jsx"));
const Onboard = lazy(() => import("../module/onboard/Onboard.jsx"));
const Dashboard = lazy(() => import("../module/Dashboard/Dashboard.jsx"));
const PastClient = lazy(() => import("../module/Client/PastClient.jsx"));
const TrackyAI = lazy(() => import("../module/TrackyAI/TrackyAI.jsx"));
const Pitch = lazy(() => import("../module/TrackyAI/Pitch.jsx"));
const TemplateGallery = lazy(() =>
  import("../module/TemplateGallery/TemplateGallery.jsx")
);
const Page404 = lazy(() => import("../CommonComponent/Page404.jsx"));
const AccountOverview = lazy(() =>
  import("../module/Account/AccountOverview.jsx")
);
const PersonalInfo = lazy(() => import("../module/Account/PersonalInfo.jsx"));
const LoginSecurity = lazy(() => import("../module/Account/LoginSecurity.jsx"));
const ProtectedRoute = lazy(() =>
  import("../module/AuthGuard/ProtectedRoute.jsx")
);
const ForgotPassword = lazy(() => import("../module/login/ForgotPassword.jsx"));
const CreatePassword = lazy(() => import("../module/login/CreatePassword.jsx"));
const ManagePlan = lazy(() => import("../module/Account/ManagePlan.jsx"));
const ReferralProgram = lazy(() =>
  import("../module/Account/ReferralProgram.jsx")
);
const VerifyEmail = lazy(() => import("../module/login/VerifyEmail.jsx"));
const PaymentSuccess = lazy(() =>
  import("../module/onboard/PaymentSuccess.jsx")
);
const PaymentFailer = lazy(() => import("../module/onboard/PaymentFailer.jsx"));
const SharedProfile = lazy(() => import("../module/Profile/SharedProfile.jsx"));
const PitchGeneratorInput = lazy(() =>
  import("../module/TrackyAI/PitchGeneratorInput.jsx")
);
const PerTemGallery = lazy(() =>
  import("../module/TemplateGallery/PerTemGallery.jsx")
);

const CovoCraft = lazy(() => import("../module/TrackyAI/CovoCraft.jsx"));
const ConvoHistory = lazy(() => import("../module/TrackyAI/ConvoHistory.jsx"));
const EditPitch = lazy(() => import("../module/TrackyAI/EditPitch.jsx"));
const EditConvo = lazy(() => import("../module/TrackyAI/EditConvo.jsx"));
import Spinner from "../CommonComponent/Spinner.jsx";
import Applayout from "../CommonComponent/Applayout.jsx";

function IndexRoutes() {
  return (
    <>
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="*" element={<Page404 />} />
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgotpassword" element={<ForgotPassword />} />
          <Route path="/forget-password" element={<CreatePassword />} />
          <Route path="/verifyemail" element={<VerifyEmail />} />
          <Route path="/profile" element={<SharedProfile />} />
          {/* <Route path="/sharedfeature" element={<SharedFeature />} />
          <Route path="/sharedpricing" element={<SharedPricing />} />
          <Route path="/sharedsupport" element={<SharedSupport />} /> */}

          <Route element={<ProtectedRoute />}>
            <Route path="/onboard" element={<Onboard />} />
            <Route element={<Applayout />}>
              <Route path="/dashboard" element={<Dashboard />} />

              <Route path="/accountoverview" element={<AccountOverview />} />
              <Route path="/loginsecurity" element={<LoginSecurity />} />
              <Route path="/manageplan" element={<ManagePlan />} />
              <Route path="/personalinfo" element={<PersonalInfo />} />
              <Route path="/referralprogram" element={<ReferralProgram />} />

              <Route path="/paymentsuccess" element={<PaymentSuccess />} />
              <Route path="/paymentfail" element={<PaymentFailer />} />
              <Route path="/addpastclient" element={<PastClient />} />
              <Route path="/editpastclient/:id" element={<PastClient />} />

              <Route path="/paymentsuccess" element={<PaymentSuccess />} />
              <Route path="/paymentfail" element={<PaymentFailer />} />
              <Route path="/addpastclient" element={<PastClient />} />
              <Route path="/editpastclient/:id" element={<PastClient />} />

              <Route path="/trackyai" element={<TrackyAI />} />
              <Route path="/pitchgenerator" element={<PitchGeneratorInput />} />
              <Route path="/pitchgenerator/:id" element={<EditPitch />} />
              <Route path="/convocraft/:id" element={<EditConvo />} />
              <Route path="/pitch" element={<Pitch />} />
              <Route path="/trackyai" element={<TrackyAI />} />
              <Route path="/pitchgenerator" element={<PitchGeneratorInput />} />
              <Route path="/pitchgenerator/:id" element={<EditPitch />} />
              <Route path="/convocraft/:id" element={<EditConvo />} />
              <Route path="/pitch" element={<Pitch />} />

              <Route path="/convocraft" element={<CovoCraft />} />
              <Route path="/convo" element={<ConvoHistory />} />


              <Route path="/templategallery" element={<TemplateGallery />} />
              <Route path="/personaltemplategallery" element={<PerTemGallery />} />
            </Route>
          </Route>
        </Routes>
      </Suspense>
    </>
  );
}

export default IndexRoutes;
