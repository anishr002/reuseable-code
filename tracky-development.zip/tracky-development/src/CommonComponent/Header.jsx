import React, { useEffect, useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { logoutData } from '../redux/slices/authSlice.js';
import { useDispatch, useSelector } from 'react-redux';
import { resetOnBoard } from '../redux/slices/onBoabrdSlice.js';
import { resetloginSecurity } from '../redux/slices/loginAndSecurity';
import { resetPastClient } from '../redux/slices/pastClientSlice';
import { resetReferral } from '../redux/slices/referralSlice';
import { resetPass } from '../redux/slices/resetPassSlice';
import { resetSharedProfile } from '../redux/slices/sharedProfileSlice';
import { resetPitch } from '../redux/slices/PitchSlice.js';
import { resetConvo } from '../redux/slices/convoSlice.js';
import {
  resetTemplate,
  setActivefilter,
} from '../redux/slices/templateSlice.js';
import alex_img from '../assets/alex_img.svg';
import help_icn from '../assets/help_icn.svg';
import saved_icn from '../assets/saved_icn.svg';
import invite_icn from '../assets/invite_icn.svg';
import notification_icon from '../assets/notification_icon.svg';
import check_mark from '../assets/check_mark.svg';
import arrow_icon from '../assets/arrow_icon.svg';
import logo_light from '../assets/logo_light.svg';
import { Menu } from '@headlessui/react';
import { SocketContext } from '../CommonComponent/context/SocketContextProvider';
import {
  getNotificationList,
  markAllasRead,
  markSingleRead,
  notificationListDataFun,
  resetNotification,
} from '../redux/slices/notificationSlice.js';

function Header({
  open,
  setOpen,
  setShowReffralDropdown,
  showReffralDropdown,
}) {
  const dispatch = useDispatch();
  const history = useNavigate();

  const { socket, isSocketConnected } = useContext(SocketContext);

  const notificatiolListLoading = useSelector(
    (state) => state?.root?.notification?.loading
  );

  const notiListObj = useSelector(
    (state) => state?.root?.notification?.notificationListData
  );

  const notiData = useSelector(
    (state) => state?.root?.notification?.notificationListData?.notificationList
  );

  const notiUnreadCount = useSelector(
    (state) => state?.root?.notification?.notificationListData?.un_read_count
  );

  const totalCountnotiData = useSelector(
    (state) => state?.root?.notification?.notificationListData?.totalCount
  );

  const loginData = useSelector((state) => state?.root?.auth);

  const PersonalinfoData = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData?.profileData
  );

  const [notilistlimt, setNotilistLimit] = useState(5);

  function mergeStrings(string1, string2) {
    const result = string1 + ' ' + string2;

    if (result.length > 18) {
      return result.substring(0, 15) + '...';
    }

    return result;
  }

  let nameToShow;
  let nameToShowinCap;
  if (PersonalinfoData?.first_name && PersonalinfoData?.last_name) {
    nameToShow = mergeStrings(
      capitalizeFirstLetter(PersonalinfoData?.first_name),
      capitalizeFirstLetter(PersonalinfoData?.last_name)
    );

    nameToShowinCap = nameToShow;
  } else {
    nameToShow = '';
  }

  function capitalizeFirstLetter(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  const templateActiveFilter = () => {
    dispatch(setActivefilter('favorites'));
  };

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const notiPayload = {
    limit: notilistlimt,
  };

  const ShowMoreNotiData = () => {
    setNotilistLimit((prevCount) => prevCount + 5);
  };

  useEffect(() => {
    dispatch(getNotificationList(auth, notiPayload));
  }, [notilistlimt]);

  const getNotificationListFunction = () => {
    dispatch(getNotificationList(auth, notiPayload));
  };

  const markAllAsRead = () => {
    const markallPayload = {
      notification_id: 'all',
    };
    dispatch(markAllasRead(auth, markallPayload, notiPayload));
  };

  const markSingleNotiRead = (noti) => {
    if (noti?.is_read == false) {
      const markSinglePayload = {
        notification_id: noti?._id,
      };
      dispatch(markSingleRead(auth, markSinglePayload, notiPayload));
    }
  };

  useEffect(() => {
    console.log(socket, 9999);
    console.log(isSocketConnected, 9999);
    console.log(socket?.connected, 9999);

    if (socket == null || socket?.connected == false) {
      console.log('Socket is not connected', 9999);
    }

    // if(!socket.connected) return;
    socket?.emit('ROOM', { id: PersonalinfoData?._id });
    socket?.on('NOTIFICATION', (payload) => {
      dispatch(
        notificationListDataFun({
          ...notiListObj,
          un_read_count: payload.un_read_count,
        })
      );
      console.log(payload, 'notification event received', 9999);
    });

    return () => {
      socket?.off('NOTIFICATION');
    };
  }, [socket, PersonalinfoData]);

  return (
    <>
      <div className='w-full '>
        <img
          src={arrow_icon}
          className={`fixed cursor-pointer md:left-[180px] left-[150px] top-[30px] w-7 shadow-lg rounded-full z-50 ${
            !open && 'rotate-180'
          }`}
          id='Sidebarbtn'
          onClick={() => {
            try {
              setOpen(!open);
              // if (open) {
              //   setShowReffralDropdown(false);
              // }
              if (open) {
                setShowReffralDropdown(true);
              }
            } catch (e) {
              console.log(e);
            }
          }}
        />
        {/*only visible in mobile view*/}

        <div
          className='flex w-full flex-row items-center md:justify-between md:me-8 p-4 bg-zinc-800 relative
        border-b border-[#4D4D4D]'>
          <div
            className='mx-auto text-center cursor-pointer'
            onClick={() => history('/dashboard')}>
            <img src={logo_light} alt='' />
          </div>
          <div className='flex items-center w-[100%] mt-0 justify-end '>
            <Menu>
              <Menu.Button className='relative'>
                <div className='mr-2 cursor-pointer'>
                  <span className='text-black text-[12px] flex justify-center items-center w-[20px] h-[20px] bg-[#2ede9f] rounded-[50%] absolute -top-2 right-2 font-bold'>
                    {notiUnreadCount !== null && notiUnreadCount !== undefined
                      ? notiUnreadCount
                      : ''}
                  </span>
                  <img
                    src={notification_icon}
                    alt='notification icon'
                    className='h-8'
                    title='Notification'
                    onClick={getNotificationListFunction}
                  />
                </div>
              </Menu.Button>
              <Menu.Items>
                {/* <Menu.Item> */}
                <div
                  className={` ${
                    notificatiolListLoading ? 'h-[149px]' : ''
                  } z-50  md:block dark-bg  text-[#ffffff]
            divide-y divide-[#525252] rounded-lg border border-[#525252]
             shadow absolute top-[83px]
             w-[60%] right-[2%]
             sm:w-[45%]  sm:right-[24%]

             md:w-[45%]  md:right-[19%]
             lg:w-[37%]  lg:right-[15%]
             xl:w-[34%]  xl:right-[12%]
             2xl:w-[30%]  2xl:right-[9%]

             max-h-[365px] overflow-y-auto overflow-x-hidden`}>
                  {notificatiolListLoading ? (
                    <>
                      <div className='flex items-center justify-center w-full h-full Bordertopzero'>
                        <svg
                          class='animate-spin -ml-1 mr-3 h-10 w-9 text-white'
                          xmlns='http://www.w3.org/2000/svg'
                          fill='none'
                          viewBox='0 0 24 24'>
                          <circle
                            class='opacity-25'
                            cx='12'
                            cy='12'
                            r='10'
                            stroke='currentColor'
                            stroke-width='4'></circle>
                          <path
                            class='opacity-75'
                            fill='currentColor'
                            d='M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z'></path>
                        </svg>
                      </div>
                    </>
                  ) : (
                    <>
                      {totalCountnotiData !== undefined &&
                      totalCountnotiData !== null &&
                      totalCountnotiData === 0 ? (
                        <>
                          <div className='flex items-center justify-center m-2'>
                            <p className=''>No notification</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className='flex justify-between m-2 p-1 pb-0'>
                            <p className='mr-auto text-[20px]'>Notifications</p>

                            {notiUnreadCount &&
                            notiUnreadCount !== null &&
                            notiUnreadCount !== undefined &&
                            notiUnreadCount > 0 ? (
                              <>
                                <p
                                  className='underline cursor-pointer ml-auto'
                                  onClick={markAllAsRead}>
                                  Mark all as read
                                </p>
                              </>
                            ) : (
                              <></>
                            )}
                          </div>
                          <hr className='border rounded-[50%] notidivercolour ml-2 mr-2 pl-1 pr-1' />
                          {notiData &&
                            notiData.length !== 0 &&
                            notiData.map((noti, index) => (
                              <>
                                <div
                                  className={`${
                                    noti?.is_read == false
                                      ? 'font-bold cursor-pointer'
                                      : 'font-thin'
                                  }  m-2 p-1 rounded-lg  Bordertopzero flex justify-between`}
                                  key={index}
                                  onClick={() => {
                                    markSingleNotiRead(noti);
                                  }}>
                                  <div>
                                  <p className=''>{noti?.message}</p>
                                  </div>
                                  <div>
                                    {noti?.is_read == false ? (
                                      <>
                                  <div className="w-3 h-3 inline-block bg-[#21CE90] rounded-full"></div>
                                      </>
                                    ) : (
                                      <>
                                      <img
                                  src={check_mark}
                                  alt='notification icon'
                                  className='w-6 h-6'
                                />
                                      </>
                                    )
                                    }
                                  </div>
                                </div>
                              </>
                            ))}
                          {totalCountnotiData &&
                          totalCountnotiData !== undefined &&
                          totalCountnotiData !== null &&
                          totalCountnotiData > notiData?.length ? (
                            <>
                              <button
                                className='py-2 px-4 bg-white text-[#18181B] font-medium text-[16px] hover:bg-[#21CE90] hover:text-[#fff] rounded-[10px] w-[95%] ml-2 mr-2 mb-1 NotiShowmorebtn'
                                block
                                onClick={ShowMoreNotiData}>
                                Show more
                              </button>
                            </>
                          ) : (
                            <></>
                          )}
                        </>
                      )}
                    </>
                  )}
                </div>
                {/* </Menu.Item> */}
              </Menu.Items>
            </Menu>

            <div className='text-white me-4'>
              <p className='text-[14px]'>
                {nameToShowinCap !== undefined &&
                  nameToShowinCap !== null &&
                  nameToShowinCap &&
                  `${nameToShowinCap}`}
              </p>
            </div>

            <Menu>
              <Menu.Button>
                <button
                  className='rounded-full w-[45px] h-[45px] p-0
                      border-2 border-[#D9D9D9]'
                  // id="dropdownDividerButton "
                  // data-dropdown-toggle="dropdownDivider"
                  // id="dropdownDividerButton "
                  // data-dropdown-toggle="dropdownDivider"
                >
                  {/* <img src={alex_img} alt="user" /> */}
                  <img
                    className='w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content'
                    src={
                      `${process.env.REACT_APP_IO}/${PersonalinfoData?.profile_image}` ||
                      alex_img
                    }
                    alt='user'
                    onError={({ currentTarget }) => {
                      currentTarget.onerror = null; // prevents looping
                      currentTarget.src = alex_img;
                    }}
                  />
                </button>
              </Menu.Button>

              <Menu.Items>
                <Menu.Item>
                  {({ close }) => (
                    <div
                      // id="dropdownDivider"
                      className='z-50  md:block dark-bg me-6   text-[#ffffff]
            divide-y divide-[#525252] rounded-lg border border-[#525252]
             shadow md:w-[20%] w-[60%] md:top-full absolute right-[-2px] md:right-[10px] top-[80px]
             '>
                      <ul
                        className='py-2 text-sm text-white dark:text-gray-200'
                        // aria-labelledby="dropdownDividerButton"
                      >
                        <li>
                          <Link to='/accountoverview' onClick={close}>
                            <a
                              href='#'
                              className='block px-4 py-2 hover:bg-[#373839]
                  hover:text-[#ffffff]'>
                              Profile Settings
                            </a>
                          </Link>
                        </li>
                        <li>
                          <Link to='/personalinfo' onClick={close}>
                            <a
                              href='#'
                              className='block px-4 py-2 hover:bg-[#373839]
                  hover:text-[#ffffff]'>
                              View Profile
                            </a>
                          </Link>
                        </li>
                      </ul>

                      <div className='py-2'>
                        <a
                          href='https://www.trytracky.com/helpcenter'
                          target='_blank'
                          className=' px-4 py-2 hover:bg-[#373839]
                  hover:text-[#ffffff] flex items-center'
                          onClick={close}>
                          <img
                            src={help_icn}
                            alt='help icon'
                            className='me-2'
                          />
                          <span className='text-[16px] font-normal'>
                            {' '}
                            Help doc{' '}
                          </span>
                        </a>

                        <Link
                          to='/templategallery'
                          onClick={templateActiveFilter}>
                          <a
                            href='#'
                            className='flex items-center px-4 py-2 hover:bg-[#373839]
                  hover:text-[#ffffff]'
                            onClick={close}>
                            <img
                              src={saved_icn}
                              alt='saved icon'
                              className='me-2'
                            />
                            <span className='text-[16px] font-normal'>
                              Saved templates
                            </span>
                          </a>
                        </Link>

                        <Link to='/referralprogram' onClick={close}>
                          <a
                            href='#'
                            className='flex items-center px-4 py-2 hover:bg-[#373839]
                  hover:text-[#ffffff]'>
                            <img
                              src={invite_icn}
                              alt='incite icon'
                              className='me-2'
                            />
                            <span className='text-[16px] font-normal'>
                              Invite Closers/Setters
                            </span>
                          </a>
                        </Link>
                      </div>

                      <div
                        className='py-2'
                        onClick={() => {
                          dispatch(logoutData());
                          dispatch(resetOnBoard());
                          dispatch(resetloginSecurity());

                          dispatch(resetPastClient());
                          dispatch(resetReferral());
                          dispatch(resetPass());

                          dispatch(resetSharedProfile());
                          dispatch(resetTemplate());
                          dispatch(resetConvo());

                          dispatch(resetPitch());
                          dispatch(resetNotification());
                        }}>
                        <Link
                          className='block px-4 py-2 hover:bg-[#373839]
                  hover:text-[#ffffff]'
                          onClick={close}>
                          Logout
                        </Link>
                      </div>
                    </div>
                  )}
                </Menu.Item>
              </Menu.Items>
            </Menu>
          </div>
        </div>
      </div>
    </>
  );
}

export default Header;
