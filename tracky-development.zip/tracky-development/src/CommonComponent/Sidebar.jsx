import React, { useState, useEffect } from "react";

import FOLDER from "../assets/SidebarIcon/home_icn.svg";
import CHAT from "../assets/SidebarIcon/ai_icn.svg";
import CALENDER from "../assets/SidebarIcon/calender_icn.svg";
import SETTING from "../assets/SidebarIcon/link_icn.svg";

import { NavLink } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import arrow_icon from "../assets/arrow_icon.svg";
import logo_light from "../assets/logo_light.svg";
import ReferralDownArrow from "../assets/ReferralDownArrow.svg";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";

function SideBar({
  open,
  setOpen,
  setShowReffralDropdown,
  showReffralDropdown,
}) {
  // const [open, setOpen] =
  //   useState(true);
  const navigate = useNavigate();
  // const [
  //   showReffralDropdown,
  //   setShowReffralDropdown,
  // ] = useState(false);
  const loginData = useSelector((state) => state?.root?.auth);

  const [showSideMenuicon, setShowSideMenuicon] = useState(true);

  const [mobileview, setMobileView] = useState(false);

  const Menus = [
    {
      title: "Profile",
      src: FOLDER,
      linkto: "/dashboard",
    },
    {
      title: "Tracky AI",
      src: CHAT,
      linkto: "/trackyai",
    },
    {
      title: "Template gallery",
      src: CALENDER,
      linkto: "/templategallery",
    },
    // { title: "Refferal link", src: SETTING, linkto: "/referralprogram" },
    // { title: "Files ", src: "Folder", gap: true },
  ];

  const redirectToHomePage = () => {
    navigate("/dashboard");
  };

  const handleDropdown = (event) => {
    event.preventDefault();
    setShowReffralDropdown(!showReffralDropdown);
  };

  function handleWindowSizeChange() {
    if (window.innerWidth <= 769 && open) {
      // document.getElementById("Sidebarbtn").click();
      setOpen(!open);
    }
    if (window.innerWidth <= 769) {
      setMobileView(true);
    }
    if (window.innerWidth > 769) {
      setMobileView(false);
    }
  }

  useEffect(() => {
    window.addEventListener("resize", handleWindowSizeChange);
    return () => {
      window.removeEventListener("resize", handleWindowSizeChange);
    };
  }, []);

  useEffect(() => {
    if (window.innerWidth < 769 && open) {
      setOpen(!open);
    }
  }, []);

  useEffect(() => {
    if (window.innerWidth <= 769) {
      setMobileView(true);
    } else if (window.innerWidth > 769) {
      setMobileView(false);
    }
  }, []);

  const ReferralCode = loginData?.data?.user?.referral_code
    ? loginData?.data?.user?.referral_code
    : loginData?.googleData?.user?.referral_code
    ? loginData?.googleData?.user?.referral_code
    : loginData?.VerifyData?.user?.referral_code
    ? loginData?.VerifyData?.user?.referral_code
    : loginData?.googleInData?.user?.referral_code
    ? loginData?.googleInData?.user?.referral_code
    : loginData?.appleData?.user?.referral_code;

  let urlToShareIS = `${process.env.REACT_APP_FRONTEND_BASE_URL}signup?referral=${ReferralCode}`;

  const handleCopyToClipboard = async () => {
    try {
      await window?.navigator?.clipboard?.writeText(urlToShareIS);
      urlCopied();
    } catch (error) {
      console.error("Error copying URL:", error);
    }
  };

  const urlCopied = async () => {
    Swal.fire({
      allowOutsideClick: true,
      background: "#373839",
      color: "#ffffff",
      text: "Referral link copied to clipboard",
      icon: "success",
      showCancelButton: false,
      confirmButtonColor: "#2EDE9F",
      confirmButtonText: "Okay",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.close();
      } else {
      }
    });
    setTimeout(function () {
      Swal.close();
    }, 2000);
  };

  return (
    <>
      {/*for only mobile view arrow will show///
      {!open && mobileview && (
        <>
          <div className="relative ">
            <img
              src={arrow_icon}
              className={`fixed  cursor-pointer right-0 left-[20px] top-[100px] w-7 shadow-lg  rounded-full  ${
                !open && "rotate-180"
              }`}
              test
              onClick={() => {
                setOpen(!open);
                if (open) {
                  setShowReffralDropdown(
                    false
                  );
                }
              }}
              id="Sidebarbtn"
            />
          </div>
        </>
      )}*/}

      <div
        className={` ${
          open ? "w-80" : mobileview ? "w-0 " : "w-20"
        } bg-[#272727] text-[#ffffff] border-r border-[#4D4D4D] h-full ${
          mobileview ? "p-0" : "p-5"
        } pt-8  ease-in duration-300`}
      >
        {/* <div className="flex items-center gap-x-4" onClick={redirectToHomePage}>
          <img
            src={logo_light}
            className={`cursor-pointer duration-500  -rotate-90  ${open && "-rotate-[360deg] "
              }`}
          />
        </div> */}

        {/* <img
          src={arrow_icon}
          className={`absolute cursor-pointer left-[20px] md:left-[180px] md:-right-[150px] top-[-50px] w-7 shadow-lg  rounded-full  ${!open && "rotate-180"
            }`}
          onClick={() => {
            setOpen(!open);
            if (open) {
              setShowReffralDropdown(
                false
              );
            }
          }}
          id="Sidebarbtn"
        /> */}

        <ul className="pt-6">
          {Menus.map((Menu, index) => (
            <NavLink
              to={Menu.linkto}
              className={({ isActive }) =>
                [isActive ? "menuActive" : ""].join(" ")
              }
              key={index}
            >
              <li
                key={index}
                className={`flex rounded-md p-2 cursor-pointer hover:bg-[#1F1F1F] text-gray-300 text-sm items-center gap-x-4
              ${Menu.gap ? "mt-9" : "mt-2"} ${
                  index === 0 && "bg-light-white"
                } `}
              >
                <img src={`${Menu.src}`} />
                <span
                  className={`${
                    !open && "hidden"
                  } origin-left duration-200 text-[16px] font-normal  `}
                >
                  {Menu.title}
                </span>
              </li>
            </NavLink>
          ))}

          <NavLink
            to={"/referralprogram"}
            className={({ isActive }) =>
              [isActive ? "menuActive" : ""].join(" ")
            }
          >
            <li
              className={`flex  rounded-md p-2 cursor-pointer  hover:bg-[#1F1F1F]
               text-gray-300 text-sm items-center gap-x-4
              mt-2`}
            >
              <img src={`${SETTING}`} />
              <span
                className={`${
                  !open && "hidden"
                } origin-left duration-200 text-[16px] font-normal w-[200px] `}
              >
                {`Refferal link`}
              </span>
              <div
                className="flex justify-end"
                onClick={(e) => e.stopPropagation()}
              >
                <img
                  src={`${ReferralDownArrow}`}
                  onClick={handleDropdown}
                  className={`${!open && "hidden"} ${
                    showReffralDropdown && "rotate-[270deg]"
                  } cursor-pointer`}
                />
              </div>
            </li>
          </NavLink>

          <div
            className={`${(!open || showReffralDropdown) && "hidden"} `}
            // className={`${(showReffralDropdown) && 'hidden'} `}
          >
            <div className="bg-[#1E1E1E] py-4 px-4 rounded-[8px]">
              <div className="bg-white rounded-[8px] p-2 flex items-start">
                <span className="bg-[#E7E7E7] rounded-[4px] px-4 py-2 text-[8px] text-[#000000] flex items-center">
                  {/* Https://trytracky.com/quintenredert */}
                  {urlToShareIS !== undefined && urlToShareIS && urlToShareIS}
                  {/* disabled */}
                </span>
                <button
                  className="bg-[#2B2C2D] text-[#ffffff] text-[8px] font-semibold rounded-[8px] px-4 py-2 ms-2"
                  onClick={handleCopyToClipboard}
                >
                  Copy
                </button>
              </div>
              <p className="text-[11px] font-semibold text-left mt-4">
                Refer a friend and get 10% commission on the first month.
              </p>
            </div>
          </div>
        </ul>
      </div>
    </>
  );
}

export default SideBar;
