import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';
import React from 'react';

function LoadingSkeleton() {
  return (
    <>
      <Skeleton width={250} height={250} />
    </>
  )
}

export default LoadingSkeleton;
