import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import logo_light from "../assets/logo_light.svg";

import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

function Page404() {
  const navigate = useNavigate();
  const [Goto, setGoto] = useState("");

  const loginData = useSelector((state) => state?.root?.auth);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const BackToHome = () => {
    if (auth) {
      navigate("/dashboard");
    } else {
      navigate("/login");
    }
  };

  useEffect(() => {
    if (auth) {
      setGoto("Dashboard");
    } else {
      setGoto("Login");
    }
  }, []);

  return (
    <>
      <Helmet>
        <title>Tracky</title>
        <meta name="description" content="Tracky" />
      </Helmet>
      <div className="bg-[#000000] grid h-screen content-center justify-center justify-items-center w-full">
        <div className="w-full ">
          <div className="flex flex-col justify-center w-full">
            <div className="mb-8 justify-center items-center w-full flex">
              <img src={logo_light} alt="logo" className="w-[80%]" />
            </div>
            <div className="My-8 text-center">
              <h1 className="text-[#2ede9f] text-[70px] font-bold">404</h1>
              <p className="text-[40px] font-semibold text-white capitalize">
                page Not Found
              </p>
              <p className="text-[20px] font-medium text-slate-200 capitalize">
                {`Please go back to ${Goto}`}
              </p>
              <button
                className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium mt-10
                            py-[10px] px-[30px] w-full md:w-[80%] hover:bg-[#ffffff] hover:text-[#000000] grow"
                onClick={BackToHome}
                type="submit"
              >
                {`Got to ${Goto}`}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Page404;
