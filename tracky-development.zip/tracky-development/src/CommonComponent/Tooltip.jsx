// Tooltip.js
import React, { useState } from 'react';

const Tooltip = ({ text, children, bgColor }) => {
  const [showTooltip, setShowTooltip] = useState(false);

  const toggleTooltip = () => {
    setShowTooltip(!showTooltip);
  };

  return (
    <div className="relative inline-block">
      <span
        className="cursor-pointer"
        onMouseEnter={toggleTooltip}
        onMouseLeave={toggleTooltip}
      >
        {children}
      </span>
      {showTooltip && (
        <div className={`absolute z-10 right-[2px] max-w-[200px] ${bgColor} text-white px-2 py-1 rounded-lg shadow-md`}>
          {text}
        </div>
      )}
    </div>
  );
};

export default Tooltip;
