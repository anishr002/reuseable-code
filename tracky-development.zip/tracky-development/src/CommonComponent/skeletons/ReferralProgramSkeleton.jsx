import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function ReferralProgramSkeleton() {
  return (
    <>
      {" "}
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
        {/* <Skeleton width={200} height={50} /> */}
        <Skeleton width={200} height={50} />

        <div className="w-full   text-[#ffffff]">
          <h1 className="text-[20px] md:text-[30px] font-semibold mb-[16px]">
            <Skeleton width={300} height={30} />
          </h1>
          <div className="flex flex-row justify-between items-center">
            <p className="text-[18px] w-[150px] md:w-full ">
              <Skeleton width={150} height={30} />
            </p>
            <button
              className="bg-transparent  text-[15px] font-medium 
                               w-auto  hover:text-[#fff] py-2 px-4 hover:rounded-[8px] 
                               flex items-center justify-end  "
              o
              type="button"
            >
              <Skeleton width={100} height={30} />
            </button>
          </div>
          {/* invite sections */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3 my-6">
            <div className="flex-col col-span-2 w-full ">
              <div className="w-full  block md:flex ">
                <div className="bg-[#373839] rounded-[15px] p-6  w-full me-0 md:me-4">
                  <h1 className="text-[25px] font-semibold mb-4">
                    <Skeleton width={200} height={30} />
                  </h1>

                  <p className="text-[12px] ">
                    <Skeleton width={300} height={20} />
                  </p>
                  <div className="flex-col w-full">
                    <div className="w-full block md:flex md:items-center ">
                      <label className=" block w-full md:w-[60%] my-4">
                        <Skeleton width={150} height={30} />
                      </label>
                      <button
                        className="cursor-pointer bg-[#373839] rounded-[8px] bg-transparent  text-[15px] font-medium py-[15px]
                                w-full md:w-[30%]
                   md:me-4 mb-4 md:mb-0"
                      >
                        <Skeleton width={100} height={30} />
                      </button>
                      <button
                        className="cursor-pointer rounded-[8px]   text-[15px] font-medium py-[15px]
                               w-full md:w-[30%]
               "
                      >
                        <Skeleton width={100} height={30} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="w-full  block md:flex mt-6">
                <div className="rounded-[15px] p-6 bg-[#373839] w-full me-0 md:me-4">
                  <h1 className="text-[25px] font-semibold mb-4">
                    <Skeleton width={200} height={30} />
                  </h1>
                  <p className="text-[12px] ">
                    <Skeleton width={300} height={20} />
                  </p>

                  <div className="flex-col w-full">
                    <form>
                      <div className="w-full block md:flex md:items-center ">
                        <label className=" block w-full md:w-[90%] my-4">
                          <Skeleton width={200} height={30} />
                        </label>
                        <button
                          className="cursor-pointer rounded-[8px]   text-[15px] font-medium py-[15px]
                               w-full md:w-[50%]
                  "
                          type="submit"
                        >
                          <div
                            className=" flex justify-center
                       items-center content-center w-full"
                          >
                            <Skeleton width={100} height={30} />
                          </div>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
                {/*box*/}
              </div>
              {/* how it works sections */}
              <h1 className="text-[14px] md:text-[20px] font-semibold my-[16px]">
                <Skeleton width={100} height={30} />
              </h1>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-3 my-6">
                <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                  <div className="flex-col">
                    <div className="mb-4">
                      <span className="rounded-full  h-[10px] w-[10px] px-[10px] py-[5px] text-[11px] font-bold">
                        <Skeleton width={100} height={30} />
                      </span>
                    </div>
                    <span className="text-[14px] font-semibold mb-4">
                      <Skeleton width={100} height={30} />
                    </span>
                    <p className="text-[12px] font-medium">
                      <Skeleton width={150} height={20} />
                    </p>
                  </div>
                </div>
                <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                  <div className="flex-col">
                    <div className="mb-4">
                      <span className="rounded-full  h-[10px] w-[10px] px-[10px] py-[5px] text-[11px] font-bold">
                        <Skeleton width={100} height={30} />
                      </span>
                    </div>
                    <span className="text-[14px] font-semibold mb-4">
                      <Skeleton width={100} height={30} />
                    </span>
                    <p className="text-[12px] font-medium">
                      <Skeleton width={150} height={20} />
                    </p>
                  </div>
                </div>
                <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                  <div className="flex-col">
                    <div className="mb-4">
                      <span className="rounded-full  h-[10px] w-[10px] px-[10px] py-[5px] text-[11px] font-bold">
                        <Skeleton width={100} height={30} />
                      </span>
                    </div>
                    <span className="text-[14px] font-semibold mb-4">
                      <Skeleton width={100} height={30} />
                    </span>
                    <p className="text-[12px] font-medium">
                      <Skeleton width={150} height={20} />
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-col w-full ">
              <div className="w-full  block md:flex ">
                <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                  <div className="flex-col">
                    <div className="mb-4">
                      <span className=" text-[16px] font-bold">
                        <Skeleton width={150} height={30} />
                      </span>
                    </div>
                    <ul class="list-none w-full">
                      <li className="flex my-2">
                        <span className="text-[14px] w-[80%]">
                          <Skeleton width={100} height={20} />
                        </span>
                        <span className="text-[14px] w-[20%]">
                          <Skeleton width={50} height={20} />
                        </span>
                      </li>
                      {/* <li className="flex my-2">
                                    <span className="text-[14px] w-[80%]">
                                      Payable amount
                                    </span>
                                    <span className="text-[14px] w-[20%]">4</span>
                                  </li>
                                  <li className="flex my-2">
                                    <span className="text-[14px] w-[80%]">
                                      Lifetime earnings
                                    </span>
                                    <span className="text-[14px] w-[20%]">4</span>
                                  </li> */}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </SkeletonTheme>
    </>
  );
}

export default ReferralProgramSkeleton;
