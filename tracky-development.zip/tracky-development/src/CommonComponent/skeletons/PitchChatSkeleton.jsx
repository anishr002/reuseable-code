import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function PitchChatSkeleton() {
  return (
    <>
      {" "}
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
      <div className="h-[calc(100vh-80px)]">
        <div className="py-2">
          <Skeleton width={300} height={30} />
          <Skeleton width={100} height={20} />
        </div>
        <div className="py-2">
          <Skeleton width={300} height={30} />
          <Skeleton width={100} height={20} />
        </div>
        <div className="py-2">
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
          <Skeleton width={1000} height={30} />
        </div>
</div>

      </SkeletonTheme>
    </>
  );
}

export default PitchChatSkeleton;
