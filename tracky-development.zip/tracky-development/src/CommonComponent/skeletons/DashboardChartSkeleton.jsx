import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function DashboardChartSkeleton() {
  return (
    <>
      {" "}
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
        <Skeleton height={250} />
      </SkeletonTheme>
    </>
  );
}

export default DashboardChartSkeleton;
