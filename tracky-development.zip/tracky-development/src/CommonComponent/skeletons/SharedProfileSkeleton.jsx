import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function SharedProfileSkeleton() {
  return (
    <>
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
        <div
          className="p-4 md:pb-6  grid grid-flow-row auto-rows-max  mx-auto
        content-center w-full   h-[calc(100vh-80px)]"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex items-start content-start md:items-start md:h-[45px]">
            <div className="">
              <p
                className="text-[20px] md:text-[30px] text-left break-word md:break-normal
             font-bold "
              >
                <Skeleton width={100} height={50} />
              </p>
            </div>
            <div className=" flex flex-row justify-between md:justify-end content-center items-center  mb-4 md:md-0">
              <button className="me-4 hover:ring  ">
                <Skeleton width={100} height={50} />
              </button>
              <div
                className="flex justify-center items-center content-center cursor-pointer  py-1 px-2
                          "
              >
                <Skeleton width={100} height={50} />
              </div>
              <button
                className="md:ms-6 mt-4 md:mt-0 rounded-[10px]
                  py-2 px-4
                  text-[16px] font-medium "
              >
                <Skeleton width={100} height={50} />
              </button>
            </div>
          </div>
          {/*Card for Alex B.*/}
          <div
            className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              pt-6 px-[20px] md:mt-8 w-auto md:w-full mx-auto"
          >
            <div className="flex flex-col md:flex-row justify-start content-start md:items-start md:content-start">
              <div className="w-auto md:w-3/5">
                {/*profile text*/}
                <div className="flex flex-col md:flex-row justify-start content-start items-start">
                  <div
                    className="rounded-full w-[70px] h-[70px] mt-4 p-0
                    "
                  >
                    <Skeleton
                      circle
                      height="100%"
                      containerClassName="avatar-skeleton"
                    />
                  </div>
                  <div className="">
                    <div className="flex justify-start content-center">
                      <p className="text-[37px] font-semibold md:ms-4">
                        <Skeleton width={400} height={50} />
                      </p>
                    </div>
                    <p className="text-[11px] font-semibold md:ms-4">
                      <Skeleton height={50} />
                    </p>
                  </div>
                </div>
                <p className="text-[18px] font-normal my-4 break-all"></p>
                <button
                  className="rounded-[10px]  text-[11px]
                           text-[#ffffff]  py-2 px-6  "
                >
                  <Skeleton height={50} />
                </button>
              </div>
              <div
                className="w-[85%] md:w-2/5 mt-4 ms-4 md:ms-6 md:mt-0 bg-[#202122]
                   shadow-md shadow-slate-800 rounded-t-[25px]  p-6  "
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="">
                    <p className="text-[15px] font-medium">
                      <Skeleton height={50} />
                    </p>
                    <p className="text-[30px] font-bold break-all">
                      <Skeleton height={50} />
                    </p>
                  </div>
                  <div className="flex justify-start content-end items-start">
                    <span className="ms-4 text-[22px]  font-semibold break-all">
                      <Skeleton height={50} />
                    </span>
                  </div>
                </div>

                <div className=" ">
                  <Skeleton height={50} />
                </div>
              </div>
            </div>
          </div>
          {/*Card for track record.*/}
          <p className="mb-2 text-[20px] font-semibold mt-6 md:mt-4 ">
            <Skeleton height={50} />
          </p>
          <div className="flex flex-col md:flex-row justify-start md:items-center content-start">
            <div className="w-auto md:w-[64%] chart-pdf">
              <div
                className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px]  w-[100%] md:w-auto mx-auto md:h-[350px]"
              >
                <div className="flex flex-col md:flex-row items-start justify-start md:items-center md:justify-center">
                  <div className="md:flex-none w-14 ">
                    <span className="text-[16px] font-bold">
                      <Skeleton height={50} />
                    </span>
                  </div>
                  <div className="md:flex-1  flex-col md:flex-row flex w-[300px] md:w-64  mt-4 md:mt-0">
                    <div className="flex flex-wrap items-start md:justify-center track_record w-[100%]">
                      <button className=" text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ">
                        <Skeleton height={50} />
                      </button>
                      <button className=" text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ">
                        <Skeleton height={50} />
                      </button>
                      <button className=" text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ">
                        <Skeleton height={50} />
                      </button>
                      <button className=" text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ">
                        <Skeleton height={50} />
                      </button>
                    </div>
                  </div>
                  <div
                    className={`flex-none w-[45%] md:w-36 text-[16px] font-bold mt-4 md:mt-0 `}
                  >
                    <button
                      className="w-full flex items-center justify-center
                               text-[11px] font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white "
                    >
                      <Skeleton height={50} />
                    </button>
                  </div>
                </div>
                <div className="mt-2 ">
                  <Skeleton height={250} />
                </div>
              </div>
            </div>
            <div className="w-auto md:w-[35%] ms-0 md:ms-6 mt-4 md:mt-0">
              <div
                className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px] md:h-[350px] w-[100%] md:w-full mx-auto"
              >
                <div className="grid grid-flow-row auto-rows-max ">
                  <div className="text-center">
                    <span className="text-[11px] text-[#868C96]">
                      <Skeleton height={50} />
                    </span>
                    <p className="text-[25px] font-medium break-all">
                      <Skeleton height={50} />
                    </p>
                  </div>
                  <hr className="border-slate-500 my-2" />
                  <div className="grid grid-cols-1 md:grid-cols-2 md:gap-4 md:divide-x md:divide-slate-500 ">
                    <div className="life text-center">
                      <span className="text-[11px] text-[#868C96]">
                        <Skeleton height={50} />
                      </span>
                      <p className="text-[25px] font-medium break-all">
                        <Skeleton height={50} />
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </SkeletonTheme>
    </>
  );
}

export default SharedProfileSkeleton;
