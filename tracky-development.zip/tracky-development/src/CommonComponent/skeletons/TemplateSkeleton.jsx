import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function TemplateSkeleton() {
  return (
    <>
      {" "}
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >

        <div className="card-container  grid grid-cols-1 md:grid-cols-4  gap-8 ">

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

          <div

            className="card  rounded-[10px] bg-[#373839]"
          >
            <div className="w-full">
              <Skeleton height={"200px"} />
            </div>
            <div className="p-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
            <div className="px-4 pb-4 pt-4">
              <Skeleton width={"200px"} height={"20px"} />

            </div>
          </div>

        </div>

      </SkeletonTheme>
    </>
  );
}

export default TemplateSkeleton;
