import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function LoginSecuritySkeleton() {
  return (
    <>
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="flex-col w-[80%]">
            <div className="w-full flex-col">
              <label className=" block w-full">
                <span className="block text-[18px] font-semibold mb-2">
                  <Skeleton width={400} height={25} />
                </span>
                <div className="w-full">
                  <Skeleton height={45} />
                </div>
              </label>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton width={300} height={25} />
              </span>
              <label className=" block w-full my-4">
                <span className="block text-[18px] font-semibold mb-2">
                  <Skeleton width={400} height={25} />
                </span>
                <div className="w-full">
                  <Skeleton w height={45} />
                </div>
              </label>
              <label className=" block w-full my-4">
                <span className="block text-[18px] font-semibold mb-2">
                  <Skeleton width={400} height={25} />
                </span>
                <div className="w-full">
                  <Skeleton w height={45} />
                </div>
              </label>
              <label className=" block w-full my-4">
                <span className="block text-[18px] font-semibold mb-2">
                  <Skeleton width={400} height={25} />
                </span>
                <div className="w-full">
                  <Skeleton w height={45} />
                </div>
              </label>
              {/*delete account skeleton*/}
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton width={150} height={25} />
              </span>
              <span className="block text-[18px] font-semibold ">
                <Skeleton width={250} height={25} />
              </span>
            </div>
          </div>
          {/*right side*/}
          <div className="flex-col w-full">
            <span className="block text-[18px] font-semibold mb-2">
              <Skeleton width={400} height={25} />
            </span>
            <span className="block text-[18px] font-semibold mb-2">
              <Skeleton width={600} height={25} />
            </span>
            <span className="block text-[18px] font-semibold my-4">
              <Skeleton height={150} />
            </span>
            <span className="block text-[18px] font-semibold mb-2">
              <Skeleton width={200} height={25} />
            </span>
            <div className="flex justify-start items-center content-center">
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={60}
                />
              </span>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={60}
                />
              </span>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={60}
                />
              </span>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={10}
                />
              </span>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={60}
                />
              </span>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={60}
                />
              </span>
              <span className="block text-[18px] font-semibold my-4">
                <Skeleton
                  className="bg-transparent  
              rounded-sm py-2 px-4 me-4
                        "
                  width={50}
                  height={60}
                />
              </span>
            </div>
            <span className="block text-[18px] font-semibold mb-2">
              <Skeleton width={300} height={25} />
            </span>
            <div className="mt-4 flex justify-start items-center">
              <span className="block text-[18px] font-semibold mb-2 me-6">
                <Skeleton width={200} height={50} />
              </span>
              <span className="block text-[18px] font-semibold mb-2">
                <Skeleton width={200} height={50} />
              </span>
            </div>
          </div>
        </div>
      </SkeletonTheme>
    </>
  );
}

export default LoginSecuritySkeleton;
