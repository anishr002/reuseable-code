import React from 'react';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';

function ManagePlanSkeleton() {
  return (
    <>
      <SkeletonTheme
        baseColor='#181818'
        highlightColor='#252525'
        borderRadius='0.5rem'
        duration={2}>
        <Skeleton width={200} height={50} />

        <div className='w-full'>
          <h1 className='text-[20px] md:text-[30px] font-semibold '>
            <Skeleton width={300} height={50} />
          </h1>
          <div className='flex flex-row items-center justify-between'>
            <p className='text-[16px] '>
              <Skeleton width={200} height={50} />
            </p>
            <button
              className=' bg-transparent  text-[15px] font-medium
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px] me-6
                               flex items-center justify-end
                  '
              type='button'>
              <Skeleton width={200} height={30} />
            </button>
          </div>

          <form>
            <div className='mt-6 '>
              <div className='grid w-3/5 grid-flow-row md:shrink-0 auto-rows-max'>
                <>
                  <label
                    class='has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            mb-4 cursor-pointer'>
                    <div className='flex flex-col items-center content-center h-full md:flex-row'>
                      <div className='flex-none mb-2 md:md-0'></div>
                      <div className='flex-auto w-64  mx-[10px] ps-4 text-center md:text-left'>
                        <div className='grid grid-flow-row auto-rows-max'>
                          <div className='text-[18px] mb-4 font-bold'>
                            <Skeleton width={400} height={20} />
                          </div>
                          <div className='text-[16px] mb-4'>
                            <Skeleton width={200} height={20} />
                          </div>
                        </div>
                      </div>

                      <div className='flex-none md:flex-1'>
                        <button
                          className='w-full px-[30px] rouned_button_transparent text-center h-[50px]
                                            shadow-2xl
                  flex items-center justify-center'
                          type='button'>
                          <Skeleton width={200} height={20} />
                        </button>
                      </div>
                    </div>
                  </label>
                  <label
                    class='has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            mb-4 cursor-pointer'>
                    <div className='flex flex-col items-center content-center h-full md:flex-row'>
                      <div className='flex-none mb-2 md:md-0'></div>
                      <div className='flex-auto w-64  mx-[10px] ps-4 text-center md:text-left'>
                        <div className='grid grid-flow-row auto-rows-max'>
                          <div className='text-[18px] mb-4 font-bold'>
                            <Skeleton width={400} height={20} />
                          </div>
                          <div className='text-[16px] mb-4'>
                            <Skeleton width={200} height={20} />
                          </div>
                        </div>
                      </div>

                      <div className='flex-none md:flex-1'>
                        <button
                          className='w-full px-[30px] rouned_button_transparent text-center h-[50px]
                                            shadow-2xl
                  flex items-center justify-center'
                          type='button'>
                          <Skeleton width={200} height={20} />
                        </button>
                      </div>
                    </div>
                  </label>
                  {/* </div> */}
                </>

                <button
                  type='submit'
                  className='rounded-[8px] border-2  text-[15px] font-medium
                            py-[10px] px-[30px] grow'>
                  <>
                    <div
                      className='mx-auto text-center flex justify-center
                       items-center content-center w-[100%]'>
                      <Skeleton width={800} height={15} />
                    </div>
                  </>
                </button>
              </div>
            </div>
          </form>
        </div>
      </SkeletonTheme>
    </>
  );
}

export default ManagePlanSkeleton;
