import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function SidebarConvoListSkeleton() {
  return (
    <>
      {" "}
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
        <Skeleton className="w-full h-screen" />
      </SkeletonTheme>
    </>
  );
}

export default SidebarConvoListSkeleton;
