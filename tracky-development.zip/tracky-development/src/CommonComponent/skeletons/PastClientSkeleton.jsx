import React from 'react';
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

function PastClientSkeleton() {

  return (
    <>
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >


        <div
          className="p-2 flex flex-row overflow-x-auto w-full h-screen items-center  justify-start"

        >
          <div
            className="rounded-full w-[40px] h-[40px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
          >

            <Skeleton
              circle
              height="100%"
              containerClassName="avatar-skeleton"
            />
          </div>
          <div className="ms-4 md:ms-8 mb-2 w-[20%] truncate">
            <p className="text-[14px] font-medium">
              <Skeleton width={100} height={50} />
            </p>
            <p className="text-[16px] text-[#868C96] mt-2 truncate">
              <Skeleton width={200} height={50} />
            </p>
          </div>
          <div className="ms-0 md:ms-8 mb-2 w-[10%] truncate ">
            <p className="text-[14px] font-medium">
              <Skeleton width={100} height={50} />
            </p>
            <p className="text-[16px] text-[#868C96] mt-2 truncate ">
              <Skeleton width={200} height={50} />
            </p>
          </div>
          <div className="ms-0 md:ms-8 mb-2 w-[30%] truncate">
            <p className="text-[14px] font-medium">
              <Skeleton width={100} height={50} />
            </p>
            <p className="text-[16px] text-[#868C96] mt-2 capitalize truncate">
              <Skeleton width={200} height={50} />
            </p>
          </div>
          <div className="ms-0 md:ms-8 mb-2 w-[10%] truncate">
            <p className="text-[14px] font-medium">
              <Skeleton width={100} height={50} />
            </p>
            <p className="text-[16px] text-[#868C96] mt-2 truncate">
              <Skeleton width={200} height={50} />
            </p>
          </div>
          <div className="ms-0 md:ms-8 mb-2 w-[10%] float-right text-right">
            <p className="text-[14px] font-medium">
              <Skeleton width={100} height={50} />
            </p>
            <div className="flex items-center justify-end mt-2">
              <Skeleton width={200} height={50} />
            </div>
          </div>
        </div>

      </SkeletonTheme>
    </>
  )
}

export default PastClientSkeleton;
