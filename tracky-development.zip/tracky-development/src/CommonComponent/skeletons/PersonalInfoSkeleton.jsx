import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

import rounded from "../../assets/rounded.svg";
import alex_img from "../../assets/alex_img.svg";

function PersonalInfoSkeleton() {
  return (
    <>
      <SkeletonTheme
        baseColor="#181818"
        highlightColor="#252525"
        borderRadius="0.5rem"
        duration={2}
      >
        {/* <Skeleton width={200} height={50} /> */}

        <div className="w-full   text-[#ffffff]">
          <h1 className="text-[30px] font-semibold mb-[16px]">
            <Skeleton width={200} height={50} />
          </h1>
          {/* form section start*/}

          <form>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="flex-col w-full">
                <div className="w-full block md:flex md:items-center ">
                  <label className=" block w-full md:w-[40%]">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>

                  <label className=" block w-full md:w-[30%] me-2">
                    <span className="block text-[14px] font-normal mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>

                  <label className=" block w-full md:w-[30%] me-2">
                    <span className="block text-[14px] font-normal mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>
                </div>
                <div className="w-full block md:flex my-6">
                  <label className=" block w-full md:w-[40%] ">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton width={150} height={50} />
                  </label>
                  <label className=" block w-full md:w-[40%] ">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>
                  <label className=" block w-full md:w-[25%] ">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={80} />
                  </label>
                </div>
                <div className="w-full block md:flex my-6">
                  <label className=" block w-full ">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>
                </div>
                <div className="w-full">
                  <p className="text-[18px]">
                    <Skeleton height={30} />
                  </p>
                  <div
                    className="rounded-full w-[70px] h-[70px] mt-4 p-0
                      "
                  >
                    <Skeleton
                      circle
                      height="100%"
                      containerClassName="avatar-skeleton"
                    />
                  </div>
                </div>
              </div>

              {/* right two factor section start*/}

              <div className="flex-col w-full">
                <div className="w-full flex-col">
                  <label className=" block w-full">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>
                  <label className=" block w-full my-6">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>
                    <Skeleton height={50} />
                  </label>
                  <label className=" block w-full my-6">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton height={30} />
                    </span>

                    <Skeleton height={50} />
                  </label>
                  <label className=" block w-full chip_block mb-4">
                    <span className="block text-[18px] font-semibold mb-2">
                      <Skeleton width={100} height={30} />
                    </span>

                    <div
                      className="flex flex-wrap flex-row 
                                  items-center justify-start"
                    >
                      <div className="me-4 mt-4 mb-4">
                        <button
                          className="rounded-[8px] 
                                        text-[18px]
                                  py-2 px-4"
                          type="button"
                        >
                          <Skeleton height={30} />
                        </button>
                      </div>
                    </div>
                  </label>
                  <div className="w-full"></div>
                  <div className="flex flex-col md:flex-row items-center justify-start">
                    <button
                      className="rounded-[8px] bg-transparent  text-[15px] font-medium py-[15px]
                                w-full md:w-[50%]
                   md:me-4 mb-4 md:mb-0
                  "
                      type="button"
                    >
                      <Skeleton height={50} />
                    </button>
                    <button
                      className="rounded-[8px]   text-[15px] font-medium py-[15px]
                               w-full md:w-[50%]
                  "
                      type="submit"
                    >
                      <Skeleton height={50} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>

          {/* <DevTool control={control} /> */}
        </div>
      </SkeletonTheme>
    </>
  );
}

export default PersonalInfoSkeleton;
