import { createContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
export const SocketContext = createContext();

export const SocketContextProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isSocketConnected, setIsConnected] = useState(null);



  const ENDPOINT = process.env.REACT_APP_IO;

  useEffect(() => {
    setSocket(io(ENDPOINT, {
      autoConnect: true,
      transports: ['websocket']}));
  }, []);

  useEffect(() => {
    if (socket !== null && socket !== undefined) {
      function onConnect() {
        setIsConnected(true);
        console.log('Server Connected', 3333);
      }

      function onDisconnect() {
        setIsConnected(false);
        console.log('Server Disconnected', 3333);
      }

      socket?.on('connect', onConnect);
      socket?.on('disconnect', onDisconnect);
      // socket?.emit('ROOM', { id: response.data?.data?._id });

      return () => {
        socket?.off('connect', onConnect);
        socket?.off('disconnect', onDisconnect);
      };
    }
  }, [socket]);

  return (
    <>
      <SocketContext.Provider value={{ socket, isSocketConnected }}>
        {children}
      </SocketContext.Provider>
    </>
  );
};
