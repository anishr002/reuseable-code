export const ToastContent = ({ message }) => (
  <div>
    <h6>{message}</h6>
  </div>
);
