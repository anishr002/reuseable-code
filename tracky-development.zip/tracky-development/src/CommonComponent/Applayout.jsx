import React, { useState, useEffect } from "react";
import { Outlet } from "react-router-dom";
import Header from "../CommonComponent/Header";
import SideBar from "../CommonComponent/Sidebar";

function Applayout() {
  // const [showReffralDropdown, setShowReffralDropdown] = useState(false);
  const [showReffralDropdown, setShowReffralDropdown] = useState(true);

  const [open, setOpen] = useState(false);

  return (
    <>
      <nav
        className={`fixed top-0 inset-x-0 z-50 h-20  flex justify-between items-center bg-zinc-800 border-b border-[#525252]`}
      >
        <Header
          open={open}
          setOpen={setOpen}
          showReffralDropdown={showReffralDropdown}
          setShowReffralDropdown={setShowReffralDropdown}
        />
      </nav>
      <aside class=" pt-20 fixed inset-y-0 overflow-x-hidden overflow-y-auto ease-in duration-300 z-[2]">
        <SideBar
          open={open}
          setOpen={setOpen}
          showReffralDropdown={showReffralDropdown}
          setShowReffralDropdown={setShowReffralDropdown}
        />
      </aside>
      <main
        class={`${
          open ? "sidebarOpen " : "sidebarClose "
        } pt-20 ease-in duration-300`}
      >
        <Outlet />
      </main>
    </>
  );
}

export default Applayout;
