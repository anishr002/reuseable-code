import { combineReducers } from "@reduxjs/toolkit";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import authSlice from "./slices/authSlice";
import onBoabrdSlice from "./slices/onBoabrdSlice";
import resetPassWordSlice from "./slices/resetPassSlice";
import pastClientSlice from "./slices/pastClientSlice";
import referralSlice from "./slices/referralSlice";
import loginAndSecurity from "./slices/loginAndSecurity";
import sharedProfileSlice from "./slices/sharedProfileSlice";
import templateSlice from "./slices/templateSlice";
import PitchSlice from "./slices/PitchSlice";
import convoSlice from "./slices/convoSlice";
import notificationSlice from "./slices/notificationSlice"
// Reducers

const persistConfig = {
  key: "root",
  storage,
};

const appReducer = combineReducers({
  auth: authSlice,
  onboard: onBoabrdSlice,
  resetpass: resetPassWordSlice,
  pastclient: pastClientSlice,
  loginSecurity: loginAndSecurity,
  sharedprofile: sharedProfileSlice,
  referral: referralSlice,
  template: templateSlice,
  pitch: PitchSlice,
  convo:convoSlice,
  notification:notificationSlice
});
const rootReducer = (state, action) => {
  // if (action.type === "login/logoutdata") {
  //     state = undefined;
  // }
  return appReducer(state, action);
};
export const persistedReducer = persistReducer(persistConfig, rootReducer);
export default rootReducer;
