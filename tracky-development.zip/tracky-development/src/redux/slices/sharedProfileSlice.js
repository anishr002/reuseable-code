import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetReferral } from "./referralSlice";
import { resetPass } from "./resetPassSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";

//Slice initial state
const initialState = {
  loading: false,
  selectedTimePeriod: 12,
  sharedpastclientData: [],
  sharedprofileData: [],
  GetSharedProfileLoading: false,
  onlyChartChangeLoading: false,
};

export const GetSharedProfile =
  (_id, timePeriod, onlyChartChange) => async (dispatch) => {
    try {
      if (onlyChartChange == true) {
        dispatch(onlyChartChangeLoadingFun(true));
      } else {
        dispatch(GetSharedProfileLoadingFlag(true));
      }

      let apiUrl;
      if (timePeriod === 7 || timePeriod === 30) {
        apiUrl = `${process.env.REACT_APP_API_BASE_URL}user/shareProfile/${_id}?days=${timePeriod}`;
      } else if (timePeriod === 6 || timePeriod === 12) {
        apiUrl = `${process.env.REACT_APP_API_BASE_URL}user/shareProfile/${_id}?months=${timePeriod}`;
      } else {
        apiUrl = `${
          process.env.REACT_APP_API_BASE_URL
        }user/shareProfile/${_id}?months=${12}`;
      }

      const response = await axios.get(apiUrl);

      if (response.status === 200) {
        dispatch(getProfileData(response.data.data));

        if (onlyChartChange == true) {
          dispatch(onlyChartChangeLoadingFun(false));
        } else {
          dispatch(GetSharedProfileLoadingFlag(false));
        }
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        if (onlyChartChange == true) {
          dispatch(onlyChartChangeLoadingFun(false));
        } else {
          dispatch(GetSharedProfileLoadingFlag(false));
        }

        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (onlyChartChange == true) {
        dispatch(onlyChartChangeLoadingFun(false));
      } else {
        dispatch(GetSharedProfileLoadingFlag(false));
      }
    }
    if (onlyChartChange == true) {
      dispatch(onlyChartChangeLoadingFun(false));
    } else {
      dispatch(GetSharedProfileLoadingFlag(false));
    }
  };

//get Past clients
export const GetSharedPastClient = (_id, data) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/sharePastClient/${_id}`,
      data
    );

    if (response.status === 200) {
      dispatch(getsharedpastclients(response.data.data));

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }

    dispatch(loadingflag(false));
  }
};

const sharedProfileSlice = createSlice({
  name: "sharedprofileSlice",
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    GetSharedProfileLoadingFlag: (state, action) => {
      state.GetSharedProfileLoading = action.payload;
    },
    onlyChartChangeLoadingFun: (state, action) => {
      state.onlyChartChangeLoading = action.payload;
    },
    getProfileData: (state, action) => {
      state.sharedprofileData = action.payload;
    },
    getsharedpastclients: (state, action) => {
      state.sharedpastclientData = action.payload;
    },
    setSelectedTimePeriod: (state, action) => {
      state.selectedTimePeriod = action.payload;
    },
    resetSharedProfile: (state, action) => {
      state.loading = false;
      state.selectedTimePeriod = 12;
      state.sharedpastclientData = [];
      state.sharedprofileData = [];
      state.GetSharedProfileLoading = false;
      state.onlyChartChangeLoading = false;
    },
  },
});

export const {
  loadingflag,
  getProfileData,
  setSelectedTimePeriod,
  getsharedpastclients,
  GetSharedProfileLoadingFlag,
  onlyChartChangeLoadingFun,
  resetSharedProfile,
} = sharedProfileSlice.actions;

export default sharedProfileSlice.reducer;

// NOTE : Please manage the slice according to your requirement
