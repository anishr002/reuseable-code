import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetPastClient } from "./pastClientSlice";
import { resetReferral } from "./referralSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  loading: false,
  step: 1,
  selectedTimePeriod: 12,
  activeTimePeriod: 12,
  activeStep: 0,
  onboardRole: [],
  onboardData: [],
  stepwiseData: {},
  onboardpaymentData: [],
  DownloadCsvData: [],
  PersonalinfoData: [],
  getDashboardTrackData: [],
  getDashboardProfileData: [],
  getDashboardChartData: [],
  hideProfileData: [],
  updatePaymentLogin: false,
  hideshareprofileloader: false,
  UpdateOnBoardPerloading: false,
  upadteRecordLoading: false,
  GetOnBoardPaymentsloading: false,
  checkUserCompleteOnboardloading: false,
  DashOnlyChartChangeloading: false,
};

//
export const AddOnBoard = (data, navigate, token) => async (dispatch) => {
  try {
    dispatch(AddOnBoardLoadflagFun(true));
    const response = await axios.put(
      `${process.env.REACT_APP_API_BASE_URL}user/profile`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(onBoard(response.data.data));

      if(response?.data?.data && response?.data?.data?.on_board_complete && response?.data?.data?.on_board_complete== true){
      dispatch(OnBoardPersonalInfo(token));
        navigate("/dashboard");
      }else{
        window.open(response.data.data.checkout_url);
      }

      dispatch(AddOnBoardLoadflagFun(false));
      dispatch(resetformdata());

      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(AddOnBoardLoadflagFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(AddOnBoardLoadflagFun(false));
  }
};

//update plan
export const UpdatePaymentPlan = (data, token) => async (dispatch) => {
  try {
    dispatch(updatePayLogin(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}payment/checkout`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(onBoard(response.data.data));

      dispatch(updatePayLogin(false));
      // navigate("/dashboard");
      window.open(response.data.data.checkout_url);
      dispatch(resetformdata());

      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(updatePayLogin(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(loadingflag(false));
  }
};

export const GetOnBoardRoles = (token) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}role/roles`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(BoardRole(response.data.data));

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(loadingflag(false));
  }
};

export const GetOnBoardPayments = (token) => async (dispatch) => {
  try {
    dispatch(GetOnBoardPaymentsloadingFun(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}payment`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(BoardPayment(response.data.data));
      dispatch(GetOnBoardPaymentsloadingFun(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(GetOnBoardPaymentsloadingFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(GetOnBoardPaymentsloadingFun(false));
  }
};

export const DownloadOnboard = (id, token) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}track/download-csv/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        responseType: "arraybuffer",
      }
    );

    if (response.status === 200) {
      const blob = new Blob([response.data], {
        type: "application/octet-stream",
      });

      const downloadLink = document.createElement("a");
      downloadLink.href = URL.createObjectURL(blob);

      downloadLink.download = "sampleTemplate.csv";

      document.body.appendChild(downloadLink);
      downloadLink.click();

      document.body.removeChild(downloadLink);

      dispatch(downloadCSV(response.data.data));

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(loadingflag(false));
  }
};

export const OnBoardPersonalInfo = (token) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}user/fetchProfile`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(BoardPersonalInfo(response.data.data));

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      // toast.error(<ToastContent message={err?.response?.data?.message} />, {
      //   position: "top-right",
      //   autoClose: 5000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // });
    }

    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(loadingflag(false));
  }
};

export const checkUserCompleteOnboard =
  (token, navigate, nextstep) => async (dispatch) => {
    try {
      dispatch(checkUserCompleteOnboardloadingfun(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}user/fetchProfile`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        if (response.data.data.profileData.on_board == true) {
          navigate("/dashboard");
        } else {
          nextstep(1);
        }

        dispatch(BoardPersonalInfo(response.data.data));
        dispatch(checkUserCompleteOnboardloadingfun(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(checkUserCompleteOnboardloadingfun(false));
        toast.error(err?.response?.data?.message);
      }

      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(checkUserCompleteOnboardloadingfun(false));
    }
    dispatch(checkUserCompleteOnboardloadingfun(false));
  };

export const UpdateOnBoardPersonalInfo =
  (data, token, navigate) => async (dispatch) => {
    try {
      dispatch(UpdateOnBoardPerloadingFun(true));
      const response = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}user/editProfile`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(BoardPersonalInfo(response.data.data));
        dispatch(OnBoardPersonalInfo(token));

        dispatch(UpdateOnBoardPerloadingFun(false));
        navigate("/accountoverview");

        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(UpdateOnBoardPerloadingFun(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(UpdateOnBoardPerloadingFun(false));
    }
  };

//get data according to date change
export const GetDashboardTrack = (data, token) => async (dispatch) => {
  try {
    dispatch(UpdateOnBoardPerloadingFun(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}track/fetchdate/${data}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      // dispatch(BoardPersonalInfo(response.data.data));
      dispatch(getTrackData(response.data.data));

      dispatch(UpdateOnBoardPerloadingFun(false));
      // navigate("/accountoverview");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(UpdateOnBoardPerloadingFun(false));
      // toast.error(<ToastContent message={err?.response?.data?.message} />, {
      //   position: "top-right",
      //   autoClose: 5000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(UpdateOnBoardPerloadingFun(false));
  }
};

//update dashboard pop up data
export const UpdateDashboardPersonalInfo =
  (data, token, onClose, activeTimePeriod) => async (dispatch) => {
    try {
      dispatch(UpdateRecordPerloadingFun(true));
      const response = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}track/update`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        // dispatch(BoardPersonalInfo(response.data.data));
        dispatch(UpdateRecordPerloadingFun(false));
        onClose();
        dispatch(GetDashboardProfile(token));
        dispatch(GetDashboardChart(token, activeTimePeriod));
        dispatch(setActiveTimePeriod(activeTimePeriod));

        // navigate("/accountoverview");

        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(UpdateRecordPerloadingFun(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(UpdateRecordPerloadingFun(false));
    }
  };

//Get Dashboard data
export const GetDashboardProfile = (token) => async (dispatch) => {
  try {
    dispatch(UpdateOnBoardPerloadingFun(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}track/fetch`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      // dispatch(BoardPersonalInfo(response.data.data));
      dispatch(getDashboard(response.data.data));

      dispatch(UpdateOnBoardPerloadingFun(false));
      // navigate("/accountoverview");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(UpdateOnBoardPerloadingFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(UpdateOnBoardPerloadingFun(false));
  }
};

//Get DashboardChart data
export const GetDashboardChart =
  (token, timePeriod, onlyChartChange) => async (dispatch) => {
    try {
      if (onlyChartChange == true) {
        dispatch(DashOnlyChartChangeloadingFun(true));
      } else {
        dispatch(UpdateOnBoardPerloadingFun(true));
      }

      let apiUrl;
      if (timePeriod === 7 || timePeriod === 30) {
        apiUrl = `${process.env.REACT_APP_API_BASE_URL}track/monthly-data?days=${timePeriod}`;
      } else if (timePeriod === 6 || timePeriod === 12) {
        apiUrl = `${process.env.REACT_APP_API_BASE_URL}track/monthly-data?months=${timePeriod}`;
      } else {
        apiUrl = `${
          process.env.REACT_APP_API_BASE_URL
        }track/monthly-data?months=${12}`;
      }

      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.status === 200) {
        dispatch(getDashboardChart(response.data.data));

        if (onlyChartChange == true) {
          dispatch(DashOnlyChartChangeloadingFun(false));
        } else {
          dispatch(UpdateOnBoardPerloadingFun(false));
        }
        // navigate("/accountoverview");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        if (onlyChartChange == true) {
          dispatch(DashOnlyChartChangeloadingFun(false));
        } else {
          dispatch(UpdateOnBoardPerloadingFun(false));
        }

        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      if (onlyChartChange == true) {
        dispatch(DashOnlyChartChangeloadingFun(false));
      } else {
        dispatch(UpdateOnBoardPerloadingFun(false));
      }
    }
    if (onlyChartChange == true) {
      dispatch(DashOnlyChartChangeloadingFun(false));
    } else {
      dispatch(UpdateOnBoardPerloadingFun(false));
    }
  };

//Hide Shared Profile
export const HideSharedProfile =
  (data, token, setShowSettingToggleModal) => async (dispatch) => {
    try {
      dispatch(hideProfileLoader(true));
      const response = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}user/settings`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
        dispatch(GetDashboardProfile(token));
        dispatch(HideProfile(response.data.data));
        setShowSettingToggleModal(false);
        // reset();
        dispatch(hideProfileLoader(false));
        // navigate("/dashboard");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(hideProfileLoader(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(hideProfileLoader(false));
    }
  };

const onBoabrdSlice = createSlice({
  name: "onboardSlice",
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    onBoard: (state, action) => {
      state.onboardData = action.payload;
    },
    BoardRole: (state, action) => {
      state.onboardRole = action.payload;
    },
    BoardPayment: (state, action) => {
      state.onboardpaymentData = action.payload;
    },
    downloadCSV: (state, action) => {
      state.DownloadCsvData = action.payload;
    },
    getTrackData: (state, action) => {
      state.getDashboardTrackData = action.payload;
    },
    getDashboard: (state, action) => {
      state.getDashboardProfileData = action.payload;
    },
    resetgetTrackData: (state, action) => {
      state.getDashboardTrackData = [];
    },
    BoardPersonalInfo: (state, action) => {
      state.PersonalinfoData = action.payload;
    },
    getDashboardChart: (state, action) => {
      state.getDashboardChartData = action.payload;
    },
    setStep: (state) => {
      state.step += 1;
    },
    Backstep: (state) => {
      state.step -= 1;
      state.activeStep -= 1;
    },
    setActiveStep: (state) => {
      state.activeStep += 1;
    },
    resetStep: (state) => {
      state.step = 1;
      state.activeStep = 0;
    },
    setSelectedTimePeriod: (state, action) => {
      state.selectedTimePeriod = action.payload;
    },
    setActiveTimePeriod: (state, action) => {
      state.activeTimePeriod = action.payload;
    },
    resetOnBoard: (state) => {
      state.loading = false;
      state.step = 1;
      state.selectedTimePeriod = 12;
      state.activeTimePeriod = 12;
      state.activeStep = 0;
      state.onboardRole = [];
      state.onboardData = [];
      state.stepwiseData = {};
      state.onboardpaymentData = [];
      state.DownloadCsvData = [];
      state.PersonalinfoData = [];
      state.getDashboardTrackData = [];
      state.getDashboardProfileData = [];
      state.getDashboardChartData = [];
      state.updatePaymentLogin = false;
      state.hideProfileData = [];
      state.hideshareprofileloader = false;
      state.UpdateOnBoardPerloading = false;
      state.GetOnBoardPaymentsloading = false;
      state.upadteRecordLoading = false;
      state.checkUserCompleteOnboardloading = false;
      state.DashOnlyChartChangeloading = false;
    },
    nextFormdata: (state, action) => {
      state.stepwiseData = action.payload;
    },
    HideProfile: (state, action) => {
      state.hideProfileData = action.payload;
    },
    resetformdata: (state) => {
      state.stepwiseData = {};
    },
    updatePayLogin: (state, action) => {
      state.updatePaymentLogin = action.payload;
    },
    hideProfileLoader: (state, action) => {
      state.hideshareprofileloader = action.payload;
    },
    UpdateOnBoardPerloadingFun: (state, action) => {
      state.UpdateOnBoardPerloading = action.payload;
    },
    UpdateRecordPerloadingFun: (state, action) => {
      state.upadteRecordLoading = action.payload;
    },
    GetOnBoardPaymentsloadingFun: (state, action) => {
      state.GetOnBoardPaymentsloading = action.payload;
    },
    AddOnBoardLoadflagFun: (state, action) => {
      state.AddOnBoardLoadflag = action.payload;
    },
    checkUserCompleteOnboardloadingfun: (state, action) => {
      state.checkUserCompleteOnboardloading = action.payload;
    },
    DashOnlyChartChangeloadingFun: (state, action) => {
      state.DashOnlyChartChangeloading = action.payload;
    },
  },
});

export const {
  loadingflag,
  setStep,
  onBoard,
  resetStep,
  setActiveStep,
  BoardRole,
  downloadCSV,
  BoardPayment,
  BoardPersonalInfo,
  hideProfileLoader,
  HideProfile,
  GetOnBoardPaymentsloadingFun,
  resetOnBoard,
  getDashboardChart,
  UpdateOnBoardPerloadingFun,
  AddOnBoardLoadflagFun,
  getTrackData,
  Backstep,
  nextFormdata,
  resetformdata,
  updatePayLogin,
  resetgetTrackData,
  getDashboard,
  setSelectedTimePeriod,
  UpdateRecordPerloadingFun,
  setActiveTimePeriod,
  checkUserCompleteOnboardloadingfun,
  DashOnlyChartChangeloadingFun,
} = onBoabrdSlice.actions;

export default onBoabrdSlice.reducer;

// NOTE : Please manage the slice according to your requirement
