import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetReferral } from "./referralSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetTemplate } from "./templateSlice.js";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  loading: true,
  resendloading: false,
  qrdata: {},
  verifysubmitdata: [],
  saveloading: false,
};

//
export const initialGetqr = (accessToken) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}user/qrGenerate`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );
    if (response.data.success) {
      dispatch(initialQrData(response.data.data));
      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(initialQrData({}));
  }
  dispatch(loadingflag(false));
};

export const resendGetqr = (accessToken) => async (dispatch) => {
  try {
    dispatch(resendloadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}user/qrGenerate`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (response.data.success) {
      dispatch(initialQrData(response.data.data));
      dispatch(resendloadingflag(false));

      // toast.success(response.data.message);
      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(resendloadingflag(false));

      // toast.error(err?.response?.data?.message
      //   , {
      //   position: "top-right",
      //   autoClose: 5000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // }
      // );

      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(initialQrData({}));
  }
  dispatch(resendloadingflag(false));
};

export const saveLoadingandSecurity =
  (accessToken, formData, navigate, successDeleteAccount) =>
  async (dispatch) => {
    try {
      dispatch(saveloadingflag(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}user/verify-2FA`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (response.data.success) {
        dispatch(resverifysubmitdata(response.data.data));
        dispatch(saveloadingflag(false));
        successDeleteAccount();
        setTimeout(() => {
          navigate("/accountoverview");
        }, 4000);
        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(saveloadingflag(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
    }
    dispatch(saveloadingflag(false));
  };

const loginSecuritySlice = createSlice({
  name: "loginSecuritySlice",
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    initialQrData: (state, action) => {
      state.qrdata = action.payload;
    },
    resendloadingflag: (state, action) => {
      state.resendloading = action.payload;
    },
    saveloadingflag: (state, action) => {
      state.saveloading = action.payload;
    },
    resverifysubmitdata: (state, action) => {
      state.verifysubmitdata = action.payload;
    },
    resetloginSecurity: (state, action) => {
      state.loading = true;
      state.resendloading = false;
      state.qrdata = {};
      state.verifysubmitdata = [];
      state.saveloading = false;
    },
  },
});

export const {
  loadingflag,
  initialQrData,
  resendloadingflag,
  saveloadingflag,
  resverifysubmitdata,
  resetloginSecurity,
} = loginSecuritySlice.actions;

export default loginSecuritySlice.reducer;

// NOTE : Please manage the slice according to your requirement
