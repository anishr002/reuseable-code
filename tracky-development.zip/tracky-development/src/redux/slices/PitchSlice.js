import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetReferral } from "./referralSlice";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  UserFirstPrompts: {},
  UserFromPitchGenerator: false,
  allPitchData: [],
  getPitchLoading: false,
  renamePitchLoading: false,
  renamePitchResponce: {},
};

export const getAllPitch = (token) => async (dispatch) => {
  try {
    dispatch(getPitchLoadingFun(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}pitch`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(allPitchDataFun(response.data.data));
      dispatch(getPitchLoadingFun(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(getPitchLoadingFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetPitch());
      dispatch(resetConvo());
    }
  }
  dispatch(getPitchLoadingFun(false));
};

export const renamePitch =
  (
    token,
    pitchID,
    formData,
    setShowInputID,
    setCurrentRenameChatID,
    setRenameChat
  ) =>
  async (dispatch) => {
    try {
      dispatch(renamePitchLoadingFun(true));
      const response = await axios.patch(
        `${process.env.REACT_APP_API_BASE_URL}pitch/update/${pitchID}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        // dispatch(renamePitchResponceFun(response.data.data));

        dispatch(renamePitchLoadingFun(false));
        dispatch(getAllPitch(token));
        setShowInputID(null);
        setCurrentRenameChatID(null);
        setRenameChat("");
        toast.success(response.data.message);
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(renamePitchLoadingFun(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
    }
    dispatch(renamePitchLoadingFun(false));
  };

export const sendInitialPitchData =
  (saveUserFirstPrompts) => async (dispatch) => {
    dispatch(UserFirstPromptsFun(saveUserFirstPrompts));
  };

const PitchSlice = createSlice({
  name: "PitchSlice",
  initialState,
  reducers: {
    UserFirstPromptsFun: (state, action) => {
      state.UserFirstPrompts = action.payload;
    },
    UserFromPitchGeneratorFun: (state, action) => {
      state.UserFromPitchGenerator = action.payload;
    },
    getPitchLoadingFun: (state, action) => {
      state.getPitchLoading = action.payload;
    },
    allPitchDataFun: (state, action) => {
      state.allPitchData = action.payload;
    },
    renamePitchLoadingFun: (state, action) => {
      state.renamePitchLoading = action.payload;
    },
    renamePitchResponceFun: (state, action) => {
      state.renamePitchResponce = action.payload;
    },
    resetPitch: (state, action) => {
      state.UserFirstPrompts = {};
      state.UserFromPitchGenerator = false;
      state.getPitchLoading = false;
      state.allPitchData = [];
        state.renamePitchLoading = false;
      state.renamePitchResponce = {};
    },
  },
});

export const {
  resetPitch,
  UserFirstPromptsFun,
  UserFromPitchGeneratorFun,
  getPitchLoadingFun,
  allPitchDataFun,
  renamePitchResponceFun,
  renamePitchLoadingFun,
} = PitchSlice.actions;

export default PitchSlice.reducer;

// NOTE : Please manage the slice according to your requirement
