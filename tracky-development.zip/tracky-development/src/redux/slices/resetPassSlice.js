import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetReferral } from "./referralSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  loading: false,
  resetPassResData: [],
};

//
export const resetPassWord = (data, navigate) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/resetPassword`,
      data
    );

    if (response.status === 200) {
      dispatch(resetPassWordData(response.data.data));
      dispatch(loadingflag(false));
      navigate("/login");
      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      navigate("/login");
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(loadingflag(false));
  }
  dispatch(loadingflag(false));
};

const resetPassWordSlice = createSlice({
  name: "resetPassWordSlice",
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    resetPassWordData: (state, action) => {
      state.resetPassResData = action.payload;
    },
    resetPass: (state, action) => {
      state.loading = false;
      state.resetPassResData = [];
    },
  },
});

export const { loadingflag, resetPassWordData, resetPass } =
  resetPassWordSlice.actions;

export default resetPassWordSlice.reducer;

// NOTE : Please manage the slice according to your requirement
