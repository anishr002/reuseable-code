import { createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
import { toast } from 'react-toastify';
import { ToastContent } from '../../CommonComponent/ToastContent';

import { resetOnBoard } from './onBoabrdSlice';
import { resetloginSecurity } from './loginAndSecurity';

import { resetPastClient } from './pastClientSlice';
import { resetReferral } from './referralSlice';
import { resetPass } from './resetPassSlice';

import { resetSharedProfile } from './sharedProfileSlice';
import { resetTemplate } from './templateSlice';
import { resetConvo } from './convoSlice.js';

import { resetPitch } from './PitchSlice.js';

//Slice initial state
const initialState = {
  data: [],
  googleData: [],
  forgotEmaildata: [],
  VerifyData: [],
  signupResData: {},
  submitsignupFormData: {},
  loading: false,
  appleData: [],
  googleInData: [],
  deleteaccountloading: false,
  deleteaccountres: [],
  signupfailapi: false,
  authstep: 1,
  ForgotEmailloadingFlag : false
};

// Login API
export const login = (data, navigate,socket) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/login`,
      data
    );

    if (response.status === 200) {
      dispatch(loginData(response.data.data));
      socket?.emit('ROOM', { id: response.data?.data?.user?._id });

      dispatch(loadingflag(false));
      response.data.data.user.on_board === true
        ? navigate('/dashboard')
        : navigate('/onboard');

      // toast.success(<ToastContent message={response.data.message} />, {
      //   position: "top-right",
      //   autoClose: 3000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: 'top-right',
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
    dispatch(loadingflag(false));
  }
  dispatch(loadingflag(false));
};

//apple sign in
export const appleSignupSlice = (signupData, navigate,socket) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/appleSignIn`,
      signupData
    );

    if (response.data.success) {
      dispatch(applesignupData(response.data.data));
      socket?.emit('ROOM', { id: response.data?.data?.user?._id });

      dispatch(loadingflag(false));
      response.data.data.user.on_board === true
        ? navigate('/dashboard')
        : navigate('/onboard');
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: 'top-right',
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
    dispatch(loadingflag(false));
  }
  dispatch(loadingflag(false));
};

//Google sign in

export const googleSignupSlicePost =
  (signupData, navigate,socket) => async (dispatch) => {
    try {
      dispatch(loadingflag(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}user/googleSignIn`,
        signupData
      );

      if (response.data.success) {
        dispatch(googlesignupData(response.data.data));
        socket?.emit('ROOM', { id: response.data?.data?.user?._id });

        dispatch(loadingflag(false));
        response.data.data.user.on_board === true
          ? navigate('/dashboard')
          : navigate('/onboard');
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(loadingflag(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: 'top-right',
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: 'dark',
        });
      }
      dispatch(loadingflag(false));
    }
    dispatch(loadingflag(false));
  };

//Verify email login

export const VerifyEmailLogin = (id, navigate,socket) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}user/verify?id=${id}`
    );

    if (response.data.success) {
      dispatch(verifyEmailData(response.data.data));
      socket?.emit('ROOM', { id: response.data?.data?.user?._id });

      dispatch(loadingflag(false));
      response.data.data.user.on_board === true
        ? setTimeout(() => {
            navigate('/dashboard');
          }, 4000)
        : setTimeout(() => {
            navigate('/onboard');
          }, 4000);

      dispatch(resetStep());
      dispatch(signupSubmittedFormData({}));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      navigate('/login');
      dispatch(resetStep());
      dispatch(signupSubmittedFormData({}));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: 'top-right',
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
    dispatch(loadingflag(false));
  }
  dispatch(loadingflag(false));
};

export const ForgotEmailPassword = (data, navigate) => async (dispatch) => {
  try {
    dispatch(ForgotEmailloadingFlagFun(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/forgetPassword`,
      data
    );

    if (response.status === 200) {
      dispatch(forgotPasswordData(response.data.data));
      dispatch(ForgotEmailloadingFlagFun(false));

      toast.success(<ToastContent message={response.data.message} />, {
        position: 'top-right',
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(ForgotEmailloadingFlagFun(false));

      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: 'top-right',
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
    dispatch(ForgotEmailloadingFlagFun(false));
  }
  dispatch(ForgotEmailloadingFlagFun(false));
};

export const googleSignInSlice = (signupData, navigate,socket) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/googleSignIn`,
      signupData
    );

    if (response.data.success) {
      dispatch(googlesignInData(response.data.data));
      socket?.emit('ROOM', { id: response.data?.data?.user?._id });

      dispatch(loadingflag(false));
      response.data.data.user.on_board === true
        ? navigate('/dashboard')
        : navigate('/onboard');
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: 'top-right',
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
    dispatch(loadingflag(false));
  }
  dispatch(loadingflag(false));
};

export const signupFormSlice =
  (signupFormData, nextstep, reset, setValue,socket) => async (dispatch) => {
    dispatch(signupSubmittedFormData(signupFormData));
    try {
      dispatch(loadingflag(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}user/register`,
        signupFormData
      );
      if (response.data.success) {
        dispatch(signupfailapiflag(false));
        // dispatch(signupSubmittedFormData({}));
        dispatch(signupresData(response.data.data));
        socket?.emit('ROOM', { id: response.data?.data?._id });

        dispatch(loadingflag(false));
        nextstep();

        toast.success(<ToastContent message={response.data.message} />, {
          position: 'top-right',
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: 'dark',
        });
      }
    } catch (err) {
      dispatch(signupfailapiflag(true));
      if (
        err?.response?.status === 400 ||
        err?.response?.status === 500 ||
        err?.response?.status === 401
      ) {
        dispatch(signupfailapiflag(true));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: 'top-right',
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: 'dark',
        });
      }
      dispatch(loadingflag(false));
    }
    dispatch(loadingflag(false));
  };

export const deleteaccount = (accessToken, navigate) => async (dispatch) => {
  try {
    dispatch(delacloadingflag(true));
    const response = await axios.delete(
      `${process.env.REACT_APP_API_BASE_URL}user`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (response.data.success) {
      dispatch(delacres(response.data.data));
      dispatch(delacloadingflag(false));
      dispatch(logoutData());
      navigate('/login');
      toast.success(<ToastContent message={response.data.message} />, {
        position: 'top-right',
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(delacloadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: 'top-right',
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'dark',
      });
    }

    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
  }
  dispatch(delacloadingflag(false));
};

const authSlice = createSlice({
  name: 'login',
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    ForgotEmailloadingFlagFun: (state, action) => {
      state.ForgotEmailloadingFlag = action.payload;
    },
    loginData: (state, action) => {
      state.data = action.payload;
    },
    googlesignupData: (state, action) => {
      state.googleData = action.payload;
    },
    verifyEmailData: (state, action) => {
      state.VerifyData = action.payload;
    },
    forgotPasswordData: (state, action) => {
      state.forgotEmaildata = action.payload;
    },
    logoutData: (state, action) => {
      state.data = [];
      state.googleData = [];
      state.forgotEmaildata = [];
      state.VerifyData = [];
      state.signupResData = {};
      state.submitsignupFormData = {};
      state.loading = false;
      state.appleData = [];
      state.googleInData = [];
      state.deleteaccountloading = false;
      state.deleteaccountres = [];
      state.signupfailapi = false;
      state.authstep = 1;
      state.ForgotEmailloadingFlag = false;
    },
    applesignupData: (state, action) => {
      state.appleData = action.payload;
    },
    googlesignInData: (state, action) => {
      state.googleInData = action.payload;
    },
    signupresData: (state, action) => {
      state.signupResData = action.payload;
    },
    signupSubmittedFormData: (state, action) => {
      state.submitsignupFormData = action.payload;
    },
    delacloadingflag: (state, action) => {
      state.deleteaccountloading = action.payload;
    },
    delacres: (state, action) => {
      state.deleteaccountres = action.payload;
    },
    signupfailapiflag: (state, action) => {
      state.signupfailapi = action.payload;
    },
    setStep: (state, action) => {
      state.authstep += 1;
    },
    resetStep: (state) => {
      state.authstep = 1;
    },
  },
});

export const {
  loadingflag,
  loginData,
  logoutData,
  forgotPasswordData,
  googlesignupData,
  verifyEmailData,
  applesignupData,
  googlesignInData,
  signupresData,
  signupSubmittedFormData,
  delacloadingflag,
  delacres,
  signupfailapiflag,
  setStep,
  resetStep,
  ForgotEmailloadingFlagFun
} = authSlice.actions;

export default authSlice.reducer;

// NOTE : Please manage the slice according to your requirement
