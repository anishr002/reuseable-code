import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetReferral } from "./referralSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  loading: false,
  getpastclientData: [],
  getsinglepastclientData: [],
  pastclientData: [],
  savingDataFlag: false,
};

//Add past Clients
export const AddPastClient = (data, navigate, token) => async (dispatch) => {
  try {
    dispatch(savingDataFlagFun(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}past-client/add `,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(PastClient(response.data.data));

      navigate("/dashboard");

      dispatch(savingDataFlagFun(false));

      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(savingDataFlagFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }

    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }

    dispatch(savingDataFlagFun(false));
  }
};

//update past Clients
export const UpdatePastClient =
  (data, id, navigate, token) => async (dispatch) => {
    try {
      dispatch(savingDataFlagFun(true));
      const response = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}past-client/edit/${id} `,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(PastClient(response.data.data));

        navigate("/dashboard");

        dispatch(savingDataFlagFun(false));

        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(savingDataFlagFun(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }

      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }

      dispatch(savingDataFlagFun(false));
    }
  };

//get Past clients
export const GetPastClient = (data, token) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}past-client/list`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(getpastclients(response.data.data));

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }

    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }

    dispatch(loadingflag(false));
  }
};

//get single past client
export const GetSinglePastClient = (id, token) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}past-client/fetch/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(getsinglepastclient(response.data.data));
      // setPage(1);

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }

    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }

    dispatch(loadingflag(false));
  }
};

export const DeletePastClient = (id, token, setPage) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.delete(
      `${process.env.REACT_APP_API_BASE_URL}past-client/delete/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(getpastclients(response.data.data));
      setPage(1);

      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }

    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(loadingflag(false));
  }
};

const pastClientSlice = createSlice({
  name: "pastclientSlice",
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    PastClient: (state, action) => {
      state.pastclientData = action.payload;
    },
    getpastclients: (state, action) => {
      state.getpastclientData = action.payload;
    },
    getsinglepastclient: (state, action) => {
      state.getsinglepastclientData = action.payload;
    },
    resetsinglepastclient: (state) => {
      state.getsinglepastclientData = [];
    },
    savingDataFlagFun: (state, action) => {
      state.savingDataFlag = action.payload;
    },
    resetPastClient: (state, action) => {
      state.loading = false;
      state.getpastclientData = [];
      state.getsinglepastclientData = [];
      state.pastclientData = [];
      state.savingDataFlag = false;
    },
  },
});

export const {
  loadingflag,
  PastClient,
  getpastclients,
  getsinglepastclient,
  resetsinglepastclient,
  savingDataFlagFun,
  resetPastClient,
} = pastClientSlice.actions;

export default pastClientSlice.reducer;

// NOTE : Please manage the slice according to your requirement
