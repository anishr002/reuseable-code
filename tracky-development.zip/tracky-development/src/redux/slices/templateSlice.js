import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice";
import { resetloginSecurity } from "./loginAndSecurity";
import { resetPastClient } from "./pastClientSlice";
import { resetReferral } from "./referralSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  GetAllTempGallaryLoad: false,
  addtemplateloading: false,
  personalloading: false,
  isLikeDislikeLoading: false,
  activefilter: "All",
  favoriteTemplateData: [],
  templateData: [],
  personaltemplateData: [],
  singleTemplateData: "",
};

//add tamplate
export const AddTemplateGallary =
  (
    data,
    token,
    reset,
    navigate,
    setShowTemplateModal,
    setSelectedRole,
    setAnswers,
    setSectionSaved,
    setSavedRole
  ) =>
  async (dispatch) => {
    try {
      dispatch(Addtemplateloading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}template/add`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        // dispatch(Alltemplate(response.data.data));
        // dispatch(GetPersonalTemplateGallary(token));

        dispatch(Addtemplateloading(false));
        reset();
        navigate("/templategallery");
        setShowTemplateModal(false);
        setSelectedRole("");
        setAnswers("");
        setSectionSaved([]);
        setSavedRole("");
        let myItem = localStorage.getItem("persist:root");
        localStorage.clear();
        localStorage.setItem("persist:root", myItem);

        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Addtemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Addtemplateloading(false));
    }
  };

//add convo tamplate
export const AddConvoTemplateGallary =
  (
    data,
    token,
    reset,
    navigate,
    setShowTemplateModal,
    setSelectedRole,
    setAnswers,
    setSectionSaved,
    setSavedRole
  ) =>
  async (dispatch) => {
    try {
      dispatch(Addtemplateloading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}template/add`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        // dispatch(Alltemplate(response.data.data));
        // dispatch(GetPersonalTemplateGallary(token));

        dispatch(Addtemplateloading(false));
        reset();
        navigate("/templategallery");
        setShowTemplateModal(false);
        setSelectedRole("");
        setAnswers("");
        setSectionSaved([]);
        setSavedRole("");
        let myItem = localStorage.getItem("persist:root");
        localStorage.clear();
        localStorage.setItem("persist:root", myItem);

        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Addtemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Addtemplateloading(false));
    }
  };

//add tamplate
export const GetAllTemplateGallary = (data, token) => async (dispatch) => {
  try {
    dispatch(GetAllTempGallaryLoadFun(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}template/list`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(Alltemplate(response.data.data));

      dispatch(GetAllTempGallaryLoadFun(false));

      // toast.success(<ToastContent message={response.data.message} />, {
      //   position: "top-right",
      //   autoClose: 2000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(GetAllTempGallaryLoadFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(GetAllTempGallaryLoadFun(false));
  }
};

//Get Single Template
export const GetSingleTemplateData = (id, token) => async (dispatch) => {
  try {
    dispatch(GetAllTempGallaryLoadFun(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}template/templateById/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(SingleTemplate(response.data.data));

      dispatch(GetAllTempGallaryLoadFun(false));

      // toast.success(<ToastContent message={response.data.message} />, {
      //   position: "top-right",
      //   autoClose: 2000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(GetAllTempGallaryLoadFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(GetAllTempGallaryLoadFun(false));
  }
};

//Get personal tamplate
export const GetPersonalTemplateGallary =
  (userID, data, token) => async (dispatch) => {
    try {
      dispatch(Personaltemplateloading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}template/listById/${userID}`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(AllPersonaltemplate(response.data.data));

        dispatch(Personaltemplateloading(false));

        // toast.success(<ToastContent message={response.data.message} />, {
        //   position: "top-right",
        //   autoClose: 2000,
        //   hideProgressBar: false,
        //   closeOnClick: true,
        //   pauseOnHover: true,
        //   draggable: true,
        //   progress: undefined,
        //   theme: "dark",
        // });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Personaltemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Personaltemplateloading(false));
    }
  };

//add Favorite tamplate
export const FavoriteTemplate = (data, token, payload) => async (dispatch) => {
  try {
    dispatch(Addtemplateloading(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}favourite/create`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(GetAllTemplateGallary(payload, token));

      dispatch(Addtemplateloading(false));
      // setIsFavorite(true);

      // navigate("/pitchgenerator");

      // toast.success(<ToastContent message={response.data.message} />, {
      //   position: "top-right",
      //   autoClose: 2000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "dark",
      // });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(Addtemplateloading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
    dispatch(Addtemplateloading(false));
  }
};

export const UpdatePitchTemplateGallary =
  (
    data,
    id,
    token,
    reset,
    navigate,
    setShowTemplateModal,
    setSelectedRole,
    setAnswers,
    setSectionSaved,
    setSavedRole
  ) =>
  async (dispatch) => {
    try {
      dispatch(Addtemplateloading(true));
      const response = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}template/update/${id}`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(GetSingleTemplateData(id, token));
        dispatch(Addtemplateloading(false));
        reset();
        // navigate("/pitchgenerator");
        setShowTemplateModal(false);

        toast.success(<ToastContent message={response.data.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Addtemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Addtemplateloading(false));
    }
  };

//delete fav tamplete
export const DeleteFavoriteTemplate =
  (id, token, payload) => async (dispatch) => {
    try {
      dispatch(Addtemplateloading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}favourite/delete/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(GetAllTemplateGallary(payload, token));

        dispatch(Addtemplateloading(false));
        // setIsFavorite(true);

        // navigate("/pitchgenerator");

        // toast.success(<ToastContent message={response.data.message} />, {
        //   position: "top-right",
        //   autoClose: 2000,
        //   hideProgressBar: false,
        //   closeOnClick: true,
        //   pauseOnHover: true,
        //   draggable: true,
        //   progress: undefined,
        //   theme: "dark",
        // });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Addtemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Addtemplateloading(false));
    }
  };

//add personal Favorite tamplate
export const PerasonalFavoriteTemplate =
  (data, token, userID, payload) => async (dispatch) => {
    try {
      dispatch(Addtemplateloading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}favourite/create`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(GetPersonalTemplateGallary(userID, payload, token));

        dispatch(Addtemplateloading(false));
        // setIsFavorite(true);

        // navigate("/pitchgenerator");

        // toast.success(<ToastContent message={response.data.message} />, {
        //   position: "top-right",
        //   autoClose: 2000,
        //   hideProgressBar: false,
        //   closeOnClick: true,
        //   pauseOnHover: true,
        //   draggable: true,
        //   progress: undefined,
        //   theme: "dark",
        // });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Addtemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Addtemplateloading(false));
    }
  };

//delete personal fav tamplete
export const DeletePersonalFavoriteTemplate =
  (id, token, userID, payload) => async (dispatch) => {
    try {
      dispatch(Addtemplateloading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}favourite/delete/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch(GetPersonalTemplateGallary(userID, payload, token));

        dispatch(Addtemplateloading(false));
        // setIsFavorite(true);

        // navigate("/pitchgenerator");

        // toast.success(<ToastContent message={response.data.message} />, {
        //   position: "top-right",
        //   autoClose: 2000,
        //   hideProgressBar: false,
        //   closeOnClick: true,
        //   pauseOnHover: true,
        //   draggable: true,
        //   progress: undefined,
        //   theme: "dark",
        // });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(Addtemplateloading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
        dispatch(resetConvo());
        dispatch(resetPitch());
      }
      dispatch(Addtemplateloading(false));
    }
  };

const templateSlice = createSlice({
  name: "templateSlice",
  initialState,
  reducers: {
    Addtemplateloading: (state, action) => {
      state.addtemplateloading = action.payload;
    },
    IsLikeDislikeLoading: (state, action) => {
      state.isLikeDislikeLoading = true;
    },
    Alltemplate: (state, action) => {
      state.templateData = action.payload;
      state.isLikeDislikeLoading = false;
    },
    SingleTemplate: (state, action) => {
      state.singleTemplateData = action.payload;
    },
    setActivefilter: (state, action) => {
      state.activefilter = action.payload;
    },
    AddFavoritetemplate: (state, action) => {
      state.favoriteTemplateData = action.payload;
    },
    AllPersonaltemplate: (state, action) => {
      state.personaltemplateData = action.payload;
      state.isLikeDislikeLoading = false;
    },
    Personaltemplateloading: (state, action) => {
      state.personalloading = action.payload;
    },
    GetAllTempGallaryLoadFun: (state, action) => {
      state.GetAllTempGallaryLoad = action.payload;
    },
    resetTemplate: (state) => {
      state.templateData = [];
      state.favoriteTemplateData = [];
      state.personaltemplateData = [];
      state.singleTemplateData = "";
      state.addtemplateloading = false;
      state.personalloading = false;
      state.activefilter = "All";
      state.GetAllTempGallaryLoad = false;
      state.isLikeDislikeLoading = false;
    },
    resertSingleTemplate: (state) => {
      state.singleTemplateData = "";
    },
  },
});

export const {
  Addtemplateloading,
  Alltemplate,
  AddFavoritetemplate,
  resetTemplate,
  setActivefilter,
  AllPersonaltemplate,
  SingleTemplate,
  Personaltemplateloading,
  GetAllTempGallaryLoadFun,
  resertSingleTemplate,
  IsLikeDislikeLoading,
} = templateSlice.actions;

export default templateSlice.reducer;

// NOTE : Please manage the slice according to your requirement
