import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  InitialLoading: false,
  referralStatistics: {},
  sendreferralEmailLoading: false,
};

//
export const getreferralStatisticsData = (token) => async (dispatch) => {
  try {
    dispatch(InitialLoadingflag(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}user/referral-status`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(referralStatisticsData(response.data.data));
      dispatch(InitialLoadingflag(false));
      navigate("/login");
      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(InitialLoadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
  }
  dispatch(InitialLoadingflag(false));
};

export const sendreferralEmail = (token, formData) => async (dispatch) => {
  try {
    dispatch(sendreferralEmailLoadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/invitation`,
      formData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.data.success) {
      // dispatch(resverifysubmitdata(response.data.data));
      dispatch(sendreferralEmailLoadingflag(false));
      toast.success(<ToastContent message={response.data.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(sendreferralEmailLoadingflag(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
  }
  dispatch(sendreferralEmailLoadingflag(false));
};

const referralSlice = createSlice({
  name: "referralSlice",
  initialState,
  reducers: {
    InitialLoadingflag: (state, action) => {
      state.InitialLoading = action.payload;
    },
    referralStatisticsData: (state, action) => {
      state.referralStatistics = action.payload;
    },
    sendreferralEmailLoadingflag: (state, action) => {
      state.sendreferralEmailLoading = action.payload;
    },
    resetReferral: (state, action) => {
      state.InitialLoading = false;
      state.referralStatistics = {};
      state.sendreferralEmailLoading = false;
    },
  },
});

export const {
  InitialLoadingflag,
  referralStatisticsData,
  sendreferralEmailLoadingflag,
  resetReferral,
} = referralSlice.actions;

export default referralSlice.reducer;

// NOTE : Please manage the slice according to your requirement
