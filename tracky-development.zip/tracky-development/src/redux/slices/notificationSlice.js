import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetReferral } from "./referralSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetPitch } from "./PitchSlice.js";
import { resetConvo } from "./convoSlice.js";

//Slice initial state
const initialState = {
  loading: false,
  notificationListData: {},
  markallreadload: false,
  marksinglereadload: false
};

//
export const getNotificationList = (token,data) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/notification/list`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(notificationListDataFun(response.data.data));
      dispatch(loadingflag(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingflag(false));
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
      dispatch(resetNotification());

    }
    dispatch(loadingflag(false));
  }
  dispatch(loadingflag(false));
};


export const markAllasRead = (token,data,notiPayload ) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));
    dispatch(markallreadloadFun(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/notification/read`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(loadingflag(false));
      dispatch(markallreadloadFun(false));
      dispatch(getNotificationList(token,notiPayload ));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(markallreadloadFun(false));
      dispatch(loadingflag(false));

    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
      dispatch(resetNotification());

    }
    dispatch(markallreadloadFun(false));
    dispatch(loadingflag(false));

  }
  dispatch(markallreadloadFun(false));
  dispatch(loadingflag(false));

};

export const markSingleRead = (token,data,notiPayload ) => async (dispatch) => {
  try {
    dispatch(loadingflag(true));

    dispatch(marksinglereadloadFun(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_BASE_URL}user/notification/read`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(loadingflag(false));
      dispatch(marksinglereadloadFun(false));
      dispatch(getNotificationList(token,notiPayload ));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(marksinglereadloadFun(false));
      dispatch(loadingflag(false));

    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
      dispatch(resetNotification());

    }
    dispatch(marksinglereadloadFun(false));
    dispatch(loadingflag(false));

  }
  dispatch(marksinglereadloadFun(false));
  dispatch(loadingflag(false));

};


const notificationSlice = createSlice({
  name: "notificationSlice",
  initialState,
  reducers: {
    loadingflag: (state, action) => {
      state.loading = action.payload;
    },
    marksinglereadloadFun: (state, action) => {
      state.marksinglereadload = action.payload;
    },
    markallreadloadFun: (state, action) => {
      state.markallreadload = action.payload;
    },
    notificationListDataFun: (state, action) => {
      state.notificationListData = action.payload;
    },
    resetNotification: (state, action) => {
      state.loading = false;
      state.notificationListData = {};
      state.marksinglereadload = false;
      state.markallreadload = false
    },
  },
});

export const { loadingflag, notificationListDataFun, resetNotification, marksinglereadloadFun, markallreadloadFun } =
  notificationSlice.actions;

export default notificationSlice.reducer;


