import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { logoutData } from "./authSlice";
import { resetOnBoard } from "./onBoabrdSlice.js";
import { resetPastClient } from "./pastClientSlice";
import { resetPass } from "./resetPassSlice";
import { resetSharedProfile } from "./sharedProfileSlice";
import { resetloginSecurity } from "./loginAndSecurity.js";
import { resetTemplate } from "./templateSlice.js";
import { resetReferral } from "./referralSlice";
import { resetPitch } from "./PitchSlice.js";
//Slice initial state
const initialState = {
  getAllConvoLoading: false,
  AllConvoData: [],
  renameConvoLoading: false,
};

export const getAllConvo = (token) => async (dispatch) => {
  try {
    dispatch(getAllConvoLoadingFun(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}pitch/calls`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      dispatch(AllConvoDataFun(response.data.data));
      dispatch(getAllConvoLoadingFun(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(getAllConvoLoadingFun(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
    if (err?.response?.status === 401) {
      dispatch(logoutData());
      dispatch(resetOnBoard());
      dispatch(resetloginSecurity());
      dispatch(resetPastClient());
      dispatch(resetReferral());
      dispatch(resetPass());
      dispatch(resetSharedProfile());
      dispatch(resetTemplate());
      dispatch(resetConvo());
      dispatch(resetPitch());
    }
  }
  dispatch(getAllConvoLoadingFun(false));
};

export const renameConvo =
  (
    token,
    convoID,
    formData,
    setShowInputID,
    setCurrentRenameChatID,
    setRenameChat
  ) =>
  async (dispatch) => {
    try {
      dispatch(renameConvoLoadingFun(true));
      const response = await axios.patch(
        `${process.env.REACT_APP_API_BASE_URL}pitch/update/${convoID}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        // dispatch(renamePitchResponceFun(response.data.data));
        dispatch(renameConvoLoadingFun(false));
        dispatch(getAllConvo(token));
        setShowInputID(null);
        setCurrentRenameChatID(null);
        setRenameChat("");
        toast.success(response.data.message);
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(renameConvoLoadingFun(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      if (err?.response?.status === 401) {
        dispatch(logoutData());
        dispatch(resetOnBoard());
        dispatch(resetloginSecurity());
        dispatch(resetPastClient());
        dispatch(resetReferral());
        dispatch(resetPass());
        dispatch(resetSharedProfile());
        dispatch(resetTemplate());
      dispatch(resetConvo());
        dispatch(resetPitch());
      }
    }
    dispatch(renameConvoLoadingFun(false));
  };

const convoSlice = createSlice({
  name: "convoSlice",
  initialState,
  reducers: {
    getAllConvoLoadingFun: (state, action) => {
      state.getAllConvoLoading = action.payload;
    },
    AllConvoDataFun: (state, action) => {
      state.AllConvoData = action.payload;
    },
    resetConvo: (state, action) => {
      state.getAllConvoLoading = false;
      state.AllConvoData = [];
      state.renameConvoLoading = false;
    },
    renameConvoLoadingFun: (state, action) => {
      state.renameConvoLoading = action.payload;
    },
  },
});

export const {
  getAllConvoLoadingFun,
  AllConvoDataFun,
  resetConvo,
  renameConvoLoadingFun,
} = convoSlice.actions;

export default convoSlice.reducer;

// NOTE : Please manage the slice according to your requirement
