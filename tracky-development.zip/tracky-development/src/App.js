import React, { Suspense } from "react";
import IndexRoutes from "./Router/IndexRoutes.jsx";
import { BrowserRouter } from "react-router-dom";
import { GoogleOAuthProvider } from "@react-oauth/google";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Spinner from "./CommonComponent/Spinner.jsx";
import {SocketContextProvider} from "./CommonComponent/context/SocketContextProvider.jsx"

function App() {

  if (process.env.NODE_ENV !== 'development'){
  console.error = function() {};
  console.warn = function () { };
  console.log = function () { };
  }

  return (
    <>
    <SocketContextProvider>
      <GoogleOAuthProvider
        clientId={process.env.REACT_APP_GOOGLE_AUTH_CLIENT_ID}
      >
        <Suspense fallback={<Spinner />}>
          <BrowserRouter>
            <IndexRoutes />
          </BrowserRouter>
        </Suspense>
      </GoogleOAuthProvider>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
        limit={1}
      />
      </SocketContextProvider>
    </>
  );
}

export default App;
