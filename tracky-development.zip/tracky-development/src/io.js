// import { io } from "socket.io-client";
// const ENDPOINT = process.env.REACT_APP_IO;
// let socket;

// export default socket = io(ENDPOINT);
