import React from "react";
import { useSelector } from "react-redux";
import { Navigate, useLocation } from "react-router-dom";
import { Outlet } from "react-router-dom/dist";

const ProtectedRoute = () => {
  const loginData = useSelector((state) => state?.root?.auth);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token || loginData?.googleInData?.token || loginData?.appleData?.token;
  return <>{auth ? <Outlet /> : <Navigate to="/" replace />}</>;
};

export default ProtectedRoute;
