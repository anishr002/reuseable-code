
import { useEffect } from 'react';
import { Navigate, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

const CheckOnboard = (WrappedComponent) => {
  const AuthComponent = (props) => {
    const navigate = useNavigate();
    const loginData = useSelector((state) => state?.root?.auth);
    const PersonalinfoData = useSelector(
      (state) => state?.root?.onboard?.PersonalinfoData
    );

    const onBoardFlag =
      PersonalinfoData?.profileData?.on_board === false &&
      (loginData?.data?.user?.on_board === false ||
        loginData?.googleData?.user?.on_board === false ||
        loginData?.VerifyData?.user?.on_board === false ||
        loginData?.signupResData?.on_board === false || loginData?.appleData?.user?.on_board === false || loginData?.googleInData?.user?.on_board === false);

    useEffect(() => {
      onBoardFlag && navigate("/onboard");
    }, []);

    return <WrappedComponent {...props} />;
  };

  return AuthComponent;
};

export default CheckOnboard;
