import React, { useEffect } from "react";

import logo_light from "../../assets/logo_light.svg";

function Signupstep2({ nextstep }) {
  const redirectTonextStep = () => {
    nextstep();
  };

  useEffect(() => {
    setTimeout(function () {
      nextstep();
    }, 3000);
    //eslint-disable-next-line
  }, []);

  return (
    <>
      <div
        className="flex items-center header h-[100px]
        header_bg light_line border-b-2 px-[60px] w-full"
      >
        <img src={logo_light} alt="light logo " />
      </div>

      <div className="dark-bg h-[100vh]  md:content text-[#ffffff] p-8">
        <div className="grid grid-flow-row auto-rows-max ">
          <div className="w-full px-[20px] rouned_button_white bg-[#21CE90] text-center h-[50px]  flex items-center justify-center content-center ju">
            <p onClick={redirectTonextStep}>
              Your account has succesfully been created. Redirecting you...
            </p>
          </div>
          <div className="mt-[60px] mx-auto">
            <img src={logo_light} alt="logo" />
          </div>
        </div>
      </div>
    </>
  );
}

export default Signupstep2;
