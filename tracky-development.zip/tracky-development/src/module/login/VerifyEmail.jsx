import React, { useEffect, useLayoutEffect, useContext } from "react";
import logo_light from "../../assets/logo_light.svg";
import { useNavigate } from "react-router-dom";
import { VerifyEmailLogin } from "../../redux/slices/authSlice";
import { useDispatch, useSelector } from "react-redux";
import Loader from "../../CommonComponent/Loader";
import { Helmet } from "react-helmet";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';

function VerifyEmail() {
  const urlParams = new URLSearchParams(window.location.search);
  const verifyid = urlParams.get("id");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loginData = useSelector((state) => state?.root?.auth);
  const { socket, isSocketConnected } = useContext(SocketContext);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  // useEffect(() => {
  //   if (verifyid !== null) {
  //     setTimeout(() => {
  //       dispatch(VerifyEmailLogin(verifyid, navigate,socket));
  //     }, 3000);
  //   }
  //   //eslint-disable-next-line
  // }, []);

  useLayoutEffect(() => {
  if (verifyid !== null) {
  // setTimeout(() => {
  //   dispatch(VerifyEmailLogin(verifyid, navigate,socket));
  // }, 3000);
  dispatch(VerifyEmailLogin(verifyid, navigate,socket));
  }
    //eslint-disable-next-line
  }, []);

  useEffect(() => {
  auth && navigate("/dashboard");
  }, []);

  return (
    <>
      <Helmet>
        <title>Tracky | Verifying</title>
        <meta name="description" content="Tracky | Verifying" />
      </Helmet>

      <div
        className="flex items-center w-full p-5 border-b-2 header header_bg light_line"
      >
        <img src={logo_light} alt="light logo " />
      </div>

      <div className="dark-bg h-screen  content email-verified-page text-[#ffffff] flex justify-center items-center">
        <div
          className=" border rounded-[12px] border-[#ffffff] py-[30px] px-[30px]
        m-10 w-80 md:w-[40%] mx-auto "
        >
          <div className="grid grid-flow-row auto-rows-max ">
            <p>Your account has been verified! Redirecting...</p>
          </div>
        </div>
      </div>
    </>
  );
}

export default VerifyEmail;
