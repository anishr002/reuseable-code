import React from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import { useNavigate } from "react-router-dom";
import logo_light from "../../assets/logo_light.svg";
import { ForgotEmailPassword } from "../../redux/slices/authSlice.js";
import { useDispatch,useSelector } from "react-redux";
import { Helmet } from "react-helmet";
import Loader from "../../CommonComponent/Loader.jsx";

function ForgotPassword() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .required("E-mail is required")
      .matches(
        /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
        "Please enter valid email address"
      ),
  });

  const saveForgotPassword = (data) => {
    dispatch(ForgotEmailPassword(data, navigate));
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const redirectToLogin = () => {
    navigate("/login");
  };

  const ForgotEmailloadingFlag = useSelector((state) => state?.root?.auth?.ForgotEmailloadingFlag);

  return (
    <>
      <Helmet>
        <title>Tracky | Forgot Password</title>
        <meta name="description" content="Tracky | Forgot Password" />
      </Helmet>
      <div
        className="flex items-center header p-4
        header_bg light_line border-b-2 w-full"
      >
        <img src={logo_light} alt="light logo " />
      </div>
      {/* content start here */}
      <div className="dark-bg  content forgetPassword text-[#ffffff] p-10 flex flex-col items-center justify-center">
        <div className="border rounded-[12px] border-[#ffffff] p-[30px] min-w-[40%] mx-auto">
          <div className="text-center md:shrink-0 mx-auto grid grid-flow-row auto-rows-max">
            <p className="sm:text-[40px] text-4xl font-bold mb-[40px] block">
              Forgot Password
            </p>
            <form onSubmit={handleSubmit(saveForgotPassword)}>
              <div className="">
                <div className="grid grid-cols-1 gap-4">
                  <div className="w-full">
                    <input
                      type="text"
                      className="w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                      placeholder="Email"
                      name="email"
                      {...register("email")}
                      autoComplete="off"
                      onKeyPress={handleKeyDown}
                    />
                    <ErrorMessage
                      errors={errors}
                      name="email"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-left text-sm ">{message}</p>
                      )}
                    />
                  </div>
                </div>
              </div>

              <button
                className="rouned_button_transparent w-full bg-[#21CE90] border-transparent border-0
                text-center h-[50px] mt-[20px]"
                type="submit"
              >

                {ForgotEmailloadingFlag ? (
                        <div
                      className=" flex justify-center
                       items-center content-center w-full"
                    >
                          <Loader />
                        </div>
                      ) : (
                        <>Send Email</>
                      )}
              </button>
            </form>

            <button className="mt-4 underline" onClick={redirectToLogin}>
              Back to Log in
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default ForgotPassword;
