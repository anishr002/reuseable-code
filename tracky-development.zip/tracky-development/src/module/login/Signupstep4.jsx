import React, { useEffect } from "react";

import spinner from "../../assets/spinner.svg";
import { Helmet } from "react-helmet";

function Signupstep4({ nextstep, setFlag }) {
  <Helmet>
    <title>Tracky | Verifying</title>
    <meta name="description" content="Tracky | Verifying" />
  </Helmet>;
  useEffect(() => {
    setFlag(true);
  }, []);
  return (
    <>
      <div className="grid grid-flow-row auto-rows-max self-center">
        <div className="mb-[30px]">
          <p className="mx-auto w-96 text-center  text-[30px] font-bold">
            Your account has been verified! Redirecting...
          </p>
        </div>
        <div className="mx-auto">
          <img src={spinner} alt="spinner" />
        </div>
      </div>
    </>
  );
}

export default Signupstep4;
