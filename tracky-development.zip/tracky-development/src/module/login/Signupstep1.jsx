import React, { useState, useEffect, useContext } from "react";
import apple_icn from "../../assets/apple_icn.svg";
import google_icn from "../../assets/google_icn.svg";
import { GoogleLogin } from "@react-oauth/google";
import data from "../../utils/country.json";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";

import logo_light from "../../assets/logo_light.svg";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';

import AppleSignin from "react-apple-signin-auth";
import {
  googleSignupSlicePost,
  appleSignupSlice,
  signupFormSlice,
} from "../../redux/slices/authSlice.js";
import Loader from "../../CommonComponent/Loader.jsx";

function Signupstep1({ nextstep, comeFromChangeEmail }) {
  const [privacy_policy, setPrivacyPolicy] = useState(false);
  const isLoading = useSelector((state) => state?.root?.auth?.loading);
  const urlParams = new URLSearchParams(window.location.search);
  const ReferralCode = urlParams.get("referral");

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const submitsignupFormData = useSelector(
    (state) => state?.root?.auth?.submitsignupFormData
  );
  const signupfailapiflag = useSelector(
    (state) => state?.root?.auth?.signupfailapi
  );

  const { socket, isSocketConnected } = useContext(SocketContext);

  const handleChange = () => {
    setPrivacyPolicy(!privacy_policy);
  };

  const validationSchema = Yup.object().shape({
    first_name: Yup.string()
      .required("First name is required")
      .max(30, "Maximum 30 characters allowed"),
    last_name: Yup.string()
      .required("Last name is required")
      .max(30, "Maximum 30 characters allowed"),
    email: Yup.string()
      .required("E-mail is required")
      .matches(
        /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
        "Please enter valid email address"
      ),
    password: Yup.string()
      .required("Password is required")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
        "Must contain 8 characters,at least one uppercase,lowercase, number and special case character"
      )
      .max(15, "Maximum 15 characters allowed"),
    privacy_policy: Yup.bool().oneOf(
      [true],
      "You must accept the privacy policy"
    ),
    country: Yup.string().required("Please select country"),
  });

  const redirectToLogin = () => {
    navigate("/login");
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    shouldUnregister: false,
    mode: "all",
  });

  const onSubmit = async (data) => {
    if (ReferralCode !== null && ReferralCode !== undefined && ReferralCode) {
      data = {
        ...data,
        ["referral_code"]: ReferralCode,
      };
    }

    dispatch(signupFormSlice(data, nextstep, reset, setValue,socket));
  };

  function isObjectNotEmpty(obj) {
    if (obj && typeof obj === "object") {
      return Object.keys(obj).length > 0;
    }

    return false;
  }

  useEffect(() => {
    if (
      isObjectNotEmpty(submitsignupFormData) &&
      submitsignupFormData?.first_name &&
      submitsignupFormData?.last_name &&
      submitsignupFormData?.email &&
      submitsignupFormData?.password &&
      submitsignupFormData?.country &&
      submitsignupFormData?.privacy_policy &&
      signupfailapiflag == true
    ) {
      setValue("first_name", submitsignupFormData.first_name);
      setValue("last_name", submitsignupFormData.last_name);
      setValue("email", submitsignupFormData.email);
      setValue("password", submitsignupFormData.password);
      setValue("country", submitsignupFormData.country);
      setValue("privacy_policy", submitsignupFormData.privacy_policy);
      setPrivacyPolicy(true);
    }
  }, []);

  useEffect(() => {
    if (
      isObjectNotEmpty(submitsignupFormData) &&
      submitsignupFormData?.first_name &&
      submitsignupFormData?.last_name &&
      submitsignupFormData?.email &&
      submitsignupFormData?.password &&
      submitsignupFormData?.country &&
      submitsignupFormData?.privacy_policy &&
      comeFromChangeEmail == true
    ) {
      setValue("first_name", submitsignupFormData.first_name);
      setValue("last_name", submitsignupFormData.last_name);
      setValue("email", submitsignupFormData.email);
      setValue("password", submitsignupFormData.password);
      setValue("country", submitsignupFormData.country);
      setValue("privacy_policy", submitsignupFormData.privacy_policy);
      setPrivacyPolicy(true);
    }
  }, []);
  return (
    <>
      <div
        className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-[60px] w-full"
      >
        <img src={logo_light} alt="light logo " />
      </div>
      {/* content start here */}
      <div className="dark-bg  content text-[#ffffff] overflow-x-hidden md:overflow-auto ">
        <div
          className="border rounded-[12px] border-[#ffffff] md:py-[30px] md:px-[30px] p-6
        m-10 w-[90%] md:w-[60%] xl:w-[40%] mx-auto"
        >
          <div className="grid grid-flow-row mx-auto md:shrink-0 auto-rows-max">
            {/* title start here */}
            <p
              className="text-[20px] md:text-[30px] text-center md:break-word md:break-normal
            w-[100%] md:w-full font-bold mb-[20px]"
            >
              Let’s track your results
            </p>
            <div className="flex items-center w-full my-4">
              <AppleSignin
                authOptions={{
                  clientId: "com.sales.tracky.clientID",
                  scope: "email name",
                  redirectURI: "https://tracky-ebon.vercel.app/onboard",
                  state: "state",
                  nonce: "nonce",
                  usePopup: true,
                }}
                uiType="dark"
                className="apple-auth-btn"
                noDefaultStyle={false}
                buttonExtraChildren="Continue with Apple"
                onSuccess={(response) => {
                  const signupData = {
                    idToken: response.authorization.id_token,
                  };

                  if (
                    ReferralCode !== null &&
                    ReferralCode !== undefined &&
                    ReferralCode
                  ) {
                    signupData = {
                      ...signupData,
                      ["referral_code"]: ReferralCode,
                    };
                  }
                  dispatch(appleSignupSlice(signupData, navigate,socket));
                }}
                onError={(error) => console.error(error)}
                skipScript={false}
                render={(props) => (
                  <button
                    {...props}
                    className="rouned_button_white border-[#ffffff] text-center h-[50px] w-[100%]
                    mx-auto "
                  >
                    <div className="flex items-center content-center justify-center">
                      <img src={apple_icn} alt="apple icon" />
                      <span className="text-[15px] ms-4">
                        Continue with Apple
                      </span>
                    </div>
                  </button>
                )}
              />
            </div>

            {/* Working Old Google Sign in */}
            {/* <div className="mx-auto">
              <GoogleLogin
                className="rouned_button_transparent
          border-transparent bg-[#5F82E5] text-center mx-auto relative h-[50px] mt-[20px] w-[80%] md:w-full"
                auto_select={false}
                // className="hidden"
                theme="filled_blue"
                size="large"
                shape="pill"
                logo_alignment="left"
                text="continue_with"
                width="390"
                onSuccess={(credentialResponse) => {
                  let signupData = {
                    signupId: credentialResponse.credential,
                  };

                  if (
                    ReferralCode !== null &&
                    ReferralCode !== undefined &&
                    ReferralCode
                  ) {
                    signupData = {
                      ...signupData,
                      ["referral_code"]: ReferralCode,
                    };
                  }
                  dispatch(googleSignupSlicePost(signupData, navigate,socket));
                }}
                onError={() => {
                  console.log("Login Failed");
                }}
              />
            </div> */}

            {/* Tring the new one */}
            <div className="relative mb-12 testinggs button_shadow">
              {/*original google button*/}
              <GoogleLogin
                className="rouned_button_transparent
          border-transparent bg-[#5F82E5] text-center mx-auto absulate h-[50px] mt-[20px] w-[50%] md:w-full button_shadow"
                auto_select={false}
                // className="hidden"
                theme="filled_blue"
                size="large"
                shape="pill"
                logo_alignment="left"
                text="continue_with"
                width="400"
                onSuccess={(credentialResponse) => {
                  let signupData = {
                    signupId: credentialResponse.credential,
                  };

                  if (
                    ReferralCode !== null &&
                    ReferralCode !== undefined &&
                    ReferralCode
                  ) {
                    signupData = {
                      ...signupData,
                      ["referral_code"]: ReferralCode,
                    };
                  }
                  dispatch(googleSignupSlicePost(signupData, navigate,socket));
                }}
                onError={() => {
                  console.log("Login Failed");
                }}
              />
              <div className="flex fle-row flex-nowrap button_shadow">
                <div className="testinggs overflow-hidden w-[50%]">
                  <GoogleLogin
                    className="rouned_button_transparent
          border-transparent bg-[#5F82E5] text-center mx-auto  h-[50px] mt-[20px] w-[50%] md:w-full button_shadow"
                    auto_select={false}
                    // className="hidden"
                    theme="filled_blue"
                    size="large"
                    shape="pill"
                    logo_alignment="left"
                    text="continue_with"
                    width="400 | 200"
                    onSuccess={(credentialResponse) => {
                      let signupData = {
                        signupId: credentialResponse.credential,
                      };

                      if (
                        ReferralCode !== null &&
                        ReferralCode !== undefined &&
                        ReferralCode
                      ) {
                        signupData = {
                          ...signupData,
                          ["referral_code"]: ReferralCode,
                        };
                      }
                      dispatch(googleSignupSlicePost(signupData, navigate,socket));
                    }}
                    onError={() => {
                      console.log("Login Failed");
                    }}
                  />
                </div>
                {/* Suplicate div with 2 goolge at same align*/}
                <div className="testinggs overflow-hidden w-[50%] button_shadow">
                  <GoogleLogin
                    className="rouned_button_transparent
          border-transparent bg-[#5F82E5] text-center mx-auto  h-[50px] mt-[20px] w-[50%] md:w-full button_shadow"
                    auto_select={false}
                    // className="hidden"
                    theme="filled_blue"
                    size="large"
                    shape="pill"
                    logo_alignment="left"
                    text="continue_with"
                    width="400 | 200"
                    onSuccess={(credentialResponse) => {
                      let signupData = {
                        signupId: credentialResponse.credential,
                      };

                      if (
                        ReferralCode !== null &&
                        ReferralCode !== undefined &&
                        ReferralCode
                      ) {
                        signupData = {
                          ...signupData,
                          ["referral_code"]: ReferralCode,
                        };
                      }
                      dispatch(googleSignupSlicePost(signupData, navigate,socket));
                    }}
                    onError={() => {
                      console.log("Login Failed");
                    }}
                  />
                </div>
              </div>

              {/*custom button to show*/}
              <div class="absolute z-30 top-0 left-0 w-full cursor-pointer button_shadow">
                <div
                  className="rouned_button_transparent
          border-transparent bg-[#5F82E5] text-center mx-auto   h-[50px] mt-[0px] w-[100%] md:w-full
          overflow-visible  button_shadow"
                >
                  <img
                    className="absolute -left-0 w-[49px] h-[49px] rounded-full shadow-lg"
                    src={google_icn}
                    alt="goolge icon"
                  />
                  <div className="w-full leading-[30px] py-2">
                    <p className="text-[15px] font-medium">
                      Continue with Google{" "}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Or divider */}
            <div className="flex items-center mt-6 ">
              <div className="w-[30%] md:w-[40%] border border-[#ffffff]"></div>
              <div className="w-[40%] text-[15px] text-center col-span-2">
                Or
              </div>
              <div className="w-[30%] md:w-[40%] border border-[#ffffff]"></div>
            </div>
            {/* Form */}
            <form onSubmit={handleSubmit(onSubmit)} className="signup_form">
              <div className="mt-6">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <input
                      type="text"
                      className="w-[100%] md:w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                      placeholder="First name"
                      name="first_name"
                      {...register("first_name")}
                      autoComplete="off"
                      onKeyPress={handleKeyDown}
                    />
                    <ErrorMessage
                      errors={errors}
                      name="first_name"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-sm">{message}</p>
                      )}
                    />
                  </div>
                  <div className="w-full">
                    <input
                      type="text"
                      className="w-[100%] md:w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                      placeholder="Last name"
                      name="last_name"
                      {...register("last_name")}
                      autoComplete="off"
                      onKeyPress={handleKeyDown}
                    />
                    <ErrorMessage
                      errors={errors}
                      name="last_name"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-sm">{message}</p>
                      )}
                    />
                  </div>
                </div>
              </div>
              <div className="mt-[25px]">
                <div className="grid grid-cols-1 gap-4">
                  <div className="w-full">
                    <input
                      type="text"
                      className="w-[100%] md:w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                      placeholder="Email"
                      name="email"
                      {...register("email")}
                      autoComplete="off"
                      onKeyPress={handleKeyDown}
                    />
                    <ErrorMessage
                      errors={errors}
                      name="email"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-sm">{message}</p>
                      )}
                    />
                  </div>
                </div>
              </div>
              <div className="mt-[25px]">
                <div className="grid grid-cols-1 gap-4">
                  <div className="w-full">
                    <input
                      type="password"
                      className="w-[100%] md:w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                      placeholder="Password"
                      name="password"
                      autoComplete="new-password"
                      {...register("password")}
                      onKeyPress={handleKeyDown}
                    />
                    <ErrorMessage
                      errors={errors}
                      name="password"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-sm max-w-[100%]">
                          {message}
                        </p>
                      )}
                    />
                  </div>
                </div>
              </div>
              <div className="mt-[25px]">
                <div className="grid grid-cols-1 gap-4">
                  <div className="w-[100%] md:w-full">
                    {/* <input
                  type="text"
                  className="w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                  placeholder="Country"
                /> */}
                    <select
                      name="country"
                      className="w-full border border-[#ffffff] pt-[5px]  h-[50px]
                      rounded-[12px] bg-[#202122] focus:border-[transparent] focus-within:border-[transparent]"
                      {...register("country")}
                    >
                      <option disabled defaultValue value="" selected>
                        Country
                      </option>
                      {data.map((e) => (
                        <option key={e.code} value={e.name}>
                          {e.name}
                        </option>
                      ))}
                    </select>
                    <ErrorMessage
                      errors={errors}
                      name="country"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-sm">{message}</p>
                      )}
                    />
                  </div>
                </div>
              </div>
              <div className="mt-[25px]">
                <div className="grid grid-cols-1 gap-4">
                  <div className="w-full">
                    <input
                      type="checkbox"
                      className="rounded text-pink-500 cursor-pointer border border-white bg-transparent h-[22px] w-[22px]"
                      name="privacy_policy"
                      {...register("privacy_policy")}
                      checked={privacy_policy}
                      onChange={handleChange}
                    />
                    <span className="text-[14px] ms-4">
                      I accept the privacy policy
                    </span>
                  </div>
                  {errors.privacy_policy && !privacy_policy && (
                    <ErrorMessage
                      errors={errors}
                      name="privacy_policy"
                      render={({ message }) => (
                        <p className="text-[#FF0000] text-sm mt-0">{message}</p>
                      )}
                    />
                  )}
                </div>
              </div>
              <div>
                <button
                  className="rounded-[25px] bg-[#21CE90]
             text-center text-[15px] h-[60px] font-medium
            py-[19px] mt-[20px] w-[100%] md:w-full button_shadow
            hover:bg-transparent hover:border
            "
                  // onClick={() => {
                  //   nextstep();
                  // }}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div
                      className="flex items-center content-center justify-center w-full "
                    >
                      <Loader />
                    </div>
                  ) : (
                    <>Create account</>
                  )}
                </button>
              </div>
            </form>
            <div className="mt-3">
              <div className="grid grid-cols-1">
                <div className="w-full text-[13px] flex justify-center items-center">
                  Already have an account?
                  <span
                    className="underline ms-2 cursor-pointer hover:text-[#21CE90]"
                    onClick={redirectToLogin}
                  >
                    Log in
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Signupstep1;
