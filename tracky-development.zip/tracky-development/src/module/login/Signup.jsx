import React, { useState, useEffect, useLayoutEffect, useContext } from "react";
import Signupstep1 from "./Signupstep1.jsx";
import Signupstep2 from "./Signupstep2.jsx";
import Signupstep3 from "./Signupstep3.jsx";
import Signupstep4 from "./Signupstep4.jsx";
import logo_light from "../../assets/logo_light.svg";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import Loader from "../../CommonComponent/Loader.jsx";
import { Helmet } from "react-helmet";
import { resetStep, setStep } from "../../redux/slices/authSlice.js";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';

function Signup() {
  // const [step, setStep] = useState(1);
  const step = useSelector((state) => state?.root?.auth?.authstep);
  const { socket, isSocketConnected } = useContext(SocketContext);

  const location2 = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [flag, setFlag] = useState(false);
  const [comeFromChangeEmail, setComeFromChangeEmail] = useState(false);

  const urlState = location2.state;
  const loginData = useSelector((state) => state?.root?.auth);
  const isLoading = useSelector((state) => state?.root?.auth?.loading);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const nextstep = () => {
    dispatch(setStep());
  };

  useEffect(() => {
    auth && navigate("/dashboard");
  }, []);

  useEffect(() => {
    if (
      location2.state !== null &&
      location2.state !== undefined &&
      location2.state.step
    ) {
      if (location2.state.step == 1) {
        setComeFromChangeEmail(true);
        setTimeout(() => {
          dispatch(resetStep());
        }, 1000);
      }
    }
    auth && navigate("/dashboard");
  }, [location2]);


  return (
    <>
      <Helmet>
        <title>Tracky | Sign up</title>
        <meta name="description" content="Tracky | Sign up" />
      </Helmet>

      <div className=" h-[100%] ">
        <div className="">
          {step === 1 && (
            <Signupstep1
              nextstep={nextstep}
              comeFromChangeEmail={comeFromChangeEmail}
            />
          )}
          {step === 2 && <Signupstep2 nextstep={nextstep} />}
          {step === 3 && <Signupstep3 nextstep={nextstep} />}
          {/* <div className="self-center contect-center">
            {step === 4 && <Signupstep4 nextstep={nextstep} />}
          </div> */}
        </div>
      </div>
    </>
  );
}

export default Signup;
