import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import { useNavigate } from "react-router-dom";
import logo_light from "../../assets/logo_light.svg";
import { resetPassWord } from "../../redux/slices/resetPassSlice.js";
import { useDispatch, useSelector } from "react-redux";
import Loader from "../../CommonComponent/Loader";
import { Helmet } from "react-helmet";

function CreatePassword() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get("token");

  useEffect(() => {
    if (token == null || token == undefined) {
      navigate("/login");
    }
  }, []);

  const dispatch = useDispatch();
  const loading = useSelector((state) => state?.root?.resetpass?.loadingflag);

  const validationSchema = Yup.object().shape({
    password1: Yup.string()
      .required("Password is required")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
        "Must contain 8 characters, one uppercase, one lowercase, one number and one special case character"
      )
      .max(15, "Maximum 15 characters allowed"),
    password: Yup.string()
      .required("Confirm password is required")
      .oneOf([Yup.ref("password1"), null], "Passwords must match")
      .max(15, "Maximum 15 characters allowed"),
  });

  const saveCreatePassword = async (data) => {
    const formData = { password: data.password, token: token };
    try {
      dispatch(resetPassWord(formData, navigate));
    } catch {}
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const redirectToLogin = () => {
    navigate("/login");
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Reset Password</title>
        <meta name="description" content="Tracky | Reset Password" />
      </Helmet>
      {/* {loading ? <Loader /> : */}
      <>
        <div
          className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-[60px] w-full"
        >
          <img src={logo_light} alt="light logo " />
        </div>
        {/* content start here */}
        <div className="dark-bg reset content text-[#ffffff] flex justify-center align-center flex-col lg:px-0 px-[60px]">
          <div className="border rounded-[12px] border-[#ffffff] p-[20px] m-10 lg:w-[40%] w-[100%] mx-auto">
            <div className="grid grid-flow-row mx-auto text-center lg:w-3/5 md:shrink-0 auto-rows-max">
              <p className="text-[40px] font-bold mb-[20px] block w-full">
                Reset Password
              </p>
              <form onSubmit={handleSubmit(saveCreatePassword)}>
                <div className="mt-[25px]">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="w-full">
                      <input
                        type="password"
                        className="w-full border border-[#ffffff] pt-[5px]
                        h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent]
                        focus-within:border-[transparent]"
                        placeholder="Password"
                        autoComplete="new-password"
                        {...register("password1")}
                        onKeyPress={handleKeyDown}
                      />
                      <ErrorMessage
                        className="text-left"
                        errors={errors}
                        name="password1"
                        render={({ message }) => (
                          <p className="text-left text-[#FF0000] text-sm">
                            {message}
                          </p>
                        )}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-[20px]">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="w-full">
                      <input
                        type="password"
                        className="w-full border border-[#ffffff] pt-[5px]  h-[50px] rounded-[12px] bg-[transparent] focus:border-[transparent] focus-within:border-[transparent]"
                        placeholder="Confirm Password"
                        name="password"
                        autoComplete="new-password"
                        {...register("password")}
                        onKeyPress={handleKeyDown}
                      />
                      <ErrorMessage
                        errors={errors}
                        name="password"
                        render={({ message }) => (
                          <p className="text-left text-[#FF0000] text-sm">
                            {message}
                          </p>
                        )}
                      />
                    </div>
                  </div>
                </div>

                <button
                  className="rouned_button_transparent w-full bg-[#21CE90] border-transparent border-0 text-center h-[50px] mt-[20px]"
                  type="submit"
                >
                                      {loading ? (
                        <div
                      className="flex items-center content-center justify-center w-full "
                    >
                          <Loader />
                        </div>
                      ) : (
                        <>Reset Password</>
                      )}

                </button>
              </form>

              <button onClick={redirectToLogin} className="mt-3">
                Back to login
              </button>
            </div>
          </div>
        </div>
      </>
      {/* } */}
    </>
  );
}

export default CreatePassword;
