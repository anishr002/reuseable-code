import React, { useEffect, useState, useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "react-toastify";
// import { ToastContent } from "../../CommonComponent/ToastContent";
import email_icn from "../../assets/email_icn.svg";
import Loader from "../../CommonComponent/Loader";

import logo_light from "../../assets/logo_light.svg";
import {signupresData, resetStep} from "../../redux/slices/authSlice.js";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';


function Signupstep3({ nextstep }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { loading, signupResData } = useSelector((state) => state?.root?.auth);
  const { socket, isSocketConnected } = useContext(SocketContext);


  const [resendEmailLoading, setResendEmailLoading] = useState(false);
  let domain = signupResData?.email.split("@")[1];
  let inboxLink = "https://mail.google.com";

  if (domain == "gmail.com") {
    inboxLink = "https://mail.google.com";
  } else if (domain == "yahoo.com") {
    inboxLink = "https://mail.yahoo.com";
  } else if (domain == "hotmail.com	") {
    inboxLink = "https://outlook.live.com/owa/";
  } else if (domain == "yopmail.com") {
    inboxLink = "https://yopmail.com/wm";
  } else if (domain == "outlook.com") {
    inboxLink = "https://outlook.live.com/owa/";
  } else {
    inboxLink = `https://www.${domain}`;
  }

  const resetVerificationEmail = async () => {
    const useremail = {
      email: signupResData?.email,
    };
    try {
      setResendEmailLoading(true);
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}user/resendEmail`,
        useremail
      );

      if (response.data.success) {
        setResendEmailLoading(false);
        toast.success(response.data.message);
      }
    } catch (err) {
      setResendEmailLoading(false);
      toast.error(err.data.message);
    }
    setResendEmailLoading(false);
  };

  const redirectToLogin = () => {
    dispatch(signupresData({}));
    dispatch(resetStep());
    navigate("/login");
  };

  const redirectToSignup = () => {
    navigate("/signup");
  };

  const redirectToOnboard = () => {
    navigate('/onboard');
  };


  useEffect(() => {

    socket?.emit('ROOM', { id: signupResData?._id });
    socket?.on('EMAIL_VERIFIED', (payload) => {

      redirectToOnboard();
      console.log(payload, 'EMAIL_VERIFIED event received', 5555);
    });

    return () => {
      socket?.off('EMAIL_VERIFIED');
    };
  }, [socket]);

  return (
    <>
      <div
        className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-[60px] w-full sticky top-0 z-10"
      >
        <div className="flex flex-row justify-between w-full">
        <img src={logo_light} alt="light logo " />
        <p className="text-lg text-[#ffffff] cursor-pointer underline flex items-center" onClick={redirectToLogin}>Go to Login</p>
        </div>
      </div>

      {/* content start here */}
      <div className="dark-bg  md:content xl:h-[calc(100vh-80px)] text-[#ffffff] p-8 overflow-scroll flex justify-center items-center">
        <div className="border rounded-[12px] border-[#ffffff] py-[30px] px-[30px]  w-80 md:w-3/5 mx-auto">
          <div className=" md:shrink-0 mx-auto grid grid-flow-row auto-rows-max ">
            {/* title start here */}
            <div className="grid grid-flow-row auto-rows-max ">
              <div className="mb-[21px] text-center mx-auto">
                <img src={email_icn} alt="email icon" />
              </div>
              <p className="text-[20px] md:text-[30px] text-center mx-auto font-bold mb-[40px] block">
                Verify your email to continue
              </p>
              <p className="text-[15px] w-full md:w-[60%] mx-auto font-normal text-center mb-[40px] block">
                {`We just sent an email to the address *****@${domain} Please check your email and click on the link provided to verify your afress.`}
              </p>
              <Link
                to="/signup"
                state={{ step: 1 }}
                className="text-[15px] mx-auto font-bold underline cursor-pointer hover:text-[#21CE90]"
              >
                {/* <p className="text-[15px] mx-auto font-bold underline cursor-pointer hover:text-[#21CE90]"> */}
                Change email
                {/* </p> */}
              </Link>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="">
                  <button
                    className="w-full rouned_button_white text-center h-[50px] bg-[#373839]  mt-[20px]
              flex items-center justify-center button_shadow hover:border-[#21CE90] hover:text-[#21CE90]"
                    onClick={resetVerificationEmail}
                    disabled={resendEmailLoading}
                  >
                    {resendEmailLoading ? (
                      <>
                        <Loader />
                      </>
                    ) : (
                      <> Resend verification email</>
                    )}
                  </button>
                </div>
                <div className="">
                  <a
                    href={inboxLink}
                    target="_blank"
                    className="w-full rouned_button_transparent text-center h-[50px] bg-[#21CE90] shadow-lg mt-[20px]
              flex items-center justify-center button_shadow hover:bg-[#373839] hover:text-[#21CE90] hover:border-[#21CE90]"
                  >
                    Go to inbox
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Signupstep3;
