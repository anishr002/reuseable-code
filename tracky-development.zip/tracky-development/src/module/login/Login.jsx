import React, { useEffect, useState,useContext } from "react";
// import LOGIN_SIDE_IMAGE from "../../assets/login.png";
import LOGIN_SIDE_IMAGE from "../../assets/LoginPageSideImage2.png";

import { useNavigate } from "react-router-dom";
import logo_dark from "../../assets/logo_black.svg";
import mail_icn from "../../assets/mail_icn.svg";
import correct_icn from "../../assets/correct_icn.svg";
import password_icn from "../../assets/key_icn.svg";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import { useDispatch, useSelector } from "react-redux";
import { login, loadingflag } from "../../redux/slices/authSlice.js";
import { GoogleLogin } from "@react-oauth/google";
import {
  googleSignInSlice,
  appleSignupSlice,
} from "../../redux/slices/authSlice";
import jsondata from "../../locales/en.json";
import Loader from "../../CommonComponent/Loader.jsx";
import { Helmet } from "react-helmet";
import AppleSignin from "react-apple-signin-auth";
import apple_icn from "../../assets/apple_black_logo.svg";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';


function Login() {
  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .required("Please enter email address")
      .matches(
        /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
        "Please enter valid email address"
      ),
    password: Yup.string()
      .required("Please enter password")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
        "Must contain 8 characters,at least one uppercase,lowercase, number and special case character"
      )
      .max(15, "Maximum 15 characters allowed"),
  });

  const {
    register,
    handleSubmit,
    getFieldState,
    trigger,
    formState: { isDirty, dirtyFields, touchedFields, isValid, errors },
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "onChange",
  });

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loginData = useSelector((state) => state?.root?.auth);
  const [emailshowCorrectIcon, setEmailShowCorrectIcon] = useState(false);

  const emailclassName = emailshowCorrectIcon ? "flex-none" : "hidden";

  const [passshowCorrectIcon, setPassShowCorrectIcon] = useState(false);
  const passclassName = passshowCorrectIcon ? "flex-none" : "hidden";

  const isLoading = useSelector((state) => state?.root?.auth?.loading);

  const { socket, isSocketConnected } = useContext(SocketContext);

  useEffect(() => {
    console.log(socket,8888);
    console.log(isSocketConnected,8888);
    console.log(socket?.connected,8888);


    if(socket== null || socket?.connected == false){
      console.log('Socket is not connected', 8888);
    }

  }, [socket]);

  useEffect(() => {
    dispatch(loadingflag(false));
  }, []);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const onSubmit = (data) => {
    dispatch(login(data, navigate,socket));
  };

  const redirectToSignup = () => {
    navigate("/signup");
  };

  const redirectToForgotPass = () => {
    navigate("/forgotpassword");
  };

  useEffect(() => {
    auth && navigate("/dashboard");
    // joinRoom();
  }, []);



  return (
    <>
      <Helmet>
        <title>Tracky | Login</title>
        <meta name="description" content="Tracky | Login" />
      </Helmet>

      <div className="flex overflow-hidden md:px-0 2xl:p-0">
        {/*Login form */}
        <div className="w-full lg:w-2/3 flex flex-col justify-center content-center items-center h-screen bg-[#ffffff]">
          <div className="logo w-[230px]  md:mt-0">
            <img src={logo_dark} alt="Tracky dark logo" />
          </div>
          <div className="mt-[20px] md:mt-[30px] mb-6  text-center">
            <h1 className="text-[29px] text-[#000000] font-bold mb-2 ">
              {jsondata?.login?.heading_1}
            </h1>
            <span className="text-[15px] text-[#000000] font-medium">
              {jsondata?.login?.heading_2}
            </span>
          </div>
          {/* tabs*/}
          <div className="w-[350px] md:w-[400px] mb-5">
            <div className="border-2 border-[#000000] bg-[#EEEEEE] p-[5px] rounded-[17px] h-[57px]">
              <div className="flex flex-row  h-[100%] items-center">
                <div
                  className="flex-auto  text-center py-2.5  rounded-[15px]
                  bg-white hover:bg-[#2EDE9F]"
                >
                  <span className="text-[15px] font-medium cursor-pointer">
                    {jsondata?.login?.toogle_1}
                  </span>
                </div>
                <div
                  className="flex-auto  text-center hover:text-[#2EDE9F] hover:font-semibold"
                  onClick={redirectToSignup}
                >
                  <span className="text-center cursor-pointer">
                    {jsondata?.login?.toogle_2}{" "}
                  </span>
                </div>
              </div>
            </div>
          </div>
          {/* form */}
          <div className="login-form">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="border border-[#000000] rounded-[17px] h-[70px] py-[15px] px-[25px] md:w-[400px]">
                {/* email */}
                <div className="flex items-center content-center h-full">
                  <div className="flex-none pe-2">
                    <img src={mail_icn} alt="mail icon" />
                  </div>
                  <div className="flex-auto w-64 border-l-2 border-[#000000] mx-[10px] ps-4">
                    <label className="text-[11px] font-medium">
                      {jsondata?.login?.email_label}
                    </label>
                    <input
                      className="border-0 p-0 text-[16px] text-[#000000] font-medium"
                      type="text"
                      name="email"
                      {...register("email", {
                        onChange: (e) => {
                          trigger("email");
                          if (
                            e.target.value.length > 1 &&
                            (!getFieldState("email").invalid ||
                              getFieldState("email").error == undefined)
                          ) {
                            setEmailShowCorrectIcon(true);
                          } else {
                            setEmailShowCorrectIcon(false);
                          }
                        },
                        onPaste: (e) => {
                          trigger("email");
                          if (
                            e.target.value.length > 1 &&
                            (!getFieldState("email").invalid ||
                              getFieldState("email").error == undefined)
                          ) {
                            setEmailShowCorrectIcon(true);
                          } else {
                            setEmailShowCorrectIcon(false);
                          }
                        },
                        onBlur: (e) => {
                          trigger("email");
                          if (
                            e.target.value.length > 1 &&
                            (!getFieldState("email").invalid ||
                              getFieldState("email").error == undefined)
                          ) {
                            setEmailShowCorrectIcon(true);
                          } else {
                            setEmailShowCorrectIcon(false);
                          }
                        },
                      })}
                      placeholder={jsondata?.login?.email_placeholder}
                      autoComplete="off"
                      onKeyPress={handleKeyDown}
                    />
                  </div>

                  <div className={emailclassName}>
                    <img src={correct_icn} alt="correct icon" />
                  </div>
                </div>
              </div>
              <ErrorMessage
                errors={errors}
                name="email"
                render={({ message }) => (
                  <p className="text-[#FF0000] text-sm max-w-[350px]">
                    {message}
                  </p>
                )}
              />
              {/* password */}
              <div className="border border-[#000000] rounded-[17px] h-[70px] py-[15px] px-[25px] mt-2 md:w-[400px]">
                <div className="flex items-center content-center h-full">
                  <div className="flex-none pe-2">
                    <img src={password_icn} alt="password icon" />
                  </div>
                  <div className="flex-auto flex-col flex w-64 border-l-2 border-[#000000] mx-[10px] ps-4">
                    <label className="text-[11px] font-medium">
                      {jsondata?.login?.pass_label}
                    </label>
                    <input
                      className="border-0 p-0 text-[16px] text-[#000000] font-medium"
                      type="password"
                      // required
                      name="password"
                      autoComplete="new-password"
                      {...register("password", {
                        onChange: (e) => {
                          if (
                            e.target.value.length > 1 &&
                            (!getFieldState("password").invalid ||
                              getFieldState("password").error == undefined)
                          ) {
                            setPassShowCorrectIcon(true);
                          } else {
                            setPassShowCorrectIcon(false);
                          }
                        },
                        onBlur: () => {
                          trigger("password");
                        },
                      })}
                      placeholder={jsondata?.login?.pass_placeholder}
                      onKeyPress={handleKeyDown}
                    />
                  </div>
                  <div className={passclassName}>
                    <img src={correct_icn} alt="correct icon" />
                  </div>
                </div>
              </div>
              <ErrorMessage
                errors={errors}
                name="password"
                render={({ message }) => (
                  <p className="text-[#FF0000] text-sm max-w-[350px]">
                    {message}
                  </p>
                )}
              />
              <div className="text-right">
                <button
                  onClick={redirectToForgotPass}
                  className="cursor-pointer hover:text-[#2EDE9F] hover:underline"
                  type="button"
                >
                  Forgot Password?
                </button>
              </div>
              {/* Button */}
              <div className="mt-[17px]">
                <button
                  className="bg-[#2EDE9F] mx-auto flex justify-center
                       items-center content-center text-center text-[#000000]
                       text-[15px] h-[60px] font-medium py-[19px] rounded-[17px] w-full
                       hover:bg-transparent hover:border-2 hover:border-[#2EDE9F]
                       hover:text-[#2EDE9F]
                       "
                  type="submit"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <div
                        className="flex items-center content-center justify-center w-full "
                      >
                        <Loader />
                      </div>
                    </>
                  ) : (
                    jsondata?.login?.main_btn
                  )}
                </button>
              </div>
            </form>

            {/* Or divider */}
            <div className="flex items-center mt-6 ">
              <div className="w-[20%] md:w-[40%] border border-[#000000]"></div>
              <div className="w-[60%] text-[15px] text-center col-span-2">
                Or continue with
              </div>
              <div className="w-[20%] md:w-[40%] border border-[#000000]"></div>
            </div>

            <div className="flex items-center justify-center mt-4">
              <div className="mr-3">
                <AppleSignin
                  authOptions={{
                    clientId: "com.sales.tracky.clientID",
                    scope: "email name",
                    redirectURI: "https://tracky-ebon.vercel.app/onboard",
                    state: "state",
                    nonce: "nonce",
                    usePopup: true,
                  }}
                  uiType="dark"
                  className="apple-auth-btn"
                  noDefaultStyle={false}
                  buttonExtraChildren="Continue with Apple"
                  onSuccess={(response) => {
                    const signupData = {
                      idToken: response.authorization.id_token,
                    };
                    dispatch(appleSignupSlice(signupData, navigate,socket));
                  }}
                  onError={(error) => console.error(error)}
                  skipScript={false}
                  render={(props) => (
                    <button
                      {...props}
                      className="rouned_button_black border-[#000000] text-center h-[35px] w-[35px]"
                    >
                      <div className="flex items-center content-center justify-center">
                        <img src={apple_icn} alt="apple icon" />
                      </div>
                    </button>
                  )}
                />
              </div>
              <div className="w-[50px]">
                <GoogleLogin
                  // className="rouned_button_transparent border-transparent bg-[#5F82E5] text-center h-[50px] mt-[20px]"
                  theme="filled_blue"
                  // size="large"
                  shape="circle"
                  // logo_alignment="left"
                  type="icon"
                  // text="continue_with"
                  onSuccess={(credentialResponse) => {
                    const signupData = {
                      signupId: credentialResponse.credential,
                    };
                    dispatch(googleSignInSlice(signupData, navigate,socket));
                  }}
                  onError={() => {
                    console.log("Login Failed");
                  }}
                />
              </div>
            </div>
          </div>
        </div>
        {/*Image */}
        <div
          className="w-1/3 dark-bg lg:flex md:flex-col lg:justify-center lg:content-center lg:h-[100vh]
        hidden "
        >
          <div className="relative lg:left-[-150px] xl:left-[-200px]">
            <img
              src={LOGIN_SIDE_IMAGE}
              alt="screen image"
              className="bg-center bg-contain "
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
