import React from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { useNavigate } from "react-router-dom/dist";
import { Helmet } from "react-helmet";

import personal_icn from "../../assets/personal_info_icn.svg";
import security_icn from "../../assets/security_icn.svg";
import plan_icn from "../../assets/plan_icn.svg";
import referral_icn from "../../assets/referral_icn.svg";
import CheckOnboard from "../AuthGuard/CheckOnboard";

function AccountOverview() {
  const navigate = useNavigate();
  return (
    <>
      <Helmet>
        <title>
          Tracky | Account Overview
        </title>
        <meta
          name="description"
          content="Tracky | Account Overview"
        />
      </Helmet>

      <div className="FirstDiv">
        <div className="dark-bg md:content  text-[#ffffff] p-6 h-full md:h-screen">
          <h1 className="text-[20px] md:text-[30px] font-semibold mb-[16px]">
            Account overview
          </h1>
          <p className="text-[16px] md:text-[18px] font-normal mb-[40px]">
            I certify that the
            information provided is
            accurate to the best of my
            knowledge and has been
            filled in honestly.
          </p>
          {/* card section start*/}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {/* 1st card section start*/}
            <div
              className="rounded-[15px] bg-[#373839] shadow-2xl p-[26px]
            flex-col justify-start content-start
            hover:border-4 hover:border-[#2EDE9F] hover:shadow-[#133025] cursor-pointer  border-4 border-[#373839]

            "
              onClick={() =>
                navigate(
                  "/personalinfo"
                )
              }
            >
              <div className="w-full">
                <img
                  src={personal_icn}
                  alt="personal icon"
                />
              </div>
              <div className="mt-4">
                <p className="text-[14px] font-bold">
                  Personal Info
                </p>
                <p className="text-[12px] font-medium">
                  Provide personal
                  details and how we
                  can reach you
                </p>
              </div>
            </div>
            {/* 1st card section start*/}
            <div
              className="rounded-[15px] bg-[#373839] shadow-2xl p-[26px]
            flex-col justify-start content-start border-4 border-[#373839] hover:shadow-[#133025] cursor-pointer  hover:border-4 hover:border-[#2EDE9F]  "
              onClick={() =>
                navigate(
                  "/loginsecurity"
                )
              }
            >
              <div className="w-full">
                <img
                  src={security_icn}
                  alt="personal icon"
                />
              </div>
              <div className="mt-4">
                <p className="text-[14px] font-bold">
                  Log in & security
                </p>
                <p className="text-[12px] font-medium">
                  Update your password
                  and secure your
                  account
                </p>
              </div>
            </div>
            {/* 1st card section start*/}
            <div
              className="rounded-[15px] bg-[#373839] border-4 border-[#373839] shadow-2xl p-[26px]
            flex-col justify-start content-start hover:border-4 hover:border-[#2EDE9F] hover:shadow-[#133025] cursor-pointer "
              onClick={() =>
                navigate(
                  "/manageplan"
                )
              }
            >
              <div className="w-full">
                <img
                  src={plan_icn}
                  alt="personal icon"
                />
              </div>
              <div className="mt-4">
                <p className="text-[14px] font-bold">
                  Plan
                </p>
                <p className="text-[12px] font-medium">
                  Update the current
                  plan that you are on
                  and change payment
                  details
                </p>
              </div>
            </div>
            {/* 1st card section start*/}
            <div
              className="rounded-[15px] bg-[#373839] shadow-2xl p-[26px]
            flex-col justify-start content-start border-4 border-[#373839] hover:shadow-[#133025] cursor-pointer  hover:border-4 hover:border-[#2EDE9F]  "
              onClick={() =>
                navigate(
                  "/referralprogram"
                )
              }
            >
              <div className="w-full">
                <img
                  src={referral_icn}
                  alt="personal icon"
                />
              </div>
              <div className="mt-4">
                <p className="text-[14px] font-bold">
                  Referral program
                </p>
                <p className="text-[12px] font-medium">
                  View how many people
                  you have send a
                  referral link.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(
  AccountOverview
);
