import React, { useState, useEffect } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { Helmet } from "react-helmet";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import ReactModal from "react-modal";
import ReferralProgramSkeleton from "../../CommonComponent/skeletons/ReferralProgramSkeleton";
import {
  EmailShareButton,
  FacebookShareButton,
  LinkedinShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  RedditShareButton,
  TelegramShareButton,
} from "react-share";
import {
  EmailIcon,
  FacebookIcon,
  LinkedinIcon,
  TwitterIcon,
  WhatsappIcon,
  TelegramIcon,
  RedditIcon,
} from "react-share";
import Swal from "sweetalert2";
import { useForm } from "react-hook-form";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { useDispatch, useSelector } from "react-redux";
import {
  sendreferralEmail,
  getreferralStatisticsData,
} from "../../redux/slices/referralSlice.js";
import Loader from "../../CommonComponent/Loader.jsx";
import { useNavigate } from "react-router-dom";

import back_icn from "../../assets/back_icn.svg";

function ReferralProgram() {
  const [showShareModal, setShowShareModal] = useState(false);
  const loginData = useSelector((state) => state?.root?.auth);
  const isInitialLoading = useSelector(
    (state) => state?.root?.referral?.InitialLoading
  );
  const isSubmitbtnLoading = useSelector(
    (state) => state?.root?.referral?.sendreferralEmailLoading
  );
  const ReferralStatisticsData = useSelector(
    (state) => state?.root?.referral?.referralStatistics
  );

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const accessToken =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  useEffect(() => {
    dispatch(getreferralStatisticsData(accessToken));
  }, []);

  const ReferralCode = loginData?.data?.user?.referral_code
    ? loginData?.data?.user?.referral_code
    : loginData?.googleData?.user?.referral_code
    ? loginData?.googleData?.user?.referral_code
    : loginData?.VerifyData?.user?.referral_code
    ? loginData?.VerifyData?.user?.referral_code
    : loginData?.googleInData?.user?.referral_code
    ? loginData?.googleInData?.user?.referral_code
    : loginData?.appleData?.user?.referral_code;

  const openModal = () => {
    setShowShareModal(true);
  };

  const closeModal = () => {
    setShowShareModal(false);
  };

  let urlToShareIS = `${process.env.REACT_APP_FRONTEND_BASE_URL}signup?referral=${ReferralCode}`;
  let social_share_message = "Sign up to Tracky using referral link";

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .required("Please enter email address")
      .matches(
        /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
        "Please enter valid email address"
      ),
  });

  const {
    register,
    handleSubmit,
    getFieldState,
    trigger,
    formState: { isDirty, dirtyFields, touchedFields, isValid, errors },
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  // const handleCopyToClipboard = () => {
  //   navigator.clipboard.writeText(urlToShareIS)
  //     .then(() => {
  //       urlCopied();
  //       // You can also show a success message or perform other actions here
  //     })
  //     .catch((error) => {
  //       // Handle the error, e.g., show an error message to the user
  //     });
  // }

  const handleCopyToClipboard = async () => {
    try {
      await window?.navigator?.clipboard?.writeText(urlToShareIS);
      urlCopied();
    } catch (error) {
      console.error("Error copying URL:", error);
    }
  };

  const urlCopied = async () => {
    Swal.fire({
      allowOutsideClick: true,
      background: "#373839",
      color: "#ffffff",
      text: "Referral link copied to clipboard",
      icon: "success",
      showCancelButton: false,
      confirmButtonColor: "#2EDE9F",
      confirmButtonText: "Okay",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.close();
      } else {
      }
    });
    setTimeout(function () {
      Swal.close();
    }, 2000);
  };

  const onSubmit = async (data) => {
    dispatch(sendreferralEmail(accessToken, data));
  };

  const RedirectToAccountOverview = () => {
    navigate("/accountoverview");
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Referral Program</title>
        <meta name="description" content="Tracky | Referral Program" />
      </Helmet>

      <div className=" FirstDiv h-full">
        <div className="dark-bg w-[100%] p-6 h-[calc(100vh-80px)] overflow-y-auto">
          <div className="  text-[#ffffff] ">
            {
              <>
                {isInitialLoading ? (
                  <ReferralProgramSkeleton />
                ) : (
                  <>
                    <div className="w-full   text-[#ffffff]">
                      <h1 className="text-[20px] md:text-[30px] font-semibold mb-[16px]">
                        Refer your friend and earn up to...
                      </h1>
                      <div className="flex flex-row justify-between items-center">
                        <p className="text-[18px] w-[150px] md:w-full ">
                          Invite your friends to Tracky!
                        </p>
                        <button
                          className="bg-transparent  text-[15px] font-medium
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px]
                               flex items-center justify-end  "
                          onClick={RedirectToAccountOverview}
                          type="button"
                        >
                          <img
                            src={back_icn}
                            alt="back icon"
                            className="me-4"
                          />
                          Back
                        </button>
                      </div>
                      {/* invite sections */}
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 my-6">
                        <div className="flex-col col-span-2 w-full ">
                          <div className="w-full  block md:flex ">
                            <div className="rounded-[15px] p-6 bg-[#373839] w-full me-0 md:me-4">
                              <h1 className="text-[25px] font-semibold mb-4">
                                Share your referral link
                              </h1>

                              <p className="text-[12px] ">
                                You can also share your referral link by copying
                                and sending it
                              </p>
                              <div className="flex-col w-full">
                                <div className="w-full block md:flex md:items-center ">
                                  <label className=" block w-full md:w-[60%] my-4">
                                    <input
                                      type="text"
                                      className="w-[100%] md:w-[90%] text-[16px] border-slate-200
                           placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#939393] "
                                      value={urlToShareIS}
                                      disabled
                                    />
                                  </label>
                                  <button
                                    className="cursor-pointer rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium py-[15px]
                                w-full md:w-[30%]
                  hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-4 md:mb-0"
                                    onClick={handleCopyToClipboard}
                                  >
                                    Copy Link
                                  </button>
                                  <button
                                    className="cursor-pointer rounded-[8px] bg-[#21CE90]  text-[15px] font-medium py-[15px]
                               w-full md:w-[30%]
                  hover:bg-[#ffffff] hover:text-[#000000]"
                                    onClick={openModal}
                                  >
                                    Share
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="w-full  block md:flex mt-6">
                            <div className="rounded-[15px] p-6 bg-[#373839] w-full me-0 md:me-4">
                              <h1 className="text-[25px] font-semibold mb-4">
                                Invite with email
                              </h1>
                              <p className="text-[12px] ">
                                Insert your friends adresses to send them an
                                invitation
                              </p>

                              <div className="flex-col w-full">
                                <form onSubmit={handleSubmit(onSubmit)}>
                                  <div className="w-full block md:flex md:items-center ">
                                    <label className=" block w-full md:w-[90%] my-4">
                                      <input
                                        type="text"
                                        className="w-[100%] md:w-[90%] text-[16px] border-slate-200
                           placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#939393] "
                                        onKeyPress={handleKeyDown}
                                        {...register("email")}
                                        autoComplete="off"
                                      />
                                    </label>
                                    <button
                                      className="cursor-pointer rounded-[8px] bg-[#21CE90]  text-[15px] font-medium py-[15px]
                               w-full md:w-[50%]
                  hover:bg-[#ffffff] hover:text-[#000000]"
                                      type="submit"
                                      disabled={isSubmitbtnLoading}
                                    >
                                      {isSubmitbtnLoading ? (
                                        <>
                                          <div
                                            className=" flex justify-center
                       items-center content-center w-full"
                                          >
                                            <Loader />
                                          </div>
                                        </>
                                      ) : (
                                        <>Send</>
                                      )}
                                    </button>
                                  </div>
                                  <ErrorMessage
                                    errors={errors}
                                    name="email"
                                    render={({ message }) => (
                                      <p
                                        className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                      >
                                        {message}
                                      </p>
                                    )}
                                  />
                                </form>
                              </div>
                            </div>
                            {/*box*/}
                          </div>
                          {/* how it works sections */}
                          <h1 className="text-[18px] font-semibold my-[16px]">
                            How it works
                          </h1>
                          <div className="grid grid-cols-1 gap-4 md:grid-cols-3 my-6">
                            <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                              <div className="flex-col">
                                <div className="mb-4">
                                  <span className="rounded-full bg-[#939393] h-[10px] w-[10px] px-[10px] py-[5px] text-[11px] font-bold">
                                    1
                                  </span>
                                </div>
                                <span className="text-[14px] font-semibold mb-4">
                                  Send invite
                                </span>
                                <p className="text-[12px] font-medium">
                                  Insert your friends adresses to send them an
                                  invitation
                                </p>
                              </div>
                            </div>
                            <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                              <div className="flex-col">
                                <div className="mb-4">
                                  <span className="rounded-full bg-[#939393] h-[10px] w-[10px] px-[10px] py-[5px] text-[11px] font-bold">
                                    1
                                  </span>
                                </div>
                                <span className="text-[14px] font-semibold mb-4">
                                  Send invite
                                </span>
                                <p className="text-[12px] font-medium">
                                  Insert your friends adresses to send them an
                                  invitation
                                </p>
                              </div>
                            </div>
                            <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                              <div className="flex-col">
                                <div className="mb-4">
                                  <span className="rounded-full bg-[#939393] h-[10px] w-[10px] px-[10px] py-[5px] text-[11px] font-bold">
                                    1
                                  </span>
                                </div>
                                <span className="text-[14px] font-semibold mb-4">
                                  Send invite
                                </span>
                                <p className="text-[12px] font-medium">
                                  Insert your friends adresses to send them an
                                  invitation
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex-col w-full ">
                          <div className="w-full  block md:flex ">
                            <div className="rounded-[15px] p-6 bg-[#373839] w-full ">
                              <div className="flex-col">
                                <div className="mb-4">
                                  <span className=" text-[16px] font-bold">
                                    Your referral stats
                                  </span>
                                </div>
                                <ul class="list-none w-full">
                                  <li className="flex my-2">
                                    <span className="text-[14px] w-[80%]">
                                      Succesfull signups
                                    </span>
                                    <span className="text-[14px] w-[20%]">
                                      {
                                        ReferralStatisticsData?.successful_signup
                                      }
                                    </span>
                                  </li>
                                  <li className="flex my-2">
                                    <span className="text-[14px] w-[80%]">
                                      Available free subscription
                                    </span>
                                    <span className="text-[14px] w-[20%]">
                                      {
                                        ReferralStatisticsData?.available_free_subscription
                                      }
                                    </span>
                                  </li>
                                  <li className="flex my-2">
                                    <span className="text-[14px] w-[80%]">
                                      Used free subscription
                                    </span>
                                    <span className="text-[14px] w-[20%]">
                                      {
                                        ReferralStatisticsData?.used_free_subscription
                                      }
                                    </span>
                                  </li>
                                  <li className="flex my-2">
                                    <span className="text-[14px] w-[80%]">
                                      Total free subscription
                                    </span>
                                    <span className="text-[14px] w-[20%]">
                                      {
                                        ReferralStatisticsData?.total_free_subscription
                                      }
                                    </span>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                <ReactModal
                  isOpen={showShareModal}
                  onRequestClose={closeModal}
                  style={{
                    content: {
                      width: "410px",
                      height: "250px",
                      margin: "auto",
                      backgroundColor: "#373839",
                      color: "#ffffff",
                      borderRadius: "15px",
                    },
                    overlay: {
                      backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
                    },
                  }}
                >
                  <div className="flex flex-row	justify-between">
                    <p className="text-[25px] font-semibold">
                      Share your referral link
                    </p>
                    <button className="" onClick={closeModal}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                        className="w-6 h-6"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M6 18 18 6M6 6l12 12"
                        />
                      </svg>
                    </button>
                  </div>
                  <hr />
                  <div className="pt-3">
                    <EmailShareButton
                      url={`${urlToShareIS}`}
                      subject={`Sign up to Tracky usign referral link`}
                      body={`Sign up to Tracky usign referral link`}
                    >
                      <EmailIcon size={62} round={true} />
                    </EmailShareButton>
                    &nbsp;&nbsp;
                    <FacebookShareButton
                      url={`${urlToShareIS}`}
                      quote={social_share_message}
                    >
                      <FacebookIcon size={62} round={true} />
                    </FacebookShareButton>
                    &nbsp;&nbsp;
                    <TwitterShareButton
                      url={`${urlToShareIS}`}
                      title={social_share_message}
                    >
                      <TwitterIcon size={62} round={true} />
                    </TwitterShareButton>
                    &nbsp;&nbsp;
                    <LinkedinShareButton
                      url={`${urlToShareIS}`}
                      title={social_share_message}
                      summary={social_share_message}
                    >
                      <LinkedinIcon size={62} round={true} />
                    </LinkedinShareButton>
                    &nbsp;&nbsp;
                    <WhatsappShareButton
                      url={`${urlToShareIS}`}
                      title={social_share_message}
                    >
                      <WhatsappIcon size={62} round={true} />
                    </WhatsappShareButton>
                  </div>
                  <div className="pt-3">
                    <TelegramShareButton
                      url={`${urlToShareIS}`}
                      title={social_share_message}
                    >
                      <TelegramIcon size={62} round={true} />
                    </TelegramShareButton>
                    &nbsp;&nbsp;
                    <RedditShareButton
                      url={`${urlToShareIS}`}
                      title={social_share_message}
                    >
                      <RedditIcon size={62} round={true} />
                    </RedditShareButton>
                    &nbsp;&nbsp;
                  </div>
                </ReactModal>
              </>
            }
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(ReferralProgram);
