import React, {
  useState,
  useEffect,
} from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import {
  useForm,
  Controller,
} from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { handleKeyDown } from "../../utils/SpaceValidation";
import { ErrorMessage } from "@hookform/error-message";
import { Helmet } from "react-helmet";
import axios from "axios";
import LoginSecuritySkeleton from "../../CommonComponent/skeletons/LoginSecuritySkeleton";
import {
  useDispatch,
  useSelector,
} from "react-redux";
import OtpInput from "react-otp-input";
import {
  initialGetqr,
  resendGetqr,
  saveLoadingandSecurity,
} from "../../redux/slices/loginAndSecurity.js";

import { deleteaccount } from "../../redux/slices/authSlice.js";
import { useNavigate } from "react-router-dom";
import Skeleton, {
  SkeletonTheme,
} from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import Loader from "../../CommonComponent/Loader.jsx";
import { logoutData } from "../../redux/slices/authSlice.js";
import { resetOnBoard } from "../../redux/slices/onBoabrdSlice.js";
import Swal from "sweetalert2";
import CheckOnboard from "../AuthGuard/CheckOnboard.jsx";
import two_fector_icn from "../../assets/two_fector_icn.svg";
import back_icn from "../../assets/back_icn.svg";

function LoginSecurity() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const qrdata = useSelector(
    (state) =>
      state?.root?.loginSecurity?.qrdata
  );
  const initialLoading = useSelector(
    (state) =>
      state?.root?.loginSecurity
        ?.loading
  );
  const resendLoading = useSelector(
    (state) =>
      state?.root?.loginSecurity
        ?.resendloading
  );
  const saveLoading = useSelector(
    (state) =>
      state?.root?.loginSecurity
        ?.saveloading
  );
  const deleteAcLoading = useSelector(
    (state) =>
      state?.root?.auth
        ?.deleteaccountloading
  );
  const [
    hidePassfield,
    setHidePassfield,
  ] = useState(false);

  const PersonalinfoData = useSelector(
    (state) =>
      state?.root?.onboard
        ?.PersonalinfoData?.profileData
  );

  const validationSchema =
    Yup.object().shape({
      email: Yup.string()
        .required(
          "Please enter email address"
        )
        .matches(
          /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
          "Please enter valid email address"
        ),
      oldpassword: Yup.string()
        .required(
          "Please enter old password"
        )
        .matches(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
          "Must contain 8 characters, at least one uppercase, lowercase, number and special case character"
        )
        .max(
          15,
          "Maximum 15 characters allowed"
        ),
      newpassword: Yup.string()
        .required(
          "Please enter new password"
        )
        .matches(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
          "Must contain 8 characters, at least one uppercase, lowercase, number and special case character"
        )
        .max(
          15,
          "Maximum 15 characters allowed"
        )
        .test(
          "not-same-as-old-password",
          "New password must be different from old password",
          function (value) {
            const oldPassword = this.parent.oldpassword; // Accessing oldpassword value
            return value !== oldPassword; // Checking if confirmNewPassword is different from oldpassword
          }
        ),
      // .notOneOf(
      //   [
      //     Yup.ref("oldpassword"),
      //     null,
      //   ],
      //   "Confirm new password must be different from old password"
      // ),
      confirmpassword: Yup.string()
        .required(
          "Please enter confirm new password"
        )
        .oneOf(
          [
            Yup.ref("newpassword"),
            null,
          ],
          "Passwords must match"
        ),

      otpInput: Yup.string()
        .required(
          "Please enter the verification code"
        )
        .min(
          6,
          "Please enter complete 6 digit verification code"
        ),
    });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
    clearErrors,
    unregister,
    getValues,
    control,
  } = useForm({
    resolver: yupResolver(
      validationSchema
    ),
    defaultValues: {
      email: PersonalinfoData.email,
    },
  });

  const loginData = useSelector(
    (state) => state?.root?.auth
  );
  const accessToken =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const onSubmit = async (data) => {
    const formData = {
      email: data.email,
      old_password: data.oldpassword,
      new_password: data.newpassword,
      token: parseInt(data.otpInput),
    };
    dispatch(
      saveLoadingandSecurity(
        accessToken,
        formData,
        navigate,
        successDeleteAccount
      )
    );
  };

  const otpInputStyle = {
    width: "2em",
    textAlign: "center",
    margin: "0 0.2em",
    padding: "0.5em",
    fontSize: "1.2em",
    backgroundColor: "transparent",
    color: "white",
  };

  useEffect(() => {
    if (
      PersonalinfoData.google_sign_in ||
      PersonalinfoData.apple_sign_in
    ) {
      setHidePassfield(true);
      // unregister("oldpassword");
      // unregister("newpassword");
      // unregister("confirmpassword");
    } else {
      dispatch(
        initialGetqr(accessToken)
      );
    }

    //eslint-disable-next-line
  }, []);

  const ResendCode = () => {
    dispatch(resendGetqr(accessToken));
  };

  const deleteAccount = () => {
    dispatch(
      deleteaccount(
        accessToken,
        navigate
      )
    );
    // dispatch(logoutData());
    // dispatch(resetOnBoard());
  };

  const confirmDeleteAccount =
    async () => {
      Swal.fire({
        allowOutsideClick: false,
        background: "#373839",
        color: "#ffffff",
        title: "Are you sure ?",
        text: "you want to delete your account ?",
        icon: "question",
        showCancelButton: true,
        cancelButtonColor: "#2EDE9F",
        confirmButtonColor: "#FF0000",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
      }).then((result) => {
        if (result.isConfirmed) {
          deleteAccount();
        } else {
        }
      });
    };

  const successDeleteAccount =
    async () => {
      Swal.fire({
        allowOutsideClick: false,
        background: "#373839",
        color: "#ffffff",
        title:
          "Two-factor authentication",
        text: "Two-factor authentication verified",
        iconHtml: `<img src=${two_fector_icn}>`,
        customClass: {
          icon: "no-border-successTwoFactor",
        },
        showCancelButton: false,
        confirmButtonColor: "#2EDE9F",
        confirmButtonText: "Close",
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.close();
          navigate("/accountoverview");
        } else {
        }
      });

      setTimeout(function () {
        Swal.close();
      }, 4000);
    };

  const RedirectToAccountOverview =
    () => {
      navigate("/accountoverview");
    };

  return (
    <>
      <Helmet>
        <title>
          Tracky | Login and Security
        </title>
        <meta
          name="description"
          content="Tracky | Login and Security"
        />
      </Helmet>
      <div className=" FirstDiv">
        
        <div className="dark-bg content p-6">
          <div className=" text-[#ffffff] ">
            <div className="flex flex-row justify-between items-center">
              <h1 className="text-[20px] md:text-[30px] font-semibold mb-[16px]">
                Login & security
              </h1>
              <button
                className=" bg-transparent  text-[15px] font-medium
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px] me-6
                               flex items-center justify-end
                  "
                onClick={
                  RedirectToAccountOverview
                }
                type="button"
              >
                <img
                  src={back_icn}
                  alt="back icon"
                  className="me-4"
                />
                Back
              </button>
            </div>
            {/* form section start*/}
            {initialLoading ? (
              <LoginSecuritySkeleton />
            ) : (
              <>
                {" "}
                {/* form section start*/}
                <form
                  onSubmit={handleSubmit(
                    onSubmit
                  )}
                >
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div className="flex-col w-full">
                      <div className="w-full flex-col">
                        {hidePassfield ? (
                          <></>
                        ) : (
                          <>
                            <label className=" block w-full">
                              <span className="block text-[16px] font-semibold mb-2">
                                Email
                                address
                              </span>
                              <input
                                type="text"
                                className="w-full md:w-[80%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white  bg-[#403F3F] "
                                placeholder="Quinten@quinten.com"
                                {...register(
                                  "email"
                                )}
                                autoComplete="off"
                                onKeyPress={
                                  handleKeyDown
                                }
                                disabled
                              />

                              <ErrorMessage
                                errors={
                                  errors
                                }
                                name="email"
                                render={({
                                  message,
                                }) => (
                                  <p
                                    className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                  >
                                    {
                                      message
                                    }
                                  </p>
                                )}
                              />
                            </label>
                            {/* forgot my password */}
                            <label className=" block w-full my-4">
                              <span className="block text-[16px] font-semibold mb-4">
                                Forgot
                                my
                                password
                              </span>
                              <span className="block text-[16px] font-medium mb-2">
                                Old
                                password
                              </span>
                              <input
                                type="password"
                                className="w-full md:w-[80%] text-[16px] border-slate-200 placeholder-white
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                                // required
                                name="oldpassword"
                                autoComplete="new-password"
                                {...register(
                                  "oldpassword"
                                )}
                                placeholder="*********"
                                onKeyPress={
                                  handleKeyDown
                                }
                              />
                              <ErrorMessage
                                errors={
                                  errors
                                }
                                name="oldpassword"
                                render={({
                                  message,
                                }) => (
                                  <p
                                    className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                  >
                                    {
                                      message
                                    }
                                  </p>
                                )}
                              />
                            </label>
                            {/* forgot my password */}
                            <label className=" block w-full my-4">
                              <span className="block text-[16px] font-medium mb-2">
                                New
                                password
                              </span>
                              <input
                                type="password"
                                className="w-full md:w-[80%] text-[16px] border-slate-200 placeholder-white
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                                // required
                                name="newpassword"
                                autoComplete="new-password"
                                {...register(
                                  "newpassword"
                                )}
                                placeholder="*********"
                                onKeyPress={
                                  handleKeyDown
                                }
                              />
                              <ErrorMessage
                                errors={
                                  errors
                                }
                                name="newpassword"
                                render={({
                                  message,
                                }) => (
                                  <p
                                    className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                  >
                                    {
                                      message
                                    }
                                  </p>
                                )}
                              />
                            </label>
                            {/* confirm my password */}
                            <label className=" block w-full my-4">
                              <span className="block text-[16px] font-medium mb-2">
                                Confirm
                                new
                                password
                              </span>
                              <input
                                type="password"
                                className="w-full md:w-[80%] text-[16px] border-slate-200 placeholder-white
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                                // required
                                name="confirmpassword"
                                autoComplete="new-password"
                                {...register(
                                  "confirmpassword"
                                )}
                                placeholder="Type here"
                                onKeyPress={
                                  handleKeyDown
                                }
                              />
                              <ErrorMessage
                                errors={
                                  errors
                                }
                                name="confirmpassword"
                                render={({
                                  message,
                                }) => (
                                  <p
                                    className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                  >
                                    {
                                      message
                                    }
                                  </p>
                                )}
                              />
                            </label>
                          </>
                        )}

                        {/* delete accoun t section start*/}
                        <div className="">
                          <p className="text-[16px] font-semibold mt-4 mb-2">
                            Delete
                            account
                          </p>
                          <p className="text-sm font-normal text-[#FF0000] underline">
                            <span
                              onClick={
                                confirmDeleteAccount
                              }
                              className="cursor-pointer"
                            >
                              Click here
                              to delete
                              account
                            </span>
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* right two factor section start*/}
                    {hidePassfield ? (
                      <></>
                    ) : (
                      <>
                        <div className="flex-col w-full">
                          <div className="w-full flex-col">
                            <p className="text-[16px] font-bold">
                              Set up
                              two-factor
                              authentication
                            </p>
                            <span className="text-[14px] font-normal">
                              Scan this
                              QR code
                              with your
                              Google
                              authenticator
                              app
                            </span>

                            {resendLoading ||
                              !qrdata.image_url ? (
                              <>
                                <SkeletonTheme
                                  baseColor="#181818"
                                  highlightColor="#252525"
                                  borderRadius="0.5rem"
                                  duration={
                                    2
                                  }
                                >
                                  <div className="w-full">
                                    <Skeleton
                                      w
                                      height={
                                        170
                                      }
                                    />
                                  </div>
                                </SkeletonTheme>
                              </>
                            ) : (
                              <>
                                <div className="mt-2 rounded-[10px] p-6 bg-white text-center flex justify-center items-center">
                                  <img
                                    src={
                                      qrdata.image_url
                                    }
                                    alt="qr code"
                                    className=""
                                  />
                                </div>
                              </>
                            )}
                            <div className="mt-4">
                              <p className="text-[16px] font-normal">
                                Verification
                                code
                              </p>
                              {/* <div className="flex justify-start content-start mt-2"> */}
                              <Controller
                                control={
                                  control
                                }
                                name="otpInput"
                                render={({
                                  field:
                                  {
                                    onChange,
                                    onBlur,
                                    value,
                                    ref,
                                    fieldState,
                                  },
                                }) => (
                                  <OtpInput
                                    // skipDefaultStyles={true}
                                    // inputStyle={"bg-transparent border border-[#ffffff] rounded-sm py-2 px-4 me-4 text-[#ffffff]"}
                                    inputStyle={
                                      otpInputStyle
                                    }
                                    containerStyle={
                                      "flex justify-start content-start mt-2 text-white	w-full md:w-[80%]"
                                    }
                                    value={
                                      value
                                    }
                                    onChange={
                                      onChange
                                    }
                                    inputType="tel"
                                    onBlur={
                                      onBlur
                                    }
                                    ref={
                                      ref
                                    }
                                    numInputs={
                                      6
                                    }
                                    renderSeparator={
                                      <>

                                      </>
                                    }
                                    renderInput={(
                                      props
                                    ) => (
                                      <input
                                        {...props}
                                      />
                                    )}
                                  />
                                )}
                              />

                              <ErrorMessage
                                errors={
                                  errors
                                }
                                name="otpInput"
                                render={({
                                  message,
                                }) => (
                                  <p
                                    className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                  >
                                    {
                                      message
                                    }
                                  </p>
                                )}
                              />
                              {/* </div> */}
                            </div>
                            <p className="text-[14px] font-normal mt-4">
                              Didn’t get
                              a code?
                              <span
                                className="underline cursor-pointer ms-2"
                                onClick={
                                  ResendCode
                                }
                              >
                                Click to
                                resend
                              </span>
                            </p>
                            <div className="flex flex-col md:flex-row items-center justify-start mt-4">
                              <button
                                className="rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium
                               py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-4 md:mb-0 grow
                  "
                                onClick={
                                  RedirectToAccountOverview
                                }
                                type="button"
                              >
                                Cancel
                              </button>
                              <button
                                className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow"
                                type="submit"
                                disabled={
                                  saveLoading
                                }
                              >
                                {saveLoading ? (
                                  <>
                                    <Loader />
                                  </>
                                ) : (
                                  "Confirm"
                                )}
                              </button>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </form>
                {/* main sections started*/}
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(
  LoginSecurity
);
