import React, { useEffect, useState } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm, Controller } from "react-hook-form";
import moment from "moment-timezone";

import * as Yup from "yup";
import { handleKeyDown } from "../../utils/SpaceValidation";
import { ErrorMessage } from "@hookform/error-message";
import rounded from "../../assets/rounded.svg";
import alex_img from "../../assets/alex_img.svg";

import {
  GetOnBoardRoles,
  OnBoardPersonalInfo,
  UpdateOnBoardPersonalInfo,
} from "../../redux/slices/onBoabrdSlice";
import { useDispatch, useSelector } from "react-redux";
import { Helmet } from "react-helmet";
import Loader from "../../CommonComponent/Loader";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import { useNavigate } from "react-router";
import PersonalInfoSkeleton from "../../CommonComponent/skeletons/PersonalInfoSkeleton";
import { MuiChipsInput } from "mui-chips-input";
// import { DevTool } from "@hookform/devtools";
import back_icn from "../../assets/back_icn.svg";

function PersonalInfo() {
  const PersonalinfoData = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData
  );

  const PersonalImage = `${process.env.REACT_APP_IO}/${PersonalinfoData?.profileData?.profile_image}`;
  const UsernameDisabled =
    PersonalinfoData?.profileData?.user_name &&
    PersonalinfoData?.profileData?.user_name !== "";

  const [selectedImage, setSelectedImage] = useState(null);
  const [timezones, setTimezones] = useState([]);
  const [isdisabled, setIsdisabled] = useState(UsernameDisabled);

  const [chips, setChips] = useState([]);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loginData = useSelector((state) => state?.root?.auth);
  const GetOnboard = useSelector((state) => state?.root?.onboard);
  const isInitialSkeleton = useSelector(
    (state) => state?.root?.onboard?.loading
  );
  const isSubmitBtnLoader = useSelector(
    (state) => state?.root?.onboard?.UpdateOnBoardPerloading
  );

  const BoardRole = GetOnboard.onboardRole;

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const validationSchema = Yup.object().shape({
    average_deal_size: Yup.string()
      .required("Enter average deal size")

      .test(
        "max-characters",
        "Value must be at most 6 digits",
        (value) => value.replace(/^0+/, "").length <= 6
      )
      .matches(/^(0(\.\d+)?|[1-9]\d*(\.\d+)?)$/, "Enter a valid number"),
    user_name: Yup.string()
      .required("Please enter username")
      .max(15, "Username must be at most 15 characters")
      .matches(
        /^[a-zA-Z][a-zA-Z\d_-]*$/,
        "Username must start with a letter and can only contain letters, numbers, underscores, and dashes"
      )
      .min(3, ({ min }) => `Username must be at least ${min} characters`),

    first_name: Yup.string()
      .required("Please enter first name")
      .max(30, "first name must be at most 30 characters"),
    last_name: Yup.string()
      .required("Please enter last name")
      .max(30, "last name must be at most 30 characters"),
    role: Yup.string().required("Please select a role"),
    bio: Yup.string()
      .required("Please enter bio")
      .max(150, "Bio must be at most 150 characters"),
    profile_image: Yup.mixed()
      .test("required", "Please upload a profile image", (value) => {
        return value?.length === 0 ? false : true;
      })
      .test("fileFormat", "Unsupported file format", (value) => {
        if (typeof value === "string") {
          return true;
        } else {
          return (
            value &&
            ["image/jpeg", "image/jpg", "image/png"].includes(value?.type)
          );
        }
      })
      .test("fileSize", "File size is too large", (value) => {
        if (typeof value === "string") {
          return true;
        } else {
          return value && value?.size <= 1024 * 1024 * 2; // 2MB
        }
      }),
    language: Yup.string()
      .required("Please enter languages")
      .max(100, "languages must be at most 100 characters"),
    time_zone: Yup.string().required("Please enter timezone"),
    bound: Yup.string().required("Please select a Bound"),
    skills: Yup.array()
      .required("Please enter skills")
      // .test(
      //   "maxSkills",
      //   "Maximum 10 characters allowed for each skill",
      //   (skills) => {
      //     if (!skills) return true; // Allow undefined or empty array
      //     return skills.every((skill) =>
      //       Yup.string().max(10).isValidSync(skill)
      //     );
      //   }
      // )
      .test(
        "stringSkills",
        "Skills must be strings and not all numbers",
        (skills) => {
          if (!skills) return true; // Allow undefined or empty array
          return skills.every(
            (skill) => Yup.string().isValidSync(skill) && !/^\d+$/.test(skill)
          );
        }
      )
      .min(3, "Please enter atleast 3 strong skills")
      .max(3, "Maximum 3 skills allowed"),
  });


  const validationSchemaWithoutUserName = Yup.object().shape({
    average_deal_size: Yup.string()
      .required("Enter average deal size")

      .test(
        "max-characters",
        "Value must be at most 6 digits",
        (value) => value.replace(/^0+/, "").length <= 6
      )
      .matches(/^(0(\.\d+)?|[1-9]\d*(\.\d+)?)$/, "Enter a valid number"),
    // user_name: Yup.string()
    //   .required("Please enter username")
    //   .max(15, "Username must be at most 15 characters")
    //   .matches(
    //     /^[a-z][a-z\d_-]*$/,
    //     "Username must start with a lowercase letter and can only contain lowercase letters, numbers, underscores, and dashes"
    //   )
    //   .min(3, ({ min }) => `Username must be at least ${min} characters`),

    first_name: Yup.string()
      .required("Please enter first name")
      .max(30, "first name must be at most 30 characters"),
    last_name: Yup.string()
      .required("Please enter last name")
      .max(30, "last name must be at most 30 characters"),
    role: Yup.string().required("Please select a role"),
    bio: Yup.string()
      .required("Please enter bio")
      .max(150, "Bio must be at most 150 characters"),
    profile_image: Yup.mixed()
      .test("required", "Please upload a profile image", (value) => {
        return value?.length === 0 ? false : true;
      })
      .test("fileFormat", "Unsupported file format", (value) => {
        if (typeof value === "string") {
          return true;
        } else {
          return (
            value &&
            ["image/jpeg", "image/jpg", "image/png"].includes(value?.type)
          );
        }
      })
      .test("fileSize", "File size is too large", (value) => {
        if (typeof value === "string") {
          return true;
        } else {
          return value && value?.size <= 1024 * 1024 * 2; // 2MB
        }
      }),
    language: Yup.string()
      .required("Please enter languages")
      .max(100, "languages must be at most 100 characters"),
    time_zone: Yup.string().required("Please enter timezone"),
    bound: Yup.string().required("Please select a Bound"),
    skills: Yup.array()
      .required("Please enter skills")
      // .test(
      //   "maxSkills",
      //   "Maximum 10 characters allowed for each skill",
      //   (skills) => {
      //     if (!skills) return true; // Allow undefined or empty array
      //     return skills.every((skill) =>
      //       Yup.string().max(10).isValidSync(skill)
      //     );
      //   }
      // )
      .test(
        "stringSkills",
        "Skills must be strings and not all numbers",
        (skills) => {
          if (!skills) return true; // Allow undefined or empty array
          return skills.every(
            (skill) => Yup.string().isValidSync(skill) && !/^\d+$/.test(skill)
          );
        }
      )
      .min(3, "Please enter atleast 3 strong skills")
      .max(3, "Maximum 3 skills allowed"),
  });


  const NewValidationSchema = isdisabled ? validationSchemaWithoutUserName : validationSchema;


  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
    setError,
    clearErrors,
    reset,
    watch,
  } = useForm({
    resolver: yupResolver(NewValidationSchema),
    mode: "all",
    defaultValues: {
      total_chat:
        PersonalinfoData?.profileData?.role?.key === "setter"
          ? PersonalinfoData?.sumData?.total_chat
          : 0,
      total_calls:
        PersonalinfoData?.profileData?.role?.key === "closer"
          ? PersonalinfoData?.sumData?.total_calls
          : 0,
      total_closed: PersonalinfoData?.sumData?.total_closed,
      skills: [],
      bio: PersonalinfoData?.profileData?.bio,
      user_name: PersonalinfoData?.profileData?.user_name
        ? PersonalinfoData?.profileData?.user_name
        : "",
      bound:
        PersonalinfoData?.profileData?.bound &&
        PersonalinfoData?.profileData?.bound,
    },
  });

  const skillwatch = watch("skills");

  const onImageClick = () => {
    document.getElementById("imageInput").click();
  };

  const onImageChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setValue("profile_image", file);
      await trigger("profile_image");

      setSelectedImage(URL.createObjectURL(file));
    }
  };

  useEffect(() => {
    const allTimezones = moment.tz.names();
    setTimezones(allTimezones);
  }, []);

  useEffect(() => {
    dispatch(OnBoardPersonalInfo(auth));
    dispatch(GetOnBoardRoles(auth));
  }, [dispatch]);

  useEffect(() => {
    // Set default value for "role" once PersonalinfoData is available
    setSelectedImage(PersonalImage);
    setValue("profile_image", PersonalImage);
    setValue("user_name", PersonalinfoData?.profileData?.user_name);
    setValue("bio", PersonalinfoData?.profileData?.bio);
    setValue("bound", PersonalinfoData?.profileData?.bound);
    setValue("total_closed", PersonalinfoData?.sumData?.total_closed);
    setValue("total_calls", PersonalinfoData?.sumData?.total_calls);
    setValue("total_chat", PersonalinfoData?.sumData?.total_chat);
    setValue(
      "average_deal_size",
      PersonalinfoData?.profileData?.average_deal_size
    );
    setValue("first_name", PersonalinfoData?.profileData?.first_name);
    setValue("last_name", PersonalinfoData?.profileData?.last_name);
    setValue("language", PersonalinfoData?.profileData?.language);
    setValue("time_zone", PersonalinfoData?.profileData?.time_zone);

    setValue(
      "skills",
      PersonalinfoData?.profileData?.skills?.length > 0
        ? JSON.parse(PersonalinfoData?.profileData?.skills)
        : []
    );

    if (PersonalinfoData?.profileData?.role?._id) {
      setValue("role", PersonalinfoData.profileData.role._id);
    }
    const ISUserDisabled =
      PersonalinfoData?.profileData?.user_name &&
      PersonalinfoData?.profileData?.user_name !== "";
    setIsdisabled(ISUserDisabled);
  }, [PersonalinfoData, setValue]);

  const onSubmit = async (data) => {
    const formData = new FormData();
    formData.append("average_deal_size", data.average_deal_size);
    formData.append("total_chat", data.total_chat);
    formData.append("total_calls", data.total_calls);
    formData.append("total_closed", data.total_closed);
    formData.append("first_name", data.first_name);
    formData.append("last_name", data.last_name);
    formData.append("role", data.role);
    formData.append("bio", data.bio);
    formData.append("profile_image", data.profile_image);
    formData.append("language", data.language);
    formData.append("time_zone", data.time_zone);
    formData.append("bound", data.bound);
    formData.append("user_name", data?.user_name);

    formData.append("skills", JSON.stringify(data.skills));

    await dispatch(UpdateOnBoardPersonalInfo(formData, auth, navigate));
  };

  const onCancel = () => {
    reset();
    navigate("/accountoverview");
  };

  const getTimezoneOptions = () => {
    return timezones.map((tz) => {
      const gmtOffset = moment.tz(tz).format("Z");

      const countryName = tz.split("/")[0]; // Extracting the country name

      return (
        <option key={tz} value={`${gmtOffset} - ${countryName}`}>
          {`${gmtOffset} - ${tz}`}
        </option>
      );
    });
  };

  const handleChange = (newChips) => {
    setChips(newChips);
  };

  const handleAddChip = (chipValue, chipIndex) => {
    /**
    chipValue: 'bar'
    chipIndex: 1
    **/
  };
  const RedirectToAccountOverview = () => {
    navigate("/accountoverview");
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Personal Info</title>
        <meta name="description" content="Tracky | Personal Info" />
      </Helmet>
      <div className=" FirstDiv">
        <div className="dark-bg md:content p-6 md:h-[calc(100vh-80px)]">
          <div className="  text-[#ffffff] ">
            {isInitialSkeleton ? (
              <PersonalInfoSkeleton />
            ) : (
              <>
                <div className="w-full   text-[#ffffff]">
                  <div className="flex flex-row items-center justify-between">
                    <h1 className="text-[20px] md:text-[30px] font-semibold mb-[16px]">
                      Personal info
                    </h1>
                    <button
                      className=" bg-transparent  text-[15px] font-medium
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px] me-6
                               flex items-center justify-end
                  "
                      onClick={RedirectToAccountOverview}
                      type="button"
                    >
                      <img src={back_icn} alt="back icon" className="me-4" />
                      Back
                    </button>
                  </div>
                  {/* form section start*/}

                  <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div className="flex-col w-full">
                        <div className="block w-full md:flex md:items-center ">
                          <label className=" block w-full md:w-[40%]">
                            <span className="block text-[16px] font-semibold mb-2">
                              Average deal size
                            </span>
                            <input
                              type="text"
                              className="w-full  md:w-[90%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                              defaultValue={
                                PersonalinfoData?.profileData?.average_deal_size
                                  ? PersonalinfoData?.profileData
                                      ?.average_deal_size
                                  : 0
                              }
                              {...register("average_deal_size")}
                              autoComplete="off"
                              // onKeyPress={handleKeyDown}
                              onKeyPress={(e) => {
                                const charCode = e.which ? e.which : e.keyCode;
                                if (
                                  (charCode > 31 &&
                                    (charCode < 48 || charCode > 57) &&
                                    charCode !== 46) ||
                                  (charCode === 46 &&
                                    e.target.value.includes("."))
                                ) {
                                  e.preventDefault();
                                }
                              }}
                            />
                            <ErrorMessage
                              errors={errors}
                              name="average_deal_size"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                          {PersonalinfoData?.profileData?.role?.key ===
                            "setter" && (
                            <label className=" block w-full md:w-[30%] me-2">
                              <span className="block  mb-2 text-[16px] font-normal mt-4 md:mt-0">
                                Total chats
                              </span>
                              <input
                                type="text"
                                className="w-full md:w-[90%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#403F3F] "
                                placeholder="1657"
                                {...register("total_chat")}
                                autoComplete="off"
                                onKeyPress={handleKeyDown}
                                disabled
                              />
                            </label>
                          )}
                          {PersonalinfoData?.profileData?.role?.key ===
                            "closer" && (
                            <label className=" block w-full md:w-[30%] me-2">
                              <span className="block text-[16px] font-normal mt-4 md:mt-0 mb-2">
                                Total calls
                              </span>
                              <input
                                type="text"
                                className="w-full md:w-[90%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#403F3F] "
                                placeholder="347"
                                {...register("total_calls")}
                                autoComplete="off"
                                onKeyPress={handleKeyDown}
                                disabled
                              />
                            </label>
                          )}
                          <label className=" block w-full md:w-[30%] me-2">
                            <span className="block text-[16px] font-normal mt-4 md:mt-0 mb-2">
                              Total closed
                            </span>
                            <input
                              type="text"
                              className="w-full md:w-[90%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#403F3F] "
                              placeholder="347"
                              {...register("total_closed")}
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                              disabled
                            />
                          </label>
                        </div>
                        <div className="block w-full my-6 md:flex">
                          <label className=" block w-full md:w-[40%] ">
                            <span className="block  mb-2 text-[16px] font-semibold mt-4 md:mt-0">
                              First name
                            </span>
                            <input
                              type="text"
                              className="w-full md:w-[90%]  text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                              placeholder="First name"
                              defaultValue={
                                PersonalinfoData?.profileData?.first_name
                              }
                              {...register("first_name")}
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                            />
                            <ErrorMessage
                              errors={errors}
                              name="first_name"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                          <label className=" block w-full md:w-[40%] ">
                            <span className="block  mb-2 text-[16px] font-semibold mt-4 md:mt-0">
                              Last name
                            </span>
                            <input
                              type="text"
                              className="w-full md:w-[90%]  text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                              {...register("last_name")}
                              defaultValue={
                                PersonalinfoData?.profileData?.last_name
                              }
                              placeholder="last name"
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                            />
                            <ErrorMessage
                              errors={errors}
                              name="last_name"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                          <label className=" block w-full md:w-[25%] ">
                            <span className="block  mb-2 text-[16px] font-semibold mt-4 md:mt-0 z-0">
                              Roll
                            </span>
                            <select
                              type="text"
                              className="w-full md:w-[80%] text-[16px]
                                bg-[transparent] border border-gray-300 text-gray-400
                                rounded-lg   py-[10px] px-[15px]
                                 "
                              {...register("role")}
                              autoComplete="off"
                              defaultValue={
                                PersonalinfoData?.profileData?.role?._id
                              }
                              disabled
                            >
                              {BoardRole?.map((role) => (
                                <option key={role?._id} value={role?._id}>
                                  {role?.key}
                                </option>
                              ))}
                            </select>
                            <ErrorMessage
                              errors={errors}
                              name="role" // Corrected from "ro" to "role"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                        </div>
                        <div className="block w-full my-6 md:flex">
                          <label className="block w-full ">
                            <span className="block text-[16px] font-semibold mb-2">
                              Username
                            </span>
                            <input
                              type="text"
                              className={`w-full md:w-[100%]  text-[16px] border-slate-200
                            placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white ${
                      isdisabled ? "bg-[#403F3F]" : "bg-[transparent]"
                    }  `}
                              // defaultValue={PersonalinfoData?.profileData?.bio}
                              {...register("user_name")}
                              placeholder="Username"
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                              disabled={isdisabled}
                            />{" "}
                            <ErrorMessage
                              errors={errors}
                              name="user_name"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                        </div>
                        <div className="block w-full my-6 md:flex">
                          <label className="block w-full ">
                            <span className="block text-[16px] font-semibold mb-2">
                              Bio
                            </span>
                            <textarea
                              type="text"
                              className="w-full md:w-[100%]  text-[16px] border-slate-200
                            placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                              // defaultValue={PersonalinfoData?.profileData?.bio}
                              {...register("bio")}
                              placeholder="My name is..."
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                            >
                              {" "}
                            </textarea>
                            <ErrorMessage
                              errors={errors}
                              name="bio"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                        </div>
                        <div className="w-full">
                          <p className="text-[16px] font-semibold">
                            Profile picture
                          </p>
                          <div
                            className="rounded-full w-[70px] h-[70px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
                          >
                            <img
                              className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content"
                              src={selectedImage || alex_img}
                              alt="user"
                              onClick={onImageClick}
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null; // prevents looping
                                currentTarget.src = alex_img;
                              }}
                            />
                            <input
                              className="p-4 bg-center bg-no-repeat bg-cover bg-origin-content"
                              id="imageInput"
                              type="file"
                              {...register("profile_image")}
                              style={{
                                display: "none",
                              }}
                              onChange={onImageChange}
                              accept="image/*"
                            />
                          </div>
                          {errors.profile_image && (
                            <p
                              className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                            >
                              {" "}
                              {errors.profile_image.message}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* right two factor section start*/}

                      <div className="flex-col w-full">
                        <div className="flex-col w-full">
                          <label className="block w-full ">
                            <span className="block text-[16px] font-semibold mb-2">
                              Languages
                            </span>
                            <input
                              type="text"
                              className="w-full md:w-[100%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                              {...register("language")}
                              placeholder="Dutch,English,Spanish"
                              defaultValue={
                                PersonalinfoData?.profileData?.language
                              }
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                            />

                            <ErrorMessage
                              errors={errors}
                              name="language"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                          <label className="block w-full my-6 ">
                            <span className="block text-[16px] font-semibold mb-2">
                              Timezone
                            </span>
                            <Controller
                              name="time_zone"
                              control={control}
                              defaultValue={
                                PersonalinfoData?.profileData?.time_zone
                              }
                              render={({ field }) => (
                                <select
                                  className="w-full md:w-[100%] text-[16px]
                                bg-[#0D0D0D] border border-gray-300 text-white
                                rounded-lg focus:ring-blue-500 focus:border-blue-500 block  py-[10px] px-[15px]
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                 dark:focus:border-blue-500"
                                  {...field}
                                  autoComplete="off"
                                  onChange={(e) => {
                                    field.onChange(e);
                                    setValue("time_zone", e.target.value);
                                  }}
                                >
                                  <option className="bg-dark text-red" value="">
                                    Select Timezone
                                  </option>
                                  {getTimezoneOptions()}
                                </select>
                              )}
                            />

                            <ErrorMessage
                              errors={errors}
                              name="time_zone"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                          <label className="block w-full my-6 ">
                            <span className="block text-[16px] font-semibold mb-2">
                              Inbound or outbound?
                            </span>

                            <select
                              className="w-full md:w-[100%] text-[16px]
                                bg-[#0D0D0D] border border-gray-300 text-white
                                rounded-lg focus:ring-blue-500 focus:border-blue-500 block  py-[10px] px-[15px]
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                 dark:focus:border-blue-500"
                              name="bound"
                              {...register("bound")}
                              autoComplete="off"
                            >
                              <option value="inbound">Inbound</option>
                              <option value="outbound">Outbound</option>
                            </select>

                            <ErrorMessage
                              errors={errors}
                              name="bound"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          </label>
                          <label className="block w-full mb-4  chip_block">
                            <span className="block text-[16px] font-semibold mb-2">
                              3 strong skills
                            </span>
                            {/* <input
                              type="text"
                              className="w-full md:w-[100%] text-[18px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[18px] px-[25px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                              {...register("skills")}
                              placeholder="Cold calling,objection handeling..."
                              autoComplete="off"
                              onKeyPress={handleKeyDown}
                              defaultValue={
                                PersonalinfoData?.profileData?.skills
                              }
                            /> */}
                            <Controller
                              className="w-full md:w-[100%] text-[16px] border-slate-200 placeholder-white
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    focus:border-0 focus:outline-none ps-6
                    contrast-more:placeholder-white bg-[transparent] rounded-lg"
                              control={control}
                              name="skills"
                              render={({ field, fieldState }) => (
                                <MuiChipsInput
                                  className="w-full md:w-[100%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[25px]
                    rounded-lg focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] "
                                  value={chips}
                                  onChange={handleChange}
                                  onAddChip={handleAddChip}
                                  hideClearAll
                                  error={fieldState.invalid}
                                  {...field}
                                />
                              )}
                            />
                            <ErrorMessage
                              errors={errors}
                              name="skills"
                              render={({ message }) => (
                                <p
                                  className="mt-2 opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[100%] mb-4"
                                >
                                  {message}
                                </p>
                              )}
                            />
                            {/* <div
                              className="flex flex-row flex-wrap items-center justify-start"
                            >
                              {skillwatch?.length > 0 &&
                                skillwatch?.map((chip, i) => {
                                  return (
                                    <div className="mt-4 mb-4 me-4">
                                      <button
                                        className=" border
                                       border-[#BFBFBF] bg-[#403F3F] text-[16px] rounded-lg
                                 text-white py-2 px-4"
                                        type="button"
                                      >
                                        {chip}
                                      </button>
                                    </div>
                                  );
                                })}
                            </div> */}
                          </label>
                          <div className="w-full">
                            {/* <button
                              className="rounded-[8px]  border-2 my-6
                           border-[#403F3F] bg-[#BFBFBF]
                           text-[15px] font-medium py-[26px]  w-full md:w-[100%]
                  hover:bg-[#ffffff] hover:text-[#000000]
                  "
                            >
                              Cold calling
                            </button> */}
                          </div>
                          <div className="flex flex-col items-center justify-start md:flex-row">
                            <button
                              className="rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium
                               py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-4 md:mb-0 grow
                  "
                              type="button"
                              onClick={onCancel}
                            >
                              Cancel
                            </button>
                            <button
                              className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow
                  "
                              type="submit"
                              disabled={isSubmitBtnLoader}
                            >
                              {isSubmitBtnLoader ? (
                                <>
                                  <div
                                    className="mx-auto text-center flex justify-center
                       items-center content-center w-[100%]"
                                  >
                                    <Loader />
                                  </div>
                                </>
                              ) : (
                                <>Submit</>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>

                  {/* <DevTool control={control} /> */}
                </div>
              </>
            )}
            {/* main sections started*/}
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(PersonalInfo);
