import React, {
  useEffect,
  useState,
  useContext
} from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import {
  useDispatch,
  useSelector,
} from "react-redux";
import {
  GetOnBoardPayments,
  UpdatePaymentPlan,
  OnBoardPersonalInfo
} from "../../redux/slices/onBoabrdSlice";
import logo_light from "../../assets/logo_light.svg";
import { useForm } from "react-hook-form";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import { Helmet } from "react-helmet";
import Swal from "sweetalert2";
import Loader from "../../CommonComponent/Loader.jsx";
import ManagePlanSkeleton from "../../CommonComponent/skeletons/ManagePlanSkeleton.jsx";
import { useNavigate } from "react-router-dom";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';

import back_icn from "../../assets/back_icn.svg";

function ManagePlan() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loginData = useSelector(
    (state) => state?.root?.auth
  );
  const GetOnboard = useSelector(
    (state) => state?.root?.onboard
  );

  const { socket, isSocketConnected } = useContext(SocketContext);
  // const BoardPayment = GetOnboard.onboardpaymentData;
  const BoardPayment = useSelector(
    (state) =>
      state?.root?.onboard
        ?.onboardpaymentData
  );
  // const [plan, setSelectedPlan] = useState("");
  const updatePaymentLogin =
    useSelector(
      (state) =>
        state?.root?.onboard
          ?.updatePaymentLogin
    );
  const isInitialSkeleton = useSelector(
    (state) =>
      state?.root?.onboard
        ?.GetOnBoardPaymentsloading
  );

  const PersonalinfoData = useSelector(
    (state) =>
      state?.root?.onboard
        ?.PersonalinfoData
  );

  const selectedPayment =
    BoardPayment?.filter(
      (pay, i) =>
        pay?.interval ==
        PersonalinfoData.profileData
          .plan_purchased_type
    );

  const {
    register,
    formState: { errors },
    setValue,
    handleSubmit,
  } = useForm({
    defaultValues: {
      plan_id:
        selectedPayment[0]?.plan_id,
    },
  });

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  useEffect(() => {
    dispatch(OnBoardPersonalInfo(auth));
    dispatch(GetOnBoardPayments(auth));
  }, [dispatch]);

  useEffect(() => {
    const selectedPayment =
      BoardPayment?.filter(
        (pay, i) =>
          pay?.interval ==
          PersonalinfoData.profileData
            .plan_purchased_type
      );
    if (selectedPayment) {
      setValue(
        "plan_id",
        selectedPayment[0]?.plan_id
      );
    }
  }, [selectedPayment]);

  const pleaseChangePlan = async () => {
    Swal.fire({
      allowOutsideClick: false,
      background: "#373839",
      color: "#ffffff",
      // title: "Are you sure ?",
      text: "Please change the selected plan first to upgrade your plan.",
      icon: "error",
      showCancelButton: false,
      confirmButtonColor: "#2EDE9F",
      confirmButtonText: "Okay",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.close();
      } else {
      }
    });
    setTimeout(function () {
      Swal.close();
    }, 3000);
  };

  const onSubmit = async (data) => {
    if (
      data?.plan_id ==
      selectedPayment[0]?.plan_id
    ) {
      pleaseChangePlan();
      return;
    }

    const payload = {
      plan_id: data?.plan_id,
      success_url:
        process.env
          .REACT_APP_SUCCESS_PAYMENT,
      cancle_url:
        process.env
          .REACT_APP_FAILER_PAYMENT,
    };
    dispatch(
      UpdatePaymentPlan(payload, auth)
    );
  };

  useEffect(() => {
    socket?.on(
      "PAYMENT_SUCCESS",
      (payload) => {
        socket?.emit(
          "CONFIRMATION",
          "Event received and processed : PAYMENT_SUCCESS"
        );

        RedirectToAccountOverview();
        open(location, "_self").close();
      }
    );
  }, [socket]);

  const RedirectToAccountOverview =
    () => {
      navigate("/accountoverview");
    };

  return (
    <>
      <Helmet>
        <title>
          Tracky | Manage Plan
        </title>
        <meta
          name="description"
          content="Tracky | Manage Plan"
        />
      </Helmet>
      <div className=" FirstDiv">

        <div className="p-6 dark-bg content">
          <div className="  text-[#ffffff] ">
            {isInitialSkeleton ||
              selectedPayment[0]
                ?.plan_id == undefined ? (
              <ManagePlanSkeleton />
            ) : (
              <>
                <div className="w-full   text-[#ffffff]">
                  <h1 className="text-[20px] md:text-[30px] font-semibold ">
                    Manage plan
                  </h1>
                  <div className="flex flex-row items-center justify-between">
                    <p className="text-[16px] ">
                      Current Plan
                    </p>
                    <button
                      className=" bg-transparent  text-[15px] font-medium
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px] me-6
                               flex items-center justify-end
                  "
                      onClick={
                        RedirectToAccountOverview
                      }
                      type="button"
                    >
                      <img
                        src={back_icn}
                        alt="back icon"
                        className="me-4"
                      />
                      Back
                    </button>
                  </div>

                  <form
                    onSubmit={handleSubmit(
                      onSubmit
                    )}
                  >
                    <div className="mt-6 ">
                      <div
                        className="grid w-3/5 grid-flow-row md:shrink-0 auto-rows-max"
                      >
                        {BoardPayment &&
                          BoardPayment?.length >
                          0 &&
                          BoardPayment?.map(
                            (
                              payment,
                              index
                            ) => {
                              return (
                                <>
                                  <label
                                    class="has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            mb-4 cursor-pointer"
                                  >
                                    {/* <div
                                    className={`border p-4 rounded-[12px] bg-[#373839] mb-4 ${payment?.plan_id ===
                                      selectedPayment[0]
                                        ?.plan_id &&
                                      "border-[#21CE90]"
                                      } `}
                                  > */}

                                    <div
                                      className="flex flex-col items-center content-center h-full md:flex-row"
                                    >
                                      <div className="flex-none mb-2 md:md-0">
                                        <input
                                          type="radio"
                                          value={
                                            payment?.plan_id
                                          }
                                          {...register(
                                            "plan_id"
                                          )}
                                          name="plan_id"
                                        />
                                      </div>
                                      <div className="flex-auto w-64  mx-[10px] ps-4 text-center md:text-left">
                                        <div className="grid grid-flow-row auto-rows-max">
                                          <div className="text-[18px] mb-4 font-bold">
                                            {
                                              payment?.name
                                            }
                                          </div>
                                          <div className="text-[16px] mb-4">
                                            {
                                              payment?.description
                                            }
                                          </div>
                                        </div>
                                      </div>
                                      {payment?.sort_value ===
                                        0 && (
                                          <div className="flex-none md:flex-1">
                                            <button
                                              className="w-full px-[30px] rouned_button_transparent text-center h-[50px]
                                           bg-[#21CE90] shadow-2xl
                  flex items-center justify-center"
                                              type="button"
                                            >
                                              Best
                                              Value
                                            </button>
                                          </div>
                                        )}
                                    </div>

                                  </label>
                                  {/* </div> */}
                                </>
                              );
                            }
                          )}

                        {errors.plan_id && (
                            <p
                            className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                            >
                            {
                              errors
                                .plan_id
                                .message
                            }
                          </p>
                        )}
                        <button
                          type="submit"
                          className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px]  hover:bg-[#ffffff] hover:text-[#000000] grow"
                          disabled={
                            updatePaymentLogin
                          }
                        >
                          {updatePaymentLogin ? (
                            <>
                              <div
                                className="mx-auto text-center flex justify-center
                       items-center content-center w-[100%]"
                              >
                                <Loader />
                              </div>
                            </>
                          ) : (
                            "Upgrade plan"
                          )}
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(ManagePlan);
