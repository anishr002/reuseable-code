// ChartComponent.js
import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import axios from "axios";
import Chart from "chart.js/auto"; // Import Chart.js library
import { useDispatch, useSelector } from "react-redux";
import { GetDashboardChart } from "../../redux/slices/onBoabrdSlice";
import { data } from "autoprefixer";

const MonthChart = ({ DashboardData }) => {
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      {
        label: "Green Line",
        data: [],
        fill: false,
        borderColor: "#2EDE9F",
        tension: 0.4,
      },
    ],
  });

  useEffect(() => {
    setChartData({
      labels: DashboardData?.graphData?.mergedData?.map(
        (entry) => entry?.month
      ),
      datasets: [
        {
          label: "Profits",
          data: DashboardData?.graphData?.mergedData?.map(
            (entry) => entry?.avgDealSize
          ),
          fill: true,
          borderColor: "#2EDE9F",
          tension: 0.4,
          cubicInterpolationMode: "monotone",
          backgroundColor: "rgba(46, 222, 159, 0.12)",
        },
      ],
    });
  }, [DashboardData]);

  const options = {
    scales: {
      x: {
        type: "category",
        labels: chartData.labels,
      },
      y: {
        display: false, // Hide the left side y-axis
      },
    },
    elements: {
      line: {
        tension: 0.5, // Increase the tension for more curve
      },
    },
    responsive: true,
    maintainAspectRatio: false,

    plugins: {
      legend: {
        display: true,
        position: "bottom", // 'top', 'left', 'right', 'bottom',
        labels: {
          usePointStyle: true,
          pointStyle: "rect",
        },
      },
      tooltip: {
        callbacks: {
          title: function (tooltipItem) {
            // Display the year and month in the tooltip title
            const entry =
              DashboardData?.graphData?.mergedData[tooltipItem[0]?.dataIndex];
            return entry ? `${entry?.month} ${entry?.year}` : "";
          },
          label: function (context) {
            // Display only the data value in the tooltip
            return context.parsed.y.toString();
          },
        },
      },
    },
  };

  return (
    <div className="">
      <Line data={chartData} options={options} className="" />
    </div>
  );
};

export default MonthChart;
