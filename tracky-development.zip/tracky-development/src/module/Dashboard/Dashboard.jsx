import React, { useLayoutEffect, useEffect, useState } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  GetDashboardChart,
  GetDashboardProfile,
  HideSharedProfile,
  OnBoardPersonalInfo,
  setActiveTimePeriod,
  setSelectedTimePeriod,
} from "../../redux/slices/onBoabrdSlice";
import { Helmet } from "react-helmet";

import mail_send_icn from "../../assets/mail_send_icn.svg";
import Settings from "../../assets/Settings.png";

import alex_img from "../../assets/alex_img.svg";
import tick_icn from "../../assets/tick_icn.png";
import up_arrow from "../../assets/up_arrow.svg";
import graph_img from "../../assets/graph_img.svg";
import pdf_icn from "../../assets/pdf_icn.svg";
import line_graph from "../../assets/line_chart_icn.svg";
import PastClient from "../../module/Client/PastClientTable";
import UpdateTrackRecordForm from "./UpdateTrackRecordForm";
import ChartComponent from "./ChartComponent";

import MonthChart from "./MonthChart";
import Loader from "../../CommonComponent/Loader";
import {
  EmailShareButton,
  FacebookShareButton,
  LinkedinShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  RedditShareButton,
  TelegramShareButton,
} from "react-share";
import {
  EmailIcon,
  FacebookIcon,
  LinkedinIcon,
  TwitterIcon,
  WhatsappIcon,
  TelegramIcon,
  RedditIcon,
} from "react-share";
import ReactModal from "react-modal";
import DashboardSkeleton from "../../CommonComponent/skeletons/DashboardSkeleton";
import { useForm } from "react-hook-form";
import DashboardChartSkeleton from "../../CommonComponent/skeletons/DashboardChartSkeleton";

function Dashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const urlState = location.state;
  const loginData = useSelector((state) => state?.root?.auth);
  const [isFormOpen, setIsFormOpen] = useState(false);
  // const [activeTimePeriod, dispatch(setActiveTimePeriod] = useState(12);
  const [exportLoading, setExportLoading] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  const [showFormModal, setShowFormModal] = useState(false);
  const [showSettingToggleModal, setShowSettingToggleModal] = useState(false);
  let onlyChartChange = false;

  const openFormModal = () => {
    setShowFormModal(true);
  };

  const closeFormModal = () => {
    setShowFormModal(false);
  };

  // const loginDataLoadingFlag = useSelector((state) => state?.root?.auth?.loading);
  // const pastClientDataLoadingFlag = useSelector((state) => state?.root?.pastclient?.loading);
  const OnBoardPersonalInfoLoadingFlag = useSelector(
    (state) => state?.root?.onboard?.loading
  );
  const UpdateOnRecordPerloadingFlag = useSelector(
    (state) => state?.root?.onboard?.upadteRecordLoading
  );
  const Hideshareprofileloader = useSelector(
    (state) => state?.root?.onboard?.hideshareprofileloader
  );

  const DashOnlyChartChangeloadingFlag = useSelector(
    (state) => state?.root?.onboard?.DashOnlyChartChangeloading
  );

  const openModal = () => {
    setShowShareModal(true);
  };

  const closeModal = () => {
    setShowShareModal(false);
  };

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { isDirty, isValid },
  } = useForm();

  const onSubmit = (data) => {

    const role_id = DashboardData?.profileData?.role?._id;

    const user_settings = {
      profile: data.profile,
      profit: data.profit,
      track_record: data.track_record,
      earnings: data.earnings,
      past_clients: data.past_clients,
    };
    dispatch(
      HideSharedProfile(
        { user_settings: user_settings },
        auth,
        setShowSettingToggleModal
        // reset
      )
    );
  };

  const openSettingToggleModal = () => {
    setShowSettingToggleModal(true);
  };

  const selectedTimePeriod = useSelector(
    (state) => state?.root?.onboard?.selectedTimePeriod
  );
  const activeTimePeriod = useSelector(
    (state) => state?.root?.onboard?.activeTimePeriod
  );

  const openForm = () => {
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
  };
  const PersonalinfoData = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData
  );
  const DashboardData = useSelector(
    (state) => state?.root?.onboard?.getDashboardProfileData
  );

  const DashboardChartData = useSelector(
    (state) => state?.root?.onboard?.getDashboardChartData
  );

  useEffect(() => {
    setValue("profile", DashboardData?.profileData?.user_settings?.profile);
    setValue("profit", DashboardData?.profileData?.user_settings?.profit);
    setValue("earnings", DashboardData?.profileData?.user_settings?.earnings);
    setValue(
      "track_record",
      DashboardData?.profileData?.user_settings?.track_record
    );
    setValue(
      "past_clients",
      DashboardData?.profileData?.user_settings?.past_clients
    );
  }, []);

  const closeSettingToggleModal = () => {
    setShowSettingToggleModal(false);
    reset();
    setValue("profile", DashboardData?.profileData?.user_settings?.profile);
    setValue("profit", DashboardData?.profileData?.user_settings?.profit);
    setValue("earnings", DashboardData?.profileData?.user_settings?.earnings);
    setValue(
      "track_record",
      DashboardData?.profileData?.user_settings?.track_record
    );
    setValue(
      "past_clients",
      DashboardData?.profileData?.user_settings?.past_clients
    );
  };

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const onBoardFlag =
    PersonalinfoData?.profileData?.on_board === true ||
    loginData?.data?.user?.on_board === true ||
    loginData?.googleData?.user?.on_board === true ||
    loginData?.VerifyData?.user?.on_board === true ||
    loginData?.signupResData?.on_board === true ||
    loginData?.googleInData?.user?.on_board === true ||
    loginData?.appleData?.user?.on_board === true;

  useEffect(() => {
    dispatch(OnBoardPersonalInfo(auth));
    dispatch(GetDashboardProfile(auth));
    dispatch(GetDashboardChart(auth, selectedTimePeriod, onlyChartChange));
  }, []);

  const handleTimePeriodChange = (timePeriod) => {
    onlyChartChange = true;
    dispatch(setSelectedTimePeriod(timePeriod));
    dispatch(GetDashboardChart(auth, timePeriod, onlyChartChange));
    dispatch(setActiveTimePeriod(timePeriod));
  };

  useEffect(() => {
    !onBoardFlag && navigate("/onboard");
  }, []);

  const formatTimeZone = (timeZone) => {
    const [offset, location] = timeZone?.split(" - ");

    const [hours, minutes] = offset?.split(":");

    const gmtOffset = parseInt(hours, 10);

    return `${location} (GMT${gmtOffset >= 0 ? "+" : ""}${gmtOffset})`;
  };
  useEffect(() => {
    // Load jQuery from CDN
    const jqueryScript = document.createElement("script");
    jqueryScript.src = "https://code.jquery.com/jquery-3.6.4.min.js";
    jqueryScript.async = true;
    jqueryScript.onload = () => {
      // Load Kendo UI from CDN
      const kendoScript = document.createElement("script");
      kendoScript.src =
        "https://kendo.cdn.telerik.com/2022.1.301/js/kendo.all.min.js"; // Replace with the appropriate version
      kendoScript.async = true;
      // kendoScript.onload = downloadFullDashboard;
      document.body.appendChild(kendoScript);
    };
    document.body.appendChild(jqueryScript);
  }, []);

  const downloadFullDashboard = () => {
    setExportLoading(true);

    const elementsToHide = document.querySelectorAll(".hideMe");
    elementsToHide.forEach((element) => {
      element.style.display = "none";
    });
    // Ensure jQuery is loaded before using it
    if (window.$) {
      // Convert the DOM element to a drawing using kendo.drawing.drawDOM
      window.$("#downloadDashboard");
      window.kendo.drawing
        .drawDOM(window.$(".pdf-download-wrapper"))
        .then(function (group) {
          // Render the result as a PDF file
          return window.kendo.drawing.exportPDF(group, {
            paperSize: "auto",
            margin: {
              left: "1cm",
              top: "1cm",
              right: "1cm",
              bottom: "1cm",
            },
          });
        })
        .done(function (data) {
          // Save the PDF file
          window.kendo.saveAs({
            dataURI: data,
            fileName: "Profile.pdf",
            proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
          });
          window.$("#downloadDashboard");
          setExportLoading(false); // Set loading state to false after export

          elementsToHide.forEach((element) => {
            element.style.removeProperty("display");
          });
        });
    } else {
      console.error("jQuery is not loaded.");
      setExportLoading(false); // Set loading state to false if jQuery is not loaded
      elementsToHide.forEach((element) => {
        element.style.removeProperty("display");
      });
    }
  };

  const downloadGraph = () => {
    // Ensure jQuery is loaded before using it
    setExportLoading(true); // Set loading state to false after export
    const elementsToHide = document.querySelectorAll(".hideMe2");
    elementsToHide.forEach((element) => {
      element.style.display = "none";
    });

    if (window.$) {
      // Convert the DOM element to a drawing using kendo.drawing.drawDOM
      window.kendo.drawing
        .drawDOM(window.$(".chart-pdf"))
        .then(function (group) {
          // Render the result as a PDF file
          return window.kendo.drawing.exportPDF(group, {
            paperSize: "auto",
            margin: {
              left: "1cm",
              top: "1cm",
              right: "1cm",
              bottom: "1cm",
            },
          });
        })
        .done(function (data) {
          // Save the PDF file
          window.kendo.saveAs({
            dataURI: data,
            fileName: "chart.pdf",
            proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
          });
          setExportLoading(false); // Set loading state to false after export
          elementsToHide.forEach((element) => {
            element.style.removeProperty("display");
          });
        });
    } else {
      console.error("jQuery is not loaded.");
      setExportLoading(false); // Set loading state to false after export
      elementsToHide.forEach((element) => {
        element.style.removeProperty("display");
      });
    }
  };

  const sharedProfile = (id) => {
    navigate(`/profile/${id}`);
  };

  let urlToShareIS = `${process.env.REACT_APP_FRONTEND_BASE_URL}profile?id=${DashboardData?.profileData?._id}`;
  let social_share_message = "Here is my Tracky Profile";

  return (
    <>
      <Helmet>
        <title>Tracky | Profile</title>
        <meta name="description" content="Tracky | Profile" />
      </Helmet>

      {/* <main class="pt-20 md:pl-80"> */}
      <div className="FirstDiv pdf-download-wrapper">
        <div
          className="dark-bg  md:content  text-[#ffffff] "
          id="downloadDashboard"
        >
          {OnBoardPersonalInfoLoadingFlag ? (
            <DashboardSkeleton />
          ) : (
            <>
              <div className="grid content-center w-full grid-flow-row p-4 mx-auto md:pb-6 auto-rows-max ">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex items-start content-start md:items-start md:h-[45px]">
                  <div className="">
                    <p
                      className="text-[20px] md:text-[30px] text-left break-word md:break-normal
             font-bold "
                    >
                      Profile
                    </p>
                  </div>
                  <div
                    className={` flex flex-row justify-between md:justify-end content-center items-center  mb-4 md:md-0 hideMe ${
                      exportLoading ? "hidden" : ""
                    }`}
                  >
                    <button
                      onClick={openSettingToggleModal}
                      className="me-4 hover:ring hover:ring-[#2EDE9F] hover:rounded-full "
                    >
                      <img
                        src={Settings}
                        alt="maiil icon"
                        // className="m-3 "
                      />
                    </button>
                    <div
                      className="flex justify-center items-center content-center border-2 border-transparent cursor-pointer hover:border-2 hover:border-[#21CE90] py-1 px-2 hover:rounded-[10px]
                        hover:bg-[#21CE90]
                          "
                      // onClick={() =>
                      //   sharedProfile(DashboardData?.profileData?._id)
                      // }
                      onClick={openModal}
                    >
                      <img
                        src={mail_send_icn}
                        alt="maiil icon"
                        className="me-3  w-[40%]"
                      />
                      <span className="text-[16px] font-medium ">Share</span>
                    </div>
                    <button
                      className="md:ms-6 mt-4 md:mt-0 bg-white rounded-[10px] text-[#18181B]
                  py-2 px-4
                  text-[16px] font-medium hover:bg-[#21CE90] hover:text-[#fff]"
                      onClick={downloadFullDashboard}
                    >
                      Download PDF
                    </button>
                  </div>
                </div>
                {/*Card for Alex B.*/}
                <div
                  className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              pt-6 px-[20px] md:mt-2 w-auto md:w-full mx-auto"
                >
                  <div className="flex flex-col content-start justify-start md:flex-row md:items-start md:content-start">
                    <div className="w-auto md:w-3/5">
                      {/*profile text*/}
                      <div className="flex flex-col items-start content-start justify-start md:flex-row">
                        <div
                          className="rounded-full w-[70px] h-[70px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
                        >
                          <img
                            className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content"
                            src={
                              `${process.env.REACT_APP_IO}/${DashboardData?.profileData?.profile_image}` ||
                              alex_img
                            }
                            alt="user"
                            onError={({ currentTarget }) => {
                              currentTarget.onerror = null; // prevents looping
                              currentTarget.src = alex_img;
                            }}
                          />
                        </div>
                        <div className="">
                          <div className="flex content-center justify-start">
                            <p className="text-[37px] font-semibold md:ms-4">
                              {DashboardData?.profileData?.first_name &&
                                DashboardData?.profileData?.last_name &&
                                DashboardData?.profileData?.last_name !==
                                  undefined &&
                                DashboardData?.profileData?.first_name !==
                                  undefined && (
                                  <>
                                    {DashboardData?.profileData?.first_name
                                      .charAt(0)
                                      .toUpperCase() +
                                      DashboardData?.profileData?.first_name.slice(
                                        1
                                      )}{" "}
                                    {DashboardData?.profileData?.last_name
                                      .charAt(0)
                                      .toUpperCase() +
                                      DashboardData?.profileData?.last_name.slice(
                                        1
                                      )}
                                  </>
                                )}
                            </p>
                            <img
                              src={tick_icn}
                              className="ms-2  top-[0px] w-[20px] h-[20px] "
                              alt="tick icon"
                            />
                          </div>
                          <p className="text-[11px] font-semibold md:ms-4">
                            {DashboardData?.profileData?.role?.key
                              ?.charAt(0)
                              ?.toUpperCase() +
                              DashboardData?.profileData?.role?.key
                                ?.slice(1)
                                ?.toLowerCase()}{" "}
                            {DashboardData?.profileData?.time_zone &&
                              formatTimeZone(
                                DashboardData?.profileData?.time_zone
                              )}
                          </p>
                        </div>
                      </div>
                      <p className="text-[18px] font-normal my-4 break-all">
                        {DashboardData?.profileData?.bio}
                      </p>
                      <button
                        className="rounded-[10px] border border-[#2EDE9F] text-[11px]
                           text-[#ffffff] bg-[#565657] py-2 px-6 hover:bg-[#2EDE9F] hover:text-[#fff] "
                        onClick={openFormModal}
                      >
                        Update Track Record
                      </button>
                      {showFormModal && (
                        <>
                          <ReactModal
                            isOpen={showFormModal}
                            onRequestClose={closeFormModal}
                            style={{
                              content: {
                                maxWidth: "650px",
                                height: "320px",
                                margin: "auto",
                                backgroundColor: "#272727",
                                borderColor: "#5C5C5C",
                                color: "#ffffff",
                                borderRadius: "15px",
                                padding: "20px",
                              },
                              overlay: {
                                backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
                              },
                            }}
                          >
                            <UpdateTrackRecordForm
                              onClose={closeFormModal}
                              activeTimePeriod={activeTimePeriod}
                              PersonalinfoData={PersonalinfoData}
                              UpdateOnRecordPerloadingFlag={
                                UpdateOnRecordPerloadingFlag
                              }
                            />
                          </ReactModal>
                        </>
                      )}
                    </div>
                    <div
                      className="w-[85%] md:w-2/5 mt-4 ms-4 md:ms-6 md:mt-0 bg-[#202122]
                   shadow-md shadow-slate-800 rounded-t-[25px]  p-6  "
                    >
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div className="">
                          <p className="text-[15px] font-medium">
                            TOTAL PROFITS{" "}
                            {DashboardData?.graphData?.currentsYears}
                          </p>
                          <p className="text-[30px] font-bold break-all">
                            €
                            {DashboardData?.graphData?.yearProfit
                              ? DashboardData?.graphData?.yearProfit
                              : 0}
                          </p>
                        </div>
                        <div className="flex items-start content-end justify-start">
                          <img src={up_arrow} alt="up arrow" />
                          <span className="ms-4 text-[22px] text-[#14A867] font-semibold break-all">
                            {DashboardData?.graphData?.totalDealSizeLastMonth
                              ? DashboardData?.graphData?.totalDealSizeLastMonth
                              : 0}
                            %
                          </span>
                        </div>
                      </div>

                      <div className="">
                        {DashboardData?.graphData?.mergedData?.length != 0 ? (
                          <MonthChart DashboardData={DashboardData} />
                        ) : (
                          <img
                            src={graph_img}
                            alt="graph image"
                            className="w-[250px] md:w-[380px] h-[230px]"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                {/*Card for track record.*/}
                <p className="mb-2 text-[20px] font-semibold mt-6 md:mt-4 ">
                  Track Record
                </p>
                <div className="flex flex-col content-start justify-start md:flex-row md:items-center">
                  <div className="w-auto md:w-[64%] chart-pdf">
                    <div
                      className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px]  w-[100%] md:w-auto mx-auto md:h-[350px]"
                    >
                      <div className="flex flex-col items-start justify-start md:flex-row md:items-center md:justify-center">
                        <div className="md:flex-none w-14 ">
                          <span className="text-[16px] font-bold">
                            {DashboardChartData?.currentsYears}{" "}
                          </span>
                        </div>
                        <div className="md:flex-1  flex-col md:flex-row flex w-[300px] md:w-64  mt-4 md:mt-0">
                          <div className="flex flex-wrap items-start md:justify-center track_record w-[100%]">
                            <button
                              className={`bg-white text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ${
                                activeTimePeriod === 12 ? "active" : ""
                              }`}
                              onClick={() => handleTimePeriodChange(12)}
                            >
                              12 Months
                            </button>
                            <button
                              className={`bg-white text-[11px] w-[45%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4
                                hover:bg-[#2ede9f] hover:text-white
                                  ${activeTimePeriod === 6 ? "active" : ""}`}
                              onClick={() => handleTimePeriodChange(6)}
                            >
                              6 Months
                            </button>
                            <button
                              className={`bg-white text-[11px] w-[45%] md:w-auto mt-4 md:mt-0 font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white ${
                                activeTimePeriod === 30 ? "active" : ""
                              }`}
                              onClick={() => handleTimePeriodChange(30)}
                            >
                              30 Days
                            </button>
                            <button
                              className={`bg-white text-[11px] w-[45%] md:w-auto mt-4 md:mt-0 font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white ${
                                activeTimePeriod === 7 ? "active" : ""
                              }`}
                              onClick={() => handleTimePeriodChange(7)}
                            >
                              7 Days
                            </button>
                          </div>
                        </div>
                        <div
                          onClick={downloadGraph}
                          className={`flex-none w-[45%] md:w-36 text-[16px] font-bold mt-4 md:mt-0 `}
                        >
                          <button
                            className={`bg-white w-full flex items-center justify-center
                               text-[11px] font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white hideMe hideMe2 ${
                                 exportLoading ? "hidden" : ""
                               }`}
                            disabled={exportLoading}
                          >
                            {exportLoading ? (
                              <Loader />
                            ) : (
                              <>
                                <img
                                  src={pdf_icn}
                                  className="me-2"
                                  alt="pdf icon"
                                />
                                Export PDF
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                      <div className="mt-2 ">
                        {DashOnlyChartChangeloadingFlag ? (
                          <>
                            <DashboardChartSkeleton />
                          </>
                        ) : (
                          <>
                            {DashboardChartData?.length != 0 ? (
                              <ChartComponent
                                DashboardChartData={DashboardChartData}
                              />
                            ) : (
                              <img src={line_graph} alt="line graph" />
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="w-auto md:w-[35%] ms-0 md:ms-6 mt-4 md:mt-0">
                    <div
                      className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px] md:h-[350px] w-[100%] md:w-full mx-auto"
                    >
                      <div className="grid grid-flow-row auto-rows-max ">
                        <div className="text-center">
                          <span className="text-[11px] text-[#868C96]">
                            Lifetime earnings
                          </span>
                          <p className="text-[25px] font-medium break-all">
                            €{" "}
                            {parseFloat(
                              DashboardData?.sumData?.average_deal_size
                                ? DashboardData?.sumData?.average_deal_size.toFixed(
                                    2
                                  )
                                : 0
                            )}
                          </p>
                        </div>
                        <hr className="my-2 border-slate-500" />
                        <div className="grid grid-cols-1 md:grid-cols-2 md:gap-4 md:divide-x md:divide-slate-500 ">
                          {DashboardData?.profileData?.role?.key ===
                            "closer" && (
                            <div className="text-center md:life">
                              <span className="text-[11px] text-[#868C96]">
                                Lifetime calls
                              </span>
                              <p className="text-[25px] font-medium break-all">
                                {DashboardData?.sumData?.total_calls
                                  ? DashboardData?.sumData?.total_calls
                                  : 0}
                              </p>
                            </div>
                          )}
                          {DashboardData?.profileData?.role?.key ===
                            "setter" && (
                            <div className="text-center life">
                              <span className="text-[11px] text-[#868C96]">
                                Lifetime chats
                              </span>
                              <p className="text-[25px] font-medium break-all">
                                {DashboardData?.sumData?.total_chat
                                  ? DashboardData?.sumData?.total_chat
                                  : 0}
                              </p>
                            </div>
                          )}

                          <div className="text-center life">
                            <span className="text-[11px] text-[#868C96]">
                              Avg. deal size
                            </span>
                            <p className="text-[25px] font-medium break-all">
                              {DashboardData?.profileData?.average_deal_size
                                ? DashboardData?.profileData?.average_deal_size
                                : 0}
                            </p>
                          </div>
                        </div>
                        <div className="text-center">
                          <span className="text-[11px] text-[#868C96]">
                            Lifetime closes
                          </span>
                          <p className="text-[25px] text-[#2EDE9F] font-medium break-all">
                            {DashboardData?.sumData?.total_closed
                              ? DashboardData?.sumData?.total_closed
                              : 0}
                          </p>
                        </div>
                        <div className="text-center">
                          <span className="text-[11px] text-[#868C96]">
                            {DashboardData?.profileData?.role?.key ===
                            "setter" ? (
                              <>Lifetime lost opportunities</>
                            ) : (
                              <> Lifetime lost calls</>
                            )}
                          </span>
                          <p className="text-[25px] text-[#EC2A2A] font-medium break-all">
                            {DashboardData?.sumData?.total_lost
                              ? DashboardData?.sumData?.total_lost
                              : 0}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="w-auto my-6 overflow-x-auto md:w-full ">
                  <PastClient exportLoading={exportLoading} />
                </div>
              </div>
            </>
          )}
        </div>

        <ReactModal
          isOpen={showShareModal}
          onRequestClose={closeModal}
          style={{
            content: {
              maxWidth: "410px",
              height: "250px",
              margin: "auto",
              backgroundColor: "#373839",
              color: "#ffffff",
              borderRadius: "15px"
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
            }
          }}
        >
          <div className="flex flex-row justify-between">
            <p className="text-[25px] font-semibold">
              Share your referral link
            </p>
            <button className="" onClick={closeModal}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18 18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
          <hr />
          <div className="pt-3">
            <EmailShareButton
              url={`${urlToShareIS}`}
              subject={`Tracky Profile`}
              body={`Here is my Tracky Profile`}
            >
              <EmailIcon size={62} round={true} />
            </EmailShareButton>
            &nbsp;&nbsp;
            <FacebookShareButton
              url={`${urlToShareIS}`}
              quote={social_share_message}
            >
              <FacebookIcon size={62} round={true} />
            </FacebookShareButton>
            &nbsp;&nbsp;
            <TwitterShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <TwitterIcon size={62} round={true} />
            </TwitterShareButton>
            &nbsp;&nbsp;
            <LinkedinShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
              summary={social_share_message}
            >
              <LinkedinIcon size={62} round={true} />
            </LinkedinShareButton>
            &nbsp;&nbsp;
            <WhatsappShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <WhatsappIcon size={62} round={true} />
            </WhatsappShareButton>
          </div>
          <div className="pt-3">
            <TelegramShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <TelegramIcon size={62} round={true} />
            </TelegramShareButton>
            &nbsp;&nbsp;
            <RedditShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <RedditIcon size={62} round={true} />
            </RedditShareButton>
            &nbsp;&nbsp;
          </div>
        </ReactModal>

        <ReactModal
          isOpen={showSettingToggleModal}
          // onRequestClose={closeSettingToggleModal}
          style={{
            content: {
              maxWidth: "427px",
              height: "413px",
              margin: "auto",
              backgroundColor: "#373839",
              color: "#ffffff",
              borderRadius: "15px",
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
            },
          }}
        >
          <div className="flex flex-row items-center content-center justify-between mb-4">
            <div>
              <p className="text-[20px] font-medium ">Settings</p>
            </div>
            <button className="" onClick={closeSettingToggleModal}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6 hover:stroke-[#2EDE9F]"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18 18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
          <hr />
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="my-2">
              <p className="">
                Please switch on the option to hide the section in the shared
                profile .
              </p>
              <ul
                // className="mt-2 list-none divide-y // divide-slate-200"
                className="mt-5 list-none divide-slate-200"
              >
                <li className="flex py-2 first:pt-0 last:pb-0">
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      // value="profile"
                      {...register("profile")}
                      class="sr-only peer"
                    />
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    <span class="ms-3 ">Profile Details</span>
                  </label>
                </li>
                <li className="flex py-2 first:pt-0 last:pb-0">
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      // value="profit"
                      {...register("profit")}
                      class="sr-only peer"
                    />
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    <span class="ms-3 ">Profit Details</span>
                  </label>
                </li>
                <li className="flex py-2 first:pt-0 last:pb-0">
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      // value="trackrecord"
                      {...register("track_record")}
                      class="sr-only peer"
                    />
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    <span class="ms-3 ">Track record Details</span>
                  </label>
                </li>
                <li className="flex py-2 first:pt-0 last:pb-0">
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      // value="earning"
                      {...register("earnings")}
                      class="sr-only peer"
                    />
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    <span class="ms-3 ">Earning Details</span>
                  </label>
                </li>
                <li className="flex py-2 first:pt-0 last:pb-0">
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      // value="pastclients"
                      {...register("past_clients")}
                      class="sr-only peer"
                    />
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    <span class="ms-3 ">Past Clients Details</span>
                  </label>
                </li>
              </ul>
              <div className="flex justify-end gap-2 mt-5">
                <button
                  className="rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium
                               py-[5px] px-[10px] w-[10%] hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-0 grow"
                  type="button"
                  onClick={closeSettingToggleModal}
                >
                  Cancel
                </button>
                <button
                  className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[5px] px-[10px] w-[10%] hover:bg-[#ffffff] hover:text-[#000000] grow
                "
                  type="submit"
                  disabled={Hideshareprofileloader}
                >
                  {Hideshareprofileloader ? (
                    <>
                      <div className="flex items-center content-center justify-center w-full ">
                        <Loader />
                      </div>
                    </>
                  ) : (
                    <> Save</>
                  )}
                </button>
              </div>
            </div>
          </form>
        </ReactModal>
      </div>

      {/* </main> */}
    </>
  );
}

export default Dashboard;
