// ChartComponent.js
import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import axios from "axios";
import Chart from "chart.js/auto"; // Import Chart.js library
import { useDispatch, useSelector } from "react-redux";
import { GetDashboardChart } from "../../redux/slices/onBoabrdSlice";

const SharedChartComponent = ({ DashboardChartData }) => {
  const DashboardData = useSelector(
    (state) => state?.root?.onboard?.getDashboardProfileData
  );
  const SharedProfileData = useSelector(
    (state) => state?.root?.sharedprofile?.sharedprofileData
  );

  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      {
        label: "Lifetime closes",
        data: [],
        fill: false,
        borderColor: "#2EDE9F",
        tension: 0.4,
      },
      {
        label: "Lifetime lost calls",
        data: [],
        fill: false,
        borderColor: "#FF0707",
        tension: 0.4,
      },
    ],
  });

  useEffect(() => {
    setChartData({
      labels: DashboardChartData?.mergedData?.map((entry) =>
        entry.day
          ? entry?.day?.toString() + " " + entry?.month?.toString()
          : entry?.month?.toString()
      ),
      datasets: [
        {
          label: "Lifetime closes",
          data: DashboardChartData?.mergedData?.map(
            (entry) => entry?.totalClose
          ),
          fill: true,
          borderColor: "#2EDE9F",
          tension: 0.4,
          cubicInterpolationMode: "monotone",
          backgroundColor: "rgba(46, 222, 159, 0.12)",
        },
        {
          label:
            SharedProfileData?.profileData?.profileData?.role?.key === "closer"
              ? "Lifetime lost calls"
              : "Lifetime lost opportunities",
          data: DashboardChartData?.mergedData?.map(
            (entry) => entry?.totalCalls
          ),
          fill: true,
          borderColor: "#FF0707",
          tension: 0.4,
          cubicInterpolationMode: "monotone",
          backgroundColor: "rgba(255, 7, 7, 0.12)",
        },
      ],
    });
  }, [DashboardChartData]);

  const options = {
    maintainAspectRatio: false,
    scales: {
      x: {
        type: "category",
        labels: chartData.labels,
      },
      y: {
        display: true, // Hide the left side y-axis
      },
    },
    elements: {
      line: {
        tension: 0.5, // Increase the tension for more curve
      },
      responsive: true,
      maintainAspectRatio: false,
    },
    plugins: {
      legend: {
        display: true,
        labels: {
          usePointStyle: true,
          pointStyle: "rect",
        },
      },
      tooltip: {
        callbacks: {
          title: function (tooltipItem) {
            // Display the year and month in the tooltip title
            const entry =
              DashboardChartData?.mergedData[tooltipItem[0]?.dataIndex];
            return entry ? `${entry?.month} ${entry?.year}` : "";
          },
          label: function (context) {
            // Display only the data value in the tooltip
            return context.parsed.y.toString();
          },
        },
      },
    },
  };

  return (
    <div className="">
      <Line data={chartData} options={options} width={"30%"} height={"270px"} />
    </div>
  );
};

export default SharedChartComponent;
