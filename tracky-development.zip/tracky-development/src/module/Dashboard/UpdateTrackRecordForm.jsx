import React, { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { handleKeyDown } from "../../utils/SpaceValidation";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import * as Yup from "yup";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  GetDashboardTrack,
  UpdateDashboardPersonalInfo,
  resetgetTrackData,
} from "../../redux/slices/onBoabrdSlice";
import { getValue } from "@testing-library/user-event/dist/utils";
import Loader from "../../CommonComponent/Loader";

const generateValidationSchema = (role) => {
  let schema = {
    // average_deal_size: Yup.number()
    //   .required(
    //     "Enter average deal size"
    //   )
    //   .typeError("Enter a valid number")
    //   .min(
    //     0,
    //     "Value must be 0 or greater than 0 "
    //   )

    //   .test(
    //     "max-characters",
    //     "Value must be at most 8 digits",
    //     (value) =>
    //       value.toString().length <= 8
    //   ),
    average_deal_size: Yup.string()
      .required("Enter a valid number")

      .test(
        "max-characters",
        "Value must be at most 6 digits",
        (value) => value.replace(/^0+/, "").length <= 6
      )
      .matches(/^(0(\.\d+)?|[1-9]\d*(\.\d+)?)$/, "Enter a valid number"),
    total_closed: Yup.number()
      .required("Enter total closed")
      .typeError("Eenter a valid number")
      .min(0, "Total closed must be 0 or greater than 0 ")
      .test("is-integer", "Total closed must be an integer", (value) =>
        Number.isInteger(value)
      )
      .test(
        "max-characters",
        "Total closed must be at most 5 digits",
        (value) => value.toString().length <= 5
      ),
    total_lost: Yup.number()
      .required("Enter total lost")
      .typeError("Enter a valid number")
      .min(0, "Total lost must be 0 or greater than 0 ")
      .test("is-integer", "Total lost must be an integer", (value) =>
        Number.isInteger(value)
      )
      .test(
        "max-characters",
        "Total lost must be at most 5 digits",
        (value) => value.toString().length <= 5
      ),
  };

  if (role === "closer") {
    schema = {
      ...schema,
      total_calls: Yup.number()
        .required("Enter total calls")
        .typeError("Enter a valid number")
        .min(0, "Total calls must be 0 or greater than 0 ")
        .test("is-integer", "Total calls must be an integer", (value) =>
          Number.isInteger(value)
        )
        .test(
          "max-characters",
          "Total calls must be at most 5 digits",
          (value) => value.toString().length <= 5
        ),
    };
  }

  if (role === "setter") {
    schema = {
      ...schema,
      total_chat: Yup.number()
        .required("Enter total chats")
        .typeError("Enter a valid number")
        .min(0, "Total chats must be 0 or greater than 0 ")
        .test("is-integer", "Total chats must be an integer", (value) =>
          Number.isInteger(value)
        )
        .test(
          "max-characters",
          "Total chats must be at most 5 digits",
          (value) => value.toString().length <= 5
        ),
    };
  }

  return Yup.object().shape(schema);
};

const UpdateTrackRecordForm = ({
  activeTimePeriod,
  PersonalinfoData,
  onClose,
  UpdateOnRecordPerloadingFlag,
}) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const dispatch = useDispatch();

  const GetTrackData = useSelector(
    (state) => state?.root?.onboard?.getDashboardTrackData
  );

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  const currentDate = new Date();
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(currentDate.getDate() - 7);

  const loginData = useSelector((state) => state?.root?.auth);
  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const validationSchema = generateValidationSchema(
    PersonalinfoData?.profileData?.role?.key
  );

  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
    clearErrors,
    reset,
    getValues,
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });

  useEffect(() => {
    const formattedDate = selectedDate.toISOString();
    dispatch(GetDashboardTrack(formattedDate, auth));
  }, [selectedDate, auth]);

  useEffect(() => {
    reset({
      average_deal_size:
        GetTrackData?.average_deal_size !== undefined
          ? GetTrackData.average_deal_size
          : "",
      total_chat:
        GetTrackData?.total_chat !== undefined ? GetTrackData.total_chat : "",
      total_calls:
        GetTrackData?.total_calls !== undefined ? GetTrackData.total_calls : "",
      total_closed:
        GetTrackData?.total_closed !== undefined
          ? GetTrackData.total_closed
          : "",
      total_lost:
        GetTrackData?.total_lost !== undefined ? GetTrackData.total_lost : "",
    });
  }, [GetTrackData, reset]);

  const onSubmit = async (data) => {
    const formData = {
      ...data,
      date: selectedDate.toISOString(),
    };
    await dispatch(
      UpdateDashboardPersonalInfo(formData, auth, onClose, activeTimePeriod)
    );
  };
  return (
    <div className="py-4 update_popup">
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Form content */}
        {/* <button onClick={onClose}>Close</button> */}
        <div className="flex flex-col items-start md:flex-row md:justify-between">
          <div className="w-full">
            <DatePicker
              className="date_picker"
              selected={selectedDate}
              onChange={handleDateChange}
              dateFormat="MM/dd/yyyy"
              maxDate={currentDate} // Prevent selecting future dates
              minDate={oneWeekAgo}
              inline
            />
          </div>

          <div className="w-full">
            <div className="flex flex-col mb-4 md:flex-row md:justify-between md:items-center">
              <label className="text-[12px] font-normal text-left ">
                Avg deal size
              </label>
              <input
                type="text"
                name="average_deal_size"
                className="w-[100%] md:w-[40%] mt-2 md:mt-0 md:ms-6 border border-[#BFBFBF] rounded-[8px] bg-transparent
                 text-[#ffffff] text-[14px] py-1"
                {...register("average_deal_size")}
                autoComplete="off"
                // onKeyPress={handleKeyDown}
                onKeyPress={(e) => {
                  const charCode = e.which ? e.which : e.keyCode;
                  if (
                    (charCode > 31 &&
                      (charCode < 48 || charCode > 57) &&
                      charCode !== 46) ||
                    (charCode === 46 && e.target.value.includes("."))
                  ) {
                    e.preventDefault();
                  }
                }}
              />
            </div>
            <div className="flex justify-end w-full">
              <ErrorMessage
                errors={errors}
                name="average_deal_size"
                render={({ message }) => (
                  <p
                    className="relative top-[-14px] text-[11px] text-[red] text-right flex justify-end
                    content-start w-[200px] text-wrap"
                  >
                    {message}
                  </p>
                )}
              />
            </div>

            {PersonalinfoData?.profileData?.role?.key === "closer" && (
              <>
                <div className="flex flex-col mb-4 md:flex-row md:justify-between md:items-center">
                  <label className="text-[12px] font-normal text-left">
                    Total calls
                  </label>
                  <input
                    type="text"
                    name="total_calls"
                    className=" w-[100%] md:w-[40%] mt-2 md:mt-0 md:ms-6 border border-[#BFBFBF] rounded-[8px] bg-transparent
                 text-[#ffffff] text-[14px] py-1"
                    {...register("total_calls")}
                    autoComplete="off"
                    // placeholder="Type here..."
                    onKeyPress={(e) => {
                      const charCode = e.which ? e.which : e.keyCode;
                      if (
                        (charCode > 31 &&
                          (charCode < 48 || charCode > 57) &&
                          charCode !== 46) ||
                        (charCode === 46 && e.target.value.includes("."))
                      ) {
                        e.preventDefault();
                      }
                    }}
                  />
                </div>
                <div className="flex justify-end w-full">
                  <ErrorMessage
                    errors={errors}
                    name="total_calls"
                    render={({ message }) => (
                      <p
                        className="relative top-[-14px] text-[11px] text-[red] text-right flex justify-end
                    content-start w-[200px] text-wrap"
                      >
                        {message}
                      </p>
                    )}
                  />
                </div>
              </>
            )}

            {PersonalinfoData?.profileData?.role?.key === "setter" && (
              <>
                {" "}
                <div className="flex flex-col mb-4 md:flex-row md:justify-between md:items-center">
                  <label className="text-[12px] font-normal text-left">
                    Total conversations
                  </label>
                  <input
                    type="text"
                    name="total_chat"
                    className=" w-[100%] md:w-[40%] mt-2 md:mt-0 md:ms-6 border border-[#BFBFBF] rounded-[8px] bg-transparent
                 text-[#ffffff] text-[14px] py-1"
                    {...register("total_chat")}
                    autoComplete="off"
                    // placeholder="Type here..."
                    onKeyPress={(e) => {
                      const charCode = e.which ? e.which : e.keyCode;
                      if (
                        (charCode > 31 &&
                          (charCode < 48 || charCode > 57) &&
                          charCode !== 46) ||
                        (charCode === 46 && e.target.value.includes("."))
                      ) {
                        e.preventDefault();
                      }
                    }}
                  />
                </div>
                <div className="flex justify-end w-full">
                  <ErrorMessage
                    errors={errors}
                    name="total_chat"
                    render={({ message }) => (
                      <p
                        className="relative top-[-14px] text-[11px] text-[red] text-right flex justify-end
                    content-start w-[100%] text-wrap"
                      >
                        {message}
                      </p>
                    )}
                  />
                </div>
              </>
            )}

            <div className="flex flex-col mb-4 md:flex-row md:justify-between md:items-center">
              <label className="text-[12px] font-normal text-left">
                Total closed
              </label>
              <input
                type="text"
                name="total_closed"
                className=" w-[100%] md:w-[40%] mt-2 md:mt-0 md:ms-6 border border-[#BFBFBF] rounded-[8px] bg-transparent
                 text-[#ffffff] text-[14px] py-1"
                {...register("total_closed")}
                autoComplete="off"
                // placeholder="Type here..."
                onKeyPress={(e) => {
                  const charCode = e.which ? e.which : e.keyCode;
                  if (
                    (charCode > 31 &&
                      (charCode < 48 || charCode > 57) &&
                      charCode !== 46) ||
                    (charCode === 46 && e.target.value.includes("."))
                  ) {
                    e.preventDefault();
                  }
                }}
              />
            </div>
            <div className="flex justify-end w-full">
              <ErrorMessage
                errors={errors}
                name="total_closed"
                render={({ message }) => (
                  <p
                    className="relative top-[-14px] text-[11px] text-[red] text-right flex justify-end
                    content-start w-[100%] text-wrap"
                  >
                    {message}
                  </p>
                )}
              />
            </div>
            <div className="flex flex-col mb-4 md:flex-row md:justify-between md:items-center">
              <label className="text-[12px] font-normal text-left">
                Total lost
              </label>
              <input
                type="text"
                name="total_lost"
                className=" w-[100%] md:w-[40%] mt-2 md:mt-0 md:ms-6 border border-[#BFBFBF] rounded-[8px] bg-transparent
                 text-[#ffffff] text-[14px] py-1"
                {...register("total_lost")}
                autoComplete="off"
                // placeholder="Type here..."
                onKeyPress={(e) => {
                  const charCode = e.which ? e.which : e.keyCode;
                  if (
                    (charCode > 31 &&
                      (charCode < 48 || charCode > 57) &&
                      charCode !== 46) ||
                    (charCode === 46 && e.target.value.includes("."))
                  ) {
                    e.preventDefault();
                  }
                }}
              />
            </div>
            <div className="flex justify-end w-full">
              <ErrorMessage
                errors={errors}
                name="total_lost"
                render={({ message }) => (
                  <p
                    className="relative top-[-14px] text-[11px] text-[red] text-right flex justify-end
                    content-start w-[100%] text-wrap"
                  >
                    {message}
                  </p>
                )}
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                className="rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium
                               py-[5px] px-[10px] w-[20%] hover:bg-[#ffffff] hover:text-[#000000] md:me-4 md:mb-0 grow"
                type="button"
                onClick={onClose}
              >
                Cancel
              </button>
              <button
                className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[5px] px-[10px] w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow
                "
                type="submit"
                disabled={UpdateOnRecordPerloadingFlag}
              >
                {UpdateOnRecordPerloadingFlag ? (
                  <>
                    <div
                      className="flex items-center content-center justify-center w-full "
                    >
                      <Loader />
                    </div>
                  </>
                ) : (
                  <> Update record</>
                )}
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default UpdateTrackRecordForm;
