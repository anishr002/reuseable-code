import React, { useEffect, useState } from "react";
import {
  Table,
  TableContainer,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Input,
  Pagination,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import {
  DeletePastClient,
  GetPastClient,
  resetsinglepastclient,
} from "../../redux/slices/pastClientSlice";
import { FaEdit, FaTrash } from "react-icons/fa";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import Swal from "sweetalert2";
import { useNavigate } from "react-router";
import { Link } from "react-router-dom";
import Loader from "../../CommonComponent/Loader";
import alex_img from "../../assets/alex_img.svg";

const PastClientTable = ({ exportLoading }) => {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [itemsPerPage, setitemsPerPage] = useState(3);
  const [searchValue, setSearch] = useState("");
  const [sortField, setSortField] = useState("updatedAt");
  const [sortOrder, setSortOrder] = useState("desc");
  // const [iserror, setError] = useState({
  //   src: props.src,
  //   errored: false,
  // });

  const search = useDebouncedValue(searchValue, 500);

  const loginData = useSelector((state) => state?.root?.auth);
  const PastClientData = useSelector(
    (state) => state?.root?.pastclient?.getpastclientData
  );
  const isLoading = useSelector((state) => state?.root?.pastclient?.loading);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const dispatch = useDispatch();

  const pageCount = Math.ceil(PastClientData?.length / itemsPerPage);

  const handleChangePage = (_, newPage) => {
    setPage(newPage);
  };
  const payload = {
    search,
    sortField,
    sortOrder,
    itemsPerPage,
    page,
  };
  useEffect(() => {
    dispatch(GetPastClient(payload, auth));
  }, [dispatch, search, page, sortField, sortOrder]);

  const handleSort = (field) => {
    const newSortOrder =
      field === sortField ? (sortOrder === "asc" ? "desc" : "asc") : "asc";

    setSortField(field);
    setSortOrder(newSortOrder);
    setPage(1);
  };

  const showAlert = (id) => {
    Swal.fire({
      background: "#373839",
      color: "#ffffff",
      title: "Are you sure?",
      text: "You won't be able to revert this Client Data",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      confirmButtonColor: "red",
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(DeletePastClient(id, auth, setPage));
        dispatch(GetPastClient(payload, auth));
      }
    });
  };

  return (
    <>
      <div className="w-full my-2 md:w-full ">
        <h1 className="text-[20px] font-semibold">Past Clients</h1>
        <TableContainer>
          <div
            className={`flex flex-col items-start justify-start md:flex-row
          md:items-center md:justify-between  content-start1 hideMe ${
            exportLoading ? "hidden" : ""
          }`}
          >
            <div className="past_input">
              <Input
                className="outline-none w-[90%] md:w-[90%] text-[18px] border-slate-200

                    contrast-more:border-slate-400 py-1 px-[15px] my-4
                    rounded-[8px] focus:border-0 focus:outline-1 focus-within:outline-red-50
                    contrast-more:placeholder-white bg-[#403F3F] text-white "
                placeholder="Search..."
                value={searchValue}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </div>
            <div>
              <button
                className="mb-4 float-left text-left rounded-[8px] bg-white text-black
                                text-[14px]  py-2 px-[37px]
                   hover:bg-[#2ede9f] hover:text-white font-semibold
                  "
                onClick={() => {
                  dispatch(resetsinglepastclient());
                  navigate("/addpastclient");
                }}
              >
                Add Past Clients
              </button>
            </div>
          </div>
          {/*card list*/}
          <div
            className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px] w-full mx-auto overflow-x-scroll"
          >
            {isLoading ? (
              <SkeletonTheme
                baseColor="#181818"
                highlightColor="#252525"
                borderRadius="0.5rem"
                duration={2}
              >
                <div className="w-full">
                  <Skeleton w height={170} />
                </div>
              </SkeletonTheme>
            ) : (
              <div className=" flex-col w-[900px] divide-y divide-[#5C5C5C]  md:w-full ">
                {PastClientData?.clientList?.length === 0 ? (
                  <>
                    <div className="flex items-center justify-center text-center">
                      No Data Found
                    </div>
                  </>
                ) : (
                  PastClientData?.clientList?.map((client, i) => {
                    return (
                      <div
                        className="flex flex-row items-center justify-start w-full p-2 overflow-x-auto"
                        key={i}
                      >
                        <div
                          className="rounded-full w-[40px] h-[40px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
                        >
                          <img
                            className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content"
                            src={
                              `${process.env.REACT_APP_IO}/${client?.client_image}` ||
                              alex_img
                            }
                            alt="user"
                            onError={({ currentTarget }) => {
                              currentTarget.onerror = null; // prevents looping
                              currentTarget.src = alex_img;
                            }}
                            // onError={onError}
                          />
                        </div>
                        <div className="ms-4 md:ms-8 mb-2 w-[20%] truncate">
                          <p className="text-[14px] font-medium">
                            Company name
                          </p>
                          <p className="text-[16px] text-[#868C96] mt-2 truncate">
                            {client?.company_name}
                          </p>
                        </div>
                        <div className="ms-0 md:ms-8 mb-2 w-[10%] truncate ">
                          <p className="text-[14px] font-medium">
                            Revenue made
                          </p>
                          <p className="text-[16px] text-[#868C96] mt-2 truncate ">
                            €{client?.revenue_made}
                          </p>
                        </div>
                        <div className="ms-0 md:ms-8 mb-2 w-[30%] truncate">
                          <p className="text-[14px] font-medium">
                            Type of work
                          </p>
                          <p className="text-[16px] text-[#868C96] mt-2 capitalize truncate">
                            {client?.company_type}
                          </p>
                        </div>
                        <div className="ms-0 md:ms-8 mb-2 w-[10%] truncate">
                          <p className="text-[14px] font-medium">
                            Closing rate
                          </p>
                          <p className="text-[16px] text-[#868C96] mt-2 truncate">
                            {client?.closing_rate}%
                          </p>
                        </div>
                        <div className="ms-0 md:ms-8 mb-2 w-[10%] float-right text-right">
                          <p className="text-[14px] font-medium">Actions</p>
                          <div className="flex items-center justify-end mt-2">
                            <Link
                              className="me-4"
                              to={`/editpastclient/${client._id}`}
                            >
                              {" "}
                              <FaEdit />
                            </Link>
                            <Link onClick={() => showAlert(client?._id)}>
                              <FaTrash />
                            </Link>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {PastClientData?.clientList && PastClientData?.clientList?.length > 0 ?
          (<>
          <div className="pagination-wrapper">
            <Pagination
              className="mt-8 text-white"
              count={PastClientData?.pageCount}
              page={page}
              onChange={handleChangePage}
              color="primary"
              size="large"
            />
          </div>
          </>) : (<></>)
          }
        </TableContainer>
      </div>
    </>
  );
};

export default PastClientTable;
