import React, { useEffect, useState } from "react";
import enjsonData from "../../locales/en.json";
import { Helmet } from "react-helmet";
import SideBar from "../../CommonComponent/Sidebar";
import Header from "../../CommonComponent/Header";
import { handleKeyDown } from "../../utils/SpaceValidation";
import * as Yup from "yup";
import { ErrorMessage } from "@hookform/error-message";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import upload_icn from "../../assets/upload_icn.svg";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  AddPastClient,
  GetSinglePastClient,
  UpdatePastClient,
} from "../../redux/slices/pastClientSlice";
import { useDispatch, useSelector } from "react-redux";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import Loader from "../../CommonComponent/Loader";
import alex_img from "../../assets/alex_img.svg";

import upload_white_icn from "../../assets/upload_white_icn.svg";
import PastClientSkeleton from "../../CommonComponent/skeletons/PastClientSkeleton";

function PastClient() {
  const { id } = useParams();
  const isEditMode = !!id;

  const [privacy_policy, setPrivacyPolicy] = useState(false);
  const loginData = useSelector((state) => state?.root?.auth);
  const singlePastClientData = useSelector(
    (state) => state?.root?.pastclient?.getsinglepastclientData
  );
  const ClientImage = `${process.env.REACT_APP_IO}/${singlePastClientData?.client_image}`;
  const [selectedImage, setSelectedImage] = useState(null);

  const isLoading = useSelector((state) => state?.root?.pastclient?.loading);
  const isSubmitBtnLoading = useSelector(
    (state) => state?.root?.pastclient?.savingDataFlag
  );

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleChange = () => {
    setPrivacyPolicy(!privacy_policy);
  };

  const validationSchema = Yup.object().shape({
    company_name: Yup.string()
      .required("Please enter company name")
      .max(30, "company name must be at most 30 characters"),
    revenue_made: Yup.number()
      .required("Please enter revenue made")
      .typeError("Please enter a valid number for revenue made")
      .min(0, "Revenue made must be 0 or  greater than 0 ")
      .test(
        "max-characters",
        "Revenue made must be at most 10 digits",
        (value) => value.toString().length <= 10
      ),

    company_type: Yup.string()
      .required("Please enter company Type")
      .max(30, "Type of company must be at most 30 characters"),
    closing_rate: Yup.number()
      .required("Please enter Closing rate")
      .typeError("Please enter a valid number for closing rate")
      .min(0, " Closing rate must be 0 or  greater than 0 ")
      .max(100, " Closing rate must be 100 or  less than 100 ")
      .test("is-integer", " Closing rate must be an integer", (value) =>
        Number.isInteger(value)
      ),
    client_image: Yup.mixed()
      .test("required", "Please upload a image", (value) => {
        return value?.length === 0 ? false : true;
      })
      .test("fileFormat", "Unsupported file format", (value) => {
        if (typeof value === "string") {
          return true;
        } else {
          return (
            value &&
            ["image/jpeg", "image/jpg", "image/png"].includes(value?.type)
          );
        }
      })
      .test("fileSize", "File size is too large", (value) => {
        if (typeof value === "string") {
          return true;
        } else {
          return value && value?.size <= 1024 * 1024; // 1MB
        }
      }),
    user_approval: Yup.bool().oneOf([true], "You must need to accept approval"),
  });
  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
    setError,
    clearErrors,
    reset,
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });

  const onImageChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setValue("client_image", file);
      await trigger("client_image");
      //clearErrors("client_image");
      setSelectedImage(URL.createObjectURL(file));
    }
  };
  const onImageClick = () => {
    document.getElementById("imageInput").click();
  };

  useEffect(() => {
    if (isEditMode) {
      dispatch(GetSinglePastClient(id, auth));
    }
  }, [id, isEditMode]);

  useEffect(() => {
    if (isEditMode) {
      setSelectedImage(ClientImage);
      reset(singlePastClientData);
    }
  }, [singlePastClientData]);

  useEffect(() => {
    setPrivacyPolicy(singlePastClientData?.user_approval || false);
  }, [singlePastClientData?.user_approval]);

  const onSubmit = async (data) => {
    const formData = new FormData();

    formData.append("company_name", data.company_name);
    formData.append("revenue_made", data.revenue_made);
    formData.append("company_type", data.company_type);
    formData.append("closing_rate", data.closing_rate);
    formData.append("client_image", data.client_image);
    formData.append("user_approval", data.user_approval);

    if (isEditMode) {
      await dispatch(UpdatePastClient(formData, id, navigate, auth));
    } else {
      await dispatch(AddPastClient(formData, navigate, auth));
    }
  };

  const onCancel = () => {
    reset();
    navigate("/dashboard");
  };

  const dropzoneStyles = {
    borderRadius: "4px",
    padding: "20px",
    textAlign: "center",
    cursor: "pointer",
  };
  return (
    <>
      <Helmet>
        <title>Tracky | Past Client</title>
        <meta name="description" content="Tracky | Past Client" />
      </Helmet>

      <div className=" FirstDiv">
        <div className="p-6 dark-bg">
          <div className=" text-[#ffffff] ">
            <h1 className="text-[20px] md:text-[30px] font-semibold mb-[16px]">
              Past clients
            </h1>

            {isLoading ? (
              <PastClientSkeleton />
            ) : (
              <>
                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex-col w-full">
                      <label className="block w-full mb-4 ">
                        <span className="block text-[16px] font-semibold mb-2">
                          Company name
                        </span>
                        <input
                          type="text"
                          className="w-[80%] text-[16px] border-slate-800 placeholder-white-400
                    contrast-more:border-slate-400 py-3 px-[25px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#252525] "
                          {...register("company_name")}
                          defaultValue={singlePastClientData?.company_name}
                          autoComplete="off"
                          placeholder="Type here..."
                          onKeyPress={handleKeyDown}
                        />

                        <ErrorMessage
                          errors={errors}
                          name="company_name"
                          render={({ message }) => (
                            <p
                              className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                            >
                              {message}
                            </p>
                          )}
                        />
                      </label>
                      <label className="block w-full mb-4 ">
                        <span className="block text-[16px] font-semibold mb-2">
                          Revenue made
                        </span>
                        <input
                          type="text"
                          className="w-[80%] text-[16px] border-slate-800 placeholder-white-400
                    contrast-more:border-slate-400 py-3 px-[25px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#252525] "
                          {...register("revenue_made")}
                          defaultValue={singlePastClientData?.revenue_made}
                          autoComplete="off"
                          placeholder="Type here..."
                          onKeyPress={(e) => {
                            const charCode = e.which ? e.which : e.keyCode;
                            if (
                              (charCode > 31 &&
                                (charCode < 48 || charCode > 57) &&
                                charCode !== 46) ||
                              (charCode === 46 && e.target.value.includes("."))
                            ) {
                              e.preventDefault();
                            }
                          }}
                        />

                        <ErrorMessage
                          errors={errors}
                          name="revenue_made"
                          render={({ message }) => (
                            <p
                              className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                            >
                              {message}
                            </p>
                          )}
                        />
                      </label>
                      <label className="block w-full mb-4 ">
                        <span className="block text-[16px] font-semibold mb-2">
                          Type of company
                        </span>
                        <input
                          type="text"
                          className="w-[80%] text-[16px] border-slate-800 placeholder-white-400
                    contrast-more:border-slate-400 py-3 px-[25px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#252525] "
                          {...register("company_type")}
                          defaultValue={singlePastClientData?.company_type}
                          autoComplete="off"
                          placeholder="For example, appoinment setter"
                          onKeyPress={handleKeyDown}
                        />

                        <ErrorMessage
                          errors={errors}
                          name="company_type"
                          render={({ message }) => (
                            <p
                              className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                            >
                              {message}
                            </p>
                          )}
                        />
                      </label>
                      <label className="block w-full mb-4 ">
                        <span className="block text-[16px] font-semibold mb-2">
                          Closing rate%
                        </span>
                        <input
                          type="text"
                          className="w-[80%] text-[16px] border-slate-800 placeholder-white-400
                    contrast-more:border-slate-400 py-3 px-[25px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#252525] "
                          {...register("closing_rate")}
                          defaultValue={singlePastClientData?.closing_rate}
                          autoComplete="off"
                          placeholder="For example, appoinment setter"
                          onKeyPress={(e) => {
                            const charCode = e.which ? e.which : e.keyCode;
                            if (
                              (charCode > 31 &&
                                (charCode < 48 || charCode > 57) &&
                                charCode !== 46) ||
                              (charCode === 46 && e.target.value.includes("."))
                            ) {
                              e.preventDefault();
                            }
                          }}
                        />

                        <ErrorMessage
                          errors={errors}
                          name="closing_rate"
                          render={({ message }) => (
                            <p
                              className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                            >
                              {message}
                            </p>
                          )}
                        />
                      </label>
                      <div
                        className="my-4 w-[50%] cursor-pointer
    flex items-center flex-col text-center
    rounded-[8px] p-8 border-dashed border-2 border-[#555555] bg-[#252525]"
                        onClick={onImageClick} // Add onClick event to the whole div
                      >
                        {selectedImage ? (
                          <div className="cursor-pointer">
                            <img
                              className="w-[40%] h-[40%] mx-auto"
                              src={selectedImage || upload_white_icn}
                              alt="upload ico9n"
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null; // prevents looping
                                currentTarget.src = alex_img;
                              }}
                            />
                          </div>
                        ) : (
                          <>
                            <div className="cursor-pointer">
                              <img src={upload_white_icn} alt="upload ico9n" />
                            </div>
                          </>
                        )}
                        <div className="cursor-pointer">
                          <input
                            type="file"
                            id="imageInput"
                            {...register("client_image")}
                            style={{
                              display: "none",
                            }}
                            onChange={onImageChange}
                            accept="image/*"
                          />
                        </div>
                        {errors.client_image && (
                          <p
                            className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                          >
                            {errors.client_image.message}
                          </p>
                        )}
                        <div className="mt-4">
                          <p className="text-[18px]">Upload your image</p>
                        </div>
                      </div>
                      {/*Link */}
                      {/* <p className="text-[18px] font-semibold text-[#2EDE9F] underline">
                        <Link to="">
                          {" "}
                          Invite company
                          for review{" "}
                        </Link>
                      </p> */}

                      <div className="mt-[25px]">
                        <div className="grid grid-cols-1 gap-4">
                          <div className="w-full">
                            <input
                              type="checkbox"
                              name="user_approval"
                              {...register("user_approval")}
                              defaultValue={singlePastClientData?.user_approval}
                              checked={privacy_policy}
                              onChange={handleChange}
                            />
                            <span className="text-[14px] ms-4">
                              I certify that the information provided is
                              accurate to the best of my knowledge and has been
                              filled in honestly.
                            </span>
                          </div>
                          {errors.user_approval && !privacy_policy && (
                            <ErrorMessage
                              errors={errors}
                              name="user_approval"
                              render={({ message }) => (
                                <p
                                  className=" opacity-8 contrast-more:opacity-100
                           text-red-600 text-sm max-w-[80%]"
                                >
                                  {message}
                                </p>
                              )}
                            />
                          )}
                        </div>
                      </div>
                      <div className="flex items-center content-center justify-start gap-4 mt-4 md:gap-0">
                        <button
                          className="rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium
                               py-[10px] px-[30px] sm:w-[20%] w-auto hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-4 md:mb-0"
                          type="button"
                          onClick={onCancel}
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[25px] sm:w-[33%] w-auto md:w-[29%] lg:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] mb-4 md:mb-0"
                          disabled={isSubmitBtnLoading}
                        >
                          {isSubmitBtnLoading ? (
                            <>
                              <div
                                className="mx-auto text-center flex justify-center
                       items-center content-center w-[100%]"
                              >
                                <Loader />
                              </div>
                            </>
                          ) : (
                            <>
                              {isEditMode
                                ? "Update  Past Client"
                                : "Add Past Client"}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(PastClient);
