import React, { useEffect, useState } from "react";
import {
  Table,
  TableContainer,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Input,
  Pagination,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

import { useNavigate } from "react-router";

import alex_img from "../../assets/alex_img.svg";
import { GetSharedPastClient } from "../../redux/slices/sharedProfileSlice";

const SharedPastClient = ({ pastclientid, HideProfile, SharedProfileData }) => {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [itemsPerPage, setitemsPerPage] = useState(3);

  const SharedPastClientData = useSelector(
    (state) => state?.root?.sharedprofile?.sharedpastclientData
  );
  const isLoading = useSelector((state) => state?.root?.sharedprofile?.loading);

  const dispatch = useDispatch();

  const handleChangePage = (_, newPage) => {
    setPage(newPage);
  };
  const payload = {
    page,
    itemsPerPage,
  };
  useEffect(() => {
    dispatch(GetSharedPastClient(pastclientid, payload));
  }, [dispatch, page]);

  return (
    <>
      <div className="w-full my-2 md:w-full">
        <h1 className="text-[20px] font-semibold mb-2">Past Clients</h1>
        {SharedProfileData?.profileData?.profileData?.user_settings
          .past_clients === true ? (
          <TableContainer className="blur-sm backdrop-brightness-10 border rounded-[12px] border-[#5C5C5C]  bg-[#272727] p-6 blurThis">
            {/*card list*/}
            <div
              className={`flex flex-col items-start justify-start md:flex-row
          md:items-center md:justify-between  content-start1 `}
            >
              {isLoading ? (
                <SkeletonTheme
                  baseColor="#181818"
                  highlightColor="#252525"
                  borderRadius="0.5rem"
                  duration={2}
                >
                  <div className="w-full">
                    <Skeleton w height={170} />
                  </div>
                </SkeletonTheme>
              ) : (
                <div className="flex-col w-full divide-y divide-[#5C5C5C] md:w-full">
                  {SharedPastClientData?.clientList?.length === 0 ? (
                    <div className="flex items-center justify-center text-center">
                      No Data Found
                    </div>
                  ) : (
                    SharedPastClientData?.clientList?.map((client, i) => {
                      return (
                        <div
                          className="flex flex-row items-center justify-start w-full p-2 overflow-x-auto"
                          key={i}
                        >
                          <div
                            className="rounded-full w-[40px] h-[40px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
                          >
                            <img
                              className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content"
                              src={
                                // `${process.env.REACT_APP_IO}/${client?.client_image}` ||
                                alex_img
                              }
                              alt="user"
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null; // prevents looping
                                currentTarget.src = alex_img;
                              }}
                              // onError={onError}
                            />
                          </div>
                          <div className="ms-4 md:ms-8 mb-2 w-[20%] truncate">
                            <p className="text-[14px] font-medium">
                              Company name
                            </p>
                            <p className="text-[16px] text-[#868C96] mt-2 truncate">
                              N/A{" "}
                            </p>
                          </div>
                          <div className="ms-0 md:ms-8 mb-2 w-[10%] truncate">
                            <p className="text-[14px] font-medium">
                              Revenue made
                            </p>
                            <p className="text-[16px] text-[#868C96] mt-2 truncate">
                              N/A
                            </p>
                          </div>
                          <div className="ms-0 md:ms-8 mb-2 w-[30%] truncate">
                            <p className="text-[14px] font-medium">
                              Type of work
                            </p>
                            <p className="text-[13px] text-[#868C96]">N/A</p>
                          </div>
                          <div className="mb-2 ms-0 md:ms-4">
                            <p className="text-[16px] font-medium">
                              Closing rate
                            </p>
                            <p className="text-[13px] text-[#868C96]">N/A</p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>
            <div className="pagination-wrapper">
              <Pagination
                className="mt-8 text-white"
                count={SharedPastClientData?.pageCount}
                page={page}
                onChange={handleChangePage}
                color="primary"
                size="large"
              />
            </div>
          </TableContainer>
        ) : (
          <TableContainer>
            {/*card list*/}
            <div
              className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px] w-full mx-auto overflow-x-scroll"
            >
              {isLoading ? (
                <SkeletonTheme
                  baseColor="#181818"
                  highlightColor="#252525"
                  borderRadius="0.5rem"
                  duration={2}
                >
                  <div className="w-full">
                    <Skeleton w height={170} />
                  </div>
                </SkeletonTheme>
              ) : (
                <div className=" flex-col w-[900px] divide-y divide-[#5C5C5C]  md:w-full ">
                  {SharedPastClientData?.clientList?.length === 0 ? (
                    <>No Data Found</>
                  ) : (
                    SharedPastClientData?.clientList?.map((client, i) => {
                      return (
                        <div
                          className="flex flex-row items-center justify-between p-2"
                          key={i}
                        >
                          <div
                            className="rounded-full w-[70px] h-[70px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
                          >
                            <img
                              className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content"
                              src={
                                `${process.env.REACT_APP_IO}/${client?.client_image}` ||
                                alex_img
                              }
                              alt="user"
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null; // prevents looping
                                currentTarget.src = alex_img;
                              }}
                              // onError={onError}
                            />
                          </div>
                          <div className="mb-2 ms-0 md:ms-4 ">
                            <p className="text-[16px] font-medium">
                              Company name
                            </p>
                            <p className="text-[13px] text-[#868C96]">
                              {client?.company_name}
                            </p>
                          </div>
                          <div className="mb-2 ms-0 md:ms-4">
                            <p className="text-[16px] font-medium">
                              Revenue made
                            </p>
                            <p className="text-[13px] text-[#868C96]">
                              €{client?.revenue_made}
                            </p>
                          </div>
                          <div className="mb-2 ms-0 md:ms-4">
                            <p className="text-[16px] font-medium">
                              Type of work
                            </p>
                            <p className="text-[13px] text-[#868C96]">
                              {client?.company_type}
                            </p>
                          </div>
                          <div className="mb-2 ms-0 md:ms-4">
                            <p className="text-[16px] font-medium">
                              Closing rate
                            </p>
                            <p className="text-[13px] text-[#868C96]">
                              {client?.closing_rate}%
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>

            {SharedPastClientData?.clientList && SharedPastClientData?.clientList?.length > 0 ?
            (<><div className="pagination-wrapper">
              <Pagination
                className="mt-8 text-white"
                count={SharedPastClientData?.pageCount}
                page={page}
                onChange={handleChangePage}
                color="primary"
                size="large"
              />
            </div></>) : (<></>)
            }
          </TableContainer>
        )}
      </div>
    </>
  );
};

export default SharedPastClient;
