import React from "react";

const SharedFeature = () => {
  return <div>SharedFeature</div>;
};

export default SharedFeature;
