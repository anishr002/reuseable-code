import React, { useLayoutEffect, useEffect, useState } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import { Helmet } from "react-helmet";

import mail_send_icn from "../../assets/mail_send_icn.svg";
import alex_img from "../../assets/alex_img.svg";
import tick_icn from "../../assets/tick_icn.png";
import up_arrow from "../../assets/up_arrow.svg";
import graph_img from "../../assets/graph_img.svg";
import pdf_icn from "../../assets/pdf_icn.svg";
import line_graph from "../../assets/line_chart_icn.svg";
import yeargraph from "../../assets/yeargraph.png";
import mpnthlygraph from "../../assets/monthlygraph.png";

import PastClient from "../Client/PastClientTable";

import Loader from "../../CommonComponent/Loader";
import MonthChart from "../Dashboard/MonthChart";
import ChartComponent from "../Dashboard/ChartComponent";
import UpdateTrackRecordForm from "../Dashboard/UpdateTrackRecordForm";
import ProfileHeader from "./ProfileHeader";
import SharedPastClient from "./sharedPastClient";
import {
  GetSharedProfile,
  setSelectedTimePeriod,
} from "../../redux/slices/sharedProfileSlice";

import {
  EmailShareButton,
  FacebookShareButton,
  LinkedinShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  RedditShareButton,
  TelegramShareButton,
} from "react-share";
import {
  EmailIcon,
  FacebookIcon,
  LinkedinIcon,
  TwitterIcon,
  WhatsappIcon,
  TelegramIcon,
  RedditIcon,
} from "react-share";
import ReactModal from "react-modal";
import SharedProfileSkeleton from "../../CommonComponent/skeletons/SharedProfileSkeleton";
import SharedChartComponent from "../Dashboard/SharedChartComponent";
import SharedChartSkeleton from "../../CommonComponent/skeletons/SharedChartSkeleton";

function SharedProfile() {
  const location = useLocation();
  // const { id } = useParams();
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [activeTimePeriod, setActiveTimePeriod] = useState(12);
  const [exportLoading, setExportLoading] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  let onlyChartChange = false;

  const HideProfile = {
    profile: true,
    profit: true,
    trackrecord: true,
    earnings: true,
    pastclients: true,
  };

  const openModal = () => {
    setShowShareModal(true);
  };

  const closeModal = () => {
    setShowShareModal(false);
  };

  const selectedTimePeriod = useSelector(
    (state) => state?.root?.sharedprofile?.selectedTimePeriod
  );

  const SharedProfileData = useSelector(
    (state) => state?.root?.sharedprofile?.sharedprofileData
  );

  const isSharedProfileDataloading = useSelector(
    (state) => state?.root?.sharedprofile?.GetSharedProfileLoading
  );

  const isonlyChartChangeLoading = useSelector(
    (state) => state?.root?.sharedprofile?.onlyChartChangeLoading
  );

  useEffect(() => {
    dispatch(GetSharedProfile(id, selectedTimePeriod, onlyChartChange));
  }, []);


  const handleTimePeriodChange = (timePeriod) => {
    onlyChartChange = true;
    dispatch(setSelectedTimePeriod(timePeriod));
    dispatch(GetSharedProfile(id, timePeriod, onlyChartChange));
    setActiveTimePeriod(timePeriod);
    onlyChartChange = false;
  };

  const formatTimeZone = (timeZone) => {
    const [offset, location] = timeZone?.split(" - ");

    const [hours, minutes] = offset?.split(":");

    const gmtOffset = parseInt(hours, 10);

    return `${location} (GMT${gmtOffset >= 0 ? "+" : ""}${gmtOffset})`;
  };
  useEffect(() => {
    // Load jQuery from CDN
    const jqueryScript = document.createElement("script");
    jqueryScript.src = "https://code.jquery.com/jquery-3.6.4.min.js";
    jqueryScript.async = true;
    jqueryScript.onload = () => {
      // Load Kendo UI from CDN
      const kendoScript = document.createElement("script");
      kendoScript.src =
        "https://kendo.cdn.telerik.com/2022.1.301/js/kendo.all.min.js"; // Replace with the appropriate version
      kendoScript.async = true;
      // kendoScript.onload = downloadFullDashboard;
      document.body.appendChild(kendoScript);
    };
    document.body.appendChild(jqueryScript);
  }, []);

  const downloadFullDashboard = () => {
    setExportLoading(true);

    const elementsToHide = document.querySelectorAll(".hideMe");
    elementsToHide.forEach((element) => {
      element.style.display = "none";
    });

    const elementsToBlur = document.querySelectorAll(".blurThis");
    elementsToBlur.forEach((element) => {
      // element.style.filter = "blur(4px)";
      element.classList.add("blurThisDiv");
    });

    // Ensure jQuery is loaded before using it
    if (window.$) {
      // Convert the DOM element to a drawing using kendo.drawing.drawDOM
      window.$("#downloadDashboard");
      window.kendo.drawing
        .drawDOM(window.$(".shared-pdf-download-wrapper"))
        .then(function (group) {
          // Render the result as a PDF file
          return window.kendo.drawing.exportPDF(group, {
            paperSize: "auto",
            margin: {
              left: "1cm",
              top: "1cm",
              right: "1cm",
              bottom: "1cm",
            },
          });
        })
        .done(function (data) {
          // Save the PDF file
          window.kendo.saveAs({
            dataURI: data,
            fileName: "Dashboard.pdf",
            proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
          });
          window.$("#downloadDashboard");
          setExportLoading(false); // Set loading state to false after export

          elementsToHide.forEach((element) => {
            element.style.removeProperty("display");
          });

          elementsToBlur.forEach((element) => {
            // element.style.removeProperty("filter");
            element.classList.remove("blurThisDiv");
          });
        });
    } else {
      console.error("jQuery is not loaded.");
      setExportLoading(false); // Set loading state to false if jQuery is not loaded
      elementsToHide.forEach((element) => {
        element.style.removeProperty("display");
      });

      elementsToBlur.forEach((element) => {
        // element.style.removeProperty("filter");
        element.classList.remove("blurThisDiv");
      });
    }
  };

  const downloadGraph = () => {
    // Ensure jQuery is loaded before using it
    setExportLoading(true); // Set loading state to false after export

    const elementsToHide = document.querySelectorAll(".hideMe2");
    elementsToHide.forEach((element) => {
      element.style.display = "none";
    });

    if (window.$) {
      // Convert the DOM element to a drawing using kendo.drawing.drawDOM
      window.kendo.drawing
        .drawDOM(window.$(".chart-pdf"))
        .then(function (group) {
          // Render the result as a PDF file
          return window.kendo.drawing.exportPDF(group, {
            paperSize: "auto",
            margin: {
              left: "1cm",
              top: "1cm",
              right: "1cm",
              bottom: "1cm",
            },
          });
        })
        .done(function (data) {
          // Save the PDF file
          window.kendo.saveAs({
            dataURI: data,
            fileName: "chart.pdf",
            proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
          });
          setExportLoading(false); // Set loading state to false after export
          elementsToHide.forEach((element) => {
            element.style.removeProperty("display");
          });
        });
    } else {
      console.error("jQuery is not loaded.");
      setExportLoading(false); // Set loading state to false after export
      elementsToHide.forEach((element) => {
        element.style.removeProperty("display");
      });
    }
  };

  let urlToShareIS = `${process.env.REACT_APP_FRONTEND_BASE_URL}profile?id=${id}`;
  let social_share_message = "Tracky Profile";



  return (
    <>
      <Helmet>
        <title>Tracky | Profile</title>
        <meta name="description" content="Tracky | Profile" />
      </Helmet>
      <nav class="fixed top-0 inset-x-0 z-50 h-20 p-6  flex justify-between items-center bg-zinc-800 border-b border-[#525252]">
        <ProfileHeader />
      </nav>
      <div className="FirstDiv shared-pdf-download-wrapper">
        <main class="pt-20 inset-y-0 overflow-x-hidden overflow-y-auto md:block">
          <div
            className="dark-bg h-[100%] text-[#ffffff] "
            id="downloadDashboard"
          >
            {isSharedProfileDataloading ? (
              <SharedProfileSkeleton />
            ) : (
              <>
                <div
                  className="grid content-center w-full grid-flow-row p-4 mx-auto md:pb-6 auto-rows-max "
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex items-start content-start md:items-start md:h-[45px]">
                    <div className="">
                      <p
                        className="text-[20px] md:text-[30px] text-left break-word md:break-normal
             font-bold "
                      >
                        Profile
                      </p>
                    </div>
                    <div
                      className={` flex flex-row justify-between md:justify-end content-center items-center  mb-4 md:md-0 hideMe ${
                        exportLoading ? "hidden" : ""
                      }`}
                    >
                      <div
                        className="flex justify-center items-center content-center border-2 border-transparent cursor-pointer hover:border-2 hover:border-[#21CE90] py-1 px-2 hover:rounded-[10px]
                        hover:bg-[#21CE90]
                          "
                        onClick={openModal}
                      >
                        <img
                          src={mail_send_icn}
                          alt="maiil icon"
                          className="me-3 w-[40%]"
                        />
                        <span className="text-[16px] font-medium ">Share</span>
                      </div>
                      <button
                        className="md:ms-6 mt-0 md:mt-0 bg-white rounded-[10px] text-[#18181B]
                  py-2 px-4
                  text-[16px] font-medium hover:bg-[#21CE90] hover:text-[#fff]"
                        onClick={downloadFullDashboard}
                        // disabled={exportLoading}
                      >
                        Download PDF
                      </button>
                    </div>
                  </div>
                  {/*Card for Alex B.*/}
                  <div
                    className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              pt-6 px-[20px] md:mt-2 w-[100%] md:w-full mx-auto"
                  >
                    <div className="flex flex-col content-start justify-start md:flex-row md:items-start md:content-start">
                      <div className="w-auto md:w-3/5">
                        {/*profile text*/}
                        <div className="flex flex-col items-start content-start justify-start md:flex-row">
                          <div
                            className="rounded-full w-[70px] h-[70px] mt-4
                      bg-gradient-to-b from-[#C57CD8] to-[#7C85D8] p-0
                      border-2 border-[#D9D9D9]"
                          >
                            <img
                              className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content"
                              src={
                                `${process.env.REACT_APP_IO}/${SharedProfileData?.profileData?.profileData?.profile_image}` ||
                                alex_img
                              }
                              alt="user"
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null; // prevents looping
                                currentTarget.src = alex_img;
                              }}
                            />
                          </div>
                          <div className="">
                            <div className="flex content-center justify-start">
                              <p className="text-[37px] font-semibold ms-4">
                                {SharedProfileData?.profileData?.profileData
                                  ?.first_name +
                                  " " +
                                  SharedProfileData?.profileData?.profileData
                                    ?.last_name}
                              </p>
                              <img
                                src={tick_icn}
                                className="ms-2  top-[0px] w-[20px] h-[20px] "
                                alt="tick icon"
                              />
                            </div>
                            <p className="text-[11px] font-semibold md:ms-4">
                              {
                                SharedProfileData?.profileData?.profileData
                                  ?.role?.key
                              }{" "}
                              {SharedProfileData?.profileData?.profileData
                                ?.time_zone &&
                                formatTimeZone(
                                  SharedProfileData?.profileData?.profileData
                                    ?.time_zone
                                )}
                            </p>
                          </div>
                        </div>
                        {SharedProfileData?.profileData?.profileData
                          ?.user_settings?.profile === true ? (
                          <div
                            className={`
                          blurThis
                          Hide-Profile-Section blur-sm backdrop-brightness-10`}
                          >
                            <p className="text-[18px] font-normal my-4 break-all ">
                              N/A
                            </p>
                            <button
                              className="rounded-[10px] border border-[#2EDE9F] text-[11px]
                           text-[#ffffff] bg-[#565657] py-2 px-6 hover:bg-[#2EDE9F] hover:text-[#fff] "
                              // onClick={() => navigate("/signup")}
                            >
                              N/A
                            </button>
                          </div>
                        ) : (
                          <div>
                            <p className="text-[18px] font-normal my-4 break-all">
                              {SharedProfileData?.profileData?.profileData?.bio}
                            </p>
                            <button
                              className="rounded-[10px] border border-[#2EDE9F] text-[11px]
                           text-[#ffffff] bg-[#565657] py-2 px-6 hover:bg-[#2EDE9F] hover:text-[#fff] "
                              onClick={() => navigate("/signup")}
                            >
                              Join Tracky
                            </button>
                          </div>
                        )}
                      </div>
                      {SharedProfileData?.profileData?.profileData
                        ?.user_settings?.profit === true ? (
                        <div
                          className={` w-[85%] md:w-2/5 mt-4 ms-4 md:ms-6 md:mt-0 bg-[#202122]
                   shadow-md shadow-slate-800 rounded-t-[25px]  p-6 Hide-Profit-Section`}
                        >
                          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 blur-sm backdrop-brightness-10 blurThis">
                            <div className="">
                              <p className="text-[15px] font-medium">
                                TOTAL PROFITS{" "}
                                {
                                  SharedProfileData?.profileData?.graphData
                                    ?.currentsYears
                                }
                              </p>
                              <p className="text-[40px] font-bold break-all">
                                N/A
                              </p>
                            </div>
                            <div className="flex items-start content-end justify-start">
                              <img src={up_arrow} alt="up arrow" />
                              <span className="ms-4 text-[22px] text-[#14A867] font-semibold  break-all">
                                N/A
                              </span>
                            </div>
                            <div className="w-[100%] lg:w-[540px] lg:h-[230px] ">
                              <img
                                src={mpnthlygraph}
                                alt="graph image"
                                className="w-full h-[230px]"
                              />
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div
                          className="w-[85%] md:w-2/5 mt-4 ms-4 md:ms-6 md:mt-0 bg-[#202122]
                   shadow-md shadow-slate-800 rounded-t-[25px]  p-6  "
                        >
                          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <div className="">
                              <p className="text-[15px] font-medium">
                                TOTAL PROFITS{" "}
                                {
                                  SharedProfileData?.profileData?.graphData
                                    ?.currentsYears
                                }
                              </p>
                              <p className="text-[40px] font-bold break-all">
                                €
                                {SharedProfileData?.profileData?.graphData
                                  ?.yearProfit
                                  ? SharedProfileData?.profileData?.graphData
                                      ?.yearProfit
                                  : 0}
                              </p>
                            </div>
                            <div className="flex items-start content-end justify-start">
                              <img src={up_arrow} alt="up arrow" />
                              <span className="ms-4 text-[22px] text-[#14A867] font-semibold break-all">
                                {SharedProfileData?.profileData?.graphData
                                  ?.totalDealSizeLastMonth
                                  ? SharedProfileData?.profileData?.graphData
                                      ?.totalDealSizeLastMonth
                                  : 0}
                                %
                              </span>
                            </div>
                            <div className="w-[100%] lg:w-[480px] lg:h-[230px] ">
                              {SharedProfileData?.profileData?.graphData
                                ?.mergedData?.length != 0 ? (
                                <MonthChart
                                  DashboardData={SharedProfileData?.profileData}
                                />
                              ) : (
                                <img
                                  src={graph_img}
                                  alt="graph image"
                                  className="w-[380px] h-[230px]"
                                />
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  {/*Card for track record.*/}
                  <p className="mb-2 text-[20px] font-semibold mt-6 md:mt-4">
                    Track Record
                  </p>
                  <div className="flex flex-col content-start justify-start md:flex-row md:items-center">
                    {SharedProfileData?.profileData?.profileData?.user_settings
                      ?.track_record == true ? (
                      <div
                        className={` w-auto md:w-[64%] chart-pdf Hide-Track-Section`}
                      >
                        <div
                          className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px]  w-[100%] md:w-full mx-auto md:h-[350px] blur-sm backdrop-brightness-10 blurThis"
                        >
                          <div className="flex flex-col items-start justify-start md:flex-row md:items-center md:justify-center">
                            <div className="md:flex-none w-14">
                              <span className="text-[16px] font-bold">
                                {SharedProfileData?.data?.currentYear}{" "}
                              </span>
                            </div>
                            <div className="md:flex-1  flex-col md:flex-row flex w-[300px] md:w-64  mt-4 md:mt-0">
                              <div className="flex flex-wrap items-start md:justify-center track_record w-[100%]">
                                <button
                                  className={`bg-white text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ${
                                    activeTimePeriod === 12 ? "active" : ""
                                  }`}
                                  // onClick={() => handleTimePeriodChange(12)}
                                >
                                  N/A
                                </button>
                                <button
                                  className={`bg-white text-[11px] w-[45%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4
                                hover:bg-[#2ede9f] hover:text-white
                                  ${activeTimePeriod === 6 ? "active" : ""}`}
                                  // onClick={() => handleTimePeriodChange(6)}
                                >
                                  N/A
                                </button>
                                <button
                                  className={`bg-white text-[11px] w-[45%] md:w-auto mt-4 md:mt-0 font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white ${
                                    activeTimePeriod === 30 ? "active" : ""
                                  }`}
                                  // onClick={() => handleTimePeriodChange(30)}
                                >
                                  N/A
                                </button>
                                <button
                                  className={`bg-white text-[11px] w-[45%] md:w-auto mt-4 md:mt-0 font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white ${
                                    activeTimePeriod === 7 ? "active" : ""
                                  }`}
                                  // onClick={() => handleTimePeriodChange(7)}
                                >
                                  N/A
                                </button>
                              </div>
                            </div>
                            <div
                              // onClick={downloadGraph}
                              className={`flex-none w-[45%] md:w-36 text-[16px] font-bold mt-4 md:mt-0 `}
                            >
                              <button
                                className={`bg-white w-full flex items-center justify-center
                               text-[11px] font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white hideMe ${
                                 exportLoading ? "hidden" : ""
                               }`}
                                // disabled={exportLoading}
                              >
                                N/A
                              </button>
                            </div>
                          </div>
                          <div className="mt-2 w-[100%]">
                            <img
                              src={yeargraph}
                              alt="line graph"
                              className="w-full"
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="w-auto md:w-[64%] chart-pdf">
                        <div
                          className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px]  w-[100%] md:w-auto mx-auto md:h-[350px]"
                        >
                          <div className="flex flex-col items-start justify-start md:flex-row md:items-center md:justify-center">
                            <div className="md:flex-none w-14">
                              <span className="text-[16px] font-bold">
                                {SharedProfileData?.data?.currentsYears}{" "}
                              </span>
                            </div>
                            <div className="md:flex-1  flex-col md:flex-row flex w-[300px] md:w-64  mt-4 md:mt-0">
                              <div className="flex flex-wrap items-start md:justify-center track_record w-[100%]">
                                <button
                                  className={`bg-white text-[11px] w-[44%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 ${
                                    activeTimePeriod === 12 ? "active" : ""
                                  }`}
                                  onClick={() => handleTimePeriodChange(12)}
                                >
                                  12 Months
                                </button>
                                <button
                                  className={`bg-white text-[11px] w-[45%] md:w-auto font-bold me-4 rounded-lg text-[#18181B] py-2 px-4
                                hover:bg-[#2ede9f] hover:text-white
                                  ${activeTimePeriod === 6 ? "active" : ""}`}
                                  onClick={() => handleTimePeriodChange(6)}
                                >
                                  6 Months
                                </button>
                                <button
                                  className={`bg-white text-[11px] w-[45%] md:w-auto mt-4 md:mt-0 font-bold me-4 rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white ${
                                    activeTimePeriod === 30 ? "active" : ""
                                  }`}
                                  onClick={() => handleTimePeriodChange(30)}
                                >
                                  30 Days
                                </button>
                                <button
                                  className={`bg-white text-[11px] w-[45%] md:w-auto mt-4 md:mt-0 font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white ${
                                    activeTimePeriod === 7 ? "active" : ""
                                  }`}
                                  onClick={() => handleTimePeriodChange(7)}
                                >
                                  7 Days
                                </button>
                              </div>
                            </div>
                            <div
                              onClick={downloadGraph}
                              className={`flex-none w-[45%] md:w-36 text-[16px] font-bold mt-4 md:mt-0 `}
                            >
                              <button
                                className={`bg-white w-full flex items-center justify-center
                               text-[11px] font-bold rounded-lg text-[#18181B] py-2 px-4 hover:bg-[#2ede9f] hover:text-white hideMe hideMe2  ${
                                 exportLoading ? "hidden" : ""
                               }`}
                                disabled={exportLoading}
                              >
                                {exportLoading ? (
                                  <Loader />
                                ) : (
                                  <>
                                    <img
                                      src={pdf_icn}
                                      className="me-2"
                                      alt="pdf icon"
                                    />
                                    Export PDF
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                          <div className="mt-2">
                            {isonlyChartChangeLoading ? (
                              <>
                                <SharedChartSkeleton />{" "}
                              </>
                            ) : (
                              <>
                                {SharedProfileData?.data?.mergedData?.length !=
                                0 ? (
                                  <SharedChartComponent
                                    DashboardChartData={SharedProfileData?.data}
                                  />
                                ) : (
                                  <img src={line_graph} alt="line graph" />
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="w-auto md:w-[35%] ms-0 md:ms-6 mt-4 md:mt-0">
                      {SharedProfileData?.profileData?.profileData
                        ?.user_settings?.earnings === true ? (
                        <div
                          className={` border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px] md:h-[350px] w-[100%] md:w-full blur-sm backdrop-brightness-10 Hide-Earning-Section blurThis`}
                        >
                          <div className="grid grid-flow-row auto-rows-max">
                            <div className="text-center">
                              <span className="text-[11px] text-[#868C96]">
                                Lifetime earnings
                              </span>
                              <p className="text-[25px] font-medium break-all">
                                {" "}
                                N/A
                              </p>
                            </div>
                            <hr className="my-2 border-slate-500" />
                            <div className="grid grid-cols-1 md:grid-cols-2 md:gap-4 md:divide-x md:divide-slate-500 ">
                              {SharedProfileData?.profileData?.profileData?.role
                                ?.key === "closer" && (
                                <div className="text-center md:life">
                                  <span className="text-[11px] text-[#868C96]">
                                    Lifetime calls
                                  </span>
                                  <p className="text-[25px] font-medium break-all">
                                    N/A
                                  </p>
                                </div>
                              )}
                              {SharedProfileData?.profileData?.profileData?.role
                                ?.key === "setter" && (
                                <div className="text-center life">
                                  <span className="text-[11px] text-[#868C96]">
                                    Lifetime chats
                                  </span>
                                  <p className="text-[25px] font-medium break-all">
                                    N/A
                                  </p>
                                </div>
                              )}

                              <div className="text-center life">
                                <span className="text-[11px] text-[#868C96]">
                                  Avg. deal size
                                </span>
                                <p className="text-[25px] font-medium break-all">
                                  N/A
                                </p>
                              </div>
                            </div>
                            <div className="text-center">
                              <span className="text-[11px] text-[#868C96]">
                                {" "}
                                Lifetime closes
                              </span>
                              <p className="text-[25px] text-[#2EDE9F] font-medium break-all">
                                N/A
                              </p>
                            </div>
                            <div className="text-center">
                              <span className="text-[11px] text-[#868C96]">
                                {SharedProfileData?.profileData?.profileData
                                  ?.role?.key === "closer"
                                  ? "Lifetime lost calls"
                                  : "Lifetime lost opportunities"}
                              </span>
                              <p className="text-[25px] text-[#EC2A2A] font-medium break-all">
                                N/A
                              </p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div
                          className="border rounded-[12px] border-[#5C5C5C]  bg-[#272727]
              py-6 px-[20px] md:h-[350px] w-[100%] md:w-full mx-auto"
                        >
                          <div className="grid grid-flow-row auto-rows-max ">
                            <div className="text-center">
                              <span className="text-[11px] text-[#868C96]">
                                Lifetime earnings
                              </span>
                              <p className="text-[25px] font-medium break-all">
                                €{" "}
                                {parseFloat(
                                  SharedProfileData?.profileData?.sumData
                                    ?.average_deal_size
                                    ? SharedProfileData?.profileData?.sumData?.average_deal_size.toFixed(
                                        2
                                      )
                                    : 0
                                )}
                              </p>
                            </div>
                            <hr className="my-2 border-slate-500" />
                            <div className="grid grid-cols-1 md:grid-cols-2 md:gap-4 md:divide-x md:divide-slate-500 ">
                              {SharedProfileData?.profileData?.profileData?.role
                                ?.key === "closer" && (
                                <div className="text-center md:life">
                                  <span className="text-[11px] text-[#868C96]">
                                    Lifetime calls
                                  </span>
                                  <p className="text-[25px] font-medium break-all">
                                    {SharedProfileData?.profileData?.sumData
                                      ?.total_calls
                                      ? SharedProfileData?.profileData?.sumData
                                          ?.total_calls
                                      : 0}
                                  </p>
                                </div>
                              )}
                              {SharedProfileData?.profileData?.profileData?.role
                                ?.key === "setter" && (
                                <div className="text-center life">
                                  <span className="text-[11px] text-[#868C96]">
                                    Lifetime chats
                                  </span>
                                  <p className="text-[25px] font-medium break-all">
                                    {SharedProfileData?.profileData?.sumData
                                      ?.total_chat
                                      ? SharedProfileData?.profileData?.sumData
                                          ?.total_chat
                                      : 0}
                                  </p>
                                </div>
                              )}

                              <div className="text-center life">
                                <span className="text-[11px] text-[#868C96]">
                                  Avg. deal size
                                </span>
                                <p className="text-[25px] font-medium break-all">
                                  {SharedProfileData?.profileData?.profileData
                                    ?.average_deal_size
                                    ? SharedProfileData?.profileData
                                        ?.profileData?.average_deal_size
                                    : 0}
                                </p>
                              </div>
                            </div>
                            <div className="text-center">
                              <span className="text-[11px] text-[#868C96]">
                                {" "}
                                Lifetime closes
                              </span>
                              <p className="text-[25px] text-[#2EDE9F] font-medium break-all">
                                {SharedProfileData?.profileData?.sumData
                                  ?.total_closed
                                  ? SharedProfileData?.profileData?.sumData
                                      ?.total_closed
                                  : 0}
                              </p>
                            </div>
                            <div className="text-center">
                              <span className="text-[11px] text-[#868C96]">
                                {SharedProfileData?.profileData?.profileData
                                  ?.role?.key === "closer"
                                  ? "Lifetime lost calls"
                                  : "Lifetime lost opportunities"}
                              </span>
                              <p className="text-[25px] text-[#EC2A2A] font-medium break-all">
                                {SharedProfileData?.profileData?.sumData
                                  ?.total_lost
                                  ? SharedProfileData?.profileData?.sumData
                                      ?.total_lost
                                  : 0}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="w-auto my-3 overflow-x-auto md:w-full">
                    <SharedPastClient
                      pastclientid={id}
                      HideProfile={HideProfile}
                      SharedProfileData={SharedProfileData}
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        </main>

        <ReactModal
          isOpen={showShareModal}
          onRequestClose={closeModal}
          style={{
            content: {
              maxWidth: "410px",
              height: "250px",
              margin: "auto",
              backgroundColor: "#373839",
              color: "#ffffff",
              borderRadius: "15px",
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
            },
          }}
        >
          <div className="flex flex-row justify-between">
            <p className="text-[25px] font-semibold">
              Share your referral link
            </p>
            <button className="" onClick={closeModal}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18 18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
          <hr />
          <div className="pt-3">
            <EmailShareButton
              url={`${urlToShareIS}`}
              subject={`Tracky Profile`}
              body={`Tracky Profile`}
            >
              <EmailIcon size={62} round={true} />
            </EmailShareButton>
            &nbsp;&nbsp;
            <FacebookShareButton
              url={`${urlToShareIS}`}
              quote={social_share_message}
            >
              <FacebookIcon size={62} round={true} />
            </FacebookShareButton>
            &nbsp;&nbsp;
            <TwitterShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <TwitterIcon size={62} round={true} />
            </TwitterShareButton>
            &nbsp;&nbsp;
            <LinkedinShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
              summary={social_share_message}
            >
              <LinkedinIcon size={62} round={true} />
            </LinkedinShareButton>
            &nbsp;&nbsp;
            <WhatsappShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <WhatsappIcon size={62} round={true} />
            </WhatsappShareButton>
          </div>
          <div className="pt-3">
            <TelegramShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <TelegramIcon size={62} round={true} />
            </TelegramShareButton>
            &nbsp;&nbsp;
            <RedditShareButton
              url={`${urlToShareIS}`}
              title={social_share_message}
            >
              <RedditIcon size={62} round={true} />
            </RedditShareButton>
            &nbsp;&nbsp;
          </div>
        </ReactModal>
      </div>
    </>
  );
}

export default SharedProfile;
