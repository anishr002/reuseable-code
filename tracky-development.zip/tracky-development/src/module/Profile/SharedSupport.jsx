import React from "react";

const SharedSupport = () => {
  return <div>SharedSupport</div>;
};

export default SharedSupport;
