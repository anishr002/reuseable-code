import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";


import alex_img from "../../assets/alex_img.svg";
import help_icn from "../../assets/help_icn.svg";
import saved_icn from "../../assets/saved_icn.svg";
import logo_light from "../../assets/logo_light.svg";

import invite_icn from "../../assets/invite_icn.svg";

function ProfileHeader() {
  // const mobile_icon = document.getElementById('mobile-icon');
  // const mobile_menu = document.getElementById('mobile-menu');
  // const hamburger_icon = document.querySelector("#mobile-icon i");

  // function openCloseMenu() {
  //   mobile_menu.classList.toggle('block');
  //   mobile_menu.classList.toggle('active');
  // }

  // function changeIcon(icon) {
  //   icon.classList.toggle("fa-xmark");
  // }

  // mobile_icon.addEventListener('click', openCloseMenu);
  const navigate = useNavigate();

  const redirectToLogin = () => {
    navigate("/login");
  };

  return (
    <>
      <nav className="relative w-full ">

        <div className="flex items-center justify-between mx-auto ">

          <img
            src={logo_light}
            className="cursor-pointer"
            onClick={redirectToLogin}
          />

          <ul className="hidden space-x-6 md:flex">
            <li className="text-white hover:text-[#2EDE9F]">
              <Link to="https://www.trytracky.com/features" target="_blank">Features</Link>
            </li>
            <li className="text-white hover:text-[#2EDE9F]">
              <Link to="https://www.trytracky.com/pricing" target="_blank">Pricing</Link>
            </li>
            <li className="text-white hover:text-[#2EDE9F]">
              <Link to="https://www.trytracky.com/helpcenter" target="_blank">Support</Link>
            </li>
            <li className="text-white hover:text-[#2EDE9F]">
              <Link to="/login" target="_blank">Login</Link>
            </li>
            <li className="text-white hover:text-[#2EDE9F]">
              <Link to="/signup" target="_blank">Start free trial</Link>
            </li>
          </ul>



          {/* <!-- Mobile menu icon --> */}
          <button id="mobile-icon" className="md:hidden">
            <i onclick="changeIcon(this)" className="fa-solid fa-bars"></i>
          </button>
        </div>

        {/* <!-- Mobile menu --> */}
        <div className="flex justify-center w-full mt-3 md:hidden">
          <div id="mobile-menu" className="absolute w-full mobile-menu top-23"> {/*<!-- add hidden here later --> */}
            <ul className="h-screen font-bold leading-9 bg-gray-100 shadow-lg">
              <li className="pl-4 border-b-2 border-white hover:bg-red-400 hover:text-white">
                <Link to="https://www.trytracky.com/features" target="_blank">Features</Link>
              </li>
              <li className="pl-4 border-b-2 border-white hover:bg-red-400 hover:text-white">
                <Link to="https://www.trytracky.com/pricing" target="_blank">Pricing</Link>
              </li>

              <li className="pl-4 border-b-2 border-white hover:bg-red-400 hover:text-white">
                <Link to="https://www.trytracky.com/helpcenter" target="_blank">Support</Link>
              </li>
              <li className="pl-4 border-b-2 border-white hover:bg-red-400 hover:text-white">
                <Link to="/login" target="_blank">Login</Link>
              </li>
              <li className="pl-4 border-b-2 border-white hover:bg-red-400 hover:text-white">
                <Link to="/signup" target="_blank">Start free trial</Link>
              </li>

            </ul>
          </div>
        </div>

      </nav>
    </>
  );
}

export default ProfileHeader;
