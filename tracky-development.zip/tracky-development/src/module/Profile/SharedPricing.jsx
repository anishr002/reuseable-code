import React from "react";

const SharedPricing = () => {
  return <div>SharedPricing</div>;
};

export default SharedPricing;
