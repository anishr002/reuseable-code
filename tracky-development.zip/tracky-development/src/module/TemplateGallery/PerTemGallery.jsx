import React from 'react';
import Header from '../../CommonComponent/Header';
import SideBar from '../../CommonComponent/Sidebar';
import { Helmet } from 'react-helmet';
import CheckOnboard from '../AuthGuard/CheckOnboard';

function PerTemGallery() {
  return (
    <>
      <Helmet>
        <title>Tracky | Template Gallery</title>
        <meta name="description" content="Tracky | Template Gallery" />
      </Helmet>
      <Header />
      <div className="flex">
        <SideBar />
        <div className="h-screen flex-1 p-7">
          <h2>Template Gallery</h2>
        </div>
      </div>
    </>

  )
}

export default CheckOnboard(PerTemGallery);
