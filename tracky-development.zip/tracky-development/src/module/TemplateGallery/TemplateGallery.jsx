import React, { useEffect, useState } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { Helmet } from "react-helmet";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import gallery_dummy from "../../assets/gallery_dummy.svg";
import fav_empty from "../../assets/fav_empty_icn.svg";
import fav_fill from "../../assets/fav_fill_icn.svg";
import add_icn from "../../assets/add_icn.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  DeleteFavoriteTemplate,
  FavoriteTemplate,
  GetAllTemplateGallary,
  IsLikeDislikeLoading,
  setActivefilter,
} from "../../redux/slices/templateSlice";
import ReactModal from "react-modal";

import { Input } from "@mui/material";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import TemplateSkeleton from "../../CommonComponent/skeletons/TemplateSkeleton";
import TemplateModal from "./TemplateModal";
import { useNavigate, useLocation } from "react-router-dom";
import { Pagination } from "@mui/material";

function TemplateGallery() {
  const [page, setPage] = useState(1);
  const [itemsPerPage, setitemsPerPage] = useState(10);
  const [searchValue, setSearch] = useState("");
  const [sortField, setSortField] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("asc");
  const [isFavorite, setIsFavorite] = useState(false);
  const [selectedUserID, setSelectedUserID] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [favUnFavLoadID, setfavUnFavLoadID] = useState("");

  const navigate = useNavigate();
  const location2 = useLocation();

  const userID = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData?.profileData?._id
  );

  const toggleModal = (userID) => {
    setSelectedUserID(userID);
    setIsModalOpen((prev) => !prev);
  };

  const search = useDebouncedValue(searchValue, 500);

  const dispatch = useDispatch();
  const loginData = useSelector((state) => state?.root?.auth);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;
  const TamplateData = useSelector(
    (state) => state?.root?.template?.templateData
  );

  const isLoading = useSelector(
    (state) => state?.root?.template?.GetAllTempGallaryLoad
  );
  const isLikeDislikeLoading = useSelector(
    (state) => state?.root?.template?.isLikeDislikeLoading
  );
  const activefilter = useSelector(
    (state) => state?.root?.template?.activefilter
  );

  const [filter, setFilter] = useState(activefilter);

  const handleChangePage = (_, newPage) => {
    setPage(newPage);
  };

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setPage(1);
    dispatch(setActivefilter(newFilter));
  };

  const payload = {
    search,
    sortField,
    sortOrder,
    itemsPerPage,
    page,
    filter,
  };

  const toggleFavorite = (item, isFav) => {
    setfavUnFavLoadID(item?._id);
    if (isFav) {
      const favID = item?.isFav?._id;
      dispatch(IsLikeDislikeLoading());
      dispatch(DeleteFavoriteTemplate(favID, auth, payload));

      // delete
    } else {
      // add api
      const TemplateID = {
        templateId: item?._id,
      };
      dispatch(IsLikeDislikeLoading());

      dispatch(FavoriteTemplate(TemplateID, auth, payload));
    }

    // setIsFavorite((prevState) => !prevState);
  };

  useEffect(() => {
    // if (activefilter == 'favorites') {
    setFilter(activefilter);
    // }

    dispatch(GetAllTemplateGallary(payload, auth));

    // return () => {
    //   dispatch(setActivefilter('All'));
    // };
  }, [dispatch, search, page, sortField, sortOrder, filter]);

  const SingleTemplate = (item) => {
    if (item?.pitch_type === "pitch") {
      navigate(`/pitchgenerator/${item?._id}`);
    } else {
      navigate(`/convocraft/${item?._id}`);
    }
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Template Gallery</title>
        <meta name="description" content="Tracky | Template Gallery" />
      </Helmet>

      <div className=" FirstDiv">
        <div
          className={`${
            TamplateData && TamplateData?.templateData?.length > 4
              ? "dark-bg p-6 h-full"
              : "dark-bg md:h-[calc(100vh-80px)] p-6 h-full"
          }`}
        >
          <div className=" text-[#ffffff]">
            <div className="w-full md:p-8  text-[#ffffff]">
              <h1 className="text-[30px] font-semibold mb-[16px]">
                Template gallery
              </h1>
              <div className="flex flex-col md:flex-row md:justify-between">
                <div className="past_input">
                  <input
                    className="w-full md:w-[90%] border-slate-200

                    contrast-more:border-slate-400 py-2 px-[15px] my-4
                    rounded-[8px] focus:border-0 focus:outline-1 focus-within:outline-red-50
                    contrast-more:placeholder-white bg-[#403F3F] text-white "
                    placeholder="Search..."
                    value={searchValue}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setPage(1);
                    }}
                  />
                </div>
                <div>
                  <button
                    type="button"
                    onClick={() => toggleModal(userID)}
                    class="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full hover:bg-[#ffffff] hover:text-[#000000]"
                  >
                    My personal gallery
                  </button>
                </div>
              </div>
              {/*filter and card*/}
              <div>
                <div className="flex flex-col md:flex-row  md:items-center md:justify-between  mt-8 mb-4">
                  <div>
                    {/* // filter === "All" ? "bg-white, text-[#000000]" : " rounded-md border border-white text-[14px] font-bold
                    //  px-[20px] py-[5px] me-4 hover:bg-white hover:text-[#000000]" */}
                    <button
                      onClick={() => handleFilterChange("All")}
                      className={`${
                        filter == "All"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] me-4 w-[46%] md:w-auto`}
                    >
                      All
                    </button>
                    <button
                      className={`${
                        filter == "setter"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] md:me-4 w-[46%] md:w-auto`}
                      onClick={() => handleFilterChange("setter")}
                    >
                      Setter
                    </button>
                    <button
                      className={`${
                        filter == "closer"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] me-4 w-[46%] mt-4 md:mt-0 md:w-auto`}
                      onClick={() => handleFilterChange("closer")}
                    >
                      Closer
                    </button>
                    <button
                      className={`${
                        filter == "favorites"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] md:me-4 w-[46%] md:w-auto mt-4 md:mt-0 `}
                      onClick={() => handleFilterChange("favorites")}
                    >
                      Favorites
                    </button>
                  </div>

                  <div className="mt-4 md:mt-0">
                    <span className=" me-4">Sort by</span>
                    <select
                      value={filter}
                      style={{
                        color: "black",
                      }}
                      onChange={(e) => handleFilterChange(e.target.value)}
                      className="rounded-md border border-white text-[14px] font-bold px-[10px] py-[5px] me-4 hover:bg-white hover:text-[#000000]"
                    >
                      <option
                        value="All"
                        className={`${
                          filter == "All" ? "bg-[#21CE90]" : " "
                        } hover:bg-[#21CE90] `}
                      >
                        All
                      </option>
                      <option
                        value="setter"
                        className={`${
                          filter == "setter" ? "bg-[#21CE90]" : " "
                        } hover:bg-[#21CE90] `}
                      >
                        Setter
                      </option>
                      <option
                        value="closer"
                        className={`${
                          filter == "closer" ? "bg-[#21CE90]" : " "
                        } hover:bg-[#21CE90] `}
                      >
                        Closer
                      </option>
                      <option
                        value="favorites"
                        className={`${
                          filter == "favorites" ? "bg-[#21CE90]" : " "
                        } hover:bg-[#21CE90]`}
                      >
                        Favorites
                      </option>
                    </select>
                    {/* ... Other filter buttons ... */}
                  </div>
                </div>
                {isLoading && !isLikeDislikeLoading ? (
                  <TemplateSkeleton />
                ) : (
                  <>
                    <div className="card-container  grid grid-cols-1 md:grid-cols-4  gap-8 mt-8">
                      {TamplateData &&
                      TamplateData?.templateData?.length > 0 ? (
                        TamplateData?.templateData?.map((item) => (
                          <div
                            key={item?._id}
                            className="card  rounded-[10px] bg-[#373839]"
                          >
                            <div className="w-full">
                              <img
                                src={gallery_dummy}
                                alt={item?.role_Data?.label}
                                className="w-full shadow-md"
                              />
                            </div>
                            <div className="p-4">
                              <div className="flex flex-row items-center text-left content-start">
                                <div className="w-[60%] text-left">
                                  <h3 className="text-[16px] font-semibold text-[#ffffff] break-words">
                                    {/* {item?.role_Data?.key === "closer" ? (
                                    <>Closer</>
                                  ) : item?.role_Data?.key === "setter" ? (
                                    <>Appointment setter</>
                                  ) : (
                                    "N/A"
                                  )} */}
                                    {item?.template_title}
                                  </h3>
                                  {/* <h6>
                                    {item?.pitch_type &&
                                      item.pitch_type
                                        .charAt(
                                          0
                                        )
                                        .toUpperCase() +
                                        item.pitch_type.slice(
                                          1
                                        )}
                                  </h6> */}

                                  <p className="text-[14px] font-normal">
                                    {/* {item.template}
                                     */}
                                    Template
                                  </p>
                                </div>
                                <div className="w-[40%] text-end">
                                  <button
                                    className="bg-[#BFBFBF] text-[12px] text-[#000000] font-semibold
                            py-1 px-4 rounded-[5px]
                            "
                                  >
                                    {item?.pitch_type &&
                                      item.pitch_type.charAt(0).toUpperCase() +
                                        item.pitch_type.slice(1)}
                                  </button>
                                </div>
                              </div>

                              <div className="flex  flex-row items-center   content-center  my-4">
                                <button
                                  className="w-[90%] bg-[#2EDE9F]
                          text-[#ffffff] text-[12px] font-semibold px-[10px] py-[10px] rounded-[21px]
                          cursor-none md:me-4
                          "
                                >
                                  {item?.role_Data?.key === "closer" ? (
                                    <>Closer</>
                                  ) : item?.role_Data?.key === "setter" ? (
                                    <>Setter</>
                                  ) : (
                                    "N/A"
                                  )}
                                </button>
                                <button
                                  className="w-[10%]
                          cursor-pointer ms-2 md:ms-0 md:me-4
                          "
                                  onClick={() =>
                                    toggleFavorite(
                                      item,
                                      item?.isFav?.is_like ? true : false
                                    )
                                  }
                                >
                                  {isLikeDislikeLoading &&
                                  favUnFavLoadID == item?._id ? (
                                    <>
                                      <div
                                        role="status"
                                        className="inline-flex items-center px-0 py-0
      text-[15px]  text-black
       transition ease-in-out duration-150 cursor-not-allowed"
                                        key={item?._id}
                                      >
                                        <svg
                                          class="animate-spin -ml-1 mr-3 h-6 w-5 text-white"
                                          xmlns="http://www.w3.org/2000/svg"
                                          fill="none"
                                          viewBox="0 0 24 24"
                                        >
                                          <circle
                                            class="opacity-25"
                                            cx="12"
                                            cy="12"
                                            r="10"
                                            stroke="currentColor"
                                            stroke-width="4"
                                          ></circle>
                                          <path
                                            class="opacity-75"
                                            fill="currentColor"
                                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                          ></path>
                                        </svg>
                                      </div>
                                    </>
                                  ) : (
                                    <>
                                      {item?.isFav?.is_like ? (
                                        <>
                                          <img
                                            src={fav_fill}
                                            alt={item?.isFav?.is_like}
                                            className="w-[100%] my-4 md:my-0 text-center mx-auto"
                                          />
                                        </>
                                      ) : (
                                        <img
                                          src={fav_empty}
                                          alt={item.title}
                                          className="w-[100%] my-4 md:my-0 text-center mx-auto"
                                        />
                                      )}
                                    </>
                                  )}
                                  {/* {item?.isFav?.length > 0 ? (
                                item?.isFav?.map((fav) => {
                                  return (
                                    <>
                                      <img
                                        src={fav_fill}
                                        alt={fav?.is_like}
                                        className="w-[20%] md:w-[100%] my-4 md:my-0 text-center mx-auto"
                                      />
                                    </>
                                  );
                                })
                              ) : (
                                <img
                                  src={fav_empty}
                                  alt={item.title}
                                  className="w-[20%] md:w-[100%] my-4 md:my-0 text-center mx-auto"
                                />
                              )} */}
                                </button>
                              </div>
                              <button
                                className="w-full border-2 rounded-[21px]
                          cursor-pointer tex-center flex items-center justify-center md:justify-center
                          hover:bg-[#21CE90] p-2
                          "
                                onClick={() => SingleTemplate(item)}
                              >
                                <img
                                  src={add_icn}
                                  alt={item.title}
                                  className="w-[10%]"
                                />
                                <span className="text-[12px] text-[#ffffff] ms-2 text-left">
                                  Use template
                                </span>
                              </button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <>No Template found</>
                      )}
                    </div>

                    {TamplateData &&
                      TamplateData?.templateData?.length > 0 ? (<>
                    <div className="pagination-wrapper">
                      <Pagination
                        className="mt-8 text-white "
                        count={TamplateData?.pageCount}
                        page={page}
                        onChange={handleChangePage}
                        color="primary"
                        size="large"
                      />
                    </div>
                    </>
                      ) : (<></>
                      )
                    }
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <ReactModal
        isOpen={isModalOpen}
        onRequestClose={() => toggleModal(null)}
        style={{
          content: {
            maxWidth: "80%",
            minWidth: "250px",
            width: "auto",
            height: "500px",
            margin: "auto",
            backgroundColor: "#272727",
            color: "#ffffff",
            borderRadius: "15px",
            borderColor: "#5C5C5C",
          },
          overlay: {
            backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
          },
        }}
      >
        <div className="flex flex-col	justify-start">
          {/* <div
            className="flex justify-end w-full cursor-pointer"
            onClick={() => toggleModal(null)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-6 h-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </div> */}
          <TemplateModal
            userID={selectedUserID}
            toggleModalhandle={toggleModal}
          />
        </div>
      </ReactModal>
    </>
  );
}

export default CheckOnboard(TemplateGallery);
