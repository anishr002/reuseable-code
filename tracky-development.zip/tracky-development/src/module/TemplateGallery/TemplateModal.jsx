import React, { useEffect, useState } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { Helmet } from "react-helmet";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import gallery_dummy from "../../assets/gallery_dummy.svg";
import fav_empty from "../../assets/fav_empty_icn.svg";
import fav_fill from "../../assets/fav_fill_icn.svg";
import add_icn from "../../assets/add_icn.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  DeletePersonalFavoriteTemplate,
  GetPersonalTemplateGallary,
  IsLikeDislikeLoading,
  PerasonalFavoriteTemplate,
  setActivefilter,
} from "../../redux/slices/templateSlice";
import ReactModal from "react-modal";
import { Pagination } from "@mui/material";
import { Input } from "@mui/material";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import TemplateSkeleton from "../../CommonComponent/skeletons/TemplateSkeleton";
import { useNavigate } from "react-router-dom";

const TemplateModal = ({ userID, toggleModalhandle }) => {
  const [filter, setFilter] = useState("All");
  const [page, setPage] = useState(1);
  const [itemsPerPage, setitemsPerPage] = useState(10);
  const [searchValue, setSearch] = useState("");
  const [sortField, setSortField] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("asc");
  const [isFavorite, setIsFavorite] = useState(false);
  const [favUnFavLoadID, setfavUnFavLoadID] = useState("");
  const [IsPersonal, setIsPersonal] = useState("");

  const [isModalOpen, setIsModalOpen] = useState(false);

  const toggleModal = () => {
    setIsModalOpen((prev) => !prev);
  };
  const search = useDebouncedValue(searchValue, 500);
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const loginData = useSelector((state) => state?.root?.auth);

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;
  const TamplateData = useSelector(
    (state) => state?.root?.template?.personaltemplateData
  );

  const isLoading = useSelector(
    (state) => state?.root?.template?.personalloading
  );
  const isLikeDislikeLoading = useSelector(
    (state) => state?.root?.template?.isLikeDislikeLoading
  );
  const activefilter = useSelector(
    (state) => state?.root?.template?.activefilter
  );

  const handleChangePage = (_, newPage) => {
    setPage(newPage);
  };

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setPage(1);
    dispatch(setActivefilter(newFilter));
  };

  const toggleFavorite = (item, isFav) => {
    setfavUnFavLoadID(item?._id);
    setIsPersonal(item?.template_type);

    if (isFav) {
      const favID = item?.isFav?._id;
      dispatch(IsLikeDislikeLoading());

      dispatch(DeletePersonalFavoriteTemplate(favID, auth, userID, payload));

      // delete
    } else {
      // add api
      const TemplateID = {
        templateId: item?._id,
      };
      dispatch(IsLikeDislikeLoading());

      dispatch(PerasonalFavoriteTemplate(TemplateID, auth, userID, payload));
    }

    // setIsFavorite((prevState) => !prevState);
  };

  const payload = {
    search,
    sortField,
    sortOrder,
    itemsPerPage,
    page,
    filter,
  };

  useEffect(() => {
    if (userID !== null) {
      dispatch(GetPersonalTemplateGallary(userID, payload, auth));
    }
  }, [dispatch, search, page, sortField, sortOrder, filter, userID]);

  const SingleTemplate = (item) => {
    if (item?.pitch_type === "pitch") {
      navigate(`/pitchgenerator/${item?._id}`);
    } else {
      navigate(`/convocraft/${item?._id}`);
    }
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Template Gallery</title>
        <meta name="description" content="Tracky | Template Gallery" />
      </Helmet>
      <div className=" flex">
        {/* <div className="">
          <SideBar />
        </div> */}
        <div className="w-[100%]">
          {/* <Header /> */}
          {/* {isLoading ? (
            <TemplateSkeleton />
          ) : ( */}
          <div className="bg-[#272727]   text-[#ffffff]">
            <div className="w-full  md:p-4  text-[#ffffff]">
              <div className="flex justify-between items-center mb-4">
                <h1 className="text-[20px] md:text-[30px] font-semibold">
                  Template gallery
                </h1>
                <div
                  className="cursor-pointer"
                  onClick={() => toggleModalhandle(null)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-6 h-6"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18 18 6M6 6l12 12"
                    />
                  </svg>
                </div>
              </div>
              <hr />
              <div
                className="mt-4"
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <div>
                  <input
                    className="w-full md:w-[90%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[#000] "
                    placeholder="Search..."
                    value={searchValue}
                    style={{
                      width: "200px",
                    }}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setPage(1);
                    }}
                  />
                </div>
              </div>
              {/*filter and card*/}
              <div>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mt-8 mb-4">
                  <div className="">
                    <button
                      onClick={() => handleFilterChange("All")}
                      className={`${
                        filter == "All"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] me-4 mb-4 md:mb-0 w-[45%] md:w-auto`}
                    >
                      All
                    </button>
                    <button
                      className={`${
                        filter == "setter"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] md:me-4 w-[45%] md:w-auto`}
                      onClick={() => handleFilterChange("setter")}
                    >
                      Setter
                    </button>
                    <button
                      className={`${
                        filter == "closer"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] me-4 w-[46%] md:w-auto`}
                      onClick={() => handleFilterChange("closer")}
                    >
                      Closer
                    </button>
                    <button
                      className={`${
                        filter == "favorites"
                          ? "bg-white text-[#000000] hover:bg-black hover:text-white"
                          : " bg-black text-white hover:bg-white hover:text-[#000000]"
                      }  rounded-md border border-white text-[14px] font-bold
                       px-[20px] py-[5px] md:me-4 w-[46%] md:w-auto`}
                      onClick={() => handleFilterChange("favorites")}
                    >
                      Favorites
                    </button>
                  </div>
                  <div className=""></div>
                  <div className=" mt-4 md:mt-0">
                    <span className="me-4">Sort by</span>
                    <select
                      value={filter}
                      style={{
                        color: "black",
                      }}
                      onChange={(e) => handleFilterChange(e.target.value)}
                      className="rounded-md border border-white text-[14px] font-bold px-[10px] py-[5px] me-4 hover:bg-white hover:text-[#000000]"
                    >
                      <option value="All">All</option>
                      <option value="setter">Setter</option>
                      <option value="closer">Closer</option>
                      <option value="favorites">Favorites</option>
                    </select>
                    {/* ... Other filter buttons ... */}
                  </div>
                </div>
                {isLoading && !isLikeDislikeLoading ? (
                  <TemplateSkeleton />
                ) : (
                  <>
                    <div className="card-container  grid grid-cols-1 md:grid-cols-4  gap-4 mt-8">
                      {TamplateData &&
                      TamplateData?.templateData &&
                      TamplateData?.templateData?.length > 0 ? (
                        TamplateData?.templateData?.map((item) => (
                          <>
                            {
                              <>
                                <div
                                  key={item?._id}
                                  className="card  rounded-[10px] bg-[#373839]"
                                >
                                  <div className="w-full">
                                    <img
                                      src={gallery_dummy}
                                      alt={item?.role_Data?.label}
                                      className="w-full"
                                    />
                                  </div>
                                  <div className="p-2">
                                    <div className="flex  flex-row items-center text-left content-start">
                                      <div className="w-[60%] ">
                                        <h3 className="text-[14px] font-semibold text-[#ffffff] w-full break-words">
                                          {/* {item?.role_Data?.key === "closer" ? (
                                    <>Closer</>
                                  ) : item?.role_Data?.key === "setter" ? (
                                    <>Appointment setter</>
                                  ) : (
                                    "N/A"
                                  )} */}
                                          {item?.template_title}
                                        </h3>
                                        {/* <h6>
                                    {item?.pitch_type &&
                                      item.pitch_type
                                        .charAt(
                                          0
                                        )
                                        .toUpperCase() +
                                        item.pitch_type.slice(
                                          1
                                        )}
                                  </h6> */}

                                        <p className="text-[12px] font-normal">
                                          {/* {item.template}
                                           */}
                                          Template
                                        </p>
                                      </div>
                                      <div className="w-[40%]">
                                        <button
                                          className="bg-[#BFBFBF] text-[12px] text-[#000000] font-semibold
                            py-1 px-4 rounded-[5px]  w-full
                            "
                                        >
                                          {item?.pitch_type &&
                                            item.pitch_type
                                              .charAt(0)
                                              .toUpperCase() +
                                              item.pitch_type.slice(1)}
                                        </button>
                                      </div>
                                    </div>
                                    <div className="w-full mt-4">
                                      <button className="border-2 cursor-default rounded-lg w-full font-medium p-2 text-center bg-[#BFBFBF] text-black">
                                        {item?.template_type &&
                                          item?.template_type
                                            .charAt(0)
                                            .toUpperCase() +
                                            item?.template_type.slice(1)}
                                      </button>
                                    </div>
                                    <div className="flex  flex-row items-center content-start my-4">
                                      <button
                                        className="w-[90%] bg-[#2EDE9F]
                          text-[#ffffff] text-[12px] font-semibold px-[10px] py-[10px] rounded-[21px]
                          cursor-default md:me-4
                          "
                                      >
                                        {item?.role_Data?.key === "closer" ? (
                                          <>Closer</>
                                        ) : item?.role_Data?.key ===
                                          "setter" ? (
                                          <>Setter</>
                                        ) : (
                                          "N/A"
                                        )}
                                      </button>
                                      <button
                                        className="w-[10%]
                          cursor-pointer ms-2 md:ms-0 md:me-4
                          "
                                        onClick={() =>
                                          toggleFavorite(
                                            item,
                                            item?.isFav?.is_like ? true : false
                                          )
                                        }
                                      >
                                        {isLikeDislikeLoading &&
                                        favUnFavLoadID == item?._id &&
                                        IsPersonal == "personal" ? (
                                          <>
                                            <div
                                              role="status"
                                              className="inline-flex items-center px-0 py-0
      text-[15px]  text-black
       transition ease-in-out duration-150 cursor-not-allowed"
                                              key={item?._id}
                                            >
                                              <svg
                                                class="animate-spin -ml-1 mr-3 h-6 w-5 text-white"
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                              >
                                                <circle
                                                  class="opacity-25"
                                                  cx="12"
                                                  cy="12"
                                                  r="10"
                                                  stroke="currentColor"
                                                  stroke-width="4"
                                                ></circle>
                                                <path
                                                  class="opacity-75"
                                                  fill="currentColor"
                                                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                                ></path>
                                              </svg>
                                            </div>
                                          </>
                                        ) : (
                                          <>
                                            {item?.isFav?.is_like ? (
                                              <>
                                                <img
                                                  src={fav_fill}
                                                  alt={item?.isFav?.is_like}
                                                  className="w-[100%] my-4 md:my-0 text-center mx-auto"
                                                />
                                              </>
                                            ) : (
                                              <img
                                                src={fav_empty}
                                                alt={item.title}
                                                className="w-[100%] my-4 md:my-0 text-center mx-auto"
                                              />
                                            )}
                                          </>
                                        )}

                                        {/* {isFavorite ? (
                                <img
                                  src={fav_empty}
                                  alt={item.title}
                                  className="w-[20%] md:w-[100%] my-4 md:my-0 text-center mx-auto"
                                />
                              ) : (
                                <img
                                  src={fav_fill}
                                  alt={item.title}
                                  className="w-[20%] md:w-[100%] my-4 md:my-0 text-center mx-auto"
                                />
                              )} */}
                                      </button>
                                    </div>
                                    <div>
                                      <button
                                        className="w-full border-2 rounded-[21px]
                          cursor-pointer tex-center flex items-center justify-center md:justify-center
                          hover:bg-[#21CE90] p-2
                          "
                                        onClick={() => SingleTemplate(item)}
                                      >
                                        <img
                                          src={add_icn}
                                          alt={item.title}
                                          className="w-[6%]"
                                        />
                                        <span className="text-[12px] text-[#ffffff] ms-2 text-left">
                                          Use template
                                        </span>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </>
                            }
                          </>
                        ))
                      ) : (
                        <>No Template found</>
                      )}
                    </div>
                    {TamplateData &&
                      TamplateData?.templateData &&
                      TamplateData?.templateData?.length > 0 ? (
                    <>
                    <div className="pagination-wrapper">
                      <Pagination
                        className="mt-8 text-white "
                        count={TamplateData?.pageCount}
                        page={page}
                        onChange={handleChangePage}
                        color="primary"
                        size="large"
                      />
                    </div>
                    </>) : (<>
                    </>)
                }
                  </>
                )}
              </div>
            </div>
          </div>
          {/* )} */}
        </div>
      </div>
    </>
  );
};

export default CheckOnboard(TemplateModal);
