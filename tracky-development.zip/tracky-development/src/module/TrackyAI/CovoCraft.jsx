import React, { useEffect, useState, useRef } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { Helmet } from "react-helmet";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import correct_icn from "../../assets/correct_icn.svg";
import white_logo from "../../assets/logo_light.svg";
import ReactModal from "react-modal";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  AddConvoTemplateGallary,
  AddTemplateGallary,
} from "../../redux/slices/templateSlice.js";
import { getAllConvo, renameConvo } from "../../redux/slices/convoSlice.js";

import Swal from "sweetalert2";
import ConvoCall from "../../assets/ConvoCall.svg";
import convo_call_1 from "../../assets/convo_call_1.svg";
import convo_call_2 from "../../assets/convo_call_2.svg";
import convo_call_3 from "../../assets/convo_call_3.svg";
import micro_phone from "../../assets/micro_phone.svg";
import play from "../../assets/play.svg";
import pause from "../../assets/pause.svg";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
// import { useSpeechSynthesis } from 'react-speech-kit';
import * as ObjectID from "bson-objectid";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import back_icn from "../../assets/back_icn.svg";
import Tooltip from "../../CommonComponent/Tooltip";
import SidebarConvoListSkeleton from "../../CommonComponent/skeletons/SidebarConvoListSkeleton.jsx";
import edit_icn from "../../assets/edit-icn.svg";
import Check2 from "../../assets/Check2.svg";
import Loader from "../../CommonComponent/Loader.jsx";
import Pitch_History from "../../assets/Pitch_History.svg";


const sectionContent = [
  {
    id: 0,
    title: "Company Details",
    description:
      "Information about the company that your are pitching towards.",
    example: "Example:company name, product, service",
    question: "Tell us about your company:",
  },
  {
    id: 1,
    title: "Who are you calling",
    description:
      "Give Tracky AI some general information about the person you are trying to reach.",
    question: "What is your desired outcome or goal?",
  },
  {
    id: 2,
    title: "Audience",
    description:
      "explain your target audience and why this company could be a great fit",
    question: "Who is your target audience or customers?",
  },
  {
    id: 3,
    title: "Desired outcome",
    description: "explain your desired outcome of this call.",
    example:
      "Example: Booking a next meeting or sending over the contract via email",

    question: "Highlight key features of your product or service:",
  },
  {
    id: 4,
    title: "Current pain points",
    description:
      " What are some pain points you are currently experiencing while talking to prospects?",
    question: "What are the current pain points or challenges?",
  },
  {
    id: 5,
    title: "Level of Objection Handling",
    description:
      "Choose how hard you want this call to be. Trust us Tracky AI is great at giving objections.",
    question: "How would you rate your objection handling capabilities?",
  },
];

const validationSchema = [
  Yup.object({
    answer_0: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
  }),
  Yup.object({
    answer_1: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
  }),
  Yup.object({
    answer_2: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
  }),
  Yup.object({
    answer_3: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
  }),
  Yup.object({
    answer_4: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
  }),
  Yup.object({
    role: Yup.string().required("Please select any option"),
  }),
];

const templateModalValidationSchema = Yup.object().shape({
  title: Yup.string()
    .required("Title is required")
    .matches(/^\S.*$/, "Title cannot start with a space")
    .matches(/^\D.*$/, "Title cannot start with a number")
    .max(15, "Title must be at most 15 characters"),

  bio: Yup.string()
    .required("Bio is required")
    .matches(/^\S.*$/, "Bio cannot start with a space")
    .matches(/^\D.*$/, "Bio cannot start with a number")
    .max(20, "Bio must be at most 20 characters"),

  template_type: Yup.string()
    .required("Type is required")
    .matches(/^\S.*$/, "Type cannot start with a space")
    .matches(/^\D.*$/, "Type cannot start with a number"),
});

function Timer({ initialTime, onTimerEnd }) {
  const [time, setTime] = useState(initialTime);

  useEffect(() => {
    const timer = setInterval(() => {
      const newTime = time - 1;
      setTime(newTime);

      if (newTime <= 0) {
        clearInterval(timer);
        onTimerEnd();
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [time, onTimerEnd]);

  // Format time to mm:ss
  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes < 10 ? "0" : ""}${minutes}:${
      seconds < 10 ? "0" : ""
    }${seconds}`;
  };

  return (
    <div>
      <p class="text-lg font-semibold">{formatTime(time)} </p>
    </div>
  );
}

function CovoCraft() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const PersonalinfoData = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData?.profileData
  );
  const loginData = useSelector((state) => state?.root?.auth);

  const getConvoLoading = useSelector(
    (state) => state?.root?.convo?.getAllConvoLoading
  );

  const [showInputID, setShowInputID] = useState(null);
  const [renamechat, setRenameChat] = useState("");
  const [editerror, setEditerror] = useState("");
  const [showHistoryBar,setShowHistoryBar] = useState(false)

  const [CurrentrenamechatID, setCurrentRenameChatID] = useState(null);
  const inputRef = useRef(null);

  const [convoID, setConvoID] = useState(null);
  const [convoFirstResLoading, setConvoFirstResLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [airesponding, setAiResponding] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleAudioPlaying = () => {
    setAiResponding(true);
    setIsPlaying(true);
  };

  const handleAudioPlayComplete = () => {
    setAiResponding(false);
    setIsPlaying(false);
  };

  const handleAudioPause = () => {
    setIsPlaying(false);
  };

  const toggleAudio = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
  };

  const startTimer = () => {
    // You can set initial time here, for example, 01:30 = 90 seconds
    const initialTime = 90;
    return <Timer initialTime={initialTime} onTimerEnd={stopRecording} />;
  };

  const [showShareModal, setShowShareModal] = useState(false);

  const [activePopup, setactivePopup] = useState(0);

  const [selectedSection, setSelectedSection] = useState(null);
  const [showTemplateModal, setShowTemplateModal] = useState(false);

  const [sectionSaved, setSectionSaved] = useState([]);

  const [selectedRole, setSelectedRole] = useState("");
  const [savedRole, setSavedRole] = useState("");

  const [answers, setAnswers] = useState({});
  const [canAccessMicrophone, setCanAccessMicrophone] = useState(true);

  const [filldanswers, setFilldanswers] = useState(
    localStorage.getItem(selectedSection)
  );

  const [role, setRole] = useState(PersonalinfoData?.role?._id);
  const [showCallModal, setShowCallModal] = useState(false);
  const [showSkeleton, setShowSkeleton] = useState(false);
  const appEnv = `${process.env.REACT_APP_API_BASE_URL}`;
  const audioRef = useRef(null);
  const {
    transcript,
    interimTranscript,
    finalTranscript,
    resetTranscript,
    listening,
    browserSupportsSpeechRecognition,
    isMicrophoneAvailable,
    browserSupportsContinuousListening,
  } = useSpeechRecognition();

  // const { speak } = useSpeechSynthesis();

  const openCallModal = () => {
    setShowCallModal(true);
  };

  const closeCallModal = () => {
    setShowCallModal(false);
  };

  const currentValidationSchema = showTemplateModal
    ? templateModalValidationSchema
    : validationSchema[activePopup];

  const {
    handleSubmit,
    register,
    setValue,
    trigger,
    reset,
    clearErrors,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(currentValidationSchema),
    mode: "all",
  });

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  useEffect(() => {
    dispatch(getAllConvo(auth));
  }, []);

  const handleEditChange = (e) => {
    const inputValue = e.target.value;
    if (inputValue.length <= 15) {
      setRenameChat(inputValue);
      setEditerror("");
    } else {
      setEditerror("Maximum 15 characters allowed.");
    }
  };

  const openModal = (sectionId) => {
    setShowShareModal(true);
    setSelectedSection(sectionId);
    setactivePopup(sectionId);
  };

  const closeModal = (id) => {
    // localStorage.removeItem(id);
    setValue(`answer_${id}`, localStorage.getItem(id));
    setSelectedRole(savedRole);
    setValue("role", savedRole);
    setShowShareModal(false);
    setSelectedSection(null);
    clearErrors();
  };

  const handleDoneButtonClick = (id, filldanswers) => {
    localStorage.setItem(id, filldanswers);
    localStorage.setItem("roles", selectedRole);

    setSectionSaved((prev) => [...prev, id]);
    setSavedRole(selectedRole);
    setValue("role", selectedRole);
    // setSelectedRole("");
    // setSelectedRole(localStorage.getItem("roles"));
    // closeModal();
    setShowShareModal(false);
  };

  const AllConvoData = useSelector((state) => state?.root?.convo?.AllConvoData);
  const addConvoLoading = useSelector(
    (state) => state?.root?.template?.addtemplateloading
  );

  const currentDate = new Date();
  currentDate.setHours(0, 0, 0, 0);

  const todayData = AllConvoData?.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    createdAtDate.setHours(0, 0, 0, 0); // Set hours, minutes, seconds, and milliseconds to 0 for accurate date comparison
    return createdAtDate.getTime() === currentDate.getTime();
  });

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(currentDate.getDate() - 7);

  const previous7DaysData = AllConvoData?.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    createdAtDate.setHours(0, 0, 0, 0);
    return createdAtDate >= sevenDaysAgo && createdAtDate < currentDate;
  });

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(currentDate.getDate() - 30);

  const eightDaysAgo = new Date();
  eightDaysAgo.setDate(currentDate.getDate() - 8);

  const previous8to30DaysData = AllConvoData?.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    return createdAtDate > thirtyDaysAgo && createdAtDate <= eightDaysAgo;
  });

  const before30DaysData = AllConvoData?.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    return createdAtDate < thirtyDaysAgo;
  });

  const handleSaveTemplate = async () => {
    const areAllTextareasEmpty = sectionContent
      .slice(0, -1)
      .every((content) => {
        const answer = answers[content.description];
        return (!answer || answer.trim().length === 0) && selectedRole == "";
      });

    if (areAllTextareasEmpty) {
      Swal.fire({
        background: "#373839",
        color: "#ffffff",
        confirmButtonColor: "#2EDE9F",
        confirmButtonText: "Okay",
        icon: "warning",
        title: "Please fill at least one detail before saving as a template.",
        showClass: {
          popup: `
      animate__animated
      animate__fadeInUp
      animate__faster
    `,
        },
        hideClass: {
          popup: `
      animate__animated
      animate__fadeOutDown
      animate__faster
    `,
        },
      });
      return;
    }

    setShowTemplateModal(true);
  };

  const saveModalClose = () => {
    setShowTemplateModal(false);
  };

  const handleAnswerChange = async (event, id) => {
    setValue(`answer_${id}`, event.target.value);

    await trigger(`answer_${id}`);

    const currentSection = sectionContent.find(
      (content) => content.id === selectedSection
    );

    if (currentSection) {
      setAnswers({
        ...answers,
        [currentSection.description]: event.target.value,
      });
      setFilldanswers(event.target.value);

      // localStorage.setItem(id, event.target.value);
    }
  };

  const onSubmit = async (data) => {
    const isValid = await trigger();

    if (isValid) {
      let templatePayload = {
        template: [],
        role,
        template_type: data?.template_type,
        template_title: data?.title,
        template_discription: data?.bio,
        pitch_type: "convo",
      };

      // Check if selectedRole is available and not empty
      if (selectedRole) {
        // Include the last question in the payload
        const lastQuestion = sectionContent[sectionContent.length - 1];
        const lastAnswer = answers[lastQuestion.description];

        templatePayload.template.push({
          key: lastQuestion.description,
          value: lastAnswer || "",
          level: selectedRole,
        });
      }

      // Include other questions in the payload if they have non-empty values
      sectionContent.slice(0, -1).forEach((content) => {
        const key = content.description;
        const value = answers[key];

        if (value && value.trim() !== "") {
          templatePayload.template.push({
            key,
            value,
          });
        }
      });

      // Dispatch the templatePayload
      await dispatch(
        AddConvoTemplateGallary(
          templatePayload,
          auth,
          reset,
          navigate,
          setShowTemplateModal,
          setSelectedRole,
          setAnswers,
          setSectionSaved,
          setSavedRole
        )
      );
    }
  };

  useEffect(() => {
    let myItem = localStorage.getItem("persist:root");
    localStorage.clear();
    localStorage.setItem("persist:root", myItem);
  }, []);

  const handleMakeConvo = async () => {
    const areAllTextareasEmpty = sectionContent
      .slice(0, -1)
      .every((content) => {
        const answer = answers[content.description];
        return (!answer || answer.trim().length === 0) && selectedRole == "";
      });

    if (areAllTextareasEmpty) {
      Swal.fire({
        background: "#373839",
        color: "#ffffff",
        confirmButtonColor: "#2EDE9F",
        confirmButtonText: "Okay",
        icon: "warning",
        title: "Please fill at least one option before start call",
        showClass: {
          popup: `
      animate__animated
      animate__fadeInUp
      animate__faster
    `,
        },
        hideClass: {
          popup: `
      animate__animated
      animate__fadeOutDown
      animate__faster
    `,
        },
      });
      return;
    }

    const a = new ObjectID();
    const b = a.toString();

    setConvoID(b);

    const templatePayload = {
      template: sectionContent
        .filter(
          (content) =>
            answers[content.description] !== undefined &&
            answers[content.description] !== null &&
            answers[content.description] !== ""
        )
        .map((content) => {
          const key = content.description;
          const value = answers[key];

          // Check if the current section is the last one
          if (content.id === sectionContent.length - 1) {
            return {
              key,
              value,
              level: selectedRole, // Add the "level" property for the last question
            };
          }

          return {
            key,
            value,
          };
        }),
      role,
      // selected_role: savedRole,
      // template_type: data?.template_type,
      // template_title: data?.title,
      // template_discription: data?.bio,
      // user_prompt: data.user_prompt,
      _id: b,
      // pitch_type: "convo",
    };

    openCallModal();
    FirstCallResponce(templatePayload);
  };

  const startRecording = () => {
    if (!browserSupportsSpeechRecognition) {
      toast.error(
        `Browser doesn't support speech recognition, update your browser or try using other browser`
      );
      return;
    }

    if (!isMicrophoneAvailable) {
      // toast.error(`In order to use call feature, you need to allow access to your microphone`);
      setCanAccessMicrophone(false);
      return;
    }

    if (location.protocol == "http:" && location.hostname !== "localhost") {
      setCanAccessMicrophone(false);
      return;
    }

    navigator.mediaDevices
      .getUserMedia({ audio: true })
      .then(() => {
        if (browserSupportsContinuousListening) {
          SpeechRecognition.startListening({
            continuous: true,
          });
          setRecording(true);
        } else {
          SpeechRecognition.startListening();
          setRecording(true);
        }
      })
      .catch((error) => {
        setCanAccessMicrophone(false);
        return;
      });

    // if (isMicrophoneAvailable) {
    //   if (browserSupportsContinuousListening) {
    //     SpeechRecognition.startListening({
    //       continuous: true,
    //     });
    //     setRecording(true);
    //   } else {
    //     SpeechRecognition.startListening();
    //     setRecording(true);
    //   }
    // } else {
    //   setCanAccessMicrophone(false);
    //   return;
    // }
  };

  const endCall = () => {
    // audioRef.current.pause();
    SpeechRecognition.abortListening();
    // sendUserRecordtoAI(transcript)
    resetTranscript();
    setRecording(false);
    setAiResponding(false);
    setIsPlaying(false);
    handleAudioPause();
    audioRef.current.pause();
    navigate(`/convo?cid=${convoID}`);
  };

  const stopRecording = () => {
    SpeechRecognition.abortListening();
    // audioRef.current.pause();
    // audioRef.current.stop();
    if (transcript == "") {
      toast.error(`Please speak something again, we didn't recording anything`);
    } else {
      sendUserRecordtoAI(transcript);
    }
    resetTranscript();
    setRecording(false);
  };

  const FirstCallResponce = async (templatePayload) => {
    const serverBaseURL = `${appEnv}pitch/new-call`;
    setConvoFirstResLoading(true);

    try {
      const response = await fetch(serverBaseURL, {
        method: "POST",
        headers: {
          // "Content-Type": "application/json",
          Authorization: `Bearer ${auth}`,
          "content-type": "application/json",

          // accept: 'audio/mpeg',
        },
        body: JSON.stringify(templatePayload),
      });

      // const d = await response.arrayBuffer();

      // const b = new Blob([d], { type: 'audio/mpeg' });
      // const u = URL.createObjectURL(b);
      // audioRef.current.src = u;
      // audioRef.current.play();

      if (response.ok) {
        // const reader = response.body.getReader();
        // const decoder = new TextDecoder();
        // let completeString = '';
        // // UserPrompts = UserPrompts + 1;
        // while (true) {
        //   const { value, done } = await reader.read();
        //   if (done) {
        //     const responseAIMessage = { content: `${completeString}`, role: 'assistant' };
        //     // setMessages((prev) => [...prev, responseAIMessage]);
        //     // setData('');
        //     // speak({ text: completeString })
        //     break;
        //   };
        //   const decoded = decoder.decode(value, { stream: true });
        //   // setData((prev) => prev + decoded);
        //   // speakText(decoded);
        //   const utterThis = new SpeechSynthesisUtterance(decoded);
        //   synth.speak(utterThis);
        //   completeString += decoder.decode(value, { stream: true });

        // }

        try {
          const d = await response.arrayBuffer();

          const b = new Blob([d], { type: "audio/mpeg" });
          const u = URL.createObjectURL(b);
          audioRef.current.src = u;
          audioRef.current.play();
          setConvoFirstResLoading(false);
        } catch (e) {
          console.log(e);
        }
      } else {
        // Handle non-successful response here
        // setConvoFirstResLoading(false);
        const errorMsgObj = await response.json();

        if (errorMsgObj.success == false) {
          toast.error(errorMsgObj?.message);
        }
        // navigate("/pitchgenerator");
        setConvoFirstResLoading(false);
      }
      setConvoFirstResLoading(false);
    } catch (error) {
      setConvoFirstResLoading(false);
    } finally {
    }
  };

  const RedirectToTrackAI = () => {
    navigate("/trackyai");
  };

  const takeInputForChatName = (chatID, defaultName) => {
    // if (showInputID) {
    //   setShowInputID(null);
    //   setCurrentRenameChatID(null);
    // } else {
    // inputRef.current.focus();
    // if (inputRef.current) {
    // }
    setCurrentRenameChatID(chatID);
    setShowInputID(chatID);
    setRenameChat(defaultName);
    setEditerror("");
    // }
  };

  const renameThisChat = (chatID) => {
    if (renamechat == "" || renamechat == undefined || editerror) {
      // setShowInputID(null);
      // setCurrentRenameChatID(null);
      // setRenameChat("");
      return;
    }
    const formData = {
      name: renamechat,
    };
    dispatch(
      renameConvo(
        auth,
        chatID,
        formData,
        setShowInputID,
        setCurrentRenameChatID,
        setRenameChat
      )
    );
    // setShowInputID(null);
    // setCurrentRenameChatID(null);
    // setRenameChat("");
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      renameThisChat(CurrentrenamechatID);
    }
    if (event.key === " " && event.target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  const openThisChat = (chatId) => {
    navigate(`/convo?cid=${chatId}`);
  };

  const sendUserRecordtoAI = async (inputText) => {
    // const serverBaseURL = "http://172.16.0.220:2000/aiCompletion";
    const serverBaseURL = `${appEnv}pitch/continue-call/${convoID}`;
    setConvoFirstResLoading(true);

    try {
      const response = await fetch(serverBaseURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Bearer ${auth}`,
        },
        body: JSON.stringify({
          user_prompt: `${inputText}`,
        }),
      });

      if (response.ok) {
        // const reader = response.body.getReader();
        // const decoder = new TextDecoder();
        // let completeString = '';

        // while (true) {
        //   const { value, done } = await reader.read();
        //   if (done) {
        //     let completeStringWithFormat = breakIntoParagraphs(completeString);

        //     const responseAIMessage = {
        //       content: `${completeString}`,
        //       role: 'assistant',
        //       needToFormat: true,
        //       formattedContent: completeStringWithFormat
        //     };
        //     setMessages((prev) => [...prev, responseAIMessage]);
        //     setData('');
        //     scrollToBottom();
        //     break;
        //   }
        //   const decoded = decoder.decode(value, {
        //     stream: true,
        //   });
        //   setData((prev) => prev + decoded);
        //   scrollToBottom();
        //   completeString += decoder.decode(value, {
        //     stream: true,
        //   });
        // }

        try {
          const d = await response.arrayBuffer();

          const b = new Blob([d], { type: "audio/mpeg" });
          const u = URL.createObjectURL(b);
          audioRef.current.src = u;
          audioRef.current.play();
          setConvoFirstResLoading(false);
        } catch (e) {
          console.log(e);
        }
      } else {
        // Handle non-successful response here
        const errorMsgObj = await response.json();

        if (errorMsgObj.success == false) {
          toast.error(errorMsgObj?.message);
        }
        setConvoFirstResLoading(false);
      }
    } catch (error) {
    } finally {
    }
    setConvoFirstResLoading(false);
  };

  const closeEditRenameFun = () => {
    setShowInputID(null);
    setCurrentRenameChatID(null);
    setRenameChat("");
  };

  const HandleHistoryBar = () =>{
    setShowHistoryBar(true);
  }

  const closeShowHistoryBar = () =>{
    setShowHistoryBar(false);
  }

  return (
    <>
      <Helmet>
        <title>Tracky | Convo craft</title>
        <meta name="description" content="Tracky | Convo craft" />
      </Helmet>

      <div className=" FirstDiv">
        <div className="dark-bg p-6 lg:h-[calc(100vh-80px)] h-full relative md:static">
          {/* <div className=" text-[#ffffff]"> */}
            <div className="h-full md:flex">
              <div className="md:w-4/5" onClick={closeEditRenameFun}>
                <div className="flex flex-row-reverse m-3 text-[#ffffff] items-center">
                <img src={Pitch_History} alt="back icon" className="block w-8 h-8 cursor-pointer md:hidden" onClick={HandleHistoryBar} title="Show history"/>
                  <button
                    className="bg-transparent  text-[15px] font-medium
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px]
                               flex items-center justify-end  "
                    onClick={RedirectToTrackAI}
                    type="button"
                  >
                    <img src={back_icn} alt="back icon" className="me-4" />
                    Back
                  </button>
                </div>

                <div
                  className="p-4 md:pb-6 grid-flow-row auto-rows-max  mx-auto
        content-center w-full flex flex-col justify-between h-[calc(100%-43px)]"
                >
                  <div className="md:px-[30px] flex flex-col items-center content-center h-full">
                    <p className="text-[24px] md:text-[50px] text-[#939393] font-medium text-center">
                      Lets close the next deal
                    </p>
                    <div className="grid grid-cols-1 gap-2 md:grid-cols-3 md:gap-8 md:mt-20">
                      {sectionContent?.map((content, index) => (
                        <div
                          key={content.id + 1}
                          className="rounded-[8px] border border-[#BFBFBF] bg-transparent
                    py-[10px] px-10 md:px-12  cursor-pointer w-full
                  text-[#ffffff] text-[16px] text-center mt-8 md:mt-0 grow hover:bg-[#2ede9f] hover:text-black"
                          onClick={() => openModal(content.id)}
                        >
                          <div className="flex items-center justify-between w-full text-left me-4">
                            <span className="me-4">
                              {content?.id + 1}. {content?.title}
                            </span>
                            {sectionSaved.includes(content.id) && (
                              <img src={correct_icn} alt="correct icon" />
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/*input form start here*/}
                  <div className="md:px-[25px] flex flex-col md:flex-row items-center content-center mt-6 md:mt-0">
                    <div className="grid w-full">
                      <div className="flex flex-col justify-end w-full md:flex-row md:mt-8 ">
                        <button
                          className="rounded-[8px] border border-[#BFBFBF] text-[16px] text-black
                    cursor-pointer py-[10px] px-[30px] bg-[#BFBFBF]
                    hover:bg-white me-4 w-full md:w-[30%]"
                          onClick={handleSaveTemplate}
                          type="button"
                        >
                          Save as Template
                        </button>
                        <button
                          className="rounded-[8px] border border-[#2EDE9F] text-[16px] text-white
                    cursor-pointer py-[10px] px-[30px] bg-transparent
                    hover:bg-[#2EDE9F] hover:text-white mt-4 md:mt-0 w-full md:w-[30%]"
                          type="button"
                          onClick={handleMakeConvo}
                        >
                          Start call
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className={`md:block md:w-1/5 bg-[#262626] overflow-auto py-[20px] px-[20px] h-[80vh] max-h-full ${showHistoryBar ? "block w-60 absolute top-0 right-0 ease-in duration-300 md:static" : "hidden"}`}>
                <div className="flex flex-col items-start justify-start float-left w-full h-full">
                  <div className="flex flex-row justify-between w-full">
                    <img
                      src={white_logo}
                      alt="logo light"
                      className="w-[50%]"
                    />
                                        <button className={`${showHistoryBar ? "block md:hidden": "hidden md:hidden"}`} onClick={closeShowHistoryBar} title="Close history">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="#ffffff"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18 18 6M6 6l12 12"
                  />
                </svg>
              </button>
                  </div>
                  <div className="w-full h-full my-4">
                    <ul class="list-none w-full  overflow-y-auto text-[#ffffff]">
                      {getConvoLoading ? (
                        <SidebarConvoListSkeleton />
                      ) : (
                        <>
                        {todayData &&
                          todayData?.length > 0 && (
                            <>
                            <p className="mt-1"> </p>
                              {todayData?.map((data, index) => {
                                return (
                                  <>
                                    <div
                                      className="cursor-pointer flex justify-between group relative items-start hover:bg-[#1F1F1F]"
                                      key={index}
                                    >
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <>
                                          <div className="flex flex-col">
                                            <input
                                              className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                              type="text"
                                              placeholder="Rename chat..."
                                              // {...register2("name", {
                                              //   required: "required",
                                              // })}
                                              autoFocus
                                              name="name"
                                              value={renamechat}
                                              onChange={handleEditChange}
                                              onKeyPress={handleKeyPress}
                                              ref={inputRef}
                                            />
                                            {editerror && (
                                              <p className="text-sm text-red-500">
                                                {editerror}
                                              </p>
                                            )}
                                          </div>
                                        </>
                                      ) : (
                                        <p
                                          className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                          onClick={() => {
                                            openThisChat(data._id);
                                          }}
                                          title="Open chat"
                                        >
                                          {data.name}
                                        </p>
                                      )}
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <img
                                          src={Check2}
                                          alt="Rename"
                                          onClick={() => {
                                            renameThisChat(data._id);
                                          }}
                                          className="m-1"
                                          title="Save"
                                        />
                                      ) : (
                                        <img
                                          src={edit_icn}
                                          alt="edit icon"
                                          className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                          onClick={() => {
                                            takeInputForChatName(data._id);
                                          }}
                                          title="Rename pitch"
                                        />
                                      )}
                                    </div>
                                  </>
                                );
                              })}
                            </>
                          )}




                          {previous7DaysData &&
                            previous7DaysData?.length > 0 && (
                              <>
                                <p className="text-[14px] text-[#848484] w-[80%]">
                                  Previous 7 days
                                </p>
                                {previous7DaysData?.map((data, index) => {
                                  return (
                                    <>
                                      <div
                                        className="cursor-pointer flex justify-between group relative hover:bg-[#1F1F1F]"
                                        key={index}
                                      >
                                        {showInputID &&
                                        showInputID == data._id ? (
                                          <>
                                            <div className="flex flex-col">
                                              <input
                                                className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                                type="text"
                                                placeholder="Rename chat..."
                                                // {...register2("name", {
                                                //   required: "required",
                                                // })}
                                                autoFocus
                                                name="name"
                                                value={renamechat}
                                                onChange={handleEditChange}
                                                onKeyPress={handleKeyPress}
                                                ref={inputRef}
                                              />
                                              {editerror && (
                                                <p className="text-sm text-red-500">
                                                  {editerror}
                                                </p>
                                              )}
                                            </div>
                                          </>
                                        ) : (
                                          <p
                                            className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                            onClick={() => {
                                              openThisChat(data._id);
                                            }}
                                            title="Open chat"
                                          >
                                            {data.name}
                                          </p>
                                        )}
                                        {showInputID &&
                                        showInputID == data._id ? (
                                          <img
                                            src={Check2}
                                            alt="Rename"
                                            onClick={() => {
                                              renameThisChat(data._id);
                                            }}
                                            title="Save"
                                          className="m-1"
                                          />
                                        ) : (
                                          <img
                                            src={edit_icn}
                                            alt="edit icon"
                                            className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                            onClick={() => {
                                              takeInputForChatName(
                                                data._id,
                                                data.name
                                              );
                                            }}
                                            title="Rename pitch"
                                          />
                                        )}
                                      </div>
                                    </>
                                  );
                                })}
                              </>
                            )}

                          {previous8to30DaysData &&
                            previous8to30DaysData?.length > 0 && (
                              <>
                                <p className="text-[14px] text-[#848484] w-[80%]">
                                  Previous 30 days
                                </p>
                                {previous8to30DaysData?.map((data, index) => {
                                  return (
                                    <>
                                      <div
                                        className="cursor-pointer flex justify-between group relative hover:bg-[#1F1F1F]"
                                        key={index}
                                      >
                                        {showInputID &&
                                        showInputID == data._id ? (
                                          <>
                                            <div className="flex flex-col">
                                              <input
                                                className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                                type="text"
                                                placeholder="Rename chat..."
                                                // {...register2("name", {
                                                //   required: "required",
                                                // })}
                                                autoFocus
                                                name="name"
                                                value={renamechat}
                                                onChange={handleEditChange}
                                                onKeyPress={handleKeyPress}
                                                ref={inputRef}
                                              />
                                              {editerror && (
                                                <p className="text-sm text-red-500">
                                                  {editerror}
                                                </p>
                                              )}
                                            </div>
                                          </>
                                        ) : (
                                          <p
                                            className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                            onClick={() => {
                                              openThisChat(data._id);
                                            }}
                                            title="Open chat"
                                          >
                                            {data.name}
                                          </p>
                                        )}
                                        {showInputID &&
                                        showInputID == data._id ? (
                                          <img
                                            src={Check2}
                                            alt="Rename"
                                            onClick={() => {
                                              renameThisChat(data._id);
                                            }}
                                            title="Save"
                                          className="m-1"
                                          />
                                        ) : (
                                          <img
                                            src={edit_icn}
                                            alt="edit icon"
                                            className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                            onClick={() => {
                                              takeInputForChatName(data._id);
                                            }}
                                            title="Rename pitch"
                                          />
                                        )}
                                      </div>
                                    </>
                                  );
                                })}
                              </>
                            )}

                          {before30DaysData && before30DaysData?.length > 0 && (
                            <>
                              <p className="text-[14px] text-[#848484] w-[80%]">
                                Before 30 days
                              </p>
                              {before30DaysData?.map((data, index) => {
                                return (
                                  <>
                                    <div
                                      className="cursor-pointer flex justify-between group relative hover:bg-[#1F1F1F]"
                                      key={index}
                                    >
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <>
                                          <div className="flex flex-col">
                                            <input
                                              className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                              type="text"
                                              placeholder="Rename chat..."
                                              // {...register2("name", {
                                              //   required: "required",
                                              // })}
                                              autoFocus
                                              name="name"
                                              value={renamechat}
                                              onChange={handleEditChange}
                                              onKeyPress={handleKeyPress}
                                              ref={inputRef}
                                            />
                                            {editerror && (
                                              <p className="text-sm text-red-500">
                                                {editerror}
                                              </p>
                                            )}
                                          </div>
                                        </>
                                      ) : (
                                        <p
                                          className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                          onClick={() => {
                                            openThisChat(data._id);
                                          }}
                                          title="Open chat"
                                        >
                                          {data.name}
                                        </p>
                                      )}
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <img
                                          src={Check2}
                                          alt="Rename"
                                          onClick={() => {
                                            renameThisChat(data._id);
                                          }}
                                          title="Save"
                                          className="m-1"
                                        />
                                      ) : (
                                        <img
                                          src={edit_icn}
                                          alt="edit icon"
                                          className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                          onClick={() => {
                                            takeInputForChatName(data._id);
                                          }}
                                          title="Rename pitch"
                                        />
                                      )}
                                    </div>
                                  </>
                                );
                              })}
                            </>
                          )}

                          {todayData?.length == 0 && before30DaysData?.length == 0 &&
                            previous8to30DaysData?.length == 0 &&
                            previous7DaysData?.length == 0 && (
                              <>
                                <p className="text-[16px] w-[80%] mb-1">
                                  No convo craft history found
                                </p>
                              </>
                            )}
                        </>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            {/* </div> */}
          </div>
        </div>
      </div>

      {sectionContent?.map((content, index) => (
        <ReactModal
          key={content.id}
          isOpen={showShareModal && selectedSection === content.id}
          style={{
            content: {
              maxWidth: "660px",
              minWidth: "200px",
              width: "auto",
              height: "400px",
              margin: "auto",
              backgroundColor: "#272727",
              color: "#ffffff",
              borderRadius: "15px",
              borderColor: "#5C5C5C",
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)",
            },
          }}
        >
          <form
            onSubmit={handleSubmit(() =>
              handleDoneButtonClick(content?.id, filldanswers)
            )}
          >
            <div className="flex flex-col justify-between p-4">
              <div className="flex flex-row justify-between mb-4">
                <p className="text-[25px] font-semibold">{`${content.title}:`}</p>
                <button
                  className=""
                  type="button"
                  onClick={() => closeModal(content?.id)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-10 h-10"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18 18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
              <hr />
              <div className="mt-4">
                <p className="text-[16px] font-semibold">
                  {content.description}{" "}
                  {content?.example ? content?.example : ""}
                </p>

                {index === sectionContent.length - 1 && (
                  <>
                    <div className="flex items-center mt-4">
                      <input
                        type="radio"
                        id="easy"
                        {...register("role")}
                        value="easy"
                        checked={selectedRole === "easy"}
                        onChange={async (e) => {
                          setSelectedRole("easy");
                          setValue("role", e.target.value);
                          await trigger("role");
                        }}
                      />
                      <label htmlFor="easy" className="ml-2">
                        Easy
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="radio"
                        id="medium"
                        {...register("role")}
                        value="medium"
                        checked={selectedRole === "medium"}
                        onChange={async (e) => {
                          setSelectedRole("medium");
                          setValue("role", e.target.value);
                          await trigger("role");
                        }}
                      />
                      <label htmlFor="medium" className="ml-2">
                        Medium
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="radio"
                        id="hard"
                        {...register("role")}
                        value="hard"
                        checked={selectedRole === "hard"}
                        onChange={async (e) => {
                          setSelectedRole("hard");
                          setValue("role", e.target.value);
                          await trigger("role");
                        }}
                      />
                      <label htmlFor="medium" className="ml-2">
                        Hard
                      </label>
                      {errors && (
                        <p className="text-[#FF0000] ">
                          {errors?.role?.message}
                        </p>
                      )}
                    </div>
                  </>
                )}

                <textarea
                  className={`w-full md:w-[100%] text-[16px] border-slate-200 placeholder-white
    contrast-more:border-slate-400 py-[10px] px-[15px]
    rounded-[8px] focus:border-0 focus:outline-none
    contrast-more:placeholder-white bg-[transparent] mt-4
    ${content?.id === 5 ? "hidden" : ""}`}
                  {...register(`answer_${content?.id}`)}
                  placeholder={
                    content?.id === 5
                      ? "What are some common objections you would like to see?"
                      : content?.id === 1
                      ? "John is the owner of “company name"
                      : "Type here..."
                  }
                  onKeyPress={handleKeyDown}
                  defaultValue={localStorage.getItem(content?.id)}
                  onChange={(e) => handleAnswerChange(e, content?.id)}
                />
                {errors && (
                  <p className="text-[#FF0000] text-sm ">
                    {errors[`answer_${content?.id}`]?.message}
                  </p>
                )}

                <div className="flex mt-2">
                  <button
                    className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow"
                    type="submit"
                    // onClick={() => handleDoneButtonClick(content?.id)}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </form>
        </ReactModal>
      ))}

      {showTemplateModal && (
        <ReactModal
          isOpen={showTemplateModal}
          onRequestClose={saveModalClose}
          style={{
            content: {
              maxWidth: "660px",
              minWidth: "200px",
              width: "auto",
              height: "430px",
              margin: "auto",
              backgroundColor: "#272727",
              color: "#ffffff",
              borderRadius: "15px",
              borderColor: "#5C5C5C",
              display: "flex",
              justifyContent: "center",
              flexDirection: "column",
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
            },
          }}
        >
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="flex flex-row justify-between">
              <p className="text-[25px] font-semibold">
                What’s the name of your template?
              </p>
              <button className="" onClick={saveModalClose}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18 18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            <hr className="mt-2" />
            <div className="flex flex-col p-4">
              <input
                type="text"
                className="w-full  md:w-[100%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] mb-4"
                {...register("title")}
                id="templateTitle"
                placeholder="Type here..."
              />
              {errors.title && (
                <p className="mb-2 text-sm text-red-500">{errors.title.message}</p>
              )}

              <select
                id="templateDetails"
                className="w-full md:w-[100%] text-[16px]
                                bg-[#272727] border border-gray-300 text-white
                                rounded-lg focus:ring-blue-500 focus:border-blue-500 block  py-[10px] px-[15px]
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                 dark:focus:border-blue-500 mb-4"
                name="template_type"
                {...register("template_type")}
              >
                <option value="personal">
                  Save to personal template gallery
                </option>
                <option value="community">
                  Save to community template gallery
                </option>
              </select>
              {errors.template_type && (
                <p className="text-sm text-red-500">
                  {errors.template_type.message}
                </p>
              )}

              <label htmlFor="bio" className="mb-2">
                Brief description of the template
              </label>
              <input
                type="text"
                className="w-full  md:w-[100%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] mb-4"
                {...register("bio")}
                id="bio"
                placeholder="Type here..."
              />
              {errors.bio && (
                <p className="text-sm text-red-500">{errors.bio.message}</p>
              )}
            </div>

            {/* Save as template button */}
            <div className="flex justify-end">
              <button
                className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow"
                // onClick={() => onSubmit()}
                type="submit"
                disabled={addConvoLoading}
              >
                {addConvoLoading ? (
                  <>
                    <div
                      className="flex items-center content-center justify-center w-full "
                    >
                      <Loader />
                    </div>
                  </>
                ) : (
                  <> Save as template</>
                )}
              </button>
            </div>
          </form>
        </ReactModal>
      )}

      <ReactModal
        isOpen={showCallModal}
        // onRequestClose={
        //   closeCallModal
        // }
        style={{
          content: {
            // width: "648px",
            // height: "451px",
            // margin: "auto",
            // backgroundColor: "#373839",
            // color: "#ffffff",
            // borderRadius: "15px",
            maxWidth: "550px",
            minWidth: "250px",
            width: "auto",
            height: "445px",
            margin: "auto",
            backgroundColor: "#272727",
            color: "#ffffff",
            borderRadius: "15px",
            borderColor: "#5C5C5C",
          },
          overlay: {
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            opacity: 1,
          },
        }}
      >
        <div className="flex flex-row-reverse items-center content-center justify-between mb-4">
          <Tooltip
            text={`${convoFirstResLoading ? "Please wait" : "End Call"}`}
            bgColor="bg-[#4d4d4d]"
          >
            <button
              className=""
              onClick={endCall}
              disabled={convoFirstResLoading}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6 hover:stroke-[#2EDE9F]"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18 18 6M6 6l12 12"
                />
              </svg>
            </button>
          </Tooltip>
        </div>

        <div className="flex items-center justify-center">
          <img
            src={ConvoCall}
            alt="Convo Call"
            className="w-[217px] h-[217px]"
          />
        </div>

        <audio
          ref={audioRef}
          type="audio/mpeg"
          onPlay={handleAudioPlaying}
          onEnded={handleAudioPlayComplete}
          onPause={handleAudioPause}
        ></audio>

        <div className="flex items-center justify-center mt-2">
          {convoFirstResLoading ||
          airesponding ||
          canAccessMicrophone == false ? (
            <></>
          ) : (
            <>
              {recording ? (
                <>
                  <Tooltip
                    text="Stop recording and send"
                    bgColor="bg-[#4d4d4d]"
                  >
                    <button
                      className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#2EDE9F] mx-2"
                      onClick={stopRecording}
                    >
                      <img src={micro_phone} alt="Convo Call" className="" />
                    </button>
                  </Tooltip>
                </>
              ) : (
                <>
                  <Tooltip text="Start Recording" bgColor="bg-[#4d4d4d]">
                    <button
                      className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#656565] mx-2"
                      onClick={startRecording}
                    >
                      <img src={micro_phone} alt="Convo Call" className="" />
                    </button>
                  </Tooltip>
                </>
              )}
            </>
          )}

          {/* <button className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#656565] mx-1">
            <img src={convo_call_1} alt="Convo Call" className="" />
          </button> */}

          <>
            <Tooltip
              text={`${convoFirstResLoading ? "Please wait" : "End Call"}`}
              bgColor="bg-[#4d4d4d]"
            >
              <button
                className={`rounded-full w-[50px] h-[50px] flex items-center justify-center  mx-2 ${
                  convoFirstResLoading ? "bg-[#AFAFAF] " : "bg-[#D60000]"
                }`}
                onClick={endCall}
                disabled={convoFirstResLoading}
              >
                <img src={convo_call_2} alt="Convo Call" className="" />
              </button>
            </Tooltip>
          </>

          {airesponding ? (
            <>
              {isPlaying ? (
                <>
                  <Tooltip text="Pause" bgColor="bg-[#4d4d4d]">
                    <button
                      className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#2ede9f] mx-2"
                      onClick={toggleAudio}
                    >
                      <img src={pause} alt="Convo Call" className="" />
                    </button>
                  </Tooltip>
                </>
              ) : (
                <>
                  <Tooltip text="Play" bgColor="bg-[#4d4d4d]">
                    <button
                      className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#2ede9f] mx-2"
                      onClick={toggleAudio}
                    >
                      <img src={play} alt="Convo Call" className="" />
                    </button>
                  </Tooltip>
                </>
              )}
            </>
          ) : (
            <></>
          )}

          {/* <Tooltip text="Restart Call" bgColor="bg-[#4d4d4d]">
            <button className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#656565] mx-2">
              <img src={convo_call_3} alt="Convo Call" className="" />
            </button>
          </Tooltip> */}
        </div>

        <div>
          {convoFirstResLoading ? (
            <>
              <div class="flex items-center justify-center">
                <svg
                  class="animate-spin -ml-1 mr-3 h-6 w-5 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    class="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    stroke-width="4"
                  ></circle>
                  <path
                    class="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                <p class="text-lg font-semibold">processing...</p>
              </div>
            </>
          ) : (
            <></>
          )}

          {recording ? (
            <>
              <div class="flex items-center justify-center">
                <p className="text-lg font-semibold">Recording...</p>
                &nbsp; {startTimer()} &nbsp;
              </div>
              <div className="flex items-center justify-center">
                <p className="text-sm">You can record maximum 1:30 minute</p>
              </div>
            </>
          ) : (
            <></>
          )}

          {canAccessMicrophone == false ? (
            <>
              <div class="flex items-center justify-center">
                <p class="text-lg text-[#FF0000] text-justify">
                  Apologies, it seems we're unable to access microphone. To
                  utilize the call feature, please grant permission for
                  microphone access.
                </p>
              </div>
            </>
          ) : (
            <></>
          )}

          {airesponding ? (
            <>
              {isPlaying ? (
                <>
                  <div class="flex items-center justify-center">
                    <p class="text-lg font-semibold">
                      Tracky AI is answering...
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <div class="flex items-center justify-center">
                    <p class="text-lg font-semibold">paused</p>
                  </div>
                </>
              )}
            </>
          ) : (
            <></>
          )}
        </div>
      </ReactModal>
    </>
  );
}

export default CheckOnboard(CovoCraft);
