import React, { useEffect, useState, useRef } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { Helmet } from "react-helmet";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import correct_icn from "../../assets/correct_icn.svg";
import white_logo from "../../assets/logo_light.svg";
import edit_icn from "../../assets/edit-icn.svg";
import Check2 from "../../assets/Check2.svg";
import ReactModal from "react-modal";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  AddTemplateGallary,
  GetSingleTemplateData,
  UpdatePitchTemplateGallary,
  resertSingleTemplate,
} from "../../redux/slices/templateSlice.js";
import Swal from "sweetalert2";
import {
  sendInitialPitchData,
  UserFromPitchGeneratorFun,
  getAllPitch,
  renamePitch,
} from "../../redux/slices/PitchSlice.js";
import * as ObjectID from "bson-objectid";
import SidebarPitchListSkeleton from "../../CommonComponent/skeletons/SidebarPitchListSkeleton";
import back_icn from "../../assets/back_icn.svg";
import Loader from "../../CommonComponent/Loader.jsx";
import Pitch_History from "../../assets/Pitch_History.svg";


const sectionContent = [
  {
    id: 0,
    title: "Company Details",
    description:
      "Information about the company that your are pitching towards.",
    example: "Example:company name, product, service",
    question: "Tell us about your company:",
  },
  {
    id: 1,
    title: "Who are you calling",
    description:
      "Give Tracky AI some general information about the person you are trying to reach.",
    question: "What is your desired outcome or goal?",
  },
  {
    id: 2,
    title: "Audience",
    description:
      "explain your target audience and why this company could be a great fit",
    question: "Who is your target audience or customers?",
  },
  {
    id: 3,
    title: "Desired outcome",
    description: "explain your desired outcome of this call.",
    example:
      "Example: Booking a next meeting or sending over the contract via email",

    question: "Highlight key features of your product or service:",
  },
  {
    id: 4,
    title: "Current pain points",
    description:
      " What are some pain points you are currently experiencing while talking to prospects?",
    question: "What are the current pain points or challenges?",
  },
];

const validationSchema = [
  Yup.object({
    answer_0: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
    role: Yup.string().required("Please select role"),
  }),
  Yup.object({
    answer_1: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
    role: Yup.string().required("Please select role"),
  }),
  Yup.object({
    answer_2: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
    role: Yup.string().required("Please select role"),
  }),
  Yup.object({
    answer_3: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
    role: Yup.string().required("Please select role"),
  }),
  Yup.object({
    answer_4: Yup.string()
      .required("Answer is required")
      .max(150, "Answer must be at most 150 characters"),
    role: Yup.string().required("Please select role"),
  }),
];

const templateModalValidationSchema = Yup.object().shape({
  title: Yup.string()
    .required("Title is required")
    .matches(/^\S.*$/, "Title cannot start with a space")
    .matches(/^\D.*$/, "Title cannot start with a number")
    .max(15, "Title must be at most 15 characters"),

  bio: Yup.string()
    .required("Bio is required")
    .matches(/^\S.*$/, "Bio cannot start with a space")
    .matches(/^\D.*$/, "Bio cannot start with a number")
    .max(20, "Bio must be at most 20 characters"),

  template_type: Yup.string()
    .required("Type is required")
    .matches(/^\S.*$/, "Type cannot start with a space")
    .matches(/^\D.*$/, "Type cannot start with a number"),
});

function EditPitch() {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const PersonalinfoData = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData?.profileData
  );
  const SingleTemplateData = useSelector(
    (state) => state?.root?.template?.singleTemplateData
  );

  const isLoader = useSelector(
    (state) => state?.root?.template?.GetAllTempGallaryLoad
  );
  const loginData = useSelector((state) => state?.root?.auth);

  const [showShareModal, setShowShareModal] = useState(false);

  const [activePopup, setactivePopup] = useState(0);

  const [selectedSection, setSelectedSection] = useState(null);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [sectionSaved, setSectionSaved] = useState([]);

  const [selectedRole, setSelectedRole] = useState("");
  const [savedRole, setSavedRole] = useState("");

  const [answers, setAnswers] = useState({});
  const [newpayload, setNewpayload] = useState({});
  const [initialValues, setInitialValues] = useState([]);
  const [templateData, setTemplateData] = useState({});

  const [filldanswers, setFilldanswers] = useState(
    localStorage.getItem(selectedSection)
  );
  const location = useLocation();
  const [role, setRole] = useState(PersonalinfoData?.role?._id);
  const currentValidationSchema = showTemplateModal
    ? templateModalValidationSchema
    : validationSchema[activePopup];

  const [showInputID, setShowInputID] = useState(null);
  const [renamechat, setRenameChat] = useState("");
  const [editerror, setEditerror] = useState("");
  const [showHistoryBar,setShowHistoryBar] = useState(false)

  const [CurrentrenamechatID, setCurrentRenameChatID] = useState(null);
  const inputRef = useRef(null);

  const allPitchData = useSelector((state) => state?.root?.pitch?.allPitchData);
  const updatetemplateloading = useSelector(
    (state) => state?.root?.template?.addtemplateloading
  );

  const getPitchLoading = useSelector(
    (state) => state?.root?.pitch?.getPitchLoading
  );

  const currentDate = new Date();
  currentDate.setHours(0, 0, 0, 0);

  const todayData = allPitchData?.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    createdAtDate.setHours(0, 0, 0, 0); // Set hours, minutes, seconds, and milliseconds to 0 for accurate date comparison
    return createdAtDate.getTime() === currentDate.getTime();
  });

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(currentDate.getDate() - 7);

  const previous7DaysData = allPitchData?.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    createdAtDate.setHours(0, 0, 0, 0);
    return createdAtDate >= sevenDaysAgo && createdAtDate < currentDate;
  });

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(currentDate.getDate() - 30);

  const eightDaysAgo = new Date();
  eightDaysAgo.setDate(currentDate.getDate() - 8);
  const previous8to30DaysData = allPitchData.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    return createdAtDate > thirtyDaysAgo && createdAtDate <= eightDaysAgo;
  });

  const before30DaysData = allPitchData.filter((item) => {
    const createdAtDate = new Date(item.createdAt);
    return createdAtDate < thirtyDaysAgo;
  });

  const {
    handleSubmit,
    register,
    setValue,
    trigger,
    reset,
    clearErrors,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(currentValidationSchema),
    mode: "all",
  });

  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const openModal = (sectionId) => {
    setShowShareModal(true);
    setSelectedSection(sectionId);
    setactivePopup(sectionId);
  };

  const closeModal = (id) => {
    initialValues?.template?.forEach(({ key, value }) => {
      const matchingContent = sectionContent?.find(
        (content) => content?.description === key
      );
      const updatedAnswers = {};
      if (matchingContent) {
        updatedAnswers[matchingContent?.description] = value;

        // Set the value in the textarea
        setValue(`answer_${matchingContent?.id}`, value);
      }
    });
    setSelectedRole(initialValues.selected_role);
    setValue("role", initialValues.selected_role);

    setShowShareModal(false);
    setSelectedSection(null);
    clearErrors();
  };

  const handleDoneButtonClick = async (id, filldanswers) => {
    localStorage.setItem(id, filldanswers);
    localStorage.setItem("roles", selectedRole);
    setSectionSaved((prev) => [...prev, id]);

    // Use the previous selected role for the payload
    const roleToUse = savedRole || selectedRole;

    // Proceed with the API call
    const templatePayload = {
      template: Object.keys(answers).map((key) => ({
        key: key,
        value: answers[key],
      })),
      role: roleToUse, // Use the preserved or selected role
      selected_role: selectedRole,
    };

    setShowShareModal(false);
    // Dispatch or handle the templatePayload here
  };

  const handleSaveTemplate = async () => {
    // const areAllTextareasEmpty = sectionContent.every((content) => {
    //   const answer = answers[content.description];
    //   return !answer || answer.trim().length === 0;
    // });

    if (
      SingleTemplateData?.template?.length === 0 &&
      SingleTemplateData?.template == null
    ) {
      Swal.fire({
        background: "#373839",
        color: "#ffffff",
        confirmButtonColor: "#2EDE9F",
        confirmButtonText: "Okay",
        icon: "warning",
        title: "Please fill at least one textarea before saving as a template.",
        showClass: {
          popup: `
      animate__animated
      animate__fadeInUp
      animate__faster
    `,
        },
        hideClass: {
          popup: `
      animate__animated
      animate__fadeOutDown
      animate__faster
    `,
        },
      });
      return;
    }

    // Proceed with API call
    const templatePayload = {
      template: Object.keys(answers).map((key) => ({
        key: key,
        value: answers[key],
      })),
      role,
      selected_role: selectedRole,
    };

    setShowTemplateModal(true);
  };

  const saveModalClose = () => {
    setShowTemplateModal(false);
  };

  const handleEditChange = (e) => {
    const inputValue = e.target.value;
    if (inputValue.length <= 15) {
      setRenameChat(inputValue);
      setEditerror("");
    } else {
      setEditerror("Maximum 15 characters allowed.");
    }
  };

  const handleAnswerChange = async (event, id) => {
    setValue(`answer_${id}`, event.target.value);

    await trigger(`answer_${id}`);

    const currentSection = sectionContent.find(
      (content) => content.id === selectedSection
    );

    if (currentSection) {
      setAnswers({
        ...answers,
        [currentSection.description]: event.target.value,
      });
      setFilldanswers(event.target.value);

      // localStorage.setItem(id, event.target.value);
    }
  };

  useEffect(() => {
    dispatch(GetSingleTemplateData(id, auth));
  }, [id]);

  useEffect(() => {
    if (SingleTemplateData) {
      setInitialValues(SingleTemplateData);
      const {
        template,
        role,
        template_type,
        template_title,
        template_discription,
        selected_role,
      } = SingleTemplateData;

      const updatedAnswers = { ...answers };

      // Match content.description with key and update value
      template?.forEach(({ key, value }) => {
        const matchingContent = sectionContent?.find(
          (content) => content?.description === key
        );
        setSectionSaved((prev) => [...prev, matchingContent?.id]);

        if (matchingContent) {
          updatedAnswers[matchingContent?.description] = value;

          // Set the value in the textarea
          // setSectionSaved(key);
          setValue(`answer_${matchingContent?.id}`, value);
        }
      });

      // Update the state with the extracted values
      setAnswers(updatedAnswers);
      setRole(role);
      setSelectedRole(selected_role);

      // Also update the form with the extracted values
      setValue("title", template_title);
      setValue("bio", template_discription);
      setValue("template_type", template_type);
    }
    return () => {
      dispatch(resertSingleTemplate());
    };
  }, [SingleTemplateData, closeModal]);

  const onSubmit = async (data) => {
    const isValid = await trigger();

    if (isValid) {
      let templatePayload = {
        template: Object.keys(answers).map((key) => ({
          key: key,
          value: answers[key],
        })),
        role,
        selected_role: selectedRole,
        template_type: data?.template_type,
        template_title: data?.title,
        template_discription: data?.bio,
      };

      // Dispatch or handle the templatePayload here
      await dispatch(
        UpdatePitchTemplateGallary(
          templatePayload,
          id,
          auth,
          reset,
          navigate,
          setShowTemplateModal,
          setSelectedRole,
          setAnswers,
          setSectionSaved,
          setSavedRole
        )
      );
    }
  };
  useEffect(() => {
    let myItem = localStorage.getItem("persist:root");
    localStorage.clear();
    localStorage.setItem("persist:root", myItem);
    // setSelectedRole(null);
  }, [location]);

  useEffect(() => {
    dispatch(getAllPitch(auth));
  }, []);

  const handleMakePitch = async (data) => {
    const areAllTextareasEmpty = sectionContent.every((content) => {
      const answer = answers[content.description];
      return !answer || answer.trim().length === 0;
    });

    if (areAllTextareasEmpty) {
      Swal.fire({
        background: "#373839",
        color: "#ffffff",
        confirmButtonColor: "#2EDE9F",
        confirmButtonText: "Okay",
        icon: "warning",
        title: "Please fill at least one textarea before making a pitch",
        showClass: {
          popup: `
      animate__animated
      animate__fadeInUp
      animate__faster
    `,
        },
        hideClass: {
          popup: `
      animate__animated
      animate__fadeOutDown
      animate__faster
    `,
        },
      });
      return;
    }

    const pitchPayload = {
      template: Object.keys(answers).map((key) => ({
        key: key,
        value: answers[key],
      })),
      role,
      selected_role: selectedRole,
      user_prompt: data.user_prompt,
    };

    const a = new ObjectID();
    const b = a.toString();

    const saveUserFirstPrompts = {
      pitchPayload: pitchPayload,
      mongodbid: b,
    };

    if (b && b !== null && b !== undefined) {
      dispatch(UserFromPitchGeneratorFun(true));
      dispatch(sendInitialPitchData(saveUserFirstPrompts));
      // setValue("");
      reset();
      setShowTemplateModal(false);
      setSelectedRole("");
      setAnswers("");
      setSectionSaved([]);
      setSavedRole("");
      let myItem = localStorage.getItem("persist:root");
      localStorage.clear();
      localStorage.setItem("persist:root", myItem);
      navigate(`/pitch?chat=${b}`, { state: { step: 1 } });
    }
  };

  const validationSchema2 = Yup.object().shape({
    user_prompt: Yup.string()
      .required("Please enter message")
      .max(100, "Messsage must be at most 100 characters"),
  });

  const {
    register: register2,
    control: control2,
    handleSubmit: handleSubmit2,
    formState: { errors: errors2 },
    clearErrors: clearErrors2,
    setError: setError2,
    reset: reset2,
    resetField: resetField2,
    unregister: unregister2,
    setValue: setValue2,
  } = useForm({
    mode: "all",
    resolver: yupResolver(validationSchema2),
  });

  const {
    register: register3,
    control: control3,
    handleSubmit: handleSubmit3,
    formState: { errors: errors3 },
    clearErrors: clearErrors3,
    setError: setError3,
    reset: reset3,
    resetField: resetField3,
    unregister: unregister3,
    setValue: setValue3,
  } = useForm({
    mode: "all",
  });

  const openThisChat = (chatId) => {
    dispatch(UserFromPitchGeneratorFun(false));
    navigate(`/pitch?chat=${chatId}`, { state: { step: 2 } });
  };

  const takeInputForChatName = (chatID, defaultName) => {
    // if (showInputID) {
    //   setShowInputID(null);
    //   setCurrentRenameChatID(null);
    // } else {
    setCurrentRenameChatID(chatID);
    setShowInputID(chatID);
    setRenameChat(defaultName);
    setEditerror("");
    // }
  };

  const renameThisChat = (chatID) => {
    if (renamechat == "" || renamechat == undefined || editerror) {
      // setShowInputID(null);
      // setCurrentRenameChatID(null);
      // setRenameChat("");
      return;
    }
    const formData = { name: renamechat };
    dispatch(
      renamePitch(
        auth,
        chatID,
        formData,
        setShowInputID,
        setCurrentRenameChatID,
        setRenameChat
      )
    );
    // setShowInputID(null);
    // setCurrentRenameChatID(null);
    // setRenameChat("");
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      renameThisChat(CurrentrenamechatID);
    }
    if (event.key === " " && event.target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  const RedirectToTemplateGallery = () => {
    navigate("/templategallery");
  };

  const closeEditRenameFun = () => {
    setShowInputID(null);
    setCurrentRenameChatID(null);
    setRenameChat("");
  };

  const HandleHistoryBar = () =>{
    setShowHistoryBar(true);
  }

  const closeShowHistoryBar = () =>{
    setShowHistoryBar(false);
  }

  return (
    <>
      <Helmet>
        <title>Tracky | Pitch generator</title>
        <meta name="description" content="Tracky | Pitch generator" />
      </Helmet>
      <div className="FirstDiv ">
        <div className="dark-bg p-6 lg:h-[calc(100vh-80px)] h-full relative md:static">
          {/* <div className="text-[#ffffff]"> */}
            <div className="md:flex">
              <div className="md:w-4/5" onClick={closeEditRenameFun}>
                <div className="flex flex-row-reverse items-center m-3">
                <img src={Pitch_History} alt="back icon" className="block w-8 h-8 cursor-pointer md:hidden" onClick={HandleHistoryBar} title="Show history"/>
                  <button
                    className="bg-transparent  text-[15px] font-medium text-[#ffffff]
                               w-auto hover:bg-[#21CE90] hover:text-[#fff] py-2 px-4 hover:rounded-[8px]
                               flex items-center justify-end  "
                  onClick={RedirectToTemplateGallery}
                  type="button"
                >
                  <img src={back_icn} alt="back icon" className="me-4" />
                  Back
                </button>
              </div>

              <div className="content-center w-full grid-flow-row p-4 mx-auto md:pb-6 auto-rows-max flex flex-col justify-between h-[calc(100%-43px)]">
                <div className="px-[30px] flex flex-col items-center content-center">
                  <p className="text-[24px] md:text-[50px] text-[#939393] font-medium text-center">
                    Lets close the next deal
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 md:gap-4 place-content-between md:mt-20">
                    {sectionContent?.map((content, index) => (
                      <div
                        key={content.id + 1}
                        className="rounded-[8px] border border-[#BFBFBF] bg-transparent
                    py-[10px] px-10 md:px-12  cursor-pointer w-full
                  text-[#ffffff] text-[16px] text-center mt-8 md:mt-0 grow hover:bg-[#2ede9f] hover:text-black"
                        onClick={() => openModal(content.id)}
                      >
                        <div className="flex items-start justify-between w-full text-left me-4">
                          <span className="">
                            {content?.id + 1}. {content?.title}
                          </span>
                          {sectionSaved.includes(content.id) && (
                            <img src={correct_icn} alt="correct icon" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                {/*input form start here*/}
                <div className="md:px-[25px] flex flex-col md:flex-row items-center content-center">
                  <div className="grid w-full">
                    <form onSubmit={handleSubmit2(handleMakePitch)}>
                      <div className="flex flex-col mt-6 md:gap-6 md:flex-row md:mt-0">
                        <div className="w-full md:w-1/2">
                          <input
                            className="w-full md:w-[100%] text-[16px] border-slate-200 placeholder-[#6B7280] text-[#ffffff]
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent]"
                            type="text"
                            placeholder="Type your message..."
                            {...register2("user_prompt", {
                              required: "required",
                            })}
                            onKeyPress={handleKeyDown}
                          />
                          {/* <span className="text-[#FF0000] text-sm">
                              {errors2.user_prompt &&
                                errors2.user_prompt.type === "required" &&
                                "Please enter your message"}
                            </span> */}
                          {errors2.user_prompt && (
                            <p className="text-[#FF0000] text-sm">
                              {errors2.user_prompt.message}
                            </p>
                          )}
                        </div>
                        <div className="w-full mt-4 md:w-1/2 md:mt-0">
                          <div className="flex flex-col items-center justify-start md:flex-row">
                            <button
                              className="rounded-[8px] bg-transparent border-2 text-[#ffffff]
                               border-[#ffffff] text-[15px] font-medium
                               py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-4 md:mb-0 grow"
                              onClick={handleSaveTemplate}
                              type="button"
                            >
                              Save as Template
                            </button>
                            <button
                              className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow"
                              // onClick={() => openModal(selectedSection)}
                              type="submit"
                            >
                              Make pitch
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>

              <div className={`md:block md:w-1/5 bg-[#262626] overflow-auto py-[20px] px-[20px] h-[80vh] max-h-full ${showHistoryBar ? "block w-60 absolute top-0 right-0 ease-in duration-300 md:static" : "hidden"}`}>
                <div className="flex flex-col items-start justify-start float-left w-full h-full">
                  <div className="flex flex-row justify-between w-full">
                    <img
                      src={white_logo}
                      alt="logo light"
                      className="w-[50%]"
                    />
                                        <button className={`${showHistoryBar ? "block md:hidden": "hidden md:hidden"}`} onClick={closeShowHistoryBar} title="Close history">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="#ffffff"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18 18 6M6 6l12 12"
                  />
                </svg>
              </button>
                  </div>
                  {/* <div className="w-full my-4">
                    <ul class="list-none w-full">
                      <li className="flex my-2">
                        <span className="text-[16px] w-[80%]">New chat</span>
                        <span className="text-[14px] w-[20%] cursor-pointer">
                          <img src={edit_icn} alt="edit icon" />
                        </span>
                      </li>
                      <li className="mt-8 ">
                        <p className="text-[14px] text-[#848484] w-[80%]">
                          Previous 7 days
                        </p>
                        <p className="text-[16px] w-[80%]">New chat</p>
                      </li>
                      <li className="mt-8 ">
                        <p className="text-[14px] text-[#848484] w-[80%]">
                          Previous 30 days
                        </p>
                        <p className="text-[16px] w-[80%] mb-2">Pitch 12-12</p>
                        <p className="text-[16px] w-[80%] mb-2">Pitch for...</p>
                        <p className="text-[16px] w-[80%] mb-2">
                          Pitch for monday
                        </p>
                        <p className="text-[16px] w-[80%] mb-2">New chat</p>
                        <p className="text-[16px] w-[80%]">Pitch 12-12</p>
                      </li>
                    </ul>
                  </div> */}
                <div className="w-full h-full my-4">
                  <ul class="list-none w-full  overflow-y-auto text-[#ffffff]">
                    {getPitchLoading ? (
                      <SidebarPitchListSkeleton />
                    ) : (
                      <>
                      {todayData &&
                          todayData?.length > 0 && (
                            <>
                            <p className="mt-1"> </p>
                              {todayData?.map((data, index) => {
                                return (
                                  <>
                                    <div
                                      className="cursor-pointer flex justify-between group relative items-start hover:bg-[#1F1F1F]"
                                      key={index}
                                    >
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <>
                                          <div className="flex flex-col">
                                            <input
                                              className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                              type="text"
                                              placeholder="Rename chat..."
                                              // {...register2("name", {
                                              //   required: "required",
                                              // })}
                                              autoFocus
                                              name="name"
                                              value={renamechat}
                                              onChange={handleEditChange}
                                              onKeyPress={handleKeyPress}
                                              ref={inputRef}
                                            />
                                            {editerror && (
                                              <p className="text-sm text-red-500">
                                                {editerror}
                                              </p>
                                            )}
                                          </div>
                                        </>
                                      ) : (
                                        <p
                                          className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                          onClick={() => {
                                            openThisChat(data._id);
                                          }}
                                          title="Open chat"
                                        >
                                          {data.name}
                                        </p>
                                      )}
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <img
                                          src={Check2}
                                          alt="Rename"
                                          onClick={() => {
                                            renameThisChat(data._id);
                                          }}
                                          className="m-1"
                                          title="Save"
                                        />
                                      ) : (
                                        <img
                                          src={edit_icn}
                                          alt="edit icon"
                                          className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                          onClick={() => {
                                            takeInputForChatName(data._id);
                                          }}
                                          title="Rename pitch"
                                        />
                                      )}
                                    </div>
                                  </>
                                );
                              })}
                            </>
                          )}

                        {previous7DaysData && previous7DaysData.length > 0 && (
                          <>
                            <p className="text-[14px] text-[#848484] w-[80%]">
                              Previous 7 days
                            </p>
                            {previous7DaysData?.map((data, index) => {
                              return (
                                <>
                                  <div
                                    className="cursor-pointer flex justify-between group relative hover:bg-[#1F1F1F]"
                                    key={index}
                                  >
                                    {showInputID && showInputID == data._id ? (
                                      <>
                                        <div className="flex flex-col">
                                          <input
                                            className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                            type="text"
                                            placeholder="Rename chat..."
                                            // {...register2("name", {
                                            //   required: "required",
                                            // })}
                                            autoFocus
                                            name="name"
                                            value={renamechat}
                                            onChange={handleEditChange}
                                            onKeyPress={handleKeyPress}
                                            ref={inputRef}
                                          />
                                          {editerror && (
                                            <p className="text-sm text-red-500">
                                              {editerror}
                                            </p>
                                          )}
                                        </div>
                                      </>
                                    ) : (
                                      <p
                                        className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                        onClick={() => {
                                          openThisChat(data._id);
                                        }}
                                        title="Open chat"
                                      >
                                        {data.name}
                                      </p>
                                    )}
                                    {showInputID && showInputID == data._id ? (
                                      <img
                                        src={Check2}
                                        alt="Rename"
                                        onClick={() => {
                                          renameThisChat(data._id);
                                        }}
                                        title="Save"
                                            className="m-1"
                                      />
                                    ) : (
                                      <img
                                        src={edit_icn}
                                        alt="edit icon"
                                        className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                        onClick={() => {
                                          takeInputForChatName(
                                            data._id,
                                            data.name
                                          );
                                        }}
                                        title="Rename pitch"
                                      />
                                    )}
                                  </div>
                                </>
                              );
                            })}
                          </>
                        )}

                        {previous8to30DaysData &&
                          previous8to30DaysData.length > 0 && (
                            <>
                              <p className="text-[14px] text-[#848484] w-[80%]">
                                Previous 30 days
                              </p>
                              {previous8to30DaysData?.map((data, index) => {
                                return (
                                  <>
                                    <div
                                      className="cursor-pointer flex justify-between group relative hover:bg-[#1F1F1F]"
                                      key={index}
                                    >
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <>
                                          <div className="flex flex-col">
                                            <input
                                              className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                              type="text"
                                              placeholder="Rename chat..."
                                              // {...register2("name", {
                                              //   required: "required",
                                              // })}
                                              autoFocus
                                              name="name"
                                              value={renamechat}
                                              onChange={(e) => {
                                                setRenameChat(e.target.value);
                                              }}
                                              onKeyPress={handleKeyPress}
                                              ref={inputRef}
                                            />
                                            {editerror && (
                                              <p className="text-sm text-red-500">
                                                {editerror}
                                              </p>
                                            )}
                                          </div>
                                        </>
                                      ) : (
                                        <p
                                          className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                          onClick={() => {
                                            openThisChat(data._id);
                                          }}
                                          title="Open chat"
                                        >
                                          {data.name}
                                        </p>
                                      )}
                                      {showInputID &&
                                      showInputID == data._id ? (
                                        <img
                                          src={Check2}
                                          alt="Rename"
                                          onClick={() => {
                                            renameThisChat(data._id);
                                          }}
                                          title="Save"
                                          className="m-1"
                                        />
                                      ) : (
                                        <img
                                          src={edit_icn}
                                          alt="edit icon"
                                          className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                          onClick={() => {
                                            takeInputForChatName(data._id);
                                          }}
                                          title="Rename pitch"
                                        />
                                      )}
                                    </div>
                                  </>
                                );
                              })}
                            </>
                          )}

                        {before30DaysData && before30DaysData.length > 0 && (
                          <>
                            <p className="text-[14px] text-[#848484] w-[80%]">
                              Before 30 days
                            </p>
                            {before30DaysData?.map((data, index) => {
                              return (
                                <>
                                  <div
                                    className="cursor-pointer flex justify-between group relative hover:bg-[#1F1F1F]"
                                    key={index}
                                  >
                                    {showInputID && showInputID == data._id ? (
                                      <>
                                        <div className="flex flex-col">
                                          <input
                                            className="rounded-[4px] border border-[#BFBFBF] bg-transparent cursor-pointer focus:border-0 focus:outline-none text-[#ffffff] text-[10px] text-left px-1	py-0 pl-2 ml-1"
                                            type="text"
                                            placeholder="Rename chat..."
                                            // {...register2("name", {
                                            //   required: "required",
                                            // })}
                                            autoFocus
                                            name="name"
                                            value={renamechat}
                                            onChange={(e) => {
                                              setRenameChat(e.target.value);
                                            }}
                                            onKeyPress={handleKeyPress}
                                            ref={inputRef}
                                          />
                                          {editerror && (
                                            <p className="text-sm text-red-500">
                                              {editerror}
                                            </p>
                                          )}
                                        </div>
                                      </>
                                    ) : (
                                      <p
                                        className="text-[16px] w-[80%] mb-1 mx-1 truncate ..."
                                        onClick={() => {
                                          openThisChat(data._id);
                                        }}
                                        title="Open chat"
                                      >
                                        {data.name}
                                      </p>
                                    )}
                                    {showInputID && showInputID == data._id ? (
                                      <img
                                        src={Check2}
                                        alt="Rename"
                                        onClick={() => {
                                          renameThisChat(data._id);
                                        }}
                                        title="Save"
                                        className="m-1"
                                      />
                                    ) : (
                                      <img
                                        src={edit_icn}
                                        alt="edit icon"
                                        className="absolute top-0 right-0 m-1 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                        onClick={() => {
                                          takeInputForChatName(data._id);
                                        }}
                                        title="Rename pitch"
                                      />
                                    )}
                                  </div>
                                </>
                              );
                            })}
                          </>
                        )}

                        {todayData?.length == 0 && before30DaysData?.length == 0 &&
                          previous8to30DaysData?.length == 0 &&
                          previous7DaysData?.length == 0 && (
                            <>
                              <p className="text-[16px] w-[80%] mb-1">
                                No Pitch history found
                              </p>
                            </>
                          )}
                      </>
                    )}
                  </ul>
                </div>
              </div>
            </div>
          </div>
          {/* </div> */}
        </div>
      </div>

      {sectionContent?.map((content, index) => {
        {
          /* return <FormModle content={content} />; */
        }
        return (
          <div className="">
            <ReactModal
              className=""
              key={content.id}
              isOpen={showShareModal && selectedSection === content.id}
              style={{
                content: {
                  maxWidth: "660px",
                  minWidth: "200px",
                  width: "auto",
                  height: "400px",
                  margin: "auto",
                  backgroundColor: "#272727",
                  color: "#ffffff",
                  borderRadius: "15px",
                  borderColor: "#5C5C5C",
                },
                overlay: {
                  backgroundColor: "rgba(0, 0, 0, 0.5)",
                },
              }}
            >
              <form
                onSubmit={handleSubmit(() =>
                  handleDoneButtonClick(content?.id, filldanswers)
                )}
              >
                <div className="flex flex-col justify-between p-4">
                  <div>
                    <p className="text-[18px] font-semibold">{`${content.title}:`}</p>
                    <p className="text-[16px] my-4">
                      {content.description}{" "}
                      <span className="font-semibold">
                        {content?.example ? content?.example : ""}
                      </span>
                    </p>
                    <div className="flex flex-col items-start mb-4 md:flex-row md:items-center">
                      <div>
                        <input
                          className="cursor-pointer"
                          type="radio"
                          id="gatekeeper"
                          {...register("role")}
                          value="gatekeeper"
                          checked={selectedRole === "gatekeeper"}
                          onChange={async (e) => {
                            setSelectedRole("gatekeeper");
                            setValue("role", e.target.value);
                            await trigger("role");
                          }}
                        />
                        <label
                          htmlFor="gatekeeper"
                          className="ml-2 cursor-pointer"
                        >
                          Gatekeeper
                        </label>
                      </div>
                      <div className="md:ms-6">
                        <input
                          type="radio"
                          id="persona"
                          {...register("role")}
                          value="persona"
                          checked={selectedRole === "persona"}
                          onChange={async (e) => {
                            setSelectedRole("persona");
                            setValue("role", e.target.value);
                            await trigger("role");
                          }}
                        />
                        <label
                          htmlFor="persona"
                          className="ml-2 cursor-pointer"
                        >
                          Persona
                        </label>
                        {errors && (
                          <p className="text-[#FF0000] text-sm">
                            {errors?.role?.message}
                          </p>
                        )}
                      </div>
                    </div>
                    <textarea
                      className="border rounded p-2 mt-4 w-full text-[#fff] text-[16px] bg-[#272727]"
                      {...register(`answer_${content?.id}`)}
                      placeholder={
                        content?.id === 1
                          ? "John is the owner of “company name"
                          : "Type here..."
                      }
                      onKeyPress={handleKeyDown}
                      defaultValue={localStorage.getItem(content?.id)}
                      onChange={(e) => handleAnswerChange(e, content?.id)}
                    />
                    {errors && (
                      <p className="text-[#FF0000] text-sm">
                        {errors[`answer_${content?.id}`]?.message}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col items-center justify-start mt-4 md:flex-row">
                    <button
                      className="rounded-[8px] bg-transparent border-2
                               border-[#ffffff] text-[15px] font-medium
                               py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] md:me-4 mb-4 md:mb-0 grow"
                      type="button"
                      onClick={() => closeModal(content?.id)}
                    >
                      Cancel
                    </button>
                    <button
                      className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow"
                      type="submit"
                      // onClick={() => handleDoneButtonClick(content?.id)}
                    >
                      Save
                    </button>
                  </div>
                </div>
              </form>
            </ReactModal>
          </div>
        );
      })}
      {showTemplateModal && (
        <ReactModal
          isOpen={showTemplateModal}
          onRequestClose={saveModalClose}
          style={{
            content: {
              maxWidth: "660px",
              minWidth: "200px",
              width: "auto",
              height: "400px",
              margin: "auto",
              backgroundColor: "#272727",
              color: "#ffffff",
              borderRadius: "15px",
              borderColor: "#5C5C5C",
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)", // Adjust the alpha channel as needed
            },
          }}
        >
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="flex flex-row justify-between">
              <p className="text-[25px] font-semibold">
                What’s the name of your template?
              </p>
              <button className="" onClick={saveModalClose}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18 18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            <hr className="mt-2" />
            <div className="flex flex-col p-4">
              <input
                type="text"
                className="w-full  md:w-[100%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] mb-4"
                {...register("title")}
                id="templateTitle"
                placeholder="Type here..."
                defaultValue={templateData.template_title}
              />
              {errors.title && (
                <p className="text-sm text-red-500">{errors.title.message}</p>
              )}

              <select
                id="templateDetails"
                className="w-full md:w-[100%] text-[16px]
                                bg-[#272727] border border-gray-300 text-white
                                rounded-lg focus:ring-blue-500 focus:border-blue-500 block  py-[10px] px-[15px]
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                 dark:focus:border-blue-500 mb-4"
                name="template_type"
                {...register("template_type")}
                defaultValue={templateData?.template_type}
              >
                <option value="personal">
                  Save to personal template gallery
                </option>
                <option value="community">
                  Save to community template gallery
                </option>
              </select>
              {errors.template_type && (
                <p className="text-sm text-red-500">
                  {errors.template_type.message}
                </p>
              )}

              <label htmlFor="bio" className="mb-2">
                Brief description of the template
              </label>
              <input
                type="text"
                className="w-full  md:w-[100%] text-[16px] border-slate-200 placeholder-white-400
                    contrast-more:border-slate-400 py-[10px] px-[15px]
                    rounded-[8px] focus:border-0 focus:outline-none
                    contrast-more:placeholder-white bg-[transparent] mb-4"
                {...register("bio")}
                id="bio"
                placeholder="Type here..."
                defaultValue={templateData?.template_discription}
              />
              {errors.bio && (
                <p className="text-sm text-red-500">{errors.bio.message}</p>
              )}
            </div>

            {/* Save as template button */}
            <div className="flex justify-end">
              <button
                className="rounded-[8px] border-2 border-[#21CE90] bg-[#21CE90]  text-[15px] font-medium
                            py-[10px] px-[30px] w-full md:w-[20%] hover:bg-[#ffffff] hover:text-[#000000] grow
                  "
                // onClick={() => onSubmit()}
                type="submit"
                disabled={updatetemplateloading}
              >
                {updatetemplateloading ? (
                  <>
                    <div
                      className="flex items-center content-center justify-center w-full "
                    >
                      <Loader />
                    </div>
                  </>
                ) : (
                  <> Save as template</>
                )}
              </button>
            </div>
          </form>
        </ReactModal>
      )}
    </>
  );
}

export default CheckOnboard(EditPitch);
