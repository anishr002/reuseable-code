import React, { useState, useEffect, useRef } from "react";
import { Helmet } from "react-helmet";
import { useLocation, useNavigate } from "react-router-dom";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import edit_icn from "../../assets/edit-icn.svg";
import back_arrow from "../../assets/back_arrow.svg";
import Tooltip from "../../CommonComponent/Tooltip";
import PitchChatSkeleton from "../../CommonComponent/skeletons/PitchChatSkeleton.jsx";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import { useDispatch, useSelector } from "react-redux";
import ReactModal from "react-modal";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { handleKeyDown } from "../../utils/SpaceValidation.js";
import ConvoCall from "../../assets/ConvoCall.svg";
import micro_phone from "../../assets/micro_phone.svg";
import play from "../../assets/play.svg";
import pause from "../../assets/pause.svg";
import convo_call_2 from "../../assets/convo_call_2.svg";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";

function Timer({ initialTime, onTimerEnd }) {
  const [time, setTime] = useState(initialTime);

  useEffect(() => {
    const timer = setInterval(() => {
      const newTime = time - 1;
      setTime(newTime);

      if (newTime <= 0) {
        clearInterval(timer);
        onTimerEnd();
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [time, onTimerEnd]);

  // Format time to mm:ss
  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes < 10 ? "0" : ""}${minutes}:${
      seconds < 10 ? "0" : ""
    }${seconds}`;
  };

  return (
    <div>
      <p class="text-lg font-semibold">{formatTime(time)} </p>
    </div>
  );
}

function ConvoHistory() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const Convoid = urlParams.get("cid");
  const loginData = useSelector((state) => state?.root?.auth);
  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const appEnv = `${process.env.REACT_APP_API_BASE_URL}`;

  const [showSkeleton, setShowSkeleton] = useState(false);
  const [messages, setMessages] = useState([]);

  const [showCallModal, setShowCallModal] = useState(false);

  const [recording, setRecording] = useState(false);
  const [airesponding, setAiResponding] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [convoFirstResLoading, setConvoFirstResLoading] = useState(false);
  const [canAccessMicrophone, setCanAccessMicrophone] = useState(true);

  // const [notFirstTime, setnotFirstTime] = useState(false);
  let FirstTime = true;

  const {
    transcript,
    interimTranscript,
    finalTranscript,
    resetTranscript,
    listening,
    browserSupportsSpeechRecognition,
    isMicrophoneAvailable,
    browserSupportsContinuousListening,
  } = useSpeechRecognition();

  const validationSchema = Yup.object().shape({
    user_prompt: Yup.string()
      .required("Please enter message")
      .max(100, "Messsage must be at most 100 characters"),
  });

  const {
    handleSubmit,
    register,
    setValue,
    trigger,
    reset,
    clearErrors,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    // mode: 'all',
  });

  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
  };

  function breakIntoParagraphs(data) {
    const sentences = data
      .split(".")
      .filter((sentence) => sentence.trim() !== ""); // Filter out empty sentences
    const paragraphs = [];
    let currentParagraph = "";
    let sentenceCount = 0;

    sentences.forEach((sentence, index) => {
      if (sentence !== "") {
        currentParagraph += sentence + ". ";
        sentenceCount++;

        // Break into a new paragraph after every 4 sentences or if it's the last sentence
        if (
          sentenceCount === 4 ||
          index === sentences.length - 1 ||
          index == 0
        ) {
          paragraphs.push({ currentParagraph });
          currentParagraph = "";
          sentenceCount = 0;
        }
      }
    });

    return paragraphs;
  }

  useEffect(() => {
    getSingleConvo(FirstTime);
  }, []);

  const redirectToNewChat = () => {
    navigate("/convocraft");
  };

  const startTimer = () => {
    const initialTime = 90;
    return <Timer initialTime={initialTime} onTimerEnd={endCall} />;
  };

  const getSingleConvo = async (FirstTime) => {
    const serverBaseURL = `${appEnv}pitch/get-pitch/${Convoid}`;

    if (FirstTime) {
      setShowSkeleton(true);
    }

    try {
      const response = await fetch(serverBaseURL, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Bearer ${auth}`,
        },
        // body: JSON.stringify({ user_prompt: `${inputText}` }),
      });

      const data = await response.json();
      if (data.success) {
        if (FirstTime) {
          setShowSkeleton(false);
        }

        let chatHistory = data.data.history;
        // let AddFirstIndex = {
        //   role: 'user',
        //   content: data.data.user_prompt,
        //   needToFormat: false,
        //   formattedContent: []
        // };
        // chatHistory?.map((data, index) => {

        // })
        // chatHistory.unshift(AddFirstIndex);
        chatHistory?.map((data, index) => {
          if (data.role == "assistant") {
            data.needToFormat = true;
            // data.formattedContent = breakIntoParagraphs(data.content);
            data.formattedContent = data.content;
          }
        });
        setMessages(chatHistory);
        setTimeout(function () {
          scrollToBottom();
        }, 500);
      } else {
        toast.error(data?.message);
        setShowSkeleton(false);
        navigate("/pitchgenerator");
      }

      if (FirstTime) {
        setShowSkeleton(false);
      }
    } catch (error) {
      if (FirstTime) {
        setShowSkeleton(false);
      }
    } finally {
    }
    if (FirstTime) {
      setShowSkeleton(false);
    }
  };

  const openCallModal = () => {
    setShowCallModal(true);
  };

  const closeCallModal = () => {
    setShowCallModal(false);
  };

  const handleStartConvoCall = (data) => {
    // sendUserMsgAndStartCall(data.user_prompt);
    sendUserMsgAndStartCall("");

    openCallModal();
  };

  const sendUserMsgAndStartCall = async (inputText) => {
    const serverBaseURL = `${appEnv}pitch/continue-call/${Convoid}`;
    setConvoFirstResLoading(true);

    try {
      const response = await fetch(serverBaseURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Bearer ${auth}`,
        },
        body: JSON.stringify({
          user_prompt: `${inputText}`,
        }),
      });

      if (response.ok) {
        // reset();
        try {
          const d = await response.arrayBuffer();

          const b = new Blob([d], { type: "audio/mpeg" });
          const u = URL.createObjectURL(b);
          audioRef.current.src = u;
          audioRef.current.play();
          setConvoFirstResLoading(false);
        } catch (e) {
          console.log(e);
        }
      } else {
        // Handle non-successful response here
        const errorMsgObj = await response.json();

        if (errorMsgObj.success == false) {
          toast.error(errorMsgObj?.message);
        }
        setConvoFirstResLoading(false);
      }
    } catch (error) {
      setConvoFirstResLoading(false);
    } finally {
    }
  };

  const audioRef = useRef(null);

  const handleAudioPlaying = () => {
    setAiResponding(true);
    setIsPlaying(true);
  };

  const handleAudioPlayComplete = () => {
    setAiResponding(false);
    setIsPlaying(false);
  };

  const handleAudioPause = () => {
    setIsPlaying(false);
  };

  const toggleAudio = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
  };

  const endCall = () => {
    SpeechRecognition.abortListening();
    resetTranscript();
    setRecording(false);
    setAiResponding(false);
    setIsPlaying(false);
    audioRef.current.pause();

    FirstTime = false;
    // refreshWholePage();
    getSingleConvo(FirstTime);
    closeCallModal();
    scrollToBottom();
    FirstTime = true;
  };

  const startRecording = () => {

    if (!browserSupportsSpeechRecognition) {
      toast.error(
        `Browser doesn't support speech recognition, update your browser or try using other browser`
      );
      return;
    }

    if (!isMicrophoneAvailable) {
      // toast.error(
      //   `In order to use call feature, you need to allow access to your microphone`
      // );
      setCanAccessMicrophone(false);
      return;
    }

    if(location.protocol == 'http:' && location.hostname !=='localhost' ){
      setCanAccessMicrophone(false);
      return;
    }




    navigator.mediaDevices
      .getUserMedia({ audio: true })
      .then(() => {
        if (browserSupportsContinuousListening) {
      SpeechRecognition.startListening({
        continuous: true,
      });
      setRecording(true);
    } else {
      SpeechRecognition.startListening();
      setRecording(true);
    }

      })
      .catch((error) => {
        setCanAccessMicrophone(false);
        return;
      });

    // if (browserSupportsContinuousListening) {
    //   SpeechRecognition.startListening({
    //     continuous: true,
    //   });
    //   setRecording(true);
    // } else {
    //   SpeechRecognition.startListening();
    //   setRecording(true);
    // }
  };

  const stopRecording = () => {
    SpeechRecognition.abortListening();

    if (transcript == "") {
      toast.error(`Please speak something again, we didn't recording anything`);
    } else {
      sendUserMsgAndStartCall(transcript);
    }
    resetTranscript();
    setRecording(false);
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Pitch</title>
        <meta name="description" content="Tracky | Tracy Pitch" />
      </Helmet>

      <div className="w-[100%]  z-0 md:z-auto h-[calc(100vh-80px)]">
        <div className="w-full p-2 md:p-[10px] bg-[#000000]  content  text-[#ffffff] content-wrapper">
          <div className="flex flex-row-reverse cursor-pointer pr-6">
            <Tooltip text="New convo craft" bgColor="bg-[#4d4d4d]">
              <img
                src={edit_icn}
                alt="edit icon"
                onClick={redirectToNewChat}
                className="ml-1 h-[35px]"
              />
            </Tooltip>
            <Tooltip text="Back" bgColor="bg-[#4d4d4d]">
              <img
                src={back_arrow}
                alt="back icon"
                onClick={redirectToNewChat}
                className="h-[45px]"
              />
            </Tooltip>
          </div>

          <div className="p-6 flex flex-col justify-between h-[calc(100%-45px)]">
            {showSkeleton ? (
              <PitchChatSkeleton />
            ) : (
              <>
                <div className=" w-full p-4 overflow-y-scroll h-screen max-h-[600px] md:max-h-[700px] pb-8">
                  {messages &&
                    messages.length !== 0 &&
                    messages.map((message, index) => (
                      <div key={index} className={`mb-5`}>

                      { message.content !== "" ? (<>
                        <p className="text-[20px]">
                          {message.role === "assistant" ? `Tracky Ai` : `You`}
                        </p>
                        <p className="text-justify">

                          {message?.needToFormat == true ? (
                            <>
                              {/* {message?.formattedContent.map(
                                (paragraph, index) => (
                                  <React.Fragment key={index}>
                                    <p key={index} className="">
                                      {paragraph.currentParagraph}
                                    </p>
                                    <br />
                                  </React.Fragment>
                                )
                              )} */}
                              <div className="w-[100%] text-justify font-sans font-inter">
                        <pre className="text-justify text-[16px] font-normal leading-6 whitespace-pre-line font-sans font-inter">
                          {message?.formattedContent}
                          </pre>
                          </div>
                            </>
                          ) : (
                            <>{message.content}</>
                          )}

                        </p>
                        </>) : (<></>)
                      }
                      </div>
                    ))}

                  {showSkeleton == false && messages.length == 0 ? (
                    <>
                      <p>No history found</p>
                    </>
                  ) : (
                    <></>
                  )}
                  <div ref={messagesEndRef} className="forScroll" />
                </div>
              </>
            )}

            {/* <form onSubmit={handleSubmit(handleStartConvoCall)}> */}
            <div className="flex flex-row-reverse justify-between mt-5">
              {/* <input
                className="rounded-[8px] border border-[#BFBFBF] bg-transparent
                    py-[10px]  cursor-pointer   focus:border-0 focus:outline-none
                  text-[#ffffff] text-[16px] text-left mt-8 md:mt-0 w-3/5"
                type="text"
                placeholder="Type your message..."
                onKeyPress={handleKeyDown}
                {...register("user_prompt")}
                autoComplete="off"
              /> */}

              <button
                className="rounded-[8px] border border-[#2EDE9F] text-[16px] text-white
                    cursor-pointer py-[10px] px-[10px] bg-transparent
                    hover:bg-[#2EDE9F] hover:text-white mt-4 md:mt-0 w-1/5"
                // type="submit"
                onClick={handleStartConvoCall}
              >
                Start call
              </button>
            </div>
            {/* {errors.user_prompt && (
                <p className="text-[#FF0000] text-sm">
                  {errors.user_prompt.message}
                </p>
              )} */}
            {/* </form> */}
          </div>
        </div>

        <ReactModal
          isOpen={showCallModal}
          // onRequestClose={
          //   closeCallModal
          // }
          style={{
            content: {
              // width: "648px",
              // height: "451px",
              // margin: "auto",
              // backgroundColor: "#373839",
              // color: "#ffffff",
              // borderRadius: "15px",

              maxWidth: "550px",
              minWidth: "250px",
              width: "auto",
              height: "445px",
              margin: "auto",
              backgroundColor: "#272727",
              color: "#ffffff",
              borderRadius: "15px",
              borderColor: "#5C5C5C",
            },
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.5)",
              opacity: 1,
            },
          }}
        >
          <div className="flex flex-row-reverse	justify-between items-center content-center mb-4">
            <Tooltip
              text={`${convoFirstResLoading ? "Please wait" : "End call"}`}
              bgColor="bg-[#4d4d4d]"
            >
              <button
                className=""
                onClick={endCall}
                disabled={convoFirstResLoading}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6 hover:stroke-[#2EDE9F]"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18 18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </Tooltip>
          </div>

          <div className="justify-center flex items-center">
            <img
              src={ConvoCall}
              alt="Convo Call"
              className="w-[217px] h-[217px]"
            />
          </div>

          <audio
            ref={audioRef}
            type="audio/mpeg"
            onPlay={handleAudioPlaying}
            onEnded={handleAudioPlayComplete}
            onPause={handleAudioPause}
          ></audio>

          <div className="justify-center flex items-center mt-2">
            {convoFirstResLoading ||
            airesponding ||
            canAccessMicrophone == false ? (
              <></>
            ) : (
              <>
                {recording ? (
                  <>
                    <Tooltip
                      text="Stop recording and send"
                      bgColor="bg-[#4d4d4d]"
                    >
                      <button
                        className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#2EDE9F] mx-2"
                        onClick={stopRecording}
                      >
                        <img src={micro_phone} alt="Convo Call" className="" />
                      </button>
                    </Tooltip>
                  </>
                ) : (
                  <>
                    <Tooltip text="Start recording" bgColor="bg-[#4d4d4d]">
                      <button
                        className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#656565] mx-2"
                        onClick={startRecording}
                      >
                        <img src={micro_phone} alt="Convo Call" className="" />
                      </button>
                    </Tooltip>
                  </>
                )}
              </>
            )}

            {/* <button className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#656565] mx-1">
            <img src={convo_call_1} alt="Convo Call" className="" />
          </button> */}

            <Tooltip
              text={`${convoFirstResLoading ? "Please wait" : "End Call"}`}
              bgColor="bg-[#4d4d4d]"
            >
              <button
                className={`rounded-full w-[50px] h-[50px] flex items-center justify-center  mx-2 ${
                  convoFirstResLoading ? "bg-[#AFAFAF] " : "bg-[#D60000]"
                }`}
                onClick={endCall}
                disabled={convoFirstResLoading}
              >
                <img src={convo_call_2} alt="Convo Call" className="" />
              </button>
            </Tooltip>

            {airesponding ? (
              <>
                {isPlaying ? (
                  <>
                    <Tooltip text="Pause" bgColor="bg-[#4d4d4d]">
                      <button
                        className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#2ede9f] mx-2"
                        onClick={toggleAudio}
                      >
                        <img src={pause} alt="Convo Call" className="" />
                      </button>
                    </Tooltip>
                  </>
                ) : (
                  <>
                    <Tooltip text="Play" bgColor="bg-[#4d4d4d]">
                      <button
                        className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#2ede9f] mx-2"
                        onClick={toggleAudio}
                      >
                        <img src={play} alt="Convo Call" className="" />
                      </button>
                    </Tooltip>
                  </>
                )}
              </>
            ) : (
              <></>
            )}

            {/* <Tooltip text="Restart Call" bgColor="bg-[#4d4d4d]">
            <button className="rounded-full w-[50px] h-[50px] flex items-center justify-center bg-[#656565] mx-2">
              <img src={convo_call_3} alt="Convo Call" className="" />
            </button>
          </Tooltip> */}
          </div>

          <div className="">
            {convoFirstResLoading ? (
              <>
                <div class="flex items-center justify-center">
                  <svg
                    class="animate-spin -ml-1 mr-3 h-6 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      class="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      stroke-width="4"
                    ></circle>
                    <path
                      class="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  <p class="text-lg font-semibold">processing...</p>
                </div>
              </>
            ) : (
              <></>
            )}

            {recording ? (
              <>
                <div class="flex items-center justify-center">
                  <p className="text-lg font-semibold">Recording...</p>
                  &nbsp; {startTimer()} &nbsp;
                </div>
                <div className="flex items-center justify-center">
                  <p className="text-sm">You can record maximum 1:30 minute</p>
                </div>
              </>
            ) : (
              <></>
            )}

            {canAccessMicrophone == false ? (
              <>
                <div class="flex items-center justify-center">
                  <p class="text-lg text-[#FF0000] text-justify">
                    Apologies, it seems we're unable to access microphone. To
                    utilize the call feature, please grant permission for
                    microphone access.
                  </p>
                </div>
              </>
            ) : (
              <></>
            )}

            {airesponding ? (
              <>
                {isPlaying ? (
                  <>
                    <div class="flex items-center justify-center">
                      <p class="text-lg font-semibold">
                        Tracky AI is answering...
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div class="flex items-center justify-center">
                      <p class="text-lg font-semibold">paused</p>
                    </div>
                  </>
                )}
              </>
            ) : (
              <></>
            )}
          </div>
        </ReactModal>
      </div>
    </>
  );
}

export default ConvoHistory;
