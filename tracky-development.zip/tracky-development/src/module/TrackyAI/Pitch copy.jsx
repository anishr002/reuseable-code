import React, { useState, useEffect, useRef } from "react";
import { Helmet } from "react-helmet";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import edit_icn from "../../assets/edit-icn.svg";
import back_arrow from "../../assets/back_arrow.svg";

import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { UserFromPitchGeneratorFun } from "../../redux/slices/PitchSlice.js";
import { toast } from "react-toastify";
import { ToastContent } from "../../CommonComponent/ToastContent";
import PitchChatSkeleton from "../../CommonComponent/skeletons/PitchChatSkeleton.jsx";
import Tooltip from "../../CommonComponent/Tooltip";
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { handleKeyDown } from '../../utils/SpaceValidation.js';


function Pitch() {
  const [messages, setMessages] = useState([]);
  // const [inputText, setInputText] = useState("");
  const [data, setData] = useState("");
  const [showSkeleton, setShowSkeleton] = useState(false);
  const [fetchingData, setFetchingData] = useState(false);

  const navigate = useNavigate();
  const location2 = useLocation();
  const dispatch = useDispatch();

  const validationSchema = Yup.object().shape({
    user_prompt: Yup.string()
      .required('Please enter message')
      .max(100, 'Messsage must be at most 100 characters'),
  });

  const {
    handleSubmit,
    register,
    setValue,
    trigger,
    reset,
    clearErrors,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    // mode: 'all',
  });

  const urlParams = new URLSearchParams(window.location.search);
  const firstChatid = urlParams.get("chat");
  const loginData = useSelector((state) => state?.root?.auth);
  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  const UserFirstPrompts = useSelector(
    (state) => state?.root?.pitch?.UserFirstPrompts
  );
  const UserFromPitchGenerator = useSelector(
    (state) => state?.root?.pitch?.UserFromPitchGenerator
  );

  const appEnv = `${process.env.REACT_APP_API_BASE_URL}`;

  let pitchPayload = UserFirstPrompts.pitchPayload;
  let mongodbID = UserFirstPrompts.mongodbid;
  let payload = {
    _id: UserFirstPrompts.mongodbid,
    ...pitchPayload,
  };
  let UserPrompts = 1;

//   function addNewlineAfterFullStop(inputString) {
//     const modifiedString = inputString.replace(/\./g, '.\n');
//     return modifiedString;
// }

// function addNewlineAfterFullStop(inputString) {
//   const modifiedString = inputString.replace(/\.([^\n])/g, (match, group) => {
//       if (group !== '\n') {
//           return '.\n \t' + group;
//       } else {
//           return match;
//       }
//   });
//   return modifiedString;
// }

// function addNewlineAfterFullStop(inputString) {
//   let outputString = "";
//   let previousChar = '';

//   for (let i = 0; i < inputString.length; i++) {
//       const currentChar = inputString[i];

//       if (currentChar === '.' && previousChar !== 'n') {
//           outputString += currentChar + '\n';
//       } else {
//           outputString += currentChar;
//       }

//       previousChar = currentChar;
//   }

//   return outputString;
// }


  // const newKey = '_id';
  // const newValue = `${UserFirstPrompts.mongodbid}`;
  // pitchPayload[newKey] = newValue;

  // const pitchPayload = {
  //   template: Object.keys(answers).map((key) => ({
  //     key: key,
  //     value: answers[key],
  //   })),
  //   role,
  //   selected_role: selectedRole,
  //   user_prompt: data.user_prompt
  // };

  // const returnedTarget = Object.assign(pitchPayload, { _id: UserFirstPrompts.mongodbid });

  const messagesEndRef = useRef(null);

  const LastMessagesRef = useRef(null);

  const lastMessageRef = useRef(null);

  const messagesEndRefStream = useRef(null);

  const scrollToBottomToStream = () => {
    if (messagesEndRefStream.current) {
      messagesEndRefStream.current.scrollIntoView({ behavior: "smooth" });
    }
  };


  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollTolastMessageRef = () => {
    if (lastMessageRef.current) {
      lastMessageRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  function breakIntoParagraphs(data) {
    const sentences = data
      .split(".")
      .filter((sentence) => sentence.trim() !== ""); // Filter out empty sentences
    const paragraphs = [];
    let currentParagraph = "";
    let sentenceCount = 0;

    sentences.forEach((sentence, index) => {
      if (sentence !== "") {
        currentParagraph += sentence + ". ";
        sentenceCount++;

        // Break into a new paragraph after every 4 sentences or if it's the last sentence
        if (
          sentenceCount === 4 ||
          index === sentences.length - 1 ||
          index == 0
        ) {
          paragraphs.push({ currentParagraph });
          currentParagraph = "";
          sentenceCount = 0;
        }
      }
    });

    return paragraphs;
  }

  const InitialfetchData = async () => {
    const newMessage = {
      content: pitchPayload?.user_prompt,
      role: "user",
    };
    setMessages([...messages, newMessage]);

    const serverBaseURL = `${appEnv}pitch/new-pitch`;
    let completeString = "";

    try {
      setShowSkeleton(true);
      const response = await fetch(serverBaseURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Bearer ${auth}`,
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        setShowSkeleton(false);
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        UserPrompts = UserPrompts + 1;
        while (true) {
          const { value, done } = await reader.read();
          if (done) {
            // let completeStringWithFormat = breakIntoParagraphs(completeString);
            // let completeStringWithFormat = addNewlineAfterFullStop(completeString);

            const responseAIMessage = {
              content: `${completeString}`,
              role: "assistant",
              needToFormat: true,
              formattedContent: completeString,
            };
            setMessages((prev) => [...prev, responseAIMessage]);
            setData("");
            scrollToBottom();
            break;
          }

          // return false;
          try {
            const decoded = decoder.decode(value, {
              stream: true,
            });

            // const stringWithNewlines = addNewlineAfterFullStop(decoded)

            // setTimeout(function(){
            // setData((prev) => prev + stringWithNewlines);
              // }, 100);

            setData((prev) => prev + decoded);
            scrollToBottom();
            completeString += decoder.decode(value, {
              stream: true,
            });
          } catch (error) { }
        }
      } else {
        // Handle non-successful response here
        setShowSkeleton(false);
        const errorMsgObj = await response.json();

        if (errorMsgObj.success == false) {
          toast.error(errorMsgObj?.message);
        }
        // navigate("/pitchgenerator");
      }
      setShowSkeleton(false);
    } catch (error) {
      setShowSkeleton(false);
      // let completeStringWithFormat = breakIntoParagraphs(completeString);
      // let completeStringWithFormat = addNewlineAfterFullStop(completeString);

      const responseAIMessage = {
        content: `${completeString}`,
        role: "assistant",
        needToFormat: true,
        formattedContent: completeString,
      };
      setMessages((prev) => [...prev, responseAIMessage]);
      setData("");
      scrollToBottom();
    } finally {
    }
  };

  useEffect(() => {
    // if (
    // location2.state !== null &&
    // location2.state !== undefined &&
    // location2.state.step
    // ) {
    //   if (location2.state.step == 1) {
    //     setComeFromChangeEmail(true);
    //     setTimeout(() => {
    //       dispatch(resetStep());
    //     }, 1000);
    //   }
    // }
    if (firstChatid == null) {
      navigate("/pitchgenerator");
    } else if (
      // firstChatid != null && location2.state !== null &&
      // location2.state !== undefined &&
      // location2.state.step && location2.state.step == 1
      UserFromPitchGenerator == true
    ) {
      InitialfetchData();
      dispatch(UserFromPitchGeneratorFun(false));
    } else if (firstChatid != null && UserFromPitchGenerator == false) {
      getSinglePitch();
    }
    //eslint-disable-next-line
  }, []);

  // const handleInputChange = (e) => {
  //   setInputText(e.target.value);
  // };

  const handleSendMessage = (data) => {
    // if (inputText.trim() === "") return;

    const newMessage = {
      content: data?.user_prompt,
      role: "user",
      needToFormat: false,
      // formattedContent: [],
      formattedContent: '',
    };
    setMessages([...messages, newMessage]);
    // scrollToBottom();
    // scrollToLastBottomInMsg();
    // scrollTolastMessageRef();

    setTimeout(function () {
      scrollTolastMessageRef();
    }, 500);

    fetchData(data?.user_prompt);
    // setInputText("");
    reset();
  };

  // const handleKeyPress = (event) => {
  //   if (event.key === "Enter") {
  //     handleSendMessage();
  //   }
  //   if (event.key === " " && event.target.selectionStart === 0) {
  //     event.preventDefault();
  //   }
  // };

  const getSinglePitch = async () => {
    const serverBaseURL = `${appEnv}pitch/get-pitch/${firstChatid}`;

    try {
      setShowSkeleton(true);
      const response = await fetch(serverBaseURL, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Bearer ${auth}`,
        },
        // body: JSON.stringify({ user_prompt: `${inputText}` }),
      });

      const data = await response.json();
      if (data.success) {
        setShowSkeleton(false);
        let chatHistory = data.data.history;
        let AddFirstIndex = {
          role: "user",
          content: data.data.user_prompt,
          needToFormat: false,
          // formattedContent: [],
          formattedContent: "",
        };
        // chatHistory?.map((data, index) => {

        // })
        chatHistory.unshift(AddFirstIndex);
        chatHistory?.map((data, index) => {
          if (data.role == "assistant") {
            data.needToFormat = true;
            // data.formattedContent = breakIntoParagraphs(data.content);
            // data.formattedContent = addNewlineAfterFullStop(data.content);
            data.formattedContent = data.content;
          }
        });
        setMessages(chatHistory);

        setTimeout(function () {
          scrollToBottom();
        }, 500);

      } else {
        toast.error(data?.message);
        setShowSkeleton(false);
        navigate("/pitchgenerator");
      }
      setShowSkeleton(false);

      // const reader = response.body.getReader();
      // const decoder = new TextDecoder();
      // let completeString = '';

      // while (true) {
      //   const { value, done } = await reader.read();
      //   if (done) {
      //     const responseAIMessage = { text: `${completeString}`, type: 'bot' };
      //     setMessages((prev) => [...prev, responseAIMessage]);
      //     setData('');
      //     break;
      //   };
      //   const decoded = decoder.decode(value, { stream: true });
      //   setData((prev) => prev + decoded);
      //   completeString += decoder.decode(value, { stream: true });
      // }
    } catch (error) {
      setShowSkeleton(false);
    } finally {
    }
  };




  const fetchData = async (inputText) => {
    // const serverBaseURL = "http://172.16.0.220:2000/aiCompletion";
    const serverBaseURL = `${appEnv}pitch/continue-pitch/${firstChatid}`;
    let completeString = "";

    try {
      setFetchingData(true);
      const response = await fetch(serverBaseURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Bearer ${auth}`,
        },
        body: JSON.stringify({
          user_prompt: `${inputText}`,
        }),
      });

      if (response.ok) {
        // reset();
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { value, done } = await reader.read();
          if (done) {
            // let completeStringWithFormat = breakIntoParagraphs(completeString);
            // let completeStringWithFormat = addNewlineAfterFullStop(completeString);

            setFetchingData(false);
            if (completeString !== "") {
              const responseAIMessage = {
                content: `${completeString}`,
                role: "assistant",
                needToFormat: true,
                formattedContent: completeString,
              };
              setMessages((prev) => [...prev, responseAIMessage]);
            }
            setData("");
            scrollToBottom();
            break;
          }

          try {

            const decoded = decoder.decode(value, {
              stream: true,
            });


            // const stringWithNewlines = addNewlineAfterFullStop(decoded);

            // setTimeout(function(){
            // setData((prev) => prev + stringWithNewlines);
              // }, 100);
            // setData((prev) => prev + stringWithNewlines);
            setData((prev) => prev + decoded);

            scrollToBottom();
            // scrollToBottomToStream();
            // setTimeout(function(){
            //   scrollToBottom();
            //   }, 100);
            completeString += decoder.decode(value, {
              stream: true,
            });

          } catch (e) {

          }

        }
      } else {
        // Handle non-successful response here
        const errorMsgObj = await response.json();

        if (errorMsgObj.success == false) {
          toast.error(errorMsgObj?.message);
          setFetchingData(false);
        }
      }
    } catch (error) {
      // let completeStringWithFormat = breakIntoParagraphs(completeString);
      // let completeStringWithFormat = addNewlineAfterFullStop(completeString);

      setFetchingData(false);
      if (completeString !== "") {
        const responseAIMessage = {
          content: `${completeString}`,
          role: "assistant",
          needToFormat: true,
          formattedContent: completeString,
        };
        setMessages((prev) => [...prev, responseAIMessage]);
      }
      setData("");
      scrollToBottom();

    } finally {
    }
  };

  const redirectToNewChat = () => {
    navigate("/pitchgenerator");
  };


  return (
    <>
      <Helmet>
        <title>Tracky | Pitch</title>
        <meta name="description" content="Tracky | Tracy Pitch" />
      </Helmet>

      <div className='FirstDiv h-[calc(100vh-80px)]'>

        <div className='bg-[#000]  p-6'>
          <div className='  text-[#ffffff] '>
            <div className='flex flex-row-reverse cursor-pointer'>
              <Tooltip text='New Chat' bgColor='bg-[#4d4d4d]'>
                <img
                  src={edit_icn}
                  alt="edit icon"
                  onClick={redirectToNewChat}
                  className="ml-1 h-[35px]"
                />
              </Tooltip>
              <Tooltip text="Back" bgColor="bg-[#4d4d4d]">
                <img
                  src={back_arrow}
                  alt="back icon"
                  onClick={redirectToNewChat}
                  className="h-[45px]"
                />
              </Tooltip>
            </div>
            <div className="p-2 md:p-6 flex flex-col h-[calc(100vh-80px-93px)]">
              {/* <div className="grid w-full grid-cols-1 gap-2 md:grid-cols-3 md:gap-8 md:mt-2"> */}

              {showSkeleton ? (
                <PitchChatSkeleton />
              ) : (
                <>
                  <div className=' w-full md:p-4 overflow-y-scroll  h-[calc(100vh-80px-60px)]   mb-2'>
                    {messages &&
                      messages.length !== 0 &&
                      messages.map((message, index) => (
                        <div key={index} className={`mb-5`}>
                          <p className="text-[20px]">
                            {message.role === "assistant" ? `Tracky Ai` : `You`}
                          </p>
                          <p
                            // className={`inline-block p-2 rounded-lg ${message.type === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-300 text-black'
                            //   }`}
                            className="text-justify"
                            ref={index === messages.length - 1 ? lastMessageRef : null}
                          >

                            {message?.needToFormat == true ? (
                              <>

                                {/* {message?.formattedContent.map(
                                  (paragraph, index) => (
                                    <React.Fragment key={index}>
                                      <p key={index} className="">
                                        {paragraph.currentParagraph}
                                      </p>
                                      <br />
                                    </React.Fragment>
                                  )
                                )} */}

                                <div className="w-[100%] text-justify font-sans font-inter">
                        <pre className="text-justify text-[16px] font-normal leading-6 whitespace-pre-line font-sans font-inter">
                          {message?.formattedContent}
                          </pre>
                          </div>

                              </>
                            ) : (
                              <>{message.content}</>
                            )}


                            <p ref={LastMessagesRef} ></p>
                          </p>
                        </div>
                      ))}
                    {data && data !== "" && (
                      <div className="mb-6">
                        <p className="text-[20px] mb-2">
                          {` ${data !== " " ? "Tracky Ai" : ""}`}
                        </p>
                        {/* <p
                          // className={`inline-block p-2 rounded-lg ${message.type === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-300 text-black'
                          //   }`}
                          className="text-justify text-[16px] font-normal leading-6 "
                        >

                        </p> */}

                        <p className="text-justify">
                        <div className="w-[100%] text-justify font-sans font-inter" ref={messagesEndRefStream}>
                        <pre className="text-justify text-[16px] font-normal leading-6 whitespace-pre-line font-sans font-inter">
                          {data}
                          </pre>
                    {/* <div ref={messagesEndRefStream} className="forScroll" /> */}
                          </div>
                        </p>
                      </div>
                    )}
                    <div ref={messagesEndRef} className="forScroll" />
                  </div>
                </>
              )}

              <form
                onSubmit={handleSubmit(
                  handleSendMessage
                )}
              >
                <div className="flex flex-col md:flex-row justify-between  bg-[#000000]">
                  <input
                    className={`rounded-[8px] border border-[#BFBFBF]
                    py-[10px]  cursor-pointer   focus:border-0 focus:outline-none
                  text-[#ffffff] text-[16px] text-left mt-8 md:mt-0 w-full md:w-3/5 ${(showSkeleton || fetchingData) ? "bg-[#403F3F] text-white" : "bg-transparent"}`}
                    type="text"
                    placeholder="Type your message..."
                    // value={inputText}
                    // onChange={handleInputChange}
                    onKeyPress={handleKeyDown}
                    {...register("user_prompt")}
                    autoComplete="off"
                    disabled={showSkeleton || fetchingData}
                  />

                  <button
                    className={`rounded-[8px] border border-[#2EDE9F] text-[16px] text-white
                    cursor-pointer py-[10px] px-[10px]
                    hover:bg-[#2EDE9F] hover:text-white mt-4 md:mt-0 w-full md:w-1/5 ${(fetchingData) ? "bg-[#403F3F] text-white" : "bg-transparent"}`}
                    type="submit"
                    disabled={showSkeleton || fetchingData}
                  // onClick={() => openModal(selectedSection)}
                  // onClick={handleSendMessage}
                  >
                    {showSkeleton || fetchingData ? "TrackAI is answering" : "Send"}
                  </button>
                </div>
                {errors.user_prompt && (
                  <p className="text-[#FF0000] text-sm">{errors.user_prompt.message}</p>
                )}
              </form>

              {/* </div> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Pitch;
