import React from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { Helmet } from "react-helmet";
import CheckOnboard from "../AuthGuard/CheckOnboard";
import { useNavigate } from "react-router-dom/dist";

function TrackyAI() {
  const navigate = useNavigate();

  const navToPitchGenerator = () => {
    navigate("/pitchgenerator");
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Tracy AI</title>
        <meta
          name="description"
          content="Tracky | Tracy AI"
        />
      </Helmet>

      <div className=" FirstDiv">

        <div className="dark-bg content p-6">
          <div className=" text-[#ffffff] h-full">
            <div
              className="p-4 md:pb-6  grid grid-flow-row auto-rows-max  mx-auto
        content-center w-full h-[85vh] md:h-full "
            >
              <div className=" flex flex-col items-center content-center h-full">
                <p className="text-[20px] md:text-[50px] text-[#939393] font-medium text-center">
                  Lets close the next
                  deal
                </p>
                <div className="flex flex-col md:flex-row justify-between w-[70%] mt-20 md:gap-5 gap-0">
                  <div
                    className="rounded-[8px] border border-[#BFBFBF] bg-transparent
                    py-[10px] xl:px-[67px] px-8 cursor-pointer
                  text-[#ffffff] text-[16px] text-center mt-8 md:mt-0
                  hover:bg-[#2ede9f] hover:text-black
                  "
                    onClick={
                      navToPitchGenerator
                    }
                  >
                    Pitch generator
                  </div>
                  <div
                    className="rounded-[8px] border border-[#BFBFBF] bg-transparent
                     py-[10px] xl:px-[67px] px-8 cursor-pointer
                  text-[#ffffff] text-[16px] text-center mt-8 md:mt-0 hover:bg-[#2ede9f] hover:text-black"
                    onClick={() =>
                      navigate(
                        "/convocraft"
                      )
                    }
                  >
                    Convo craft
                  </div>
                  <div
                    className="rounded-[8px] border border-[#BFBFBF] bg-transparent
                     py-[10px] xl:px-[67px] px-8 cursor-pointer
                  text-[#ffffff] text-[16px] text-center mt-8 md:mt-0 hover:bg-[#2ede9f] hover:text-black"
                    onClick={() =>
                      navigate(
                        "/templategallery"
                      )
                    }
                  >
                    Template gallery
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default CheckOnboard(TrackyAI);
