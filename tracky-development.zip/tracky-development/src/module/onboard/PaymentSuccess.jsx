import React, { useEffect } from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { IoIosCheckmarkCircle } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import { OnBoardPersonalInfo } from "../../redux/slices/onBoabrdSlice";
import { useDispatch, useSelector } from "react-redux";

import success_icn from "../../assets/success_icn.svg";


const PaymentSuccess = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loginData = useSelector((state) => state?.root?.auth);
  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.googleInData?.token ||
    loginData?.appleData?.token;

  useEffect(() => {
    dispatch(OnBoardPersonalInfo(auth));
  }, [dispatch]);

  const redirectToDashboard = () => {
    navigate("/dashboard");
  };

  return (
    <>
      {/* <div className=" flex"> */}
        {/* <div className="">
          <SideBar />
        </div> */}
        <div className="w-[100%]">
          {/* <Header /> */}
          <div className="dark-bg content  text-[#ffffff] w-full">
            <div
              className="p-4 md:pb-6  grid grid-flow-row auto-rows-max  mx-auto
        content-center w-full  tex-center content "
            >
              <div className="mx-auto">
                <img src={success_icn} alt="success image" />
              </div>
              <p
                className="text-[20px] md:text-[40px] t break-word md:break-normal
             font-bold mx-auto text-center mt-4"
              >
                Payment successful
              </p>
              <p
                className="text-[18px]  break-word md:break-normal
             font-normal mx-auto text-center mt-4"
              >
                A receipt for this payment has been sent to your email
              </p>
              <button
                className="bg-[#2EDE9F] mx-auto flex justify-center w-full md:w-[30%]
                       items-center content-center text-center
                        text-[#000000] text-[15px] font-medium py-[26px]
                        rounded-[17px] mt-6"
                type="submit"
                onClick={redirectToDashboard}
              >
                Go back to dashboard
              </button>
            </div>
          </div>
        </div>
      {/* </div> */}
    </>
  );
};

export default PaymentSuccess;
