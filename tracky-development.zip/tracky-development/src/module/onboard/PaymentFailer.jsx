import React from "react";
import Header from "../../CommonComponent/Header";
import SideBar from "../../CommonComponent/Sidebar";
import { FaTimes } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import payment_fail_icn from "../../assets/payment_fail_icn.svg";


const PaymentFailer = () => {
  const navigate = useNavigate();


  const redirectToDashboard = () => {
    navigate("/dashboard");
  };

  return (
    <>
      <div className=" flex">
        <div className="">
          {/* <SideBar /> */}
        </div>
        <div className="w-[100%]">
          {/* <Header /> */}
          <div className="dark-bg content  text-[#ffffff] w-full">
            <div
              className="p-4 md:pb-6  grid grid-flow-row auto-rows-max  mx-auto
        content-center w-full  tex-center content "
            >
              <div className="mx-auto">
                <img src={payment_fail_icn} alt="success image" />
              </div>
              <p
                className="text-[20px] md:text-[40px] t break-word md:break-normal
             font-bold mx-auto text-center mt-4"
              >
                Payment Fail
              </p>
              <p
                className="text-[18px]  break-word md:break-normal
             font-normal mx-auto text-center mt-4"
              >
                A receipt for this payment has been sent to your email
              </p>
              <button
                className="bg-[#2EDE9F] mx-auto flex justify-center w-[30%]
                       items-center content-center text-center
                        text-[#000000] text-[15px] font-medium py-[26px]
                        rounded-[17px] mt-6"
                type="submit"
                onClick={redirectToDashboard}
              >
                Go back to dashboard
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PaymentFailer;
