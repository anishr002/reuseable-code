import React, { useEffect, useState, useContext } from "react";

import logo_light from "../../assets/logo_light.svg";
import user_icn from "../../assets/user_icn.svg";
import graph_icn from "../../assets/graph_icon.svg";
import profile_icn from "../../assets/profile_icn.svg";
import dash_image from "../../assets/dash_image.svg";
import rounded from "../../assets/rounded.svg";
import upload_icn from "../../assets/upload_icn.svg";
import selected_checked from "../../assets/selected_Check.svg";
import checked from "../../assets/Check.svg";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { handleKeyDown } from "../../utils/SpaceValidation";
import { ErrorMessage } from "@hookform/error-message";
import { useDispatch, useSelector } from "react-redux";
import {
  AddOnBoard,
  Backstep,
  DownloadOnboard,
  GetOnBoardPayments,
  GetOnBoardRoles,
  OnBoardPersonalInfo,
  nextFormdata,
  resetStep,
  setActiveStep,
  setStep,
  checkUserCompleteOnboard,
} from "../../redux/slices/onBoabrdSlice";

import { Helmet } from "react-helmet";
import { Link, useNavigate } from "react-router-dom";
import { logoutData } from "../../redux/slices/authSlice.js";

import { resetOnBoard } from "../../redux/slices/onBoabrdSlice.js";
import Loader from "../../CommonComponent/Loader.jsx";
import axios from "axios";
import { SocketContext } from '../../CommonComponent/context/SocketContextProvider';

function Onboard() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const step = useSelector((state) => state?.root?.onboard?.step);
  const isLoading = useSelector(
    (state) => state?.root?.onboard?.AddOnBoardLoadflag
  );

  const { socket, isSocketConnected } = useContext(SocketContext);
  const activeStep = useSelector((state) => state?.root?.onboard?.activeStep);
  const PersonalinfoData = useSelector(
    (state) => state?.root?.onboard?.PersonalinfoData
  );

  const onStartcheckUserCompleteOnboardLoading = useSelector(
    (state) => state?.root?.onboard?.checkUserCompleteOnboardloading
  );

  const loginData = useSelector((state) => state?.root?.auth);
  const GetOnboard = useSelector((state) => state?.root?.onboard);
  const onBoardstepwiseData = useSelector(
    (state) => state?.root?.onboard?.stepwiseData
  );

  const BoardRole = GetOnboard.onboardRole;
  const BoardPayment = GetOnboard.onboardpaymentData;

  const onBoardFlag =
    PersonalinfoData?.profileData?.on_board === true ||
    loginData?.data?.user?.on_board === true ||
    loginData?.googleData?.user?.on_board === true ||
    loginData?.VerifyData?.user?.on_board === true ||
    loginData?.signupResData?.on_board === true ||
    loginData?.googleInData?.user?.on_board === true ||
    loginData?.appleData?.user?.on_board === true;

  const user_id = loginData?.data?.user?._id
    ? loginData?.data?.user?._id
    : loginData?.googleData?.user?._id
      ? loginData?.googleData?.user?._id
      : loginData?.VerifyData?.user?._id
        ? loginData?.VerifyData?.user?._id
        : loginData?.googleInData?.user?._id
          ? loginData?.googleInData?.user?._id
          : loginData?.appleData?.user?._id;
  // const track_record_csv = null;
  const auth =
    loginData?.data?.token ||
    loginData?.googleData?.token ||
    loginData?.VerifyData?.token ||
    loginData?.appleData?.token ||
    loginData?.googleInData?.token;

  const [selectedImage, setSelectedImage] = useState(null);
  const [plan, setSelectedPlan] = useState("");
  const [userName, setUserName] = useState("");
  const [checkUsernameLoading, setCheckUsernameLoading] = useState(false);

  const [selectedFile, setSelectedFile] = useState(null);

  const validationSchema = [
    Yup.object({
      profile_name: Yup.string()
        .required("Please enter username")
        .max(15, "Username must be at most 15 characters")
        .matches(
          /^[a-zA-Z][a-zA-Z\d_-]*$/,
          "Username must start with a letter and can only contain letters, numbers, underscores, and dashes"
        )
        .min(3, ({ min }) => `Username must be at least ${min} characters`),

      profile_image: Yup.mixed()
        .test("required", "Please upload a profile photo", (value) => {
          return value?.length === 0 ? false : true;
        })
        .test(
          "fileFormat",
          "Unsupported file format",
          (value) =>
            value &&
            ["image/jpeg", "image/jpg", "image/png"].includes(value?.type)
        )
        .test(
          "fileSize",
          "File size is too large",
          (value) => value && value?.size <= 1024 * 1024 * 2 // 2MB
        ),
    }),
    Yup.object({
      bio: Yup.string()
        .required("Bio is required")
        .max(150, "Bio must be at most 150 characters"),
    }),
    Yup.object({
      role: Yup.string().required("Please select role"),
    }),
    Yup.object({
      average_deal_size: Yup.string()
        .required("Please enter average deal size")

        .test(
          "max-characters",
          "Deal size must be in at most 6 digits",
          (value) => value.replace(/^0+/, "").length <= 6
        )
        .matches(
          /^(0(\.\d+)?|[1-9]\d*(\.\d+)?)$/,
          "Please enter a valid number"
        ),
    }),
    Yup.object({
      track_record: Yup.string().required("Please select track record"),
    }),
    Yup.object({
      track_record_csv: Yup.mixed()
        .test("required", "Please choose csv file", (value) => {
          return value?.length === 0 ? false : true;
        })
        .test(
          "fileFormat",
          "Unsupported file format",
          (value) => value && ["text/csv", "dragover"].includes(value?.type)
        )
        .test(
          "fileSize",
          "File size is too large",
          (value) => value && value?.size <= 1024 * 1024 * 2 // 2MB
        ),
    }),
    Yup.object({
      plan_id: Yup.string().required("Please choose plan"),
    }),
  ];
  const currentValidationSchema = validationSchema[activeStep];
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
    setError,
    clearErrors,
    reset, // Add this line
    trigger,
  } = useForm({
    resolver: yupResolver(currentValidationSchema),
    mode: "onChange",
    defaultValues: {
      role: onBoardstepwiseData?.role,
      average_deal_size: onBoardstepwiseData?.average_deal_size,
      bio: onBoardstepwiseData?.bio,
      profile_name: onBoardstepwiseData?.profile_name,
      track_record: onBoardstepwiseData?.track_record,
    },
  });

  const RoleId = getValues("role");

  const nextstep = async (step) => {
    if (step) {
      dispatch(setStep());
    } else {
      const isStepValid = await trigger();
      if (isStepValid) {
        dispatch(setActiveStep());
        dispatch(setStep());
        dispatch(nextFormdata(getValues()));
      }
    }
  };

  useEffect(() => {
    dispatch(resetStep());
  }, []);

  const backStep = () => {
    dispatch(Backstep());
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setValue("track_record_csv", file);
    clearErrors("track_record_csv");
    setSelectedFile(file);
  };

  const handleDrop = async (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    setValue("track_record_csv", file);
    await trigger("profile_image");

    // clearErrors("track_record_csv");
    setSelectedFile(file);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const dropzoneStyles = {
    border: "2px dashed #cccccc",
    borderRadius: "4px",
    padding: "20px",
    textAlign: "center",
    cursor: "pointer",
  };

  const onImageClick = () => {
    document.getElementById("imageInput").click();
  };

  const onImageChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setValue("profile_image", file);
      await trigger("profile_image");
      //clearErrors("profile_image");
      setSelectedImage(URL.createObjectURL(file));
    }
  };

  const onSubmit = async (data) => {
    const formData = new FormData();
    formData.append("user_name", data.profile_name || "");
    formData.append("plan_id", data.plan_id || null);
    formData.append("role", data.role || null);
    formData.append("track_record", data.track_record || null);
    formData.append("bio", data.bio || "");
    formData.append("average_deal_size", data.average_deal_size || null);

    formData.append("user_id", user_id);
    formData.append("track_record_csv", data.track_record_csv || null);
    formData.append("profile_image", data.profile_image || null);
    formData.append(
      "success_url",
      process.env.REACT_APP_SUCCESS_PAYMENT || null
    );
    formData.append("cancle_url", process.env.REACT_APP_FAILER_PAYMENT || null);

    await dispatch(AddOnBoard(formData, navigate, auth));
  };

  useEffect(() => {
    onBoardFlag && navigate("/dashboard");
  }, []);

  useEffect(() => {
    dispatch(GetOnBoardRoles(auth));
    dispatch(GetOnBoardPayments(auth));
    dispatch(OnBoardPersonalInfo(auth));
  }, [dispatch]);




  useEffect(() => {

    socket?.emit('ROOM', { id: user_id });
    socket?.on("PAYMENT_SUCCESS", (payload) => {
      socket?.emit(
        "CONFIRMATION",
        "Event received and processed: PAYMENT_SUCCESS"
      );
      // open(location, "_self").close();
      dispatch(OnBoardPersonalInfo(auth));
      setTimeout(function(){
        navigate("/dashboard");
        }, 3000);
    });

    return () => {
      socket?.off('PAYMENT_SUCCESS');
    };
  }, [socket]);

  //radio box selection and checked radio

  const [selectedRole, setSelectedRole] = useState("");

  // This function will be called when a div is clicked
  const handleDivClick = (roleId) => {
    setSelectedRole(roleId);
  };

  const onStartcheckUserCompleteOnboard = () => {
    dispatch(checkUserCompleteOnboard(auth, navigate, nextstep));
  };

  const checkUserName = async () => {
    const isStepValid = await trigger();
    if (isStepValid) {
      if (userName !== "") {
        const username = {
          user_name: userName,
        };
        try {
          setCheckUsernameLoading(true);
          const response = await axios.post(
            `${process.env.REACT_APP_API_BASE_URL}user/username-check`,
            username,
            {
              headers: {
                Authorization: `Bearer ${auth}`,
              },
            }
          );

          if (response.data.success) {
            if (response.data.data.username_exists) {
              setError("profile_name", {
                type: "custom",
                message: "Username already exists.",
              });
            } else {
              clearErrors("profile_name");
              dispatch(setActiveStep());
              dispatch(setStep());
              dispatch(nextFormdata(getValues()));
            }
            setCheckUsernameLoading(false);
          }
        } catch (err) {
          setCheckUsernameLoading(false);
        }
        setCheckUsernameLoading(false);
      }
    }
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Onboard</title>
        <meta name="description" content="Tracky | Onboard" />
      </Helmet>
      <form onSubmit={handleSubmit(onSubmit)} className="overflow-hidden">
        {step === 1 && (
          <>
            <div
              className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between sticky top-0 z-10"
            >
              <div>
                <img src={logo_light} alt="light logo " />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <div>
                  <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                    Logout
                  </Link>
                </div>
              </div>
            </div>
            {/* content start here */}
            <div className="dark-bg  content   py-[12px] px-[50px]  text-[#ffffff] h-[calc(100vh-80px)">
              <div
                className=" my-[10px]  grid grid-cols-1 gap-4 sm:grid-cols-2
              md:grid-cols-2  md:content-center md:items-center md:h-full"
              >
                {/* left content only */}
                <div className="">
                  <p className="text-[18px] md:text-[30px] font-semibold mb-[63px] w-full text-center md:text-left md:w-[65%] break-normal">
                    Hey{" "}
                    <span className="capitalize">
                      {PersonalinfoData?.profileData?.first_name}
                    </span>
                    , ready to show off your results?
                  </p>
                  <ul class="list-outside ">
                    <li className="flex items-center content-center border-b border-[#ffffff] pb-5 mb-5">
                      <img src={user_icn} alt="user icion" />
                      <span className="text-[16px] ms-4 font-medium">
                        Answer a few questions and start building your profile
                      </span>
                    </li>
                    <li className="flex items-center content-center border-b border-[#ffffff] pb-5 mb-5">
                      <img src={graph_icn} alt="user icion" />
                      <span className="text-[16px] ms-4 font-medium">
                        Upload your track record and keep updating this daily
                      </span>
                    </li>
                    <li className="flex items-center content-center border-b border-[#ffffff] pb-5">
                      <img src={profile_icn} alt="user icion" />
                      <span className="text-[16px] ms-4 font-medium">
                        Apply for open roles or reach out to business owners
                        sharing your profile
                      </span>
                    </li>
                  </ul>
                  <div className="mt-[74px] flex flex-col md:flex-row items-center">
                    <button
                      className="rounded-[10px] bg-[#ffffff] text-[#000000] text-[18px] font-bold px-[39px]
                      py-[16px] get_started_button_shadow hover:bg-[#2EDE9F] "
                      onClick={() => {
                        // nextstep(1);
                        onStartcheckUserCompleteOnboard();
                      }}
                      type="button"
                      disabled={onStartcheckUserCompleteOnboardLoading}
                    >
                      {onStartcheckUserCompleteOnboardLoading ? (
                        <div
                      className="flex items-center content-center justify-center w-full "
                    >
                          <Loader />
                        </div>
                      ) : (
                        <>Get Started</>
                      )}
                    </button>

                    <span className="text-[12px] md:ms-[32px] mt-4 md:mt-0 text-center md:text-left">
                      it only takes 5-10 minutes and you can edit this later.
                      We’ll save as you go.
                    </span>
                  </div>
                </div>
                {/* right side image only */}
                <div className="w-full">
                  <img
                    src={dash_image}
                    alt="dashboard image"
                    className="w-full"
                  />
                </div>
              </div>
              {/* content end here */}
            </div>
          </>
        )}
        {step === 2 && (
          <>
            <div
              className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between"
            >
              <div>
                <img src={logo_light} alt="light logo " />
              </div>

              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div
              className="dark-bg content_small   text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-hidden md:overflow-auto
            "
            >
              <div className=" p-6 md:p-8  mx-auto text-[#ffffff]">
                <div
                  className=" border border-white rounded-[15px] grid grid-flow-row auto-rows-max  mx-auto
        content-center md:w-[80%]  p-4 md:p-8"
                >
                  <div
                    className="flex flex-col items-center content-center justify-between md:flex-row "
                  >
                    <div
                      className="cursor-pointer "
                      onClick={() => dispatch(resetStep())}
                    >
                      <div>
                        <span className="text-[18px] underline hover:text-[#2EDE9F] ">
                          {" "}
                          Back step{" "}
                        </span>
                      </div>
                    </div>

                    <div
                      className="cursor-pointer "
                      onClick={() => {
                        if (onBoardstepwiseData?.profile_name == "") {
                          const fieldsToReset = [
                            "profile_name",
                            "profile_image",
                          ];
                          reset(
                            fieldsToReset.reduce((acc, field) => {
                              acc[field] = null;
                              return acc;
                            }, {})
                          );
                        }

                        dispatch(setStep());
                        dispatch(setActiveStep());
                      }}
                    >
                      <span className="text-[18px] underline hover:text-[#2EDE9F] mt-4 md:mt-0">
                        {" "}
                        Skip step{" "}
                      </span>
                    </div>
                  </div>

                  <p className="text-[20px] md:text-[30px] font-bold mb-[20px] block text-center mt-[20px] ">
                    Upload your profile picture and pick a username
                  </p>

                  <div className="w-[100%] md:w-full flex flex-col md:flex-row justify-center items-center content-center">
                    <div className="md:w-[20%] text-center w-full flex items-center flex-col">
                      <label htmlFor="image" className="cursor-pointer ">
                        <div className=" overflow-hidden rounded-full w-[60px] h-[60px] md:w-[90px] md:h-[90px] md:mb-0 mb-4">
                          <img
                            src={selectedImage || rounded}
                            alt="upload image"
                            className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full bg-origin-content "
                            onClick={onImageClick}
                          />
                        </div>
                      </label>

                      <input
                        id="imageInput"
                        type="file"
                        {...register("profile_image")}
                        style={{
                          display: "none",
                        }}
                        onChange={onImageChange}
                        accept="image/*"
                        required
                      />

                      <div className="text-center md:w-[90%]">
                        {errors.profile_image && (
                          <p className="text-[#FF0000] text-sm">
                            {errors.profile_image.message}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="md:w-[70%]">
                      <input
                        // className="ms-10"
                        type="text"
                        name="profile_name"
                        {...register("profile_name", {
                          onChange: (e) => {
                            setUserName(e.target.value);
                          },
                          // onBlur: (e) => { },
                        })}
                        defaultValue={onBoardstepwiseData?.profile_name}
                        placeholder="@Tracky"
                        autoComplete="off"
                        onKeyPress={handleKeyDown}
                        className="border md:ms-4 border-[#ffffff] bg-[#373839] rounded-[12px]
                       p-4 text-[18px] text-[#ffffff] w-full"
                      />
                      {/* <ErrorMessage
                      errors={errors}
                      name=" profile_name"
                      render={({ message }) => <p>{message}</p>}
                    /> */}
                      <div className="text-center md:text-left md:ms-4">
                        {errors.profile_name && (
                          <p className="text-[#FF0000] text-sm">
                            {errors.profile_name.message}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      // nextstep();
                      checkUserName();
                    }}
                    type="button"
                    className="w-[300px] md:w-[379px] mx-auto rouned_button_transparent text-center h-[50px] bg-[#373839] shadow-2xl mt-[40px]
              flex items-center justify-center button_shadow hover:border hover:border-[#2EDE9F] hover:text-[#2EDE9F]"
                    disabled={checkUsernameLoading}
                  >
                    {checkUsernameLoading ? (
                      <div
                      className="flex items-center content-center justify-center w-full "
                    >
                        <Loader />
                      </div>
                    ) : (
                      <>Continue</>
                    )}
                  </button>
                </div>
              </div>
              {/* stepper % start here */}
              <div className="relative">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[17.5%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>

            {/* content end here */}
          </>
        )}
        {step === 3 && (
          <>
            <div
              className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between"
            >
              <div>
                <img src={logo_light} alt="light logo " />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div
              className="dark-bg  content_small  text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-hidden md:overflow-auto"
            >
              <div className=" p-6 md:p-8  mx-auto text-[#ffffff]">
                <div
                  className="border border-white rounded-[15px] grid grid-flow-row auto-rows-max  mx-auto
        content-center md:w-full  p-4 md:p-8"
                >
                  <div
                    className="flex flex-col items-center content-center justify-between md:flex-row"
                  >
                    <div className="cursor-pointer " onClick={backStep}>
                      <span className="text-[18px] underline hover:text-[#2EDE9F]">
                        {" "}
                        Back step{" "}
                      </span>
                    </div>
                    <div
                      className="cursor-pointer "
                      onClick={() => {
                        if (onBoardstepwiseData?.bio == "") {
                          const fieldsToReset = ["bio"];
                          reset(
                            fieldsToReset.reduce((acc, field) => {
                              acc[field] = null;
                              return acc;
                            }, {})
                          );
                        }

                        dispatch(setStep());
                        dispatch(setActiveStep());
                      }}
                    >
                      <button
                        className="text-[18px] underline hover:text-[#2EDE9F] "
                        type="button"
                      >
                        {" "}
                        Skip step{" "}
                      </button>
                    </div>
                  </div>
                  <div className="w-full md:w-[80%] md:shrink-0 mx-auto grid grid-flow-row auto-rows-max ">
                    {/* title start here */}
                    <p className="text-[20px] md:text-[30px] font-bold mb-[20px] block text-center mt-[20px] ">
                      Tell us something about yourself
                    </p>
                    <textarea
                      {...register("bio")}
                      className="shaow-2xl text-[#000000] rounded-[10px] w-full"
                      defaultValue={onBoardstepwiseData?.bio}
                      onKeyPress={handleKeyDown}
                      rows="4"
                      cols="50"
                    ></textarea>
                    {errors.bio && (
                      <p className="text-[#FF0000] text-sm">{errors.bio.message}</p>
                    )}
                    {/* <ErrorMessage
                    errors={errors}
                    name="bio"
                    render={({ message }) => <p>{message}</p>}
                  /> */}
                    <button
                      onClick={() => {
                        nextstep();
                      }}
                      type="button"
                      className="w-[300px] md:w-[379px] mx-auto rouned_button_transparent text-center h-[50px] bg-[#373839] shadow-2xl mt-[40px]
              flex items-center justify-center button_shadow hover:border hover:border-[#2EDE9F] hover:text-[#2EDE9F]"
                    >
                      Continue
                    </button>
                  </div>
                </div>
              </div>
              {/* stepper % start here */}
              {/* stepper % start here */}
              <div className="relative">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[37.5%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>
          </>
        )}
        {step === 4 && (
          <>
            <div
              className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between"
            >
              <div>
                <img src={logo_light} alt="light logo " />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div className="dark-bg  content_small  text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-hidden md:overflow-auto">
              <div className="border rounded-[12px] border-[#ffffff] p-[20px]  w-[90%] md:w-70%] xl:w-[50%] mx-auto">
                <div
                  className="flex items-center content-start justify-center w-full cursor-pointer md:items-end md:justify-end"
                  onClick={backStep}
                >
                  <span className="text-[18px] underline hover:text-[#2EDE9F]">
                    {" "}
                    Back step{" "}
                  </span>
                </div>
                <div className="w-[100%]  md:w-3/5 md:shrink-0 mx-auto grid grid-flow-row auto-rows-max">
                  {/* title start here */}
                  <p
                    className="text-[20px] md:text-[30px] text-center break-word md:break-normal
            w-[100%] mt-4 md:mt-0 md:w-full font-bold mb-[40px] px-6 "
                  >
                    Are you a appointment setter or a closer?
                  </p>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    {/* first start here */}
                    {BoardRole?.map((role, index) => {
                      return (
                        <>
                          <label
                            class="has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            cursor-pointer"
                          >
                            <input
                              className="checked:border-[2EDE9F] float-right flex justify-end justify-self-end"
                              type="radio"
                              value={role?._id}
                              name="role"
                              // checked={selectedRole === role?._id} // Check if this radio button should be selected
                              // onChange={() => setSelectedRole(role?._id)}
                              {...register("role")}
                            />
                            <p className="text-[20px] font-semibold  block text-center my-[20px] ">
                              {role?.label}
                            </p>
                          </label>
                        </>
                      );
                    })}
                  </div>
                  {errors.role && (
                    <p className="text-[#FF0000] text-sm">{errors.role.message}</p>
                  )}
                  <button
                    onClick={() => {
                      nextstep();
                    }}
                    type="button"
                    className="w-[300px] md:w-[379px] mx-auto rouned_button_transparent text-center h-[50px] bg-[#373839] shadow-2xl mt-[40px]
              flex items-center justify-center button_shadow hover:border hover:border-[#2EDE9F] hover:text-[#2EDE9F]"
                  >
                    Continue
                  </button>
                </div>
              </div>
              {/* stepper % start here */}
              <div className="relative ">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[50%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>
          </>
        )}
        {step === 5 && (
          <>
            <div
              className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between"
            >
              <div>
                <img src={logo_light} alt="light logo " />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div className="dark-bg  content_small  text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-hidden md:overflow-auto">
              <div className="border rounded-[12px] border-[#ffffff] py-[30px] px-[10px] w-[90%] md:w-[70%] xl:w-[50%] mx-auto">
                <div
                  className="flex items-center content-start justify-center w-full mb-4 cursor-pointer md:items-end md:justify-end md:mb-0"
                  onClick={backStep}
                >
                  <span className="text-[18px] underline hover:text-[#2EDE9F]">
                    {" "}
                    Back step{" "}
                  </span>
                </div>
                <div className="grid grid-flow-row mx-auto md:shrink-0 auto-rows-max">
                  {/* title start here */}
                  <p
                    className="text-[20px] md:text-[30px] text-center break-word md:break-normal
            mx-auto font-bold mb-[40px] w-[90%] md:w-full"
                  >
                    What’s your average deal size?
                  </p>
                  <div className="grid grid-cols-1  gap-4 mx-auto w-[80%]">
                    {/* first start here */}
                    <input
                      type="number"
                      {...register("average_deal_size")}
                      defaultValue={onBoardstepwiseData?.average_deal_size}
                      placeholder="Enter your deal size"
                      className="border border-[#ffffff] bg-[#373839] rounded-[12px]
                      p-4 text-[18px] text-[#ffffff] w-[90%] md:w-full mx-auto"
                    />
                    <p className="text-[15px] font-semibold w-[90%] md:w-full mx-auto">
                      Don’t know your average deal size? Insert 0
                    </p>
                  </div>
                  {errors.average_deal_size && (
                    <p className="text-[#FF0000] text-center text-sm ms-4">
                      {errors.average_deal_size.message}
                    </p>
                  )}
                  <button
                    onClick={() => {
                      nextstep();
                    }}
                    type="button"
                    className="w-[300px] md:w-[379px] mx-auto rouned_button_transparent text-center h-[50px] bg-[#373839] shadow-2xl mt-[40px]
              flex items-center justify-center button_shadow hover:border hover:border-[#2EDE9F] hover:text-[#2EDE9F]"
                  >
                    Continue
                  </button>
                </div>
              </div>
              {/* stepper % start here */}
              <div className="relative ">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[62.5%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>
          </>
        )}
        {step === 6 && (
          <>
            <div
              className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between"
            >
              <div>
                <img src={logo_light} alt="light logo " />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div className="dark-bg  content_small  text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-hidden md:overflow-auto">
              <div className="border rounded-[12px] border-[#ffffff] p-[20px]  w-[90%] md:w-70%] xl:w-[50%] mx-auto">
                <div
                  className="flex items-center content-start justify-center w-full cursor-pointer md:items-end md:justify-end"
                  onClick={backStep}
                >
                  <span className="text-[18px] underline hover:text-[#2EDE9F]">
                    {" "}
                    Back step{" "}
                  </span>
                </div>
                <div className="grid grid-flow-row mx-auto md:shrink-0 auto-rows-max">
                  {/* title start here */}
                  <p
                    className="text-[20px] md:text-[30px] text-center break-word md:break-normal
            mx-auto font-bold mb-[40px] w-[90%] md:w-full"
                  >
                    Do you currently keep track of your record?
                  </p>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {/* first start here */}
                    {/* <div
                      className="border border-[#ffffff] bg-[#373839]
                    shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max"
                    >
                      <div className="flex items-end content-start justify-end w-full">
                        <button
                          className="text-[18px] underline"
                          type="button"
                        >
                          <input
                            type="radio"
                            value="false"
                            {...register(
                              "track_record"
                            )}
                          />
                        </button>
                      </div>
                      <p className="text-[20px] font-semibold mb-[40px] block text-center mt-[30px] ">
                        No i never dit
                        but would love
                        to start!
                      </p>
                    </div> */}

                    <label
                      class="has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            cursor-pointer"
                    >
                      <input
                        className="checked:border-[2EDE9F] float-right flex justify-end justify-self-end"
                        type="radio"
                        // value={
                        //   role?._id
                        // }
                        value="false"
                        // name="role"
                        // checked={selectedRole === role?._id} // Check if this radio button should be selected
                        // onChange={() => setSelectedRole(role?._id)}
                        // {...register(
                        //   "role"
                        // )}
                        {...register("track_record")}
                      />
                      <p className="text-[20px] font-semibold  block text-center my-[20px] ">
                        No i never dit but would love to start!
                      </p>
                    </label>

                    {/* 2nd start here */}
                    {/* <div className="border border-[#ffffff] bg-[#373839] shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max">
                      <div className="flex items-end content-start justify-end w-full">
                        <button
                          className="text-[18px] underline"
                          type="button"
                        >
                          <input
                            type="radio"
                            value="true"
                            {...register(
                              "track_record"
                            )}
                          />
                        </button>
                      </div>
                      <p className="text-[20px] font-semibold mb-[40px] block text-center mt-[30px] ">
                        Yes, but i used
                        tools like
                        Excell.
                      </p>
                    </div> */}

                    <label
                      class="has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            cursor-pointer"
                    >
                      <input
                        className="checked:border-[2EDE9F] float-right flex justify-end justify-self-end"
                        type="radio"
                        name="role"
                        // checked={selectedRole === role?._id} // Check if this radio button should be selected
                        // onChange={() => setSelectedRole(role?._id)}
                        value="true"
                        {...register("track_record")}
                      />
                      <p className="text-[20px] font-semibold  block text-center my-[20px] ">
                        Yes, but i used tools like Excell.
                      </p>
                    </label>
                  </div>
                  {errors.track_record && (
                    <p className="text-[#FF0000] text-sm">
                      {errors.track_record.message}
                    </p>
                  )}
                  <button
                    onClick={() => {
                      nextstep();
                    }}
                    type="button"
                    className="w-[300px] md:w-[379px] mx-auto rouned_button_transparent text-center h-[50px] bg-[#373839] shadow-2xl mt-[40px]
              flex items-center justify-center button_shadow hover:border hover:border-[#2EDE9F] hover:text-[#2EDE9F]"
                  >
                    Continue
                  </button>
                </div>
              </div>
              {/* stepper % start here */}
              <div className="relative ">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[75%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>
          </>
        )}
        {step === 7 && (
          <>
            <div className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between">
              <div>
                <img src={logo_light} alt="light logo" />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div className="dark-bg  content_small  text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-hidden md:overflow-auto">
              <div
                className="border rounded-[12px] border-[#ffffff] py-[30px] px-[20px] md:px-[50px]
              w-[90%] md:w-3/5 mx-auto"
              >
                <div
                  className="flex flex-col items-center content-center justify-between md:flex-row "
                >
                  <div className="cursor-pointer " onClick={backStep}>
                    <span className="text-[18px] underline hover:text-[#2EDE9F]">
                      {" "}
                      Back step{" "}
                    </span>
                  </div>
                  <div
                    className="cursor-pointer "
                    onClick={() => {
                      dispatch(setStep());
                      dispatch(setActiveStep());
                    }}
                  >
                    <button
                      className="text-[18px] underline hover:text-[#2EDE9F]  "
                      type="button"
                    >
                      Skip step
                    </button>
                  </div>
                </div>
                <div className="grid grid-flow-row mx-auto md:shrink-0 auto-rows-max">
                  {/* title start here */}
                  <p
                    className="text-[20px] md:text-[30px] text-center break-word md:break-normal
            mx-auto font-bold mb-[40px] w-[90%] md:w-full mt-4"
                  >
                    Upload your track record as a CSV file
                  </p>
                  <div
                    className="flex items-center content-center justify-center mb-6"
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                  >
                    <label htmlFor="fileInput" style={dropzoneStyles}>
                      {selectedFile ? (
                        <p>{selectedFile.name}</p>
                      ) : (
                        <>
                          <img
                            src={upload_icn}
                            alt="upload icon"
                            className="mx-auto mb-4"
                          />
                          <p>Click or drag and drop your file</p>
                        </>
                      )}
                    </label>
                    <input
                      type="file"
                      id="fileInput"
                      {...register("track_record_csv")}
                      style={{
                        display: "none",
                      }}
                      onChange={handleFileChange}
                      accept=".xls, .xlsx, .csv"
                    />
                  </div>
                  {errors.track_record_csv && (
                    <p className="text-[#FF0000] text-center text-sm">
                      {errors.track_record_csv.message}
                    </p>
                  )}

                  <button
                    className="underline text-[15px] text-[#2EDE9F]"
                    type="button"
                    onClick={() => dispatch(DownloadOnboard(RoleId))}
                  >
                    Download template
                  </button>
                  <button
                    onClick={() => {
                      nextstep();
                    }}
                    type="button"
                    className="w-[300px] md:w-[379px] mx-auto rouned_button_transparent text-center h-[50px] bg-[#373839] shadow-2xl mt-[40px]
              flex items-center justify-center button_shadow hover:border hover:border-[#2EDE9F] hover:text-[#2EDE9F]"
                  >
                    Continue
                  </button>
                </div>
              </div>
              {/* stepper % start here */}
              <div className="relative">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[87.5%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>
          </>
        )}
        {step === 8 && (
          <>
            <div className="flex items-center header h-[80px]
        header_bg light_line border-b-2 px-4 md:px-10 w-full justify-between">
              <div>
                <img src={logo_light} alt="light logo " />
              </div>
              <div
                className=""
                onClick={() => {
                  dispatch(logoutData());
                  dispatch(resetOnBoard());
                }}
              >
                <Link className="block px-4 py-2 text-sm text-[#ffffff] ">
                  Logout
                </Link>
              </div>
            </div>
            {/* content start here */}
            <div className="dark-bg  content_small  text-[#ffffff] mx-auto w-full flex items-center content-center
            overflow-auto">
              <div className="border rounded-[12px] border-[#ffffff] p-[20px]  w-[90%] md:w-70%] xl:w-[50%] mx-auto">
                <div
                  className="flex items-center content-start justify-center w-full mb-4 cursor-pointer md:items-end md:justify-end md:mb-0"
                  onClick={backStep}
                >
                  <span className="text-[18px] underline hover:text-[#21CE90]">
                    {" "}
                    Back step{" "}
                  </span>
                </div>
                <div className="grid grid-flow-row mx-auto md:shrink-0 auto-rows-max">
                  {/* title start here */}
                  <p
                    className="text-[20px] md:text-[30px] text-center break-word md:break-normal
            mx-auto font-bold mb-[40px] w-[90%] md:w-full"
                  >
                    Choose your plan
                  </p>
                  {BoardPayment?.map((payment, index) => {
                    return (
                      <>
                        {/* <div
                            className={`border p-4 rounded-[12px] bg-[#373839] w-[94%] md:w-full mb-4 ${plan ===
                              "annual" &&
                              "border-[#21CE90]"
                              } `}
                          > */}

                        <label
                          class="has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-900 has-[:checked]:ring-indigo-200 border border-[#ffffff] bg-[#373839]
                            shadow-2xl hover:border-[#2EDE9F] rounded-[12px] p-4 grid grid-flow-row auto-rows-max
                            has-[:checked]:green_button_shadow
                            has-[:checked]:shadow-2xl has-[:checked]:shadow-[rgba(46, 222, 159, 0.3)] has-[:checked]:blur-{18.157896041870117px}
                            mb-4 cursor-pointer"
                        >
                          <div className="flex flex-col items-center content-center justify-start h-full md:flex-row">
                            <div className="flex-none">
                              <input
                                type="radio"
                                value={payment?.plan_id}
                                {...register("plan_id")}
                              />
                            </div>
                            <div className="flex-auto w-64  mx-[10px] ps-4 text-center md:text-left">
                              <div className="grid grid-flow-row auto-rows-max">
                                <div className="text-[18px] mb-4 font-bold">
                                  {payment?.name}
                                </div>
                                <div className="text-[16px] mb-4">
                                  {payment?.description}
                                </div>
                              </div>
                            </div>
                            {payment?.sort_value === 0 && (
                              <div className="flex-auto md:flex-1">
                                <button
                                  className="w-full  rouned_button_transparent text-center h-[50px]
                                   bg-[#21CE90] shadow-2xl py-2 px-4
                  flex items-center justify-center text-[12px] md:text-[14px]"
                                  type="button"
                                >
                                  Best Value
                                </button>
                              </div>
                            )}
                          </div>
                        </label>

                        {/* </div> */}
                      </>
                    );
                  })}

                  {errors.plan_id && (
                    <p className="text-[#FF0000] text-center text-sm">
                      {errors.plan_id.message}
                    </p>
                  )}
                  <button
                    type="submit"
                    // type="button"
                    className="w-[80%] mx-auto md:w-full  rouned_button_transparent text-center h-[50px] bg-[#21CE90]  mt-[40px]
            flex items-center justify-center button_shadow hover:border hover:border-[#21CE90] hover:bg-transparent hover:text-[#21CE90]"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader />
                      </>
                    ) : (
                      <> Add plan</>
                    )}
                  </button>
                </div>
              </div>
              {/* stepper % start here */}
              <div className="relative ">
                <div className="fixed bottom-0 left-0 w-full">
                  <div className="w-full border-4 relative border-[#353535]"></div>
                  <div className="w-[100%] border-4 relative border-[#2EDE9F] top-[-9px]"></div>
                </div>
              </div>
            </div>
          </>
        )}
      </form>
    </>
  );
}

export default Onboard;
