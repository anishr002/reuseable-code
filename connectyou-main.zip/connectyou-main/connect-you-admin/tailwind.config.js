/** @type {import('tailwindcss/vite').Config} */
export default {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"], // Ensure this points to all your files
  theme: {
    extend: {
      fontFamily: {
        quicksand: ["Quicksand", "sans-serif"],
        mundial: ["Mundial", "sans-serif"],
      },
      colors: {
        cythemePri: "#013338",
        cythemeSec: "#3aa7a3",
        cythemeTer: "#EBBD33",
      },
      screens: {
        "h-sm": { raw: "(min-height: 600px)" },
        "h-md": { raw: "(min-height: 800px)" },
        "h-lg": { raw: "(min-height: 1000px)" },
      },
    },
  },
  plugins: [],
};
