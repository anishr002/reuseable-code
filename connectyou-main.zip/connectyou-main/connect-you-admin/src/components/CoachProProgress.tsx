import {
  Box,
  CircularProgress,
  Step,
  StepContent,
  StepLabel,
  Stepper,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import { Row } from "../pages/CoachDetails";
import { httpAPI_admin } from "../AxiosAPI";

export interface Step {
  Step: number;
  completed: boolean;
  label: string;
  description: string;
}

interface CoachCertificateListType {
  _id: string;
  title: string;
  image: string;
}
interface CoachcredentialsListType {
  _id: string;
  organization: string;
  position: string;
  workingOn: string;
  startDate: string;
  endDate: string;
}

const CoachProProgress = ({ coachId }: { coachId: string }) => {
  const [data, setData] = useState<Row | null>(null);
  const [coachCertificateList, setcoachCertificateList] = useState<
    CoachCertificateListType[] | null
  >(null);
  const [coachcredentialsList, setcoachcredentialsList] = useState<
    CoachcredentialsListType[] | null
  >(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [steps, setSteps] = useState<Step[]>([
    {
      Step: 1,
      completed: false,
      label: "Add Profile Picture & Personal details",
      description: `Coach is required to add, Basic personal information and a profile picture..`,
    },
    {
      Step: 2,
      completed: false,
      label: "Complete the Email Verification.",
      description:
        "Coach must Verify the email address they have provided while creating this profile.",
    },
    {
      Step: 3,
      completed: false,
      label: "Add Google Calendar",
      description:
        "Coach must Sync their's Google calendar with our platform to get updated, notified, and organized.",
    },
    // {
    //   Step: 4,
    //   completed: false,
    //   label: "Add a Username",
    //   description:
    //     "Add your unique username that can help you sign in or get identified on the portal.",
    // },
    // {
    //   Step: 5,
    //   completed: false,
    //   label: "Select your preferred time zone.",
    //   description:
    //     "Choose a time zone of your preference. Note that your time zone will be used to add booking times and available slots for booking your sessions.",
    // },
    // {
    //   Step: 6,
    //   completed: false,
    //   label: "Add a Meeting Link",
    //   description:
    //     "Add a meeting link of your preference, that a coachee can follow to join the session they book with you.",
    // },
    {
      Step: 7,
      completed: false,
      label: "Add Certificates",
      description:
        "Coach must add the certifications they have acquired. These certifications are visible to the public and can be used in advanced filters in the coaches list. At least one certificate is required to get listed in the marketplace.",
    },
    {
      Step: 8,
      completed: false,
      label: "Add Coaching Credentials",
      description:
        "Coach must add their's coaching credentials. These credentials are visible to the public and can be used in advanced filters in the coaches list. At least one credential is required to get listed in the marketplace.",
    },
    // {
    //   Step: 9,
    //   completed: false,
    //   label: "Get profile approval from the Admin",
    //   description: `Once you have completed all the steps, you can submit your profile for approval from the admin.`,
    // },
  ]);
  const [activeStep, setActiveStep] = useState(0);
  const [completedAll, setCompletedAll] = useState(false);
  const [incomplete, setIncomplete] = useState<Step[] | null>(null);

  const checkProfileCompletionStatus = () => {
    if (!data || !coachCertificateList || !coachcredentialsList) {
      setActiveStep(0);
    } else {
      const updatedSteps = [...steps];
      updatedSteps[0].completed =
        data.image !== "" &&
          data.name !== "" &&
          data.Lname !== "" &&
          data.gender !== ""
          ? true
          : false;
      updatedSteps[1].completed = data.emailVerified === 1;
      updatedSteps[2].completed = data.calendarStatus === 1;
      // updatedSteps[3].completed = data.userName !== "" ; // if uncommented change the index of follwoing to step 6 7 & 8 as required
      // updatedSteps[4].completed = data.timeZone !== "" ; // if uncommented change the index of follwoing to step 6 7 & 8 as required
      // updatedSteps[5].completed = data.zoomMeetingURL !== ""; // if uncommented change the index of follwoing to step 6 7 & 8 as required
      updatedSteps[3].completed = coachcredentialsList?.length > 0;
      updatedSteps[4].completed = coachCertificateList?.length > 0;
      // updatedSteps[5].completed = data.approve === 1;
      setSteps(updatedSteps);
      const allCompleted = updatedSteps.every((step) => step.completed);
      const inComplete = updatedSteps.filter((step) => !step.completed);

      setIncomplete(inComplete);
      setCompletedAll(allCompleted);
      localStorage.setItem("completedAll", `${allCompleted}`);
      const firstIncompleteStep = updatedSteps.findIndex(
        (step) => !step.completed
      );
      setActiveStep(
        firstIncompleteStep === -1 ? steps.length - 1 : firstIncompleteStep
      );
    }
  };
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/details/${coachId}`
      );
      if (response.data.data) {
        setData(response.data.data);

        setcoachcredentialsList(response.data.data.coachcredentials);

        setcoachCertificateList(response.data.data.coachcertificates);
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [coachId]);
  useEffect(() => {
    checkProfileCompletionStatus();
  }, [data]);

  return (
    <Box sx={{ width: "100%", p: 1 }}>
      <Typography
        variant="body1"
        sx={{
          ...headings,
          color: "gray",
        }}
      >
        Do you want to approve Coach{" "}
        <strong>
          {data?.name} {data?.Lname}
        </strong>
        ?
      </Typography>
      <Typography
        variant="body1"
        sx={{
          ...headings,
        }}
      >
        Required Steps For Coach Profile Approval
        {incomplete && incomplete?.length > 0 && (
          <Typography variant="body1" sx={{ ...headings, color: "red" }}>
            Incomplete Steps : {incomplete?.length}/{steps.length}
          </Typography>
        )}
      </Typography>
      {loading ? (
        <CircularProgress size={25} sx={{ color: "#3aa7a3" }} />
      ) : (
        <>
          <Stepper activeStep={activeStep} orientation="vertical" nonLinear>
            {steps.map((step, index) => (
              <Step
                key={step.label}
                completed={step.completed}
                onClick={() => setActiveStep(activeStep === index ? -1 : index)}
                sx={{
                  cursor: "pointer",
                  ".css-1u4zpwo-MuiSvgIcon-root-MuiStepIcon-root.Mui-completed":
                  {
                    color: "#3aa7a3",
                  },
                  ".css-1u4zpwo-MuiSvgIcon-root-MuiStepIcon-root": {
                    color: "red",
                  },
                  ".css-4ff9q7.Mui-completed": {
                    color: "#3aa7a3",
                  },
                  ".css-4ff9q7.Mui-active ": {
                    color: "red",
                  },
                }}
              >
                <StepLabel
                // optional={
                //   index === steps.length - 1 ? (
                //     <Typography
                //       variant="caption"
                //       sx={{ color: "gray", fontFamily: "montserrat" }}
                //     >
                //       Final step
                //     </Typography>
                //   ) : null
                // }
                >
                  <span
                    style={{
                      color: `${step.completed ? "#3aa7a3" : "red"}`,
                      fontWeight: 600,
                      fontFamily: "montserrat",
                      background: "#fefefe",
                      padding: "2px 10px",
                      borderRadius: 10,
                    }}
                  >
                    {step.label}
                  </span>
                </StepLabel>
                <StepContent>
                  <Typography
                    sx={{
                      fontFamily: "montserrat",
                      fontSize: "0.951rem",
                      fontWeight: 400,
                      color: "gray",
                      px: 2,
                      textAlign: "left"
                    }}
                  >
                    {step.description}
                  </Typography>
                </StepContent>
              </Step>
            ))}
          </Stepper>
          {completedAll && (
            <Typography variant="body1" sx={{ ...headings }}>
              Coach have added all the required details into their coach
              Profile.
            </Typography>
          )}
        </>
      )}
    </Box>
  );
};

export default CoachProProgress;
const headings = {
  py: 2,
  px: 0,
  fontWeight: 600,
  fontFamily: "montserrat",
  color: "#3aa7a3",
};
