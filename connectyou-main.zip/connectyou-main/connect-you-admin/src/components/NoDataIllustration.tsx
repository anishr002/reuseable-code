import { Box, Typography } from "@mui/material";

import NoData from "../assets/NO-DATA.jpg";

const NoDataIllustration = ({
  height = "360px",
  message = "No Data to View",
}: {
  height?: string;
  message?: string;
}) => {
  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          p: 3,
          height: "80%",
        }}
      >
        <img
          src={NoData}
          alt="no-data-il"
          style={{
            height: height,
            objectFit: "contain",
          }}
        />
        <Typography variant="h6" sx={{ color: "#013338" }}>
          {message}
        </Typography>
      </Box>
    </>
  );
};

export default NoDataIllustration;
