import React, { ReactNode, useState } from "react";
import {
  IconButton,
  CircularProgress,
  Tooltip,
  IconButtonProps,
} from "@mui/material";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import { toast } from "react-toastify";

interface FileDownloadProps {
  pathname: string;
  file: string | null;
  variant: "success" | "failure";
  text?: ReactNode;
  props?: Omit<IconButtonProps, "onClick" | "disabled">;
}

const FileDownloadButton: React.FC<FileDownloadProps> = ({
  pathname,
  file,
  variant,
  text,
  props,
}) => {
  const [loading, setLoading] = useState(false);

  const handleDownload = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const link = document.createElement("a");
      link.href = `${pathname}/${file}`;
      link.download = file;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.error("Download failed:", error);
      toast.error(`${error.response.message || "Unable to download file"}`);
    } finally {
      setLoading(false);
    }
  };

  if (!file) {
    return <>-</>;
  }

  return (
    <Tooltip title="Download">
      <IconButton onClick={handleDownload} disabled={loading} {...props}>
        {loading ? (
          <CircularProgress
            size={24}
            sx={{ color: variant === "success" ? "#3aa7a3" : "red" }}
          />
        ) : (
          <>
            <DownloadForOfflineIcon
              sx={{ color: variant === "success" ? "#3aa7a3" : "red" }}
            />
            {text}
          </>
        )}
      </IconButton>
    </Tooltip>
  );
};

export default FileDownloadButton;
