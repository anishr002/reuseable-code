import "react-quill/dist/quill.snow.css";

// Define the editor modules and formats for better type safety

import { Box, Typography } from "@mui/material";

const EditableTextList = ({ text }: { text: string }) => {
  const renderSavedContent = (savedContent: string | TrustedHTML) => {
    return (
      <div
        dangerouslySetInnerHTML={{
          __html: savedContent,
        }}
      />
    );
  };

  return (
    <>
      <Box
        component={"ul"}
        sx={{
          display: "flex",
          flexDirection: "column",
          position: "relative",
          paddingInline: 4,
        }}
      >
        <Typography variant="h6" fontWeight={500}>
          {renderSavedContent(text)}
        </Typography>

        {/* Popper for edit and delete options */}
      </Box>
    </>
  );
};

export default EditableTextList;
