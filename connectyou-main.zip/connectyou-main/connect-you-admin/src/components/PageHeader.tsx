import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Box, Typography } from "@mui/material";
import { ReactNode } from "react";
import { useNavigate } from "react-router-dom";

const PageHeader = ({ children }: { children: ReactNode }) => {
  const naviagate = useNavigate();
  return (
    <Box
      sx={{
        width: "100%",
        px: 2,
        py: 0.2,
        display: "flex",
        justifyContent: "start",
        alignItems: "center",
        gap: 0.5,
      }}
    >
      <ArrowBackIosIcon
        sx={{
          color: "#013338",
          cursor: "pointer",
          "&:hover": { color: "#ebbe34" },
        }}
        onClick={() => naviagate(-1)}
      />

      <Typography
        variant="h6"
        sx={{
          fontWeight: "bold",
          padding: "1rem 0",
          width: "100%",
          flexDirection: { xs: "column", md: "row" },
          display: "flex",
          justifyContent: { xs: "start", md: "space-between" },
          gap: "5px",
          alignItems: { xs: "start", md: "center" },
          color: "#013338",
        }}
      >
        {children}
      </Typography>
    </Box>
  );
};

export default PageHeader;
