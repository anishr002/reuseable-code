/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { httpAPI_admin } from "../../AxiosAPI";
import { Typography, Switch, FormControlLabel } from "@mui/material";

const ShortlistCoachToCompany = ({
  coachId,
  variant = "full",
  showSwitchLabel = true,
}: {
  coachId: string;
  variant?: "full" | "Only-Button";
  showSwitchLabel?: boolean;
}) => {
  const [isChecked, setIsChecked] = useState(false);
  const [status, setStatus] = useState<"Shortlisted" | "Unlisted" | "New">(
    "New"
  );
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await httpAPI_admin.get(
          `/admin/coach/shortlist/status/${coachId}`
        );
        console.log(res);

        if (res.data?.shortlistStatus) {
          setStatus(res.data.shortlistStatus);
          setIsChecked(res.data.shortlistStatus === "Shortlisted");
        }
      } catch (err) {
        toast.error("Failed to fetch shortlist status");
      }
    };
    fetchStatus();
  }, [coachId]);

  const handleChange = async () => {
    setLoading(true);
    try {
      let response;
      if (!isChecked) {
        response = await httpAPI_admin.put(
          `/admin/coach/shortlist/list/${coachId}`
        );
        console.log(response);
        if (response?.data?.success) {
          toast.success(response.data.message || "Coach shortlisted");
          setStatus("Shortlisted");
          setIsChecked(true);
        } else {
          throw new Error(response.data?.message || "Shortlisting failed");
        }
      } else {
        response = await httpAPI_admin.put(
          `/admin/coach/shortlist/un-list/${coachId}`
        );
        if (response?.data?.success) {
          toast.success(response.data.message || "Coach unlisted");
          setStatus("Unlisted");
          setIsChecked(false);
        } else {
          throw new Error(response.data?.message || "Unlisting failed");
        }
      }
    } catch (err: any) {
      const message =
        err?.response?.data?.message || err?.message || "Action failed";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  if (variant === "full") {
    return (
      <div
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
        className="w-full h-fit flex justify-between items-center gap-4"
      >
        <Typography
          variant="subtitle1"
          sx={{
            color: "#013338",
            fontWeight: "bold",
          }}
        >
          Shortlist for company
        </Typography>

        <FormControlLabel
          sx={{
            px: 1,
          }}
          control={
            <Switch
              checked={isChecked}
              onChange={handleChange}
              disabled={loading}
              sx={{
                "& .MuiSwitch-switchBase.Mui-checked": {
                  // color: "#3aa7a3",
                },
                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                  // backgroundColor: "#3aa7a3",
                },
                "& .MuiSwitch-track": {
                  // backgroundColor: "#ccc",
                },
              }}
            />
          }
          label={
            showSwitchLabel ? (
              <Typography
                variant="body2"
                sx={{ color: "#013338", fontWeight: "600", fontSize:"0.8rem" }}
              >
                {status === "New" ? "" : status}
              </Typography>
            ) : undefined
          }
          labelPlacement="start"
        />
      </div>
    );
  }

  if (variant === "Only-Button") {
    return (
      <div
        style={{
          width: "100%",
        }}
        className="w-full h-fit flex justify-center items-center gap-4"
      >
        <FormControlLabel
          control={
            <Switch
              checked={isChecked}
              onChange={handleChange}
              disabled={loading}
              sx={{
                "& .MuiSwitch-switchBase.Mui-checked": {
                  // color: "#3aa7a3",
                },
                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                  // backgroundColor: "#3aa7a3",
                },
                "& .MuiSwitch-track": {
                  // backgroundColor: "#ccc",
                },
              }}
            />
          }
          labelPlacement="start"
          label={
            showSwitchLabel ? (
              <Typography variant="body2" sx={{ color: "#013338" }}>
                {status === "New" ? "" : status}
              </Typography>
            ) : undefined
          }
        />
      </div>
    );
  }
};

export default ShortlistCoachToCompany;
