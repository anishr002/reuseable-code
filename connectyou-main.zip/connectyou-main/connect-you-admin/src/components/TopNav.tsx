import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import CloseIcon from "@mui/icons-material/Close";
import AccountCircle from "@mui/icons-material/AccountCircle";
import { Divider, Typography } from "@mui/material";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { adminLogout } from "../slices/Login";
import logoImage from "../assets/Logo.png";

interface TopNavProps {
  viewportWidth: any;
  open: boolean;
  toggleDrawer: (open: boolean) => any;
}

const TopNav: React.FC<TopNavProps> = (props) => {
  const dispatch = useDispatch();
  const adminData = useSelector((state: any) => state.adminLogin.userdata);
  const { viewportWidth, open, toggleDrawer } = props;

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] =
    React.useState<null | HTMLElement>(null);

  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

  const handleProfileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };
  const navigate = useNavigate();
  const handleLogout = () => {
    dispatch(adminLogout());
    localStorage.removeItem("authToken");
    navigate("/login");
    handleMenuClose();
  };



  const menuId = "primary-search-account-menu";
  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={menuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMenuOpen}
      onClose={handleMenuClose}
      style={{
        marginTop: 48,
        width: "300px",
      }}
    >
      <Box sx={{ my: 1.5, px: 2 }}>
        <Typography variant="subtitle2" noWrap>
          {adminData.name}
        </Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }} noWrap>
          {adminData.email}
        </Typography>
      </Box>

      <Divider sx={{ borderStyle: "dashed" }} />

      <MenuItem onClick={()=>{handleMenuClose();
        navigate('/profile')
      }} sx={{ padding: "0px 0px" }}>
        <IconButton
          size="large"
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <p>Profile</p>
      </MenuItem>

      <MenuItem onClick={handleLogout} sx={{ padding: "0px 0px" }}>
        <IconButton
          size="large"
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <ExitToAppIcon />
        </IconButton>
        <p>Log out</p>
      </MenuItem>
    </Menu>
  );

  const mobileMenuId = "primary-search-account-menu-mobile";
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
      style={{
        marginTop: 48,
        width: "300px",
      }}
    >
      <Box sx={{ my: 1.5, px: 2 }}>
        <Typography variant="subtitle2" noWrap>
          Admin
        </Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }} noWrap>
          admin@gmail.com
        </Typography>
      </Box>
      <Divider sx={{ borderStyle: "dashed" }} />
      {/* <MenuItem>
                <IconButton size="large" aria-label="show 4 new mails" color="inherit">
                    <Badge badgeContent={4} color="error">
                        <MailIcon />
                    </Badge>
                </IconButton>
                <p>Messages</p>
            </MenuItem> */}
      {/* <MenuItem onClick={handleMenuClose} sx={{ padding: "0px 0px" }}>
        <IconButton
          size="large"
          aria-label="show 17 new notifications"
          color="inherit"
        >
          <Badge badgeContent={17} color="error">
            <NotificationsIcon />
          </Badge>
        </IconButton>
        <p>Notifications</p>
      </MenuItem> */}
      <MenuItem onClick={()=>{handleMenuClose();
        navigate('/profile')
      }} sx={{ padding: "0px 0px" }}>
        <IconButton
          size="large"
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <p>Profile</p>
      </MenuItem>
      <MenuItem onClick={handleMenuClose} sx={{ padding: "0px 0px" }}>
        <IconButton
          size="large"
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <ExitToAppIcon />
        </IconButton>
        <p>Log out</p>
      </MenuItem>
    </Menu>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar
        position="fixed"
        // style={{ backgroundColor: "#5FB6D5", height: "70px" }}
        style={{ backgroundColor: "white", height: "70px" }}
      >
        <Toolbar>
          <IconButton
            sx={{
              mr: 2,
              display: {
                xs: "flex",
                md: "none",
                color: "black",
              },
            }}
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            onClick={toggleDrawer(!open)}
          >
            {open || viewportWidth > 888 ? <CloseIcon /> : <MenuIcon />}
          </IconButton>
          <Box display="flex" alignItems="center">
            <img
              src={logoImage}
              alt="Logo"
              style={{ height: "40px", objectFit: "contain" }}
            />
            {/* <img
              src="https://s3-alpha-sig.figma.com/img/b5b5/ff38/81474f714cd72f7a3800cd6a568d6dd3?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=fxwXep-uLjKyCayMjzgszIF~P2HPzUvPHHA0Cw3C26~ZRShCL4S7BEoI4fwE19~Sqz28LHvRQRoCzekfBIBXeoy1cRJNC4SJJwTrSP7jHrldFMxojysPjGGIZh2TLIJ4Semgj26CNzAdK6uzuNCSq1VeqLjm2HTE7galZviFeElNbo3L~ppStTJvzExzFwMt6ToBrmYUBQjrqS3HuvZhrEYXm4YbrWRcwW0e2WojgapGFlIixQO2y2JJf9ufzaZaMVQP6CdVmykyrcKB-V-sjFQDHpUxrTlMzQX21WeNGuK-SzFtEAPe-5wU-9COj3nBrz~H~BwykNY9zVb5vrHp7A__"
              alt="Logo"
              style={{ height: "60px", width: "90px" }}
            /> */}
          </Box>

          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: { xs: "none", md: "flex" } }}>
            {/* <IconButton
              size="large"
              aria-label="show 17 new notifications"
              color="inherit"
            >
              <Link to="/notification">
                <Badge badgeContent={0} color="error">
                  <NotificationsIcon />
                </Badge>
              </Link>
            </IconButton> */}
            <IconButton
              size="large"
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
            >
              <AccountCircle />
            </IconButton>
          </Box>
          <Box sx={{ display: { xs: "flex", md: "none" } }}>
            <IconButton
              size="large"
              aria-label="show more"
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <AccountCircle />
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>
      {renderMobileMenu}
      {renderMenu}
    </Box>
  );
};

export default TopNav;
