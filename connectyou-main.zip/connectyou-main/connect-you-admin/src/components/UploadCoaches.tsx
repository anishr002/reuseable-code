import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFile";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import React, { useState } from "react";
import { AxiosError } from "axios";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import {
  Box,
  Button,
  Typography,
  CircularProgress,
  Alert,
  Container,
} from "@mui/material";
import { BulkAddOppAPIRes } from "../types/BulkAddReports";

const UploadCoaches: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);
  const [result, setResult] = useState<BulkAddOppAPIRes | null>(null);
  const [inputKey, setInputKey] = useState<number>(Date.now()); // Force re-render of input field

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    console.log("file selected now", { selectedFile: selectedFile?.name });

    if (selectedFile) {
      if (
        selectedFile.type === "text/csv" ||
        selectedFile.name.endsWith(".csv")
      ) {
        setFile(selectedFile);
        setError(null);
        setResult(null);
        setSuccess(false);
        setUploading(false);
      } else {
        setError("Please upload a valid CSV file.");
        setFile(null);
      }
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setError("Please select a CSV file to upload.");
      return;
    }

    setUploading(true);
    setError(null);
    setSuccess(false);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await httpAPI_admin.post(
        `${backendURL}/admin/add-data/coach/upload-coaches`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      if (response.status === 200) {
        setSuccess(true);
        setResult(response.data);
        setFile(null); // Reset file after upload
        setInputKey(Date.now()); // Reset file input field
      } else {
        setError("Failed to upload the file. Please try again.");
      }
    } catch (err) {
      const error = err as AxiosError;
      setError(error.message || "An error occurred while uploading the file.");
      console.error(error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        alignItems: "start",
        justifyContent: "start",
        flexDirection: "column",
        px: 1,
      }}
    >
      <Box
        sx={{
          width: "100%",
          pb: 4,
          bgcolor: "#fff",
          borderRadius: 2,
        }}
      >
        {/* Title */}
        <Container
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
            borderBottom: "1px solid #ddd",
            pb: 2,
          }}
        >
          <Typography
            variant="h6"
            fontWeight="bold"
            color="#013338"
            textAlign="left"
            py={2}
          >
            Upload Coaches Data
          </Typography>

          {error && (
            <Alert
              severity="error"
              sx={{ mt: 2, width: "fit-content", minWidth: 300, px: 4 }}
            >
              {error}
            </Alert>
          )}

          {/* Success Message */}
          {success && (
            <Alert
              severity="success"
              sx={{ mt: 2, width: "fit-content", minWidth: 300, px: 4 }}
            >
              Bulk write task completed successfully!
            </Alert>
          )}
        </Container>

        <Container
          sx={{
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          {uploading ? (
            <Alert severity="warning">
              Please do not leave or refresh this page until the loading is
              completed.
            </Alert>
          ) : (
            <div></div>
          )}

          {/* Upload Button */}
          <Button
            onClick={handleUpload}
            variant="contained"
            sx={{
              width: 200,
              bgcolor: "#013338",
              color: "white",
              "&:hover": { bgcolor: "#002a2e" },
            }}
            disabled={uploading || !file}
          >
            {uploading ? (
              <CircularProgress size={24} color="inherit" />
            ) : (
              "Upload"
            )}
          </Button>
        </Container>

        {/* Custom File Input */}
        <Container sx={{ textAlign: "left", pt: 4 }}>
          <input
            key={inputKey} // Force input re-render when file is cleared
            type="file"
            accept=".csv"
            id="file-upload"
            style={{ display: "none" }}
            onChange={handleFileChange}
            disabled={uploading}
          />
          <label htmlFor="file-upload">
            <Button
              disabled={uploading}
              variant="contained"
              component="span"
              sx={{
                bgcolor: file ? "#ebbd33" : "#3aa7a3",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
                color: "white",
                px: 4,
                gap: 2,
                width: "100%",
                py: 6,
                "&:hover": { bgcolor: file ? "#d1a020" : "#2e8985" },
              }}
            >
              <div>
                {file ? (
                  <InsertDriveFileIcon sx={{ fontSize: "2.1rem" }} />
                ) : (
                  <FileUploadIcon sx={{ fontSize: "2.1rem" }} />
                )}
              </div>
              <span
                style={{
                  color: "white",
                  fontWeight: "600",
                  fontSize: "1.2rem",
                }}
              >
                {file ? ` ${file.name}` : " Choose CSV File"}
              </span>
            </Button>
          </label>

          {/* File Name & Instructions */}
          {file && (
            <Typography mt={1} color="#013338" fontSize={14}>
              <strong>Selected File:</strong> {file.name}
            </Typography>
          )}
          <Typography mt={1} color="gray" fontSize={12}>
            Only CSV files are allowed.
          </Typography>
        </Container>
        {/* Display Result */}

        {result && (
          <Box sx={{ mt: 3, p: 2, borderRadius: 1 }}>
            <Typography fontWeight="bold" color="#013338">
              Upload Summary
            </Typography>
            <Typography>
              Successful Entries: {result?.data?.successNumber}
            </Typography>
            <Typography>
              Failed Entries: {result?.data?.failureNumber}
            </Typography>

            {/* Download Buttons */}
            <Box
              sx={{ mt: 2, display: "flex", flexDirection: "column", gap: 1 }}
            >
              {result?.files?.success && (
                <a
                  href={`${backendURL}/files/${result?.files?.success}`}
                  download={`${backendURL}/files/${result?.files?.success}`}
                >
                  <Button
                    variant="outlined"
                    sx={{
                      color: "#013338",
                      borderColor: "#013338",
                      width: 300,
                    }}
                  >
                    Download Successful Entries
                  </Button>
                </a>
              )}
              {result?.files?.failure && (
                <a
                  href={`${backendURL}/files/${result?.files?.failure}`}
                  download={`${backendURL}/files/${result?.files?.failure}`}
                >
                  <Button
                    variant="outlined"
                    sx={{
                      color: "#d32f2f",
                      borderColor: "#d32f2f",
                      width: 300,
                    }}
                  >
                    Download Failed Entries
                  </Button>
                </a>
              )}
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default UploadCoaches;
