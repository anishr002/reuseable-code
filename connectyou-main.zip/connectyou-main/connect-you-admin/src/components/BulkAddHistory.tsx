import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import { Alert, Box, Pagination, TableCell, Typography } from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import BulkAddReportsType from "../types/BulkAddReports";
import FileDownloadButton from "./FileDownloadButton";
import dayjs from "dayjs";
import MenuButton, { MenuOption } from "./buttons/MenuButton";

const BulkAddHistory: React.FC = () => {
  const [data, setData] = React.useState<BulkAddReportsType[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
  });
  const [pageNo, setPageNo] = React.useState(1);
  React.useEffect(() => {
    console.log({ pageInfo });
  }, [pageInfo]);
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/add-data/history?pageNo=${pageNo}&limit=10`
      );
      console.log(response);
      if (response.data.success) {
        setPageInfo({
          totalPages: response.data.totalPages,
        });
        return setData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "hidden",
          height: `100%`,
          maxHeight: "calc(100vh - 88px)",
        }}
        elevation={0}
      >
        {data?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "100%",

                overflow: "auto",
                minWidth: "fit-content",
              }}
              className="style-scroll"
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    {[
                      "Entry Type",
                      "Data Source",
                      "Dated",
                      "Result",
                      "Count",
                      "Entries",
                    ].map((header, index) => (
                      <TableCell
                        key={index}
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                          whiteSpace: "nowrap",
                          position: "sticky",
                          top: 0,
                          zIndex: 1100,
                        }}
                      >
                        {header}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data?.map((row, index) => (
                    <TableRow
                      hover
                      role="checkbox"
                      tabIndex={-1}
                      key={index}
                      sx={{}}
                    >
                      <TableCell
                        sx={{
                          wordBreak: { xs: "keep-all", md: "keep-all" },
                          color: "#013338",
                          fontWeight: 500,
                        }}
                      >
                        {row.entry_type || "-"}
                      </TableCell>
                      <TableCell
                        sx={{
                          wordBreak: { xs: "keep-all", md: "keep-all" },
                          color: "#013338",
                          fontWeight: 500,
                        }}
                      >
                        {row?.dataSource || "-"}
                      </TableCell>
                      <TableCell
                        sx={{
                          whiteSpace: "nowrap",
                          color: "#013338",
                          fontWeight: 500,
                        }}
                      >
                        {dayjs(row.createdAt).format(`DD MMMM YYYY hh:mm A`) ||
                          "-"}
                      </TableCell>
                      <TableCell
                        sx={{ width: "fit-content", whiteSpace: "nowrap" }}
                      >
                        <Alert
                          severity={`${
                            row.result === "Success"
                              ? "success"
                              : row.result === "Partial Success"
                              ? "warning"
                              : "error"
                          }`}
                          title={`${row.result}`}
                          sx={{ p: 1 }}
                        >
                          {`${row.result}`}
                          {/* Partial Success */}
                        </Alert>
                      </TableCell>
                      <TableCell
                        sx={{
                          whiteSpace: "nowrap",
                          fontSize: "1rem",
                          width: "fit-content",
                          color: "#013338",
                          fontWeight: 500,
                        }}
                      >
                        <Box>
                          <Typography variant="body2" sx={{color:"#013338"}}>
                            Successfull :{" "}
                            {row.successCount
                              ? row.successCount?.toString()?.padStart(2, "0")
                              : "-"}
                          </Typography>
                          <Typography variant="body2" sx={{color:"red"}}>
                            Failed :{" "}
                            {row.failureCount
                              ? row.failureCount?.toString()?.padStart(2, "0")
                              : "-"}
                          </Typography>
                        </Box>
                      </TableCell>

                      <TableCell
                        sx={{
                          whiteSpace: "nowrap",
                          fontSize: "1rem",
                          width: "fit-content",
                          color: "#013338",
                        }}
                      >
                        <MenuButton>
                          {(() => {
                            const array: MenuOption[] = [];
                            if (row.successFilepath) {
                              array.push({
                                label: (
                                  <FileDownloadButton
                                    props={{
                                      sx: {
                                        p: 0,
                                        "&:hover": {
                                          background: "transparent",
                                        },
                                      },
                                    }}
                                    file={row.successFilepath}
                                    pathname={`${backendURL}/files`}
                                    variant="success"
                                    text={
                                      <Typography
                                        variant="body2"
                                        sx={{ ml: 0.5 }}
                                      >
                                        Download Successfull Entries
                                      </Typography>
                                    }
                                  />
                                ),
                                action: () => undefined,
                              });
                            }
                            if (row.failureFilepath) {
                              array.push({
                                label: (
                                  <FileDownloadButton
                                    props={{
                                      sx: {
                                        p: 0,
                                        "&:hover": {
                                          background: "transparent",
                                        },
                                      },
                                    }}
                                    file={row.failureFilepath}
                                    pathname={`${backendURL}/files`}
                                    variant="failure"
                                    text={
                                      <Typography
                                        variant="body2"
                                        sx={{ ml: 0.5 }}
                                      >
                                        Download Failed Entries
                                      </Typography>
                                    }
                                  />
                                ),
                                action: () => undefined,
                              });
                            }

                            return array;
                          })()}
                        </MenuButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {pageInfo?.totalPages > 1 && (
                <Box
                  sx={{
                    display: "flex",
                    position: "sticky",
                    bottom: 0,
                    background: "white",
                    justifyContent: "start",
                    alignItems: "center",
                    paddingY: 2,
                    borderTop: "2px solid #ccc",
                    height: "fit-content",
                  }}
                >
                  <Pagination
                    count={Number(pageInfo?.totalPages)}
                    page={Number(pageNo)}
                    onChange={handlePagination}
                  />
                </Box>
              )}
            </TableContainer>
          </>
        ) : (
          <NoDataIllustration message="No data ! " />
        )}
      </Paper>
    </>
  );
};
export default BulkAddHistory;
