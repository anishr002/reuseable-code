import { Box, Button, Paper, Typography } from "@mui/material";
import React, { ReactNode, useEffect, useState } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";

export interface OperationResult {}
export interface EntryRecord {}

export type Routes = "coach" | "coach-hubspot" | "user" | "history";
const CSVUploadComponent: React.FC = () => {
  const location = useLocation();
  const [activeRoute, setActiveRoute] = useState<Routes>("coach");

  useEffect(() => {
    console.log(location, location.pathname);
    // Determine the active route based on the current pathname
    if (location.pathname.includes("user")) {
      setActiveRoute("user");
    } else if (location.pathname.includes("history")) {
      setActiveRoute("history");
    } else if (location.pathname.includes("coach-hubspot")) {
      setActiveRoute("coach-hubspot");
    } else {
      setActiveRoute("coach");
    }
  }, [location.pathname]);

  useEffect(() => {
    console.log({ activeRoute });
  }, [activeRoute]);

  return (
    <Paper
      sx={{
        width: "100%",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        height: "calc(100vh - 88px)",
      }}
    >
      {/* Header */}
      <Typography
        variant="h6"
        sx={{
          fontWeight: "bold",
          px: 2,
          pt: 2,
          width: "100%",
          display: "flex",
          justifyContent: { xs: "start", md: "space-between" },
          alignItems: { xs: "start", md: "center" },
          color: "#013338",
          background: "#fff",
          zIndex: 10,
          mb: 1,
        }}
      >
        <div style={{ position: "relative", display: "flex" }}>
          Batch User Upload
        </div>
      </Typography>

      {/* Navigation Tabs */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "start",
          borderBottom: "2px solid #ddd",
          px: 1,
          background: "#fff",
          zIndex: 9,
        }}
      >
        {/* Coachee Tab (Disabled) */}
        {/* <Link to="/bulk-add/user"> */}
        <Button
          disabled
          sx={{
            px: 4,
            borderRadius: 0,
            borderBottom: "2px solid transparent",
            color: "#013338",
            boxShadow: "none",
            display: "none",
            "&:hover": {
              backgroundColor: "transparent",
            },
          }}
        >
          Coachee
        </Button>

        {/* History Tab */}
        <TabButton href={"/bulk-add/coach"} isActive={activeRoute === "coach"}>
          Coach CSV Upload
        </TabButton>
        <TabButton
          href={"/bulk-add/coach-hubspot"}
          isActive={activeRoute === "coach-hubspot"}
        >
          Coach Hubspot Sync
        </TabButton>
        <TabButton
          href={"/bulk-add/history"}
          isActive={activeRoute === "history"}
        >
          History
        </TabButton>
      </Box>

      {/* Outlet Area */}
      <Box
        sx={{
          flexGrow: 1,
          overflow: "auto",
        }}
        className="style-scroll"
      >
        <Outlet />
      </Box>
    </Paper>
  );
};

export default CSVUploadComponent;

const TabButton = ({
  isActive,
  children,
  href,
}: {
  isActive?: boolean;
  children?: ReactNode;
  href: string;
}) => {
  return (
    <Link to={href}>
      <Button
        sx={{
          borderRadius: 0,
          px: 4,
          borderBottom: isActive
            ? "2px solid #ebbd33"
            : "2px solid transparent",
          color: isActive ? "#ebbd33" : "#013338",
          boxShadow: "none",
          "&:hover": {
            backgroundColor: "transparent",
          },
        }}
      >
        {children}
      </Button>
    </Link>
  );
};
