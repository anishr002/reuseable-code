/* eslint-disable @typescript-eslint/no-explicit-any */
import ContentPasteIcon from "@mui/icons-material/ContentPaste";
import PaidIcon from "@mui/icons-material/Paid";
import ReceiptIcon from "@mui/icons-material/Receipt";
import LiveHelpIcon from "@mui/icons-material/LiveHelp";
import AssignmentIcon from "@mui/icons-material/Assignment";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import * as React from "react";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import { useLocation } from "react-router-dom";
import { AccountCircle, Dashboard } from "@mui/icons-material";
import NotificationsIcon from "@mui/icons-material/Notifications";
import GroupIcon from "@mui/icons-material/Group";
import { Link } from "react-router-dom";
import ViewListIcon from "@mui/icons-material/ViewList";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import { useDispatch, useSelector } from "react-redux";
import { setCount } from "../slices/Notification";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { setPendingCount } from "../slices/PendingApprovalCount";
import LocalLibraryIcon from "@mui/icons-material/LocalLibrary";
interface TemporaryDrawerProps {
  viewportWidth: any;
  open: boolean;
  toggleDrawer: (open: boolean) => any;
}

const SideNav: React.FC<TemporaryDrawerProps> = (props) => {
  const { viewportWidth, open, toggleDrawer } = props;
  const location = useLocation();
  const isActiveRoute = (route: string): boolean => {
    // Handle the home route separately
    if (route === "/") {
      return location.pathname === "/";
    }
    if (location.pathname === route) {
      return true;
    }
    const dynamicRoutePattern = new RegExp(
      `^${route.replace(/:\w+/g, "[^/]+")}$`
    );
    return dynamicRoutePattern.test(location.pathname);
  };

  const unreadCount = useSelector(
    (state: any) => state.unreadCount.unReadNotificationCount
  );

  const loginUserData = useSelector((state: any) => state.adminLogin.userdata);
  const dispatch = useDispatch();
  const fetchNotifications = async () => {
    try {
      const response = await httpAPI_admin.post(
        `${backendURL}/admin/profile/get-all-notifications`,

        { _id: loginUserData._id }
      );
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        dispatch(setCount(response.data.unreadNotifications));
      }
    } catch (error: any) {
      console.log(error);
    }
  };
  const fetchPendingApprovalData = async () => {
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/new-profile-approval-requests?pageNo=1&filter=2`
      );
      if (response.data.success) {
        dispatch(setPendingCount(response.data.data.length));
        return;
      }
    } catch (error) {
      console.log({ error });
    }
  };
  React.useEffect(() => {
    fetchNotifications();
    fetchPendingApprovalData();
  }, [loginUserData, isActiveRoute]);

  return (
    <Box
      id="meadia-query"
      sx={{
        width: 250,
        position: "fixed",
        top: "70px",
        left: 0,
        bottom: 0,
        backgroundColor: "#5FB6D5",
        color: "white",
        boxShadow: "2px 0px 5px rgba(0, 0, 0, 0.1)",
        transform:
          open || viewportWidth > 888 ? "translateX(0)" : "translateX(-100%)",
        transition: "transform 0.3s ease-in-out",
        zIndex: 1200,
        overflowY: "auto",
        WebkitOverflowScrolling: "touch",
        "&::-webkit-scrollbar": {
          width: "4px",
        },
        "&::-webkit-scrollbar-track": {
          background: "#f1f1f1",
        },
        "&::-webkit-scrollbar-thumb": {
          background: "#888",
          borderRadius: "4px",
        },
      }}
    >
      <List sx={{ paddingTop: 0 }}>
        {/* dashboard  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/") ? "#013338" : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton selected={isActiveRoute("/")} component={Link} to="/">
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <Dashboard style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Dashboard" />
          </ListItemButton>
        </ListItem>

        {/* coaches  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor:
              isActiveRoute("/coach") || isActiveRoute("/coach/detail/:id")
                ? "#013338"
                : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/coach")}
            component={Link}
            to="/coach"
          >
            <ListItemIcon
              sx={{
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <GroupIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Coaches" />
          </ListItemButton>
        </ListItem>

        {/* approvals  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/pending-coaches")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/pending-coaches")}
            component={Link}
            to="/pending-coaches"
          >
            <ListItemIcon
              sx={{
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <PersonAddIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Unapproved Coaches" />
          </ListItemButton>
        </ListItem>

        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor:
              isActiveRoute("/approvals") || isActiveRoute("/approvals/history")
                ? "#013338"
                : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/approvals")}
            component={Link}
            to="/approvals"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <PersonAddIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Pending Approvals" />
          </ListItemButton>
        </ListItem>

        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/coach/coach-agreements")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/coach/coach-agreements")}
            component={Link}
            to="/coach/coach-agreements"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <ContentPasteIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Coach Agreements" />
          </ListItemButton>
        </ListItem>
        {/* shortlisted-coaches  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/shortlisted-coaches")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/shortlisted-coaches")}
            component={Link}
            to="/shortlisted-coaches"
          >
            <ListItemIcon
              sx={{
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <GroupIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Shortlisted Coaches" />
          </ListItemButton>
        </ListItem>
        {/* coachee  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor:
              isActiveRoute("/coachee") || isActiveRoute("/coachee/detail/:id")
                ? "#013338"
                : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/coachee")}
            component={Link}
            to="/coachee"
          >
            <ListItemIcon
              sx={{
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <GroupIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Coachee" />
          </ListItemButton>
        </ListItem>
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor:
              isActiveRoute("/bulk-add") ||
              isActiveRoute("/bulk-add/coach") ||
              isActiveRoute("/bulk-add/history") ||
              isActiveRoute("/bulk-add/user")
                ? "#013338"
                : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={
              isActiveRoute("/bulk-add") ||
              isActiveRoute("/bulk-add/coach") ||
              isActiveRoute("/bulk-add/history") ||
              isActiveRoute("/bulk-add/user")
            }
            component={Link}
            to="/bulk-add"
          >
            <ListItemIcon
              sx={{
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <PersonAddIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Batch User Upload" />
          </ListItemButton>
        </ListItem>
        {/* payouts  */}

        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor:
              isActiveRoute("/payout") || isActiveRoute("/payout/detail")
                ? "#013338"
                : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/payout")}
            component={Link}
            to="/payout"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <AccountBalanceIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Payout" />
          </ListItemButton>
        </ListItem>
        {/* bookings  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor:
              isActiveRoute("/bookings") ||
              isActiveRoute("/bookings/detail/:id")
                ? "#013338"
                : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/bookings")}
            component={Link}
            to="/bookings"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <ViewListIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Bookings" />
          </ListItemButton>
        </ListItem>

        {/* bookings  Reports*/}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/bookings/booking-reports")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/bookings/booking-reports")}
            component={Link}
            to="/bookings/booking-reports"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px",
                marginRight: "4px",
              }}
            >
              <ReceiptIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Booking Reports" />
          </ListItemButton>
        </ListItem>
        {/* refund request page  */}

        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/refunds") ? "#013338" : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/refunds")}
            component={Link}
            to="/refunds"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <PaidIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Refund Requests" />
          </ListItemButton>
        </ListItem>

        {/* t&C  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/terms-conditions")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/terms-conditions")}
            component={Link}
            to="/terms-conditions"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <AssignmentIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Terms-Conditions" />
          </ListItemButton>
        </ListItem>
        {/* privacy-policy  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/privacy-policy")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/privacy-policy")}
            component={Link}
            to="/privacy-policy"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <AssignmentIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Privacy Policy" />
          </ListItemButton>
        </ListItem>
        {/* cookie-policy  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/cookie-policy")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/cookie-policy")}
            component={Link}
            to="/cookie-policy"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <AssignmentIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Cookie Policy" />
          </ListItemButton>
        </ListItem>
        {/* enquiry  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/enquiries")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/enquiries")}
            component={Link}
            to="/enquiries"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <LiveHelpIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Enquiries" />
          </ListItemButton>
        </ListItem>
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/coach-resource")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={
              isActiveRoute("/resource") || isActiveRoute("/resource/details")
            }
            component={Link}
            to="/resource"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <LocalLibraryIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Resource" />
          </ListItemButton>
        </ListItem>
        <ListItem
          sx={{
            cursor: "pointer",
            display: "none", // remove if coachee req
            backgroundColor: isActiveRoute("/coachee-resource")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/coachee-resource")}
            component={Link}
            to="/coachee-resource"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <LocalLibraryIcon style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Coachee Resource" />
          </ListItemButton>
        </ListItem>

        {/* notifications  */}
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/notification")
              ? "#013338"
              : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/notification")}
            component={Link}
            to="/notification"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <NotificationsIcon style={{ color: "white" }} />

              {/* Notification Bubble */}
              {unreadCount > 0 && (
                <span
                  style={{
                    background: "#ebbe34",
                    color: "white",
                    width: "20px",
                    height: "20px",
                    borderRadius: "50%",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    fontSize: "0.75rem",
                    position: "absolute",
                    top: -5, // Position above the icon
                    right: "0%", // Position to the top right
                    boxShadow: "0px 0px 8px rgba(0, 0, 0, 0.15)", // Optional shadow for effect
                  }}
                >
                  {unreadCount > 99 ? "99+" : unreadCount}
                </span>
              )}
            </ListItemIcon>
            <ListItemText primary="Notifications" />
          </ListItemButton>
        </ListItem>
        <ListItem
          sx={{
            cursor: "pointer",
            backgroundColor: isActiveRoute("/profile") ? "#013338" : "inherit",
          }}
          disablePadding
          onClick={toggleDrawer(false)}
        >
          <ListItemButton
            selected={isActiveRoute("/profile")}
            component={Link}
            to="/profile"
          >
            <ListItemIcon
              sx={{
                position: "relative",
                minWidth: "30px", // Reduce default minWidth (default is 56px)
                marginRight: "4px", // Optionally add a smaller margin
              }}
            >
              <AccountCircle style={{ color: "white" }} />
            </ListItemIcon>
            <ListItemText primary="Profile" />
          </ListItemButton>
        </ListItem>
      </List>
      {/* <Divider /> */}
    </Box>
  );
};

export default SideNav;
