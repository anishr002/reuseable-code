import MoreVertIcon from "@mui/icons-material/MoreVert";
import {
  Box,
  Typography,
  Card,
  CardContent,
  IconButton,
  Popover,
  Button,
} from "@mui/material";
import React from "react";
import { NavLink } from "react-router-dom";

const ResourceRender = ({
  _id,
  title,
  description,
  onEdit,
  onDelete,
  buttonShow,
}: {
  _id: string;
  title: string;
  description: string;
  buttonShow: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
}) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  // Open popper for options
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // Close popper
  const handleClose = () => {
    setAnchorEl(null);
  };

  // Render HTML content safely

  return (
    <Box className="style-scroll" sx={{ marginBottom: 2 }}>
      <Card
        sx={{
          boxShadow: 3,
          borderRadius: 2,
          overflow: "hidden",
          p: 2,
          position: "relative",
        }}
      >
        <Typography variant="h6" fontWeight={600} sx={{ flexGrow: 1 , color:"#013338"}}>
          Resource Details
        </Typography>
        <CardContent sx={{ padding: 1 }}>
          <Box
            sx={{
              display: "flex",

              mb: 2,
            }}
          >
            <Typography variant="h6" fontWeight={500} sx={{ flexGrow: 1 }}>
              {title}
            </Typography>

            {/* Popover button for actions */}
            <IconButton
              onClick={handleClick}
              sx={{
                width: "fit-content",
                height: "fit-content",
                position: "absolute",
                top: 1,
                right: 1,
                zIndex: 1,
              }}
            >
              <MoreVertIcon sx={{ color: "#3aa7a3" }} />
            </IconButton>
          </Box>
          {/* Description Content */}
          <Typography variant="body1" sx={{ mb: 2 }}>
            {description}
          </Typography>
          {/* Description Content */}
          {buttonShow && (
            <NavLink to={`details/${_id}`} style={{ textDecoration: "none" }}>
              <Button
                variant="contained"
                sx={{
                  backgroundColor: "#013338",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "#013338", // Ensures the color remains the same on hover
                  },
                }}
              >
                View Details
              </Button>
            </NavLink>
          )}
          {/* Popover for edit/delete options */}
          <Popover
            open={Boolean(anchorEl)}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "right",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "right",
            }}
          >
            <Box sx={{ p: 2 }}>
              <Typography
                variant="body2"
                onClick={() => {
                  handleClose();
                  onEdit && onEdit();
                }}
                sx={{ cursor: "pointer", color: "#1976d2", mb: 1  , pr:3}}
              >
                Edit 
              </Typography>
              <Typography
                variant="body2"
                onClick={() => {
                  handleClose();
                  onDelete && onDelete();
                }}
                sx={{ cursor: "pointer", color: "#d32f2f" , pr:3 }}
              >
                Delete
              </Typography>
            </Box>
          </Popover>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ResourceRender;
