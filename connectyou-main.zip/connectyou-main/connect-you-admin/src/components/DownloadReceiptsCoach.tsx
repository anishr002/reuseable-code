import React, { useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import {
  Paper,
  Tabs,
  Tab,
  Button,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Typography,
  CircularProgress,
  Box,
} from "@mui/material";

import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { useParams } from "react-router-dom";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";
import { toast } from "react-toastify";
import FilePreview from "./FilePreview";

// Component for managing monthly receipts
const MonthlyReceipts: React.FC = () => {
  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm<{ month: string; year: string }>({ mode: "onSubmit" });
  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [noOrder, setNoOrder] = useState<boolean>(false);

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const years = Array.from({ length: 3 }, (_, i) =>
    (new Date().getFullYear() - i).toString()
  );

  const { coachId } = useParams();
  const onSubmit: SubmitHandler<{ month: string; year: string }> = async (
    data
  ) => {
    setShowDownload(false);
    setNoOrder(false);
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/coach/payout-history-coach/gen-rec/monthly/${coachId}/${data.month}/${data.year}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setReceipt(response.data.receipt);
          setShowDownload(true);
          setNoOrder(false);
        } else {
          setShowDownload(false);
          setNoOrder(true);
        }
      }
    } catch (error) {
      console.log("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      style={{ display: "flex", flexDirection: "column", gap: "16px" }}
    >
      <FormControl fullWidth error={!!errors.month}>
        <InputLabel id="month-select-label">Month</InputLabel>
        <Select
          labelId="month-select-label"
          {...register("month", { required: "Month is required" })}
        >
          {months.map((month) => (
            <MenuItem key={month} value={month}>
              {month}
            </MenuItem>
          ))}
        </Select>
        {errors.month && (
          <Typography variant="caption" color="error">
            {errors.month.message}
          </Typography>
        )}
      </FormControl>

      <FormControl fullWidth error={!!errors.year}>
        <InputLabel id="year-select-label">Year</InputLabel>
        <Select
          labelId="year-select-label"
          {...register("year", { required: "Year is required" })}
        >
          {years.map((year) => (
            <MenuItem key={year} value={year}>
              {year}
            </MenuItem>
          ))}
        </Select>
        {errors.year && (
          <Typography variant="caption" color="error">
            {errors.year.message}
          </Typography>
        )}
      </FormControl>

      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
          py: 1,
          flexDirection: "column",
        }}
      >
        {!receipt ? (
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            {loading ? (
              <CircularProgress size={24} sx={{ color: "white" }} />
            ) : (
              "Get Receipt"
            )}
          </Button>
        ) : (
          <Box
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
            onClick={() => {
              setLoading(false);
              setNoOrder(false);
              setReceipt(null);
              setShowDownload(false);
            }}
          >
            Clear
          </Box>
        )}
        {showDownload && receipt && (
          <FilePreview
            file={receipt}
            fileUrl={`${backendURL}/receipt/${receipt}`}
          />
        )}
      </Box>

      {noOrder && (
        <Typography color="error" align="center">
          This Coach do not have any payout history during this period, Please
          change the filter and try again.
        </Typography>
      )}
    </form>
  );
};

const YearlyReceipts: React.FC = () => {
  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm<{ year: string }>({ mode: "onSubmit" });

  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [noOrder, setNoOrder] = useState<boolean>(false);

  const years = Array.from({ length: 3 }, (_, i) =>
    (new Date().getFullYear() - i).toString()
  );

  const { coachId } = useParams();
  const onSubmit: SubmitHandler<{ year: string }> = async (data) => {
    setShowDownload(false);
    setNoOrder(false);
    setLoading(true);
    try {
      setLoading(true);
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/coach/payout-history-coach/gen-rec/yearly/${coachId}/${data.year}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setReceipt(response.data.receipt);
          setShowDownload(true);
          setNoOrder(false);
        } else {
          setNoOrder(true);
          setShowDownload(false);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.log("faching error", error);
    }
  };

  return (
    <form
      style={{ display: "flex", flexDirection: "column", gap: "16px" }}
      onSubmit={handleSubmit(onSubmit)}
    >
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Year</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            label="Year"
            {...register("year", { required: "Please select a year" })}
            error={!!errors.year}
          >
            {years.map((y) => (
              <MenuItem value={y}>{y}</MenuItem>
            ))}
          </Select>
        </FormControl>
        {errors.year && (
          <Typography variant="caption" color="error">
            {errors.year.message}
          </Typography>
        )}
      </Box>
      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
          py: 1,
          flexDirection: "column",
        }}
      >
        {!receipt ? (
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            {loading ? (
              <CircularProgress size={24} sx={{ color: "white" }} />
            ) : (
              "Get Receipt"
            )}
          </Button>
        ) : (
          <Box
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
            onClick={() => {
              setLoading(false);
              setNoOrder(false);
              setReceipt(null);
              setShowDownload(false);
            }}
          >
            Clear
          </Box>
        )}
        {showDownload && receipt && (
          <FilePreview
            file={receipt}
            fileUrl={`${backendURL}/receipt/${receipt}`}
          />
        )}
      </Box>
      {noOrder && (
        <>
          <Typography color="error" align="center">
            This Coach do not have any payout history during this period, Please
            change the filter and try again.
          </Typography>
        </>
      )}
    </form>
  );
};

const CustomReceipts: React.FC = () => {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    setValue,
  } = useForm<{ from: string; to: string }>({ mode: "onChange" });

  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [noOrder, setNoOrder] = useState<boolean>(false);
  const { coachId } = useParams();

  const onSubmit: SubmitHandler<{ from: string; to: string }> = async (
    data
  ) => {
    setShowDownload(false);
    setNoOrder(false);
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/coach/payout-history-coach/gen-rec/periodic/${coachId}/${data.from}/${data.to}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setReceipt(response.data.receipt);
          setShowDownload(true);
          setNoOrder(false);
        } else {
          setNoOrder(true);
          setShowDownload(false);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.error("Fetching error", error);
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      style={{ display: "flex", flexDirection: "column", gap: "16px" }}
      onSubmit={handleSubmit(onSubmit)}
    >
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="From"
              {...register("from", { required: "Please select a start date" })}
              disableFuture
              onChange={(date) =>
                setValue("from", dayjs(date).format("YYYY-MM-DD"))
              }
              slotProps={{
                textField: {
                  error: !!errors.from,
                  helperText: errors.from?.message,
                },
              }}
            />
          </LocalizationProvider>
        </FormControl>
      </Box>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="To"
              {...register("to", {
                required: "Please select an end date",
                validate: {
                  laterThanFrom: (value) => {
                    const fromDate = watch("from");
                    if (fromDate && dayjs(value).isBefore(dayjs(fromDate))) {
                      return "End date must be later than start date";
                    }
                    return true; // valid
                  },
                },
              })}
              disableFuture
              onChange={(date) =>
                setValue("to", dayjs(date).format("YYYY-MM-DD"))
              }
              slotProps={{
                textField: {
                  error: !!errors.to,
                  helperText: errors.to?.message,
                },
              }}
            />
          </LocalizationProvider>
        </FormControl>
      </Box>

      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
          py: 1,
          flexDirection: "column",
        }}
      >
        {!receipt ? (
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            {loading ? (
              <CircularProgress size={24} sx={{ color: "white" }} />
            ) : (
              "Get Receipt"
            )}
          </Button>
        ) : (
          <Box
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
            onClick={() => {
              setLoading(false);
              setNoOrder(false);
              setReceipt(null);
              setShowDownload(false);
            }}
          >
            Clear
          </Box>
        )}
        {showDownload && receipt && (
          <FilePreview
            file={receipt}
            fileUrl={`${backendURL}/receipt/${receipt}`}
          />
        )}
      </Box>
      {noOrder && (
        <>
          <Typography color="error" align="center">
            This Coach do not have any payout history during this period, Please
            change the filter and try again.
          </Typography>
        </>
      )}
    </form>
  );
};

// Main tabbed component
const DownloadReceiptsCoach: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);

  const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  return (
    <Paper
      elevation={0}
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        gap: 1,
        backgroundColor: "transparent",
        px: 3,
        py: 2,
      }}
    >
      <Tabs
        value={activeTab}
        onChange={handleTabChange}
        indicatorColor="primary"
        textColor="inherit"
      >
        <Tab label="Monthly" />
        <Tab label="Yearly" />
        <Tab label="Custom" />
      </Tabs>
      <Paper elevation={0} sx={{ py: 2 }}>
        {activeTab === 0 && <MonthlyReceipts />}
        {activeTab === 1 && <YearlyReceipts />}
        {activeTab === 2 && <CustomReceipts />}
      </Paper>
    </Paper>
  );
};

export default DownloadReceiptsCoach;
