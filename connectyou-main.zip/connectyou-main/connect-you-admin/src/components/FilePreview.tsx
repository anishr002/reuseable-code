import { useState } from "react";
import * as XLSX from "xlsx";
import DownloadIcon from "@mui/icons-material/Download";
import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

const FilePreview = ({
  file,
  fileUrl,
  showDownLoadButton = true,
}: {
  file: string;
  fileUrl: string;
  showDownLoadButton?: boolean;
}) => {
  const [excelData, setExcelData] = useState<string[][] | null>(null);

  const fileExtension = file.split(".").pop()?.toLowerCase();

  const handleExcelPreview = async () => {
    try {
      const response = await fetch(fileUrl);
      const blob = await response.blob();
      const reader = new FileReader();

      reader.onload = (e) => {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json(sheet, {
          header: 1,
        }) as string[][];
        setExcelData(rows); // Set Excel data for rendering
      };

      reader.readAsBinaryString(blob);
    } catch (error) {
      console.error("Failed to preview Excel file:", error);
    }
  };

  if (fileExtension === "pdf") {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "10px",
          width: "100%",
        }}
      >
        <iframe
          src={fileUrl}
          title="PDF Preview"
          style={{
            width: "100%",
            height: "500px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        {showDownLoadButton && <DownloadButton fileUrl={fileUrl} />}
      </div>
    );
  }

  if (fileExtension === "xls" || fileExtension === "xlsx") {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "10px",
          width: "100%",
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <span role="img" aria-label="Excel File">
              📊
            </span>
            <span>{file}</span>
          </div>
          <Button
            onClick={handleExcelPreview}
            sx={{ ...downLoadButton, width: 200 }}
          >
            Preview Excel
          </Button>
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            width: "100%",
            overflow: "hidden",
            p: 3,
          }}
        >
          {excelData && (
            <TableContainer
              component={Paper}
              sx={{
                width: "100%",
                maxWidth: "100%", // Adjust container width
                overflowX: "auto", // Enable horizontal scrolling for large tables
              }}
            >
              <Table>
                <TableHead>
                  <TableRow>
                    {excelData[0]?.map((header, index) => (
                      <TableCell
                        key={index}
                        sx={{
                          backgroundColor: "#f4f4f4",
                          fontWeight: "bold",
                          whiteSpace: "nowrap", // Prevent wrapping
                        }}
                      >
                        {header}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {excelData.slice(1).map((row, rowIndex) => (
                    <TableRow key={rowIndex}>
                      {row.map((cell, cellIndex) => (
                        <TableCell
                          key={cellIndex}
                          sx={{
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap", // Prevent text wrapping
                            maxWidth: 200, // Optional: Adjust cell width
                          }}
                          title={cell} // Tooltip for truncated content
                        >
                          {cell || "-"}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>

        {showDownLoadButton && <DownloadButton fileUrl={fileUrl} />}
      </div>
    );
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "10px",
      }}
    >
      <span>Unsupported file type</span>
    </div>
  );
};

const DownloadButton = ({ fileUrl }: { fileUrl: string }) => (
  <a href={fileUrl} target="_blank" download>
    <Button sx={{ ...downLoadButton, width: 200 }} startIcon={<DownloadIcon />}>
      Download
    </Button>
  </a>
);

export default FilePreview;

const downLoadButton = {
  height: "40px",
  color: "white",
  backgroundColor: "#3aa7a3",
  borderColor: "#3aa7a3",
  borderRadius: "20px",
  fontFamily: "Montserrat",
  "&:hover": {
    borderColor: "white",
    backgroundColor: "white",
    color: "#3aa7a3",
  },
};
