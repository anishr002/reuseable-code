import { createSlice } from "@reduxjs/toolkit";

const unReadNotificationCount = 0;

const initialState = { unReadNotificationCount };

const UnreadCoundSlice = createSlice({
  name: "unreadCount",
  initialState,
  reducers: {
    setCount: (state, action) => {
      state.unReadNotificationCount = action.payload;
    },
  },
});
export const { setCount } = UnreadCoundSlice.actions;

export default UnreadCoundSlice.reducer;
