import { createSlice } from "@reduxjs/toolkit";

const pendingReqCount = 0;

const initialState = { pendingReqCount };

const pendingApprovalCountSlice = createSlice({
  name: "pendingApprovalCount",
  initialState,
  reducers: {
    setPendingCount: (state, action) => {
      state.pendingReqCount = action.payload;
    },
  },
});

export const { setPendingCount } = pendingApprovalCountSlice.actions;
export default pendingApprovalCountSlice.reducer;
