import { createSlice } from "@reduxjs/toolkit";

let userdata = {};
const token = localStorage.getItem("authToken");
if (token) {
  const decodedToken = JSON.parse(atob(token.split(".")[1]));
  userdata = decodedToken;
}
const initialState = { userdata };
const adminLoginSlice = createSlice({
  name: "adminLogin",
  initialState,
  reducers: {
    adminLogin: (state, action) => {
      state.userdata = action.payload;
    },
    adminLogout: (state) => {
      state.userdata = {};
    },
  },
});

export const { adminLogin, adminLogout } = adminLoginSlice.actions;

export default adminLoginSlice.reducer;


