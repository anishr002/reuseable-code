/* eslint-disable @typescript-eslint/no-explicit-any */
import ImportExportIcon from "@mui/icons-material/SystemUpdateAlt";
import DeleteIcon from "@mui/icons-material/Delete";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import VisibilityIcon from "@mui/icons-material/Visibility";
import TableRow from "@mui/material/TableRow";
import GroupIcon from "@mui/icons-material/Group";
import {
  Avatar,
  Box,
  Button,
  IconButton,
  Pagination,
  TableCell,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import { Link } from "react-router-dom";
import { Coach_Data_Type } from "../../types/Coach_Type";
import backendURL, { httpAPI_admin } from "../../AxiosAPI";
import NoDataIllustration from "../../components/NoDataIllustration";
import Swal from "sweetalert2";
import ExportModal from "./ExportModal";

export default function ShortListedCoaches() {
  const [rows, setData] = React.useState<Coach_Data_Type[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state

  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);
  const refresh = React.useCallback(() => setPageUpdated((prev) => !prev), []);
  const [searchTerm, setSearchTerm] = React.useState<string>("");
  const [filterSearch, setFilterSearch] = React.useState<string>("");
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        // `/admin/coach/list?pageNo=${pageNo}&searchTerm=${filterSearch}`
        `/admin/coach/shortlisted-for-company?pageNo=${pageNo}&searchTerm=${filterSearch}`
      );
      console.log({ response });
      if (response.status === 200) {
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        return setData(response.data.coachList);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo, pageUpdated, filterSearch]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  const handleUncheck = React.useCallback((coachId: string) => {
    console.log(coachId);
    Swal.fire({
      title: "Remove for the list ?",
      text: `Are you sure You want to remove this coach from the shortlisted coaches list ?`,
      showCancelButton: true,
      showConfirmButton: true,
      confirmButtonText: "Remove ",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const response = await httpAPI_admin.put(
            `/admin/coach/shortlist/un-list/${coachId}`
          );
          if (response?.data?.success) {
            Swal.fire({
              title: response.data.message || "Coach unlisted",
              showConfirmButton: true,
              confirmButtonText: "Okay",
            });
          } else {
            throw new Error(response.data?.message || "Unlisting failed");
          }
          return refresh();
        } catch (error) {
          console.log(error);
        }
      }
    });
  }, []);

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };

  const [open, setOpen] = React.useState<boolean>(false);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <ExportModal onClose={() => setOpen(false)} open={open} />
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Shortlisted Coaches{" "}
            {rows.length > 0 && (
              <Tooltip title="Export List">
                <IconButton
                  onClick={() => {
                    setOpen(true);
                  }}
                  sx={{ display: "inline-flex", color: "#013338" }}
                >
                  <ImportExportIcon color="inherit" fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
              }}
            >
              <TextField
                id="outlined-search"
                placeholder="Search..."
                type="search"
                variant="outlined"
                fullWidth
                size="small"
                value={searchTerm}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  setSearchTerm(event.target.value);
                  if (event.target.value === "") {
                    setFilterSearch("");
                  }
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                    backgroundColor: "#fff",
                  },
                }}
              />
              <Button
                sx={{
                  paddingX: 3,
                  backgroundColor: "#3aa7a3",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "#31c6f8",
                  },
                }}
                onClick={() => setFilterSearch(searchTerm)}
              >
                Search
              </Button>
            </Box>

            <GroupIcon style={{ color: "#013338" }} />
          </Box>
        </Box>
        {rows.length > 0 ? (
          <TableContainer
            sx={{
              maxHeight: {
                lg:
                  pageInfo.totalPages > 1
                    ? "calc(100vh - 240px)"
                    : "calc(100vh - 170px)",
                xl: "auto",
              },
              overflow: "auto",
            }}
          >
            <Table stickyHeader aria-label="sticky table">
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Coach
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Email
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Unlist
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Details
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row, index) => {
                  return (
                    <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                      <TableCell
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 1,
                          color: "#013338",
                        }}
                      >
                        <div>
                          {row.image ? (
                            <>
                              <Avatar
                                alt={row.name}
                                src={`${backendURL}/usersProfile/${row.image}`}
                              />
                            </>
                          ) : (
                            <>
                              <Avatar
                                sx={{
                                  backgroundColor: "#013338",
                                }}
                              >
                                {capitalizeFirstLetter(row.name)}
                              </Avatar>
                            </>
                          )}
                        </div>
                        <p style={{ whiteSpace: "nowrap" }}>
                          {row.name} {row.Lname}{" "}
                          {row?.gender &&
                            `(${
                              row.gender
                                ? row.gender.charAt(0).toUpperCase()
                                : ""
                            })`}
                        </p>
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                        }}
                      >
                        <a href={`mailto:${row.email}`}>{row.email}</a>
                      </TableCell>
                      {/* <TableCell>{row.gender ? row.gender : "-"}</TableCell> */}
                      <TableCell
                        sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                      >
                        <Tooltip title="Remove from list">
                          <IconButton
                            onClick={() => {
                              handleUncheck(row._id);
                            }}
                            sx={{
                              p: 0.6,
                              "&:hover": {
                                color: "red",
                              },
                            }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                      <TableCell
                        sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                      >
                        <Link
                          style={{ textDecoration: "none", color: "white" }}
                          to={`/coach/detail/${row._id}`}
                        >
                          <VisibilityIcon
                            color="primary"
                            style={{ cursor: "pointer" }}
                          />
                        </Link>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <NoDataIllustration />
        )}
        {pageInfo.totalPages > 1 && (
          <Box
            sx={{
              display: "flex",
              justifyConten: "center",
              alignItems: "center",
              paddingY: 2,
              borderTop: "2px solid #ccc",
            }}
          >
            <Pagination
              count={Number(pageInfo.totalPages)}
              page={Number(pageInfo.currentPage)}
              onChange={handlePagination}
            />
          </Box>
        )}
      </Paper>
    </>
  );
}
