import CloseIcon from "@mui/icons-material/Close";
import React, { useEffect, useState } from "react";
import {
  Modal,
  Box,
  Typography,
  CircularProgress,
  Button,
  Alert,
  Stack,
  IconButton,
  Tooltip,
  ThemeProvider,
  Container,
} from "@mui/material";
import { httpAPI_admin } from "../../AxiosAPI";
import { ButtonTheme } from "../../lib/MUI/ButtonsTheme";

interface ExportModalProps {
  open: boolean;
  onClose: () => void;
}

const style = {
  position: "absolute" as const,
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  borderRadius: 2,
  boxShadow: 24,
  p: 4,
};

const ExportModal: React.FC<ExportModalProps> = ({ open, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [data, setData] = useState<any>(null);
  const [skip, setSkip] = useState(0);
  const limit = 1000;

  const fetchData = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await httpAPI_admin.get(
        `/admin/coach/shortlist/export?skip=${skip}&limit=${limit}`
      );
      setData(res.data);
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to fetch data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) fetchData();
  }, [open, skip]);

  const handleDownload = (fileUrl: string, fileName: string) => {
    const link = document.createElement("a");
    link.href = fileUrl;
    link.download = fileName;
    link.click();
  };

  return (
    <ThemeProvider theme={ButtonTheme}>
      <Modal open={open}>
        <Box sx={style}>
          <Tooltip title="close">
            <IconButton
              sx={{
                position: "absolute",
                top: 0,
                right: 2,
                color: "gray",
                "&:hover": {
                  color: "red",
                },
              }}
              onClick={onClose}
            >
              <CloseIcon color="inherit" />
            </IconButton>
          </Tooltip>
          <Typography
            variant="h6"
            mb={2}
            sx={{ color: "#013338", textAlign: "center", fontWeight: "600" }}
          >
            Export Shortlisted Coaches
          </Typography>

          {loading && (
            <Box textAlign="center" py={2}>
              <CircularProgress />
              <Typography variant="body2" mt={2}>
                Generating files...
              </Typography>
            </Box>
          )}

          {!loading && error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          {!loading && data && (
            <Stack spacing={2} direction={"column"}>
              <Container>
                <Typography
                  variant="body2"
                  sx={{
                    color: "#013338",
                    fontWeight: "500",
                    textAlign: "center",
                  }}
                >
                  {data.count} coaches exported in the Files.
                </Typography>
              </Container>
              <Stack direction="column" spacing={2}>
                <Button
                  variant="contained"
                  sx={{
                    background: "#013338",
                  }}
                  onClick={() =>
                    handleDownload(data.files.xlsx, "shortlisted_coaches.xlsx")
                  }
                >
                  Download XLSX
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    border: "1px solid #013338",
                    color: "#013338",
                  }}
                  onClick={() =>
                    handleDownload(data.files.csv, "shortlisted_coaches.csv")
                  }
                >
                  Download CSV
                </Button>
              </Stack>

              <Stack
                direction="row"
                spacing={2}
                justifyContent="space-between"
                mt={2}
              >
                {skip !== 0 && (
                  <Button
                    disabled={skip === 0}
                    onClick={() => setSkip((prev) => Math.max(0, prev - limit))}
                  >
                    Previous
                  </Button>
                )}
                {data?.hasMore && (
                  <Button
                    disabled={!data?.hasMore}
                    onClick={() => setSkip((prev) => prev + limit)}
                  >
                    Next
                  </Button>
                )}
              </Stack>
            </Stack>
          )}
        </Box>
      </Modal>
    </ThemeProvider>
  );
};

export default ExportModal;
