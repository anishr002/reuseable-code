import { PieChart } from "@mui/x-charts/PieChart";
import { Box, Typography, useTheme, useMediaQuery } from "@mui/material";
import formatNumberToMoney from "../../utils/formatNumberToMoney";

type salesStats = {
    totalRevenue: number;
    totalPayout: number;
    totalDuePayouts: number;
    totalProfit: number;
};

type Props = {
    salesStats: salesStats;
};

const colors = ["#013338", "#ebbd33", "#ff6b6b", "#3aa7a3", "#ff8600"];

const valueFormatter = (params: { value: number }) => `${params.value}`;

export default function SalesPieChartPieChart({ salesStats }: Props) {
    const theme = useTheme();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));

    const {
        totalRevenue,
        totalPayout,
        totalDuePayouts,
        totalProfit,
    } = salesStats;

    const chartData = [
        {
            id: 0,
            value: totalRevenue,
            label: "Total Revenue",
            color: colors[0],
        },
        {
            id: 1,
            value: totalPayout,
            label: "Total Payout",
            color: colors[1],
        },
        {
            id: 2,
            value: totalDuePayouts,
            label: "Due Payout",
            color: colors[2],
        },
        {
            id: 3,
            value: totalProfit,
            label: "Total Profit",
            color: colors[3],
        },
    ];

    return (
        <Box
            sx={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
            }}
        >
            <Typography
                variant="body1"
                sx={{ width: "100%", color: "#013338" }}
                fontWeight="bold"
                mb={0}
            >
                Overall Sales Stats
            </Typography>
            <PieChart
                series={[
                    {
                        data: chartData,
                        highlightScope: { fade: "global", highlight: "item" },
                        faded: { innerRadius: 20, additionalRadius: -20, color: "gray" },
                        valueFormatter,
                        innerRadius: 30,
                        outerRadius: isSmallScreen ? 80 : 100,
                        paddingAngle: 2,
                    },
                ]}
                width={undefined}
                height={isSmallScreen ? 260 : 240}
            />

            <Box mt={1} width="100%">

                <StatLine label="Total Revenue" value={formatNumberToMoney(totalRevenue)} color={colors[0]} />
                <StatLine
                    label="Total Payout"
                    value={formatNumberToMoney(totalPayout)}
                    color={colors[1]}
                />
                <StatLine
                    label="Due Payout"
                    value={formatNumberToMoney(totalDuePayouts)}
                    color={colors[2]}
                />
                <StatLine
                    label="Total Profit"
                    value={formatNumberToMoney(totalProfit)}
                    color={colors[3]}
                />
            </Box>
        </Box>
    );
}

// Reusable stat line component
const StatLine = ({
    label,
    value,
    color,
}: {
    label: string;
    value: string;
    color?: string;
}) => (
    <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={1}
        px={1}
        sx={{ color }}
    >
        <Typography variant="body2" fontWeight={500}>
            {label}
        </Typography>
        <Typography variant="body2" fontWeight={600}>
            {value}
        </Typography>
    </Box>
);
