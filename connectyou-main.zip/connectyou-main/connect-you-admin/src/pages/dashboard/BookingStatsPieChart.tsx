import { PieChart } from "@mui/x-charts/PieChart";
import { Box, Typography, useTheme, useMediaQuery } from "@mui/material";

type BookingStats = {
    totalBookings: number;
    pendingBookings: number;
    canceledBookings: number;
    completedBookings: number;
};

type Props = {
    bookingStats: BookingStats;
};

const colors = ["#013338", "#3aa7a3", "#ebbd33", "#ff6b6b"];

const valueFormatter = (params: { value: number }) => `${params.value}`;

export default function BookingStatsPieChart({ bookingStats }: Props) {
    const theme = useTheme();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));

    const {
        pendingBookings,
        completedBookings,
        canceledBookings,
        totalBookings,
    } = bookingStats;

    const chartData = [
        {
            id: 0,
            value: pendingBookings,
            label: "Pending",
            color: colors[0],
        },
        {
            id: 1,
            value: completedBookings,
            label: "Completed",
            color: colors[1],
        },
        {
            id: 2,
            value: canceledBookings,
            label: "Canceled",
            color: colors[2],
        },
    ];

    return (
        <Box
            sx={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
            }}
        >
            <Typography
                variant="body1"
                sx={{ width: "100%", color: "#013338" }}
                fontWeight="bold"
                mb={0}
            >
                Booking Stats
            </Typography>
            <PieChart
                series={[
                    {
                        data: chartData,
                        highlightScope: { fade: "global", highlight: "item" },
                        faded: { innerRadius: 20, additionalRadius: -20, color: "gray" },
                        valueFormatter,
                        innerRadius: 30,
                        outerRadius: isSmallScreen ? 80 : 100,
                        paddingAngle: 2,
                    },
                ]}
                width={undefined}
                height={isSmallScreen ? 260 : 240}
            />

            <Box mt={1} width="100%">
                <StatLine label="Total Bookings" value={totalBookings} />
                <StatLine
                    label="Pending Bookings"
                    value={pendingBookings}
                    color={colors[0]}
                />
                <StatLine
                    label="Completed Bookings"
                    value={completedBookings}
                    color={colors[1]}
                />
                <StatLine
                    label="Cancelled Bookings"
                    value={canceledBookings}
                    color={colors[2]}
                />
            </Box>
        </Box>
    );
}

// Reusable stat line component
const StatLine = ({
    label,
    value,
    color,
}: {
    label: string;
    value: number;
    color?: string;
}) => (
    <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={1}
        px={1}
        sx={{ color }}
    >
        <Typography variant="body2" fontWeight={500}>
            {label}
        </Typography>
        <Typography variant="body2" fontWeight={600}>
            {value}
        </Typography>
    </Box>
);
