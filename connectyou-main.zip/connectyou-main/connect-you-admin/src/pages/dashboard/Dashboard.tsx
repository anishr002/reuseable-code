/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Avatar,
  Box,
  Chip,
  CircularProgress,
  Grid,
  Paper,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import PaidIcon from "@mui/icons-material/Paid";
import PeopleIcon from "@mui/icons-material/People";
import { RemoveRedEye } from "@mui/icons-material";
import moment from "moment-timezone";
import { Link, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import backendURL, { httpAPI_admin } from "../../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import { LineChart } from "@mui/x-charts/LineChart";
import BookingStatsPieChart from "./BookingStatsPieChart";
import SalesPieChartPieChart from "./SalesPieChart";
import formatNumberToMoney from "../../utils/formatNumberToMoney";

const label = { inputProps: { "aria-label": "Switch demo" } };
const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});
interface CountDataType {
  totalBalance: number;
  totalRevenue: number;
  payoutAmount: number;
  totalDuePayouts: number;
  totalCommission: number;
  orderCount: number;
  sessionCount: number;
  orderCountCompleted: number;
  userCount: number;
  coachCount: number;
  totalAddedSessions: number;
}

interface BookingDataType {
  _id: string;
  bookingId: string;
  createdAt: string;
  orderStatus: number;
  updatedAt: string;
  bookingDate: string;
  bookingTime: string;
  coachId: string;
  sessionId: string;
  userId: string;
  sessionCompletedDate: string;
  userName: string;
  userPhoto: string;
  coachName: string;
  coachLName: string;
  coachUserName: string;
  title: string;
  type: number;
  price: number;
  description: string;
  coachPhoto: string;
}
interface CoachData {
  coachId: string;
  name: string;
  Lname: string;
  email: string;
  image: string;
  userName: string;
}

interface PayoutType {
  _id: string;
  coachId: string;
  amount: number;
  status: number;
  createdAt: string;
  approveDate: string;
  coachData: CoachData;
  totalAmount: number;
  totalPayout: number;
}
interface BookingStats {
  totalBookings: number;
  completedBookings: number;
  pendingBookings: number;
  canceledBookings: number;
}

const xLabels = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];
const Dashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [countData, setCountData] = React.useState<CountDataType>({
    totalBalance: 0,
    totalRevenue: 0,
    totalDuePayouts: 0,
    totalCommission: 0,
    payoutAmount: 0,
    orderCount: 0,
    sessionCount: 0,
    orderCountCompleted: 0,
    userCount: 0,
    coachCount: 0,
    totalAddedSessions: 0
  });

  const [completedOrderList, setCompletedOrderList] = React.useState<
    BookingDataType[]
  >([]);
  const [payoutList, setPayoutList] = React.useState<PayoutType[]>([]);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);
  const [coachData, setCoachArray] = React.useState([]);
  const [coacheeData, setUserArray] = React.useState([]);
  const [bookingStats, setBookingStats] = useState<BookingStats>({
    totalBookings: 0,
    pendingBookings: 0,
    canceledBookings: 0,
    completedBookings: 0,
  });
  const [avalBal, setAvalBal] = useState<string | null>(null);
  const [totaldebit, setTotalDebit] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<StripeTransaction[] | null>(
    null
  );
  const fetchStripeBalance = async (filterType = 0, page = 1, limit = 10) => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/transactions/fetch-stripe-balance`,
        {
          params: {
            filter: filterType, // 0 = all, 1 = debits, 2 = credits
            page, // Current page number
            limit, // Number of items per page
          },
        }
      );

      if (response.status === 200) {
        const { balance, debit, transactions } = response.data;
        setAvalBal(balance);
        setTotalDebit(debit);
        setTransactions(transactions);
      }
    } catch (error) {
      console.error("Error fetching balance and transactions:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchBookingStats = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/dashboard/booking-stats`
      );
      console.log({ response });
      if (response.status === 200) {
        setBookingStats(response.data.data);
        return setLoading(false);
      } else {
        throw new Error("Unable to fetch the booking stats");
      }
    } catch (error: any) {
      console.log({ error });
      return toast.error(
        error?.response?.data?.message || "Something went wrong"
      );
    } finally {
      setLoading(false);
    }
  };

  const fetchCountData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(`/admin/dashboard/orderList`);
      if (response.data) {
        setCountData(response.data.countData);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const fetchCompletedOrderList = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/dashboard/completed-orderList`
      );
      if (response.data) {
        setCompletedOrderList(response.data.data);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };
  const fetchPayoutData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/dashboard/payout-history-recent`
      );
      if (
        response.data.payoutHistory &&
        response.data.payoutHistory.length > 0
      ) {
        setLoading(false);
        console.log("sdfsdfsd", response.data.payoutHistory);
        return setPayoutList(response.data.payoutHistory);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };
  //registration-state
  const fetchRegistrationStateData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/dashboard/registration-state`
      );
      if (response.data.userArray) {
        setUserArray(response.data.userArray);
        setCoachArray(response.data.coachArray);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const Init = async () => {
      try {
        setLoading(true);
        await Promise.allSettled([
          fetchBookingStats(),
          fetchCountData(),
          fetchCompletedOrderList(),
          fetchPayoutData(),
          fetchRegistrationStateData(),
          fetchStripeBalance(),
        ]);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    Init();
  }, [pageUpdated]);

  const handleApproveClick =
    (id: string, coachId1: string) =>
      async (_: React.ChangeEvent<HTMLInputElement>) => {
        const coachId = coachId1.trim();
        setLoading(true);
        swalWithBootstrapButtons
          .fire({
            title: "Are you sure?",
            text: `You want to approve it`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: `Yes, approve It!`,
            cancelButtonText: "Not, Now",
            reverseButtons: true,
          })
          .then(async (result) => {
            if (result.isConfirmed) {
              setLoading(true);
              try {
                const response = await httpAPI_admin.post(
                  `/admin/coach/payout-approve/${id.trim()}`,
                  { coachId }
                );
                if (response.data.success === true) {
                  setPageUpdated(!pageUpdated);
                  setLoading(false);
                  swalWithBootstrapButtons.fire({
                    title: `Approve!`,
                    text: `Payout approved successfully`,
                    icon: "success",
                    showConfirmButton: false,
                    timer: 1500,
                  });
                  return setPageUpdated(!pageUpdated);
                }
              } catch (error: any) {
                console.log(error);
                if (
                  error.response.status === 500 ||
                  error.response.status === 400 ||
                  error.response.status === 401 ||
                  error.response.status === 403 ||
                  error.response.status === 404 ||
                  error.response.status === 409
                ) {
                  setTimeout(() => {
                    toast.error(
                      error.response.data.message
                        ? error.response.data.message
                        : "Something went wrong"
                    );
                  }, 1000);

                  return setLoading(false);
                } else {
                  toast.error("Something went wrong");
                  return setLoading(false);
                }
              }
            } else {
              setLoading(false);
            }
          });
      };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <Paper
      sx={{
        width: "100%",
        height: "calc(100vh - 70px)",
        px: 1,
        pb: 12,
        background: "transparent",
        overflow: "auto",
      }}
      className="style-scroll"
    >
      <Grid
        container
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: 2,
        }}
      >
        <Grid container columnSpacing={2} rowSpacing={2} alignItems="stretch">
          {/* Pie Chart Card */}
          <Grid item xs={12} md={6}>
            <Box
              sx={{
                background: "white",
                borderRadius: 2,
                boxShadow: 1,
                height: "100%",
                p: 2, // ensure full height alignment
              }}
            >
              <BookingStatsPieChart bookingStats={bookingStats} />
            </Box>
          </Grid>

          {/* Coaches + Coachees */}
          <Grid item xs={12} md={6}>
            <Grid container spacing={2} direction="column">
              {/* Total Coaches */}
              <Grid item xs={12}>
                <Paper
                  onClick={() => navigate("/coach")}
                  elevation={3}
                  sx={{
                    borderRadius: 2,
                    cursor: "pointer",
                    p: 2,
                    backgroundColor: "white",
                  }}
                >
                  <Box display="flex" flexDirection="column" gap={2}>
                    <Box display="flex" justifyContent="space-between">
                      <Typography
                        variant="h6"
                        fontWeight="600"
                        sx={{ color: "#013338" }}
                      >
                        Total Coaches
                      </Typography>
                    </Box>
                    <Box
                      display="flex"
                      alignItems="center"
                      justifyContent="space-between"
                    >
                      <PeopleIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                      <Typography variant="h6" fontWeight="600">
                        {countData.coachCount}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>

              {/* Total Coachee */}
              <Grid item xs={12}>
                <Paper
                  onClick={() => navigate("/coachee")}
                  elevation={3}
                  sx={{
                    borderRadius: 2,
                    cursor: "pointer",
                    p: 2,
                    backgroundColor: "white",
                  }}
                >
                  <Box display="flex" flexDirection="column" gap={2}>
                    <Box display="flex" justifyContent="space-between">
                      <Typography
                        variant="h6"
                        fontWeight="600"
                        sx={{ color: "#013338" }}
                      >
                        Total Coachee
                      </Typography>
                    </Box>
                    <Box
                      display="flex"
                      alignItems="center"
                      justifyContent="space-between"
                    >
                      <PeopleIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                      <Typography variant="h6" fontWeight="600">
                        {countData.userCount}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
              {/* total sessions  */}
              <Grid item xs={12}>
                <Paper
                  elevation={3}
                  sx={{
                    borderRadius: 2,
                    cursor: "pointer",
                    p: 2,
                    backgroundColor: "white",
                  }}
                >
                  <Box display="flex" flexDirection="column" gap={2}>
                    <Box display="flex" justifyContent="space-between">
                      <Typography
                        variant="h6"
                        fontWeight="600"
                        sx={{ color: "#013338" }}
                      >
                        Total Active Paid Sessions
                      </Typography>
                    </Box>
                    <Box
                      display="flex"
                      alignItems="center"
                      justifyContent="space-between"
                    >
                      <PeopleIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                      <Typography variant="h6" fontWeight="600">
                        {countData.totalAddedSessions}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container columnSpacing={2} rowSpacing={2} alignItems="stretch">
          <Grid item xs={6}>
            <Paper
              elevation={3}
              sx={{
                width: "100%",
                height: "360px",
                position: "relative",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "start",
                overflow: "auto",
              }}
              className="hide-scrollbar"
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "bold",
                  padding: "8px 20px",
                  width: "100%",
                  display: "flex",
                  justifyContent: "space-between",
                  gap: "5px",
                  alignItems: "center",
                  color: "#013338",
                  py: "15px",
                }}
              >
                <span>Monthly Registrations</span>
                <PeopleIcon sx={{ color: "#3aa7a3" }} />
              </Typography>

              <LineChart
                series={[
                  { data: coacheeData, label: "Coachee" },
                  { data: coachData, label: "Coach" },
                ]}
                xAxis={[{ scaleType: "point", data: xLabels }]}
              />
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Box
              sx={{
                background: "white",
                borderRadius: 2,
                boxShadow: 1,
                height: "100%",
                p: 2, // ensure full height alignment
              }}
            >
              <SalesPieChartPieChart
                salesStats={{
                  totalDuePayouts: countData.totalDuePayouts,
                  totalPayout: countData.payoutAmount,
                  totalRevenue: countData.totalRevenue,
                  totalProfit: countData.totalCommission,
                }}
              />
            </Box>
          </Grid>
        </Grid>
        <Grid columnSpacing={2} rowSpacing={2} alignItems="stretch">
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Grid container>
                {loading ? (
                  <Box
                    sx={{
                      width: "100%",
                      height: 300,
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <CircularProgress size={35} sx={{ color: "#EBBE34" }} />
                  </Box>
                ) : transactions && transactions?.length > 0 ? (
                  <React.Fragment>
                    <Grid item xs={12} md={12} lg={12}>
                      <Paper
                        elevation={3}
                        sx={{
                          width: "100%",
                        }}
                      >
                        <Typography
                          variant="h6"
                          sx={{
                            fontWeight: "bold",
                            padding: "8px 20px",
                            width: "100%",
                            display: "flex",
                            justifyContent: "space-between",
                            gap: "5px",
                            alignItems: "center",
                            color: "#013338",
                            py: "15px",
                          }}
                        >
                          <span>Recent Stripe Transactions</span>
                          <Typography
                            variant="h6"
                            fontWeight="600"
                            sx={{
                              color: "#013338",
                              display: "flex",
                              alignItems: "center",
                            }}
                          >
                            <Link
                              to={"stripe-txns"}
                              style={{
                                color: "blue",
                                textDecoration: "none",
                                fontSize: "1rem",
                                fontWeight: 5000,
                              }}
                            >
                              See More
                            </Link>
                          </Typography>
                        </Typography>
                        <TableContainer
                          sx={{
                            maxHeight: "300px",
                            overflow: "auto",
                          }}
                          className="style-scroll"
                        >
                          <Table stickyHeader sx={{ maxHeight: "100%" }}>
                            <TableHead>
                              <TableRow>
                                <TableCell
                                  sx={{ color: "white", background: "#013338" }}
                                >
                                  No.
                                </TableCell>
                                <TableCell
                                  sx={{ color: "white", background: "#013338" }}
                                >
                                  Amount
                                </TableCell>
                                <TableCell
                                  sx={{ color: "white", background: "#013338" }}
                                >
                                  Type
                                </TableCell>
                                <TableCell
                                  sx={{ color: "white", background: "#013338" }}
                                >
                                  Transfer
                                </TableCell>
                                <TableCell
                                  sx={{ color: "white", background: "#013338" }}
                                >
                                  Dated
                                </TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {transactions.map((d, i) => (
                                <React.Fragment key={i}>
                                  <TableRow>
                                    <TableCell>{i + 1}</TableCell>
                                    <TableCell>
                                      <span
                                        style={{
                                          color:
                                            Number(d.amount) > 0
                                              ? "green"
                                              : "red",
                                        }}
                                      >
                                        $ {(d.amount / 100).toFixed(2)}
                                      </span>
                                    </TableCell>
                                    <TableCell>
                                      <span
                                        style={{
                                          color:
                                            Number(d.amount) > 0
                                              ? "green"
                                              : "red",
                                        }}
                                      >
                                        {d.amount > 0 ? "CREDIT" : "DEBIT"}
                                      </span>
                                    </TableCell>
                                    <TableCell
                                      sx={{ textTransform: "uppercase" }}
                                    >
                                      {d.type}
                                    </TableCell>
                                    <TableCell>
                                      {!isNaN(Number(d.created))
                                        ? new Date(
                                          Number(d.created) * 1000
                                        ).toLocaleString()
                                        : "-"}
                                    </TableCell>
                                  </TableRow>
                                </React.Fragment>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Paper>
                    </Grid>
                  </React.Fragment>
                ) : (
                  ""
                )}
              </Grid>
            </Grid>
            <Grid item xs={6}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Paper elevation={0} sx={{ width: "100%" }}>
                    <Box
                      display="flex"
                      flexDirection="column"
                      gap={2}
                      borderRadius={2}
                      boxShadow={3}
                      p={2}
                      flex={1}
                      sx={{ cursor: "pointer", backgroundColor: "white" }}
                    >
                      <Box display="flex" justifyContent="space-between">
                        <Typography
                          variant="h6"
                          fontWeight="600"
                          sx={{ color: "#013338" }}
                        >
                          Stripe Account Balance
                        </Typography>
                      </Box>
                      <Box
                        display="flex"
                        gap={1}
                        alignItems="center"
                        justifyContent="space-between"
                      >
                        <Box display="flex">
                          <PaidIcon
                            sx={{ fontSize: "2rem", color: "#3aa7a3" }}
                          />
                        </Box>
                        <Box display="flex">
                          <Typography variant="h6" fontWeight="600">
                            {loading ? (
                              <>
                                <CircularProgress
                                  size={12}
                                  sx={{ color: "#EBBE34" }}
                                />
                              </>
                            ) : !isNaN(Number(avalBal)) ? (
                              formatNumberToMoney(Number(avalBal), "00.00")
                            ) : (
                              "00:00"
                            )}
                            {/* { countData.totalRevenue} */}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>
                <Grid item xs={12}>
                  <Paper elevation={0} sx={{ width: "100%" }}>
                    <Box
                      display="flex"
                      flexDirection="column"
                      gap={2}
                      borderRadius={2}
                      boxShadow={3}
                      p={2}
                      flex={1}
                      sx={{ cursor: "pointer", backgroundColor: "white" }}
                    >
                      <Box display="flex" justifyContent="space-between">
                        <Typography
                          variant="h6"
                          fontWeight="600"
                          sx={{ color: "#013338" }}
                        >
                          Total Withdrawal
                        </Typography>
                      </Box>
                      <Box
                        display="flex"
                        gap={1}
                        alignItems="center"
                        justifyContent="space-between"
                      >
                        <Box display="flex">
                          <PaidIcon
                            sx={{ fontSize: "2rem", color: "#3aa7a3" }}
                          />
                        </Box>
                        <Box display="flex">
                          <Typography variant="h6" fontWeight="600">
                            {loading ? (
                              <>
                                <CircularProgress
                                  size={12}
                                  sx={{ color: "#EBBE34" }}
                                />
                              </>
                            ) : !isNaN(Number(totaldebit)) ? (
                              formatNumberToMoney(Number(totaldebit), "00.00")
                            ) : (
                              "00:00"
                            )}
                            {/* { countData.totalRevenue} */}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>
                <Grid
                  sx={{
                    display: "none",
                  }}
                  item
                  xs={12}
                >
                  <Paper elevation={0} sx={{ width: "100%" }}>
                    <Box
                      display="flex"
                      flexDirection="column"
                      gap={2}
                      borderRadius={2}
                      boxShadow={3}
                      p={2}
                      flex={1}
                      sx={{ cursor: "pointer", backgroundColor: "white" }}
                    >
                      <Box display="flex" justifyContent="space-between">
                        <Typography
                          variant="h6"
                          fontWeight="600"
                          sx={{ color: "#013338" }}
                        >
                          XXXX
                        </Typography>
                      </Box>
                      <Box
                        display="flex"
                        gap={1}
                        alignItems="center"
                        justifyContent="space-between"
                      >
                        <Box display="flex">
                          <PaidIcon
                            sx={{ fontSize: "2rem", color: "#3aa7a3" }}
                          />
                        </Box>
                        <Box display="flex">
                          <Typography variant="h6" fontWeight="600">
                            {loading ? (
                              <>
                                <CircularProgress
                                  size={12}
                                  sx={{ color: "#EBBE34" }}
                                />
                              </>
                            ) : !isNaN(Number(totaldebit)) ? (
                              formatNumberToMoney(
                                Number(avalBal) - Number(totaldebit),
                                "00.00"
                              )
                            ) : (
                              "00:00"
                            )}
                            {/* { countData.totalRevenue} */}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        {completedOrderList.length > 0 && <Grid columnSpacing={2} rowSpacing={2} alignItems="stretch">
          <Grid item xs={12}>
            <Paper
              elevation={3}
              sx={{
                width: "100%",
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "bold",
                  padding: "8px 20px",
                  width: "100%",
                  display: "flex",
                  justifyContent: "space-between",
                  gap: "5px",
                  alignItems: "center",
                  color: "#013338",
                  py: "15px",
                }}
              >
                <span>Completed Session</span>
                <AccountBalanceIcon style={{ color: "#3aa7a3" }} />
              </Typography>
              <TableContainer
                sx={{
                  maxHeight: "300px",
                  overflow: "auto",
                }}
                className="style-scroll"
              >
                {completedOrderList.length > 0 ? (
                  <Table stickyHeader sx={{ maxHeight: "100%" }}>
                    <TableHead>
                      <TableRow>
                        <TableCell
                          sx={{ color: "white", background: "#013338" }}
                        >
                          Coach
                        </TableCell>
                        <TableCell
                          sx={{ color: "white", background: "#013338" }}
                        >
                          Coachee
                        </TableCell>
                        <TableCell
                          sx={{ color: "white", background: "#013338" }}
                        >
                          Time
                        </TableCell>
                        <TableCell
                          sx={{ color: "white", background: "#013338" }}
                        >
                          View
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {completedOrderList.map((s, i) => (
                        <TableRow key={i} hover>
                          <TableCell>
                            <Link
                              to={`/coach/detail/${s.coachId}`}
                              style={{
                                display: "flex",
                                gap: "10px",
                                alignItems: "center",
                                color: "#013338",
                                textDecoration: "none",
                              }}
                            >
                              <Avatar
                                sx={{ width: 30, height: 30 }}
                                alt={s.coachName}
                                src={`${backendURL}/usersProfile/${s.coachPhoto}`}
                              />
                              <Typography
                                variant="body2"
                                sx={{ fontWeight: "500" }}
                              >
                                {s.coachName}
                              </Typography>
                            </Link>
                          </TableCell>
                          <TableCell>
                            <Link
                              to={`/coachee/detail/${s.userId}`}
                              style={{
                                display: "flex",
                                gap: "10px",
                                alignItems: "center",
                                color: "#013338",
                                textDecoration: "none",
                              }}
                            >
                              <Avatar
                                sx={{ width: 30, height: 30 }}
                                alt={s.userName}
                                src={`${backendURL}/usersProfile/${s.userPhoto}`}
                              />
                              <Typography
                                variant="body2"
                                sx={{ fontWeight: "500" }}
                              >
                                {s.userName}
                              </Typography>
                            </Link>
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                          >
                            <Typography
                              variant="body2"
                              sx={{ fontWeight: "500" }}
                            >
                              {moment(s.sessionCompletedDate).isSame(
                                moment(),
                                "day"
                              )
                                ? moment(s.sessionCompletedDate)
                                  .local()
                                  .fromNow()
                                : moment(s.sessionCompletedDate)
                                  .local()
                                  .format("YYYY-MM-DD HH:mm:ss")}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Link
                              to={`/bookings/detail/${s.bookingId}`}
                              style={{
                                display: "flex",
                                gap: "10px",
                                alignItems: "center",
                                color: "#013338",
                                textDecoration: "none",
                              }}
                            >
                              <RemoveRedEye
                                sx={{
                                  color: "#31c6f8",
                                  fontSize: "1.2rem",
                                }}
                              />
                            </Link>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <Box
                    sx={{
                      height: 200,
                      width: "100%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexGrow: 1,
                    }}
                  >
                    <Typography
                      variant="body1"
                      sx={{
                        color: "red",
                      }}
                    >
                      No Bookings yet
                    </Typography>
                  </Box>
                )}
              </TableContainer>
            </Paper>
          </Grid>
        </Grid>}
        {payoutList.length > 0 && <Grid columnSpacing={2} rowSpacing={2} alignItems="stretch">
          <Grid container sx={{ marginTop: "5px" }}>
            <Paper
              sx={{
                width: "100%",
                overflow: "auto",
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "bold",
                  padding: "8px 20px",
                  width: "100%",
                  display: "flex",
                  justifyContent: "space-between",
                  gap: "5px",
                  alignItems: "center",
                  color: "#013338",
                  py: "15px",
                }}
              >
                <span>Payout Requests</span>
                <AccountBalanceIcon style={{ color: "#3aa7a3" }} />
              </Typography>

              <TableContainer
                sx={{
                  maxHeight: "500px",
                  overflow: "auto",
                }}
                className="style-scroll"
              >
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow sx={{ textTransform: "uppercase" }}>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                          width: "20%",
                        }}
                      >
                        Profile
                      </TableCell>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                          width: "15%",
                        }}
                      >
                        username
                      </TableCell>
                      <TableCell
                        sx={{ backgroundColor: "#013338", color: "white" }}
                      >
                        Balance
                      </TableCell>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                          width: "10%",
                        }}
                      >
                        Requested Payout
                      </TableCell>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                        }}
                      >
                        Request Date
                      </TableCell>

                      <TableCell
                        sx={{ backgroundColor: "#013338", color: "white" }}
                      >
                        Status
                      </TableCell>
                      <TableCell
                        sx={{ backgroundColor: "#013338", color: "white" }}
                      >
                        Details
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {payoutList.map((a, i) => (
                      <TableRow hover role="checkbox" tabIndex={-1} key={i}>
                        <TableCell
                          sx={{
                            width: "20%",
                          }}
                        >
                          <Link
                            to={`/coach/detail/${a.coachData.coachId}`}
                            style={{
                              display: "flex",
                              gap: "10px",
                              alignItems: "center",
                              color: "#013338",
                              textDecoration: "none",
                            }}
                          >
                            <Avatar
                              sx={{ width: 30, height: 30 }}
                              alt={a.coachData.name}
                              src={`${backendURL}/usersProfile/${a.coachData.image}`}
                            />
                            <Typography
                              variant="body2"
                              sx={{ fontWeight: "500" }}
                            >
                              {a.coachData.name}
                            </Typography>
                          </Link>
                        </TableCell>
                        <TableCell>{a.coachData.userName}</TableCell>
                        <TableCell>
                          {formatNumberToMoney(a.totalAmount / 100)}
                        </TableCell>
                        <TableCell>{formatNumberToMoney(a.amount / 100)}</TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {moment(a.createdAt).isSame(moment(), "day")
                            ? moment(a.createdAt).local().fromNow()
                            : moment(a.createdAt)
                              .local()
                              .format("YYYY-MM-DD HH:mm:ss")}
                        </TableCell>
                        <TableCell>
                          {a.status != 1 ? (
                            <Switch
                              {...label}
                              checked={a.status === 1 ? true : false}
                              disabled={a.status === 1 ? true : false}
                              onChange={
                                a.status === 0
                                  ? handleApproveClick(a._id, a.coachId)
                                  : undefined
                              }
                            />
                          ) : (
                            <Chip
                              label="Approved"
                              color="success"
                              sx={{ width: "120px", fontWeight: "bold" }}
                              icon={
                                <CheckCircleIcon sx={{ color: "white" }} />
                              }
                            />
                          )}
                        </TableCell>
                        <TableCell>
                          <Link to={`/payout/detail/${a.coachData.coachId}`}>
                            <RemoveRedEye
                              sx={{ color: "#31c6f8", fontSize: "1.2rem" }}
                            />
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Grid>
        </Grid>}
      </Grid>
    </Paper>
  );
};

export default Dashboard;



export interface StripeTransaction {
  amount: number;
  created: string;
  type: string;
  id: string;
}

