import React, { useEffect, useState } from "react";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TablePagination,
  IconButton,
  Collapse,
  Paper,
  Box,
  Typography,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import { APIThrottle_Type } from "../utils/serverStats";
import dayjs from "dayjs";

const ServerPar = () => {
  const [data, setData] = useState<APIThrottle_Type[]>([]);
  const [refresh, setRefresh] = useState<boolean>(false);
  const [page, setPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(5);
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [totalLogs, setTotalLogs] = useState<number>(0);

  // Fetch data from the backend
  useEffect(() => {
    const fetchData = async () => {
      const endp = `${backendURL}/admin/api-logs?page=${
        page + 1
      }&limit=${rowsPerPage}`;
      try {
        const response = await httpAPI_admin.get(endp);
        if (response.data.success) {
          setData(response.data.data);
          setTotalLogs(response.data.totalLogs);
        }
      } catch (error) {
        console.error("Failed to fetch data", error);
      }
    };

    fetchData();
  }, [refresh, page, rowsPerPage]);

  const handleRefresh = () => {
    setRefresh(!refresh); // Toggle refresh state to trigger data reload
  };

  const handleChangePage = (_: unknown, newPage: number) => {
    setPage(newPage); // Update the page when changed
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10)); // Update the rows per page
    setPage(0); // Reset page to 0 when rows per page changes
  };

  const handleExpandClick = (rowIndex: number) => {
    setExpandedRow(expandedRow === rowIndex ? null : rowIndex); // Toggle expanded row
  };

  return (
    <Paper
      sx={{
        width: "100%",
        height: "calc(100vh - 88px)",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          width: "100%",
          height: 60,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          p: 3,
          flexShrink: 0,
        }}
      >
        <Typography variant="h6">Server Request Stats</Typography>
        <IconButton onClick={handleRefresh} color="primary">
          <RefreshIcon />
        </IconButton>
      </Box>

      {/* Scrollable Table Container */}
      <Box
        sx={{
          flex: 1,
          overflow: "auto",
        }}
      >
        <Table stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell sx={{ color: "#013338" }}>Report Time</TableCell>
              <TableCell sx={{ color: "#013338" }}>Endpoints</TableCell>
              <TableCell sx={{ color: "#013338" }}>
                Total Requests in 24h
              </TableCell>
              <TableCell sx={{ color: "#013338" }}>Avg Requests/Min</TableCell>
              <TableCell sx={{ color: "#013338" }}>Details</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data?.length > 0 ? (
              data?.map((row, index) => (
                <React.Fragment key={index}>
                  <TableRow>
                    <TableCell>
                      {dayjs(row.createdAt).format("DD MMMM YYYY hh:mm A")}
                    </TableCell>
                    <TableCell>{Object.keys(row.endpoints).length}</TableCell>
                    <TableCell>{row.totalRequestIn24Hours}</TableCell>
                    <TableCell>{row.averageRequestsPerMinute}</TableCell>
                    <TableCell>
                      <IconButton onClick={() => handleExpandClick(index)}>
                        {expandedRow === index ? (
                          <ExpandLessIcon />
                        ) : (
                          <ExpandMoreIcon />
                        )}
                      </IconButton>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell colSpan={6} sx={{ p: 0 }}>
                      <Collapse
                        in={expandedRow === index}
                        timeout="auto"
                        unmountOnExit
                      >
                        <Box m={1}>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell>Endpoint</TableCell>
                                <TableCell>Request Count</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {Object.entries(row.endpoints).map(
                                ([endpoint, data], idx) => (
                                  <TableRow key={idx}>
                                    <TableCell>{endpoint}</TableCell>
                                    <TableCell>{data.count}</TableCell>
                                  </TableRow>
                                )
                              )}
                            </TableBody>
                          </Table>
                        </Box>
                      </Collapse>
                    </TableCell>
                  </TableRow>
                </React.Fragment>
              ))
            ) : (
              <>
                <TableRow>
                  <TableCell colSpan={6}>
                    <Box>
                      <Typography variant="h6">No Data Available</Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              </>
            )}
          </TableBody>
        </Table>
      </Box>

      {/* Sticky Pagination */}
      <Box
        sx={{
          flexShrink: 0,
          background: "white",
          borderTop: "1px solid #ddd",
        }}
      >
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={totalLogs}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Box>
    </Paper>
  );
};

export default ServerPar;
