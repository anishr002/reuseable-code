import ReactDOM from "react-dom/client";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";
import TableRow from "@mui/material/TableRow";
import dayjs from "dayjs";
import GroupIcon from "@mui/icons-material/Group";
import {
  Avatar,
  Box,
  Button,
  Pagination,
  Switch,
  TableCell,
  TextField,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
const label = { inputProps: { "aria-label": "Switch demo" } };
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import NoDataIllustration from "../components/NoDataIllustration";
import CoachProProgress from "../components/CoachProProgress";

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});

export default function PendingCoachPage() {
  interface Row {
    _id: string;
    name: string;
    email: string;
    image: string;
    gender: string;
    DOB: string;
    freeTrial: string;
    block: number;
    approve: number;
    emailVerified: number;
  }
  const [rows, setData] = React.useState<Row[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state

  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const [searchTerm, setSearchTerm] = React.useState<string>(""); //charecter search
  const [filterSearch, setFilterSearch] = React.useState<string>(""); //charecter search

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/list?pageNo=${pageNo}&filter=0&searchTerm=${filterSearch}`
      );
      if (response.status === 200) {
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        return setData(response.data.coachList);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      return setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo, pageUpdated, filterSearch]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  //handle coach block
  const handleBlockClick =
    (id: string, blockStatus: number) =>
      async (_event: React.ChangeEvent<HTMLInputElement>) => {
        setLoading(true);
        const text = blockStatus == 1 ? "unblock" : "block";
        swalWithBootstrapButtons
          .fire({
            title: "Are you sure?",
            text: `You want to ${text} it`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: `Yes, ${text} It!`,
            cancelButtonText: "Not, Now",
            reverseButtons: true,
          })
          .then(async (result) => {
            if (result.isConfirmed) {
              setLoading(true);
              try {
                const response = await httpAPI_admin.put(
                  `/admin/coach/block/${id.trim()}`
                );
                if (response.data.success === true) {
                  setPageUpdated(!pageUpdated);
                  return setLoading(false);
                }
              } catch (error) {
                console.error("Error accepting:", error);
              } finally {
                setLoading(false);
                swalWithBootstrapButtons.fire({
                  title: `${text}!`,
                  text: `Profile ${text} successfully`,
                  icon: "success",
                  showConfirmButton: false,
                  timer: 1500,
                });
                return setPageUpdated(!pageUpdated);
              }
            } else {
              setLoading(false);
            }
          });
      };

  //handle coach profile approve
  const handleApproveClick =
    (id: string, approveStatus: number) =>
      async (_: React.ChangeEvent<HTMLInputElement>) => {
        setLoading(true);
        const text = approveStatus == 0 ? "approve" : "reject";
        const container = document.createElement("div");
        const root = ReactDOM.createRoot(container);
        root.render(<CoachProProgress coachId={id} />);
        swalWithBootstrapButtons
          .fire({
            title: "Are you sure?",
            text: `You want to ${text} it`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: `Yes, ${text} It!`,
            cancelButtonText: "Not, Now",
            reverseButtons: true,
            html: text === "approve" ? container : "",
            customClass: {
              confirmButton: "btn-success",
              cancelButton: "btn-danger",
              popup: "custom-modal",
            },
            buttonsStyling: false,
            backdrop: true,
            willClose: () => {
              // Clean up the React component on modal close
              root.unmount();
            },
          })
          .then(async (result) => {
            if (result.isConfirmed) {
              setLoading(true);
              try {
                const response = await httpAPI_admin.put(
                  `/admin/coach/profile-approve/${id.trim()}`
                );
                if (response.data.success === true) {
                  setPageUpdated(!pageUpdated);
                  return setLoading(false);
                }
              } catch (error) {
                console.error("Error accepting:", error);
              } finally {
                setLoading(false);
                swalWithBootstrapButtons.fire({
                  title: `${text}!`,
                  text: `Profile ${text} successfully`,
                  icon: "success",
                  showConfirmButton: false,
                  timer: 1500,
                });
                return setPageUpdated(!pageUpdated);
              }
            } else {
              setLoading(false);
            }
          });
      };

  //handle coach account delete
  const handleDelteClick = (id: string) => {
    setLoading(true);
    const text = "delete";
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to ${text} it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, ${text} It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI_admin.put(
              `/admin/coach/account-delete/${id.trim()}`
            );
            if (response.data.success === true) {
              setPageUpdated(!pageUpdated);
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            swalWithBootstrapButtons.fire({
              title: `Delete!`,
              text: `Account deleted successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            return setPageUpdated(!pageUpdated);
          }
        } else {
          setLoading(false);
        }
      });
  };

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Unapproved Coaches
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
              }}
            >
              <TextField
                id="outlined-search"
                placeholder="Search..."
                type="search"
                variant="outlined"
                fullWidth
                size="small"
                value={searchTerm}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  setSearchTerm(event.target.value);
                  if (event.target.value === "") {
                    setFilterSearch("");
                  }
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                    backgroundColor: "#fff",
                    cursor: "pointer",
                  },
                }}
              />
              <Button
                sx={{
                  paddingX: 3,
                  backgroundColor: "#3aa7a3",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "#31c6f8",
                  },
                }}
                onClick={() => setFilterSearch(searchTerm)}
              >
                Apply
              </Button>
            </Box>

            <GroupIcon style={{ color: "#013338" }} />
          </Box>
        </Box>
        {rows.length > 0 ? (
          <TableContainer
            sx={{
              maxHeight: {
                lg:
                  pageInfo.totalPages > 1
                    ? "calc(100vh - 240px)"
                    : "calc(100vh - 170px)",
                xl: "auto",
              },
              overflow: "auto",
            }}
          >
            <Table stickyHeader aria-label="sticky table">
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Image
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Name
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Email
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Gender
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    DOB
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Details
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Free Trial
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Email Verified
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Block
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Approve
                  </TableCell>
                  <TableCell
                    sx={{ backgroundColor: "#013338", color: "white" }}
                  >
                    Delete
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row, index) => {
                  return (
                    <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                      <TableCell>
                        <span>
                          {row.image ? (
                            <>
                              <Avatar
                                alt={row.name}
                                src={`${backendURL}/usersProfile/${row.image}`}
                              />
                            </>
                          ) : (
                            <>
                              <Avatar
                                sx={{
                                  backgroundColor: "#013338",
                                }}
                              >
                                {capitalizeFirstLetter(row.name)}
                              </Avatar>
                            </>
                          )}
                        </span>
                      </TableCell>
                      <TableCell>{row.name}</TableCell>
                      <TableCell>{row.email}</TableCell>
                      <TableCell>{row.gender ? row.gender : "-"}</TableCell>
                      <TableCell
                        sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                      >
                        {row.DOB ? dayjs(row.DOB).format("DD-MM-YYYY") : "-"}
                      </TableCell>
                      <TableCell>
                        <Link to={`/coach/detail/${row._id}`}>
                          <VisibilityIcon
                            color="primary"
                            style={{ cursor: "pointer" }}
                          />
                        </Link>
                      </TableCell>
                      <TableCell>
                        <Switch
                          {...label}
                          defaultChecked
                          disabled
                          color={row.freeTrial === "true" ? "success" : "error"}
                        />
                      </TableCell>
                      <TableCell>
                        <Switch
                          {...label}
                          disabled
                          defaultChecked={
                            row.emailVerified === 1 ? true : false
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <Switch
                          {...label}
                          checked={row.block === 1 ? true : false}
                          color={row.block === 1 ? "error" : "default"}
                          onChange={handleBlockClick(row._id, row.block)}
                        />
                      </TableCell>
                      <TableCell>
                        <Switch
                          {...label}
                          checked={row.approve === 1 ? true : false}
                          onChange={handleApproveClick(row._id, row.approve)}
                        />
                      </TableCell>
                      <TableCell>
                        <DeleteIcon
                          color="error"
                          style={{ cursor: "pointer" }}
                          onClick={() => handleDelteClick(row._id)}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <NoDataIllustration />
        )}
        {pageInfo.totalPages > 1 && (
          <Box
            sx={{
              display: "flex",
              justifyConten: "center",
              alignItems: "center",
              paddingY: 2,
              borderTop: "2px solid #ccc",
              height: "80px",
            }}
          >
            <Pagination
              count={Number(pageInfo.totalPages)}
              page={Number(pageInfo.currentPage)}
              onChange={handlePagination}
            />
          </Box>
        )}
      </Paper>
    </>
  );
}
