import React, { useEffect, useState } from "react";
import { useForm, SubmitHandler, Controller } from "react-hook-form";
import {
  Paper,
  Tabs,
  Tab,
  Button,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Typography,
  CircularProgress,
  Box,
  TextField,
  Autocomplete,
  Avatar,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import FilePreview from "../components/FilePreview";

// Component for managing monthly reports
const Monthlyreports: React.FC<{ coachId: string }> = ({
  coachId,
}: {
  coachId: string;
}) => {
  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm<{ filter: string; month: string; year: string }>({
    mode: "onSubmit",
  });
  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [report, setreport] = useState<string | null>(null);
  const [noOrder, setNoOrder] = useState<boolean>(false);

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const years = Array.from({ length: 3 }, (_, i) =>
    (new Date().getFullYear() - i).toString()
  );

  const onSubmit: SubmitHandler<{
    month: string;
    year: string;
    filter: string;
  }> = async (data) => {
    setShowDownload(false);
    setNoOrder(false);
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/coach/coach-booking-reports/gen-rep/monthly/${coachId}/${data.month}/${data.year}?filter=${data.filter}`
      );
      console.log(response);
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setreport(response.data.report);
          setShowDownload(true);
          setNoOrder(false);
        } else {
          setShowDownload(false);
          setNoOrder(true);
        }
      }
    } catch (error) {
      console.log("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      style={{ display: "flex", flexDirection: "column", gap: "16px" }}
    >
      <FormControl fullWidth error={!!errors.month}>
        <InputLabel id="month-select-label">Month</InputLabel>
        <Select
          labelId="month-select-label"
          {...register("month", { required: "Month is required" })}
        >
          {months.map((month) => (
            <MenuItem key={month} value={month}>
              {month}
            </MenuItem>
          ))}
        </Select>
        {errors.month && (
          <Typography variant="caption" color="error">
            {errors.month.message}
          </Typography>
        )}
      </FormControl>

      <FormControl fullWidth error={!!errors.year}>
        <InputLabel id="year-select-label">Year</InputLabel>
        <Select
          labelId="year-select-label"
          {...register("year", { required: "Year is required" })}
        >
          {years.map((year) => (
            <MenuItem key={year} value={year}>
              {year}
            </MenuItem>
          ))}
        </Select>
        {errors.year && (
          <Typography variant="caption" color="error">
            {errors.year.message}
          </Typography>
        )}
      </FormControl>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Session Status</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            defaultValue={4}
            label="Session Status"
            {...register("filter")}
            error={!!errors.filter}
          >
            {filterOptions.map((y) => (
              <MenuItem value={y.value}>{y.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
        {errors?.filter && (
          <p className="text-red-600 text-sm font-semibold">
            {errors?.filter?.message}
          </p>
        )}
      </Box>

      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
          py: 1,
          flexDirection: "column",
        }}
      >
        {!report ? (
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            {loading ? (
              <CircularProgress size={24} sx={{ color: "white" }} />
            ) : (
              "Get report"
            )}
          </Button>
        ) : (
          <Box
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
            onClick={() => {
              setLoading(false);
              setNoOrder(false);
              setreport(null);
              setShowDownload(false);
            }}
          >
            Clear
          </Box>
        )}
        {showDownload && report && (
          <FilePreview
            file={report}
            fileUrl={`${backendURL}/reports/${report}`}
          />
        )}
      </Box>

      {noOrder && (
        <Typography color="error" align="center">
          This Coach do not have any bookings during this period, Please change
          the filter and try again.
        </Typography>
      )}
    </form>
  );
};

const Yearlyreports: React.FC<{ coachId: string }> = ({
  coachId,
}: {
  coachId: string;
}) => {
  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm<{ filter: string; year: string }>({ mode: "onSubmit" });

  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [report, setreport] = useState<string | null>(null);
  const [noOrder, setNoOrder] = useState<boolean>(false);

  const years = Array.from({ length: 3 }, (_, i) =>
    (new Date().getFullYear() - i).toString()
  );

  const onSubmit: SubmitHandler<{ year: string; filter: string }> = async (
    data
  ) => {
    setShowDownload(false);
    setNoOrder(false);
    setLoading(true);
    try {
      setLoading(true);
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/coach/coach-booking-reports/gen-rep/yearly/${coachId}/${data.year}?filter=${data.filter}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setreport(response.data.report);
          setShowDownload(true);
          setNoOrder(false);
        } else {
          setNoOrder(true);
          setShowDownload(false);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.log("faching error", error);
    }
  };

  return (
    <form
      style={{ display: "flex", flexDirection: "column", gap: "16px" }}
      onSubmit={handleSubmit(onSubmit)}
    >
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Year</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            label="Year"
            {...register("year", { required: "Please select a year" })}
            error={!!errors.year}
          >
            {years.map((y) => (
              <MenuItem value={y}>{y}</MenuItem>
            ))}
          </Select>
        </FormControl>
        {errors.year && (
          <Typography variant="caption" color="error">
            {errors.year.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Session Status</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            defaultValue={4}
            label="Session Status"
            {...register("filter")}
            error={!!errors.filter}
          >
            {filterOptions.map((y) => (
              <MenuItem value={y.value}>{y.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
        {errors?.filter && (
          <p className="text-red-600 text-sm font-semibold">
            {errors?.filter?.message}
          </p>
        )}
      </Box>
      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
          py: 1,
          flexDirection: "column",
        }}
      >
        {!report ? (
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            {loading ? (
              <CircularProgress size={24} sx={{ color: "white" }} />
            ) : (
              "Get report"
            )}
          </Button>
        ) : (
          <Box
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
            onClick={() => {
              setLoading(false);
              setNoOrder(false);
              setreport(null);
              setShowDownload(false);
            }}
          >
            Clear
          </Box>
        )}
        {showDownload && report && (
          <FilePreview
            file={report}
            fileUrl={`${backendURL}/reports/${report}`}
          />
        )}
      </Box>
      {noOrder && (
        <>
          <Typography color="error" align="center">
            This Coach do not have any bookings during this period, Please
            change the filter and try again.
          </Typography>
        </>
      )}
    </form>
  );
};

const Customreports: React.FC<{ coachId: string }> = ({
  coachId,
}: {
  coachId: string;
}) => {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    setValue,
  } = useForm<{ filter: string; from: string; to: string }>({
    mode: "onChange",
  });

  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [report, setreport] = useState<string | null>(null);
  const [noOrder, setNoOrder] = useState<boolean>(false);

  const onSubmit: SubmitHandler<{
    from: string;
    to: string;
    filter: string;
  }> = async (data) => {
    setShowDownload(false);
    setNoOrder(false);
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/coach/coach-booking-reports/gen-rep/periodic/${coachId}/${data.from}/${data.to}?filter=${data.filter}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setreport(response.data.report);
          setShowDownload(true);
          setNoOrder(false);
        } else {
          setNoOrder(true);
          setShowDownload(false);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.error("Fetching error", error);
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      style={{ display: "flex", flexDirection: "column", gap: "16px" }}
      onSubmit={handleSubmit(onSubmit)}
    >
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="From"
              {...register("from", { required: "Please select a start date" })}
              disableFuture
              onChange={(date) =>
                setValue("from", dayjs(date).format("YYYY-MM-DD"))
              }
              slotProps={{
                textField: {
                  error: !!errors.from,
                  helperText: errors.from?.message,
                },
              }}
            />
          </LocalizationProvider>
        </FormControl>
      </Box>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="To"
              {...register("to", {
                required: "Please select an end date",
                validate: {
                  laterThanFrom: (value) => {
                    const fromDate = watch("from");
                    if (fromDate && dayjs(value).isBefore(dayjs(fromDate))) {
                      return "End date must be later than start date";
                    }
                    return true; // valid
                  },
                },
              })}
              disableFuture
              onChange={(date) =>
                setValue("to", dayjs(date).format("YYYY-MM-DD"))
              }
              slotProps={{
                textField: {
                  error: !!errors.to,
                  helperText: errors.to?.message,
                },
              }}
            />
          </LocalizationProvider>
        </FormControl>
      </Box>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Session Status</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            defaultValue={4}
            label="Session Status"
            {...register("filter")}
            error={!!errors.filter}
          >
            {filterOptions.map((y) => (
              <MenuItem value={y.value}>{y.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
        {errors?.filter && (
          <p className="text-red-600 text-sm font-semibold">
            {errors?.filter?.message}
          </p>
        )}
      </Box>

      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
          py: 1,
          flexDirection: "column",
        }}
      >
        {!report ? (
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            {loading ? (
              <CircularProgress size={24} sx={{ color: "white" }} />
            ) : (
              "Get report"
            )}
          </Button>
        ) : (
          <Box
            sx={{
              maxWidth: 300,
              height: "40px",
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
            onClick={() => {
              setLoading(false);
              setNoOrder(false);
              setreport(null);
              setShowDownload(false);
            }}
          >
            Clear
          </Box>
        )}
        {showDownload && report && (
          <FilePreview
            file={report}
            fileUrl={`${backendURL}/reports/${report}`}
          />
        )}
      </Box>
      {noOrder && (
        <>
          <Typography color="error" align="center">
            This Coach do not have any bookings during this period, Please
            change the filter and try again.
          </Typography>
        </>
      )}
    </form>
  );
};

// Main tabbed component

interface Coach {
  _id: string;
  name: string;
  Lname: string;
  email: string;
  image: string;
}

const BookingsReport: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);

  const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const [selectedObject, setSelectedObject] = useState<Coach | null>(null);

  const {
    control,
    formState: { errors },
  } = useForm<{ filter: string; user: Coach }>();

  const [data, setData] = useState<Coach[] | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchCoachList = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/coach/coach-booking-reports/coach-list`
      );
      console.log(response);
      if (response.status === 200) {
        setData(response.data.data);
      } else return toast.error("Error while fetching coaches");
    } catch (error) {
      console.error({ error });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoachList();
  }, []);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <Paper
      sx={{
        width: "100%",
        overflow: "auto",
        height: "calc(100vh - 88px)",
        maxHeight: "calc(100vh - 88px)",
      }}
    >
      <Box sx={{ width: "100%" }}>
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            gap: "5px",
            alignItems: "center",
            color: "#013338",
          }}
        >
          Coach's Booking Reports
        </Typography>
      </Box>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          gap: 1,
          backgroundColor: "transparent",
          px: 3,
          py: 2,
        }}
      >
        <Box sx={{ minWidth: 120 }}>
          <FormControl fullWidth>
            <Controller
              name="user"
              control={control}
              rules={{ required: "Please select a user" }}
              render={({ field }) => (
                <Autocomplete
                  noOptionsText={`No Results found, try adjusting search input !`}
                  {...field}
                  options={data ? data : []}
                  getOptionLabel={(option) =>
                    `${option.name} ${option.Lname} ( ${option.email} )`
                  }
                  onChange={(_, value) => {
                    setSelectedObject(value);
                    field.onChange(value);
                  }}
                  renderOption={(props, option) => (
                    <Box
                      component="li"
                      {...props}
                      sx={{ display: "flex", alignItems: "center", gap: 1 }}
                    >
                      <Avatar
                        src={`${backendURL}/usersProfile/${option.image}`}
                        alt={option.name}
                      />
                      <Box>
                        <Typography>{`${option.name} ${option.Lname}`}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          {option.email}
                        </Typography>
                      </Box>
                    </Box>
                  )}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Select Coach"
                      error={!!errors.user}
                    />
                  )}
                />
              )}
            />
          </FormControl>

          {errors.user && (
            <Typography variant="caption" color="error">
              {errors?.user.message && errors?.user.message}
            </Typography>
          )}
        </Box>
        {selectedObject === null && (
          <Box sx={{ minWidth: 120, px: 3, py: 3 }}>
            <Typography variant="body2">Please Select a coach</Typography>
          </Box>
        )}
      </Box>
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          gap: 1,
          backgroundColor: "transparent",
          px: 3,
          py: 2,
        }}
      >
        {selectedObject && (
          <>
            <Tabs
              value={activeTab}
              onChange={handleTabChange}
              indicatorColor="primary"
              textColor="inherit"
            >
              <Tab label="Monthly" />
              <Tab label="Yearly" />
              <Tab label="Custom" />
            </Tabs>
            <Paper elevation={0} sx={{ py: 2 }}>
              {activeTab === 0 && (
                <Monthlyreports coachId={selectedObject?._id} />
              )}
              {activeTab === 1 && (
                <Yearlyreports coachId={selectedObject?._id} />
              )}
              {activeTab === 2 && (
                <Customreports coachId={selectedObject?._id} />
              )}
            </Paper>
          </>
        )}
      </Paper>
    </Paper>
  );
};

export default BookingsReport;
const filterOptions = [
  { name: "All", value: 4 },
  { name: "Upcoming", value: 0 },
  { name: "Completed", value: 1 },
  { name: "Cancelled", value: 2 },
];
