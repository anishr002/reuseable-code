import CloseIcon from "@mui/icons-material/Close";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import * as React from "react";
import Paper from "@mui/material/Paper";
import {
  Avatar,
  Box,
  Switch,
  Typography,
  TextField,
  Grid,
  Tooltip,
  Chip,
  Drawer,
  IconButton,
  Rating,
  CircularProgress,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
import DeleteIcon from "@mui/icons-material/Delete";
import { Link, useNavigate, useParams } from "react-router-dom";
const label = { inputProps: { "aria-label": "Switch demo" } };
const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});

export default function UserDetails() {
  const { userId } = useParams(); //coachee id
  const navigate = useNavigate();
  interface Row {
    _id: string;
    name: string;
    email: string;
    gender: string;
    image: string;
    DOB: string;
    freeTrial: string;
    block: number;
    approve: number;
    userName: string;
    sessions: Session[];
    emailVerified: number;
    averageRating: number;
    totalRatings: number;
  }
  interface Session {
    session_name: string;
    bookedOn: string;
    bookingTime: string;
    booking_id: string;
    coachName: string;
    status: number;
  }
  const [data, setData] = React.useState<Row>({
    _id: "",
    name: "",
    email: "",
    gender: "",
    DOB: "",
    image: "",
    freeTrial: "",
    block: 0,
    approve: 0,
    userName: "",
    emailVerified: 0,
    sessions: [],
    totalRatings: 0,
    averageRating: 0,
  });
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const fetchData = async () => {
    try {
      const response = await httpAPI_admin.get(`/admin/user/details/${userId}`);
      console.log("dfasdf", response);
      if (response.data.userData) {
        return setData(response.data.userData);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, []);

  //handle coach block
  const handleBlockClick =
    (id: string, blockStatus: number) =>
      async (_event: React.ChangeEvent<HTMLInputElement>) => {
        setLoading(true);
        const text = blockStatus == 1 ? "unblock" : "block";
        swalWithBootstrapButtons
          .fire({
            title: "Are you sure?",
            text: `You want to ${text} it`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: `Yes, ${text} It!`,
            cancelButtonText: "Not, Now",
            reverseButtons: true,
          })
          .then(async (result) => {
            if (result.isConfirmed) {
              setLoading(true);
              try {
                const response = await httpAPI_admin.put(
                  `/admin/user/block/${id.trim()}`
                );
                if (response.data.success === true) {
                  setPageUpdated(!pageUpdated);
                  return setLoading(false);
                }
              } catch (error) {
                console.error("Error accepting:", error);
              } finally {
                setLoading(false);
                swalWithBootstrapButtons.fire({
                  title: `${text}!`,
                  text: `Profile ${text} successfully`,
                  icon: "success",
                  showConfirmButton: false,
                  timer: 1500,
                });
                setPageUpdated(!pageUpdated);
              }
            } else {
              setLoading(false);
            }
          });
      };

  //handle user account delete
  const handleDelteClick = (id: string) => {
    setLoading(true);
    const text = "delete";
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to ${text} it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, ${text} It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI_admin.put(
              `/admin/user/account-delete/${id.trim()}`
            );
            if (response.data.success === true) {
              setPageUpdated(!pageUpdated);
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            swalWithBootstrapButtons.fire({
              title: `Delete!`,
              text: `Account deleted successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            setPageUpdated(!pageUpdated);
            return navigate("/user");
          }
        } else {
          setLoading(false);
        }
      });
  };
  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };

  const [openDrawer, setOpenDrawer] = React.useState<boolean>(false);

  interface RatingDataType {
    name: string;
    Lname: string;
    coachId: string;
    image: string;
    message: string;
    createdAt: string;
    ratingNumber: number;
  }
  const [ratingData, setRatingData] = React.useState<RatingDataType[]>([]);
  const [loadingRating, setLoadingRating] = React.useState<boolean>(false);

  const fetchRatingData = async () => {
    console.log(userId);
    setLoadingRating(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/user/details/rating/${userId}`
      );
      console.log(response.data);
      if (response.data.data) {
        setRatingData(response.data.data);
        return setLoadingRating(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoadingRating(false);
    }
  };
  React.useEffect(() => {
    fetchRatingData();
  }, []);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <div style={{ height: "auto", overflow: "auto" }}>
      <Paper
        sx={{
          width: "100%",
          overflowY: "scroll",
          overflowX: "hidden",
          maxHeight: "calc(100vh - 110px)",
        }}
      >
        <Grid container>
          {/* first section for header  */}
          <Grid item sm={12} xs={12} sx={{ height: "30vh" }}>
            <Box
              sx={{
                background: "#013338",
                width: "100%",
                p: 1,
                height: "18vh",
                position: "relative",
              }}
            >
              <Box
                display="flex"
                justifyContent="start"
                alignItems="start"
                margin="0 auto"
                padding="0 15px"
                width={"100%"}
                flexDirection={{ md: "row", sm: "column", xs: "column" }}
                height={{ md: 160, sm: 230, xs: 230 }}
                borderRadius="50%"
                position="absolute"
                sx={{
                  top: "100%",
                  transform: { md: "translateY(-50%)", xs: "translateY(-40%)" },
                }}
              >
                {data?.image ? (
                  <Avatar
                    src={`${backendURL}/usersProfile/${data?.image}`}
                    alt="User"
                    sx={{
                      width: 130,
                      height: 130,
                    }}
                  />
                ) : (
                  <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    sx={{
                      minWidth: 130,
                      height: 130,
                    }}
                    bgcolor="slategray"
                    borderRadius="50%"
                  >
                    <Typography
                      variant="body2"
                      color="white"
                      sx={{ fontSize: "1.5rem" }}
                    >
                      {capitalizeFirstLetter(data?.name)}
                    </Typography>
                  </Box>
                )}
                <Box
                  p={1}
                  sx={{
                    width: "100%",
                    overflow: "hidden",
                    color: { sm: "#013338", xs: "#013338", md: "white" },
                  }}
                >
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: "normal",
                      padding: "0 16px",
                      width: "100%",
                      whiteSpace: "nowrap",
                      textOverflow: { sm: "ellipsis" },
                    }}
                  >
                    {data?.name?.charAt(0).toUpperCase() + data?.name?.slice(1)}
                  </Typography>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: "300",
                      fontSize: "1rem",
                      padding: "2px 16px",
                      width: "100%",
                      whiteSpace: { lg: "nowrap", sm: "normal", xs: "balance" },
                    }}
                  >
                    {data.email}
                  </Typography>
                </Box>
              </Box>
              <Box
                display="flex"
                justifyContent="start"
                alignItems="start"
                margin="0 auto"
                padding="0 15px"
                position="absolute"
                sx={{
                  right: 0,
                  top: { lg: "70%", sm: "50%", xs: "20%" },
                  transform: "translateY(-10%)",
                }}
              ></Box>
            </Box>
          </Grid>
          {/* second section for the detals and other options  */}
          <Grid item sm={12} md={6} xs={12}>
            <div className="flex flex-col gap-1" style={{ padding: "10px" }}>
              <Box
                sx={{
                  borderRadius: 2,
                }}
              >
                <Grid container spacing={2} sx={{ width: "100%" }}>
                  <Grid item sm={12} xs={12}>
                    <Paper
                      elevation={3}
                      sx={{
                        width: "100%",
                        px: 2,
                        py: 1,
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <Typography
                        variant="body1"
                        sx={{
                          fontSize: "1rem",
                          fontWeight: 600,
                          color: "black",
                        }}
                      >
                        Email Status
                      </Typography>
                      {data?.emailVerified === 0 ? (
                        <Box
                          sx={{
                            display: "flex",
                            p: 0,
                            gap: 1,
                            color: "#3aa7a3",
                          }}
                        >
                          <CheckCircleIcon color="inherit" />
                          <Typography
                            variant="body2"
                            sx={{ fontFamily: "montserrat" }}
                          >
                            Verified
                          </Typography>
                        </Box>
                      ) : (
                        <Box sx={{ display: "flex", p: 0, gap: 2 }}>
                          <Typography
                            variant="body2"
                            sx={{ fontFamily: "montserrat" }}
                          >
                            Unverified
                          </Typography>
                        </Box>
                      )}
                    </Paper>
                  </Grid>
                  <Grid item sm={12} xs={12}>
                    <Paper
                      elevation={3}
                      sx={{
                        width: "100%",
                        px: 2,
                        py: 2,
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "space-between",
                        alignItems: "start",
                        gap: 1,
                      }}
                    >
                      {[
                        { label: "User Name", value: data.userName },
                        {
                          label: "Name",
                          value:
                            data.name.charAt(0).toUpperCase() +
                            data.name.slice(1),
                        },
                        { label: "Email", value: data.email },
                      ].map((item, index) => (
                        <Grid
                          key={index}
                          item
                          sm={12}
                          xs={12}
                          sx={{ width: "100%" }}
                        >
                          {renderTextField(item.label, item.value)}
                        </Grid>
                      ))}

                      <Grid item sm={12} xs={12} display={"flex"} gap={2}>
                        <Box
                          sx={{
                            p: 0,
                            width: "100%",
                            display: "flex",
                            justifyContent: "start",
                            alignItems: "start",
                            flexDirection: "column",
                            gap: 1.5,
                          }}
                        >
                          <Typography
                            variant="body1"
                            sx={{
                              fontSize: "0.955rem",
                              fontWeight: 600,
                              color: "black",
                            }}
                          >
                            Date Of Birth
                          </Typography>
                          <TextField
                            size="small"
                            fullWidth
                            label={"Date Of Birth"}
                            variant="outlined"
                            defaultValue={
                              data?.DOB && !isNaN(new Date(data.DOB).getTime())
                                ? new Date(data.DOB).toDateString()
                                : "Not Provided Yet"
                            }
                            InputProps={{
                              inputProps: {
                                readOnly: true,
                              },
                            }}
                          />
                        </Box>

                        <Box
                          sx={{
                            p: 0,
                            width: "100%",
                            display: "flex",
                            justifyContent: "start",
                            alignItems: "start",
                            flexDirection: "column",
                            gap: 1.5,
                          }}
                        >
                          <Typography
                            variant="body1"
                            sx={{
                              fontSize: "0.955rem",
                              fontWeight: 600,
                              color: "black",
                            }}
                          >
                            Gender
                          </Typography>
                          <TextField
                            size="small"
                            fullWidth
                            label={"Gender"}
                            variant="outlined"
                            defaultValue={data.gender}
                            InputProps={{
                              inputProps: {
                                readOnly: true,
                              },
                            }}
                          />
                        </Box>
                      </Grid>
                    </Paper>
                  </Grid>
                </Grid>
              </Box>
            </div>
          </Grid>
          <Grid item sm={12} md={6} xs={6}>
            <Box
              sx={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "start",
                justifyContent: "start",
                paddingY: "20px",
                p: "20px",
              }}
            >
              {/* 15 min. Free Trial status */}

              {/* Email Verified status */}
              {/* <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width="100%"
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                  }}
                >
                  Email Verified
                </Typography>
                <Box display="flex" alignItems="center">
                  <Tooltip
                    title={
                      data?.emailVerified === 1 ? "Verified" : "Unverified"
                    }
                  >
                    {data.emailVerified === 1 ? (
                      <Switch {...label} disabled defaultChecked />
                    ) : (
                      <Switch {...label} disabled />
                    )}
                  </Tooltip>
                </Box>
              </Box> */}

              {/* Block status */}
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width="100%"
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                  }}
                >
                  Block
                </Typography>
                <Box display="flex" alignItems="center">
                  <Tooltip title={data.block === 1 ? "Blocked" : "Un-Blocked"}>
                    <Switch
                      {...label}
                      checked={data.block === 1 ? true : false}
                      color={data.block === 1 ? "error" : "default"}
                      onChange={handleBlockClick(data._id, data.block)}
                    />
                  </Tooltip>
                </Box>
              </Box>

              {/* Delete status */}
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width="100%"
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                  }}
                >
                  Delete
                </Typography>
                <Box display="flex" alignItems="center">
                  <Tooltip title={"Delete"}>
                    <DeleteIcon
                      color="error"
                      style={{ cursor: "pointer" }}
                      onClick={() => handleDelteClick(data._id)}
                    />
                  </Tooltip>
                </Box>
              </Box>

              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width={{ sm: "100%", md: "100%" }}
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                  }}
                >
                  Booking History
                </Typography>
                <Box display="flex" alignItems="center">
                  <Chip
                    size="small"
                    label="Details"
                    onClick={() =>
                      navigate(`/coachee/booking-history/${userId}`)
                    }
                    sx={{
                      backgroundColor: "#5FB6D5",
                      color: "white",
                      width: "fit-content",
                      px: 1,
                      "&:hover": {
                        backgroundColor: "#EBBE34",
                      },
                    }}
                  />
                </Box>
              </Box>

              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width={{ sm: "100%", md: "100%" }}
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                  }}
                >
                  Transaction History
                </Typography>
                <Box display="flex" alignItems="center">
                  <Chip
                    size="small"
                    label="Details"
                    onClick={() =>
                      navigate(`/coachee/transaction-history/${userId}`)
                    }
                    sx={{
                      backgroundColor: "#5FB6D5",
                      color: "white",
                      width: "fit-content",
                      px: 1,
                      "&:hover": {
                        backgroundColor: "#EBBE34",
                      },
                    }}
                  />
                </Box>
              </Box>

              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width={{ sm: "100%", md: "100%" }}
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                  }}
                >
                  Chat History
                </Typography>
                <Box display="flex" alignItems="center">
                  <Chip
                    size="small"
                    label="Details"
                    onClick={() => navigate(`/chat-history/${userId}/user`)}
                    sx={{
                      backgroundColor: "#5FB6D5",
                      color: "white",
                      width: "fit-content",
                      px: 1,
                      "&:hover": {
                        backgroundColor: "#EBBE34",
                      },
                    }}
                  />
                </Box>
              </Box>
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width={{ sm: "100%", md: "100%" }}
                gap={3}
                sx={{ padding: "4px 25px" }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{
                    color: "#013338",
                    fontWeight: "bold",
                    width: { sm: "160px" },
                    display: "flex",
                    alignItems: "center",
                    gap: 0.51,
                  }}
                >
                  Ratings{" "}
                  <Rating
                    name="read-only"
                    size="small"
                    value={data.averageRating}
                    precision={0.5}
                    readOnly
                  />
                  <b
                    style={{ color: "gray", fontWeight: 500 }}
                  >{`(${data?.totalRatings})`}</b>
                </Typography>
                {data?.totalRatings > 0 ? (
                  <Box display="flex" alignItems="center">
                    <Chip
                      size="small"
                      label="Details"
                      onClick={() => setOpenDrawer(true)}
                      sx={{
                        backgroundColor: "#5FB6D5",
                        color: "white",
                        width: "fit-content",
                        px: 1,
                        "&:hover": {
                          backgroundColor: "#EBBE34",
                        },
                      }}
                    />
                  </Box>
                ) : (
                  <Box display="flex" alignItems="center">
                    <Chip
                      size="small"
                      label="None"
                      sx={{
                        backgroundColor: "gray",
                        color: "white",
                        width: "fit-content",
                        px: 1,
                        "&:hover": {
                          backgroundColor: "#gray",
                        },
                      }}
                    />
                  </Box>
                )}
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      <Drawer
        anchor="right"
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
      >
        {loadingRating ? (
          <CircularProgress size={19} />
        ) : (
          <Box
            sx={{
              width: { xs: 320, sm: 350, md: 550, xl: 660 },
              postition: "relative",
            }}
            role="presentation"
          >
            <Box
              sx={{
                zIndex: 99,
                display: "flex",
                width: "100%",
                justifyContent: "space-between",
                alignItems: "center",
                px: 2,
                py: 2,
                position: "sticky",
                top: 0,
                backgroundColor: "white",
              }}
            >
              <Typography variant="h6" fontWeight="bold" color="textPrimary">
                Posted Reviews & Ratings
              </Typography>
              <IconButton onClick={() => setOpenDrawer(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
            {ratingData.map((a, index) => (
              <Box
                display={"flex"}
                key={index}
                sx={{
                  width: "100%",
                  borderBottom: "1px solid gray",
                  py: 2,
                  my: 1,
                  px: 3,
                  flexDirection: { xs: "column", md: "row" },
                  justifyContent: "start",
                  alignItems: { xs: "start", md: "start" },
                  gap: 1,
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: { xs: "row", md: "column" },
                    justifyContent: "start",
                    alignItems: { xs: "center", md: "start" },
                    gap: { xs: 2, md: 1 },
                    width: { xs: "100%", md: "30%" },
                  }}
                >
                  <Avatar
                    alt={a.name}
                    src={`${backendURL}/usersProfile/${a.image}`}
                    sx={{
                      height: { xs: 50, md: 70 },
                      width: { xs: 50, md: 70 },
                    }}
                  />
                  <Box
                    sx={{
                      fontWeight: 600,
                      display: "flex",
                      flexDirection: "column",
                      width: "100%",
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{ fontFamily: "Montserrat", fontWeight: 600 }}
                    >
                      <Link
                        style={{
                          textDecoration: "none",
                          color: "#013338",
                        }}
                        to={`/coach/detail/${a.coachId}`}
                      >
                        {a.name} {a.Lname}
                      </Link>
                    </Typography>
                    <Typography
                      variant="caption"
                      sx={{ fontFamily: "Montserrat", fontWeight: 500 }}
                    >
                      {a.createdAt &&
                        new Date(a.createdAt)?.toLocaleDateString() +
                        "  " +
                        new Date(a.createdAt)?.toLocaleTimeString()}
                    </Typography>
                  </Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "start",
                    alignItems: "start",
                    gap: 2,
                    fontFamily: "Montserrat",
                    width: { xs: "100%", md: "70%" },
                  }}
                >
                  <Rating
                    name="read-only"
                    size="small"
                    value={a.ratingNumber}
                    precision={0.5}
                    readOnly
                  />
                  <Typography variant="body2" sx={{ fontFamily: "Montserrat" }}>
                    {a.message}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Box>
        )}
      </Drawer>
    </div>
  );
}

const renderTextField = (label: string, val: string) => {
  return (
    <Box
      sx={{
        p: 0,
        width: "100%",
        display: "flex",
        justifyContent: "start",
        alignItems: "start",
        flexDirection: "column",
        gap: 1.5,
      }}
    >
      <Typography
        variant="body1"
        sx={{ fontSize: "0.955rem", fontWeight: 600, color: "black" }}
      >
        {label}
      </Typography>
      <TextField
        size="small"
        fullWidth
        label={label}
        variant="outlined"
        defaultValue={val}
        InputProps={{
          inputProps: {
            readOnly: true,
          },
        }}
      />
    </Box>
  );
};
