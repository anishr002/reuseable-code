import Swal from "sweetalert2";
import Paper from "@mui/material/Paper";
import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import { Link, useParams } from "react-router-dom";
import dayjs from "dayjs";
import { toast } from "react-toastify";
import { Refund_Req_data } from "./RefundRequestPage";
import React from "react";

export default function RefundRequestDetails() {
  const { refund_id } = useParams();
  const [data, setData] = React.useState<Refund_Req_data | null>(null);
  const [loading, setLoading] = React.useState(true); // Add loading state

  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const fetchRefundRequestDetails = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/refunds/refund-request-details/${refund_id}`
      );
      console.log({ response });
      if (response.status === 200) {
        const { data } = response.data;
        setData(data);
      }
    } catch (error) {
      console.error("Error fetching balance and transactions:", error);
    } finally {
      setLoading(false);
    }
  };
  React.useEffect(() => {
    fetchRefundRequestDetails();
  }, [pageUpdated]);

  const cancelRefundFunction = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you really want to deny this refund request?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, deny it!",
      cancelButtonText: "No, keep it",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setLoading(true);
        try {
          const response = await httpAPI_admin.put(
            `${backendURL}/admin/txn-history/refunds/actions/cancel-request/${refund_id}`
          );
          console.log(response);
          if (response.status === 200) {
            setPageUpdated(!pageUpdated);
            toast.success("Refund Request has been denied successfully");
          }
        } catch (error) {
          console.error(error);
        } finally {
          setLoading(false);
        }
      }
    });
  };

  const approveFunction = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you really want to approve this refund request?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, approve it!",
      cancelButtonText: "No, keep it",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setLoading(true);
        try {
          const response = await httpAPI_admin.put(
            `${backendURL}/admin/txn-history/refunds/actions/approve-request/${refund_id}`
          );
          console.log(response);
          if (response.status === 200) {
            setPageUpdated(!pageUpdated);
            toast.success("Refund Request Approved successfully");
          }
        } catch (error) {
          console.error(error);
        } finally {
          setLoading(false);
        }
      }
    });
  };

  const handleApprove = () => {
    approveFunction();
  };

  //handle coach account delete
  const handleRejectRequest = () => {
    cancelRefundFunction();
  };

  interface Label {
    [key: number]: string;
  }
  const statusColors: Label = {
    0: "#ebbe34", // Pending
    1: "#3aa7a3", // Approved
    2: "red", // Declined
  };

  const statusLabels: Label = {
    0: "Pending",
    1: "Approved",
    2: "Declined",
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: "calc(100vh - 88px)",
          background: "transparent",
          padding: "1rem",
        }}
      >
        <Typography
          variant="h6"
          sx={{
            fontWeight: "bold",
            marginBottom: "1.5rem",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            color: "#013338",
          }}
        >
          Refund Requests
        </Typography>

        {data ? (
          <>
            <Card
              sx={{
                boxShadow: 3,
                borderRadius: 2,
                overflow: "hidden",
                marginBottom: "1.5rem",
                padding: "1.5rem",
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "600",
                  marginBottom: "1rem",
                  color: "#3aa7a3",
                }}
              >
                Refund Information
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Session Date:
                  </Typography>
                  <Typography variant="body1">
                    {dayjs(data.sessionDateUpdated).format(
                      "MM-DD-YYYY hh:mm A"
                    )}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Amount:
                  </Typography>
                  <Typography variant="body1">
                    ${(Number(data.amount) / 100).toFixed(2)}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="#013338">
                    Cancel Remark:
                  </Typography>
                  <Typography variant="body1">
                    {data.session_cancel_remark}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Cancel Requested By:
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{ textTransform: "uppercase", fontWeight: 500 }}
                  >
                    {data.cancel_requested_by}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Requested At:
                  </Typography>
                  <Typography variant="body1">
                    {dayjs(data.createdAt).format("MM/DD/YYYY hh:mm A")}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Refund Status:
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{
                      color: "white",
                      backgroundColor: statusColors[data.refund_status],
                      padding: "4px 12px",
                      borderRadius: "12px",
                      display: "inline-block",
                      textTransform: "uppercase",
                      fontWeight: 500,
                    }}
                  >
                    {statusLabels[data.refund_status]}
                  </Typography>
                </Grid>
                {data.refund_status === 1 && (
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2" color="#013338">
                      Approval Date:
                    </Typography>
                    <Typography variant="body1">
                      {new Date(
                        Number(data.refund_created) * 1000
                      ).toLocaleString()}
                    </Typography>
                  </Grid>
                )}
                {data.refund_status === 0 && (
                  <Grid item xs={12}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-start",
                        marginTop: "1rem",
                        gap: 2,
                      }}
                    >
                      <Button
                        onClick={handleRejectRequest}
                        variant="outlined"
                        color="error"
                        sx={{
                          textTransform: "capitalize",
                          fontWeight: 500,
                          borderRadius: 2,
                          padding: "8px 16px",
                          "&:hover": { backgroundColor: "#ffe5e5" },
                        }}
                      >
                        Cancel Request
                      </Button>
                      <Button
                        onClick={handleApprove}
                        variant="contained"
                        sx={{
                          textTransform: "capitalize",
                          fontWeight: 500,
                          borderRadius: 2,
                          padding: "8px 16px",
                          backgroundColor: "#ebbe34",
                          color: "white",
                          "&:hover": { backgroundColor: "#d8a730" },
                        }}
                      >
                        Approve Request
                      </Button>
                    </Box>
                  </Grid>
                )}
              </Grid>
            </Card>

            <Card
              sx={{
                boxShadow: 3,
                borderRadius: 2,
                overflow: "hidden",
                marginBottom: "1.5rem",
                padding: "1.5rem",
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "600",
                  marginBottom: "1rem",
                  color: "#3aa7a3",
                }}
              >
                User & Coach Information
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <Link
                    to={`/coachee/detail/${data.userData._id}`}
                    style={{ textDecoration: "none" }}
                  >
                    <Card
                      sx={{
                        boxShadow: 3,
                        borderRadius: 2,
                        overflow: "hidden",
                        padding: "1.5rem",
                        textAlign: "left",
                      }}
                    >
                      <CardContent>
                        <Avatar
                          src={`${backendURL}/usersProfile/${data.userData.image}`}
                          alt={data.userData.name}
                          sx={{ width: 80, height: 80, marginBottom: "1rem" }}
                        />
                        <Typography variant="body1" sx={{ fontWeight: 600 }}>
                          {data.userData.name}
                        </Typography>
                        <Typography variant="body2" color="#013338">
                          {data.userData.email}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Link>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Link
                    to={`/coach/detail/${data.coachData._id}`}
                    style={{ textDecoration: "none" }}
                  >
                    <Card
                      sx={{
                        boxShadow: 3,
                        borderRadius: 2,
                        overflow: "hidden",
                        padding: "1.5rem",
                        textAlign: "left",
                      }}
                    >
                      <CardContent>
                        <Avatar
                          src={`${backendURL}/usersProfile/${data.coachData.image}`}
                          alt={data.coachData.name}
                          sx={{ width: 80, height: 80, marginBottom: "1rem" }}
                        />
                        <Typography variant="body1" sx={{ fontWeight: 600 }}>
                          {data.coachData.name} {data.coachData.Lname}
                        </Typography>
                        <Typography variant="body2" color="#013338">
                          {data.coachData.email}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Link>
                </Grid>
              </Grid>
            </Card>

            <Card
              sx={{
                boxShadow: 3,
                borderRadius: 2,
                overflow: "hidden",
                padding: "1.5rem",
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: "600",
                  marginBottom: "1rem",
                  color: "#3aa7a3",
                }}
              >
                Session Information
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Session Title:
                  </Typography>
                  <Typography variant="body1">
                    {data.sessionData.title}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="#013338">
                    Session Price:
                  </Typography>
                  <Typography variant="body1">
                    ${data.sessionData.price}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="#013338">
                    Session Description:
                  </Typography>
                  <Typography variant="body1">
                    {data.sessionData.description}
                  </Typography>
                </Grid>
              </Grid>
            </Card>
          </>
        ) : (
          <NoDataIllustration message="Request not found, Request was either moved or deleted! " />
        )}
      </Paper>
    </>
  );
}
