import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";

import DeleteIcon from "@mui/icons-material/Delete";
import TableRow from "@mui/material/TableRow";
import { Box, Pagination, TableCell, Typography } from "@mui/material";
import { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";

import Swal from "sweetalert2";

import NoDataIllustration from "../components/NoDataIllustration";
import moment from "moment-timezone";

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});

interface Row {
  _id: string;
  fullName: string;
  email: string;
  message: string;
  subject: string;
  createdAt: string;
}

export default function Enquiries() {
  const [rows, setData] = React.useState<Row[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const fetchData = async () => {
    try {
      const response = await httpAPI_admin.get(
        `/admin/contact/list-all-subs?pageNo=${pageNo}}`
      );
      if (response.status === 200) {
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        return setData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo, pageUpdated]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  const handleDelteClick = (id: string) => {
    setLoading(true);
    const text = "delete";
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to ${text} it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, ${text} It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          try {
            setLoading(true);
            const response = await httpAPI_admin.put(
              `/admin/contact/remove-enquiry/${id.trim()}`
            );
            console.log(response);
            if (response.status === 200) {
              setPageUpdated(!pageUpdated);
              swalWithBootstrapButtons.fire({
                title: `Deleted!`,
                text: `Enrty deleted successfully`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            setPageUpdated(!pageUpdated);
          }
        } else {
          setLoading(false);
        }
      });
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexDirection: { xs: "column", md: "row" },
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Enquiries{" "}
            <span style={{ fontSize: "0.95rem" }}>
              (Contact Us form submissions)
            </span>
          </Typography>
        </Box>
        {rows?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 240px)",
                overflow: "auto",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Full Name
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Email
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Subject
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Message
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Dated
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Delete
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell
                          sx={{
                            whiteSpace: "nowrap",
                            color: "#013338",
                            fontWeight: 500,
                          }}
                        >
                          {capitalizeFirstLetter(row?.fullName)}
                        </TableCell>
                        <TableCell
                          sx={{
                            width: "200px",
                            maxWidth: "250px",
                            wordBreak: "break-all",
                          }}
                        >
                          <a
                            style={{
                              cursor: "pointer",
                              textDecoration: "none",
                            }}
                            href={`mailto:${row?.email}`}
                          >
                            {row?.email}
                          </a>
                        </TableCell>
                        <TableCell>{row?.subject}</TableCell>
                        <TableCell>{row?.message}</TableCell>
                        <TableCell>
                          {moment(row?.createdAt).format("MM/DD/YYYY HH:mm A")}
                        </TableCell>
                        <TableCell>
                          <DeleteIcon
                            color="error"
                            style={{ cursor: "pointer" }}
                            onClick={() => handleDelteClick(row._id)}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo.totalPages)}
                  page={Number(pageInfo.currentPage)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration />
        )}
      </Paper>
    </>
  );
}
