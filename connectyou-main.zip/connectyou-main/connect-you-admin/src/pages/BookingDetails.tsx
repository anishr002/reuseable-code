import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import {
  Avatar,
  Box,
  Button,
  Chip,
  createTheme,
  Paper,
  Rating,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useMediaQuery,
} from "@mui/material";
// import PaymentIcon from "@mui/icons-material/Payment";
// import BusinessIcon from "@mui/icons-material/Business";
import { Link, NavLink, useParams } from "react-router-dom";
import apiBaseUrl from "../URLconf";
import React from "react";
import { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import moment from "moment-timezone";
import { ThemeProvider } from "@emotion/react";

interface OrderDetails {
  _id: string;
  createdAt: string;
  orderStatus: number;
  receipt: string;
}
interface SessionData {
  _id: string;
  coachId: string;
  title: string;
  price: string;
  type: string;
  description: string;
}
interface userData {
  _id: string;
  name: string;
  Lname: string;
  image: string;
  gender: string;
}
interface CoachData {
  _id: string;
  name: string;
  Lname: string;
  image: string;
  gender: string;
  title_line: string;
  zoomMeetingURL: string;
  timeZone: string;
}

interface CustomerData {
  customer_city: string;
  customer_country: string;
  customer_email: string;
  customer_line1: string;
  customer_line2: string;
  customer_name: string;
  customer_phone: string;
  customer_postal_code: string;
  customer_state: string;
}
interface CardDetails {
  chargeId: string;
  cardBrand: string;
  cardCountry: string;
  card_exp_month: string;
  card_exp_year: string;
  card_last4: string;
  currency: string;
  amount: number;
}

interface Session {
  _id: string;
  sessionDate: string;
  sessionDateUpdated: string;
  sessionStatus: number;
  sessionAmount: number;
  sessionCancelBy: string;
  messageCancel: string;
  sessionCompletedUser: number;
  sessionCompletedCoach: number;
  completedCoachMSG: string;
  completedUserMSG: string;
  sessionData: SessionData;
}

interface BookedSessionsProps {
  coachData: CoachData;
  sessions: Session[];
  sessionCompleted: boolean;
}
interface RatingData {
  _id: string;
  ratingNumber: number;
  message: string;
  coachId: string;
}

const BookingDetails = () => {
  const backendURL = apiBaseUrl;
  const { bookingId } = useParams<{ bookingId?: string }>();
  const [loading, setLoading] = React.useState<boolean>(true); //faching data

  const [orderData, setOrderData] = React.useState<OrderDetails>();
  const [userData, setUserData] = React.useState<userData>();
  const [customerData, setCustomerData] = React.useState<CustomerData>();
  const [cardDetails, setCardDetails] = React.useState<CardDetails>();
  const [ratingData, setRatingData] = React.useState<RatingData[]>([]);
  const [bookedSessionList, setBookedSessionList] = React.useState<
    BookedSessionsProps[]
  >([]);
  const isMobile = useMediaQuery("(min-width:600px)");

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `admin/booking/booking-history-details/${bookingId}`
      );
      if (response.data.data) {
        setOrderData(response.data.data);
        setUserData(response.data.data.userData);
        setCustomerData(response.data.data.customer);
        setCardDetails(response.data.data.cardDetails);
        setRatingData(response.data.data.ratingsData);
        setBookedSessionList(response.data.data.booked_sessionsData);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  //use Effects
  React.useEffect(() => {
    fetchData();
  }, []);
  const theme = createTheme({
    typography: {
      fontFamily: "montserrat",
    },
  });
  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `calc(100vh - 88px)`,
          maxHeight: "calc(100vh - 88px)",
          background: "transparent",
          pb: 4,
        }}
        elevation={0}
      >
        <ThemeProvider theme={theme}>
          <Box display="flex" flexDirection="column" gap={5} overflow="auto">
            {/* coachee details  */}
            <Box
              sx={{
                display: "flex",
                flexDirection: { xs: "column", lg: "row" },
                gap: "1.5rem", // 6 * 0.25rem (6 in Tailwind is 1.5rem)
                alignItems: "center",
                width: "100%",
                padding: "1rem", // 4 * 0.25rem (4 in Tailwind is 1rem)
                backgroundColor: "white", // bg-white
                boxShadow: 1, // shadow-md equivalent in MUI
                borderRadius: "8px", // rounded-lg maps to 8px
              }}
            >
              {/* Avatar and Coach Name */}
              <Avatar
                src={`${backendURL}/usersProfile/${userData?.image}`}
                sx={{ width: "10rem", height: "10rem" }}
              />
              <Box
                sx={{
                  padding: "1rem",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <TableContainer>
                  <Table>
                    <TableHead>
                      {isMobile && (
                        <TableRow>
                          <TableCell
                            sx={{
                              px: 2,
                              py: 1,
                              fontSize: "0.875rem",
                              fontWeight: "600",
                              color: "gray",
                            }}
                          >
                            Coachee
                          </TableCell>
                          <TableCell
                            sx={{
                              px: 2,
                              py: 1,
                              fontSize: "0.875rem",
                              fontWeight: "600",
                              color: "gray",
                            }}
                          >
                            Gendar
                          </TableCell>
                        </TableRow>
                      )}
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        {!isMobile && <TableCell>Coachee</TableCell>}
                        <TableCell sx={{ px: 2, py: 1 }}>
                          <NavLink
                            to={`/coachee/detail/${userData?._id}`}
                            style={{ textDecoration: "none" }}
                          >
                            <Typography
                              variant="h6"
                              fontWeight="600"
                              color="primary"
                            >
                              {userData?.name}
                            </Typography>
                          </NavLink>
                        </TableCell>
                        {isMobile && (
                          <TableCell
                            sx={{
                              px: 2,
                              py: 1,
                              fontSize: "0.875rem",
                              color: "gray.800",
                            }}
                          >
                            {userData?.gender}
                          </TableCell>
                        )}
                      </TableRow>
                      {!isMobile && (
                        <>
                          <TableRow>
                            <TableCell>Gender</TableCell>
                            <TableCell> {userData?.gender}</TableCell>
                          </TableRow>
                        </>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            </Box>

            {/* billing details */}
            <Box
              display="grid"
              gridTemplateColumns={{
                xs: "repeat(1, 1fr)",
                lg: "repeat(3, 1fr)",
              }}
              gap={2}
              width="100%"
            >
              {/* Payment Customer Details */}
              <Box
                display="flex"
                flexDirection="column"
                gap={3}
                borderRadius={2}
                boxShadow={3}
                p={4}
                flex={1}
                bgcolor="white"
              >
                {/* Title */}
                <Box display="flex" alignItems="center">
                  <Typography
                    variant="h6"
                    fontWeight="600"
                    color="text.primary"
                  >
                    Payment Customer Details
                  </Typography>
                </Box>

                {/* Customer Details */}
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={1}
                  fontWeight="500"
                >
                  {[
                    { label: "Name", value: customerData?.customer_name },
                    { label: "Email", value: customerData?.customer_email },
                    { label: "Phone No", value: customerData?.customer_phone },
                  ].map((item, index) => (
                    <Box key={index} display="flex">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        minWidth={96}
                      >
                        <Typography>{item.label}</Typography>
                        <Typography>:</Typography>
                      </Box>
                      <Box pl={2} color="text.secondary">
                        <Typography>{item.value || "-"}</Typography>
                      </Box>
                    </Box>
                  ))}
                  {orderData?.receipt && (
                    <Box display="flex">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        minWidth={96}
                      >
                        <Typography>Receipt</Typography>
                        <Typography>:</Typography>
                      </Box>
                      <Box pl={2} color="text.secondary">
                        <a
                          href={`${backendURL}/receipt/${orderData?.receipt}`}
                          target="_blank"
                          download
                          style={{
                            color: "blue",
                            fontFamily: "montserrat",
                            fontSize: "0.851rem",
                            textDecoration: "none",
                          }}
                        >
                          Download Receipt
                        </a>
                      </Box>
                    </Box>
                  )}
                </Box>
              </Box>
              {/* Billing Address */}
              <Box
                display="flex"
                flexDirection="column"
                gap={3}
                borderRadius={2}
                boxShadow={3}
                p={4}
                flex={1}
                bgcolor="white"
              >
                {/* Title */}
                <Box display="flex" alignItems="center">
                  <Typography
                    variant="h6"
                    fontWeight="600"
                    color="text.primary"
                  >
                    Billing Address
                  </Typography>
                </Box>

                {/* Address Details */}
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={1}
                  fontWeight="500"
                >
                  {[
                    { label: "City", value: customerData?.customer_city },
                    { label: "State", value: customerData?.customer_state },
                    { label: "Country", value: customerData?.customer_country },
                    {
                      label: "Pin Code",
                      value: customerData?.customer_postal_code,
                    },
                  ].map((item, index) => (
                    <Box key={index} display="flex">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        minWidth={96}
                      >
                        <Typography>{item.label}</Typography>
                        <Typography>:</Typography>
                      </Box>
                      <Box pl={2} color="text.secondary">
                        <Typography>{item.value || "-"}</Typography>
                      </Box>
                    </Box>
                  ))}
                </Box>
              </Box>
              {/* Payment Details */}
              <Box
                display="flex"
                flexDirection="column"
                gap={3}
                borderRadius={2}
                boxShadow={3}
                p={4}
                flex={1}
                bgcolor="white"
              >
                {/* Title */}
                <Box display="flex" alignItems="center">
                  <Typography
                    variant="h6"
                    fontWeight="600"
                    color="text.primary"
                  >
                    Payment Details
                  </Typography>
                </Box>

                {/* Address Details */}
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={1}
                  fontWeight="500"
                >
                  {[
                    { label: "Brand", value: cardDetails?.cardBrand },
                    {
                      label: "Currency",
                      value: orderData?.receipt ? cardDetails?.currency : "",
                    },
                    { label: "Country", value: cardDetails?.cardCountry },
                  ].map((item, index) => (
                    <Box key={index} display="flex">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        minWidth={96}
                      >
                        <Typography>{item.label}</Typography>
                        <Typography>:</Typography>
                      </Box>
                      <Box pl={2} color="text.secondary">
                        <Typography>{item.value || "-"}</Typography>
                      </Box>
                    </Box>
                  ))}
                </Box>
              </Box>
            </Box>

            {/* sessin list with coach details */}
            <Box
              display="flex"
              flexDirection="column"
              alignItems="center"
              gap={4}
              mx="auto"
              width="100%"
            >
              {bookedSessionList.map((b, index) => (
                <Box
                  key={index}
                  sx={{
                    display: "flex",
                    width: "100%",
                    flexDirection: "column",
                    border: "2px solid #013338",
                    padding: "1.25rem",
                    borderRadius: "4px",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: { xs: "column", lg: "row" },
                      gap: "1.5rem", // 6 * 0.25rem (6 in Tailwind is 1.5rem)
                      alignItems: "center",
                      width: "100%",
                      padding: "1rem", // 4 * 0.25rem (4 in Tailwind is 1rem)
                      backgroundColor: "white", // bg-white
                      boxShadow: 1, // shadow-md equivalent in MUI
                      borderRadius: "8px", // rounded-lg maps to 8px
                    }}
                  >
                    {/* Avatar and Coach Name */}
                    <Avatar
                      src={`${backendURL}/usersProfile/${b.coachData.image}`}
                      sx={{ width: "10rem", height: "10rem" }}
                    />
                    <Box
                      sx={{
                        padding: "1rem",
                        display: "flex",
                        flexDirection: "column",
                      }}
                    >
                      <TableContainer>
                        <Table>
                          <TableHead>
                            {isMobile && (
                              <TableRow>
                                <TableCell
                                  sx={{
                                    px: 2,
                                    py: 1,
                                    fontSize: "0.875rem",
                                    fontWeight: "600",
                                    color: "gray",
                                  }}
                                >
                                  Coach
                                </TableCell>
                                <TableCell
                                  sx={{
                                    px: 2,
                                    py: 1,
                                    fontSize: "0.875rem",
                                    fontWeight: "600",
                                    color: "gray",
                                  }}
                                >
                                  Meeting Link
                                </TableCell>
                              </TableRow>
                            )}
                          </TableHead>
                          <TableBody>
                            {isMobile ? (
                              <TableRow>
                                <TableCell sx={{ px: 2, py: 1 }}>
                                  <NavLink
                                    to={`/coach/detail/${b.coachData._id}`}
                                    style={{ textDecoration: "none" }}
                                  >
                                    <Typography
                                      variant="h6"
                                      fontWeight="600"
                                      color="primary"
                                    >
                                      {b.coachData.name} {b.coachData.Lname}
                                    </Typography>
                                  </NavLink>
                                </TableCell>
                                <TableCell
                                  sx={{
                                    px: 2,
                                    py: 1,
                                    fontSize: "0.875rem",
                                    color: "gray.800",
                                  }}
                                >
                                  <Link
                                    to={b.coachData.zoomMeetingURL}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    style={{
                                      color: "blue",
                                      fontFamily: "montserrat",
                                      fontSize: "0.851rem",
                                      textDecoration: "none",
                                    }}
                                  >
                                    {b.coachData.zoomMeetingURL}
                                  </Link>
                                </TableCell>
                              </TableRow>
                            ) : (
                              <>
                                <TableRow>
                                  <TableCell sx={{ px: 2, py: 1 }}>
                                    Coach :{" "}
                                    <NavLink
                                      to={`/coach/detail/${b.coachData._id}`}
                                      style={{ textDecoration: "none" }}
                                    >
                                      <Typography
                                        variant="h6"
                                        fontWeight="600"
                                        color="primary"
                                      >
                                        {b.coachData.name} {b.coachData.Lname}
                                      </Typography>
                                    </NavLink>
                                  </TableCell>
                                </TableRow>
                                <TableRow>
                                  <TableCell
                                    sx={{
                                      px: 2,
                                      py: 1,
                                      fontSize: "0.875rem",
                                      color: "gray.800",
                                    }}
                                  >
                                    Meeting Link :
                                    <Link
                                      to={b.coachData.zoomMeetingURL}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      style={{ wordBreak: "break-all" }}
                                    // sx={{
                                    //   color: "#3aa7a3",
                                    //   textDecoration: "none",
                                    //   "&:hover": {
                                    //     color: "#48a1b7",
                                    //     transition: "all 0.2s",
                                    //   },
                                    // }}
                                    >
                                      {b.coachData.zoomMeetingURL}
                                    </Link>
                                  </TableCell>
                                </TableRow>
                              </>
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>

                      {b.sessionCompleted &&
                        ratingData.length > 0 &&
                        ratingData.map((r, k) => {
                          if (r.coachId == b.coachData._id) {
                            return (
                              <Box
                                key={k}
                                display="flex"
                                flexDirection="column"
                                gap={1}
                                p={2}
                                flex={1}
                                borderRadius={1}
                              >
                                <Rating
                                  name="read-only"
                                  value={r.ratingNumber}
                                  readOnly
                                  precision={0.5}
                                  size="small"
                                />
                                <Typography
                                  variant="body2"
                                  color="textSecondary"
                                >
                                  {r.message}
                                </Typography>
                              </Box>
                            );
                          } else return null;
                        })}
                    </Box>
                  </Box>
                  <Box
                    display="flex"
                    flexDirection="column"
                    justifyContent="center"
                    alignItems="center"
                    width="100%"
                    gap={5}
                    mx="auto"
                    pt={5}
                  >
                    {b.sessions.map((s, j) => {
                      return (
                        <Box
                          key={j}
                          className="session-card custom-shadow" // Use your custom classes if necessary
                          display="flex"
                          width="100%"
                          position="relative"
                          p={{ xs: 4, md: 2 }}
                          px={4}
                          bgcolor="white"
                        >
                          <Box display="flex" flexDirection="column" gap={2}>
                            <Box
                              display="flex"
                              alignItems="center"
                              justifyContent={{
                                xs: "space-between",
                                md: "flex-start",
                              }}
                              width="100%"
                              gap={5}
                            >
                              <Typography variant="body2" fontWeight="bold">
                                {moment(s.sessionDateUpdated)
                                  .local()
                                  .format("DD-MM-YYYY hh:mm A")}
                                -
                                {moment(s.sessionDateUpdated)
                                  .local()
                                  .add(1, "hours")
                                  .format("hh:mm A")}
                              </Typography>
                            </Box>

                            {/* Status Messages */}

                            {s.sessionStatus === 2 && (
                              <Box>
                                <Chip
                                  icon={<CancelIcon color="inherit" />}
                                  label="Meeting Cancelled"
                                  sx={{
                                    backgroundColor: "red",
                                    color: "white",
                                  }}
                                />
                              </Box>
                            )}
                            {s.sessionStatus === 1 && (
                              <Box>
                                <Chip
                                  icon={<CheckCircleIcon color="inherit" />}
                                  label="Meeting Completed"
                                  sx={{
                                    backgroundColor: "#3aa7a3",
                                    color: "white",
                                  }}
                                />
                              </Box>
                            )}
                            {s.sessionStatus === 0 && (
                              <Box>
                                <Chip
                                  icon={
                                    <AccessTimeFilledIcon color="inherit" />
                                  }
                                  label="Status Pending"
                                  sx={{
                                    backgroundColor: "#ebbe34",
                                    color: "white",
                                  }}
                                />
                              </Box>
                            )}

                            {/* Session Details */}
                            <Typography variant="h5" fontWeight="600">
                              {s.sessionData.title}
                            </Typography>
                            <Typography variant="h6" fontWeight="600">
                              ${s.sessionData.price}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {s.sessionData.description}
                            </Typography>
                            <Box>
                              <NavLink
                                to={`session/detail/${s._id}`}
                                style={{ textDecoration: "none" }}
                              >
                                <Button
                                  variant="contained"
                                  sx={{
                                    backgroundColor: "#013338",
                                    color: "white",
                                    "&:hover": {
                                      backgroundColor: "#013338", // Ensures the color remains the same on hover
                                    },
                                  }}
                                >
                                  View Details
                                </Button>
                              </NavLink>
                            </Box>
                          </Box>
                        </Box>
                      );
                    })}
                  </Box>
                </Box>
              ))}
            </Box>
          </Box>
        </ThemeProvider>
      </Paper>
    </>
  );
};

export default BookingDetails;
