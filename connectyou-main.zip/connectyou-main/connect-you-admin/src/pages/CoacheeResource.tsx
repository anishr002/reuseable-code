import { useEffect } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";

// Define the editor modules and formats for better type safety

import CloseIcon from "@mui/icons-material/Close";
import { Box, Button, Modal, Paper, Typography } from "@mui/material";
import { useState } from "react";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import { Controller, useForm } from "react-hook-form";
import ResourceRender from "../components/ResourceRender";
import Swal from "sweetalert2";
const primaryButton = {
  p: 0,
  color: "white",
  backgroundColor: "#EBBE34",
  borderColor: "#EBBE34",
  borderRadius: "20px",
  fontFamily: "Montserrat",
  mx: "auto",
  "&:hover": {
    borderColor: "white",
    backgroundColor: "white",
    color: "#EBBE34",
  },
};

interface Data {
  _id: string;
  title: string;
  description: string;
}
const CoacheeResource = () => {
  const [selectedData, setSelectedData] = useState<Data>({
    _id: "",
    title: "",
    description: "",
  });
  const [refresh, setRefresh] = useState<boolean>(false);
  const toggleRefresh = () => {
    setRefresh(!refresh);
  };
  const [openAddNewModal, setOpenAddNewModal] = useState<boolean>(false);
  const toggleOpenAddNew = (b: boolean) => {
    setOpenAddNewModal(b);
  };

  const [loading, setLoading] = useState<boolean>(false);
  const [data, setData] = useState<Data[]>([]);
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.get(
        `${backendURL}/admin/user/user-resource/list`
      );
      if (res.status === 200) {
        setSelectedData({
          _id: "",
          title: "",
          description: "",
        });
        setData(res.data.data);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [refresh]);

  // modal opener for update existing
  const [openUpdateResModal, setOpenUpdateResModal] = useState<boolean>(false);
  const toggleOpenUpdateRes = (b: boolean) => {
    setOpenUpdateResModal(b);
  };
  const [updateresourceId, setUpdateRes] = useState<string | null>(null);
  // Render the saved content in HTML format
  const handleEdit = ({
    resourceId,
    title,
    description,
  }: {
    resourceId: string;
    title: string;
    description: string;
  }) => {
    console.log("Edit clicked", resourceId);
    setUpdateRes(resourceId);
    toggleOpenUpdateRes(true);
    setSelectedData({
      _id: resourceId,
      title,
      description,
    });
  };

  const handleDelete = ({ resourceId }: { resourceId: string }) => {
    console.log("Delete clicked", resourceId);
    setUpdateRes(resourceId);
    Swal.fire({
      title: "Are you sure?",
      text: "You want to remove this section?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, remove it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/user/user-resource/remove-resource/${resourceId}`
        );
        console.log(response);
        if (response.status === 200) {
          Swal.fire({
            title: "Removed!",
            text: "The section has been removed.",
            icon: "success",
            timer: 1500,
          });
          toggleRefresh();
        } else {
          toast.error(
            "There was some error while removing the section, Please try again"
          );
        }
      }
    });
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: "calc(100vh - 88px)",
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height: "3rem",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Coachee Resource
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Button
              sx={{ ...primaryButton, px: 3 }}
              onClick={() => toggleOpenAddNew(true)}
            >
              Add New
            </Button>
          </Box>
        </Box>

        <Box
          sx={{ height: "calc(100% - 3rem)", overflow: "auto", padding: 2 }}
          className="style-scroll"
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
              height: "auto",

              width: "100%",
            }}
          >
            {data.length > 0 ? (
              data.map((a, i) => (
                <ResourceRender
                  key={i}
                  _id={a._id}
                  title={a.title}
                  description={a.description}
                  onEdit={() => {
                    handleEdit({
                      resourceId: a._id,
                      description: a.description,
                      title: a.title,
                    });
                  }}
                  onDelete={() => {
                    handleDelete({ resourceId: a._id });
                  }}
                  buttonShow={true}
                />
              ))
            ) : (
              <Box
                sx={{
                  width: "100%",
                  height: "10rem",
                  textAlign: "center",
                  color: "red",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  fontFamily: "montserrat",
                }}
              >
                You have not added any Coachee Resource
              </Box>
            )}
          </Box>
        </Box>
      </Paper>
      <AddNewModal
        open={openAddNewModal}
        toggle={toggleOpenAddNew}
        toggleRefresh={toggleRefresh}
        title={selectedData.title}
        description={selectedData.description}
      />
      {updateresourceId && (
        <UpdateResourceModal
          open={openUpdateResModal}
          toggle={toggleOpenUpdateRes}
          toggleRefresh={toggleRefresh}
          title={selectedData.title}
          resourceId={updateresourceId}
          description={selectedData.description}
        />
      )}
    </>
  );
};

export default CoacheeResource;

const modules = {
  toolbar: [
    [
      { header: "1" },
      { header: "2" },
      { header: "3" },
      { font: ["Montserrat"] },
      { size: ["small", false, "large", "huge"] },
    ],
    [{ list: "ordered" }, { list: "bullet" }],
    ["bold", "italic", "underline", "strike"],
    ["link"],
    [{ align: [] }],
    [{ direction: "rtl" }],
    [{ indent: "-1" }, { indent: "+1" }],
    [{ color: [] }, { background: [] }],
    ["clean"],
  ],
};

const formats = [
  "header",
  "font",
  "size",
  "list",
  "bullet",
  "ordered",
  "check",
  "bold",
  "italic",
  "underline",
  "link",
  "strike",
  "align",
  "direction",
  "indent",
  "color",
  "background",
  "clean",
];

const AddNewModal = ({
  open,
  toggle,
  toggleRefresh,
  title,
  description,
}: {
  open: boolean;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
  title: string;
  description: string;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    defaultValues: {
      title: "",
      description: "",
    },
    mode: "onChange",
  });
  useEffect(() => {
    setValue("title", title);
    setValue("description", description);
  }, [title, description, setValue]);
  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: { title: string; description: string }) => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/user/user-resource/add`,
        data
      );
      if (res.status === 200) {
        toggleRefresh();
        toggle(false); // Close the modal after submission
        reset();
        return toast.success("New user resource added");
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: 300, sm: 450, md: "80%" },
          maxHeight: { xs: 450, md: "80%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Title and Description
        </Typography>

        {!loading ? (
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              {/* title Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.title ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Title {errors.title && "is required"}
                </Typography>
                <Controller
                  name="title"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>
              {/* Description Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Description {errors.description && "is required"}
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 2, textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3 }}
                type="submit"
              >
                Submit
              </Button>
            </Box>
          </form>
        ) : (
          <>
            <Paper
              elevation={0}
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "10rem",
                background: "transparent",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Paper>
          </>
        )}
      </Box>
    </Modal>
  );
};

const UpdateResourceModal = ({
  open,
  toggle,
  toggleRefresh,
  resourceId,
  title,
  description,
}: {
  open: boolean;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
  resourceId: string;
  title: string;
  description: string;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    defaultValues: {
      title: "",
      description: "",
    },
    mode: "onChange",
  });
  useEffect(() => {
    console.log(title, description);
    setValue("title", title);
    setValue("description", description);
  }, [title, description, setValue]);

  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: { title: string; description: string }) => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/user/user-resource/update-resource/${resourceId}`,
        data
      );
      if (res.status === 200) {
        toggleRefresh();
        toggle(false);
        reset();
        return toast.success("Coachee resource updated");
      }
    } catch (error) {
      console.log(error);
      toast.error("Some error while updating resource");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: 300, sm: 450, md: "80%" },
          maxHeight: { xs: 450, md: "80%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Update Title and Description
        </Typography>

        {!loading ? (
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              {/* title Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.title ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Title {errors.title && "is required"}
                </Typography>
                <Controller
                  name="title"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>
              {/* Description Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Description {errors.description && "is required"}
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 2, textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3 }}
                type="submit"
              >
                Update
              </Button>
            </Box>
          </form>
        ) : (
          <>
            <Paper
              elevation={0}
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "10rem",
                background: "transparent",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Paper>
          </>
        )}
      </Box>
    </Modal>
  );
};
