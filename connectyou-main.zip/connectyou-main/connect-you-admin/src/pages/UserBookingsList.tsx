import {
  Avatar,
  AvatarGroup,
  Box,
  createTheme,
  InputAdornment,
  Pagination,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import React from "react";
import { ThemeProvider } from "@emotion/react";
import { Link, useParams } from "react-router-dom";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { Visibility } from "@mui/icons-material";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import moment from "moment-timezone";

interface UserData {
  _id: string;
  name: string;
  image: string;
  timeZone: string;
  email: string;
}

interface CoachData {
  _id: string;
  name: string;
  Lname: string;
  userName: string;
  gender: string;
  email: string;
  image: string;
  timeZone: string;
}

interface HistoryType {
  _id: string;
  userId: string;
  orderStatus: number;
  createdAt: string;
  userData: UserData;
  totalBookedAmount: number;
  coachData: CoachData[];
  bookedSessionsCount: number;
  upcomingCount: number;
  completedCount: number;
  cancelledCount: number;
}

const CoachBookingsList = () => {
  const { userId } = useParams(); //userId id
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [bookingList, setBookingList] = React.useState<HistoryType[]>([]);
  const [userData, setuserData] = React.useState<UserData>();
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `admin/booking/booking-history/user/${userId}?pageNo=${pageNo}`
      );
      if (response.data.data) {
        setLoading(false);
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        setuserData(response.data.userData);
        return setBookingList(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      setLoading(false);
      return toast.error("Something went wrong");
    } finally {
      return setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo]);
  const [searchTerm, setSearchTerm] = React.useState("");

  const theme = createTheme({
    typography: {
      fontFamily: "montserrat",
    },
  });

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };
  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <>
      <Box
        sx={{
          height: "auto",
          width: "100%",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          pb: 15,
        }}
      >
        {/* coach profile avtar  */}
        <Box
          sx={{
            display: "flex",
            width: "100%",
            backgroundColor: "#013338",
            color: "white",
            position: "relative",
            height: { xs: "5rem", md: "8rem" },
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              paddingLeft: "1.25rem",
              gap: "1rem",
              position: "absolute",
              top: { xs: "1rem", md: "2.25rem" },
              height: "100%",
            }}
          >
            <Avatar
              alt={userData?.name}
              src={`${backendURL}/usersProfile/${userData?.image}`}
              sx={{
                width: { xs: "4rem", sm: "6rem", md: "8rem" },
                height: { xs: "4rem", sm: "6rem", md: "8rem" },
              }}
            />

            <Box className="profile-info" sx={{ paddingBottom: "1rem" }}>
              <Typography
                variant="h6"
                component="p"
                sx={{
                  fontSize: "1.2rem",
                  lineHeight: "2rem",
                  fontWeight: "600",
                }}
              >
                {userData?.name}
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: "500",
                }}
              >
                {userData?.email}
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* table content  */}
        <Paper
          sx={{
            marginTop: "50px",
            width: "100%",
            overflow: "auto",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              padding: "1rem 20px",
              width: "100%",
              display: "flex",
              justifyContent: "space-between",
              gap: "5px",
              alignItems: "center",
              color: "#013338",
            }}
          >
            <span>Bookings History</span>
            <Box sx={{ color: "#013338", display: "none" }}>
              <TextField
                id="outlined-search"
                placeholder="Search..."
                type="search"
                variant="outlined"
                fullWidth
                size="small"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                    backgroundColor: "#fff",
                    borderColor: "#013338",
                    "& fieldset": {
                      borderColor: "#013338",
                    },
                    "&:hover fieldset": {
                      borderColor: "#3aa7a3",
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "#3aa7a3", // Custom focus color
                    },
                  },
                  "& .MuiOutlinedInput-input": {
                    padding: "4px 6px",
                  },
                  "& .MuiInputLabel-root": {
                    top: "-4px",
                    color: "#666",
                  },
                }}
              />
            </Box>
          </Typography>
          {bookingList?.length > 0 ? (
            <ThemeProvider theme={theme}>
              <TableContainer
                component={Paper}
                sx={{
                  maxHeight: "calc(100vh - 400px)",
                  overflow: "auto",
                }}
              >
                <Table stickyHeader aria-label="sticky table">
                  <TableHead
                    sx={{
                      padding: "1px",
                      fontFamily: "montserrat",
                      "& .MuiTableCell-head": { lineHeight: "normal" },
                    }}
                  >
                    <TableRow
                      sx={{ textTransform: "uppercase", fontWeight: "500" }}
                    >
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Total Session
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Up Coming
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Completed
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Cancelled
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Price {"($)"}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Booking Date
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Coach
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Client
                      </TableCell>

                      <TableCell
                        sx={{
                          color: "white",
                          backgroundColor: "#013338",
                        }}
                      >
                        Details
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {bookingList.map((u, i) => (
                      <TableRow key={i} hover role="checkbox" tabIndex={-1}>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                          }}
                        >
                          {u.bookedSessionsCount}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                          }}
                        >
                          {u.upcomingCount}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                          }}
                        >
                          {u.completedCount}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                          }}
                        >
                          {u.cancelledCount}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                          }}
                        >
                          ${u.totalBookedAmount}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                          }}
                        >
                          {moment(u.createdAt).format("DD-MM-YYYY hh:mm A")}
                        </TableCell>
                        <TableCell>
                          <Box
                            sx={{
                              color: "#013338",
                              fontWeight: "600",
                              padding: 0,
                              display: "flex",
                              alignItems: "center",
                            }}
                          >
                            <AvatarGroup max={3}>
                              {u.coachData.map((c, j) => (
                                <Avatar
                                  key={j}
                                  alt={c.name}
                                  src={`${backendURL}/usersProfile/${c.image}`}
                                />
                              ))}
                            </AvatarGroup>
                          </Box>
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                          }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              gap: 2,
                              width: "100%",
                            }}
                          >
                            <Avatar
                              alt={u.userData.name}
                              src={`${backendURL}/usersProfile/${u.userData.image}`}
                            />
                            <Typography
                              variant="body2"
                              sx={{
                                whiteSpace: "nowrap",
                                textOverflow: "ellipsis",
                                overflow: "hidden",
                              }}
                            >
                              {u.userData.name}
                            </Typography>
                          </Box>
                        </TableCell>

                        <TableCell
                          sx={{
                            whiteSpace: "nowrap",
                          }}
                        >
                          <Link to={`/bookings/detail/${u._id}`}>
                            <Visibility color="primary" />
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                  {/* end of table body  */}
                </Table>
              </TableContainer>
              {pageInfo.totalPages > 1 && (
                <Box
                  sx={{
                    display: "flex",
                    justifyConten: "center",
                    alignItems: "center",
                    paddingY: 2,
                    borderTop: "2px solid #ccc",
                  }}
                >
                  <Pagination
                    count={Number(pageInfo.totalPages)}
                    page={Number(pageInfo.currentPage)}
                    onChange={handlePagination}
                  />
                </Box>
              )}
            </ThemeProvider>
          ) : (
            <NoDataIllustration height="200px" />
          )}
        </Paper>
      </Box>
    </>
  );
};

export default CoachBookingsList;
