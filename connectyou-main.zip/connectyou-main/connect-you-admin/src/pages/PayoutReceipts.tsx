import * as React from "react";
import Paper from "@mui/material/Paper";

import PaidIcon from "@mui/icons-material/Paid";
import { Avatar, Box, Typography, Grid } from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast, ToastContainer } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";

import { useParams } from "react-router-dom";

import DownloadReceiptsCoach from "../components/DownloadReceiptsCoach";

interface CoachData {
  _id: string;
  name: string;
  Lname: string;
  email: string;
  image: string;
}
interface BalanceData {
  totalRevenue: number;
  payoutBalance: number;
  totalBalance: number;
  payoutBalancePending: number;
}

export default function PayoutReceipts() {
  const { coachId } = useParams(); //coach id
  const [data, setCoachData] = React.useState<CoachData>({
    _id: "",
    name: "",
    Lname: "",
    email: "",
    image: "",
  });
  const [balanceData, setBalance] = React.useState<BalanceData>({
    totalRevenue: 0,
    payoutBalance: 0,
    totalBalance: 0,
    payoutBalancePending: 0,
  });
  const [loading, setLoading] = React.useState(true); // Add loading state

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/payout-history/coach/${coachId}?pageNo=1`
      );
      if (response.data.payoutList) {
        setCoachData(response.data.coachData);
        setBalance(response.data.balanceDetails);

        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  //handle payout approve

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };
  return (
    <>
      <Box
        sx={{
          width: "100%",
          overflow: "auto",
          height: "100svh",
        }}
      >
        {/* coach profile avtar  */}
        <Box
          sx={{
            display: "flex",
            width: "100%",
            backgroundColor: "#013338",
            color: "white",
            position: "relative",
            height: { xs: "5rem", md: "8rem" },
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              paddingLeft: "1.25rem",
              gap: "1rem",
              position: "absolute",
              top: { xs: "1rem", md: "2.25rem" },
              height: "100%",
            }}
          >
            {data?.image != "" ? (
              <Avatar
                alt={data?.name}
                src={`${backendURL}/usersProfile/${data?.image}`}
                sx={{
                  width: { xs: "4rem", sm: "6rem", md: "8rem" },
                  height: { xs: "4rem", sm: "6rem", md: "8rem" },
                }}
              />
            ) : (
              <Avatar
                sx={{
                  backgroundColor: "#013338",
                  width: { xs: "4rem", sm: "6rem", md: "8rem" },
                  height: { xs: "4rem", sm: "6rem", md: "8rem" },
                  fontSize: "3rem",
                }}
              >
                {capitalizeFirstLetter(data?.name)}
              </Avatar>
            )}

            <Box className="profile-info" sx={{ paddingBottom: "1rem" }}>
              <Typography
                variant="h6"
                component="p"
                sx={{
                  fontSize: "1.2rem",
                  lineHeight: "2rem",
                  fontWeight: "600",
                }}
              >
                {data.name} {data.Lname}
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: "500",
                }}
              >
                {data.email}
              </Typography>
            </Box>
          </Box>
        </Box>
        {/* payment card  */}
        <Box
          display="flex"
          flexDirection={{ xs: "column", md: "row" }}
          gap={5}
          p={1}
          mx="auto"
          marginTop={8}
          sx={{
            width: {
              lg: "100%",
              xl: "80%",
            },
            mx: "auto",
          }}
        >
          <Grid container spacing={2} sx={{ height: "fit-content" }}>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Total Balence
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.totalBalance)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Total Payout
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.payoutBalance)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Pending Payout
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.payoutBalancePending)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Total Revenue
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.totalRevenue)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Box>
        {/* ////////////////// */}
        {/* table */}
        <Paper
          sx={{
            width: {
              lg: "100%",
              xl: "80%",
            },
            overflow: "auto",
            scrollbarWidth: "none",

            marginTop: "10px",
            marginBottom: "90px",
          }}
        >
          <Box
            sx={{
              padding: 3,
              color: "#013338",
              display: "flex",
              justifyContent: "justify-between",
              alignItems: "center",
            }}
          >
            <Typography
              variant="body1"
              // gutterBottom
              sx={{
                fontWeight: "bold",
                padding: "4px 10px",
                width: "100%",
                display: "flex",
                justifyContent: "space-between",
                gap: "5px",
                alignItems: "center",
                color: "#013338",
              }}
            >
              <span>Payout History</span>
            </Typography>
          </Box>
          <Box>
            <DownloadReceiptsCoach />
          </Box>
        </Paper>
      </Box>
      <ToastContainer theme="colored" />
    </>
  );
}
function formatNumber(value: number, fallback = "0.00") {
  return value != null && !isNaN(value) ? Number(value).toFixed(2) : fallback;
}
