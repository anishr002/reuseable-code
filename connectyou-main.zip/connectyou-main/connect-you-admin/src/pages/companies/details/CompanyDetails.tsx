import { useParams } from "react-router-dom";

const CompanyDetails = () => {
  const { companyId } = useParams();
  return (
    <div>
      <div className="">Companyy {companyId}</div>
    </div>
  );
};

export default CompanyDetails;
