/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import VisibilityIcon from "@mui/icons-material/Visibility";
import TableRow from "@mui/material/TableRow";
import dayjs from "dayjs";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import {
  Avatar,
  Box,
  FormControl,
  Pagination,
  TableCell,
  Typography,
} from "@mui/material";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import { Link } from "react-router-dom";
import backendURL, { httpAPI_admin } from "../../AxiosAPI";
import NoDataIllustration from "../../components/NoDataIllustration";

interface CoachData {
  coachId: string;
  name: string;
  Lname: string;
  email: string;
  image: string;
}

interface PayoutType {
  _id: string;
  coachId: string;
  amount: number;
  status: number;
  createdAt: string;
  approveDate: string;
  coachData: CoachData;
  totalAmount: number;
  totalPayout: number;
}
export default function Companies() {
  const [data, setData] = React.useState<PayoutType[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);

  const fetchData = React.useCallback(async (pageNo: number) => {
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/payout-history?pageNo=${pageNo}`
      );
      console.log("rows", response);
      if (response.status === 200) {
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        return setData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  }, []);
  React.useEffect(() => {
    fetchData(pageNo);
  }, [pageNo, fetchData]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${data.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            gap: "5px",
            alignItems: "center",
            color: "#013338",
          }}
        >
          <span>Companies</span>
          <Box
            sx={{
              display: "flex",
              gap: 2,
            }}
          >
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            ></FormControl>
            <AccountBalanceIcon style={{ color: "#013338" }} />
          </Box>
        </Typography>
        {data?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 200px)",
                overflow: "auto",
                cursor: "pointer",
                mx: "auto",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead
                  sx={{
                    maxWidth: "100%",
                    padding: "1px",
                    "& .MuiTableCell-head": { lineHeight: "normal" },
                  }}
                >
                  <TableRow sx={{ textTransform: "uppercase" }}>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        width: "7%",
                      }}
                    >
                      Profile
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        width: "8%",
                      }}
                    >
                      Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        maxWidth: "9%",
                        textWrap: "balance",
                      }}
                    >
                      Email
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Receipts
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Details
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Approve
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                      }}
                    >
                      Requested Payout
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Balance
                    </TableCell>

                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Total Payout
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Total Revenue
                    </TableCell>

                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                      }}
                    >
                      Request Date
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                      }}
                    >
                      Approve Date
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          <span>
                            {row.coachData.image ? (
                              <>
                                <Avatar
                                  alt={row.coachData.name}
                                  src={`${backendURL}/usersProfile/${row.coachData.image}`}
                                />
                              </>
                            ) : (
                              <>
                                <Avatar
                                  sx={{
                                    backgroundColor: "#013338",
                                  }}
                                ></Avatar>
                              </>
                            )}
                          </span>
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          {row.coachData.name}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          {row.coachData.email}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          <Box
                            sx={{
                              px: 2,
                              py: 0.51,
                              color: "white",
                              backgroundColor: "#EBBE34",
                              borderColor: "#EBBE34",
                              borderRadius: "20px",
                              fontFamily: "Montserrat",
                              mx: "auto",
                              "&:hover": {
                                borderColor: "white",
                                backgroundColor: "white",
                                color: "#EBBE34",
                              },
                            }}
                          >
                            <Link
                              to={`/payout/detail/receipts/${row.coachId}`}
                              style={{
                                textDecoration: "none",
                                color: "inherit",
                              }}
                            >
                              Receipts
                            </Link>
                          </Box>
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          <Link to={`detail/${row.coachData.coachId}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                        <TableCell
                          sx={{
                            whiteSpace: "nowrap",
                            fontSize: "1rem",
                          }}
                        >
                          .
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          ${formatNumber(row.amount / 100)}
                          {/* field for Requested amount  */}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          $
                          {formatNumber(
                            (row.totalAmount - row.totalPayout) / 100
                          )}
                          {/* field for total  balance  */}
                        </TableCell>

                        <TableCell sx={{ fontSize: "1rem" }}>
                          ${formatNumber(row.totalPayout / 100)}
                          {/* field for total ayout  */}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          ${formatNumber(row.totalAmount / 100)}
                          {/* field for total revenuw  */}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {dayjs(row.createdAt).format("DD-MM-YYYY hh:mm A")}
                          {/* field for request date  */}
                        </TableCell>

                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {/* field for approved date   */}
                          {row.approveDate != ""
                            ? dayjs(row.approveDate).format(
                                "DD-MM-YYYY hh:mm A"
                              )
                            : "-"}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo.totalPages)}
                  page={Number(pageInfo.currentPage)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration />
        )}
      </Paper>
    </>
  );
}

function formatNumber(value: number, fallback = "0.00") {
  return value != null && !isNaN(value) ? Number(value).toFixed(2) : fallback;
}
