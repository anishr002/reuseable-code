const UpdateCompanyData = () => {
  return (
    <div>
      <div className=""></div>
    </div>
  );
};

export default UpdateCompanyData;
