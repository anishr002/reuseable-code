import Swal from "sweetalert2";
import CancelIcon from "@mui/icons-material/Cancel";
const label = { inputProps: { "aria-label": "Switch demo" } };
import VisibilityIcon from "@mui/icons-material/Visibility";
import ScheduleIcon from "@mui/icons-material/Schedule";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";

import {
  Box,
  FormControl,
  MenuItem,
  Pagination,
  Select,
  Switch,
  TableCell,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import { Link, useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { toast } from "react-toastify";

export default function RefundRequestPage() {
  const [data, setTransactions] = React.useState<Refund_Req_data[]>([]);
  const [pendingCount, setPendingCount] = React.useState<number>(0);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);
  const [filterTerm, setFilterTerm] = React.useState<number>(3); // 0 for pending req, // 1 for approved req // 2 for deniend req // 3 all
  const handleChangeFilter = (event: any) => {
    setFilterTerm(event.target.value);
    setPageNo(1);
  };
  const fetchRefundRequests = async (filterType = 3, page = 1, limit = 10) => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/refunds/fetch-request-list`,
        {
          params: {
            filter: filterType, // 3 = all, 1 = approved, 2 = denied
            page, // Current page number
            limit, // Number of items per page
            type: "listing",
          },
        }
      );
      if (response.status === 200) {
        const { transactions, totalPages, pendingCount } = response.data;
        setTransactions(transactions);
        setPageInfo({
          currentPage: pageNo,
          totalPages: totalPages,
        });
        setPendingCount(pendingCount);
      }
    } catch (error) {
      console.error("Error fetching balance and transactions:", error);
    } finally {
      setLoading(false);
    }
  };
  React.useEffect(() => {
    fetchRefundRequests(filterTerm, pageNo, 20);
  }, [pageNo, filterTerm, pageUpdated]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  const cancelRefundFunction = async (refund_req_id: string) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to cancel this refund request?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, cancel it!",
      cancelButtonText: "No, keep it",
    });

    if (result.isConfirmed) {
      setLoading(true);
      try {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/txn-history/refunds/actions/cancel-request/${refund_req_id}`
        );
        console.log(response);
        if (response.status === 200) {
          setPageUpdated(!pageUpdated);
          return toast.success("Refund Request has been denied successfully");
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }
  };

  //handle coach account delete
  const handleRejectRequest = (refund_req_id: string) => {
    console.log({ refund_req_id });
    cancelRefundFunction(refund_req_id);
  };

  const navigate = useNavigate();

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${data.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            flexDirection: { xs: "column", md: "row" },
            display: "flex",
            justifyContent: { xs: "space-between", md: "space-between" },
            gap: "5px",
            alignItems: { xs: "start", md: "center" },
            color: "#013338",
          }}
        >
          <div
            style={{
              position: "relative",
              display: "flex",
            }}
          >
            Refund Requests
            {pendingCount > 0 && (
              <span
                style={{
                  background: "#ebbe34",
                  color: "white",
                  width: "20px",
                  height: "20px",
                  borderRadius: "50%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  fontSize: "0.75rem",
                  boxShadow: "0px 0px 8px rgba(0, 0, 0, 0.15)", // Optional shadow for effect
                }}
              >
                {pendingCount > 99 ? "99+" : pendingCount}
              </span>
            )}
          </div>

          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            >
              <Select
                displayEmpty
                size="small"
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={filterTerm}
                onChange={handleChangeFilter}
                sx={{
                  color: "#013338",
                  borderColor: "#013338",
                  fontSize: "0.775rem",
                  "& .MuiSelect-icon": {
                    color: "#013338", // Set the color of the dropdown icon
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#013338", // Set border color
                  },
                }}
              >
                <MenuItem sx={{ fontSize: "0.775rem" }} value={3}>
                  <em>All</em>
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                  Approved
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                  Declined
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={0}>
                  Pending
                </MenuItem>
              </Select>
            </FormControl>
            <Box
              onClick={() => {
                navigate("/refunds/history");
              }}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "1.1rem",
              }}
            >
              View History
              <ScheduleIcon style={{ color: "#013338" }} />
            </Box>
          </Box>
        </Typography>
        {data?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 210px)",
                overflow: "auto",
                minWidth: "fit-content",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Coachee Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email Address
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Amount
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Requested on
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Details
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Approve
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Decline
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Status
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-word" },
                          }}
                        >
                          {row.userData.name}
                        </TableCell>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-all" },
                          }}
                        >
                          {row.userData.email}
                        </TableCell>
                        <TableCell>
                          {(Number(row.amount) / 100).toFixed(2)}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {row?.createdAt
                            ? dayjs(row?.createdAt).format("DD-MM-YYYY hh:mm A")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <Link to={`/refunds/details/${row?._id}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                        <SwtichControllerApprove
                          pageUpdated={pageUpdated}
                          row={row}
                          setLoading={setLoading}
                          setPageUpdated={setPageUpdated}
                          loading={loading}
                        />
                        <TableCell>
                          {row.refund_status === 0 ? (
                            <CancelIcon
                              color="error"
                              style={{ cursor: "pointer" }}
                              onClick={() =>
                                row.refund_status === 0 &&
                                handleRejectRequest(row._id)
                              }
                            />
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell>
                          <span
                            style={{
                              color: "white",
                              background:
                                row.refund_status === 0
                                  ? "#ebbe34"
                                  : row.refund_status === 1
                                    ? "#3aa7a3"
                                    : "red",
                              padding: "5px 10px",
                              borderRadius: "22px",
                            }}
                          >
                            {row.refund_status === 0
                              ? "Pending"
                              : row.refund_status === 1
                                ? "Approved"
                                : "Declined"}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo?.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo?.totalPages)}
                  page={Number(pageNo)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration message="No Refund Requests! " />
        )}
      </Paper>
    </>
  );
}

interface UserData {
  name: string;
  _id: string;
  email: string;
  gender: string;
  image: string;
}
interface CoachData {
  name: string;
  _id: string;
  email: string;
  gender: string;
  image: string;
  Lname: string;
}
interface SessionData {
  title: string;
  _id: string;
  price: string;
  description: string;
}

export interface Refund_Object_Type {
  _id: string;
  cartId: string;
  bookings_id: string;
  booked_session_id: string;
  userId: string;
  coachId: string;
  sessionId: string;
  coachTimeZone: string;
  userTimeZone: string;
  sessionType: string;
  sessionDate: Date;
  sessionDateUpdated: Date;
  charge: string;
  amount: string;
  session_cancel_remark: string;
  cancel_requested_by: string;
  refund_status: number; /// 0 for pending , 1 for approved // 2 for denied
  refund_id: string;
  refund_transaction_id: string;
  refund_charge_id: string;
  refund_created: string; // timestamp from stripe once completed
  refund_amount: string;
  refund_stripe_status: string; // stripe refund status
  createdAt: string;
}

export interface Refund_Req_data extends Refund_Object_Type {
  userData: UserData;
  coachData: CoachData;
  sessionData: SessionData;
}

const SwtichControllerApprove = ({
  row,
  setLoading,
  setPageUpdated,
  pageUpdated,
  loading,
}: {
  loading: boolean;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
  setPageUpdated: React.Dispatch<React.SetStateAction<boolean>>;
  row: Refund_Object_Type;
  pageUpdated: boolean;
}) => {
  const [switchState, setSwitchState] = React.useState<boolean>(
    row.refund_status === 1 ? true : false
  );

  const approveFunction = async (refund_req_id: string) => {
    setLoading(true);

    // Show confirmation dialog
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to approve this refund request?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, approve it!",
      cancelButtonText: "No, keep it",
    });

    console.log(result);

    if (result.isConfirmed) {
      try {
        // Call the API to approve the refund request
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/txn-history/refunds/actions/approve-request/${refund_req_id}`
        );

        console.log(response);

        if (response.status === 200) {
          if (response.data.message === "Refund already processed") {
            Swal.fire({
              title: "This refund has already been processed.",
              timer: 2000,
              icon: "info",
              showConfirmButton: true,
            });
            setPageUpdated(!pageUpdated);
            return setSwitchState(true); // Update switch state only after success
          }
          setPageUpdated(!pageUpdated);
          setSwitchState(true); // Update switch state only after success
          toast("Refund Request Approved successfully");
        }
      } catch (error: any) {
        console.error(error);
        setSwitchState(false); // Revert to original state on failure
      } finally {
        setLoading(false);
      }
    } else if (result.isDismissed || result.isDenied) {
      setSwitchState(false);
      console.log("dismissed or denied");
      setLoading(false);
    }
  };

  const handleApprove = (
    _: React.ChangeEvent<HTMLInputElement>,
    checked: boolean,
    refund_req_id: string
  ) => {
    setSwitchState(checked);
    approveFunction(refund_req_id);
  };

  return (
    <>
      <TableCell>
        {row.refund_status === 0 ? (
          <Switch
            {...label}
            disabled={loading}
            color={row?.refund_status === 0 ? "info" : "default"}
            value={switchState}
            onChange={(
              event: React.ChangeEvent<HTMLInputElement>,
              checked: boolean
            ) => {
              handleApprove(event, checked, row._id);
            }}
          />
        ) : (
          <span>-</span>
        )}
      </TableCell>
    </>
  );
};
