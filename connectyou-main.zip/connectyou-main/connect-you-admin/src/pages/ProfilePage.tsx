import * as React from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import {
  Avatar,
  Button,
  CircularProgress,
  IconButton,
  Modal,
  Paper,
  TextField,
  Typography,
} from "@mui/material";
import backendURL from "../AxiosAPI";
import { useSelector } from "react-redux";
import LockIcon from "@mui/icons-material/Lock";
import { useForm } from "react-hook-form";
import { httpAPI_admin } from "../AxiosAPI";
import { ToastContainer, toast } from "react-toastify";

type FormData = {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
};

type Fun = () => void;

const ProfilePage: React.FC = () => {
  // global state
  const adminData = useSelector((state: any) => state.adminLogin.userdata);
  const [loading, setLoading] = React.useState(false); //loading behaviour on form submit

  // pasword field controls /
  const [showPasswordContainer, setShowPasswordContainer] =
    React.useState<boolean>(false);
  const handlePasswordUpdate = () => {
    return setShowPasswordContainer(!showPasswordContainer);
  };

  // react hook form controls setup
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
    reset,
  } = useForm<FormData>();

  const onSubmit = handleSubmit(async (data) => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.post(`/admin/update-password`, data);
      if (response.status === 200) {
        toast.success("Password updated successfully");
        reset();
        handlePasswordUpdate();
        handleClose();
        return setLoading(false);
      }
    } catch (error: any) {
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        // toast.error(error.response.data.message); // removed this  as it is not vissible under the modal
        style.border = "0.5px solid red";
        seOpenChild(true);
        setTimeout(() => {
          reset();
          seOpenChild(false);
          style.border = "0.5px solid #000";
        }, 3000);
        return setLoading(false);
      }
    } finally {
      return setLoading(false);
    }
  });
  // end of react hook form config here

  // modal controls are configured here
  const [open, setOpen] = React.useState<boolean>(false);
  const [openChild, seOpenChild] = React.useState(false);
  const handleOpen: Fun = () => setOpen(true);
  const handleClose: Fun = () => {
    reset();
    seOpenChild(false);
    setOpen(false);
  };

  // update password  form rendering funcation
  const renderForm = () => {
    return (
      <form onSubmit={onSubmit}>
        <Box mt={3}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="name"
                label="Old password"
                variant="outlined"
                {...register("oldPassword", {
                  required: "Please enter old password",
                })}
                error={!!errors.oldPassword}
                helperText={errors.oldPassword?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="password"
                label="New password"
                variant="outlined"
                {...register("newPassword", {
                  required: "Please enter new password",
                  minLength: {
                    value: 8,
                    message: "Password must be at least 8 characters long",
                  },
                  maxLength: {
                    value: 20,
                    message: "Password must be at most 20 characters long",
                  },
                })}
                error={!!errors.newPassword}
                helperText={errors.newPassword?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="password"
                label="Confirm New password"
                variant="outlined"
                {...register("confirmPassword", {
                  required: "Please enter confirm password",
                  validate: (value) =>
                    value === getValues("newPassword") ||
                    "new password and confirm password do not match",
                })}
                error={!!errors.confirmPassword}
                helperText={errors.confirmPassword?.message}
              />
            </Grid>
            {/* <Grid item xs={12} sm={12} p={2}>
              <Typography variant="caption">
                <Link to="?" style={{ color: "red", textDecoration: "none" }}>
                  Forgot Password ?
                </Link>
              </Typography>
            </Grid> */}
            <Grid item xs={12} sm={6}>
              <Button
                variant="contained"
                color="error"
                fullWidth
                onClick={() => {
                  handlePasswordUpdate();
                  handleClose();
                }}
              >
                Cancel
              </Button>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  "Submit"
                )}
              </Button>
            </Grid>
          </Grid>
        </Box>
      </form>
    );
  };
  // ends here

  // parent component return
  return (
    <>
      {renderModal(
        open,
        handleClose,
        renderForm(),
        renderChildModal(openChild)
      )}
      {/* added in the end of this function  */}
      <Paper
        sx={{
          width: "100%",
          overflowY: "scroll",
          overflowX: "hidden",
          minHeight: "98vh",
          maxHeight: "100vh",
          pb: 10,
        }}
        elevation={3}
      >
        <Grid container spacing={1}>
          <Grid item sm={12} xs={12} sx={{ height: "30vh" }}>
            <Box
              sx={{
                background: "#013338",
                width: "100%",
                p: 1,
                height: "18vh",
                position: "relative",
              }}
            >
              <Box
                display="flex"
                justifyContent="start"
                alignItems="start"
                margin="0 auto"
                padding="0 15px"
                width={"100%"}
                flexDirection={{ md: "row", sm: "column", xs: "column" }}
                height={{ md: 160, sm: 230, xs: 230 }}
                borderRadius="50%"
                position="absolute"
                sx={{
                  top: "100%",
                  transform: { md: "translateY(-50%)", xs: "translateY(-40%)" },
                }}
              >
                {adminData?.image ? (
                  <Avatar
                    src={`${backendURL}/usersProfile/${adminData?.image}`}
                    alt="User"
                    sx={{
                      width: 130,
                      height: 130,
                    }}
                  />
                ) : (
                  <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    sx={{
                      minWidth: 130,
                      height: 130,
                    }}
                    bgcolor="slategray"
                    borderRadius="50%"
                  >
                    <Typography
                      variant="body2"
                      color="white"
                      sx={{ fontSize: "1.5rem" }}
                    >
                      {capitalizeFirstLetter(adminData?.name)}
                    </Typography>
                  </Box>
                )}
                <Box
                  p={1}
                  sx={{
                    width: "100%",
                    overflow: "hidden",
                    color: { sm: "#013338", xs: "#013338", md: "white" },
                  }}
                >
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: "normal",
                      padding: "0 16px",
                      width: "100%",
                      whiteSpace: "nowrap",
                      textOverflow: { sm: "ellipsis" },
                    }}
                  >
                    {adminData?.name?.charAt(0).toUpperCase() +
                      adminData?.name?.slice(1)}
                  </Typography>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: "300",
                      fontSize: "1rem",
                      padding: "2px 16px",
                      width: "100%",
                      whiteSpace: { lg: "nowrap", sm: "normal", xs: "balance" },
                    }}
                  >
                    {adminData.email}
                  </Typography>
                </Box>
              </Box>
              <Box
                display="flex"
                justifyContent="start"
                alignItems="start"
                margin="0 auto"
                padding="0 15px"
                position="absolute"
                sx={{
                  right: 0,
                  top: { lg: "70%", sm: "50%", xs: "20%" },
                  transform: "translateY(-10%)",
                }}
              >
                <Typography variant="button">
                  <IconButton
                    size="small"
                    sx={{
                      color: "white",
                      borderBottom: "1px solid",
                      borderColor: "white",
                      borderRadius: "0",
                      ":hover": {
                        color: "lightblue",
                        borderColor: "lightblue",
                      },
                    }}
                    aria-label="update password"
                    onClick={() => {
                      handlePasswordUpdate();
                      handleOpen();
                    }}
                  >
                    <LockIcon sx={{ fontSize: "medium", mr: 0.5 }} />
                    Update Password
                  </IconButton>
                </Typography>
              </Box>
            </Box>
          </Grid>

          <Grid
            container
            sx={{ width: { sm: "50%", xs: "100%" } }}
            spacing={1}
            p={5}
          >
            <Grid item sm={12} xs={12}>
              <Paper
                elevation={3}
                sx={{
                  width: "100%",
                  px: 2,
                  py: 1,
                  height: 110,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "start",
                  alignItems: "start",
                  gap: 2,
                }}
              >
                <Typography
                  variant="body1"
                  sx={{ fontSize: "1.2rem", fontWeight: 500, color: "#013338" }}
                >
                  Name
                </Typography>
                <TextField
                  size="small"
                  fullWidth
                  variant="outlined"
                  defaultValue={adminData.name}
                  disabled
                  sx={{
                    "& .MuiInputBase-input.Mui-disabled": {
                      color: "#013338", // Text color
                    },
                    "& .MuiOutlinedInput-root.Mui-disabled .MuiOutlinedInput-notchedOutline":
                      {
                        borderColor: "#013338", // Border color
                      },
                    "& .MuiOutlinedInput-root.Mui-disabled": {
                      backgroundColor: "#ffffff", // Background color
                    },
                    ".css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input.Mui-disabled":
                      {
                        WebkitTextFillColor: "black",
                      },
                  }}
                />
              </Paper>
            </Grid>
            <Grid item sm={12} xs={12}>
              <Paper
                elevation={3}
                sx={{
                  width: "100%",
                  px: 2,
                  py: 1,
                  height: 110,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "start",
                  alignItems: "start",
                  gap: 2,
                }}
              >
                <Typography
                  variant="body1"
                  sx={{ fontSize: "1.2rem", fontWeight: 500, color: "#013338" }}
                >
                  Email
                </Typography>
                <TextField
                  size="small"
                  fullWidth
                  variant="outlined"
                  defaultValue={adminData.email}
                  disabled
                  sx={{
                    "& .MuiInputBase-input.Mui-disabled": {
                      color: "#013338", // Text color
                    },
                    "& .MuiOutlinedInput-root.Mui-disabled .MuiOutlinedInput-notchedOutline":
                      {
                        borderColor: "#013338", // Border color
                      },
                    "& .MuiOutlinedInput-root.Mui-disabled": {
                      backgroundColor: "#ffffff", // Background color
                    },
                    ".css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input.Mui-disabled":
                      {
                        WebkitTextFillColor: "black",
                      },
                  }}
                />
              </Paper>
            </Grid>
            <Grid item sm={12} xs={12}>
              <Paper
                elevation={3}
                sx={{
                  width: "100%",
                  px: 2,
                  py: 1,
                  height: 210,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "start",
                  alignItems: "start",
                  gap: 2,
                }}
              >
                <Typography
                  variant="body1"
                  sx={{ fontSize: "1.2rem", fontWeight: 500, color: "#013338" }}
                >
                  Address
                </Typography>
                <TextField
                  size="small"
                  fullWidth
                  variant="outlined"
                  multiline={true}
                  rows={4}
                  defaultValue={adminData.address}
                  disabled
                  sx={{
                    "& .MuiInputBase-input.Mui-disabled": {
                      color: "#013338", // Text color
                    },
                    "& .MuiOutlinedInput-root.Mui-disabled .MuiOutlinedInput-notchedOutline":
                      {
                        borderColor: "#013338", // Border color
                      },
                    "& .MuiOutlinedInput-root.Mui-disabled": {
                      backgroundColor: "#ffffff", // Background color
                    },
                    ".css-12tl3rr-MuiInputBase-input-MuiOutlinedInput-input.Mui-disabled":
                      {
                        WebkitTextFillColor: "black",
                      },
                  }}
                />
              </Paper>
            </Grid>
          </Grid>
        </Grid>

        <ToastContainer theme="colored" />
      </Paper>
    </>
  );
};
export default ProfilePage;
//  end of parent component here

// modal config here
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: {
    xs: "80vw",
    md: 600,
  },
  bgcolor: "background.paper",
  border: "0.5px solid black",
  boxShadow: 24,
  p: 4,
};

const renderModal = (
  open: boolean,
  handleClose: Fun,
  render: any,
  rendChild: any
) => {
  return (
    <Modal
      keepMounted
      open={open}
      onClose={handleClose}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
    >
      <Box sx={style}>
        <Typography
          variant="button"
          sx={{
            width: "100%",
            textAlign: "center",
            color: "#013338",
            fontWeight: "600",
          }}
        >
          Update Password
        </Typography>
        {rendChild}
        {render}
      </Box>
    </Modal>
  );
};

const renderChildModal = (open: boolean) => {
  return (
    <>
      {open && (
        <Box
          sx={{
            width: {
              md: "100%",
              sm: "100%",
            },
            backgroundColor: "white",
            borderRadius: "8px",
            padding: "20px",
            textAlign: "center",
            outline: "none",
          }}
        >
          <Typography
            sx={{
              marginBottom: "10px",
              color: "red",
              fontWeight: "bold",
            }}
            variant="h6"
          >
            Incorrect Password
          </Typography>
          <Typography
            sx={{ marginBottom: "20px", color: "gray" }}
            variant="body1"
          >
            The old password you entered is incorrect. Please try again.
          </Typography>
        </Box>
      )}
    </>
  );
};
const capitalizeFirstLetter = (string: string) => {
  if (!string) return "E";
  return string.charAt(0).toUpperCase();
};
