import SearchIcon from "@mui/icons-material/Search";
import ContentPasteIcon from "@mui/icons-material/ContentPaste";
import ReactDOM from "react-dom/client";
import CancelIcon from "@mui/icons-material/Cancel";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import VisibilityIcon from "@mui/icons-material/Visibility";

import TableRow from "@mui/material/TableRow";
import {
  Avatar,
  Box,
  Button,
  FormControl,
  MenuItem,
  Pagination,
  Select,
  Switch,
  TableCell,
  TextField,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
const label = { inputProps: { "aria-label": "Switch demo" } };
import Swal from "sweetalert2";
import { Link, useNavigate } from "react-router-dom";
import NoDataIllustration from "../components/NoDataIllustration";
import dayjs from "dayjs";
import FilePreview from "../components/FilePreview";

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
    title: "montserrat-title",
    popup: "montserrat-popup",
  },
  buttonsStyling: false,
});
export default function CoachAgreements() {
  interface Row {
    _id: string;
    dateOfSubmission: string;
    dateOfApproval: string;
    agreement_file: string;
    approve: number;
    status: number;
    remarks: string;
    discontinue: string;
    createdAt: string;
    coachDetails: {
      _id: string;
      email: string;
      name: string;
      Lname: string;
      gender: string;
      image: string;
    };
  }
  const [rows, setData] = React.useState<Row[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  const refresh = () => {
    setPageUpdated(!pageUpdated);
  };
  //handle coach block
  const handleApprove =
    ({
      req_id,
      coach_id,
      file,
    }: {
      req_id: string;
      coach_id: string;
      file: string;
    }) =>
      async (_event: React.ChangeEvent<HTMLInputElement>) => {
        console.log(_event);
        const container = document.createElement("div");
        const root = ReactDOM.createRoot(container);
        root.render(
          <Box
            sx={{
              display: "flex",
              width: "100%",
              gap: 2,
              flexDirection: "column",
            }}
          >
            <span> Do you want to approve this agreement for the coach ?</span>
            <FilePreview
              file={file}
              fileUrl={`${backendURL}/coachAgreements/${file}`}
              showDownLoadButton={false}
            />
          </Box>
        );
        swalWithBootstrapButtons
          .fire({
            title: "Approve coach agreement?",
            text: `You have examinned and want to approve this agreement ?`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: `Confirm Approval`,
            cancelButtonText: "Back",
            reverseButtons: true,
            html: container,
            customClass: {
              confirmButton: "btn-success",
              cancelButton: "btn-danger",
              popup: "custom-modal",
            },
            buttonsStyling: false,
            backdrop: true,
          })
          .then(async (result) => {
            if (result.isConfirmed) {
              try {
                const response = await httpAPI_admin.put(
                  `${backendURL}/admin/coach/agreement/approve-agreements/${req_id.trim()}/${coach_id.trim()}`
                );
                console.log(response);
                if (response.data.success === true) {
                  refresh();
                  swalWithBootstrapButtons.fire({
                    title: `Coach Profile aprroved !`,
                    text: `Coach profile has been approved successfully.`,
                    icon: "success",
                    showConfirmButton: true,
                    timer: 1500,
                  });
                }
              } catch (error) {
                console.error("Error accepting:", error);
                refresh();

                swalWithBootstrapButtons.fire({
                  text: "Some Error Occurred, Please try again!",
                  title: "Opps !",
                  icon: "error",
                  showConfirmButton: true,
                });
              } finally {
                console.log("Running finnally of the approve");
                refresh();
              }
            } else {
              refresh();
            }
          });
      };

  //handle coach account delete
  const handleRejectRequest = ({
    req_id,
    coach_id,
  }: {
    req_id: string;
    coach_id: string;
  }) => {
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You want to reject this profile approval request.",
        icon: "warning",
        input: "textarea", // Adding a text area for rejection notes
        inputValue:
          "Your Agreement do not have the signatures, please upload a signed copy of the agreement.", // Default rejection message
        inputPlaceholder: "Enter profile rejection notes for coach here...", // Placeholder text
        showCancelButton: true,
        confirmButtonText: `Yes, Reject this request !`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
        preConfirm: (notes) => {
          if (!notes) {
            Swal.showValidationMessage("Rejection notes are required.");
            return false; // Prevent confirmation if no notes provided
          }
          return notes; // Return the notes value if valid
        },
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          const rejectionNotes = result.value;
          setLoading(true);
          try {
            const response = await httpAPI_admin.put(
              `${backendURL}/admin/coach/agreement/reject-agreements/${req_id.trim()}/${coach_id.trim()}`,
              { remarks: rejectionNotes } // Send rejection notes with the request
            );
            console.log({ approve: response });
            if (response.data.success === true) {
              swalWithBootstrapButtons.fire({
                title: `Rejected!`,
                text: `The profile was rejected successfully.`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
            }
          } catch (error) {
            console.error("Error rejecting:", error);

            swalWithBootstrapButtons.fire({
              text: "Some Error Occurred, Please try again!",
              title: "Opps !",
              icon: "error",
              showConfirmButton: false,
            });
          } finally {
            refresh();
          }
        } else {
          refresh();
        }
      });
  };
  //handle revoke
  const handleRevoke = ({
    req_id,
    coach_id,
  }: {
    req_id: string;
    coach_id: string;
  }) => {
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You want to reject this profile approval request.",
        icon: "warning",
        input: "textarea", // Adding a text area for rejection notes
        inputValue:
          "Your Agreement do not have the signatures, please upload a signed copy of the agreement.", // Default rejection message
        inputPlaceholder: "Enter profile rejection notes for coach here...", // Placeholder text
        showCancelButton: true,
        confirmButtonText: `Yes, Reject this request !`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
        preConfirm: (notes) => {
          if (!notes) {
            Swal.showValidationMessage("Rejection notes are required.");
            return false; // Prevent confirmation if no notes provided
          }
          return notes; // Return the notes value if valid
        },
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          const rejectionNotes = result.value;
          setLoading(true);
          try {
            const response = await httpAPI_admin.put(
              `${backendURL}/admin/coach/agreement/revoke-agreements/${req_id.trim()}/${coach_id.trim()}`,
              { remarks: rejectionNotes } // Send rejection notes with the request
            );
            console.log({ approve: response });
            if (response.data.success === true) {
              swalWithBootstrapButtons.fire({
                title: `Revoked!`,
                text: `Coach agreement have been revoked for the coach.`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
            }
          } catch (error) {
            console.error("Error rejecting:", error);
            swalWithBootstrapButtons.fire({
              text: "Some Error Occurred, Please try again!",
              title: "Opps !",
              icon: "error",
              showConfirmButton: false,
            });
          } finally {
            refresh();
          }
        } else {
          refresh();
        }
      });
  };
  const [filterTerm, setFilterTerm] = React.useState<number>(3); //filter data by approve or not
  const [searchTerm, setSearchTerm] = React.useState<string>(""); //charecter search
  const [filterSearch, setFilterSearch] = React.useState<string>(""); //charecter search
  const handleChangeFilter = (event: any) => {
    setFilterTerm(event.target.value);
  };
  const fetchPendingApprovalData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/agreement/list-agreements?pageNo=${pageNo}&limit=10&filter=${filterTerm}&searchTerm=${filterSearch}`
      );
      if (response.data.success) {
        setPageInfo({
          totalPages: response.data.totalPages,
        });
        return setData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchPendingApprovalData();
  }, [pageNo, pageUpdated, filterTerm, filterSearch]);

  const navigate = useNavigate();
  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            flexDirection: { xs: "column", md: "row" },
            display: "flex",
            justifyContent: { xs: "start", md: "space-between" },
            gap: "5px",
            alignItems: { xs: "start", md: "center" },
            color: "#013338",
          }}
        >
          <div
            style={{
              position: "relative",
              display: "flex",
            }}
          >
            Legal & Agreements
          </div>
          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                sm: "row",
              },
              gap: 2,
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: { xs: "start", sm: "center" },
                flexDirection: {
                  xs: "column",
                  sm: "row",
                },
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  gap: 2,
                  alignItems: "center",
                }}
              >
                <TextField
                  id="outlined-search"
                  placeholder="Search..."
                  type="search"
                  variant="outlined"
                  fullWidth
                  size="small"
                  value={searchTerm}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setSearchTerm(event.target.value);
                    if (event.target.value === "") {
                      setFilterSearch("");
                    }
                  }}
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: "30px",
                      backgroundColor: "#fff",
                    },
                  }}
                />
                <Button
                  sx={{
                    minWidth: 35,
                    minHeight: 35,
                    borderRadius: "50%",
                    backgroundColor: "#3aa7a3",
                    color: "white",
                    "&:hover": {
                      backgroundColor: "#31c6f8",
                    },
                  }}
                  onClick={() => setFilterSearch(searchTerm)}
                >
                  <SearchIcon />
                </Button>
              </Box>

              <FormControl
                sx={{
                  fontSize: "1rem",
                  minWidth: 110,
                  "& .MuiOutlinedInput-root": {
                    "& fieldset": {
                      borderColor: "#013338", // Set border color for outlined variant
                    },
                    "&:hover fieldset": {
                      borderColor: "#013338", // Set border color on hover
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "#013338", // Set border color when focused
                    },
                  },
                  borderColor: "#013338",
                }}
                size="small"
              >
                <Select
                  displayEmpty
                  size="small"
                  labelId="demo-select-small-label"
                  id="demo-select-small"
                  value={filterTerm}
                  onChange={handleChangeFilter}
                  sx={{
                    color: "#013338",
                    borderColor: "#013338",
                    fontSize: "0.775rem",
                    "& .MuiSelect-icon": {
                      color: "#013338", // Set the color of the dropdown icon
                    },
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#013338", // Set border color
                    },
                  }}
                >
                  <MenuItem sx={{ fontSize: "0.775rem" }} value={3}>
                    <em>All</em>
                  </MenuItem>
                  <MenuItem sx={{ fontSize: "0.775rem" }} value={0}>
                    Pending
                  </MenuItem>
                  <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                    Approved
                  </MenuItem>
                  <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                    Rejected
                  </MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Box
              onClick={() => {
                navigate("/coach/coach-agreements/details");
              }}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "1.1rem",
              }}
            >
              View Agreement
              <ContentPasteIcon style={{ color: "#013338" }} />
            </Box>
          </Box>
        </Typography>
        {rows?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 210px)",
                overflow: "auto",
                minWidth: "fit-content",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email Address
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Agreement
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Submitted
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Approve
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Decline
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Details
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-word" },
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                            cursor: "pointer",
                          }}
                          onClick={() =>
                            navigate(`/coach/detail/${row?.coachDetails._id}`)
                          }
                        >
                          <div>
                            {row.coachDetails.image ? (
                              <>
                                <Avatar
                                  alt={row.coachDetails.name}
                                  src={`${backendURL}/usersProfile/${row.coachDetails.image}`}
                                />
                              </>
                            ) : (
                              <>
                                <Avatar
                                  sx={{
                                    backgroundColor: "#013338",
                                  }}
                                >
                                  {capitalizeFirstLetter(row.coachDetails.name)}
                                </Avatar>
                              </>
                            )}
                          </div>
                          {`${row?.coachDetails?.name} ${row?.coachDetails.Lname}`}
                          {row?.coachDetails?.gender
                            ? ` (${row?.coachDetails?.gender?.charAt(0)}) `
                            : ""}
                        </TableCell>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-all" },
                          }}
                        >
                          {row?.coachDetails?.email}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          <a
                            href={`${backendURL}/coachAgreements/${row.agreement_file}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            download
                          >
                            <ContentPasteIcon sx={{ color: "#eabd32" }} />
                          </a>
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {row?.dateOfSubmission
                            ? dayjs(row?.dateOfSubmission).format(
                              "DD-MM-YYYY hh:mm A"
                            )
                            : "-"}
                        </TableCell>
                        <TableCell>
                          {row.status !== 2 ? (
                            <Switch
                              {...label}
                              color="info"
                              onChange={handleApprove({
                                req_id: row?._id,
                                coach_id: row?.coachDetails._id,
                                file: row?.agreement_file,
                              })}
                            />
                          ) : (
                            <>{row.approve === 1 ? "Approved" : "Rejected"}</>
                          )}
                        </TableCell>
                        <TableCell>
                          {row.status !== 2 ? (
                            <CancelIcon
                              color="error"
                              style={{ cursor: "pointer" }}
                              onClick={() =>
                                handleRejectRequest({
                                  coach_id: row?.coachDetails._id,
                                  req_id: row?._id,
                                })
                              }
                            />
                          ) : (
                            <>
                              {row.approve === 2 ? (
                                "Rejected"
                              ) : (
                                <Button
                                  sx={{ color: "red" }}
                                  onClick={() => {
                                    handleRevoke({
                                      coach_id: row?.coachDetails._id,
                                      req_id: row?._id,
                                    });
                                  }}
                                >
                                  Revoke
                                </Button>
                              )}
                            </>
                          )}
                        </TableCell>
                        <TableCell>
                          <Link to={`/coach/detail/${row?.coachDetails._id}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo?.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo?.totalPages)}
                  page={Number(pageNo)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration message="No Pending Requests! " />
        )}
      </Paper>
    </>
  );
}
const capitalizeFirstLetter = (string: string) => {
  if (!string) return "E";
  return string.charAt(0).toUpperCase();
};
