/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from "react";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { useParams } from "react-router-dom";
import ResourceRender from "../components/ResourceRender";
import {
  Box,
  Button,
  Card,
  CircularProgress,
  Container,
  IconButton,
  Modal,
  Paper,
  Popover,
  TextField,
  Typography,
} from "@mui/material";
import { Controller, useForm } from "react-hook-form";
import CloseIcon from "@mui/icons-material/Close";
import { toast } from "react-toastify";
import EditIcon from "@mui/icons-material/Edit";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
import { UpdateResourceModal } from "./CoachResource";
import {
  ResourceDetails,
  ResourcesData,
  ResourcesModule_Type,
} from "../types/ResourcesType";
import { primaryButton } from "../utils/muibuttons";
import { MoreVert } from "@mui/icons-material";

const CoachResourceDetails = () => {
  const { resourceId } = useParams(); //resource id
  const [refresh, setRefresh] = useState<boolean>(false);
  const toggleRefresh = () => {
    setRefresh(!refresh);
  };
  const [openAddNewModal, setOpenAddNewModal] = useState<boolean>(false);
  const toggleOpenAddNew = (b: boolean) => {
    setOpenAddNewModal(b);
  };
  const [loading, setLoading] = useState<boolean>(false);
  const [data, setData] = useState<ResourceDetails | undefined>(undefined);
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.get(
        `${backendURL}/admin/resources/details/${resourceId}`
      );
      // console.log("sdfsdfsdfsdf", res.data.data);
      if (res.status === 200) {
        setData(res.data.data);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [refresh]);

  const [updateresourceId, setUpdateRes] = useState<string | null>(null);
  const [selectedData, setSelectedData] = useState<Pick<
    ResourcesData,
    "_id" | "title" | "description" | "availableFor"
  > | null>(null);

  const [openUpdateResModal, setOpenUpdateResModal] = useState<boolean>(false);
  const toggleOpenUpdateRes = (b: boolean) => {
    setOpenUpdateResModal(b);
  };

  const handleEdit = ({
    resourceId,
    title,
    description,
    availableFor,
  }: {
    resourceId: string;
    title: string;
    description: string;
    availableFor: "coach" | "coachee" | "all";
  }) => {
    console.log("Edit clicked", resourceId);
    setUpdateRes(resourceId);
    toggleOpenUpdateRes(true);
    setSelectedData({
      _id: resourceId,
      title,
      description,
      availableFor,
    });
  };

  const handleDelete = ({ id }: { id: string }) => {
    console.log(id);
    Swal.fire({
      title: "Are you sure?",
      text: "You want to remove this section?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, remove it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/coach/coach-resource/remove-resource/${id}`
        );
        console.log(response);
        if (response.status === 200) {
          Swal.fire({
            title: "Removed!",
            text: "The section has been removed.",
            icon: "success",
            timer: 1500,
          });
          toggleRefresh();
        } else {
          toast.error(
            "There was some error while removing the section, Please try again"
          );
        }
      }
    });
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <>
      {data ? (
        <Paper
          sx={{
            width: "100%",
            overflowY: "scroll",
            overflowX: "hidden",
            maxHeight: "calc(100vh - 90px)",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
              height: "auto",
              width: "100%",
            }}
          >
            {data && (
              <ResourceRender
                _id={data?._id}
                title={data?.title}
                description={data?.description}
                buttonShow={false}
                onEdit={() => {
                  toggleOpenUpdateRes(true);
                  handleEdit({
                    title: data.title,
                    description: data.description,
                    resourceId: data._id,
                    availableFor: data.availableFor,
                  });
                }}
                onDelete={() => {
                  resourceId && handleDelete({ id: resourceId });
                }}
              />
            )}
          </Box>
          <Box
            sx={{
              fontWeight: "bold",
              padding: "1rem 20px",
              width: "100%",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              height: "3rem",
            }}
          >
            <Typography
              variant="h6"
              sx={{
                fontWeight: "bold",
                color: "#013338",
              }}
            >
              Modules under this resource
            </Typography>
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
              }}
            >
              <Button
                sx={{ ...primaryButton, px: 3 }}
                onClick={() => toggleOpenAddNew(true)}
              >
                Add New
              </Button>
            </Box>
          </Box>
          <Box
            sx={{
              width: "100%",
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              gap: 3,
              pb: 7,
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "100%",
                gap: 2,
              }}
            >
              {data && data.modules?.length > 0 ? (
                data.modules.map((r, i) => (
                  <Section
                    key={i}
                    r={r}
                    id={resourceId}
                    refresh={toggleRefresh}
                  />
                ))
              ) : (
                <Container
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    height: "15rem",
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{ fontSize: "1rem", color: "#666" }}
                  >
                    No content added yet !
                  </Typography>
                </Container>
              )}
            </Box>
          </Box>
        </Paper>
      ) : (
        <>
          <Paper
            sx={{
              width: "100%",
              overflowY: "scroll",
              overflowX: "hidden",
              height: "100vh",
            }}
          >
            <Container
              sx={{
                height: "15rem",
                display: "flex",
                justifyContent: "Center",
                alignItems: "center",
              }}
            >
              <Typography variant="h6">Resource is not available</Typography>
            </Container>
          </Paper>
        </>
      )}
      {resourceId && (
        <AddNewModal
          open={openAddNewModal}
          toggle={toggleOpenAddNew}
          toggleRefresh={toggleRefresh}
          resourceId={resourceId}
        />
      )}
      {updateresourceId && selectedData && (
        <UpdateResourceModal
          open={openUpdateResModal}
          toggle={toggleOpenUpdateRes}
          toggleRefresh={toggleRefresh}
          title={selectedData.title}
          resourceId={updateresourceId}
          description={selectedData.description}
          availableFor={selectedData.availableFor}
        />
      )}
    </>
  );
};

export default CoachResourceDetails;

const AddNewModal = ({
  open,
  toggle,
  toggleRefresh,
  resourceId,
}: {
  open: boolean;
  resourceId: string;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
}) => {
  type FormValues = {
    title: string;
    description: string;
    image?: FileList | null;
    pdfFile?: FileList | null;
  };

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
    watch,
  } = useForm<FormValues>({});

  const ImageForm = watch("image");
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | undefined>();

  // Image preview
  useEffect(() => {
    if (ImageForm && ImageForm.length > 0) {
      const file = ImageForm[0];
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  }, [ImageForm]);

  const onSubmit = async (data: FormValues) => {
    const formData = new FormData();
    if (data.image) formData.append("image", data.image[0]);
    if (data.pdfFile) formData.append("pdf", data.pdfFile[0]);
    formData.append("title", data.title);
    formData.append("description", data.description);

    try {
      setLoading(true);
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/resources/add-module/${resourceId}`,
        formData
      );
      console.log(res);
      if (res.status === 200) {
        setImagePreview(undefined);
        toggleRefresh();
        toggle(false);
        reset();
        toast.success("Resource section added");
      }
    } catch (error: any) {
      console.error(error);
      toast.error(error?.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal open={open} sx={{ zIndex: 1200 }}>
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "80%", sm: "80%", md: 500 },
          maxHeight: "80vh",
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 3,
          borderRadius: 2,
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />
        <Typography variant="h6" sx={{ mb: 2, textAlign: "center" }}>
          Add Module
        </Typography>

        <form onSubmit={handleSubmit(onSubmit)}>
          <Box display="flex" flexDirection="column" gap={2}>
            {/* Title */}
            <Box>
              <Typography
                variant="body1"
                color={errors.title ? "error" : "textPrimary"}
              >
                Title
              </Typography>

              <Controller
                name="title"
                control={control}
                rules={{
                  required: "Title is required",
                  maxLength: {
                    value: 60,
                    message: "Title can have most 60 Characters",
                  },
                  minLength: {
                    value: 10,
                    message: "Title must have atleast 10 Characters",
                  },
                }}
                defaultValue=""
                render={({ field }) => (
                  <TextField
                    {...field}
                    fullWidth
                    helperText={errors.title?.message}
                    error={!!errors.title}
                  />
                )}
              ></Controller>
            </Box>

            {/* Description */}
            <Box>
              <Typography
                variant="body1"
                color={errors.description ? "error" : "textPrimary"}
              >
                Description
              </Typography>
              <Controller
                name="description"
                control={control}
                rules={{
                  required: "Description is required",
                  validate: (value) => {
                    const stripped = value.replace(/<[^>]*>/g, "").trim();
                    return stripped.length > 0 || "Description cannot be empty";
                  },
                  maxLength: {
                    value: 1200,
                    message: "Description can have most 1200 Characters",
                  },
                  minLength: {
                    value: 10,
                    message: "Description must have atleast 10 Characters",
                  },
                }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    fullWidth
                    multiline
                    maxRows={6}
                    helperText={errors.description?.message}
                    error={!!errors.description}
                  />
                )}
              />
            </Box>
            {/* Image Upload */}
            <Box>
              <Typography variant="body1">Image</Typography>
              <Box
                sx={{
                  position: "relative",
                  width: "100%",
                  height: 200,
                  bgcolor: "#e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                }}
              >
                {imagePreview ? (
                  <img
                    src={imagePreview}
                    alt="Preview"
                    style={{
                      objectFit: "contain",
                      width: "100%",
                      height: "100%",
                    }}
                  />
                ) : (
                  <Box
                    sx={{
                      width: "100%",
                      height: "100%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#666",
                    }}
                  >
                    Image
                  </Box>
                )}
                <input
                  accept="image/*"
                  type="file"
                  id="upload-image"
                  style={{ display: "none" }}
                  {...register("image")}
                />
                <label htmlFor="upload-image">
                  <IconButton
                    sx={{
                      position: "absolute",
                      bottom: 8,
                      right: 8,
                      bgcolor: "white",
                      ":hover": { bgcolor: "white" },
                    }}
                    component="span"
                  >
                    <EditIcon color="primary" />
                  </IconButton>
                </label>
              </Box>
            </Box>
            <Box>
              <Typography variant="body1" color="textPrimary">
                PDF
              </Typography>
              <input
                accept="application/pdf"
                type="file"
                {...register("pdfFile", {})}
              />
            </Box>

            {/* Submit */}
            <Box textAlign="center" mt={2}>
              <Button
                variant="contained"
                type="submit"
                sx={{ px: 4 }}
                disabled={loading}
              >
                {loading ? <CircularProgress size={24} /> : "Submit"}
              </Button>
            </Box>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

const Section = ({
  key,
  r,
  id,
  refresh,
}: {
  key: number;
  r: ResourcesModule_Type;
  id: string | undefined;
  refresh: () => void;
}) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [editSection, setEditSection] = useState<string | null>(null);
  // Open popper for options
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setEditSection(id ? id : null);
  };

  // Close popper
  const handleClose = () => {
    setAnchorEl(null);
    setEditSection(null);
  };

  const handleClickDelete = ({ id }: { id: string }) => {
    console.log(id);
    Swal.fire({
      title: "Are you sure?",
      text: "You want to remove this section?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, remove it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/resources/remove-module/${id}`
        );
        console.log(response);
        if (response.status === 200) {
          Swal.fire({
            title: "Removed!",
            text: "The section has been removed.",
            icon: "success",
            timer: 1500,
          });
          refresh();
        } else {
          toast.error(
            "There was some error while removing the section, Please try again"
          );
        }
      }
    });
  };

  const handleClickEdit = () => {
    toggleOpenUpdateSection(true);
  };

  const [openUpdateModuleModal, setopenUpdateModuleModal] =
    useState<boolean>(false);

  const toggleOpenUpdateSection = (b: boolean) => {
    setopenUpdateModuleModal(b);
  };

  return (
    <>
      <UpdateModuleModal
        description={r.description}
        image={r.thumbnailImage}
        title={r.title}
        pdfFile={r.pdfFile}
        moduleId={r._id}
        toggle={toggleOpenUpdateSection}
        toggleRefresh={refresh}
        open={openUpdateModuleModal}
      />
      <Box
        key={key}
        sx={{
          width: "100%",
          px: 3,
          pt: 2,
          position: "relative",
        }}
      >
        <Card
          sx={{
            width: "100%",
            p: 3,
            borderRadius: 2,
            border: editSection ? "1px solid #3aa7a3" : "1px solid #013338",
            position: "relative",
          }}
        >
          {/* Edit Icon */}
          <IconButton
            onClick={handleClick}
            sx={{
              position: "absolute",
              top: 8,
              right: 8,
              zIndex: 1,
            }}
          >
            <MoreVert sx={{ color: "#3aa7a3" }} />
          </IconButton>

          {/* Popover for Edit/Delete */}
          <Popover
            open={Boolean(anchorEl)}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
          >
            <Box sx={{ p: 1 }}>
              <Typography
                variant="body2"
                onClick={() => {
                  handleClickEdit();
                  handleClose();
                }}
                sx={{ cursor: "pointer", color: "#1976d2", mb: 1 }}
              >
                Edit
              </Typography>
              <Typography
                variant="body2"
                onClick={() => {
                  handleClickDelete({ id: r._id });
                  handleClose();
                }}
                sx={{ cursor: "pointer", color: "#d32f2f" }}
              >
                Delete
              </Typography>
            </Box>
          </Popover>

          {/* Title */}
          <Typography
            variant="h6"
            sx={{ fontWeight: "bold", color: "#013338", mb: 1 }}
          >
            {r.title}
          </Typography>
          {/* Image Display */}
          {r.thumbnailImage && (
            <Box
              sx={{
                mt: 2,
                mb: 2,
                borderRadius: 2,
                overflow: "hidden",
                maxHeight: 300,
                textAlign: "center",
                backgroundColor: "#fafafa",
              }}
            >
              <img
                src={`${backendURL}/resourceFiles/${r.thumbnailImage}`}
                alt="Section Image"
                style={{
                  maxWidth: "100%",
                  maxHeight: "100%",
                  objectFit: "contain",
                }}
              />
            </Box>
          )}
          <Box
            sx={{
              mb: 2,
              "& p": { m: 0 },
              "& ul": { pl: 2 },
            }}
          >
            <Typography
              variant="body1"
              sx={{ fontSize: "1rem", color: "#666" }}
            >
              {r.description}
            </Typography>
          </Box>
          {/* PDF File Display */}
          {r.pdfFile && (
            <Box sx={{ mt: 2 }}>
              <Typography
                variant="body2"
                sx={{ fontWeight: 600, mb: 1, color: "#013338" }}
              >
                Attached PDF:
              </Typography>
              <a
                href={`${backendURL}/resourceFiles/${r.pdfFile}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  color: "#3aa7a3",
                  textDecoration: "underline",
                  wordBreak: "break-word",
                }}
              >
                {r.pdfFile}
              </a>
            </Box>
          )}
        </Card>
      </Box>
    </>
  );
};
type Props = {
  open: boolean;
  moduleId: string;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
  description: string;
  title: string;
  image?: string;
  pdfFile?: string;
};

const UpdateModuleModal = ({
  open,
  toggle,
  toggleRefresh,
  moduleId,
  description,
  title,
  image,
  pdfFile,
}: Props) => {
  type FormValues = {
    title: string;
    description: string;
    image?: FileList | null;
    pdfFile?: FileList | null;
  };

  const {
    control,
    handleSubmit,
    register,
    formState: { errors },
    reset,
    watch,
    setValue,
  } = useForm<FormValues>({
    defaultValues: {
      title: title || "",
      description: description || "",
    },
  });
  const imageWatch = watch("image");
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | undefined>(
    undefined
  );

  useEffect(() => {
    if (imageWatch && imageWatch.length > 0) {
      const file = imageWatch[0];
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  }, [imageWatch]);

  useEffect(() => {
    setValue("description", description);
    setValue("title", title);
    if (image) {
      setImagePreview(`${backendURL}/resourceFiles/${image}`);
    }
  }, [description, title, image]);

  const onSubmit = async (data: FormValues) => {
    const formData = new FormData();
    formData.append("title", data.title);
    formData.append("description", data.description);
    if (data.image) formData.append("image", data.image[0]);
    if (data.pdfFile) formData.append("pdf", data.pdfFile[0]);
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/resources/update-module/${moduleId}`,
        formData
      );

      if (res.status === 200) {
        toggleRefresh();
        toggle(false);
        reset();
        toast.success("Module updated successfully!");
        setImagePreview(undefined);
      }
    } catch (error: any) {
      console.error(error);
      toast.error("Failed to update module");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal open={open} sx={{ zIndex: 1200 }}>
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "80%", sm: "80%", md: 500 },
          maxHeight: "80vh",
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 3,
          borderRadius: 2,
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />
        <Typography variant="h6" sx={{ mb: 2, textAlign: "center" }}>
          Update Module
        </Typography>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Box display="flex" flexDirection="column" gap={2}>
            <Box>
              <Typography
                variant="body1"
                color={errors.title ? "error" : "textPrimary"}
              >
                Title
              </Typography>

              <Controller
                name="title"
                control={control}
                rules={{
                  required: "Title is required",
                  maxLength: {
                    value: 60,
                    message: "Title can have most 60 Characters",
                  },
                  minLength: {
                    value: 10,
                    message: "Title must have atleast 10 Characters",
                  },
                }}
                defaultValue=""
                render={({ field }) => (
                  <TextField
                    {...field}
                    fullWidth
                    helperText={errors.title?.message}
                    error={!!errors.title}
                  />
                )}
              ></Controller>
            </Box>

            {/* Description */}
            <Box>
              <Typography
                variant="body1"
                color={errors.description ? "error" : "textPrimary"}
              >
                Description
              </Typography>
              <Controller
                name="description"
                control={control}
                rules={{
                  required: "Description is required",
                  validate: (value) => {
                    const stripped = value.replace(/<[^>]*>/g, "").trim();
                    return stripped.length > 0 || "Description cannot be empty";
                  },
                  maxLength: {
                    value: 1200,
                    message: "Description can have most 1200 Characters",
                  },
                  minLength: {
                    value: 10,
                    message: "Description must have atleast 10 Characters",
                  },
                }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    fullWidth
                    multiline
                    maxRows={6}
                    helperText={errors.description?.message}
                    error={!!errors.description}
                  />
                )}
              />
            </Box>
            <Box>
              <Typography variant="body1" color="textPrimary">
                Upload Image
              </Typography>
              <Box
                sx={{
                  position: "relative",
                  width: "100%",
                  height: 200,
                  bgcolor: "#e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                }}
              >
                {imagePreview ? (
                  <img
                    src={imagePreview}
                    alt="Preview"
                    style={{
                      objectFit: "contain",
                      width: "100%",
                      height: "100%",
                    }}
                  />
                ) : (
                  <Box
                    sx={{
                      width: "100%",
                      height: "100%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#666",
                    }}
                  >
                    Upload Image
                  </Box>
                )}
                <input
                  accept="image/*"
                  type="file"
                  id="upload-image"
                  style={{ display: "none" }}
                  {...register("image")}
                />
                <label htmlFor="upload-image">
                  <IconButton
                    sx={{
                      position: "absolute",
                      bottom: 8,
                      right: 8,
                      bgcolor: "white",
                      ":hover": { bgcolor: "white" },
                    }}
                    component="span"
                  >
                    <EditIcon color="primary" />
                  </IconButton>
                </label>
              </Box>
            </Box>
            <Box>
              <Typography variant="body1" color="textPrimary">
                Update PDF {`${pdfFile}`}
              </Typography>
              <input
                accept="application/pdf"
                type="file"
                {...register("pdfFile")}
              />
              {errors.pdfFile && (
                <Typography color="error" variant="body2">
                  {errors.pdfFile.message}
                </Typography>
              )}
            </Box>

            {/* Submit */}
            <Box textAlign="center" mt={2}>
              <Button
                variant="contained"
                type="submit"
                sx={{ px: 4 }}
                disabled={loading}
              >
                {loading ? <CircularProgress size={24} /> : "Submit"}
              </Button>
            </Box>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};
