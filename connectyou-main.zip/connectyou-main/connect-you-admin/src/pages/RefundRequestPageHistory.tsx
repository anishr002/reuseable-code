import VisibilityIcon from "@mui/icons-material/Visibility";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import {
  Box,
  FormControl,
  MenuItem,
  Pagination,
  Select,
  TableCell,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import { Link } from "react-router-dom";
import dayjs from "dayjs";
import { Refund_Req_data } from "./RefundRequestPage";
import PageHeader from "../components/PageHeader";

export default function RefundRequestPageHistory() {
  const [data, setTransactions] = React.useState<Refund_Req_data[]>([]);

  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);

  const [filterTerm, setFilterTerm] = React.useState<number>(3); // 0 for pending req, // 1 for approved req // 2 for deniend req // 3 all
  const handleChangeFilter = (event: any) => {
    setFilterTerm(event.target.value);
    setPageNo(1);
  };
  const fetchRefundRequests = async (filterType = 3, page = 1, limit = 10) => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/refunds/fetch-request-list`,
        {
          params: {
            filter: filterType, // 0 = all, 1 = approved, 2 = denied
            page, // Current page number
            limit, // Number of items per page
            type: "history",
          },
        }
      );
      if (response.status === 200) {
        const { transactions, totalPages } = response.data;
        setTransactions(transactions);
        setPageInfo({
          currentPage: pageNo,
          totalPages: totalPages,
        });
      }
    } catch (error) {
      console.error("Error fetching balance and transactions:", error);
    } finally {
      setLoading(false);
    }
  };
  React.useEffect(() => {
    fetchRefundRequests(filterTerm, pageNo, 20);
  }, [pageNo, filterTerm]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${data.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <PageHeader>
          <div
            style={{
              position: "relative",
              display: "flex",
            }}
          >
            Refund History
          </div>

          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            >
              <Select
                displayEmpty
                size="small"
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={filterTerm}
                onChange={handleChangeFilter}
                sx={{
                  color: "#013338",
                  borderColor: "#013338",
                  fontSize: "0.775rem",
                  "& .MuiSelect-icon": {
                    color: "#013338", // Set the color of the dropdown icon
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#013338", // Set border color
                  },
                }}
              >
                <MenuItem sx={{ fontSize: "0.775rem" }} value={3}>
                  <em>All</em>
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                  Approved
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                  Declined
                </MenuItem>
              </Select>
            </FormControl>
          </Box>
        </PageHeader>
        {data?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 210px)",
                overflow: "auto",
                minWidth: "fit-content",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Coachee Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email Address
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Amount
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Requested on
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Details
                    </TableCell>

                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Status
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-word" },
                          }}
                        >
                          {row.userData.name}
                        </TableCell>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-all" },
                          }}
                        >
                          {row.userData.email}
                        </TableCell>
                        <TableCell>
                          {(Number(row.amount) / 100).toFixed(2)}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {row?.createdAt
                            ? dayjs(row?.createdAt).format("DD-MM-YYYY hh:mm A")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <Link to={`/refunds/details/${row?._id}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                        <TableCell>
                          <span
                            style={{
                              color: "white",
                              background:
                                row.refund_status === 0
                                  ? "#ebbe34"
                                  : row.refund_status === 1
                                    ? "#3aa7a3"
                                    : "red",
                              padding: "5px 10px",
                              borderRadius: "22px",
                            }}
                          >
                            {row.refund_status === 0
                              ? "Pending"
                              : row.refund_status === 1
                                ? "Approved"
                                : "Declined"}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo?.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo?.totalPages)}
                  page={Number(pageNo)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration message="No Refund history present! " />
        )}
      </Paper>
    </>
  );
}
