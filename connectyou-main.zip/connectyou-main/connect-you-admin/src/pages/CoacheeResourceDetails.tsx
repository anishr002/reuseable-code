import React, { useEffect, useState } from "react";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { useParams } from "react-router-dom";
import ResourceRender from "../components/ResourceRender";
import {
  Box,
  Button,
  CircularProgress,
  Container,
  IconButton,
  Modal,
  Paper,
  Popover,
  Typography,
} from "@mui/material";
import { Controller, useForm } from "react-hook-form";
import ReactQuill from "react-quill";
import CloseIcon from "@mui/icons-material/Close";
import { toast } from "react-toastify";
import EditIcon from "@mui/icons-material/Edit";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
const primaryButton = {
  p: 0,
  color: "white",
  backgroundColor: "#EBBE34",
  borderColor: "#EBBE34",
  borderRadius: "20px",
  fontFamily: "Montserrat",
  mx: "auto",
  "&:hover": {
    borderColor: "white",
    backgroundColor: "white",
    color: "#EBBE34",
  },
};
interface resource_sections_data {
  _id: string;
  description: string;
  image: string;
}
interface Data {
  _id: string;
  title: string;
  description: string;
  resource_sections_data: resource_sections_data[];
}
const CoacheeResourceDetails = () => {
  const { resourceId } = useParams(); //resource id

  const [refresh, setRefresh] = useState<boolean>(false);
  const toggleRefresh = () => {
    setRefresh(!refresh);
  };
  const [openAddNewModal, setOpenAddNewModal] = useState<boolean>(false);
  const toggleOpenAddNew = (b: boolean) => {
    setOpenAddNewModal(b);
  };
  const [loading, setLoading] = useState<boolean>(false);
  const [data, setData] = useState<Data>();
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.get(
        `${backendURL}/admin/user/user-resource/details/${resourceId}`
      );
      if (res.status === 200) {
        setData(res.data.data);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [refresh]);

  const [updateresourceId, setUpdateRes] = useState<string | null>(null);
  const [selectedData, setSelectedData] = useState({
    _id: "",
    title: "",
    description: "",
  });
  const [openUpdateResModal, setOpenUpdateResModal] = useState<boolean>(false);
  const toggleOpenUpdateRes = (b: boolean) => {
    setOpenUpdateResModal(b);
  };
  const handleEdit = ({
    resourceId,
    title,
    description,
  }: {
    resourceId: string;
    title: string;
    description: string;
  }) => {
    console.log("Edit clicked", resourceId);
    setUpdateRes(resourceId);
    toggleOpenUpdateRes(true);
    setSelectedData({
      _id: resourceId,
      title,
      description,
    });
  };
  const handleDelete = ({ id }: { id: string }) => {
    console.log(id);
    Swal.fire({
      title: "Are you sure?",
      text: "You want to remove this section?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, remove it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/user/user-resource/remove-resource/${id}`
        );
        console.log(response);
        if (response.status === 200) {
          Swal.fire({
            title: "Removed!",
            text: "The section has been removed.",
            icon: "success",
            timer: 1500,
          });
          toggleRefresh();
        } else {
          toast.error(
            "There was some error while removing the section, Please try again"
          );
        }
      }
    });
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <>
      {data ? (
        <Paper
          sx={{
            width: "100%",
            overflowY: "scroll",
            overflowX: "hidden",
            maxHeight: "calc(100vh - 90px)",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
              height: "auto",
              width: "100%",
            }}
          >
            {data && (
              <ResourceRender
                _id={data?._id}
                title={data?.title}
                description={data?.description}
                buttonShow={false}
                onEdit={() => {
                  toggleOpenUpdateRes(true);
                  handleEdit({
                    title: data.title,
                    description: data.description,
                    resourceId: data._id,
                  });
                }}
                onDelete={() => {
                  resourceId && handleDelete({ id: resourceId });
                }}
              />
            )}
          </Box>
          <Box
            sx={{
              fontWeight: "bold",
              padding: "1rem 20px",
              width: "100%",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              height: "3rem",
            }}
          >
            <Typography
              variant="h6"
              sx={{
                fontWeight: "bold",
                color: "#013338",
              }}
            >
              Sections
            </Typography>
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
              }}
            >
              <Button
                sx={{ ...primaryButton, px: 3 }}
                onClick={() => toggleOpenAddNew(true)}
              >
                Add New
              </Button>
            </Box>
          </Box>
          <Box
            sx={{
              width: "100%",
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              gap: 3,
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "100%",
                gap: 2,
              }}
            >
              {data && data.resource_sections_data?.length > 0 ? (
                data.resource_sections_data.map((r, i) => (
                  <Section
                    key={i}
                    r={r}
                    id={resourceId}
                    refresh={toggleRefresh}
                  />
                ))
              ) : (
                <Container
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    height: "15rem",
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{ fontSize: "1rem", color: "#666" }}
                  >
                    No content added yet !
                  </Typography>
                </Container>
              )}
            </Box>
          </Box>
        </Paper>
      ) : (
        <>
          <Paper
            sx={{
              width: "100%",
              overflowY: "scroll",
              overflowX: "hidden",
              height: "100vh",
            }}
          >
            <Container
              sx={{
                height: "15rem",
                display: "flex",
                justifyContent: "Center",
                alignItems: "center",
              }}
            >
              <Typography variant="h6">Resource is not available</Typography>
            </Container>
          </Paper>
        </>
      )}
      {resourceId && (
        <AddNewModal
          open={openAddNewModal}
          toggle={toggleOpenAddNew}
          toggleRefresh={toggleRefresh}
          resourceId={resourceId}
        />
      )}
      {updateresourceId && (
        <UpdateResourceModal
          open={openUpdateResModal}
          toggle={toggleOpenUpdateRes}
          toggleRefresh={toggleRefresh}
          title={selectedData.title}
          resourceId={updateresourceId}
          description={selectedData.description}
        />
      )}
    </>
  );
};

export default CoacheeResourceDetails;

const modules = {
  toolbar: [
    [
      { header: "1" },
      { header: "2" },
      { header: "3" },
      { font: ["Montserrat"] },
      { size: ["small", false, "large", "huge"] },
    ],
    [{ list: "ordered" }, { list: "bullet" }],
    ["bold", "italic", "underline", "strike"],
    ["link"],
    [{ align: [] }],
    [{ direction: "rtl" }],
    [{ indent: "-1" }, { indent: "+1" }],
    [{ color: [] }, { background: [] }],
    ["clean"],
  ],
};

const formats = [
  "header",
  "font",
  "size",
  "list",
  "bullet",
  "ordered",
  "check",
  "bold",
  "italic",
  "underline",
  "link",
  "strike",
  "align",
  "direction",
  "indent",
  "color",
  "background",
  "clean",
];

const AddNewModal = ({
  open,
  toggle,
  toggleRefresh,
  resourceId,
}: {
  open: boolean;
  resourceId: string;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
}) => {
  type FormValues = {
    image: FileList | null;
    description: string;
  };
  const {
    control,
    handleSubmit,
    register,
    formState: { errors },
    reset,
    watch,
  } = useForm<FormValues>({});
  const ImageForm = watch("image");
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = React.useState<string | undefined>(
    undefined
  );
  //handle front image priviews
  React.useEffect(() => {
    if (ImageForm && ImageForm.length > 0) {
      const file = ImageForm[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, [ImageForm]);
  const onSubmit = async (data: any) => {
    const formData = new FormData();
    if (data.image) {
      formData.append("image", data.image[0]);
    }
    setLoading(true);
    formData.append("description", data.description);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/user/user-resource/add-section/${resourceId}`,
        formData
      );
      if (res.status === 200) {
        setImagePreview(undefined);
        toggleRefresh();
        toggle(false);
        reset();
        return toast.success("Resource section added");
      }
    } catch (error: any) {
      console.log(error);
      return toast.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: 300, sm: 450, md: "90%" },
          maxHeight: { xs: 450, md: "80%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Description and Image
        </Typography>

        <form onSubmit={handleSubmit(onSubmit)}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 1,
              }}
            >
              {/* Description Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  width: "80%",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Description {errors.description && "is required"}
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>

              {/* image Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  width: "20%",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.image ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Image {errors.image && "is required"}
                </Typography>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    width: "100%",
                    position: "relative",
                    height: "200px", // Add a fixed height to the image area
                    backgroundColor: imagePreview ? "transparent" : "#e0e0e0", // Placeholder background color when no image
                  }}
                >
                  {imagePreview ? (
                    <img
                      src={imagePreview}
                      alt="User"
                      className="bg-center bg-contain w-full"
                      style={{
                        objectFit: "contain",
                        maxHeight: "100%",
                        maxWidth: "100%",
                      }}
                    />
                  ) : (
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        width: "100%",
                        height: "100%",
                        backgroundColor: "#e0e0e0", // Placeholder background color
                        borderRadius: "8px", // Optional: rounding the corners of the placeholder
                      }}
                    >
                      <Typography variant="body2" color="textSecondary">
                        Upload Image
                      </Typography>
                    </Box>
                  )}
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      position: "absolute",
                      bottom: 0,
                      right: 0,
                      borderRadius: "50%",
                      backgroundColor: "red",
                    }}
                  >
                    <input
                      accept=".jpg, .png"
                      style={{ display: "none" }}
                      id="icon-button-file2"
                      type="file"
                      {...register("image")}
                    />
                    <label htmlFor="icon-button-file2">
                      <IconButton
                        color="primary"
                        aria-label="upload picture"
                        component="span"
                      >
                        <EditIcon
                          style={{ fontSize: "1.5rem", color: "#3aa7a3" }}
                        />
                      </IconButton>
                    </label>
                  </Box>
                </Box>
              </Box>
            </Box>
            <Box sx={{ textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3, zIndex: "1400" }}
                type="submit"
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  "Submit"
                )}
              </Button>
            </Box>
          </Box>
          {/* Submit Button */}
        </form>
      </Box>
    </Modal>
  );
};

const UpdateResourceModal = ({
  open,
  toggle,
  toggleRefresh,
  resourceId,
  title,
  description,
}: {
  open: boolean;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
  resourceId: string;
  title: string;
  description: string;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    defaultValues: {
      title: "",
      description: "",
    },
    mode: "onChange",
  });
  useEffect(() => {
    console.log(title, description);
    setValue("title", title);
    setValue("description", description);
  }, [title, description, setValue]);

  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: { title: string; description: string }) => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/user/user-resource/update-resource/${resourceId}`,
        data
      );
      if (res.status === 200) {
        toggleRefresh();
        toggle(false);
        reset();
        return toast.success("Coachee resource Updated");
      }
    } catch (error) {
      console.log(error);
      toast.error("Some error while updating resource");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: 300, sm: 450, md: "80%" },
          maxHeight: { xs: 450, md: "80%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Update Title and Description
        </Typography>

        {!loading ? (
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              {/* title Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.title ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Title {errors.title && "is required"}
                </Typography>
                <Controller
                  name="title"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>
              {/* Description Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Description {errors.description && "is required"}
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null} // React Hook Form manages refs
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px", zIndex: "1300" }}
                    />
                  )}
                />
              </Box>
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 2, textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3 }}
                type="submit"
              >
                Update
              </Button>
            </Box>
          </form>
        ) : (
          <>
            <Paper
              elevation={0}
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "10rem",
                background: "transparent",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Paper>
          </>
        )}
      </Box>
    </Modal>
  );
};

const Section = ({
  key,
  r,
  id,
  refresh,
}: {
  key: number;
  r: resource_sections_data;
  id: string | undefined;
  refresh: () => void;
}) => {
  const renderSavedContent = (savedContent: string | TrustedHTML) => {
    return (
      <div
        style={{ fontFamily: "Montserrat, sans-serif" }}
        dangerouslySetInnerHTML={{
          __html: savedContent,
        }}
      />
    );
  };

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [editSection, setEditSection] = useState<string | null>(null);

  // Open popper for options
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setEditSection(id ? id : null);
  };

  // Close popper
  const handleClose = () => {
    setAnchorEl(null);
    setEditSection(null);
  };

  const handleClickDelete = ({ id }: { id: string }) => {
    console.log(id);
    Swal.fire({
      title: "Are you sure?",
      text: "You want to remove this section?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, remove it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/user/user-resource/remove-section/${id}`
        );
        console.log(response);
        if (response.status === 200) {
          Swal.fire({
            title: "Removed!",
            text: "The section has been removed.",
            icon: "success",
            timer: 1500,
          });
          refresh();
        } else {
          toast.error(
            "There was some error while removing the section, Please try again"
          );
        }
      }
    });
  };

  const handleClickEdit = () => {
    toggleOpenUpdateSection(true);
  };

  const [openUpdateSectionModal, setopenUpdateSectionModal] =
    useState<boolean>(false);

  const toggleOpenUpdateSection = (b: boolean) => {
    setopenUpdateSectionModal(b);
  };
  const UpdateSectionModal = ({
    open,
    toggle,
    toggleRefresh,
    sectionId,
    description,
    image,
  }: {
    open: boolean;
    sectionId: string;
    toggle: (b: boolean) => void;
    toggleRefresh: () => void;
    description: string;
    image: string;
  }) => {
    type FormValues = {
      newimage: FileList | null;
      description: string;
    };
    const {
      control,
      handleSubmit,
      register,
      formState: { errors },
      reset,
      watch,
      setValue,
    } = useForm<FormValues>({});

    React.useEffect(() => {
      setValue("description", description);
    }, [description]);

    const ImageForm = watch("newimage");
    const [loading, setLoading] = useState(false);
    const [imagePreview, setImagePreview] = React.useState<string | undefined>(
      undefined
    );
    //handle front image priviews
    React.useEffect(() => {
      if (ImageForm && ImageForm.length > 0) {
        const file = ImageForm[0];
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result as string);
        };
        reader.readAsDataURL(file);
      }
    }, [ImageForm]);
    const onSubmit = async (data: any) => {
      const formData = new FormData();
      if (data.newimage) {
        formData.append("image", data.newimage[0]);
      }
      setLoading(true);
      formData.append("description", data.description);
      try {
        const res = await httpAPI_admin.post(
          `${backendURL}/admin/user/user-resource/update-section/${sectionId}`,
          formData
        );
        if (res.status === 200) {
          setImagePreview(undefined);
          toggleRefresh();
          toggle(false);
          reset();
          return toast.success("Resource section Updated");
        }
      } catch (error: any) {
        console.log(error);
        return toast.error(error);
      } finally {
        setLoading(false);
      }
    };

    return (
      <Modal
        sx={{ zIndex: "1200" }}
        open={open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: 300, sm: 450, md: "90%" },
            maxHeight: { xs: 450, md: "80%" },
            overflow: "auto",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 3,
            borderRadius: 2,
          }}
        >
          {/* Close Icon */}
          <CloseIcon
            onClick={() => {
              reset();
              toggle(false);
            }}
            style={{
              cursor: "pointer",
              position: "absolute",
              right: 15,
              top: 15,
            }}
          />

          {/* Modal Title */}
          <Typography
            variant="h6"
            component="h2"
            sx={{
              mb: 3,
              width: "100%",
              textAlign: "center",
            }}
          >
            Update Description and Image
          </Typography>

          {/* Form */}
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Description and Image Inputs */}
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 3,
              }}
            >
              {/* Description Input */}
              <Box>
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "text.primary",
                    fontWeight: 500,
                  }}
                >
                  Description {errors.description && "is required"}
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: true,
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                  }}
                  render={({ field }) => (
                    <ReactQuill
                      {...field}
                      ref={null}
                      modules={modules}
                      formats={formats}
                      placeholder="Write here..."
                      style={{ marginTop: "10px" }}
                    />
                  )}
                />
              </Box>

              {/* Image Input */}
              <Box>
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.newimage ? "red" : "text.primary",
                    fontWeight: 500,
                  }}
                >
                  Image {errors.newimage && "is required"}
                </Typography>
                <label htmlFor="icon-button-file2">
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      width: "100%",
                      height: 200,
                      position: "relative",
                      backgroundColor: imagePreview ? "transparent" : "#e0e0e0",
                      borderRadius: 2,
                      overflow: "hidden",
                    }}
                  >
                    {imagePreview ? (
                      <img
                        src={imagePreview}
                        alt="Preview"
                        style={{
                          objectFit: "contain",
                          maxHeight: "100%",
                          maxWidth: "100%",
                        }}
                      />
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          width: "100%",
                          height: "100%",
                          background: image
                            ? `url(${backendURL}/resourcesImage/${image})`
                            : "lightgray",
                          backgroundPosition: "center",
                          backgroundRepeat: "no-repeat",
                          backgroundSize: "contain",
                        }}
                      >
                        {!image && (
                          <Typography variant="body1">Upload image</Typography>
                        )}
                      </Box>
                    )}
                    <Box
                      sx={{
                        position: "absolute",
                        bottom: 8,
                        right: 8,
                        backgroundColor: "white",
                        borderRadius: "50%",
                        boxShadow: 1,
                      }}
                    >
                      <input
                        accept=".jpg, .png"
                        style={{ display: "none" }}
                        id="icon-button-file2"
                        type="file"
                        {...register("newimage")}
                      />
                      <IconButton
                        color="primary"
                        aria-label="upload picture"
                        component="span"
                      >
                        <EditIcon />
                      </IconButton>
                    </Box>
                  </Box>
                </label>
              </Box>
            </Box>

            {/* Submit Button */}
            <Box sx={{ textAlign: "center", mt: 4 }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 5 }}
                type="submit"
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  "Submit"
                )}
              </Button>
            </Box>
          </form>
        </Box>
      </Modal>
    );
  };

  return (
    <>
      <UpdateSectionModal
        description={r.description}
        image={r.image}
        sectionId={r._id}
        toggle={toggleOpenUpdateSection}
        toggleRefresh={refresh}
        open={openUpdateSectionModal}
      />
      <Box
        key={key}
        sx={{
          width: "100%",
          p: 3,
          position: "relative",
          background: editSection === id ? "#e1e2e3" : "white",
        }}
      >
        <IconButton
          onClick={handleClick}
          sx={{
            position: "absolute", // Fix the position of the button
            top: 0, // Align at the top of the container
            right: 0, // Align at the right of the container
            zIndex: 1, // Ensure it's above the content
          }}
        >
          <EditIcon sx={{ color: "#3f51b5" }} />
        </IconButton>
        <Popover
          open={Boolean(anchorEl)}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "right",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
        >
          <Box sx={{ p: 1 }}>
            <Typography
              variant="body2"
              onClick={() => {
                handleClickEdit();
                handleClose();
              }}
              sx={{ cursor: "pointer", color: "#1976d2", mb: 1 }}
            >
              Edit
            </Typography>
            <Typography
              variant="body2"
              onClick={() => {
                handleClickDelete({ id: r._id });
                handleClose();
              }}
              sx={{ cursor: "pointer", color: "#d32f2f" }}
            >
              Delete
            </Typography>
          </Box>
        </Popover>
        <Typography
          variant="h6"
          sx={{
            fontSize: "1.2rem",
            fontWeight: "bold",
            marginBottom: "0.5rem",
            color: "blue",
          }}
        >
          Section {key}
        </Typography>
        <Box
          key={key}
          sx={{
            width: "100%",
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
          }}
        >
          <Box
            key={key}
            sx={{
              width: { xs: "100%", md: r.image ? "60%" : "100%" },
              display: "flex",
              px: "10px",
            }}
          >
            {renderSavedContent(r.description)}
          </Box>
          {r.image != "" && (
            <Box
              key={key}
              sx={{
                width: { xs: "100%", md: "40%" },
                display: "flex",
                height: "fit",
              }}
            >
              <img
                src={`${backendURL}/resourcesImage/${r.image}`}
                alt={`Section ${key + 1}`}
                style={{
                  width: "100%",
                  maxWidth: "300px",
                  height: "auto",
                  marginTop: "1rem",
                  margin: "auto",
                  borderRadius: "8px",
                }}
              />
            </Box>
          )}
        </Box>
      </Box>
    </>
  );
};
