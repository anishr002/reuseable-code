import ReactDOM from "react-dom/client";
import * as React from "react";
import Paper from "@mui/material/Paper";
import {
  Avatar,
  Box,
  Switch,
  Typography,
  Chip,
  Card,
  CardContent,
  Grid,
  TextField,
  Tooltip,
  Drawer,
  IconButton,
  Badge,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import { Rating } from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
import DeleteIcon from "@mui/icons-material/Delete";
import { useNavigate, useParams } from "react-router-dom";
import InfoIcon from "@mui/icons-material/Info";
import CloseIcon from "@mui/icons-material/Close";
import CoachProProgress from "../components/CoachProProgress";
import { Cancel } from "@mui/icons-material";
import FilePreview from "../components/FilePreview";
import ShortlistCoachToCompany from "../components/UI/ShortlistCoachToCompany";
const label = { inputProps: { "aria-label": "Switch demo" } };

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});

export default function CoachDetails() {
  const { coachId } = useParams(); //coach id
  const navigate = useNavigate();
  interface CoachcredentialsListType {
    _id: string;
    title: string;
    image: string;
    workingOn: string;
    startDate: string;
    endDate: string;
  }

  interface CoachExperienceListType {
    _id: string;
    organization: string;
    position: string;
    workingOn: string;
    startDate: string;
    endDate: string;
  }

  interface CoachEducationListType {
    _id: string;
    organization: string;
    degree: string;
    startDate: string;
    endDate: string;
  }

  interface CoachCertificateListType {
    _id: string;
    title: string;
    certificateFile: string;
  }

  interface RatingDataType {
    name: string;
    image: string;
    message: string;
    createdAt: string;
    ratingNumber: number;
  }

  // Updated Initial State
  const [data, setData] = React.useState<Row>({
    _id: "",
    block: 1,
    name: "",
    Lname: "",
    userName: "",
    gender: "",
    DOB: "",
    email: "",
    image: "",
    freeTrial: "",
    about_me: "",
    title_line: "",
    languages: [],
    industries: [],
    coachingSpecialities: [],
    coachingExperience: "",
    city: "",
    country: "",
    fullAddress: "",
    zoomMeetingURL: "",
    calendarStatus: 0,
    approve: 0,
    updateStatus: 0,
    averageRating: 0,
    totalRatings: 0,
    emailVerified: 1,
    timeZone: "",
    experienceYear: "",
    coachCertificateList: [],
    coachingCredentials: [], // Updated to match `CoachcredentialsListType`
    nonProfitCoaching: false,
    refered_by_partner: 0,
    refering_partner: null,
  });

  interface RatingDataType {
    name: string;
    image: string;
    message: string;
    createdAt: string;
    ratingNumber: number;
  }

  const [ratingData, setRatingData] = React.useState<RatingDataType[]>([]);
  const [selectedLanguages, setSelectedLanguages] = React.useState<string[]>(
    []
  );
  const [selectedCoachingSpecialities, setSelectedCoachingSpecialities] =
    React.useState<string[]>([]);
  const [coachcredentialsList, setcoachcredentialsList] = React.useState<
    CoachcredentialsListType[]
  >([]);
  const [coachExperienceList, setcoachExperienceList] = React.useState<
    CoachExperienceListType[]
  >([]);

  const [coachEducationList, setcoachEducationList] = React.useState<
    CoachEducationListType[]
  >([]);

  const [coachCertificateList, setcoachCertificateList] = React.useState<
    CoachCertificateListType[]
  >([]);

  const [loading, setLoading] = React.useState(false); // Add loading state // set to true later  // diabled just for testing
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  //fatch coach details
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/details/${coachId}`
      );
      console.log(response);
      if (response.data.data) {
        setData(response.data.data);
        setSelectedLanguages(response.data.data.languages);
        setSelectedCoachingSpecialities(
          response.data.data.coachingSpecialities
        );
        setcoachcredentialsList(response.data.data.coachcredentials);
        setcoachExperienceList(response.data.data.coachexperiences);
        setcoachEducationList(response.data.data.coacheducations);
        setcoachCertificateList(response.data.data.coachcertificates);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };
  //fatch rating list
  const fetchRatingData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/details/rating/${coachId}`
      );
      if (response.data.data) {
        setRatingData(response.data.data);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
    fetchRatingData();
  }, [pageUpdated]);

  //handel rating
  const [openDrawer, setOpenDrawer] = React.useState<boolean>(false);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  //handle coach block
  const handleBlockClick =
    (id: string, blockStatus: number) =>
    async (_: React.ChangeEvent<HTMLInputElement>) => {
      setLoading(true);
      const text = blockStatus == 1 ? "unblock" : "block";
      swalWithBootstrapButtons
        .fire({
          title: "Are you sure?",
          text: `You want to ${text} it`,
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: `Yes, ${text} It!`,
          cancelButtonText: "Not, Now",
          reverseButtons: true,
        })
        .then(async (result) => {
          if (result.isConfirmed) {
            setLoading(true);
            try {
              const response = await httpAPI_admin.put(
                `/admin/coach/block/${id.trim()}`
              );
              if (response.data.success === true) {
                setPageUpdated(!pageUpdated);
                return setLoading(false);
              }
            } catch (error) {
              console.error("Error accepting:", error);
            } finally {
              setLoading(false);
              swalWithBootstrapButtons.fire({
                title: `${text}!`,
                text: `Profile ${text} successfully`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
              setPageUpdated(!pageUpdated);
            }
          } else {
            setLoading(false);
          }
        });
    };

  //handle coach profile approve
  const handleApproveClick =
    (id: string, approveStatus: number) =>
    async (_: React.ChangeEvent<HTMLInputElement>) => {
      setLoading(true);
      const text = approveStatus == 0 ? "approve" : "reject";
      // Create a container for the React component
      const container = document.createElement("div");
      const root = ReactDOM.createRoot(container);
      root.render(<CoachProProgress coachId={id} />);
      swalWithBootstrapButtons
        .fire({
          title: "Approve this coach ?",
          text: `You want to ${text} it`,
          icon: text === "approve" ? "question" : "warning",
          showCancelButton: true,
          confirmButtonText: `Yes, ${text} It!`,
          cancelButtonText: "Not, Now",
          reverseButtons: true,
          html: text === "approve" ? container : "",
          customClass: {
            confirmButton: "btn-success",
            cancelButton: "btn-danger",
            popup: "custom-modal",
          },
          buttonsStyling: false,
          backdrop: true,
          willClose: () => {
            // Clean up the React component on modal close
            root.unmount();
          },
        })
        .then(async (result) => {
          if (result.isConfirmed) {
            setLoading(true);
            try {
              const response = await httpAPI_admin.put(
                `/admin/coach/profile-approve/${id.trim()}`
              );
              if (response.data.success === true) {
                setPageUpdated(!pageUpdated);
                return setLoading(false);
              }
            } catch (error) {
              console.error("Error accepting:", error);
            } finally {
              setLoading(false);
              swalWithBootstrapButtons.fire({
                title: `${text}!`,
                text: `Profile ${text} successfully`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
              setPageUpdated(!pageUpdated);
            }
          } else {
            setLoading(false);
          }
        });
    };

  //handle coach account delete
  const handleDelteClick = (id: string) => {
    setLoading(true);
    const text = "delete";
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to ${text} it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, ${text} It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI_admin.put(
              `/admin/coach/account-delete/${id.trim()}`
            );
            if (response.data.success === true) {
              setPageUpdated(!pageUpdated);
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            swalWithBootstrapButtons.fire({
              title: `Delete!`,
              text: `Account deleted successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            setPageUpdated(!pageUpdated);
            navigate("/coach");
          }
        } else {
          setLoading(false);
        }
      });
  };

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflowY: "scroll",
          overflowX: "hidden",
          maxHeight: "calc(100vh - 110px)",
        }}
      >
        <Grid container sx={{ height: "26vh" }}>
          <Box
            sx={{
              background: "#013338",
              width: "100%",
              p: 1,
              height: "7rem",
              position: "relative",
            }}
          >
            <Box
              display="flex"
              justifyContent="start"
              alignItems="start"
              margin="0 auto"
              padding="0 15px"
              width={"100%"}
              flexDirection={{ md: "row", sm: "column", xs: "column" }}
              height={{ md: 160, sm: 230, xs: 230 }}
              borderRadius="50%"
              position="absolute"
              sx={{
                top: "100%",
                transform: { md: "translateY(-50%)", xs: "translateY(-40%)" },
              }}
            >
              {data?.image ? (
                <Avatar
                  src={`${backendURL}/usersProfile/${data?.image}`}
                  alt="User"
                  sx={{
                    width: 130,
                    height: 130,
                  }}
                />
              ) : (
                <Box
                  display="flex"
                  justifyContent="center"
                  alignItems="center"
                  sx={{
                    width: 130,
                    height: 130,
                  }}
                  bgcolor="slategray"
                  borderRadius="50%"
                >
                  <Typography
                    variant="h6"
                    color="white"
                    sx={{ fontSize: "3rem" }}
                  >
                    {capitalizeFirstLetter(data?.name)}
                  </Typography>
                </Box>
              )}
              <Box
                p={1}
                sx={{
                  width: "100%",
                  overflow: "hidden",
                  color: { sm: "#013338", xs: "#013338", md: "white" },
                }}
              >
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: "normal",
                    padding: "0 16px",
                    width: "100%",
                    whiteSpace: "nowrap",
                    textOverflow: { sm: "ellipsis" },
                  }}
                >
                  {data?.name?.charAt(0).toUpperCase() + data?.name?.slice(1)}
                </Typography>
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: "400",
                    fontSize: "1rem",
                    padding: "0 16px",
                    whiteSpace: { lg: "nowrap", sm: "normal", xs: "balance" },
                  }}
                >
                  {data?.email}
                </Typography>
              </Box>
            </Box>
            <Box
              display="flex"
              justifyContent="start"
              alignItems="start"
              margin="0 auto"
              padding="0 15px"
              position="absolute"
              sx={{
                right: 0,
                top: { lg: "70%", sm: "50%", xs: "20%" },
                transform: "translateY(-10%)",
              }}
            ></Box>
          </Box>
        </Grid>
        <Grid container sx={{ pb: 5, px: 2 }}>
          <Grid item sm={12} md={6}>
            <Grid container sx={{ padding: 2 }} spacing={3}>
              {renderTextField(
                "Full Name *",
                data?.name ? data?.name : "Yet to be Added"
              )}
              {renderTextField(
                "Email *",
                data?.email ? data?.email : "Yet to be Added"
              )}
              {renderTextField(
                "Username *",
                data?.userName ? data?.userName : "Yet to be Added"
              )}
              {renderTextField(
                "Date of Birth *",
                data?.DOB && !isNaN(new Date(data.DOB).getTime())
                  ? new Date(data.DOB).toDateString()
                  : "Yet to be Added"
              )}
              {renderTextField(
                "Gender *",
                data?.gender ? data?.gender : "Yet to be Added"
              )}
              {renderTextField(
                " Time Zone *",
                data?.timeZone ? data?.timeZone : "Yet to be Added"
              )}
              {renderTextField(
                "Title Line *",
                data?.title_line ? data?.title_line : "Yet to be Added"
              )}
              {renderTextField(
                "About Me *",
                data?.about_me ? data?.about_me : "Yet to be Added"
              )}
              {/* non profit coaching  */}
              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 400,
                      display: "flex",
                      flexDirection: "row",
                      width: "100%",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    {renderHeader("Non-Profit Coaching Programs")}
                    {data?.nonProfitCoaching ? (
                      <Box display="flex" alignItems="center" gap={1} px={2}>
                        <Badge
                          badgeContent={
                            <CheckCircleIcon style={{ color: "#3aa7a3" }} />
                          }
                          overlap="circular"
                        ></Badge>
                      </Box>
                    ) : (
                      <Box display="flex" alignItems="center" gap={1} px={2}>
                        <Badge
                          badgeContent={<Cancel sx={{ color: "red" }} />}
                          overlap="circular"
                        ></Badge>
                      </Box>
                    )}
                  </Typography>
                </Paper>
              </Grid>
              {/* partner refernce  */}
              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader(
                    <>
                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          justifyContent: "space-between",
                          width: "100%",
                        }}
                      >
                        <Typography
                          variant="body1"
                          sx={{
                            fontWeight: 600,
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                          }}
                        >
                          Referred by Erickson Partner
                        </Typography>

                        {data?.refered_by_partner ? (
                          data?.refered_by_partner === 0 ? (
                            <Typography
                              sx={{
                                backgroundColor: "#ebbe34",
                                color: "#fff",
                                px: 2,
                                py: 0.5,
                                borderRadius: "8px",
                                fontWeight: 600,
                              }}
                            >
                              Pending
                            </Typography>
                          ) : data?.refered_by_partner === 2 ? (
                            <Box display="flex" alignItems="center" gap={1}>
                              <Badge
                                badgeContent={<Cancel sx={{ color: "red" }} />}
                                overlap="circular"
                              ></Badge>
                            </Box>
                          ) : (
                            <Box display="flex" alignItems="center" gap={1}>
                              <Badge
                                badgeContent={
                                  <CheckCircleIcon
                                    style={{ color: "#3aa7a3" }}
                                  />
                                }
                                overlap="circular"
                              ></Badge>
                            </Box>
                          )
                        ) : (
                          <Box display="flex" alignItems="center" gap={1}>
                            <Badge
                              badgeContent={<Cancel sx={{ color: "red" }} />}
                              overlap="circular"
                            ></Badge>
                          </Box>
                        )}
                      </Box>
                    </>
                  )}
                  {data.refered_by_partner === 1 && (
                    <Typography
                      variant="body1"
                      sx={{
                        fontWeight: 500,
                        display: "flex",
                        flexDirection: "row",
                        width: "100%",
                        alignItems: "center",
                        justifyContent: "space-between",
                        px: 2,
                      }}
                    >
                      Referring Partner : {data.refering_partner?.region} -{" "}
                      {data.refering_partner?.country}
                    </Typography>
                  )}
                </Paper>
              </Grid>

              {/* meeting link  */}
              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Meeting Link")}
                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 400,
                      display: "flex",
                      justifyContent: "flex-start",
                      alignItems: "center",
                    }}
                  >
                    {data?.zoomMeetingURL ? (
                      <a
                        href={data?.zoomMeetingURL || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          textDecoration: "none",
                          color: "blue", // Set your desired link color here
                        }}
                      >
                        {data?.zoomMeetingURL}
                      </a>
                    ) : (
                      <span>Meeting URI is Yet to be Added.</span>
                    )}
                  </Typography>
                </Paper>
              </Grid>

              <Grid item sm={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Languages")}
                  <Box
                    display={"flex"}
                    flexDirection={"row"}
                    flexWrap={"wrap"}
                    gap={2}
                  >
                    {selectedLanguages.length > 0 ? (
                      selectedLanguages.map((a, i) => (
                        <Chip key={i} label={a} />
                      ))
                    ) : (
                      <Chip label="Not-Added" />
                    )}
                  </Box>
                </Paper>
              </Grid>

              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Coaching Specialities")}
                  <Box
                    display={"flex"}
                    flexDirection={"row"}
                    flexWrap={"wrap"}
                    gap={2}
                  >
                    {selectedCoachingSpecialities.length > 0 ? (
                      selectedCoachingSpecialities.map((a, i) => (
                        <Chip key={i} label={a} />
                      ))
                    ) : (
                      <Chip label="Not-Added" />
                    )}
                  </Box>
                </Paper>
              </Grid>
              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Experience (years)")}
                  <Box
                    display={"flex"}
                    flexDirection={"row"}
                    flexWrap={"wrap"}
                    gap={2}
                  >
                    {data.experienceYear ? (
                      <Chip
                        label={data.experienceYear.toString().padStart(2, "0")}
                      />
                    ) : (
                      <Chip label="Not-Added" />
                    )}
                  </Box>
                </Paper>
              </Grid>
              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Address")}
                  <Typography
                    variant="body2"
                    // gutterBottom
                    sx={{
                      fontWeight: "normal",
                      display: "flex",
                      justifyContent: "start",
                      alignItems: "center",
                      color: "black",
                      padding: "10px 15px ",
                    }}
                  >
                    {data?.fullAddress || "Not-Added"}
                  </Typography>
                </Paper>
              </Grid>
            </Grid>

            <Grid item sm={12} xs={12} p={2}>
              <Paper elevation={3} sx={{ p: 2 }}>
                {renderHeader(
                  <>
                    <span
                      style={{
                        color:
                          coachCertificateList.length > 0 ? "inherit" : "red",
                      }}
                    >
                      Certificates
                    </span>
                    <Required a={true} />
                  </>
                )}
                {coachCertificateList.length > 0 ? (
                  coachCertificateList
                    .filter((row) => row.certificateFile)
                    .map((row, i) => (
                      <Card
                        key={i}
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          flexDirection: "column",
                          padding: "10px 15px",
                          margin: "5px 0",
                          border: "1px solid #3aa7a3",
                        }}
                      >
                        <Box sx={{ display: "flex", flexDirection: "column" }}>
                          <CardContent sx={{ flex: "1 0 auto" }}>
                            <Typography
                              component="div"
                              variant="h6"
                              sx={{ color: "#3aa7a3" }}
                            >
                              {row.title}
                            </Typography>
                          </CardContent>
                        </Box>
                        <FilePreview
                          file={row.certificateFile}
                          fileUrl={`${backendURL}/certificate/${row.certificateFile}`}
                        />
                      </Card>
                    ))
                ) : (
                  <>
                    {renderUnavailable(
                      "Certificates Data Hasn't been added Yet"
                    )}
                  </>
                )}
              </Paper>
            </Grid>
          </Grid>

          <Grid item sm={12} md={6} order={-1}>
            <Grid container spacing={2} sx={{ pt: 2 }}>
              <Grid item xs={12} sm={12}>
                {/* profile status  */}

                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent={"space-between"}
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Profile Status
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Typography>
                      {data?.approve === 0 ? (
                        <Chip
                          size="small"
                          icon={<AccessTimeFilledIcon color="inherit" />}
                          label="Pending"
                          sx={{
                            backgroundColor: "#EBBE34",
                            color: "white",
                            width: 110,
                          }}
                        />
                      ) : (
                        <Chip
                          size="small"
                          icon={<CheckCircleIcon color="inherit" />}
                          label="Approved"
                          sx={{
                            backgroundColor: "#3aa7a3",
                            color: "white",
                            width: 110,
                          }}
                        />
                      )}
                    </Typography>
                  </Box>
                </Box>

                {/* Approve Action */}
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Approve
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Tooltip
                      title={data.approve === 1 ? "Approved" : "Not-Approved"}
                    >
                      <Switch
                        {...label}
                        checked={data.approve === 1 ? true : false}
                        color={data.approve === 1 ? "primary" : "error"}
                        onChange={handleApproveClick(data._id, data?.approve)}
                      />
                    </Tooltip>
                  </Box>
                </Box>
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent={"space-between"}
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
               
                    <ShortlistCoachToCompany coachId={data._id} />
                 
                </Box>
                {/* rating  */}
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    15 min. Free Trial
                  </Typography>

                  <Box display="flex" alignItems="center">
                    <Tooltip title={data.freeTrial === "true" ? "On" : "Off"}>
                      <Switch
                        {...label}
                        defaultChecked
                        disabled
                        color={data.freeTrial === "true" ? "primary" : "error"}
                      />
                    </Tooltip>
                  </Box>
                </Box>
                {/* Email Verified status */}
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    <span
                      style={{
                        color: data?.emailVerified === 1 ? "inherit" : "red",
                      }}
                    >
                      Email Verified
                    </span>
                    <Required a={true} />
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Tooltip
                      title={
                        data?.emailVerified === 1 ? "Verified" : "Unverified"
                      }
                    >
                      {data.emailVerified === 1 ? (
                        <Switch
                          {...label}
                          disabled
                          defaultChecked
                          color="primary"
                        />
                      ) : (
                        <Switch {...label} disabled />
                      )}
                    </Tooltip>
                  </Box>
                </Box>
                {/* Google Calender status */}
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    <span
                      style={{
                        color: data.calendarStatus === 1 ? "#013338" : "red",
                      }}
                    >
                      Google Calendar
                    </span>
                    <Required a={true} />
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Tooltip
                      title={data.calendarStatus === 1 ? "Added" : "Not-Added"}
                    >
                      {data.calendarStatus === 1 ? (
                        <Chip
                          size="small"
                          icon={<CheckCircleIcon color="inherit" />}
                          label="Added"
                          sx={{
                            backgroundColor: "#3aa7a3",
                            color: "white",
                            width: 110,
                          }}
                        />
                      ) : (
                        <Chip
                          size="small"
                          icon={<AccessTimeFilledIcon color="inherit" />}
                          label="Not-Added"
                          sx={{
                            backgroundColor: "#ebbd33",
                            color: "white",
                            width: 110,
                          }}
                        />
                      )}
                    </Tooltip>
                  </Box>
                </Box>
                {/* Block status */}
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Block
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Tooltip
                      title={data.block === 1 ? "Blocked" : "Un-Blocked"}
                    >
                      <Switch
                        {...label}
                        checked={data.block === 1 ? true : false}
                        color={data.block === 1 ? "error" : "primary"}
                        onChange={handleBlockClick(data._id, data?.block)}
                      />
                    </Tooltip>
                  </Box>
                </Box>
                {/* Delete status */}
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Delete
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Tooltip title={"Delete"}>
                      <DeleteIcon
                        color="error"
                        style={{ cursor: "pointer" }}
                        onClick={() => handleDelteClick(data._id)}
                      />
                    </Tooltip>
                  </Box>
                </Box>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Payout History
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Chip
                      size="small"
                      label="Details"
                      onClick={() => navigate(`/payout/detail/${coachId}`)}
                      sx={{
                        backgroundColor: "#5FB6D5",
                        color: "white",
                        width: "fit-content",
                        px: 1,
                        "&:hover": {
                          backgroundColor: "#EBBE34",
                        },
                      }}
                    />
                  </Box>
                </Box>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Booking History
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Chip
                      size="small"
                      label="Details"
                      onClick={() =>
                        navigate(`/coach/booking-history/${coachId}`)
                      }
                      sx={{
                        backgroundColor: "#5FB6D5",
                        color: "white",
                        width: "fit-content",
                        px: 1,
                        "&:hover": {
                          backgroundColor: "#EBBE34",
                        },
                      }}
                    />
                  </Box>
                </Box>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                    }}
                  >
                    Chat History
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Chip
                      size="small"
                      label="Details"
                      onClick={() => navigate(`/chat-history/${coachId}/coach`)}
                      sx={{
                        backgroundColor: "#5FB6D5",
                        color: "white",
                        width: "fit-content",
                        px: 1,
                        "&:hover": {
                          backgroundColor: "#EBBE34",
                        },
                      }}
                    />
                  </Box>
                </Box>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  width={{ sm: "100%", md: "100%" }}
                  gap={3}
                  sx={{ padding: "4px 25px" }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      color: "#013338",
                      fontWeight: "bold",
                      width: { sm: "160px" },
                      display: "flex",
                      alignItems: "center",
                      gap: 0.51,
                    }}
                  >
                    Ratings
                    <Rating
                      name="read-only"
                      size="small"
                      value={data.averageRating}
                      precision={0.5}
                      readOnly
                    />
                    <b
                      style={{ color: "gray", fontWeight: 500 }}
                    >{`(${data?.totalRatings})`}</b>
                  </Typography>
                  {data?.totalRatings > 0 ? (
                    <Box display="flex" alignItems="center">
                      <Chip
                        size="small"
                        label="Details"
                        onClick={() => setOpenDrawer(true)}
                        sx={{
                          backgroundColor: "#5FB6D5",
                          color: "white",
                          width: "fit-content",
                          px: 1,
                          "&:hover": {
                            backgroundColor: "#EBBE34",
                          },
                        }}
                      />
                    </Box>
                  ) : (
                    <Box display="flex" alignItems="center">
                      <Chip
                        size="small"
                        label="None"
                        sx={{
                          backgroundColor: "gray",
                          color: "white",
                          width: "fit-content",
                          px: 1,
                          "&:hover": {
                            backgroundColor: "#gray",
                          },
                        }}
                      />
                    </Box>
                  )}
                </Box>
              </Grid>

              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader(
                    <>
                      <span
                        style={{
                          color:
                            coachcredentialsList.length > 0 ? "inherit" : "red",
                        }}
                      >
                        Coaching Credentials
                      </span>
                      <Required a={true} />
                    </>
                  )}
                  {coachcredentialsList.length > 0 ? (
                    coachcredentialsList.map((row, i) => {
                      console.log({ row });
                      return (
                        <Card
                          key={i}
                          variant="outlined"
                          sx={{
                            width: "100%",
                            p: 2,
                            my: 1,
                            borderRadius: 2,
                            backgroundColor: "#f9fafa",
                          }}
                        >
                          <CardContent
                            sx={{
                              display: "flex",
                              flexDirection: "column",
                              gap: 2,
                            }}
                          >
                            <Typography
                              variant="h6"
                              component="div"
                              sx={{ color: "#013338", fontWeight: 600 }}
                            >
                              {row.title}
                            </Typography>

                            <Box
                              sx={{
                                height: 200,
                                width: "100%",
                                overflow: "hidden",
                                borderRadius: 2,
                                border: "1px solid #e0e0e0",
                                backgroundColor: "#fff",
                              }}
                            >
                              <img
                                src={`${backendURL}/credentials/${row.image}`}
                                alt={row.title}
                                style={{
                                  objectFit: "contain",
                                  height: "100%",
                                  width: "100%",
                                }}
                              />
                            </Box>

                            <Typography variant="body2" sx={{ color: "#666" }}>
                              {new Date(row.startDate).toLocaleDateString(
                                "en-US",
                                {
                                  year: "numeric",
                                  month: "long",
                                }
                              )}{" "}
                              –{" "}
                              {row.workingOn === "false"
                                ? new Date(row.endDate).toLocaleDateString(
                                    "en-US",
                                    {
                                      year: "numeric",
                                      month: "long",
                                    }
                                  )
                                : "Present"}
                            </Typography>
                          </CardContent>
                        </Card>
                      );
                    })
                  ) : (
                    <>{renderUnavailable()}</>
                  )}
                </Paper>
              </Grid>

              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Experience")}
                  {coachExperienceList.length > 0 ? (
                    coachExperienceList.map((row, i) => (
                      <Card
                        key={i}
                        variant="outlined"
                        sx={{
                          width: "100%",
                          padding: "10px 0",
                          margin: "5px 0",
                        }}
                      >
                        <CardContent>
                          <Typography variant="h5" component="div">
                            {row.organization}
                          </Typography>
                          <Typography variant="body2">
                            {row.position}
                          </Typography>
                          <Typography variant="caption">
                            {new Date(row.startDate).toLocaleDateString(
                              "en-US",
                              {
                                year: "numeric",
                                month: "long",
                              }
                            )}
                            <span>&nbsp;</span>-<span>&nbsp;</span>
                            {row.workingOn == "false"
                              ? new Date(row.endDate).toLocaleDateString(
                                  "en-US",
                                  { year: "numeric", month: "long" }
                                )
                              : "Present"}
                          </Typography>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <>
                      {renderUnavailable(
                        "The Coach Haven't added the Experience Details Yet !"
                      )}
                    </>
                  )}
                </Paper>
              </Grid>

              <Grid item sm={12} xs={12}>
                <Paper elevation={3} sx={{ padding: "10px 15px" }}>
                  {renderHeader("Education")}
                  {coachEducationList.length > 0 ? (
                    coachEducationList.map((row, i) => (
                      <Card
                        key={i}
                        variant="outlined"
                        sx={{
                          width: "100%",
                          padding: "10px 0",
                          margin: "5px 0",
                        }}
                      >
                        <CardContent>
                          <Typography variant="h5" component="div">
                            {row.organization}
                          </Typography>
                          <Typography variant="body2">{row.degree}</Typography>
                          <Typography variant="caption">
                            {new Date(row.startDate).toLocaleDateString(
                              "en-US",
                              {
                                year: "numeric",
                                month: "long",
                              }
                            )}
                            <span>&nbsp;</span>-<span>&nbsp;</span>
                            {new Date(row.endDate).toLocaleDateString("en-US", {
                              year: "numeric",
                              month: "long",
                            })}
                          </Typography>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <>
                      {renderUnavailable("Education Details Are Not-Added !")}
                    </>
                  )}
                </Paper>
              </Grid>
              <Grid item sm={12} xs={12}>
                <Required a={false} />
              </Grid>
            </Grid>
          </Grid>
          {/* end */}
        </Grid>
      </Paper>

      <Drawer
        anchor="right"
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
      >
        <Box
          sx={{
            width: { xs: 320, sm: 350, md: 550, xl: 660 },
            postition: "relative",
          }}
          role="presentation"
        >
          <Box
            sx={{
              zIndex: 99,
              display: "flex",
              width: "100%",
              justifyContent: "space-between",
              alignItems: "center",
              px: 2,
              py: 2,
              position: "sticky",
              top: 0,
              backgroundColor: "white",
            }}
          >
            <Typography variant="h6" fontWeight="bold" color="textPrimary">
              All Reviews
            </Typography>
            <IconButton onClick={() => setOpenDrawer(false)}>
              <CloseIcon />
            </IconButton>
          </Box>
          {ratingData.map((a, index) => (
            <Box
              display={"flex"}
              key={index}
              sx={{
                width: "100%",
                borderBottom: "1px solid gray",
                py: 2,
                my: 1,
                px: 3,
                flexDirection: { xs: "column", md: "row" },
                justifyContent: "start",
                alignItems: { xs: "start", md: "start" },
                gap: 1,
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: { xs: "row", md: "column" },
                  justifyContent: "start",
                  alignItems: { xs: "center", md: "start" },
                  gap: { xs: 2, md: 1 },
                  width: { xs: "100%", md: "30%" },
                }}
              >
                <Avatar
                  alt={a.name}
                  src={`${backendURL}/usersProfile/${a.image}`}
                  sx={{ height: { xs: 50, md: 70 }, width: { xs: 50, md: 70 } }}
                />
                <Box
                  sx={{
                    fontWeight: 600,
                    display: "flex",
                    flexDirection: "column",
                    width: "100%",
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{ fontFamily: "Montserrat", fontWeight: 600 }}
                  >
                    {a.name}
                  </Typography>
                  <Typography
                    variant="caption"
                    sx={{ fontFamily: "Montserrat", fontWeight: 500 }}
                  >
                    {a.createdAt &&
                      new Date(a.createdAt)?.toLocaleDateString() +
                        "  " +
                        new Date(a.createdAt)?.toLocaleTimeString()}
                  </Typography>
                </Box>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "start",
                  alignItems: "start",
                  gap: 2,
                  fontFamily: "Montserrat",
                  width: { xs: "100%", md: "70%" },
                }}
              >
                <Rating
                  name="read-only"
                  size="small"
                  value={a.ratingNumber}
                  precision={0.5}
                  readOnly
                />
                <Typography variant="body2" sx={{ fontFamily: "Montserrat" }}>
                  {a.message}
                </Typography>
              </Box>
            </Box>
          ))}
        </Box>
      </Drawer>
    </>
  );
}

const renderHeader = (name: any = "No Information Has Been Added Yet") => {
  return (
    <Typography
      variant="body1"
      gutterBottom
      sx={{
        fontWeight: "600",
        display: "flex",
        justifyContent: "start",
        alignItems: "center",
        color: "#013338",
        padding: "5px 15px",
      }}
    >
      {name}
    </Typography>
  );
};

const renderUnavailable = (
  message: string = "No Information Has Been Added Yet"
) => {
  return (
    <Card
      variant="outlined"
      sx={{
        width: "100%",
        padding: "10px 0",
        margin: "5px 0",
        borderColor: "#013338",
      }}
    >
      <CardContent>
        <Typography
          variant="body2"
          component="div"
          sx={{
            color: "#013338",
            textAlign: "center",
            fontWeight: "500",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            gap: "7px",
          }}
        >
          <InfoIcon
            sx={{
              fontSize: {
                sm: "2rem",
                md: "3rem",
              },
            }}
          />
          {message}
        </Typography>
      </CardContent>
    </Card>
  );
};

const renderTextField = (label: string, value: string | undefined) => {
  return (
    <Grid item sm={12} xs={12}>
      <TextField
        InputProps={{
          readOnly: true,
        }}
        id="outlined-required"
        label={label}
        fullWidth
        size="small"
        value={value}
        variant="outlined"
        sx={{
          "& .MuiInputBase-input.Mui-disabled": {
            color: "#013338",
          },
          "& .MuiOutlinedInput-root.Mui-disabled": {
            "& fieldset": {
              borderColor: "#013338",
            },
          },
          "& .MuiInputLabel-root.Mui-disabled": {
            color: "#013338",
          },
          "& .MuiInputBase-root.Mui-disabled": {
            color: "#013338",
          },
        }}
      />
    </Grid>
  );
};

const Required = ({ a }: { a: boolean }) => {
  return (
    <>
      {a ? (
        <span
          style={{
            color: "red",
            fontWeight: "400",
            fontSize: "0.96rem",
            whiteSpace: "nowrap",
            height: "100%",
          }}
        >
          *
        </span>
      ) : (
        <span
          style={{
            color: "red",
            fontWeight: "400",
            fontSize: "0.86rem",
            lineBreak: "auto",
            height: "100%",
            fontFamily: "montserrat",
          }}
        >
          * marked fields are required for profile approval and adding to the
          coaches list on the coach marketplace.
        </span>
      )}
    </>
  );
};

export interface Row {
  _id: string;
  block: number;
  name: string;
  Lname: string;
  userName: string;
  gender: string;
  DOB: string;
  email: string;
  image: string;
  freeTrial: string;
  about_me: string;
  title_line: string;
  languages: Array<string>;
  industries: Array<string>;
  coachingSpecialities: Array<string>;
  coachingExperience: string;
  city: string;
  country: string;
  fullAddress: string;
  zoomMeetingURL: string;
  calendarStatus: number;
  approve: number;
  updateStatus: number;
  averageRating: number;
  totalRatings: number;
  emailVerified: number;
  timeZone: string;
  experienceYear: string;
  coachCertificateList: CoachCertificateListType[];
  coachingCredentials: CoachcredentialsListType[];
  refered_by_partner: number;
  nonProfitCoaching: boolean;
  refering_partner: { region: string; country: string } | null;
}

interface CoachCertificateListType {
  _id: string;
  title: string;
  image: string;
}
interface CoachcredentialsListType {
  _id: string;
  organization: string;
  position: string;
  workingOn: string;
  startDate: string;
  endDate: string;
  // endDate2: string;
}
