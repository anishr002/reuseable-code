import ReactDOM from "react-dom/client";
import ScheduleIcon from "@mui/icons-material/Schedule";
import CancelIcon from "@mui/icons-material/Cancel";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import VisibilityIcon from "@mui/icons-material/Visibility";

import TableRow from "@mui/material/TableRow";
import {
  Box,
  Button,
  Pagination,
  Switch,
  TableCell,
  TextField,
  Typography,
} from "@mui/material";
import { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
const label = { inputProps: { "aria-label": "Switch demo" } };
import Swal from "sweetalert2";
import { Link, useNavigate } from "react-router-dom";
import NoDataIllustration from "../components/NoDataIllustration";
import dayjs from "dayjs";
import { useDispatch, useSelector } from "react-redux";
import { setPendingCount } from "../slices/PendingApprovalCount";
import CoachProProgress from "../components/CoachProProgress";

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
    title: "montserrat-title",
    popup: "montserrat-popup",
  },
  buttonsStyling: false,
});
export default function Approvals() {
  interface Row {
    _id: string;
    name: string;
    Lname: string;
    email: string;
    gender: string;
    coach_id: string;
    completionStatus: string;
    requestedOn: string;
    approve: number;
    emailVerified: number;
  }
  const [rows, setData] = React.useState<Row[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const dispatch = useDispatch();

  const [searchTerm, setSearchTerm] = React.useState<string>(""); //charecter search
  const [filterSearch, setFilterSearch] = React.useState<string>(""); //charecter search

  const fetchPendingApprovalData = async () => {
    console.log("api call using filter");
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/new-profile-approval-requests?pageNo=${pageNo}&filter=2&searchTerm=${filterSearch}`
      );
      if (response.data.success) {
        setPageInfo({
          totalPages: response.data.totalPages,
        });
        dispatch(setPendingCount(response.data.data.length));
        return setData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    console.log("Calling fethc on change for page ", pageUpdated);
    fetchPendingApprovalData();
  }, [pageNo, pageUpdated, filterSearch]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  //handle coach block
  const handleApprove =
    ({ req_id, coach_id }: { req_id: string; coach_id: string }) =>
      async (_event: React.ChangeEvent<HTMLInputElement>) => {
        console.log(_event);
        const container = document.createElement("div");
        const root = ReactDOM.createRoot(container);
        root.render(<CoachProProgress coachId={coach_id} />);
        swalWithBootstrapButtons
          .fire({
            title: "Are you sure ?",
            text: `You want to approve this coach profile ?`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: `Confirm Approval`,
            cancelButtonText: "Back",
            reverseButtons: true,
            html: container,
            customClass: {
              confirmButton: "btn-success",
              cancelButton: "btn-danger",
              popup: "custom-modal",
            },
            buttonsStyling: false,
            backdrop: true,
          })
          .then(async (result) => {
            if (result.isConfirmed) {
              try {
                const response = await httpAPI_admin.post(
                  `/admin/coach/new-profile-approve/${coach_id.trim()}/${req_id.trim()}`
                );
                console.log(response);
                if (response.data.success === true) {
                  swalWithBootstrapButtons.fire({
                    title: `Coach Profile aprroved !`,
                    text: `Coach profile has been approved successfully.`,
                    icon: "success",
                    showConfirmButton: true,
                    timer: 1500,
                  });
                }
              } catch (error) {
                console.error("Error accepting:", error);
                swalWithBootstrapButtons.fire({
                  text: "Some Error Occurred, Please try again!",
                  title: "Opps !",
                  icon: "success",
                  showConfirmButton: true,
                });
              } finally {
                console.log("Running finnally of the approve");
                setPageUpdated(!pageUpdated);
              }
            } else {
              setPageUpdated(!pageUpdated);
            }
          });
      };

  //handle coach account delete
  const handleRejectRequest = ({
    req_id,
    coach_id,
  }: {
    req_id: string;
    coach_id: string;
  }) => {
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You want to reject this profile approval request.",
        icon: "warning",
        input: "textarea", // Adding a text area for rejection notes
        inputValue:
          "Your profile is not complete for approval. Please update the required details and you can request again at any time.", // Default rejection message
        inputPlaceholder: "Enter profile rejection notes for coach here...", // Placeholder text
        showCancelButton: true,
        confirmButtonText: `Yes, Reject this request !`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
        preConfirm: (notes) => {
          if (!notes) {
            Swal.showValidationMessage("Rejection notes are required.");
            return false; // Prevent confirmation if no notes provided
          }
          return notes; // Return the notes value if valid
        },
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          const rejectionNotes = result.value;
          setLoading(true);
          try {
            const response = await httpAPI_admin.post(
              `/admin/coach/new-profile-decline/${coach_id.trim()}/${req_id.trim()}`,
              { note: rejectionNotes } // Send rejection notes with the request
            );
            console.log(response);
            if (response.data.success === true) {
              swalWithBootstrapButtons.fire({
                title: `Rejected!`,
                text: `The profile was rejected successfully.`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
            }
          } catch (error) {
            console.error("Error rejecting:", error);
            swalWithBootstrapButtons.fire({
              text: "Some Error Occurred, Please try again!",
              title: "Opps !",
              icon: "error",
              showConfirmButton: false,
            });
          } finally {
            setPageUpdated(!pageUpdated);
          }
        } else {
          setPageUpdated(!pageUpdated);
        }
      });
  };
  const pendingCount = useSelector(
    (state: any) => state.pendingApprovalReqCount.pendingReqCount
  );

  const navigate = useNavigate();
  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            flexDirection: { xs: "column", md: "row" },
            display: "flex",
            justifyContent: { xs: "start", md: "space-between" },
            gap: "5px",
            alignItems: { xs: "start", md: "center" },
            color: "#013338",
          }}
        >
          <div
            style={{
              position: "relative",
              display: "flex",
            }}
          >
            Pending Approvals
            {pendingCount > 0 && (
              <span
                style={{
                  background: "#ebbe34",
                  color: "white",
                  width: "20px",
                  height: "20px",
                  borderRadius: "50%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  fontSize: "0.75rem",
                  boxShadow: "0px 0px 8px rgba(0, 0, 0, 0.15)", // Optional shadow for effect
                }}
              >
                {pendingCount > 99 ? "99+" : pendingCount}
              </span>
            )}
          </div>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
              }}
            >
              <TextField
                id="outlined-search"
                placeholder="Search..."
                type="search"
                variant="outlined"
                fullWidth
                size="small"
                value={searchTerm}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  setSearchTerm(event.target.value);
                  if (event.target.value === "") {
                    setFilterSearch("");
                  }
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                    backgroundColor: "#fff",
                  },
                }}
              />
              <Button
                sx={{
                  paddingX: 3,
                  backgroundColor: "#3aa7a3",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "#31c6f8",
                  },
                }}
                onClick={() => setFilterSearch(searchTerm)}
              >
                Apply
              </Button>
            </Box>
            <Box
              onClick={() => {
                navigate("/approvals/history");
              }}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "1.1rem",
              }}
            >
              View History
              <ScheduleIcon style={{ color: "#013338" }} />
            </Box>
          </Box>
        </Typography>

        {rows?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 210px)",
                overflow: "auto",
                minWidth: "fit-content",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email Address
                    </TableCell>
                    {/* <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Completion Status
                    </TableCell> */}
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email verification
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Requested on
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Details
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Approve
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Decline
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-word" },
                          }}
                        >
                          {`${row?.name} ${row?.Lname}`}
                          {row?.gender ? ` (${row?.gender?.charAt(0)}) ` : ""}
                        </TableCell>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-all" },
                          }}
                        >
                          {row.email}
                        </TableCell>
                        <TableCell>
                          {row?.emailVerified === 1 ? (
                            <Box
                              sx={{
                                display: "flex",
                                px: 1,
                                py: 0.5,
                                gap: 0,
                                color: "white",
                                alignItems: "center",
                                justifyContent: "space-between",
                                background: "#3aa7a3",
                                borderRadius: "32px",
                              }}
                            >
                              <Typography
                                variant="caption"
                                sx={{ fontFamily: "montserrat" }}
                              >
                                Verified
                              </Typography>
                              <CheckCircleIcon color="inherit" />
                            </Box>
                          ) : (
                            <Box
                              sx={{
                                display: "flex",
                                px: 1,
                                py: 0.5,
                                gap: 0,

                                alignItems: "center",
                                justifyContent: "space-between",
                                borderRadius: "32px",
                                background: "gray",
                                color: "white",
                              }}
                            >
                              <Typography
                                variant="caption"
                                sx={{ fontFamily: "montserrat" }}
                              >
                                Unverified
                              </Typography>
                              <PendingActionsIcon color="inherit" />
                            </Box>
                          )}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {row?.requestedOn
                            ? dayjs(row?.requestedOn).format("DD-MM-YYYY")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <Link to={`/coach/detail/${row?.coach_id}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                        <TableCell>
                          <Switch
                            {...label}
                            color={row?.approve === 1 ? "info" : "default"}
                            onChange={handleApprove({
                              req_id: row?._id,
                              coach_id: row?.coach_id,
                            })}
                          />
                        </TableCell>

                        <TableCell>
                          <CancelIcon
                            color="error"
                            style={{ cursor: "pointer" }}
                            onClick={() =>
                              handleRejectRequest({
                                coach_id: row?.coach_id,
                                req_id: row?._id,
                              })
                            }
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo?.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo?.totalPages)}
                  page={Number(pageNo)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration message="No Pending Requests! " />
        )}
      </Paper>
    </>
  );
}
