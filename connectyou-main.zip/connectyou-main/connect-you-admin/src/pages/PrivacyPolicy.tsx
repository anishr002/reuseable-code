import { useEffect } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";

// Define the editor modules and formats for better type safety

import CloseIcon from "@mui/icons-material/Close";
import { Box, Button, Modal, Paper, Typography } from "@mui/material";
import { useState } from "react";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";

import EditableTextList from "../components/EditableTextList";
import { Controller, useForm } from "react-hook-form";
const primaryButton = {
  p: 0,
  color: "white",
  backgroundColor: "#EBBE34",
  borderColor: "#EBBE34",
  borderRadius: "20px",
  fontFamily: "Montserrat",
  mx: "auto",
  "&:hover": {
    borderColor: "white",
    backgroundColor: "white",
    color: "#EBBE34",
  },
};

interface Data {
  data: string;
}
const PrivacyPolicy = () => {
  const [data, setData] = useState<Data[]>([]);
  const [editdata, setEditdata] = useState<string>("");
  const [refresh, setRefresh] = useState<boolean>(false);
  const toggleRefresh = () => {
    setRefresh(!refresh);
  };
  const [openAddNewModal, setOpenAddNewModal] = useState<boolean>(false);
  const toggleOpenAddNew = (b: boolean) => {
    setOpenAddNewModal(b);
    if (data.length > 0) {
      setEditdata(data[0].data);
    } else {
      setEditdata("");
    }
  };
  const [loading, setLoading] = useState<boolean>(false);
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.get(
        `${backendURL}/admin/terms-policies/list-all-privacy-policy`
      );
      if (res.status === 200) {
        setData(res.data.data);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [refresh]);

  // Render the saved content in HTML format

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: "calc(100vh - 88px)",
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height: "3rem",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Privacy Policy
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Button
              sx={{ ...primaryButton, px: 3 }}
              onClick={() => toggleOpenAddNew(true)}
            >
              {data.length === 0 ? "Add New" : "Update"}
            </Button>
          </Box>
        </Box>

        <Box
          sx={{ height: "calc(100% - 3rem)", overflow: "auto", padding: 2 }}
          className="style-scroll"
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
              height: "auto",
              width: "100%",
            }}
          >
            {data.length > 0 ? (
              data.map((a, i) => <EditableTextList key={i} text={a.data} />)
            ) : (
              <Box
                sx={{
                  width: "100%",
                  height: "10rem",
                  textAlign: "center",
                  color: "red",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  fontFamily: "montserrat",
                }}
              >
                You have not added any clause to the Privacy Policy yet.
              </Box>
            )}
          </Box>
        </Box>
      </Paper>
      <AddNewModal
        open={openAddNewModal}
        toggle={toggleOpenAddNew}
        toggleRefresh={toggleRefresh}
        data={editdata}
      />
    </>
  );
};

export default PrivacyPolicy;

const modules = {
  toolbar: [
    [
      { header: "1" },
      { header: "2" },
      { header: "3" },
      { font: ["Montserrat"] },
      { size: ["small", false, "large", "huge"] },
    ],
    [{ list: "ordered" }, { list: "bullet" }],
    ["bold", "italic", "underline", "strike"],
    ["link"],
    [{ align: [] }],
    [{ direction: "rtl" }],
    [{ indent: "-1" }, { indent: "+1" }],
    [{ color: [] }, { background: [] }],
    ["clean"],
  ],
};

const formats = [
  "header",
  "font",
  "size",
  "list",
  "bullet",
  "ordered",
  "check",
  "bold",
  "italic",
  "underline",
  "link",
  "strike",
  "align",
  "direction",
  "indent",
  "color",
  "background",
  "clean",
];

const AddNewModal = ({
  open,
  toggle,
  toggleRefresh,
  data,
}: {
  open: boolean;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
  data: string;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    defaultValues: {
      text: "",
    },
    mode: "onChange",
  });

  useEffect(() => {
    setValue("text", data);
  }, [data, setValue]);

  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: { text: string }) => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/terms-policies/add-update-privacy-policy`,
        data
      );
      if (res.status === 200) {
        toggleRefresh();
        toggle(false); // Close the modal after submission
        reset();
        return toast.success("Privacy Policy updated");
      }
    } catch (error) {
      console.log(error);
    }
    setLoading(false);
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: 300, sm: 450, md: "80%" },
          maxHeight: { xs: 450, md: "80%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Add Privacy Policy
        </Typography>

        {!loading ? (
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Description Input */}
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              <Typography
                variant="body1"
                sx={{
                  color: errors.text ? "red" : "black",
                  fontWeight: 500,
                }}
              >
                Text {errors.text && "is required"}
              </Typography>
              <Controller
                name="text"
                control={control}
                rules={{
                  required: true,
                  validate: (value) => {
                    const strippedContent = value
                      .replace(/<[^>]*>/g, "")
                      .trim();
                    return strippedContent.length > 0 || "Text cannot be empty";
                  },
                }}
                render={({ field }) => (
                  <ReactQuill
                    {...field}
                    ref={null} // React Hook Form manages refs
                    modules={modules}
                    formats={formats}
                    placeholder="Write here..."
                    style={{ marginTop: "10px", zIndex: "1300" }}
                  />
                )}
              />
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 2, textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3 }}
                type="submit"
              >
                Submit
              </Button>
            </Box>
          </form>
        ) : (
          <>
            <Paper
              elevation={0}
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "10rem",
                background: "transparent",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Paper>
          </>
        )}
      </Box>
    </Modal>
  );
};
