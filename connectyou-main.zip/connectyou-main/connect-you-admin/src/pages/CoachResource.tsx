import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Pagination,
  FormHelperText,
} from "@mui/material";
import { Edit, Delete, Visibility } from "@mui/icons-material";
import { useEffect } from "react";
import "react-quill/dist/quill.snow.css";
// Define the editor modules and formats for better type safety
import CloseIcon from "@mui/icons-material/Close";
import {
  Box,
  Button,
  MenuItem,
  Modal,
  Paper,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { useState } from "react";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import { Controller, useForm } from "react-hook-form";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { primaryButton } from "../utils/muibuttons";
import { ResourcesData } from "../types/ResourcesType";

interface Data {
  _id: string;
  title: string;
  description: string;
  availableFor: string;
}

const CoachResource = () => {
  const tabCols = [
    "Name",
    "Available For",
    "Published",
    "Last Updated",
    "Edit",
    "Delete",
    "View",
  ];
  const navigate = useNavigate();
  const [selectedData, setSelectedData] = useState<Data | null>(null);
  const [refresh, setRefresh] = useState<boolean>(false);
  const toggleRefresh = () => {
    setRefresh(!refresh);
  };

  const [loading, setLoading] = useState<boolean>(false);
  const [data, setData] = useState<ResourcesData[]>([]);
  const [pageInfo, setPageInfo] = useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = useState(1);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.get(
        `${backendURL}/admin/resources/list?limit=10&page=${pageNo}`
      );
      if (res.status === 200) {
        setSelectedData(null);
        setData(res.data.data);
        res.data.pageInfo && setPageInfo(res.data.pageInfo);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [refresh, pageNo]);

  // modal opener for adding new
  const [openAddNewModal, setOpenAddNewModal] = useState<boolean>(false);
  const toggleOpenAddNew = (b: boolean) => {
    setOpenAddNewModal(b);
  };

  // modal opener for update existing
  const [openUpdateResModal, setOpenUpdateResModal] = useState<boolean>(false);
  const toggleOpenUpdateRes = (b: boolean) => {
    setOpenUpdateResModal(b);
  };
  const [updateresourceId, setUpdateRes] = useState<string | null>(null);
  // Render the saved content in HTML format
  const handleEdit = ({
    resourceId,
    title,
    description,
    availableFor,
  }: {
    resourceId: string;
    title: string;
    description: string;
    availableFor: string;
  }) => {
    console.log("Edit clicked", resourceId);
    setUpdateRes(resourceId);
    toggleOpenUpdateRes(true);
    setSelectedData({
      _id: resourceId,
      title,
      description,
      availableFor,
    });
  };

  const handleDelete = ({ resourceId }: { resourceId: string }) => {
    console.log("Delete clicked", resourceId);
    setUpdateRes(resourceId);
    Swal.fire({
      title: "Are you sure?",
      text: "You want to remove this section?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, remove it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await httpAPI_admin.put(
          `${backendURL}/admin/resources/remove-resource/${resourceId}`
        );
        console.log(response);
        if (response.status === 200) {
          Swal.fire({
            title: "Removed!",
            text: "The section has been removed.",
            icon: "success",
            timer: 1500,
          });
          toggleRefresh();
        } else {
          toast.error(
            "There was some error while removing the section, Please try again"
          );
        }
      }
    });
  };

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "hidden",
          height: "calc(100vh - 88px)",
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px 1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Resources
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Button
              sx={{ ...primaryButton, px: 3 }}
              onClick={() => toggleOpenAddNew(true)}
            >
              Add +
            </Button>
          </Box>
        </Box>
        <Box
          sx={{ height: "calc(100% - 3rem)", overflow: "auto" }}
          className="style-scroll"
        >
          {data.length > 0 ? (
            <>
              <TableContainer
                sx={{
                  overflow: "auto",
                  maxHeight: "100%",
                }}
                className="style-scroll"
              >
                <Table stickyHeader aria-label="sticky table">
                  <TableHead sx={{ position: "sticky", top: 0, zIndex: 20 }}>
                    <TableRow>
                      {tabCols.map((a, i) => (
                        <TableCell
                          key={i}
                          sx={{ backgroundColor: "#013338", color: "white" }}
                        >
                          {a}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody sx={{ minHeight: "100%" }}>
                    {data.map((a, i) => (
                      <TableRow key={i}>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                            width: "auto",
                          }}
                        >
                          {a.title}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                            textTransform: "uppercase",
                          }}
                        >
                          {Array.isArray(a.availableFor)
                            ? a.availableFor.join(", ")
                            : a.availableFor}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                          }}
                        >
                          {dayjs(a.createdAt).format("DD MMMM YYYY hh:mm A")}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                          }}
                        >
                          {dayjs(a.updatedAt).format("DD MMMM YYYY hh:mm A ")}
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                            width: "5%",
                          }}
                        >
                          <IconButton
                            onClick={() =>
                              handleEdit({
                                resourceId: a._id,
                                title: a.title,
                                description: a.description,
                                availableFor: a.availableFor,
                              })
                            }
                          >
                            <Edit />
                          </IconButton>
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                            width: "5%",
                          }}
                        >
                          <IconButton
                            onClick={() => handleDelete({ resourceId: a._id })}
                          >
                            <Delete />
                          </IconButton>
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "#013338",
                            fontWeight: "semibold",
                            width: "5%",
                          }}
                        >
                          <IconButton
                            onClick={() => {
                              navigate(`details/${a._id}`);
                            }}
                          >
                            <Visibility />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                  {pageInfo.totalPages > 1 && (
                    <>
                      <TableRow
                        sx={{
                          position: "sticky",
                          bottom: 0,
                          zIndex: 2,
                        }}
                      >
                        <TableCell
                          colSpan={tabCols.length}
                          sx={{
                            background: "white",
                            px: 0,
                            pt: 0,
                            borderTop: "2px solid #ccc",
                          }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              justifyConten: "center",
                              alignItems: "center",
                              py: 2,
                              my: "auto",
                            }}
                          >
                            <Pagination
                              count={Number(pageInfo.totalPages)}
                              page={Number(pageInfo.currentPage)}
                              onChange={handlePagination}
                              sx={{
                                p: 0,
                              }}
                            />
                          </Box>
                        </TableCell>
                      </TableRow>
                    </>
                  )}
                </Table>
              </TableContainer>
            </>
          ) : (
            <Box
              sx={{
                width: "100%",
                height: "10rem",
                textAlign: "center",
                color: "red",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                fontFamily: "montserrat",
              }}
            >
              <Typography>You have not added any Coach Resource</Typography>
            </Box>
          )}
        </Box>
      </Paper>
      <AddNewModal
        open={openAddNewModal}
        toggle={toggleOpenAddNew}
        toggleRefresh={toggleRefresh}
      />
      {updateresourceId && selectedData && (
        <UpdateResourceModal
          open={openUpdateResModal}
          toggle={toggleOpenUpdateRes}
          toggleRefresh={toggleRefresh}
          title={selectedData.title}
          resourceId={updateresourceId}
          description={selectedData.description}
          availableFor={selectedData.availableFor}
        />
      )}
    </>
  );
};

export default CoachResource;

const AddNewModal = ({
  open,
  toggle,
  toggleRefresh,
}: {
  open: boolean;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    defaultValues: {
      title: "",
      description: "",
      availableFor: "",
    },
    mode: "onChange",
  });

  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: {
    title: string;
    description: string;
    availableFor: string;
  }) => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/resources/add-resource`,
        data
      );
      if (res.status === 200) {
        toggleRefresh();
        toggle(false); // Close the modal after submission
        reset();
        return toast.success("New coach resource added");
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "80%", sm: "80%", md: 450 },
          maxHeight: { xs: "80vh", md: "70%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Add Resource
        </Typography>

        {!loading ? (
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              {/* title Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.title ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Title
                </Typography>
                <Controller
                  name="title"
                  control={control}
                  rules={{
                    required: "Title is required",
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                    maxLength: {
                      value: 60,
                      message: "Title can have most 60 Characters",
                    },
                    minLength: {
                      value: 10,
                      message: "Title must have atleast 10 Characters",
                    },
                  }}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      hiddenLabel
                      helperText={errors.title?.message}
                      error={!!errors.title}
                    />
                  )}
                />
              </Box>
              {/* Description Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Description
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: "Description is required",
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 ||
                        "description cannot be empty"
                      );
                    },
                    maxLength: {
                      value: 400,
                      message: "description can have most 400 Characters",
                    },
                    minLength: {
                      value: 10,
                      message: "description must have atleast 10 Characters",
                    },
                  }}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      hiddenLabel
                      helperText={errors.description?.message}
                      error={!!errors.description}
                      multiline
                      maxRows={6}
                      rows={3}
                    />
                  )}
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.availableFor ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Resource Privacy
                </Typography>
                <Controller
                  name="availableFor"
                  control={control}
                  rules={{ required: "Please selected one of the options" }}
                  defaultValue=""
                  render={({ field }) => (
                    <Select
                      {...field}
                      displayEmpty
                      error={!!errors.availableFor}
                    >
                      <MenuItem value="">Please select a user type</MenuItem>
                      <MenuItem value="all">All </MenuItem>
                      <MenuItem value="coach">Coach</MenuItem>
                      <MenuItem value="coachee">Coachee</MenuItem>
                    </Select>
                  )}
                />
              </Box>
              {errors.availableFor?.message && (
                <FormHelperText sx={{ color: "red", paddingLeft: 2 }}>
                  {errors.availableFor?.message}
                </FormHelperText>
              )}
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 2, textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3 }}
                type="submit"
              >
                Submit
              </Button>
            </Box>
          </form>
        ) : (
          <>
            <Paper
              elevation={0}
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "10rem",
                background: "transparent",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Paper>
          </>
        )}
      </Box>
    </Modal>
  );
};

export const UpdateResourceModal = ({
  open,
  toggle,
  toggleRefresh,
  resourceId,
  title,
  description,
  availableFor,
}: {
  open: boolean;
  toggle: (b: boolean) => void;
  toggleRefresh: () => void;
  resourceId: string;
  title: string;
  description: string;
  availableFor: string;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    defaultValues: {
      title: "",
      description: "",
      availableFor: "",
    },
    mode: "onChange",
  });
  useEffect(() => {
    setValue("title", title);
    setValue("description", description);
    setValue("availableFor", availableFor);
  }, [title, description, setValue]);

  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: {
    title: string;
    description: string;
    availableFor: string;
  }) => {
    setLoading(true);
    try {
      const res = await httpAPI_admin.post(
        `${backendURL}/admin/resources/update-resource/${resourceId}`,
        data
      );
      if (res.status === 200) {
        toggleRefresh();
        toggle(false);
        reset();
        return toast.success("Resource has been updated !");
      }
    } catch (error) {
      console.log(error);
      toast.error("Some error while updating resource");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      sx={{ zIndex: "1200" }}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "80%", sm: "80%", md: 450 },
          maxHeight: { xs: "80vh", md: "70%" },
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
          zIndex: "1200",
        }}
      >
        <CloseIcon
          onClick={() => {
            reset();
            toggle(false);
          }}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />

        <Typography
          variant="h6"
          component="h2"
          sx={{ mb: 2, width: "100%", textAlign: "center" }}
        >
          Update Resource
        </Typography>
        {!loading ? (
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              {/* title Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.title ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Title
                </Typography>
                <Controller
                  name="title"
                  control={control}
                  rules={{
                    required: "Title is required",
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 || "Text cannot be empty"
                      );
                    },
                    maxLength: {
                      value: 60,
                      message: "Title can have most 60 Characters",
                    },
                    minLength: {
                      value: 10,
                      message: "Title must have atleast 10 Characters",
                    },
                  }}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      hiddenLabel
                      helperText={errors.title?.message}
                      error={!!errors.title}
                    />
                  )}
                />
              </Box>
              {/* Description Input */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.description ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Description
                </Typography>
                <Controller
                  name="description"
                  control={control}
                  rules={{
                    required: "Description is required",
                    validate: (value) => {
                      const strippedContent = value
                        .replace(/<[^>]*>/g, "")
                        .trim();
                      return (
                        strippedContent.length > 0 ||
                        "description cannot be empty"
                      );
                    },
                    maxLength: {
                      value: 1200,
                      message: "Description can have most 1200 Characters",
                    },
                    minLength: {
                      value: 10,
                      message: "description must have atleast 10 Characters",
                    },
                  }}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      hiddenLabel
                      helperText={errors.description?.message}
                      error={!!errors.description}
                      multiline
                      maxRows={6}
                      rows={3}
                    />
                  )}
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: errors.availableFor ? "red" : "black",
                    fontWeight: 500,
                  }}
                >
                  Resource Privacy
                </Typography>
                <Controller
                  name="availableFor"
                  control={control}
                  rules={{ required: "Please selected one of the options" }}
                  defaultValue=""
                  render={({ field }) => (
                    <Select
                      {...field}
                      displayEmpty
                      error={!!errors.availableFor}
                    >
                      <MenuItem value="">Please select a user type</MenuItem>
                      <MenuItem value="all">All </MenuItem>
                      <MenuItem value="coach">Coach</MenuItem>
                      <MenuItem value="coachee">Coachee</MenuItem>
                    </Select>
                  )}
                />
              </Box>
              {errors.availableFor?.message && (
                <FormHelperText sx={{ color: "red", paddingLeft: 2 }}>
                  {errors.availableFor?.message}
                </FormHelperText>
              )}
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 2, textAlign: "center" }}>
              <Button
                variant="contained"
                sx={{ ...primaryButton, px: 3 }}
                type="submit"
              >
                Submit
              </Button>
            </Box>
          </form>
        ) : (
          <>
            <Paper
              elevation={0}
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "10rem",
                background: "transparent",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Paper>
          </>
        )}
      </Box>
    </Modal>
  );
};
