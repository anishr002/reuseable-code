import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import SmsFailedIcon from "@mui/icons-material/SmsFailed";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import {
  Avatar,
  Box,
  Grid,
  Paper,
  TextField,
  Typography,
  useMediaQuery,
} from "@mui/material";

import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { ThreeDots } from "react-loader-spinner";

type UserProfile = {
  _id: string;
  name: string;
  image: string;
  Lname: string;
  email: string;
};

type ChatData = {
  _id: string;
  senderId: string;
  receiverId: string;
  chatRoomId: string;
  message: string;
  messageType: string;
  files: string[];
  createdAt: string;
  updatedAt: string;
  userProfile: UserProfile;
  coachProfile: UserProfile;
};

type User = {
  _id: string;
  count: number;
  ChatData: ChatData;
};

type MessageList = {
  _id: string;
  senderId: string;
  receiverId: string;
  chatRoomId: string;
  message: string;
  messageType: string;
  files: string[];
  createdAt: string;
  updatedAt: string;
};

const ChatHistory = () => {
  // test code here

  const renderFilePreview2 = (file: string) => {
    const fileUrl = `${backendURL}/messageFile/${file}`;
    const fileExtension = file.split(".").pop()?.toLowerCase();

    const downloadFile = async (file: string) => {
      const fileUrl = `${backendURL}/messageFile/${file}`;
      try {
        const response = await fetch(fileUrl);
        const blob = await response.blob();
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.setAttribute("download", file); // Set the filename for the download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        console.error("Failed to download the file:", error);
      }
    };

    const viewFile = (file: string) => {
      const fileUrl = `${backendURL}/messageFile/${file}`;
      const link = document.createElement("a");
      link.href = fileUrl;
      link.setAttribute("download", file); // Set the filename for the download
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    switch (fileExtension) {
      case "png":
      case "jpg":
      case "jpeg":
      case "gif":
      case "webp":
        return (
          <Box
            key={file}
            sx={{
              display: "flex",
              alignItems: "center",
              position: "relative",
              p: 0.31,
            }}
            onClick={() => viewFile(file)}
          >
            <img
              src={fileUrl}
              alt="Preview"
              style={{
                width: "14rem",
                height: "8rem",
                objectFit: "cover",
                borderRadius: 4,
              }}
            />

            <Box
              sx={{
                color: "gray",
                fontSize: "0.851rem",
                cursor: "pointer",
                position: "absolute",
                bottom: 0,
                right: 0,
                p: 0,
              }}
              onClick={() => downloadFile(file)}
            >
              <DownloadForOfflineIcon />
            </Box>
          </Box>
        );
      case "mp4":
      case "mov":
        return (
          <Box
            key={file}
            sx={{
              display: "flex",
              alignItems: "center",
              position: "relative",
              p: 0.31,
            }}
            onClick={() => viewFile(file)}
          >
            <video
              controls
              style={{
                width: "14rem",
                height: "8rem",
                objectFit: "cover",
                borderRadius: 4,
              }}
            >
              <source src={fileUrl} type={`video/${fileExtension}`} />
              Your browser does not support the video tag.
            </video>
            <Box
              sx={{
                color: "gray",
                fontSize: "0.851rem",
                cursor: "pointer",
                position: "absolute",
                bottom: 0,
                right: 0,
                p: 0,
              }}
              onClick={() => downloadFile(file)}
            >
              <DownloadForOfflineIcon />
            </Box>
          </Box>
        );
      case "pdf":
        return (
          <Box
            key={file}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
              p: 0.31,
              maxWidth: 300,
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
                px: 1,
              }}
            >
              <span
                style={{ marginRight: 3 }}
                role="img"
                aria-label="PDF Document"
              >
                📄
              </span>
              <span>{file}</span>
            </Box>
            <Box
              sx={{
                color: "gray",
                fontSize: "0.851rem",
                cursor: "pointer",
              }}
              onClick={() => downloadFile(file)}
            >
              <DownloadForOfflineIcon />
            </Box>
          </Box>
        );
      case "doc":
      case "docx":
      case "txt":
        return (
          <Box
            key={file}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
              p: 0.31,
              maxWidth: 300,
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
                px: 1,
              }}
            >
              <span
                style={{ marginRight: 3 }}
                role="file"
                aria-label="Word Document"
              >
                📝
              </span>
              <span>{file}</span>
            </Box>
            <Box
              sx={{
                color: "gray",
                fontSize: "0.851rem",
                cursor: "pointer",
              }}
              onClick={() => downloadFile(file)}
            >
              <DownloadForOfflineIcon />
            </Box>
          </Box>
        );
      default:
        return (
          <Box
            key={file}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
              p: 0.31,
              maxWidth: 300,
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
                px: 1,
              }}
            >
              <span
                style={{ marginRight: 3 }}
                role="img"
                aria-label="Unsupported File"
              >
                ❓
              </span>
              <span>{file}</span>
            </Box>
            <Box
              sx={{
                color: "gray",
                fontSize: "0.851rem",
                cursor: "pointer",
              }}
              onClick={() => downloadFile(file)}
            >
              <DownloadForOfflineIcon />
            </Box>
          </Box>
        );
    }
  };
  const messageEndRef = useRef<HTMLDivElement | null>(null);
  const { id, entity } = useParams();
  const [data, setdata] = useState<UserProfile>(); // for main coach / user data
  const [loading, setLoading] = useState<boolean>(true); //faching data main loading state
  const [loadingUserList, setLoadingUserList] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState<boolean>(false); //message loading

  const [searchQuery, setSearchQuery] = useState(""); // for search keywords.

  const isMobile = useMediaQuery("(max-width:880px)"); // media query
  const [isActive, setIsActive] = useState<string>(""); // also for mobile design or active user
  const [users, setUsers] = useState<User[]>([]); //store users list // of the all users that have messaged the coach / vice verse
  const [selectedUser, setSelectedUsers] = useState<UserProfile>(); //store users list store selected user data

  const [messageList, setMessageList] = useState<MessageList[]>([]); //store messsage array

  //handle search in inbox

  const filteredUsers = users.filter((user) =>
    (entity === "coach"
      ? user.ChatData.userProfile.name
      : user.ChatData.coachProfile.name
    )
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  );

  const fetchDataInboxList = async () => {
    setLoadingUserList(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/${entity}/${entity}-inbox/${id}`
      );
      if (response.status === 200) {
        setUsers(response.data.data);
        console.log(response.data.data);
        return setLoadingUserList(false);
      }
    } catch (error: any) {
      setLoadingUserList(false);
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        console.log("error");
        setLoadingUserList(false);
      } else {
        return setLoadingUserList(false);
      }
    } finally {
      setLoadingUserList(false);
    }
  };
  const fetchUserProfileData = async () => {
    console.log(entity, id);
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/${entity}/details/${id}`
      );
      console.log(response);
      if (response.status === 200) {
        if (entity === "user") {
          setdata(response.data.userData);
        } else if (entity === "coach") {
          setdata(response.data.data);
        }
        console.log(data);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setLoading(false);
    }
  };

  const fetchmessageList = async (chatRoomId: string) => {
    setLoadingMessage(true);
    console.log(chatRoomId);
    try {
      const response = await httpAPI_admin.get(
        `/admin/${entity}/${entity}-message-list/${chatRoomId}`
      );
      if (response.data.data) {
        console.log(response.data.data, "Messages");
        setMessageList(response.data.data);
        return setLoadingMessage(false);
      }
    } catch (error) {
      console.log({ error });
      return setLoadingMessage(false);
    } finally {
      setLoadingMessage(false);
    }
  };

  useEffect(() => {
    fetchUserProfileData();
    fetchDataInboxList();
  }, []);

  if (loading) {
    return (
      <Box
        sx={{
          width: "100%",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Box>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflowY: "scroll",
          overflowX: "hidden",
          maxHeight: "calc(100vh - 90px)",
          scrollbarWidth: "none",
        }}
      >
        <Grid
          container
          sx={{ height: { xs: "240px", sm: "200px", md: "160px" } }}
        >
          <Box
            sx={{
              background: "#013338",
              width: "100%",
              p: 1,
              height: { xs: "10rem", sm: "7rem" },
              position: "relative",
            }}
          >
            <Box
              display="flex"
              justifyContent="start"
              alignItems="start"
              margin="0 auto"
              padding="0 15px"
              width={"100%"}
              flexDirection={{ md: "row", sm: "column", xs: "column" }}
              height={{ md: 160, sm: 230, xs: 290 }}
              borderRadius="50%"
              position="absolute"
              sx={{
                top: "100%",
                transform: { md: "translateY(-50%)", xs: "translateY(-40%)" },
              }}
            >
              {data?.image ? (
                <Avatar
                  src={`${backendURL}/usersProfile/${data?.image}`}
                  alt="User"
                  sx={{
                    width: 110,
                    height: 110,
                  }}
                />
              ) : (
                <Box
                  display="flex"
                  justifyContent="center"
                  alignItems="center"
                  sx={{
                    width: 110,
                    height: 110,
                  }}
                  bgcolor="slategray"
                  borderRadius="50%"
                >
                  <Typography
                    variant="h6"
                    color="white"
                    sx={{ fontSize: "2.4rem" }}
                  >
                    {data?.name && capitalizeFirstLetter(data?.name)}
                  </Typography>
                </Box>
              )}
              <Box
                p={1}
                sx={{
                  width: "100%",
                  overflow: "hidden",
                  color: { sm: "#013338", xs: "#013338", md: "white" },
                }}
              >
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: "normal",
                    padding: "0 16px",
                    width: "100%",
                    whiteSpace: "nowrap",
                    textOverflow: { sm: "ellipsis" },
                  }}
                >
                  {data?.name &&
                    data?.name?.charAt(0).toUpperCase() +
                    data?.name?.slice(1)}{" "}
                  {entity === "coach" ? data?.Lname : ""}
                </Typography>
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: "400",
                    fontSize: "1rem",
                    padding: { xs: "5px", sm: "0 16px" },
                    whiteSpace: { lg: "nowrap", sm: "normal", xs: "balance" },
                  }}
                >
                  {data?.email}
                </Typography>
              </Box>
            </Box>
          </Box>
        </Grid>

        {users.length > 0 ? (
          <Grid
            container
            sx={{ height: "calc(100vh - 120px)", overflow: "auto" }}
          >
            <Grid
              display={isMobile ? (isActive ? "none" : "flex") : "flex"}
              flexDirection={"column"}
              item
              sm={12}
              xs={12}
              md={5}
              lg={4}
              height={"100%"}
              overflow={"auto"}
              sx={{ scrollbarWidth: "none" }}
            >
              <Typography variant="h5" color={"#013338"} px={2} height={50}>
                Conversation History
              </Typography>

              <Box
                display={isMobile ? (isActive ? "none" : "flex") : "flex"}
                width="100%"
                px={2}
              >
                <TextField
                  fullWidth
                  label="Search..."
                  id="rh45h56h5t"
                  variant="outlined"
                  size="small"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </Box>
              {loadingUserList ? (
                <>
                  <Box
                    sx={{
                      width: "100%",
                      height: "100%",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <ThreeDots
                      visible={true}
                      height="80"
                      width="80"
                      color="#31c6f8"
                      radius="9"
                      ariaLabel="three-dots-loading"
                      wrapperStyle={{}}
                      wrapperClass=""
                    />
                  </Box>
                </>
              ) : (
                <Box
                  display="flex"
                  flexDirection="column"
                  width="100%"
                  height={"100%"}
                  overflow={"auto"}
                  pt={1}
                >
                  {filteredUsers?.map((u, i) => (
                    <Box
                      key={i}
                      display={isMobile ? (isActive ? "none" : "flex") : "flex"}
                      width="100%"
                      gap={2}
                      py={1}
                      px={2}
                      alignItems="center"
                      sx={{
                        cursor: "pointer",
                        backgroundColor:
                          isActive ===
                            (entity === "coach"
                              ? u?.ChatData?.userProfile?._id
                              : u?.ChatData?.coachProfile?._id)
                            ? "#efefef"
                            : "inherit",
                        color:
                          isActive ===
                            (entity === "coach"
                              ? u?.ChatData?.userProfile?._id
                              : u?.ChatData?.coachProfile?._id)
                            ? "#013338"
                            : "inherit",
                        position: "relative",
                      }}
                      onClick={() => {
                        console.log(u?.ChatData?.chatRoomId);
                        console.log(u);
                        setSelectedUsers(
                          entity === "coach"
                            ? u?.ChatData?.userProfile
                            : u?.ChatData.coachProfile
                        );
                        setIsActive(
                          entity === "coach"
                            ? u?.ChatData?.userProfile?._id
                            : u?.ChatData?.coachProfile?._id
                        );
                        fetchmessageList(u?.ChatData?.chatRoomId);
                      }}
                    >
                      <Avatar
                        alt={
                          entity === "coach"
                            ? u?.ChatData?.userProfile?.name
                            : u?.ChatData?.coachProfile?.name
                        }
                        src={`${backendURL}/usersProfile/${entity === "coach"
                          ? u?.ChatData?.userProfile?.image
                          : u?.ChatData?.coachProfile?.image
                          }`}
                        sx={{ width: 40, height: 40 }}
                      />
                      <Box display="flex" flexDirection="column">
                        <Typography variant="subtitle1" fontWeight="medium">
                          {entity === "coach"
                            ? u?.ChatData?.userProfile?.name
                            : u?.ChatData?.coachProfile?.name +
                            " " +
                            u?.ChatData?.coachProfile?.Lname}
                        </Typography>
                        <Typography
                          variant="body2"
                          color="textSecondary"
                          noWrap
                          sx={{ maxWidth: { xs: 180, md: 140, lg: 288 } }}
                        >
                          {u?.ChatData?.message}
                        </Typography>
                        <Box position="absolute" top={"20%"} right={"5%"}>
                          <Typography
                            variant="caption"
                            noWrap
                            sx={{
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                              whiteSpace: "nowrap",
                              fontSize: "0.675rem",
                              color: "gray",
                            }}
                          >
                            {u?.ChatData?.updatedAt &&
                              new Date(
                                u?.ChatData?.updatedAt
                              ).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: true,
                              })}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </Grid>
            <Grid item sm={12} xs={12} md={7} lg={8} height={"100%"}>
              <Box
                display={
                  isMobile
                    ? isActive !== ""
                      ? "flex"
                      : "none"
                    : isActive
                      ? "flex"
                      : "none"
                }
                flexDirection="column"
                position="relative"
                height="100%"
              >
                {/* Header Section */}
                <Box
                  display="flex"
                  alignItems="center"
                  bgcolor="#013338"
                  px={4}
                  py={1}
                >
                  {isMobile && (
                    <Typography
                      variant="h6"
                      color="white"
                      sx={{ cursor: "pointer", pr: 4 }}
                      onClick={() => {
                        setIsActive("");
                        setSelectedUsers(undefined);
                      }}
                    >
                      <ArrowBackIosIcon
                        sx={{ fontSize: "small" }}
                        color="inherit"
                      />
                    </Typography>
                  )}
                  <Avatar
                    alt={selectedUser?.name}
                    src={`${backendURL}/usersProfile/${selectedUser?.image}`}
                    sx={{ width: 48, height: 48 }}
                  />
                  <Box ml={3} display="flex" flexDirection="column">
                    <Typography
                      variant="subtitle1"
                      fontWeight="bold"
                      color="white"
                    >
                      {entity === "coach"
                        ? selectedUser?.name
                        : selectedUser?.name + " " + selectedUser?.Lname}
                    </Typography>
                  </Box>
                </Box>

                {/* Messages Section */}
                <Box
                  display="flex"
                  flexDirection="column"
                  px={4}
                  py={6}
                  flex={1}
                  bgcolor="#F4F4F4"
                  sx={{ overflowY: "auto" }}
                >
                  {messageList.length > 0 ? (
                    messageList.map((u, i) => (
                      <Box
                        m={1}
                        key={i}
                        display="flex"
                        justifyContent={
                          selectedUser?._id !== u.receiverId
                            ? "flex-start"
                            : "flex-end"
                        }
                      >
                        <Box
                          p={0.4}
                          borderRadius={2}
                          maxWidth="300px"
                          minWidth="100px"
                          display={"flex"}
                          flexDirection={"column"}
                          justifyContent={"start"}
                          overflow={"hidden"}
                          textOverflow={"ellipsis"}
                          bgcolor={
                            selectedUser?._id !== u.receiverId
                              ? "#FFFFFF"
                              : "#fff"
                          }
                          color="black"
                          sx={{
                            position: "relative",
                            justifyContent: "start",
                          }}
                        >
                          {u.files && u.files.length > 0 && (
                            <Box
                              display={"flex"}
                              sx={{ flexDirection: "column", gap: "10px" }}
                            >
                              {u.files.map((file) => renderFilePreview2(file))}
                            </Box>
                          )}
                          {u.message && (
                            <Box
                              sx={{ py: 1, px: 1 }}
                              mt={u.files && u.files.length > 0 ? 2 : 0}
                            >
                              <Typography
                                variant="body2"
                                sx={{
                                  fontWeight: 500,
                                  color: "black",
                                  width: "100%",
                                  textAlign: "left",
                                  p: 0,
                                }}
                              >
                                {u.message}
                              </Typography>
                              <Box position="absolute" top={0} right={0} px={1}>
                                <Typography
                                  variant="h6"
                                  sx={{
                                    fontSize: "0.575rem",
                                    color: "gray",
                                    whiteSpace: "nowrap",
                                    fontFamily: "montserrat",
                                  }}
                                >
                                  {u?.updatedAt &&
                                    new Date(u.updatedAt).toLocaleTimeString(
                                      [],
                                      {
                                        hour: "2-digit",
                                        minute: "2-digit",
                                        hour12: false,
                                      }
                                    )}
                                </Typography>
                              </Box>
                            </Box>
                          )}
                        </Box>
                      </Box>
                    ))
                  ) : loadingMessage ? (
                    <Box
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                      height="100%"
                    >
                      Loading...
                    </Box>
                  ) : (
                    <Box
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                      height="100%"
                    >
                      No Messages
                    </Box>
                  )}
                  <div ref={messageEndRef} />
                </Box>

                {/* Message Send Container */}
              </Box>
            </Grid>
          </Grid>
        ) : (
          <>
            <Box
              sx={{
                width: "100%",
                height: "60vh",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                gap: 3,
              }}
            >
              <SmsFailedIcon sx={{ fontSize: "5rem" }} />
              <Typography variant="h6">
                This {entity} do not have any Chats available To display
              </Typography>{" "}
            </Box>
          </>
        )}
      </Paper>
    </>
  );
};

export default ChatHistory;

const capitalizeFirstLetter = (string: string) => {
  if (!string) return "E";
  return string.charAt(0).toUpperCase();
};
