import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import GroupIcon from "@mui/icons-material/Group";
import {
  Box,
  FormControl,
  MenuItem,
  Pagination,
  Select,
  TableCell,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import { StripeTransaction } from "./dashboard/Dashboard";

export default function StripeTransactions() {
  const [transactions, setTransactions] = React.useState<
    StripeTransaction[] | null
  >(null);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [filterTerm, setFilterTerm] = React.useState<number>(0); // defaults to all
  const handleChangeFilter = (event: any) => {
    setFilterTerm(event.target.value);
    setPageNo(1);
    setLastItem(null);
  };

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };
  const [lastItem, setLastItem] = React.useState<string | null>(null);
  React.useEffect(() => {
    if (transactions) {
      setLastItem(transactions[transactions.length - 1].id);
    }
  }, [transactions]);

  const fetchBalance = async (filterType = 0, page = 1, limit = 10) => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/txn-history/transactions/fetch-stripe-balance`,
        {
          params: {
            filter: filterType, // 0 = all, 1 = debits, 2 = credits
            page, // Current page number
            limit, // Number of items per page
            starting_after: lastItem,
          },
        }
      );

      if (response.status === 200) {
        const { transactions, totalPages } = response.data;
        setTransactions(transactions);
        setPageInfo({
          currentPage: pageNo,
          totalPages: totalPages,
        });
      }
    } catch (error) {
      console.error("Error fetching balance and transactions:", error);
    } finally {
      setLoading(false);
    }
  };
  React.useEffect(() => {
    fetchBalance(filterTerm, pageNo, 20);
  }, [pageNo, filterTerm]);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `calc(100vh - 88px)`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Box
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              color: "#013338",
            }}
          >
            Stripe Transactions{" "}
            {filterTerm === 0
              ? "(All) "
              : filterTerm === 1
                ? "(Debit) "
                : "(Credit) "}
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            >
              <Select
                displayEmpty
                size="small"
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={filterTerm}
                onChange={handleChangeFilter}
                sx={{
                  color: "#013338",
                  borderColor: "#013338",
                  fontSize: "0.775rem",
                  "& .MuiSelect-icon": {
                    color: "#013338", // Set the color of the dropdown icon
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#013338", // Set border color
                  },
                }}
              >
                <MenuItem sx={{ fontSize: "0.775rem" }} value={0}>
                  <em>All</em>
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                  DEBIT
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                  CREDIT
                </MenuItem>
              </Select>
            </FormControl>
            <GroupIcon style={{ color: "#013338" }} />
          </Box>
        </Box>
        {transactions && transactions.length > 0 ? (
          <TableContainer
            sx={{
              maxHeight: {
                lg:
                  pageInfo.totalPages > 1
                    ? "calc(100vh - 240px)"
                    : "calc(100vh - 170px)",
                xl: "auto",
              },
              overflow: "auto",
            }}
          >
            <Table stickyHeader sx={{ maxHeight: "100%" }}>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ color: "white", background: "#013338" }}>
                    Sr No.
                  </TableCell>
                  <TableCell sx={{ color: "white", background: "#013338" }}>
                    Amount
                  </TableCell>
                  <TableCell sx={{ color: "white", background: "#013338" }}>
                    Type
                  </TableCell>
                  <TableCell sx={{ color: "white", background: "#013338" }}>
                    Transfer
                  </TableCell>
                  <TableCell sx={{ color: "white", background: "#013338" }}>
                    Dated
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {transactions.map((d, i) => (
                  <React.Fragment key={i}>
                    <TableRow>
                      <TableCell>{i + 1}</TableCell>
                      <TableCell>
                        <span
                          style={{
                            color: Number(d.amount) > 0 ? "green" : "red",
                          }}
                        >
                          $ {(d.amount / 100).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span
                          style={{
                            color: Number(d.amount) > 0 ? "green" : "red",
                          }}
                        >
                          {d.amount > 0 ? "CREDIT" : "DEBIT"}
                        </span>
                      </TableCell>
                      <TableCell sx={{ textTransform: "uppercase" }}>
                        {d.type}
                      </TableCell>
                      <TableCell>
                        {!isNaN(Number(d.created))
                          ? new Date(Number(d.created) * 1000).toLocaleString()
                          : "-"}
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <NoDataIllustration message="You do not have any transactions" />
        )}
        {pageInfo.totalPages > 1 && (
          <Box
            sx={{
              display: "flex",
              justifyConten: "center",
              alignItems: "center",
              paddingY: 2,
              borderTop: "2px solid #ccc",
            }}
          >
            <Pagination
              count={Number(pageInfo.totalPages)}
              page={Number(pageInfo.currentPage)}
              onChange={handlePagination}
            />
          </Box>
        )}
      </Paper>
    </>
  );
}
