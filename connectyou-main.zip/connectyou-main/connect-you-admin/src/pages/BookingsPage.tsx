// import CheckCircleIcon from "@mui/icons-material/CheckCircle";
// import CancelIcon from "@mui/icons-material/Cancel";
// import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import { Visibility } from "@mui/icons-material";
// import SearchIcon from "@mui/icons-material/Search";

import {
  Avatar,
  AvatarGroup,
  Box,
  Button,
  createTheme,
  Pagination,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import { ThreeDots } from "react-loader-spinner";
import { Link } from "react-router-dom";
import apiBaseUrl from "../URLconf";
import { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThemeProvider } from "@emotion/react";
import moment from "moment-timezone";
import NoDataIllustration from "../components/NoDataIllustration";
const backendURL = apiBaseUrl;

interface UserData {
  _id: string;
  name: string;
  image: string;
  timeZone: string;
}

interface CoachData {
  _id: string;
  name: string;
  Lname: string;
  userName: string;
  gender: string;
  email: string;
  image: string;
  timeZone: string;
}

interface HistoryType {
  _id: string;
  userId: string;
  orderStatus: number;
  createdAt: string;
  userData: UserData;
  totalBookedAmount: number;
  coachData: CoachData[];
  bookedSessionsCount: number;
  upcomingCount: number;
  completedCount: number;
  cancelledCount: number;
}

const BookingsPage = () => {
  //   data
  const [bookingList, setBookingList] = React.useState<HistoryType[]>([]);

  // loading states controls
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [searchTerm, setSearchTerm] = useState<string | null>(null);
  const [filterSearch, setFilterSearch] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `admin/booking/booking-history?pageNo=${pageNo}&searchTerm=${filterSearch ? (filterSearch !== "" ? filterSearch : "") : ""
        }`
      );
      if (response.data.data) {
        setLoading(false);
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        return setBookingList(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      setLoading(false);
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  // pagination controls
  const [pageNo, setPageNo] = React.useState(1);
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 10,
    currentPage: 1,
  });
  const [pageUpdated] = React.useState<boolean>(false);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  //use Effects
  React.useEffect(() => {
    fetchData();
  }, [pageNo, pageUpdated, filterSearch]);

  const theme = createTheme({
    typography: {
      fontFamily: "montserrat",
    },
  });

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <Paper
        sx={{
          width: "100%",
          height: `${bookingList.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            gap: "5px",
            alignItems: "center",
            color: "#013338",
          }}
        >
          <span>Bookings History</span>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                display: "flex",
                gap: 2,
                alignItems: "center",
              }}
            >
              <TextField
                id="outlined-search"
                placeholder="Search..."
                type="search"
                variant="outlined"
                fullWidth
                size="small"
                value={searchTerm}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  if (event.target.value !== "") {
                    setSearchTerm(event.target.value);
                  } else setSearchTerm(null);
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                    backgroundColor: "#fff",
                  },
                }}
              />
              <Button
                sx={{
                  paddingX: 3,
                  backgroundColor: "#31c6f8",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "#31c6f8",
                  },
                }}
                onClick={() => setFilterSearch(searchTerm)}
              >
                Search
              </Button>
            </Box>
          </Box>
        </Typography>
        {bookingList?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 220px)",
                overflow: "auto",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead
                  sx={{
                    padding: "1px",
                    fontFamily: "montserrat",
                    "& .MuiTableCell-head": { lineHeight: "normal" },
                  }}
                >
                  <TableRow
                    sx={{ textTransform: "uppercase", fontWeight: "500" }}
                  >
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Total Session
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Up Coming
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Completed
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Cancelled
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Price {"($)"}
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Booking Date
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Coach
                    </TableCell>
                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Client
                    </TableCell>

                    <TableCell
                      sx={{
                        color: "white",
                        backgroundColor: "#013338",
                      }}
                    >
                      Details
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {bookingList.map((u, i) => (
                    <TableRow key={i} hover role="checkbox" tabIndex={-1}>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                        }}
                      >
                        {u.bookedSessionsCount}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                        }}
                      >
                        {u.upcomingCount}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                        }}
                      >
                        {u.completedCount}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                        }}
                      >
                        {u.cancelledCount}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                        }}
                      >
                        ${u.totalBookedAmount}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {moment(u.createdAt).format("DD-MM-YYYY hh:mm A")}
                      </TableCell>
                      <TableCell>
                        <Box
                          sx={{
                            color: "#013338",
                            fontWeight: "600",
                            padding: 0,
                            display: "flex",
                            alignItems: "center",
                          }}
                        >
                          <AvatarGroup max={3}>
                            {u.coachData.map((c, j) => (
                              <Avatar
                                key={j}
                                alt={c.name}
                                src={`${backendURL}/usersProfile/${c.image}`}
                              />
                            ))}
                          </AvatarGroup>
                        </Box>
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "#013338",
                          fontWeight: "600",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            gap: 2,
                            width: "100%",
                          }}
                        >
                          <Avatar
                            alt={u.userData.name}
                            src={`${backendURL}/usersProfile/${u.userData.image}`}
                          />
                          <Typography
                            variant="body2"
                            sx={{
                              whiteSpace: "nowrap",
                              textOverflow: "ellipsis",
                              overflow: "hidden",
                              fontWeight: 600,
                            }}
                          >
                            {u.userData.name}
                          </Typography>
                        </Box>
                      </TableCell>

                      <TableCell
                        sx={{
                          whiteSpace: "nowrap",
                        }}
                      >
                        <Link to={`detail/${u._id}`}>
                          <Visibility color="primary" />
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                {/* end of table body  */}
              </Table>
              {/* emd of the table container  */}
            </TableContainer>
            {pageInfo?.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo.totalPages)}
                  page={Number(pageInfo.currentPage)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration />
        )}
        {/* paginations   */}
      </Paper>
    </ThemeProvider>
  );
};

export default BookingsPage;
