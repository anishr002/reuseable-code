import React, { useState } from "react";
import { AxiosError } from "axios";
import backendURL, { httpAPI_admin } from "../../AxiosAPI";
import {
  Box,
  Button,
  Typography,
  CircularProgress,
  Alert,
  Container,
  Select,
  MenuItem,
  FormControl,
  FormLabel,
  FormHelperText,
} from "@mui/material";
import { BulkAddOppAPIRes } from "../../types/BulkAddReports";
import { Controller, useForm } from "react-hook-form";

const SyncCoachesFromHubspot: React.FC = () => {
  const [syncing, setsyncing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);
  const [result, setResult] = useState<BulkAddOppAPIRes | null>(null);
  interface FormValues {
    filter: string;
  }
  const {
    control,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm<FormValues>({
    mode: "onChange",
    reValidateMode: "onChange",
  });

  const onSubmit = handleSubmit(async (data: FormValues) => {
    setsyncing(true);
    setError(null);
    setSuccess(false);
    try {
      const response = await httpAPI_admin.post(
        `${backendURL}/hub/api-v3/sync-data/sync-coaches`,
        { filter: data.filter }
      );
      if (response.status === 200) {
        if (response.data.success) {
          setSuccess(true);
          setResult(response.data);
        } else if (response.data.success === false) {
          setSuccess(true);
          setResult(response.data);
        }
      } else {
        setError("Failed to upload the file. Please try again.");
      }
    } catch (err) {
      const error = err as AxiosError;
      setError(error.message || "An error occurred while syncing the file.");
      console.error(error);
    } finally {
      setsyncing(false);
    }
  });

  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        alignItems: "start",
        justifyContent: "start",
        flexDirection: "column",
        px: 1,
      }}
    >
      <Box
        sx={{
          width: "100%",
          pb: 4,
          bgcolor: "#fff",
          borderRadius: 2,
        }}
      >
        {/* Title */}
        <Container
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
            borderBottom: "1px solid #ddd",
            pb: 2,
          }}
        >
          <Typography
            variant="h6"
            fontWeight="bold"
            color="#013338"
            textAlign="left"
            py={2}
          >
            Sync coaches from hubspot
          </Typography>

          {error && (
            <Alert
              severity="error"
              sx={{ mt: 2, width: "fit-content", minWidth: 300, px: 4 }}
            >
              {error}
            </Alert>
          )}

          {/* Success Message */}
          {success && (
            <Alert
              severity="success"
              sx={{ mt: 2, width: "fit-content", minWidth: 300, px: 4 }}
            >
              Sync task completed successfully!
            </Alert>
          )}
        </Container>

        <Container
          sx={{
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          {syncing ? (
            <Alert severity="warning">
              Please do not leave or refresh this page until the loading is
              completed.
            </Alert>
          ) : (
            <Box sx={{ width: 350 }}>
              <Controller
                name="filter"
                defaultValue={""}
                control={control}
                rules={{
                  required: "Please select a contact status",
                }}
                render={({ field }) => (
                  <FormControl fullWidth error={!!errors.filter}>
                    <FormLabel
                      sx={{
                        color: "#013338",
                        ps: 2,
                        mb: 0.42,
                        fontWeight: 600,
                      }}
                    >
                      Coach Status
                    </FormLabel>
                    <Select fullWidth displayEmpty {...field}>
                      <MenuItem value="">Please select</MenuItem>
                      {[
                        "Known",
                        "Shortlisted",
                        "Submitted a profile",
                        "Shortlisted & invited to an assessment",
                        "Assessed",
                        "Onboarding",
                        "Onboarded & available on the site",
                        "We chose not to work with them",
                        "They chose not to work with us",
                        "Invited to an assessment",
                        "Invited to submit a video",
                      ].map((a, i) => (
                        <MenuItem
                          key={`Coach-Profile-status-options-item-${i}`}
                          value={a}
                        >
                          {a}
                        </MenuItem>
                      ))}
                    </Select>
                    {errors.filter?.message && (
                      <FormHelperText>{errors.filter?.message}</FormHelperText>
                    )}
                  </FormControl>
                )}
              />
            </Box>
          )}

          {/* Upload Button */}
          <Button
            onClick={() => onSubmit()}
            variant="contained"
            sx={{
              width: 200,
              bgcolor: "#013338",
              color: "white",
              "&:hover": { bgcolor: "#002a2e" },
            }}
            disabled={syncing || !watch("filter")}
          >
            {syncing ? (
              <CircularProgress size={24} color="inherit" />
            ) : (
              "Start Syncing"
            )}
          </Button>
        </Container>

        {result && (
          <Box sx={{ mt: 3, p: 2, borderRadius: 1 }}>
            <Typography fontWeight="bold" color="#013338">
              Task Summary
            </Typography>
            <Typography>
              Coaches Found: {result?.data?.contactsFound}
            </Typography>
            <Typography>
              Successful Entries: {result?.data?.successNumber}
            </Typography>
            <Typography>
              Failed Entries: {result?.data?.failureNumber}
            </Typography>

            {/* Download Buttons */}
            <Box
              sx={{ mt: 2, display: "flex", flexDirection: "column", gap: 1 }}
            >
              {result?.files?.success && (
                <a
                  href={`${backendURL}/files/${result?.files?.success}`}
                  download={`${backendURL}/files/${result?.files?.success}`}
                >
                  <Button
                    variant="outlined"
                    sx={{
                      color: "#013338",
                      borderColor: "#013338",
                      width: 300,
                    }}
                  >
                    Download Successful Entries
                  </Button>
                </a>
              )}
              {result?.files?.failure && (
                <a
                  href={`${backendURL}/files/${result?.files?.failure}`}
                  download={`${backendURL}/files/${result?.files?.failure}`}
                >
                  <Button
                    variant="outlined"
                    sx={{
                      color: "#d32f2f",
                      borderColor: "#d32f2f",
                      width: 300,
                    }}
                  >
                    Download Failed Entries
                  </Button>
                </a>
              )}
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default SyncCoachesFromHubspot;
