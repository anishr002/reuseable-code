import Logo from "../assets/Logo.png";
import {
  Box,
  Button,
  Card,
  CircularProgress,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { useForm, Resolver } from "react-hook-form";
import backendURL from "../AxiosAPI";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { adminLogin } from "../slices/Login";

type FormValues = {
  email: string;
  password: string;
};
const resolver: Resolver<FormValues> = async (values) => {
  return {
    values: values.email && values.password ? values : {},
    errors: {
      ...(values.email
        ? {}
        : { email: { type: "required", message: "Email is required." } }),
      ...(values.password
        ? {}
        : { password: { type: "required", message: "Password is required." } }),
    },
  };
};
const LoginPage = () => {
  // const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  // const [showPassword, setShowPassword] = useState(false);
  const [showPassword] = useState(false);
  const [loading, setLoading] = useState(false); //loading behaviour on form submit

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({ resolver });
  const onSubmit = handleSubmit(async (data) => {
    setLoading(true);
    try {
      const response = await axios.post(`${backendURL}/admin/login`, data);
      if (response.status === 200) {
        const authToken = response.data.data.token;
        localStorage.setItem("authToken", authToken);
        const loginUserData = JSON.parse(atob(authToken.split(".")[1])); //store the login user data
        dispatch(adminLogin(loginUserData));
        navigate("/");
        return setLoading(false);
      }
    } catch (error: any) {
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        toast.error(
          error.response.data.message
            ? error.response.data.message
            : "Something went wrong"
        );
        return setLoading(false);
      }
    } finally {
      return setLoading(false);
    }
  });

  return (
    <>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          backgroundColor: "#F3F5F6",
          overflow: "auto",
        }}
      >
        <Stack alignItems="center" justifyContent="center" sx={{ height: 1 }}>
          <Card
            sx={{
              p: 5,
              width: 1,
              maxWidth: 420,
              borderRadius: 4,
            }}
          >
            <Stack alignItems="center" justifyContent="center" sx={{ mb: 3 }}>
              <img
                alt="Coaching"
                src={Logo}
                style={{
              
                  height: "60px",
                  marginRight: "10px",
                  objectFit: "contain",
                }}
              />
            </Stack>

            <Typography
              variant="h6"
              sx={{ my: 3, fontWeight: "bold", color: "#5FB6D5" }}
            >
              Login
            </Typography>
            <form onSubmit={onSubmit}>
              <Stack spacing={3}>
                <TextField
                  size="small"
                  label="Email address"
                  {...register("email", {
                    required: "Please enter email",
                    pattern: {
                      value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                      message: "Please enter valid email address",
                    },
                  })}
                  error={!!errors.email}
                  helperText={errors.email?.message}
                />

                <TextField
                  size="small"
                  {...register("password", {
                    required: "Please enter password",
                  })}
                  label="Password"
                  type={showPassword ? "text" : "password"}
                  error={!!errors.password}
                  helperText={errors.password?.message}
                  // InputProps={{
                  //   endAdornment: (
                  //     <InputAdornment position="end">
                  //       <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                  //         <Icon icon={showPassword ? eyeFill : eyeOffFill} />
                  //       </IconButton>
                  //     </InputAdornment>
                  //   ),
                  // }}
                />
              </Stack>

              <Stack sx={{ my: 3 }}>
                <Button
                  fullWidth
                  size="small"
                  type="submit"
                  variant="contained"
                  sx={{ backgroundColor: "#5FB6D5" }}
                >
                  {loading ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : (
                    "Login"
                  )}
                </Button>
              </Stack>
            </form>
          </Card>
        </Stack>
      </Box>
      <ToastContainer theme="colored" />
    </>
  );
};

export default LoginPage;
