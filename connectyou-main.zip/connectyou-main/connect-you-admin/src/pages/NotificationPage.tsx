/* eslint-disable @typescript-eslint/no-explicit-any */
import Logo from "../assets/Logo.png";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import Paper from "@mui/material/Paper";
import Modal from "@mui/material/Modal";
import CloseIcon from "@mui/icons-material/Close";
import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Pagination,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { ThreeDots } from "react-loader-spinner";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { Link } from "react-router-dom";
import { setCount } from "../slices/Notification";
import Swal from "sweetalert2";

interface AddNotificationModalProps {
  open: boolean;
  handleClose: () => void;
}
export interface Notification {
  _id: string;
  user_id: string;
  heading: string;
  description: string;
  url: string;
  readStatus: boolean;
  createdAt: string;
  unreadNotifications: number;
}

const AddNotificationModal: React.FC<AddNotificationModalProps> = (props) => {
  const { open, handleClose } = props;
  const [usertype, setUserType] = React.useState("");
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [image, setImage] = React.useState<File | null>(null);
  const [imagePreview, setImagePreview] = React.useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    // Handle form submission here
    console.log({ usertype, title, description, image });
  };

  return (
    <div>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            width: "90%",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: 400,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography id="modal-modal-title" variant="h6" component="h2" mb={2}>
            Add Notification
          </Typography>

          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel id="usertype-label">User Type</InputLabel>
            <Select
              labelId="usertype-label"
              id="usertype"
              value={usertype}
              onChange={(e) => setUserType(e.target.value)}
              label="User Type"
            >
              <MenuItem value="seller">Coach</MenuItem>
              <MenuItem value="buyer">User</MenuItem>
              <MenuItem value="buyer">All</MenuItem>
            </Select>
            {imagePreview && (
              <img
                src={imagePreview}
                alt="Preview"
                style={{ maxWidth: "100%", height: "200px", marginTop: "8px" }}
              />
            )}
            <input
              accept="image/*"
              style={{ display: "none" }}
              id="image-upload"
              type="file"
              onChange={handleImageChange}
            />
            <label htmlFor="image-upload">
              {/* add something here like url  */}
            </label>
          </FormControl>
          <TextField
            fullWidth
            id="title"
            label="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            variant="outlined"
            sx={{ mb: 2 }}
          />
          <TextField
            fullWidth
            id="description"
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            variant="outlined"
            multiline
            rows={4}
            sx={{ mb: 2 }}
          />

          <Button variant="contained" onClick={handleSubmit}>
            Submit
          </Button>
        </Box>
      </Modal>
    </div>
  );
};

// modal section end
export default function NotificationPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loginUserData = useSelector((state: any) => state.adminLogin.userdata);
  const unreadNotifications = useSelector(
    (state: any) => state.unreadCount.unReadNotificationCount
  );
  const [totalPages, settotalPages] = useState<number>(1);
  const [page, setPage] = useState<number>(1);
  const [filter, setFilter] = useState<number>(0);

  const dispatch = useDispatch();
  const fetchNotifications = async () => {
    try {
      const response = await httpAPI_admin.post(
        `${backendURL}/admin/profile/get-all-notifications?page=${page <= 0 ? 1 : page
        }&limit=${20}&filter=${filter}`,
        { _id: loginUserData._id }
      );

      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        console.log(response.data);
        setNotifications(response.data.data);
        dispatch(setCount(response.data.unreadNotifications));
        settotalPages(Number(response.data.totalPages));
      }
    } catch (error: any) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [page, filter, totalPages]);

  const handleChangeFilter = (e: SelectChangeEvent<number>) => {
    setFilter(Number(e.target.value));
    setPage(1);
  };
  //handel modal activity
  const [open, setOpen] = useState(false);
  // const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          maxHeight: "calc(100vh - 85px)",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box
          sx={{
            width: "100%",
            height: { xs: "10rem", md: "5rem" },
            postion: "sticky",
            top: 0,
            left: 0,
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            justifyContent: { xs: "start", md: "space-between" },
            alignItems: { xs: "start", md: "center" },
            boxShadow: "0px 2px 6px rgba(0, 0, 0, 0.2)",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              padding: "1rem 20px",
              width: "fit-content",
              display: "flex",
              justifyContent: "space-between",
              gap: "5px",
              alignItems: "center",
              color: "#013338",
            }}
          >
            <span> Notification</span>
            {unreadNotifications > 0 && (
              <span
                style={{
                  background: "#ebbe34",
                  color: "white",
                  width: "25px",
                  height: "25px",
                  borderRadius: "50%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  fontSize: "0.751rem",
                  padding: 2,
                }}
              >
                {unreadNotifications > 99 ? "99+" : unreadNotifications}
              </span>
            )}
            {/* <Button
              onClick={handleOpen}
              variant="contained"
              sx={{ marginLeft: "auto", paddingX: 6 }}
            >
              Add
            </Button> */}
          </Typography>
          <Box
            sx={{
              display: "flex",

              px: 2,
              alignItems: "center",
              gap: 2,
            }}
          >
            {unreadNotifications > 0 && (
              <Button
                variant="outlined"
                onClick={() => {
                  Swal.fire({
                    title: "Mark all as read?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#EBBE34",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Read All !",
                  }).then(async (result) => {
                    if (result.isConfirmed) {
                      try {
                        const response = await httpAPI_admin.put(
                          `${backendURL}/admin/profile/notification/mark-all-as-read`,
                          { _id: loginUserData._id }
                        );
                        console.log({ "mark as read": response.data });
                        if (response.status === 200) {
                          fetchNotifications();
                          Swal.fire({
                            title: "Success!",
                            text: "All the notifications have been marked as read.",
                            icon: "success",
                            timer: 1500,
                            showConfirmButton: false,
                          });
                        } else {
                          console.error(
                            "Some Error While getting notifications."
                          );
                        }
                      } catch (error: any) {
                        console.log(error);
                      }
                    }
                  });
                }}
                sx={{
                  color: "white",
                  backgroundColor: "#EBBE34",
                  borderColor: "#EBBE34",
                  borderRadius: "20px",
                  fontFamily: "Montserrat",
                  "&:hover": {
                    borderColor: "#EBBE34",
                    backgroundColor: "white",
                    color: "#EBBE34",
                  },
                }}
              >
                Mark All As Read
              </Button>
            )}
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            >
              <InputLabel
                id="demo-select-small-label"
                sx={{
                  color: "#013338",
                  fontSize: "0.975rem",
                  "&.Mui-focused": {
                    color: "#013338", // Change label color when focused
                  },
                }}
              >
                FILTER
              </InputLabel>
              <Select
                size="small"
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={filter}
                label="filterTerm"
                onChange={handleChangeFilter}
                sx={{
                  color: "#013338",
                  borderColor: "#013338",
                  fontSize: "0.775rem",
                  "& .MuiSelect-icon": {
                    color: "#013338", // Set the color of the dropdown icon
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#013338", // Set border color
                  },
                }}
              >
                <MenuItem sx={{ fontSize: "0.775rem" }} value={0}>
                  All
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                  Unread
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                  Read
                </MenuItem>
              </Select>
            </FormControl>
          </Box>
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "start",
            alignItems: "start",
            gap: 4,
            pt: 3,
            px: 1,
            overflow: "auto",
            height: { xs: "calc(100vh - 10rem)", md: "calc(100vh - 7rem)" },
            pb: "10rem",
          }}
        >
          {loading ? (
            <Box
              sx={{
                width: "100%",
                height: "20rem",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#3aa7a3"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </Box>
          ) : (
            <>
              <NotificationCard
                Notifications={notifications}
                fetchNotifications={fetchNotifications}
                type={"admin"}
              />
            </>
          )}
        </Box>
        <Box
          sx={{
            display: "flex",
            justifyConten: "center",
            alignItems: "center",
            paddingY: 2,
            borderTop: "2px solid #ccc",
          }}
        >
          <Pagination
            count={totalPages}
            page={page}
            onChange={(e, value) => {
              console.log(e);
              setPage(value);
            }}
          />
        </Box>
      </Paper>
      <AddNotificationModal open={open} handleClose={handleClose} />
    </>
  );
}

const NotificationCard = ({
  Notifications,
  fetchNotifications,
  type,
}: {
  Notifications: Notification[];
  fetchNotifications: () => void;
  type: string;
}) => {
  const [selectedNotification, setSelectedNotification] =
    useState<Notification | null>(null);

  const handleViewDetails = (notification: Notification) => {
    setSelectedNotification(notification);
  };

  const closeModal = () => {
    setSelectedNotification(null);
  };

  const MarkAsRead = async ({ _id }: { _id: string }) => {
    try {
      const response = await httpAPI_admin.put(
        `${backendURL}/${type}/profile/notification/mark-as-read`,
        { _id }
      );
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        fetchNotifications();
      }
    } catch (error: any) {
      console.log(error);
    }
  };

  return (
    <>
      {Notifications?.length > 0 ? (
        <>
          {Notifications.map((n: Notification, i: number) => (
            <Paper
              key={i}
              sx={{
                display: "flex",
                flexDirection: { xs: "column", md: "row" },
                justifyContent: "flex-start",
                alignItems: "flex-start",
                gap: 2,
                padding: 2,
                backgroundColor: n.readStatus ? "white" : "#EBF5F9",
                boxShadow: 1,
                position: "relative",
                width: "100%",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <IconButton
                  sx={{
                    border: `8px solid ${n.readStatus ? "#737373" : "#013338"}`,
                    borderRadius: "50%",
                    padding: 2,
                    minWidth: 48,
                    minHeight: 48,
                  }}
                >
                  {n.readStatus ? (
                    <NotificationsNoneIcon sx={{ color: "#737373" }} />
                  ) : (
                    <NotificationsActiveIcon sx={{ color: "#013338" }} />
                  )}
                </IconButton>
              </Box>

              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "flex-start",
                  alignItems: "flex-start",
                  width: "100%",
                }}
              >
                <Typography
                  sx={{
                    color: n.readStatus ? "#737373" : "#013338",
                    fontWeight: "bold",
                    fontSize: "1rem",
                  }}
                >
                  {n.heading}
                </Typography>
                <Typography
                  sx={{
                    position: "absolute",
                    top: 0,
                    right: 2,
                    fontSize: "0.75rem",
                    color: n.readStatus ? "#737373" : "#013338",
                    py: 1,
                  }}
                >
                  {new Date(n.createdAt).toLocaleString()}
                </Typography>
                <Typography
                  sx={{
                    fontSize: "0.875rem",
                    color: "#737373",
                    lineClamp: 1,
                    width: { xs: "100%", md: "33%" },
                  }}
                  noWrap
                >
                  {n.description}
                </Typography>

                <Button
                  variant="text"
                  sx={{ fontSize: "0.875rem", color: "gray" }}
                  onClick={() => {
                    handleViewDetails(n);
                    MarkAsRead({ _id: n._id });
                  }}
                >
                  Read More
                </Button>
              </Box>
            </Paper>
          ))}
        </>
      ) : (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
            width: "100%",
            color: "red",
          }}
        >
          <Typography>No Notifications!</Typography>
        </Box>
      )}

      {selectedNotification && (
        <NotificationDetailsModal
          notification={selectedNotification}
          closeModal={closeModal}
        />
      )}
    </>
  );
};

const NotificationDetailsModal = ({
  notification,
  closeModal,
}: {
  notification: Notification;
  closeModal: () => void;
}) => {
  const { heading: title, description, url, createdAt: time } = notification;

  return (
    <Modal
      open={Boolean(notification)}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
      onClose={closeModal}
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: 300, sm: 450 },
          height: 450,
          overflow: "auto",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 2,
          py: 4,
          borderRadius: 1,
        }}
      >
        <CloseIcon
          onClick={() => closeModal()}
          style={{
            cursor: "pointer",
            position: "absolute",
            right: 15,
            top: 15,
          }}
        />
        <Box
          sx={{
            height: 350,
            width: "100%",
            display: "flex",
            justifyContent: "start",
            alignItems: "start",
            flexDirection: "column",
            p: 2,
            gap: 2,
          }}
        >
          <img
            src={Logo}
            alt="Website-Logo"
            style={{
              height: "60px",
              objectFit: "contain",
              margin: "auto",
            }}
          />
          <Typography
            variant="h6"
            sx={{
              fontWeight: 600,
              width: "100%",
              textAlign: "center",
              color: "#013338",
              fontFamily: "montserrat",
            }}
          >
            {title}
          </Typography>
          <Typography
            variant="body2"
            sx={{
              fontWeight: 500,
              width: "100%",
              textAlign: "center",
              color: "black",
              fontFamily: "montserrat",
              px: 1,
            }}
          >
            {description}
          </Typography>
          <Typography
            variant="caption"
            sx={{
              fontWeight: 300,
              width: "100%",
              textAlign: "center",
              color: "black",
              fontFamily: "montserrat",
              px: 1,
            }}
          >
            {new Date(time).toLocaleString()}
          </Typography>
          <Button
            variant="outlined"
            sx={{
              p: 0,
              color: "white",
              backgroundColor: "#EBBE34",
              borderColor: "#EBBE34",
              borderRadius: "20px",
              fontFamily: "Montserrat",
              mx: "auto",
              "&:hover": {
                borderColor: "white",
                backgroundColor: "white",
                color: "#EBBE34",
              },
            }}
          >
            <Link
              style={{ color: "inherit", textDecoration: "none" }}
              to={`${url}`}
            >
              View
            </Link>
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};
