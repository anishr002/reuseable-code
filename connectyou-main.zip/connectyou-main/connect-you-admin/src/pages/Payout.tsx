/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import VisibilityIcon from "@mui/icons-material/Visibility";
import TableRow from "@mui/material/TableRow";
import dayjs from "dayjs";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import {
  Avatar,
  Box,
  Chip,
  FormControl,
  MenuItem,
  Pagination,
  Select,
  TableCell,
  Tooltip,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import NoDataIllustration from "../components/NoDataIllustration";
import MenuButton from "../components/buttons/MenuButton";
import { LockClock } from "@mui/icons-material";

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});
interface CoachData {
  coachId: string;
  name: string;
  Lname: string;
  email: string;
  image: string;
}

interface PayoutType {
  _id: string;
  coachId: string;
  amount: number;
  status: number;
  createdAt: string;
  approveDate: string;
  paid: boolean;
  coachData: CoachData;
  totalAmount: number;
  totalPayout: number;
}
export default function Payout() {
  const [rows, setData] = React.useState<PayoutType[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state

  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);
  const [filterTerm, setFilterTerm] = React.useState<number>(2); //filter data by approve or not
  const handleChangeFilter = (event: any) => {
    setFilterTerm(event.target.value);
  };
  const fetchData = async () => {
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/payout-history?pageNo=${pageNo}&filterOption=${
          filterTerm === 0 ? 0 : filterTerm
        }`
      );
      if (response.data.payoutHistory) {
        console.log("rows", response);
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        return setData(response.data.payoutHistory);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo, pageUpdated, filterTerm]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  //handle payout approve
  const handleApproveClick = async (id: string, coachId1: string) => {
    const coachId = coachId1.trim();
    setLoading(true);
    const result = await swalWithBootstrapButtons.fire({
      title: "Are you sure?",
      text: "You want to approve it",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, approve it!",
      cancelButtonText: "Not now",
      reverseButtons: true,
    });

    if (!result.isConfirmed) {
      setLoading(false);
      return;
    }

    try {
      const response = await httpAPI_admin.post(
        `/admin/coach/payout-approve/${id.trim()}`,
        { coachId }
      );

      if (response.data.success) {
        swalWithBootstrapButtons
          .fire({
            title: "Approved!",
            text: "Payout approved successfully",
            icon: "success",
            showConfirmButton: false,
          })
          .then(() => {
            setPageUpdated(!pageUpdated);
          });
        setPageUpdated((prev) => !prev);
      } else {
        throw new Error(response.data.message || "Unknown server error");
      }
    } catch (error: any) {
      console.error("Error approving payout:", error);
      swalWithBootstrapButtons.fire({
        title: "Error",
        text:
          error?.response?.data?.message ||
          error.message ||
          "Something went wrong",
        icon: "error",
      });
    } finally {
      setPageUpdated(!pageUpdated);
      setLoading(false);
    }
  };

  const handleRejectClick = (id: string) => {
    setLoading(true);
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to deny this payout ?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Reject Payout`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI_admin.post(
              `/admin/coach/payout-reject/${id.trim()}`
            );
            if (response.data.success === true) {
              setPageUpdated(!pageUpdated);
              setLoading(false);
              swalWithBootstrapButtons.fire({
                title: `Rejected!`,
                text: `Payout has been rejected successfully`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
              return setPageUpdated(!pageUpdated);
            }
          } catch (error: any) {
            console.log(error);
            if (
              error.response.status === 500 ||
              error.response.status === 400 ||
              error.response.status === 401 ||
              error.response.status === 403 ||
              error.response.status === 404 ||
              error.response.status === 409
            ) {
              swalWithBootstrapButtons.fire({
                title: "Error !",
                text: error.response.data.message
                  ? error.response.data.message
                  : "Something went wrong",
              });
              setPageUpdated(!pageUpdated);
              return setLoading(false);
            } else {
              toast.error("Something went wrong");
              return setLoading(false);
            }
          }
        } else {
          setLoading(false);
        }
      });
  };

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            gap: "5px",
            alignItems: "center",
            color: "#013338",
          }}
        >
          <span>Payout Requests</span>
          <Box
            sx={{
              display: "flex",
              gap: 2,
            }}
          >
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            >
              <Select
                displayEmpty
                size="small"
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={filterTerm}
                onChange={handleChangeFilter}
                sx={{
                  color: "#013338",
                  borderColor: "#013338",
                  fontSize: "0.775rem",
                  "& .MuiSelect-icon": {
                    color: "#013338", // Set the color of the dropdown icon
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#013338", // Set border color
                  },
                }}
              >
                <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                  <em>All</em>
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                  Approved
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={0}>
                  Pending
                </MenuItem>
              </Select>
            </FormControl>
            <AccountBalanceIcon style={{ color: "#013338" }} />
          </Box>
        </Typography>
        {rows?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 200px)",
                overflow: "auto",
                cursor: "pointer",
                mx: "auto",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead
                  sx={{
                    maxWidth: "100%",
                    padding: "1px",
                    "& .MuiTableCell-head": { lineHeight: "normal" },
                  }}
                >
                  <TableRow sx={{ textTransform: "uppercase" }}>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        width: "7%",
                      }}
                    >
                      Profile
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        width: "8%",
                      }}
                    >
                      Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        maxWidth: "9%",
                        textWrap: "balance",
                      }}
                    >
                      Email
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Receipts
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Details
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Actions
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                      }}
                    >
                      Requested Payout
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Balance
                    </TableCell>

                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Total Payout
                    </TableCell>
                    <TableCell
                      sx={{ backgroundColor: "#013338", color: "white" }}
                    >
                      Total Revenue
                    </TableCell>

                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                      }}
                    >
                      Request Date
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                      }}
                    >
                      Approve Date
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          <span>
                            {row.coachData.image ? (
                              <>
                                <Avatar
                                  alt={row.coachData.name}
                                  src={`${backendURL}/usersProfile/${row.coachData.image}`}
                                />
                              </>
                            ) : (
                              <>
                                <Avatar
                                  sx={{
                                    backgroundColor: "#013338",
                                  }}
                                >
                                  {capitalizeFirstLetter(row.coachData.name)}
                                </Avatar>
                              </>
                            )}
                          </span>
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          {row.coachData.name}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          {row.coachData.email}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          <Box
                            sx={{
                              px: 2,
                              py: 0.51,
                              color: "white",
                              backgroundColor: "#EBBE34",
                              borderColor: "#EBBE34",
                              borderRadius: "20px",
                              fontFamily: "Montserrat",
                              mx: "auto",
                              "&:hover": {
                                borderColor: "white",
                                backgroundColor: "white",
                                color: "#EBBE34",
                              },
                            }}
                          >
                            <Link
                              to={`/payout/detail/receipts/${row.coachId}`}
                              style={{
                                textDecoration: "none",
                                color: "inherit",
                              }}
                            >
                              Receipts
                            </Link>
                          </Box>
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          <Link to={`detail/${row.coachData.coachId}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                        <TableCell
                          sx={{
                            whiteSpace: "nowrap",
                            fontSize: "1rem",
                          }}
                        >
                          {row.status != 1 ? (
                            <>
                              <MenuButton variant="darksea">
                                {[
                                  {
                                    label: "Approve Payout",
                                    action: () => {
                                      handleApproveClick(row._id, row.coachId);
                                    },
                                  },
                                  {
                                    label: "Reject Payout",
                                    action: () => {
                                      handleRejectClick(row._id);
                                    },
                                  },
                                ]}
                              </MenuButton>
                            </>
                          ) : row.paid ? (
                            <Chip
                              label="Approved"
                              color="success"
                              sx={{ width: "120px", fontWeight: "bold" }}
                              icon={<CheckCircleIcon sx={{ color: "white" }} />}
                            />
                          ) : (
                            <Box
                              sx={{
                                display: "flex",
                                gap: 4,
                              }}
                              className=""
                            >
                              <Tooltip title="Payout Approved, But transfer is still being processed , Sometimes It might take 24 hours, You can also cancel this payout and the transfer will be reversed.">
                                <Chip
                                  label="Pending"
                                  color="warning"
                                  sx={{ width: "120px", fontWeight: "bold" }}
                                  icon={<LockClock sx={{ color: "white" }} />}
                                />
                              </Tooltip>
                              <MenuButton variant="darksea">
                                {[
                                  {
                                    label: "Reject Payout",
                                    action: () => {
                                      handleRejectClick(row._id);
                                    },
                                  },
                                ]}
                              </MenuButton>
                            </Box>
                          )}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          ${formatNumber(row.amount / 100)}
                          {/* field for Requested amount  */}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          $
                          {formatNumber(
                            (row.totalAmount - row.totalPayout) / 100
                          )}
                          {/* field for total  balance  */}
                        </TableCell>

                        <TableCell sx={{ fontSize: "1rem" }}>
                          ${formatNumber(row.totalPayout / 100)}
                          {/* field for total ayout  */}
                        </TableCell>
                        <TableCell sx={{ fontSize: "1rem" }}>
                          ${formatNumber(row.totalAmount / 100)}
                          {/* field for total revenuw  */}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {dayjs(row.createdAt).format("DD-MM-YYYY hh:mm A")}
                          {/* field for request date  */}
                        </TableCell>

                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {/* field for approved date   */}
                          {row.approveDate != ""
                            ? dayjs(row.approveDate).format(
                                "DD-MM-YYYY hh:mm A"
                              )
                            : "-"}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo.totalPages > 1 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo.totalPages)}
                  page={Number(pageInfo.currentPage)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration />
        )}
      </Paper>
    </>
  );
}

function formatNumber(value: number, fallback = "0.00") {
  return value != null && !isNaN(value) ? Number(value).toFixed(2) : fallback;
}
