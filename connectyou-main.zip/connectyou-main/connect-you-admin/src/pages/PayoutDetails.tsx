import DownloadIcon from "@mui/icons-material/Download";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import dayjs from "dayjs";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import PaidIcon from "@mui/icons-material/Paid";
import {
  Avatar,
  Box,
  Chip,
  Pagination,

  TableCell,
  Typography,
  Grid,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast, ToastContainer } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import Swal from "sweetalert2";
import { Link, useParams } from "react-router-dom";
import NoDataIllustration from "../components/NoDataIllustration";
import MenuButton from "../components/buttons/MenuButton";

const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: "btn-success",
    cancelButton: "btn-danger",
  },
  buttonsStyling: false,
});

interface CoachData {
  _id: string;
  name: string;
  Lname: string;
  email: string;
  image: string;
}
interface BalanceData {
  totalRevenue: number;
  payoutBalance: number;
  totalBalance: number;
  payoutBalancePending: number;
}

interface PayoutType {
  _id: string;
  coachId: string;
  approveDate: string;
  amount: number;
  status: number;
  paid:boolean;
  createdAt: string;
  totalAmount: number;
  totalPayout: number;
  receipt: string;
}
export default function PayoutDetails() {
  const { coachId } = useParams(); //coach id
  const [rows, setData] = React.useState<PayoutType[]>([]);
  const [data, setCoachData] = React.useState<CoachData>({
    _id: "",
    name: "",
    Lname: "",
    email: "",
    image: "",
  });
  const [balanceData, setBalance] = React.useState<BalanceData>({
    totalRevenue: 0,
    payoutBalance: 0,
    totalBalance: 0,
    payoutBalancePending: 0,
  });
  const [loading, setLoading] = React.useState(true); // Add loading state

  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
    currentPage: 1,
  });
  const [pageNo, setPageNo] = React.useState(1);
  const [pageUpdated, setPageUpdated] = React.useState<boolean>(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/payout-history/coach/${coachId}?pageNo=${pageNo}`
      );
      if (response.data.payoutList) {
        setPageInfo({
          totalPages: response.data.totalPages,
          currentPage: response.data.currentPage,
        });
        setCoachData(response.data.coachData);
        setBalance(response.data.balanceDetails);
        setData(response.data.payoutList);
        return setLoading(false);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo, pageUpdated]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  //handle payout approve
  const handleApproveClick =async (id: string, coachId1: string) => {
    const coachId = coachId1.trim();
    setLoading(true);
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to approve it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, approve It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI_admin.post(
              `/admin/coach/payout-approve/${id.trim()}`,
              { coachId }
            );
            if (response.data.success === true) {
              setPageUpdated(!pageUpdated);
              setLoading(false);
              swalWithBootstrapButtons.fire({
                title: `Approve!`,
                text: `Payout approved successfully`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
              return setPageUpdated(!pageUpdated);
            }
          } catch (error: any) {
            console.log(error);
            if (
              error.response.status === 500 ||
              error.response.status === 400 ||
              error.response.status === 401 ||
              error.response.status === 403 ||
              error.response.status === 404 ||
              error.response.status === 409
            ) {
              setTimeout(() => {
                toast.error(
                  error.response.data.message
                    ? error.response.data.message
                    : "Something went wrong"
                );
              }, 1000);

              return setLoading(false);
            } else {
              toast.error("Something went wrong");
              return setLoading(false);
            }
          }
        } else {
          setLoading(false);
        }
      });
  };
  const handleRejectClick = (id: string) => {
    setLoading(true);
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: `You want to deny this payout ?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Reject Payout`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI_admin.post(
              `/admin/coach/payout-reject/${id.trim()}`
            );
            if (response.data.success === true) {
              setPageUpdated(!pageUpdated);
              setLoading(false);
              swalWithBootstrapButtons.fire({
                title: `Rejected!`,
                text: `Payout has been rejected successfully`,
                icon: "success",
                showConfirmButton: false,
                timer: 1500,
              });
              return setPageUpdated(!pageUpdated);
            }
          } catch (error: any) {
            console.log(error);
            if (
              error.response.status === 500 ||
              error.response.status === 400 ||
              error.response.status === 401 ||
              error.response.status === 403 ||
              error.response.status === 404 ||
              error.response.status === 409
            ) {
              setTimeout(() => {
                toast.error(
                  error.response.data.message
                    ? error.response.data.message
                    : "Something went wrong"
                );
              }, 1000);

              return setLoading(false);
            } else {
              toast.error("Something went wrong");
              return setLoading(false);
            }
          }
        } else {
          setLoading(false);
        }
      });
  };

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };
  return (
    <>
      <Box
        sx={{
          width: "100%",
          overflow: "auto",

          height: "100svh",
        }}
      >
        {/* coach profile avtar  */}
        <Box
          sx={{
            display: "flex",
            width: "100%",
            backgroundColor: "#013338",
            color: "white",
            position: "relative",
            height: { xs: "5rem", md: "8rem" },
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              paddingLeft: "1.25rem",
              gap: "1rem",
              position: "absolute",
              top: { xs: "1rem", md: "2.25rem" },
              height: "100%",
              width: {
                lg: "100%",
                xl: "80%",
              },
              marginX: "auto",
            }}
          >
            {data?.image != "" ? (
              <Avatar
                alt={data?.name}
                src={`${backendURL}/usersProfile/${data?.image}`}
                sx={{
                  width: { xs: "4rem", sm: "6rem", md: "8rem" },
                  height: { xs: "4rem", sm: "6rem", md: "8rem" },
                }}
              />
            ) : (
              <Avatar
                sx={{
                  backgroundColor: "#013338",
                  width: { xs: "4rem", sm: "6rem", md: "8rem" },
                  height: { xs: "4rem", sm: "6rem", md: "8rem" },
                  fontSize: "3rem",
                }}
              >
                {capitalizeFirstLetter(data?.name)}
              </Avatar>
            )}

            <Box className="profile-info" sx={{ paddingBottom: "1rem" }}>
              <Typography
                variant="h6"
                component="p"
                sx={{
                  fontSize: "1.2rem",
                  lineHeight: "2rem",
                  fontWeight: "600",
                }}
              >
                {data.name} {data.Lname}
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: "500",
                }}
              >
                {data.email}
              </Typography>
            </Box>
          </Box>
        </Box>
        {/* payment card  */}
        <Box
          display="flex"
          flexDirection={{ xs: "column", md: "row" }}
          gap={5}
          p={1}
          mx="auto"
          marginTop={8}
          sx={{
            width: {
              lg: "100%",
              xl: "80%",
            },
            mx: "auto",
          }}
        >
          <Grid container spacing={2} sx={{ height: "fit-content" }}>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Total Balance
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.totalBalance)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Total Payout
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.payoutBalance)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Pending Payout
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.payoutBalancePending)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ width: "100%" }}>
                <Box
                  display="flex"
                  flexDirection="column"
                  gap={2}
                  borderRadius={2}
                  boxShadow={3}
                  p={2}
                  flex={1}
                  sx={{ cursor: "pointer", backgroundColor: "white" }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      variant="h6"
                      fontWeight="600"
                      sx={{ color: "#013338" }}
                    >
                      Total Revenue
                    </Typography>
                  </Box>
                  <Box
                    display="flex"
                    gap={1}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Box display="flex">
                      <PaidIcon sx={{ fontSize: "2rem", color: "#3aa7a3" }} />
                    </Box>
                    <Box display="flex">
                      <Typography variant="h6" fontWeight="600">
                        ${formatNumber(balanceData.totalRevenue)}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Box>
        {/* ////////////////// */}
        {/* table */}
        <Paper
          sx={{
            width: {
              lg: "100%",
              xl: "80%",
            },
            marginX: "auto",
            overflow: "auto",
            scrollbarWidth: "none",
            marginTop: "10px",
            marginBottom: "90px",
          }}
        >
          <Box
            sx={{
              padding: 3,
              color: "#013338",
              display: "flex",
              justifyContent: "justify-between",
              alignItems: "center",
            }}
          >
            <Typography
              variant="body1"
              // gutterBottom
              sx={{
                fontWeight: "bold",
                padding: "4px 10px",
                width: "100%",
                display: "flex",
                justifyContent: "space-between",
                gap: "5px",
                alignItems: "center",
                color: "#013338",
              }}
            >
              <span>Payout History</span>
            </Typography>
            <Box
              sx={{
                px: 2,
                py: 1,
                color: "white",
                backgroundColor: "#EBBE34",
                borderColor: "#EBBE34",
                borderRadius: "20px",
                fontFamily: "Montserrat",
                mx: "auto",
                "&:hover": {
                  borderColor: "white",
                  backgroundColor: "white",
                  color: "#EBBE34",
                },
              }}
            >
              <Link
                to={`/payout/detail/receipts/${coachId}`}
                style={{ textDecoration: "none", color: "inherit" }}
              >
                Receipts
              </Link>
            </Box>
          </Box>
          {rows?.length > 0 ? (
            <>
              <TableContainer
                sx={{
                  overflow: "auto",
                  cursor: "pointer",
                  borderRadius: 2,
                  boxShadow: 3,
                }}
              >
                <Table stickyHeader aria-label="sticky table">
                  <TableHead
                    sx={{
                      padding: "1px",
                      "& .MuiTableCell-head": { lineHeight: "normal" },
                    }}
                  >
                    <TableRow sx={{ textTransform: "uppercase" }}>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                        }}
                      >
                        Requested Payout
                      </TableCell>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                        }}
                      >
                        Request Date
                      </TableCell>
                      <TableCell
                        sx={{
                          backgroundColor: "#013338",
                          color: "white",
                        }}
                      >
                        Approve Date
                      </TableCell>
                      <TableCell
                        sx={{ backgroundColor: "#013338", color: "white" }}
                      >
                        Actions
                      </TableCell>
                      <TableCell
                        sx={{ backgroundColor: "#013338", color: "white" }}
                      >
                        Receipt
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row, index) => {
                      return (
                        <TableRow
                          hover
                          role="checkbox"
                          tabIndex={-1}
                          key={index}
                        >
                          <TableCell sx={{ fontSize: "1rem" }}>
                            ${formatNumber(row.amount / 100)}
                            {/* field for Requested amount  */}
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                          >
                            {dayjs(row.createdAt).format(
                              "DD-MM-YYYY | hh:mm A"
                            )}
                            {/* field for request date  */}
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                          >
                            {/* field for request time   */}
                            {row.approveDate != ""
                              ? dayjs(row.approveDate).format(
                                  "DD-MM-YYYY | hh:mm A"
                                )
                              : "-"}
                          </TableCell>
                          <TableCell
                            sx={{
                              whiteSpace: "nowrap",
                              fontSize: "1rem",
                            }}
                          >
                            {row.status != 1 ? (
                              <>
                                <MenuButton variant="darksea">
                                  {[
                                    {
                                      label: "Approve Payout",
                                      action: () => {
                                        handleApproveClick(
                                          row._id,
                                          row.coachId
                                        );
                                      },
                                    },
                                    {
                                      label: "Reject Payout",
                                      action: () => {
                                        handleRejectClick(row._id);
                                      },
                                    },
                                  ]}
                                </MenuButton>
                              </>
                            ) : (
                              <Chip
                                label="Approved"
                                color="success"
                                sx={{ width: "120px", fontWeight: "bold" }}
                                icon={
                                  <CheckCircleIcon sx={{ color: "white" }} />
                                }
                              />
                            )}
                          </TableCell>
                          <TableCell sx={{ padding: "16px" }}>
                            {row?.receipt && row?.receipt !== "" ? (
                              <a
                                href={`${backendURL}/receipt/${row?.receipt}`}
                                target="_blank"
                                download
                              >
                                <DownloadIcon />
                              </a>
                            ) : (
                              "N/A"
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
              {pageInfo.totalPages > 1 && (
                <Box
                  sx={{
                    display: "flex",
                    justifyConten: "center",
                    alignItems: "center",
                    paddingY: 2,
                    borderTop: "2px solid #ccc",
                  }}
                >
                  <Pagination
                    count={Number(pageInfo.totalPages)}
                    page={Number(pageInfo.currentPage)}
                    onChange={handlePagination}
                  />
                </Box>
              )}
            </>
          ) : (
            <NoDataIllustration message="No Payout History yet !" />
          )}
        </Paper>
      </Box>
      <ToastContainer theme="colored" />
    </>
  );
}
function formatNumber(value: number, fallback = "0.00") {
  return value != null && !isNaN(value) ? Number(value).toFixed(2) : fallback;
}
