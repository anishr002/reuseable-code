import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import {
  Avatar,
  Box,
  Chip,
  createTheme,
  Paper,
  Typography,
} from "@mui/material";
import React from "react";
import { useParams } from "react-router-dom";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import moment from "moment-timezone";
import { ThemeProvider } from "@emotion/react";
import { ThreeDots } from "react-loader-spinner";

interface SessionData {
  _id: string;
  coachId: string;
  title: string;
  price: string;
  type: string;
  description: string;
}
interface CoachData {
  _id: string;
  name: string;
  Lname: string;
  image: string;
  gender: string;
  title_line: string;
  zoomMeetingURL: string;
  timeZone: string;
}
interface UserData {
  _id: string;
  name: string;
  image: string;
  gender: string;
}

interface BookedSessionDataType {
  _id: string;
  sessionDate: string;
  sessionDateUpdated: string;
  sessionStatus: number;
  sessionAmount: number;
  sessionCancelBy: string;
  messageCancel: string;
  sessionCompletedUser: number;
  sessionCompletedCoach: number;
  completedUserMSG: string;
  completedCoachMSG: string;
  sessionData: SessionData;
}
interface Rescheduled_sessionsDataType {
  _id: string;
  rescheduledBy: string;
  coachTimeZone: string;
  sessionDate: string;
  message: number;
  createdAt: number;
}

const BookedSessionDetails = () => {
  const { bookingId } = useParams<{ bookingId?: string }>();
  const { bookedSessionId } = useParams<{ bookedSessionId?: string }>();
  const [loading, setLoading] = React.useState<boolean>(true); //faching data
  const [coachData, setCoachData] = React.useState<CoachData>();
  const [userData, setUserData] = React.useState<UserData>();
  const [bookedSessionList, setBookedSessionList] =
    React.useState<BookedSessionDataType>(); //It's a single record object, not an array
  const [rescheduled_sessionsData, setRescheduled_sessionsData] =
    React.useState<Rescheduled_sessionsDataType[]>([]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await httpAPI_admin.get(
        `admin/booking/booking-history-session-details/${bookingId}/${bookedSessionId}`
      );

      if (response.status === 200) {
        setBookedSessionList(response.data.data.booked_sessionsData);
        setCoachData(response.data.data.booked_sessionsData.coachData);
        setUserData(response.data.data.booked_sessionsData.userData);
        setRescheduled_sessionsData(
          response.data.data.booked_sessionsData.rescheduled_sessionsData
        );
        return setLoading(false);
      }
    } catch (error: any) {
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        toast.error("Something went wrong");
        return setLoading(false);
      }
    } finally {
      return setLoading(false);
    }
  };
  const theme = createTheme({
    typography: {
      fontFamily: "montserrat",
    },
  });
  //call the fatch order details fatch function
  React.useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <>
      <ThemeProvider theme={theme}>
        <Box
          display="flex"
          flexDirection="column"
          gap={5}
          overflow="auto"
          paddingBottom={12}
          height="100vh"
        >
          {/* coachee details  */}
          <Box
            display="flex"
            flexDirection={{
              xs: "column",
              lg: "row",
            }}
            gap={4}
            boxShadow={3}
            bgcolor="white"
            p={4}
            borderRadius={2}
            width="100%"
            alignItems="center"
            justifyContent="space-between"
          >
            {/* User 1 Avatar and Information */}
            <Box
              display="flex"
              gap={2}
              alignItems="center"
              justifyContent={{ xs: "start", lg: "center" }}
              width={{ lg: "50%" }}
            >
              <Avatar
                src={`${backendURL}/usersProfile/${coachData?.image}`}
                sx={{
                  width: 120,
                  height: 120,
                  border: "4px solid #f0f0f0",
                  mb: 2,
                }}
              />
              <Box
                display="flex"
                flexDirection="column"
                gap={1}
                textAlign="center"
              >
                <Typography variant="h6">Coach</Typography>
                <Box display="flex" width="100%" alignItems="center" gap={2}>
                  <Typography variant="body1" fontWeight="bold">
                    Name:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {coachData?.name}&nbsp;{coachData?.Lname}
                  </Typography>
                </Box>
                <Box display="flex" width="100%" alignItems="center" gap={2}>
                  <Typography variant="body1" fontWeight="bold">
                    Gender:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {coachData?.gender}
                  </Typography>
                </Box>
              </Box>
            </Box>

            {/* User 2 Avatar and Information */}
            <Box
              display="flex"
              gap={2}
              alignItems="center"
              justifyContent={{ xs: "start", lg: "center" }}
              width={{ lg: "50%" }}
            >
              <Avatar
                src={`${backendURL}/usersProfile/${userData?.image}`}
                sx={{
                  width: 120,
                  height: 120,
                  border: "4px solid #f0f0f0",
                  mb: 2,
                }}
              />
              <Box
                display="flex"
                flexDirection="column"
                gap={1}
                textAlign="center"
              >
                <Typography variant="h6">Coachee</Typography>
                <Box display="flex" width="100%" alignItems="center" gap={2}>
                  <Typography variant="body1" fontWeight="bold">
                    Name:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {userData?.name}
                  </Typography>
                </Box>
                <Box display="flex" width="100%" alignItems="center" gap={2}>
                  <Typography variant="body1" fontWeight="bold">
                    Gender:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {userData?.gender}
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>
          {/* session details */}
          <Box
            display="flex"
            flexDirection="column"
            boxShadow={3}
            borderRadius={2}
            width="100%"
            gap={1}
            bgcolor="white"
            p={4}
          >
            <Box
              display="flex"
              justifyContent={{ xs: "flex-start", md: "space-between" }}
              width="100%"
              gap={5}
            >
              <Typography variant="body2" fontWeight="bold">
                {moment(bookedSessionList?.sessionDateUpdated)
                  .local()
                  .format("DD-MM-YYYY  hh:mm A")}{" "}
                -{" "}
                {moment(bookedSessionList?.sessionDateUpdated)
                  .local()
                  .add(1, "hours")
                  .format(" hh:mm A")}
              </Typography>
            </Box>

            <Box display="flex" gap={5}>
              {bookedSessionList && bookedSessionList.sessionStatus === 0 && (
                <Box>
                  <Chip
                    icon={<AccessTimeFilledIcon color="inherit" />}
                    label="Status Pending"
                    sx={{
                      backgroundColor: "#ebbe34",
                      color: "white",
                    }}
                  />
                </Box>
              )}
              {bookedSessionList && bookedSessionList.sessionStatus === 1 && (
                <Box>
                  <Chip
                    icon={<CheckCircleIcon color="inherit" />}
                    label="Meeting Completed"
                    sx={{
                      backgroundColor: "#3aa7a3",
                      color: "white",
                    }}
                  />
                </Box>
              )}
              {bookedSessionList && bookedSessionList.sessionStatus === 2 && (
                <Box>
                  <Chip
                    icon={<CancelIcon color="inherit" />}
                    label="Meeting Cancelled"
                    sx={{
                      backgroundColor: "red",
                      color: "white",
                    }}
                  />
                </Box>
              )}
            </Box>

            <Typography variant="h6" fontWeight="bold">
              {bookedSessionList?.sessionData?.title}
            </Typography>

            <Typography variant="body1" fontWeight="bold">
              ${bookedSessionList?.sessionData?.price}
            </Typography>

            <Typography variant="body2" color="textSecondary">
              {bookedSessionList?.sessionData?.description}
            </Typography>
          </Box>
          {/* cancel massage  */}

          {bookedSessionList && bookedSessionList.sessionStatus === 2 && (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 2,
                boxShadow: 3,
                width: "100%",
                p: 2,
                backgroundColor: "white",
                position: "relative",
              }}
            >
              <Box sx={{ display: "flex" }}>
                <Chip
                  label={
                    bookedSessionList.sessionCancelBy === "coach"
                      ? "Cancelled by Coach"
                      : "Cancelled by Coachee"
                  }
                  sx={{
                    backgroundColor: "red",
                    color: "white",
                    fontWeight: "bold",
                    borderRadius: "50px",
                    px: 2,
                    py: 1,
                  }}
                />
              </Box>
              <Typography variant="body2" sx={{ pl: 4 }}>
                {bookedSessionList.messageCancel}
              </Typography>
            </Box>
          )}

          {/* complete message  */}
          {bookedSessionList &&
            (bookedSessionList.sessionCompletedCoach === 1 ||
              bookedSessionList.sessionCompletedUser === 1) && (
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 2,
                  boxShadow: 3,
                  width: "100%",
                  p: 2,
                  backgroundColor: "white",
                  position: "relative",
                }}
              >
                {bookedSessionList.sessionCompletedCoach === 1 && (
                  <Box
                    sx={{ display: "flex", flexDirection: "column", gap: 1 }}
                  >
                    <Box sx={{ display: "flex" }}>
                      <Chip
                        label="Completion Message From Coach"
                        sx={{
                          px: 1,
                          py: 0.5,
                          backgroundColor: "#3aa7a3",
                          color: "white",
                          fontWeight: "bold",
                        }}
                      />
                    </Box>
                    <Typography variant="body2" sx={{ pl: 4 }}>
                      {bookedSessionList.completedCoachMSG}
                    </Typography>
                  </Box>
                )}
                {bookedSessionList.sessionCompletedUser === 1 && (
                  <Box
                    sx={{ display: "flex", flexDirection: "column", gap: 1 }}
                  >
                    <Box sx={{ display: "flex" }}>
                      <Chip
                        label="Completion Message From Coachee"
                        sx={{
                          px: 2,
                          py: 0.5,
                          backgroundColor: "#3aa7a3",
                          color: "white",
                          fontWeight: "bold",
                        }}
                      />
                    </Box>
                    <Typography variant="body2" sx={{ pl: 4 }}>
                      {bookedSessionList.completedUserMSG}
                    </Typography>
                  </Box>
                )}
              </Box>
            )}

          {/* rescheduled session details */}
          <Box display="flex" flexDirection="column" gap={5} width="100%">
            {rescheduled_sessionsData.map((r, i) => (
              <Box
                key={i}
                display="flex"
                flexDirection="column"
                gap={3}
                p={4}
                bgcolor="grey.100"
                boxShadow={3}
                sx={{ opacity: 0.75, boxShadow: 3 }}
              >
                <Box display="flex" justifyContent="space-between">
                  <Box display="flex" gap={2} alignItems="center">
                    <Typography
                      variant="h6"
                      fontWeight="bold"
                      sx={{ color: "#333" }}
                    >
                      Meeting Details
                    </Typography>
                    <Chip
                      label="Rescheduled"
                      sx={{ backgroundColor: "#EBBE34", color: "white" }}
                    />
                  </Box>
                </Box>

                <Box
                  display="flex"
                  flexDirection="column"
                  gap={1}
                  fontWeight="medium"
                >
                  <Box display="flex">
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2">Meeting Date</Typography>
                      <Typography variant="body2">:</Typography>
                    </Box>
                    <Typography
                      variant="body2"
                      sx={{ color: "text.secondary" }}
                    >
                      {moment(r.sessionDate).local().format("DD-MM-YYYY")}
                    </Typography>
                  </Box>

                  <Box display="flex">
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2">Meeting Time</Typography>
                      <Typography variant="body2">:</Typography>
                    </Box>
                    <Typography
                      variant="body2"
                      sx={{ color: "text.secondary" }}
                    >
                      {moment(r.sessionDate).local().format("hh:mm A")} -{" "}
                      {moment(r.sessionDate).add(1, "hours").format("hh:mm A")}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
      </ThemeProvider>
    </>
  );
};

export default BookedSessionDetails;
