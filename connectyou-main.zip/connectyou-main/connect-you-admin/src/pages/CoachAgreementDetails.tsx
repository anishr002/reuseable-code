import FilePresentIcon from "@mui/icons-material/FilePresent";
import EditIcon from "@mui/icons-material/Edit";
import ContentPasteIcon from "@mui/icons-material/ContentPaste";
import * as React from "react";
import Paper from "@mui/material/Paper";
import {
  Box,
  Button,
  CircularProgress,
  Container,
  FormHelperText,
  IconButton,
  Modal,
  Tooltip,
  Typography,
} from "@mui/material";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";
import NoDataIllustration from "../components/NoDataIllustration";
import FilePreview from "../components/FilePreview";
import { useForm } from "react-hook-form";

interface AgreementType {
  _id: string;
  dateOfRevision: string;
  file: string;
  createdAt: string;
}

export default function CoachAgreementDetails() {
  const [agreement, setAgreement] = React.useState<AgreementType | null>(null);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [refreshPage, setrefreshPage] = React.useState<boolean>(false);
  const [openUpdateModal, SetopenUpdateModal] = React.useState<boolean>(false);

  const fetchCoachAgreement = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/coach/agreement/get-agreement`
      );
      if (response.data.success) {
        return setAgreement(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchCoachAgreement();
  }, [refreshPage]);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: "calc(100vh - 88px)",
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            flexDirection: { xs: "column", md: "row" },
            display: "flex",
            justifyContent: { xs: "start", md: "space-between" },
            gap: "5px",
            alignItems: { xs: "start", md: "center" },
            color: "#013338",
          }}
        >
          <div
            style={{
              position: "relative",
              display: "flex",
            }}
          >
            COACH AGREEMENT
          </div>
          <Box
            sx={{
              display: "flex",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Box
              onClick={() => {
                SetopenUpdateModal(true);
              }}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "1.1rem",
              }}
            >
              Update
              <ContentPasteIcon style={{ color: "#013338" }} />
            </Box>
          </Box>
        </Typography>
        {agreement ? (
          <div style={{ width: "100%", padding: "10px" }}>
            <FilePreview
              showDownLoadButton={false}
              file={agreement.file}
              fileUrl={`${backendURL}/coachAgreements/${agreement.file}`}
            />
          </div>
        ) : (
          <NoDataIllustration message="No agreement has been added yet !" />
        )}
      </Paper>
      <AddAgreementModal
        onClose={() => SetopenUpdateModal(false)}
        open={openUpdateModal}
        refreshPage={() => setrefreshPage(!refreshPage)}
      />
    </>
  );
}

const AddAgreementModal = ({
  open,
  refreshPage,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
  refreshPage: () => void;
}) => {
  type agreementValue = {
    agreementFile: FileList | null;
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm<agreementValue>({});

  const [fileUrl, setFileUrl] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState<boolean>(false);

  const selectedFile = watch("agreementFile");
  React.useEffect(() => {
    if (selectedFile && selectedFile.length > 0) {
      const file = selectedFile[0];
      if (file.type === "application/pdf") {
        const url = URL.createObjectURL(file);
        setFileUrl(url);
      }
    }
  }, [selectedFile]);

  const onsubmitagreement = handleSubmit(async (data) => {
    setLoading(true);
    try {
      const formData = new FormData();
      if (data.agreementFile) {
        formData.append("agreement_file", data.agreementFile[0]);
      }
      console.log(formData);
      const response = await httpAPI_admin.put(
        `${backendURL}/admin/coach/agreement/add-agreement`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log({ response });
      if (response.status === 200) {
        onClose();
        reset();
        refreshPage();
        return setLoading(false);
      } else setError("Some Error occured while updating the agreement");
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        setError(error.response.data.message);
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  });

  return (
    <>
      <Modal
        aria-labelledby={`modal-title`}
        aria-describedby={`modal-desc`}
        open={open}
        onClose={(_: unknown, reason: "backdropClick" | "escapeKeyDown") => {
          if (reason === "backdropClick") {
            onClose();
          } else if (reason === "escapeKeyDown") {
            onClose();
          }
        }}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Box
          sx={{
            maxHeight: "80vh", // Max height of 70 to 80vh
            maxWidth: "90%",
            overflowY: "auto", // Allow scrolling for the content
            borderRadius: "md",
            boxShadow: "lg",
            display: "flex",
            flexDirection: "column",
            width: 500,
            gap: 2,
            background: "white",
            justifyContent: "start",
          }}
        >
          {/* Fixed Header */}
          <div
            id={`modal-header`}
            style={{
              position: "sticky",
              top: 0,
              backgroundColor: "white",
              zIndex: 10,
              minHeight: "60px",
              width: "100%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              boxShadow:
                "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
            }}
          >
            <div
              style={{
                width: " 83.333333%",
                margin: "0 auto",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                padding: "0.75rem  0",
              }}
            >
              <Typography sx={{ color: "#eabd32", fontWeight: 600 }}>
                Update Coach Agreement
              </Typography>
            </div>
          </div>
          <div
            id={`modal-content`}
            style={{
              overflowY: "auto",
              maxHeight: "calc(80vh - 80px)",
              // header height is adjusted to it
              padding: "10px ",
            }}
            className={` style-scroll `}
          >
            {error && (
              <>
                <Typography
                  variant="caption"
                  sx={{ color: "red", fontWeight: 500, fontSize: "1rem" }}
                >
                  {error}
                </Typography>
              </>
            )}
            <form
              onSubmit={onsubmitagreement}
              style={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
              }}
            >
              <label
                htmlFor={"upload-coach-agreement"}
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  width: "100%",
                  borderRadius: "0.375rem", // Equivalent to rounded-md
                  position: "relative",
                  overflow: "hidden",
                  cursor: "pointer",
                }}
              >
                <input
                  accept="pdf/*"
                  style={{ display: "none" }}
                  id="upload-coach-agreement"
                  type="file"
                  {...register("agreementFile", {
                    required: "Please upload coach agreement file",
                  })}
                />

                {!fileUrl ? (
                  <div
                    style={{
                      width: "100%",
                      borderRadius: "0.5rem", // Equivalent to rounded-lg
                      minHeight: "6rem", // Equivalent to min-h-24 (24 * 0.25rem)
                      paddingTop: "3rem", // Equivalent to py-12 (12 * 0.25rem)
                      paddingBottom: "3rem",
                      backgroundColor: "#9CA3AF", // Equivalent to bg-gray-400
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <span>
                      <FilePresentIcon
                        sx={{ color: "white", fontSize: "2.5rem" }}
                      />
                    </span>
                    <span
                      style={{
                        fontSize: "1rem",
                        color: "black",
                        fontWeight: 500,
                      }}
                    >
                      Upload PDF
                    </span>
                  </div>
                ) : (
                  <Container
                    sx={{
                      width: "100%",
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <div style={{ width: "80%", maxWidth: "600px" }}>
                      {" "}
                      {/* Wrapper div for centering */}
                      <iframe
                        src={fileUrl}
                        title="PDF Preview"
                        style={{
                          width: "100%",
                          height: "300px",
                          border: "1px solid #ccc",
                          borderRadius: "5px",
                        }}
                      />
                    </div>
                  </Container>
                )}

                {fileUrl ? (
                  <div
                    style={{
                      position: "absolute",
                      bottom: "2rem",
                      right: "2rem",
                      width: "2rem",
                      height: "2rem",
                      borderRadius: "9999px",
                      backgroundColor: "#eabd32",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Tooltip title="Edit">
                      <IconButton
                        color="primary"
                        aria-label="upload-picture"
                        component="span"
                      >
                        <EditIcon sx={{ color: "white", fontSize: "1.5rem" }} />
                      </IconButton>
                    </Tooltip>
                  </div>
                ) : (
                  ""
                )}
              </label>
              {errors.agreementFile && (
                <FormHelperText>{errors.agreementFile.message}</FormHelperText>
              )}
              <div
                style={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  margin: "12px auto",
                }}
              >
                <Button
                  type="submit"
                  sx={{ ...primaryButton, my: 2, px: 4, py: 1, mx: "auto" }}
                >
                  {loading ? (
                    <CircularProgress size={24} sx={{ color: "#eabd320" }} />
                  ) : (
                    "Submit"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </Box>
      </Modal>
    </>
  );
};
const primaryButton = {
  p: 0,
  color: "white",
  backgroundColor: "#EBBE34",
  borderColor: "#EBBE34",
  borderRadius: "20px",
  fontFamily: "Montserrat",
  mx: "auto",
  "&:hover": {
    borderColor: "white",
    backgroundColor: "white",
    color: "#EBBE34",
  },
};
