import PendingActionsIcon from "@mui/icons-material/PendingActions";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import VisibilityIcon from "@mui/icons-material/Visibility";

import TableRow from "@mui/material/TableRow";
import { Box, Pagination, TableCell, Typography } from "@mui/material";
import { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";
import { ThreeDots } from "react-loader-spinner";

import { Link } from "react-router-dom";
import NoDataIllustration from "../components/NoDataIllustration";
import dayjs from "dayjs";

export default function ApprovalHistory() {
  interface Row {
    _id: string;
    name: string;
    Lname: string;
    email: string;
    gender: string;
    coach_id: string;
    completionStatus: string;
    requestedOn: string;
    approve: number;
    emailVerified: number;
    reqClosedOn: string;
    idealTime: string;
    requestStatus: string;
  }
  const [rows, setData] = React.useState<Row[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageInfo, setPageInfo] = React.useState({
    totalPages: 0,
  });
  const [pageNo, setPageNo] = React.useState(1);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/profile-approval-requests-history?pageNo=${pageNo}&limit=10`
      );
      if (response.data.success) {
        setPageInfo({
          totalPages: response.data.totalPages,
        });
        return setData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, [pageNo]);

  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setPageNo(page);
  };

  //handle coach block

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }

  return (
    <>
      {/* <Typography variant="h4" gutterBottom>
        Coaches
      </Typography> */}
      <Paper
        sx={{
          width: "100%",
          overflow: "auto",
          height: `${rows.length > 0 ? "auto" : "calc(100vh - 88px)"}`,
          maxHeight: "calc(100vh - 88px)",
        }}
      >
        <Typography
          variant="h6"
          // gutterBottom
          sx={{
            fontWeight: "bold",
            padding: "1rem 20px",
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            gap: "5px",
            alignItems: "center",
            color: "#013338",
          }}
        >
          <span>Approval History</span>
        </Typography>
        {rows?.length > 0 ? (
          <>
            <TableContainer
              sx={{
                maxHeight: "calc(100vh - 210px)",
                overflow: "auto",
                minWidth: "fit-content",
              }}
            >
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Name
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email Address
                    </TableCell>
                    {/* <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Completion Status
                    </TableCell> */}
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Email verification
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Requested on
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Closed on
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Ideal Time
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Status
                    </TableCell>
                    <TableCell
                      sx={{
                        backgroundColor: "#013338",
                        color: "white",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Profile
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows?.map((row, index) => {
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-word" },
                          }}
                        >
                          {`${row?.name} ${row?.Lname}`}
                          {row?.gender ? ` (${row?.gender?.charAt(0)}) ` : ""}
                        </TableCell>
                        <TableCell
                          sx={{
                            wordBreak: { xs: "keep-all", md: "break-all" },
                          }}
                        >
                          {row?.email}
                        </TableCell>
                        <TableCell>
                          {row?.emailVerified === 1 ? (
                            <Box
                              sx={{
                                display: "flex",
                                px: 1,
                                py: 0.5,
                                gap: 0,
                                color: "white",
                                alignItems: "center",
                                justifyContent: "space-between",
                                background: "#3aa7a3",
                                borderRadius: "32px",
                              }}
                            >
                              <Typography
                                variant="caption"
                                sx={{ fontFamily: "montserrat" }}
                              >
                                Verified
                              </Typography>
                              <CheckCircleIcon color="inherit" />
                            </Box>
                          ) : (
                            <Box
                              sx={{
                                display: "flex",
                                px: 1,
                                py: 0.5,
                                gap: 0,

                                alignItems: "center",
                                justifyContent: "space-between",
                                borderRadius: "32px",
                                background: "gray",
                                color: "white",
                              }}
                            >
                              <Typography
                                variant="caption"
                                sx={{ fontFamily: "montserrat" }}
                              >
                                Unverified
                              </Typography>
                              <PendingActionsIcon color="inherit" />
                            </Box>
                          )}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {row?.requestedOn
                            ? dayjs(row?.requestedOn).format("DD-MM-YYYY")
                            : "-"}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {row?.reqClosedOn
                            ? dayjs(row?.reqClosedOn).format("DD-MM-YYYY")
                            : "-"}
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          {Math.ceil(Number(row?.idealTime) / 60000)} mins
                        </TableCell>
                        <TableCell
                          sx={{ whiteSpace: "nowrap", fontSize: "1rem" }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              px: 1,
                              py: 0.5,
                              gap: 0,
                              color: "white",
                              alignItems: "center",
                              justifyContent: "space-between",
                              background: `${row?.requestStatus === "Approved"
                                ? "#3aa7a3"
                                : row?.requestStatus === "Expired"
                                  ? "gray"
                                  : "red"
                                }`,
                              borderRadius: "32px",
                            }}
                          >
                            <Typography
                              variant="caption"
                              sx={{ fontFamily: "montserrat" }}
                            >
                              {row?.requestStatus}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Link to={`/coach/detail/${row?.coach_id}`}>
                            <VisibilityIcon
                              color="primary"
                              style={{ cursor: "pointer" }}
                            />
                          </Link>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
            {pageInfo?.totalPages > 0 && (
              <Box
                sx={{
                  display: "flex",
                  justifyConten: "center",
                  alignItems: "center",
                  paddingY: 2,
                  borderTop: "2px solid #ccc",
                }}
              >
                <Pagination
                  count={Number(pageInfo?.totalPages)}
                  page={Number(pageNo)}
                  onChange={handlePagination}
                />
              </Box>
            )}
          </>
        ) : (
          <NoDataIllustration message="No Pending Requests! " />
        )}
      </Paper>
    </>
  );
}
