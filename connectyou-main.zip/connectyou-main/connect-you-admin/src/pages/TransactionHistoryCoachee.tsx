import { Avatar, Box, Paper, Typography } from "@mui/material";

import React from "react";

import { useParams } from "react-router-dom";
import backendURL, { httpAPI_admin } from "../AxiosAPI";
import { toast } from "react-toastify";

import { ThreeDots } from "react-loader-spinner";

import DownloadReceiptsCoachee from "../components/DownloadReceiptsCoachee";

interface UserData {
  _id: string;
  name: string;
  image: string;
  timeZone: string;
  email: string;
}

const TransactionHistoryCoachee = () => {
  const { userId } = useParams(); //userId id
  const [loading, setLoading] = React.useState(true); // Add loading state

  const [userData, setuserData] = React.useState<UserData>();
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI_admin.get(
        `admin/booking/booking-history/user/${userId}?pageNo=1`
      );
      if (response.data.data) {
        setLoading(false);
        setuserData(response.data.userData);
      }
    } catch (error) {
      console.log({ error });
      setLoading(false);
      return toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return (
      <Paper
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "calc(100vh - 100px)",
        }}
      >
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </Paper>
    );
  }
  return (
    <>
      <Box
        sx={{
          height: "100vh",
          width: "100%",
          overflow: "auto",

          pb: 15,
        }}
      >
        {/* coach profile avtar  */}
        <Box
          sx={{
            display: "flex",
            width: "100%",
            backgroundColor: "#013338",
            color: "white",
            position: "relative",
            height: { xs: "5rem", md: "8rem" },
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              paddingLeft: "1.25rem",
              gap: "1rem",
              position: "absolute",
              top: { xs: "1rem", md: "2.25rem" },
              height: "100%",
            }}
          >
            <Avatar
              alt={userData?.name}
              src={`${backendURL}/usersProfile/${userData?.image}`}
              sx={{
                width: { xs: "4rem", sm: "6rem", md: "8rem" },
                height: { xs: "4rem", sm: "6rem", md: "8rem" },
              }}
            />

            <Box className="profile-info" sx={{ paddingBottom: "1rem" }}>
              <Typography
                variant="h6"
                component="p"
                sx={{
                  fontSize: "1.2rem",
                  lineHeight: "2rem",
                  fontWeight: "600",
                }}
              >
                {userData?.name}
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: "500",
                }}
              >
                {userData?.email}
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* table content  */}
        <Paper
          sx={{
            marginTop: "50px",
            width: "100%",
            overflow: "auto",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: "bold",
              padding: "1rem 20px",
              width: "100%",
              display: "flex",
              justifyContent: "space-between",
              gap: "5px",
              alignItems: "center",
              color: "#013338",
            }}
          >
            <span>Transaction History</span>
          </Typography>
          <Box>
            <DownloadReceiptsCoachee />
          </Box>
        </Paper>
      </Box>
    </>
  );
};

export default TransactionHistoryCoachee;
