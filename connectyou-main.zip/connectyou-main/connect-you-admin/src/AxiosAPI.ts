import axios from "axios";
import apiBaseUrl from './URLconf'
const backendURL = apiBaseUrl;
export default backendURL;


export const httpAPI_admin = axios.create({
  baseURL: apiBaseUrl,
});

httpAPI_admin.interceptors.request.use(
  (config) => {
    const authToken = localStorage.getItem("authToken");
    if (authToken) {
      config.headers.Authorization = `Bearer ${authToken}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
