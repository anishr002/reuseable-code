import { createTheme } from "@mui/material/styles";

export const ButtonTheme = createTheme({
  palette: {
    primary: {
      main: "#013338",
      contrastText: "#ffffff",
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          backgroundColor: "#013338",
          color: "#ffffff",
          borderRadius: "22px",
          "&:hover": {
            backgroundColor: "#3aa7a3",
          },
        },
        outlinedPrimary: {
          borderColor: "#013338",
          color: "#013338",
          borderRadius: "22px",
          "&:hover": {
            borderColor: "#3aa7a3",
            backgroundColor: "rgba(58, 167, 163, 0.1)", // subtle filled effect
            color: "#3aa7a3",
          },
        },
      },
    },
  },
});
