export interface Shortlists_Type {
  status: boolean; // true for is shortlisted // false for not shortlisted
  _id: string;
  coachId: string;
  email: string;
  createdAt: string;
  updatedAt: string;
}
