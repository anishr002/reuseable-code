/* eslint-disable @typescript-eslint/no-explicit-any */
export default interface BulkAddReportsType {
  dataSource: string;
  entry_type: "Bulk_Coach_Entry" | "Bulk_Coachee_Entry";
  result: "Success" | "Partial Success" | "Failure";
  successFilepath: string;
  failureFilepath: string;
  successCount: number;
  failureCount: number;
  uploadedBy: string;
  createdAt: number;
}

export interface BulkAddOppAPIRes {
  success: boolean;
  message: string;
  data: {
    successfullEntries: any[];
    failedEntries: any[];
    successNumber: number;
    failureNumber: number;
    contactsFound?: number;
  };
  files: {
    success: string;
    failure: string;
  };
}
