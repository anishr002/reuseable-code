export interface Coach_Data_Type {
  userType?: "coach" | "coachee" | string;
  registrationType?: "direct" | "indirect";
  _id: string;
  name: string;
  Lname: string;
  email: string;
  emailVerified: number;
  userName: string;
  gender: string;
  DOB: string;
  calendarStatus?: number;
  calendarAddedDate?: string;
  stripe_customerID?: string;
  accHolderId?: string;
  stripe_accID?: string;
  stripe_addStatus?: number;
  bankAccountID?: string;
  invoice_prefix?: string;
  freeTrial?: string;
  approve: number;
  paymentLink: string;
  image: string;
  about_me: string;
  title_line: string;
  languages: string[];
  industries: string[];
  coachingSpecialities: string[];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  location?: any;
  city: string;
  fullAddress: string;
  Bcountry: string;
  Bcity: string;
  bankAccount_holder_name: string;
  bankAccount_routing_number: string;
  bankAccount_account_number: string;
  persionId_number: string;
  idProofFront: string;
  idProofBack: string;
  zoomMeetingURL: string;
  timeZone: string;
  experienceYear: number;
  my_invitation_code: string;
  ssn_last_4: string;
  live: number;
  lastSeen: string;
  hub_spot_id: string;
  refered_by_partner: number;
  nonProfitCoaching: boolean;
  refering_partner: {
    region: string;
    country: string;
  } | null;
  country: string;
  currency: string;
  countryCode: string;
  phoneCode: string;
  createdAt: string;
  updatedAt: string;
  averageRating: number;
  totalRatings: number;
  zoomId: string;
  zoomAccStatus: string;
  linkedin_profile_link: string;
  coaching_focus_area: Focus_Area_type[];
}

export interface Focus_Area_type {
  category: string;
  label: string;
  tag: string;
}
