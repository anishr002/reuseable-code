const isDevelopment = import.meta.env.MODE === 'development';

const apiBaseUrl = isDevelopment ? import.meta.env.VITE_apiBaseUrl_DEV : import.meta.env.VITE_apiBaseUrl_PRO

export default apiBaseUrl


