export interface APIThrottle_Type {
  endpoints: {
    [endpoint: string]: {
      count: number;
      ips: {
        [ipAddress: string]: {
          ipAddress: string;
          requested: number;
        };
      };
    };
  };
  totalRequestIn24Hours: string;
  averageRequestsPerMinute: string;
  createdAt: string;
  updatedAt: string;
}
