export const primaryButton = {
  p: 0.5,
  color: "white",
  backgroundColor: "#EBBE34",
  borderColor: "#EBBE34",
  borderRadius: "20px",
  fontFamily: "Montserrat",
  mx: "auto",
  border: "1px solid transparent",
  "&:hover": {
    border: "1px solid #ebbd33",
    backgroundColor: "white",
    color: "#EBBE34",
  },
};
