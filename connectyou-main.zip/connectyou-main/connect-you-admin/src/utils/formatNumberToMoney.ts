export default function formatNumberToMoney(value: number, fallback = "0.00") {
  return value != null && !isNaN(value)
    ? `$ ${Number(value).toFixed(2)}`
    : fallback;
}
