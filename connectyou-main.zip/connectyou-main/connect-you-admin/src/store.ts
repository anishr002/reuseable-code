import { configureStore } from "@reduxjs/toolkit";
import adminLoginReducer from "./slices/Login";
import pendingApprovalReqCountReducer from "./slices/PendingApprovalCount";
import unreadCountReducer from "./slices/Notification";

const store = configureStore({
  reducer: {
    adminLogin: adminLoginReducer,
    unreadCount: unreadCountReducer,
    pendingApprovalReqCount: pendingApprovalReqCountReducer,
  },
});

export default store;
