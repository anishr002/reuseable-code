import React from "react";

import TopNav from "../components/TopNav";
import SideNav from "../components/SideNav";
import { Outlet, useLocation } from "react-router-dom";
import Box from "@mui/material/Box";

const Layout = () => {
  const [open, setOpen] = React.useState(false);

  const toggleDrawer = (newOpen: boolean) => () => {
    setOpen(newOpen);
  };
  const [viewportWidth, setViewportWidth] = React.useState(window.innerWidth);

  React.useEffect(() => {
    const handleResize = () => {
      setViewportWidth(window.innerWidth);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Remove event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  const location = useLocation();
  const isActiveRoute = (route: string): boolean => {
    return location.pathname === route;
  };
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        // backgroundColor: "#F4F4F4",
        backgroundColor: isActiveRoute("/profile") ? "white" : "#F4F4F4",
      }}
    >
      <TopNav
        viewportWidth={viewportWidth}
        open={open}
        toggleDrawer={toggleDrawer}
      />
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          position: "fixed",
          top: "70px",
          width: "100%",
        }}
      >
        <SideNav
          viewportWidth={viewportWidth}
          open={open}
          toggleDrawer={toggleDrawer}
        />
        <Box
          sx={{
            flexGrow: 1,
            p: 1,
            ml: { md: "250px" },
            overflow: "auto",
          }}
        >
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
};

export default Layout;
