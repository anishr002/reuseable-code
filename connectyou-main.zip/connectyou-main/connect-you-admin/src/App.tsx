/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  BrowserRouter,
  Routes,
  Route,
  Outlet,
  Navigate,
} from "react-router-dom";
import Layout from "./layout/Layout";
import Dashboard from "./pages/dashboard/Dashboard";
import LoginPage from "./pages/LoginPage";
import CoachPage from "./pages/CoachPage";
import UserPage from "./pages/UserPage";
import NotificationPage from "./pages/NotificationPage";
import ProfilePage from "./pages/ProfilePage";

import "react-toastify/dist/ReactToastify.css";
import { useDispatch, useSelector } from "react-redux";
import "./App.css";
import CoachDetails from "./pages/CoachDetails";
import UserDetails from "./pages/UserDetails";
import { createTheme, ThemeProvider } from "@mui/material";
import Payout from "./pages/Payout";
import PayoutDetails from "./pages/PayoutDetails";
import BookingsPage from "./pages/BookingsPage";
import BookingDetails from "./pages/BookingDetails";
import CoachBookingsList from "./pages/CoachBookingsList";
import UserBookingsList from "./pages/UserBookingsList";
import ChatHistory from "./pages/ChatHistory";
import { socket } from "./socket";
import { toast } from "react-toastify";
import { useCallback, useEffect } from "react";
import backendURL, { httpAPI_admin } from "./AxiosAPI";
import { setCount } from "./slices/Notification";
import Approvals from "./pages/Approvals";
import ApprovalHistory from "./pages/ApprovalHistory";
import BookedSessionDetails from "./pages/BookedSessionDetails";
import { setPendingCount } from "./slices/PendingApprovalCount";
import PendingCoachPage from "./pages/PendingCoachPage";
import TermsAndConditions from "./pages/TermsAndConditions";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Enquiries from "./pages/Enquiries";
import PayoutReceipts from "./pages/PayoutReceipts";
import TransactionHistoryCoachee from "./pages/TransactionHistoryCoachee";
import CoachResource from "./pages/CoachResource";
import CoacheeResource from "./pages/CoacheeResource";
import CoachResourceDetails from "./pages/CoachResourceDetails";
import CoacheeResourceDetails from "./pages/CoacheeResourceDetails";
import BookingsReport from "./pages/BookingsReport";
import StripeTransactions from "./pages/StripeTransactions";
import RefundRequestPage from "./pages/RefundRequestPage";
import RefundRequestPageHistory from "./pages/RefundRequestPageHistory";
import RefundRequestDetails from "./pages/RefundRequestDetails";
import CookiePolicy from "./pages/CookiePolicy";
import CoachAgreements from "./pages/CoachAgreements";
import CoachAgreementDetails from "./pages/CoachAgreementDetails";
import CSVUploadComponent from "./components/CSVUploadComponent";
import UploadCoaches from "./components/UploadCoaches";
import BulkAddHistory from "./components/BulkAddHistory";
import SyncCoachesFromHubspot from "./pages/bulk-write/SyncCoachesFromHubspot";
import ServerPar from "./pages/ServerPar";
import Companies from "./pages/companies/Companies";
import CompanyDetails from "./pages/companies/details/CompanyDetails";
import ShortListedCoaches from "./pages/Shortlists/ShortListedCoaches";
import { adminLogin, adminLogout } from "./slices/Login";

const theme = createTheme({
  typography: {
    fontFamily: "'Montserrat', sans-serif",
  },
});

interface Props {
  isAuthenticated: boolean;
}
const IsAdminLogin: React.FC<Props> = ({ isAuthenticated }) => {
  return isAuthenticated ? <Outlet /> : <Navigate to="/login" />;
};
export default function App() {
  const isAuthenticatedAdmin = useSelector(
    (state: any) => state.adminLogin.userdata.name
  );
  const loginUserData = useSelector((state: any) => state.adminLogin.userdata);
  const dispatch = useDispatch();

  const fetchNotifications = async () => {
    try {
      const response = await httpAPI_admin.post(
        `${backendURL}/admin/profile/get-all-notifications?page=${1}&limit=${20}`,
        { _id: loginUserData._id }
      );
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        console.log(response);
        dispatch(setCount(response.data.unreadNotifications));
      }
    } catch (error: any) {
      console.log(error);
    }
  };
  const fetchPendingApprovalData = async () => {
    try {
      const response = await httpAPI_admin.get(
        `/admin/coach/new-profile-approval-requests?pageNo=1&filter=2`
      );
      if (response.data.success) {
        dispatch(setPendingCount(response.data.data.length));
        return;
      }
    } catch (error) {
      console.log({ error });
    }
  };
  const fetchProfile = useCallback(async () => {
    try {
      const response = await httpAPI_admin.get(
        `${backendURL}/admin/profile/data`
      );
      if (response.status === 200) {
        const data = response.data.data;
        dispatch(adminLogin(data));
      } else {
        dispatch(adminLogout());
        localStorage.clear();
      }
    } catch (error: any) {
      const status = error?.response?.status;
      if ([400, 401, 404].includes(status)) {
        dispatch(adminLogout());
        localStorage.clear();
      } else {
        console.error("Unhandled error fetching profile:", error);
      }
    }
  }, [dispatch]);

  const alertListener = () => {
    socket.onAny((event, data) => {
      console.log(`Event received: ${event}`, data);
    });
    socket.on("listening-to-alerts", (data) => {
      console.log(data);
    });
    socket.on("new-alert", (data) => {
      toast.info(data?.heading || "There is a new notification");
      fetchPendingApprovalData();
      fetchNotifications();
    });
  };

  const stopLiveListener = () => {
    socket.off("new-alert");
  };

  useEffect(() => {
    socket.emit("listen-alerts", { _id: loginUserData._id });
    fetchPendingApprovalData();
  }, []);

  useEffect(() => {
    if (loginUserData) {
      alertListener();
    }
    return () => stopLiveListener();
  }, [loginUserData]);

  useEffect(() => {
    fetchProfile();
  }, []);

  return (
    <ThemeProvider theme={theme}>
      <BrowserRouter>
        <Routes>
          <Route
            element={<IsAdminLogin isAuthenticated={isAuthenticatedAdmin} />}
          >
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="coach">
                <Route index element={<CoachPage />} />
                <Route path="detail/:coachId" element={<CoachDetails />} />
                <Route path="coach-agreements">
                  <Route index element={<CoachAgreements />} />
                  <Route path="details" element={<CoachAgreementDetails />} />
                </Route>
                <Route
                  path="booking-history/:coachId"
                  element={<CoachBookingsList />}
                />
              </Route>
              <Route path="stripe-txns" element={<StripeTransactions />} />
              <Route path="coachee">
                <Route index element={<UserPage />} />
                <Route path="detail/:userId" element={<UserDetails />} />
                <Route
                  path="booking-history/:userId"
                  element={<UserBookingsList />}
                />
                <Route
                  path="transaction-history/:userId"
                  element={<TransactionHistoryCoachee />}
                />
              </Route>
              <Route path="payout">
                <Route index element={<Payout />} />
                <Route path="detail/:coachId" element={<PayoutDetails />} />
                <Route
                  path="detail/receipts/:coachId"
                  element={<PayoutReceipts />}
                />
              </Route>
              <Route path="bookings">
                <Route index element={<BookingsPage />} />
                <Route path="detail/:bookingId">
                  <Route index element={<BookingDetails />} />
                  <Route path="session">
                    <Route
                      path="detail/:bookedSessionId"
                      element={<BookedSessionDetails />}
                    />
                  </Route>
                </Route>
                <Route path="booking-reports" element={<BookingsReport />} />
              </Route>
              {/* //adding new route for the request for approval of the profiles of the coaches  */}
              <Route path="approvals">
                <Route index element={<Approvals />} />
                <Route path="history" element={<ApprovalHistory />} />
              </Route>
              <Route path="pending-coaches">
                <Route index element={<PendingCoachPage />} />
              </Route>
              <Route path="bulk-add" element={<CSVUploadComponent />}>
                <Route index element={<UploadCoaches />} />
                <Route path="coach" element={<UploadCoaches />} />
                <Route
                  path="coach-hubspot"
                  element={<SyncCoachesFromHubspot />}
                />
                <Route path="user" element={"Coachee"} />
                <Route path="history" element={<BulkAddHistory />} />
              </Route>
              <Route path="refunds">
                <Route index element={<RefundRequestPage />} />
                <Route
                  path={"history"}
                  element={<RefundRequestPageHistory />}
                />
                <Route
                  path={"details/:refund_id"}
                  element={<RefundRequestDetails />}
                />
              </Route>
              <Route path="companies">
                <Route index element={<Companies />} />
                <Route path="details/:companyId" element={<CompanyDetails />} />
              </Route>
              <Route
                path="/chat-history/:id/:entity"
                element={<ChatHistory />}
              />
              <Route path="resource">
                <Route index element={<CoachResource />} />
                <Route
                  path="details/:resourceId"
                  element={<CoachResourceDetails />}
                />
              </Route>
              <Route path="coachee-resource">
                <Route index element={<CoacheeResource />} />
                <Route
                  path="details/:resourceId"
                  element={<CoacheeResourceDetails />}
                />
              </Route>

              <Route
                path="shortlisted-coaches"
                element={<ShortListedCoaches />}
              />
              <Route path="notification" element={<NotificationPage />} />
              <Route path="enquiries" element={<Enquiries />} />
              <Route path="profile" element={<ProfilePage />} />
              <Route path="terms-conditions" element={<TermsAndConditions />} />
              <Route path="privacy-policy" element={<PrivacyPolicy />} />
              <Route path="cookie-policy" element={<CookiePolicy />} />
              <Route path="server-stats" element={<ServerPar />} />
            </Route>
          </Route>
          <Route path="/login" element={<LoginPage />}></Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
