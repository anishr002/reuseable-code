import { io } from "socket.io-client";
import apiBaseUrl from "./URLconf";
const authToken = localStorage.getItem("authToken");

export const socket = io(apiBaseUrl, {
  extraHeaders: {
    authorization: `bearer ${authToken}`,
  },
});

