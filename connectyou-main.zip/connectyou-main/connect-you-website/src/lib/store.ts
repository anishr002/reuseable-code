import { configureStore } from "@reduxjs/toolkit";
import loginReducer from "../slices/Login";
import unreadCountReducer from "../slices/Notification";
import cartKeyReducer from "../slices/CartId";
import refreshTrigger from "../slices/refreshTrigger";
import unreadMessageReducerCoach from "../slices/MessageCountCoach";
import unreadMessageReducerCoachee from "../slices/MessageCountCoachee";
import newMessageReducer from "../slices/NewMessage";
import cartCountReducer from "../slices/cartCount";
import NotificationDrawerReducer from "../slices/notificationDrawer";
const store = configureStore({
  reducer: {
    login: loginReducer,
    unreadCount: unreadCountReducer,
    cartId: cartKeyReducer,
    refreshTrigger: refreshTrigger,
    unreadMessageCoachee: unreadMessageReducerCoachee,
    unreadMessageCoach: unreadMessageReducerCoach,
    newMessage: newMessageReducer,
    cartCount: cartCountReducer,
    openNotificationDrawer: NotificationDrawerReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
// store.subscribe(() => {
//   console.log({ currentState: store.getState() });
// });
export default store;
