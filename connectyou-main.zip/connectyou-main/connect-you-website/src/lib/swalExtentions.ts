import Swal from "sweetalert2";
import "../styles/Swal.css";

const customAlert = Swal.mixin({
  customClass: {
    confirmButton: "swal2-confirm",
    cancelButton: "swal2-cancel",
  },
  buttonsStyling: false,
});

export default customAlert;
