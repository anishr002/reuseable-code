/* eslint-disable @typescript-eslint/no-unused-expressions */
import { SocketWithState } from "../contexts/SocketContext";

const emitMessageDelivery = ({
  socket,
  userType,
  userId,
}: {
  socket: SocketWithState | null;
  userType: string;
  userId: string;
}) => {
  const data = {
    userType,
    userId,
  };
  socket && socket?.emit(`message-delivery-status-delivered`, data);
};

const emitOnline = ({
  socket,
  userId,
  userType,
}: {
  socket: SocketWithState | null;
  userId: string;
  userType: string;
}) => {
  const data = {
    userType,
    userId,
  };
  socket && socket.emit("user-online", data);
};

const emitOffline = ({
  socket,
  userId,
}: {
  socket: SocketWithState | null;
  userId: string;
}) => {
  socket && socket.emit("user-offline", userId);
};

const emitMarkAsRead = ({
  socket,
  chatRoomId,
}: {
  socket: SocketWithState | null;
  chatRoomId: string;
}) => {
  socket &&
    socket.emit("mark-message-read", {
      chatRoomId: chatRoomId,
    });
};

export { emitMessageDelivery, emitOnline, emitOffline, emitMarkAsRead };
