import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  typography: {
    fontFamily: "'Quicksand', 'Mundial', sans-serif",
  },
  palette: {
    primary: {
      main: "#013338",
    },
    secondary: {
      main: "#3aa7a3",
    },
    action: {
      active: "#ebbd33",
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          fontFamily: "'Quicksand', 'Mundial', sans-serif",
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        option: {
          color: "#013338 !important", // Ensures list items are #013338
        },
        listbox: {
          backgroundColor: "white",
        },
        inputRoot: {
          "&.Mui-error .MuiInputBase-input": {
            color: "#FF0000 !important", // Make autocomplete input text #FF0000 in error state
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          color: "#3aa7a3", // Input text color
          "& fieldset": {
            borderColor: "#3aa7a3", // Default border
          },
          "&:hover fieldset": {
            borderColor: "#3aa7a3", // Hover border
          },
          "&.Mui-focused fieldset": {
            borderColor: "#3aa7a3", // Focus border
          },
          "&.Mui-error fieldset": {
            borderColor: "#FF0000 !important", // Keep error #FF0000
          },
          "&.Mui-error input": {
            color: "#FF0000 !important", // Make input text #FF0000 in error state
          },
          "&.Mui-error textarea": {
            color: "#FF0000 !important", // Make textarea text #FF0000 in error state
          },
          "&.Mui-error .MuiSelect-select": {
            color: "#FF0000 !important", // Make select text #FF0000 in error state
          },
        },
      },
    },
    MuiInputLabel: {
      styleOverrides: {
        root: {
          color: "#3aa7a3", // Label color
          "&.Mui-focused": {
            color: "#3aa7a3",
          },
          "&.Mui-error": {
            color: "#FF0000", // Keep label #FF0000 in error state
          },
        },
      },
    },
    MuiSvgIcon: {
      styleOverrides: {
        root: {
          color: "#3aa7a3", // Styles dropdown arrow & clock icon
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          borderRadius: "24px",
          "& .MuiOutlinedInput-root": {
            "& fieldset": {
              borderColor: "#3aa7a3", // Default border color
            },
            "&:hover fieldset": {
              borderColor: "#3aa7a3", // Hover border color
            },
            "&.Mui-focused fieldset": {
              borderColor: "#3aa7a3", // Focused border color
            },
            "&.Mui-error fieldset": {
              borderColor: "#FF0000 !important", // Keep error outline #FF0000
            },
            "&.Mui-error input": {
              color: "#FF0000 !important", // Text color in error state
            },
            "&.Mui-error textarea": {
              color: "#FF0000 !important", // Textarea color in error state
            },
          },
          "& .MuiInputBase-input": {
            color: "#3aa7a3", // Input text color
            fontSize: "16px",
          },
          "& .MuiSvgIcon-root": {
            color: "#3aa7a3", // Calendar icon color
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          "&.Mui-error": {
            color: "#FF0000 !important", // Make select text #FF0000 in error state
          },
        },
        select: {
          "&.Mui-error": {
            color: "#FF0000 !important", // Additional selector for select text
          },
        },
      },
    },
    MuiFormControl: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderColor: "#3aa7a3",
            "&:hover fieldset": { borderColor: "#3aa7a3" },
            "&.Mui-focused fieldset": { borderColor: "#3aa7a3" },
            "&.Mui-error fieldset": {
              borderColor: "#FF0000 !important",
            },
            "&.Mui-error input": {
              color: "#FF0000 !important", // Form control input text in error state
            },
          },
        },
      },
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          "&.Mui-error": {
            root: {
              "&.Mui-error": {
                color: "#FF0000",
              },
            },
          },
        },
      },
    },
  },
});

export default theme;
