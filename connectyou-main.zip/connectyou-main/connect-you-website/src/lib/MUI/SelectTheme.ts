import { createTheme } from "@mui/material/styles";

export const Selecttheme = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3", // keep same on focus
          },
        },
        input: {
          color: "#3aa7a3", // Input text color
        },
      },
    },
    MuiInputLabel: {
      styleOverrides: {
        root: {
          color: "#3aa7a3",
          "&.Mui-focused": {
            color: "#3aa7a3",
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        icon: {
          color: "#3aa7a3", // Dropdown arrow color
        },
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: {
          color: "#3aa7a3",
          "&.Mui-selected": {
            fontWeight: 700,
            backgroundColor: "transparent", // prevent background highlight
            "&:hover": {
              backgroundColor: "rgba(58, 167, 163, 0.1)", // optional hover effect
            },
          },
        },
      },
    },
  },
});
