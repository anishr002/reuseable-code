import { createTheme } from "@mui/material";

const DarkSeaTextFieldTheme = createTheme({
  palette: {
    primary: {
      main: "#989898",
    },
  },
  components: {
    MuiInputLabel: {
      styleOverrides: {
        root: {
          color: "#013338",
          "&.Mui-focused": {
            color: "#013338",
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: "#989898",
          },
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: "#989898",
          },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: "#013338",
          },
          "& .MuiInputBase-input": {
            color: "#013338",
          },
        },
      },
    },
  },
});

export default DarkSeaTextFieldTheme;
