export const thinScroll = {
    "& .MuiOutlinedInput-input": {
      scrollbarWidth: "thin", // For Firefox
      "&::-webkit-scrollbar": {
        width: "4px", // For Webkit-based browsers (Chrome, Edge, etc.)
        height: "4px",
      },
      "&::-webkit-scrollbar-thumb": {
        backgroundColor: "rgba(0, 0, 0, 0.5)", // Customize the thumb color
        borderRadius: "10px",
      },
      "&::-webkit-scrollbar-thumb:hover": {
        backgroundColor: "rgba(0, 0, 0, 0.7)", // Thumb color on hover
      },
      "&::-webkit-scrollbar-track": {
        backgroundColor: "transparent", // Customize the track color
      },
    },
  };