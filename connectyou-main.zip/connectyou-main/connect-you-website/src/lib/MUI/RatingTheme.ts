import { createTheme } from "@mui/material/styles";

const RatingTheme = (themeColor: string) => {
  return createTheme({
    components: {
      MuiRating: {
        styleOverrides: {
          iconFilled: {
            color: themeColor,
          },
        },
      },
    },
  });
};

export default RatingTheme;
