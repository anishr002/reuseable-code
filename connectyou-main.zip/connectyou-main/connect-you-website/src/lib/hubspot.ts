import {
  HubSpotProperties_Type_Coach,
  HubSpotProperties_Type_Coachee,
} from "../Types/backend/HubSpotProperties_Type";
import backendURL, { httpAPI } from "../util/AxiosAPI";

export type HS_properties = Partial<
  HubSpotProperties_Type_Coach | HubSpotProperties_Type_Coachee
>;

interface addAsHubSpotContactProps {
  _id: Required<string>;
  properties: HS_properties;
  userType: "coach" | "coachee";
}

const addAsHubSpotContact = async ({
  _id,
  properties,
  userType,
}: addAsHubSpotContactProps) => {
  try {
    // console.log({ _id, properties, userType });
    const response = await httpAPI.post(
      `${backendURL}/hub/api-v3/contacts/create-hub-contact`,
      { _id, properties, userType }
    );
    console.log({ "HS-US": response.status });
  } catch (error) {
    console.error("Error Adding to hubspot", error);
  }
};

export default addAsHubSpotContact;

const updateHubSpotInfo = async ({
  userType,
}: {
  userType: "coach" | "coachee";
}) => {
  try {
    const response = await httpAPI.post(
      `${backendURL}/hub/api-v3/contacts/${userType}/update-hub-contact`
    );
    console.log({ "HS-US": response.status });
  } catch (error) {
    console.log({ "Error updating hubspot contact": error });
  }
};

const genHubLead = async ({
  data,
}: {
  data: Partial<HubSpotProperties_Type_Coach | HubSpotProperties_Type_Coachee>;
}) => {
  try {
    const response = await httpAPI.post(
      `${backendURL}/hub/api-v3/leads/generate-hub-lead`,
      data
    );
    console.log({ "HS-US": response.status });
  } catch (error) {
    console.error("Error Adding to hubspot", error);
  }
};

export { updateHubSpotInfo, genHubLead };
