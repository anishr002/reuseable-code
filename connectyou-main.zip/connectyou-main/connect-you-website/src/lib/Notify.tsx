import { createTheme } from "@mui/material/styles";
import { IoClose } from "react-icons/io5";
import React, {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect,
  ReactElement,
  useCallback,
} from "react";
import Snackbar, { SnackbarCloseReason } from "@mui/material/Snackbar";
import Alert, { AlertColor } from "@mui/material/Alert";
import useNetworkAndServerStatus from "../util/useNetworkAndServerStatus";
import {
  CssBaseline,
  IconButton,
  Slide,
  SlideProps,
  ThemeProvider,
} from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "./store";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import NewReleasesIcon from "@mui/icons-material/NewReleases";
import HelpCenterIcon from "@mui/icons-material/HelpCenter";
import { PopAlertRegister } from "../util/PopAlert";
import { useNavigate } from "react-router-dom";

export type NotifyParams = {
  message: ReactNode;
  messageDescription?: ReactNode;
  severity?: AlertColor;
  variant?: "filled" | "outlined" | "standard";
  horizontal?: "left" | "right" | "center";
  vertical?: "top" | "bottom";
  autohideDuration?: number;
  dontHide?: boolean;
  onClick?: string | null;
  type?: "chat" | "alert" | "others";
  actionOnClick?: () => void | undefined;
  iconPlaceholder?: ReactNode;
};

type NotificationContextType = {
  notifyMe: (params: NotifyParams) => void;
};

const NotificationContext = createContext<NotificationContextType | undefined>(
  undefined
);

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<
    { id: string; params: NotifyParams }[]
  >([]);

  const notifyMe = useCallback((params: NotifyParams) => {
    setNotifications((prev) => [
      ...prev,
      { id: `${Date.now()}-${Math.random()}`, params },
    ]);
  }, []);

  const handleClose =
    (id: string) =>
    (_: React.SyntheticEvent | Event, reason?: SnackbarCloseReason) => {
      if (reason === "clickaway") return;
      setNotifications((prev) =>
        prev.filter((notification) => notification.id !== id)
      );
    };

  const { isOnline, isServerConnected } = useNetworkAndServerStatus();

  const SlideTransitionDown = (props: SlideProps) => {
    return <Slide {...props} direction="down" />;
  };
  const SlideTransitionRightToLeft = (props: SlideProps) => {
    return <Slide {...props} direction="left" />;
  };
  const loginUserData = useSelector((state: RootState) => state.login.userdata);

  const returnStyle = (severity: AlertColor) => {
    switch (severity) {
      case "success":
        return {
          color: "#fff",
          background: "#3aa7a3",
          icon: <CheckCircleIcon />,
        };
      case "info":
        return {
          color: "#013338",
          background: "#f9f9f9",
          icon: <HelpCenterIcon />,
        };
      case "warning":
        return {
          color: "#fff",
          background: "#ebbd33",
          icon: <NewReleasesIcon />,
        };
      case "error":
        return {
          color: "#fff",
          background: "#ff0000",
          icon: <ErrorIcon />,
        };
    }
  };
  useEffect(() => {
    if (notifyMe) {
      PopAlertRegister.setNotifyHandler(notifyMe);
    }
    return () => PopAlertRegister.cleanUp();
  }, [notifyMe]);
  const navigate = useNavigate();

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <NotificationContext.Provider value={{ notifyMe }}>
        {children}
        {!isOnline || !isServerConnected ? (
          <></>
        ) : (
          notifications.map((notification, index) => {
            return (
              <Snackbar
                key={notification.id}
                anchorOrigin={{
                  vertical: notification.params.vertical || "top",
                  horizontal: notification.params.horizontal || "right",
                }}
                open
                autoHideDuration={
                  notification.params.dontHide
                    ? null
                    : notification.params.autohideDuration || 2000
                }
                sx={{ mt: index * 8 }}
                onClose={handleClose(notification.id)}
                slotProps={{
                  transition:
                    notification.params.vertical === "top"
                      ? SlideTransitionDown
                      : SlideTransitionRightToLeft,
                }}
              >
                <Alert
                  severity={notification.params.severity || "info"}
                  variant={notification.params.variant || "filled"}
                  sx={{
                    position: "relative",
                    width: "100%",
                    fontFamily: "Quicksand",
                    background: returnStyle(
                      notification.params.severity || "success"
                    ).background,
                    color: returnStyle(
                      notification.params.severity || "success"
                    ).color,
                  }}
                  icon={
                    notification.params.iconPlaceholder
                      ? notification.params.iconPlaceholder
                      : returnStyle(notification.params.severity || "success")
                          .icon
                  }
                  action={
                    <div className="flex items-center space-x-2">
                      <IconButton
                        aria-label="close"
                        size="small"
                        onClick={handleClose(notification.id)}
                        sx={{ color: "inherit", p: 0.2 }}
                      >
                        <IoClose size={18} />
                      </IconButton>
                    </div>
                  }
                  slotProps={{
                    icon: {
                      onClick: () => {
                        if (notification.params.actionOnClick) {
                          notification.params.actionOnClick();
                        } else if (notification.params.onClick) {
                          navigate(notification.params.onClick);
                        }
                      },
                      className: "my-auto px-3",
                    },
                  }}
                >
                  <div
                    onClick={notification.params.actionOnClick}
                    className="flex flex-col gap-1 max-w-[20rem]"
                  >
                    <div
                      className="cursor-pointer line-clamp-1 font-mundial  text-[1rem]"
                      onClick={() => {
                        if (notification.params.actionOnClick) {
                          notification.params.actionOnClick();
                        } else if (notification.params.onClick) {
                          navigate(notification.params.onClick);
                        } else {
                          navigate(
                            `/${
                              loginUserData.userType === "coach" ? "c" : "u"
                            }/notifications`
                          );
                        }
                      }}
                    >
                      {notification.params.message}
                    </div>
                    <span
                      onClick={() => {
                        if (notification.params.actionOnClick) {
                          notification.params.actionOnClick();
                        } else if (notification.params.onClick) {
                          navigate(notification.params.onClick);
                        } else {
                          navigate(
                            `/${
                              loginUserData.userType === "coach" ? "c" : "u"
                            }/notifications`
                          );
                        }
                      }}
                      className="cursor-pointer font-medium text-xs line-clamp-2"
                    >
                      {notification.params.messageDescription}
                    </span>
                  </div>
                </Alert>
              </Snackbar>
            );
          })
        )}
      </NotificationContext.Provider>
    </ThemeProvider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useNotify = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error(
      "useNotification must be used within a NotificationProvider"
    );
  }
  return context;
};

export const SetupPopAlerts = ({
  children,
}: {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  children: ReactElement<unknown, any>;
}) => {
  useNotify();
  return <>{children}</>;
};

// theme.ts or theme/index.ts

const theme = createTheme({
  components: {
    MuiAlert: {
      styleOverrides: {
        root: {
          fontFamily: "Quicksand",
          borderRadius: 10,
          boxShadow: "0 2px 10px rgba(0,0,0,0.15)",
        },
        filledSuccess: {
          backgroundColor: "#3aa7a3",
          color: "#ffffff",
        },
        filledWarning: {
          backgroundColor: "#ebbd33",
          color: "#000000",
        },
        filledError: {
          backgroundColor: "#f44336",
          color: "#ffffff",
        },
        filledInfo: {
          backgroundColor: "#2196f3",
          color: "#ffffff",
        },
      },
    },
  },
});
