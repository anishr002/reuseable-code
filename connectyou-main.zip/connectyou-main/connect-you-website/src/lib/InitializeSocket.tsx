/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "./store";
import useFetchNotification from "../components/hooks/useFetchNotification";
import { useNotify } from "./Notify";
import { setNewMessage } from "../slices/NewMessage";
import backendURL, { httpAPI } from "../util/AxiosAPI";
import { setUnreadMessageCoach } from "../slices/MessageCountCoach";
import { setUnreadMessageCoachee } from "../slices/MessageCountCoachee";
import { useEffect } from "react";
import { useSocketContext } from "../contexts/SocketContext";
import { callRefresh } from "../slices/notificationDrawer";
import { useNavigate } from "react-router-dom";
import { Avatar } from "@mui/material";
import ChatAvatar from "../components/UI/ChatAvatar";
import { IoChatbubbleEllipsesSharp } from "react-icons/io5";
import { emitMessageDelivery, emitOffline, emitOnline } from "./emitter";

const InitializeSocket = () => {
  const getSocket = useSocketContext();
  const socket = getSocket();
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  const loginData = loginUserData?.name && loginUserData;
  const loginUserType = loginData
    ? loginUserData.userType == "coach"
      ? "c"
      : "u"
    : null;
  const newMessage = useSelector((state: RootState) => state.newMessage.isNew);
  const dispatch = useDispatch();
  const { refresh } = useFetchNotification();
  const { notifyMe } = useNotify();
  const navigate = useNavigate();

  const fetchMessageCount = async () => {
    dispatch(setNewMessage({ isNew: !newMessage }));
    if (loginUserType == "c") {
      try {
        const response = await httpAPI.get(
          `${backendURL}/coach/message/unread-count`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("authToken")}`,
            },
          }
        );
        if (response.status !== 200) {
          console.error("server error");
        } else {
          const unreadCount = response.data.data;
          dispatch(setUnreadMessageCoach(unreadCount));
        }
      } catch (error: any) {
        console.log(error);
      }
    }
    if (loginUserType == "u") {
      try {
        const response = await httpAPI.get(
          `${backendURL}/user/dashboard/unread-count`
        );
        if (response.status !== 200) {
          console.error("server error");
        } else {
          const unreadCount = response.data.data;
          dispatch(setUnreadMessageCoachee(unreadCount));
        }
      } catch (error: any) {
        console.log(error);
      }
    }
  };

  useEffect(() => {
    if (loginUserType && socket) {
      socket.emit("listen-alerts", { _id: loginUserData._id });
    }
  }, [loginUserType, socket, loginUserData._id]);

  useEffect(() => {
    const alertListener = () => {
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      socket &&
        socket.on("new-alert", (data) => {
          // console.log(data);
          emitMessageDelivery({
            socket: socket,
            userId: loginUserData._id || "",
            userType: loginUserData.userType || "",
          });
          notifyMe({
            message: data?.heading || "There is a new notification",
            messageDescription: data?.description,
            severity: "info",
            onClick: data?.url,
          });
          dispatch(callRefresh());
          refresh();
        });
    };
    function onConnect() {
      console.log("connected");
      emitOnline({
        socket: socket,
        userId: loginUserData._id || "",
        userType: loginUserData.userType || "",
      });
    }
    function onDisconnect() {
      console.log("diconnected");
      emitOffline({
        socket: socket,
        userId: loginUserData._id || "",
      });
    }
    if (loginUserType && socket) {
      socket.connect();
      socket.on("connect", onConnect);
      socket.on("disconnect", onDisconnect);
      alertListener();
    }
    return () => {
      if (socket) {
        socket.disconnect();
        socket.off("connect", onConnect);
        socket.off("disconnect", onDisconnect);
        socket.off("socket.off");
      }
    };
  }, [loginUserType, loginUserData._id, socket]);

  useEffect(() => {
    const handleRecievMessage = () => {
      fetchMessageCount();
    };
    const handleIncomingMessage = (data: {
      senderId: string;
      message: string;
      from: string;
      image: string;
    }) => {
      fetchMessageCount();
      if (data.message)
        if (!window.location.pathname.includes("chat"))
          return notifyMe({
            autohideDuration: 3500,
            message: data?.from || "New Message",
            messageDescription: (
              <span className="line-clamp-1 ">
                <IoChatbubbleEllipsesSharp className=" inline mr-1 text-inherit" />
                {data?.message || "Unsupported message"}
              </span>
            ),
            severity: "info",
            iconPlaceholder: (
              <ChatAvatar _id={data.senderId} socket={socket}>
                <Avatar
                  alt={data?.from}
                  src={`${backendURL}/usersProfile/${data.image}`}
                  sx={{
                    width: { xs: 50, md: 40 },
                    height: { xs: 50, md: 40 },
                  }}
                />
              </ChatAvatar>
            ),
            actionOnClick: () => {
              loginUserType &&
                navigate(`/${loginUserType}/chat`, {
                  state: { openChatFor: true, chatFor: data?.senderId },
                });
            },
          });
    };
    if (socket) {
      socket.on("new-message", handleRecievMessage);
      socket.on("got-new-message", handleIncomingMessage);
    }
    return () => {
      if (socket) {
        socket.off("new-message", handleRecievMessage);
        socket.off("got-new-message", handleIncomingMessage);
      }
    };
  }, [socket]);

  return <></>;
};

export default InitializeSocket;
