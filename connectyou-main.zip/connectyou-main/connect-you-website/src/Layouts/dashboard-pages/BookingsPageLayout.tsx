import React, { useEffect, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { DarkThemeButtonTransparent } from "../../components/buttons/ThemeButtons";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import CreatePageHeading, {
  HeadingText,
} from "../../contexts/context-hooks/useCreateHeading";
type routeOptions = "upcoming" | "completed" | "canceled";
const BookingsPageLayout: React.FC = () => {
  const loggedUser = useSelector((state: RootState) => state.login.userdata);
  const location = useLocation();
  const navigate = useNavigate();
  const [activeRoute, setActiveRoute] = useState<routeOptions>("upcoming");

  useEffect(() => {
    if (location?.pathname && location?.pathname.includes("completed")) {
      setActiveRoute("completed");
    } else if (location?.pathname && location?.pathname.includes("canceled")) {
      setActiveRoute("canceled");
    } else {
      setActiveRoute("upcoming");
    }
  }, [location.pathname]);

  return (
    <>
      <CreatePageHeading>
        <HeadingText>Bookings</HeadingText>
      </CreatePageHeading>
      <div className="flex flex-col h-full  w-full">
        <div className="flex md:flex-row md:flex-wrap flex-col md:space-y-0 space-y-3.5 justify-start md:items-center space-x-3.5 pb-[30px]">
          <DarkThemeButtonTransparent
            text="upcoming sessions"
            isActive={activeRoute === "upcoming"}
            onClick={() => {
              navigate(
                `/${
                  loggedUser.userType === "coach" ? "c" : "u"
                }/bookings/upcoming`
              );
              setActiveRoute("upcoming");
            }}
          />
          <DarkThemeButtonTransparent
            text="completed sessions"
            isActive={activeRoute === "completed"}
            onClick={() => {
              navigate(
                `/${
                  loggedUser.userType === "coach" ? "c" : "u"
                }/bookings/completed`
              );
              setActiveRoute("completed");
            }}
          />
          <DarkThemeButtonTransparent
            text="canceled/Incomplete"
            isActive={activeRoute === "canceled"}
            onClick={() => {
              navigate(
                `/${
                  loggedUser.userType === "coach" ? "c" : "u"
                }/bookings/canceled`
              );
              setActiveRoute("canceled");
            }}
          />
        </div>
        <div className="flex flex-col w-full flex-1">
          <Outlet />
        </div>
      </div>
    </>
  );
};

export default BookingsPageLayout;
