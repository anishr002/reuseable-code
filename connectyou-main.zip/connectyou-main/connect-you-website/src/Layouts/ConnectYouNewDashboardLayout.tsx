import React, { useEffect, useRef, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import "../App.css";
import WebsitelogoLink from "../components/UI/WebsitelogoLink";
import DashboardSideNavLinks from "../components/Navigations/DashboardSideNavLinks";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../lib/store";
import navigationLinkOptions from "../Options/navigationLinkOptions";
import { useCreateHeading } from "../contexts/context-hooks/useCreateHeading";
import LoggedUserNavigationItem from "../components/UI/LoggedUserNavigationItem";
import { MdOutlineNotificationAdd } from "react-icons/md";
import { FormProvider, useForm } from "react-hook-form";
import { IoSearchSharp } from "react-icons/io5";
import {
  Autocomplete,
  AutocompleteChangeReason,
  Box,
  createTheme,
  CssBaseline,
  FilterOptionsState,
  IconButton,
  TextField,
  ThemeProvider,
  Tooltip,
} from "@mui/material";
import { GiHamburgerMenu } from "react-icons/gi";
import FilterMobileDrawer from "../pages/find-a-coach-page/FilterMobileDrawer";
import NotificationItemsCount from "../components/UI/NotificationItemsCount";
import { toggleOpenNotifiDrawer } from "../slices/notificationDrawer";
import { IoMdLogOut } from "react-icons/io";
import logoutLocal from "../util/logoutLocal";
import { logout } from "../slices/Login";
import getSearchSuggestionsList from "../Types/maps/searchMap";
import { SearchOtpionTypes } from "../Types/UI/SearchMap";

const ConnectYouNewDashboardLayout: React.FC = () => {
  const dispatch = useDispatch();
  const loggedUserData = useSelector(
    (state: RootState) => state.login.userdata
  );
  const navigate = useNavigate();
  const { content } = useCreateHeading();
  const methods = useForm<{ searchStr?: string }>();
  const location = useLocation();
  const [addPadding, setAddPadding] = useState(true);
  useEffect(() => {
    if (
      location?.pathname?.includes("/u/chat") ||
      location?.pathname?.includes("/c/chat")
    ) {
      setAddPadding(false);
    } else {
      setAddPadding(true);
    }
  }, [location.pathname]);

  const PageHeading = () => {
    return (
      <div className="leading-0">
        {content ? content : <div className="w-1 h-1"></div>}
      </div>
    );
  };

  const drawerRef = useRef<{ toggleDrawer: (b: boolean) => void } | null>(null);

  return (
    <FormProvider {...methods}>
      <div className="flex flex-col w-full h-screen  overflow-hidden">
        <div className="flex flex-1 w-full h-full">
          <aside className="hidden md:flex flex-col w-[270px] bg-[white]   shadow-md">
            <div className="w-full min-h-[70px] h-[70px] bg-[#013338]  px-10 flex items-center shadow">
              <div className="flex items-center justify-start h-full flex-1">
                <WebsitelogoLink />
              </div>
            </div>
            <div className="flex flex-col style-scroll overflow-auto style-scroll-thin  px-10  py-10 justify-start items-start gap-7">
              <DashboardSideNavLinks
                links={
                  loggedUserData.userType === "coach"
                    ? navigationLinkOptions.coachDashboard
                    : navigationLinkOptions.coacheeDashboard
                }
              />
            </div>
          </aside>
          <main className="flex-1 h-full w-full  overflow-hidden">
            <div className="  w-full min-h-[70px] h-[70px] bg-[#013338] px-10 md:ps-4 flex items-center ">
              <div className="w-full h-full flex flex-row justify-between items-center text-white">
                <div className="flex md:hidden w-[120px]">
                  <WebsitelogoLink />
                </div>
                <div className="hidden md:flex items-center justify-start h-full md:flex-1">
                  <PageHeading />
                </div>
                <div className="flex md:hidden  items-center justify-end gap-5 flex-1">
                  <div className="flex md:hidden items-center justify-end  h-full ">
                    <PageHeading />
                  </div>
                  <GiHamburgerMenu
                    className="text-[24px] cursor-pointer text-white hover:text-[#ebbd33]"
                    onClick={() => {
                      drawerRef.current?.toggleDrawer(true);
                    }}
                  />
                </div>
                <div className="flex md:hidden">
                  <FilterMobileDrawer
                    minWidth={"100%"}
                    keepChildinBigScreens={false}
                    iconColor="white"
                    ref={drawerRef}
                    background="#013338"
                    heading={
                      <div className="sm:ps-10 ps-2 flex flex-1 w-full justify-between items-center h-[70px]">
                        <div className="w-[160px] pr-4 items-center flex justify-start">
                          <WebsitelogoLink />
                        </div>
                        <div className="flex items-center justify-start h-full text-[16px]">
                          <PageHeading />
                        </div>
                      </div>
                    }
                    anchor="top"
                  >
                    <div className="flex flex-col justify-start items-center gap-7 px-10 pt-10 pb-10 max-h-[100dvh-70px] ">
                      <div className="flex flex-col justify-start items-start gap-7 ">
                        <div
                          onClick={() => {
                            navigate(
                              `${
                                loggedUserData?.userType === "coach"
                                  ? "/c"
                                  : "/u"
                              }/profile`
                            );
                            drawerRef.current?.toggleDrawer(false);
                          }}
                          className="flex items-center gap-4 "
                        >
                          <div className=" w-fit h-fit border border-[#ebbd33] rounded-full p-0.5 cursor-pointer">
                            <LoggedUserNavigationItem
                              size={40}
                              helper={() => undefined}
                              link={{ name: "Login", link: "/login" }}
                              showName={false}
                            />
                          </div>
                          <div className="text-[#ebbd33] hover:text-[#3aa7a3] font-semibold text-[20px]">
                            Profile
                          </div>
                          <button
                            onClick={() => {
                              dispatch(toggleOpenNotifiDrawer());
                            }}
                            className=" translate-x-[200%] text-[30px] text-white hover:text-[#ebbd33] cursor-pointer "
                          >
                            <NotificationItemsCount />
                            <MdOutlineNotificationAdd />
                          </button>
                        </div>
                        <DashboardSideNavLinks
                          onClick={() => {
                            drawerRef.current?.toggleDrawer(false);
                          }}
                          colors={{ primary: "white", secondary: "#3aa7a3" }}
                          links={
                            loggedUserData.userType === "coach"
                              ? navigationLinkOptions.coachDashboard.filter(
                                  (a) => a.name !== "Profile"
                                )
                              : navigationLinkOptions.coacheeDashboard.filter(
                                  (a) => a.name !== "Profile"
                                )
                          }
                        />
                        <button
                          type="button"
                          onClick={() => {
                            logoutLocal();
                            dispatch(logout());
                          }}
                          className="text-[red]  rounded-[100px] px-2 py-2 uppercase flex flex-row justify-start gap-3 items-center font-semibold text-[18x] "
                        >
                          <IoMdLogOut />
                          <span>Logout</span>
                        </button>
                      </div>
                      <div className="w-8/12">
                        <Searchbar />
                      </div>
                    </div>
                  </FilterMobileDrawer>
                </div>
                <div className=" md:flex hidden  items-center justify-end h-full flex-1 gap-10">
                  <div className="w-fit max-w-[300px] min-w-[240px] ">
                    <Searchbar />
                  </div>
                  <button
                    onClick={() => {
                      dispatch(toggleOpenNotifiDrawer());
                    }}
                    className=" text-[30px] text-white hover:text-[#ebbd33] cursor-pointer relative"
                  >
                    <NotificationItemsCount />
                    <MdOutlineNotificationAdd />
                  </button>
                  <div className="min-w-1 min-h-1">
                    <LoggedUserNavigationItem
                      size={40}
                      helper={() => undefined}
                      link={{ name: "Login", link: "/login" }}
                      showName={false}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col max-h-[calc(100dvh-70px)]  justify-start   items-start w-full h-full overflow-x-hidden overflow-auto style-scroll">
              <div
                style={{
                  padding: addPadding ? "16px" : "0px",
                }}
                className="flex flex-col  h-full bg-[#f0f0f0] w-full min-h-fit "
              >
                <Outlet />
              </div>
            </div>
          </main>
        </div>
      </div>
    </FormProvider>
  );
};

export default ConnectYouNewDashboardLayout;

const Searchbar: React.FC = () => {
  const navigate = useNavigate();
  const userType: string | undefined = useSelector(
    (state: RootState) => state.login.userdata.userType
  );

  const [inputValue, setInputValue] = useState("");
  const [selectedOption, setSelectedOption] =
    useState<SearchOtpionTypes | null>(null);

  const options =
    inputValue.trim().length > 0
      ? getSearchSuggestionsList(
          userType ? (userType === "coach" ? "coach" : "coachee") : undefined
        ) || []
      : [];

  const clearInput = () => {
    setInputValue("");
  };

  const handleOptionAction = (option: SearchOtpionTypes) => {
    if (option.route) {
      navigate(option.route);
    } else if (option?.action) {
      option.action?.();
    }
    clearInput();
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Autocomplete
        fullWidth
        clearOnBlur={true}
        clearOnEscape
        size="small"
        freeSolo
        inputValue={inputValue}
        onInputChange={(_, newInputValue, reason) => {
          setInputValue(newInputValue);
          if (reason === "clear") {
            clearInput();
          }
        }}
        onChange={(_, newValue, reason: AutocompleteChangeReason) => {
          if (newValue && reason === "selectOption") {
            handleOptionAction(newValue as SearchOtpionTypes);
            setSelectedOption(null);
          }
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && selectedOption) {
            handleOptionAction(selectedOption);
            setSelectedOption(null);
          }
        }}
        onHighlightChange={(_, option) => {
          setSelectedOption(option as SearchOtpionTypes);
        }}
        options={options}
        filterOptions={(
          options: SearchOtpionTypes[],
          state: FilterOptionsState<SearchOtpionTypes>
        ) => {
          const searchTerm = state.inputValue.toLowerCase();
          return options.filter((option) => {
            return (
              option.label.toLocaleLowerCase().includes(searchTerm) ||
              option.keyword.some((kw) =>
                kw.toLocaleLowerCase().includes(searchTerm)
              ) ||
              option?.subLabel?.toLocaleLowerCase()?.includes(searchTerm)
            );
          });
        }}
        slotProps={{
          listbox: {
            sx: {
              maxHeight: "300px",
              overflowY: "auto",
              zIndex: 9999,
            },
            className: "style-scroll style-scroll-thin shadow-md ",
          },
          popper: {
            placement: "bottom-start",
            sx: {
              zIndex: 9999,
              minWidth: { xs: 350, md: 450, xl: 500 },
              maxWidth: "60%",
            },
            modifiers: [
              {
                name: "preventOverflow",
                enabled: true,
                options: {
                  altAxis: true,
                  altBoundary: true,
                  boundary: "viewport",
                  padding: 8,
                },
              },
            ],
          },
        }}
        renderInput={(params) => (
          <TextField
            {...params}
            size="small"
            label="Search key term"
            fullWidth
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <Tooltip
                  title={
                    !inputValue || inputValue.length === 0
                      ? "Enter keyword to search"
                      : "Search"
                  }
                >
                  <IconButton sx={{ pr: 1 }}>
                    <IoSearchSharp
                      className={`text-[18px] mr-1 ${
                        !inputValue || inputValue.length === 0
                          ? "text-[#3aa7a3a2]"
                          : "text-[#3aa7a3] hover:text-[#ebbd33]"
                      }`}
                    />
                  </IconButton>
                </Tooltip>
              ),
            }}
          />
        )}
        renderOption={(props, option) => (
          <Box
            sx={{
              borderBottom: "1px solid #ddd",
            }}
            component={"li"}
            {...props}
            key={option.label}
          >
            <div className="w-full flex flex-row gap-2  ">
              <div className="shrink-0 flex items-center justify-center">
                {option.Icon && (
                  <option.Icon className="text-[#3aa7a3] inline mr-1" />
                )}
              </div>
              <div className="flex-1 flex flex-col px-2 py-1 w-full">
                <p className="text-sm font-semibold font-quicksand text-[#013338] line-clamp-1">
                  {option.label}
                </p>
                {option.subLabel && (
                  <span className="text-xs font-quicksand text-gray-400 line-clamp-1">
                    {option.subLabel}
                  </span>
                )}
              </div>
            </div>
          </Box>
        )}
      />
    </ThemeProvider>
  );
};

const theme = createTheme({
  components: {
    MuiInputLabel: {
      styleOverrides: {
        root: {
          color: "#3aa7a3",
          "&.Mui-focused": {
            color: "#3aa7a3",
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: "24px",
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "& .MuiInputBase-input": {
            color: "#3aa7a3",
            fontSize: "16px",
            paddingRight: "6px !important", // <- Forcefully reduce padding
          },
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            paddingRight: "6px !important", // <- Override the popup/clear icon default padding
          },
        },
      },
    },
  },
});
