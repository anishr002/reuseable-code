/* eslint-disable @typescript-eslint/no-explicit-any */
import { Link, Outlet } from "react-router-dom";
import TopNavigationBar from "../components/Navigations/TopNavigationBar";
import FooterNavigation from "../components/Navigations/FooterNavigation";
import DrawerNavigation from "../components/wrappers/DrawerNavigation";
import WebsitelogoLink from "../components/UI/WebsitelogoLink";
import React, { useState } from "react";
import XSpace from "../components/wrappers/XSpace";
import MagicScrollWrapper from "../components/wrappers/MagicScrollWrapper";
import LoggedUserNavigationItem from "../components/UI/LoggedUserNavigationItem";
import navigationLinkOptions from "../Options/navigationLinkOptions";
import Footer from "../components/UI/Footer";
import useScreenSize from "../components/hooks/useScreenSize";
import MainNavigation from "../components/UI/MainNavigation";

const ConnectYouNewWebLayout = () => {
  return (
    <>
      <MagicScrollWrapper>
        <Navigation />
      </MagicScrollWrapper>
      <Main />
    </>
  );
};

export default ConnectYouNewWebLayout;

const Navigation = () => {
  const { isMobile, isTab } = useScreenSize();
  const [open, setOpen] = useState(false);
  const toggleDrawer = (bool: boolean) => {
    setOpen(bool);
  };
  return (
    <header className="w-full h-[4.5rem] bg-[#013338] flex justify-center items-center ">
      <XSpace>
        <div className="hidden lg:flex w-full h-fit py-1 justify-center items-center">
          <TopNavigationBar>
            <div className="">
              <WebsitelogoLink />
            </div>
            <div className="flex flex-1 justify-center font-[500] text-md md:text-base items-center gap-6 uppercase">
              <MainNavigation
                links={navigationLinkOptions.top}
                helper={() => toggleDrawer(false)}
              />
            </div>
            <Link
              to={"/get-in-touch"}
              className="hidden sm:flex flex-row justify-center items-center cursor-pointer uppercase h-[35px] sm:w-[170px] rounded-[30px] bg-[#EBBD33] text-[#013338] whitespace-nowrap px-6 hover:border hover:border-[#013338] hover:bg-[white] transition-all duration-300 ease-in-out text-xs sm:text-sm"
            >
              Get In Touch
            </Link>
          </TopNavigationBar>
        </div>
        <div className="lg:hidden flex w-full h-fit  py-1 justify-between items-center">
          <div className="">
            <WebsitelogoLink />
          </div>
          <div className="flex flex-row gap-2 items-center justify-center">
            {navigationLinkOptions.top.map((link, i) => {
              if (link.link === "/login" && (isMobile || isTab))
                return (
                  <React.Fragment key={`nav-link-${i}-header-${link.name}`}>
                    <LoggedUserNavigationItem
                      helper={() => toggleDrawer(false)}
                      i={i}
                      link={link}
                      showName={false}
                    />
                  </React.Fragment>
                );
            })}
            <DrawerNavigation open={open} toggleDrawer={toggleDrawer}>
              <div className="flex relative flex-1 h-full flex-col justify-start items-center gap-6 uppercase text-md md:text-base">
                <MainNavigation
                  links={navigationLinkOptions.top}
                  helper={() => toggleDrawer(false)}
                />
                <Link
                  to={"/get-in-touch"}
                  className="absolute bottom-2 flex flex-row justify-center items-center cursor-pointer uppercase h-[35px] sm:w-[170px] rounded-[30px] bg-[#EBBD33] text-[#013338] whitespace-nowrap px-6 hover:border hover:border-[#013338] hover:bg-[white] transition-all duration-300 ease-in-out text-xs sm:text-sm"
                >
                  Get In Touch
                </Link>
              </div>
            </DrawerNavigation>
          </div>
        </div>
      </XSpace>
    </header>
  );
};

const FooterSection = () => {
  return (
    <footer className="w-full  h-auto bg-[#013338] flex flex-col lg:flex-row justify-center items-center  lg:py-1 py-10 md:py-4 text-xs sm:text-sm">
      <XSpace>
        <FooterNavigation>
          {/* <div className="">
          <WebsitelogoLink />
        </div>
        <div className="flex flex-1 font-[500] text-md flex-col lg:flex-row justify-center items-center gap-6 capitalize">
          <MainNavigation
            links={navigationLinkOptions.footer}
            helper={() => toggleDrawer(false)}
          />
        </div>
        <div className="text-white font-medium text-xs sm:text-sm">
          ConnectYou 2025
        </div> */}
          <Footer />
        </FooterNavigation>
      </XSpace>
    </footer>
  );
};

const Main = () => {
  return (
    <>
      <main className="w-full h-auto bg-white relative flex flex-col justify-start items-center">
        <Outlet />
      </main>
      <FooterSection />
    </>
  );
};

export { Footer, Navigation, FooterSection };
