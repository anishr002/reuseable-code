import { initializeApp } from "firebase/app";
import { getMessaging } from "firebase/messaging";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

let firebase_apiKey = import.meta.env.VITE_firebase_apiKey;
let firebase_authDomain = import.meta.env.VITE_firebase_authDomain;
let firebase_projectId = import.meta.env.VITE_firebase_projectId;
let firebase_storageBucket = import.meta.env.VITE_firebase_storageBucket;
let firebase_messagingSenderId = import.meta.env.VITE_firebase_messagingSenderId;
let firebase_appId = import.meta.env.VITE_firebase_appId;
let firebase_measurementId = import.meta.env.VITE_firebase_measurementId;

// Initialize the Firebase app in the service worker
const firebaseConfig = {
    apiKey: firebase_apiKey,
    authDomain: firebase_authDomain,
    projectId: firebase_projectId,
    storageBucket: firebase_storageBucket,
    messagingSenderId: firebase_messagingSenderId,
    appId: firebase_appId,
    measurementId: firebase_measurementId,
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const messaging = getMessaging(app);

export default messaging