import { lazy, StrictMode, Suspense } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import "./styles/fonts.css";
import store from "./lib/store.ts";
import { Provider } from "react-redux";
import LoadingElement from "./components/UI/LoadingElement.tsx";
import Image from "./components/UI/Image.tsx";
import Logo from "/loginLogo.png";

const App = lazy(() => {
  import("./components/UI/LoadingElement.tsx");
  const page = import("./App.tsx");
  return page;
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("../firebase-messaging-sw.js")
    .then((registration) => {
      // Listen for updates to the Service Worker
      registration.onupdatefound = () => {
        const installingWorker = registration.installing;
        if (installingWorker) {
          installingWorker.onstatechange = () => {
            if (installingWorker.state === "installed") {
              if (navigator.serviceWorker.controller) {
                // New content is available; reload the page
                console.log("New Content Found");
                // window.location.reload();
              }
            }
          };
        }
      };
    })
    .catch((error) => {
      console.error("Service Worker registration failed:", error);
    });
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    console.log("Controller has been changed. Reloading page now...");
    // window.location.reload();
  });
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Provider store={store}>
      <Suspense
        fallback={
          <div className="w-full h-screen flex items-center justify-center">
            <LoadingElement
              variant="dynamic"
              style={{
                background: "white",
                // display:"none"
              }}
            >
              <div className="w-full h-fit hidden flex-col justify-center items-center">
                <Image
                  src={Logo}
                  alt="Logo"
                  className="object-contain"
                  height={200}
                  width={300}
                  fallback={"Loading"}
                />
              </div>
            </LoadingElement>
          </div>
        }
      >
        <App />
      </Suspense>
    </Provider>
  </StrictMode>
);
