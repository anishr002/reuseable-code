/* eslint-disable @typescript-eslint/no-explicit-any */
import React, {
  lazy,
  ReactNode,
  Suspense,
  useCallback,
  useEffect,
} from "react";
import useNetworkAndServerStatus from "./util/useNetworkAndServerStatus";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Outlet,
} from "react-router-dom";
import useFetchCartData from "./components/hooks/useFetchCartData";
import InitializeSocket from "./lib/InitializeSocket";
import { SocketProvider } from "./contexts/SocketContext";
import { useDispatch, useSelector } from "react-redux";
import Logo from "/loginLogo.png";
import { ThemeProvider } from "@mui/material";
import theme from "./lib/MUI/Theme";
import ConnectYouNewWebLayout from "./Layouts/ConnectYouNewWebLayout";
import ConnectYouNewDashboardLayout from "./Layouts/ConnectYouNewDashboardLayout";
import HeadingContextProvider from "./providers/HeadingContextProvider";
import CookiePermissionModal from "./components/UI/CookiePermissionModal";
import "./App.css";
import LoadingElement from "./components/UI/LoadingElement";
import { onMessage } from "firebase/messaging";
import messaging from "./firebase/firebaseConfig";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import ActionsProviderInitializer from "./providers/ActionsProviderInitializer";
import { httpAPI } from "./util/AxiosAPI";
import backendURL from "./util/baseBackendURLConfig";
import { login, logout } from "./slices/Login";
import logoutLocal from "./util/logoutLocal";
import { NotificationProvider } from "./lib/Notify";
dayjs.extend(utc);
dayjs.extend(timezone);

const HomePage = lazy(() => import("./pages/home/HomePage"));
const PageNotFound = lazy(() => import("./pages/redirections/PageNotFound"));
const CoacheeRoutes = lazy(() => {
  const page = import("./routes/CoacheeRoutes");
  import("./components/wrappers/LoadGoogleScripts");
  return page;
});
const CoachRoutes = lazy(() => {
  const page = import("./routes/CoachRoutes");
  import("./components/wrappers/LoadGoogleScripts");
  return page;
});
const FindACoachRoutes = lazy(() => import("./routes/FindACoachRoutes"));
const PublicRoutes = lazy(() => import("./routes/PublicRoutes"));
const AccountVerification = lazy(
  () => import("./pages/account-verification/AccountVerification")
);
const Login = lazy(() => import("./pages/login/Login"));
const RecoverPassword = lazy(
  () => import("./pages/recover-password/RecoverPassword")
);
const SignUPCoach = lazy(
  () => import("./pages/registration-pages/SignUPCoach")
);
const SignUpCoachee = lazy(
  () => import("./pages/registration-pages/SignUpCoachee")
);
const NotificationDrawer = lazy(
  () => import("./components/UI/NotificationDrawer")
);
const FaqPage = lazy(() => import("./pages/FAQs/FaqPage"));
const Notifications = lazy(() => import("./pages/Notification/Notifications"));
interface IsCoachLoginProps {
  loginUserType: string | null;
}

const IsCoachLogin: React.FC<IsCoachLoginProps> = ({ loginUserType }) => {
  const auth = loginUserType === "c";
  return auth ? <Outlet /> : <Navigate to="/" />;
};
const IsUserLogin: React.FC<IsCoachLoginProps> = ({ loginUserType }) => {
  const auth = loginUserType === "u";
  return auth ? <Outlet /> : <Navigate to="/" />;
};

interface IsUserLoginSingle {
  loginUserType: string | null;
  children: React.ReactNode;
}

const IsUserLoginSingle: React.FC<IsUserLoginSingle> = ({
  loginUserType,
  children,
}) => {
  if (loginUserType !== "u") {
    return <Navigate to="/login" state={{ from: window.location.pathname }} />;
  }
  return <>{children}</>;
};

const App: React.FC = () => {
  const { NetworkAndServerStatus } = useNetworkAndServerStatus();
  useFetchCartData();
  const loginUserData = useSelector((state: any) => state.login.userdata);
  const loginData = loginUserData?.name && loginUserData;
  const loginUserType = loginData
    ? loginUserData?.userType === "coach"
      ? "c"
      : "u"
    : null;

  onMessage(messaging, (payload) => {
    if (payload?.notification) {
      const { title, body } = payload.notification;
      const notification = new Notification(title || "test", {
        body,
        icon: Logo,
      });
      notification.onclick = () => {
        notification.close();
        window.focus();
        window.location.href = `${payload?.data?.url}`;
      };
    }
  });

  const renderWithSuspense = (
    children: ReactNode,
    postion: "absolute" | "static" = "static",
    variant: "dynamic" | "full" = "full"
  ) => {
    return (
      <Suspense
        fallback={
          <>
            <LoadingElement
              variant={variant}
              style={{
                position: postion,
                inset: 0,
                top: 0,
                left: 0,
                background:
                  postion === "absolute" ? "#ecd17e07" : "transparent",
              }}
            />
          </>
        }
      >
        {children}
      </Suspense>
    );
  };

  useEffect(() => {
    const preloadAboutPage = async () => {
      await import("./routes/PublicRoutes");
    };
    preloadAboutPage();
  }, []);
  const dispatch = useDispatch();

  const fetchProfile = useCallback(async () => {
    try {
      const response = await httpAPI.get(
        `${backendURL}/${
          loginUserData?.userType === "coach" ? "coach" : "user"
        }/profile/profile/data`
      );
      if (response.status === 200) {
        const data = response.data.data;
        // console.log({ data });
        dispatch(login(data));
      } else {
        dispatch(logout());
        logoutLocal();
      }
    } catch (error: any) {
      const status = error?.response?.status;
      if ([400, 401].includes(status)) {
        dispatch(logout());
        logoutLocal();
      } else {
        console.error("Unhandled error fetching profile:", error);
      }
    }
  }, []);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  return (
    <BrowserRouter>
      <NotificationProvider>
        <ThemeProvider theme={theme}>
          <HeadingContextProvider>
            <ActionsProviderInitializer></ActionsProviderInitializer>
            <SocketProvider
              initialAuthToken={
                loginUserData?._id ? localStorage.getItem("authToken") : null
              }
            >
              {loginUserData?._id && <InitializeSocket />}
              <Routes>
                <Route path="/" element={<ConnectYouNewWebLayout />}>
                  <Route index element={<HomePage />} />
                  <Route path="*" element={<PublicRoutes />} />
                </Route>
                <Route path="/find-a-coach">
                  <Route index element={<Navigate to="list" replace />} />
                  <Route
                    path="*"
                    element={renderWithSuspense(
                      <FindACoachRoutes />,
                      "static",
                      "full"
                    )}
                  ></Route>
                </Route>
                <Route
                  path="/login"
                  element={renderWithSuspense(<Login />, "static", "full")}
                />
                <Route
                  path="/signup-coach"
                  element={renderWithSuspense(
                    <SignUPCoach />,
                    "static",
                    "full"
                  )}
                ></Route>
                <Route
                  path="/signup-coachee"
                  element={renderWithSuspense(
                    <SignUpCoachee />,
                    "static",
                    "full"
                  )}
                ></Route>
                <Route
                  path="/account-verification"
                  element={renderWithSuspense(
                    <AccountVerification />,
                    "static",
                    "full"
                  )}
                ></Route>
                <Route
                  path="/forgot-password/:userType"
                  element={renderWithSuspense(
                    <RecoverPassword />,
                    "static",
                    "full"
                  )}
                />
                <Route
                  path="/faqs"
                  element={renderWithSuspense(<FaqPage />, "static", "full")}
                />
                {/* coach Dashboard */}
                <Route element={<IsCoachLogin loginUserType={loginUserType} />}>
                  <Route path="/c" element={<ConnectYouNewDashboardLayout />}>
                    <Route
                      index
                      element={<Navigate to={"dashboard"} replace />}
                    ></Route>
                    <Route
                      path="notifications"
                      element={renderWithSuspense(
                        <Notifications type="coach" />
                      )}
                    />
                    <Route
                      path="*"
                      element={renderWithSuspense(
                        <CoachRoutes />,
                        "absolute",
                        "full"
                      )}
                    />
                  </Route>
                </Route>
                {/* user Dashboard */}
                <Route element={<IsUserLogin loginUserType={loginUserType} />}>
                  <Route path="/u" element={<ConnectYouNewDashboardLayout />}>
                    <Route
                      index
                      element={<Navigate to={"dashboard"} replace />}
                    ></Route>
                    <Route
                      path="notifications"
                      element={renderWithSuspense(
                        <Notifications type="user" />
                      )}
                    />
                    <Route
                      path="*"
                      element={renderWithSuspense(
                        <CoacheeRoutes />,
                        "absolute",
                        "full"
                      )}
                    />
                  </Route>
                </Route>
                <Route path="*" element={<PageNotFound />} />
              </Routes>
            </SocketProvider>
            <NotificationDrawer />
            <CookiePermissionModal />
            <NetworkAndServerStatus />
          </HeadingContextProvider>
        </ThemeProvider>
      </NotificationProvider>
    </BrowserRouter>
  );
};
export default App;
