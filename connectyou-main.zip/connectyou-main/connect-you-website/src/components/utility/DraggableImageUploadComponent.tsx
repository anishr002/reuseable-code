import EditIcon from "@mui/icons-material/Edit";
import FilePresentIcon from "@mui/icons-material/FilePresent";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import ImageIcon from "@mui/icons-material/Image";
import { Avatar, IconButton, Tooltip } from "@mui/material";
import React, {
  ReactNode,
  useState,
  useRef,
  DragEvent,
  useEffect,
} from "react";
import { useFormContext } from "react-hook-form";
import backendURL from "../../util/AxiosAPI";

interface DraggableImageUploadComponentProps {
  name?: string;
  icon?: "File" | "Image" | "PdfFile";
  variant?: "Rectangle" | "Round";
  fileUrl?: string | null;
  children: ReactNode;
  labelName: string;
  type?: "image" | "pdf";
  onError?: (error: string) => void;
  formName: string;
  def?: string;
}
/**
 * @param type can be image or pdf file 
 * 
 * @param children : hidden input element for form handling
 * 
 * @param labelName : to show on the upload component
 * 
 * @param icon : to show the icon when nothing selected
 * 
 * @param formName : name registered in form values
 * 
 * @param def : default value can be a https, or string or anything
 * 
 * @param name : to render the title of the component
 * 
 * @param variant : can be rounded or rect for visual rep
 * 
 * @description Implementation        <div className="col-span-1 w-full row-span-5 flex flex-col items-center justify-center">
                               <label
                                 htmlFor="coach-profile-picture-upload"
                                 className={`flex flex-col gap-4 justify-center items-center w-full  relative p-2 rounded-[5px] border border-dashed ${
                                   methods.formState.errors.coach?.image
                                     ? "border-[red]"
                                     : "border-[#3aa7a3]"
                                 }`}
                               >
                                 <div className="cursor-pointer w-full flex items-center justify-center text-[#3aa7a3] underline underline-offset-4 font-medium">
                                   Select from computer or drop image here
                                 </div>
                                 <div className="w-full flex flex-col gap-1 justify-start">
                                   <span className="text-[#3aa7a3] font-medium text-sm">
                                     Instructions for uploading proile :
                                   </span>
                                   <span className="text-red-700 font-medium text-sm">
                                     **Only JPG/JPEG/PNG/WEBP image files are
                                     allowed
                                   </span>
                                   <span className="text-red-700 font-medium text-sm">
                                     **Allowed Image files size limit is 5MB
                                   </span>
                                 </div>
                                 <DraggableImageUploadComponent
                                   type="image"
                                   children={
                                     <input
                                       accept="image/*"
                                       style={{ display: "none" }}
                                       id="coach-profile-picture-upload"
                                       type="file"
                                       {...methods.register("coach.image", {
                                         validate: (files) => {
                                           const file = files?.[0];
                                           if (file && file instanceof File) {
                                             const allowedTypes = [
                                               "image/jpeg",
                                               "image/jpg",
                                               "image/png",
                                               "image/gif",
                                               "image/webp",
                                             ];
                                             if (
                                               !allowedTypes.includes(file.type)
                                             ) {
                                               return "Only JPEG, PNG, GIF, and WEBP images are allowed.";
                                             }
                                             const maxSize = 5 * 1024 * 1024;
                                             if (file.size > maxSize) {
                                               return "Image file size must be less than 5MB.";
                                             }
                                           }
                                           return true;
                                         },
                                       })}
                                     />
                                   }
                                   labelName="coach-profile-picture-upload"
                                   icon="Image"
                                   formName="coach.image"
                                   def={coachData?.image}
                                   name="Upload Image"
                                   variant="Rectangle"
                                 />
                               </label>
                               {methods.formState.errors.coach?.image && (
                                 <span className="text-sm font-medium pt-4 w-full text-left text-red-700">
                                   {methods.formState.errors.coach?.image?.message?.toString()}
                                 </span>
                               )}
                             </div>
 */

const DraggableImageUploadComponent: React.FC<
  DraggableImageUploadComponentProps
> = ({
  name = "Select",
  icon = "Image",
  fileUrl,
  children,
  labelName,
  variant = "Round",
  type = "image",
  onError,
  formName,
  def,
}) => {
  const [imageError, setImageError] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const labelRef = useRef<HTMLLabelElement>(null);

  // Check if drag and drop is supported
  const isDragDropSupported = () => {
    const div = document.createElement("div");
    return (
      ("draggable" in div || ("ondragstart" in div && "ondrop" in div)) &&
      "FormData" in window &&
      "FileReader" in window
    );
  };

  // Handle drag events with error handling
  const handleDragEnter = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragDropSupported()) return;
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragDropSupported()) return;
    if (!isDragging) {
      setIsDragging(true);
    }
  };

  const handleDrop = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (!isDragDropSupported()) {
      onError?.("Drag and drop is not supported in this browser");
      return;
    }

    try {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        // Check file type constraints
        const file = e.dataTransfer.files[0]; // Take only the first file

        // Validate file type
        if (type === "image" && !file.type.startsWith("image/")) {
          onError?.("Please drop an image file");
          return;
        }

        if (type === "pdf" && file.type !== "application/pdf") {
          onError?.("Please drop a PDF file");
          return;
        }

        // Find the associated input element
        const input = document.getElementById(labelName) as HTMLInputElement;
        if (input) {
          // Set the files to the input element
          try {
            // Modern browsers
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            input.files = dataTransfer.files;
          } catch (error) {
            // Fallback for browsers that don't support DataTransfer
            console.error("DataTransfer not supported", error);
            onError?.(
              "Your browser doesn't fully support drag and drop, please use the file selector instead"
            );
            return;
          }

          // Trigger the change event
          try {
            const event = new Event("change", { bubbles: true });
            input.dispatchEvent(event);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
          } catch (error: any) {
            // Fallback for older browsers
            console.log(error);
            const event = document.createEvent("HTMLEvents");
            event.initEvent("change", true, false);
            input.dispatchEvent(event);
          }
        } else {
          onError?.(`Input element with id "${labelName}" not found`);
        }
      }
    } catch (error) {
      console.error("Error handling file drop", error);
      onError?.("Error processing dropped file");
    }
  };

  // Common drag props - only apply if supported
  const dragProps = isDragDropSupported()
    ? {
        onDragEnter: handleDragEnter,
        onDragLeave: handleDragLeave,
        onDragOver: handleDragOver,
        onDrop: handleDrop,
        ref: labelRef,
      }
    : { ref: labelRef };

  // Drag indicator styles
  const getDragStyle = () => {
    return isDragging
      ? { boxShadow: "0 0 0 2px #eabd32", transition: "all 0.2s ease-in-out" }
      : {};
  };
  const { watch } = useFormContext();

  const userImage = watch(formName);
  const [imagePreview, setImagePreview] = React.useState<string | undefined>(
    undefined
  );
  useEffect(() => {
    const imageUrl =
      def && typeof def === "string"
        ? `${backendURL}/usersProfile/${def}`
        : undefined;
    setImagePreview(imageUrl);
  }, [def]);

  useEffect(() => {
    if (userImage && userImage instanceof FileList && userImage?.length > 0) {
      const file = userImage[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, [userImage]);

  return (
    <>
      {children}
      <div className="hidden">
        <Avatar
          src={imagePreview}
          alt="image-preview"
          onError={() => setImageError(true)}
        />
      </div>

      {variant === "Round" && (
        <label
          htmlFor={labelName}
          className={`flex justify-center items-center w-40 h-40 rounded-full relative overflow-hidden cursor-pointer ${
            isDragging ? "bg-gray-300" : ""
          }`}
          style={getDragStyle()}
          {...dragProps}
        >
          {!imagePreview || imageError ? (
            <div className="w-full h-full rounded-lg bg-gray-400  flex flex-col justify-center items-center">
              <span>
                {icon === "File" && (
                  <FilePresentIcon
                    sx={{ color: "white", fontSize: "2.5rem" }}
                  />
                )}
                {icon === "Image" && (
                  <ImageIcon sx={{ color: "white", fontSize: "2.5rem" }} />
                )}
                {icon === "PdfFile" && (
                  <PictureAsPdfIcon
                    sx={{ color: "white", fontSize: "2.5rem" }}
                  />
                )}
              </span>
              <span className="font-semibold text-xs text-white">{name}</span>
              {isDragging && isDragDropSupported() && (
                <span className="text-xs text-white mt-1">Drop file here</span>
              )}
            </div>
          ) : (
            <Avatar
              src={imagePreview}
              alt="User"
              sx={{
                width: { sm: 140, md: 150, lg: 160, xl: 200 },
                height: { sm: 140, md: 150, lg: 160, xl: 200 },
              }}
            />
          )}

          {imagePreview && !imageError ? (
            <div className="absolute bottom-0 right-1/4 rounded-full w-8 h-8 bg-slate-50 flex justify-center items-center">
              <Tooltip title="Edit">
                <IconButton
                  color="primary"
                  aria-label="upload-picture"
                  component="span"
                >
                  <EditIcon sx={{ color: "#eabd32", fontSize: "1.5rem" }} />
                </IconButton>
              </Tooltip>
            </div>
          ) : (
            ""
          )}
        </label>
      )}

      {variant === "Rectangle" && (
        <>
          {type === "image" ? (
            <>
              <label
                htmlFor={labelName}
                className={`flex justify-center items-center w-full max-h-[400px] rounded-md relative overflow-hidden cursor-pointer ${
                  isDragging ? "bg-gray-300" : ""
                }`}
                style={getDragStyle()}
                {...dragProps}
              >
                {!imagePreview || imageError ? (
                  <div className="w-full  rounded-lg min-h-24 py-12 bg-gray-400  flex flex-col justify-center items-center">
                    <span>
                      {icon === "File" && (
                        <FilePresentIcon
                          sx={{ color: "white", fontSize: "2.5rem" }}
                        />
                      )}
                      {icon === "Image" && (
                        <ImageIcon
                          sx={{ color: "white", fontSize: "2.5rem" }}
                        />
                      )}
                      {icon === "PdfFile" && (
                        <PictureAsPdfIcon
                          sx={{ color: "white", fontSize: "2.5rem" }}
                        />
                      )}
                    </span>
                    <span className="font-semibold text-xs text-white">
                      {name}
                    </span>
                    {isDragging && isDragDropSupported() && (
                      <span className="text-xs text-white mt-1">
                        Drop file here
                      </span>
                    )}
                  </div>
                ) : (
                  <img
                    src={imagePreview}
                    alt="User"
                    className=" w-full max-w-full flex justify-center items-center object-contain"
                  />
                )}

                {imagePreview && !imageError ? (
                  <div className="absolute top-4 right-4 rounded-full w-8 h-8 bg-slate-50 flex justify-center items-center">
                    <Tooltip title="Edit">
                      <IconButton
                        color="primary"
                        aria-label="upload-picture"
                        component="span"
                      >
                        <EditIcon
                          sx={{ color: "#eabd32", fontSize: "1.5rem" }}
                        />
                      </IconButton>
                    </Tooltip>
                  </div>
                ) : (
                  ""
                )}
              </label>
            </>
          ) : (
            <>
              <label
                htmlFor={labelName}
                className={`flex justify-center items-center w-full rounded-md relative overflow-hidden cursor-pointer ${
                  isDragging ? "bg-gray-300" : ""
                }`}
                style={getDragStyle()}
                {...dragProps}
              >
                {!fileUrl ? (
                  <div className="w-full  rounded-lg min-h-24 py-12 bg-gray-400  flex flex-col justify-center items-center">
                    <span>
                      {icon === "File" && (
                        <FilePresentIcon
                          sx={{ color: "white", fontSize: "2.5rem" }}
                        />
                      )}
                      {icon === "Image" && (
                        <ImageIcon
                          sx={{ color: "white", fontSize: "2.5rem" }}
                        />
                      )}
                      {icon === "PdfFile" && (
                        <PictureAsPdfIcon
                          sx={{ color: "white", fontSize: "2.5rem" }}
                        />
                      )}
                    </span>
                    <span className="font-semibold text-xs text-white">
                      {name}
                    </span>
                    {isDragging && isDragDropSupported() && (
                      <span className="text-xs text-white mt-1">
                        Drop file here
                      </span>
                    )}
                  </div>
                ) : (
                  <iframe
                    src={fileUrl}
                    title="PDF Preview"
                    style={{
                      width: "100%",
                      height: "300px",
                      border: "1px solid #ccc",
                      borderRadius: "5px",
                    }}
                  />
                )}

                {fileUrl ? (
                  <div className="absolute bottom-8 right-8 rounded-full w-8 h-8 bg-[#eabd32] flex justify-center items-center">
                    <Tooltip title="Edit">
                      <IconButton
                        color="primary"
                        aria-label="upload-picture"
                        component="span"
                      >
                        <EditIcon sx={{ color: "white", fontSize: "1.5rem" }} />
                      </IconButton>
                    </Tooltip>
                  </div>
                ) : (
                  ""
                )}
              </label>
            </>
          )}
        </>
      )}
    </>
  );
};

export default DraggableImageUploadComponent;
