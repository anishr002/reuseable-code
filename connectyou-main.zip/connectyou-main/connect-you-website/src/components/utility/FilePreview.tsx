/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import * as XLSX from "xlsx";
import { YellowButton } from "../buttons/ThemeButtons";
import FileDownloadIcon from "@mui/icons-material/FileDownload";

const FilePreview = ({
  file,
  fileUrl,
  showDownloadButton = true,
}: {
  file: string;
  fileUrl: string;
  showDownloadButton?: boolean;
}) => {
  const fileExtension = file.split(".").pop()?.toLowerCase();
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleExcelPreview = async () => {
    if (isLoading) return; // Prevent multiple calls
    setIsLoading(true);

    try {
      const response = await fetch(fileUrl);
      const blob = await response.blob();

      // Use a Promise-based approach for FileReader
      const readFileAsArrayBuffer = (fileBlob: Blob) => {
        return new Promise<ArrayBuffer>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            if (e.target?.result) {
              resolve(e.target.result as ArrayBuffer);
            } else {
              reject(new Error("No data from reader"));
            }
          };
          reader.onerror = (e) => reject(e);
          reader.readAsArrayBuffer(fileBlob);
        });
      };

      const data = await readFileAsArrayBuffer(blob);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const rows = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1 });

      // Create a new HTML document with just the table
      const newWindow = window.open('', '_blank');
      if (!newWindow) {
        alert('Pop-up blocked. Please allow pop-ups for this site to view the Excel data.');
        setIsLoading(false);
        return;
      }

      // Create HTML content with styling
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Excel Preview: ${file}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              margin: 20px;
            }
            h2 {
              color: #333;
            }
            table {
              border-collapse: collapse;
              width: 100%;
              max-width: 100%;
              margin-top: 20px;
            }
            th {
              background-color: #f4f4f4;
              font-weight: bold;
              text-align: left;
              padding: 10px;
              border: 1px solid #ddd;
              white-space: nowrap;
            }
            td {
              padding: 8px 10px;
              border: 1px solid #ddd;
              text-overflow: ellipsis;
              max-width: 300px;
              overflow: hidden;
              white-space: nowrap;
            }
            tr:nth-child(even) {
              background-color: #f9f9f9;
            }
            tr:hover {
              background-color: #f1f1f1;
            }
          </style>
        </head>
        <body>
          <h2>Excel Preview: ${file}</h2>
          ${rows.length > 0 ?
          `<table>
              <thead>
                <tr>
                  ${rows[0]?.map((header: any) => `<th>${header || ""}</th>`).join("")}
                </tr>
              </thead>
              <tbody>
                ${rows.slice(1).map((row) => `
                  <tr>
                    ${row.map((cell: any) => `<td title="${cell || ""}">${cell || "-"}</td>`).join("")}
                  </tr>
                `).join("")}
              </tbody>
            </table>` :
          '<p>No data available or empty Excel file</p>'
        }
        </body>
        </html>
      `;

      newWindow.document.write(htmlContent);
      newWindow.document.close();

    } catch (error) {
      console.error("Failed to preview Excel file:", error);
      alert("Failed to preview Excel file. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (fileExtension === "pdf") {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "10px",
          width: "100%",
        }}
        className="style-scroll style-scroll-thin"
      >
        <iframe
          src={fileUrl}
          title="PDF Preview"
          className="style-scroll style-scroll-thin"
          style={{
            width: "100%",
            height: "500px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        {showDownloadButton && <DownloadButton fileUrl={fileUrl} />}
      </div>
    );
  }

  if (fileExtension === "xls" || fileExtension === "xlsx") {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "10px",
          width: "100%",
          overflow: "hidden",
        }}
        className="style-scroll style-scroll-thin"
      >
        <div className="flex flex-col items-center justify-between w-full p-4 rounded-2xl bg-[#3aa7a334]">
          <div className="flex flex-col items-center gap-3 text-[#013338] text-lg font-medium">
            <span role="img" aria-label="Excel File" className="text-2xl">
              📊
            </span>
            <span className="break-all">{file}</span>
          </div>

          <button
            onClick={handleExcelPreview}
            disabled={isLoading}
            className="mt-4 w-48 py-2 px-4 bg-[#3aa7a3] text-white rounded-lg hover:bg-[#32908d] transition-all duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {isLoading ? "Loading..." : "Preview Excel"}
          </button>
        </div>

        <div className="flex w-full items-center justify-center mt-4">
          {showDownloadButton && <DownloadButton fileUrl={fileUrl} />}
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "10px",
      }}
    >
      <span>Unsupported file type</span>
    </div>
  );
};

const DownloadButton = ({ fileUrl }: { fileUrl: string }) => {
  const handleDownload = async () => {
    try {
      const response = await fetch(fileUrl);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.setAttribute(
        "download",
        fileUrl.split("/").pop() || "downloaded-file"
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  return (
    <button
      onClick={handleDownload}
      className="flex items-center gap-2 text-white hover:text-[#ebbe34] transition"
    >
      <YellowButton text="Download" />
      <FileDownloadIcon sx={{ color: "white", fontSize: "1.5rem" }} />
    </button>
  );
};

export { DownloadButton };
export default FilePreview;