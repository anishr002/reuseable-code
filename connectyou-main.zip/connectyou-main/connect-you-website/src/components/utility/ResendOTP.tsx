import {
  forwardRef,
  ReactNode,
  useImperativeHandle,
  useEffect,
  useState,
  useCallback,
} from "react";
import { CountDownTimer } from "./CountDownTimer";
import { CircularProgress } from "@mui/material";
import moment from "moment";

export interface ResendOTPState {
  timestamp: string;
  resendCount: number;
  timeForNextResend: number;
}

const ResendOTP = forwardRef(
  (
    {
      children,
      localStorageKey = "default",
      loading,
    }: {
      children?: ReactNode;
      localStorageKey?: string;
      loading?: boolean;
    },
    ref
  ) => {
    const [resendOTPCount, setResendOtpCount] = useState<number>(0);
    const [timeForNextResend, setTimeForNextResend] = useState<number>(0);

    useEffect(() => {
      const saved = localStorage.getItem(localStorageKey);
      if (saved) {
        try {
          const { timestamp, resendCount, timeForNextResend } = JSON.parse(
            saved
          ) as ResendOTPState;
          const expiresAt = moment(timestamp).add(timeForNextResend, "seconds");
          const secondsLeft = expiresAt.diff(moment(), "seconds");

          if (secondsLeft > 0) {
            setResendOtpCount(resendCount || 1);
            setTimeForNextResend(secondsLeft);
          } else {
            updateLocalStorage(resendCount || 1, 0);
          }
        } catch (error) {
          console.error("Error parsing stored OTP state:", error);
          updateLocalStorage(1, 0);
        }
      }
    }, [localStorageKey]);

    const updateLocalStorage = useCallback(
      (count: number, waitTime: number) => {
        const data: ResendOTPState = {
          timestamp: moment().toISOString(),
          resendCount: count,
          timeForNextResend: waitTime,
        };
        localStorage.setItem(localStorageKey, JSON.stringify(data));
        setResendOtpCount(count);
        setTimeForNextResend(waitTime);
      },
      [localStorageKey]
    );

    const handleTime = (remainingTime: number) => {
      setTimeForNextResend(remainingTime);
      if (remainingTime === 0) {
        updateLocalStorage(resendOTPCount, 0);
      }
    };

    const handleResend = useCallback(() => {
      if (resendOTPCount > 6 || timeForNextResend > 0) return;
      const newCount = resendOTPCount + 1;
      let newWaitTime = 30 + 30 * (newCount - 1); // 30s, 60s, 90s, etc.
      if (newCount === 6) {
        newWaitTime = 3600; // 1 hour in seconds
      }
      updateLocalStorage(newCount, newWaitTime);
    }, [resendOTPCount, timeForNextResend, updateLocalStorage, localStorageKey]);
    useImperativeHandle(ref, () => ({
      onClickResend: handleResend,
    }));

    return (
      <>
        {timeForNextResend === 0 ? (
          <div className="">
            {resendOTPCount > 6 ? (
              <>Too many requests. Please try again in a moment.</>
            ) : loading ? (
              <CircularProgress size={15} sx={{ color: "#013338" }} />
            ) : (
              <>
                <span className="text-[#013338]">Didn't receive an OTP? </span>
                {children}
              </>
            )}
          </div>
        ) : (
          <>
            Resend OTP in{" "}
            <CountDownTimer time={timeForNextResend} handleTime={handleTime} />
          </>
        )}
      </>
    );
  }
);

export default ResendOTP;
