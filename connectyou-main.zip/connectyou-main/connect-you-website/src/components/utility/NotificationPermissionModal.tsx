/* eslint-disable @typescript-eslint/no-explicit-any */
import { getToken } from "firebase/messaging";
import messaging from "../../firebase/firebaseConfig";
import Logo from "/loginLogo.png";
import { Box, Button, Modal, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useSelector } from "react-redux";
import { useNotify } from "../../lib/Notify";
import ModalCloseButton from "../../components/buttons/ModalCloseButton";

const NotificationPermissionModal = ({
  userType,
}: {
  userType: "coach" | "user";
}) => {
  const loginUserData = useSelector((state: any) => state.login.userdata);
  const loginData = loginUserData?.name && loginUserData;
  const loginUserType = loginData
    ? loginUserData.userType == "coachee"
      ? "u"
      : "c"
    : null;
  const firebase_vapidKey = import.meta.env.VITE_firebase_vapidKey;
  const [OpenNotifyAccess, setOpenNotifyAccess] = useState(false);
  const [open, setOpenPermissionModal] = useState(false);
  const onClose = () => setOpenPermissionModal((prev) => !prev);
  const { notifyMe } = useNotify();

  useEffect(() => {
    if ("Notification" in window) {
      if (Notification.permission === "default") {
        setOpenPermissionModal(true);
      }
      if (Notification.permission === "granted") {
        setOpenNotifyAccess(true);
      }
    } else {
      console.warn("Notification API is not supported by this browser.");
    }
  }, []);

  useEffect(() => {
    async function requestPermission() {
      if (!("Notification" in window)) {
        console.warn("Push Notification is not supported.");
        return;
      }
      Notification.requestPermission()
        .then(async (permission) => {
          if (permission === "granted") {
            const registration = await navigator.serviceWorker.ready;
            let subscription = await registration.pushManager.getSubscription();
            if (!subscription) {
              // If no subscription exists, create a new one
              subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: firebase_vapidKey,
              });
            }
            const uniqueIdentifier = subscription.endpoint;
            const token = await getToken(messaging, {
              vapidKey: firebase_vapidKey,
            });

            try {
              await localStorage.setItem("FCM-Token", token);
              await localStorage.setItem("FCM-deviceId", uniqueIdentifier);
              await httpAPI.post(
                `${backendURL}/${userType}/profile/token-add`,
                {
                  deviceId: uniqueIdentifier,
                  token,
                }
              );
            } catch (error: any) {
              console.log({ error });
              notifyMe({ message: "Something went wrong", severity: "error" });
            }
          }
        })
        .catch((error) => {
          console.log("firebase-notification", error);
        });
    }
    if (loginUserType && OpenNotifyAccess) {
      requestPermission();
    }
  }, [OpenNotifyAccess, loginUserType, firebase_vapidKey]);

  return (
    <>
      <Modal
        open={open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
        onClose={() => onClose()}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,
            borderRadius: 1,
          }}
        >
          <ModalCloseButton onClick={() => onClose()} />
          <Box
            sx={{
              height: 320,
              width: "100%",
              display: "flex",
              justifyContent: "start",
              alignItems: "start",
              flexDirection: "column",
              p: 2,
              gap: 2,
            }}
          >
            <img
              src={Logo}
              alt="Website-Logo"
              className="w-36 h-36 object-contain mx-auto"
            />
            <Typography
              variant="h6"
              sx={{
                fontWeight: 600,
                width: "100%",
                textAlign: "center",
                color: "#013338",
                fontFamily: "Quicksand",
              }}
            >
              Turn On Notifications
            </Typography>
            <Typography
              variant="body2"
              sx={{
                fontWeight: 500,
                width: "100%",
                textAlign: "center",
                color: "black",
                fontFamily: "Quicksand",
                px: 1,
              }}
            >
              Get Instant Notifications on your device when someone interacts
              with your profile
            </Typography>
            <Button
              onClick={() => {
                onClose();
                setOpenNotifyAccess(true);
              }}
              variant="outlined"
              sx={{
                color: "white",
                mx: "auto",
                backgroundColor: "#EBBE34",
                borderColor: "#EBBE34",
                borderRadius: "20px",
                fontFamily: "Quicksand",
                "&:hover": {
                  borderColor: "#EBBE34",
                  backgroundColor: "white",
                  color: "#EBBE34",
                },
              }}
            >
              Turn On
            </Button>
            <Button
              onClick={() => onClose()}
              sx={{
                color: "gray",
                mx: "auto",
                p: 0,
                fontSize: "0.775rem",
                "&:hover": {
                  textDecoration: "underline",
                },
              }}
            >
              Ask Me Later
            </Button>
          </Box>
        </Box>
      </Modal>
    </>
  );
};

export default NotificationPermissionModal;
