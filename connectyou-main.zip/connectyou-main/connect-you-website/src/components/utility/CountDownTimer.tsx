import moment from "moment-timezone";
import React, { useEffect, useState } from "react";

export const CountDownTimer = React.memo(
  ({ time, handleTime }: { time: number; handleTime: (x: number) => void }) => {
    const [timeForNextResend, setTimeForNextResend] = useState<number>(time);
    useEffect(() => {
      setTimeForNextResend(time);
    }, [time]);
    useEffect(() => {
      let interval: NodeJS.Timeout;
      if (timeForNextResend > 0) {
        interval = setInterval(() => {
          setTimeForNextResend((prev) => {
            if (prev <= 1) {
              clearInterval(interval!);
              return 0; // Stop timer at 0
            }
            return prev - 1; // Decrement timer
          });
        }, 1000);
      } else if (timeForNextResend === 0) {
        handleTime(0);
      }
      return () => {
        if (interval) clearInterval(interval); // Ensure cleanup
      };
    }, [timeForNextResend, handleTime]); // `handleTime` as dependency to avoid stale closure
    const formattedTime = moment.utc(timeForNextResend * 1000).format("mm:ss");

    return <>{formattedTime}</>;
  }
);
