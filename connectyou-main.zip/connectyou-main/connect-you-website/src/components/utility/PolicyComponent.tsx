import { Box, Typography } from "@mui/material";

const PolicyComponent = ({
  _id,
  data,
}: {
  _id: string;
  data: string;
}) => {
  const renderSavedContent = (savedContent: string | TrustedHTML) => {
    return (
      <div
        className="custom-content-container"
        dangerouslySetInnerHTML={{
          __html: savedContent,
        }}
      />
    );
  };

  return (
    <>
      <Box
        component={"ul"}
        key={_id}
        sx={{
          display: "flex",
          flexDirection: "column",
          position: "relative",
          padding: 1,
        }}
      >
        <Typography variant="body1" fontWeight={400} sx={{ px: 1, py:0.5 }}>
          {renderSavedContent(data)}
        </Typography>
      </Box>
    </>
  );
};

export default PolicyComponent;
