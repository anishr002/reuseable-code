/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useRef, useEffect, useCallback } from "react";

interface MessageDateTrackerProps {
  containerRef: React.RefObject<HTMLDivElement | null>;
  dateRefs: React.RefObject<{ [key: string]: HTMLDivElement | null }>;
  messageList?: any[];
  selectedUserId?: string;
  className?: string;
  style?: React.CSSProperties;
}

const MessageDateTracker: React.FC<MessageDateTrackerProps> = ({
  containerRef,
  dateRefs,
  messageList = [],
  selectedUserId,
  className = "",
  style = {},
}) => {
  const [currentDateLabel, setCurrentDateLabel] = useState<string>("");
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Function to determine most visible date element with priority to bottom messages
  const updateVisibleDate = useCallback(() => {
    if (
      !containerRef.current ||
      Object.keys(dateRefs.current || {}).length === 0
    ) {
      return;
    }

    const containerRect = containerRef.current.getBoundingClientRect();
    const visibleDateRefs = Object.entries(dateRefs.current || {})
      .map(([dateKey, ref]) => {
        if (!ref)
          return { dateKey, visibleArea: 0, topPosition: 0, bottomPosition: 0 };

        const rect = ref.getBoundingClientRect();
        // Calculate overlap with container
        const top = Math.max(rect.top, containerRect.top);
        const bottom = Math.min(rect.bottom, containerRect.bottom);
        const visibleHeight = Math.max(0, bottom - top);

        // Calculate percentage of element visible
        const visibleArea = (visibleHeight / rect.height) * 100;

        // Make sure we're using the actual date value from the element's data attribute
        const elementDateKey = ref.getAttribute("data-date-key") || dateKey;

        return {
          dateKey: elementDateKey,
          visibleArea,
          topPosition: rect.top,
          bottomPosition: rect.bottom,
          distanceFromContainerBottom: Math.abs(
            containerRect.bottom - rect.bottom
          ),
        };
      })
      .filter((item) => item.visibleArea > 0) // Only consider visible elements
      .sort((a, b) => {
        // Priority is given to elements closer to the bottom of the container
        return (
          (a.distanceFromContainerBottom || 0) -
          (b.distanceFromContainerBottom || 0)
        );
      });

    if (visibleDateRefs.length > 0) {
      const newDateKey = visibleDateRefs[0].dateKey;
      if (newDateKey !== currentDateLabel) {
        setCurrentDateLabel(newDateKey);
      }
    }
  }, []);

  // Set up initial observation
  useEffect(() => {
    if (
      !containerRef.current ||
      Object.keys(dateRefs.current || {}).length === 0
    ) {
      return;
    }

    // Initial update on component mount
    requestAnimationFrame(updateVisibleDate);

    // Set up intersection observer with a more stable configuration
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          // Debounce the updates to avoid rapid changes
          if (debounceTimerRef.current) {
            clearTimeout(debounceTimerRef.current);
          }
          debounceTimerRef.current = setTimeout(updateVisibleDate, 150);
        }
      },
      {
        root: containerRef.current,
        threshold: [0.1, 0.5],
        rootMargin: "0px 0px 0px 0px", // Neutral margin to observe entire container
      }
    );

    // Observe all date refs
    Object.values(dateRefs.current || {}).forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      observer.disconnect();
    };
  }, [messageList, selectedUserId, updateVisibleDate, dateRefs, containerRef]);

  // Handle scroll events with debouncing
  useEffect(() => {
    const scrollContainer = containerRef.current;
    if (!scrollContainer) return;

    const handleScroll = () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }

      // Use a longer debounce for scrolling to prevent flickering
      debounceTimerRef.current = setTimeout(updateVisibleDate, 200);
    };

    scrollContainer.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      scrollContainer.removeEventListener("scroll", handleScroll);
    };
  }, [containerRef, updateVisibleDate]);

  // Reset when user changes
  useEffect(() => {
    return () => {
      dateRefs.current = {};
      setCurrentDateLabel("");
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [selectedUserId, dateRefs]);

  if (!currentDateLabel) {
    return null;
  }
  return (
    <div
      className={`absolute top-[80%] left-1/2 mt-10 bg-white z-10 text-xs text-[#013338] font-semibold rounded-[10px] px-2 py-1 transform -translate-x-1/2 ${className}`}
      style={style}
    >
      {currentDateLabel}
    </div>
  );
};

export default MessageDateTracker;
