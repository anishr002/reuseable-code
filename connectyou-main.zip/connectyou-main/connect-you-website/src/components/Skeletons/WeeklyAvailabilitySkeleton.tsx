import {
  Skeleton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Box,
} from "@mui/material";

const WeeklyAvailabilitySkeleton = () => {
  const rows = Array.from({ length: 7 }); // One for each day of the week

  return (
    <Box className="w-full overflow-auto style-scroll style-scroll-thin">
      <Box className="w-full min-w-fit">
        <Table className="min-w-full">
          <TableHead>
            <TableRow>
              {["Day", "Unavailable", "Full Day", "From", "Time Slots"].map(
                (_, i) => (
                  <TableCell
                    key={i}
                    className="px-4 py-1 text-left text-sm font-semibold"
                  >
                    <Skeleton width={80} />
                  </TableCell>
                )
              )}
            </TableRow>
          </TableHead>

          <TableBody>
            {rows.map((_, rowIndex) => (
              <TableRow key={rowIndex} className="bg-[#f5f5f5]">
                {/* Day */}
                <TableCell className="px-4 py-1">
                  <Skeleton width={60} height={20} />
                </TableCell>

                {/* Unavailable */}
                <TableCell className="px-4 py-1">
                  <Skeleton variant="circular" width={20} height={20} />
                </TableCell>

                {/* All Day */}
                <TableCell className="px-4 py-1">
                  <Skeleton variant="circular" width={20} height={20} />
                </TableCell>

                {/* From */}
                <TableCell className="px-4 py-1">
                  <Skeleton variant="circular" width={20} height={20} />
                </TableCell>

                {/* Time Slots */}
                <TableCell className="px-4 py-1">
                  <Box className="flex flex-wrap gap-2">
                    {Array.from({ length: 2 }).map((_, i) => (
                      <Skeleton
                        key={i}
                        variant="rectangular"
                        width={140}
                        height={32}
                        sx={{ borderRadius: "8px" }}
                      />
                    ))}
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Box>
    </Box>
  );
};

export default WeeklyAvailabilitySkeleton;
