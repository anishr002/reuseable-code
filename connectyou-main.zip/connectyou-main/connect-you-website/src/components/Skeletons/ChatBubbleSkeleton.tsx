import { Skeleton } from "@mui/material";

const ChatBubbleSkeleton = () => {
  const dummyMessages = Array.from({ length: 4 });

  return (
    <div className="flex flex-col space-y-3 w-full">
      {dummyMessages.map((_, index) => {
        const isSender = index % 2 === 0; // alternate sender/receiver

        return (
          <div
            key={index}
            className={`flex w-full ${
              isSender ? "justify-end" : "justify-start"
            }`}
          >
            <div
              className={`p-3 rounded-lg max-w-[80%] md:max-w-xs ${
                isSender ? "bg-blue-100" : "bg-gray-200"
              }`}
            >
              {/* Simulate file preview */}
              <Skeleton
                variant="text"
                width={200}
                height={20}
                className="rounded-md mb-2"
                animation="wave"
              />

              {/* Simulate message line(s) */}
              <Skeleton
                variant="text"
                width={isSender ? 140 : 180}
                height={20}
                animation="wave"
              />
              <Skeleton
                variant="text"
                width={isSender ? 100 : 160}
                height={20}
                animation="wave"
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default ChatBubbleSkeleton;
