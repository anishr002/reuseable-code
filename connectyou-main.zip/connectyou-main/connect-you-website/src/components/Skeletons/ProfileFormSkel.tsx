import { Skeleton } from "@mui/material";

const ProfileFormSkel = ({ rows = 1 }: { rows?: number }) => {
  return (
    <>
      {Array(rows)
        .fill("")
        .map((_, index) => (
          <div className="col-span-1" key={index}>
            <Skeleton variant="rectangular" width="100%" height={50} />
          </div>
        ))}
    </>
  );
};

export default ProfileFormSkel;
