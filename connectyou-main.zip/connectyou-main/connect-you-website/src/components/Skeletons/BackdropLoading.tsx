import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import { CircularProgress } from "@mui/material";

export default function BackdropLoading({
  open,
  children,
}: {
  open: boolean;
  children?: React.ReactNode;
}) {
  return (
    <div>
      <Backdrop
        sx={(theme) => ({
          color: "#fff",
          zIndex:  theme.zIndex.modal + 10000,
        })}
        open={open}
        // className="bg-radial to-[#3aa7a327] via-[#3aa7a310]  from-[#3aa7a300]"
      >
        {children ? (
          children
        ) : (
          <CircularProgress
            size={40}
            sx={{
              color: "#3aa7a3",
            }}
          />
        )}
      </Backdrop>
    </div>
  );
}
