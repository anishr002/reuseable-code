import { FaUser } from "react-icons/fa";

const CoachCardSkeleton = ({ length = 4 }: { length?: number }) => {
  return (
    <>
      {Array.from({ length: length }).map((_, i) => (
        <div
          key={i}
          className="relative coach-card flex overflow-hidden flex-col justify-center items-center w-full md:min-h-[250px] md:h-[250px] lg:min-h-[230px] lg:h-[250px] border border-[#013338] rounded-[20px] animate-pulse bg-[#f4fdfd]"
        >
          <div className="w-full h-full grid grid-cols-1 sm:grid-cols-12 ">
            {/* Left Image Placeholder */}
            <div className="relative h-full col-span-4 md:col-span-4 flex justify-center items-center overflow-hidden">
              <div className="w-full h-full min-h-[500px]  bg-[#d4f2f2] rounded-l-[20px] flex items-center justify-center">
                <FaUser className="text-[140px] opacity-65 text-[#3aa7a367]" />
              </div>
            </div>

            {/* Right Content Placeholder */}
            <div className="col-span-8 md:col-span-8 sm:pl-9 flex flex-col justify-start items-start pt-2 px-3 lg:px-0 lg:pr-5 py-1 space space-y-2">
              {/* Rating */}
              <div className="w-full flex justify-end">
                <div className="h-4 w-24 bg-[#bce6e5] rounded-md" />
              </div>

              {/* Name */}
              <div className="h-5 w-3/4 bg-[#bce6e5] rounded-md" />

              {/* Location */}
              <div className="h-4 w-1/2 bg-[#bce6e5] rounded-md" />

              {/* Title line */}
              <div className="h-4 w-2/3 bg-[#bce6e5] rounded-md" />

              {/* Credentials */}
              <div className="h-4 w-5/6 bg-[#bce6e5] rounded-md" />

              {/* Languages */}
              <div className="h-4 w-1/2 bg-[#bce6e5] rounded-md" />

              {/* Experience */}
              <div className="h-4 w-1/3 bg-[#bce6e5] rounded-md" />

              {/* Button */}
              <div className="flex justify-end w-full pt-4">
                <div className="h-9 w-[120px] bg-[#ebbd337a] rounded-full" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </>
  );
};

export default CoachCardSkeleton;
