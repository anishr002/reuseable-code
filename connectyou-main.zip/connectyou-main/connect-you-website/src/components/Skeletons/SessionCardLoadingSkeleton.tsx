import {
  FormControlLabel,
  FormGroup,
  IconButton,
  Skeleton,
} from "@mui/material";
import { BsThreeDotsVertical } from "react-icons/bs";

const SessionCardLoadingSkeleton = ({
  theme = "loading",
}: {
  theme?: "loading" | "error";
}) => {
  return (
    <div className="bg-[#ffffff] min-h-[225px] rounded-[5px] px-5 py-7 flex flex-col w-full space-y-3.5 relative">
      {/* Three Dots Icon Skeleton */}
      <div className="absolute top-1 right-1">
        <IconButton size="small" disabled>
          <BsThreeDotsVertical
            className={`${
              theme === "loading" ? "text-gray-300" : "text-[#ff000057]"
            }`}
          />
        </IconButton>
      </div>

      <div className="w-full grid grid-cols-12 auto-rows-fr gap-x-[10px] gap-y-[10px]">
        {/* Title Skeleton */}
        <div className="col-span-9">
          <Skeleton variant="text" width="80%" height={20} />
        </div>

        {/* Toggle Switch Skeleton */}
        <div
          className={`col-span-3 flex flex-row justify-between items-start ${
            theme === "loading" ? "text-gray-300" : "text-[#ff000057]"
          }`}
        >
          <FormGroup>
            <FormControlLabel
              control={
                <Skeleton variant="rectangular" width={30} height={15} />
              }
              label={<Skeleton variant="text" width={50} height={12} />}
              labelPlacement="start"
            />
          </FormGroup>
        </div>

        {/* Duration and Price Skeleton */}
        <div
          className={`col-span-12 flex flex-row w-full justify-start items-center gap-10 ${
            theme === "loading" ? "text-gray-300" : "text-[#ff000057]"
          }`}
        >
          <Skeleton variant="text" width={50} height={18} />
          <Skeleton variant="text" width={60} height={18} />
        </div>
      </div>

      {/* Description Skeleton */}
      <div
        className={`col-span-12 w-full flex flex-col gap-3 items-start justify-start ${
          theme === "loading" ? "text-gray-300" : "text-[#ff000057]"
        }`}
      >
        <Skeleton variant="text" width="100%" height={15} />
        <Skeleton variant="text" width="90%" height={15} />
        <Skeleton variant="text" width="80%" height={15} />
        {/* See More Skeleton */}
        <Skeleton variant="text" width={60} height={12} />
      </div>
    </div>
  );
};
export default SessionCardLoadingSkeleton;
