import React from "react";
import SpeakerNotesOffIcon from "@mui/icons-material/SpeakerNotesOff";

export const InboxListLoading = ({
  Option,
}: {
  Option: "Loader" | "No-Data";
}) => {
  if (Option === "Loader") {
    return (
      <>
        {Array(4)
          .fill("")
          .map((_, i) => (
            <React.Fragment key={i}>
              <div className="w-full flex flex-row justify-start items-center gap-4  ">
                <span className="bg-gray-200 rounded-full w-12 h-12 animate-pulse"></span>
                <div className="flex flex-col gap-2 flex-1">
                  <span className="bg-gray-200 rounded h-4 w-3/4 animate-pulse"></span>
                  <span className="bg-gray-200 rounded h-2 w-2/3 animate-pulse"></span>
                </div>
              </div>
            </React.Fragment>
          ))}
      </>
    );
  }

  if (Option === "No-Data") {
    return (
      <div className=" w-full flex flex-col justify-center items-center h-64  text-[white]">
        <SpeakerNotesOffIcon
          sx={{
            color: "lightgray",
            fontSize: "2rem",
          }}
        />
        <p className="text-lg font-semibold mt-4">No Messages</p>
        <p className="text-sm">
          Your inbox is currently empty. Check back later!
        </p>
      </div>
    );
  }

  return null;
};
