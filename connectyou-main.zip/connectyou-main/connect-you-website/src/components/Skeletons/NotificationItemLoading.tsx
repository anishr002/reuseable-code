import Skeleton from "@mui/material/Skeleton";

const NotificationItemLoading = () => {
  return (
    <>
      <div className="rounded-[10px] bg-[#f5f5f5] p-4 grid grid-cols-6 gap-2">
        {/* Date & Time Skeleton */}
        <div className="col-span-2 flex flex-col">
          <Skeleton
            variant="text"
            width={80}
            height={20}
            sx={{ bgcolor: "#d6eceb" }}
          />
          <Skeleton
            variant="text"
            width={60}
            height={18}
            sx={{ bgcolor: "#d6eceb" }}
          />
        </div>

        {/* Notification Heading & Description Skeleton */}
        <div className="col-span-4 flex flex-col">
          <Skeleton
            variant="text"
            width="80%"
            height={20}
            sx={{ bgcolor: "#d6eceb" }}
          />
          <Skeleton
            variant="text"
            width="100%"
            height={18}
            sx={{ bgcolor: "#d6eceb" }}
          />
          <Skeleton
            variant="text"
            width="90%"
            height={18}
            sx={{ bgcolor: "#d6eceb" }}
          />
        </div>
      </div>
    </>
  );
};

export default NotificationItemLoading;
