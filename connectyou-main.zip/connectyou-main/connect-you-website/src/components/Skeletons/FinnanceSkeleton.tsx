import { Skeleton } from "@mui/material";

const FinnanceSkeleton = ({ variant }: { variant: "banking" | "stats" }) => {
  return (
    <>
      {variant === "banking" ? (
        <div className="flex-1 min-w-[300px] sm:w-full flex flex-col justify-between">
          <div>
            <Skeleton variant="text" width={150} height={24} />
            <Skeleton variant="text" width="90%" height={20} />
            <Skeleton variant="text" width="80%" height={20} />
          </div>
          <div className="flex justify-between mt-4">
            <Skeleton variant="text" width={100} height={24} />
            <Skeleton variant="rounded" width={140} height={40} />
          </div>
        </div>
      ) : variant === "stats" ? (
        <div className="flex-1 min-w-[300px] sm:w-full">
          {/* Heading Skeleton */}
          <Skeleton variant="text" width={180} height={24} className="pb-5" />
          <Skeleton
            variant="rectangular"
            width="100%"
            height={2}
            className="mb-4"
          />

          {/* Payment Details Skeleton */}
          <div className="mt-4 space-y-3 font-semibold">
            <div className="flex justify-between px-2">
              <Skeleton variant="text" width={120} height={20} />
              <Skeleton variant="text" width={60} height={20} />
            </div>
            <div className="flex justify-between px-2">
              <Skeleton variant="text" width={120} height={20} />
              <Skeleton variant="text" width={60} height={20} />
            </div>
            <div className="flex justify-between items-center p-2 rounded-md bg-opacity-50">
              <Skeleton variant="text" width={120} height={20} />
              <Skeleton variant="text" width={60} height={20} />
            </div>
          </div>

          {/* Button Skeleton */}
          <div className="flex justify-center pt-7">
            <Skeleton variant="rounded" width={120} height={40} />
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
};

export default FinnanceSkeleton;
