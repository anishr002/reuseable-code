import React from "react";
import { Link } from "react-router-dom";

interface NavigationLinkWrapProps {
  link: string;
  text: string;
}
const NavigationLinkWrap: React.FC<NavigationLinkWrapProps> = ({
  link,
  text,
}) => {
  return (
    <Link
      to={link}
      className=" w-fit h-fit cursor-pointer text-[#3aa7a3] font-medium text-lg hover:text-[#ebbd33] underline underline-offset-2"
    >
      {text}
    </Link>
  );
};

export default NavigationLinkWrap;
