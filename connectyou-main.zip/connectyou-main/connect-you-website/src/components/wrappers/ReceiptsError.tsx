import React from "react";

interface ReceiptsErrorProps {
  children: string | React.JSX.Element;
}
const ReceiptsError: React.FC<ReceiptsErrorProps> = ({ children }) => {
  return (
    <div className="  w-full border-l-4 border-red-500 pl-4  bg-red-100 bg-opacity-60">
      <div className=" text-red-600 font-semibold text-sm p-2 ">{children}</div>
    </div>
  );
};

export default ReceiptsError;
