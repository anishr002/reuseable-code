/* eslint-disable @typescript-eslint/no-explicit-any */
import { ReactNode, useEffect, useState } from "react";
import React from "react";
import Checkbox from "@mui/material/Checkbox";
import { CircularProgress, TextField } from "@mui/material";
import { Autocomplete } from "@react-google-maps/api";
import { useNotify } from "../../lib/Notify";
import CustomModalWrapper from "../../components/wrappers/CustomModalWrapper";
import { YellowButton } from "../../components/buttons/ThemeButtons";
import MenuButton from "../buttons/MenuButton";
import { MdEdit } from "react-icons/md";

export interface AddressAutoCompletionHelperFunctionProps {
  selectedAddress: string;
  countryCode: string;
  city: string | null;
  country: string | null;
  lat: number | null;
  lng: number | null;
  phoneCode: string | null;
}

interface AddressSelectionComponentProps {
  helper: ({
    selectedAddress,
    city,
    country,
    lat,
    lng,
    phoneCode,
  }: AddressAutoCompletionHelperFunctionProps) => void | undefined;
  children: ReactNode;
  header: ReactNode;
}

const AddressSelectionComponent: React.FC<AddressSelectionComponentProps> = ({
  helper,
  children,
  header,
}) => {
  const [loadingUpdate, setLoading] = React.useState<boolean>(false);
  const { notifyMe } = useNotify();
  const [isCurrentAddress, setIsCurrentAddress] =
    React.useState<boolean>(false);
  const handleChange_isCurrentAddress = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setIsCurrentAddress(event.target.checked);
  };
  //address states to extract and then export
  const [selectedAddress, setSelectedAddress] = React.useState<string>("");
  const [city, setCity] = React.useState<string | null>("");
  const [country, setCountry] = React.useState<string | null>("");
  const [phoneCode, setPhoneCode] = React.useState<string | null>("");
  const [lat, setLat] = React.useState<number | null>(null);
  const [lng, setLng] = React.useState<number | null>(null);
  const [countryCode, setCountryCode] = React.useState<string>("");
  const [cityViewPortBound, setCityViewPortBounds] = useState<
    undefined | google.maps.LatLngBounds
  >(undefined);

  // for efficeincy and reduced API calls
  const [PREVcountryCode, setPREVCountryCode] = React.useState<string>("");
  const [PREVcityViewPortBound, setPREVCityViewPortBounds] = useState<
    undefined | google.maps.LatLngBounds
  >(undefined);

  // autocomplete instances
  const [AutoCompleteCountryInstance, setAutoCompleteCountryInstance] =
    React.useState<google.maps.places.Autocomplete | undefined>(undefined);
  const [AutoCompleteCityInstance, setAutoCompleteCityInstance] =
    React.useState<google.maps.places.Autocomplete | undefined>(undefined);
  //streetAddress
  const [autocomplete, setAutocomplete] = React.useState<
    google.maps.places.Autocomplete | undefined
  >(undefined);
  const [loadingAutoStreetSelection, setLoadingAutoStreetSelection] =
    useState<boolean>(false);
  const handlePlaceChangedFullAddress = React.useCallback(async () => {
    if (autocomplete) {
      const place = autocomplete.getPlace();
      if (place.formatted_address) {
        setLoadingAutoStreetSelection(false);
        setAddresErrors((prevErrors) => ({
          ...prevErrors,
          selectedAddress: undefined,
        }));
        setSelectedAddress(place.formatted_address);
      }
      if (place.geometry && place.geometry.location) {
        setLat(place.geometry.location.lat());
        setLng(place.geometry.location.lng());
      }
    }
  }, [autocomplete]);

  interface AddressErrors {
    selectedAddress?: string;
    city?: string;
    country?: string;
  }
  const [openAddress, setOpenAddress] = React.useState<boolean>(false);
  const [addresErrors, setAddresErrors] = React.useState<AddressErrors>({});

  const validateFields = () => {
    const newErrors: AddressErrors = {};
    if (!selectedAddress)
      newErrors.selectedAddress = "Full address is required";
    if (!city) newErrors.city = "City is required";
    if (!country) newErrors.country = "Country is required";
    return newErrors;
  };

  const [loadingAutoCountrySelection, setLoadingAutoCountrySelection] =
    useState<boolean>(false);
  const handlePlaceChangeCountry = () => {
    if (AutoCompleteCountryInstance !== undefined) {
      const place = AutoCompleteCountryInstance.getPlace();
      if (place && place.address_components) {
        setLoadingAutoCountrySelection(false);
        const countryComponent = place.address_components.find((component) =>
          component.types.includes("country")
        );
        // console.log({ place });
        if (countryComponent) {
          setAddresErrors((prevErrors) => ({
            ...prevErrors,
            country: undefined,
          }));
          setCountry(countryComponent.long_name);
          setCountryCode(countryComponent.short_name);
          setPhoneCode("");
          if (AutoCompleteCityInstance) {
            AutoCompleteCityInstance.setOptions({
              componentRestrictions: { country: countryComponent.short_name },
              types: ["(cities)"],
            });
          }
          if (autocomplete) {
            autocomplete.setOptions({
              componentRestrictions: { country: countryComponent.short_name },
              types: ["address"],
            });
          }
        }
      }
    } else {
      console.log("Autocomplete is not loaded yet!");
    }
  };

  const onLoadAutoCompleteCountry = (
    autocompleteInstance: google.maps.places.Autocomplete
  ) => {
    autocompleteInstance.setTypes(["(regions)"]);
    setAutoCompleteCountryInstance(autocompleteInstance);
  };

  const [loadingCurrentAddress, setLoadingCurrentAddress] =
    React.useState<boolean>(false);
  const requestLocationPermission = async () => {
    try {
      const permissionStatus = await navigator.permissions.query({
        name: "geolocation",
      });
      if (permissionStatus.state === "granted") {
        console.log("");
      } else if (permissionStatus.state === "denied") {
        alert(
          "Location permission denied. Please enable it in your browser settings."
        );
        setLoading(false);
        setLoadingCurrentAddress(false);
        return setOpenAddress(false);
      } else {
        navigator.geolocation.getCurrentPosition(
          () => {
            console.log("permission granted");
          },
          (err) => {
            if (err.code === 1) {
              alert(
                "Location permission denied. Please enable it in your browser settings."
              );
              setLoading(false);
              setLoadingCurrentAddress(false);
              return setOpenAddress(false);
            }
          }
        );
      }
    } catch (error) {
      console.error("Error checking location permission:", error);
      setLoading(false);
      setLoadingCurrentAddress(false);
      return setOpenAddress(false);
    }
  };

  useEffect(() => {
    // console.log({ isCurrentAddress });
    if (isCurrentAddress) {
      if (navigator.geolocation) {
        requestLocationPermission();
        setLoadingCurrentAddress(true);
        navigator.geolocation.getCurrentPosition((position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const geocoder = new google.maps.Geocoder();
          const latLng = new google.maps.LatLng(lat, lng);
          geocoder.geocode({ location: latLng }, (results, status) => {
            if (status === "OK" && results && results[0]) {
              // console.log({ result: results[0] });
              const countryComponent = results[0].address_components.find(
                (component) => component.types.includes("country")
              );
              if (countryComponent) {
                setAddresErrors((prevErrors) => ({
                  ...prevErrors,
                  country: undefined,
                }));
                setCountry(countryComponent.long_name);
                setCountryCode(countryComponent.short_name);
                setPhoneCode("");
              }
              const cityComponent = results[0].address_components.find(
                (component) =>
                  component.types.includes("locality") ||
                  component.types.includes("sublocality")
              );
              if (cityComponent) {
                setAddresErrors((prevErrors) => ({
                  ...prevErrors,
                  city: undefined,
                }));
                setCity(cityComponent.long_name);
              }
              if (results[0].formatted_address) {
                setAddresErrors((prevErrors) => ({
                  ...prevErrors,
                  selectedAddress: undefined,
                }));
                setSelectedAddress(results[0].formatted_address);
              }
              if (results[0].geometry && results[0].geometry.location) {
                setLat(results[0].geometry.location.lat());
                setLng(results[0].geometry.location.lng());
              }
              setLoadingCurrentAddress(false);
            }
          });
        });
      } else {
        console.error("Geolocation is not supported by this browser.");
      }
    }
  }, [isCurrentAddress]);

  const [loadingAutoCitySelection, setLoadingAutoCitySelection] =
    useState<boolean>(false);
  const handlePlaceChangeAutocompleteCity = () => {
    if (AutoCompleteCityInstance !== undefined) {
      const place = AutoCompleteCityInstance.getPlace();
      if (place && place.address_components) {
        setLoadingAutoCitySelection(false);
        const cityComponent = place.address_components.find(
          (component) =>
            component.types.includes("locality") ||
            component.types.includes("sublocality")
        );

        if (cityComponent) {
          setAddresErrors((prevErrors) => ({
            ...prevErrors,
            city: undefined,
          }));
          setCity(cityComponent.long_name);
        }
        if (place.geometry && place.geometry.viewport) {
          setCityViewPortBounds(place.geometry.viewport);
        }
      }
    } else {
      console.log("Autocomplete is not loaded yet!");
    }
  };

  useEffect(() => {
    if (autocomplete && countryCode && countryCode !== PREVcountryCode) {
      autocomplete.setComponentRestrictions({ country: countryCode });
      setPREVCountryCode(countryCode);
    }
    if (
      autocomplete &&
      cityViewPortBound &&
      cityViewPortBound !== PREVcityViewPortBound
    ) {
      autocomplete.setBounds(cityViewPortBound);
      autocomplete.setOptions({ strictBounds: true });
      setPREVCityViewPortBounds(cityViewPortBound);
    }
  }, [countryCode, autocomplete, cityViewPortBound]);

  const onLoadAutocompleteCity = (
    autocompleteInstance: google.maps.places.Autocomplete
  ) => {
    autocompleteInstance.setTypes(["(cities)"]);
    if (countryCode) {
      autocompleteInstance.setComponentRestrictions({ country: countryCode });
    }
    setAutoCompleteCityInstance(autocompleteInstance);
  };

  const onLoadAutoCompleteFullAddress = (
    autocompleteInstance: google.maps.places.Autocomplete
  ) => {
    autocompleteInstance.setTypes(["address"]);
    autocompleteInstance.setFields([
      "address_components",
      "formatted_address",
      "geometry",
    ]);
    if (countryCode) {
      autocompleteInstance.setComponentRestrictions({ country: countryCode });
    }
    setAutocomplete(autocompleteInstance);
  };

  const onUpdateAddress = async () => {
    setAddresErrors({}); // Clear previous errors
    const validationErrors = validateFields();
    if (Object.keys(validationErrors).length > 0) {
      setAddresErrors(validationErrors);
      setLoading(false);
      return notifyMe({
        message:
          validationErrors.selectedAddress ||
          validationErrors.city ||
          validationErrors.country ||
          "There was some error while saving address",
      });
    }
    helper({
      selectedAddress,
      city,
      country,
      lat,
      lng,
      countryCode,
      phoneCode,
    });
    setOpenAddress(false);
  };

  return (
    <React.Fragment>
      {/* address */}
      <>
        <div className="flex w-full items-center justify-start gap-3  ">
          {header}
          <MenuButton
            Icon={MdEdit}
            options={[{ label: "Edit", action: () => setOpenAddress(true) }]}
          ></MenuButton>
        </div>
        {children}
      </>
      <CustomModalWrapper
        backdropClose={false}
        open={openAddress}
        title="Update Address"
        onClose={() => setOpenAddress(false)}
        children={
          <>
            {loadingCurrentAddress ? (
              <div
                className="flex justify-center items-center h-44 w-full
          "
              >
                <CircularProgress size={24} color="primary" />
              </div>
            ) : (
              <div className="flex flex-col w-full gap-8">
                <div className="flex w-full">
                  <div className="w-full z-10 flex flex-col">
                    <Autocomplete
                      onLoad={onLoadAutoCompleteCountry}
                      onPlaceChanged={handlePlaceChangeCountry}
                      options={{
                        componentRestrictions: { country: [] },
                        types: ["(regions)"],
                      }}
                    >
                      <TextField
                        id="outlined-basic"
                        label="Country"
                        variant="outlined"
                        fullWidth
                        size="small"
                        value={country}
                        onFocus={() => setLoadingAutoCountrySelection(true)}
                        onChange={(e) => {
                          setCountry(e.target.value);
                        }}
                        slotProps={{
                          input: {
                            endAdornment: loadingAutoCountrySelection && (
                              <CircularProgress
                                size={20}
                                sx={{ color: "#3aa7a3" }}
                              />
                            ),
                          },
                        }}
                      />
                    </Autocomplete>
                    {addresErrors.country && (
                      <span className="form-error-message">
                        {addresErrors.country}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex w-full">
                  <div className="w-full z-10 flex flex-col">
                    <Autocomplete
                      onLoad={onLoadAutocompleteCity}
                      onPlaceChanged={handlePlaceChangeAutocompleteCity}
                    >
                      <TextField
                        id="outlined-basic"
                        label="City"
                        variant="outlined"
                        fullWidth
                        size="small"
                        onFocus={() => setLoadingAutoCitySelection(true)}
                        disabled={country !== "" ? false : true}
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        slotProps={{
                          input: {
                            endAdornment: loadingAutoCitySelection && (
                              <CircularProgress
                                size={20}
                                sx={{ color: "#3aa7a3" }}
                              />
                            ),
                          },
                        }}
                      />
                    </Autocomplete>
                    {addresErrors.city && (
                      <span className="form-error-message">
                        {addresErrors.city}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="w-full z-10 flex flex-col">
                    <Autocomplete
                      onLoad={onLoadAutoCompleteFullAddress}
                      onPlaceChanged={handlePlaceChangedFullAddress}
                    >
                      <TextField
                        id="outlined-basic"
                        label="Full Address"
                        variant="outlined"
                        fullWidth
                        disabled={city != "" ? false : true} // Changed to depend on countryCode instead of city
                        size="small"
                        value={selectedAddress}
                        onChange={(e) => setSelectedAddress(e.target.value)}
                        onFocus={() => setLoadingAutoStreetSelection(true)}
                        slotProps={{
                          input: {
                            endAdornment: loadingAutoStreetSelection && (
                              <CircularProgress
                                size={20}
                                sx={{ color: "#3aa7a3" }}
                              />
                            ),
                          },
                        }}
                      />
                    </Autocomplete>
                    {addresErrors.selectedAddress && (
                      <span className="form-error-message">
                        {addresErrors.selectedAddress}
                      </span>
                    )}
                  </div>
                  <div className="flex w-full items-center">
                    <Checkbox
                      checked={isCurrentAddress}
                      onChange={handleChange_isCurrentAddress}
                      inputProps={{ "aria-label": "controlled" }}
                      sx={{
                        color: "#3aa7a3",
                        "&.Mui-checked": {
                          color: "#3aa7a3",
                        },
                      }}
                    />
                    <p>Get current address</p>
                  </div>
                </div>
                <div
                  className="flex cursor-pointer w-1/2 mx-auto"
                  onClick={onUpdateAddress}
                >
                  <YellowButton
                    loading={loadingUpdate}
                    text="Save"
                    type="submit"
                  />
                </div>
              </div>
            )}
          </>
        }
      />
    </React.Fragment>
  );
};

export default AddressSelectionComponent;
