import { FaArrowLeft } from "react-icons/fa6";
import { Swiper } from "swiper/react";
import { Swiper as SwiperType } from "swiper";
import React, {
  ReactNode,
  SetStateAction,
  useEffect,
  useRef,
  useState,
} from "react";
import { Autoplay, Pagination } from "swiper/modules";
import { FaArrowRight } from "react-icons/fa";
import { AutoplayOptions, SwiperOptions } from "swiper/types";
import "swiper/swiper-bundle.css";
import { IconButton } from "@mui/material";
import "../../styles/FullScreenSlider.css";

interface FullWidthSimpleSliderProps {
  children: ReactNode;
  breakpoints?:
    | {
        [width: number]: SwiperOptions;
        [ratio: string]: SwiperOptions;
      }
    | undefined;
  autoplay?: AutoplayOptions;
  padding?: string;
  swiperInstance: SwiperType | null;
  setSwiperInstance: React.Dispatch<SetStateAction<SwiperType | null>>;
  showNavButtons?: boolean;
  showPagination?: boolean;
  props?: Omit<
    SwiperOptions,
    | "modules"
    | "autoplay"
    | "spaceBetween"
    | "slidesPerView"
    | "effect"
    | "breakpoints"
    | "onSwiper"
    | "style"
    | "className"
  >;
  onSlideChange?: ((swiper: SwiperType) => void) | undefined;
  navBtnColor?: string;
  slidesPerView?: number | "auto" | undefined;
  buttonVariant?: "inline" | "absolute";
  spaceBetween?: string | number | undefined;
}

const FullWidthSimpleSlider: React.FC<FullWidthSimpleSliderProps> = ({
  children,
  breakpoints,
  autoplay,
  padding = "10px 16px",
  swiperInstance,
  setSwiperInstance,
  showNavButtons = true,
  showPagination = true,
  props,
  onSlideChange,
  navBtnColor = "white",
  slidesPerView = 1,
  buttonVariant = "absolute",
  spaceBetween = 30,
}) => {
  const [showNav, setShowNav] = useState(false);
  const swiperRef = useRef<SwiperType>(null);

  const checkNavigation = (swiper: SwiperType) => {
    if (!swiper) return;
    const hasScrollableContent = swiper.isBeginning !== swiper.isEnd;
    const hasMultipleSlides = swiper.slides && swiper.slides.length > 1;
    setShowNav(hasScrollableContent && hasMultipleSlides);
  };

  useEffect(() => {
    if (swiperInstance) {
      setTimeout(() => {
        swiperInstance.update();
        checkNavigation(swiperInstance);
      }, 100);
    }
  }, [children, swiperInstance]);

  useEffect(() => {
    const handleResize = () => {
      if (swiperInstance) {
        checkNavigation(swiperInstance);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [swiperInstance]);

  return (
    <div className="w-full relative h-full flex gap-3 justify-center items-center">
      {showNavButtons && buttonVariant === "inline" && showNav && (
        <div
          style={{
            color: navBtnColor,
          }}
          className=" text-[white]   text-2xl font-[800]  z-[999]  w-4 h-4 px-4 rounded-full flex flex-col justify-center items-center  "
        >
          <IconButton
            onClick={() => {
              if (swiperInstance) {
                swiperInstance?.slidePrev();
              }
            }}
          >
            <FaArrowLeft
              style={{
                color: navBtnColor,
              }}
              className="text-white  text-md "
            />
          </IconButton>
        </div>
      )}
      <Swiper
        modules={[Autoplay, Pagination]}
        autoplay={autoplay}
        spaceBetween={spaceBetween}
        slidesPerView={slidesPerView}
        {...(showPagination && {
          pagination: {
            clickable: true,
          },
        })}
        effect="slide"
        breakpoints={breakpoints}
        onSwiper={(swiper) => setSwiperInstance(swiper)}
        style={{
          width: "100%",
          height: "100%",
          padding: padding,
          textAlign: "center",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
        }}
        className="mySwiper"
        {...props}
        onSlideChange={onSlideChange}
        onInit={(swiper) => {
          swiperRef.current = swiper;
          checkNavigation(swiper);
        }}
      >
        {children}
      </Swiper>
      {showNavButtons && buttonVariant === "inline" && showNav && (
        <>
          <div
            style={{
              color: navBtnColor,
            }}
            className=" text-[white]   text-2xl font-[800] z-[999]  w-4 h-4 px-4 rounded-full flex flex-col justify-center items-center  "
          >
            <IconButton
              onClick={() => {
                if (swiperInstance) {
                  swiperInstance?.slideNext();
                }
              }}
            >
              <FaArrowRight
                style={{
                  color: navBtnColor,
                }}
                className="text-white  text-md "
              />
            </IconButton>
          </div>
        </>
      )}
      {showNavButtons && buttonVariant === "absolute" && (
        <>
          <div
            style={{
              color: navBtnColor,
            }}
            className="absolute top-1/2 text-[white]  -translate-y-1/2 left-4 text-2xl font-[800]  z-[999]  w-4 h-4 px-4 rounded-full flex flex-col justify-center items-center  "
          >
            <IconButton
              onClick={() => {
                if (swiperInstance) {
                  swiperInstance?.slidePrev();
                }
              }}
            >
              <FaArrowLeft
                style={{
                  color: navBtnColor,
                }}
                className="text-white  text-md "
              />
            </IconButton>
          </div>
          <div
            style={{
              color: navBtnColor,
            }}
            className="absolute top-1/2 text-[white]  -translate-y-1/2 right-4 text-2xl font-[800] z-[999]  w-4 h-4 px-4 rounded-full flex flex-col justify-center items-center  "
          >
            <IconButton
              onClick={() => {
                if (swiperInstance) {
                  swiperInstance?.slideNext();
                }
              }}
            >
              <FaArrowRight
                style={{
                  color: navBtnColor,
                }}
                className="text-white  text-md "
              />
            </IconButton>
          </div>
        </>
      )}
    </div>
  );
};

export default FullWidthSimpleSlider;
