import { Box, Drawer, IconButton } from "@mui/material";
import React, { ReactNode } from "react";
import { GiHamburgerMenu } from "react-icons/gi";
import { IoClose } from "react-icons/io5";

interface DrawerNavigationProps {
  children: ReactNode;
  open: boolean;
  toggleDrawer: (bool: boolean) => void;
  background?: string;
}
const DrawerNavigation: React.FC<DrawerNavigationProps> = ({
  children,
  open,
  toggleDrawer,
  background = "#013338",
}) => {
  return (
    <>
      <div className="w-fit h-full flex justify-center items-center">
        <IconButton onClick={() => toggleDrawer(true)}>
          <GiHamburgerMenu className="text-white font-[500] text-md" />
        </IconButton>
        <Drawer anchor="right" open={open} onClose={() => toggleDrawer(false)}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "start",
              width: 320,
              background: background,
              height: "100%",
              py: 7,
            }}
          >
            <IconButton
              onClick={() => toggleDrawer(false)}
              sx={{
                position: "absolute",
                top: 15,
                right: 15,
                color: "#fff",
                fontSize: "1.5rem",
                "&:hover": {
                  color: "red",
                },
              }}
            >
              <IoClose />
            </IconButton>
            {children}
          </Box>
        </Drawer>
      </div>
    </>
  );
};

export default DrawerNavigation;
