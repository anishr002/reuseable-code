import { Modal, Paper, SxProps } from "@mui/material";
import SubmitModalHeader from "./SubmitModalHeader";
import React, { ReactNode, useState } from "react";
interface CustomModalWrapperProps {
  open: boolean;
  title?: string | ReactNode;
  children: React.ReactNode;
  backdropClose?: boolean;
  escapeClose?: boolean;
  onClose: () => void;
  sx?: SxProps | undefined;
  allowChildrenPadding?: boolean;
}

const CustomModalWrapper: React.FC<CustomModalWrapperProps> = ({
  open,
  title,
  children,
  backdropClose = true,
  escapeClose = true,
  allowChildrenPadding = true,
  onClose,
  sx = {
    width: {
      xs: "100%",
      sm: 500,
    },
  },
}) => {
  const [isScrolled, setIsScrolled] = useState(false);

  return (
    <>
      <Modal
        aria-labelledby={`${
          typeof title === "string" ? title : "untitled"
        }-modal-title`}
        aria-describedby={`${
          typeof title === "string" ? title : "untitled"
        }-modal-desc`}
        open={open}
        onClose={(_: unknown, reason: "backdropClick" | "escapeKeyDown") => {
          if (reason === "backdropClick" && backdropClose) {
            onClose();
          } else if (reason === "escapeKeyDown" && escapeClose) {
            onClose();
          }
        }}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Paper
          variant="outlined"
          sx={{
            ...sx,
            maxHeight: "80vh",
            maxWidth: "90%",
            overflowY: "auto",
            borderRadius: "md",
            boxShadow: "lg",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div
            id={`${title}-modal-header`}
            style={{
              position: "sticky",
              top: 0,
              backgroundColor: "white",
              zIndex: 10,
              minHeight: "60px",
              width: "100%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              boxShadow: isScrolled
                ? "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)"
                : "none",
            }}
          >
            <div
              style={{
                width: " 83.333333%",
                margin: "0 auto",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                padding: "0.75rem  0",
              }}
            >
              <SubmitModalHeader
                title={title}
                onClose={() => onClose()}
                showCloseButton={true}
              />
            </div>
          </div>

          <div
            id={`${title}-modal-content`}
            style={{
              overflowY: "auto",
              maxHeight: title ? "calc(80vh - 80px)" : "80vh", // header height is adjusted to it
            }}
            className={`${
              allowChildrenPadding && "px-2 sm:px-4 xl:px-6 pt-4 pb-5"
            } style-scroll style-scroll-thin font-quicksand `}
            onScroll={(e) => setIsScrolled(e.currentTarget.scrollTop > 10)}
          >
            {children}
          </div>
        </Paper>
      </Modal>
    </>
  );
};

export default CustomModalWrapper;
