import React, { ReactNode } from "react";
import XSpace from "./XSpace";
import useDeviceCheck from "../hooks/useCheckDevice";
import useScreenSize from "../hooks/useScreenSize";
import "../../styles/PageBanner.css";

interface PageBannerWrapperProps {
  image: string;
  leftChild: ReactNode;
}

const PageBannerWrapper: React.FC<PageBannerWrapperProps> = ({
  image,
  leftChild,
}) => {
  const { isIOS } = useDeviceCheck();
  const { is1Xl } = useScreenSize();

  return (
    <>
      {is1Xl ? (
        <div className="mb-14 w-full relative bg-[#013338] rounded-b-3xl overflow-hidden md:pb-0 pb-6 min-h-fit  flex justify-center items-center">
          <XSpace>
            <div
              className={`overflow-hidden max-w-full  sm:min-h-[35rem] w-full md:min-h-[32rem] 2xl:min-h-[38rem] md:h-[70vh] 2xl:h-[75vh]  grid grid-cols-1 md:grid-cols-12 justify-center items-center ${
                isIOS ? "" : "h-full"
              }`}
            >
              <div className="absolute inset-0 w-full h-full pointer-events-none bg-gradient-to-r from-[#013338] via-60% to-transparent z-[10]"></div>
              <div
                className={`col-span-1 bg-gradient-to-r from-[#013338] via-60% to-transparent  md:col-span-8 2xl:col-span-6 flex flex-col justify-center items-start ${
                  isIOS ? "" : "h-full"
                } w-full  gap-6 z-20 text-left`}
              >
                <div className="left-slide-in bg-transparent">{leftChild}</div>
              </div>
              <div
                className={`flex col-span-1  flex-col justify-start  md:pt-0 md:justify-center items-center md:items-start ${
                  isIOS ? "min-h-[300px]" : "h-full"
                } w-full px-6 md:px-12 gap-6`}
              >
                <img
                  src={image}
                  alt="image"
                  className={`right-slide-in z-10 sm:block md:absolute inset-y-0 right-[-4rem] 2xl:right-0 bottom-0  object-contain   ${
                    isIOS ? "min-h-[300px]" : "h-full"
                  } `}
                />
              </div>
            </div>
          </XSpace>
        </div>
      ) : (
        <div className="mb-14 w-full relative bg-[#013338] rounded-b-3xl overflow-hidden md:pb-0 pb-6  flex justify-center items-center">
          <XSpace>
            <div className=" flex w-full py-14 flex-col justify-center items-center">
              <div className="absolute inset-0 w-full h-full pointer-events-none bg-gradient-to-r from-[#013338] via-60% to-transparent z-[10]"></div>
              <div className="z-20 flex flex-col justify-center items-center">
                <div className="w-full flex items-center justify-center h-72">
                  <img
                    src={image}
                    alt="banner-image"
                    className="object-contain w-full h-full"
                  />
                </div>
                <div className="flex flex-col space-y-3.5 text-center justify-center items-center mt-6">
                  {leftChild}
                </div>
              </div>
            </div>
          </XSpace>
        </div>
      )}
    </>
  );
};

export default PageBannerWrapper;
