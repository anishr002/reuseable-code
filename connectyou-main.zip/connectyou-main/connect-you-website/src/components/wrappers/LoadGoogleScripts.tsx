import { ReactNode } from "react";
import GoogleScriptLoadProvider from "../../providers/GoogleScriptLoadProvider";

const LoadGoogleScripts = ({ children }: { children: ReactNode }) => {
  return (
    <>
      <GoogleScriptLoadProvider>{children}</GoogleScriptLoadProvider>
    </>
  );
};

export default LoadGoogleScripts;
