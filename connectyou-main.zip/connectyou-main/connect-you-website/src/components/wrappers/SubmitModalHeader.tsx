import { IconButton, Tooltip } from "@mui/material";
import React, { ReactNode } from "react";
import { IoClose } from "react-icons/io5";

interface Props {
  title: ReactNode;
  showCloseButton?: boolean;
  onClose?: () => void | null;
}
const SubmitModalHeader: React.FC<Props> = ({
  title,
  showCloseButton = true,
  onClose = null,
}) => {
  return (
    <>
      <div className="flex w-full justify-center items-center ">
        <h1 className="z-20 leading-normal text-[#013338] font-mundial font-bold  text-[20px] md:text-[20px] text-md xl:text-xl  w-fit uppercase break-before-auto text-center text-pretty">
          {title}
        </h1>
        {showCloseButton && onClose && (
          <Tooltip
            title="Close"
            children={
              <IconButton
                sx={{
                  position: "absolute",
                  top: 2,
                  right: 2,
                  color: "#013338",
                  "&:hover": {
                    color: "red",
                  },
                }}
                onClick={() => {
                  onClose();
                }}
              >
                <IoClose className="text-inherit" />
              </IconButton>
            }
          />
        )}
      </div>
    </>
  );
};

export default SubmitModalHeader;
