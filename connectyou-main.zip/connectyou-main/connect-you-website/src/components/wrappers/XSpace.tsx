import React, { ReactNode } from "react";

interface XSpace
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "className"> {
  children: ReactNode;
  className?: string;
}
const XSpace: React.FC<XSpace> = (props) => {
  const { children, className, ...rest } = props;
  return (
    <div
      {...rest}
      className={`${className} flex flex-col justify-center items-center w-full h-fit px-[15px] md:px-[40px] lg:px-[60px] xl:px-[80px] 2xl:max-w-[140rem] 2xl:mx-auto`}
    >
      {children}
    </div>
  );
};

export default XSpace;
