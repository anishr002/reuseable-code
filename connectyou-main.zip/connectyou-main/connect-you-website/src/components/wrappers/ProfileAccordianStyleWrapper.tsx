/* eslint-disable @typescript-eslint/no-explicit-any */
import { ReactElement, ReactNode, useEffect, useState } from "react";
import DropScrollWrapper from "./DropScrollWrapper";
import WhiteRoundedBox from "../dashboard-components/WhiteRoundedBox";
import ProvideToolTip from "./ProvideToolTip";
import { IconButton } from "@mui/material";
import { FaAngleDown, FaAngleUp } from "react-icons/fa";

const ProfileAccordianStyleWrapper = ({
  header,
  children,
  actions,
  defaultOpen = false,
  showCollapseButton = true,
}: {
  header: ReactNode | null;
  children: ReactElement<unknown, any>;
  actions: ReactNode | null;
  defaultOpen?: boolean;
  showCollapseButton?: boolean;
}) => {
  const [open, setOpen] = useState<boolean>(false);
  useEffect(() => {
    setOpen(defaultOpen);
  }, [defaultOpen]);

  return (
    <div className=" flex flex-col w-full h-fit  h-sm:overflow-hidden space-y-3.5 bg-white ">
      <WhiteRoundedBox
        className={`w-full pt-3 ${
          open ? "pb-2" : "pb-0"
        } flex flex-col md:flex-row md:justify-between md:items-center gap-4 relative md:pr-10 pr-0 `}
      >
        {header}
        <div className="text-[#3aa7a3]  underline-offset-[7px] font-medium text-[18px] flex flex-row flex-wrap justify-between sm:items-center md:h-10 gap-3">
          {actions}
          {showCollapseButton && (
            <div className="absolute top-3 right-0 p-2 md:h-10 w-10 items-center flex justify-center">
              <ProvideToolTip title={open ? "Collapse" : "Expand"}>
                <IconButton
                  sx={{ p: 0, color: "inherit", fontSize: "18px" }}
                  onClick={() => setOpen((prev) => !prev)}
                >
                  <div className="underline cursor-pointer ">
                    {!open ? <FaAngleDown /> : <FaAngleUp />}
                  </div>
                </IconButton>
              </ProvideToolTip>
            </div>
          )}
        </div>
      </WhiteRoundedBox>
      <div className={` px-[20px] ${open ? "pb-[20px]" : "pb-0"} `}>
        <DropScrollWrapper open={open}>{children}</DropScrollWrapper>
      </div>
    </div>
  );
};

export default ProfileAccordianStyleWrapper;
