import React, { ReactNode } from "react";

interface HighlightGetInTouchCardWrapperProps {
  image: string;
  rightContent: ReactNode;
  button: ReactNode;
}
const HighlightGetInTouchCardWrapper: React.FC<
  HighlightGetInTouchCardWrapperProps
> = ({ image, rightContent, button }) => {
  return (
    <div className="w-full h-full flex justify-center items-center py-4">
      <div className=" w-full lg:h-[400px] gap-6 py-0  md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px] bg-linear-to-r from-[#006771] to-[#013338] overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 w-full h-full gap-4 pb-7 lg:pb-0 lg:gap-0 justify-center items-center">
          <div className="col-span-1 overflow-hidden w-full h-full flex justify-center items-center ">
            <img
              src={image}
              alt="background-image"
              className="object-cover md:absolute block inset-0 z-1 h-[100%] "
            />
          </div>
          <div className="w-full absolute h-full inset-0 z-2 bg-gradient-to-l from-[#01343883] via-[#01343834]"></div>
          <div className="col-span-1 overflow-hidden z-10 w-full h-full flex flex-col gap-6 justify-center items-center ">
            {rightContent}
            {button}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HighlightGetInTouchCardWrapper;
