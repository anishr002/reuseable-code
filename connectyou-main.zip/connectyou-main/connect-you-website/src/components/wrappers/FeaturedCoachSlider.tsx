import { Swiper } from "swiper/react";
import { Swiper as SwiperType } from "swiper";
import React, { ReactNode, useState } from "react";
import { Autoplay, Pagination } from "swiper/modules";
import { AutoplayOptions, SwiperOptions } from "swiper/types";
import "swiper/swiper-bundle.css";
import "../../styles/FeaturedCoachSlide.css";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import { IconButton } from "@mui/material";
import useScreenSize from "../hooks/useScreenSize";

interface FeaturedCoachSliderProps {
  children: ReactNode;
  breakpoints?:
    | {
        [width: number]: SwiperOptions;
        [ratio: string]: SwiperOptions;
      }
    | undefined;
  autoplay?: AutoplayOptions;
}

const defAutoplay = {
  delay: 2500,
  disableOnInteraction: true,
  pauseOnMouseEnter: true,
};

const deBreakPoints = {
  320: {
    slidesPerView: 1,
    spaceBetween: 50,
  },
  480: {
    slidesPerView: 1,
    spaceBetween: 50,
  },
  640: {
    slidesPerView: 1,
    spaceBetween: 50,
  },
  860: {
    slidesPerView: 1,
    spaceBetween: 50,
  },
  1180: {
    slidesPerView: 1,
    spaceBetween: 50,
  },
};

const FeaturedCoachSlider: React.FC<FeaturedCoachSliderProps> = ({
  children,
  breakpoints = deBreakPoints,
  autoplay = defAutoplay,
}) => {
  const [swiperInstance, setSwiperInstance] = useState<SwiperType | null>(null);
  const { isMobile, isTab } = useScreenSize();


  return (
    <div className="w-full relative h-full flex justify-center items-center">
      <Swiper
        modules={[Autoplay, Pagination]}
        loop={true}
        loopAdditionalSlides={3}
        autoplay={autoplay}
        spaceBetween={isMobile ? 10 : 50}
        centeredSlides={true}
        slidesPerView={1}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
        effect="cube"
        breakpoints={breakpoints}
        onSwiper={(swiper) => setSwiperInstance(swiper)}
        style={{
          width: "100%",
          height: "100%",
          textAlign: "center",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
          paddingLeft: isMobile || isTab ? "60px" : "250px",
          paddingRight: isMobile || isTab ? "60px" : "250px",
          paddingBottom: "40px",
          paddingTop: "40px",
        }}
        className="featured-mySwiper"
      >
        {children}
      </Swiper>
      <>
        <IconButton
          sx={{
            position: "absolute",
            top: "50%",
            left: isMobile || isTab ? "20px" : "220px",
            transform: "translate(-50%, -50%)",
            fontSize: "1.5rem",
            zIndex: 9999,
            width: "32px",
            height: "32px",
            padding: "8px",
            borderRadius: "50%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: isMobile || isTab ? "#3AA7A3" : "",
            color: isMobile || isTab ? "white" : "#013338",
            "&:hover": {
              backgroundColor: "#3aa7a3",
              color: "white",
            },
          }}
          onClick={() => {
            if (swiperInstance) {
              swiperInstance.slidePrev();
            }
          }}
        >
          <FaArrowLeft />
        </IconButton>
        <IconButton
          sx={{
            position: "absolute",
            top: "50%",
            right: isMobile || isTab ? "20px" : "220px", // Adjust this value as needed
            transform: "translate(50%, -50%)",

            fontSize: "1.5rem",
            zIndex: 9999,
            width: "32px",
            height: "32px",
            padding: "8px",
            borderRadius: "50%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",

            backgroundColor: isMobile || isTab ? "#3AA7A3" : "",
            color: isMobile || isTab ? "white" : "#013338",
            "&:hover": {
              backgroundColor: "#3aa7a3",
              color: "white",
            },
          }}
          onClick={() => {
            if (swiperInstance) {
              swiperInstance.slideNext();
            }
          }}
        >
          <FaArrowRight />
        </IconButton>
      </>
    </div>
  );
};

export default FeaturedCoachSlider;
