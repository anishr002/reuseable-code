/* eslint-disable @typescript-eslint/no-explicit-any */
import { ReactElement } from "react";

const DropScrollWrapper = ({
  open,
  children,
}: {
  children: ReactElement<unknown, any>;
  open: boolean;
}) => {
  return (
    <>
      <div
        className={`transition-all ease-in-out duration-500 origin-top transform ${
          open ? "max-h-full rotate-x-0" : "max-h-0 rotate-x-90"
        } overflow-hidden`}
        style={{
          transformOrigin: "top",
          transition: "max-height 0.5s ease-in-out, transform 0.5s ease-in-out",
        }}
      >
        {children}
      </div>
    </>
  );
};

export default DropScrollWrapper;
