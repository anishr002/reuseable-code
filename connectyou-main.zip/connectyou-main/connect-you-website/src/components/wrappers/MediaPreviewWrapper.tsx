import { forwardRef, ReactNode, useImperativeHandle, useState } from "react";
import FullWidthSimpleSlider from "./FullWidthSimpleSlider";
import { Swiper as SwiperType } from "swiper";
import { SwiperSlide } from "swiper/react";
import { Modal } from "@mui/material";
import ModalCloseButton from "../buttons/ModalCloseButton";
import { renderReadFilePreview } from "../../util/renderFilePreview";
export interface MediaPreviewWrapperProps {
  children: ReactNode;
  allowClickPreview?: boolean;
  files?: string[];
  path?: string;
  childProps?: Omit<React.HTMLAttributes<HTMLDivElement>, "onClick">;
}

const MediaPreviewWrapper = forwardRef(
  (
    {
      children,
      allowClickPreview,
      files,
      childProps,
    }: MediaPreviewWrapperProps,
    ref
  ) => {
    const [swiperInstance, setSwiperInstance] = useState<SwiperType | null>(
      null
    );
    const [openModal, setOpen] = useState<boolean>(false);
    const close = () => setOpen(false);
    const open = () => setOpen(true);
    useImperativeHandle(ref, () => ({
      close: () => close(),
      open: () => open(),
    }));

    return (
      <>
        <div {...(allowClickPreview ? { onClick: open } : {})} {...childProps}>
          {children}
        </div>
        <Modal
          sx={{
            width: "100%",
            height: "100dvh",
            mx: "auto",
            my: "auto",
          }}
          open={openModal}
          onClose={close}
        >
          <div className="w-full h-full flex flex-row justify-center items-center bg-black/90 p-4">
            <ModalCloseButton
              onClick={close}
              sx={{
                color: "red",
                zIndex: 999,
              }}
            />
            <FullWidthSimpleSlider
              swiperInstance={swiperInstance}
              setSwiperInstance={setSwiperInstance}
              buttonVariant="inline"
              slidesPerView={1}
              props={{}}
            >
              {files?.map((file, i) => (
                <SwiperSlide key={`image-preview-temp-modal-file-item-${i}`}>
                  <div className="flex w-full h-full justify-center items-center">
                    {renderReadFilePreview({
                      path: "messageFile",
                      file: file,
                      imageElProps: {
                        className:
                          "preview-image w-full h-full object-center object-contain rounded-[5px]  bg-transparent ",
                        style: {
                          objectFit: "contain",
                        },
                      },
                      smartFileElProps: {
                        className:
                          "w-52 h-42 rounded-[5px] flex flex-col justify-center items-center  ",
                        maxLength: 100,
                        allowDownload: true,
                        allowPreview: true,
                        flexDirection: "column",
                      },
                      videoElProps: {
                        autoPlay: true,
                        className:
                          "preview-image w-full h-full  rounded-[5px] bg-transparent",
                        muted: true,
                        loop: true,
                        playsInline: true,
                        allowDownload: true,
                        style: {
                          objectFit: "contain",
                        },
                      },
                    })}
                  </div>
                </SwiperSlide>
              ))}
            </FullWidthSimpleSlider>
          </div>
        </Modal>
      </>
    );
  }
);

export default MediaPreviewWrapper;
