/* eslint-disable @typescript-eslint/no-explicit-any */
import { Tooltip } from "@mui/material";
import { ReactElement } from "react";

interface Props {
  title: string;
  children: ReactElement<unknown, any>;
}
const ProvideToolTip = (props: Props) => {
  const { children, title } = props;
  return (
    <>
      <Tooltip title={title}>{children}</Tooltip>
    </>
  );
};

export default ProvideToolTip;
