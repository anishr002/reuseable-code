/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { ReactNode, useEffect, useState } from "react";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";
import { DarkThemeButton, YellowButton } from "../buttons/ThemeButtons";
import LoadingElement from "./LoadingElement";
import DateDropdown from "./DateDropdown";
import TimeSlotDropdown from "./TimeSlotDropdown";
import Coaching_session_Type, {
  Timeslot,
} from "../../Types/backend/Coaching_session_Type";
import dayjs, { Dayjs } from "dayjs";
import useCreateAvailableTimeSlots, {
  TimeSlot,
} from "../hooks/useCreateAvailableTimeSlots";
import { RootState } from "../../lib/store";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import moment from "moment-timezone";
import { useNotify } from "../../lib/Notify";
import axios from "axios";
import {
  convertDayjsToTimeStampStr,
  convertTo12hours,
} from "../../util/formatTime";
import { Box, Collapse } from "@mui/material";
import { Coach_Data_Type } from "../../Types/backend/Coach_Data_Type";
import { FaClock } from "react-icons/fa";
import customAlert from "../../lib/swalExtentions";
import useDatesLoop from "../hooks/useDatesLoop";

interface SessionBookingModalProps {
  title?: React.ReactNode;
  heading?: string;
  sessionKeys: {
    coachId: string;
    sessionId: string;
  };
  defaults?: {
    sessionDate: Dayjs;
    timeSlot: Timeslot;
    bookingId: string;
    bookdSessionId: string;
    userId?: string;
  };
  children: ReactNode;
  type?: "booking" | "reschedule";
  Refresh?: () => void;
  entity?: "user" | "coach";
}

interface Session extends Coaching_session_Type {
  coachDetails: Pick<Coach_Data_Type, "timeZone" | "_id">;
}
const SessionBookingModal: React.FC<SessionBookingModalProps> = ({
  title = "Book a session",
  heading = "Add your details to book a session",
  sessionKeys,
  defaults,
  children,
  type = "booking",
  Refresh,
  entity = "user",
}) => {
  const [open, setOpen] = useState<boolean>(false);
  const [sessionDetails, setSessionDetails] = useState<Session | undefined>(
    undefined
  );
  const fetchSessionDetails = async () => {
    try {
      const response = await httpAPI.get(
        `${backendURL}/api-v2/public/sessions/session-details/${sessionKeys.sessionId}`
      );
      if (response.status === 200) {
        setSessionDetails(response.data.data);
      }
    } catch (error: any) {
      console.error(
        "Failed to fetch coachee details:",
        error?.response?.data?.message
      );
    }
  };

  useEffect(() => {
    const init = async () => {
      try {
        setLoading(true);
        await fetchSessionDetails();
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [sessionKeys.sessionId, open, defaults]);

  const { notifyMe } = useNotify();
  const navigate = useNavigate();
  //selected Date Section
  const [selectedDate, setSelectedDate] = useState<Dayjs | null>(null);
  //selected Time slot
  const [selectedTimeslot, setSelectedTimeslot] = useState<Timeslot | null>(
    null
  );
  useEffect(() => {
    if (defaults) {
      setSelectedDate(defaults.sessionDate);
    }
  }, [defaults, open]);

  const [loading, setLoading] = useState<boolean>(false);
  const [loadingSlots, setLoadingSlots] = useState<boolean>(false);
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  const cartId = useSelector((state: RootState) => state.cartId.value);
  const [sortedTimeSlots, setSortedTimeSlots] = useState<Timeslot[]>([]);
  const {
    slotsForDay: timeSlots,
    noslotsAval: notimeSlots,
    loadingSlots: initialloadingslots,
    createSlots,
    createSlotsForMultipleDates,
  } = useCreateAvailableTimeSlots();

  const [unavailableTimeslots, setUnavailableTimeslots] = useState<Timeslot[]>(
    []
  );

  const getDatesArr = useDatesLoop();

  const [coachAvailSlots, setCoachAvailSlots] = useState<
    {
      date: Dayjs;
      slots: TimeSlot[];
    }[]
  >([]);

  useEffect(() => {
    const dates = getDatesArr({ endDate: dayjs().add(3, "months") });
    const getData = async () => {
      const slots = await createSlotsForMultipleDates({
        coachId: sessionKeys.coachId,
        dates: dates,
        slotGap: "00:30",
      });
      setCoachAvailSlots(slots);
      console.log({ "Coach-  slots ": slots });
    };
    getData();
  }, [sessionKeys.coachId, open]);

  const fetchUnavailableSlotsAndDates = async () => {
    try {
      if (entity === "user") {
        const timeZone = loginUserData?.timeZone || moment.tz.guess();
        const userId =
          entity === "user" ? loginUserData?._id : defaults?.userId;
        const formatDates = (dates: any[]) =>
          dates.map((d: any) => ({
            from: moment(d.from).tz(timeZone).format("HH:mm"),
            to: moment(d.to).tz(timeZone).format("HH:mm"),
          }));
        const [coachResponse, cartResponse, userResponse, blockedForCoach] =
          await Promise.all([
            axios.post(
              `${backendURL}/coach/profile/coach-booked-date/${sessionKeys.coachId}`,
              {
                sessionDate: selectedDate
                  ? convertDayjsToTimeStampStr(selectedDate)
                  : "",
                timeZone,
                userId,
              }
            ),
            axios.post(`${backendURL}/user/cart/cart-added-date`, {
              sessionDate: selectedDate
                ? convertDayjsToTimeStampStr(selectedDate)
                : "",
              coachId: sessionKeys.coachId,
              timeZone,
              userId,
              cartId,
            }),
            userId
              ? userId !== ""
                ? axios.post(
                    `${backendURL}/user/profile/user-booked-date/${userId}`,
                    {
                      sessionDate: selectedDate
                        ? convertDayjsToTimeStampStr(selectedDate)
                        : "",
                      coachId: sessionKeys.coachId,
                      timeZone,
                      userId,
                      cartId,
                    }
                  )
                : Promise.resolve({ status: 204, data: { data: [] } })
              : Promise.resolve({ status: 204, data: { data: [] } }),
            axios.post(
              `${backendURL}/user/cart/coach-cart-added-date-disabled`,
              {
                sessionDate: selectedDate
                  ? convertDayjsToTimeStampStr(selectedDate)
                  : "",
                coachId: sessionKeys.coachId,
                timeZone,
                userId,
                cartId,
              }
            ),
          ]);
        const formattedCoachDates =
          coachResponse.status === 200
            ? formatDates(coachResponse.data.data || [])
            : [];
        const formattedCartDates =
          cartResponse.status === 200
            ? formatDates(cartResponse.data.data || [])
            : [];
        const formattedUserDates =
          userResponse.status === 200 ? userResponse.data.data || [] : [];
        const formattedDiabledCoach =
          blockedForCoach.status === 200 ? blockedForCoach.data.data || [] : [];
        // console.log(
        //   "formattedCartDates",
        //   formattedCartDates,
        //   "formattedCoachDates",
        //   formattedCoachDates,
        //   "formattedUserDates",
        //   formattedUserDates,
        //   "formattedDiabledCoach",
        //   formattedDiabledCoach
        // );
        setUnavailableTimeslots([
          ...formattedCoachDates,
          ...formattedCartDates,
          ...formattedUserDates,
          ...formattedDiabledCoach,
        ]);
      } else {
        const timeZone = loginUserData?.timeZone || moment.tz.guess();
        const userId = defaults?.userId;
        const formatDates = (dates: any[]) =>
          dates.map((d: any) => ({
            from: moment(d.from).tz(timeZone).format("HH:mm"),
            to: moment(d.to).tz(timeZone).format("HH:mm"),
          }));
        const [coachResponse, cartResponse, userResponse] = await Promise.all([
          axios.post(
            `${backendURL}/coach/profile/coach-booked-date/${sessionKeys.coachId}`,
            {
              sessionDate: selectedDate
                ? convertDayjsToTimeStampStr(selectedDate)
                : "",
              timeZone,
              userId,
            }
          ),
          axios.post(`${backendURL}/user/cart/cart-added-date`, {
            sessionDate: selectedDate
              ? convertDayjsToTimeStampStr(selectedDate)
              : "",
            coachId: sessionKeys.coachId,
            timeZone,
            userId,
            cartId,
          }),
          userId
            ? userId !== ""
              ? axios.post(
                  `${backendURL}/user/profile/user-booked-date/${userId}`,
                  {
                    sessionDate: selectedDate
                      ? convertDayjsToTimeStampStr(selectedDate)
                      : "",
                    coachId: sessionKeys.coachId,
                    timeZone,
                    userId,
                    cartId,
                  }
                )
              : Promise.resolve({ status: 204, data: { data: [] } })
            : Promise.resolve({ status: 204, data: { data: [] } }),
        ]);
        const formattedCoachDates =
          coachResponse.status === 200
            ? formatDates(coachResponse.data.data || [])
            : [];
        const formattedCartDates =
          cartResponse.status === 200
            ? formatDates(cartResponse.data.data || [])
            : [];
        const formattedUserDates =
          userResponse.status === 200 ? userResponse.data.data || [] : [];

        // console.log(
        //   "formattedCartDates",
        //   formattedCartDates,
        //   "formattedCoachDates",
        //   formattedCoachDates,
        //   "formattedUserDates",
        //   formattedUserDates,
        //   "formattedDiabledCoach",
        //   formattedDiabledCoach
        // );
        setUnavailableTimeslots([
          ...formattedCoachDates,
          ...formattedCartDates,
          ...formattedUserDates,
        ]);
      }
    } catch (error: any) {
      console.error("Fetch error:", error);
      const errorMessage =
        error.response?.data?.message || "Something went wrong";
      const errorStatus = error.response?.status;
      switch (errorStatus) {
        case 400:
        case 401:
        case 403:
        case 404:
        case 409:
        case 500:
          notifyMe({ message: errorMessage, severity: "error" });
          break;
        default:
          notifyMe({
            message: "An unexpected error occurred.",
            severity: "error",
          });
      }
    }
  };

  useEffect(() => {
    const fetch = async () => {
      try {
        if (sessionKeys.coachId && selectedDate) {
          setLoadingSlots(true);
          await Promise.allSettled([
            createSlots({
              coachId: sessionKeys.coachId,
              dayIndex: selectedDate.day(),
              slotGap: "00:30",
              date: selectedDate,
            }),
            fetchUnavailableSlotsAndDates(),
          ]);
        } else {
          setLoadingSlots(false);
        }
      } catch (error) {
        console.log(error);
      } finally {
        setLoadingSlots(false);
      }
    };
    fetch();
  }, [selectedDate, sessionKeys.coachId]);

  useEffect(() => {
    if (unavailableTimeslots.length > 0) {
      const availableSlots = timeSlots.filter(
        (slot) => !unavailableTimeslots.some((b) => isOverlap(b, slot))
      );
      setSortedTimeSlots(availableSlots);
    } else {
      setSortedTimeSlots(timeSlots);
    }
  }, [unavailableTimeslots, timeSlots]);

  const handlCloseAction = () => {
    setOpen(false);
    if (type === "booking") {
      setSelectedDate(null);
      setSelectedTimeslot(null);
    }
    if (type === "reschedule") {
      setSelectedDate(null);
      setSelectedTimeslot(null);
    }
  };

  const handleAddToCart = async () => {
    if (selectedTimeslot && selectedDate && sessionDetails) {
      setLoading(true);
      const selectedTime1 = selectedTimeslot.from;
      const selectedDate1 = selectedDate.format("DD-MM-YYYY");
      const selectedTimeStamp = `${selectedDate1} ${selectedTime1}`;
      try {
        const response = await httpAPI.post(
          `${backendURL}/user/cart/add-session`,
          {
            sessionId: sessionKeys.sessionId,
            sessionDate: selectedTimeStamp,
            userId: loginUserData?._id,
            cartId: cartId,
            coachId: sessionKeys.coachId,
            sessionType: sessionDetails.type,
            timeZone: loginUserData?.timeZone || moment.tz.guess(),
          }
        );
        // console.log(response);
        if (response.status === 200) {
          setLoading(false);
          return navigate(`/cart`);
        }
      } catch (error: any) {
        console.log("Add to cart click error", error);
        if (error.response.status === 403) {
          setLoading(false);
          setSelectedTimeslot(null);
          setOpen(false);
          return customAlert.fire({
            title: "Maximum Limit Exceeded !",
            text: "You can only have 3 free sessions, Please select a paid session to proceed for booking a session with this coach",
            icon: "warning",
          });
        }
        return notifyMe({
          message: error.response.data.message,
          severity: "error",
        });
      } finally {
        setLoading(false);
      }
    }
  };

  const handleReschedule = async () => {
    setLoading(true);
    const selectedTime1 = selectedTimeslot?.from;
    const selectedDate1 = selectedDate?.format("DD-MM-YYYY");
    const selectedTimeStamp = `${selectedDate1} ${selectedTime1}`;
    try {
      const response = await httpAPI.post(
        `${backendURL}/${entity}/order/order-details/session-reschedule`,
        {
          bookingId: defaults?.bookingId,
          bookedSessionId: defaults?.bookdSessionId,
          sessionDate: selectedTimeStamp,
          coachId: sessionDetails?.coachId,
          coachTimeZone: sessionDetails?.coachDetails?.timeZone,
          sessionDateOld: defaults?.sessionDate,
          timeZone: loginUserData?.timeZone,
          userId: defaults?.userId,
        }
      );
      if (response.status === 200) {
        Refresh && Refresh();
        setLoading(false);
        return notifyMe({
          message: "Meeting rescheduled successfully",
          severity: "success",
        });
      }
    } catch (error: any) {
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          severity: "error",
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
        });
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  };

  const clientTz: string = loginUserData?.timeZone || moment.tz.guess();

  return (
    <React.Fragment>
      <div className="" onClick={() => setOpen(true)}>
        {children}
      </div>
      <CustomModalWrapper
        open={open}
        onClose={() => setOpen(false)}
        title={title}
        backdropClose={true}
        escapeClose={true}
        sx={{
          width: {
            sm: "90%",
            md: "70%",
            lg: 600,
          },
        }}
      >
        <div className="w-full h-fit  pb-8 px-4 md:px-10 flex flex-col items-center justify-start space-y-6 ">
          <p className="text-[#013338] font-medium text-[18px] text-center">
            {heading}
          </p>
          <div className="h-[53px] capitalize flex items-center justify-center w-fit  text-pretty rounded-[100px] px-6 text-[18px]  font-bold bg-[#f0f0f0] text-[#013338] text-center ">
            {`${sessionDetails?.title || "Session Title"}   $${
              sessionDetails?.price || "Free"
            }`}
          </div>
          <div className="hidden h-[53px] capitalize  items-center  leading-0 justify-center w-fit  text-pretty rounded-[100px] px-6 text-[18px]  font-bold bg-[#f0f0f0] text-[#013338] text-center ">
            <FaClock className="text-[#3aa7a3] mr-2" />{" "}
            {`${sessionDetails?.duration} mins`}
          </div>
          {loading ? (
            <div className="w-full h-14 items-center justify-center flex overflow-hidden">
              <LoadingElement style={{ height: 120 }} />
            </div>
          ) : (
            <div className="flex flex-col gap-4 w-full items-start justify-center">
              <div className="flex flex-col gap-2 w-full">
                <div className="flex items-center justify-between w-full">
                  <span className="font-medium text-[#013338] text-[18px]">
                    Select a Date
                  </span>
                  <span className="font-medium text-[#013338] text-sm">
                    {clientTz}
                  </span>
                </div>
                <DateDropdown
                  def={defaults?.sessionDate}
                  helper={(data: Dayjs | null) => {
                    // console.log(data);
                    setSelectedDate(data);
                    setSelectedTimeslot(null);
                    setLoadingSlots(true);
                  }}
                  calenderProps={{}}
                  highlights={coachAvailSlots}
                />
              </div>
              {loadingSlots || initialloadingslots ? (
                <div className=" text-[#3aa7a3] flex flex-col justify-center items-center py-3 gap-3 w-full h-fit overflow-hidden">
                  Getting Available Slots..
                  <LoadingElement style={{ height: 40 }} />
                </div>
              ) : selectedDate ? (
                <>
                  {!notimeSlots && sortedTimeSlots.length > 0 ? (
                    <div className="flex flex-col gap-2 w-full">
                      <span className="font-medium text-[#013338] text-[18px]">
                        Select a Time
                      </span>
                      <TimeSlotDropdown
                        helper={(data: Timeslot) => {
                          // console.log(data);
                          setSelectedTimeslot(data);
                        }}
                        options={sortedTimeSlots}
                      />
                    </div>
                  ) : (
                    <Collapse
                      in={notimeSlots || sortedTimeSlots.length === 0}
                      timeout={400}
                    >
                      <Box className="flex uppercase text-xs my-4 bg-[#fd292917] border border-transparent border-l-red-600 border-l-2  py-2 px-3 w-full items-center justify-start gap-2 text-[red] text-left   font-medium">
                        {coachAvailSlots.length > 0 &&
                        selectedDate &&
                        coachAvailSlots?.filter((a) =>
                          a?.date.isSame(selectedDate)
                        )[0]?.slots?.length > 0
                          ? "All The slots have been booked for the day, Please check another day"
                          : `No time slots are available on this day, select another day !`}
                      </Box>
                    </Collapse>
                  )}
                </>
              ) : (
                <Collapse
                  in={notimeSlots || sortedTimeSlots.length === 0}
                  timeout={400}
                >
                  <Box className="  flex uppercase text-xs my-4 bg-[#fd292917] border border-transparent border-l-red-600 border-l-2  py-2 px-3 w-full items-center justify-start gap-2 text-[red] text-left   font-medium">
                    {!selectedDate
                      ? "Please Select a date to get the available sessions!"
                      : "No time slots are available for the day"}
                  </Box>
                </Collapse>
              )}
            </div>
          )}
          {(selectedDate && (
            <div className="flex flex-col  w-full items-center justify-center gap-2 text-[#013338] text-center  font-semibold text-[16px]">
              {type === "reschedule" ? (
                <div className="flex flex-col space-y-2.5  py-3 px-4 rounded-[10px] bg-[#f0f0f0]">
                  <p
                    className={`${
                      selectedTimeslot && "line-through text-gray-400"
                    }`}
                  >
                    <span>Your Session is scheduled to commence on </span>
                    <span>
                      {`On ${defaults?.sessionDate?.format(
                        "MM-DD-YYYY"
                      )} - From ${defaults?.timeSlot.from} To ${
                        defaults?.timeSlot.to
                      }`}
                    </span>
                  </p>
                  {selectedTimeslot && (
                    <p>
                      <span>
                        Your Session will be rescheduled to commence on{" "}
                      </span>
                      {`On ${selectedDate?.format(
                        "MM-DD-YYYY"
                      )} - From ${convertTo12hours(
                        selectedTimeslot?.from
                      )} To ${convertTo12hours(selectedTimeslot?.to)}`}
                    </p>
                  )}
                </div>
              ) : (
                <>
                  {selectedTimeslot && (
                    <div className="rounded-[10px] py-3 px-4 bg-[#f0f0f0]">
                      <span>
                        Your Session will be scheduled to commence on{" "}
                      </span>
                      {`On ${selectedDate?.format(
                        "MM-DD-YYYY"
                      )} - From ${convertTo12hours(
                        selectedTimeslot?.from
                      )} To ${convertTo12hours(selectedTimeslot?.to)}`}
                    </div>
                  )}
                </>
              )}
            </div>
          )) ||
            ""}
          <div className="flex flex-col md:flex-row w-full items-center justify-center gap-4">
            <DarkThemeButton
              loading={false}
              text="cancel"
              style={{ width: "160px", padding: "0 20px" }}
              onClick={() => handlCloseAction()}
            />
            {type === "booking" ? (
              <YellowButton
                onClick={() => handleAddToCart()}
                loading={loading}
                text="Add To Cart"
                style={{
                  width: "160px",
                  cursor: loading ? "progress" : "pointer",
                  padding: "0 20px",
                }}
                shouldDisable={loading || !selectedDate || !selectedTimeslot}
              />
            ) : (
              <YellowButton
                onClick={() => handleReschedule()}
                loading={loading}
                text="Confirm Reschedule"
                style={{
                  width: "160px",
                  cursor: loading ? "progress" : "pointer",
                  padding: "0 20px",
                }}
                shouldDisable={loading || !selectedDate || !selectedTimeslot}
              />
            )}
          </div>
        </div>
      </CustomModalWrapper>
    </React.Fragment>
  );
};

export default SessionBookingModal;

const timeToMinutes = (time: string) => {
  const [hour, minute] = time.split(":").map(Number);
  return hour * 60 + minute;
};
const isOverlap = (slot1: Timeslot, slot2: Timeslot) => {
  return (
    timeToMinutes(slot1.from) < timeToMinutes(slot2.to) &&
    timeToMinutes(slot1.to) > timeToMinutes(slot2.from)
  );
};
