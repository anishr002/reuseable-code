/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import Paper from "@mui/material/Paper";
import Drawer from "@mui/material/Drawer";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import { toggleOpenNotifiDrawer } from "../../slices/notificationDrawer";
import MundialHeadingText from "./MundialHeadingText";
import ModalCloseButton from "../buttons/ModalCloseButton";
import NotificationItemsCount from "./NotificationItemsCount";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Notification } from "../../pages/Notification/Notifications";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { setCount } from "../../slices/Notification";
import Warning from "./Warning";
import moment from "moment-timezone";
import NotificationItemLoading from "../Skeletons/NotificationItemLoading";

const NotificationDrawer = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const open = useSelector(
    (state: RootState) => state.openNotificationDrawer.open
  );
  const refresh = useSelector(
    (state: RootState) => state.openNotificationDrawer.refresh
  );
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  const [addShadow, setAddShadow] = useState<boolean>(false);
  const handleClose = () => dispatch(toggleOpenNotifiDrawer());
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const fetchNotifications = async () => {
    if (Object.keys(loginUserData).length == 0) {
      return;
    }
    try {
      const response = await httpAPI.post(
        `${backendURL}/${
          loginUserData.userType === "coach" ? "coach" : "user"
        }/profile/get-all-notifications?page=1&limit=10&filter=1`,
        { _id: loginUserData._id }
      );
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        setNotifications(response.data.data);
        dispatch(setCount(response.data.unreadNotifications));
      }
    } catch (error: any) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [refresh, open, loginUserData]);

  return (
    <Drawer
      sx={{
        "& .MuiDrawer-paper": {
          width: {
            xs: "95%",
            sm: "70%",
            md: 400,
            xl: 460,
          },
        },
      }}
      anchor="right"
      open={open}
      onClose={handleClose}
    >
      <Paper
        variant="elevation"
        elevation={1}
        sx={{
          width: "100%",
          height: "100dvh",
          maxHeight: "100dvh",
          background: "white",
          py: 2,
        }}
      >
        <ModalCloseButton onClick={handleClose} sx={{ zIndex: 9999 }} />
        <div className="flex flex-col space-y-2 h-full overflow-hidden relative ">
          <div
            className={`flex flex-row justify-between items-center pb-1 h-fit px-3 w-full ${
              addShadow && "shadow-md"
            }`}
          >
            <MundialHeadingText
              sizeVariant="xs"
              variant="darksea"
              className="relative   flex gap-4  items-center "
            >
              Notifications
              <NotificationItemsCount variant="inline" />
            </MundialHeadingText>
          </div>
          {loading ? (
            <div className="flex flex-col space-y-2.5 w-full h-full">
              {Array(10)
                .fill("")
                .map((_, i) => (
                  <NotificationItemLoading
                    key={`notification-loading-sekeleton-items-${i}`}
                  />
                ))}
            </div>
          ) : (
            <div
              className="flex flex-col space-y-2.5 flex-1 overflow-auto style-scroll px-4 "
              onScroll={(e) => {
                e?.currentTarget?.scrollTop > 20
                  ? setAddShadow(true)
                  : setAddShadow(false);
              }}
            >
              {notifications.length > 0 ? (
                notifications.map((notification, i) => (
                  <div
                    key={`notification-drawer-notification-item-${i}`}
                    onClick={() => {
                      handleClose();
                      navigate(
                        `/${
                          loginUserData.userType === "coach" ? "c" : "u"
                        }/notifications`,
                        {
                          state: {
                            openNotificationDetails: true,
                            notification_id: notification._id,
                          },
                        }
                      );
                    }}
                    className="font-quicksand cursor-pointer border border-transparent hover:border-[#3aa7a388] rounded-[10px] bg-[#f5f5f5] p-4 grid grid-cols-12"
                  >
                    <div className="col-span-full md:col-span-2 flex md:flex-col items-center md:items-start  md:gap-0 gap-2 md:justify-start ">
                      <span className="text-[#013338] text-sm font-semibold">
                        {moment(notification.createdAt).format("DD MMMM")}
                      </span>
                      <span className="text-[#013338] text-xs font-medium">
                        {moment(notification.createdAt).format("hh:mmA")}
                      </span>
                    </div>
                    <div className="col-span-full md:col-span-10 md:ps-2 flex flex-col">
                      <span className="text-[#013338] text-[18px] md:text-[16px] font-semibold font-mundial line-clamp-2">
                        {notification.heading}
                      </span>
                      <span className="text-[#013338] text-[16px] md:text-[14px] font-normal line-clamp-3">
                        {notification.description}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex px-2 ">
                  <Warning variant="seagreen">
                    You do not have any new notification right now.
                  </Warning>
                </div>
              )}
              <div className="absolute -bottom-4 left-0 w-full h-[130px] bg-gradient-to-t pointer-events-none from-white via-[#ffffff60] to-[#ffffff0e]   z-10"></div>
            </div>
          )}
        </div>
      </Paper>
    </Drawer>
  );
};

export default NotificationDrawer;
