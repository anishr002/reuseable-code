import React, { useEffect, useState } from "react";
import { FaClock } from "react-icons/fa";
import { ExpandMore, ExpandLess } from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import { Timeslot } from "../../Types/backend/Coaching_session_Type";
import { convertTo12hours } from "../../util/formatTime";

const DropdownContainer = styled("div")({
  position: "relative",
  width: "100%",
  border: "1px solid #3aa7a3",
  borderRadius: "10px",
  padding: "10px 10px",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  backgroundColor: "white",
});

const DropdownList = styled("div")({
  position: "absolute",
  top: "100%",
  left: 0,
  width: "100%",
  backgroundColor: "white",
  border: "1px solid #3aa7a3",
  borderRadius: "10px",
  maxHeight: "200px",
  overflowY: "auto",
  zIndex: 10,
  boxShadow: "0 2px 5px rgba(0, 0, 0, 0.2)",
});

const Option = styled("div")<{ selected: boolean }>((props) => ({
  display: "flex",
  alignItems: "center",
  gap: "8px",
  padding: "10px",
  cursor: "pointer",
  color: props.selected ? "#3aa7a3" : "#013338",
  backgroundColor: props.selected ? "white" : "transparent",
  "&:hover": {
    backgroundColor: "#e0f7f7",
  },
}));

const ScrollStyle = styled("div")({
  "&::-webkit-scrollbar": {
    width: "6px",
  },
  "&::-webkit-scrollbar-thumb": {
    background: "#3aa7a3",
    borderRadius: "10px",
  },
  display: "flex",
  flexDirection: "column",
  gap: "10px",
});

interface TimeSlotDropdownProps {
  options: Timeslot[];
  helper: (data: Timeslot) => void;
  def?: Timeslot;
}
const TimeSlotDropdown: React.FC<TimeSlotDropdownProps> = ({
  options,
  helper,
  def,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<Timeslot | null>(null);

  const handleSelect = (slot: Timeslot) => {
    setSelectedSlot(slot);
    setIsOpen(false);
    helper(slot);
  };

  useEffect(() => {
    if (def) {
      setSelectedSlot(options.find((a) => a === def) || null);
    }
  }, [def]);
  
  return (
    <div style={{ position: "relative", width: "100%" }}>
      <DropdownContainer
        onClick={() => {
          setIsOpen(!isOpen);
        }}
      >
        <div className="flex justify-start gap-3 items-center text-[#3aa7a3]">
          <span>
            <FaClock />
          </span>
          <span>
            {selectedSlot
              ? `${convertTo12hours(selectedSlot.from)} - ${convertTo12hours(
                  selectedSlot.to
                )}`
              : "Please Select"}
          </span>
        </div>
        {isOpen ? (
          <ExpandLess sx={{ color: "#3aa7a3" }} />
        ) : (
          <ExpandMore sx={{ color: "#3aa7a3" }} />
        )}
      </DropdownContainer>

      {isOpen && (
        <DropdownList className="style-scroll">
          <ScrollStyle>
            {options.map((slot, index) => (
              <Option
                key={index}
                selected={
                  selectedSlot?.from === slot.from &&
                  selectedSlot?.to === slot.to
                }
                onClick={() => handleSelect(slot)}
              >
                <FaClock />
                {convertTo12hours(slot.from)} - {convertTo12hours(slot.to)}
              </Option>
            ))}
          </ScrollStyle>
        </DropdownList>
      )}
    </div>
  );
};

export default TimeSlotDropdown;
