import InfoOutlined from "@mui/icons-material/InfoOutline";
import WarningRounded from "@mui/icons-material/WarningRounded";
import ErrorOutline from "@mui/icons-material/ErrorOutline";
import Check from "@mui/icons-material/CheckCircleOutline";
import { Box } from "@mui/material";
import { ReactNode } from "react";
import "../../styles/Animations.css";

const Warning = ({
  children,
  variant = "yellow",
  inline = false,
}: {
  children: ReactNode;
  variant?: "red" | "yellow" | "seagreen" | "success";
  inline?: boolean;
}) => {
  const returnStyles = () => {
    switch (variant) {
      case "red":
        return {
          text: "red",
          bgColor: "rgba(255, 0, 0, 0.15)", // Light red background
          borderColor: "rgba(255, 0, 0, 1)", // Solid red border
          icon: <ErrorOutline sx={{ color: "rgba(255, 0, 0, 1)" }} />, // Red error icon
        };
      case "seagreen":
        return {
          text: "#3aa7a3",
          bgColor: "rgba(58, 167, 163, 0.15)", // Light seagreen background
          borderColor: "rgba(58, 167, 163, 1)", // Solid seagreen border
          icon: <InfoOutlined sx={{ color: "rgba(58, 167, 163, 1)" }} />, // Info icon
        };
      case "success":
        return {
          text: "#3aa7a3",
          bgColor: "rgba(58, 167, 163, 0.15)", // Light seagreen background
          borderColor: "rgba(58, 167, 163, 1)", // Solid seagreen border
          icon: <Check sx={{ color: "rgba(58, 167, 163, 1)" }} />, // Info icon
        };
      case "yellow":
      default:
        return {
          text: "#ebbd33",
          bgColor: "rgba(235, 189, 51, 0.15)", // Light yellow background
          borderColor: "rgba(235, 189, 51, 1)", // Solid yellow border
          icon: <WarningRounded sx={{ color: "rgba(235, 189, 51, 1)" }} />, // Yellow warning icon
        };
    }
  };

  const { text, bgColor, borderColor, icon } = returnStyles();

  return (
    <>
      {inline ? (
        <Box
          sx={{
            color: text,
            borderLeftColor: borderColor,
            background: bgColor,
          }}
          className="  flex uppercase text-sm  border border-transparent border-l-2 py-0.5 px-3 flex-1 items-center justify-start gap-2 text-left font-medium"
        >
          {icon} {children}
        </Box>
      ) : (
        <Box
          sx={{
            color: text,
            borderLeftColor: borderColor,
            background: bgColor,
          }}
          className="  flex uppercase text-sm  border border-transparent border-l-2 py-2 px-3 flex-1 items-center justify-start gap-2 text-left font-medium"
        >
          {icon} {children}
        </Box>
      )}
    </>
  );
};

export default Warning;
