import "../../styles/FeatureCard.css";

interface FeatureCardProps {
  vector: string;
  heading: string | React.JSX.Element;
  description: string;
  background?: string;
  textColor?: string;
  className?: string;
}
const FeatureCard: React.FC<FeatureCardProps> = ({
  vector,
  heading,
  description,
  background = "bg-[#3AA7A3]",
  textColor = "text-[white]",
  className = "feature-card",
}) => {
  return (
    <div
      className={`${background} ${textColor} ${className} col-span-1 w-full h-full flex justify-center items-center  rounded-[10px] px-6 py-4 md:px-7 md:py-6 min-h-[150px]`}
    >
      <div className="flex justify-center items-center w-16 h-16 md:w-17 md:h-17 bg-white rounded-full shrink-0 mr-3 overflow-hidden p-2 image-bg">
        <img
          src={vector}
          alt="image"
          className="object-contain max-h-9/12 max-w-9/12"
        />
      </div>
      <div className="flex flex-col justify-start items-start flex-1 gap-2">
        <h1 className=" font-mundial font-bold  text-[16px] md:text-[20px] uppercase">
          {heading}
        </h1>
        <p className=" font-medium text-[12px] md:text-[14px]">{description}</p>
      </div>
    </div>
  );
};

export default FeatureCard;
