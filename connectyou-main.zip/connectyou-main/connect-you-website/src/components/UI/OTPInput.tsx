import * as React from "react";
import { Box, TextField } from "@mui/material";

interface OTPProps {
  separator: React.ReactNode;
  length: number;
  value: string;
  onChange: (newValue: string | ((prev: string) => string)) => void;
}

const OTP: React.FC<OTPProps> = ({ separator, length, value, onChange }) => {
  const inputRefs = React.useRef(new Array(length).fill(null));

  const focusInput = (targetIndex: number) => {
    inputRefs.current[targetIndex]?.focus();
  };

  const selectInput = (targetIndex: number) => {
    inputRefs.current[targetIndex]?.select();
  };

  const handleKeyDown = (event: React.KeyboardEvent, currentIndex: number) => {
    switch (event.key) {
      case "ArrowLeft":
        event.preventDefault();
        if (currentIndex > 0) {
          focusInput(currentIndex - 1);
          selectInput(currentIndex - 1);
        }
        break;
      case "ArrowRight":
        event.preventDefault();
        if (currentIndex < length - 1) {
          focusInput(currentIndex + 1);
          selectInput(currentIndex + 1);
        }
        break;
      case "Backspace":
      case "Delete":
        event.preventDefault();
        onChange((prevOtp) => {
          const otp =
            prevOtp.slice(0, currentIndex) + prevOtp.slice(currentIndex + 1);
          return otp;
        });
        if (event.key === "Backspace" && currentIndex > 0) {
          focusInput(currentIndex - 1);
        }
        break;
      default:
        break;
    }
  };

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    currentIndex: number
  ) => {
    const currentValue = event.target.value;
    let indexToEnter = 0;

    while (indexToEnter <= currentIndex) {
      if (
        inputRefs.current[indexToEnter]?.value &&
        indexToEnter < currentIndex
      ) {
        indexToEnter += 1;
      } else {
        break;
      }
    }

    onChange((prev: string) => {
      const otpArray = prev.split("");
      const lastValue = currentValue[currentValue.length - 1];
      otpArray[indexToEnter] = lastValue;
      return otpArray.join("");
    });

    if (currentValue !== "" && currentIndex < length - 1) {
      focusInput(currentIndex + 1);
    }
  };

  const handlePaste = (
    event: React.ClipboardEvent<HTMLDivElement>,
    currentIndex: number
  ) => {
    event.preventDefault();
    const clipboardData = event.clipboardData;

    if (clipboardData.types.includes("text/plain")) {
      let pastedText = clipboardData.getData("text/plain");
      pastedText = pastedText.substring(0, length).trim();
      let indexToEnter = 0;

      while (indexToEnter <= currentIndex) {
        if (
          inputRefs.current[indexToEnter]?.value &&
          indexToEnter < currentIndex
        ) {
          indexToEnter += 1;
        } else {
          break;
        }
      }

      const otpArray = value.split("");

      for (let i = indexToEnter; i < length; i += 1) {
        otpArray[i] = pastedText[i - indexToEnter] ?? " ";
      }

      onChange(otpArray.join(""));
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        gap: 1,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {new Array(length).fill(null).map((_, index) => (
        <React.Fragment key={index}>
          <TextField
            inputRef={(ele) => {
              inputRefs.current[index] = ele;
            }}
            aria-label={`Digit ${index + 1} of OTP`}
            onKeyDown={(event) => handleKeyDown(event, index)}
            onChange={(event) => handleChange(event, index)}
            onClick={() => selectInput(index)}
            onPaste={(event) => handlePaste(event, index)}
            value={value[index] ?? ""}
            variant="outlined"
            sx={{
              width: 40,
              textAlign: "center",
              "& input": {
                padding: "8px 8px",
              },
              ".css-quhxjy-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                {
                  borderColor: "#ebbd33",
                },
            }}
          />
          {index === length - 1 ? null : separator}
        </React.Fragment>
      ))}
    </Box>
  );
};

interface OTPInputProps {
  handleOtp: (otp: string) => void;
}

export default function OTPInput({ handleOtp }: OTPInputProps) {
  const [otp, setOtp] = React.useState("");
  React.useEffect(() => {
    handleOtp(otp);
  }, [otp]);
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "row",
        gap: 2,
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
      }}
    >
      <OTP
        separator={<span>-</span>}
        value={otp}
        onChange={setOtp}
        length={5}
      />
    </Box>
  );
}
