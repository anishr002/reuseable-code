import CookieIcon from "@mui/icons-material/Cookie";
import Button from "@mui/material/Button";
import Switch from "@mui/material/Switch";
import Modal from "@mui/material/Modal";
import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Paper } from "@mui/material";
import ModalCloseButton from "../buttons/ModalCloseButton";

const CookiePermissionModal = () => {
  const urlpath = useLocation();
  const [openCookiePermissionModal, setOpenCookiePermissionModal] =
    useState<boolean>(false);
  const [childOpen, setChildOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState(0);

  const handleCheckCookiePermission = () => {
    const permission: string | null = localStorage.getItem("Cookie-Permission");
    if (permission && (permission === "allowed" || permission === "some")) {
      return true;
    } else return false;
  };
  const toggleOpenCookiePermissionModal = (newValue: boolean) => {
    setOpenCookiePermissionModal(newValue);
  };

  useEffect(() => {
    const permission = handleCheckCookiePermission();
    if (permission === false) {
      toggleOpenCookiePermissionModal(true);
    }
  }, [urlpath.pathname]);

  const handleCreateCookiePermission = async (val: string) => {
    await localStorage.setItem("Cookie-Permission", val);
  };

  const toggleCookiePrefernces = async (name: string, value: string) => {
    localStorage.setItem(name, value);
  };

  return (
    <>
      {openCookiePermissionModal && (
        <div
          style={{
            position: "fixed",
            bottom: "30px",
            left: "25px",
            zIndex: "100",
          }}
          className="flex flex-col justify-start itens-start md:w-[26rem] w-[20rem] md:h-[18rem] h-fit bg-white custom-shadow rounded-xl  py-2 px-2 z-[99999999]"
        >
          <div className="grid grid-cols-1 py-2 text-[brown] ">
            <CookieIcon
              color="inherit"
              sx={{ fontSize: "5rem" }}
              className="animate-spin-to-right justify-self-end "
            />
          </div>
          <div className=" text-center text-pretty w-full text-sm font-medium text-[#73e51] py-2">
            By clicking 'Accept All Cookies', you agree to allow "ConnectYou" to
            exchange and store cookies on your device and disclose information
            in accordance with our
            <u className="cursor-pointer pl-1 connect-you-brand-text">
              <Link
                to="/cookie-policy"
                className="text-[#3aa7a3] hover:text-[#ebbd33]"
              >
                Cookie Policy
              </Link>
            </u>
          </div>
          <div className="flex flex-wrap md:flex-row flex-col justify-between items-center gap-2 w-full pt-2 px-8">
            <Button
              variant="outlined"
              size="small"
              sx={{
                flexGrow: 1,
                color: "white",
                fontSize: "0.775rem",
                backgroundColor: "#3aa7a3",
                borderColor: "#3aa7a3",
                borderRadius: "20px",
                fontFamily: "Quicksand",
                "&:hover": {
                  borderColor: "#3aa7a3",
                  backgroundColor: "white",
                  color: "#3aa7a3",
                },
              }}
              onClick={() => {
                toggleOpenCookiePermissionModal(false);
                setChildOpen(false);
                handleCreateCookiePermission("allowed");
              }}
            >
              Accept All Cookies
            </Button>
            <Button
              variant="outlined"
              size="small"
              sx={{
                flexGrow: 1,
                color: "white",
                fontSize: "0.775rem",
                backgroundColor: "#3aa7a3",
                borderColor: "#3aa7a3",
                borderRadius: "20px",
                fontFamily: "Quicksand",
                "&:hover": {
                  borderColor: "#3aa7a3",
                  backgroundColor: "white",
                  color: "#3aa7a3",
                },
              }}
              onClick={() => {
                toggleOpenCookiePermissionModal(false);
                setChildOpen(false);
                handleCreateCookiePermission("some");
              }}
            >
              Accept Necessary
            </Button>
            <Button
              variant="outlined"
              size="small"
              sx={{
                color: "white",
                fontSize: "0.775rem",
                width: { md: "100%" },
                backgroundColor: "#3aa7a3",
                borderColor: "#3aa7a3",
                borderRadius: "20px",
                fontFamily: "Quicksand",
                "&:hover": {
                  borderColor: "#3aa7a3",
                  backgroundColor: "white",
                  color: "#3aa7a3",
                },
              }}
              onClick={() => setChildOpen(true)}
            >
              Customize Settings
            </Button>
          </div>

          <Modal
            aria-labelledby="modal-title"
            aria-describedby="modal-desc"
            open={childOpen}
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <>
              <Paper
                variant="outlined"
                sx={{
                  width: { xs: "90%", md: 620 },
                  background: "background.paper",
                  overflow: "auto",
                  padding: 2,
                  height: { xs: "80vh", md: 400 },
                }}
                // className="style-scroll"
              >
                <ModalCloseButton onClick={() => setChildOpen(false)} />
                <h1 className=" px-4 text-xl font-semibold text-[#3aa7a3]">
                  ConnectYou
                </h1>
                <div className="flex flex-row justify-evenly items-center px-4 py-4">
                  <div
                    onClick={() => {
                      setActiveTab(0);
                    }}
                    className={`cursor-pointer flex flex-row justify-center items-center w-1/3 border border-transparent ${
                      activeTab === 0 && "border-b-[#3aa7a3]"
                    }`}
                  >
                    Consent
                  </div>
                  <div
                    onClick={() => {
                      setActiveTab(1);
                    }}
                    className={`cursor-pointer flex flex-row justify-center items-center w-1/3 border border-transparent ${
                      activeTab === 1 && "border-b-[#3aa7a3]"
                    }`}
                  >
                    Details
                  </div>
                  <div
                    onClick={() => {
                      setActiveTab(2);
                    }}
                    className={`cursor-pointer flex flex-row justify-center items-center w-1/3 border border-transparent ${
                      activeTab === 2 && "border-b-[#3aa7a3]"
                    }`}
                  >
                    About
                  </div>
                </div>
                {activeTab === 0 && (
                  <div className="flex flex-col w-full px-4 py-2 justify-start items-start text-md ">
                    <h1 className="w-full text-center font-semibold text-lg">
                      Cookie Consent Preference Center
                    </h1>
                    <p>
                      When you visit any of our websites, it may store or
                      retrieve information on your browser, mostly in the form
                      of cookies. This information might be about you, your
                      preferences, or your device and is mostly used to make the
                      site work as you expect it to. The information does not
                      usually directly identify you, but it can give you a more
                      personalized experience. Please note, blocking some types
                      of cookies may impact your experience of the site and the
                      services we are able to offer.
                    </p>
                    <a
                      className="text-[#3aa7a3] underline cursor-pointer"
                      href="?"
                    >
                      Cookie Policy
                    </a>
                    <div className="flex justify-center items-center w-full pt-6">
                      <Button
                        variant="outlined"
                        size="small"
                        sx={{
                          color: "white",
                          fontSize: "0.775rem",
                          backgroundColor: "#3aa7a3",
                          borderColor: "#3aa7a3",
                          borderRadius: "20px",
                          fontFamily: "Quicksand",
                          "&:hover": {
                            borderColor: "#3aa7a3",
                            backgroundColor: "white",
                            color: "#3aa7a3",
                          },
                        }}
                        onClick={() => {
                          handleCreateCookiePermission("allowed");
                          setChildOpen(false);
                          toggleOpenCookiePermissionModal(false);
                        }}
                      >
                        Accept All Cookies
                      </Button>
                    </div>
                  </div>
                )}
                {activeTab === 1 && (
                  <div className="flex flex-col w-full px-4 py-3 justify-start items-start">
                    <div className="flex flex-col w-full px-4 py-2 justify-start items-start text-md ">
                      <h1 className="w-full text-center font-semibold text-lg">
                        Custom Cookies Setting{" "}
                        <a
                          className="text-[#013338] underline cursor-pointer"
                          href="?"
                        >
                          Cookie Policy
                        </a>
                      </h1>
                      <div className="flex flex-col jutify-start items-start">
                        <div className="flex flex-col w-full">
                          <div className="flex flex-row justify-between items-center w-full">
                            <span className="text-[#013338] font-medium text-md">
                              Search Preferences
                            </span>
                            <span>
                              <Switch
                                onChange={(e) => {
                                  if (e.target.checked === true) {
                                    toggleCookiePrefernces(
                                      "Search-Preferences",
                                      `allowed`
                                    );
                                  } else
                                    toggleCookiePrefernces(
                                      "Search-Preferences",
                                      `blocked`
                                    );
                                }}
                                sx={{
                                  "& .MuiSwitch-switchBase.Mui-checked": {
                                    color: "#3aa7a3",
                                  },
                                  "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                                    {
                                      backgroundColor: "#3aa7a3",
                                    },
                                }}
                              />
                            </span>
                          </div>
                          <div className="flex flex-row justify-between items-center w-full">
                            Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Dolore ullam unde error facilis? Fuga,
                            laboriosam!
                          </div>
                        </div>
                        <div className="flex flex-col w-full">
                          <div className="flex flex-row justify-between items-center w-full">
                            <span className="text-[#013338] font-medium text-md">
                              Language Preferences
                            </span>
                            <span>
                              <Switch
                                onChange={(e) => {
                                  if (e.target.checked === true) {
                                    toggleCookiePrefernces(
                                      "Language-Preferences",
                                      `allowed`
                                    );
                                  } else
                                    toggleCookiePrefernces(
                                      "Language-Preferences",
                                      `blocked`
                                    );
                                }}
                                sx={{
                                  "& .MuiSwitch-switchBase.Mui-checked": {
                                    color: "#3aa7a3",
                                  },
                                  "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                                    {
                                      backgroundColor: "#3aa7a3",
                                    },
                                }}
                              />
                            </span>
                          </div>
                          <div className="flex flex-row justify-between items-center w-full">
                            Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Dolore ullam unde error facilis? Fuga,
                            laboriosam!
                          </div>
                        </div>
                        <div className="flex flex-col w-full">
                          <div className="flex flex-row justify-between items-center w-full">
                            <span className="text-[#013338] font-medium text-md">
                              Other Preferences
                            </span>
                            <span>
                              <Switch
                                onChange={(e) => {
                                  if (e.target.checked === true) {
                                    toggleCookiePrefernces(
                                      "Other-Preferences",
                                      `allowed`
                                    );
                                  } else
                                    toggleCookiePrefernces(
                                      "Other-Preferences",
                                      `blocked`
                                    );
                                }}
                                sx={{
                                  "& .MuiSwitch-switchBase.Mui-checked": {
                                    color: "#3aa7a3",
                                  },
                                  "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                                    {
                                      backgroundColor: "#3aa7a3",
                                    },
                                }}
                              />
                            </span>
                          </div>
                          <div className="flex flex-row justify-between items-center w-full">
                            Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Dolore ullam unde error facilis? Fuga,
                            laboriosam!
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-center items-center w-full pt-6">
                        <Button
                          variant="outlined"
                          size="small"
                          sx={{
                            color: "white",
                            fontSize: "0.775rem",
                            backgroundColor: "#3aa7a3",
                            borderColor: "#3aa7a3",
                            borderRadius: "20px",
                            fontFamily: "Quicksand",
                            "&:hover": {
                              borderColor: "#3aa7a3",
                              backgroundColor: "white",
                              color: "#3aa7a3",
                            },
                          }}
                          onClick={() => {
                            handleCreateCookiePermission("some");
                            setChildOpen(false);
                            toggleOpenCookiePermissionModal(false);
                          }}
                        >
                          Accept Custom Cookies
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                {activeTab === 2 && (
                  <div className="flex flex-col w-full px-4 py-3 justify-start items-start">
                    <div className="flex flex-col w-full px-4 py-3 justify-start items-start">
                      <div className="flex flex-col w-full px-4 py-2 justify-start items-start text-md ">
                        <h1 className="w-full text-center font-semibold text-lg">
                          About ConnectYou
                        </h1>
                        <p>
                          Lorem ipsum dolor sit amet consectetur, adipisicing
                          elit. Dolorem aliquam tempora id ea sunt adipisci
                          earum sequi maxime, sint, explicabo quas, nihil
                          perspiciatis aspernatur. Hic consectetur laboriosam
                          ratione facere autem. Facilis incidunt assumenda
                          aliquam inventore officia, et minus dolores cumque
                          sunt sint reprehenderit soluta. Rem est illo, illum,
                          adipisci ab possimus cumque quae consequuntur natus
                          minima animi dolores veniam sequi.
                        </p>
                        <a
                          className="text-[#013338] underline cursor-pointer"
                          href="?"
                        >
                          Cookie Policy
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </Paper>
            </>
          </Modal>
        </div>
      )}
    </>
  );
};

export default CookiePermissionModal;
