import React, { ReactNode, useState } from "react";
import { PiVideoCameraSlash } from "react-icons/pi";
import { MdOutlineDownloading } from "react-icons/md";
import { Tooltip } from "@mui/material";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";

type SmartVideoProps = React.VideoHTMLAttributes<HTMLVideoElement> & {
  allowDownload?: boolean;
  children?: ReactNode;
};

const Video = ({
  allowDownload = false,
  children,
  className,
  ...rest
}: SmartVideoProps) => {
  const [error, setError] = useState(false);
  const [hovered, setHovered] = useState(false);

  const handleDownload = () => {
    if (rest.src) {
      const link = document.createElement("a");
      link.setAttribute("target", "_blank");
      link.href = rest.src;
      link.download = rest.title || "video";
      link.click();
    }
  };

  // Extract video format from src
  const getVideoFormat = (src?: string) => {
    if (!src) return null;
    const parts = src.split(".");
    return parts.length > 1 ? parts[parts.length - 1].toUpperCase() : null;
  };

  return (
    <div
      className={`relative cursor-pointer inline-block ${className}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {!error ? (
        <video
          onError={() => setError(true)}
          className={className} // Use external styles
          {...rest}
        ></video>
      ) : (
        <div className={`flex items-center justify-center ${className}`}>
          <PiVideoCameraSlash size={32} />
        </div>
      )}

      {hovered && !error && rest.src && children}

      {allowDownload && hovered && !error && rest.src && (
        <Tooltip title="Download">
          <button
            className="absolute bottom-1 right-1 p-0.5 bg-white/60 backdrop-blur-md rounded-full text-gray-800 hover:bg-white"
            onClick={handleDownload}
            type="button"
          >
            <MdOutlineDownloading size={18} />
          </button>
        </Tooltip>
      )}

      {getVideoFormat(rest.src) && (
        <div className="absolute bottom-1 left-1 bg-black/60 backdrop-blur-md text-white text-xs px-2 py-0.5 rounded-full">
          {getVideoFormat(rest.src)}
        </div>
      )}
    </div>
  );
};

export default Video;

export interface ChatSquareVideoProps extends SmartVideoProps {
  children?: ReactNode;
}

const ChatSquareVideo = (props: ChatSquareVideoProps) => {
  const { className, children, ...rest } = props;
  const defClassName = `w-18 h-18 object-cover object-center`; // same as your image
  const styling = removeDuplicateClasses(`${className} ${defClassName}`);

  return (
    <Video {...rest} className={styling}>
      {children}
    </Video>
  );
};

export { ChatSquareVideo };
