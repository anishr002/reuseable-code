/* eslint-disable @typescript-eslint/no-explicit-any */
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import StepContent from "@mui/material/StepContent";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { Coach_Data_Type } from "../../Types/backend/Coach_Data_Type";
import { CoachCertificate_Type } from "../../Types/backend/CoachCertificate_Type";
import { CoachCredentials_Type } from "../../Types/backend/CoachCredentials_Type";
import { useNotify } from "../../lib/Notify";
import DummyTextField from "../inputFields/DummyTextField";

export interface Step {
  Step: number;
  completed: boolean;
  label: string;
  description: string;
}

interface ProfileStatusProps {
  data: Pick<
    Coach_Data_Type,
    | "name"
    | "image"
    | "Lname"
    | "gender"
    | "emailVerified"
    | "calendarStatus"
    | "approve"
    | "_id"
  >;
  coachCertificateList: CoachCertificate_Type[];
  coachcredentialsList: CoachCredentials_Type[];
  toggleOpenInstructionModal: () => void;
  getStatus: ({ x, y }: { x: number; y: boolean }) => void;
  viewList: boolean;
  toggleViewList: ({ X }: { X: boolean }) => void;
}

const ProfileStatus: React.FC<ProfileStatusProps> = ({
  data,
  coachCertificateList,
  coachcredentialsList,
  toggleOpenInstructionModal,
  getStatus,
  viewList,
  toggleViewList,
}) => {
  const loginUserData = useSelector((state: any) => state.login.userdata);
  const { notifyMe } = useNotify();
  const [steps, setSteps] = useState<Step[]>([
    {
      Step: 1,
      completed: false,
      label: "Add a Profile Picture, and add personal details",
      description: `Once you have created a Coach Profile on the Connect You, you can add your details in the profile, start by adding the profile picture of your choice, and add your personal information.`,
    },
    {
      Step: 2,
      completed: false,
      label: "Complete the Email Verification.",
      description:
        "Verify the email address you have provided while creating this profile.",
    },
    {
      Step: 3,
      completed: false,
      label: "Add your Google Calendar",
      description:
        "Sync your Google calendar with our platform to get updated, notified, and organized.",
    },
    // {
    //   Step: 4,
    //   completed: false,
    //   label: "Add a Username",
    //   description:
    //     "Add your unique username that can help you sign in or get identified on the portal.",
    // },
    // {
    //   Step: 5,
    //   completed: false,
    //   label: "Select your preferred time zone.",
    //   description:
    //     "Choose a time zone of your preference. Note that your time zone will be used to add booking times and available slots for booking your sessions.",
    // },
    // {
    //   Step: 6,
    //   completed: false,
    //   label: "Add a Meeting Link",
    //   description:
    //     "Add a meeting link of your preference, that a coachee can follow to join the session they book with you.",
    // },
    {
      Step: 7,
      completed: false,
      label: "Add Certificates",
      description:
        "Add the certifications you have acquired. These certifications are visible to the public and can be used in advanced filters in the coaches list. At least one certificate is required to get listed in the marketplace.",
    },
    {
      Step: 8,
      completed: false,
      label: "Add Coaching Credentials",
      description:
        "Add your coaching credentials. These credentials are visible to the public and can be used in advanced filters in the coaches list. At least one credential is required to get listed in the marketplace.",
    },
    {
      Step: 9,
      completed: false,
      label: "Get profile approval from the Admin",
      description: `Once you have completed all the steps, you can submit your profile for approval from the admin.`,
    },
  ]);

  const [activeStep, setActiveStep] = useState(0);
  const [completedAll, setCompletedAll] = useState(false);
  const [incomplete, setIncomplete] = useState<Step[] | null>(null);

  const checkProfileCompletionStatus = () => {
    if (!data) {
      setActiveStep(0);
      toggleViewList({ X: false });
      return notifyMe({
        message: "Some Error Occured while geting profile status details",
        severity: "error",
      });
    }
    const updatedSteps = [...steps];
    updatedSteps[0].completed =
      data.image !== "" &&
      data.name !== "" &&
      data.Lname !== "" &&
      data.gender !== ""
        ? true
        : false;
    updatedSteps[1].completed = data.emailVerified === 1;
    updatedSteps[2].completed = data.calendarStatus === 1;
    // updatedSteps[3].completed = data.userName !== "" ; // if uncommented change the index of follwoing to step 6 7 & 8 as required
    // updatedSteps[4].completed = data.timeZone !== "" ; // if uncommented change the index of follwoing to step 6 7 & 8 as required
    // updatedSteps[5].completed = data.zoomMeetingURL !== ""; // if uncommented change the index of follwoing to step 6 7 & 8 as required
    updatedSteps[3].completed = coachCertificateList.length > 0;
    updatedSteps[4].completed = coachcredentialsList.length > 0;
    updatedSteps[5].completed = data.approve === 1;
    setSteps(updatedSteps);
    const allCompleted = updatedSteps.every((step) => step.completed);
    const inComplete = updatedSteps.filter((step) => !step.completed);

    setIncomplete(inComplete);
    setCompletedAll(allCompleted);
    localStorage.setItem("completedAll", `${allCompleted}`);
    const firstIncompleteStep = updatedSteps.findIndex(
      (step) => !step.completed
    );
    setActiveStep(
      firstIncompleteStep === -1 ? steps.length - 1 : firstIncompleteStep
    );
    getStatus({
      x: updatedSteps.filter((a) => a.completed === true).length,
      y: allCompleted,
    });
  };

  useEffect(() => {
    const postStatus = async ({
      coach_id,
      data,
    }: {
      coach_id: string;
      data: Step[];
    }) => {
      try {
        await httpAPI.put(
          `${backendURL}/coach/profile/profile-completion-status-update`,
          { coach_id, data }
        );
      } catch (error) {
        console.log(error);
      }
    };
    const coach_id = loginUserData._id;
    if (incomplete && incomplete?.length > 0) {
      postStatus({ coach_id, data: incomplete });
    }
  }, [incomplete, loginUserData._id]);

  useEffect(() => {
    checkProfileCompletionStatus();
  }, [data]);

  useEffect(() => {
    // Check if modal has already been shown
    const isFirstVisit = localStorage.getItem("isFirstVisit");
    const completedAll = localStorage.getItem("completedAll");
    if (!isFirstVisit) {
      localStorage.setItem("isFirstVisit", "true"); // Mark as shown
    }
    if (!isFirstVisit && completedAll !== "true") {
      toggleOpenInstructionModal();
    }
  }, []);

  return (
    <Paper
      elevation={0}
      sx={{
        width: "100%",
        background: `${viewList ? "white" : "transparent"}`,
        fontFamily: "Quicksand",
        borderRadius: 1,
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          pb: `${viewList ? 2 : 0}`,
          width: "100%",
        }}
      >
        <DummyTextField
          textLabel={
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: "1rem",
                pb: 1,
              }}
            >
              <div className="flex flex-row  items-center justify-start gap-1.5 text-[#013338]  text-[18px] font-medium">
                Profile Details Status
                {!completedAll && (
                  <Typography
                    variant="body1"
                    sx={{
                      borderRadius: "10px",
                      padding: "2px 10px",
                      fontWeight: 500,
                      fontSize: "12px",
                      color: "white",
                      fontFamily: "Quicksand",
                      background: "red",
                    }}
                  >
                    Pending
                  </Typography>
                )}
              </div>
              <button
                onClick={() => toggleViewList({ X: viewList ? false : true })}
              >
                {!viewList ? <ExpandMoreIcon /> : <ExpandLessIcon />}
              </button>
            </Box>
          }
          value={
            viewList ? (
              <div className="flex flex-col gap-4 px-4 py-5">
                <Stepper
                  activeStep={activeStep}
                  orientation="vertical"
                  nonLinear
                >
                  {steps.map((step, index) => (
                    <Step
                      key={step.label}
                      completed={step.completed}
                      onClick={() =>
                        setActiveStep(activeStep === index ? -1 : index)
                      }
                      sx={{
                        cursor: "pointer",
                        ".css-1u4zpwo-MuiSvgIcon-root-MuiStepIcon-root.Mui-completed":
                          {
                            color: "#3aa7a3",
                          },
                        ".css-1u4zpwo-MuiSvgIcon-root-MuiStepIcon-root": {
                          color: "red",
                        },
                        ".css-4ff9q7.Mui-completed": {
                          color: "#3aa7a3",
                        },
                        ".css-4ff9q7.Mui-active ": {
                          color: "red",
                        },
                      }}
                    >
                      <StepLabel
                        optional={
                          index === steps.length - 1 ? (
                            <Typography
                              variant="caption"
                              sx={{ color: "gray", fontFamily: "Quicksand" }}
                            >
                              Final step
                            </Typography>
                          ) : null
                        }
                      >
                        <span
                          style={{
                            color: `${step.completed ? "#3aa7a3" : "red"}`,
                            fontWeight: 600,
                            fontFamily: "Quicksand",
                            background: "#fefefe",
                            padding: "2px 10px",
                            borderRadius: 10,
                          }}
                        >
                          {step.label}
                        </span>
                      </StepLabel>
                      <StepContent>
                        <Typography
                          sx={{
                            fontFamily: "Quicksand",
                            fontSize: "0.8rem",
                            fontWeight: 500,
                            color: "gray",
                            px: 2,
                          }}
                        >
                          {step.description}
                        </Typography>
                      </StepContent>
                    </Step>
                  ))}
                </Stepper>
                {completedAll ? (
                  <Paper elevation={0} sx={{ p: 3, mt: 2, width: "100%" }}>
                    <Typography variant="body2" sx={{ color: "#3aa7a3" }}>
                      All steps completed, congratulations! Your profile has
                      been listed in the coaches section.
                    </Typography>
                  </Paper>
                ) : (
                  <Paper elevation={0} sx={{ p: 3, mt: 2, width: "100%" }}>
                    <Typography
                      variant="body2"
                      sx={{
                        color: "gray",
                        fontSize: "0.85rem",
                        fontFamily: "Quicksand",
                      }}
                    >
                      <em> **</em>Steps mentioned above are required to be
                      completed to get listed in the coaches section of the
                      portal. The profile is not eligible to get listed, untill
                      all the steps are completed.
                    </Typography>
                  </Paper>
                )}
              </div>
            ) : (
              <>
                {completedAll ? (
                  <span className="text-[#3aa7a3]"> All steps Completed</span>
                ) : (
                  <span className="text-[#ebbd33]">
                    Pending {incomplete?.length?.toString()} steps
                  </span>
                )}
              </>
            )
          }
        />
      </Box>
    </Paper>
  );
};

export default ProfileStatus;
