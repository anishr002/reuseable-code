import React, { ReactNode, useState } from "react";
import { PiImageBroken } from "react-icons/pi";
import { MdOutlineDownloading } from "react-icons/md";
import { Tooltip } from "@mui/material";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";

type SmartImageProps = React.ImgHTMLAttributes<HTMLImageElement> & {
  allowDownload?: boolean;
  children?: ReactNode;
  fallback?: ReactNode;
};

const Image = ({
  allowDownload = false,
  children,
  className,
  fallback,
  ...rest
}: SmartImageProps) => {
  const [error, setError] = useState(false);
  const [hovered, setHovered] = useState(false);
  const handleDownload = () => {
    if (rest.src) {
      const link = document.createElement("a");
      link.setAttribute("target", "_blank");
      link.href = rest.src;
      link.download = rest.alt || "image";
      link.click();
    }
  };

  return (
    <div
      className={`relative cursor-pointer inline-block ${className}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {!error ? (
        <img {...rest} onError={() => setError(true)} className={className} />
      ) : fallback ? (
        fallback
      ) : (
        <div
          className={` flex items-center flex-col gap-2 justify-center ${className}`}
        >
          <PiImageBroken size={32} />
          <span className="text-xs font-semibold break-all p-1">
            {rest?.alt || ""}
          </span>
        </div>
      )}

      {hovered && !error && rest.src && children}
      {allowDownload && hovered && !error && rest.src && (
        <Tooltip title="Download">
          <button
            className="absolute bottom-1 right-1 p-0.5 bg-white/60 backdrop-blur-md rounded-full text-gray-800 hover:bg-white"
            onClick={handleDownload}
            type="button"
          >
            <MdOutlineDownloading size={18} />
          </button>
        </Tooltip>
      )}
    </div>
  );
};

export default Image;

export interface ChatSquareImageProps extends SmartImageProps {
  children?: ReactNode;
}
const ChatSquareImage = (props: ChatSquareImageProps) => {
  const { className, children, ...rest } = props;
  const defClassName = `w-18 h-18 object-cover object-center bg-[#013338]`;
  const styling = removeDuplicateClasses(`${className} ${defClassName}`);
  return (
    <Image {...rest} className={styling}>
      {children}
    </Image>
  );
};

export { ChatSquareImage };

/*
const removeDuplicateClasses = (classStr: string) => {
  return Array.from(new Set(classStr.split(" "))).join(" ");
};

export default removeDuplicateClasses;

*/
