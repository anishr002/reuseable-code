/* eslint-disable @typescript-eslint/no-explicit-any */
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import React from "react";
import { NavLink } from "react-router-dom";

import useScreenSize from "../hooks/useScreenSize";
import LoggedUserNavigationItem from "./LoggedUserNavigationItem";
import CartItemsCount from "./CartItemsCount";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";

interface MainNavigationProps {
  links: { name: string; link: string }[];
  helper: () => void;
}

const MainNavigation: React.FC<MainNavigationProps> = ({ links, helper }) => {
  const { isMobile, isTab } = useScreenSize();
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  return (
    <>
      {links.map((link, i) => {
        if (link.link === "/login") {
          return (
            <React.Fragment key={`nav-link-${i}-header-${link.name}`}>
              {!(isMobile || isTab) && (
                <LoggedUserNavigationItem helper={helper} i={i} link={link} />
              )}
            </React.Fragment>
          );
        }
        return (
          <NavLink
            key={`navigation-link-${i}-header-${link.name}`}
            className={` w-fit text-white   hover:text-[#EBBD33] transition duration-300 `}
            to={link.link}
          >
            <span onClick={() => helper()}>{link.name}</span>
          </NavLink>
        );
      })}
      {Object.keys(loginUserData).length > 0 ? (
        loginUserData?.userType === "coachee" && (
          <NavLink
            onClick={() => helper()}
            to="/cart"
            className="justify-center items-center w-8 h-8 rounded-full cursor-pointer relative"
          >
            <ShoppingCartIcon sx={{ color: "white", width: 22, height: 22 }} />
            <CartItemsCount />
          </NavLink>
        )
      ) : (
        <NavLink
          onClick={() => helper()}
          to="/cart"
          className="justify-center items-center w-8 h-8 rounded-full cursor-pointer relative"
        >
          <ShoppingCartIcon sx={{ color: "white", width: 22, height: 22 }} />
          <CartItemsCount />
        </NavLink>
      )}
    </>
  );
};

export default MainNavigation;
