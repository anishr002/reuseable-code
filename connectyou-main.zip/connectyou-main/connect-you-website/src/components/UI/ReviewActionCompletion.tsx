import { Avatar, Rating } from "@mui/material";
import moment from "moment";
import backendURL from "../../util/AxiosAPI";
import { ReactNode, useEffect, useState } from "react";
import MenuButton, { MenuOption } from "../buttons/MenuButton";
import Paragraph from "./Paragraph";

interface ReviewData {
  _id: string;
  remarks: string;
  ratingNumber: number;
  title: string;
  createdAt: string;
  updatedAt: string;
  userDetails: {
    name: string;
    image: string;
    lastName?: string;
  };
}

const ReviewActionCompletion = ({
  reveiwData,
  showUserInfo = true,
  showActions = true,
  menuOptions,
  children,
}: {
  reveiwData: ReviewData;
  showUserInfo?: boolean;
  showActions?: boolean;
  menuOptions?: MenuOption[];
  children?: ReactNode;
}) => {
  const [isEdited, setIsEdited] = useState(false);
  useEffect(() => {
    setIsEdited(reveiwData.createdAt != reveiwData.updatedAt);
    // console.log(
    //   "createdAt",
    //   reveiwData.createdAt,
    //   "updatedAt",
    //   reveiwData.updatedAt
    // );
  }, [reveiwData]);

  const formattedDate = moment(
    reveiwData.updatedAt || reveiwData.createdAt
  ).format("DD MMMM YYYY hh:mm A");

  return (
    <div className="flex w-full flex-col border border-[#3aa7a3] rounded-2xl p-4 shadow-md relative">
      <div className="flex-1 items-start flex flex-col justify-start ">
        <div className="flex flex-row ">
          {showUserInfo && (
            <Avatar
              src={`${backendURL}/usersProfile/${reveiwData.userDetails?.image}`}
              alt={reveiwData.userDetails?.name}
              sx={{
                width: 56,
                height: 56,
                bgcolor: "#013338",
                fontSize: 18,
                fontWeight: 600,
              }}
            />
          )}
          <div className=" pl-4 flex flex-col items-start  ">
            {showUserInfo && (
              <p className="text-lg text-[#3aa7a3] font-medium">
                {`${reveiwData.userDetails?.name} ${reveiwData.userDetails?.lastName}`}
              </p>
            )}
            <span className="text-[#013338] text-xs">
              {formattedDate} {isEdited && `( Edited )`}
            </span>
            <Rating
              value={reveiwData.ratingNumber}
              precision={0.5}
              readOnly
              sx={{
                color: "#ebbd33",
              }}
            />
          </div>
        </div>
        <h3 className="text-md font-semibold text-[#013338] mb-1">
          {reveiwData.title}
        </h3>
        <div className="text-sm text-left text-[#444] mb-2 w-full text-pretty ">
          <Paragraph lines={3}>
            {reveiwData.remarks.toString().trim()}
          </Paragraph>
        </div>
      </div>
      {showActions && menuOptions && (
        <div className="absolute top-2 right-2">
          <MenuButton options={menuOptions} sizeVariant="sm"></MenuButton>
        </div>
      )}
      {children}
    </div>
  );
};

export default ReviewActionCompletion;
