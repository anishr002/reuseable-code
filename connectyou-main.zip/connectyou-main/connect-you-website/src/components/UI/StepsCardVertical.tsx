import React, { ReactNode } from "react";
import "../../styles/StepsCardVert.css";
interface StepsCardVerticalProps {
  step: { heading: string; description: string; image: string };
  stepTitle: string | ReactNode;
  description: ReactNode;
}
const StepsCardVertical: React.FC<StepsCardVerticalProps> = ({
  step,
  stepTitle,
  description,
}) => {
  return (
    <>
      <div className="   flex  w-12/12 mx-auto my-6 xl:my-0 flex-col justify-center items-center h-full col-span-12 sm:col-span-6 lg:col-span-4 relative bg-white rounded-[20px] shadow-lg">
        {stepTitle}
        <div className="w-full overflow-hidden h-auto rounded-[20px]">
          <img
            src={step.image}
            alt="step image"
            className="object-cover rounded-[20px] w-full h-full hover:scale-[1.02] cursor-pointer"
          />
        </div>
        <div className="description cursor-pointer rounded-b-[20px] flex-1 px-5 md:px-8 lg:px-10 w-full flex flex-col justify-start items-center text-center gap-4 py-4 md:pt-8 md:pb-10 xl:pt-10 xl:pb-14">
          {description}
        </div>
      </div>
    </>
  );
};

export default StepsCardVertical;
