import ClearIcon from "@mui/icons-material/Clear";
import SearchIcon from "@mui/icons-material/Search";
import { IconButton, InputAdornment, TextField } from "@mui/material";
import { useState } from "react";

const CharSearchField = ({
  handleSerach,
  placeHolder = "Search by Coach's name",
}: {
  handleSerach: (str: string) => void;
  placeHolder?: string;
}) => {
  const [searchName, setSearchName] = useState<string>("");

  return (
    <>
      <div className="flex justify-center items-center gap-3 w-fit">
        <div className="w-full md:max-w-96">
          <TextField
            id="outlined-search"
            placeholder={placeHolder}
            variant="outlined"
            fullWidth
            size="small"
            value={searchName}
            onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
              const name = event.target.value;
              setSearchName(name);
              handleSerach(name);
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
              endAdornment: searchName.length > 0 && (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => {
                      handleSerach("");
                      setSearchName("");
                    }}
                  >
                    <ClearIcon sx={{ color: "red" }} />
                  </IconButton>
                </InputAdornment>
              ),
            }}
            sx={{
              "& .MuiOutlinedInput-root": {
                borderRadius: "30px",
                backgroundColor: "#fff",
                boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
              },
              "& .MuiOutlinedInput-input": {
                padding: "10px 14px",
              },
              "& .MuiInputLabel-root": {
                top: "-4px",
                color: "#666",
              },
            }}
          />
        </div>
      </div>
    </>
  );
};

export default CharSearchField;
