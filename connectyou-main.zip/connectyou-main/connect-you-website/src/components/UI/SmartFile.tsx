import React, { ReactNode, useState } from "react";
import { Tooltip } from "@mui/material";
import { AiOutlineFile } from "react-icons/ai";
import { GrDocumentTxt } from "react-icons/gr";
import { MdOutlineDownloading } from "react-icons/md";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";
import { FaFilePdf } from "react-icons/fa6";
import { GrDocumentText, GrDocumentCsv, GrDocumentZip } from "react-icons/gr";
import { BsFiletypeXls, BsFiletypeXlsx } from "react-icons/bs";

export type SmartFileProps = React.HTMLAttributes<HTMLDivElement> & {
  src: string; // URL of the file
  filename: string; // Name to display
  maxLength?: number; // Max characters to show
  allowPreview?: boolean;
  allowDownload?: boolean;
  children?: ReactNode;
  flexDirection?: "row" | "row-reverse" | "column" | "column-reverse";
};

const getFileIcon = (extension: string) => {
  switch (extension.toLowerCase()) {
    case "pdf":
      return <FaFilePdf size={20} />;
    case "doc":
    case "docx":
      return <GrDocumentText size={20} />;
    case "txt":
      return <GrDocumentTxt size={20} />;
    case "csv":
      return <GrDocumentCsv size={20} />;
    case "zip":
      return <GrDocumentZip size={20} />;
    case "xls":
      return <BsFiletypeXls size={20} />;
    case "xlsx":
      return <BsFiletypeXlsx size={20} />;
    default:
      return <AiOutlineFile size={20} />;
  }
};

const SmartFile = ({
  src,
  filename,
  maxLength = 20,
  className,
  children,
  allowPreview = false,
  allowDownload = false,
  flexDirection = "row",
  ...rest
}: SmartFileProps) => {
  const [hovered, setHovered] = useState(false);

  const openFile = () => {
    if (allowPreview) {
      window.open(src, "_blank");
    }
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation(); // prevent opening in new tab
    const link = document.createElement("a");
    link.href = src;
    link.download = filename;
    link.click();
  };

  const getExtension = (name: string) => {
    const parts = name?.split(".");
    return parts?.length > 1 ? parts?.pop() || "" : "";
  };

  const clippedName =
    filename?.length > maxLength
      ? `${filename.slice(0, maxLength)}...${filename.slice(
          filename.length - 2,
          filename.length
        )}.${getExtension(filename)}`
      : filename;

  const extension = getExtension(filename);

  const styling = removeDuplicateClasses(
    `relative bg-[#013338] text-white px-3 py-2 rounded-md flex items-center gap-2 cursor-pointer ${className}`
  );

  return (
    <div
      className={styling}
      onClick={openFile}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      {...rest}
    >
      <Tooltip title={allowPreview ? "Click to preview" : ""}>
        <div
          style={{
            flexDirection: flexDirection,
          }}
          className="flex items-center justify-center"
        >
          {getFileIcon(extension)}
          <span className="ml-1 text-sm font-medium">{clippedName}</span>
        </div>
      </Tooltip>
      {hovered && children}
      {hovered && allowDownload && (
        <Tooltip title="Download">
          <button
            className="absolute bottom-1 right-1 p-0.5 bg-white/60 backdrop-blur-md rounded-full text-gray-800 hover:bg-white"
            onClick={handleDownload}
            type="button"
          >
            <MdOutlineDownloading size={18} />
          </button>
        </Tooltip>
      )}
    </div>
  );
};

export { SmartFile };
