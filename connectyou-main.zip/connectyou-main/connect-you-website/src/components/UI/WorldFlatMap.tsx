/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { ComposableMap, Geographies, Geography } from "react-simple-maps";
import useScreenSize from "../hooks/useScreenSize";
import { FaUser } from "react-icons/fa";
import useDeviceCheck from "../hooks/useCheckDevice";

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

interface GeoFeature {
  rsmKey: string;
  type: string;
  properties: {
    name: string;
  };
  geometry: any;
  id: string;
}

interface WorldFlatMapProps {
  countryName?: string;
  height?: string;
}

const WorldFlatMap: React.FC<WorldFlatMapProps> = ({
  countryName = "Canada",
  height = "450px",
}) => {
  const { isMobile } = useScreenSize();
  const [hoveredCountry, setHoveredCountry] = useState<string | null>(null);
  const { isIOS } = useDeviceCheck();
  return (
    <div
      className="w-full bg-[#013338] flex justify-center items-center h-full min-h-0 relative"
      style={{
        height: isMobile || isIOS ? "235px" : height,
      }}
    >
      {hoveredCountry && (
        <div
          className="absolute z-10   px-3 py-1 rounded-md shadow-lg text-sm font-medium"
          style={{
            bottom: "10px",
            left: "50%",
            transform: "translateX(-50%)",
            color:
              hoveredCountry === countryName.trim() ||
              hoveredCountry.includes(countryName.trim())
                ? "white"
                : "#013338",
            background:
              hoveredCountry === countryName.trim() ||
              hoveredCountry.includes(countryName.trim())
                ? "#ebbd33c9"
                : "#ffffffbb",
          }}
        >
          {(hoveredCountry === countryName.trim() ||
            hoveredCountry.includes(countryName.trim())) && (
            <>
              <FaUser className="text-white inline pr-2 text-[18px]" />
            </>
          )}{" "}
          {hoveredCountry}
        </div>
      )}
      <ComposableMap
        className="h-fit p-0 m-0"
        height={450}
        projection="geoNaturalEarth1"
        projectionConfig={{
          scale: isMobile || isIOS ? 210 : 170,
          center: [15, 12],
        }}
      >
        <Geographies geography={geoUrl}>
          {({ geographies }: { geographies: GeoFeature[] }) =>
            geographies
              .filter((geo) => geo.properties.name !== "Antarctica")
              .map((geo: GeoFeature) => {
                const isHighlighted =
                  geo.properties.name === countryName.trim() ||
                  geo.properties.name.includes(countryName.trim());
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    fill={isHighlighted ? "#ebbd33" : "#3aa7a3"}
                    stroke="#013338"
                    strokeWidth={0.5}
                    onMouseEnter={() => setHoveredCountry(geo.properties.name)}
                    onMouseLeave={() => setHoveredCountry(null)}
                    style={{
                      default: { outline: "none" },
                      hover: {
                        fill: isHighlighted ? "#ebbd33" : "#2a7572",
                        outline: "none",
                        cursor: "pointer",
                      },
                      pressed: {
                        fill: isHighlighted ? "#ebbd33" : "#2a7572",
                        outline: "none",
                      },
                    }}
                  />
                );
              })
          }
        </Geographies>
      </ComposableMap>
    </div>
  );
};

export default WorldFlatMap;
