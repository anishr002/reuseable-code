/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-expressions */
import { RiDeleteBin6Line } from "react-icons/ri";
import React, { useEffect, useRef, useState } from "react";
import Coaching_session_Type from "../../Types/backend/Coaching_session_Type";
import CustomSwitch from "../buttons/CustomSwitch";
import {
  FormControlLabel,
  FormGroup,
  IconButton,
  Menu,
  MenuItem,
  Tooltip,
} from "@mui/material";
import MundialHeadingText from "./MundialHeadingText";
import { BsThreeDotsVertical } from "react-icons/bs";
import { MdOutlineModeEdit } from "react-icons/md";
import ModalCloseButton from "../buttons/ModalCloseButton";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";
import AddNewCoachingSessionModal from "../../pages/dashboard-pages/coach/coaching-sessions/AddNewCoachingSessionModal";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useNotify } from "../../lib/Notify";
import customAlert from "../../lib/swalExtentions";
import SessionCardLoadingSkeleton from "../Skeletons/SessionCardLoadingSkeleton";

interface CoachingSessionCardProps
  extends React.HTMLAttributes<HTMLDivElement> {
  session_id: string;
  triggerParent?: () => void;
  allowDeletion?: boolean;
}
const CoachingSessionCard: React.FC<CoachingSessionCardProps> = (props) => {
  const [loading, setLoading] = useState<boolean>(false);
  const { notifyMe } = useNotify();
  const { session_id, triggerParent, allowDeletion = true, ...rest } = props;
  const [coachingSession, setCoachingSession] =
    useState<Coaching_session_Type | null>(null);
  const [refresh, setRefresh] = useState<boolean>(false);
  const Refresh = () => setRefresh((prev) => !prev);

  useEffect(() => {
    const fetch = async () => {
      try {
        setLoading(true);
        const url = `${backendURL}/api-v2/auth/coach/sessions/session-details/${session_id}`;
        const response = await httpAPI.get(url);
        // console.log({ response });
        if (response.status === 200) {
          return setCoachingSession(response.data.data);
        }
      } catch (error) {
        console.error("Error accepting:", error);
      } finally {
        setLoading(false);
      }
    };
    session_id && fetch();
  }, [refresh, session_id]);

  const descriptionRef = useRef<HTMLParagraphElement | null>(null);
  const [addSeeMore, setAddSeeMore] = useState<boolean>(false);
  useEffect(() => {
    if (descriptionRef.current) {
      const lineHeight = parseFloat(
        getComputedStyle(descriptionRef.current).lineHeight
      );
      const maxHeight = lineHeight * 3;
      if (descriptionRef.current.scrollHeight > maxHeight) {
        setAddSeeMore(true);
      }
    }
  }, [descriptionRef, coachingSession]);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [openMenu, setOpenMenu] = useState<boolean>(false);
  const [openDes, setOpenDes] = useState<boolean>(false);
  const [openEdit, setOpenEdit] = useState<boolean>(false);
  const handleClick = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    setAnchorEl(event.currentTarget);
    setOpenMenu(true);
  };
  const handleClose = () => {
    setAnchorEl(null);
    setOpenMenu(false);
  };
  const handleViewDetails = () => {
    setOpenDes(true);
  };
  const handleEdit = async () => {
    setLoading(true);
    setOpenEdit(true);
  };

  const handleDelete = (id: string) => {
    setLoading(true);
    customAlert
      .fire({
        title: "Are you sure?",
        text: `You want to delete it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, delete It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI.get(
              `${backendURL}/coach/session/session-delete/${id.trim()}`
            );
            if (response.status === 200) {
              Refresh();
              triggerParent?.();
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            customAlert.fire({
              title: `Delete!`,
              text: `Session delete successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
          }
        } else {
          setLoading(false);
        }
      });
  };

  const handleUpdateStatus = async (status: boolean) => {
    try {
      setLoading(true); // Ensure loading state is handled
      const url = `${backendURL}/api-v2/auth/coach/sessions/session-toggle-status/${session_id.trim()}`;
      const response = await httpAPI.put(url, { status });
      // console.log({ response: response.data });
      if (response.status === 200) {
        Refresh();
      }
    } catch (error) {
      console.log(error);
      notifyMe({
        message: "There was some problem while updating this session",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {coachingSession && (
        <AddNewCoachingSessionModal
          open={openEdit}
          title={`Edit ${coachingSession.title || "Session"}`}
          onClose={() => {
            setLoading(false);
            setOpenEdit(false);
          }}
          next={async ({
            data,
          }: {
            data: {
              title: string;
              price: number;
              description: string;
              duration: number;
            };
          }) => {
            const apidata: any = data;
            apidata.sessionId = session_id;
            try {
              setLoading(true);
              const response = await httpAPI.post(
                `${backendURL}/coach/session/session-edit`,
                apidata
              );
              if (response.status === 200) {
                setOpenEdit(false);
                Refresh();
                notifyMe({
                  message: "Session updated successfully",
                  severity: "success",
                });
                return setLoading(false);
              }
            } catch (error: any) {
              console.log("submit error", error);
              if (
                error.response.status === 500 ||
                error.response.status === 400 ||
                error.response.status === 401 ||
                error.response.status === 403 ||
                error.response.status === 404 ||
                error.response.status === 409
              ) {
                notifyMe({
                  message: error.response.data.message
                    ? error.response.data.message
                    : "Something went wrong",
                  severity: "error",
                });

                return setLoading(false);
              }
            } finally {
              setLoading(false);
            }
          }}
          def={{
            session: {
              description: coachingSession.description,
              duration: coachingSession.duration,
              price: coachingSession.price,
              title: coachingSession.title,
            },
          }}
        />
      )}
      <Menu
        open={openMenu}
        onClose={() => handleClose()}
        anchorEl={anchorEl}
        sx={{ minWidth: "fit-content" }}
      >
        <div className="div flex flex-col justify-start items-start bg-white h-fit pt-6 pb-3 rounded-[10px]">
          <MenuItem
            sx={{ width: 0, p: 0, display: "none" }}
            onClick={handleClose}
          >
            <FormGroup
              sx={{ width: "100%", justifyContent: "space-between", py: 0 }}
            >
              <FormControlLabel
                control={
                  <CustomSwitch
                    // checked={sessionStatus}
                    checked={coachingSession?.status}
                    onChange={(event) => {
                      const newStatus = event.target.checked;
                      handleUpdateStatus(newStatus);
                    }}
                  />
                }
                label={
                  <span
                    style={{
                      color: coachingSession?.status ? "#3aa7a3" : "red",
                    }}
                    className={` font-semibold text-[12px] uppercase leading-0 py-2`}
                  >
                    {coachingSession?.status === true ? "Enabled" : "disabled"}
                  </span>
                }
                labelPlacement="start"
                sx={{
                  gap: "15px",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              />
            </FormGroup>
          </MenuItem>
          <ModalCloseButton onClick={handleClose} sx={{ fontSize: "18px" }} />

          <MenuItem sx={{ width: 200, p: 0 }} onClick={handleClose}>
            <button
              type="button"
              className="text-[#013338] px-4 py-2 cursor-pointer w-full h-full hover:text-[#ebbd33] font-medium flex flex-row justify-start items-center gap-5 text-[14px]"
              onClick={() => handleEdit()}
            >
              <div>
                <MdOutlineModeEdit />
              </div>
              <Tooltip
                title={`
                  Edit ${coachingSession?.title} `}
              >
                <span className="line-clamp-1 text-ellipsis max-w-full">
                  Edit {coachingSession?.title}
                </span>
              </Tooltip>
            </button>
          </MenuItem>

          <Tooltip
            title={
              allowDeletion ? "" : "You must have atleast one session added"
            }
          >
            <MenuItem sx={{ width: 200, p: 0 }} onClick={handleClose}>
              <button
                type="button"
                disabled={!allowDeletion}
                className="text-[#013338] px-4 py-2 cursor-pointer w-full h-full hover:text-[#ebbd33] font-medium flex flex-row justify-start items-center gap-5 text-[14px]"
                onClick={() => handleDelete(session_id)}
              >
                <div>
                  <RiDeleteBin6Line />
                </div>
                <span>Delete</span>
              </button>
            </MenuItem>
          </Tooltip>
        </div>
      </Menu>
      {loading ? (
        <SessionCardLoadingSkeleton theme="loading" />
      ) : coachingSession ? (
        <div
          className="bg-[#ffffff] min-h-[225px] rounded-[5px] px-5 py-7 flex flex-col w-full space-y-3.5 relative"
          {...rest}
        >
          <div className="w-full grid grid-cols-1 md:grid-cols-12  gap-x-[10px] gap-y-[10px]">
            <div className="col-span-12 flex flex-row justify-between items-start w-full">
              <div className="flex  flex-1 items-start justify-start ">
                <MundialHeadingText variant="darksea" sizeVariant="sm">
                  {coachingSession?.title || "Session Title"}
                </MundialHeadingText>
              </div>

              <div className="w-fit px-2 flex flex-row justify-end items-start text-[#3aa7a3]">
                {coachingSession.type === 1 ? (
                  <FormGroup>
                    <FormControlLabel
                      control={
                        <CustomSwitch
                          // checked={sessionStatus}
                          checked={coachingSession?.status}
                          onChange={(event) => {
                            const newStatus = event.target.checked;
                            handleUpdateStatus(newStatus);
                          }}
                        />
                      }
                      label={
                        <span
                          style={{
                            color: coachingSession?.status ? "#3aa7a3" : "red",
                          }}
                          className={` font-semibold text-[12px] uppercase leading-0 py-2`}
                        >
                          {coachingSession?.status === true
                            ? "Enabled"
                            : "disabled"}
                        </span>
                      }
                      labelPlacement="start"
                      sx={{
                        gap: "10px",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    />
                  </FormGroup>
                ) : (
                  <>
                    <div
                      onClick={handleClick}
                      className=" flex justify-end items-center"
                    >
                      <IconButton
                        size="small"
                        sx={{
                          color: openMenu ? "#3aa7a3" : "#013338",
                          p: 0,
                        }}
                      >
                        <BsThreeDotsVertical className="text-inherit" />
                      </IconButton>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="col-span-12 flex flex-row w-full justify-start items-center gap-10 text-[#3aa7a3] text-[15px] font-bold">
              <div className="">{coachingSession?.duration || 60} mins</div>
              <div className="">
                $ {(coachingSession?.price || 0.0).toFixed(2)}
              </div>
            </div>
          </div>
          <div className="col-span-12  w-full flex flex-col gap-3 items-start justify-start text-[#013338] text-[15px] font-normal">
            <p ref={descriptionRef} className={`line-clamp-3`}>
              {coachingSession?.description ||
                "A description of the session goal and content etc. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt aliqua.A description of the session goal and content etc. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt aliqua. "}
            </p>
            {addSeeMore && (
              <button
                type="button"
                onClick={handleViewDetails}
                className="text-[#3aa7a3] font-normal text-xs cursor-pointer hover:text-[#ebbd33] hover:font-medium"
              >
                See More
              </button>
            )}
          </div>
        </div>
      ) : (
        <>
          <SessionCardLoadingSkeleton theme="error" />
        </>
      )}
      {coachingSession && (
        <CustomModalWrapper
          open={openDes}
          onClose={() => setOpenDes(false)}
          title={`${coachingSession?.title || "Session Title"}`}
          backdropClose={true}
          escapeClose={true}
        >
          <div className="flex flex-col text-center items-center justify-center">
            <div className="col-span-12 flex flex-col items-center justify-between p-[30px] space-y-6">
              <div
                className={`flex-1 text-center overflow-hidden text-[#013338] font-medium text-[16px] md:text-[18px]`}
              >
                <p>
                  {coachingSession?.description ||
                    "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus dolores reprehenderit inventore ullam aspernatur voluptate placeat esse quisquam fugiat deserunt."}
                </p>
              </div>
            </div>

            <div className="col-span-12 -order-1  flex flex-row items-center justify-end gap-5 w-full ">
              <div
                className={`h-[45px] font-bold rounded-[100px] flex items-center justify-center leading-normal px-5 min-w-fit border  ${
                  coachingSession?.type === 1
                    ? "border-[#3aa7a3] text-[#3aa7a3]"
                    : "bg-[#3aa7a3] text-white border-transparent"
                } `}
              >
                {coachingSession?.duration || 30} min
              </div>
              <div
                className={`h-[45px] font-bold rounded-[100px] flex items-center justify-center leading-normal px-5 min-w-fit border  ${
                  coachingSession?.type === 1
                    ? "border-[#3aa7a3] text-[#3aa7a3]"
                    : "bg-[#3aa7a3] text-white border-transparent"
                } `}
              >
                {coachingSession?.type === 1
                  ? "Free"
                  : `${coachingSession?.currency.symbol || "$"} ${
                      coachingSession?.price || "00.00"
                    }`}
              </div>
            </div>
          </div>
        </CustomModalWrapper>
      )}
    </>
  );
};

export default CoachingSessionCard;
