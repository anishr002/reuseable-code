import React from "react";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";

interface Props extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: "seablue" | "darksea" | "yellow" | "black" | "white" | "danger";
  sizeVariant?: "lg" | "md" | "sm" | "xs" | "xxs";
}

const MundialHeadingText: React.FC<Props> = ({
  children,
  className = "",
  variant = "darksea",
  sizeVariant = "lg",
  ...rest
}) => {
  const returnSize = () => {
    switch (sizeVariant) {
      case "lg":
        return "text-[24px] md:text-[32px]";
      case "md":
        return "text-[20px] md:text-[24px]";
      case "sm":
        return "text-[16px] md:text-[20px]";
      case "xs":
        return "text-[14px] md:text-[18px]";
      case "xxs":
        return "text-[12px] md:text-[14px]";
      default:
        return "text-[12px] md:text-[16px]";
    }
  };

  const baseClasses = ` font-mundial font-bold text-[#3aa7a3] uppercase ${returnSize()} `;
  const uniqueClassName = removeDuplicateClasses(
    ` ${className} ${baseClasses}`
  );
  const returnColor = () => {
    switch (variant) {
      case "seablue":
        return "#3aa7a3";
      case "darksea":
        return "#013338";
      case "yellow":
        return "#ebbd33";
      case "black":
        return "#000000";
      case "white":
        return "#FFFFFF";
      case "danger":
        return "#FF0000";
      default:
        return "#3aa7a3";
    }
  };

  return (
    <div
      style={{ color: variant ? returnColor() : undefined }}
      {...rest}
      className={uniqueClassName}
    >
      {children}
    </div>
  );
};

export default MundialHeadingText;
