import React from "react";
import Warning from "./Warning";
import SessionTimeline from "./SessionTimeline";
import BookedSession_TImeline_Type from "../../Types/backend/BookedSession_TImeline_Type";

interface SessionOutcomeProps {
  status: number; //0 for pending , 1 for completed , 2 for cancelled, and 3 or incomplete
  commencingDate: string;
  timeline: BookedSession_TImeline_Type[];
}
type Status = () => {
  text: string;
  variant: "red" | "yellow" | "seagreen" | undefined;
};
const SessionOutcome: React.FC<SessionOutcomeProps> = ({
  status,
  timeline,
}) => {
  const Status: Status = () => {
    switch (status) {
      case 0:
        return {
          variant: "yellow",
          text: "Session is Pending ",
        };
      case 1:
        return {
          variant: "seagreen",
          text: "Session has been completed",
        };
      case 2:
        return {
          variant: "red",
          text: "Session has been cancelled",
        };
      case 3:
        return {
          variant: "red",
          text: "Session has been marked as incomplete",
        };
      default:
        return {
          variant: "yellow",
          text: "Session is Pending",
        };
    }
  };
  return (
    <div className=" flex flex-col  flex-1 space-y-2 w-full  justify-start items-start">
      <div className="w-full">
        <Warning variant={Status().variant}>
          <div className="w-full flex justify-between items-center">
            {Status().text}
          </div>
        </Warning>
      </div>
      <SessionTimeline timeline={timeline} />
    </div>
  );
};

export default SessionOutcome;
