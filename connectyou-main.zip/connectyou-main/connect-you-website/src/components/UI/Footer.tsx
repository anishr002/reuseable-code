import { Button, Menu, MenuItem } from "@mui/material";
import Logo from "/loginLogo.png";
import EmailIcon from "@mui/icons-material/Email";
import CallIcon from "@mui/icons-material/Call";
import { NavLink } from "react-router-dom";
import navigationLinkOptions from "../../Options/navigationLinkOptions";
import {
  FaFacebook,
  FaInstagram,
  FaLinkedin,
  FaPinterest,
  FaRegCopyright,
  FaYoutube,
} from "react-icons/fa";
import { FaX } from "react-icons/fa6";
import WebsitelogoLink from "./WebsitelogoLink";
import React from "react";

const Footer = () => {
  const [openPopper, setopenPopper] = React.useState<boolean>(false);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setopenPopper((previousOpen) => !previousOpen);
  };
  const handleClickAway = () => {
    setopenPopper(false);
  };

  return (
    <>
      <div className="">
        <WebsitelogoLink />
      </div>
      <div className="flex flex-1 font-[500] text-md flex-col md:flex-row justify-center md:items-center  gap-6 md:gap-2 lg:gap-6 capitalize">
        {navigationLinkOptions.footer.map((link, i) => {
          return (
            <NavLink
              key={`navigation-link-${i}-header-${link.name}`}
              className={` w-fit text-white   hover:text-[#EBBD33] transition duration-300 `}
              to={link.link}
            >
              <span>{link.name}</span>
            </NavLink>
          );
        })}
        <button
          type="button"
          onClick={(e) => {
            handleClick(e);
          }}
          className={`cursor-pointer w-fit text-white   hover:text-[#EBBD33] transition duration-300 order-[1]`}
        >
          Our Policies
        </button>
        <Menu open={openPopper} anchorEl={anchorEl} onClose={handleClickAway}>
          <div className="flex flex-col bg-white">
            {navigationLinkOptions.policies.map((link, i) => (
              <NavLink
                key={`navigation-link-${i}-policies-${link.name}`}
                className={` w-fit text-[#013338]  hover:text-[#EBBD33] transition duration-300 order-[${i}]`}
                to={link.link}
              >
                <MenuItem onClick={handleClickAway}>
                  <span>{link.name}</span>
                </MenuItem>
              </NavLink>
            ))}
          </div>
        </Menu>
      </div>
      <div className="text-white font-medium text-xs sm:text-sm">
        ConnectYou 2025
      </div>
      <div className="hidden flex-col w-full  pt-10 gap-3 pb-5 text-white">
        <div className="flex justify-between w-full flex-col md:flex-row gap-5 md:gap-0">
          <div className=" flex flex-col gap-8 w-full md:w-96">
            <div className="logo flex items-center">
              <NavLink to="/">
                <img src={Logo} alt="" className="w-52 object-contain" />
              </NavLink>
            </div>
            <div className="flex">
              <p className="flex text-base  font-medium">
                It is a long established fact that a reader will be distracted
                by the readable content of a page when looking at its layout.
                The point of using making it look like readable English.
              </p>
            </div>
            <div className="flex ">
              <div className="flex flex-wrap gap-3 ">
                <span className="text-white">
                  <NavLink to={`/coach`}>
                    <Button
                      variant="outlined"
                      sx={{
                        color: "white",
                        backgroundColor: "#ebbd33",
                        borderColor: "#ebbd33",
                        minWidth: "10.3rem",
                        borderRadius: "20px",
                        fontFamily: "Quicksand",
                        "&:hover": {
                          borderColor: "white",
                          backgroundColor: "white",
                          color: "#ebbd33",
                        },
                      }}
                    >
                      Find a Coach
                    </Button>
                  </NavLink>
                </span>
                <span className="text-white">
                  <NavLink to={`/signup-coach`}>
                    <Button
                      variant="outlined"
                      sx={{
                        color: "white",
                        backgroundColor: "#3aa7a3",
                        borderColor: "#3aa7a3",
                        borderRadius: "20px",
                        fontFamily: "Quicksand",
                        "&:hover": {
                          borderColor: "white",
                          backgroundColor: "white",
                          color: "#3aa7a3",
                        },
                      }}
                    >
                      Become a Coach
                    </Button>
                  </NavLink>
                </span>
              </div>
            </div>
          </div>
          <div className=" flex flex-col gap-3">
            <div className="flex">
              <p className="text-[#ebbd33] font-semibold text-xl">
                Quick Links
              </p>
            </div>
            <div className="flex flex-col gap-2 text-base font-medium">
              {navigationLinkOptions.footer.map((link, i) => (
                <p
                  key={`footer-main-nav-links-item-${i}`}
                  className=" hover:font-medium"
                >
                  <NavLink
                    to={link.link}
                    className="hover:text-[#ebbd33] hover:font-semibold"
                  >
                    {link.name}
                  </NavLink>
                </p>
              ))}
            </div>
          </div>
          <div className=" flex flex-col gap-3">
            <div className="flex pr-4">
              <p className="text-[#ebbd33] font-semibold text-xl">
                Our Policies
              </p>
            </div>
            <div className="flex flex-col gap-2 text-base font-medium">
              {navigationLinkOptions.policies.map((link, i) => (
                <div
                  key={`footer-policies-link-items-${i}`}
                  className=" hover:font-medium"
                >
                  <NavLink
                    to={link.link}
                    className="hover:text-[#ebbd33] hover:font-semibold capitalize "
                  >
                    {link.name}
                  </NavLink>
                </div>
              ))}
            </div>
          </div>
          <div className=" flex flex-col gap-3 text-base font-medium">
            <div className="flex">
              <NavLink
                to={"/get-im-touch"}
                className="text-[#ebbd33] font-semibold text-xl"
              >
                Get In Touch
              </NavLink>
            </div>
            <div className="flex flex-col gap-2">
              <p className="">
                <NavLink
                  to="/get-in-touch"
                  className="hover:text-[#ebbd33] hover:font-semibold"
                >
                  Contact Us
                </NavLink>
              </p>
              <p className="">
                <a
                  href="mailto:support@connectyou.com"
                  className="flex flex-row justify-start gap-2 items-center hover:text-[#ebbd33]"
                >
                  <EmailIcon sx={{ color: "#ebbd33", fontSize: "1.2rem" }} />
                  support@connectyou.com
                </a>
              </p>
              <p className="">
                <a
                  href="tel:+1-877-435-1455"
                  className="flex flex-row justify-start gap-2 items-center hover:text-[#ebbd33]"
                >
                  <CallIcon sx={{ color: "#ebbd33", fontSize: "1.2rem" }} />
                  +1-877-435-1455
                </a>
              </p>
            </div>
          </div>
        </div>
        <div className="flex gap-3 w-full justify-end">
          <a
            target="_blank"
            href="https://www.facebook.com/EricksonCoachingInternational"
            className="cursor-pointer"
          >
            <span className="text-base text-white hover:text-[#ebbd33]">
              <FaFacebook />
            </span>
          </a>
          <a
            target="_blank"
            href="https://twitter.com/EricksonCoaches"
            className="cursor-pointer"
          >
            <span className="text-base text-white hover:text-[#ebbd33]">
              <FaX />
            </span>
          </a>
          <a
            target="_blank"
            href="http://instagram.com/ericksoncoaching"
            className="cursor-pointer"
          >
            <span className="text-base text-white hover:text-[#ebbd33]">
              <FaInstagram />
            </span>
          </a>
          <a
            target="_blank"
            href="https://www.linkedin.com/company/erickson-coaching-international"
            className="cursor-pointer"
          >
            <span className="text-base text-white hover:text-[#ebbd33]">
              <FaLinkedin />
            </span>
          </a>
          <a
            target="_blank"
            href="http://pinterest.com/ericksoncoaching"
            className="cursor-pointer"
          >
            <span className="text-base text-white hover:text-[#ebbd33]">
              <FaPinterest />
            </span>
          </a>
          <a
            target="_blank"
            href="https://www.youtube.com/user/ericksonvideo"
            className="cursor-pointer"
          >
            <span className="text-base text-white hover:text-[#ebbd33]">
              <FaYoutube />
            </span>
          </a>
        </div>
        <hr className="text-gray-300 h-1 w-full" />
        <div className="flex items-center">
          <span>
            <FaRegCopyright
              className="text-white"
              style={{ color: "white", marginInline: 2 }}
            />
          </span>
          <p className="text-xs">2024 All Rights Reserved By Connect You</p>
        </div>
      </div>
    </>
  );
};
export default Footer;
