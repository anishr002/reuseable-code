import React from "react";
import Checkbox from "@mui/material/Checkbox";
import { styled } from "@mui/material/styles";

interface CustomCheckBoxProps {
  checked: boolean;
  handleChange: (
    event: React.ChangeEvent<HTMLInputElement>,
    checked: boolean
  ) => void | undefined;
}
const CustomCheckBox: React.FC<CustomCheckBoxProps> = ({
  checked,
  handleChange,
}) => {
  const CustomCheckboxStyled = styled(Checkbox)({
    "& .MuiSvgIcon-root": {
      fontSize: 24, // Set the size of the checkbox icon
    },
    "&.Mui-checked": {
      color: "#EABD32", // Change checkbox color when checked
    },
    "&.Mui-checked .MuiSvgIcon-root": {
      color: "#EABD32", // Change the icon color when checked
    },
    "&.MuiCheckbox-root": {
      padding: 0, // Optional: Remove padding if needed
    },
  });

  return (
    <CustomCheckboxStyled
      checked={checked}
      onChange={handleChange}
      inputProps={{ "aria-label": "controlled" }}
    />
  );
};

export default CustomCheckBox;
