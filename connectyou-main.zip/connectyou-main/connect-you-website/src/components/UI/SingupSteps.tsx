import React from "react";
import brandLogo from "/loginLogo.png";
import { Link } from "react-router-dom";
interface SingupStepsProps {
  Steps: string[];
  Title: string;
}
const SingupSteps: React.FC<SingupStepsProps> = ({ Steps, Title }) => {
  return (
    <>
      <Link
        to="/"
        className="flex connect-you-brand-text font-semibold text-2xl"
      >
        <img src={brandLogo} alt="logo" className="object-contain w-52" />
      </Link>
      <div className="flex connect-you-brand-text font-semibold text-lg">
        <h2>{Title}</h2>
      </div>
      <div className="flex flex-col gap-7">
        {Steps.map((a: string, i: number) => (
          <div
            key={i}
            className="flex gap-3 items-center p-3 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300"
          >
            {/* Index Number */}
            <span className="flex items-center justify-center w-8 h-8 text-base font-semibold text-white bg-[#EABD32] rounded-full">
              {i + 1}
            </span>
            {/* Content */}
            <p className="text-[#EABD32] text-base font-medium">{a}</p>
          </div>
        ))}
      </div>
    </>
  );
};

export default SingupSteps;
