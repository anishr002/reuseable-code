import { useState } from "react";
import image from "../../assets/images/woman-image.png";
import { ResourcesModule_Type } from "../../Types/backend/Resource_Type";
import backendURL from "../../util/AxiosAPI";
import MundialHeadingText from "./MundialHeadingText";
import dayjs from "dayjs";
import asyncFileDownload from "../../util/asyncFileDownload";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";
import Image from "./Image";
import { FaBook } from "react-icons/fa";

const ResourceCard = ({ data }: { data: ResourcesModule_Type }) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center rounded-[5px] px-[10px]  py-[10px] h-[300px] md:h-[225px]  min-h-[300px]   md:min-h-[225px] overflow-hidden  bg-white">
        <div className="relative rounded-[5px] md:max-w-[160px] h-full  overflow-hidden w-full md:w-2/5  flex items-center justify-center">
          <Image
            src={
              data.thumbnailImage
                ? `${backendURL}/resourceFiles/${data.thumbnailImage}`
                : image
            }
            alt={data.title || "Resource-Module-Thumb"}
            className="w-full h-full object-cover object-center"
            fallback={
              <div className="w-full h-full bg-gray-100 flex items-center justify-center flex-col space-y-3.5">
                <FaBook className="text-[#3aa7a3] font-black text-6xl" />
                <span className="text-[#3aa7a3] text-center">
                  {data?.title || ""}
                </span>
              </div>
            }
          />
        </div>
        <div className="flex flex-col  md:flex-1 items-start justify-between  md:ps-6 w-full md:w-3/5 h-full py-4">
          <div className="flex flex-col  w-full">
            <MundialHeadingText sizeVariant="xs" className="p-0 line-clamp-2">
              {data.title || "Resource Title"}
            </MundialHeadingText>
            <span className="text-[#3aa7a3] text-sm font-medium">
              {`Published on ${dayjs(data.createdAt).format("DD MMMM YYYY")}`}
            </span>
          </div>
          <div className="flex-1">
            <p className="text-gray-700 text-sm w-full line-clamp-3  pt-2">
              {data.description}
            </p>
          </div>
          <div className="flex  space-y-1.5 w-full justify-between items-start ">
            <button
              className="text-sm font-semibold underline text-[#3aa7a3]"
              onClick={() => setOpen(true)}
            >
              Read More
            </button>
            <button
              className="text-sm font-semibold underline text-[#3aa7a3]"
              onClick={() =>
                asyncFileDownload({ fileUrl: `/resourceFiles/${data.pdfFile}` })
              }
            >
              Download PDF
            </button>
          </div>
        </div>
      </div>
      <CustomModalWrapper
        title={data.title}
        open={open}
        onClose={() => setOpen(false)}
      >
        <div className="flex flex-col">
          <div className="w-full min-h-screen bg-[#f3f4f6] flex flex-col items-start justify-start ">
            <div className="w-full bg-white  rounded-[10px] overflow-hidden border border-[#3aa7a3]">
              <div className="w-full h-[350px] bg-[#013338] flex items-center justify-center overflow-hidden">
                <img
                  src={`${backendURL}/resourceFiles/${data.thumbnailImage}`}
                  alt="Thumbnail"
                  className="object-cover h-full w-full"
                />
              </div>
              <div className="p-6 space-y-4 flex-1">
                <p className="text-gray-700 text-md w-full text-left break-words px-2">
                  {data.description}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#3aa7a3] font-medium">
                    Published: {dayjs(data.createdAt).format("MMMM DD, YYYY")}
                  </span>
                  <a
                    href={`${backendURL}/resourceFiles/${data.pdfFile}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#3aa7a3] hover:bg-[#2e8481] text-white px-4 py-2 rounded-lg text-sm font-medium"
                  >
                    View PDF
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CustomModalWrapper>
    </>
  );
};

export default ResourceCard;
