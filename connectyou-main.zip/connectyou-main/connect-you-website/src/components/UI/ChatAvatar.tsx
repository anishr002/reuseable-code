import { Badge } from "@mui/material";
import { ReactNode, useEffect, useState } from "react";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import { getTimeDifference } from "../../util/getTimeDifferenceString";
import { SocketWithState } from "../../contexts/SocketContext";

interface ReceivedUerType {
  live: number;
  name: string;
  lastSeen: string;
  Lname?: string;
}

const ChatAvatar = ({
  _id,
  socket,
  children,
  showliveText = false,
  name,
}: {
  _id: string;
  children: ReactNode;
  socket?: SocketWithState | null;
  showliveText?: boolean;
  name?: ReactNode;
}) => {
  const [user, setUser] = useState<ReceivedUerType | null>(null);
  const loginData = useSelector(
    (state: RootState) => state?.login?.userdata?.userType
  );

  const [refresh, setRefresh] = useState<boolean>(false);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await httpAPI.get(
          `${backendURL}/${
            loginData === "coach" ? "coach" : "user"
          }/profile/get-live-status/${_id}`
        );
        // console.log({ res });
        if (res.status === 200) {
          setUser(res.data.data);
        }
      } catch (error) {
        console.error(error);
      }
    };
    fetchData();
  }, [_id, refresh, loginData]);

  useEffect(() => {
    const refPage = () => setRefresh((prev) => !prev);
    if (socket) {
      socket.on("new-connected-coaches", refPage);
      socket.on("new-connected-users", refPage);
      socket.on("new-diconnected-coaches", refPage);
      socket.on("new-diconnected-users", refPage);
    }
    return () => {
      if (socket) {
        socket.off("new-connected-coaches", refPage);
        socket.off("new-diconnected-coaches", refPage);
        socket.off("new-connected-users", refPage);
        socket.off("new-diconnected-users", refPage);
      }
    };
  }, [socket]);

  return (
    <div className=" flex flex-row justify-center items-center">
      <Badge
        overlap="circular"
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        sx={{
          border: user && user.live == 1 ? "2px solid #3aa7a3" : "none",
          borderRadius: "100%",
        }}
        badgeContent={
          user ? (
            user.live == 1 ? (
              <span className="w-3 h-3 bg-[#3aa7a3] border-2 border-white rounded-full" />
            ) : null
          ) : null
        }
      >
        {children}
      </Badge>
      <div className="ml-3 flex flex-col">
        {name}
        {showliveText && (
          <>
            {user?.live == 1 ? (
              <span className="text-[0.60rem]  font-normal text-[#013338]">
                Online
              </span>
            ) : (
              user?.lastSeen && (
                <span className="text-[0.60rem]  font-normal text-[#013338]">
                  Last Seen{" : "}
                  {getTimeDifference(new Date(user.lastSeen))}
                </span>
              )
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ChatAvatar;
