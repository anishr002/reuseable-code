import React, { useEffect, useState, useMemo } from "react";
import { Menu, MenuItem, IconButton, Tooltip } from "@mui/material";
import {
  LocalizationProvider,
  DateCalendar,
  DateCalendarProps,
  PickersDay,
  PickersDayProps,
} from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs, { Dayjs } from "dayjs";
import { ExpandMore, ExpandLess } from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import { TimeSlot } from "../hooks/useCreateAvailableTimeSlots";

const DropdownContainer = styled("div")({
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  padding: "5px 10px",
  border: "1px solid #3aa7a3",
  borderRadius: "10px",
  cursor: "pointer",
  minWidth: "100%",
  width: "100%",
});

const StyledCalendar = styled(DateCalendar)({
  backgroundColor: "white",
  padding: "8px",
  "& .MuiPickersDay-root": {
    color: "#013338",
  },
  "& .MuiPickersDay-root.Mui-disabled": {
    color: "#d3d3d3",
  },
  "& .Mui-selected": {
    backgroundColor: "#3aa7a3 !important",
    color: "white !important",
  },
  "& .MuiPickersCalendarHeader-label": {
    color: "#3aa7a3",
  },
  "& .MuiPickersArrowSwitcher-button": {
    color: "#3aa7a3",
  },
});
const HighlightedDay = styled(PickersDay, {
  shouldForwardProp: (prop) => !["dotType"].includes(prop as string),
})<{ dotType?: "available" | "unavailable" | "none" }>(({ dotType }) => ({
  // ...(dotType === "available" && {
  //   "&::after": {
  //     content: '""',
  //     display: "block",
  //     position: "absolute",
  //     bottom: "2px",
  //     left: "50%",
  //     transform: "translateX(-50%)",
  //     width: "4px",
  //     height: "4px",
  //     borderRadius: "50%",
  //     backgroundColor: "#3aa7a3",
  //   },
  // }),
  ...(dotType === "unavailable" && {
    "&::after": {
      content: '""',
      display: "block",
      position: "absolute",
      bottom: "2px",
      left: "50%",
      transform: "translateX(-50%)",
      width: "4px",
      height: "4px",
      borderRadius: "50%",
      backgroundColor: "#e53935", // Red color for days with no timeslots
    },
  }),
}));

type DateStatus = {
  [key: string]: "available" | "unavailable";
};

const DateDropdown = ({
  helper,
  def,
  calenderProps,
  highlights,
}: {
  helper: (selectedDate: Dayjs | null) => void;
  def?: Dayjs;
  calenderProps?: DateCalendarProps<dayjs.Dayjs> &
    React.RefAttributes<HTMLDivElement>;
  highlights: { date: Dayjs; slots: TimeSlot[] }[];
}) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedDate, setSelectedDate] = useState<Dayjs | null>(null);
  const dateStatusMap = useMemo(() => {
    const statusMap: DateStatus = {};
    if (!highlights || !Array.isArray(highlights)) return statusMap;

    highlights.forEach((highlight) => {
      if (highlight?.date) {
        const dateStr = highlight.date.format("YYYY-MM-DD");
        if (highlight.slots && highlight.slots.length > 0) {
          statusMap[dateStr] = "available";
        } else {
          statusMap[dateStr] = "unavailable";
        }
      }
    });

    return statusMap;
  }, [highlights]);

  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleDateChange = (date: Dayjs | null) => {
    setSelectedDate(date);
    helper(date);
    handleClose();
  };

  const shouldDisableDate = (date: Dayjs) => {
    return date.isBefore(dayjs(), "day");
  };

  useEffect(() => {
    if (def) {
      setSelectedDate(def);
    }
  }, [def]);

  const ServerDay = React.memo(
    React.forwardRef<HTMLButtonElement, PickersDayProps<Dayjs>>(
      (props, ref) => {
        const { day, outsideCurrentMonth, ...other } = props;
        if (outsideCurrentMonth) {
          return (
            <PickersDay
              day={day}
              outsideCurrentMonth={outsideCurrentMonth}
              {...other}
              ref={ref}
            />
          );
        }
        const dateStr = day.format("YYYY-MM-DD");
        const dotType = dateStatusMap[dateStr] || "none";

        return (
          <Tooltip
            title={
              // dotType === "available" ? "Coach Available" : "Coach Unavailable"
              ""
            }
          >
            <HighlightedDay
              {...other}
              day={day}
              ref={ref}
              outsideCurrentMonth={outsideCurrentMonth}
              dotType={dotType}
            />
          </Tooltip>
        );
      }
    )
  );

  const legend = useMemo(
    () => (
      <MenuItem
        sx={{
          display: "flex",
          flexDirection: "column",
          flexWrap: "wrap",
          alignItems: "flex-start",
          gap: 3,
          py: 1,
          px: 2,
          borderTop: "1px solid #eee",
          "& > div": {
            display: "flex",
            alignItems: "center",
            marginBottom: "4px",
          },
        }}
      >
        <div className="flex w-full gap-2">
          {/* <div>
            <span
              style={{
                display: "inline-block",
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                backgroundColor: "#3aa7a3",
                marginRight: "8px",
              }}
            ></span>
            <span style={{ fontSize: 14 }}>Coach-Available</span>
          </div> */}
          <div>
            <span
              style={{
                display: "inline-block",
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                backgroundColor: "#e53935",
                marginRight: "8px",
              }}
            ></span>
            <span style={{ fontSize: 14 }}>Coach-Unavailable</span>
          </div>
        </div>
      </MenuItem>
    ),
    []
  );

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DropdownContainer style={{ width: "100%" }} onClick={handleClick}>
        <span style={{ color: "#3aa7a3" }}>
          {selectedDate ? selectedDate.format("DD/MM/YYYY") : "Please Select"}
        </span>
        <IconButton size="small" sx={{ color: "#3aa7a3" }}>
          {anchorEl ? <ExpandLess /> : <ExpandMore />}
        </IconButton>
      </DropdownContainer>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        sx={{ p: 0 }}
      >
        <MenuItem sx={{ p: 0 }} disableRipple>
          <StyledCalendar
            value={selectedDate}
            onChange={handleDateChange}
            shouldDisableDate={shouldDisableDate}
            maxDate={dayjs().add(3, "month")}
            slots={{
              day: ServerDay,
            }}
            {...calenderProps}
          />
        </MenuItem>
        <div className="max-w-[300px] mx-auto">{legend}</div>
        <div className="">
          {Object.keys(dateStatusMap).length === 0 && (
            <div className="w-full px-10">
              <p className="text-xs text-center font-semibold text-[red] w-full break-words">
                This coach has not added <br /> their's availablility data.
              </p>
            </div>
          )}
        </div>
      </Menu>
    </LocalizationProvider>
  );
};

export default DateDropdown;
