import { Avatar } from "@mui/material";
import React, { useState } from "react";
import { CountryType } from "../../Options/Options";

interface RenderCountryFlagProps {
  country: CountryType;
  variant?: "flat" | "rounded";
}
const RenderCountryFlag: React.FC<RenderCountryFlagProps> = ({
  country,
  variant = "flat",
}) => {
  const [flagCDNerror, setFlagCDNError] = useState<boolean>(false);
  const handleFlagError = () => {
    setFlagCDNError(true);
  };

  return (
    <>
      {country?.code && (
        <>
          <Avatar
            src={`https://flagcdn.com/w40/${country.code.toLowerCase()}.png`}
            alt="flag"
            sx={{ display: "none" }}
            onError={handleFlagError}
          />
          {!flagCDNerror && (
            <img
              loading="lazy"
              width="30"
              src={`https://flagcdn.com/w40/${country.code.toLowerCase()}.png`}
              alt={
                country.label
                  ? `${country.label}-flag-${country.code}`
                  : "Country-flag"
              }
              className={`${
                variant === "flat" ? "rounded-sm" : "rounded-full"
              } w-full h-full`}
            />
          )}
        </>
      )}
    </>
  );
};

export default RenderCountryFlag;
