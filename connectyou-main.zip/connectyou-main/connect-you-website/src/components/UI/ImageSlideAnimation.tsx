import "../../styles/ImageSlideAnimation.css";

import { useEffect, useState } from "react";

const ImageSlideAnimation = ({ array }: { array: string[] }) => {
  const [direction, setDirection] = useState("right");

  useEffect(() => {
    const handleDirection = (e: WheelEvent) => {
      const X = e.deltaY;
      setDirection(X > 0 ? "right" : "left");
    };
    window.addEventListener("wheel", handleDirection);
    return () => window.removeEventListener("wheel", handleDirection);
  }, []);

  return (
    <div className="slide-parent flex flex-col px-4 md:px-0 justify-center items-center w-full">
      <div
        className={`flex flex-row justify-${
          direction === "left" ? "start" : "end"
        } items-center w-full    max-w-full overflow-hidden px-2 flex-nowrap`}
      >
        <div
          className={`flex flex-row justify-between items-center px-5 gap-1 slide-${direction} min-w-fit  flex-nowrap `}
        >
          {array.map((a, i: number) => (
            <img
              key={`sliding-brand-animation-items-item-${i}-part-2`}
              src={a}
              alt="brand-partner-image"
              className="object-contain p-5 min-w-[10rem]  [aspect-ratio:3/2] h-[10rem]"
            />
          ))}
        </div>
        <div
          className={`flex flex-row justify-between items-center px-5 gap-1 min-w-fit   slide-${direction} flex-nowrap`}
        >
          {array.map((a, i: number) => (
            <img
              key={`sliding-brand-animation-items-item-${i}-part-2`}
              src={a}
              alt="brand-partner-image"
              className="object-contain p-5 min-w-[10rem]  [aspect-ratio:3/2] h-[10rem]"
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImageSlideAnimation;
