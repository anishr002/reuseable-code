/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { ReactNode, useState } from "react";
import {
  Fade,
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
} from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { SubmitHandler, useForm } from "react-hook-form";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useNotify } from "../../lib/Notify";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";
import { YellowButton } from "../buttons/ThemeButtons";
import validatePassword from "../../util/ValidatePassword";
import customAlert from "../../lib/swalExtentions";

interface FormValues {
  old_password: string;
  new_password: string;
  cnf_password: string;
}

interface UpdatePasswordComponentProps {
  togglePageRefresh: () => void;
  userType: "coach" | "user";
  children: ReactNode;
}

const UpdatePasswordComponent: React.FC<UpdatePasswordComponentProps> = ({
  togglePageRefresh,
  userType,
  children,
}) => {
  const { notifyMe } = useNotify();
  const [openUpdatePasswordModal, setOpenUpdatePasswordModal] =
    useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
  } = useForm<FormValues>({ mode: "onChange" });

  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);
  const [showError, setShowError] = React.useState(false);

  const [showPassword, setShowPassword] = React.useState(false);
  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const [showPassword2, setShowPassword2] = React.useState(false);
  const handleClickShowPassword2 = () => setShowPassword2((show) => !show);
  const handleMouseDownPassword2 = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);
  const handleClickShowConfirmPassword = () =>
    setShowConfirmPassword((show) => !show);
  const handleMouseDownConfirmPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const onSubmitPassword: SubmitHandler<FormValues> = async (
    data: FormValues
  ) => {
    setLoading(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/${userType}/profile/password-update`,
        { old_password: data.old_password, new_password: data.new_password }
      );
      if (response.status === 200) {
        notifyMe({
          message: "Password updated successfully ",
          severity: "success",
        });
        togglePageRefresh();
        setOpenUpdatePasswordModal(false);
        customAlert.fire({
          title: "Password Updated !",
          text: "Your password as been updated, please use the new password for login.",
          showConfirmButton: true,
          timer: 2500,
        });
        reset();
        setShowError(false);
        return setLoading(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          severity: "error",
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
        });
        setErrorMessage(
          error.response.data.message
            ? error.response.data.message
            : "Something went wrong"
        );
        setShowError(true);

        // Hide the error after 10 seconds
        setTimeout(() => {
          setShowError(false);
        }, 10000);
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div onClick={() => setOpenUpdatePasswordModal(true)}>{children}</div>

      {/*update password */}
      <CustomModalWrapper
        open={openUpdatePasswordModal}
        title="Update Password"
        onClose={() => setOpenUpdatePasswordModal(false)}
        backdropClose={false}
        children={
          <div className="flex flex-col w-full gap-8">
            {showError && (
              <div className="flex flex-col gap-3">
                <Fade in={showError} timeout={1000}>
                  <div className="text-red-500 text-center w-full">
                    <p className="font-semibold">{errorMessage} </p>{" "}
                  </div>
                </Fade>
              </div>
            )}
            <form
              onSubmit={handleSubmit(onSubmitPassword)}
              className="flex w-full flex-col gap-3"
            >
              <div className="pt-4">
                <FormControl
                  variant="outlined"
                  error={!!errors.old_password}
                  fullWidth
                  size="small"
                >
                  <InputLabel htmlFor="outlined-adornment-password">
                    Old Password
                  </InputLabel>
                  <OutlinedInput
                    id="outlined-adornment-password"
                    autoComplete="old-password"
                    {...register("old_password", {
                      required: "Please enter your old password",
                    })}
                    type={showPassword ? "text" : "password"}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    }
                    label="Old Password"
                  />
                  {errors.old_password && (
                    <FormHelperText error style={{ marginLeft: 0 }}>
                      {errors.old_password.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </div>

              <div className="pt-4">
                <FormControl
                  variant="outlined"
                  error={!!errors.new_password}
                  fullWidth
                  size="small"
                >
                  <InputLabel htmlFor="outlined-adornment-password">
                    New Password
                  </InputLabel>
                  <OutlinedInput
                    id="outlined-adornment-password"
                    type={showPassword2 ? "text" : "password"}
                    autoComplete="new-password"
                    {...register("new_password", {
                      required: "New password is required",
                      validate: validatePassword,
                    })}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword2}
                          onMouseDown={handleMouseDownPassword2}
                          edge="end"
                        >
                          {showPassword2 ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    }
                    label="New Password"
                  />
                  {errors.new_password && (
                    <FormHelperText error style={{ marginLeft: 0 }}>
                      {errors.new_password.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </div>

              <div className="pt-4">
                <FormControl
                  variant="outlined"
                  error={!!errors.cnf_password}
                  fullWidth
                  size="small"
                >
                  <InputLabel htmlFor="outlined-adornment-confirm-password">
                    Confirm Password
                  </InputLabel>
                  <OutlinedInput
                    id="outlined-adornment-confirm-password"
                    type={showConfirmPassword ? "text" : "password"}
                    autoComplete="new-password"
                    {...register("cnf_password", {
                      required: "Confirm password is required",
                      validate: (value) =>
                        value === watch("new_password") ||
                        "Passwords do not match",
                    })}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle confirm password visibility"
                          onClick={handleClickShowConfirmPassword}
                          onMouseDown={handleMouseDownConfirmPassword}
                          edge="end"
                        >
                          {showConfirmPassword ? (
                            <VisibilityOff />
                          ) : (
                            <Visibility />
                          )}
                        </IconButton>
                      </InputAdornment>
                    }
                    label="Confirm Password"
                  />
                  {errors.cnf_password && (
                    <FormHelperText error style={{ marginLeft: 0 }}>
                      {errors.cnf_password.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </div>

              <div className="flex w-1/2 mx-auto">
                <YellowButton type="submit" loading={loading} text="Save" />
              </div>
            </form>
          </div>
        }
      />
    </>
  );
};

export default UpdatePasswordComponent;
