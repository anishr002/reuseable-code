/* eslint-disable @typescript-eslint/no-unused-expressions */
import { FC, ReactNode, useEffect, useState } from "react";
import { Controller, FormProvider, useForm } from "react-hook-form";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";
import { createTheme, Rating, ThemeProvider } from "@mui/material";
import RegisterTextInputField from "../inputFields/RegisterTextInputField";
import { BackdropLoader } from "./LoadingElement";
import { YellowButton } from "../buttons/ThemeButtons";

export type ExtractReviewActionData = {
  review: {
    ratingNumber: number;
    remarks: string;
    title: string;
  };
};
interface ReviewActionProps {
  children: ReactNode;
  title: string;
  loading?: boolean;
  nextAction?: ({ data }: { data: ExtractReviewActionData }) => Promise<void>;
  coachId?: string;
  def?: ExtractReviewActionData;
}
const ReviewAction: FC<ReviewActionProps> = ({
  children,
  title = "Add a Review",
  loading,
  nextAction,
  def,
}) => {
  const [open, setOpen] = useState<boolean>(false);
  const methods = useForm<ExtractReviewActionData>({
    mode: "onChange",
    reValidateMode: "onChange",
    shouldFocusError: true,
  });

  const onSubmit = methods.handleSubmit(
    async (data: ExtractReviewActionData) => {
      // console.log(data);
      nextAction && (await nextAction({ data }));
      methods.reset();
      setOpen(false);
    }
  );

  useEffect(() => {
    if (def) {
      methods.setValue("review", def.review);
    }
  }, [def]);

  return (
    <FormProvider {...methods}>
      <div onClick={() => setOpen(true)}>{children}</div>
      <CustomModalWrapper
        title={title}
        onClose={() => setOpen(false)}
        open={open}
        backdropClose
        escapeClose
      >
        <div className="flex flex-col space-y-3">
          {loading && (
            <BackdropLoader
              open={loading}
              text="Please wait, updating your review"
            />
          )}
          <div className="flex w-full items-cneter justify-center">
            <ThemeProvider theme={ratingTheme}>
              <Controller
                name="review.ratingNumber"
                control={methods.control}
                rules={{
                  required: "Please select the rating number",
                }}
                render={({ field }) => (
                  <Rating
                    {...field}
                    sx={{ color: "#ebbd33", fontSize: "3rem" }}
                    precision={0.5}
                  />
                )}
              />
            </ThemeProvider>
          </div>
          <div className="flex w-full items-cneter justify-center">
            <RegisterTextInputField
              textLabel={"Review Title"}
              name="review.title"
              validationOptions={{
                required: "Please add a review Title",
                maxLength: {
                  value: 200,
                  message: "Maximum 200 characters are allowed",
                },
              }}
              validationError={
                methods.formState.errors.review?.remarks?.message
              }
              multiline
              rows={2}
              maxRows={5}
            />
          </div>
          <div className="flex w-full items-cneter justify-center">
            <RegisterTextInputField
              textLabel={"Remarks"}
              name="review.remarks"
              validationOptions={{
                required: "Please add a review description",
                maxLength: {
                  value: 700,
                  message: "Maximum 700 characters are allowed",
                },
              }}
              validationError={
                methods.formState.errors.review?.remarks?.message
              }
              multiline
              rows={6}
              maxRows={10}
            />
          </div>
          <div className="flex w-full items-cneter justify-center">
            <YellowButton
              text="Save"
              onClick={() => onSubmit()}
              shouldDisable={
                !methods.watch("review.remarks") ||
                !methods.watch("review.ratingNumber") ||
                loading ||
                Object.keys(methods.formState.errors).length > 0
              }
            />
          </div>
        </div>
      </CustomModalWrapper>
    </FormProvider>
  );
};

export default ReviewAction;

const ratingTheme = createTheme({});

// Styled Rating: filled stars use #013338 and overall star size is 44px
