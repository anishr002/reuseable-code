import { renderReadFilePreview } from "../../util/renderFilePreview";
import Chat_Message_Type from "../../Types/backend/Chat_Message_Type";
import { UserProfile } from "../../pages/dashboard-pages/coach/chat/Page";
import { CoachProfile } from "../../pages/dashboard-pages/coachee/Chat/Page";
import { HTMLAttributes, ReactNode, useEffect, useState } from "react";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";
import { Tooltip } from "@mui/material";
import { FaEye } from "react-icons/fa";
import MediaPreviewWrapper from "../wrappers/MediaPreviewWrapper";
import { getFileExtensionAndType } from "../../util/getFileExtensionAndType";
import backendURL from "../../util/AxiosAPI";

const ChatMessageListItem = ({
  selectedUser,
  message,
}: {
  selectedUser: UserProfile | CoachProfile | null;
  message: Chat_Message_Type;
}) => {
  const [mediaCase, setMediaCase] = useState<"noMedia" | "onlyMedia" | "mix">(
    "mix"
  );

  useEffect(() => {
    if (message) {
      if (message?.files.length === 0) {
        return setMediaCase("noMedia");
      } else if (
        message?.files.length > 0 &&
        message?.message &&
        message?.message !== ""
      ) {
        return setMediaCase("mix");
      } else if (
        message?.files.length > 0 &&
        !message?.message &&
        message?.message === ""
      ) {
        return setMediaCase("onlyMedia");
      } else {
        return setMediaCase("mix");
      }
    }
  }, [message, selectedUser]);

  const ManagedMultipleMedia = () => {
    return (
      <>
        {message?.files &&
        message?.files.length > 0 &&
        message?.files.length < 4 ? (
          <div className="w-full h-full flex flex-col space-y-1.5  max-w-fit items-center justify-center">
            {message?.files.map((file) => (
              <div
                key={`Files-render-item-${file}`}
                className={`
                    flex items-center w-full rounded-[5px] overflow-hidden
                    ${
                      selectedUser?._id != message?.receiverId
                        ? " justify-start"
                        : "justify-end"
                    }
                  `}
              >
                <MediaPreviewWrapper
                  files={[file]}
                  childProps={{
                    className: `w-fit h-fit flex items-center justify-center rounded-[5px] overflow-hidden  p-1   ${
                      selectedUser?._id != message?.receiverId
                        ? "bg-[#FFFFFF]  text-[#013338]  justify-start"
                        : "bg-[#3aa7a3] text-white justify-end"
                    }`,
                  }}
                  {...(["document", "unknown"].includes(
                    getFileExtensionAndType(file).type
                  )
                    ? {
                        allowClickPreview: false,
                      }
                    : {
                        allowClickPreview: true,
                      })}
                >
                  {renderReadFilePreview({
                    file: file,
                    imageElProps: {
                      className: "preview-image w-52 h-32 rounded-[5px]",
                    },
                    smartFileElProps: {
                      className: "w-[240px] h-12 rounded-[5px]",
                      maxLength: 12,
                    },
                    videoElProps: {
                      autoPlay: true,
                      className: "preview-image w-52 h-32 rounded-[5px]",
                      muted: true,
                      loop: true,
                      playsInline: true,
                    },
                    ...(["document", "unknown"].includes(
                      getFileExtensionAndType(file).type
                    )
                      ? {
                          children: (
                            <Tooltip title="Preview">
                              <button
                                className="absolute top-1 right-1 p-0.5 bg-white/60 backdrop-blur-md rounded-full text-gray-800 hover:bg-white"
                                onClick={() => {
                                  window.open(
                                    `${backendURL}/messageFile/${file}`,
                                    "blank"
                                  );
                                }}
                                type="button"
                              >
                                <FaEye size={18} />
                              </button>
                            </Tooltip>
                          ),
                        }
                      : {}),
                  })}
                </MediaPreviewWrapper>
              </div>
            ))}
          </div>
        ) : (
          <div
            className={`w-full h-full grid grid-cols-2 grid-rows-2 gap-1 p-1  max-w-fit rounded-[10px]  auto-rows-fr *: ${
              selectedUser?._id != message?.receiverId
                ? "bg-[#FFFFFF]  text-[#013338]"
                : "bg-[#3aa7a3] text-white"
            } `}
          >
            {message?.files.slice(0, 3).map((file) => (
              <div
                key={`Files-render-item-${file}`}
                className={`
                    flex items-center w-full rounded-[5px] overflow-hidden
                    ${
                      selectedUser?._id != message?.receiverId
                        ? " justify-start"
                        : "justify-end"
                    }
                  `}
              >
                <MediaPreviewWrapper
                  files={[file]}
                  allowClickPreview={true}
                  childProps={{
                    className: `w-fit h-fit flex items-center justify-center  rounded-[5px] overflow-hidden     ${
                      selectedUser?._id != message?.receiverId
                        ? " text-[#013338]  justify-start"
                        : " text-white justify-end"
                    }`,
                  }}
                >
                  {renderReadFilePreview({
                    file: file,
                    imageElProps: {
                      className: "preview-image w-32 h-32 rounded-[5px]",
                    },
                    smartFileElProps: {
                      className:
                        "w-32 h-32 rounded-[5px] flex items-center justify-center",
                      maxLength: 3,
                      flexDirection: "column",
                    },
                    videoElProps: {
                      autoPlay: true,
                      className: "preview-image w-32 h-32 rounded-[5px]",
                      muted: true,
                      loop: true,
                      playsInline: true,
                    },
                  })}
                </MediaPreviewWrapper>
              </div>
            ))}
            <div className=" col-span-1  flex items-center justify-center w-full   overflow-hidden">
              <MediaPreviewWrapper
                files={message?.files}
                allowClickPreview={true}
                childProps={{
                  className: `w-fit h-fit flex items-center justify-center  rounded-[5px] overflow-hidden     ${
                    selectedUser?._id != message?.receiverId
                      ? " text-[#013338]  justify-start"
                      : " text-white justify-end"
                  }`,
                }}
              >
                <MoreItemsPlaceHolder
                  style={{
                    borderRadius: 5,
                  }}
                  className="w-full h-full flex items-center justify-center "
                  backdrop={
                    <>
                      {renderReadFilePreview({
                        file: message?.files.slice(3, 4)[0],
                        imageElProps: {
                          className: "preview-image w-32 h-32 rounded-[5px]",
                        },
                        smartFileElProps: {
                          className:
                            "w-32 h-32 text-xs flex items-center justify-center",
                          maxLength: 3,
                          allowPreview: true,
                          flexDirection: "column",
                        },
                        videoElProps: {
                          autoPlay: true,
                          className: "preview-image w-32 h-32 rounded-[5px]",
                          muted: true,
                          loop: true,
                          playsInline: true,
                        },
                      })}
                    </>
                  }
                >
                  {`+${message?.files.length - 3}`}
                </MoreItemsPlaceHolder>
              </MediaPreviewWrapper>
            </div>
          </div>
        )}
      </>
    );
  };

  const NoMediaCase = () => {
    return (
      <>
        <div
          className={`px-4  rounded-lg max-w-96  min-w-24 relative  ${
            selectedUser?._id != message?.receiverId
              ? "bg-[#FFFFFF] text-[#013338]"
              : "bg-[#3aa7a3] text-white"
          }`}
        >
          {message?.message && (
            <div
              className={`${
                message?.files && message?.files.length > 0 ? "" : ""
              } break-all py-2`}
            >
              {message?.message}
            </div>
          )}
        </div>
      </>
    );
  };

  const MixMediaAndMessage = () => {
    return (
      <>
        <div
          className={` rounded-lg max-w-96  min-w-24 relative flex flex-col space-y-1.5`}
        >
          <div
            className={`w-full flex  ${
              selectedUser?._id === message?.receiverId
                ? "justify-end"
                : "justify-start"
            }`}
          >
            <ManagedMultipleMedia />
          </div>
          {message?.message && (
            <div
              className={` w-full flex flex-row  ${
                selectedUser?._id === message?.receiverId
                  ? "justify-end"
                  : "justify-start"
              }`}
            >
              <div
                className={`${
                  message?.files && message?.files.length > 0 ? "" : ""
                } break-all px-4 py-3 max-w-96  min-w-24 w-fit rounded-[5px]
              ${
                selectedUser?._id != message?.receiverId
                  ? "bg-[#FFFFFF] text-[#013338] text-pretty"
                  : "bg-[#3aa7a3] text-white text-pretty"
              }
              `}
              >
                {message?.message}
              </div>
            </div>
          )}
        </div>
      </>
    );
  };

  const OnlyMediaCase = () => {
    return (
      <>
        <div
          className={`mb-2  max-w-96 flex flex-col overflow-hidden justify-center items-center  min-w-24 relative  `}
        >
          <ManagedMultipleMedia />
        </div>
      </>
    );
  };

  if (mediaCase === "noMedia") {
    return <NoMediaCase />;
  }

  if (mediaCase === "onlyMedia") {
    return <OnlyMediaCase />;
  }

  if (mediaCase === "mix") {
    return <MixMediaAndMessage />;
  }
  return <NoMediaCase />;
};

export default ChatMessageListItem;

const MoreItemsPlaceHolder = ({
  children,
  backdrop,
  className,
  ...rest
}: {
  children?: ReactNode;
  backdrop?: ReactNode;
} & HTMLAttributes<HTMLDivElement>) => {
  const classed = removeDuplicateClasses(`bg-black/70 ${className || ""}`);
  return (
    <div className={`relative ${classed}`} {...rest}>
      {backdrop}
      <div
        className={`absolute inset-0 font-bold font-quicksand text-lg text-white cursor-pointer uppercase ${classed}`}
        {...rest}
      >
        {children}
      </div>
    </div>
  );
};
