import { Button } from "@mui/material";
import { Link } from "react-router-dom";
import JoinCard from "../../pages/become-a-coach/JoinCard";
import XSpace from "../wrappers/XSpace";
const Community = () => {
  return (
    <div className="flex flex-row justify-center items-center w-full py-10">
      <XSpace>
        <JoinCard />
      </XSpace>
      <div className="hidden flex-col md:flex-row custom-bg px-10 py-10 gap-4">
        <div className="flex flex-col gap-4 w-full md:w-3/4">
          <h1 className="text-white font-bold font-mundial text-2xl md:text-4xl gap-2">
            Join our Community of Coaches
          </h1>
          <p className="text-slate-300">
            {/* Unlock your potential and inspire others. Join our vibrant community
            of coaches today and make a lasting impact! Connect with like-minded
            professionals, share your expertise, and grow together. */}
            Join our thriving community of dedicated coaches and take your
            career to the next level. Become part of a network of like-minded
            professionals who are passionate about making a positive impact.
            Whether you're looking to share your expertise, learn from others,
            or collaborate on new opportunities, we offer the perfect platform
            to connect, grow, and inspire.
          </p>
        </div>
        <div className="flex  items-center">
          <Link to={`/signup-coach`}>
            <span className="text-white">
              <Button
                variant="outlined"
                sx={{
                  color: "white",
                  backgroundColor: "#EBBE34",
                  borderColor: "#EBBE34",
                  borderRadius: "20px",
                  fontFamily: "Quicksand",
                  "&:hover": {
                    borderColor: "#3aa7a3",
                    backgroundColor: "#3aa7a3",
                  },
                }}
              >
                Join Now
              </Button>
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Community;
