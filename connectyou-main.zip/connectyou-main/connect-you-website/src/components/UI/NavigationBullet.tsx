import { ReactNode } from "react";

const NavigationBullet = ({
  title,
  isActive,
  type,
  onClick,
}: {
  title: string | ReactNode;
  isActive?: boolean;
  type?: "submit" | "reset" | "button" | undefined;
  onClick?: () => void | undefined;
}) => {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`w-fit hover:bg-[#ebbd33] transition-all duration-200 ease-in-out cursor-pointer h-full rounded-[100px] px-4 flex justify-center items-center text-[#013338]  font-bold  whitespace-nowrap ${
        isActive ? "bg-[#ebbd33]" : ""
      }`}
    >
      {title}
    </button>
  );
};
export default NavigationBullet;
