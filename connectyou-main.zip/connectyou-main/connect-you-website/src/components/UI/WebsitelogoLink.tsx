import React from "react";
import logo from "../../assets/website-logos/connect-you-logo.png";

import { Link } from "react-router-dom";

const WebsitelogoLink: React.FC = () => {
  return (
    <>
      <div className="w-full flex justify-center items-center  py-4">
        <Link to="/" className="w-fit flex justify-center items-center">
          <img src={logo} alt="brand-logo" className="object-contain h-full" />
        </Link>
      </div>
    </>
  );
};

export default WebsitelogoLink;
