import React, { JSX } from "react";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";

import { IoIosArrowDown } from "react-icons/io";

interface CustomAccordComponentProps {
  question: string | JSX.Element;
  answer: string | JSX.Element;
}
const CustomAccordComponent: React.FC<CustomAccordComponentProps> = ({
  question,
  answer,
}) => {
  return (
    <div className="w-full flex flex-row justify-center items-center ">
      <Accordion
        sx={{
          width: "100%",
          borderBottom: "1.2px solid #3AA7A3",
          boxShadow: "none",
          marginBottom: "10px",
          borderRadius: 0,
          backgroundColor: "",
          ".css-18krbdx-MuiPaper-root-MuiAccordion-root:last-of-type": {
            borderRadius: 0,
          },
        }}
      >
        <AccordionSummary
          expandIcon={<IoIosArrowDown style={{ color: "#3AA7A3" }} />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          <Typography
            component="span"
            variant="body1"
            sx={{ color: "#013338", fontFamily: "Quicksand", fontWeight: 500 }}
          >
            {question}
          </Typography>
        </AccordionSummary>
        <AccordionDetails
          sx={{
            backgroundColor: "#e0f1ef9a",
            padding: "15px",
            borderRadius: "4px",
          }}
        >
          <Typography
            variant="body2"
            sx={{ color: "#013338", fontFamily: "Quicksand" }}
          >
            {answer}
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};

export default CustomAccordComponent;
