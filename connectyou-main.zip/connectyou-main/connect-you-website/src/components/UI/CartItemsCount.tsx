/* eslint-disable @typescript-eslint/no-explicit-any */

import { useSelector } from "react-redux";

const CartItemsCount = ({
  variant = "absolute",
}: {
  variant?: "inline" | "absolute";
}) => {
  const cartItemsCount = useSelector(
    (state: any) => state.cartCount.cartItemsCount
  );

  return (
    <>
      {cartItemsCount ? (
        <span
          style={{
            background: "#3aa7a3",
            color: "white",
            width: "20px",
            height: "20px",
            borderRadius: "50%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            fontSize: "0.75rem",
            position: variant === "absolute" ? "absolute" : "static",
            top: -10,
            right: "-10%",
            boxShadow: "0px 0px 8px rgba(0, 0, 0, 0.15)",
          }}
        >
          {cartItemsCount < 10 ? cartItemsCount : "9+"}
        </span>
      ) : (
        ""
      )}
    </>
  );
};

export default CartItemsCount;
