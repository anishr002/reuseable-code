import { useEffect, useState } from "react";
import Chat_Message_Type from "../../Types/backend/Chat_Message_Type";
import { getFileExtensionAndType } from "../../util/getFileExtensionAndType";
import { FaCamera } from "react-icons/fa";
import { IoMdDocument } from "react-icons/io";
import { FaMessage } from "react-icons/fa6";

const ChatMessageThumbStr = ({ children }: { children: Chat_Message_Type }) => {
  const [messageType, setMessageType] = useState<
    "noMessageStr" | "haveMessageStr"
  >("noMessageStr");

  useEffect(() => {
    if (children) {
      if (!children?.message || children?.message === "") {
        console.log("noMessageStr");
        setMessageType("noMessageStr");
      } else if (children.message) {
        console.log("haveMessageStr");
        setMessageType("haveMessageStr");
      }
    }
  }, [children]);

  const NoMessageStr = () => {
    if (!children?.files || children?.files?.length === 0) {
      return <></>;
    }
    return (
      <p className="inline-flex items-center">
        <span className="inline-flex ml-1 text-xs mr-1">
          {["image"].includes(
            getFileExtensionAndType(children?.files[0])?.type
          ) ? (
            <FaCamera className="text-inherit"></FaCamera>
          ) : ["video"].includes(
              getFileExtensionAndType(children?.files[0])?.type
            ) ? (
            <FaCamera className="text-inherit"></FaCamera>
          ) : ["document"].includes(
              getFileExtensionAndType(children?.files[0])?.type
            ) ? (
            <IoMdDocument className="text-inherit"> </IoMdDocument>
          ) : (
            <FaMessage className="text-inherit"> </FaMessage>
          )}
        </span>
        <span className="inline-flex">
          {["image"].includes(
            getFileExtensionAndType(children?.files[0])?.type
          ) ? (
            <>Photo </>
          ) : ["video"].includes(
              getFileExtensionAndType(children?.files[0])?.type
            ) ? (
            <>Video </>
          ) : ["document"].includes(
              getFileExtensionAndType(children?.files[0])?.type
            ) ? (
            <>Document</>
          ) : (
            <>{children?.files[0] ? children?.files[0] : "New Message"}</>
          )}
        </span>
      </p>
    );
  };

  if (messageType === "noMessageStr") {
    return <NoMessageStr></NoMessageStr>;
  }

  if (messageType === "haveMessageStr") {
    return <>{children?.message}</>;
  }
};

export default ChatMessageThumbStr;
