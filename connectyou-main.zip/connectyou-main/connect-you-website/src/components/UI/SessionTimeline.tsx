import BookedSession_TImeline_Type from "../../Types/backend/BookedSession_TImeline_Type";
import dayjs from "dayjs";
import Warning from "./Warning";
import MundialHeadingText from "./MundialHeadingText";

const SessionTimeline = ({
  timeline,
}: {
  timeline: BookedSession_TImeline_Type[];
}) => {
  return (
    <div className="flex flex-col space-y-3  flex-1 w-full">
      <div className="w-full">
        <div className="w-fit py-4">
          <MundialHeadingText
            variant="seablue"
            sizeVariant="xs"
            style={{ padding: 0 }}
          >
            Session Timeline
          </MundialHeadingText>
        </div>
      </div>
      <div className="min-h-[10rem] flex flex-col relative ">
        <div className="absolute h-full bg-[#65d1cd3f] w-1 top-0 left-0"></div>
        {timeline && timeline.length > 0 ? (
          <>
            {/* Timeline items */}
            <div className="space-y-6">
              {timeline.map((sta, i) => (
                <div
                  key={`session-time-line-items-${i}-${sta.bookedSessionId}`}
                  className="relative"
                >
                  <div
                    className={`absolute -left-0 top-0 h-full w-1 rounded-full ${
                      i === timeline.length - 1 ? "bg-[#3aa7a3] " : ""
                    }`}
                  ></div>
                  {/* Timeline content */}
                  <div
                    style={{
                      background:
                        sta.actionBy.toLocaleLowerCase() === "coachee"
                          ? "#fdd96e0e"
                          : "#77e0dd0a",
                    }}
                    className={` pl-4 py-2 rounded flex flex-col items-start justify-start`}
                  >
                    <p className="font-medium text-[#013338]  text-sm">
                      {sta.action}
                      <span className="font-normal text-gray-500 ml-2 text-sm">
                        by {sta.actionBy}
                      </span>
                    </p>

                    <p className="text-gray-600 mt-1 text-sm">{sta.message}</p>

                    <p className="text-xs text-gray-400 mt-2">
                      {dayjs(sta.createdAt).format("DD MMMM YYYY hh:mmA")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="w-fit h-fit my-auto">
            <Warning variant="yellow" inline>
              There are no Entries in the session timeline right now.
            </Warning>
          </div>
        )}
      </div>
    </div>
  );
};

export default SessionTimeline;
