/* eslint-disable @typescript-eslint/no-unused-expressions */
import { RxDotsHorizontal } from "react-icons/rx";
import { BiCheckDouble } from "react-icons/bi";
import { LiaCheckSolid } from "react-icons/lia";
import { IconType } from "react-icons/lib";
// import { Tooltip } from "@mui/material";
import { useEffect, useState } from "react";
import Chat_Message_Type from "../../Types/backend/Chat_Message_Type";
import { SocketWithState } from "../../contexts/SocketContext";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import { httpAPI } from "../../util/AxiosAPI";
import backendURL from "../../util/baseBackendURLConfig";

type Status = "read" | "delivered" | "sent" | "failed" | "";

interface Obj {
  color: string;
  icon: IconType;
  announce: string;
}

const getStatusIndicator = (status: Status): Obj => {
  // console.log({ status });
  switch (status) {
    case "read":
      return {
        color: "#3aa7a3",
        icon: BiCheckDouble,
        announce: "Message Read",
      };
    case "delivered":
      return {
        color: "#999999",
        icon: BiCheckDouble,
        announce: "Message Delivered",
      };
    case "sent":
      return {
        color: "#3aa7a3",
        icon: LiaCheckSolid,
        announce: "Message Sent",
      };
    case "failed":
      return {
        color: "#999999",
        icon: RxDotsHorizontal,
        announce: "Network error",
      };
    default:
      return {
        color: "#999999",
        icon: RxDotsHorizontal,
        announce: "Error occurred while sending",
      };
  }
};

interface ChatMessageDStatusProps {
  socket: SocketWithState | null;
  message_id: string;
  keepStatic?: boolean;
  defaultMessage?: Chat_Message_Type;
}

const ChatMessageDStatus: React.FC<ChatMessageDStatusProps> = (props) => {
  const { socket, message_id } = props;
  const [refresh, setRefresh] = useState<boolean>(false);
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  const [message, setMessage] = useState<undefined | Chat_Message_Type>(
    undefined
  );

  useEffect(() => {
    const fetchMessageStatus = async () => {
      try {
        const res = await httpAPI.get(
          `${backendURL}/api-v2/auth/${
            loginUserData.userType === "coach" ? "coach" : "coachee"
          }/chat/message-details/${message_id}`
        );
        // console.log(res);
        if (res.status === 200) {
          setMessage(res.data.data);
          // PopAlert.success({ message: "Fethced Message Status " });
        } else {
          // PopAlert.error({ message: "Error Getting  Message Status " });
        }
      } catch (error) {
        console.log(error);
      }
    };
    !props.keepStatic && fetchMessageStatus();
  }, [refresh, message_id, props.keepStatic, loginUserData.userType]);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const refPage = () => {
      // console.log(data, "Recevieed a new event ");
      setRefresh((prev) => !prev);
    };
    if (socket) {
      socket.on("message-status-updated", refPage);
    }
    return () => {
      if (socket) {
        socket.off("message-status-updated", refPage);
      }
    };
  }, [socket]);

  const [statusIcon, setStatusIcon] = useState<
    ReturnType<typeof getStatusIndicator>
  >({
    color: "#999999",
    icon: RxDotsHorizontal,
    announce: "Loading...",
  });

  useEffect(() => {
    if (message && !props.keepStatic) {
      // console.log({ message });
      const status =
        loginUserData.userType === "coachee"
          ? message.messageReadStatusCoach
          : message.messageReadStatusUser;
      const indicator = getStatusIndicator(status as Status);
      setStatusIcon(indicator);
    }
  }, [message, loginUserData.userType, props.keepStatic]);

  useEffect(() => {
    if (props.keepStatic) {
      const message = props.defaultMessage;

      const status =
        loginUserData.userType === "coachee"
          ? message?.messageReadStatusCoach
          : message?.messageReadStatusUser;
      const indicator = getStatusIndicator(status as Status);
      setStatusIcon(indicator);
    }
  }, [props.defaultMessage, loginUserData.userType, props.keepStatic]);

  // useEffect(() => {
  //   console.log({ props });
  // }, [props]);

  if (!message && !props.keepStatic) {
    return (
      <>
        <div
          className="flex items-center gap-1 my-auto"
          style={{ color: "#999999" }}
          aria-label={"Network Error"}
        >
          <RxDotsHorizontal size={18} color={"#999999"} />
        </div>
      </>
    );
  }

  if (props.keepStatic) {
    return (
      <>
        {loginUserData._id === props?.defaultMessage?.senderId && (
          // <Tooltip title={statusIcon.announce}>
          <div
            className="flex items-center gap-1 my-auto"
            style={{ color: statusIcon.color }}
            aria-label={statusIcon.announce}
          >
            <statusIcon.icon size={18} color={statusIcon.color} />
          </div>
          // </Tooltip>
        )}
      </>
    );
  } else {
    return (
      <>
        {loginUserData._id === message?.senderId && (
          // <Tooltip title={statusIcon.announce}>
          <div
            className="flex items-center gap-1 my-auto"
            style={{ color: statusIcon.color }}
            aria-label={statusIcon.announce}
          >
            <statusIcon.icon size={18} color={statusIcon.color} />
          </div>
          // </Tooltip>
        )}
      </>
    );
  }
};

export default ChatMessageDStatus;
