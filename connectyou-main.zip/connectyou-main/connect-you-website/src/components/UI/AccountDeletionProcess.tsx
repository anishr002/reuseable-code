/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { ReactNode } from "react";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useNotify } from "../../lib/Notify";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";
import { logout } from "../../slices/Login";
import AccountDeletionResonsOptions from "../../Options/AccountDeletionResonsOptions";
import logoutLocal from "../../util/logoutLocal";
import MundialHeadingText from "./MundialHeadingText";
import Warning from "./Warning";

interface AccountDeletionProcessProps {
  userType: "coach" | "user";
  children: ReactNode;
}
const AccountDeletionProcess: React.FC<AccountDeletionProcessProps> = ({
  userType,
  children,
}) => {
  const { notifyMe } = useNotify();
  //  request delete accout buttons
  const [openDeleteAccountModal, setOpenDeleteAccountModal] =
    React.useState(false);
  const [deleteAccountModalSteps, setDeleteAccountModalSteps] =
    React.useState<number>(0);
  const [customMessage, setCustomMessage] = React.useState<string>("");
  const [showPassword, setshowPassword] = React.useState(false);
  const [loadingDelete, setLoadingDelete] = React.useState(false);
  const [password, setPassword] = React.useState<string>("");
  const [passwordError, setPasswordError] = React.useState<string | null>(null);
  const [selectedReasons, setSelectedReasons] = React.useState<string[]>([]);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // Function to handle checkbox changes
  const handleCheckboxChange = (reason: string) => {
    setSelectedReasons(
      (prevReasons) =>
        prevReasons.includes(reason)
          ? prevReasons.filter((item) => item !== reason) // Uncheck the checkbox
          : [...prevReasons, reason] // Check the checkbox
    );
  };

  // Function to handle form submission
  const handleSubmitAccountDelete = async () => {
    setLoadingDelete(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/${userType}/profile/account-delete-request`,
        { password: password, reason: selectedReasons, message: customMessage }
      );
      if (response.status === 200) {
        setOpenDeleteAccountModal(false);
        dispatch(logout());

        logoutLocal();
        return navigate("/");
      }
    } catch (error: any) {
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
        setPasswordError(
          error.response.data.message
            ? error.response.data.message
            : "Something went wrong"
        );
        return setLoadingDelete(false);
      } else {
        notifyMe({ message: "Something went wrong", severity: "error" });
        return setLoadingDelete(false);
      }
    } finally {
      setLoadingDelete(false);
    }
  };
  return (
    <>
      <div
        onClick={() => {
          setOpenDeleteAccountModal(true);
          setDeleteAccountModalSteps(0);
        }}
      >
        {children}
      </div>
      <>
        <CustomModalWrapper
          backdropClose={false}
          open={openDeleteAccountModal}
          onClose={() => setOpenDeleteAccountModal(false)}
          title="Delete Account"
        >
          <>
            {deleteAccountModalSteps === 0 && (
              <div className="flex flex-col gap-3 pt-4 ">
                <MundialHeadingText sizeVariant="xs" variant="darksea">
                  Are You Sure You want to Delete Your Account ?
                </MundialHeadingText>
                <div className="text-[#013338] font-normal text-center  text-[16px]">
                  <Warning variant="red">
                    All your information will be deleted and you will not be
                    able to recover your account after deletion.
                  </Warning>
                </div>
                <Button
                  onClick={() => setDeleteAccountModalSteps(1)}
                  variant="contained"
                  sx={{
                    boxShadow: 0,
                    background: "red",
                    color: "white",
                    border: "1px solid transparent",
                    fontFamily: "Quicksand",
                    "&:hover": {
                      color: "red",
                      background: "white",
                      border: "1px solid red",
                    },
                  }}
                >
                  Proceed To Delete My Account
                </Button>
              </div>
            )}
            {deleteAccountModalSteps === 1 && (
              <Box sx={{ height: 500 }}>
                <Typography
                  variant="h6"
                  sx={{ fontFamily: "Quicksand", textAlign: "center" }}
                >
                  Please Select an option, why you want to delete your account ?
                </Typography>
                <Box>
                  <div className="max-w-md p-6 mx-auto ">
                    <h2 className="text-md font-semibold mb-4 font-[Quicksand]">
                      Why are you deleting your account?
                    </h2>
                    {AccountDeletionResonsOptions.map((reason, index) => (
                      <div key={index} className="mb-2">
                        <label className="inline-flex items-center  font-[Quicksand]">
                          <input
                            type="checkbox"
                            value={reason}
                            checked={selectedReasons.includes(reason)}
                            onChange={() => handleCheckboxChange(reason)}
                            className="form-checkbox h-4 w-4 text-blue-600 font-[Quicksand]"
                          />
                          <span className="ml-2">{reason}</span>
                        </label>
                      </div>
                    ))}
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 mb-2 font-[Quicksand]"
                        htmlFor="customMessage"
                      >
                        Additional Comments (Optional)
                      </label>
                      <textarea
                        id="customMessage"
                        value={customMessage}
                        onChange={(e) => setCustomMessage(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md"
                        rows={3}
                        placeholder="Write your message here..."
                      />
                    </div>
                    <span className="w-full flex justify-end">
                      <Button
                        onClick={() => {
                          setDeleteAccountModalSteps(2);
                        }}
                        variant="contained"
                        disabled={selectedReasons.length === 0 && true}
                        sx={{
                          boxShadow: 0,
                          background: "red",
                          color: "white",
                          "&:hover": {
                            color: "red",
                            background: "white",
                            border: "1px solid red",
                          },
                        }}
                      >
                        {" "}
                        Delete Account
                      </Button>
                    </span>
                  </div>
                </Box>
              </Box>
            )}
            {deleteAccountModalSteps === 2 && (
              <Box sx={{ overflow: "auto", textAlign: "center" }}>
                <Typography variant="h6" sx={{ fontFamily: "Quicksand" }}>
                  Please Enter Your Account Password below.
                </Typography>
                <Typography variant="caption" sx={{ color: "red" }}>
                  **Account Once deleted cannot be recovered.
                </Typography>
                <Box>
                  <div className="max-w-md p-6 mx-auto bg-white rounded-lg shadow-lg flex flex-col gap-2">
                    <h2 className="text-md font-medium mb-4">
                      Confirm Identity to delete your account.
                    </h2>
                    <FormControl variant="outlined" fullWidth size="small">
                      <div className="text-left text-[#013338] font-bold text-[18px] pb-2 w-full ">
                        Password
                      </div>
                      <TextField
                        size="small"
                        id="outlined-adornment-password"
                        type={showPassword ? "text" : "password"}
                        autoComplete="password"
                        value={password}
                        onChange={(e) => {
                          const pass = e.target.value;
                          setPassword(pass);
                          setPasswordError((prev) => (prev ? null : null));
                        }}
                        hiddenLabel
                        slotProps={{
                          input: {
                            endAdornment: (
                              <InputAdornment position="end">
                                <IconButton
                                  aria-label="toggle password visibility"
                                  onClick={() => setshowPassword(!showPassword)}
                                  edge="end"
                                >
                                  {showPassword ? (
                                    <VisibilityOff />
                                  ) : (
                                    <Visibility />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            ),
                          },
                        }}
                      />
                    </FormControl>
                    {passwordError && (
                      <FormHelperText sx={{ color: "red" }}>
                        {passwordError}
                      </FormHelperText>
                    )}
                    <Button
                      onClick={() => {
                        password?.length !== 0 && handleSubmitAccountDelete();
                      }}
                      variant="contained"
                      disabled={password?.length == 0 && true}
                      sx={{
                        mt: 4,
                        boxShadow: 0,
                        background: "red",
                        color: "white",
                        "&:hover": {
                          color: "red",
                          background: "white",
                          border: "1px solid red",
                        },
                      }}
                    >
                      {loadingDelete ? (
                        <CircularProgress size={24} color="inherit" />
                      ) : (
                        " Delete Account"
                      )}
                    </Button>
                  </div>
                </Box>
              </Box>
            )}
          </>
        </CustomModalWrapper>
      </>
    </>
  );
};

export default AccountDeletionProcess;
