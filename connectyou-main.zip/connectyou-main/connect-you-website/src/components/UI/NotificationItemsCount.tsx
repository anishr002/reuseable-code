/* eslint-disable @typescript-eslint/no-explicit-any */
import { useSelector } from "react-redux";

const NotificationItemsCount = ({
  variant = "right-top",
}: {
  variant?: "right-top" | "left-top" | "inline";
}) => {
  const unreadCount = useSelector(
    (state: any) => state.unreadCount.unReadNotificationCount
  );

  if (unreadCount <= 0) return null;

  // Define position styles based on the variant
  const positionStyles: Record<string, React.CSSProperties> = {
    "right-top": { top: -4, right: "-40%" },
    "left-top": { top: -4, left: "-40%" },
    inline: { position: "static", marginLeft: "2px" },
  };

  return (
    <span
      style={{
        background: "#ebbe34",
        color: "white",
        width: "20px",
        height: "20px",
        borderRadius: "50%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "0.75rem",
        position: variant === "inline" ? "relative" : "absolute",
        boxShadow: "0px 0px 8px rgba(0, 0, 0, 0.15)",
        ...positionStyles[variant],
      }}
    >
      {unreadCount < 9 ? unreadCount : "9+"}
    </span>
  );
};

export default NotificationItemsCount;
