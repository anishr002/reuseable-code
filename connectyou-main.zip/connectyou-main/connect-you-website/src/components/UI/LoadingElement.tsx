import React, { ReactNode } from "react";
import Logo from "/loginLogo.png";
import { InfinitySpin } from "react-loader-spinner";
import Warning from "./Warning";
import BackdropLoading from "../Skeletons/BackdropLoading";
import Image from "./Image";

interface LoadingElementProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "full" | "dynamic";
  children?: ReactNode;
}

const LoadingElement = React.memo((props: LoadingElementProps) => {
  const { variant = "dynamic", children, ...rest } = props;

  if (variant === "full") {
    return (
      <div
        {...rest}
        className={` flex flex-col w-full min-h-screen justify-center items-center py-10 `}
      >
        <div className="flex flex-col w-full items-center justify-center">
          <InfinitySpin width="200" color="#ebbd33" />
          <Image
            src={Logo}
            alt="Logo"
            className="object-contain"
            height={200}
            width={300}
            fallback={"Loading"}
          />
        </div>
        {children ? (
          children
        ) : (
          <p className=" text-[#ebbd33] text-base font-quicksand ">
            Please wait, Loading....
          </p>
        )}
      </div>
    );
  }

  if (variant === "dynamic") {
    return (
      <div
        {...rest}
        className={`flex flex-col w-full h-full flex-1 justify-center items-center `}
      >
        <InfinitySpin width="200" color="#ebbd33" />
        {children ? children : <></>}
      </div>
    );
  }
});

const BackdropLoader = ({
  open = false,
  text = "Please wait while we are updating your changes.",
  children,
}: {
  open?: boolean;
  text?: ReactNode;
  children?: ReactNode;
}) => {
  return (
    <>
      <BackdropLoading open={open}>
        <div className="w-full h-fit flex  flex-col items-center justify-center ">
          {children}
          <LoadingElement
            color="#3aa7a3"
            variant="dynamic"
            style={{ height: "10px" }}
          />
          {text && <Warning variant="yellow">{text}</Warning>}
        </div>
      </BackdropLoading>
    </>
  );
};

export { BackdropLoader };
export default LoadingElement;
