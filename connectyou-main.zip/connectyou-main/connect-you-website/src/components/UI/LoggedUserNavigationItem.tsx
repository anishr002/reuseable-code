/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useRef, useState } from "react";
import { MdDashboard } from "react-icons/md";
import { IoMdLogOut } from "react-icons/io";
import { IoNotifications, IoPersonSharp } from "react-icons/io5";
import { useDispatch, useSelector } from "react-redux";
import { Avatar, ClickAwayListener, Fade, Paper, Popper } from "@mui/material";
import { logout } from "../../slices/Login";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { setCount } from "../../slices/Notification";
import { Link, NavLink, useNavigate } from "react-router-dom";
import NotificationItemsCount from "./NotificationItemsCount";
import logoutLocal from "../../util/logoutLocal";
import customAlert from "../../lib/swalExtentions";
// import { FaTruckMedical } from "react-icons/fa6";

interface LoggedUserNavigationItemProps {
  helper?: () => void;
  i?: number;
  link: { name: string; link: string };
  showName?: boolean;
  size?: number;
}
const LoggedUserNavigationItem: React.FC<LoggedUserNavigationItemProps> = ({
  helper,
  i,
  link,
  showName = true,
  size = 35,
}) => {
  const loggedUser = useSelector((state: any) => state.login.userdata);
  const navigate = useNavigate();
  const popperRef = useRef<HTMLDivElement | null>(null);
  const dispatch = useDispatch();
  const [openPopper, setopenPopper] = React.useState<boolean>(false);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setopenPopper((previousOpen) => !previousOpen);
  };
  const handleClickAway = () => {
    setopenPopper(false);
  };
  const handleLogout = () => {
    dispatch(logout());
    logoutLocal();
    setopenPopper(false);
    return navigate("/");
  };
  const loginData = loggedUser?.name && loggedUser;
  const loginUserType = loginData
    ? loggedUser.userType == "coach"
      ? "c"
      : "u"
    : null;

  const capitalizeFirstLetter = (string: string) => {
    if (!string) return "E";
    return string.charAt(0).toUpperCase();
  };

  const fetchNotifications = async () => {
    try {
      const response = await httpAPI.post(
        `${backendURL}/${
          loggedUser.userType === "coach" ? "coach" : "user"
        }/profile/get-all-notifications`,
        { _id: loggedUser._id }
      );
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        dispatch(setCount(response.data.unreadNotifications));
      }
    } catch (error: any) {
      console.log(error);
    }
  };
  useEffect(() => {
    if (loginUserType) {
      fetchNotifications();
    }
  }, [loggedUser, openPopper]);

  const [isloggedIn, setIsLoggedIn] = useState<boolean>(false);
  useEffect(() => {
    if (Object.keys(loggedUser).length > 0) {
      setIsLoggedIn(true);
    } else setIsLoggedIn(false);
  }, [loggedUser]);

  return (
    <div>
      {isloggedIn ? (
        <>
          <button
            onClick={(e) => {
              handleClick(e);
              if (helper) {
                helper();
              }
            }}
            key={`navigation-link-${i}-header-${link.name}`}
            className={`flex  ${
              showName
                ? openPopper
                  ? "flex-row-reverse pl-4"
                  : "flex-row pr-4"
                : ""
            } justify-start -order-1 lg:order-1  transition-all duration-200 ease-in-out  text-md md:text-base items-center cursor-pointer ${
              showName && "min-w-[100px]"
            } uppercase  rounded-[30px] max-w-fit bg-[#3aa7a3] relative whitespace-nowrap  gap-3 border border-transparent overflow-hidden hover:border-[#3aa7a3] hover:bg-[white]  text-xs sm:text-sm text-[white] hover:text-[#3aa7a3]`}
            type="button"
            style={{
              height: size,
            }}
          >
            <div
              className={` w-full h-full flex justify-center items-center rounded-full max-w-fit bg-[white]  `}
            >
              <Avatar
                alt={capitalizeFirstLetter(
                  loginData?.firstName || loginData?.name || "U"
                )}
                src={`${backendURL}/usersProfile/${loggedUser.image}`}
                sx={{
                  height: size,
                  width: size,
                }}
              />
            </div>
            {showName && (
              <span className=" max-w-[100px] text-ellipsis line-clamp-1">
                {loggedUser?.firstName ||
                  loggedUser?.name?.split(" ")[0] ||
                  "User"}
              </span>
            )}
          </button>
          <Popper
            ref={popperRef}
            open={openPopper}
            anchorEl={anchorEl}
            transition
            sx={{
              inset: "0px auto auto -3px !important",
              zIndex: 9999,
              mt: 2,
            }}
            modifiers={[
              {
                name: "arrow",
                enabled: true,
                options: {
                  element: anchorEl,
                },
              },
            ]}
          >
            {({ TransitionProps }) => (
              <Fade {...TransitionProps} timeout={350}>
                <Paper
                  elevation={2}
                  sx={{
                    fontFamily: "Quicksand",
                    borderRadius: 2,
                    overflow: "hidden",
                  }}
                >
                  <ClickAwayListener onClickAway={handleClickAway}>
                    <div className="flex flex-col mt-1 w-64 ">
                      <div className="flex items-center gap-2 py-3 px-3">
                        <div className="w-full h-full py-1">
                          <Avatar
                            alt={capitalizeFirstLetter(loginData?.name)}
                            src={`${backendURL}/usersProfile/${loginData?.image}`}
                            sx={{
                              width: 60,
                              height: 60,
                            }}
                          />
                        </div>
                        <div className="flex flex-col justify-center text-[#013338]">
                          <p className=" leading-tight font-semibold line-clamp-1 text-ellipsis max-w-[90%]">
                            {loggedUser?.name || loggedUser?.firstName}{" "}
                            {loggedUser?.Lname}
                          </p>
                          <p className="text-xs break-all  w-44 line-clamp-1 ">
                            {loggedUser?.email}
                          </p>
                        </div>
                      </div>
                      <Link
                        to={`/${loginUserType}`}
                        onClick={() => setopenPopper(false)}
                        className="flex items-center gap-2 cursor-pointer hover:bg-slate-200 py-3 px-3 w-full"
                      >
                        <div className="flex flex-col justify-center w-full">
                          <div className="flex items-center gap-2 w-full">
                            <span>
                              <MdDashboard className="text-[#3aa7a3] text-[24px]" />
                            </span>
                            <div className="flex flex-col justify-center">
                              <p className="text-[#013338] font-medium">
                                Dashboard
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                      <Link
                        to={`/${loginUserType}/profile`}
                        onClick={() => setopenPopper(false)}
                        className="flex items-center cursor-pointer hover:bg-slate-200 py-3 px-3 w-full"
                      >
                        <div className="flex items-center gap-2 w-full">
                          <span>
                            <IoPersonSharp className="text-[#3aa7a3] text-[24px]" />
                          </span>
                          <div className="flex flex-col justify-center">
                            <p className="text-[#013338] font-medium">
                              Profile
                            </p>
                          </div>
                        </div>
                      </Link>
                      <Link
                        to={`/${loginUserType}/notifications`}
                        onClick={() => setopenPopper(false)}
                        className="flex items-center cursor-pointer hover:bg-slate-200 py-3 px-3 w-full"
                      >
                        <div className="flex items-center gap-2 w-full">
                          <div className="relative">
                            <NotificationItemsCount />
                            <IoNotifications className="text-[#3aa7a3] text-[24px]" />
                          </div>
                          <div className="flex flex-col justify-center">
                            <p className="text-[#013338] font-medium">
                              Notifications
                            </p>
                          </div>
                        </div>
                      </Link>
                      <div
                        onClick={() => {
                          setopenPopper(false);
                          customAlert
                            .fire({
                              title: "Are you sure?",
                              text: "You really want to logout this account?",
                              showCancelButton: true,
                              showConfirmButton: true,
                              confirmButtonText: "Yes, Logout",
                              showLoaderOnConfirm: true,
                              cancelButtonText: "No",
                            })
                            .then((result) => {
                              if (result.isConfirmed) {
                                handleLogout();
                              }
                            });
                        }}
                        className="flex items-center gap-2 border border-transparent border-t-2 border-t-gray-200 pt-3 cursor-pointer hover:bg-slate-200 py-3 px-3 w-full"
                      >
                        <span>
                          <IoMdLogOut className="text-[red] text-[24px]" />
                        </span>
                        <div className="flex flex-col justify-center w-full">
                          <p className="text-[#013338] font-medium">Log out</p>
                        </div>
                      </div>
                    </div>
                  </ClickAwayListener>
                </Paper>
              </Fade>
            )}
          </Popper>
        </>
      ) : (
        <NavLink
          key={`navigation-link-${i}-header-${link.name}`}
          className=" -order-1 lg:order-1   w-fit text-[#3aa7a3]  hover:text-[#3aa7a3] transition duration-300 rounded-[100px] min-w-[100px]  "
          to={link.link}
        >
          <button
            type="button"
            className="w-full h-full uppercase cursor-pointer flex justify-center items-center font-semibold text-md border border-[#3aa7a3] px-3 py-1 rounded-[100px] "
            onClick={() => {
              if (helper) {
                helper();
              }
            }}
          >
            {link.name}
          </button>
        </NavLink>
      )}
    </div>
  );
};

export default LoggedUserNavigationItem;
