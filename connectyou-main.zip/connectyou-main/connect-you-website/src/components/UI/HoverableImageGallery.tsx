import React, { useState } from "react";
import { Box } from "@mui/material";
import "../../styles/HoverableImageGallery.css";
import Business_Challenege_Content_TYPE from "../../Types/UI/BusinessChallenege_Content_TYPE";

interface HoverableImageGalleryProps {
  content: Business_Challenege_Content_TYPE[];
}
const HoverableImageGallery: React.FC<HoverableImageGalleryProps> = ({
  content,
}) => {
  const [expanded, setExpanded] = useState<number>(0);
  const handleMouseEnter = (num: number) => setExpanded(num);
  const handleMouseLeave = () => setExpanded(0);

  return (
    <Box className="flex space-x-1.5 md:space-x-4 w-full">
      {content.map((frame: Business_Challenege_Content_TYPE, index: number) => (
        <Box
          key={`business-challenege-content-slide-${index}`}
          onMouseEnter={() => handleMouseEnter(index)}
          onMouseLeave={handleMouseLeave}
          onClick={() => handleMouseEnter(index)}
          className={`expandable-card relative  min-w-[10%] md:min-h-[450px] md:h-[80vh] h-80 transition-all duration-[300ms] ease-linear bg-black w-full   rounded-[20px] overflow-hidden group ${
            expanded === index ? "flex-9" : "flex-1"
          }`}
        >
          <img
            src={frame.image}
            alt="Image 1"
            className={`absolute inset-0 w-full md:object-[50%_0%] object-[70%_0%] ${
              expanded === index
                ? "object-cover h-full md:h-full md:object-cover w-full"
                : "object-cover md:h-full md:object-cover w-full h-full"
            } transition-all duration-500 ease-in-out group-hover ${
              expanded === index
                ? "origin-top-right md:origin-top opacity-100"
                : "origin-top opacity-35"
            }`}
          />
          <div
            className={`${
              expanded === index
                ? " bg-gradient-to-r from-[#000000cc] via-[63%] to-transparent"
                : "bg-gradient-to-r from-[#000000cc] via-[63%] to-transparent"
            } absolute inset-0 w-full h-full `}
          ></div>
          {
            <div
              className={`absolute inset-0 w-full h-full flex items-center  ${
                expanded === index ? "opacity-100" : "opacity-0"
              } transition-opacity duration-500`}
            >
              <div className="relative z-10 p-4 md:p-8 max-w-md">
                <p className="text-base md:text-[32px] font-bold font-mundial uppercase text-white mb-2 md:mb-4 transform transition-transform duration-500 translate-y-0">
                  {frame.heading}
                </p>
                <p className="text-white font-medium text-sm md:text-[20px] transform transition-transform duration-500 translate-y-0">
                  {frame.description}
                </p>
              </div>
            </div>
          }
        </Box>
      ))}
    </Box>
  );
};

export default HoverableImageGallery;
