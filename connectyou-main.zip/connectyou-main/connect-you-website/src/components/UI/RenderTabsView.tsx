import { useState, ReactNode } from "react";
import { DarkThemeButtonTransparent } from "../buttons/ThemeButtons";

export type Tab = {
  tabTitle: string;
  Element: ReactNode;
};

const RenderTabsView = ({ tabs }: { tabs: Tab[] }) => {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <div className="w-full flex-1 h-full ">
      <div className="flex  mb-4  gap-2 flex-wrap justify-start items-center ">
        {tabs.map((tab, index) => (
          <DarkThemeButtonTransparent
            style={{
              width: "fit-content",
            }}
            text={tab.tabTitle}
            key={index}
            onClick={() => setActiveTab(index)}
            isActive={index === activeTab}
          >
            {tab.tabTitle}
          </DarkThemeButtonTransparent>
        ))}
      </div>
      <div className="flex flex-col  min-h-fit ">{tabs[activeTab].Element}</div>
    </div>
  );
};

export default RenderTabsView;
