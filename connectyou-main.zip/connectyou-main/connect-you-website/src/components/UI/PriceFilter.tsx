import { useState, useMemo, useEffect } from "react";
import { Box, Slider, Typography, styled } from "@mui/material";
import { useFormContext } from "react-hook-form";

// Styled Components
const FilterWrapper = styled(Box)({
  width: "100%",
  padding: "0 16px",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
});

const BarGraphContainer = styled(Box)({
  display: "flex",
  justifyContent: "flex-start", // Ensure bars start from the left
  alignItems: "flex-end",
  height: "100px",
  width: "100%",
  padding: "0 8px",
  marginBottom: "16px",
  gap: "8px", // Add spacing of 8px between bars
});

const Bar = styled(Box)<{ active: boolean; height: number }>((props) => ({
  width: "29px", // Set fixed width of each bar
  height: `${props.height}px`, // Set height dynamically based on pattern
  backgroundColor: props.active ? "#3AA7A3" : "rgba(58, 167, 163, 0.4)",
  transition: "background-color 0.3s",
}));

const StyledSlider = styled(Slider)({
  color: "#013338",
  "& .MuiSlider-thumb": {
    backgroundColor: "#013338",
  },
  width: "100%",
});

const PriceFilter = ({
  selectedValue,
}: {
  selectedValue?: { from: number; to: number };
}) => {
  const [range, setRange] = useState<[number, number]>([100, 200]);
  const methods = useFormContext();
  useEffect(() => {
    if (range) {
      methods.setValue("selectedValues", { from: range[0], to: range[1] });
    }
  }, [range]);
  
  useEffect(() => {
    if (selectedValue) {
      setRange([selectedValue.from, selectedValue.to]);
    }
  }, [selectedValue]);
  // Define price points for the bars
  const pricePoints = useMemo(() => [0, 100, 200, 300, 400], []);

  // Define exact label mapping
  const labelsMap: Record<number, string> = {
    0: "< $100",
    100: "$100",
    200: "$200",
    300: "$300",
    400: "$400 +",
  };

  // Define height pattern with slight randomness
  const heightPattern = [35, 49, 68, 82, 68, 82, 56, 49, 76, 27, 19, 36, 18];

  // Create bars between each price point
  const bars = useMemo(() => {
    const barsArray = [];
    for (let i = 0; i < pricePoints.length - 1; i++) {
      const start = pricePoints[i];
      const end = pricePoints[i + 1];

      // Create 3 bars between each price point
      const barsInBetween = 3;
      const step = (end - start) / (barsInBetween + 1); // Calculate the distance between bars

      for (let j = 1; j <= barsInBetween; j++) {
        barsArray.push(start + j * step); // Push the price point for each bar in between
      }
    }

    // Add the final bar at the end (corresponding to +$400)
    barsArray.push(pricePoints[pricePoints.length - 1]);

    return barsArray;
  }, [pricePoints]);

  // Handle range change
  const handleChange = (_: Event, newValue: number | number[]) => {
    setRange(newValue as [number, number]);
  };

  return (
    <FilterWrapper>
      {/* Bar Graph */}
      <BarGraphContainer>
        {bars.map((barValue, index) => (
          <Bar
            key={index}
            active={barValue >= range[0] && barValue <= range[1]}
            height={heightPattern[index % heightPattern.length]} // Use height pattern
          />
        ))}
      </BarGraphContainer>

      {/* Price Labels */}
      <StyledSlider
        value={range}
        onChange={handleChange}
        min={0}
        max={400}
        step={100}
        marks={pricePoints.map((point) => ({
          value: point,
        }))}
      />
      <Box display="flex" justifyContent="space-between" width="100%" pt={2}>
        {pricePoints.map((point) => (
          <Typography
            key={point}
            variant="body2"
            sx={{
              fontSize: { xs: 14, md: "18px" },
              fontWeight: 500,
              color: "#013338",
            }}
          >
            {labelsMap[point]}
          </Typography>
        ))}
      </Box>
    </FilterWrapper>
  );
};

export default PriceFilter;
