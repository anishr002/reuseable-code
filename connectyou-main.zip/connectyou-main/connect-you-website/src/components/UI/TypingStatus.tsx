import { ReactNode, useEffect, useState } from "react";
import { SocketWithState } from "../../contexts/SocketContext";
import { ThreeDots } from "react-loader-spinner";

const TypingStatusIndicator = ({
  props,
  loginId,
  selectedUserId,
  socket,
  showTypingStr = false,
  children,
}: {
  props: React.HTMLAttributes<HTMLDivElement>;
  socket: SocketWithState | null;
  loginId: string | null | undefined;
  selectedUserId: string | null | undefined;
  children?: ReactNode;
  showTypingStr?: boolean;
}) => {
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    // console.log({
    //   loginId,
    //   socket,
    // });
    if (!socket || !loginId) return;

    const handleTypingStatus = (data: {
      sendingTo: string;
      userId: string;
      isTyping: boolean;
    }) => {
      // console.log(data);
      if (data.sendingTo === loginId && data.userId === selectedUserId) {
        setIsTyping(data.isTyping);
        setTimeout(() => {
          setIsTyping(false);
        }, 3000); // Reset after 3 seconds of inactivity
      }
    };

    socket.on("typing-status", handleTypingStatus);

    return () => {
      socket.off("typing-status", handleTypingStatus);
    };
  }, [socket, loginId, selectedUserId]);

  return (
    <>
      {isTyping ? (
        <div
          {...props}
          className={`inline-flex flex-row whitespace-nowrap text-inherit justify-center items-center leading-0 text-sm ${
            props?.className ?? ""
          }`}
        >
          {showTypingStr && (
            <span style={{ color: props?.style?.color ?? "inherit" }}>
              Typing
            </span>
          )}
          <ThreeDots
            color={props?.style?.color ?? "inherit"}
            height={8}
            width={36}
            wrapperClass="pt-1"
          />
        </div>
      ) : (
        children
      )}
    </>
  );
};

export default TypingStatusIndicator;
