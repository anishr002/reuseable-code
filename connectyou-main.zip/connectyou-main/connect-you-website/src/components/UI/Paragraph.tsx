import { useEffect, useRef, useState } from "react";

const Paragraph = ({
  children,
  lines = 5,
  className,
}: {
  children: string;
  lines?: number;
  className?: string;
}) => {
  const descriptionRef = useRef<HTMLParagraphElement | null>(null);
  const [addSeeMore, setAddSeeMore] = useState<boolean>(false);
  useEffect(() => {
    if (descriptionRef.current) {
      const lineHeight = parseFloat(
        getComputedStyle(descriptionRef.current).lineHeight
      );
      const maxHeight = lineHeight * lines;
      if (descriptionRef.current.scrollHeight > maxHeight) {
        setAddSeeMore(true);
      }
    }
  }, [descriptionRef, children, lines]);

  const [expand, setExpand] = useState(false);

  return (
    <>
      <p
        style={
          !expand
            ? {
                display: "-webkit-box",
                WebkitLineClamp: lines,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
              }
            : {}
        }
        ref={descriptionRef}
        className={className}
      >
        {children}
      </p>
      {addSeeMore && (
        <span
          onClick={() => setExpand((prev) => !prev)}
          className="text-sm font-normal hover:underline mt-2  cursor-pointer"
        >
          {expand ? "See less" : "See more"}
        </span>
      )}
    </>
  );
};

export default Paragraph;
