import React, { ReactNode } from "react";

interface TopNavigationBarProps {
  children: ReactNode;
}
const TopNavigationBar: React.FC<TopNavigationBarProps> = ({ children }) => {
  return (
    <div className="w-full h-full flex justify-between items-center gap-1 text-sm font-[600] ">
      {children}
    </div>
  );
};

export default TopNavigationBar;
