import React, { ReactNode } from "react";

interface FooterNavigationProps {
  children: ReactNode;
}
const FooterNavigation: React.FC<FooterNavigationProps> = ({ children }) => {
  return (
    <div className="w-full h-full flex flex-1 flex-col md:flex-row  justify-between md:items-center items-start ps-3 md:ps-0 gap-4 md:gap-1 text-sm font-[600] ">
      {children}
    </div>
  );
};

export default FooterNavigation;
