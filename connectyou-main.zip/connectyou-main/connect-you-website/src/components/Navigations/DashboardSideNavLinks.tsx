import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import strMatch from "../../util/strMatch";
import { linkType } from "../../Options/navigationLinkOptions";

interface DashboardSideNavLinksProps {
  links: linkType[];
  colors?: {
    primary: string;
    secondary: string;
  };
  onClick?: () => void;
}
const DashboardSideNavLinks: React.FC<DashboardSideNavLinksProps> = ({
  links,
  colors = {
    primary: "#013338",
    secondary: "#3aa7a3",
  },
  onClick,
}) => {
  const location = useLocation();
  const [activeRoute, setActiveRoute] = useState<string>("");

  useEffect(() => {
    if (location.pathname) {
      setActiveRoute(location.pathname);
    }
  }, [location.pathname]);

  return (
    <>
      {links.map((option, i) => {
        const isActive = strMatch(activeRoute, option.link);
        return (
          <React.Fragment key={`dash-board-links-${i}`}>
            <Link
              onClick={onClick}
              to={option.link}
              className="flex cursor-pointer flex-row justify-start items-center gap-3"
            >
              <div className="flex items-center justify-center w-fit text-[18px] cursor-pointer">
                {(option.icon && (
                  <option.icon
                    style={{
                      color: isActive ? colors.secondary : colors.primary,
                      fontSize: isActive ? "24px" : "22px",
                      fontWeight: "bold",
                    }}
                  />
                )) ||
                  "-"}
              </div>
              <div
                className={`${
                  isActive ? "font-bold" : " font-medium"
                } text-[18px]`}
                style={{
                  color: isActive ? colors.secondary : colors.primary,
                }}
              >
                {option.name}
              </div>
            </Link>
          </React.Fragment>
        );
      })}
    </>
  );
};

export default DashboardSideNavLinks;
