import { ReactNode } from "react";

const DummyTextField = ({
  textLabel,
  value,
  extraElement = null,
  keepBorder = true,
  endAdornment,
  borderColor = "darkSea",
  borderStyle = "solid",
}: {
  keepBorder?: boolean;
  textLabel?: ReactNode;
  value?: ReactNode;
  extraElement?: ReactNode;
  endAdornment?: ReactNode;
  borderColor?: "darkSea" | "seaBlue";
  borderStyle?: "solid" | "dashed" | "dotted" | "hidden";
}) => {
  return (
    <div className="flex flex-col justify-between flex-1 w-full h-full relative">
      {textLabel &&
        (typeof textLabel === "string" ? (
          <span className="text-[#013338] pb-2 text-[18px] font-medium">
            {textLabel}
          </span>
        ) : (
          <>{textLabel}</>
        ))}
      {extraElement ? extraElement : null}
      <div
        style={{
          borderStyle: borderStyle,
        }}
        className={`flex flex-row justify-between items-start flex-1 rounded-[5px] border break-all ${
          keepBorder
            ? borderColor === "darkSea"
              ? "border-[#013338]  p-[7px]"
              : "border-[#3aa7a3]  p-[7px]"
            : "border-transparent  p-[]"
        }  text-[#013338] font-medium`}
      >
        {value || <div className="opacity-0">asdf</div>}
        <div className="shrink-0 w-fit h-full flex items-center justify-center">
          {endAdornment}
        </div>
      </div>
    </div>
  );
};

export default DummyTextField;
