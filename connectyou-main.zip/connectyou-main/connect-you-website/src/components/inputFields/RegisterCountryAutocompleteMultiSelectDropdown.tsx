import React from "react";
import { useFormContext, Controller } from "react-hook-form";
import {
  Autocomplete,
  TextField,
  Checkbox,
  createTheme,
  ThemeProvider,
} from "@mui/material";
import { ExpandMore, Close } from "@mui/icons-material";
import { CountryType } from "../../Options/Options";
import RenderCountryFlag from "../UI/RenderCountryFlag";

// Custom Theme
const theme = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          fontFamily: "Quicksand",
          borderColor: "#3aa7a3", // Default border
          borderRadius: "10px", // Added border radius
          ".MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          ".css-19qnlrw-MuiFormLabel-root-MuiInputLabel-root": {
            color: "#3aa7a3",
          },
          "css-113d811-MuiFormLabel-root-MuiInputLabel-root.Mui-focused": {
            color: "#3aa7a3",
          },
        },
        input: {
          color: "#013338",
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        popupIndicator: {
          color: "#3aa7a3", // Arrow color
        },
        root: {
          ".css-19qnlrw-MuiFormLabel-root-MuiInputLabel-root": {
            color: "#3aa7a3",
          },
          "css-113d811-MuiFormLabel-root-MuiInputLabel-root.Mui-focused": {
            color: "#3aa7a3",
          },
        },
      },
    },
  },
});

interface ComponentProps {
  options: CountryType[];
  name: string;
  label?: string;
}

const RegisterCountryAutocompleteMultiSelectDropdown: React.FC<
  ComponentProps
> = ({ options, name, label = "Please Select" }) => {
  const { control } = useFormContext();

  return (
    <ThemeProvider theme={theme}>
      <Controller
        name={name}
        control={control}
        render={({ field }) => (
          <div>
            {/* Autocomplete Select Field */}
            <Autocomplete
              multiple
              options={options}
              getOptionLabel={(option) => option.label}
              value={field.value || []} // Ensure value is an array of CountryType
              onChange={(_, newValue) => field.onChange(newValue)}
              popupIcon={<ExpandMore style={{ color: "#3aa7a3" }} />}
              renderOption={(props, option, { selected }) => (
                <li {...props} className="flex items-center gap-3">
                  <Checkbox
                    checked={
                      field.value?.some(
                        (item: CountryType) => item.code === option.code
                      ) || false
                    }
                    sx={{
                      color: "#013338",
                      "&.Mui-checked": {
                        color: "#013338",
                      },
                    }}
                  />
                  <div
                    className={`${
                      selected ? "font-bold" : "font-normal"
                    } text-[#013338] flex w-full justify-start items-center line-clamp-1 gap-3`}
                  >
                    <span className="w-6 h-6">
                      <RenderCountryFlag country={option} variant="rounded" />
                    </span>
                    <span> {option.label}</span>
                  </div>
                </li>
              )}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={label}
                  variant="outlined"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: "10px",
                      borderColor: "#3aa7a3",
                    },
                    "css-113d811-MuiFormLabel-root-MuiInputLabel-root.Mui-focused":
                      {
                        color: "#3aa7a3",
                      },
                  }}
                  slotProps={{
                    input: {
                      ...params.InputProps,
                      startAdornment: null, // Hide selected values inside input
                    },
                  }}
                />
              )}
            />

            {/* Selected Items - Render Below Select Field */}
            <div className="mt-4 flex flex-wrap gap-2">
              {field.value?.map((selectedItem: CountryType) => (
                <div
                  key={selectedItem.code}
                  className="flex items-center justify-center leading-none bg-[#013338] text-white px-4 py-1 rounded-full"
                >
                  <div className="mr-2 flex flex-row justify-start items-center gap-3">
                    <span className="w-6 h-6 hidden">
                      <RenderCountryFlag
                        country={selectedItem}
                        variant="rounded"
                      />
                    </span>
                    {selectedItem.label}
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      field.onChange(
                        field.value.filter(
                          (item: CountryType) => item.code !== selectedItem.code
                        )
                      )
                    }
                    className="text-white hover:text-red-700 cursor-pointer"
                  >
                    <Close fontSize="small" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      />
    </ThemeProvider>
  );
};

export default RegisterCountryAutocompleteMultiSelectDropdown;
