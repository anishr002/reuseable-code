/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from "react";
import {
  FormControl,
  FormHelperText,
  Box,
  Paper,
  Typography,
  Button,
  styled,
  Tooltip,
  IconButton,
} from "@mui/material";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

import dayjs, { Dayjs } from "dayjs";
import { FieldError, Merge } from "react-hook-form";
import { DateCalendar, LocalizationProvider } from "@mui/x-date-pickers";
import CustomModalWrapper from "../wrappers/CustomModalWrapper";

import MundialHeadingText from "../UI/MundialHeadingText";
import { IoClose } from "react-icons/io5";
const StyledCalendar = styled(DateCalendar)({
  backgroundColor: "white",
  padding: "8px",
  "& .MuiPickersDay-root": {
    color: "#013338",
  },
  "& .MuiPickersDay-root.Mui-disabled": {
    color: "#d3d3d3",
  },
  "& .Mui-selected": {
    backgroundColor: "#3aa7a3 !important",
    color: "white !important",
  },
  "& .MuiPickersCalendarHeader-label": {
    color: "#3aa7a3",
  },
  "& .MuiPickersArrowSwitcher-button": {
    color: "#3aa7a3",
  },
});

interface RegisterDaterangePickerProps {
  label: string;
  error?: FieldError | Merge<FieldError, (FieldError | undefined)[]>;
  def?:
    | {
        from: Dayjs;
        to: Dayjs;
      }
    | undefined;
  minDate?: Dayjs | null;
  maxDate?: Dayjs | null;
  helper?: ({
    data,
  }: {
    data: {
      from: Dayjs | null;
      to: Dayjs | null;
    };
  }) => void;
  shouldDisableFuture?: boolean;
  shouldDisablePast?: boolean;
}

const RegisterDaterangePicker: React.FC<RegisterDaterangePickerProps> = ({
  label,
  error,
  def,
  minDate,
  maxDate,
  helper,
  shouldDisableFuture,
  shouldDisablePast = true,
}) => {
  const [isPickerOpen, setPickerOpen] = useState(false);
  const [fromDate, setFromDate] = useState<Dayjs | null>(null);
  const [toDate, setToDate] = useState<Dayjs | null>(null);
  const [selectedRange, setSelectedRange] = useState<{
    from: string;
    to: string;
  } | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const togglePicker = () => {
    setPickerOpen(!isPickerOpen);
  };

  const handleSubmit = () => {
    if (fromDate && toDate) {
      if (fromDate.isAfter(toDate)) {
        setValidationError("From date cannot be later than to date.");
        return;
      } else {
        setValidationError(null);
        const data = {
          from: fromDate,
          to: toDate,
        };
        if (helper) {
          setPickerOpen(false);
          helper({ data });
        }
      }
    }
  };

  useEffect(() => {
    if (def?.from) setFromDate(dayjs(def.from));
    if (def?.to) setToDate(dayjs(def.to));
  }, [def]);

  useEffect(() => {
    if (fromDate && toDate) {
      setSelectedRange({
        from: dayjs(fromDate).format("DD-MM-YYYY"),
        to: dayjs(toDate).format("DD-MM-YYYY"),
      });
    }
  }, [fromDate, toDate]);

  return (
    <div className="cursor-pointer w-full h-full flex justify-center items-center shrink-0">
      <FormControl
        fullWidth
        error={!!error || !!validationError}
        sx={{ padding: "0 0" }}
      >
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <Paper
            elevation={0}
            sx={{
              background: "white",
              border: 0,
              width: "100%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "start",
              alignItems: "center",
            }}
          >
            {selectedRange && (
              <Tooltip title="Reset">
                <IconButton
                  sx={{ p: 0, position: "absolute", top: -14, right: -14 }}
                  onClick={() => {
                    setFromDate(null);
                    setToDate(null);
                    setSelectedRange(null);
                    helper && helper({ data: { from: null, to: null } });
                  }}
                >
                  <IoClose className="text-[#013338] hover:text-[red] text-[14px]" />
                </IconButton>
              </Tooltip>
            )}
            <Box
              onClick={() => togglePicker()}
              sx={{
                position: "relative",
                display: "flex",
                flexDirection: {
                  xs: "column",
                  md: "row",
                },
                justifyContent: "space-between",
                width: "100%",
                alignItems: { md: "center" },
                gap: { xs: 4, md: 10 },
                color: "#013338",
              }}
            >
              <MundialHeadingText
                sizeVariant="sm"
                className="md:flex-1 whitespace-nowrap"
              >
                {label || "Filter by date"}
              </MundialHeadingText>
              <div className="flex items-center justify-center gap-4">
                <div className="w-fit px-2 py-2 flex items-center justify-center rounded-[5px] text-[#3aa7a3] border border-[#3aa7a3] font-medium text-xs">
                  {selectedRange ? selectedRange.from : "dd-mm-yyyy"}
                </div>
                to
                <div className="w-fit px-2 py-2 flex items-center justify-center rounded-[5px] text-[#3aa7a3] border border-[#3aa7a3] font-medium text-xs">
                  {selectedRange ? selectedRange.to : "dd-mm-yyyy"}
                </div>
              </div>
            </Box>

            {isPickerOpen && (
              <CustomModalWrapper
                onClose={() => setPickerOpen(false)}
                open={isPickerOpen}
                title={"Select a Date"}
                allowChildrenPadding={false}
                escapeClose={true}
                backdropClose={true}
                sx={{
                  width: {
                    xs: "80%",
                    sm: "fit-content",
                    p: {
                      xs: 1,
                      sm: 2,
                    },
                  },
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    p: 3,
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 2,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{ color: "#013338", fontWeight: 500 }}
                  >
                    {selectedRange ? "Selected" : "Select A"} Date Range
                  </Typography>
                  {selectedRange && (
                    <Typography
                      variant="body1"
                      sx={{ color: "#3aa7a3", fontWeight: 400 }}
                    >
                      {`From ${selectedRange.from} To ${selectedRange.to}`}
                    </Typography>
                  )}
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 2,
                    }}
                  >
                    <Box sx={{ backgroundColor: "#013338" }}>
                      <StyledCalendar
                        disableFuture={shouldDisableFuture}
                        disablePast={shouldDisablePast}
                        value={fromDate}
                        minDate={minDate ? minDate : undefined}
                        maxDate={maxDate ? maxDate : undefined}
                        onChange={(value) => setFromDate(value)}
                        sx={{
                          p: 0,
                          color: "#f8f8f8",
                          "& .MuiDayPicker-Day": { color: "#f8f8f8" },
                          "& .MuiTypography-root": { color: "white" },
                          ".css-16n1jr6-MuiButtonBase-root-MuiPickersDay-root":
                            { color: "white" },
                          ".css-1tviim5-MuiButtonBase-root-MuiPickersDay-root:not(.Mui-selected)":
                            {
                              borderColor: "white",
                              color: "white",
                            },
                        }}
                      />
                    </Box>
                    <Box sx={{ backgroundColor: "#013338" }}>
                      <StyledCalendar
                        disableFuture={shouldDisableFuture}
                        disablePast={shouldDisablePast}
                        value={toDate}
                        minDate={fromDate || minDate || undefined}
                        maxDate={maxDate ? maxDate : undefined}
                        onChange={(value) => setToDate(value)}
                        disabled={!fromDate}
                        sx={{
                          p: 0,
                          color: "#f8f8f8",
                          "& .MuiDayPicker-Day": { color: "#f8f8f8" },
                          "& .MuiTypography-root": { color: "white" },
                          ".css-16n1jr6-MuiButtonBase-root-MuiPickersDay-root":
                            { color: "white" },
                          ".css-1tviim5-MuiButtonBase-root-MuiPickersDay-root:not(.Mui-selected)":
                            {
                              borderColor: "white",
                              color: "white",
                            },
                        }}
                      />
                    </Box>
                  </Box>
                  <Button
                    sx={{
                      px: 4,
                      mx: "auto",
                      cursor: "pointer",
                      width: "fit-content",
                      color: "white",
                      background: "#3aa7a3",
                      "&:hover": {
                        background: "white",
                        color: "#3aa7a3",
                        border: "1px solid #3aa7a3",
                      },
                    }}
                    onClick={handleSubmit}
                  >
                    Done
                  </Button>
                </Box>
              </CustomModalWrapper>
            )}
          </Paper>

          {(error || validationError) && (
            <FormHelperText sx={{ color: "#d32f2f" }}>
              {validationError || error?.message}
            </FormHelperText>
          )}
        </LocalizationProvider>
      </FormControl>
    </div>
  );
};

export default RegisterDaterangePicker;
