/* eslint-disable @typescript-eslint/no-explicit-any */
import { FiEye, FiEyeOff } from "react-icons/fi";
import {
  FormControl,
  IconButton,
  InputAdornment,
  TextField,
} from "@mui/material";
import React, { useState } from "react";
import { FieldValues, RegisterOptions, useFormContext } from "react-hook-form";

interface RegisterPasswordInputFieldProps {
  label?: string;
  placeholder?: string;
  name: string;
  validationOptions?: RegisterOptions<FieldValues, any | unknown>;
  multiline?: boolean;
  rows?: number;
  disabled?: boolean;
  validaationError?: string;
}



const RegisterPasswordInputField: React.FC<RegisterPasswordInputFieldProps> = ({
  label = "Password",
  name,
  validationOptions,
  multiline,
  placeholder,
  rows,
  validaationError,
  disabled = false,
}) => {
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };
  const {
    register,
    formState: { errors },
  } = useFormContext();

  return (
    <>
      <FormControl
        variant="outlined"
        error={!!errors[name]?.message}
        fullWidth
        size="small"
      >
        {/* <InputLabel htmlFor={`outlined-adornment-${name}`}>{label}</InputLabel> */}
        <TextField
          type={showPassword ? "text" : "password"}
          multiline={multiline}
          size="small"
          placeholder={placeholder}
          rows={rows}
          disabled={disabled}
          autoComplete="password"
          {...register(name, validationOptions)}
          slotProps={{
            input: {
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {showPassword ? (
                      <FiEye
                        style={{
                          fontSize: "1rem",
                          color: errors[name]?.message ? "red" : "#989898",
                        }}
                      />
                    ) : (
                      <FiEyeOff
                        style={{
                          fontSize: "1rem",
                          color: errors[name]?.message ? "red" : "#989898",
                        }}
                      />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            },
          }}
          label={label}
          error={!!validaationError}
          helperText={validaationError ? validaationError : null}
        />
      </FormControl>
    </>
  );
};

export default RegisterPasswordInputField;
