/* eslint-disable @typescript-eslint/no-explicit-any */
import { PiWarningCircleLight } from "react-icons/pi";
import { FormControl, TextField, TextFieldProps } from "@mui/material";
import React, { ReactNode } from "react";
import { FieldValues, RegisterOptions, useFormContext } from "react-hook-form";

interface RegisterTextInputFieldProps extends Omit<TextFieldProps, "variant"> {
  validationOptions?: RegisterOptions<FieldValues, any>;
  name: string;
  themecolor?: string;
  autoComplete?: string;
  validationError?: string | undefined;
  startAdornment?: ReactNode;
  endAdornment?: ReactNode;
  textLabel?: ReactNode;
}

const RegisterTextInputField: React.FC<RegisterTextInputFieldProps> = ({
  label,
  name,
  validationOptions,
  multiline,
  placeholder,
  rows,
  autoComplete,
  hiddenLabel = false,
  validationError,
  startAdornment,
  endAdornment,
  textLabel,
  ...rest
}) => {
  const {
    register,
    formState: { errors },
  } = useFormContext();

  return (
    <>
      <FormControl
        variant="outlined"
        error={!!errors[name]?.message}
        fullWidth
        size="small"
      >
        {textLabel && (
          <span className="text-[#013338] pb-2 text-[18px] font-medium">
            {textLabel}
          </span>
        )}
        <TextField
          size="small"
          id={`${autoComplete}-outline-text-field`}
          fullWidth
          type={"text"}
          multiline={multiline}
          placeholder={placeholder}
          rows={rows}
          autoComplete={autoComplete}
          {...register(name, validationOptions)}
          {...(!hiddenLabel && { label: label })}
          slotProps={{
            input: {
              startAdornment: startAdornment ? startAdornment : undefined,
              endAdornment: errors[name]?.message ? (
                <>
                  <PiWarningCircleLight className="text-[red]" />
                </>
              ) : endAdornment ? (
                endAdornment
              ) : undefined,
            },
          }}
          error={!!validationError}
          helperText={validationError ? validationError : null}
          {...rest}
        />
      </FormControl>
    </>
  );
};

export default RegisterTextInputField;
