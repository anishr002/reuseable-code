import React, { ReactNode } from "react";
import { useFormContext, Controller } from "react-hook-form";
import {
  Checkbox,
  FormControlLabel,
  createTheme,
  ThemeProvider,
} from "@mui/material";

// Custom MUI Theme
const theme = createTheme({
  components: {
    MuiCheckbox: {
      styleOverrides: {
        root: {
          fontFamily: "Quicksand",
          color: "#013338", // Default border color
          "&.Mui-checked": {
            color: "#013338", // Color when checked
          },
        },
      },
    },
    MuiFormControlLabel: {
      styleOverrides: {
        root: {
          fontFamily: "Quicksand",
          color: "#013338", // Label text color
          fontWeight: 400,
          "& .Mui-checked + .MuiFormControlLabel-label": {
            fontWeight: 700, // Bold text when checked
          },
        },
      },
    },
  },
});

interface RegisterCheckBoxProps {
  name: string;
  label: ReactNode;
  value?: boolean;
  displayLabel?: ReactNode;
}

const RegisterCheckBox: React.FC<RegisterCheckBoxProps> = ({
  label,
  displayLabel,
  name,
}) => {
  const { control, setValue, watch } = useFormContext();
  const selectedValues = watch(name) || [];

  const handleChange = (checked: boolean) => {
    const updatedValues = checked
      ? [...selectedValues, label]
      : selectedValues.filter((item: string) => item !== label);
    setValue(name, updatedValues, { shouldValidate: true });
  };

  return (
    <ThemeProvider theme={theme}>
      <Controller
        name="selectedValues"
        control={control}
        render={() => (
          <FormControlLabel
            control={
              <Checkbox
                checked={selectedValues.includes(label)}
                onChange={(e) => handleChange(e.target.checked)}
              />
            }
            label={displayLabel}
            className="flex gap-2 font-quicksand"
          />
        )}
      />
    </ThemeProvider>
  );
};

export default RegisterCheckBox;
