import { useState, useEffect, useRef } from "react";
import { FieldValues, RegisterOptions, useFormContext } from "react-hook-form";
import {
  Menu,
  MenuItem,
  FormControl,
  FormHelperText,
  Button,
  Checkbox,
} from "@mui/material";
import { FaAngleDown, FaAngleUp } from "react-icons/fa";

const CustomSelect = ({
  name,
  options,
  textLabel,
  validationError,
  multiple = false,
  defaultValue,
  validationOptions,
}: {
  name: string;
  options: string[];
  textLabel?: string;
  validationError?: string;
  multiple?: boolean;
  defaultValue?: string | string[];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  validationOptions?: RegisterOptions<FieldValues, any>;
}) => {
  const { register, setValue, clearErrors } = useFormContext();
  const [selectedValue, setSelectedValue] = useState<string | string[]>(
    multiple
      ? Array.isArray(defaultValue)
        ? defaultValue
        : []
      : typeof defaultValue === "string"
      ? defaultValue
      : ""
  );

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [buttonWidth, setButtonWidth] = useState(0);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const open = Boolean(anchorEl);

  useEffect(() => {
    if (buttonRef.current) {
      setButtonWidth(buttonRef.current.offsetWidth);
    }
    // Set the initial form value
    setValue(name, selectedValue);
    clearErrors(name);
  }, [name, setValue, selectedValue]);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSelect = (option: string) => {
    let newValue;
    if (multiple) {
      newValue = Array.isArray(selectedValue)
        ? selectedValue.includes(option)
          ? selectedValue.filter((item) => item !== option)
          : [...selectedValue, option]
        : [option];
    } else {
      newValue = option;
      handleClose();
    }
    setSelectedValue(newValue);
    setValue(name, newValue);
  };

  return (
    <FormControl variant="outlined" sx={{ width: "100%" }}>
      {textLabel && (
        <span className="text-[#013338] pb-2 text-[18px] font-medium">
          {textLabel}
        </span>
      )}
      <Button
        variant="outlined"
        onClick={handleClick}
        endIcon={
          open ? <FaAngleUp color="#3aa7a3" /> : <FaAngleDown color="#3aa7a3" />
        }
        sx={{
          display: "flex",
          justifyContent: "space-between",
          textAlign: "left",
          textTransform: "uppercase",
          color: "#3aa7a3",
          borderColor: "#3aa7a3",
          width: "100%",
          py:0.85
        }}
        ref={buttonRef}
      >
        {multiple
          ? Array.isArray(selectedValue) && selectedValue.length > 0
            ? selectedValue.join(", ")
            : "Select"
          : selectedValue || "Select"}
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          sx: {
            borderRadius: "5px",
            boxShadow: "0px 4px 10px rgba(0,0,0,0.1)",
            maxHeight: "200px",
            overflowY: "auto",
            width: buttonWidth,
          },
        }}
      >
        {options.map((option, index) => (
          <MenuItem
            key={index}
            onClick={() => handleSelect(option)}
            sx={{
              textTransform: "uppercase",
              color: "#3aa7a3",
              fontWeight:
                multiple &&
                Array.isArray(selectedValue) &&
                selectedValue.includes(option)
                  ? "bold"
                  : typeof selectedValue === "string" &&
                    selectedValue === option
                  ? "bold"
                  : "normal",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            {option}
            {multiple
              ? Array.isArray(selectedValue) &&
                selectedValue.includes(option) && (
                  <Checkbox checked sx={{ color: "#3aa7a3" }} />
                )
              : typeof selectedValue === "string" &&
                selectedValue === option && (
                  <Checkbox checked sx={{ color: "#3aa7a3" }} />
                )}
          </MenuItem>
        ))}
      </Menu>
      <input
        type="hidden"
        {...register(name, validationOptions)}
        value={JSON.stringify(selectedValue)}
      />
      {validationError && (
        <FormHelperText>
          <span className="text-xs font-normal text-red-600">
            {validationError}
          </span>
        </FormHelperText>
      )}
    </FormControl>
  );
};

export default CustomSelect;
