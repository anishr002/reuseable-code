/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  createTheme,
  ThemeProvider,
  FormControl,
  FormHelperText,
  InputLabel,
  OutlinedInput,
  OutlinedInputProps,
} from "@mui/material";
import React from "react";
import { FieldValues, RegisterOptions, useFormContext } from "react-hook-form";

interface RegisterTextInputSearchFieldProps
  extends Omit<
    OutlinedInputProps,
    | "label"
    | "placeholder"
    | "name"
    | "validationOptions"
    | "multiline"
    | "rows"
    | "autoComplete"
  > {
  textLabel?: string;
  placeholder?: string;
  name: string;
  validationOptions?: RegisterOptions<FieldValues, any | unknown>;
  multiline?: boolean;
  rows?: number;
  autoComplete?: string;
  mainColor?: string;
}

const RegisterTextInputSearchField: React.FC<
  RegisterTextInputSearchFieldProps
> = (props) => {
  const {
    register,
    formState: { errors },
  } = useFormContext();
  const { mainColor = "#3aa7a3" } = props;

  const theme = createTheme({
    components: {
      MuiInputLabel: {
        styleOverrides: {
          root: {
            color: mainColor,
            "&.Mui-focused": {
              color: mainColor,
            },
          },
        },
      },
      MuiOutlinedInput: {
        styleOverrides: {
          root: {
            borderRadius: "24px",
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor: mainColor,
            },
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor: mainColor,
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: mainColor,
            },
            "& .MuiInputBase-input": {
              color: mainColor,
              fontSize: "16px",
            },
          },
        },
      },
    },
  });

  const {
    textLabel,
    name,
    validationOptions,
    multiline,
    placeholder,
    rows,
    autoComplete,
    ...rest
  } = props;
  return (
    <ThemeProvider theme={theme}>
      <FormControl
        variant="outlined"
        error={!!errors[name]?.message}
        fullWidth
        size="small"
      >
        <InputLabel htmlFor={`outlined-adornment-${name}`}>
          {textLabel}
        </InputLabel>
        <OutlinedInput
          label={textLabel}
          size="small"
          id={`${autoComplete}-outline-text-field`}
          fullWidth
          type="text"
          multiline={multiline}
          placeholder={placeholder}
          rows={rows}
          autoComplete={autoComplete}
          {...register(name, validationOptions)}
          {...rest}
        />
        {errors[name]?.message && (
          <FormHelperText error style={{ marginLeft: 5, color: "red" }}>
            {errors[name]?.message?.toString()}
          </FormHelperText>
        )}
      </FormControl>
    </ThemeProvider>
  );
};

export default RegisterTextInputSearchField;
