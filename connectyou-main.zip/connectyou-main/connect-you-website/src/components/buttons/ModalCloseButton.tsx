import { IconButton, IconButtonProps, Tooltip } from "@mui/material";
import { IoClose } from "react-icons/io5";

const ModalCloseButton = (props: IconButtonProps) => {
  return (
    <Tooltip title="Close">
      <IconButton
        style={{ position: "absolute", top: 4, right: 4, cursor: "pointer" }}
        {...props}
      >
        <IoClose className="text-inherit hover:text-[#ebbd33] cursor-pointer" />
      </IconButton>
    </Tooltip>
  );
};

export default ModalCloseButton;
