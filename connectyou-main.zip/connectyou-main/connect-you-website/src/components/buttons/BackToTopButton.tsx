import React from "react";
import arrow_warm_up from "../../assets/icons/arrow_warm_up.png";

const BackToTopButton: React.FC<
  Omit<React.HTMLAttributes<HTMLButtonElement>, "className">
> = (props) => {
  return (
    <>
      <button
        {...props}
        className="cursor-pointer w-[44px] h-[44px] rounded-full p-3 bg-[#3aa7a3] flex flex-row justify-center items-center"
      >
        <img
          src={arrow_warm_up}
          alt="icon"
          className="w-full h-full object-contain block"
        />
      </button>
    </>
  );
};

export default BackToTopButton;
