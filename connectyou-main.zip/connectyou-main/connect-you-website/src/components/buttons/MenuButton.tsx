import { useState, ReactNode } from "react";
import { IconButton, Menu, MenuItem, SxProps } from "@mui/material";
import { BsThreeDotsVertical } from "react-icons/bs";
import { IconType } from "react-icons/lib";
import ProvideToolTip from "../wrappers/ProvideToolTip";

export interface MenuOption {
  label: ReactNode;
  action: () => void;
}

interface MenuButtonProps {
  variant?: "seablue" | "darksea" | "yellow" | "black" | "white";
  itemsVariant?: "seablue" | "darksea" | "yellow" | "black" | "white";
  sizeVariant?: "lg" | "md" | "sm" | "xs";
  options: MenuOption[];
  Icon?: IconType;
  backdropClose?: boolean;
  title?: string;
  sx?: SxProps;
}

const MenuButton: React.FC<MenuButtonProps> = ({
  variant = "seablue",
  itemsVariant = "darksea",
  sizeVariant = "xs",
  options,
  Icon,
  backdropClose = true,
  title,
  sx,
}) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const returnSize = () => {
    switch (sizeVariant) {
      case "lg":
        return { sm: "24px", md: "32px" };
      case "md":
        return { sm: "20px", md: "24px" };
      case "sm":
        return { sm: "16px", md: "20px" };
      case "xs":
        return { sm: "14px", md: "18px" };
      default:
        return { sm: "12px", md: "16px" };
    }
  };

  const returnColor = (variant: string) => {
    switch (variant) {
      case "seablue":
        return "#3aa7a3";
      case "darksea":
        return "#013338";
      case "yellow":
        return "#ebbd33";
      case "black":
        return "#000000";
      case "white":
        return "#FFFFFF";
      default:
        return "#3aa7a3";
    }
  };

  return (
    <>
      <ProvideToolTip title={title || ""}>
        <IconButton
          onClick={handleClick}
          sx={{ fontSize: returnSize(), color: returnColor(variant), ...sx }}
        >
          {Icon ? (
            <Icon className="text-inherit cursor-pointer" />
          ) : (
            <BsThreeDotsVertical className="text-inherit cursor-pointer" />
          )}
        </IconButton>
      </ProvideToolTip>

      <Menu
        sx={{
          width: {
            xs: 300,
            sm: 350,
            md: 380,
          },
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={backdropClose ? handleClose : undefined}
      >
        {options.map((option, index) => (
          <MenuItem
            key={index}
            onClick={() => {
              option.action();
              handleClose();
            }}
            sx={{ color: returnColor(itemsVariant), minWidth: 120 }}
          >
            {option.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default MenuButton;
