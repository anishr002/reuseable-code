import { styled } from "@mui/material/styles";
import Switch from "@mui/material/Switch";

// Custom styled switch
const CustomSwitch = styled(Switch)(({ theme }) => ({
  width: 30,
  height: 14,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "& .MuiSwitch-thumb": {
      backgroundColor: "red", // Default thumb color (unchecked state)
    },
    "& + .MuiSwitch-track": {
      backgroundColor: "transparent",
      border: "1px solid red", // Default track border color (unchecked state)
      opacity: 1,
    },
    "&.Mui-checked": {
      transform: "translateX(15px)",
      "& .MuiSwitch-thumb": {
        backgroundColor: "#3aa7a3", // Thumb color when checked
      },
      "& + .MuiSwitch-track": {
        backgroundColor: "transparent",
        border: "1px solid #3aa7a3", // Track border color when checked
        opacity: 1,
      },
    },
    "&.Mui-disabled": {
      "& .MuiSwitch-thumb": {
        backgroundColor: "red",
      },
      "& + .MuiSwitch-track": {
        backgroundColor: "transparent",
        border: "1px solid red",
        opacity: 0.5,
      },
    },
    "&.Mui-checked.Mui-disabled": {
      "& .MuiSwitch-thumb": {
        backgroundColor: "red",
      },
      "& + .MuiSwitch-track": {
        backgroundColor: "transparent",
        border: "1px solid red",
        opacity: 0.5,
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 10,
    height: 10,
    boxShadow: "0 2px 4px 0 rgba(0,0,0,0.2)",
    borderRadius: "50%",
  },
  "& .MuiSwitch-track": {
    borderRadius: 26 / 2,
    backgroundColor: "transparent",
    border: "1px solid #E9E9EA",
    opacity: 1,
    transition: theme.transitions.create(["border-color"], {
      duration: 500,
    }),
  },
}));

const CustomSwitchGray = styled(Switch)(({ theme }) => ({
  width: 30,
  height: 14,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "& .MuiSwitch-thumb": {
      backgroundColor: "gray", // Default thumb color (unchecked state)
    },
    "& + .MuiSwitch-track": {
      backgroundColor: "transparent",
      border: "1px solid gray", // Default track border color (unchecked state)
      opacity: 1,
    },
    "&.Mui-checked": {
      transform: "translateX(15px)",
      "& .MuiSwitch-thumb": {
        backgroundColor: "#3aa7a3", // Thumb color when checked
      },
      "& + .MuiSwitch-track": {
        backgroundColor: "transparent",
        border: "1px solid #3aa7a3", // Track border color when checked
        opacity: 1,
      },
    },
    "&.Mui-disabled": {
      "& .MuiSwitch-thumb": {
        backgroundColor: "gray",
      },
      "& + .MuiSwitch-track": {
        backgroundColor: "transparent",
        border: "1px solid gray",
        opacity: 0.5,
      },
    },
    "&.Mui-checked.Mui-disabled": {
      "& .MuiSwitch-thumb": {
        backgroundColor: "gray",
      },
      "& + .MuiSwitch-track": {
        backgroundColor: "transparent",
        border: "1px solid gray",
        opacity: 0.5,
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 10,
    height: 10,
    boxShadow: "0 2px 4px 0 rgba(0,0,0,0.2)",
    borderRadius: "50%",
  },
  "& .MuiSwitch-track": {
    borderRadius: 26 / 2,
    backgroundColor: "transparent",
    border: "1px solid #E9E9EA",
    opacity: 1,
    transition: theme.transitions.create(["border-color"], {
      duration: 500,
    }),
  },
}));

export { CustomSwitchGray };
export default CustomSwitch;
