import { CircularProgress } from "@mui/material";
import React from "react";

export interface ButtonProps
  extends Omit<
    React.HTMLAttributes<HTMLButtonElement>,
    "type" | "onClick" | "disabled" | "className"
  > {
  isActive?: boolean;
  text: string | React.ReactNode;
  onClick?: () => void;
  type?: "submit" | "button" | "reset" | undefined;
  className?: string;
  loading?: boolean;
  disabled?: boolean;
}

const RoundedButton: React.FC<ButtonProps> = (props) => {
  const {
    loading,
    disabled,
    isActive = true,
    text,
    onClick,
    type = "button",
    className,
  } = props;
  return (
    <>
      {isActive ? (
        <button
          {...props}
          type={type}
          onClick={onClick}
          disabled={loading || disabled}
          className={`${
            loading
              ? "cursor-progress"
              : disabled
              ? "cursor-not-allowed"
              : "cursor-pointer"
          } flex justify-center items-center disabled:bg-[#EBBD337C] uppercase leading-0 w-[220px] h-[40px] sm:w-[180px] md:w-[220px] lg:w-[250px] rounded-[30px] font-[700] text-[18px] bg-[#EBBD33] text-[#013338] whitespace-nowrap px-6 border border-[#EBBD33] hover:bg-[#013338] hover:text-[#EBBD33] transition-all duration-300 ease-in-out font-mundial ${className}`}
        >
          {loading ? (
            <CircularProgress
              sx={{
                color: "inherit",
              }}
              size={30}
            />
          ) : (
            text
          )}
        </button>
      ) : (
        <button
          {...props}
          type={type}
          onClick={onClick}
          disabled={loading || disabled}
          className={`${
            loading
              ? "cursor-progress"
              : disabled
              ? "cursor-not-allowed"
              : "cursor-pointer"
          } flex justify-center items-center disabled:bg-[#0133387c] uppercase leading-0 w-[220px] h-[40px] sm:w-[180px] md:w-[220px] lg:w-[250px] rounded-[30px] font-[700] text-[18px] text-[#EBBD33] border border-[#EBBD33] hover:text-[#013338] bg-[#013338] whitespace-nowrap px-6 hover:bg-[#EBBD33] transition-all duration-300 ease-in-out font-mundial ${className}`}
        >
          {loading ? (
            <CircularProgress
              sx={{
                color: "inherit",
              }}
              size={30}
            />
          ) : (
            text
          )}
        </button>
      )}
    </>
  );
};

const PrimaryYellowButton: React.FC<ButtonProps> = (props) => {
  const {
    loading,
    text,
    onClick,
    type = "button",
    className,
    disabled,
  } = props;

  return (
    <>
      <button
        {...props}
        type={type}
        onClick={() => onClick && onClick()}
        disabled={loading || disabled}
        className={`${
          loading
            ? "cursor-progress"
            : disabled
            ? "cursor-not-allowed"
            : "cursor-pointer"
        } disabled:bg-[#ebbd337e] flex justify-center items-center uppercase leading-0 min-w-[220px] h-[40px] sm:min-w-[180px] md:min-w-[220px] lg:min-w-[250px] rounded-[30px] font-[700] font-mundial text-[18px] bg-[#EBBD33] text-[#013338] whitespace-nowrap px-6 border border-transparent hover:border-[#013338] hover:bg-[white]  transition-all duration-300 ease-in-out ${className}`}
      >
        {loading ? (
          <CircularProgress
            sx={{
              color: "inherit",
            }}
            size={30}
          />
        ) : (
          text
        )}
      </button>
    </>
  );
};

export default RoundedButton;
export { PrimaryYellowButton };
