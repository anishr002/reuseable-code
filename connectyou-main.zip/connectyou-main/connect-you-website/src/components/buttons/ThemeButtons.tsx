import { CircularProgress, Tooltip } from "@mui/material";
import React from "react";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";
// import { FaLock } from "react-icons/fa";
interface ButtonProps
  extends Omit<
    React.HTMLAttributes<HTMLButtonElement>,
    "type" | "disabled" | "className"
  > {
  loading?: boolean;
  text: string;
  type?: "submit" | "reset" | "button" | undefined;
  className?: string | undefined;
  shouldDisable?: boolean;
  disabledToolTip?: string;
  loadingToolTip?: string;
}
const YellowButton: React.FC<ButtonProps> = (props) => {
  const {
    type,
    loading = false,
    className,
    text,
    shouldDisable,
    disabledToolTip = "",
    loadingToolTip,
    ...rest
  } = props;

  const baseClasses = `${
    loading ? "cursor-progress" : "cursor-pointer"
  } h-[40px] min-w-fit  leading-normal whitespace-nowrap rounded-[100px] disabled:cursor-not-allowed disabled:opacity-35 border border-transparent flex justify-center items-center font-mundial font-bold text-[16px]  bg-[#ebbd33] text-[#013338] hover:text-[#ebbd33] hover:bg-[#013338] transition-all ease-in duration-300 uppercase w-[220px]
sm:w-[180px] md:w-[220px] lg:w-[250px] px-4`;

  return (
    <Tooltip
      title={
        shouldDisable
          ? disabledToolTip
          : loading
          ? loadingToolTip || "Loading, Please wait.."
          : ""
      }
    >
      <button
        type={type}
        disabled={loading || shouldDisable}
        className={` ${removeDuplicateClasses(
          `${className} ${baseClasses}`
        )}  `}
        {...rest}
      >
        {loading ? (
          <CircularProgress
            size={30}
            color="inherit"
            sx={{ color: "inherit" }}
          />
        ) : (
          text
        )}
      </button>
    </Tooltip>
  );
};
const CancelButton: React.FC<ButtonProps> = (props) => {
  const { type, loading, className, text, shouldDisable, ...rest } = props;

  const baseClasses = `${
    loading ? "cursor-progress" : "cursor-pointer"
  } h-[40px] min-w-fit  leading-normal whitespace-nowrap rounded-[100px] disabled:cursor-not-allowed disabled:opacity-35 border border-transparent flex justify-center items-center font-mundial font-bold text-[16px]  bg-[red] text-[white] hover:text-[red] hover:bg-[white] hover:border-[red] transition-all ease-in duration-300 uppercase w-[220px]
sm:w-[180px] md:w-[220px] lg:w-[250px] px-4`;

  return (
    <button
      type={type}
      disabled={loading || shouldDisable}
      className={` ${removeDuplicateClasses(`${className} ${baseClasses}`)}  `}
      {...rest}
    >
      {loading ? (
        <CircularProgress size={30} color="inherit" sx={{ color: "inherit" }} />
      ) : (
        text
      )}
    </button>
  );
};

const DarkThemeButton: React.FC<ButtonProps> = (props) => {
  const { type, loading, className, text, ...rest } = props;

  const BaseClasses = `${
    loading ? "cursor-progress" : "cursor-pointer"
  } h-[40px] min-w-fit  rounded-[100px] leading-normal  whitespace-nowrap border border-transparent flex justify-center items-center font-mundial font-bold text-[16px]  bg-[#3AA7A3] text-white  hover:bg-[#013338] transition-all ease-in duration-300 uppercase w-[220px]
sm:w-[180px] md:w-[220px] lg:w-[250px] px-4`;

  return (
    <button
      type={type || "submit"}
      disabled={loading}
      className={`
      ${removeDuplicateClasses(`${className}${BaseClasses}`)} `}
      {...rest}
    >
      {loading ? (
        <CircularProgress size={30} color="inherit" sx={{ color: "inherit" }} />
      ) : (
        text || "Submit"
      )}
    </button>
  );
};
const YellowLightButton: React.FC<ButtonProps> = (props) => {
  const { type, loading, className, text, ...rest } = props;

  return (
    <button
      type={type || "submit"}
      disabled={loading}
      className={`
      ${className} ${
        loading ? "cursor-progress" : "cursor-pointer"
      } h-[40px] min-w-fit  rounded-[100px] leading-normal whitespace-nowrap flex justify-center items-center font-mundial font-bold text-[16px]  bg-[#ebbd33] text-[#013338]  hover:bg-[white] border border-transparent hover:border-[#013338] transition-all ease-in duration-300 uppercase w-[220px]
      sm:w-[180px] md:w-[220px] lg:w-[250px] px-4`}
      {...rest}
    >
      {loading ? (
        <CircularProgress size={30} color="inherit" sx={{ color: "inherit" }} />
      ) : (
        text || "Submit"
      )}
    </button>
  );
};

interface DarkThemeButtonTransparentProps extends ButtonProps {
  isActive?: boolean;
}
const DarkThemeButtonTransparent: React.FC<DarkThemeButtonTransparentProps> = (
  props
) => {
  const { type, loading, className, text, isActive = false, ...rest } = props;

  const defClasses = `${
    loading ? "cursor-progress" : "cursor-pointer"
  } h-[40px] min-w-fit  rounded-[100px] leading-none  border  flex justify-center items-center font-mundial  text-[16px]   transition-all ease-in duration-300 uppercase w-[220px]
sm:w-[180px] md:w-[220px] lg:w-[250px] px-4 ${
    isActive
      ? "bg-[#3aa7a3] text-white font-bold  border-transparent"
      : "bg-transparent border-[#3aa7a3] text-[#013338]  font-semibold"
  } `;

  return (
    <button
      {...rest}
      type={type || "submit"}
      disabled={loading}
      className={`${removeDuplicateClasses(`${className} ${defClasses}`)} `}
    >
      {loading ? (
        <CircularProgress size={30} color="inherit" sx={{ color: "inherit" }} />
      ) : (
        text || "Submit"
      )}
    </button>
  );
};
export {
  CancelButton,
  YellowButton,
  DarkThemeButton,
  YellowLightButton,
  DarkThemeButtonTransparent,
};
