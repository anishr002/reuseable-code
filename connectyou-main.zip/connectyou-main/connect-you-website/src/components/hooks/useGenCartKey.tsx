import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { initialize } from "../../slices/CartId";
import genCartKeyFun from "../../util/genCartKeyFun";
type useGenCartKeyType = () => {
  cartKey: string | null;
  genCartKey: () => void;
};

const useGenCartKey: useGenCartKeyType = () => {
  const [cartKey, setCartKey] = useState<string | null>(null);
  const [refresh, setReferesh] = useState<boolean>(false);
  const genCartKey = () => setReferesh((prev) => !prev);
  const disptach = useDispatch();
  useEffect(() => {
    let storedCartId = localStorage.getItem("cartKey");
    if (!storedCartId || storedCartId === "") {
      storedCartId = genCartKeyFun();
      localStorage.setItem("cartKey", storedCartId);
      setCartKey(storedCartId);
      disptach(initialize(storedCartId));
    } else {
      setCartKey(storedCartId);
      disptach(initialize(storedCartId));
    }
  }, [refresh, disptach]);
  return { cartKey, genCartKey };
};
export default useGenCartKey;
