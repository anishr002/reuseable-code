/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect } from "react";
import { io, Socket } from "socket.io-client";
import { useSelector } from "react-redux";
import backendURL from "../../util/baseBackendURLConfig";

interface SocketWithState extends Socket {
  connected: boolean;
}

interface UseSocketParams {
  initialAuthToken?: string | null;
}

const useSocket = ({
  initialAuthToken = null,
}: UseSocketParams): {
  socket: SocketWithState | null;
  clearSocket: () => void;
} => {
  const [socket, setSocket] = useState<SocketWithState | null>(null); // Store socket instance in state
  const [authToken, setAuthToken] = useState<string | null>(
    initialAuthToken || localStorage.getItem("authToken")
  );

  const loginUserData = useSelector((state: any) => state.login.userdata);

  const [loginUserType, setLoginUserType] = useState<string | null>(null);

  useEffect(() => {
    if (!loginUserData) {
      setSocket(null);
    }
    setLoginUserType(
      loginUserData?.name
        ? loginUserData.userType === "coachee"
          ? "u"
          : "c"
        : null
    );
  }, [loginUserData, loginUserData?._id, loginUserData?.userType]);

  useEffect(() => {
    if (loginUserType) setAuthToken(localStorage.getItem("authToken"));
  }, [loginUserType]);

  useEffect(() => {
    if (!authToken || !loginUserType) {
      // Disconnect and reset socket if userType or token is unavailable
      if (socket) {
        socket.disconnect();
        setSocket(null);
      }
      return;
    }

    if (!socket) {
      const newSocket = io(backendURL, {
        autoConnect: false,
        extraHeaders: {
          authorization: `bearer ${authToken}`,
        },
      }) as SocketWithState;
      console.log("connection successful");
      newSocket.connect();
      setSocket(newSocket);
    } else if (!socket.connected) {
      socket.connect();
    }

    return () => {
      if (socket) {
        socket.disconnect();
        setSocket(null);
      }
    };
  }, [authToken, loginUserType, socket]);

  const clearSocket = () => {
    socket?.disconnect();
    setAuthToken(null);
    setSocket(null);
  };

  // useEffect(() => {
  //   console.log({ socket });
  // }, [socket]);
  return { clearSocket, socket };
};

export default useSocket;
