/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef, useState } from "react";
/**
 * A hook that saves and restores scroll position.
 *
 * @param key - Unique identifier for the scroll position (e.g., page route)
 * @param dependencies - Array of dependencies that trigger saving the position when changed
 * @param restoreScroll - Boolean flag to enable/disable scroll restoration
 */

const useScrollRestoration = (
  key: string = "default",
  dependencies: any[] = [],
  restoreScroll: boolean = true
) => {
  const [savedPosition, setSavedPosition] = useState<number>(0);
  const scrollRestored = useRef<boolean>(false);
  const storageKey = `scrollPosition_${key}`;

  useEffect(() => {
    setSavedPosition(window.scrollY);
    sessionStorage.setItem(storageKey, savedPosition.toString());
    return () => {
      if (!scrollRestored.current) {
        sessionStorage.setItem(storageKey, savedPosition.toString());
      }
    };
  }, dependencies);

  useEffect(() => {
    if (restoreScroll && !scrollRestored.current) {
      const savedScrollPosition = sessionStorage.getItem(storageKey);
      if (savedScrollPosition) {
        requestAnimationFrame(() => {
          window.scrollTo({
            top: parseInt(savedScrollPosition, 10),
            behavior: "smooth",
          });
          scrollRestored.current = true;
        });
      }
    }

    const handleScroll = () => {
      if (window.scrollY !== savedPosition) {
        setSavedPosition(window.scrollY);
        sessionStorage.setItem(storageKey, window.scrollY.toString());
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [restoreScroll, storageKey]);

  return {
    saveScroll: () => {
      const currentPosition = window.scrollY;
      setSavedPosition(currentPosition);
      sessionStorage.setItem(storageKey, currentPosition.toString());
    },
    restoreScroll: () => {
      const savedScrollPosition = sessionStorage.getItem(storageKey);
      if (savedScrollPosition) {
        window.scrollTo({
          top: parseInt(savedScrollPosition, 10),
          behavior: "auto",
        });
      }
    },
  };
};

export default useScrollRestoration;
  