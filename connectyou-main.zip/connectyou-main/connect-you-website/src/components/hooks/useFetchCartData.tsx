import React, { useState } from "react";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useDispatch, useSelector } from "react-redux";
import useGenCartKey from "./useGenCartKey";
import { setCartCount } from "../../slices/cartCount";
import { RootState } from "../../lib/store";

const useFetchCartData = () => {
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  const dispatch = useDispatch();
  const { genCartKey, cartKey } = useGenCartKey();
  const [refresh, setRefresh] = useState<boolean>(false);
  const [cartCount, setCartC] = useState<boolean>(false);
  const refreshCartCount = () => setRefresh((prev) => !prev);

  React.useEffect(() => {
    const fetchData = async () => {
      if (!cartKey) {
        return genCartKey();
      }
      try {
        const response = await httpAPI.post(
          `${backendURL}/user/cart/list-session`,
          {
            userId: loginUserData?._id,
            cartId: cartKey,
          }
        );
        if (response.status === 200) {
          localStorage.setItem("cartItems", response.data.data.length);
          dispatch(setCartCount(response.data.data.length));
          setCartC(response.data.data.length);
        }
      } catch (error) {
        console.log({ error });
      }
    };
    fetchData();
  }, [refresh, cartKey, loginUserData?._id, loginUserData?.userType]);

  return { refreshCartCount, cartCount };
};

export default useFetchCartData;
