// useDatesLoop.ts
import { useCallback, useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import dayjs, { Dayjs } from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import isSameOrBefore from "dayjs/plugin/isSameOrBefore";

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(isSameOrBefore);

interface UseDatesLoopParams {
  endDate: string | Date | Dayjs;
  startDate?: string | Date | Dayjs;
}

type DatesLoopFunction = (params: UseDatesLoopParams) => Dayjs[];

const useDatesLoop = (): DatesLoopFunction => {
  const loginUserData = useSelector(
    (state: RootState) => state?.login?.userdata
  );

  const timezoneToUse = useMemo(() => {
    return loginUserData?.timeZone || dayjs.tz.guess();
  }, [loginUserData?.timeZone]);

  const generateDates = useCallback(
    ({ startDate, endDate }: UseDatesLoopParams): Dayjs[] => {
      const start = dayjs
        .tz(startDate ?? new Date(), timezoneToUse)
        .startOf("day");
      const end = dayjs.tz(endDate, timezoneToUse).startOf("day");

      if (!end.isValid() || start.isAfter(end)) {
        return [];
      }

      const dates: Dayjs[] = [];
      let current = start.clone();

      while (current.isSameOrBefore(end)) {
        dates.push(current.clone());
        current = current.add(1, "day");
      }

      return dates;
    },
    [timezoneToUse] 
  );

  return generateDates;
};

export default useDatesLoop;
