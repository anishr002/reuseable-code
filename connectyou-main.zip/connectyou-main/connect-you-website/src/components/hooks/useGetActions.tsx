import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { RootState } from "../../lib/store";
import { useEffect } from "react";
import ActionProvider from "../../util/ProvideActions";

const useGetActions = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const loginData = useSelector((state: RootState) => state.login.userdata);
  const dispatch = useDispatch();

  useEffect(() => {
    ActionProvider.set({
      navigate,
      location,
      loginData,
      dispatch,
    });
    return () => ActionProvider.clear();
  }, [navigate, location, loginData, dispatch]);

  return {
    navigate,
    location,
    loginData,
    dispatch,
  };
};

export default useGetActions;
