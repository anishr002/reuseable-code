/* eslint-disable @typescript-eslint/no-unused-vars */
import { useLocation, useNavigate } from "react-router-dom";

const useDetectRedirection = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const detectReqestedRedirection = (
    nextAction?: () => void,
    shouldClearStatePartially?: boolean
  ) => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const state = location.state as Record<string, any> | null;

      const redirectionRequested = state?.redirectionRequested;
      const requestedRedirectionLocation = state?.requestedRedirectionLocation;

      if (redirectionRequested && requestedRedirectionLocation) {
        // console.log("🔁 Redirecting to:", requestedRedirectionLocation);

        // Clear redirection-related state before navigating
        if (shouldClearStatePartially) {
          const {
            redirectionRequested,
            requestedRedirectionLocation,
            ...rest
          } = state;
          window.history.replaceState(
            { ...rest },
            "",
            window.location.pathname + window.location.search
          );
        }

        setTimeout(() => {
          navigate(requestedRedirectionLocation);
        }, 0);
      } else {
        // console.log("✅ No redirect requested, executing nextAction");
        nextAction?.();

        if (shouldClearStatePartially && state) {
          const {
            redirectionRequested,
            requestedRedirectionLocation,
            ...rest
          } = state;
          window.history.replaceState(
            { ...rest },
            "",
            window.location.pathname + window.location.search
          );
        }
      }
    } catch (error) {
      console.error("❌ Redirection error:", error);
    }
  };

  return { detectReqestedRedirection };
};

export default useDetectRedirection;

export const requestRedirection = (path: string) => ({
  redirectionRequested: true,
  requestedRedirectionLocation: path,
});
