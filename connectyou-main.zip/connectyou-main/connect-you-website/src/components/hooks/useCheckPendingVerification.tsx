/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from "react";

const useCheckPendingVerification = () => {
  const [pending_verificationAcc, setpending_verificationAcc] = useState([]);
  const [BankAccountsStatus, setBankAccountsStatus] = useState(0);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchKycCompletionStatus = async () => {
    setLoading(true);
    try {
      setBankAccountsStatus(1);
      setpending_verificationAcc([]);
    } catch (error: any) {
      console.error("fetching error at fetchKycCompletionStatus", { error });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchKycCompletionStatus();
  }, []);

  const refresh = () => {
    fetchKycCompletionStatus();
  };
  return {
    BankAccountsStatus,
    pending: pending_verificationAcc,
    refresh,
    loading,
  };
};
export default useCheckPendingVerification;
