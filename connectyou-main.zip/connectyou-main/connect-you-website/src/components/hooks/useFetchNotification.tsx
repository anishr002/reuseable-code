/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { setCount } from "../../slices/Notification";

const useFetchNotification = () => {
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  const dispatch = useDispatch();
  const [notificationCount, setNotificationCount] = useState<number>(0);
  const [refresh, setRefresh] = useState<boolean>(false);

  useEffect(() => {
    const fetchNotifications = async () => {
      if (loginUserData?._id) {
        try {
          const response = await httpAPI.post(
            `${backendURL}/${
              loginUserData.userType === "coach" ? "coach" : "user"
            }/profile/get-all-notifications?page=${1}&limit=10&filter=${0}`,
            { _id: loginUserData._id },
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("authToken")}`,
              },
            }
          );
          if (response.status !== 200) {
            console.error("Error Fetching socket Notifications");
          } else {
            setNotificationCount(response.data.unreadNotifications);
            dispatch(setCount(response.data.unreadNotifications));
          }
        } catch (error: any) {
          console.error({
            "Error while fetching notifications /useFetchNotification": error,
          });
        }
      } else return;
    };
    fetchNotifications();
  }, [loginUserData?.userType, refresh]);

  const refreshAPI = () => setRefresh((prev) => !prev);
  return { count: notificationCount, refresh: refreshAPI };
};

export default useFetchNotification;
