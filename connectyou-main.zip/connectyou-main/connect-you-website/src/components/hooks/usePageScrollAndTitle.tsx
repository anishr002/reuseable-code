import { useEffect } from "react";

interface usePageScrollAndTitleProps {
  title: string;
  allowScroll?: boolean;
}
const usePageScrollAndTitle = ({
  title,
  allowScroll = true,
}: usePageScrollAndTitleProps) => {
  useEffect(() => {
    document.title = `${title}`;
    if (allowScroll) {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [title, allowScroll]);
};

export default usePageScrollAndTitle;
