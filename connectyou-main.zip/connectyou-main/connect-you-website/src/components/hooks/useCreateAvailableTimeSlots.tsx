/* eslint-disable @typescript-eslint/no-explicit-any */
import moment from "moment-timezone";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import dayjs, { Dayjs } from "dayjs";
// all the import must stay at the top above me///

type FunctionCreate = ({
  // funtion to start creating slots only for selected day to minimize the fun call time
  coachId,
  // coachId refers to the id of the coach who's availble slots are yet to be viewed
  dayIndex,
  // day index  can be from 0 to 6 as sun to sat , //
  slotGap,
  // specified gap between the two consequtive slots of that day selected
  date,
}: // date must be a dayjs date as we are dependent on the dayjs for execution of this functionality
{
  coachId: string;
  // must be a string of coachId
  dayIndex: number;
  // must be a number from 0 to 6 as the index ing of the days in JS
  slotGap: string;
  // must be string as "hh:mm"
  date: Dayjs;
  //all the values must be passed into the funcation to get the result
}) => void; // does not retrun anything/
// type declaration for the crate funcation exported from the hook itself

type FunctionCreateMultiple = ({
  // funtion to start creating slots only for selected day to minimize the fun call time
  coachId,
  // coachId refers to the id of the coach who's availble slots are yet to be viewed
  slotGap,
  // specified gap between the two consequtive slots of that day selected
  dates,
}: // date must be a dayjs date as we are dependent on the dayjs for execution of this functionality
{
  coachId: string;
  // must be a string of coachId
  slotGap: string;
  // must be string as "hh:mm"
  dates: Dayjs[];
  //all the values must be passed into the funcation to get the result
}) => Promise<
  {
    date: Dayjs;
    slots: TimeSlot[];
  }[]
>;
//creating a default function that will return an array of objects containing the available slots as per the users provided availability data

//type declaration for the availability
export interface TimeSlot {
  from: string;
  to: string;
}

interface DayAvailability {
  id: number;
  name: string;
  unavailable: boolean;
  allday: boolean;
  availability: TimeSlot[] | null;
}

type WeekAvailability = {
  availability: DayAvailability[];
  allDayTimeSlot: TimeSlot;
  coachId: string;
  preferedTimeZone: string;
  repeatAvailibility: boolean;
};

// deault export function to return the slots array of length 7 sun to sat , or 0 to 6 , with the available time slots in object form inside arrays of the parent arrays
// type declaration for the slots that we are exporting
interface AvalTimeSlot {
  [key: string]: string;
}
//smallest object depest level ;  consit of from and to key for the start and ending of the slot // will have the simple 1 hour or varying differnce
interface Day {
  [key: string]: AvalTimeSlot[];
}
// day slot that will have an array of the above mentioned objects .
type Slots = Day[];

//default export funcation
export default function useCreateAvailableTimeSlots(): {
  slotsForDay: TimeSlot[];
  //returns the slots generated dynamically for that day
  loadingSlots: boolean;
  // is a boolean to represent if there are no slots available on the selected day
  errorMessage: string | null;
  //loading state for the creation of the slots
  noslotsAval: boolean;
  // if there happens any error this represents that error and is null otherwise
  createSlots: FunctionCreate;
  // function to create all the slots that gets called on any specific event coccurance.
  createSlotsForMultipleDates: FunctionCreateMultiple;
} {
  // const [coachId, setCoachId] = useState<string>('');
  // coachId as the state which will be set by the create funcation when passed and callled...

  const loginUserData = useSelector((state: any) => state.login.userdata);
  // redux global state

  // logged in user will have a key timezone saved as prefered timezone that we will use to see timings in his local ie this timezone
  const client: { [key: string]: string } = getBrowserTimeZone();
  // this function creates / assigns the default browser's time zone to the const here

  // helper function that will provide the default browser's timezone
  const clientTz: string = loginUserData?.timeZone || client?.defaultTZ;
  // either the users's selected timezone if not present then the default tz of the browser

  // this is the data state  for each days availibity.
  const [loadingSlots, setLoadingSlots] = useState<boolean>(false);
  // main loading state of this hook exported to provide the loading functionality for the user
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  // / error  message string in case of any error occurs here
  const [noslotsAval, setnoSlotsAval] = useState<boolean>(false);

  const [slotsForDay, setSlots] = useState<TimeSlot[]>([]);
  // main array containng exactly 7 objects in them having the days from sun to sat , ie 0 to 7
  const [convertedDayAvailibility, setConvertedDayAvailibilty] = useState<
    TimeSlot[] | null
  >(null);

  // function to fetch the availibility data for the given coach
  const fetchAvailabilityData = async (coachId: string) => {
    setLoadingSlots(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/availability/coachAvailability-data/${coachId}`
      );
      if (response.status === 200) {
        const data: WeekAvailability = response.data.data;
        const timeZone = response.data.coachTimeZone;
        // setForeignTimeZone(timeZone);
        setErrorMessage(null);
        return { data, timeZone }; // Return both data and timeZone
      }
    } catch (error: any) {
      console.log("submit error", error);
      setErrorMessage("Error Fetching Data");
      if ([500, 400, 401, 403, 404, 409].includes(error.response.status)) {
        console.error(error.response.data.message || "Something went wrong");
      }
    } finally {
      setLoadingSlots(false);
    }

    return null; // Return null if there was an error
  };

  // wehnever the coachID changes the Fetching availibility data begins

  const createSlots = async ({
    // this fun can be called after getting it required from the custom hook to generate the specific availability of the day that will be identified
    //using the index of that day ie. for sun 0 and for sat 6
    coachId,
    // coach id should be passed here while calling the funcation to execute the custom hook
    dayIndex,
    // day index ie number must be passed here
    slotGap,
    //this will be considered as the gap between two consequtive slots ///
    date,
  }: // date must be a dayjs date as we are dependent on the dayjs for execution of this functionality
  {
    coachId: string;
    // must be a string
    dayIndex: number;
    // the index number of the day as in js from 0 to 6 as sun to sat of the weekdays
    slotGap: string;
    // must be a string
    date: Dayjs;
    // date must be a Dayjs object to calculate the offset differnces and other requuired items
  }) => {
    // setCoachId(coachId);

    setLoadingSlots(true);
    const { data: availabilityData, timeZone: foreignTimeZone } =
      (await fetchAvailabilityData(coachId)) || {}; // Destructure directly with fallback
    if (!availabilityData || !foreignTimeZone) {
      setLoadingSlots(false);
      return; // Exit if data fetching failed
    }

    const newConvertedSlots = mapAvailabilityToInitialSlots(
      availabilityData.availability,
      // passing the availity array in the new aval
      foreignTimeZone,
      // coach's time zone /state that is set above from the aval, the prefer timeozone of the coach.
      clientTz,
      // clients time zone //// the ultimate timezone of the client that is viewer , either from the login data or from the browser itself
      availabilityData.allDayTimeSlot.from,
      // passed fromt eh awavailibilty object , allday timeslot, from
      availabilityData.allDayTimeSlot.to
      // passed fromt eh awavailibilty object , allday timeslot, to
    );
    if (newConvertedSlots.length > 0) {
      const daySlot = newConvertedSlots[dayIndex];
      Object.entries(daySlot).forEach(([day, slots]) => {
        console.log(day);
        const slots1: TimeSlot[] = slots.flatMap((slot) => {
          const currentTime = dayjs().tz(clientTz);
          const selectedDate = date;
          if (currentTime.date() === selectedDate.date()) {
            const roundUpToNextSlot = (time: string): string => {
              const inputTime = dayjs(time, "HH:mm");
              const minutes = inputTime.minute();
              // Round up based on the minutes
              if (minutes > 0 && minutes < 30) {
                return inputTime.minute(30).second(0).format("HH:mm");
              } else if (minutes >= 30) {
                return inputTime.add(1, "hour").startOf("hour").format("HH:mm");
              }
              // If already at the start of the hour, return as is
              return inputTime.startOf("hour").format("HH:mm");
            };
            return generateTimeSlots(
              slot.from < currentTime.format("HH:mm")
                ? roundUpToNextSlot(currentTime.format("HH:mm"))
                : slot.from,
              slot.to,
              slotGap
            );
          } else {
            return generateTimeSlots(slot.from, slot.to, slotGap);
          }
        });
        setConvertedDayAvailibilty(slots1);
      });
    }
  };

  ///function that can create the slots from an array of date's:
  const createSlotsForMultipleDates = async ({
    coachId,
    slotGap,
    dates,
  }: {
    coachId: string;
    slotGap: string;
    dates: Dayjs[];
  }): Promise<{ date: Dayjs; slots: TimeSlot[] }[]> => {
    setLoadingSlots(true);

    const { data: availabilityData, timeZone: foreignTimeZone } =
      (await fetchAvailabilityData(coachId)) || {};
    if (!availabilityData || !foreignTimeZone) {
      setLoadingSlots(false);
      return [];
    }

    const newConvertedSlots = mapAvailabilityToInitialSlots(
      availabilityData.availability,
      foreignTimeZone,
      clientTz,
      availabilityData.allDayTimeSlot.from,
      availabilityData.allDayTimeSlot.to
    );

    const result: { date: Dayjs; slots: TimeSlot[] }[] = [];

    for (const date of dates) {
      const dayIndex = date.day(); // 0 = Sunday, 6 = Saturday
      const daySlot = newConvertedSlots[dayIndex];

      if (!daySlot) continue;

      const currentTime = dayjs().tz(clientTz);

      const slots: TimeSlot[] = Object.entries(daySlot).flatMap(
        ([, slotArray]) =>
          slotArray.flatMap((slot) => {
            const roundUpToNextSlot = (time: string): string => {
              const inputTime = dayjs(time, "HH:mm");
              const minutes = inputTime.minute();
              if (minutes > 0 && minutes < 30) {
                return inputTime.minute(30).second(0).format("HH:mm");
              } else if (minutes >= 30) {
                return inputTime.add(1, "hour").startOf("hour").format("HH:mm");
              }
              return inputTime.startOf("hour").format("HH:mm");
            };

            const slotFrom =
              currentTime.isSame(date, "day") &&
              slot.from < currentTime.format("HH:mm")
                ? roundUpToNextSlot(currentTime.format("HH:mm"))
                : slot.from;

            return generateTimeSlots(slotFrom, slot.to, slotGap);
          })
      );

      result.push({ date, slots });
    }

    setConvertedDayAvailibilty(result.map((r) => r.slots).flat());
    setLoadingSlots(false);

    return result;
  };

  // /////////........... function to be called with passing of the object with the values defined to start the generation of the slots

  useEffect(() => {
    if (convertedDayAvailibility && convertedDayAvailibility?.length > 0) {
      setnoSlotsAval(false);
      setSlots(convertedDayAvailibility);
      setLoadingSlots(false);
    } else if (
      !convertedDayAvailibility ||
      convertedDayAvailibility?.length === 0
    ) {
      setnoSlotsAval(true);
      setLoadingSlots(false);
    }
  }, [convertedDayAvailibility]);

  return {
    slotsForDay,
    //returns the slots generated dynamically for that day
    noslotsAval,
    // is a boolean to represent if there are no slots available on the selected day
    loadingSlots,
    //loading state for the creation of the slots
    errorMessage,
    // if there happens any error this represents that error and is null otherwise
    createSlots,
    // function to create all the slots that gets called on any specific event coccurance.
    createSlotsForMultipleDates,
    // to return multiple days slots from date array
  };
}

function generateTimeSlots(
  //this fun return an array of the slots in key and value form
  startTime: string,
  // can be passed as the initial time to start generating the aval slots with the provided gap between them
  endTime: string,
  // can be passed as the last time to start generating the aval slots with the provided gap between them
  slotGap: string
  // string in the form of minutes to be passed as gap between the two consequtive slots
  // the ffap should be passed as "hh:mm"
) {
  // Convert startTime and endTime to Date objects for easier manipulation

  const start = new Date();
  const end = new Date();

  // Parse the provided start and end times into hours and minutes
  const [startHour, startMinute] = startTime.split(":").map(Number);
  const [endHour, endMinute] = endTime.split(":").map(Number);

  // Set the start and end Date objects with parsed hours and minutes
  start.setHours(startHour, startMinute, 0, 0);
  end.setHours(endHour, endMinute, 0, 0);

  // If the date is today, ensure the start time is not before the current time

  // Parse the slot gap into hours and minutes
  const [gapHours, gapMinutes] = slotGap.split(":").map(Number);

  const slots = [];

  while (start < end) {
    // Calculate the slot's end time (1 hour duration)
    const slotEnd = new Date(start);
    slotEnd.setHours(start.getHours() + 1);

    // Only add the slot if the slot's end is within the range
    if (slotEnd <= end) {
      slots.push({
        from: start.toTimeString().slice(0, 5),
        to: slotEnd.toTimeString().slice(0, 5),
      });
    }

    // Move the start time forward by the gap duration
    start.setMinutes(start.getMinutes() + 60 + (gapHours * 60 + gapMinutes));
  }
  return slots;
}

///
function mapAvailabilityToInitialSlots(
  availability: DayAvailability[],
  initialTimeZone: string,
  finalTimeZone: string,
  allDayFrom: string,
  allDayto: string
): Slots {
  const slots: Slots = [];
  // Initialize an array for each day of the week
  const weekDays = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
  ];
  // checking the time shift status intially to have unifrmatiy

  const timeShiftDirection = timeShiftDirectionStatus({
    foreign: initialTimeZone,
    client: finalTimeZone,
  });

  // tells about the direction of time shift negative means the time in client  is to be behind the foreign
  // intialising the weekdays
  const daySlotsMap: { [key: string]: AvalTimeSlot[] } = {};

  weekDays.forEach((day) => {
    daySlotsMap[day] = []; // Initialize slots for each day
  });

  // console.log(availability);
  availability.forEach((day) => {
    if (day.unavailable) {
      return; // Skip unavailable days
    }
    // returns an empty array for that day which is unavailable
    // end of handling the first case of given availibilty is unavailable
    if (day.allday) {
      //when the day is set to all day we will first conver the given all day time slots to and ffrom time to lcoal time ie, clients time
      const allDayfromTimeInClient = convertTimeZone(
        // convert function introduced at top
        initialTimeZone,
        finalTimeZone,
        allDayFrom
      );
      // as the convertedTZ contains the time stamp eg 18:00
      //time converted in to the client / views local time
      const allDayToTimeInClient = convertTimeZone(
        initialTimeZone,
        finalTimeZone,
        allDayto
      );
      // as the convertedTZ contains the time stamp eg 18:00
      //time converted in to the client / views local time
      // setting up the timeshift direction const to start case break
      //case first
      if (timeShiftDirection === "isSame") {
        // this obvioulsy means that the both time zones are in the same offset and they are the same timezones
        if (
          allDayfromTimeInClient.convertedTZ < allDayToTimeInClient.convertedTZ
          // in such case the from time will always be less than the to time and in positive direction and this we can diercly make
          // the slot without any manipulation and fast response is expected this
          // is the reason to put the same flag check at first
        ) {
          daySlotsMap[day.name].push({
            from: allDayfromTimeInClient.convertedTZ,
            to: allDayToTimeInClient.convertedTZ,
          });
        }
        // simplest pushing the slot into the return obj
      }
      // time shift is not  there ie same // same time zone this creating simple slots
      //case second
      //when the clients time zone is ahead of the froeign time zone , means addition of some hours in the clients / viewers time
      if (timeShiftDirection === "isPositive") {
        if (
          allDayfromTimeInClient.convertedTZ < allDayToTimeInClient.convertedTZ
        ) {
          if (
            !allDayfromTimeInClient.dayChanged &&
            !allDayToTimeInClient.dayChanged
          ) {
            daySlotsMap[day.name].push({
              from: allDayfromTimeInClient.convertedTZ,
              to: allDayToTimeInClient.convertedTZ,
            });
          }
          if (allDayfromTimeInClient.dayChanged) {
            const nextDayIndex = (day.id + 1) % 7;
            daySlotsMap[weekDays[nextDayIndex]].push({
              from: allDayfromTimeInClient.convertedTZ,
              to: allDayToTimeInClient.convertedTZ,
            }); // Start of the next day
          }
          if (
            !allDayfromTimeInClient.dayChanged &&
            allDayToTimeInClient.dayChanged
          ) {
            daySlotsMap[day.name].push({
              from: allDayfromTimeInClient.convertedTZ,
              to: "23:59",
            });
            const nextDayIndex = (day.id + 1) % 7;
            daySlotsMap[weekDays[nextDayIndex]].push({
              from: "00:00",
              to: allDayToTimeInClient.convertedTZ,
            });
          }
        } else {
          // Split the slots at midnight
          daySlotsMap[day.name].push({
            from: allDayfromTimeInClient.convertedTZ,
            to: "23:59",
          }); // End of the current day
          // Push the next day slot
          // console.log(day.name, "all day pusher time went to two diff days");
          const nextDayIndex = (day.id + 1) % 7;
          daySlotsMap[weekDays[nextDayIndex]].push({
            from: "00:00",
            to: allDayToTimeInClient.convertedTZ,
          }); // Start of the next day
        }
      }
      // case third /
      //when the time is to be substracted  viewer time is behind some hours the foreign time
      if (timeShiftDirection === "isNegative") {
        if (
          allDayfromTimeInClient.convertedTZ < allDayToTimeInClient.convertedTZ
        ) {
          // when the slot is in same day // create a simple object
          if (
            !allDayfromTimeInClient.dayChanged &&
            !allDayToTimeInClient.dayChanged
          ) {
            daySlotsMap[day.name].push({
              from: allDayfromTimeInClient.convertedTZ,
              to: allDayToTimeInClient.convertedTZ,
            });
          }
          if (allDayfromTimeInClient.dayChanged) {
            const prevDayIndex = (day.id - 1 + 7) % 7;
            // console.log(prevDayIndex);
            daySlotsMap[weekDays[prevDayIndex]].push({
              from: allDayfromTimeInClient.convertedTZ,
              to: "23:59",
            }); // Start of the current  day
            daySlotsMap[day.name].push({
              from: "00:00",
              to: allDayToTimeInClient.convertedTZ,
            }); // End of the previous day
            // Push the current day slot
          }
          if (
            allDayfromTimeInClient.dayChanged &&
            allDayToTimeInClient.dayChanged
          ) {
            const prevDayIndex = (day.id - 1 + 7) % 7;
            daySlotsMap[weekDays[prevDayIndex]].push({
              from: allDayfromTimeInClient.convertedTZ,
              to: allDayToTimeInClient.convertedTZ,
            });
          }
        } else {
          const prevDayIndex = (day.id - 1 + 7) % 7;
          // console.log(prevDayIndex);
          daySlotsMap[weekDays[prevDayIndex]].push({
            from: allDayfromTimeInClient.convertedTZ,
            to: "23:59",
          }); // Start of the current  day
          // Split the slots at midnight
          daySlotsMap[day.name].push({
            from: "00:00",
            to: allDayToTimeInClient.convertedTZ,
          }); // End of the previous day
          // Push the current day slot
        }
      }
    }

    if (day.availability && day.availability.length > 0) {
      day.availability.forEach((slot) => {
        // console.log(slot);
        const fromTimeInClient = convertTimeZone(
          initialTimeZone,
          finalTimeZone,
          slot.from
        );
        const toTimeInClient = convertTimeZone(
          initialTimeZone,
          finalTimeZone,
          slot.to
        );
        if (timeShiftDirection === "isSame") {
          if (fromTimeInClient.convertedTZ < toTimeInClient.convertedTZ) {
            // Same day slot
            if (!fromTimeInClient.dayChanged && !toTimeInClient.dayChanged) {
              daySlotsMap[day.name].push({
                from: fromTimeInClient.convertedTZ,
                to: toTimeInClient.convertedTZ,
              });
            }
          }
        }

        // Both times are positive
        if (timeShiftDirection === "isPositive") {
          // Check if they are on the same day
          if (fromTimeInClient.convertedTZ < toTimeInClient.convertedTZ) {
            // Same day slot
            if (!fromTimeInClient.dayChanged && !toTimeInClient.dayChanged) {
              daySlotsMap[day.name].push({
                from: fromTimeInClient.convertedTZ,
                to: toTimeInClient.convertedTZ,
              });
            }
            // Next day slot logic
            if (fromTimeInClient.dayChanged) {
              const nextDayIndex = (day.id + 1) % 7;
              daySlotsMap[weekDays[nextDayIndex]].push({
                from: fromTimeInClient.convertedTZ,
                to: toTimeInClient.convertedTZ,
              });
            }

            if (!fromTimeInClient.dayChanged && toTimeInClient.dayChanged) {
              daySlotsMap[day.name].push({
                from: fromTimeInClient.convertedTZ,
                to: "23:59",
              });
              const nextDayIndex = (day.id + 1) % 7;
              daySlotsMap[weekDays[nextDayIndex]].push({
                from: "00:00",
                to: toTimeInClient.convertedTZ,
              });
            }
          } else {
            // Split the slots at midnight
            daySlotsMap[day.name].push({
              from: fromTimeInClient.convertedTZ,
              to: "23:59",
            });
            const nextDayIndex = (day.id + 1) % 7;
            daySlotsMap[weekDays[nextDayIndex]].push({
              from: "00:00",
              to: toTimeInClient.convertedTZ,
            });
          }
        }

        // Both times are negative
        if (timeShiftDirection === "isNegative") {
          if (fromTimeInClient.convertedTZ < toTimeInClient.convertedTZ) {
            // Same day
            if (!fromTimeInClient.dayChanged && !toTimeInClient.dayChanged) {
              daySlotsMap[day.name].push({
                from: fromTimeInClient.convertedTZ,
                to: toTimeInClient.convertedTZ,
              });
            }

            if (fromTimeInClient.dayChanged) {
              daySlotsMap[day.name].push({
                from: "00:00",
                to: toTimeInClient.convertedTZ,
              });
              const prevDayIndex = (day.id - 1 + 7) % 7;
              daySlotsMap[weekDays[prevDayIndex]].push({
                from: fromTimeInClient.convertedTZ,
                to: "23:59",
              });
            }

            if (fromTimeInClient.dayChanged && toTimeInClient.dayChanged) {
              const prevDayIndex = (day.id - 1 + 7) % 7;
              daySlotsMap[weekDays[prevDayIndex]].push({
                from: fromTimeInClient.convertedTZ,
                to: toTimeInClient.convertedTZ,
              });
            }
          } else {
            // Split the slots at midnight
            daySlotsMap[day.name].push({
              from: "00:00",
              to: toTimeInClient.convertedTZ,
            });
            const prevDayIndex = (day.id - 1 + 7) % 7;
            daySlotsMap[weekDays[prevDayIndex]].push({
              from: fromTimeInClient.convertedTZ,
              to: "23:59",
            });
          }
        }
      });
    }
  });
  // Build the final slots array in order from Sunday to Saturday
  weekDays.forEach((day) => {
    if (daySlotsMap[day].length > 0) {
      slots.push({ [day]: daySlotsMap[day] });
    } else {
      slots.push({ [day]: [] }); // Ensure all days are represented
    }
  });

  return slots;
}

//type declaration for the createSlots Function that will be called at any occurance of event in the parent to create or generate the slots

// this TimeSlot is of the key and value pairs for the converted into local time for the slot timeings available

interface OUTput {
  convertedTZ: string;
  // ts interface for the helper function
  convertedTZutcStr: string;
  // ts interface for the helper function
  timeDiffernce: string;
  // positive or negative as per UTC diff
  dayChanged: boolean;
  // differnce in the time
}
// function that will take 3 params , Intial Time zone (ffrom wich the time need to be converted) , final timezone (into which the tz is to be ocnvereted) , and the time
export function convertTimeZone(
  initialTimeZone: string,
  // from which time zone we want to convert the time
  finalTimeZone: string,
  // to which time zone we wanted to convert the time to
  time: string
  // time that we want to convert
): OUTput {
  // time conversion simeple
  const initialTime = moment.tz(time, "HH:mm", initialTimeZone);
  // converted time in the local or client time zone
  const finalTime = initialTime.clone().tz(finalTimeZone);
  // in the foreign timezone
  // will create a moment object ie UTC with offset of the initial provided from initial TZ  ,
  //  with ref to its time zone using the UTC offset

  const foreignOffset = moment.tz(initialTimeZone).utcOffset();
  // the utc offset of the coach or foerign
  const clientOffset = moment.tz(finalTimeZone).utcOffset();
  // the utc offset of the local timezone or the client or the viewer

  let timeDifference;
  if (foreignOffset > clientOffset) {
    timeDifference = "isNegative"; // the viewer will be in a time behind the coach
  } else if (foreignOffset < clientOffset) {
    timeDifference = "isPositive"; // menas that the viewer time is ahead of the the foregin or coaches time
  } else {
    timeDifference = "isPositive"; //
  }
  // chekc this check  to get ruight values
  // Calculate the day difference between initial and final times
  const dayDifference = finalTime.day() - initialTime.day();
  const dayChanged = dayDifference !== 0; // Indicator for day change

  // will create a moment object ie UTC with offset of the final TZ  , with ref to its time zone using the UTC offset
  return {
    convertedTZ: finalTime.format("HH:mm"),
    // simply returning the HH:mm like 16:00
    convertedTZutcStr: finalTime.toISOString(),
    // will return the whole UTC date with adjusted OFfset that we can use later if we want
    timeDiffernce: timeDifference,
    // have three values , ispositive for + time diff , - is negative for -ve diff. and is same for same tiem zones
    dayChanged: dayChanged,
  };

  // we will simply return the new time  and // in a UTC date format  both so that we can use any one we like to display or to play with
}
//new function that will only tell about the UTC differnece between the two time zone to calculate out if the time should be added or substracted b/w
//the two time zones

export function timeShiftDirectionStatus({
  foreign,
  client,
}: {
  foreign: string;
  client: string;
}) {
  let timeShiftDirection;
  // isPositive /// means we have to add the time to the clients time
  // client is ahead of foreign time
  // is Negative means just to substract the time from clients time
  // client is behind the foreign time
  // is same means both are in same timezone
  const foreignOffset = moment.tz(foreign).utcOffset();
  // the utc offset of the coach or foerign
  const clientOffset = moment.tz(client).utcOffset();
  // the utc offset of the local timezone or the client or the viewer

  if (foreignOffset > clientOffset) {
    timeShiftDirection = "isNegative"; // the viewer will be in a time behind the coach
  } else if (foreignOffset < clientOffset) {
    timeShiftDirection = "isPositive"; // menas that the viewer time is ahead of the the foregin or coaches time
  } else {
    timeShiftDirection = "isSame"; //lies in the same offset
  }

  return timeShiftDirection;
}

export function getBrowserTimeZone(): { [key: string]: string } {
  // geting the default time zone of the user from the moment js liberary
  const TZ = moment.tz.guess();
  // will guess / get the default time zone in IANA format that the users browser recognizes
  // console.log(TZ);
  return { defaultTZ: TZ };
  // returning it as an object with name as default time zone (defaultTZ ) to avaoid confusion
}
