import React, { ReactNode } from "react";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";

interface WhiteProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
}
const WhiteRoundedBox: React.FC<WhiteProps> = (props) => {
  const { children, className, ...rest } = props;
  const defClasses = "bg-white h-fit p-[20px] flex flex-col rounded-[5px]";

  return (
    <div
      {...rest}
      className={`${removeDuplicateClasses(`${className} ${defClasses}`)}`}
    >
      {children}
    </div>
  );
};

export default WhiteRoundedBox;
