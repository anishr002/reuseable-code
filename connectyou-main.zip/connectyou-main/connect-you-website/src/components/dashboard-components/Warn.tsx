import { FC, ReactNode, useEffect, useState } from "react";
import { IoIosWarning } from "react-icons/io";
import removeDuplicateClasses from "../../util/removeDuplicateClasses";
import ProvideToolTip from "../wrappers/ProvideToolTip";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";
import moment from "moment-timezone";
import customAlert from "../../lib/swalExtentions";
import { SweetAlertOptions } from "sweetalert2";

export interface WarnProps {
  children?: ReactNode;
  iconClases?: string;
  warning?: string;
  date?: string;
  compareByTZ?: boolean;
  PopOptions?: SweetAlertOptions;
  popupNextAction?: () => void;
}
const Warn: FC<WarnProps> = ({
  children,
  iconClases,
  warning = "The commencement date for the session has passed. Click the icon above to know more.",
  date,
  compareByTZ,
  PopOptions,
  popupNextAction,
}) => {
  const userTimeZone =
    useSelector((state: RootState) => state.login.userdata.timeZone) ||
    moment().tz();
  const [trig, setTrig] = useState<boolean>(false);

  useEffect(() => {
    const compare = () => {
      if (date) {
        if (compareByTZ) {
          return (
            moment(date)
              .tz(userTimeZone || "")
              .isBefore(moment().tz(userTimeZone || "")) && setTrig(true)
          );
        } else {
          return moment(date).isBefore(moment()) && setTrig(true);
        }
      }
    };
    compare();
  }, [date]);

  return (
    <>
      {children}
      {trig && (
        <ProvideToolTip title={warning || ""}>
          <div
            onClick={() => {
              customAlert
                .fire({
                  title: "The session date has already passed!",
                  text: "The scheduled date for this session has passed. Please update the session status by clicking on the 'View Details' button, navigating to the 'Actions' tab, and selecting the appropriate option from the available actions.",
                  confirmButtonText: "View Details",
                  showCancelButton: true,
                  ...PopOptions,
                })
                .then((result) => {
                  if (result.isConfirmed) {
                    popupNextAction?.();
                  }
                });
            }}
            className="inline-flex justify-center items-center mx-0.5"
          >
            <IoIosWarning
              className={removeDuplicateClasses(
                `${iconClases} text-[red] font-semibold text-[14px]`
              )}
            />
          </div>
        </ProvideToolTip>
      )}
    </>
  );
};

export default Warn;
