import { createContext, ReactNode, SetStateAction } from "react";

export const HeadingContext = createContext<{
  content: ReactNode;
  setContent: React.Dispatch<SetStateAction<ReactNode | undefined>>;
} | null>(null);
