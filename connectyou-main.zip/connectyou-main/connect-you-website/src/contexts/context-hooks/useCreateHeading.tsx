/* eslint-disable react-refresh/only-export-components */
/* eslint-disable react-hooks/exhaustive-deps */
import { ReactNode, useContext, useEffect } from "react";
import { HeadingContext } from "../HeadingContext";
import { CircularProgress } from "@mui/material";

export const useCreateHeading = () => {
  const context = useContext(HeadingContext);
  if (!context) {
    throw new Error("useCreateHeading must be used within a HeadingProvider");
  }
  return context;
};

export const HeadingText = ({
  loading,
  children,
}: {
  loading?: boolean;
  children: ReactNode;
}) => {
  return (
    <h1 className="text-[white] flex flex-row w-full h-full justify-start items-center gap-2 whitespace-nowrap uppercase font-bold text-[14px] font-mundial  md:text-[20px] leading-normal overflow-hidden">
      <span className="truncate text-ellipsis overflow-hidden flex-1 max-w-[250px] w-full">
        {children}
      </span>
      {loading && <CircularProgress size={24} color="inherit" />}
    </h1>
  );
};

const CreatePageHeading = ({ children }: { children: ReactNode }) => {
  const { setContent } = useCreateHeading();
  useEffect(() => {
    if (children) {
      setContent(children);
    }
    return () => setContent(undefined);
  }, [children, setContent]);

  return <></>;
};

export default CreatePageHeading;
