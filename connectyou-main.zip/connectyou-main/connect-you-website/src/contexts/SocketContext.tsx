import React, { createContext, useContext, ReactNode, useEffect } from "react";
import { Socket } from "socket.io-client";
import { useSelector } from "react-redux";
import { RootState } from "../lib/store";
import useSocket from "../components/hooks/useSocket";


export interface SocketWithState extends Socket {
  connected: boolean;
}
interface SocketContextValue {
  socket: SocketWithState | null;
}

const SocketContext = createContext<SocketContextValue | null>(null);

export const SocketProvider: React.FC<{
  children: ReactNode;
  initialAuthToken?: string | null;
}> = ({ children, initialAuthToken }) => {

  const loggedIn = useSelector(
    (state: RootState) => state.login?.userdata?.userType
  );
  const { socket, clearSocket } = useSocket({ initialAuthToken });

  useEffect(() => {
    if (!loggedIn || loggedIn === "") {
      console.log("clearing socket.. as user logged out");
      clearSocket();
    }
  }, [loggedIn]);

  return (
    <SocketContext.Provider value={{ socket }}>
      {children}
    </SocketContext.Provider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useSocketContext = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error("useSocketContext must be used within a SocketProvider");
  }
  const getSocket = () => {
    return context.socket;
  };
  return getSocket;
};
