import { useNavigate } from "react-router-dom";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import useScreenSize from "../../components/hooks/useScreenSize";
import XSpace from "../../components/wrappers/XSpace";

const SuccessStories = () => {
  const { isXl } = useScreenSize();
  const navigate = useNavigate();

  return (
    <div className="cursor-pointer bg-[#f0f0f0] w-full gap-4 py-6 md:py-10 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <XSpace>
        <div className="flex flex-col  justify-center items-center gap-5">
          <p className="uppercase text-[#013338]  font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
            Success Stories{isXl && <br />} from Our Business Partners
          </p>
          <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
            Hear how ConnectYou has transformed organizations worldwide.
          </p>
          <div className="gap-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 w-full flex-1 py-1">
            {options.map((opt, i) => (
              <div
                key={`subscription-options-list-${i}`}
                className={`bg-[#3aa7a3] text-white col-span-1 flex flex-col gap-5 p-4 justify-center items-center rounded-[20px] 
              transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-2xl hover:border-[#013338]`}
              >
                <p className="font-bold uppercase font-mundial text-[20px]">
                  {opt.heading}
                </p>

                <p className="font-medium text-[16px]">{opt.description}</p>
                <a
                  target="_blank"
                  className="w-full  underline underline-offset-2 text-[#013338] hover:text-[#ebbd33]"
                >
                  Learn More
                </a>
              </div>
            ))}
          </div>
          <div className="w-full flex justify-center items-center">
            <PrimaryYellowButton
              text="Get in touch"
              onClick={() => navigate("/get-in-touch")}
            />
          </div>
        </div>
      </XSpace>
    </div>
  );
};

export default SuccessStories;

const options = [
  {
    heading: " Leadership Development at a Leading Tech Firm",
    description:
      "Discover how coaching empowered leaders to navigate change and inspire teams.",
    link: "/",
  },
  {
    heading: "Boosting Team Dynamics in a Fortune 500 Company",
    description:
      "See how personalized coaching drove collaboration and innovation.",
    link: "/",
  },
  {
    heading: "Improved Retention for a Global Retail Brand",
    description:
      "Learn how targeted coaching programs reduced turnover and increased employee satisfaction.",
    link: "/",
  },
];
