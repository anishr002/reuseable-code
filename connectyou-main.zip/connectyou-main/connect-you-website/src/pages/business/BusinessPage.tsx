import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import XSpace from "../../components/wrappers/XSpace";
import BusinessPageBanner from "./BusinessPageBanner";
import ChallengesSection from "./ChallengesSection";
import CoachingSolutions from "./CoachingSolutions";
import FiveStepsSection from "./FiveStepsSection";
import Subscriptions from "./Subscriptions";
import SuccessStories from "./SuccessStories";
import TransformWorkForce from "./TransformWorkForce";
import TrustedBySection from "./TrustedBySection";
import WhyPartner from "./WhyPartner";

const BusinessPage = () => {
  usePageScrollAndTitle({ title: "ConnectYou Business" });
  return (
    <div className="w-full flex flex-col h-full justify-center items-center bg-white">
      <BusinessPageBanner />
      <XSpace>
        <ChallengesSection />
      </XSpace>
      <CoachingSolutions />
      <XSpace>
        <WhyPartner />
      </XSpace>
      <TrustedBySection />
      <FiveStepsSection />
      <XSpace>
        <Subscriptions />
      </XSpace>
      <SuccessStories />
      <XSpace>
        <TransformWorkForce />
      </XSpace>
    </div>
  );
};

export default BusinessPage;
