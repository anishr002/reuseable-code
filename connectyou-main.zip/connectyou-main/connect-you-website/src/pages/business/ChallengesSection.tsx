import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import HoverableImageGallery from "../../components/UI/HoverableImageGallery";
import image1 from "../../assets/images/image-1.png";
import image2 from "../../assets/images/image-2.webp";
import image3 from "../../assets/images/image-3.png";
import image4 from "../../assets/images/image-4.webp";
import Business_Challenege_Content_TYPE from "../../Types/UI/BusinessChallenege_Content_TYPE";
import { useNavigate } from "react-router-dom";

const ChallengesSection = () => {
  const navigate = useNavigate();
  return (
    <div className=" cursor-pointer  w-full xl:min-h-fit gap-4 py-10 md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338]  pt-10 font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Solving your business challenges
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        Coaching that addresses today’s workplace needs.
      </p>
      <div className="flex-1 flex flex-row justify-center items-center w-full py-10">
        <HoverableImageGallery content={BusinessChallengeArr} />
      </div>
      <div className=" flex flex-row justify-center items-center w-full">
        <PrimaryYellowButton
          onClick={() => navigate("/get-in-touch")}
          text="Get In Touch"
        />
      </div>
    </div>
  );
};

export default ChallengesSection;

const BusinessChallengeArr: Business_Challenege_Content_TYPE[] = [
  {
    image: image1,
    heading: "High-Performance Culture",
    description:
      "How do we align teams to perform at their best while staying true to company values?",
  },
  {
    image: image2,
    heading: "Innovation, Change & Transformation",
    description:
      "How do we build resilience and embrace opportunities in an increasingly complex world?",
  },
  {
    image: image3,
    heading: "Diversity, Equity & Inclusion",
    description:
      "How do we foster an inclusive culture that breaks barriers and drives DEI outcomes and connectedness?",
  },
  {
    image: image4,
    heading: "Leadership & Talent Development",
    description:
      "How do we accelerate the growth of emerging leaders and retain top talent?",
  },
];
