import { useNavigate } from "react-router-dom";
import image from "../../assets/images/transform-work-force-image.png";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import HighlightGetInTouchCardWrapper from "../../components/wrappers/HighlightGetInTouchCardWrapper";

const TransformWorkForce = () => {
  const navigate = useNavigate();

  return (
    <div className="flex w-full justify-center items-center py-10">
      <HighlightGetInTouchCardWrapper
        button={
          <>
            <PrimaryYellowButton
              text="Get In Touch"
              onClick={() => navigate("/get-in-touch")}
            />
          </>
        }
        rightContent={
          <>
            <p className="z-20 text-[#ebbd33] text-pretty  flex flex-col justify-center items-center w-full font-bold font-mundial uppercase text-[24px] md:text-[36px] text-center md:text-left">
              Ready to Transform <br />
              <span className="text-white">Your Workforce?</span>
            </p>
            <p className=" text-white font-medium text-[18px] text-center w-9/12">
              Discover how ConnectYou can unlock the full potential of your team
              and drive measurable business outcomes.
            </p>
          </>
        }
        image={image}
      />
    </div>
  );
};

export default TransformWorkForce;
