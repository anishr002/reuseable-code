import React, { useState } from "react";
import XSpace from "../../components/wrappers/XSpace";
import NavigationBullet from "../../components/UI/NavigationBullet";
import image1 from "../../assets/images/bussiness-slider-Team Coaching-image.png";
import image2 from "../../assets/images/bussiness-slider-Leadership-Development-image.png";
import image3 from "../../assets/images/bussiness-slider-Executive-Coaching-image.png";
import image4 from "../../assets/images/bussiness-slider-Custom-Programs-&-Workshops-image.png";
import image5 from "../../assets/images/business-page-slider-image.png";
import Coaching_Programs_Tabs_Data_TYPE from "../../Types/UI/Coaching_Programs_Tabs_Data_TYPE";
import FullWidthSimpleSlider from "../../components/wrappers/FullWidthSimpleSlider";
import { SwiperSlide } from "swiper/react";
import { Swiper as SwiperType } from "swiper";
import useScreenSize from "../../components/hooks/useScreenSize";

const CoachingSolutions = () => {
  const [active, setActive] = useState<Coaching_Programs_Tabs_Data_TYPE | null>(
    coachingPrograms[0]
  );
  const handleActive = ({ cp }: { cp: Coaching_Programs_Tabs_Data_TYPE }) => {
    setActive(cp);
    if (swiperInstance) {
      swiperInstance.slideTo(cp.index - 1);
    }
  };
  const [swiperInstance, setSwiperInstance] = useState<SwiperType | null>(null);
  const onSlideChange = (swiper: SwiperType) => {
    // console.log({ swiper });
    setActive(coachingPrograms[swiper.activeIndex]);
  };
  const { isMobile, isTab } = useScreenSize();
  return (
    <div className="w-full h-auto rounded-[20px] bg-[#013338] min-h-fit gap-4 py-10 md:py-18 flex flex-col justify-center items-center relative mb-14">
      <XSpace>
        <div className="flex flex-col  xl:min-h-[680px] w-full items-center justify-center h-fit gap-12 lg:px-0 sm:px-6 md:px-10 overflow-hidden">
          <p className="uppercase text-[white] font-mundial leading-[110%] font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
            <span className="text-[#ebbd33]">Coaching solutions </span>
            designed <br />
            for your business needs
          </p>
          <div className="w-full h-full flex-1 flex flex-col justify-center items-center gap-6 sm:gap-12">
            <div className="w-full rounded-[100px] px-2.5 py-2 bg-[#f0f0f0] h-[70px] flex flex-row justify-between items-center ">
              {isMobile || isTab ? (
                <div
                  onClick={() => {
                    if (swiperInstance) {
                      if (swiperInstance.isEnd) {
                        swiperInstance.slideTo(0, 1);
                      } else {
                        swiperInstance.slideNext();
                      }
                    }
                  }}
                  className="w-full h-full justify-center items-center flex bg-[#ebbd33] rounded-[100px]"
                >
                  <NavigationBullet
                    title={active?.name}
                    isActive={Boolean(active?.name)}
                  />
                </div>
              ) : (
                <>
                  {coachingPrograms.map(
                    (cp: Coaching_Programs_Tabs_Data_TYPE, i: number) => (
                      <React.Fragment key={`coaching-program-nav-bullet-${i}`}>
                        <NavigationBullet
                          title={cp.name}
                          onClick={() => handleActive({ cp })}
                          isActive={active?.name === cp.name}
                        />
                      </React.Fragment>
                    )
                  )}
                </>
              )}
            </div>

            <div className="md:flex-1 w-full md:h-full flex flex-row justify-between items-center gap-12">
              {/* Left Side: Image */}
              <FullWidthSimpleSlider
                swiperInstance={swiperInstance}
                setSwiperInstance={setSwiperInstance}
                showNavButtons={false}
                showPagination={false}
                props={{
                  centeredSlides: true,
                  loop: false,
                }}
                onSlideChange={onSlideChange}
              >
                {coachingPrograms.map(
                  (cp: Coaching_Programs_Tabs_Data_TYPE, i: number) => (
                    <SwiperSlide
                      key={`coaching-progrmas-slide-${i}`}
                      style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <div className="flex flex-col md:flex-row  justify-between items-center gap-12">
                        <div className="w-full  md:w-1/2 h-full flex justify-center items-center overflow-hidden rounded-[10px]">
                          <img
                            src={cp.content.image || image1} // Default image if none is provided
                            alt={cp.name}
                            className="w-full h-full object-cover rounded-[10px] hover:scale-3d hover:scale-[1.02] cursor-pointer"
                          />
                        </div>
                        {/* Right Side: Heading and Description */}
                        <div className="w-full  md:w-1/2 h-full flex flex-col justify-center items-start text-left gap-4">
                          <h2 className="text-[#ebbd33] font-mundial uppercase font-bold text-[32px]">
                            {cp.content.heading}
                          </h2>
                          <p className="text-white font-normal text-[20px] md:w-10/12">
                            {cp.content.description}
                          </p>
                        </div>
                      </div>
                    </SwiperSlide>
                  )
                )}
              </FullWidthSimpleSlider>
            </div>
          </div>
        </div>
      </XSpace>
    </div>
  );
};

export default CoachingSolutions;

const coachingPrograms: Coaching_Programs_Tabs_Data_TYPE[] = [
  {
    index: 1,
    name: "Team Coaching",
    content: {
      image: image1,
      heading: "Team Coaching",
      description:
        "Build stronger, more cohesive teams. Help your teams collaborate, innovate, and perform at their best with customized coaching tailored to group dynamics and goals.",
    },
  },
  {
    index: 2,
    name: "Leadership Development",
    content: {
      image: image2,
      heading: "Leadership Development",
      description:
        "Equip your leaders with the skills and mindset needed to inspire and drive success. From emerging leaders to senior executives, we offer tailored solutions for every level.",
    },
  },
  {
    index: 3,
    name: "Executive Coaching",
    content: {
      image: image3,
      heading: "Executive Coaching",
      description:
        "Support your top executives in achieving clarity, resilience, and strategic decision-making. Our experienced coaches specialize in empowering leaders to excel in high-pressure environments.",
    },
  },
  {
    index: 4,
    name: "Custom Programs & Workshops",
    content: {
      image: image4,
      heading: "Custom Programs & Workshops",
      description:
        "Create bespoke coaching and training experiences designed to meet your organization’s unique challenges and goals. We work closely with you to align our programs with your strategic vision.",
    },
  },
  {
    index: 5,
    name: "Individual Coaching",
    content: {
      image: image5,
      heading: "Individual Coaching",
      description:
        "Support the personal growth and professional development of key individuals within your organization. From stress management to skill enhancement, one-on-one coaching helps employees thrive and achieve their full potential.",
    },
  },
];
