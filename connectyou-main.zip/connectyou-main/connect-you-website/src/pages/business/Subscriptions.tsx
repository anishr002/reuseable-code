import { useState } from "react";
import "../../styles/Subscriptions.css";
// dont forget to add the color in the css for the list marker colors

const Subscriptions = () => {
  const [activeCard, setActiveCard] = useState<number | null>(null);
  const onMouseEnter = (i: number) => setActiveCard(i);
  const onMouseLeave = () => setActiveCard(null);

  return (
    <div className="cursor-pointer w-full gap-4 py-6 md:py-10 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Solutions for Every Size
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        Choose from our 3 subscriptions for organizations
      </p>
      <div className="gap-x-2 gap-y-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 w-full flex-1 py-1">
        {options.map((opt, i) => (
          <div
            onMouseEnter={() => onMouseEnter(i)}
            onMouseLeave={onMouseLeave}
            key={`subscription-options-list-${i}`}
            className={`bg-[#f0f0f0] col-span-1 flex flex-col gap-5 py-10 justify-center items-center rounded-[20px] 
              border-2 border-[${opt.themeColor}] 
              transition-all duration-300 ease-in-out`}
            style={{
              borderColor: opt.themeColor,
              background: activeCard === i ? opt.themeColor : "#f0f0f0",
            }}
          >
            <div
              className={`flex text-[${opt.headingColor}] uppercase font-mundial font-bold flex-row justify-center items-center w-fit px-8 py-1.5 rounded-[20px] bg-[${opt.themeColor}]`}
              style={{
                borderColor: opt.themeColor,
                background:
                  activeCard === i
                    ? i === 2
                      ? "white"
                      : "#013338"
                    : opt.themeColor,
                color:
                  activeCard === i
                    ? i === 2
                      ? opt.themeColor
                      : "white"
                    : "white",
              }}
            >
              {opt.name}
            </div>
            <ul className="list-disc">
              {opt.points.map((point, inx) => (
                <li
                  key={`subscription-plan-${opt.name}-point-list-item-${inx}`}
                  className={`font-semibold ${
                    activeCard === i
                      ? ` marker-${opt.name}-active`
                      : ` marker-${opt.name}`
                  } text-[#013338] `}
                  style={{
                    listStyleType: "disc",
                    color:
                      activeCard === i
                        ? i === 2
                          ? "white"
                          : "#013338"
                        : "#013338",
                  }}
                >
                  {point}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Subscriptions;

const options = [
  {
    name: "Basic",
    points: [
      "Lorem ipsum dolor sit amet.",
      "Lorem ipsum dolor sit amet.",
      "Lorem ipsum dolor sit amet.",
    ],
    themeColor: "#3AA7A3",
    headingColor: "white",
  },
  {
    name: "Standard",
    points: [
      "Lorem ipsum dolor sit amet.",
      "Lorem ipsum dolor sit amet.",
      "Lorem ipsum dolor sit amet.",
    ],
    themeColor: "#EBBD33",
    headingColor: "#013338",
  },
  {
    name: "Enterprise",
    points: [
      "Lorem ipsum dolor sit amet.",
      "Lorem ipsum dolor sit amet.",
      "Lorem ipsum dolor sit amet.",
    ],
    themeColor: "#013338",
    headingColor: "white",
  },
];
