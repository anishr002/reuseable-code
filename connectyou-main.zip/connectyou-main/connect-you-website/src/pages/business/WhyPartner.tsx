import vector1 from "../../assets/icons/check-vector.png";
import vector2 from "../../assets/icons/lins-vector.png";
import vector3 from "../../assets/icons/45.png";
import vector4 from "../../assets/icons/why-cy-vertor-3.png";

import FeatureCard from "../../components/UI/FeatureCard";

const WhyPartner = () => {
  return (
    <div className=" cursor-pointer  w-full xl:min-h-[31rem] gap-4 py-6 md:py-10 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center ">
        Why businesses partner with
        <span className="text-[#3aa7a3]"> connectyou </span> ?
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        We make coaching simple, effective, and personalized for organizations
        of all sizes across the world.
      </p>
      <div className="gap-4 grid grid-cols-1 min-h-fit auto-rows-fr md:grid-cols-2 xl:grid-cols-2 w-full flex-1 py-1">
        {partnerPerks.map((feature, i) => (
          <div
            className="w-full  col-span-1 min-h-fit max-h-full"
            key={`why-parneter-connect-you-featured-card-${i}`}
          >
            <FeatureCard
              description={feature.description}
              heading={feature.heading}
              vector={feature.vector}
              background="bg-[#ebbd33]"
              textColor="text-[#013338]"
              className="feature-card-yellow " // Ensure cards stretch to fill the grid cell
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default WhyPartner;

const partnerPerks = [
  {
    heading: "The best coaches in the world",
    description:
      "Work with the top certified coaches experienced in your industry.",
    vector: vector1,
  },
  {
    heading: "Measurable Impact",
    description:
      "Every coaching program is tracked for ROI based on your organizational goals, with measurable outcomes regularly reviewed.",
    vector: vector2,
  },
  {
    heading: "A legacy of human transformation",
    description:
      "ConnectYou has been partnering with organizations and world class coaches for 45 years",
    vector: vector3,
  },
  {
    heading: "Global Scheduling",
    description:
      "Our coaching network stretches across 6 continents and over 14 languages, making ConnectYou a perfect partner for your company whether you’re a startup or a multinational corporation.",
    vector: vector4,
  },
];
