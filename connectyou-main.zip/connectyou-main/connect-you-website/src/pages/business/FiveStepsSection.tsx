import React from "react";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import { Link, useNavigate } from "react-router-dom";
import XSpace from "../../components/wrappers/XSpace";
import image from "../../assets/backgrounds/5step-section-bg.png";

const FiveStepsSection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className=" relative overflow-hidden w-full h-auto rounded-[20px] bg-[#013338] gap-4 py-18 flex flex-col justify-center items-center  mb-14">
      <div className="absolute w-full h-full z-10 inset-0">
        <img
          src={image}
          alt="bg-image"
          className="w-1/2 h-auto max-w-[200px] md:max-w-1/2  md:w-auto md:h-1/2  object-contain "
        />
      </div>
      <XSpace>
        <div className="z-20 flex flex-col  w-full items-center justify-center h-full gap-12 lg:px-0 px-6 md:px-10 overflow-hidden">
          <p className="flex flex-row flex-wrap justify-center items-center gap-2 uppercase text-[#ebbd33] font-mundial font-bold text-[20px] sm:text-[32px] w-full text-center">
            How we’ll
            <Link to="/" className="flex justify-center items-center">
              Connectyou
            </Link>{" "}
            in 5 simple steps{" "}
          </p>
          <p className="flex flex-col justify-center items-center  text-[white] font-medium gap-3 text-[20px] w-full text-center">
            Scaling Coaching Across Your Organization
          </p>
          <div className="w-full h-full flex-1 grid grid-cols-1 md:grid-cols-2  justify-center items-center gap-6 sm:gap-x-3 sm:gap-y-5">
            {steps.map((step, i) => (
              <div
                key={`steps0-guide-step-${i}`}
                className="flex w-full  border-2 border-transparent hover:border-[#3aa7a3] mx-auto my-6 xl:my-0 flex-col justify-center items-center h-full col-span-1 relative bg-white rounded-[20px] shadow-lg"
                style={{ padding: "16px" }}
              >
                <div className="w-full flex flex-row justify-start items-start py-0.5 font-semibold uppercase font-mundial text-[20px] text-[#3aa7a3]">
                  Step {i + 1}
                </div>
                <div className="flex-1 w-full flex flex-col justify-start items-start  gap-4 py-4">
                  <span className="uppercase w-full flex justify-start items-start text-[24px] font-bold font-mundial text-[#013338] ">
                    {step.heading}
                  </span>
                  <span className="w-full flex justify-start items-start text-[15px] font-medium text-[#013338]">
                    {step.description}
                  </span>
                </div>
              </div>
            ))}
            <div className="flex w-11/12 mx-auto my-6 xl:my-0 flex-col gap-4 justify-center items-start h-full col-span-1 relative  rounded-[20px] shadow-lg">
              <div className="flex flex-col justify-start items-start  text-[white] font-medium gap-3 text-[18px] w-full">
                Your goals are within reach. Let us help you get there. Get in
                touch with us today!
              </div>
              <PrimaryYellowButton
                onClick={() => navigate("/get-in-touch")}
                text="Get in touch"
              />
            </div>
          </div>
        </div>
      </XSpace>
    </div>
  );
};

export default FiveStepsSection;

const steps = [
  {
    heading: " Consultation & Needs Assessment",
    description:
      "We’ll have a conversation to comprehensively understand your goals and challenges.",
  },
  {
    heading: " Custom Program Design",
    description:
      "Our organizational experts will create a tailored coaching solution to align with your business strategy and a list of recommended top coaches for you to work with.",
  },
  {
    heading: " Seamless Implementation",
    description:
      "We’ll take care of all of the details and onboarding to ensure your program runs with minimal disruption.",
  },
  {
    heading: " Measure & Refine",
    description:
      "We’ll work with you to monitor progress with real-time insights and adjust programs as needed.",
  },
  {
    heading: " Experience the Impact",
    description:
      "See and celebrate the tangible impact on your people and your organizational results!",
  },
];
