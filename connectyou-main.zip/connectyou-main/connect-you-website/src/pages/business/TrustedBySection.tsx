import ImageSlideAnimation from "../../components/UI/ImageSlideAnimation";
import logo1 from "../../assets/brands/Rectangle42.png";
import logo2 from "../../assets/brands/Rectangle43.png";
import logo3 from "../../assets/brands/Rectangle44.png";
import logo4 from "../../assets/brands/Rectangle45.png";
import logo5 from "../../assets/brands/Rectangle46.png";
import logo6 from "../../assets/brands/Rectangle47.png";
import logo7 from "../../assets/brands/Rectangle48.png";

const TrustedBySection = () => {
  const newArray = [logo1, logo2, logo3, logo4, logo5, logo6, logo7];

  return (
    <div className=" cursor-pointer  w-full  gap-4 py-6 md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Trusted by leading companies worldwide
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        Join the organizations already benefiting from our world-class coaching
        solutions.
      </p>
      <div className="flex-1 w-full flex flex-row justify-center items-center">
        <ImageSlideAnimation array={newArray} />
      </div>
    </div>
  );
};

export default TrustedBySection;
