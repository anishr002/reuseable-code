import { useNavigate } from "react-router-dom";
import woman from "../../assets/images/business-image-banner.png";
import woman2 from "../../assets/images/business-image-banner-xl.png";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import PageBannerWrapper from "../../components/wrappers/PageBannerWrapper";
import useScreenSize from "../../components/hooks/useScreenSize";

const BusinessPageBanner = () => {
  const navigate = useNavigate();

  const { is1Xl } = useScreenSize();
  return (
    <>
      <PageBannerWrapper
        image={is1Xl ? woman2 : woman}
        leftChild={
          <>
            <p className=" w-full z-20 text-white font-mundial font-bold uppercase text-[24px] md:text-[36px] ">
              Transform your people, <br />
              <span className="text-[#ebbd33]">transform your business</span>
            </p>
            <p className="z-20 font-medium text-white text-[18px] md:text-[26px]   w-full md:w-7/12">
              Unlock your organization’s potential today with tailored coaching
              solutions that drive performance, engagement, and growth.
            </p>
            <div className="z-[20] pt-4 flex justify-center items-center lg:items-start lg:justify-start py-2">
              <PrimaryYellowButton
                onClick={() => navigate("/find-a-coach")}
                text="Find Your Coach"
              />
            </div>
          </>
        }
      />
    </>
  );
};

export default BusinessPageBanner;
