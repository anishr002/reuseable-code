import CustomAccordComponent from "../../components/UI/CustomAccordComponent";
import { coachFaqOptions, FAQs_Type } from "../../Options/Faqs";

const CoachFAQ = () => {
  return (
    <div className="cursor-pointer w-full gap-4 py-6 md:py-12 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        FAQs for Coaches
      </p>

      <div className="grid  grid-cols-1  justify-center items-center gap-6 flex-1">
        {coachFaqOptions.map((faq: FAQs_Type, i: number) => (
          <CustomAccordComponent
            key={`faqq-for-coach-${i}`}
            answer={faq.answer}
            question={faq.question}
          />
        ))}
      </div>
    </div>
  );
};

export default CoachFAQ;
