import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import XSpace from "../../components/wrappers/XSpace";
import Banner from "./Banner";
import CoachFAQ from "./CoachFAQ";
import JoinCard from "./JoinCard";
import KeyBenifitsSection from "./KeyBenifitsSection";
import StepsToJoin from "./StepsToJoin";
import TestimonialsFromCoaches from "./TestimonialsFromCoaches";
import ToolsToSuccess from "./ToolsToSuccess";
import WhySection from "./WhySection";

const BecomeACoach = () => {
  usePageScrollAndTitle({ title: "Coach" });
  return (
    <div className="w-full flex flex-col h-full justify-center items-center bg-white">
      <Banner />
      <XSpace>
        <WhySection />
        <KeyBenifitsSection />
      </XSpace>
      <StepsToJoin />
      <XSpace>
        <TestimonialsFromCoaches />
        <ToolsToSuccess />
        <CoachFAQ />
        <JoinCard />
      </XSpace>
    </div>
  );
};

export default BecomeACoach;
