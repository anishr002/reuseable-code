import globe from "../../assets/icons/globe-with-marker.png";
import people from "../../assets/icons/people-image.png";
import settins from "../../assets/icons/settings-icon.png";

const KeyBenifitsSection = () => {
  return (
    <div className="cursor-pointer w-full gap-4 py-6 md:py-12 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Key Benefits
      </p>

      <div className="grid sm:grid-cols-2 grid-cols-1 md:grid-cols-3 justify-center items-center gap-6 flex-1">
        {options.map((op, i) => (
          <div
            key={`Key-Benefits-section-${i}`}
            className="flex flex-col justify-start items-center gap-5 rounded-[20px] bg-[#013338] text-[1.1rem] md:text-[1.3rem] text-white font-medium p-6 w-full flex-shrink-0 h-full transform transition-transform duration-300 ease-in-out hover:scale-105 hover:bg-[#0a4e53]"
          >
            <p className="text-[#ebbd33] relative">
              <img
                src={op.icon}
                alt="image-icon"
                className="object-contain w-[40px] h-[40px]"
              />
            </p>
            <p className="text-[#ebbd33] text-center uppercase font-lod font-mundial">
              {op.heading}
            </p>
            <p className="text-center font-normal">{op.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default KeyBenifitsSection;

const options = [
  {
    icon: globe,
    heading: "Global Reach",
    description:
      "Gain visibility with clients from over six continents. Expand your practice beyond borders and time zones",
  },
  {
    icon: people,
    heading: "Hassle-Free Coaching",
    description:
      "Let us handle the marketing, client matching and administrative tasks, so you can focus on what matters most—impactful coaching",
  },
  {
    icon: settins,
    heading: "Flexibility & Control",
    description:
      "Set your own schedule, rates, and niche preferences. Work when and how you want.",
  },
];
