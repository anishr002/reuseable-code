import man from "../../assets/images/white-shirt-man-image.png";
import React, { ReactNode } from "react";

const TestimonialsFromCoaches = () => {
  return (
    <div className="cursor-pointer w-full gap-4 py-6 md:py-12 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <div className="flex-1 grid grid-cols-1  md:grid-cols-2 md:w-8/12 w-full gap-4">
        <div className="col-span-1 w-full flex flex-col justify-center items-center gap-5">
          <p className="h-[90px] uppercase text-[#013338] font-bold font-mundial text-[24px] md:text-[36px] w-full text-center">
            Hear from the <br />
            <span className="text-[#3aa7a3]">ConnectYou Coaches</span>
          </p>
          <GrayCard
            author=""
            quote={
              <>
                ConnectYou has{" "}
                <b>revolutionized how I reach clients globally</b>. The platform
                is seamless and supportive!{" "}
              </>
            }
          />
        </div>
        <div className="relative col-span-1 w-full flex flex-col justify-center items-center gap-5 h-full">
          <img
            src={man}
            className="md:absolute inset-0 object-center object-contain w-full h-full"
          />
        </div>
        <div className="relative col-span-1 w-full flex flex-col justify-center items-center gap-5 h-full">
          <GrayCard
            author=" – x., Career Coach "
            quote={
              <>
                " Joining ConnectYou was{" "}
                <b>the best decision for growing my practice.</b> It’s a true
                partnership.”",
              </>
            }
          />
        </div>
        <div className="relative col-span-1 w-full flex flex-col justify-center items-center gap-5 h-full">
          <GrayCard
            author=" – x., Executive Coach "
            quote={
              <>
                "I love that I can <b>focus entirely on coaching</b> while they
                take care of everything else.",
              </>
            }
          />
        </div>
      </div>
    </div>
  );
};

export default TestimonialsFromCoaches;

interface GrayCard {
  quote?: string | ReactNode | undefined;
  author?: string | ReactNode | undefined;
}
const GrayCard: React.FC<GrayCard> = ({ quote, author }) => {
  return (
    <div className="h-[250px] p-6 flex flex-col justify-center items-center gap-7 rounded-[20px] bg-[#f0f0f0] text-[#013338] text-[20px]">
      <div className="text-left w-full ">{quote}</div>
      <p className="text-left w-full ">{author}</p>
    </div>
  );
};
