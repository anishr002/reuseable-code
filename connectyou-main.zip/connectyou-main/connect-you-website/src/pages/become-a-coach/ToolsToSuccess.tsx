import mic from "../../assets/icons/mic-vector-icon.png";
import calendar from "../../assets/icons/calendar-vector-icon.png";
import lock from "../../assets/icons/lock-vector-icon.png";

const ToolsToSuccess = () => {
  return (
    <div className="cursor-pointer w-full gap-8 py-6  flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Tools to help you <span className="text-[#3aa7a3]">succeed</span>
      </p>

      <div className="grid sm:grid-cols-2 grid-cols-1 md:grid-cols-3 justify-center items-center gap-6 flex-1">
        {options.map((op, i) => (
          <div
            key={`Key-Benefits-section-${i}`}
            className="flex py-8 flex-col justify-start items-center gap-5 rounded-[20px] bg-[#3aa7a3] text-[1.1rem] md:text-[1.3rem] text-white font-medium p-6 w-full flex-shrink-0 h-full transform transition-transform duration-300 ease-in-out hover:scale-105 "
          >
            <div className="flex justify-center items-center text-[white] bg-white relative w-[55px] h-[55px] rounded-full">
              <img
                src={op.icon}
                alt="image-icon"
                className="object-contain w-9/12 h-9/12 p-1"
              />
            </div>
            <p className="text-[white] text-center">{op.heading}</p>
            <p className="text-center">{op.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToolsToSuccess;

const options = [
  {
    icon: mic,
    heading: "Enhanced Visibility",
    description:
      "We market your services to a global audience, bringing clients directly to you",
  },
  {
    icon: calendar,
    heading: "Streamlined Scheduling",
    description: "Setup your calendar and manage bookings with ease",
  },
  {
    icon: lock,
    heading: "Secure Payment Processing",
    description: "Automated payments ensure you’re paid on time, every time",
  },
];
