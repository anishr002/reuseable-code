import logo from "../../assets/website-logos/connect-you-logo.png";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import XSpace from "../../components/wrappers/XSpace";
import { Link, useNavigate } from "react-router-dom";
import image1 from "../../assets/images/become-a-coach-image-1.png";
import image2 from "../../assets/images/become-a-coach-image-2.png";
import image3 from "../../assets/images/become-a-coach-image-3.png";
import StepsCardVertical from "../../components/UI/StepsCardVertical";
import React from "react";

const StepsToJoin = () => {
  const navigate = useNavigate();

  return (
    <div className="w-full h-auto rounded-[20px] bg-[#013338] gap-4 py-18 flex flex-col justify-center items-center relative mb-14">
      <XSpace>
        <div className="flex flex-col xl:min-h-[650px] w-full items-center justify-center h-full gap-12 lg:px-0 px-6 md:px-10 overflow-hidden">
          <p className="flex flex-row flex-wrap justify-center items-center gap-2 uppercase text-[white] font-semibold text-[20px] sm:text-[24px] w-full text-center">
            How to join
            <Link to="/" className="flex justify-center items-center">
              <img
                src={logo}
                alt="brand-logo"
                className="object-contain h-[18px] sm:h-[20px] inline-block"
              />
            </Link>
          </p>

          <div className="w-full h-full flex-1 grid grid-cols-1 sm:grid-cols-12 lg:grid-cols-12 justify-center items-center gap-6 lg:gap-2">
            {steps.map((step, i) => (
              <React.Fragment key={`Join-guide-step-${i}`}>
                <StepsCardVertical
                  stepTitle={
                    <div className="absolute z-20 top-0 -translate-y-1/2 left-1/2 -translate-x-1/2 bg-[#3aa7a3] rounded-[20px] text-[white] w-[100px] flex flex-row justify-center items-center py-0.5 font-semibold text-[20px]">
                      Step {i + 1}
                    </div>
                  }
                  step={step}
                  description={
                    <>
                      <p
                        className={`uppercase w-full flex justify-center items-center text-[20px] font-mundial font-bold text-[#013338]`}
                      >
                        {step.heading}
                      </p>
                      <p className="w-full flex justify-center items-center text-[15px] font-medium text-[#013338]">
                        {step.description}
                      </p>
                    </>
                  }
                />
              </React.Fragment>
            ))}
          </div>

          <div className="flex flex-col justify-center items-center  text-[white] font-medium gap-3 text-[20px] w-full text-center">
            It’s that simple! Let’s get started.
            <PrimaryYellowButton
              onClick={() => navigate("/signup-coach")}
              text="Apply Today"
            />
          </div>
        </div>
      </XSpace>
    </div>
  );
};

export default StepsToJoin;

const steps = [
  {
    heading: "Apply",
    description:
      "Submit your application with your certifications, experience, and a short bio.",
    image: image1,
  },
  {
    heading: "Get Reviewed",
    description:
      "Our team carefully evaluates every application to ensure quality and alignment with our values.",
    image: image2,
  },
  {
    heading: "Start Coaching",
    description:
      "Once approved, set up your schedule and rates and begin connecting with clients worldwide.",
    image: image3,
  },
];
