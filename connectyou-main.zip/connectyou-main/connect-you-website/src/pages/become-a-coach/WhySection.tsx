const WhySection = () => {
  return (
    <div className=" cursor-pointer  w-full  gap-4 py-10 md:py-12 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Why partner with ConnectYou?
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        At ConnectYou, we believe in empowering coaches to focus on what they do
        best: transforming lives. Partnering with us means joining a community
        dedicated to helping clients achieve their dreams while supporting you
        with the tools, resources, and opportunities you need to thrive.
      </p>
    </div>
  );
};

export default WhySection;
