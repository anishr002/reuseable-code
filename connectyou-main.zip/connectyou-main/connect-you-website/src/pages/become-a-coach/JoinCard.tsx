import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import image1 from "../../assets/images/woman-in-blue-coat.png";
import image2 from "../../assets/images/background-join-card-.png";
import { useNavigate } from "react-router-dom";

const JoinCard = () => {
  const navigate = useNavigate();
  return (
    <>
      <div className="w-full h-full flex justify-center items-center py-4">
        <div className="  w-full lg:min-h-[400px] gap-6 py-12  md:py-4 flex flex-col justify-center items-center relative mb-14 rounded-[20px] bg-linear-to-r from-[#006771] to-[#013338] overflow-hidden">
          <img
            src={image1}
            alt="bg-image"
            className="ps-10 md:block hidden absolute object-contain h-full inset-0 z-10"
          />
          <div className="md:w-7/12  flex flex-col justify-center items-center gap-4 z-20">
            <p className="uppercase text-[white] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center">
              Are you ready to join <br />
              <span className="text-[#ebbd33]">
                {" "}
                the ConnectYou <br /> coaching network?{" "}
              </span>
            </p>
            <p className="text-[white] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
              Let’s connect you with clients and help you make a greater impact
              through coaching.
            </p>
            <div className="w-full flex justify-center items-center">
              <PrimaryYellowButton
                onClick={() => navigate("/signup-coach")}
                text="Apply now"
              />
            </div>
          </div>
          <img
            src={image2}
            alt="bg-image"
            className=" absolute object-contain h-full inset-y-0 right-0 z-10"
          />
        </div>
      </div>
    </>
  );
};

export default JoinCard;
