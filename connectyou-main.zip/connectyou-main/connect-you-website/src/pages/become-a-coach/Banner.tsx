import { useNavigate } from "react-router-dom";
import image from "../../assets/images/become-a-coach-page-image-banner.png";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import PageBannerWrapper from "../../components/wrappers/PageBannerWrapper";

const Banner = () => {
  const navigate = useNavigate();
  return (
    <>
      <PageBannerWrapper
        image={image}
        leftChild={
          <>
            <p className="z-20 text-white font-mundial font-bold uppercase text-[24px] md:text-[36px] text-center md:text-left w-full">
              <span className="text-[#ebbd33]">Become a coach</span>
              <br />
              on ConnectYou
            </p>
            <p className="z-20 font-medium text-white text-[18px] md:text-[26px] text-center md:text-left  w-full md:w-10/12">
              Join our network of world-class coaches and connect with
              individuals and organizations ready for transformation.
            </p>
            <div className="z-[20] w-full flex justify-center items-center md:items-start md:justify-start py-2">
              <PrimaryYellowButton
                onClick={() => navigate("/signup-coach")}
                text="Apply Now"
              />
            </div>
          </>
        }
      />
    </>
  );
};

export default Banner;
