/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useRef, useState } from "react";
import bg from "../../assets/backgrounds/logo-background-deep-sea.png";
import WebsitelogoLink from "../../components/UI/WebsitelogoLink";
import { TabHeader } from "../login/Login";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import { useLocation, useNavigate } from "react-router-dom";
import { httpAPI } from "../../util/AxiosAPI";
import backendURL from "../../util/baseBackendURLConfig";
import OTPInput from "../../components/UI/OTPInput";
import { updateHubSpotInfo } from "../../lib/hubspot";
import { login } from "../../slices/Login";
import { useDispatch } from "react-redux";
import useDetectRedirection from "../../components/hooks/useDetectRedirection";
import ResendOTP from "../../components/utility/ResendOTP";
import customAlert from "../../lib/swalExtentions";

interface User {
  email: string;
  password: string;
  userType: "coach" | "coachee";
}
const AccountVerification: React.FC = () => {
  const location = useLocation();
  const [activeStep, setActiveStep] = useState<number>(0);
  const [error, setError] = useState<string | undefined>(undefined);
  const handleChangeActiveStep = (step: number) => {
    setActiveStep(step);
  };
  const [loading, setLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string | undefined>(undefined);
  const dispatch = useDispatch();
  const handleloading = (b: boolean) => {
    setError(undefined);
    setLoading(b);
  };
  const navigate = useNavigate();
  //user data for later use
  const [user, setUser] = useState<User | null>(null);
  const { detectReqestedRedirection } = useDetectRedirection();
  useEffect(() => {
    // console.log({ location });
    if (location?.state) {
      setUser(location?.state?.user);
    }
    if (location?.state?.message) {
      setMessage(location?.state?.message);
    }
  }, [location]);

  const requestOTP = async (email: string, allowStepChange: boolean = true) => {
    try {
      const response = await httpAPI.post(
        `${backendURL}/api-v2/public/validate/get-email-verification-otp`,
        {
          email: email,
        }
      );
      if (response.status === 200) {
        if (allowStepChange) {
          handleChangeActiveStep(1);
        }
      }
      if (response.status === 404) {
        setError(
          response?.data?.message || "Something went wrong, Please try again"
        );
        customAlert.fire({
          title: "Something Went wrong !",
          showConfirmButton: true,
          text:
            response?.data?.message || "Something went wrong, Please try again",
        });
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.log(error);
      setError(
        error?.response?.data?.message ||
          "Something went wrong, Please try again"
      );
      customAlert.fire({
        title: "Something Went wrong !",
        showConfirmButton: true,
        text:
          error?.response?.data?.message ||
          "Something went wrong, Please try again.",
      });
    } finally {
      handleloading(false);
    }
  };

  return (
    <React.Fragment>
      <div className="w-full  overflow-hidden relative bg-[#013338] xl:py-3 h-screen">
        {/* Background image */}
        <div className="w-fit h-fit absolute md:-top-[20%] md:-right-[8%] pointer-events-none z-10 overflow-hidden flex justify-center items-center">
          <img
            src={bg}
            alt="background"
            className="object-cover w-full h-full transform -rotate-1 md:scale-[1.09]"
          />
        </div>
        {/* Main content */}
        <div className="relative z-20 w-full h-full flex flex-col md:justify-center gap-10">
          {/* Header logo */}
          <WebsitelogoLink />

          {/* Scrollable content section */}
          <div
            id="login-scrollabel-content"
            className="flex w-11/12 mx-auto  max-h-[400px] lg:max-h-[fit-content] md:w-[680px]  justify-center items-start flex-grow overflow-y-auto  py-6 gap-4 bg-[#FFFFFF] rounded-[20px] style-scroll"
          >
            <div className=" min-h-fit flex w-full  justify-center items-center ">
              <div className="flex flex-col justify-center items-center xl:py-2 px-3 w-11/12 md:w-8/12">
                {activeStep === 0 && user?.email && (
                  <>
                    <AccountVerificationStepOne
                      handleNextClick={async () => {
                        handleloading(true);
                        requestOTP(user.email, true);
                      }}
                      loading={loading}
                      email={user.email}
                      message={message}
                    />
                  </>
                )}
                {activeStep === 1 && user?.email && (
                  <>
                    <AccountVerificationStepTwo
                      handleNextClick={() => handleChangeActiveStep(2)}
                      email={user.email}
                      resendOTP={() => {
                        handleloading(true);
                        requestOTP(user.email, false);
                      }}
                      loading={loading}
                    />
                  </>
                )}
                {activeStep === 2 && user?.email && (
                  <>
                    <AccountVerificationStepThree
                      handleNextClick={async (otp: string) => {
                        handleloading(true);
                        try {
                          const response = await httpAPI.post(
                            `${backendURL}/api-v2/public/validate/verify-email-verification-otp`,
                            {
                              email: user.email,
                              receivedOTP: otp,
                            }
                          );
                          if (response.status === 200) {
                            handleChangeActiveStep(3);
                          }
                        } catch (error: any) {
                          console.log(error);
                          setError(
                            error?.response?.data?.message ||
                              "Something went wrong, Please try again."
                          );
                          customAlert.fire({
                            title: "Something Went wrong !",
                            showConfirmButton: true,
                            text:
                              error?.response?.data?.message ||
                              "Something went wrong, Please try again.",
                          });
                        } finally {
                          handleloading(false);
                        }
                      }}
                      email={user.email}
                      loading={loading}
                      resendOTP={() => requestOTP(user.email, false)}
                    />
                  </>
                )}
                {activeStep === 3 && user?.email && (
                  <>
                    <AccountVerificationStepFour
                      loading={loading}
                      handleNextClick={async () => {
                        handleloading(true);
                        const data = {
                          email: user.email,
                          password: user.password,
                          location: "",
                        };
                        try {
                          const response = await httpAPI.post(
                            `${backendURL}/${
                              user.userType === "coach" ? "coach" : "user"
                            }/authentication/login`,
                            data
                          );
                          // console.log(response, data);
                          if (response.status === 200) {
                            // ReactGA.event({ category: "category", action: "login", label: "user" });
                            const authToken = response.data.data.token;
                            localStorage.setItem("authToken", authToken);
                            const loginUserData = JSON.parse(
                              atob(authToken.split(".")[1])
                            ); //store the login user data
                            detectReqestedRedirection(() => {
                              navigate(
                                `/${
                                  user.userType === "coach" ? "c" : "u"
                                }/profile`
                              );
                            }, true);
                            dispatch(login(loginUserData));
                            setError(undefined);
                            updateHubSpotInfo({ userType: "coach" });
                            return handleloading(false);
                          }
                        } catch (error: any) {
                          console.log(error);
                          navigate(`/login`, {
                            state: {
                              userType: user.userType,
                              email: user.email,
                              password: user.password,
                            },
                          });
                          setError(
                            error?.response?.data?.message ||
                              "Something went wrong, Please try again."
                          );
                          customAlert.fire({
                            title: "Something Went wrong !",
                            showConfirmButton: true,
                            text:
                              error?.response?.data?.message ||
                              "Something went wrong, Please try again.",
                          });
                          return handleloading(false);
                        } finally {
                          handleloading(false);
                        }
                      }}
                      email={user.email}
                    />
                  </>
                )}
                {error && (
                  <span className="text-xs pt-6 pb-10 font-medium text-red-600">
                    {error}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default AccountVerification;

interface AccountVerificationStepOneProps {
  handleNextClick: () => void;
  message?: string;
  email: string;
  loading: boolean;
  resendOTP?: () => void;
}

const AccountVerificationStepOne: React.FC<AccountVerificationStepOneProps> = ({
  handleNextClick,
  message = "To secure your account and access all features, please verify your email address. Click the GET OTP button below to receive an OTP for account verification.",
  email,
  loading,
}) => {
  return (
    <>
      <div className="w-full h-fit gap-3 flex flex-col justify-start items-start">
        <div className="flex flex-col w-full justify-center items-center gap-4">
          <div className="py-1 px-2 text-center">
            <TabHeader title="Account Verification Required" />
            <p className="py-3 px-2 text-[#013338] font-medium">{message}</p>
            <p className="py-2 px-2 text-[#3aa7a3] text-lg font-semibold font-mundial ">
              {`${email.slice(0, 2).padEnd(6, "*")}@${email.split("@")[1]}`}
            </p>
          </div>
        </div>
        <div className="pb-1.5 pt-4 flex flex-col justify-center items-center w-full">
          <PrimaryYellowButton
            loading={loading}
            text="Get OTP"
            type="button"
            onClick={() => handleNextClick()}
          />
        </div>
      </div>
    </>
  );
};
const AccountVerificationStepTwo: React.FC<
  Pick<
    AccountVerificationStepOneProps,
    "handleNextClick" | "email" | "resendOTP" | "loading"
  >
> = ({ handleNextClick, email, resendOTP, loading }) => {
  const renderRef = useRef<{ onClickResend: () => void }>(null);

  return (
    <>
      <div className="w-full h-fit gap-3 flex flex-col justify-start items-start">
        <div className="flex flex-col w-full justify-center items-center gap-4">
          <div className="py-1 px-2 text-center">
            <TabHeader title="Account Verification Required" />
            <p className="py-3 px-2 text-[#013338] font-medium">
              OTP sent successfully.
            </p>
            <p className="py-2 px-2 text-[#013338] font-medium">
              An OTP was sent successfully on your registered email address.
              This OTP is only valid for next 15 minutes.
            </p>
            <p className="py-2 px-2 text-[#3aa7a3] text-lg font-semibold font-mundial ">
              {`${email.slice(0, 2).padEnd(6, "*")}@${email.split("@")[1]}`}
            </p>
            <div className="pb-0.5 text-xs   text-[red] font-semibold font-mundial">
              <ResendOTP
                ref={renderRef}
                localStorageKey={`account-verification-${email}`}
                loading={loading}
              >
                <button
                  type="button"
                  // disabled={!renderRef?.current}
                  className="inline-flex  hover:underline text-[#3aa7a3]"
                  onClick={() => {
                    resendOTP?.();
                    renderRef?.current?.onClickResend?.();
                  }}
                >
                  Resend OTP
                </button>
              </ResendOTP>
            </div>
          </div>
        </div>
        <div className="pb-1.5 pt-4 flex flex-col justify-center items-center w-full">
          <PrimaryYellowButton
            loading={loading}
            text="Enter OTP"
            type="button"
            onClick={() => handleNextClick()}
          />
        </div>
      </div>
    </>
  );
};

const AccountVerificationStepThree: React.FC<{
  handleNextClick: (otp: string) => void;
  message?: string;
  email: string;
  loading: boolean;
  resendOTP?: () => void;
}> = ({
  handleNextClick,
  message = "Please enter the 5-digit OTP that you have received on the reigstered email address.",
  email,
  loading,
  resendOTP,
}) => {
  const [OTP, setOtp] = useState<string | null>(null);
  const renderRef = useRef<{ onClickResend: () => void }>(null);

  return (
    <>
      <div className="w-full h-fit gap-3 flex flex-col justify-start items-start">
        <div className="flex flex-col w-full justify-center items-center gap-4">
          <div className="py-1 px-2 text-center">
            <TabHeader title="Account Verification Required" />
            <p className="py-3 px-2 text-[#013338] font-medium">{message}</p>
            <p className="py-2 px-2 text-[#3aa7a3] text-lg font-semibold font-mundial ">
              {`${email.slice(0, 2).padEnd(6, "*")}@${email.split("@")[1]}`}
            </p>
            <div className="pb-0.5 text-xs   text-[red] font-semibold font-mundial">
              <ResendOTP
                ref={renderRef}
                localStorageKey={`account-verification-${email}`}
              >
                <button
                  type="button"
                  disabled={!renderRef?.current}
                  className="inline-flex  hover:underline text-[#3aa7a3]"
                  onClick={() => {
                    resendOTP?.();
                    renderRef?.current?.onClickResend?.();
                  }}
                >
                  Resend OTP
                </button>
              </ResendOTP>
            </div>
            <p className="py-4 px-2 text-[#3aa7a3] text-lg font-semibold font-mundial ">
              <OTPInput handleOtp={(otp) => setOtp(otp)} />
            </p>
          </div>
        </div>
        <div className="pb-1.5 pt-4 flex flex-col justify-center items-center w-full">
          <PrimaryYellowButton
            loading={loading}
            text="Submit OTP"
            type="button"
            disabled={!OTP || OTP.length !== 5}
            onClick={() => {
              if (OTP) {
                handleNextClick(OTP);
              }
            }}
          />
        </div>
      </div>
    </>
  );
};

const AccountVerificationStepFour: React.FC<
  Pick<AccountVerificationStepOneProps, "handleNextClick" | "email" | "loading">
> = ({ handleNextClick, email, loading }) => {
  return (
    <>
      <div className="w-full h-fit gap-3 flex flex-col justify-start items-start">
        <div className="flex flex-col w-full justify-center items-center gap-4">
          <div className="py-1 px-2 text-center">
            <TabHeader title="Account Verification Completed" />
            <p className="py-3 px-2 text-[#013338] font-medium">
              Congratulations, Your account has been verified successfully
            </p>
            <p className="py-2 px-2 text-[#013338] font-medium">
              You can sign in to your account with your registered email address{" "}
              {`${email.slice(0, 2).padEnd(6, "*")}@${email.split("@")[1]}`}.
            </p>
            <p className="py-2 px-2 text-[#013338] font-medium">Greretings !</p>
          </div>
        </div>
        <div className="pb-1.5 pt-4 flex flex-col justify-center items-center w-full">
          <PrimaryYellowButton
            text="Login"
            type="button"
            loading={loading}
            onClick={() => handleNextClick()}
          />
        </div>
      </div>
    </>
  );
};
