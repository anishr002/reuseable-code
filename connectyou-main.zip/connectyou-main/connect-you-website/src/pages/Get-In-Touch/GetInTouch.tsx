/* eslint-disable @typescript-eslint/no-explicit-any */
import SentimentDissatisfiedIcon from "@mui/icons-material/SentimentDissatisfied";
import SentimentSatisfiedAltIcon from "@mui/icons-material/SentimentSatisfiedAlt";
import MailOutlineIcon from "@mui/icons-material/MailOutline";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import PlaceIcon from "@mui/icons-material/Place";
import facebookIcon from "../../assets/socialIcon-white/facebook.png";
import twitterXIcon from "../../assets/socialIcon-white/twiterx.png";
import InstagramIcon from "../../assets/socialIcon-white/insta.png";
import LinkedInIcon from "../../assets/socialIcon-white/linkedin.png";
import PinterestIcon from "../../assets/socialIcon-white/pintrest.png";
import YouTubeIcon from "../../assets/socialIcon-white/youtube.png";
import { useForm } from "react-hook-form";
import React, { useEffect, useState } from "react";
import { CircularProgress, TextField } from "@mui/material";

import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import { useNotify } from "../../lib/Notify";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import Community from "../../components/UI/Community";
import XSpace from "../../components/wrappers/XSpace";
const ContactUsData = () => {
  const { notifyMe } = useNotify();

  const [loading, setLoading] = React.useState(false); //loading behaviour on form submit
  type FormValues = {
    fullName: string;
    email: string;
    subject: string;
    message: string;
  };
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormValues>({ mode: "onChange" });
  const [formState, setFormState] = useState<
    "initial" | "loading" | "success" | "error"
  >("initial");
  const [data, setData] = useState<FormValues | null>(null);
  const onSubmitUser = handleSubmit(async (data) => {
    setLoading(true);
    setFormState("loading");
    // console.log(data);
    setData(data);
    try {
      const response = await httpAPI.post(
        `${backendURL}/admin/contact/new-contact-us`,
        { ...data }
      );
      if (response.status === 200) {
        notifyMe({
          message: "Contact form submitted successfully.",
          severity: "success",
        });
        reset();
        setFormState("success");
        return setLoading(false);
      } else {
        setFormState("error");
        return notifyMe({
          message: "Some error occurred, Please try again.",
          severity: "error",
        });
      }
    } catch (error: any) {
      console.log(error);
      notifyMe({ message: "Something went wrong", severity: "error" });
      setFormState("error");
      return setLoading(false);
    } finally {
      setLoading(false);
    }
  });

  useEffect(() => {
    const timer = setTimeout(() => setFormState("initial"), 1000 * 60 * 5);
    return () => clearTimeout(timer);
  }, [formState]);

  usePageScrollAndTitle({
    title: `Contact - Connect You`,
  });

  return (
    <div className="py-10 flex flex-row justify-center items-center">
      <XSpace>
        <>
          <div className="w-full grid grid-cols-1 md:grid-cols-2  h-full min-h-[50vh] justify-center items-center bg-white">
            <div className="flex w-full col-span-1  bg-radial from-[#0c818b] to-[#013338] text-white flex-col gap-12 px-5 lg:px-20 py-20">
              <div className="flex text-white flex-col gap-5">
                <h1 className="font-semibold text-4xl">Have Question?</h1>
                <p>
                  Learn about how Connect-You, that can transform your coaching
                  practice.
                </p>
              </div>
              <div className="flex">
                <div className="flex items-center gap-1">
                  <MailOutlineIcon
                    sx={{ fontSize: "1.5rem", lineHeight: "1.25rem" }}
                  />
                  <p className="flex text-sm">support@connectyou.com</p>
                </div>
              </div>
              <div className="flex">
                <LocalPhoneIcon
                  sx={{ fontSize: "1.5rem", lineHeight: "1.25rem" }}
                />
                <p className="flex text-sm">+1-877-435-1455</p>
              </div>
              <div className="flex">
                <PlaceIcon sx={{ fontSize: "1.5rem", lineHeight: "1.25rem" }} />
                <p className="flex text-sm">
                  408 - 55 Water Street, Office# 8871, Vancouver, BC, Canada,
                  British Columbia
                </p>
              </div>
              <div className="flex gap-3 w-full">
                <a
                  target="_blank"
                  href="https://www.facebook.com/EricksonCoachingInternational"
                  className="cursor-pointer"
                >
                  <img
                    src={facebookIcon}
                    className="w-4 h-4"
                    alt="facebookIcon"
                  />
                </a>
                <a
                  target="_blank"
                  href="https://twitter.com/EricksonCoaches"
                  className="cursor-pointer"
                >
                  <img
                    src={twitterXIcon}
                    className="w-4 h-4"
                    alt="twitterXIcon"
                  />
                </a>
                <a
                  target="_blank"
                  href="http://instagram.com/ericksoncoaching"
                  className="cursor-pointer"
                >
                  <img
                    src={InstagramIcon}
                    className="w-4 h-4"
                    alt="InstagramIcon"
                  />
                </a>
                <a
                  target="_blank"
                  href="https://www.linkedin.com/company/erickson-coaching-international"
                  className="cursor-pointer"
                >
                  <img
                    src={LinkedInIcon}
                    className="w-4 h-4"
                    alt="LinkedInIcon"
                  />
                </a>
                <a
                  target="_blank"
                  href="http://pinterest.com/ericksoncoaching"
                  className="cursor-pointer"
                >
                  <img
                    src={PinterestIcon}
                    className="w-4 h-4"
                    alt="PinterestIcon"
                  />
                </a>
                <a
                  target="_blank"
                  href="https://www.youtube.com/user/ericksonvideo"
                  className="cursor-pointer"
                >
                  <img
                    src={YouTubeIcon}
                    className="w-5 h-5"
                    alt="YouTubeIcon"
                  />
                </a>
              </div>
            </div>
            <div className="flex w-full col-span-1 justify-center px-3">
              <form
                onSubmit={onSubmitUser}
                className="w-full md:w-11/12 lg:w-3/5"
              >
                {formState === "initial" && (
                  <div className="w-full">
                    <div className="pt-4">
                      <TextField
                        id="outlined-required"
                        label="Full Name"
                        fullWidth
                        {...register("fullName", {
                          required: "Please enter fullName",
                          minLength: {
                            value: 4,
                            message: "Full name must have atleast 4 characters",
                          },
                          maxLength: {
                            value: 15,
                            message: "The fullName cannot exceed 15 characters",
                          },
                        })}
                        error={!!errors.fullName}
                        helperText={errors.fullName?.message}
                        FormHelperTextProps={{
                          style: {
                            marginLeft: 0,
                          },
                        }}
                      />
                    </div>
                    <div className="pt-4">
                      <TextField
                        id="outlined-required"
                        label="Email"
                        fullWidth
                        {...register("email", {
                          required: "Please enter email",
                          pattern: {
                            value:
                              /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                            message: "Please enter valid email address",
                          },
                        })}
                        error={!!errors.email}
                        helperText={errors.email?.message}
                        FormHelperTextProps={{
                          style: {
                            marginLeft: 0,
                          },
                        }}
                      />
                    </div>
                    <div className="pt-4">
                      <TextField
                        id="outlined-required"
                        label="Subject"
                        fullWidth
                        {...register("subject", {
                          required: "Subject is a required field",
                          minLength: {
                            value: 4,
                            message: "Subject must have atleast 4 characters",
                          },
                          maxLength: {
                            value: 150,
                            message: "Subject cannot exceed 150 characters",
                          },
                        })}
                        error={!!errors.subject}
                        helperText={errors.subject?.message}
                        FormHelperTextProps={{
                          style: {
                            marginLeft: 0,
                          },
                        }}
                      />
                    </div>
                    <div className="pt-4">
                      <TextField
                        id="outlined-textarea"
                        label="Message"
                        fullWidth
                        multiline
                        minRows={4}
                        {...register("message", {
                          required: "Please enter a message",
                          minLength: {
                            value: 4,
                            message:
                              "Message field must have atleast 4 characters",
                          },
                          maxLength: {
                            value: 500,
                            message:
                              "Message field cannot exceed 500 characters",
                          },
                        })}
                        error={!!errors.message}
                        helperText={errors.message?.message}
                        FormHelperTextProps={{
                          style: {
                            marginLeft: 0,
                          },
                        }}
                      />
                    </div>
                    <div className="pb-1.5 pt-4">
                      <button
                        type="submit"
                        className="flex w-full justify-center rounded-md custom-bg px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm focus-visible:outline focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                      >
                        {loading ? (
                          <CircularProgress size={24} color="inherit" />
                        ) : (
                          "Send"
                        )}
                      </button>
                    </div>
                  </div>
                )}
                {formState === "loading" && (
                  <>
                    <div className="flex w-full h-full flex-col gap-3 justify-center items-center py-5">
                      <CircularProgress size={32} sx={{ color: "#013338" }} />
                      <div className="text-base font-semibold text-[#013338]">
                        Your form is being submitted, Please wait ....
                      </div>
                    </div>
                  </>
                )}
                {formState === "success" && (
                  <>
                    <div className="flex w-full h-full flex-col gap-4 justify-center items-center py-5">
                      <div className="text-base font-semibold text-[#013338]">
                        <SentimentSatisfiedAltIcon
                          color="inherit"
                          sx={{ fontSize: "4rem" }}
                        />
                      </div>
                      <div className="text-base text-center font-semibold text-[#013338]">
                        Dear, {data?.fullName}, your enquiry has been submitted
                        successfully, our team will get back to you shortly.
                      </div>
                      <p className="text-base font-semibold text-[#013338]">
                        Thank you !!
                      </p>
                      <div className=" flex flex-col items-center justify-center gap-5 text-base font-semibold text-[#013338]">
                        Register with Connect You{"? "}
                        <div className="flex flex-col md:flex-row gap-5">
                          <a href="/signup-coach" className="text-blue-600">
                            {" "}
                            Sign Up as a Coach ?
                          </a>

                          <a href="/signup-coachee" className="text-blue-600">
                            {" "}
                            Sign Up as a User ?
                          </a>
                        </div>
                      </div>
                    </div>
                  </>
                )}
                {formState === "error" && (
                  <>
                    <div className="flex w-full h-full flex-col gap-4 justify-center items-center py-5">
                      <div className="text-base font-semibold text-[#013338]">
                        <div className="text-red-600 relative">
                          <SentimentDissatisfiedIcon
                            color="inherit"
                            sx={{ fontSize: "4rem" }}
                          />
                          <div className="absolute right-0 top-0 text-base">
                            {" "}
                            !
                          </div>
                        </div>
                      </div>
                      <div className="text-base text-center font-semibold text-[#013338]">
                        Dear, {data?.fullName},There was some network error
                        while submitting your request, Please try again later.
                      </div>
                      <p className="text-base font-semibold text-[#013338]">
                        Thank you for your patience !!
                      </p>
                      <div className=" flex flex-col items-center justify-center gap-5 text-base font-semibold text-[#013338]">
                        Register with Connect You{"? "}
                        <div className="flex flex-col md:flex-row gap-5">
                          <a href="/signup-coach" className="text-blue-600">
                            {" "}
                            Sign Up as a Coach ?
                          </a>

                          <a href="/signup-coachee" className="text-blue-600">
                            {" "}
                            Sign Up as a User ?
                          </a>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </form>
            </div>
          </div>
        </>
      </XSpace>
    </div>
  );
};

const GetInTouch = () => {
  return (
    <>
      <ContactUsData />
      <Community />
    </>
  );
};

export default GetInTouch;
