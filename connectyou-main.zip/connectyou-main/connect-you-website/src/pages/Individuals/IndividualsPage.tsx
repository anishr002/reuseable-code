import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import XSpace from "../../components/wrappers/XSpace";
import ExploreCoaching from "../home/ExploreCoaching";
import LetsConnectSection from "../home/LetsConnectSection";
import StepsToConnect from "../home/StepsToConnect";
import IndividualPageBanner from "./IndividualPageBanner";
import TransformationStoriesSection from "./TransformationStoriesSection";
import WhyChooseConnectYou from "./WhyChooseConnectYou";
import WhyCoachSection from "./WhyCoachSection";

const IndividualsPage = () => {
  usePageScrollAndTitle({ title: "Individuals" });
  return (
    <>
      <div className="w-full flex flex-col h-full justify-center items-center bg-white">
        <IndividualPageBanner />
        <XSpace>
          <WhyCoachSection />
        </XSpace>
        <StepsToConnect />
        <XSpace>
          <ExploreCoaching />
          <WhyChooseConnectYou />
          <TransformationStoriesSection />
          <LetsConnectSection />
        </XSpace>
      </div>
    </>
  );
};

export default IndividualsPage;
