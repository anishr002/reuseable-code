import { useNavigate } from "react-router-dom";
import image from "../../assets/images/individual-page-banner-image.png";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import PageBannerWrapper from "../../components/wrappers/PageBannerWrapper";

const IndividualPageBanner = () => {
  const navigate = useNavigate();
  return (
    <>
      <PageBannerWrapper
        image={image}
        leftChild={
          <>
            <p className=" w-full z-20 text-white font-mundial font-bold uppercase text-[24px] md:text-[36px] ">
              Your journey starts
              <span className="text-[#ebbd33]"> here </span>
            </p>
            <p className="z-20 font-medium text-white text-[18px] md:text-[26px] w-full ">
              Transform your goals into achievements with expert coaching.
            </p>
            <div className="z-[20] pt-4 flex justify-center items-center lg:items-start lg:justify-start py-2">
              <PrimaryYellowButton
                onClick={() => navigate("/find-a-coach")}
                text="Find Your Coach"
              />
            </div>
          </>
        }
      />
    </>
  );
};

export default IndividualPageBanner;
