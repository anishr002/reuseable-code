import React, { JSX } from "react";
import icon1 from "../../assets/icons/why-cy-vertor-1.png";
import icon2 from "../../assets/icons/why-cy-vertor-2.png";
import icon3 from "../../assets/icons/why-cy-vertor-3.png";
import icon4 from "../../assets/icons/why-cy-vertor-4.png";
import { Link } from "react-router-dom";

const WhyChooseConnectYou = () => {
  return (
    <div className=" cursor-pointer  w-full gap-4 py-6 md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Why Choose
        <Link className="hover:underline px-1 text-[#ebbd33] " to="/">
          connectyou
        </Link>
        ?
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        Coaching made easy, flexible, and accessible.
      </p>

      <div className="gap-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 w-full h-fit flex-1 my-10">
        {Arr.map((a, index) => {
          return (
            <React.Fragment key={`why-choose-connect-you-card-${index}`}>
              <Card icon={a.icon} text={a.head} />
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default WhyChooseConnectYou;

const Card = ({ text, icon }: { text: JSX.Element; icon: string }) => {
  return (
    <div className="col-span-1 why-cy-card  w-full h-full min-h-[125px] flex justify-center items-center bg-[#f0f0f0] rounded-[10px] px-6 py-10 md:px-8 md:py-2">
      <div className=" flex flex-col md:flex-row gap-4 items-center justify-center text-[#013338] w-full">
        {/* Icon Container */}
        <div className="flex icon justify-center items-center mr-3 min-w-10 min-h-10 max-w-10 max-h-10">
          <img
            src={icon}
            alt="icon"
            className="object-contain  h-full "
            style={{ minWidth: "30px", minHeight: "30px" }} // Ensure equal size
          />
        </div>

        {/* Text */}
        <div className="text-[#013338] text-left text-[16px] md:text-[18px] font-medium">
          {text}
        </div>
      </div>
    </div>
  );
};

const Arr = [
  {
    head: (
      <p className="text-[#013338]">
        <b>Skilled coaches</b> specializing in everything from leadership to
        wellness.
      </p>
    ),
    icon: icon1,
  },
  {
    head: (
      <p className="text-[#013338]">
        Filter by price range to ensure that your investment in yourself{" "}
        <b>fits your budget</b>.
      </p>
    ),
    icon: icon2,
  },
  {
    head: (
      <p className="text-[#013338]">
        <b> Coaches from over 6 continents</b> available in time zones to suit
        you.
      </p>
    ),
    icon: icon3,
  },
  {
    head: (
      <p className="text-[#013338]">
        Schedule <b> on-demand coaching sessions</b> that work with your busy
        life.
      </p>
    ),
    icon: icon4,
  },
];
