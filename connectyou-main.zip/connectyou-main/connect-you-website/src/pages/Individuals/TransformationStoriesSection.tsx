import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import useScreenSize from "../../components/hooks/useScreenSize";
import image from "../../assets/images/testimonial-stories-image-1.png";
import { FaArrowLeft } from "react-icons/fa6";
import { Swiper, SwiperSlide } from "swiper/react";
import { Swiper as SwiperType } from "swiper";
import { useState } from "react";
import { Autoplay, Pagination } from "swiper/modules";
import { FaArrowRight } from "react-icons/fa";
import "swiper/swiper-bundle.css";
import { IconButton } from "@mui/material";
import "../../styles/FullScreenSlider.css";
import { useNavigate } from "react-router-dom";

const TransformationStoriesSection = () => {
  const navigate = useNavigate();
  const [swiperInstance, setSwiperInstance] = useState<SwiperType | null>(null);
  const { isMobile, isTab } = useScreenSize();
  return (
    <div className="w-full  py-6 md:py-10 flex flex-col  gap-10 justify-center items-center relative my-14 rounded-[20px] bg-radial from-[#024249] to-[#013338] ">
      <p className="uppercase text-[white] font-bold font-mundial text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        Stories of
        <span className="text-[#ebbd33]"> Transformation </span>
      </p>
      <div className="h-fit  w-full md:w-10/12 mx-auto relative">
        <Swiper
          modules={[Autoplay, Pagination]}
          loop={true}
          autoplay={{
            delay: 2500,
            disableOnInteraction: true,
            pauseOnMouseEnter: true,
          }}
          spaceBetween={30}
          slidesPerView={1}
          pagination={{
            clickable: true,
          }}
          effect="slide"
          onSwiper={(swiper) => setSwiperInstance(swiper)}
          style={{
            width: "80%",
            height: "100%",
            padding: "30px 16px",
            textAlign: "center",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            position: "relative",
          }}
          className="mySwiper-t"
        >
          {slides.map((slide, index) => (
            <SwiperSlide
              key={`featured-coach-slide-in-${index}`}
              style={{
                background: "#F0F0F0",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: "100%",
                height: "100%",
                borderRadius: 20,
              }}
            >
              <div
                className={`grid ${
                  isMobile
                    ? "grid-cols-1  justify-center items-center"
                    : isTab
                    ? "grid-cols-12  justify-center items-center"
                    : "grid-cols-12  justify-start items-center"
                }  w-full h-full rounded-[20px] py-[12px] px-[20px]`}
              >
                <div
                  className={`${
                    isMobile || isTab ? "h-64 w-full" : " h-40 w-40 "
                  } col-span-4 flex justify-start items-center rounded-[20px] overflow-hidden`}
                >
                  <img
                    src={slide.image}
                    alt="coach-image"
                    className="object-cover bg-center origin-center w-full h-full rounded-[20px] hover:scale-[1.02] cursor-pointer"
                  />
                </div>
                <div
                  className={`h-full w-full col-span-8 flex  flex-col justify-center ${
                    isMobile || isTab ? "items-start py-4" : "items-start"
                  } px-4 items-start text-left`}
                >
                  <p className="font-medium text-[16px] text-[#013338]">
                    {slide.quote}
                  </p>
                  <p className="italic cursor-pointer font-semibold text-[18px] text-[#3aa7a3] hover:underline underline-offset-2 ">
                    {slide.name}
                  </p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
        <div className="absolute top-1/2 text-[white]  -translate-y-1/2 left-4 text-2xl font-[800]  z-[999]  w-4 h-4 px-4 rounded-full flex flex-col justify-center items-center  ">
          <IconButton
            onClick={() => {
              if (swiperInstance) {
                swiperInstance?.slidePrev();
              }
            }}
          >
            <FaArrowLeft className="text-white  text-md " />
          </IconButton>
        </div>
        <div className="absolute top-1/2 text-[white]  -translate-y-1/2 right-4 text-2xl font-[800] z-[999]  w-4 h-4 px-4 rounded-full flex flex-col justify-center items-center  ">
          <IconButton
            onClick={() => {
              if (swiperInstance) {
                swiperInstance?.slideNext();
              }
            }}
          >
            <FaArrowRight className="text-white  text-md " />
          </IconButton>
        </div>
      </div>
      <p className="text-[24px] font-medium text-white">
        It’s that simple! Let’s get started.
      </p>
      <div className="flex w-full justify-center items-center">
        <PrimaryYellowButton
          onClick={() => navigate("/find-a-coach")}
          text="Find Your Coach"
        />
      </div>
    </div>
  );
};

export default TransformationStoriesSection;
const slides = [
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
  {
    name: "Review Name",
    image: image,
    quote:
      "Thanks to ConnectYou, I found a coach who understood my needs perfectly. It’s been life-changing.",
  },
];
