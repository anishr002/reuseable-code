import React from "react";
import image1 from "../../assets/images/why-coach-iimage-1.png";
import image2 from "../../assets/images/why-coach-iimage-2.png";
import image3 from "../../assets/images/why-coach-iimage-3.png";
import image4 from "../../assets/images/why-coach-iimage-4.png";

const WhyCoachSection = () => {
  return (
    <div className="   w-full xl:min-h-[31rem] gap-4 py-6 md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[32px] w-full text-center md:w-8/12">
        Why Work with a Coach?
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        Imagine having someone in your corner who’s dedicated to helping you
        succeed. That’s what coaching is all about—giving you the clarity,
        tools, and support to achieve your goals. Your coach will be skilled in
        asking you the questions that unlock your next steps.
      </p>
      <div className="flex-1 w-full h-full gap-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 py-10">
        {whycoachArr.map((wh, index) => (
          <React.Fragment key={`why-choose-coach-card-${index}`}>
            <WhyCoachCard
              heading={wh.heading}
              image={wh.image}
              text={wh.text}
            />
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default WhyCoachSection;

const whycoachArr = [
  {
    heading: "Achieve More, Faster",
    image: image1,
    text: "Set clear goals and create actionable steps to reach them.",
  },
  {
    heading: "Gain Clarity",
    image: image2,
    text: "Discover what’s holding you back and how to overcome it.",
  },
  {
    heading: "Balance Your Life",
    image: image3,
    text: "Create harmony between your personal and professional aspirations.",
  },
  {
    heading: "Supercharge your organization",
    image: image4,
    text: "World-class coaching solutions for businesses.",
  },
];

const WhyCoachCard = ({
  image,
  text,
  heading,
}: {
  image: string;
  text: string;
  heading: string;
}) => {
  return (
    <div className="col-span-1 relative w-full flex justify-center items-end min-h-[350px] rounded-[20px] overflow-hidden">
      <div className="absolute w-full h-full top-0 left-0 z-10">
        <img
          src={image}
          alt="bg-image"
          className="object-cover inset-0 h-full w-full absolute hover:scale-[1.02] cursor-pointer transition-all duration-300 ease-in-out"
        />
      </div>
      <div className=" cursor-pointer hover:h-6/12 transition-all duration-300 ease-in-out w-full gap-2  pt-5   min-h-[140px] bottom-0 pb-3 z-20 rounded-[20px] bg-[#013338] flex flex-col justify-start items-center">
        <span className="text-[#ebbd33] font-bold font-mundial uppercase text-[18px] text-center px-4 text-pretty">
          {heading}
        </span>
        <span className="text-[white] font-medium text-[15px] text-center px-6 text-pretty">
          {text}
        </span>
      </div>
    </div>
  );
};
