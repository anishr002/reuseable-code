/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-expressions */
import SettingsIcon from "@mui/icons-material/Settings";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import Logo from "/loginLogo.png";
import React, { MouseEvent, SetStateAction, useEffect, useState } from "react";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import { useDispatch, useSelector } from "react-redux";
import { ThreeDots } from "react-loader-spinner";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Menu,
  MenuItem,
  Pagination,
  Paper,
  Select,
  SelectChangeEvent,
  Stack,
  Switch,
  Typography,
} from "@mui/material";
import { Link, useLocation } from "react-router-dom";
import { setCount } from "../../slices/Notification";
import CustomModalWrapper from "../../components/wrappers/CustomModalWrapper";
import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import ModalCloseButton from "../../components/buttons/ModalCloseButton";
import { callRefresh } from "../../slices/notificationDrawer";
import MundialHeadingText from "../../components/UI/MundialHeadingText";
import WhiteRoundedBox from "../../components/dashboard-components/WhiteRoundedBox";
import customAlert from "../../lib/swalExtentions";

export interface Notification {
  _id: string;
  user_id: string;
  heading: string;
  description: string;
  url: string;
  readStatus: boolean;
  createdAt: string;
  unreadNotifications: number;
}

const Notifications = ({ type }: { type: string }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const loginUserData = useSelector((state: any) => state.login.userdata);
  const [totalPages, setTotalPages] = useState(0);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState<number>(0);
  const [unreadNotifications, setunreadNotifications] = useState<number>(0);
  usePageScrollAndTitle({
    title: ` ${
      unreadNotifications > 0
        ? `Notifications (${unreadNotifications})`
        : "Notifications"
    }`,
  });
  const dispatch = useDispatch();

  const fetchNotifications = async () => {
    try {
      const response = await httpAPI.post(
        `${backendURL}/${type}/profile/get-all-notifications?page=${page}&limit=10&filter=${filter}`,
        { _id: loginUserData._id }
      );
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        setNotifications(response.data.data);
        setunreadNotifications(response.data.unreadNotifications);
        setErrorMsg(null);
        setTotalPages(response.data.totalPages);
        dispatch(setCount(response.data.unreadNotifications));
      }
    } catch (error: any) {
      console.log(error);
      setErrorMsg(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [page, filter]);

  // for the preferrence settings  system //
  const [anchorEl1, setAnchorEl] = useState<null | HTMLElement>(null);
  const handleOpenMenu = (event: MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const [openNotificationPreferenceModal, setOpenNotificationPreferenceModal] =
    useState<boolean>(false);

  const [isScrolled, setIsScrolled] = useState(false);

  const header = () => {
    const handleChangeFilter = (e: SelectChangeEvent<number>) => {
      setFilter(Number(e.target.value));
      setPage(1);
    };

    return (
      <>
        <div className="flex flex-row w-fit items-center justify-between h-full">
          <div className="flex items-center w-full  justify-end gap-4">
            <div className="">
              <div className="text-[#013338]">
                <span
                  className="hover:cursor-pointer text-[#3aa7a3] "
                  onClick={handleOpenMenu}
                >
                  <SettingsIcon />
                </span>
                <Menu
                  anchorEl={anchorEl1}
                  onClose={handleCloseMenu}
                  open={Boolean(anchorEl1)}
                >
                  <Box sx={{ px: 1, py: 1 }}>
                    <MenuItem
                      onClick={() => {
                        handleCloseMenu();
                        setOpenNotificationPreferenceModal(true);
                      }}
                      sx={{ color: "#013338" }}
                    >
                      Settings
                    </MenuItem>
                    <MenuItem
                      onClick={() => {
                        handleCloseMenu();
                        unreadNotifications > 0 &&
                          customAlert
                            .fire({
                              title: "Mark all as read?",
                              text: "You won't be able to revert this!",
                              icon: "warning",
                              showCancelButton: true,
                              confirmButtonColor: "#EBBE34",
                              cancelButtonColor: "#d33",
                              confirmButtonText: "Read All !",
                            })
                            .then(async (result) => {
                              if (result.isConfirmed) {
                                try {
                                  const response = await httpAPI.put(
                                    `${backendURL}/${loginUserData.userType}/profile/notification/mark-all-as-read`,
                                    { _id: loginUserData._id }
                                  );
                                  // console.log(response.data);
                                  if (response.status === 200) {
                                    fetchNotifications();
                                    dispatch(callRefresh());
                                    customAlert.fire({
                                      title: "Success!",
                                      text: "All the notifications have been marked as read.",
                                      icon: "success",
                                      timer: 1500,
                                      showConfirmButton: false,
                                    });
                                  } else {
                                    console.error(
                                      "Some Error While getting notifications."
                                    );
                                  }
                                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                } catch (error: any) {
                                  console.log(error);
                                }
                              }
                            });
                      }}
                      sx={{
                        color: unreadNotifications > 0 ? "#013338" : "gray",
                      }}
                      disabled={unreadNotifications > 0 ? false : true}
                    >
                      Mark All As Read
                    </MenuItem>
                  </Box>
                </Menu>

                {/* <Button
                  variant="outlined"
                  
                  sx={{
                    color: "white",
                    backgroundColor: "#EBBE34",
                    borderColor: "#EBBE34",
                    borderRadius: "20px",
                    fontFamily: "Quicksand",
                    "&:hover": {
                      borderColor: "#EBBE34",
                      backgroundColor: "white",
                      color: "#EBBE34",
                    },
                  }}
                >
                  Mark All As Read
                </Button> */}
              </div>
            </div>
            <FormControl
              sx={{
                fontSize: "1rem",
                minWidth: 110,
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: "#013338", // Set border color for outlined variant
                  },
                  "&:hover fieldset": {
                    borderColor: "#013338", // Set border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#013338", // Set border color when focused
                  },
                },
                borderColor: "#013338",
              }}
              size="small"
            >
              <InputLabel
                id="demo-select-small-label"
                sx={{
                  color: "#013338",
                  fontSize: "0.975rem",
                  "&.Mui-focused": {
                    color: "#013338", // Change label color when focused
                  },
                }}
              >
                FILTER
              </InputLabel>
              <Select
                size="small"
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={filter}
                label="filterTerm"
                onChange={handleChangeFilter}
                sx={{
                  color: "#013338",
                  borderColor: "#013338",
                  fontSize: "0.775rem",
                  "& .MuiSelect-icon": {
                    color: "#013338", // Set the color of the dropdown icon
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#013338", // Set border color
                  },
                }}
              >
                <MenuItem sx={{ fontSize: "0.775rem" }} value={0}>
                  All
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={1}>
                  Unread
                </MenuItem>
                <MenuItem sx={{ fontSize: "0.775rem" }} value={2}>
                  Read
                </MenuItem>
              </Select>
            </FormControl>
          </div>
        </div>
        <NotificationPreferenceModal
          open={openNotificationPreferenceModal}
          setOpen={setOpenNotificationPreferenceModal}
        />
      </>
    );
  };

  if (loading) {
    return (
      <div className="flex w-full h-screen justify-center items-center overflow-auto ">
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </div>
    );
  }

  if (errorMsg) {
    return (
      <>
        <Paper
          elevation={0}
          sx={{
            display: "flex",
            flexDirection: "column",
            p: 1,
            width: "100%",
            overflow: "auto",
            maxHeight: "100vh",
            background: "transparent",
          }}
        >
          <div
            className="w-full h flex flex-col gap-5 px-4 py-6 justify-start items-start bg-white h-screen overflow-auto
      "
          >
            <div className="flex w-full h-60 justify-center items-center overflow-auto ">
              <div className="text-2xl font-semibold text-red-600">
                {errorMsg}
              </div>
            </div>
          </div>
        </Paper>
      </>
    );
  }

  return (
    <div className="w-full h-full bg-white  rounded-[5px] max-h-[calc(100vh-103px)] overflow-hidden">
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          background: "transparent",
          height: "100%",
        }}
      >
        <div
          style={{
            boxShadow: isScrolled
              ? "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)"
              : "none",
          }}
          className="header min-h-[fit-content]  w-full flex items-center justify-between  px-2 pt-2 mb-2 bg-white "
        >
          <WhiteRoundedBox className="flex flex-row justify-between items-center w-full">
            <MundialHeadingText
              variant="darksea"
              sizeVariant="xs"
              className="ps-2"
            >
              Notifications
            </MundialHeadingText>
            {header()}
          </WhiteRoundedBox>
        </div>

        <div
          className="flex-1 flex flex-col overflow-auto w-full bg-white   style-scroll mb-2"
          onScroll={(e) => setIsScrolled(e.currentTarget.scrollTop > 20)}
        >
          <div className="flex items-start justify-start flex-col min-h-fit w-full space-y-1.5   p-2">
            <NotificationCard
              Notifications={notifications}
              fetchNotifications={fetchNotifications}
              type={type}
            />
          </div>
        </div>

        <Paper
          elevation={3}
          sx={{
            position: "sticky",
            bottom: 0,
            display: "flex",
            background: "white",
            justifyConten: "space-between",
            width: "100%",
            alignItems: "center",
            height: "fit-content",
            py: 1,
            borderTop: "1px solid #ccc",
          }}
        >
          <Stack
            width={"100%"}
            spacing={2}
            flexDirection={"row"}
            alignContent={"center"}
            justifyContent={"space-between"}
            alignItems={"center"}
          >
            <Pagination
              count={totalPages}
              page={page}
              onChange={(_, value) => {
                // console.log(e);
                setPage(value);
              }}
            />
          </Stack>
        </Paper>
      </Paper>
    </div>
  );
};

export default Notifications;

const NotificationCard = ({
  Notifications,
  fetchNotifications,
  type,
}: {
  Notifications: Notification[];
  fetchNotifications: () => void;
  type: string;
}) => {
  const dispatch = useDispatch();
  const [selectedNotification, setSelectedNotification] =
    useState<Notification | null>(null);

  const handleViewDetails = (notification: Notification) => {
    setSelectedNotification(notification);
  };

  const closeModal = () => {
    setSelectedNotification(null);
  };

  const MarkAsRead = async ({ _id }: { _id: string }) => {
    try {
      const response = await httpAPI.put(
        `${backendURL}/${type}/profile/notification/mark-as-read`,
        { _id }
      );
      // console.log(response.data);
      if (response.status !== 200) {
        console.error("Some Error While getting notifications.");
      } else {
        dispatch(callRefresh());
        fetchNotifications();
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.log(error);
    }
  };
  const location = useLocation();
  useEffect(() => {
    if (
      location.state &&
      location.state?.openNotificationDetails &&
      location.state?.notification_id
    ) {
      setSelectedNotification(
        Notifications.find((a) => a._id === location.state.notification_id) ||
          null
      );
      MarkAsRead({ _id: location.state.notification_id });
      window.history.replaceState({}, "");
    }
  }, [location.state]);

  return (
    <>
      {Notifications.length > 0 ? (
        <>
          {" "}
          {Notifications.sort((a, b) => {
            return Number(a.readStatus) - Number(b.readStatus);
          }).map((n: Notification, i: number) => (
            <div
              key={i}
              className={`Notification ${
                n.readStatus === false
                  ? "bg-[#3aa7a325] border-b-[#3aa7a3]"
                  : "bg-white border-b-[#cec8c8]"
              } relative w-full flex md:flex-row flex-col border border-transparent justify-start items-start h-auto px-4 md:pt-4 pt-6 pb-2 text-md font-semibold  gap-4`}
            >
              <div className="flex flex-row justify-center item-center w-fit py-2  ">
                <div
                  className={`flex flex-row justify-center items-center rounded-full border-[8px] ${
                    n.readStatus === false
                      ? "border-[#3aa7a3]"
                      : "border-[#737373]"
                  }  min-w-12 min-h-12 p-2`}
                >
                  {n.readStatus ? (
                    <NotificationsNoneIcon sx={{ color: "#737373" }} />
                  ) : (
                    <NotificationsActiveIcon
                      sx={{
                        color: "#3aa7a3",
                      }}
                    />
                  )}
                </div>
              </div>
              <div className="flex flex-col justify-start items-start gap-2 w-11/12">
                <div
                  className={`${
                    n.readStatus === false
                      ? "text-[#3aa7a3] "
                      : "text-[#737373]"
                  } `}
                >
                  {n.heading}
                </div>
                <div
                  className={`absolute top-0 right-2 text-xs text-normal ${
                    n.readStatus === false
                      ? "text-[#3aa7a3] "
                      : "text-[#737373]"
                  }  py-2 "`}
                >
                  {new Date(n.createdAt).toLocaleString()}
                </div>
                <div className=" line-clamp-1 w-full md:w-1/3 text-sm md:text-xs font-normal text-[#737373]">
                  {n.description}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    handleViewDetails(n);
                    MarkAsRead({ _id: n._id });
                  }}
                  className="flex w-full text-sm text-gray-600 font-medium "
                >
                  Read More
                </button>
              </div>
            </div>
          ))}
        </>
      ) : (
        <>
          <div className="flex flex-row justify-center items-center w-full h-screen text-[red]">
            No Notifications !
          </div>
        </>
      )}

      {selectedNotification && (
        <NotificationDetailsModal
          notification={selectedNotification}
          closeModal={closeModal}
        />
      )}
    </>
  );
};

const NotificationDetailsModal = ({
  notification,
  closeModal,
}: {
  notification: Notification;
  closeModal: () => void;
}) => {
  const { heading: title, description, url, createdAt: time } = notification;

  return (
    <>
      <CustomModalWrapper
        open={Boolean(notification)}
        onClose={closeModal}
        title={
          <img
            src={Logo}
            alt="Website-Logo"
            className="w-36 pt- object-contain mx-auto"
          />
        }
      >
        <ModalCloseButton onClick={() => closeModal()} />
        <Box
          sx={{
            height: "fit-content",
            width: "100%",
            display: "flex",
            justifyContent: "start",
            alignItems: "start",
            flexDirection: "column",
            p: 2,
            gap: 2,
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: 600,
              width: "100%",
              textAlign: "center",
              color: "#013338",
              fontFamily: "Quicksand",
            }}
          >
            {title}
          </Typography>
          <Typography
            variant="body2"
            sx={{
              fontWeight: 500,
              width: "100%",
              textAlign: "center",
              color: "black",
              fontFamily: "Quicksand",
              px: 1,
            }}
          >
            {description}
          </Typography>
          <Typography
            variant="caption"
            sx={{
              fontWeight: 300,
              width: "100%",
              textAlign: "center",
              color: "black",
              fontFamily: "Quicksand",
              px: 1,
            }}
          >
            {new Date(time).toLocaleString()}
          </Typography>
          {url && (
            <Button
              variant="outlined"
              sx={{
                p: 0,
                color: "white",
                backgroundColor: "#EBBE34",
                borderColor: "#EBBE34",
                borderRadius: "20px",
                fontFamily: "Quicksand",
                mx: "auto",
                "&:hover": {
                  borderColor: "white",
                  backgroundColor: "white",
                  color: "#EBBE34",
                },
              }}
            >
              <Link className="h-full w-full" to={`${url}`}>
                View
              </Link>
            </Button>
          )}
        </Box>
      </CustomModalWrapper>
    </>
  );
};
interface NotificationPreferenceModalProps {
  open: boolean;
  setOpen: React.Dispatch<SetStateAction<boolean>>;
}

interface NotificationPreferenceModalProps {
  open: boolean;
  setOpen: React.Dispatch<SetStateAction<boolean>>;
  allowBackdropClickClose?: boolean;
}

const NotificationPreferenceModal: React.FC<
  NotificationPreferenceModalProps
> = ({ open, setOpen, allowBackdropClickClose = false }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [notificationPreferences, setNotificationPreferences] = useState<
    Record<string, boolean>
  >({
    authentication: true,
    admin: true,
    promotion: true,
    bookings: true,
    alerts: true,
    payments: true,
    newsletter: true,
    systemUpdates: true,
    locationBased: true,
    others: true,
  });

  const [pauseAll, setPauseAll] = useState<boolean>(false);
  const togglePauseAll = (value: boolean) => {
    setPauseAll(value);
    setNotificationPreferences((prev) =>
      Object.keys(prev).reduce((acc, key) => {
        acc[key] = !value; // Set all preferences to false if Pause All is true
        return acc;
      }, {} as Record<string, boolean>)
    );
  };

  const [refresh, setRefresh] = useState<boolean>(false);
  const loginUserData = useSelector((state: any) => state.login.userdata);

  useEffect(() => {
    const fetchNotificationsPreference = async () => {
      setLoading(true);
      try {
        const response = await httpAPI.get(
          `${backendURL}/${
            loginUserData.userType === "coach" ? "coach" : "user"
          }/profile/notification/get-preferrences`
        );
        // console.log(response);
        if (response.status === 200) {
          setNotificationPreferences(response.data.data.preferrences);
          setPauseAll(response.data.data.pauseAll);
        } else {
          console.log("Some Error Occurred:", response.data);
        }
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    fetchNotificationsPreference();
  }, [refresh]);

  const toggleNotificationPreference = (name: string, value: boolean) => {
    setNotificationPreferences((prev) => ({ ...prev, [name]: value }));
  };

  const submitNotificationPreferrence = async () => {
    setLoading(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/${
          loginUserData.userType === "coach" ? "coach" : "user"
        }/profile/notification/update-preferrences`,
        {
          preferrences: notificationPreferences,
          pauseAll: pauseAll,
        }
      );
      if (response.status === 200) {
        setRefresh(!refresh);
        setLoading(false);
        setOpen(false);
      } else {
        console.log("Error saving preferences:", response.data);
      }
    } catch (error) {
      console.error("Error while saving notification preferences:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <CustomModalWrapper
        children={
          <>
            {loading ? (
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <ThreeDots color="#eabd32" />
              </Box>
            ) : (
              <div className="flex font-quicksand flex-col w-full px-4 py-3 justify-start items-start">
                <div className="flex flex-col w-full px-4 py-2 justify-start items-start text-md ">
                  <h1 className="w-full font-mundial text-start font-semibold text-lg ">
                    Manage Notification Preferences
                  </h1>
                  <h1 className="w-full text-start font-medium text-xs ">
                    Adjust the types of notifications that you want to receive
                  </h1>
                  <div className="flex flex-col justify-start items-start w-full">
                    <div key="pauseAll" className="flex flex-col w-full my-2 ">
                      <div className="flex flex-row justify-between items-center w-full">
                        <span
                          className={`${
                            pauseAll ? "text-[red]" : "text-[black]"
                          } font-medium text-md`}
                        >
                          Pause All Notifications
                        </span>
                        <span>
                          <Switch
                            checked={pauseAll}
                            onChange={(e) => togglePauseAll(e.target.checked)}
                            sx={{
                              "& .MuiSwitch-switchBase.Mui-checked": {
                                color: pauseAll ? "red" : "#eabd32",
                              },
                              "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                                {
                                  backgroundColor: pauseAll ? "red" : "#eabd32",
                                },
                            }}
                          />
                        </span>
                      </div>
                      <div className="flex flex-row justify-between items-center w-full text-sm text-gray-600">
                        Toggle this to disable all notification preferences.
                      </div>
                    </div>
                    {!pauseAll ? (
                      <>
                        {Object.entries(notificationPreferences).map(
                          ([key, value]) => (
                            <div
                              key={key}
                              className="flex flex-col w-full my-1"
                            >
                              <div className="flex flex-row justify-between items-center w-full">
                                <span
                                  className={`${
                                    value === true
                                      ? "text-[#eabd32]"
                                      : "text-black"
                                  } font-medium text-md`}
                                >
                                  {key
                                    .replace(/([A-Z])/g, " $1")
                                    .replace(/^./, (str: string) =>
                                      str.toUpperCase()
                                    )}{" "}
                                </span>
                                <span>
                                  <Switch
                                    checked={value}
                                    onChange={(e) =>
                                      toggleNotificationPreference(
                                        key,
                                        e.target.checked
                                      )
                                    }
                                    sx={{
                                      "& .MuiSwitch-switchBase.Mui-checked": {
                                        color: "#eabd32",
                                      },
                                      "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                                        {
                                          backgroundColor: "#eabd32",
                                        },
                                    }}
                                  />
                                </span>
                              </div>
                              <div className="flex flex-row justify-between items-center w-full text-sm text-gray-600">
                                {key === "authentication" &&
                                  "Receive notifications for login attempts and security updates."}
                                {key === "admin" &&
                                  "Receive notifications from administrators or system alerts."}
                                {key === "promotion" &&
                                  "Receive notifications about promotions, discounts, and special offers."}
                                {key === "bookings" &&
                                  "Receive notifications about booking confirmations, reminders, and updates."}
                                {key === "alerts" &&
                                  "Receive important security & profile alerts and notifications."}
                                {key === "payments" &&
                                  "Receive notifications about payment confirmations, failures, and reminders."}
                                {key === "newsletter" &&
                                  "Subscribe to our newsletter for updates and news."}
                                {key === "systemUpdates" &&
                                  "Receive notifications about system updates and maintenance."}
                                {key === "locationBased" &&
                                  "Receive location-based notifications and offers."}
                                {key === "others" &&
                                  "Other notifications containing less important information."}
                              </div>
                            </div>
                          )
                        )}
                      </>
                    ) : (
                      <>
                        <div className="w-full text-center text-sm font-medium text-red-600 py-6">
                          You have paused all the notifications, you will not
                          receive any notification untill you change this
                          setting.
                        </div>
                      </>
                    )}
                  </div>
                  <div className="flex justify-center items-center w-full pt-6">
                    <Button
                      variant="outlined"
                      size="small"
                      sx={{
                        color: "white",
                        fontSize: "0.775rem",
                        backgroundColor: "#EBBE34",
                        borderColor: "#EBBE34",
                        borderRadius: "20px",
                        fontFamily: "Quicksand",
                        "&:hover": {
                          borderColor: "#ebbe34",
                          backgroundColor: "white",
                          color: "#EBBE34",
                        },
                      }}
                      onClick={submitNotificationPreferrence}
                    >
                      Save Preferences
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </>
        }
        open={open}
        onClose={() => setOpen(false)}
        title="Notification Preferences"
        backdropClose={allowBackdropClickClose}
      />
    </>
  );
};
