import { useEffect, useRef, useState } from "react";
import manImage from "../../assets/images/man-about-story-section.png";
import womanImage from "../../assets/images/woman-about-story-section.png";

const ConnectYouStory = () => {
  const textSectionRef = useRef<HTMLDivElement | null>(null);
  const [textSectionHeight, settextSectionHeight] = useState<number>(0);
  useEffect(() => {
    if (textSectionRef && textSectionRef.current) {
      settextSectionHeight(textSectionRef.current.scrollHeight);
    }
  }, [textSectionRef]);
  return (
    <div id="connect-you-story" className=" w-full gap-4 py-6 md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <div className="w-full grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Man Image */}
        <div className="w-full col-span-1 md:col-span-12 md:hidden h-fit">
          <div className="md:hidden flex flex-col gap-4 w-full">
            <p className="uppercase text-[#013338] font-bold font-mundial text-[20px] md:text-[24px] lg:text-[32px] w-full ">
              The Story of ConnectYou
            </p>
            <span className="text-[#3aa7a3] text-[16px] md:text-[18px]  font-bold">
              Welcome to ConnectYou.
            </span>
          </div>
        </div>
        <div className="col-span-1 md:col-span-4 flex justify-start items-start w-full order-1 md:order-1">
          <div
            style={{
              maxHeight: `${textSectionHeight}px`,
            }}
            className="w-full h-full relative overflow-hidden flex justify-start items-start rounded-[20px]"
          >
            <img
              src={manImage}
              alt="man"
              className="w-full h-full object-cover cursor-pointer hover:scale-[1.02] block inset-0 absolute object-[50%_0%]"
            />
          </div>
        </div>

        {/* Text Section */}
        <div
          ref={textSectionRef}
          className="col-span-1 h-full md:col-span-8 flex flex-col justify-start items-start w-full gap-3 ps-4 order-2 md:order-2"
        >
          <div className="hidden md:flex flex-col gap-4 w-full">
            <p className="uppercase text-[#013338] font-bold font-mundial text-[20px] md:text-[24px] lg:text-[32px] w-full md:w-12/12">
              The Story of ConnectYou
            </p>
            <span className="text-[#3aa7a3] text-[16px] md:text-[18px]  font-bold">
              Welcome to ConnectYou.
            </span>
          </div>
          <span className="text-[#013338] text-[16px] md:text-[18px]  font-medium">
            ConnectYou is more than just a platform—it’s a vision realized. Born
            out of the legacy of Erickson Coaching International, the most
            established and globally respected coach training school in the
            world, ConnectYou carries forward our 45-year tradition of
            pioneering coaching excellence.
          </span>
          <span className="text-[#013338] text-[16px] md:text-[18px]  font-medium">
            At Erickson, we’ve always believed in the power of coaching to
            transform lives, organizations, and communities. Over the decades,
            we’ve partnered with organizations across the globe, helping them
            build coaching cultures and empowering their people to thrive. We’ve
            watched with excitement as businesses began to embrace coaching—not
            just as a tool for executives or as a remedy for poor performance
            but as a core driver of health, innovation, and excellence at every
            level.
          </span>
          <span className="text-[#013338] text-[16px] md:text-[18px]  font-medium">
            ConnectYou was born from this passion to better serve coaches,
            individuals, and organizations. It bridges the gap between the
            world’s best coaches and the organizations and individuals who need
            them most. Too often, coaching has been an exclusive privilege—a
            luxury for the few. With ConnectYou, we’re determined to change
            that. We envision a future where coaching is embedded in every
            aspect of individual and organizational health, where it fuels
            collaboration, resilience, and success for all.
          </span>
        </div>

        {/* Additional Text Section */}
        <div className="col-span-1 md:col-span-8 flex flex-col justify-start items-start w-full gap-3 ps-4 order-4 md:order-3">
          <span className="text-[#013338] text-[16px] md:text-[18px]  font-medium">
            We’re also strong advocates for certified coaches, and are proud of
            our own vibrant global community of +55,000 graduates spanning six
            continents. These incredible professionals live the Erickson mission
            of “changing the world, one conversation at a time.” ConnectYou is
            our commitment to supporting them, offering a transparent,
            empowering platform where they can thrive, be fairly compensated,
            and continue making a difference.
          </span>
          <span className="text-[#013338] text-[16px] md:text-[18px]  font-medium">
            Together, we are shaping the future of coaching—creating a world
            where transformative conversations are accessible, impactful, and
            woven into the fabric of everyday life.
          </span>

          <span  className="text-[#013338] text-[16px] md:text-[18px]  font-medium">
            We’re thrilled to embark on this journey with you—whether as a
            coach, an individual seeking transformation, or an organization
            striving for excellence. Thank you for being part of this movement.
          </span>
          <div className="text-[#013338] text-[16px] md:text-[18px]  font-medium flex flex-col gap-1">
            <span>Warm regards,</span>
            <a
              href="https://www.erickson.edu/en/home"
              target="_blank"
              className="cursor-pointer font-bold text-[#3aa7a3] hover:text-[#ebbd33] hover:underline underline-offset-2 text-[16px] md:text-[20px]"
            >
              Erickson Coaching International
            </a>
            <span>Founders of ConnectYou</span>
          </div>
        </div>

        {/* Woman Image */}
        <div className="col-span-1 md:col-span-4 flex justify-center items-start w-full order-3 md:order-4">
          <div className="w-full  overflow-hidden flex justify-center items-center rounded-[20px]">
            <img
              src={womanImage}
              alt="woman"
              className="w-full h-full object-cover cursor-pointer hover:scale-[1.02]"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectYouStory;
