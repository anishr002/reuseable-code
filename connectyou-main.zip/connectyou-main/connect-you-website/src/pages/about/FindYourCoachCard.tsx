import { useNavigate } from "react-router-dom";
import image from "../../assets/images/find-you-coach-sec-image.png";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import HighlightGetInTouchCardWrapper from "../../components/wrappers/HighlightGetInTouchCardWrapper";

const FindYourCoachCard = () => {
  const navigate = useNavigate();
  return (
    <>
      <HighlightGetInTouchCardWrapper
        button={
          <>
            <PrimaryYellowButton
              onClick={() => navigate("/find-a-coach")}
              text="Find Your Coach"
            />
          </>
        }
        rightContent={
          <>
            <p className="z-20 text-[#ebbd33] flex flex-col justify-center items-center w-full font-mundial font-bold uppercase text-[24px] md:text-[36px] text-center md:text-left">
              Ready to get connected <br />
              <span className="text-white">with your coach?</span>
            </p>
            <p className=" text-white font-medium text-[18px]  text-pretty  text-center w-10/12">
              Start your journey today. Whether you're seeking personal
              transformation, team development, or organizational growth,
              ConnectYou is here to guide you every step of the way.
            </p>
          </>
        }
        image={image}
      />
    </>
  );
};

export default FindYourCoachCard;
