import woman from "../../assets/images/about-banner-image.png";
import PageBannerWrapper from "../../components/wrappers/PageBannerWrapper";

const AboutBanner = () => {
  return (
    <>
      <PageBannerWrapper
        image={woman}
        leftChild={
          <>
            <p className="z-20 text-white font-mundial font-bold uppercase text-[24px] md:text-[36px] ">
              Connecting the world{" "}
              <span className="text-[#ebbd33]">
                through transformative coaching
              </span>
            </p>
            <p className="z-20 font-medium text-white text-[18px] md:text-[26px] mt-4 md:mt-6 w-full md:w-10/12">
              Discover the story behind ConnectYou and the vision that drives us
              to transform lives, organizations, and communities.
            </p>
          </>
        }
      />
    </>
  );
};

export default AboutBanner;
