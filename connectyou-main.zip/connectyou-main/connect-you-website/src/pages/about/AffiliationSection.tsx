import image1 from "../../assets/icons/affiliation-1.png";
import image2 from "../../assets/icons/affiliation-2.png";
import image3 from "../../assets/icons/affiliation-3.png";

const AffiliationSection = () => {
  return (
    <div className="cursor-pointer w-full xl:min-h-[25rem] gap-4 py-6 md:py-0 flex flex-col justify-center items-center relative mb-14 rounded-[20px]">
      <p className="uppercase text-[#013338] font-mundial font-bold text-[24px] md:text-[36px] w-full text-center md:w-8/12">
        A Global Legacy of
        <span className="text-[#3aa7a3]"> Quality and Trust </span>
      </p>
      <p className="text-[#013338] text-[16px] md:text-[20px] w-full text-center md:w-8/12 font-medium">
        ConnectYou is built on Erickson Coaching International’s legacy of
        excellence and is proud to hold globally recognized certifications and
        partnerships.
      </p>
      <div className="pt-5 flex-1 grid grid-cols-1 gap-6 sm:grid-cols-12 w-full">
        {aff.map((af, i) => (
          <div
            key={`affiliation-card-${i}`}
            className="aff-card rounded-[20px] min-h-[300px]   col-span-1 sm:col-span-6 lg:col-span-4 flex flex-col justify-start items-center bg-[#013338] gap-6 pt-4 lg:pt-10 px-6 sm:px-10"
          >
            <div className="flex w-full h-24 justify-center items-start">
              {i === 1 ? (
                <img
                  src={af.image}
                  alt="image-aff"
                  className={`object-contain  h-9/12 w-fit p-0 block`}
                  // className={`object-contain max-w-24 h-24 sm:max-w-28 sm:max-h-28 md:max-w-32 md:max-h-32  aspect-3/2 block`}
                />
              ) : (
                <img
                  src={af.image}
                  alt="image-aff"
                  className={`object-contain h-full  aspect-3/2 block`}
                  // className={`object-contain max-w-24 h-24 sm:max-w-28 sm:max-h-28 md:max-w-32 md:max-h-32  aspect-3/2 block`}
                />
              )}
            </div>
            <p className=" aff-text text-white text-center text-[14px] sm:text-[16px] md:text-[18px] font-medium  t text-balance">
              {af.section}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AffiliationSection;

const aff = [
  {
    section:
      "Accredited by the International Coaching Federation, the gold standard in coaching worldwide",
    image: image1,
  },
  {
    section: "A trusted pioneer in coach training for over 45 years",
    image: image2,
  },
  {
    section:
      "Aligned with SHRM’s commitment to leadership and organizational success",
    image: image3,
  },
];
