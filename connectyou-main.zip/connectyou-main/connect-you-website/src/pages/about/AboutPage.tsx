import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import XSpace from "../../components/wrappers/XSpace";
import AboutBanner from "./AboutBanner";
import AffiliationSection from "./AffiliationSection";
import ConnectYouStory from "./ConnectYouStory";
import FindYourCoachCard from "./FindYourCoachCard";

const AboutPage = () => {
  usePageScrollAndTitle({ title: "About ConnectYou" });
  return (
    <div className="w-full flex flex-col h-full justify-center items-center bg-white">
      <AboutBanner />
      <XSpace>
        <ConnectYouStory />
        <FindYourCoachCard />
        <AffiliationSection />
      </XSpace>
    </div>
  );
};

export default AboutPage;
