/* eslint-disable @typescript-eslint/no-explicit-any */

import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { Avatar, Button, IconButton } from "@mui/material";
import React, { useEffect } from "react";
import SessionNotFounDImage from "../../assets/illustrations/no-cart-data.png";
import DeleteIcon from "@mui/icons-material/Delete";
import moment from "moment-timezone";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import { useNotify } from "../../lib/Notify";
import backendURL, { httpAPI } from "../../util/AxiosAPI";
import Community from "../../components/UI/Community";
import XSpace from "../../components/wrappers/XSpace";
import { setCartCount } from "../../slices/cartCount";
import useGenCartKey from "../../components/hooks/useGenCartKey";
import { PrimaryYellowButton } from "../../components/buttons/RoundedButton";
import CartSessionCard from "./CartSessionCard";
import Warning from "../../components/UI/Warning";
import { YellowButton } from "../../components/buttons/ThemeButtons";
import MundialHeadingText from "../../components/UI/MundialHeadingText";
import CartItem_Type from "../../Types/UI/CartItem_Type";
import dayjs from "dayjs";
import ProvideToolTip from "../../components/wrappers/ProvideToolTip";
import { IoAddCircle, IoRemoveCircleSharp } from "react-icons/io5";
import LoadingElement, {
  BackdropLoader,
} from "../../components/UI/LoadingElement";
import customAlert from "../../lib/swalExtentions";
import CartItemsCount from "../../components/UI/CartItemsCount";
import MenuButton from "../../components/buttons/MenuButton";
import { FaTrash } from "react-icons/fa";
import { requestRedirection } from "../../components/hooks/useDetectRedirection";

const Cart = () => {
  const navigate = useNavigate();
  const { notifyMe } = useNotify();
  const [cartItems, setcartItems] = React.useState<CartItem_Type[]>([]);
  const [loading, setLoading] = React.useState(true); // Add loading state
  const [pageUpdated, setPageUpdated] = React.useState(true);
  const [loadingPaymentPage, setloadingPaymentPage] = React.useState(false); //loading behaviour on form submit
  const location = useLocation();
  const { cartKey: cartId, genCartKey } = useGenCartKey();
  useEffect(() => {
    if (!cartId || cartId === "") {
      genCartKey();
    }
  }, [cartId]);
  const loginUserData = useSelector((state: any) => state.login.userdata);
  const loginData = loginUserData?.name && loginUserData;
  const loginUserType = loginData
    ? loginUserData.userType == "coachee"
      ? "u"
      : "c"
    : null;
  const userTimeZone = loginData?.timeZone || moment.tz.guess();
  const dispatch = useDispatch();
  const fetchData = async () => {
    if (!cartId) {
      return genCartKey();
    }
    try {
      const response = await axios.post(
        `${backendURL}/user/cart/list-session`,
        {
          userId: loginData?._id,
          cartId: cartId,
        }
      );
      // console.log({ response });
      if (response.status === 200) {
        setcartItems(response.data.data);
        localStorage.setItem("cartItems", response.data.data.length);
        dispatch(setCartCount(response.data.data.length));
      }
    } catch (error) {
      console.log({ error });
    }
  };

  const removeSession = async (id: string) => {
    setLoading(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/user/cart/remove-session/${id}`
      );
      if (response.status === 200) {
        setLoading(false);
        return setPageUpdated(!pageUpdated);
      }
    } catch (error) {
      console.log({ error });
      notifyMe({ message: "Something went wrong", severity: "error" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const init = async () => {
      try {
        setLoading(true);
        await fetchData();
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [pageUpdated, cartId, location.pathname, loginData?._id]);

  const handlecheckout = async () => {
    setloadingPaymentPage(true);
    await fetchData();
    if (cartItems.length == 0) {
      setloadingPaymentPage(false);
      setLoading(false);
      return notifyMe({
        severity: "warning",
        message: "Please add a session to checkout",
      });
    }
    if (loginUserType != "u") {
      setloadingPaymentPage(false);
      setLoading(false);
      if (loginUserType === "c") {
        return customAlert.fire({
          title: "You must be logged in as a coachee !",
          text: "Please Sign in or register as a coachee to use this feature.",
          showConfirmButton: true,
        });
      } else {
        return customAlert
          .fire({
            title: "You are not logged in!",
            text: "Please Sign in or register as a coachee to use this feature.",
            showConfirmButton: true,
            showCancelButton: true,
            confirmButtonText: "Login",
            cancelButtonText: "Signup",
            customClass: {
              confirmButton: "swal-login-btn",
              cancelButton: "swal-signup-btn",
            },
            buttonsStyling: false,
          })
          .then((result) => {
            if (result.isConfirmed) {
              navigate("/login", {
                state: { ...requestRedirection("/cart") },
              });
            } else if (result.dismiss === customAlert.DismissReason.cancel) {
              navigate("/signup-coachee", {
                state: { ...requestRedirection("/cart") },
              });
            }
          });
      }
    }
    const items = cartItems.map((data: CartItem_Type) => {
      return {
        cartId: data._id,
        coachId: data.coachData._id,
        coachTimeZone: data.coachData.timeZone,
        sessionId: data.sessionData._id,
        amount: data.sessionData.price,
        sessionType: data.sessionData.type,
        stripePriceId: data.sessionData.stripePriceId,
        sessionDate: data.sessionDate,
      };
    });
    try {
      const response = await httpAPI.post(
        `${backendURL}/user/PaymentLink/create`,
        {
          items: items,
          cartId: cartId,
        }
      );
      if (response.status === 200) {
        const paymentLink = response.data.paymentLink;
        window.location.href = paymentLink;
        setTimeout(() => {
          return setloadingPaymentPage(false);
        }, 300);
      }
    } catch (error: any) {
      console.log({ error });
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        setloadingPaymentPage(false);
        setLoading(false);
        return notifyMe({
          severity: "error",
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
        });
      } else {
        setloadingPaymentPage(false);
        setLoading(false);
        return notifyMe({ message: "Something went wrong", severity: "error" });
      }
    }
  };
  usePageScrollAndTitle({
    title: `Cart ${
      cartItems.length > 0
        ? cartItems.length > 9
          ? "(9+)"
          : `(${cartItems.length})`
        : ""
    }`,
  });
  const TAX_PERCENT = 0; // Update later for VAT etc.
  const getCartSummary = (cartItems: CartItem_Type[]) => {
    const subtotal = cartItems.reduce(
      (sum, item) => sum + Number(item.sessionData.price || 0),
      0
    );
    const tax = (subtotal * TAX_PERCENT) / 100;
    const total = subtotal + tax;
    return { subtotal, tax, total };
  };

  const handleRemoveItem = async (id: string) => {
    try {
      customAlert
        .fire({
          title: "Are you sure?",
          text: "You want to remove this session from your cart?",
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: "Yes, Remove it!",
        })
        .then((result) => {
          if (result.isConfirmed) {
            return removeSession(id);
          }
        });
    } catch (error) {
      console.log(error);
    }
  };

  if (loading) {
    return (
      <div className="flex w-full h-screen justify-center items-center">
        <LoadingElement variant="dynamic" />
      </div>
    );
  }

  return (
    <>
      <BackdropLoader
        open={loadingPaymentPage}
        text="Please wait while we prepare your payment page .."
      ></BackdropLoader>
      <XSpace>
        <div className="w-full min-h-fit pt-10 grid grid-cols-12 auto-cols-fr space-y-3 relative">
          <div className="col-span-full pb-6">
            <div className="w-full flex items-center justify-between gap-4">
              <MundialHeadingText
                sizeVariant="lg"
                className="leading-0 relative flex justify-start items-center gap-3"
              >
                My Cart <CartItemsCount variant="inline" />
              </MundialHeadingText>
              {cartItems.length > 0 && (
                <div onClick={() => navigate("/find-a-coach/list")}>
                  <YellowButton text="add more session +"></YellowButton>
                </div>
              )}
            </div>
          </div>
        </div>
        {cartItems.length > 0 ? (
          <div className="w-full min-h-fit pb-10 grid grid-cols-12 auto-cols-fr space-y-3 relative">
            <div className="col-span-full md:col-span-8 md:pr-10 space-y-3">
              {cartItems.map((c, i) => {
                return (
                  <>
                    <CartSessionCard item={c} key={`cart-listing-items-${i}`}>
                      <div className="absolute top-1 right-1">
                        <MenuButton
                          title="More Options"
                          options={[
                            {
                              action: () => handleRemoveItem(c._id),
                              label: (
                                <div className="flex items-center justify-start ">
                                  <span className="pr-3">
                                    <IoRemoveCircleSharp className="text-[red]" />
                                  </span>
                                  <span className="">Remove Session</span>
                                </div>
                              ),
                            },
                            {
                              action: () =>
                                navigate(
                                  `/find-a-coach/details/${c.coachId}/sessions`
                                ),
                              label: (
                                <div className="flex items-center justify-start ">
                                  <span className="pr-3">
                                    <IoAddCircle className="text-[#3aa7a3]" />
                                  </span>
                                  <span className="">Add More Sessions</span>
                                </div>
                              ),
                            },
                          ]}
                        ></MenuButton>
                      </div>
                    </CartSessionCard>
                  </>
                );
              })}
            </div>
            <div className="col-span-full h-full md:col-span-4">
              <div className=" max-h-fit z-20 flex flex-col rounded-[10px] bg-[#013338] p-2 py-4 relative overflow-hidden">
                <div className="flex justify-center pb-8  items-center h-fit w-full gap-5 mx-auto pt-1 border-b border-white ">
                  <MundialHeadingText sizeVariant="sm" variant="white">
                    Summary
                  </MundialHeadingText>
                </div>
                <div className="flex-1">
                  {cartItems.length > 0 ? (
                    <div className="flex-1 flex flex-col justify-between text-white px-3 py-4 gap-4">
                      <table className="w-full text-left border-separate border-spacing-y-2">
                        <thead>
                          <tr className="text-sm uppercase text-white border-b border-white">
                            {/* <th className="pb-1">Coach</th> */}
                            <th className="pb-1">Session</th>
                            <th className="pb-1 text-right">Price</th>
                          </tr>
                        </thead>
                        <tbody className="min-h-[300px]">
                          {cartItems.map((item) => (
                            <tr
                              key={item._id}
                              className="bg-[#f0f0f0]  relative cursor-pointer   text-[#013338]  p-2"
                            >
                              <td
                                onClick={() =>
                                  navigate(
                                    `/find-a-coach/details/${item.coachId}/sessions`,
                                    {
                                      state: {
                                        sessionId: item.sessionId,
                                        openDetails: true,
                                      },
                                    }
                                  )
                                }
                                className="p-2 rounded-l-[10px]"
                              >
                                <div className="flex flex-col space-y-1.5">
                                  <MundialHeadingText
                                    sizeVariant="xxs"
                                    variant="darksea"
                                    className="font-medium line-clamp-1"
                                  >
                                    {item.sessionData.title}
                                  </MundialHeadingText>
                                  <span className="text-sm font-medium line-clamp-1 ">
                                    {item.coachData.name} {item.coachData.Lname}
                                  </span>
                                  <span className="text-xs font-medium ">
                                    {dayjs(item.sessionDate).format(
                                      "DD MMMM YYYY hh:mm A"
                                    )}
                                    -
                                    {dayjs(item.sessionDate)
                                      .add(1, "hour")
                                      .format("hh:mm A")}
                                  </span>
                                </div>
                              </td>
                              <td className="p-2 rounded-r-[10px] ">
                                <div className=" text-right pr-3  flex items-end justify-start h-full flex-col ">
                                  <span>
                                    {`$${item.sessionData.price?.toFixed(2)}`}
                                  </span>
                                  <div className="flex items-center justify-center absolute -top-2 -right-2">
                                    <ProvideToolTip title="Remove from cart">
                                      <IconButton
                                        sx={{
                                          p: 0,
                                        }}
                                        onClick={() =>
                                          handleRemoveItem(item._id)
                                        }
                                      >
                                        <FaTrash
                                          className="text-sm text-[#ebbd33] hover:text-[red] "
                                          size={19}
                                        />
                                      </IconButton>
                                    </ProvideToolTip>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      <div className="pt-4 border-t border-white text-sm space-y-2">
                        <div className="flex justify-between">
                          <span>Subtotal</span>
                          <span>
                            ${getCartSummary(cartItems).subtotal.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Tax ({TAX_PERCENT}%)</span>
                          <span>
                            ${getCartSummary(cartItems).tax.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between font-semibold text-lg">
                          <span>Total</span>
                          <span>
                            ${getCartSummary(cartItems).total.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-white text-center py-10">
                      Your cart is empty.
                    </div>
                  )}
                </div>
                {cartItems.length > 0 && (
                  <div className="flex justify-center  items-center h-fit w-full gap-5 mx-auto pt-5 ">
                    <YellowButton
                      className="hover:border-[#ebbd33]"
                      text="Proceed to checkout"
                      loading={loadingPaymentPage}
                      onClick={() => handlecheckout()}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col justify-center items-center min-w-full min-h-screen space-y-5">
            <div>
              <img
                src={SessionNotFounDImage}
                alt="Coach Not Found"
                className="object-contain w-full h-full md:max-w-80 md:max-h-8max-w-80"
              />
            </div>
            <div className="w-fit h-fit">
              <Warning inline variant="red">
                You have not added any session into your cart yet.
              </Warning>
            </div>
            <YellowButton
              className="mt-7"
              text="Book A Session"
              onClick={() => navigate("/find-a-coach/list")}
            ></YellowButton>
          </div>
        )}
        {/* //old design  */}
        <div className="hidden flex-col space-y-3">
          {cartItems.length > 0 && (
            <div className="flex justify-end items-center w-full gap-5 mx-auto pt-5 ">
              <PrimaryYellowButton
                text="Proceed to checkout"
                loading={loadingPaymentPage}
                onClick={() => handlecheckout()}
              />
            </div>
          )}
          <div className="flex flex-col justify-center items-center w-full  gap-5 mx-auto py-5">
            {cartItems.map((c: CartItem_Type, i: number) => {
              return (
                <>
                  <div
                    key={i}
                    className="session-card flex flex-col gap-2 custom-shadow w-full relative pt-8 md:pt-4 px-4 pb-4"
                  >
                    <div className="flex absolute top-0 right-0 p-2">
                      <Button
                        variant="outlined"
                        startIcon={<DeleteIcon />}
                        onClick={() => handleRemoveItem(c._id)}
                        sx={{
                          color: "white",
                          backgroundColor: "red",
                          borderColor: "red",
                          borderRadius: "20px",
                          fontFamily: "Quicksand",
                          paddingX: "10px",
                          paddingY: "2px",
                          transition: "all 0.3s ease-in-out",
                          "&:hover": {
                            borderColor: "red",
                            backgroundColor: "red",
                            transform: "scale(1.05)",
                            boxShadow: "0 4px 10px rgba(255, 0, 0, 0.5)",
                          },
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                    <NavLink
                      to={`/find-a-coach/details/${c.coachData._id}`}
                      className="flex gap-3 items-center cursor-pointer"
                    >
                      <span>
                        <Avatar
                          src={`${backendURL}/usersProfile/${c.coachData.image}`}
                        />
                      </span>
                      <p className="text-base font-semibold">
                        {c.coachData.name}&nbsp;{c.coachData.Lname}
                      </p>
                    </NavLink>
                    <div className="flex items-center justify-between md:justify-start w-full gap-5">
                      <p className="text-sm  font-semibold">
                        {moment(c.sessionDate)
                          .tz(userTimeZone)
                          .format("DD-MM-YYYY hh:mm A")}
                        -
                        {moment(c.sessionDate)
                          .tz(userTimeZone)
                          .add(1, "hours")
                          .format(" hh:mm A")}
                      </p>
                      {/* <span className="text-white">
                  <Button
                    variant="outlined"
                    startIcon={<EditIcon />}
                    sx={{
                      color: "white",
                      backgroundColor: "#EBBE34",
                      borderColor: "#EBBE34",
                      borderRadius: "20px",
                      fontFamily: "Quicksand",
                      paddingX: "10px",
                      paddingY: "2px",
                      "&:hover": {
                        borderColor: "#3aa7a3",
                        backgroundColor: "#3aa7a3",
                      },
                    }}
                  >
                    Change
                  </Button>
                </span> */}
                    </div>
                    <div className="title flex">
                      <h1 className="text-2xl font-semibold">
                        {c.sessionData.title}
                      </h1>
                    </div>
                    <div className="flex">
                      <p className="font-semibold">
                        {c.sessionData.currencySymbol}
                        {c.sessionData.price}
                      </p>
                    </div>
                    <div className="flex">
                      <p>{c.sessionData.description}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() =>
                          navigate(
                            `/find-a-coach/details/${c.coachData._id}/sessions`,
                            {
                              state: {
                                openDetails: true,
                                sessionId: c.sessionId,
                              },
                            }
                          )
                        }
                      >
                        <p
                          className="cursor-pointer text-sm underline font-semibold"
                          style={{ color: "#EBBE34" }}
                        >
                          View Details
                        </p>
                      </button>
                      <Link
                        to={`/find-a-coach/details/${c.coachData._id}/sessions`}
                      >
                        <p
                          className="cursor-pointer text-sm underline font-semibold"
                          style={{ color: "#EBBE34" }}
                        >
                          Add More session
                        </p>
                      </Link>
                    </div>
                  </div>
                </>
              );
            })}

            {cartItems.length == 0 && (
              <div className="flex flex-col gap-4 w-full justify-center items-center min-h-[25rem]">
                <span>
                  <img
                    src={SessionNotFounDImage}
                    alt="Coach Not Found"
                    className="object-contain w-full h-full md:max-w-96 md:max-h-96"
                  />
                </span>
                <span>No items in the cart !</span>
              </div>
            )}
          </div>
        </div>
      </XSpace>
      <Community />
    </>
  );
};

export default Cart;
