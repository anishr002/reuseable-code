import { ReactNode } from "react";
import Paragraph from "../../components/UI/Paragraph";
import MundialHeadingText from "../../components/UI/MundialHeadingText";
import CartItem_Type from "../../Types/UI/CartItem_Type";
import dayjs from "dayjs";
import { Link } from "react-router-dom";
import { Avatar } from "@mui/material";
import backendURL from "../../util/AxiosAPI";
import { FaClock } from "react-icons/fa";
import { useSelector } from "react-redux";
import { RootState } from "../../lib/store";

export interface CaProps {
  item: CartItem_Type;
  cardProps?: Omit<React.HTMLAttributes<HTMLDivElement>, "className">;
  children?: ReactNode;
}

const CartSessionCard: React.FC<CaProps> = ({ item, cardProps, children }) => {
  const loginUserData = useSelector((state: RootState) => state.login.userdata);
  return (
    <>
      <div
        {...cardProps}
        className="flex flex-1 flex-col rounded-[10px] cart-item-card relative"
      >
        {children}
        <div className=" col-span-1 w-full h-full grid grid-cols-1 md:grid-cols-12 rounded-[10px] bg-[#f0f0f0] min-h-[270px] overflow-hidden hover:shadow-sm  border border-transparent hover:border-[#3aa7a3] transition-all duration-300 ease-in-out">
          <div className="col-span-9 flex flex-col items-start justify-between p-[30px] space-y-6">
            <MundialHeadingText className="text-[18px] md:text-[22px] text-[#013338]">
              {item.sessionData.title || "Session Title"}
              <div className="text-sm font-medium text-[#013338]">
                <>
                  <FaClock className="inline mr-1 font-semibold text-xl text-[#3aa7a3]" />
                </>{" "}
                {`${dayjs(item.sessionDate)
                  .tz(loginUserData?.timeZone || dayjs.tz.guess())
                  .format("DD MMMM YYYY")}, From ${dayjs(item.sessionDate)
                  .tz(loginUserData?.timeZone || dayjs.tz.guess())
                  .format("hh:mmA")} to ${dayjs(item.sessionDate)
                  .tz(loginUserData?.timeZone || dayjs.tz.guess())
                  .add(1, "hour")
                  .format("hh:mmA")}`}
              </div>
              <div
                className={`h-fit py-4 font-normal text-sm rounded-[100px] whitespace-nowrap flex md:hidden w-fit items-center justify-center leading-0  px-5 min-w-fit border  ${
                  item.sessionData.type === 1
                    ? "border-[#3aa7a3] text-[#3aa7a3]"
                    : "bg-[#3aa7a3] text-white border-transparent"
                } `}
              >
                {item.sessionData.type === 1
                  ? "Free"
                  : `${item.sessionData.currencySymbol} ${item.sessionData.price}`}
              </div>
            </MundialHeadingText>
            <div
              className={`flex-1 text-left overflow-hidden text-[#013338] font-medium text-[16px] md:text-[18px]`}
            >
              <Paragraph lines={3}>{item.sessionData.description}</Paragraph>
            </div>
            <div className="flex flex-row justify-start items-center">
              <Link
                to={`/find-a-coach/details/${item.coachData._id}`}
                className="flex gap-3 items-center cursor-pointer"
              >
                <div>
                  <Avatar
                    src={`${backendURL}/usersProfile/${item.coachData.image}`}
                  />
                </div>
                <MundialHeadingText sizeVariant="sm" variant="seablue">
                  {item.coachData.name}&nbsp;{item.coachData.Lname}
                </MundialHeadingText>
              </Link>
            </div>
          </div>
          <div className="col-span-3 hidden md:flex flex-col items-end md:items-start justify-between pt-[30px] pr-[30px] md:p-[30px]">
            <div
              className={`h-[45px] font-bold rounded-[100px] whitespace-nowrap flex items-center justify-center leading-normal px-5 min-w-fit border  ${
                item.sessionData.type === 1
                  ? "border-[#3aa7a3] text-[#3aa7a3]"
                  : "bg-[#3aa7a3] text-white border-transparent"
              } `}
            >
              {item.sessionData.type === 1
                ? "Free"
                : `${item.sessionData.currencySymbol} ${item.sessionData.price}`}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CartSessionCard;
