import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import React, { useEffect, useRef, useState } from "react";
import usePageScrollAndTitle from "../../components/hooks/usePageScrollAndTitle";
import XSpace from "../../components/wrappers/XSpace";
import { faqOptions, FAQs_Type, faqsOptionsArray } from "../../Options/Faqs";
import { Navigation } from "../../Layouts/ConnectYouNewWebLayout";
import useScreenSize from "../../components/hooks/useScreenSize";
import CharSearchField from "../../components/UI/CharSearchField";
import scrollToTop from "../../util/scrollToTop";
import { FooterSection } from "../../Layouts/ConnectYouNewWebLayout";
import { useLocation } from "react-router-dom";

enum FaqsType {
  General = "General",
  Coach = "Coach",
  About = "About",
}

const faqsTypeOptions = Object.values(FaqsType).map((value) => ({
  label: value,
  value: value,
}));

const FaqPage = () => {
  usePageScrollAndTitle({
    title: `FAQ - Connect You`,
  });

  const [activeTab, setActiveTab] = useState<FaqsType>(FaqsType.General);
  const [searchName, setSearchName] = useState("");
  const mainAreaRef = useRef<HTMLDivElement | null>(null);
  const headerRef = useRef<HTMLDivElement | null>(null);
  const { isMobile, isTab } = useScreenSize();
  const [headerHeight, setHeaderHeight] = useState(0);
  useEffect(() => {
    if (headerRef && headerRef.current) {
      setHeaderHeight(headerRef.current.scrollHeight);
    }
  }, [headerRef]);

  const handleActiveTab = (tab: FaqsType) => {
    setSearchName("");
    setActiveTab(tab);
  };
  const filteredFaqs = faqsOptionsArray.filter((faq) => {
    const searchWords = searchName.toLowerCase();
    const questionWords = faq.question.toLowerCase();
    const answerWords = faq.answer.toLowerCase();
    return (
      questionWords.includes(searchWords) || answerWords.includes(searchWords)
    );
  });

  const location = useLocation();

  useEffect(() => {
    if (location.state) {
      if (location.state.open) {
        const { open, ...rest } = location.state;
        setSearchName(open);
        window.history.replaceState(
          { ...rest },
          "",
          window.location.pathname + window.location.search
        );
      }
    }
  }, [location.state]);

  useEffect(() => {
    const key = searchName;
    const active = faqOptions.faqsGeneralOptions
      .map((a) => a.question)
      .includes(key)
      ? FaqsType.General
      : faqOptions.coachFaqOptions.map((a) => a.question).includes(key)
      ? FaqsType.Coach
      : faqOptions.aboutConnectYouOptions.map((a) => a.question).includes(key)
      ? FaqsType.About
      : FaqsType.General;
    setActiveTab(active);
  }, [searchName]);

  return (
    <div className="w-full h-screen overflow-hidden">
      <React.Fragment>
        <div className="w-full h-screen overflow-hidden flex flex-col justify-start items-start">
          <div
            ref={mainAreaRef}
            className="flex flex-col w-full h-full  overflow-y-auto style-scroll  "
          >
            <div className="flex flex-col justify-start items-start w-full min-h-[fit] bg-white ">
              <div
                ref={headerRef}
                className="w-full flex flex-col  sticky top-0 z-[100] "
              >
                <Navigation />
                <div className="w-full bg-white py-4 flex flex-row justify-end items-center px-4">
                  <CharSearchField
                    handleSerach={(str: string) => {
                      setSearchName(str);
                    }}
                  />
                </div>
              </div>
              <XSpace>
                <div className="grid grid-cols-1 lg:grid-cols-12 w-full h-fit">
                  <div
                    className={` col-span-3 w-full lg:min-h-[400px] z-[90]  bg-white  sticky overflow-y-auto style-scroll style-scroll-thin  `}
                    style={{
                      top: `${headerHeight}px`,
                      height:
                        isMobile || isTab
                          ? "fit-content"
                          : `calc(100vh - ${headerHeight}px)`,
                    }}
                  >
                    <div className="flex flex-col w-full h-full  custom-shadow gap-3  bg-white z-20 lg:pt-10 lg:pb-5 ">
                      <div className="flex items-center w-full">
                        <h1 className="custom-text-color3 font-semibold text-2xl">
                          Frequently Asked Question
                        </h1>
                      </div>
                      <div className="flex w-full flex-col gap-3 px-3 ">
                        <div className="grid grid-cols-3 lg:grid-cols-1 gap-3 ">
                          {faqsTypeOptions.map((faqT, i) => (
                            <div
                              key={`faq-type-${faqT.label}-item-${i}`}
                              className="text-base col-span-1 flex justify-center md:justify-start items-center"
                            >
                              <button
                                type="button"
                                onClick={() => {
                                  scrollToTop(mainAreaRef);
                                  handleActiveTab(faqT.value);
                                }}
                                className={`py-2 px-4 cursor-pointer transition-all duration-300 ${
                                  activeTab === faqT.value
                                    ? "text-[#ebbd33] font-mundial font-bold border-b-2 border-[#ebbd33]"
                                    : "text-[#013338] hover:text-[#ebbd33] border-b-2 border-transparent"
                                }`}
                              >
                                {faqT.label}
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className=" col-span-9 w-full flex flex-col justify-start items-center min-h-screen">
                    <div className=" flex flex-col w-full gap-2 pt-10 md:pt-0 ">
                      {searchName !== "" ? (
                        <>
                          {filteredFaqs.length > 0 ? (
                            <RenderFaqListing faqs={filteredFaqs} />
                          ) : (
                            <div className=" w-full h-[20rem] flex justify-center items-center">
                              <p className="md:w-1/2 w-10/12 text-[red]">
                                Your Search didn't match any of the FAQ ! Please
                                adjust the search to see results
                              </p>
                            </div>
                          )}
                        </>
                      ) : (
                        <RenderFaqListing
                          faqs={
                            activeTab === FaqsType.General
                              ? faqOptions.faqsGeneralOptions
                              : activeTab === FaqsType.Coach
                              ? faqOptions.coachFaqOptions
                              : faqOptions.aboutConnectYouOptions
                          }
                        />
                      )}
                    </div>
                  </div>
                </div>
              </XSpace>
            </div>
            <div className="w-full flex flex-col justify-start items-center ">
              <FooterSection />
            </div>
          </div>
        </div>
      </React.Fragment>
    </div>
  );
};

export default FaqPage;

const RenderFaqListing = ({ faqs }: { faqs: FAQs_Type[] }) => {
  const [open, setOpen] = useState<string | null>(null);
  const location = useLocation();
  useEffect(() => {
    console.log(location.state);
    if (location.state) {
      setOpen(location?.state?.open);
    }
  }, [location.state]);

  return (
    <>
      {faqs.map((data, i) => {
        return (
          //i < 2 ||
          <Accordion
            defaultExpanded={open ? data.question === open : i < 2}
            key={`faq-acccording-item-${data.question}-${i}`}
          >
            <AccordionSummary
              expandIcon={
                <ExpandMoreIcon
                  sx={{
                    color: "#013338",
                  }}
                />
              }
              aria-controls="panel1-content"
              id="panel1-header"
            >
              <Typography
                id={data.question}
                sx={{
                  color: "#013338",
                  fontWeight: "bold",
                  fontFamily: "Quicksand",
                }}
              >
                {data.question}
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography
                sx={{
                  fontFamily: "Quicksand",
                }}
              >
                {data.answer}
              </Typography>
            </AccordionDetails>
          </Accordion>
        );
      })}
    </>
  );
};
