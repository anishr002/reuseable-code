/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import Logo from "/loginLogo.png";
import ClearIcon from "@mui/icons-material/Clear";
import MUIAutocomplete from "@mui/material/Autocomplete";
import dayjs from "dayjs";
import AddBoxIcon from "@mui/icons-material/AddBox";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import {
  Box,
  Button,
  Checkbox,
  CircularProgress,
  createTheme,
  IconButton,
  Modal,
  Radio,
  TextField,
  ThemeProvider,
  Tooltip,
  Typography,
} from "@mui/material";
import { LocalizationProvider, TimePicker } from "@mui/x-date-pickers";
import { useEffect, useState } from "react";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { Dayjs } from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { useForm } from "react-hook-form";
import usePageScrollAndTitle from "../../../../components/hooks/usePageScrollAndTitle";
import { useNotify } from "../../../../lib/Notify";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import { YellowButton } from "../../../../components/buttons/ThemeButtons";
import ModalCloseButton from "../../../../components/buttons/ModalCloseButton";
import { FaAngleDown } from "react-icons/fa";
import CreatePageHeading, {
  HeadingText,
} from "../../../../contexts/context-hooks/useCreateHeading";
import WeeklyAvailabilitySkeleton from "../../../../components/Skeletons/WeeklyAvailabilitySkeleton";

// eslint-disable-next-line @typescript-eslint/no-namespace
declare namespace Intl {
  function supportedValuesOf(key: "timeZone"): string[];
}

dayjs.extend(utc);
dayjs.extend(timezone);
interface TimeSlot {
  from: string;
  to: string;
}

type VoidFunction = () => void;
interface DayAvailability {
  id: number;
  name: string;
  unavailable: boolean;
  allday: boolean;
  availability: TimeSlot[] | null;
}

type WeekAvailability = DayAvailability[];

const Page: React.FC = () => {
  usePageScrollAndTitle({
    title: `Availability`,
  });
  // main state
  const { notifyMe } = useNotify();
  const [loadingUpdate, setLoadingUpdate] = useState<boolean>(false); //updating the user data.
  const [loading, setLoading] = useState(false); // loading
  const [pageUpdated, setPageUpdated] = useState(false); // loading
  const [coachTimeZone, setTimeZone] = useState("");
  // user data state for his week availability
  const [weekAvailability, setWeekAvailability] = useState<WeekAvailability>([
    {
      id: 0,
      name: "sunday",
      unavailable: true,
      allday: false,
      availability: [],
    },
    {
      id: 1,
      name: "monday",
      unavailable: true,
      allday: false,
      availability: [],
    },
    {
      id: 2,
      name: "tuesday",
      unavailable: true,
      allday: false,
      availability: [],
    },
    {
      id: 3,
      name: "wednesday",
      unavailable: true,
      allday: false,
      availability: [],
    },
    {
      id: 4,
      name: "thursday",
      unavailable: true,
      allday: false,
      availability: [],
    },
    {
      id: 5,
      name: "friday",
      unavailable: true,
      allday: false,
      availability: [],
    },
    {
      id: 6,
      name: "saturday",
      unavailable: true,
      allday: false,
      availability: [],
    },
  ]);

  const [repeatAvailibility, setRepeatAvailibility] = useState(false); // state to save repeat aval. option
  const [openInstructions, setOpenInstructions] = useState<boolean>(false);
  const toggleInstructionModal = (boolean: boolean) => {
    setOpenInstructions(boolean);
  };

  const [allDayTimeSlot, setAllDayTimeSlot] = useState({
    from: "",
    to: "",
  });
  /////////////fetchings////////////
  const fetchAvailabilityData = async () => {
    setLoading(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/availability/coachAvailability-data`
      );
      if (response.data.coachTimeZone) {
        setTimeZone(response.data.coachTimeZone);
        setcoachTimeZone("timeZone", response.data.coachTimeZone);
      }
      if (!response.data.data) {
        // console.log("now", response.data.data);
        return toggleInstructionModal(true);
      }
      localStorage.setItem(
        "weekAvailability",
        JSON.stringify(response.data.data?.availability)
      );
      if (response.data.data.allDayTimeSlot) {
        setAllDayTimeSlot(response.data.data.allDayTimeSlot);
      }

      // console.log(response.data.data.allDayTimeSlot);
      if (response.data.data.repeatAvailibility) {
        setRepeatAvailibility(response.data.data.repeatAvailibility);
      }
      if (response.data.data.availability) {
        const availabilityArray = response.data.data.availability;
        if (availabilityArray.length > 0) {
          setWeekAvailability(response.data.data.availability);
        }
      }
    } catch (error) {
      console.log(error);
      notifyMe({ severity: "error", message: "Something went wrong" });
    } finally {
      setLoading(false);
    }
  };

  const onUpdateAvailability = async () => {
    if (allDayTimeSlot.from === "" || allDayTimeSlot.to === "") {
      return toggleInstructionModal(true);
    }
    setLoading(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/availability/coachAvailability-add`,
        {
          availability: weekAvailability,
          repeatAvailibility: repeatAvailibility,
        }
      );
      if (response.status === 200) {
        notifyMe({
          message: "Availability updated successfully",
          severity: "success",
        });
        setHasChanges(false);
        setPageUpdated(!pageUpdated);
        return setLoading(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
        setHasChanges(false);
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAvailabilityData();
  }, [pageUpdated]);

  const [hasChanges, setHasChanges] = useState<boolean>(false);

  useEffect(() => {
    const oldData = localStorage.getItem("weekAvailability");
    const parsedOldData = oldData ? JSON.parse(oldData) : null;
    const isEqual =
      JSON.stringify(parsedOldData) === JSON.stringify(weekAvailability || {});
    setHasChanges(!isEqual);
  }, [weekAvailability]);

  //////////////////////////
  const toggleUnavailable = (dayId: number) => {
    setWeekAvailability((prevAvailability) =>
      prevAvailability.map((day) =>
        day.id === dayId
          ? {
              ...day,
              unavailable: !day.unavailable,
              allday: false,
              availability: [],
            }
          : day
      )
    );
  };

  const setAllDayAvailability = (dayId: number, isAllDay: boolean) => {
    setWeekAvailability((prevAvailability: any) =>
      prevAvailability.map((day: any) =>
        day.id === dayId
          ? {
              ...day,
              allday: isAllDay,
              unavailable: false,
            }
          : day
      )
    );
  };

  const setAvailabilityFrom = (
    dayId: number,
    isAllDay: boolean,
    unavailable: boolean
  ) => {
    setWeekAvailability((prevAvailability) =>
      prevAvailability.map((day) =>
        day.id === dayId
          ? { ...day, allday: isAllDay, unavailable: unavailable }
          : day
      )
    );
  };

  const [fromValue, setfromValue] = useState<Dayjs | null>(null); // Change to Dayjs
  const [toValue, setToValue] = useState<Dayjs | null>(null); // Change to Dayjs
  const [currentDayId, setCurrentDayId] = useState<number | null>(null); // Track current day ID

  const addTimeSlot = (dayId: number) => {
    if (!fromValue || !toValue) {
      notifyMe({
        message:
          "Please select both 'From' and 'To' time for creating a Availibility Time Slot",
        severity: "warning",
      });
      return;
    }

    const selectedFromTime = fromValue.format("HH:mm");
    const selectedToTime = toValue.format("HH:mm");

    // Check that the "To" time is greater than the "From" time
    if (selectedToTime <= selectedFromTime) {
      notifyMe({
        message: "The Time slot must be within the same day.",
        severity: "warning",
      });
      return; // Do not proceed if the time range crosses over to the next day
    }

    // Check if the selected time range overlaps with any existing time slots for the day
    const day = weekAvailability.find((d) => d.id === dayId);
    if (day) {
      const isOverlapping =
        day.availability &&
        day.availability.some((slot) => {
          return (
            (selectedFromTime >= slot.from && selectedFromTime < slot.to) || // New start time overlaps with existing slot
            (selectedToTime > slot.from && selectedToTime <= slot.to) || // New end time overlaps with existing slot
            (selectedFromTime <= slot.from && selectedToTime >= slot.to) // New slot fully encompasses existing slot
          );
        });

      if (isOverlapping) {
        notifyMe({
          message:
            "The selected time overlaps with an existing time slot. Please choose a different time range.",
          severity: "warning",
        });
        return; // Do not proceed further if there is an overlap
      }
    }

    setAvailabilityFrom(dayId, false, false);
    setWeekAvailability((prevAvailability) =>
      prevAvailability.map((day) =>
        day.id === dayId
          ? {
              ...day,
              availability: [
                ...(day.availability || []),
                {
                  from: selectedFromTime,
                  to: selectedToTime,
                },
              ],
            }
          : day
      )
    );

    setfromValue(null);
    setToValue(null);
    setOpenModal(false);
  };

  const removeTimeSlot = (dayId: number, slotIndex: number) => {
    setWeekAvailability((prevAvailability: any) =>
      prevAvailability.map((day: any) =>
        day.id === dayId
          ? {
              ...day,
              availability: day.availability?.filter(
                (_: any, index: number) => index !== slotIndex
              ),
            }
          : day
      )
    );
  };

  const [alldayFromVal, setAllDayFromVal] = useState<string>(
    allDayTimeSlot.from
  );
  const [alldayToVal, setAllDayToVal] = useState<string>(allDayTimeSlot.to);

  const handleAllDayTimeSlot = async () => {
    if (alldayToVal === "" || alldayFromVal === "") {
      return notifyMe({
        message: `Please complete all fields !`,
        severity: "warning",
      });
    }
    if (alldayToVal < alldayFromVal) {
      return notifyMe({
        message: "Please select a time slot range within the same day",
        severity: "warning",
      });
    }
    setAllDayTimeSlot({
      from: alldayFromVal,
      to: alldayToVal,
    });
    setLoading(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/availability/coachAvailability-add`,
        {
          allDayTimeSlot: {
            from: alldayFromVal,
            to: alldayToVal,
          },
        }
      );
      if (response.status === 200) {
        setAllDayTimeSlotModal(false);
        setLoading(false);
        toggleInstructionModal(false);
        notifyMe({
          message: "Your All Day Time Slot Has been Updated !",
          severity: "success",
        });
        setPageUpdated(!pageUpdated);
        return setLoading(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  };

  // timezone modal and control timezone settings /////////////
  function getTimeZones() {
    return Intl.supportedValuesOf("timeZone");
  }
  const timeZones = getTimeZones();
  type TimzoneFormValues = {
    timeZone: string;
  };
  //  modal for title line controls
  const {
    register: registerTimeZone,
    handleSubmit: handleSubmitTimeZone,
    formState: { errors: errorsTimeZone },
    setValue: setcoachTimeZone,
  } = useForm<TimzoneFormValues>({
    mode: "onSubmit",
  });
  type Timezone = {
    timeZone: string;
  };

  const onSubmitTimezone = async (data: Timezone) => {
    setLoading(true);
    setLoadingUpdate(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-more`,
        { timeZone: data.timeZone }
      );
      if (response.status === 200) {
        setLoadingUpdate(false);
        setOpenTimeZoneModal(false);
        notifyMe({
          message: "Timezone updated successfully",
          severity: "success",
        });
        setPageUpdated(!pageUpdated);
        return setLoading(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  };
  // modals and theirs states

  // timeozne modal
  const [openTimeZoneModal, setOpenTimeZoneModal] = useState<boolean>(false);
  const renderTimeZoneModal = () => {
    return (
      <>
        <CustomModalWrapper
          open={openTimeZoneModal}
          onClose={() => setOpenTimeZoneModal(false)}
          title="Update Preferred Timezone"
          children={
            <div className="flex flex-col w-full gap-8">
              <form
                onSubmit={handleSubmitTimeZone(onSubmitTimezone)}
                className="flex w-full flex-col gap-3"
              >
                <div className="flex flex-col w-full gap-3  justify-center items-center">
                  <div className="w-full font-medium text-base py-1 text-[#013338] ">
                    Select the timezone of your preference and click on the
                    "Save" button.
                  </div>
                  <MUIAutocomplete
                    fullWidth
                    size="small"
                    id="tags-outlined"
                    options={timeZones}
                    freeSolo
                    defaultValue={coachTimeZone}
                    filterSelectedOptions
                    color="inherit"
                    sx={{
                      "& .MuiAutocomplete-listbox": {
                        color: "#013338", // Color for list items
                      },
                      ".css-odv3gu-MuiAutocomplete-listbox": {
                        color: "#013338", // Color for list items
                      },
                      "MuiAutocomplete-option": {
                        color: "#013338", // Color for list items
                      },
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Timezone"
                        placeholder="Please Select Your Timezone"
                        sx={{
                          background: "white",
                          "& .MuiOutlinedInput-root": {
                            color: "#3aa7a3",
                            "& fieldset": { borderColor: "#3aa7a3" }, // Default border color
                            "&:hover fieldset": { borderColor: "#3aa7a3" }, // Hover border color
                            "&.Mui-focused fieldset": {
                              borderColor: "#3aa7a3",
                            }, // Focus border color
                          },
                          "& .MuiInputLabel-root": {
                            color: "#3aa7a3", // Label color
                            "&.Mui-focused": { color: "#3aa7a3" }, // Focused label color
                          },
                          "& .MuiAutocomplete-popupIndicator": {
                            color: "#3aa7a3", // Dropdown arrow color
                          },
                        }}
                        {...registerTimeZone("timeZone", {
                          required: "Timezone is required",
                          validate: (value) => {
                            return (
                              timeZones.includes(value) ||
                              "Please select a valid timezone from the list."
                            );
                          },
                        })}
                        error={!!errorsTimeZone.timeZone}
                        helperText={errorsTimeZone.timeZone?.message}
                        FormHelperTextProps={{
                          style: { marginLeft: 0, color: "#3aa7a3" }, // Error message color
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex w-1/2 mx-auto justify-center items-center pt-3">
                  <YellowButton
                    loading={loadingUpdate}
                    text="Save"
                    type="submit"
                  />
                </div>
              </form>
            </div>
          }
        />
      </>
    );
  };
  // timezone modal ending here
  // all day time zolt seelction modal
  const [openAllDayTimeSlotModal, setAllDayTimeSlotModal] = useState(false);
  const toggleAllDatTimeSlot: VoidFunction = () => {
    setAllDayTimeSlotModal(!openAllDayTimeSlotModal);
  };

  const renderAllDayTimeSlotModal = () => {
    return (
      <>
        <CustomModalWrapper
          title="Select Full Day Available Time"
          open={openAllDayTimeSlotModal}
          onClose={() => {
            setAllDayTimeSlotModal(false);
          }}
          children={
            <div className="flex flex-col w-full gap-5 py-2  justify-center items-center">
              <div className="w-full font-medium text-base py-1 text-[#013338] ">
                Please select your preferred time range. Kindly note that this
                time range will be used to generate the available time slots for
                booking sessions on the selected day, with availability
                considered for the entire day.
                <hr className="w-full h-1 text-gray-200 my-4" />
              </div>

              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DemoContainer components={["TimePicker", "TimePicker"]}>
                  <div className="flex flex-col gap-4 justify-center w-full">
                    <TimePicker
                      slotProps={{
                        inputAdornment: {
                          position: "start",
                        },
                      }}
                      label="From"
                      onChange={(value: any) =>
                        setAllDayFromVal(value?.format("HH:mm"))
                      }
                      className="ulstyle"
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          color: "#3aa7a3", // Text color inside the input field
                          "& fieldset": { borderColor: "#3aa7a3" }, // Default border color
                          "&:hover fieldset": { borderColor: "#3aa7a3" }, // Hover border color
                          "&.Mui-focused fieldset": { borderColor: "#3aa7a3" }, // Focused border color
                        },
                        "& .MuiInputBase-input": {
                          color: "#3aa7a3", // Input text color
                        },
                        "& .MuiFormLabel-root": {
                          color: "#3aa7a3", // Label color
                          "&.Mui-focused": { color: "#3aa7a3" }, // Focused label color
                        },
                        "& .MuiSvgIcon-root": {
                          color: "#3aa7a3", // Styles the calendar/clock icon
                        },
                        "& .MuiList-root": {
                          scrollbarWidth: "none !important", // Hide scrollbar
                        },
                      }}
                    />
                    <TimePicker
                      label="To"
                      onChange={(value: any) =>
                        setAllDayToVal(value?.format("HH:mm"))
                      }
                      slotProps={{
                        inputAdornment: {
                          position: "start",
                        },
                      }}
                      // className="ulstyle"
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          color: "#3aa7a3", // Text color inside the input field
                          "& fieldset": { borderColor: "#3aa7a3" }, // Default border color
                          "&:hover fieldset": { borderColor: "#3aa7a3" }, // Hover border color
                          "&.Mui-focused fieldset": { borderColor: "#3aa7a3" }, // Focused border color
                        },
                        "& .MuiInputBase-input": {
                          color: "#3aa7a3", // Input text color
                        },
                        "& .MuiFormLabel-root": {
                          color: "#3aa7a3", // Label color
                          "&.Mui-focused": { color: "#3aa7a3" }, // Focused label color
                        },
                        "& .MuiSvgIcon-root": {
                          color: "#3aa7a3", // Styles the calendar/clock icon
                        },
                        "& .MuiList-root": {
                          scrollbarWidth: "none !important", // Hide scrollbar
                        },
                      }}
                    />
                  </div>
                </DemoContainer>
              </LocalizationProvider>
              {allDayTimeSlot.from && allDayTimeSlot.to && (
                <div className="w-full py-4 text-center  flex-justify-center items-center">
                  <p className=" text-center text-[#3aa7a3] font-medium capitalize">
                    The time range considered for the day with availability set
                    to "All day" is From {formatdTime(allDayTimeSlot.from)} - To{" "}
                    {formatdTime(allDayTimeSlot.to)}
                  </p>
                </div>
              )}
              <div
                className="flex w-1/2 mx-auto justify-center items-center py-3"
                onClick={handleAllDayTimeSlot}
              >
                <YellowButton loading={loading} text="Save" />
              </div>
            </div>
          }
        />
      </>
    );
  };
  //ends here

  //time selection modal here //
  const [openModal, setOpenModal] = useState<boolean>(false);
  const renderModal = () => {
    if (currentDayId === null) return null;
    const day = weekAvailability.filter((d) => d.id === currentDayId)[0].name;
    return (
      <>
        <CustomModalWrapper
          open={openModal}
          title={`Update Availability${day ? ` for ${day}` : ""}`}
          onClose={() => setOpenModal(false)}
          children={
            <div className="flex flex-col w-full gap-5  justify-center items-center">
              <div className="w-full font-medium text-base py-1 text-[#013338] ">
                Please select the time range of your preference. Please note
                that the time slots for session bookings will be generated in
                between the range you provide for the specific day.{" "}
                <hr className="w-full h-1 text-gray-200 my-4" />
                <p className="w text-center text-[#3aa7a3] capitalize">
                  Adding for : {day}
                </p>
              </div>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DemoContainer components={["TimePicker", "TimePicker"]}>
                  <div className="flex flex-col gap-4 justify-center w-full">
                    <TimePicker
                      label="From"
                      value={fromValue}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          color: "#3aa7a3", // Text color inside the input field
                          "& fieldset": { borderColor: "#3aa7a3" }, // Default border color
                          "&:hover fieldset": { borderColor: "#3aa7a3" }, // Hover border color
                          "&.Mui-focused fieldset": { borderColor: "#3aa7a3" }, // Focused border color
                        },
                        "& .MuiInputBase-input": {
                          color: "#3aa7a3", // Input text color
                        },
                        "& .MuiFormLabel-root": {
                          color: "#3aa7a3", // Label color
                          "&.Mui-focused": { color: "#3aa7a3" }, // Focused label color
                        },
                        "& .MuiSvgIcon-root": {
                          color: "#3aa7a3", // Styles the calendar/clock icon
                        },
                        "& .MuiList-root": {
                          scrollbarWidth: "none !important", // Hide scrollbar
                        },
                      }}
                      slotProps={{
                        inputAdornment: {
                          position: "start",
                        },
                      }}
                      onChange={setfromValue}
                    />
                    <TimePicker
                      label="To"
                      value={toValue}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          color: "#3aa7a3", // Text color inside the input field
                          "& fieldset": { borderColor: "#3aa7a3" }, // Default border color
                          "&:hover fieldset": { borderColor: "#3aa7a3" }, // Hover border color
                          "&.Mui-focused fieldset": { borderColor: "#3aa7a3" }, // Focused border color
                        },
                        "& .MuiInputBase-input": {
                          color: "#3aa7a3", // Input text color
                        },
                        "& .MuiFormLabel-root": {
                          color: "#3aa7a3", // Label color
                          "&.Mui-focused": { color: "#3aa7a3" }, // Focused label color
                        },
                        "& .MuiSvgIcon-root": {
                          color: "#3aa7a3", // Styles the calendar/clock icon
                        },
                        "& .MuiList-root": {
                          scrollbarWidth: "none !important", // Hide scrollbar
                        },
                      }}
                      slotProps={{
                        inputAdornment: {
                          position: "start",
                        },
                      }}
                      onChange={setToValue}
                    />
                  </div>
                </DemoContainer>
              </LocalizationProvider>
              {fromValue && toValue && (
                <div className="w-full py-4 text-center  flex-justify-center items-center">
                  <p className=" text-center text-[#3aa7a3] font-medium capitalize">
                    Selected time range : From{" "}
                    {dayjs(fromValue).format("hh:mm A")} : To{" "}
                    {dayjs(toValue).format("hh:mm A")}
                  </p>
                </div>
              )}
              <div className="flex">
                <YellowButton
                  text="Add Time Slot"
                  onClick={() => addTimeSlot(currentDayId!)}
                />
              </div>
            </div>
          }
        />
      </>
    );
  };
  const theme = createTheme({
    palette: {
      primary: {
        main: "#3aa7a3",
      },
    },
    components: {
      MuiRadio: {
        styleOverrides: {
          root: {
            color: "#3aa7a3",
            "&.Mui-checked": {
              color: "#3aa7a3",
            },
          },
        },
      },
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <CreatePageHeading>
        <HeadingText> Availability </HeadingText>
      </CreatePageHeading>
      <InstructionModal
        open={openInstructions}
        fun={toggleInstructionModal}
        openAnother={toggleAllDatTimeSlot}
      />
      {renderTimeZoneModal()}
      {renderAllDayTimeSlotModal()}
      {renderModal()}
      <div className="flex flex-col justify-start items-start bg-white rounded-[5px] space-y-3.5 px-[20px] py-[30px]">
        <div className="grid grid-cols-1 md:grid-cols-2 w-full gap-2.5">
          <div className="col-span-1 flex w-full items-center justify-start">
            <MundialHeadingText
              variant="darksea"
              sizeVariant="sm"
              className="flex gap-3.5 items-center "
            >
              Availability
              {loading && (
                <CircularProgress size={18} sx={{ color: "#3aa7a3" }} />
              )}
            </MundialHeadingText>
          </div>
          {(allDayTimeSlot.from !== "" || allDayTimeSlot.to !== "") &&
            !loading &&
            hasChanges && (
              <div className="col-span-1 flex w-full items-center justify-end">
                <span className="pr-4 text-[#3aa7a3]">
                  *Please click to save the changes.{" "}
                </span>
                <span onClick={() => onUpdateAvailability()} className="w-fit">
                  <YellowButton
                    loading={loadingUpdate}
                    type="button"
                    className="w-fit px-8 sm:w-fit md:w-fit lg:w-fit"
                    text="Save"
                  />
                </span>
              </div>
            )}
        </div>
        {(allDayTimeSlot.from !== "" || allDayTimeSlot.to !== "") &&
          hasChanges && (
            <div className="hidden pl-10 text-xs text-red-600 text-left font-medium">
              *Please Click the save button to save the changes.{" "}
            </div>
          )}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-[18px] w-full">
          <div className="col-span-1 flex flex-col gap-4 justify-between  py-1  w-full">
            <div className="flex md:flex-row flex-col justify-start md:items-center items-start text-sm font-medium text-[#013338]">
              Select the timezone of your preference.
            </div>
            <div
              onClick={() => setOpenTimeZoneModal(true)}
              className="  cursor-pointer border py-2 border-[#3aa7a3] relative max-w-[260px] w-full px-6  mr-3 flex justify-between items-center gap-1 bg-white rounded-[5px] text-sm font-medium"
            >
              <span className="text-[#3aa7a3]">
                {coachTimeZone
                  ? coachTimeZone
                  : "Select Your Preferred Timezone"}
              </span>
              <span className="cursor-pointer   text-[#3aa7a3] flex justify-center items-center">
                <FaAngleDown color="inherit" />
              </span>
            </div>
          </div>
          <div className="col-span-1 flex flex-col gap-4 justify-between  py-1  w-full">
            <div className="flex md:flex-row flex-col justify-start md:items-center items-start text-sm font-medium text-[#013338]">
              Set Full Day Time Slot{" "}
            </div>
            <div
              onClick={() => {
                setAllDayTimeSlotModal(true);
              }}
              className="  cursor-pointer border py-2 border-[#3aa7a3] relative  max-w-[260px] w-full px-6  mr-3 flex justify-between items-center gap-1 bg-white rounded-[5px] text-sm font-medium"
            >
              <span className="text-[#3aa7a3]">
                {allDayTimeSlot.from !== "" && allDayTimeSlot.to !== "" ? (
                  <>
                    From:{" "}
                    <span>{convertTo12HourFormat(allDayTimeSlot.from)}</span>{" "}
                    to: <span>{convertTo12HourFormat(allDayTimeSlot.to)}</span>
                  </>
                ) : (
                  <span>Select a Full Day Time Slot</span>
                )}
              </span>
              <span className="cursor-pointer   text-[#3aa7a3] flex justify-center items-center">
                <FaAngleDown color="inherit" />
              </span>
            </div>
          </div>
        </div>
        {loading ? (
          <WeeklyAvailabilitySkeleton />
        ) : (
          <>
            <div
              className="w-full overflow-auto style-scroll style-scroll-thin "
              style={{ scrollbarWidth: "thin" }}
            >
              <div className=" w-full   min-w-fit">
                {allDayTimeSlot.from !== "" ? (
                  <table className="min-w-full ">
                    <thead>
                      <tr>
                        <th className="w-1/12 px-4 py-1  text-left text-sm font-semibold text-[#013338]">
                          Day
                        </th>
                        <th className="w-1/12 px-4 py-1  text-left text-sm font-semibold text-[#013338]">
                          Unavailable
                        </th>
                        <th className="w-1/12 px-4 py-1 whitespace-nowrap  text-left text-sm font-semibold text-[#013338]">
                          Full-Day
                        </th>
                        <th className="w-1/12 px-4 py-1  text-left text-sm font-semibold text-[#013338]">
                          From
                        </th>
                        <th className="w-8/12 px-4 py-1  text-left text-sm font-semibold text-[#013338]">
                          Time Slots
                        </th>
                      </tr>
                    </thead>
                    <tbody style={{ rowGap: "14px" }} className="space-y-2">
                      {weekAvailability.map((day) => (
                        <tr
                          key={day?.id}
                          className="hover:bg-gray-50 bg-[#f5f5f5] rounded-[5px] border-7 border-transparent border-b-white"
                        >
                          <td className="px-4 py-1  text-[#013338] font-semibold text-base capitalize">
                            {day.name}
                          </td>
                          <td className="px-4 py-1  text-[#3aa7a3] font-semibold text-base">
                            {/* <Tooltip title={`Set ${day.name} as unavailable`}> */}
                            <Radio
                              sx={{
                                color: "#3aa7a3",
                                ".css-1w8ljni-MuiButtonBase-root-MuiRadio-root.Mui-checked":
                                  {
                                    color: "#3aa7a3",
                                  },
                              }}
                              onChange={() => toggleUnavailable(day.id)}
                              checked={day.unavailable}
                              name={`unavailable-${day.id}`}
                            />
                            {/* </Tooltip> */}
                          </td>
                          <td className="px-4 py-1  text-[#3aa7a3] font-semibold text-base">
                            {/* <Tooltip
                              title={`Set Available all-day for  ${day.name}`}
                            > */}
                            <Radio
                              sx={{
                                color: "#3aa7a3",
                                ".css-1w8ljni-MuiButtonBase-root-MuiRadio-root.Mui-checked":
                                  {
                                    color: "inherit",
                                  },
                              }}
                              onChange={() =>
                                setAllDayAvailability(day.id, !day.allday)
                              }
                              checked={day.allday}
                              name={`allday-${day.id}`}
                            />
                            {/* </Tooltip> */}
                          </td>
                          <td className="px-4 py-1  text-[#3aa7a3] font-semibold text-base">
                            <Radio
                              sx={{
                                color: "#3aa7a3",
                                ".css-1w8ljni-MuiButtonBase-root-MuiRadio-root.Mui-checked":
                                  {
                                    color: "inherit",
                                  },
                              }}
                              onChange={() => {
                                setCurrentDayId(day.id); // Set the current day ID for the modal
                                setOpenModal(true);
                              }}
                              checked={!day.allday && !day.unavailable}
                              name={`available-${day.id}`}
                            />
                          </td>
                          <td className="px-4 py-1  text-[#013338] font-semibold text-base">
                            <div className="flex flex-row justify-between items-center px-2 w-full">
                              <div className="w-[calc(100% - 20px)] flex flex-row justify-start items-center gap-2 flex-wrap">
                                {day.unavailable ? (
                                  <div className="w-fit px-2 flex justify-start items-center gap-1  rounded-xl text-sm font-medium">
                                    You have marked yourself{" "}
                                    <strong>unavailable</strong> for {day.name}
                                  </div>
                                ) : (
                                  <>
                                    {day.allday ? (
                                      <div className="relative w-fit px-3 mr-3  gap-1  rounded-xl text-sm font-medium">
                                        You Have Selected{" "}
                                        <strong>
                                          Full day availability (
                                          {allDayTimeSlot
                                            ? convertTo12HourFormat(
                                                allDayTimeSlot.from
                                              ) +
                                              " - " +
                                              convertTo12HourFormat(
                                                allDayTimeSlot.to
                                              )
                                            : ""}
                                          )
                                        </strong>{" "}
                                        for {day.name?.toUpperCase()}
                                      </div>
                                    ) : (
                                      <>
                                        {day.availability &&
                                        day.availability.length > 0 ? (
                                          day.availability.map((time, i) => (
                                            <div
                                              key={i}
                                              className="relative w-fit px-3 mr-3 flex justify-start items-center gap-1  rounded-xl  text-sm font-medium"
                                            >
                                              From{" "}
                                              <span className="text-[#3aa7a3]  bg-white border border-[#3aa7a3] rounded-[5px] px-3 py-1">
                                                {convertTo12HourFormat(
                                                  time.from
                                                )}
                                              </span>{" "}
                                              {" to "}
                                              <span className="text-[#3aa7a3]  bg-white border border-[#3aa7a3] rounded-[5px] px-3 py-1">
                                                {convertTo12HourFormat(time.to)}
                                              </span>
                                              {!day.allday && (
                                                <Tooltip
                                                  title="Remove"
                                                  children={
                                                    <IconButton
                                                      onClick={() =>
                                                        removeTimeSlot(
                                                          day.id,
                                                          i
                                                        )
                                                      }
                                                      sx={{
                                                        color: "red",
                                                        position: "absolute",
                                                        top: -5,
                                                        right: -2,
                                                        p: 0,
                                                      }}
                                                    >
                                                      <ClearIcon
                                                        color="inherit"
                                                        sx={{
                                                          fontSize: "0.75rem",
                                                        }}
                                                      />
                                                    </IconButton>
                                                  }
                                                />
                                              )}
                                            </div>
                                          ))
                                        ) : (
                                          <div className="w-fit px-2 flex justify-start items-center gap-1  rounded-xl text-sm font-medium">
                                            No Time Slots Selected yet.
                                          </div>
                                        )}
                                      </>
                                    )}
                                  </>
                                )}
                              </div>
                              {!day.unavailable && !day.allday && (
                                <div
                                  onClick={() => {
                                    setOpenModal(true);
                                    setCurrentDayId(day.id); // Set current day ID
                                  }}
                                  className="cursor-pointer  text-md w-5 h-5 rounded-full text-[#3aa7a3]  flex flex-row justify-center items-center"
                                >
                                  <AddBoxIcon color="inherit" />
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="min-w-full bg h-[80vh] flex flex-col justify-center items-center">
                    <h1 className="text-red-600 font-semibold text-sm w-1/2 text-center">
                      Please select your all-day time slot and preferred
                      timezone first. Once selected, you'll be able to set your
                      weekly availability.
                    </h1>
                  </div>
                )}
              </div>
            </div>
            {allDayTimeSlot.from !== "" && (
              <div className="flex justify-between px-5 my-2 ">
                <div className="flex flex-row justify-start items-center text-sm font-semibold text-[#013338]">
                  <label
                    style={{
                      color: "#3aa7a3",
                    }}
                    className="flex flex-row justify-start items-start gap-3 py-4 "
                  >
                    <Checkbox
                      className="w-2 h-2 border border-white"
                      checked={repeatAvailibility}
                      onChange={() => {
                        const newValue = !repeatAvailibility;
                        setRepeatAvailibility(newValue);
                        setHasChanges(true);
                      }}
                      style={{
                        accentColor: "#3aa7a3",
                      }}
                    />
                    <span>Keep the same availability for next week.</span>
                  </label>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </ThemeProvider>
  );
};

export default Page;

const InstructionModal = ({
  open,
  fun,
  openAnother,
}: {
  open: boolean;
  fun: (boolean: boolean) => void;
  openAnother: VoidFunction;
}) => {
  const [step, setStep] = useState(0);

  return (
    <>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        {/* Modal data start */}
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: 300, sm: 450 },
            height: 450,
            overflow: "auto",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,
            py: 4,
            borderRadius: 1,
          }}
        >
          <ModalCloseButton onClick={() => fun(false)} />
          <Box
            sx={{
              width: "100%",
              display: "flex",
              justifyContent: "start",
              alignItems: "start",
              flexDirection: "column",
              p: 2,
              gap: 2,
            }}
          >
            <img
              src={Logo}
              alt="Website-Logo"
              className="w-40 py-10  object-contain mx-auto"
            />
            <Typography
              variant="h6"
              sx={{
                fontWeight: 600,
                width: "100%",
                textAlign: "center",
                color: "#013338",
                fontFamily: "Quicksand",
              }}
            >
              Please add the weekly availability !
            </Typography>
            {step === 0 && (
              <>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 600,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  Complete the following steps to get started :
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  1. Add your prefered Timezone.(Other wise will be set to the
                  system's default timezone.)
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  2. Add your Full day timing, which can be than used to provide
                  available time slots for bookings.
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  3. Select your preffered days and mark the availability times
                  to them.
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  Once you've completed all these steps, a coachee will be able
                  to book a session with you under the timings you have added
                  here, .
                </Typography>
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 300,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  *Your Full day time slot, Timezone and weekly availability can
                  be modified later.
                </Typography>
                <Button
                  variant="outlined"
                  onClick={() => setStep(1)}
                  sx={{
                    px: 1,
                    color: "white",
                    backgroundColor: "#EBBE34",
                    borderColor: "#EBBE34",
                    borderRadius: "20px",
                    fontFamily: "Quicksand",
                    mx: "auto",
                    "&:hover": {
                      borderColor: "white",
                      backgroundColor: "white",
                      color: "#EBBE34",
                    },
                  }}
                >
                  CONTINUE
                </Button>
              </>
            )}

            {step === 1 && (
              <>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  Click continue to add your all-day availability—this is the
                  time you’ll be open for bookings.
                </Typography>
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 300,
                    width: "100%",
                    textAlign: "center",
                    color: "black",
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  *Your Full day time slot, Timezone and weekly availability can
                  be modified later.
                </Typography>
                <Button
                  variant="outlined"
                  onClick={() => openAnother()}
                  sx={{
                    px: 1,
                    color: "white",
                    backgroundColor: "#EBBE34",
                    borderColor: "#EBBE34",
                    borderRadius: "20px",
                    fontFamily: "Quicksand",
                    mx: "auto",
                    "&:hover": {
                      borderColor: "white",
                      backgroundColor: "white",
                      color: "#EBBE34",
                    },
                  }}
                >
                  CONTINUE
                </Button>
              </>
            )}
          </Box>
        </Box>
        {/* Modal data end */}
      </Modal>
    </>
  );
};
const convertTo12HourFormat = (time: string): string => {
  const [hour, minute] = time.split(":").map(Number);
  const ampm = hour >= 12 ? "PM" : "AM";
  const adjustedHour = hour % 12 || 12; // Convert '0' hour to '12' for 12 AM
  return `${adjustedHour}:${minute < 10 ? `0${minute}` : minute} ${ampm}`;
};
const formatdTime = (time: string): string => {
  const [hours, minutes] = time.split(":").map((num) => num.padStart(2, "0"));
  const suffix = +hours >= 12 ? "PM" : "AM";
  const formattedHours = (+hours % 12 || 12).toString().padStart(2, "0");
  return `${formattedHours}:${minutes} ${suffix}`;
};
