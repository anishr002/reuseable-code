/* eslint-disable @typescript-eslint/no-explicit-any */
// const label = { inputProps: { "aria-label": "Checkbox demo" } };
import {
  Autocomplete,
  Box,
  FormControl,
  TextField,
  Tooltip,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { Controller, useForm } from "react-hook-form";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { CoachCredentials_Type } from "../../../../Types/backend/CoachCredentials_Type";
import { useNotify } from "../../../../lib/Notify";
import customAlert from "../../../../lib/swalExtentions";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import { CoachingCertificationsOptions } from "../../../../Options/Options";
import ImageUploadComponent from "../../../../components/utility/ImageUploadComponent";
import { YellowButton } from "../../../../components/buttons/ThemeButtons";
import dayjs from "dayjs";
import ProfileAccordianStyleWrapper from "../../../../components/wrappers/ProfileAccordianStyleWrapper";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import DummyTextField from "../../../../components/inputFields/DummyTextField";
import moment from "moment-timezone";
import MenuButton from "../../../../components/buttons/MenuButton";
import Warning from "../../../../components/UI/Warning";
import ModalCloseButton from "../../../../components/buttons/ModalCloseButton";
import { DownloadButton } from "../../../../components/utility/FilePreview";
import Image from "../../../../components/UI/Image";

interface CoachingCredentialsProps {
  coachcredentialsList: CoachCredentials_Type[] | undefined;
  togglePageRefresh: () => void;
  isEditing: boolean;
}
const CoachingCredentials: React.FC<CoachingCredentialsProps> = ({
  coachcredentialsList,
  togglePageRefresh,
  isEditing,
}) => {
  const [openCC, setOpenUpdateCC] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const { notifyMe } = useNotify();

  type CoachingCredentialsValue = {
    title: string;
    image: FileList | null;
    // startDate: any | null;
    endDate: any | null;
    // endDateCheckbox: any | null;
  };

  const {
    register,
    handleSubmit,
    formState: { errors: errors },
    reset,
    control,
    watch,
  } = useForm<CoachingCredentialsValue>({
    mode: "onChange",
    reValidateMode: "onSubmit",
  });

  const CredentialsImage = watch("image");
  const [imagePreviewCredentials, setImagePreviewCredentials] = useState<
    string | undefined
  >(undefined);

  useEffect(() => {
    if (CredentialsImage && CredentialsImage.length > 0) {
      const file = CredentialsImage[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviewCredentials(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, [CredentialsImage]);

  const onSubmit = handleSubmit(async (data) => {
    setLoading(true);
    console.log({ credential: data });
    const formData = new FormData();
    if (data.image) {
      formData.append("image", data.image[0]);
    }
    formData.append("title", data.title);
    // formData.append("startDate", data.startDate);
    formData.append("endDate", data.endDate);
    // formData.append("endDateCheckbox", data.endDateCheckbox);
    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-coaching-credentials`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      if (response.status === 200) {
        reset();
        setOpenUpdateCC(false);
        togglePageRefresh();
        notifyMe({
          message: "Coaching credentials updated successfully",
          severity: "success",
        });
        return setLoading(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });

        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  });

  const deleteCredentials = (id: string) => {
    setLoading(true);
    customAlert
      .fire({
        title: "Are you sure?",
        text: `You want to delete it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, delete It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI.get(
              `${backendURL}/coach/profile/credentials-delete/${id}`
            );
            if (response.data.success === true) {
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            customAlert.fire({
              title: `Delete!`,
              text: `Credential delete successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            togglePageRefresh();
          }
        } else {
          return setLoading(false);
        }
      });
  };

  const [previewCredential, setpreviewCredential] =
    useState<CoachCredentials_Type | null>(null);

  return (
    <>
      <ProfileAccordianStyleWrapper
        defaultOpen={true}
        actions={
          <>
            {isEditing ? (
              <YellowButton
                onClick={() => setOpenUpdateCC(true)}
                text="+add"
                className="max-w-fit px-5"
              />
            ) : null}
          </>
        }
        header={
          <Tooltip
            title={
              coachcredentialsList && coachcredentialsList.length > 0
                ? "Coaching Credentials are required for profile approval"
                : ""
            }
          >
            <MundialHeadingText
              sizeVariant="sm"
              variant={
                coachcredentialsList && coachcredentialsList.length > 0
                  ? "darksea"
                  : "danger"
              }
            >
              Coaching Credentials*
            </MundialHeadingText>
          </Tooltip>
        }
      >
        <div className="">
          <div className="flex min-h-fit flex-col w-full h-full  pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
              {coachcredentialsList && coachcredentialsList?.length > 0 ? (
                coachcredentialsList?.map((cred, i) => (
                  <React.Fragment
                    key={`coach-profile-coaching-credential-list-item-${i}`}
                  >
                    <div className="col-span-2 ">
                      <DummyTextField
                        borderColor={isEditing ? "seaBlue" : "darkSea"}
                        value={
                          <>
                            <div className="flex break-words  whitespace-normal flex-col md:flex-row w-full md:items-center justify-between pr-10 ">
                              <span className="flex-1 ">{cred.title}</span>
                              <span>{`Completed On : ${moment(
                                cred.endDate
                              ).format("MMMM YYYY")}`}</span>
                              <div>
                                <div className="absolute z-[10] top-0 right-0 p-1">
                                  {isEditing ? (
                                    <MenuButton
                                      options={[
                                        // {
                                        //   label: "Edit",
                                        //   action: () => undefined,
                                        // },
                                        {
                                          label: "Preview",
                                          action: () =>
                                            setpreviewCredential(cred),
                                        },
                                        {
                                          label: "Delete",
                                          action: () =>
                                            deleteCredentials(cred._id),
                                        },
                                      ]}
                                    ></MenuButton>
                                  ) : (
                                    <MenuButton
                                      options={[
                                        {
                                          label: "Preview",
                                          action: () =>
                                            setpreviewCredential(cred),
                                        },
                                      ]}
                                    ></MenuButton>
                                  )}
                                </div>
                              </div>
                            </div>
                          </>
                        }
                      />
                    </div>
                  </React.Fragment>
                ))
              ) : (
                <>
                  <div className="flex col-span-full">
                    <Warning>
                      You have not added your coaching credentials information
                      yet.
                    </Warning>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </ProfileAccordianStyleWrapper>

      <CustomModalWrapper
        backdropClose={false}
        open={openCC}
        onClose={() => {
          setOpenUpdateCC(false);
          setImagePreviewCredentials(undefined);
        }}
        title="Add Coaching Credentials"
      >
        {/* Modal data start */}
        <form className="w-full  pt-5 pb-10 px-6 " onSubmit={onSubmit}>
          <div className="flex flex-col gap-10">
            <div className="flex flex-col gap-5 w-full">
              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Coach Credentials</p>
                <Controller
                  name="title"
                  control={control}
                  defaultValue=""
                  render={({
                    field: { onChange, value },
                    fieldState: { error },
                  }) => (
                    <Autocomplete
                      size="small"
                      id="coacing-credential-selection-autocomplete"
                      fullWidth
                      options={CoachingCertificationsOptions}
                      value={value}
                      onChange={(_event, newValue) => {
                        onChange(newValue);
                      }}
                      autoHighlight
                      getOptionLabel={(option) => option}
                      isOptionEqualToValue={(option, value) => option === value}
                      renderOption={(props, option) => (
                        <Box component="li" {...props} key={option}>
                          {option}
                        </Box>
                      )}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          error={!!error}
                          helperText={error ? error.message : null}
                          inputProps={{
                            ...params.inputProps,
                            autoComplete: "off",
                          }}
                          FormHelperTextProps={{
                            sx: { ml: 0 },
                          }}
                        />
                      )}
                    />
                  )}
                  rules={{ required: "Please select a coach credential" }}
                />
              </div>
              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Image</p>
                <div className="flex flex-col gap-2 textsm">
                  <span className="text-red-700">
                    *Coaching Credentails are allowed only in JPG/JPEG/PNG/WEBP
                    image formats .
                  </span>
                  <span className="text-red-700">
                    **Max allowed File size is 7MB.
                  </span>
                </div>
                <div className="w-full  flex justify-center items-center overflow-hidden">
                  <ImageUploadComponent
                    children={
                      <input
                        accept="image/*"
                        style={{ display: "none" }}
                        id="image-upload2"
                        type="file"
                        {...register("image", {
                          required: "Please upload image file",
                        })}
                      />
                    }
                    labelName="image-upload2"
                    icon="Image"
                    imagePreview={imagePreviewCredentials}
                    name="Upload picture"
                    variant="Rectangle"
                  />
                </div>

                {errors.image && (
                  <span className="form-error-message">
                    {errors.image?.message}
                  </span>
                )}
              </div>

              {/* <div className="hidden flex-col gap-2">
                <p className="text-base font-medium">Start Date</p>
                <FormControl fullWidth size="small" error={!!errors.startDate}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <Controller
                      control={control}
                      name="startDate"
                      rules={{
                        validate: (value) => {
                          if (!endDateWatch && !value) {
                            return "Start date is required";
                          }
                          if (value && !dayjs(value).isValid()) {
                            return "Please select a valid date";
                          }
                          if (
                            value &&
                            !dayjs(value, "MM-DD-YYYY", true).isValid()
                          ) {
                            return "Please select a valid date in MM-DD-YYYY format";
                          }
                          return true;
                        },
                      }}
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          disableFuture
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          views={["year", "month", "day"]}
                          sx={{
                            width: "100%",
                            "& .MuiInputBase-root": {
                              height: "43px",
                              overflow: "hidden",
                            },
                            "& .MuiFormLabel-root": {
                              top: -5,
                            },
                            "& .MuiInputLabel-shrink": {
                              top: 0,
                            },
                          }}
                          slotProps={{
                            inputAdornment: {
                              position: "start",
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {errors?.startDate && (
                    <p className="form-error-message">
                      {String(errors.startDate.message)}
                    </p>
                  )}
                </FormControl>
              </div> */}

              {/* <div className="hidden flex-col gap-2">
                <span className="flex items-center">
                  <Checkbox {...label} {...register("endDateCheckbox")} />
                  <p className="text-sm font-medium">
                    Currently enrolled in this certification program
                  </p>
                </span>
              </div> */}

              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Date Of Completion</p>
                <FormControl fullWidth size="small" error={!!errors.endDate}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <Controller
                      control={control}
                      name="endDate"
                      rules={{
                        validate: (value) => {
                          if (!value) {
                            return "End date is required";
                          }
                          if (value && !dayjs(value).isValid()) {
                            return "Please select a valid date";
                          }
                          if (
                            value &&
                            !dayjs(value, "MM-DD-YYYY", true).isValid()
                          ) {
                            return "Please select a valid date in MM-DD-YYYY format";
                          }
                          if (dayjs(value).isAfter(dayjs())) {
                            return "End Date must be in past !";
                          }
                          return true;
                        },
                      }}
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          disableFuture
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          views={["year", "month", "day"]}
                          sx={{
                            width: "100%",
                            "& .MuiInputBase-root": {
                              height: "43px",
                              overflow: "hidden",
                            },
                            "& .MuiFormLabel-root": {
                              top: -5,
                            },
                            "& .MuiInputLabel-shrink": {
                              top: 0,
                            },
                          }}
                          slotProps={{
                            inputAdornment: {
                              position: "start",
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {errors?.endDate && (
                    <p className="form-error-message">
                      {String(errors?.endDate.message)}
                    </p>
                  )}
                </FormControl>
              </div>

              <div className="flex w-1/2 mx-auto">
                <YellowButton
                  shouldDisable={
                    loading ||
                    !watch("image") ||
                    !watch("title") ||
                    !watch("endDate") ||
                    Object.keys(errors).length > 0
                  }
                  loading={loading}
                  type="submit"
                  text="Save"
                />
              </div>
            </div>
          </div>
        </form>
      </CustomModalWrapper>

      <CustomModalWrapper
        open={!!previewCredential}
        onClose={() => setpreviewCredential(null)}
        title={previewCredential?.title}
      >
        <div className="w-full  flex flex-col space-y-2.5">
          <span>{`${moment(previewCredential?.startDate).format("MMMM YYYY")}-${
            previewCredential?.workingOn
              ? "Present"
              : moment(previewCredential?.endDate).format("MMMM YYYY")
          }`}</span>
          <span className="text-[#3aa7a3] font-normal text-sm">
            Added :{" "}
            {moment(previewCredential?.createdAt).format(
              "DD MMMM YYYY hh:mm A"
            )}
          </span>

          <ModalCloseButton onClick={() => setpreviewCredential(null)} />
          {previewCredential && (
            <div className="w-full h-fit min-h-40 flex items-center justify-center bg-[#013338] text-white">
              <Image
                src={`${backendURL}/credentials/${previewCredential?.image}`}
                alt={previewCredential.title || "coachi-credential-image"}
                className="object-contain w-full object-center"
              />
            </div>
          )}
          <div className="w-full flex flex-col space-y-2 py-5 items-center justify-center">
            <DownloadButton
              fileUrl={`${backendURL}/credentials/${previewCredential?.image}`}
            />
            {/* {previewCredential && (
              <CancelButton
                text="Delete"
                onClick={() => deleteCredentials(previewCredential?._id)}
                className="max-w-fit px-5"
              />
            )} */}
          </div>
        </div>
      </CustomModalWrapper>
    </>
  );
};

export default CoachingCredentials;
