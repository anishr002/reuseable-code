/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { CircularProgress, TextField, Tooltip } from "@mui/material";
import ImageUploadComponent from "../../../../components/utility/ImageUploadComponent";
import { CoachCertificate_Type } from "../../../../Types/backend/CoachCertificate_Type";
import { useNotify } from "../../../../lib/Notify";
import { updateHubSpotInfo } from "../../../../lib/hubspot";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import { YellowButton } from "../../../../components/buttons/ThemeButtons";
import DummyTextField from "../../../../components/inputFields/DummyTextField";
import MenuButton from "../../../../components/buttons/MenuButton";
import ProfileAccordianStyleWrapper from "../../../../components/wrappers/ProfileAccordianStyleWrapper";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import Warning from "../../../../components/UI/Warning";
import ModalCloseButton from "../../../../components/buttons/ModalCloseButton";
import FilePreview from "../../../../components/utility/FilePreview";
import moment from "moment-timezone";
import customAlert from "../../../../lib/swalExtentions";

interface CoachCertificateUpdateModalProps {
  coachCertificateList: CoachCertificate_Type[] | undefined;
  togglePageRefresh: () => void;
  isEditing: boolean;
}

type FormValues = {
  title: string;
  certificateFile: FileList | null;
};

const CoachCertificateUpdateModal: React.FC<
  CoachCertificateUpdateModalProps
> = ({ coachCertificateList, togglePageRefresh, isEditing }) => {
  const {
    register,
    handleSubmit,
    formState: { errors: errors },
    reset,
    watch,
  } = useForm<FormValues>({
    mode: "onChange",
    reValidateMode: "onChange",
  });
  const [open, SetOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const { notifyMe } = useNotify();
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const selectedFile = watch("certificateFile");
  useEffect(() => {
    if (selectedFile && selectedFile.length > 0) {
      const file = selectedFile[0];
      if (file.type === "application/pdf") {
        const url = URL.createObjectURL(file);
        setFileUrl(url);
      } else {
        setFileUrl(null);
        notifyMe({
          message: "Only PDF files are accepted as certificates.",
          severity: "error",
        });
      }
    }
  }, [selectedFile]);

  const onSubmit = handleSubmit(async (data) => {
    setLoading(true);
    try {
      const formData = new FormData();
      if (data.certificateFile) {
        formData.append("certificateFile", data.certificateFile[0]);
      }
      formData.append("title", data.title);
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-certificate`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      if (response.status === 200) {
        reset();
        SetOpen(false);
        togglePageRefresh();
        notifyMe({
          message: "Certificate uploaded successfully",
          severity: "success",
        });
        updateHubSpotInfo({ userType: "coach" });
        return setLoading(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
        return setLoading(false);
      }
    } finally {
      setLoading(false);
    }
  });

  const deleteCertificate = (id: string) => {
    setLoading(true);
    customAlert
      .fire({
        title: "Are you sure?",
        text: `You want to delete it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, delete It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI.get(
              `${backendURL}/coach/profile/certificate-delete/${id}`
            );
            if (response.data.success === true) {
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            customAlert.fire({
              title: `Delete!`,
              text: `Certificate deleted successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            togglePageRefresh();
            updateHubSpotInfo({ userType: "coach" });
          }
        } else {
          setLoading(false);
        }
      });
  };
  const [previewCertificate, setpreviewCertificate] =
    useState<CoachCertificate_Type | null>(null);

  return (
    <>
      <>
        <ProfileAccordianStyleWrapper
          defaultOpen={true}
          actions={
            <>
              {isEditing && (
                <YellowButton
                  onClick={() => SetOpen(true)}
                  text="+add"
                  className="max-w-fit px-5"
                />
              )}
            </>
          }
          header={
            <Tooltip
              title={
                coachCertificateList && coachCertificateList?.length > 0
                  ? "Certificates are required for profile approval"
                  : ""
              }
            >
              <MundialHeadingText
                sizeVariant="sm"
                variant={
                  coachCertificateList && coachCertificateList?.length > 0
                    ? "darksea"
                    : "danger"
                }
              >
                Certificates*
              </MundialHeadingText>
            </Tooltip>
          }
        >
          <div className="flex min-h-fit flex-col w-full h-full  pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
              {loading ? (
                <div className="w-full h-32 flex justify-center items-center">
                  <CircularProgress size={30} sx={{ color: "#3aa7a3" }} />
                </div>
              ) : coachCertificateList && coachCertificateList?.length > 0 ? (
                coachCertificateList?.map((cc, i) => {
                  return (
                    <React.Fragment
                      key={`coach-proflie-coach-certificate-list-item-${i}`}
                    >
                      <div className="col-span-2">
                        <DummyTextField
                          borderColor={isEditing ? "seaBlue" : "darkSea"}
                          value={
                            <>
                              <div className="flex w-full items-center justify-between">
                                <span>{cc.title}</span>
                                <div>
                                  {isEditing ? (
                                    <MenuButton
                                      options={[
                                        // {
                                        //   label: "Edit",
                                        //   action: () => undefined,
                                        // },
                                        {
                                          label: "Delete",
                                          action: () =>
                                            deleteCertificate(cc._id),
                                        },
                                        {
                                          label: "Preview",
                                          action: () =>
                                            setpreviewCertificate(cc),
                                        },
                                      ]}
                                    ></MenuButton>
                                  ) : (
                                    <MenuButton
                                      options={[
                                        {
                                          label: "Preview",
                                          action: () =>
                                            setpreviewCertificate(cc),
                                        },
                                      ]}
                                    ></MenuButton>
                                  )}
                                </div>
                              </div>
                            </>
                          }
                        />
                      </div>
                    </React.Fragment>
                  );
                })
              ) : (
                <>
                  <div className="flex col-span-full">
                    <Warning>
                      You have not added your coaching certification details yet
                      !
                    </Warning>
                  </div>
                </>
              )}
            </div>
          </div>
        </ProfileAccordianStyleWrapper>
      </>
      <CustomModalWrapper
        backdropClose={false}
        open={open}
        title=" Upload Certificates and Badges"
        onClose={() => SetOpen(false)}
        children={
          <form className="w-full  pt-5  px-6 " onSubmit={onSubmit}>
            <div className="flex flex-col gap-10">
              <div className="flex flex-col gap-5 w-full">
                <div className="flex flex-col gap-2">
                  <p className="text-base font-semibold text-[#013338]">
                    Title
                  </p>
                  <TextField
                    id="outlined-required"
                    placeholder="Title"
                    fullWidth
                    multiline
                    minRows={1}
                    size="small"
                    {...register("title", {
                      required: "Please enter title",
                    })}
                    error={!!errors.title}
                    helperText={errors.title?.message}
                    FormHelperTextProps={{
                      style: {
                        marginLeft: 1,
                      },
                    }}
                  />
                </div>

                <div className="flex flex-col gap-2 min-h-60">
                  <p className="text-base font-semibold text-[#013338]">
                    Certificate
                  </p>
                  <div className="flex flex-col gap-2">
                    <span className="text-red-700">
                      *Certificate are allowed only in pdf file format .
                    </span>
                    <span className="text-red-700">
                      **Max allowed File size is 7MB.
                    </span>
                  </div>
                  <ImageUploadComponent
                    children={
                      <input
                        accept="pdf/*"
                        style={{ display: "none" }}
                        id="upload-certificate-pdf"
                        type="file"
                        {...register("certificateFile", {
                          required: "Please upload a certificate file",
                          validate: (fileList) => {
                            const file = fileList?.[0];
                            if (!file)
                              return "Please upload a certificate file";
                            if (file.type !== "application/pdf")
                              return "Only PDF files are allowed";
                            if (file.size > 7 * 1024 * 1024)
                              return "File size must be under 7MB";
                            return true;
                          },
                        })}
                      />
                    }
                    labelName="upload-certificate-pdf"
                    icon="PdfFile"
                    name="Upload Pdf file"
                    variant="Rectangle"
                    fileUrl={fileUrl}
                    type="pdf"
                  />
                  {errors.certificateFile && (
                    <span className="form-error-message">
                      {errors.certificateFile?.message}
                    </span>
                  )}
                </div>

                <div className="flex w-1/2 mx-auto">
                  <YellowButton
                    shouldDisable={
                      loading ||
                      !watch("title") ||
                      !watch("certificateFile") ||
                      Object.keys(errors).length > 0
                    }
                    loading={loading}
                    type="submit"
                    text="Save"
                  />
                </div>
              </div>
            </div>
          </form>
        }
      />

      <CustomModalWrapper
        open={!!previewCertificate}
        onClose={() => setpreviewCertificate(null)}
        title={previewCertificate?.title}
      >
        <div className="w-full  flex flex-col space-y-2.5">
          <div className="flex w-full items-center justify-end">
            <span className="text-[#3aa7a3] font-normal text-sm">
              Added :{" "}
              {moment(previewCertificate?.createdAt).format(
                "DD MMMM YYYY hh:mm A"
              )}
            </span>
          </div>
          <ModalCloseButton onClick={() => setpreviewCertificate(null)} />
          {previewCertificate && (
            <FilePreview
              file={previewCertificate.certificateFile}
              fileUrl={`${backendURL}/certificate/${previewCertificate.certificateFile}`}
              showDownloadButton={true}
            />
          )}
          {/* {previewCertificate && (
            <div className="w-full py-4 flex items-center justify-center">
              <CancelButton
                text="Delete"
                onClick={() => deleteCertificate(previewCertificate?._id)}
                className="max-w-fit px-5"
              />
            </div>
          )} */}
        </div>
      </CustomModalWrapper>
    </>
  );
};

export default CoachCertificateUpdateModal;
