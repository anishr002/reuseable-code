import { styled } from "@mui/material";
import Tooltip, { TooltipProps, tooltipClasses } from "@mui/material/Tooltip";

const CircleProgress = ({
  stepsCompleted,
  totalSteps,
  completedAll,
}: {
  stepsCompleted: number;
  totalSteps: number;
  completedAll: boolean;
}) => {
  // Calculate completion percentage based on steps
  const completionPercentage = (stepsCompleted / totalSteps) * 100;

  // Calculate strokeDashoffset based on the percentage (circle circumference = 282.6)
  const circumference = 282.6;
  const strokeDashoffset =
    circumference -
    (circumference * (completedAll ? 100 : completionPercentage)) / 100;

  // Determine stroke color based on completion percentage
  let strokeColor;
  if (completionPercentage >= 80) strokeColor = "#3aa7a3"; // green/blue
  else if (completionPercentage >= 50) strokeColor = "#ebbe34"; // yellow
  else if (completionPercentage >= 20) strokeColor = "#ffa500"; // orange
  else strokeColor = "red"; // red when under 20%

  return (
    <div className="absolute inset-0 flex items-center justify-center z-[999] ">
      <svg
        className="w-full h-full"
        viewBox="0 0 100 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="50"
          cy="50"
          r="46"
          stroke="white" // Background circle color
          strokeWidth="2"
          fill="none"
        />
        <circle
          cx="50"
          cy="50"
          r="45"
          stroke={strokeColor}
          strokeWidth="2"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          style={{
            transform: "rotate(-90deg)", // Start from the top
            transformOrigin: "50% 50%", // Center rotation
            transition: "stroke-dashoffset 0.5s ease, stroke 0.5s ease",
          }}
        />
      </svg>
      <LightTooltip title="Profile Completion Status">
        <div
          className={`absolute bottom-0 left-2/3 -translate- md:text-sm text-xs font-medium text-[${strokeColor}] md:w-10 w-8 flex flex-row justify-center items-center md:h-10 h-8  rounded-full  bg-white `}
        >
          {Math.ceil(completionPercentage)}%
        </div>
      </LightTooltip>
    </div>
  );
};

export default CircleProgress;

export const LightTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: theme.palette.common.white,
    color: "rgba(0, 0, 0, 0.87)",
    boxShadow: theme.shadows[1],
    fontSize: 12,
    fontFaimly:"Quicksand"
  },
})) as typeof Tooltip;
