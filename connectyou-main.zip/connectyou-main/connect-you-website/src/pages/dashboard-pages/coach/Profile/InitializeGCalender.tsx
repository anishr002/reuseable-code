import { ReactNode, useState } from "react";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import LoadingElement from "../../../../components/UI/LoadingElement";

const InitializeGCalender = ({
  children,
  allowClick = true,
}: {
  children: ReactNode;
  allowClick?: boolean;
}) => {
  const [loading, setLoading] = useState(false);
  const handleAddCalendar = async () => {
    setLoading(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/profile/get-calendar-url`
      );
      if (response.status === 200) {
        setLoading(false);
        const G_url = response.data.data;
        // console.log({ G_url });
        return (window.location.href = G_url);
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingElement className="max-w-[50px] max-h-[50px]" />;
  }
  return (
    <div onClick={() => allowClick && handleAddCalendar()}>
      <div className="">{children}</div>
    </div>
  );
};

export default InitializeGCalender;
