/* eslint-disable @typescript-eslint/no-explicit-any */
import HelpIcon from "@mui/icons-material/Help";
import CalendarTodayIcon from "../../../../assets/icons/icons8-google-calendar.svg";
import { FormProvider, useForm } from "react-hook-form";
import WhiteRoundedBox from "../../../../components/dashboard-components/WhiteRoundedBox";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import AccountDeletionProcess from "../../../../components/UI/AccountDeletionProcess";
import {
  CancelButton,
  YellowButton,
} from "../../../../components/buttons/ThemeButtons";
import ProfileAccordianStyleWrapper from "../../../../components/wrappers/ProfileAccordianStyleWrapper";
import { useEffect, useRef, useState } from "react";
import {
  Coach_Data_Type,
} from "../../../../Types/backend/Coach_Data_Type";
import RegisterTextInputField from "../../../../components/inputFields/RegisterTextInputField";
import validateUserName from "../../../../util/validateUserName";
import UpdatePasswordComponent from "../../../../components/UI/UpdatePasswordComponent";
import { trigger } from "../../../../slices/refreshTrigger";
import { useDispatch } from "react-redux";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useNotify } from "../../../../lib/Notify";
import CustomSelect from "../../../../components/inputFields/CustomSelect";
import AddressSelectionComponent, {
  AddressAutoCompletionHelperFunctionProps,
} from "../../../../components/wrappers/AddressSelectionComponent";
import getTimeZones from "../../../../util/getTimeZones";
import DummyTextField from "../../../../components/inputFields/DummyTextField";
import moment from "moment-timezone";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { updateHubSpotInfo } from "../../../../lib/hubspot";
import logoutLocal from "../../../../util/logoutLocal";
import { login, logout } from "../../../../slices/Login";
import ProfileFormSkel from "../../../../components/Skeletons/ProfileFormSkel";
import MenuButton from "../../../../components/buttons/MenuButton";
import {
  Avatar,
  FormGroup,
  IconButton,
  Rating,
  ThemeProvider,
  Tooltip,
} from "@mui/material";
import CustomSwitch, {
  CustomSwitchGray,
} from "../../../../components/buttons/CustomSwitch";
import { MdEdit } from "react-icons/md";
import { CoachCredentials_Type } from "../../../../Types/backend/CoachCredentials_Type";
import { CoachWorkExp_Type } from "../../../../Types/backend/CoachWorkExp_Type";
import { CoachEducationalBackground_Type } from "../../../../Types/backend/CoachEducationalBackground_Type";
import { CoachCertificate_Type } from "../../../../Types/backend/CoachCertificate_Type";
import LanguagesList from "../../../../Options/Languages_Options";
import customAlert from "../../../../lib/swalExtentions";
import { FaCheck, FaEye } from "react-icons/fa";
import ProvideToolTip from "../../../../components/wrappers/ProvideToolTip";
import NotificationPermissionModal from "../../../../components/utility/NotificationPermissionModal";
import { IoAddCircle, IoCloseCircle } from "react-icons/io5";
import InitializeGCalender from "./InitializeGCalender";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import ProfileStatus from "../../../../components/UI/ProfileStatus";
import capitalizeFirstLetter from "../../../../util/capitaliseFirstLetter";
import RatingTheme from "../../../../lib/MUI/RatingTheme";
import CoachCertificateUpdateModal from "./CoachCertificateUpdateModal";
import DraggableImageUploadComponent from "../../../../components/utility/DraggableImageUploadComponent";
import ReviewsDrawer from "../Rating/ReviewsDrawer";
import CoachingCredentials from "./CoachingCredentials";
import useScrollRestoration from "../../../../components/hooks/useScrollRestoration";
import WorkExperience from "./WorkExperience";
import CoachEducationalBackground from "./CoachEducationalBackground";
import { IndustriesOptions } from "../../../../Options/Options";
import CreatePageHeading, {
  HeadingText,
} from "../../../../contexts/context-hooks/useCreateHeading";
import usePageScrollAndTitle from "../../../../components/hooks/usePageScrollAndTitle";
import CoachInstructionModal from "./CoachInstructionModal";
import EricksonReference from "./EricksonReference";
import CircleProgress from "./CircleProgress";
import LoadGoogleScripts from "../../../../components/wrappers/LoadGoogleScripts";
import { BackdropLoader } from "../../../../components/UI/LoadingElement";
import Coaching_Focus_Area from "../../../../Options/Coaching_Focus_Area";

interface BasicDetailsFormValues {
  name: string;
  Lname: string;
  userName: string;
  gender: string;
  city: string;
  country: string;
  timeZone: string;
  location: {
    type: string;
    coordinates: [number, number];
    //lat lng
  };
  fullAddress: string;
  countryCode: string;
  phoneCode: string;
  title_line: string;
  about_me: string;
  languages: string[];
  zoomMeetingURL?: string;
  experienceYear?: number;
  // coachingSpecialities?: string[];
  coaching_focus_area: string[];
  nonProfitCoaching?: boolean;
  image?: FileList | null;
  industries?: string[];
  linkedin_profile_link?: string;
}

interface FormValues {
  coach: BasicDetailsFormValues;
}
export interface CoachData extends Coach_Data_Type {
  coachingCredentialsList: CoachCredentials_Type[];
  coachWorkExperiencesList: CoachWorkExp_Type[];
  coachEducationalBackgroundList: CoachEducationalBackground_Type[];
  coachCertificatesList: CoachCertificate_Type[];
}

const Page = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { notifyMe } = useNotify();
  const methods = useForm<FormValues>({
    mode: "onChange",
    reValidateMode: "onChange",
    shouldFocusError: true,
  });
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [coachData, setCoachData] = useState<CoachData | null>(null);
  const [refresh, setRefresh] = useState<boolean>(false);
  const [loadingUpdateProfile, setLoadingUpdateProfile] = useState(false);

  const fetchData = async () => {
    try {
      const response = await httpAPI.get(`${backendURL}/coach/profile/profile`);
      // console.log({ response });
      if (response.status === 200) {
        setCoachData(response.data.data);
      }
    } catch (error) {
      console.log({ error });
      dispatch(logout());
      logoutLocal();
      return navigate("/");
    }
  };

  const refetch = async () => {
    try {
      setLoadingUpdateProfile(true);
      await fetchData();
    } catch (error: any) {
      console.log({
        "error at fetch profile": error?.response?.data?.message || error,
      });
    } finally {
      setLoadingUpdateProfile(false);
      setRefresh((prev) => !prev);
    }
  };

  useEffect(() => {
    const initialize = async () => {
      try {
        setLoading(true);
        await fetchData();
      } catch (error: any) {
        console.log({
          "error at fetch profile": error?.response?.data?.message || error,
        });
      } finally {
        setLoading(false);
      }
    };
    initialize();
  }, []);

  const onSubmit = methods.handleSubmit(async (data: FormValues) => {
    methods.trigger("coach");
    if (Object.keys(methods.formState.errors).length > 0) {
      return notifyMe({
        message: "Please complete the required fields with valid input",
      });
    }
    setLoadingUpdateProfile(true);
    try {
      // console.log({ "form submitted by  coach": data.coach });
      const UpdatedData = {
        name: data.coach.name,
        Lname: data.coach.Lname,
        userName: data.coach.userName,
        gender: data.coach.gender,
        city: data.coach.city,
        country: data.coach.country,
        timeZone: data.coach.timeZone,
        location: data.coach.location,
        fullAddress: data.coach.fullAddress,
        countryCode: data.coach.countryCode,
        phoneCode: data.coach.phoneCode,
        title_line: data.coach.title_line,
        about_me: data.coach.about_me,
        languages: data.coach.languages,
        zoomMeetingURL: data.coach.zoomMeetingURL,
        experienceYear: data.coach.experienceYear,
        // coachingSpecialities: data.coach.coachingSpecialities,1
        nonProfitCoaching: data.coach.nonProfitCoaching,
        industries: data.coach.industries,
        linkedin_profile_link: data.coach.linkedin_profile_link,
        ...(data.coach.coaching_focus_area
          ? {
              coaching_focus_area: Coaching_Focus_Area.filter((a) =>
                data.coach.coaching_focus_area.includes(a.tag)
              ),
            }
          : {}),
      };
      const imageFile = data.coach.image;
      const ImageFormData = new FormData();
      if (imageFile) {
        ImageFormData.append("image", imageFile[0]);
      }
      const Promises = [
        httpAPI.post(
          `${backendURL}/coach/profile/profile-update-more`,
          UpdatedData
        ),
      ];
      if (imageFile) {
        Promises.push(
          httpAPI.post(
            `${backendURL}/coach/profile/profile-update`,
            ImageFormData,
            {
              headers: {
                "Content-Type": "multipart/form-data",
              },
            }
          )
        );
      }
      const responses = await Promise.allSettled(Promises);
      // console.log("Promise Results:", responses);
      responses.forEach((res, index) => {
        if (res.status === "rejected") {
          const errorMessage =
            res?.reason?.response?.data?.message ||
            (index === 1
              ? "Unable to upload profile picture, try again later!"
              : "Unable to update profile, try again later!");
          notifyMe({
            message: errorMessage,
            severity: "error",
          });
        }
      });
      if (responses.every((res) => res.status === "fulfilled")) {
        if (imageFile) {
          const authToken = responses[1]?.value?.data?.data?.token;
          if (authToken) {
            localStorage.setItem("authToken", authToken);
            const loginUserData = JSON.parse(atob(authToken.split(".")[1]));
            dispatch(login(loginUserData));
          }
        } else {
          const authToken = responses[0]?.value?.data?.data?.token;
          if (authToken) {
            localStorage.setItem("authToken", authToken);
            const loginUserData = JSON.parse(atob(authToken.split(".")[1]));
            dispatch(login(loginUserData));
          }
        }
        dispatch(trigger());
        refetch();
        setIsEditing(false);
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
      }
    } finally {
      setLoadingUpdateProfile(false);
    }
  });
  useEffect(() => {
    updateHubSpotInfo({ userType: "coach" });
  }, [refresh]);

  // submit profile for review
  const [loadingUpdateReview, setLoadingUpdateReview] =
    useState<boolean>(false);
  const handelReviewSubmit = async () => {
    setLoadingUpdateReview(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/profile/profile-submit`
      );
      if (response.status === 200) {
        notifyMe({
          message: "Profile submitted for review",
          severity: "success",
        });
        return setLoadingUpdateReview(false);
      }
    } catch (error: any) {
      console.log(error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });

        return setLoadingUpdateReview(false);
      } else {
        notifyMe({ message: "Something went wrong", severity: "error" });
        return setLoadingUpdateReview(false);
      }
    } finally {
      setLoadingUpdateReview(false);
    }
  };

  const [searchParams, setSearchParams] = useSearchParams();
  const getsuccess = searchParams.get("getsuccess");
  useEffect(() => {}, []);

  useEffect(() => {
    // console.log({ getsuccess });
    if (getsuccess && getsuccess === "completed") {
      customAlert.fire({
        title: "Google Calendar Added",
        text: "Congratulations, google calendar added successfully.",
        allowEscapeKey: true,
        allowOutsideClick: true,
        icon: "success",
        iconColor: "#ebbe34",
        timer: 2500,
        showConfirmButton: true,
        confirmButtonColor: "#ebbe34",
      });
    } else if (getsuccess && getsuccess === "aborted") {
      customAlert.fire({
        title: "Google Calendar Sync failed",
        text: "Couldn't add google calendar, Process aborted or canceled",
        allowEscapeKey: true,
        allowOutsideClick: true,
        icon: "error",
        iconColor: "red",
        timer: 2500,
        showConfirmButton: true,
        confirmButtonColor: "#ebbe34",
      });
    }
    if (getsuccess) {
      searchParams.delete("getsuccess");
      setSearchParams(searchParams);
    }
  }, [getsuccess]);

  //aditional
  const [openTitleLineSuggestion, setopenTitleLineSuggestion] =
    useState<boolean>(false);
  const [openAboutMeSuggestions, setopenAboutMeSuggestions] =
    useState<boolean>(false);

  //instructions and profile status
  const [openInstructionModal, setOpenInstructionModal] = useState(false);
  const toggleOpenInstructionModal = () => {
    setOpenInstructionModal(!openInstructionModal);
  };
  const [stepsCompleted, setStepsCompleted] = useState(0);
  const [completedAll, setCompletedAll] = useState(false);
  const [showCircle, setShowCircle] = useState(false);
  const [viewList, setViewList] = useState(false);
  const toggleViewList = ({ X }: { X: boolean }) => {
    setViewList(X);
  };
  const getStatus = ({ x, y }: { x: number; y: boolean }) => {
    setStepsCompleted(x);
    setCompletedAll(y);
    // console.log("completed number of steps ", x, "Completed All ?", y);
  };
  const profileRef = useRef<HTMLDivElement | null>(null);
  const submitRef = useRef<HTMLDivElement | null>(null);
  useScrollRestoration("Page", [refresh], true);
  usePageScrollAndTitle({
    title: "Profile",
    allowScroll: isEditing ? false : true,
  });

  if (loading) {
    return (
      <div className="flex flex-col bg-white rounded-[5px] p-5">
        <div className="w-full  py-5">
          <ProfileFormSkel rows={1} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] py-5 w-full">
          <ProfileFormSkel rows={5} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] py-5 w-full">
          <ProfileFormSkel rows={4} />
        </div>
      </div>
    );
  }

  return (
    <FormProvider {...methods}>
      <CreatePageHeading>
        <HeadingText>Profile</HeadingText>
      </CreatePageHeading>
      <NotificationPermissionModal userType="coach" />
      {coachData && (
        <CoachInstructionModal
          coachCertificateList={coachData?.coachCertificatesList?.length}
          open={openInstructionModal}
          toggleOpenModal={toggleOpenInstructionModal}
          UserData={coachData}
          coachcredentialsList={coachData?.coachingCredentialsList?.length}
        />
      )}
      {/* modal for web push notification */}
      {loadingUpdateProfile && <BackdropLoader open={loadingUpdateProfile} />}
      <div
        className={` flex flex-col w-full min-h-fit space-y-3.5 ${
          loadingUpdateProfile ? "pointer-events-none opacity-75" : ""
        } `}
      >
        <WhiteRoundedBox className="w-full flex flex-col md:flex-row md:justify-between md:items-start gap-4">
          <div className="flex flex-col md:w-1/2 space-y-1.5 ">
            <MundialHeadingText sizeVariant="sm">Profile</MundialHeadingText>
            <p className="text-[16px] font-normal text-[#013338]">
              Please complete the following fields and submit them for review.{" "}
              <br />
              Your profile will be made public once approved.
            </p>
            <p className="text-[14px] font-normal text-[#013338]">
              * marked fields are required for profile approval.
            </p>
          </div>
          <div className="text-[#3aa7a3] underline-offset-[7px] font-medium text-[18px] flex flex-row justify-between items-center gap-3">
            {isEditing ? (
              <>
                <>
                  {Object.keys(methods.watch()).length > 0 && (
                    <>
                      <span className="font-normal text-sm">
                        *Please click to save the changes.
                      </span>
                      <CancelButton
                        text="Cancel"
                        className="px-3"
                        style={{ width: "fit-content" }}
                        onClick={() => {
                          customAlert
                            .fire({
                              title: "Are you sure ?",
                              text: "You want to cancel Edits? All the updates you made will be lost.",
                              showCancelButton: true,
                              showConfirmButton: true,
                              showCloseButton: true,
                            })
                            .then((result) => {
                              if (result.isConfirmed) {
                                setIsEditing(false);
                                methods.clearErrors("coach");
                              }
                            });
                        }}
                        shouldDisable={loadingUpdateProfile || loading}
                      />
                      <YellowButton
                        onClick={() => {
                          customAlert
                            .fire({
                              title: "Are you sure ?",
                              text: "You want to update your profile ?",
                              showCancelButton: true,
                              showConfirmButton: true,
                              showCloseButton: true,
                            })
                            .then((result) => {
                              if (result.isConfirmed) {
                                onSubmit();
                              }
                            });
                        }}
                        text="Save"
                        style={{ width: "fit-content" }}
                        className="w-fit px-6"
                        shouldDisable={
                          loading ||
                          loadingUpdateProfile ||
                          Object.keys(methods.formState.errors).length > 0
                        }
                      />
                    </>
                  )}
                </>
              </>
            ) : (
              <>
                <>
                  <span className="font-normal text-sm">
                    *Click here to edit your profile.
                  </span>
                  <IconButton sx={{ p: 0, color: "inherit", fontSize: "18px" }}>
                    <div className="underline cursor-pointer ">
                      <MenuButton
                        Icon={MdEdit}
                        options={[
                          {
                            label: "Edit",
                            action: () => {
                              setIsEditing(true);
                            },
                          },
                        ]}
                      />
                    </div>
                  </IconButton>
                </>
              </>
            )}
          </div>
        </WhiteRoundedBox>
        <>
          <ProfileAccordianStyleWrapper
            defaultOpen={true}
            header={
              <MundialHeadingText sizeVariant="sm">Account</MundialHeadingText>
            }
            actions={
              <div className="flex items-center justify-center flex-wrap md:pr-10 gap-4">
                <AccountDeletionProcess userType="coach">
                  <div className="underline cursor-pointer hover:text-[red] ">
                    Delete Account
                  </div>
                </AccountDeletionProcess>
                <div
                  onClick={() =>
                    customAlert
                      .fire({
                        title: "Are you sure ?",
                        text: "You want to logout ?",
                        showCancelButton: true,
                        showCloseButton: true,
                        showConfirmButton: true,
                      })
                      .then((result) => {
                        if (result.isConfirmed) {
                          logoutLocal();
                          return dispatch(logout());
                        }
                      })
                  }
                  className="underline cursor-pointer hover:text-[red] "
                >
                  Log Out
                </div>
              </div>
            }
          >
            <div className="">
              <div className="flex min-h-fit flex-col w-full h-full  pb-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
                  {isEditing ? (
                    <>
                      <div className="col-span-1">
                        <RegisterTextInputField
                          name="coach.name"
                          defaultValue={coachData?.name}
                          textLabel={"First Name"}
                          validationOptions={{
                            required: "First name is a  required field !",
                          }}
                          validationError={
                            methods.formState.errors.coach?.name?.message
                          }
                        ></RegisterTextInputField>
                      </div>
                      <div className="col-span-1">
                        <RegisterTextInputField
                          name="coach.Lname"
                          textLabel={"Last Name"}
                          defaultValue={coachData?.Lname}
                          validationOptions={{
                            required: "Last name is a  required field !",
                          }}
                          validationError={
                            methods.formState.errors.coach?.Lname?.message
                          }
                        ></RegisterTextInputField>
                      </div>
                      <div className="col-span-1">
                        <RegisterTextInputField
                          name="coach.userName"
                          textLabel={"Username"}
                          defaultValue={coachData?.userName}
                          validationError={
                            methods.formState.errors?.coach?.userName?.message
                          }
                          validationOptions={{
                            required: "Username is a required field !",
                            validate: async (value) => {
                              methods.clearErrors("coach.userName");
                              const result = await validateUserName(value);
                              // console.log(result);
                              if (result && result !== true)
                                methods.setError("coach.userName", {
                                  type: "manual",
                                  message: result,
                                });
                              return result;
                            },
                          }}
                        ></RegisterTextInputField>
                      </div>
                      <div className="col-span-1">
                        <UpdatePasswordComponent
                          togglePageRefresh={() => {
                            refetch();
                            dispatch(trigger());
                          }}
                          userType="coach"
                        >
                          <RegisterTextInputField
                            name="password"
                            textLabel={"Password"}
                            value={"coachData?"}
                            type="password"
                            endAdornment={
                              <button
                                className="text-sm font-semibold text-[inherit] underline underline-offset-1 hover:text-[#ebbd33]"
                                type="button"
                              >
                                Change
                              </button>
                            }
                          ></RegisterTextInputField>
                        </UpdatePasswordComponent>
                      </div>
                      <div className="col-span-1">
                        <RegisterTextInputField
                          name="coach.email"
                          textLabel={"Email"}
                          defaultValue={coachData?.email}
                          disabled={true}
                          endAdornment={
                            coachData?.emailVerified === 1 ? (
                              <ProvideToolTip title="VERIFIED">
                                <FaCheck className="text-[#3aa7a3]" />
                              </ProvideToolTip>
                            ) : (
                              <ProvideToolTip title="UNVERIFIED">
                                <IoCloseCircle className="text-[red]" />
                              </ProvideToolTip>
                            )
                          }
                        ></RegisterTextInputField>
                      </div>
                      <div className="col-span-1">
                        <CustomSelect
                          textLabel="Gender"
                          name="coach.gender"
                          options={["Male", "Female", "Others"]}
                          defaultValue={coachData?.gender}
                          validationOptions={{
                            validate: (value) => {
                              if (!value) {
                                return "Gender is required";
                              }
                              if (value) {
                                methods.clearErrors("coach.gender");
                                methods.trigger("coach.gender");
                                return true;
                              }
                            },
                          }}
                          validationError={
                            methods.formState.errors?.coach?.gender?.message
                          }
                        />
                      </div>
                      <div className="col-span-1 md:col-span-2 gap-[18px]  flex flex-row flex-wrap relative ">
                        <LoadGoogleScripts>
                          <AddressSelectionComponent
                            header={
                              <span className="text-[#013338]  text-[18px] font-medium">
                                Address
                              </span>
                            }
                            helper={({
                              city,
                              country,
                              countryCode,
                              lat,
                              lng,
                              selectedAddress,
                              phoneCode,
                            }: AddressAutoCompletionHelperFunctionProps) => {
                              if (city) {
                                methods.setValue("coach.city", city);
                                methods.clearErrors("coach.city");
                              }
                              if (country) {
                                methods.setValue("coach.country", country);
                                methods.clearErrors("coach.country");
                              }
                              if (countryCode) {
                                methods.setValue(
                                  "coach.countryCode",
                                  countryCode
                                );
                              }
                              if (selectedAddress) {
                                methods.setValue(
                                  "coach.fullAddress",
                                  selectedAddress
                                );
                              }
                              if (lat && lng) {
                                methods.setValue("coach.location", {
                                  type: "Point",
                                  coordinates: [lng, lat],
                                });
                              }
                              if (phoneCode) {
                                methods.setValue("coach.phoneCode", phoneCode);
                              }
                            }}
                          >
                            <div className="w-full md:w-[calc(50%-18px)]">
                              <RegisterTextInputField
                                textLabel="Country"
                                name="coach.country"
                                disabled
                                defaultValue={coachData?.country}
                                validationOptions={{
                                  required: "Country is a  required field !",
                                }}
                                validationError={
                                  methods.formState.errors.coach?.country
                                    ?.message
                                }
                              />
                            </div>
                            <div className="w-full md:w-[calc(50%-18px)]">
                              <RegisterTextInputField
                                textLabel="City"
                                name="coach.city"
                                disabled
                                defaultValue={coachData?.city}
                                validationOptions={{
                                  required: "City is a  required field !",
                                }}
                                validationError={
                                  methods.formState.errors.coach?.city?.message
                                }
                              />
                            </div>
                            <div className="w-full ">
                              <RegisterTextInputField
                                textLabel="Full Address"
                                name="coach.fullAddress"
                                disabled
                                defaultValue={coachData?.fullAddress}
                                validationError={
                                  methods.formState.errors.coach?.fullAddress
                                    ?.message
                                }
                              />
                            </div>
                          </AddressSelectionComponent>
                        </LoadGoogleScripts>
                      </div>
                      <div className="col-span-full">
                        <div className="w-full">
                          <span className="text-[red] text-xs font-semibold">
                            **Important: This address represents your place of
                            residence. It may or may not match the banking
                            address and country you provided at the time of
                            registration.{" "}
                          </span>
                        </div>
                      </div>
                      <div className="col-span-1">
                        <CustomSelect
                          textLabel="Time Zone"
                          name="coach.timeZone"
                          defaultValue={coachData?.timeZone}
                          options={getTimeZones()}
                          validationOptions={{
                            required: "TimeZone is a  required field !",
                          }}
                          validationError={
                            methods.formState.errors.coach?.timeZone?.message
                          }
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="col-span-1">
                        <DummyTextField
                          value={coachData?.name}
                          textLabel="First Name"
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Last Name"
                          value={coachData?.Lname}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Username"
                          value={coachData?.userName}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel={
                            <span
                              className={`${
                                coachData?.emailVerified === 1
                                  ? "text-[#013338]"
                                  : "text-[red]"
                              } pb-2 text-[18px] font-medium`}
                            >
                              Email*
                            </span>
                          }
                          value={coachData?.email}
                          endAdornment={
                            coachData?.emailVerified === 1 ? (
                              <ProvideToolTip title="VERIFIED">
                                <FaCheck className="text-[#3aa7a3]" />
                              </ProvideToolTip>
                            ) : (
                              <ProvideToolTip title="UNVERIFIED">
                                <IoCloseCircle className="text-[red]" />
                              </ProvideToolTip>
                            )
                          }
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Gender"
                          value={coachData?.gender}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Date of birth"
                          value={moment(coachData?.DOB).format("DD-MMMM YYYY")}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Time Zone"
                          value={coachData?.timeZone}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="City"
                          value={coachData?.city}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Country"
                          value={coachData?.country}
                        />
                      </div>
                      <div className="col-span-1 md:col-span-2">
                        <DummyTextField
                          textLabel="Full Address"
                          value={coachData?.fullAddress}
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </ProfileAccordianStyleWrapper>
          <ProfileAccordianStyleWrapper
            defaultOpen={true}
            actions={null}
            header={
              <div className="flex flex-col md:w-1/2 space-y-1.5 ">
                <MundialHeadingText sizeVariant="sm">
                  Additional Information
                </MundialHeadingText>
              </div>
            }
          >
            <div className={`flex min-h-fit flex-col w-full h-full  `}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
                <div className="col-span-1 ">
                  <DummyTextField
                    // textLabel={"Profile Approval Status"}
                    textLabel={
                      <div className="flex w-full items-center justify-between text-[#013338] font-medium">
                        <span className="text-[#013338] pb-2 text-[18px] font-medium">
                          Profile Approval Status
                        </span>
                        {coachData?.approve === 0 ? (
                          <Tooltip title="Request Now">
                            <IconButton
                              sx={{ p: 0 }}
                              onClick={() => {
                                if (submitRef && submitRef.current) {
                                  submitRef.current.scrollIntoView({
                                    behavior: "smooth",
                                    block: "start",
                                  });
                                }
                              }}
                            >
                              <HelpIcon />
                            </IconButton>
                          </Tooltip>
                        ) : (
                          <IconButton></IconButton>
                        )}
                      </div>
                    }
                    value={
                      <div className="w-full items-center justify-between flex  h-full">
                        {coachData?.approve === 1 ? (
                          <span className="text-[#3aa7a3]">Approved</span>
                        ) : (
                          <span className="text-[red]">Pending</span>
                        )}
                        {coachData?.approve === 1 ? (
                          <FaCheck className="text-[#3aa7a3]"></FaCheck>
                        ) : (
                          <IoCloseCircle className="text-[red]"></IoCloseCircle>
                        )}
                      </div>
                    }
                  ></DummyTextField>
                </div>

                <div className="col-span-1">
                  <DummyTextField
                    textLabel={
                      <div className="flex w-full items-center justify-between text-[#013338] font-medium">
                        <span className="text-[#013338] pb-2 text-[18px] font-medium">
                          Rating & Reviews
                        </span>
                        <Tooltip title="View All">
                          <ReviewsDrawer>
                            <IconButton sx={{ p: 0 }}>
                              <FaEye className="text-[#3aa7a3]" />
                            </IconButton>
                          </ReviewsDrawer>
                        </Tooltip>
                      </div>
                    }
                    value={
                      <div className="w-full flex flex-col md:flex-row justify-between md:items-center">
                        <span>
                          <ThemeProvider theme={RatingTheme("#ebbd33")}>
                            <Rating
                              readOnly
                              value={coachData?.averageRating || 0}
                              precision={0.5}
                            />
                          </ThemeProvider>
                        </span>
                        <span>
                          Total Ratings :{" "}
                          {coachData?.totalRatings
                            ?.toString()
                            .padStart(2, "0") || "00"}
                        </span>
                      </div>
                    }
                  />
                </div>
                {coachData && (
                  <>
                    <EricksonReference
                      allowEdit={isEditing}
                      userData={coachData}
                      togglePageRefresh={refetch}
                    />
                  </>
                )}
                <div className="col-span-1">
                  <DummyTextField
                    borderColor={
                      isEditing && coachData?.calendarStatus === 0
                        ? "seaBlue"
                        : "darkSea"
                    }
                    textLabel={
                      <div className="w-full h-full flex items-center justify-between">
                        <div className="pb-2 flex flex-row justify-start items-center gap-4 text-[#013338] font-medium">
                          <span
                            className={`${
                              coachData?.calendarStatus === 1
                                ? "text-[#013338]"
                                : "text-[red]"
                            } text-[18px] font-medium`}
                          >
                            Google Calendar
                          </span>

                          {isEditing && coachData?.calendarStatus === 0 && (
                            <InitializeGCalender
                              allowClick={coachData?.calendarStatus === 0}
                            >
                              <Tooltip title="Add Google Calender">
                                <IconButton sx={{ p: 0 }}>
                                  <IoAddCircle className="text-[#3aa7a3] cursor-pointer" />
                                </IconButton>
                              </Tooltip>
                            </InitializeGCalender>
                          )}
                        </div>
                        <img
                          src={CalendarTodayIcon}
                          alt="calender-icon"
                          className="object-contain max-w-6 max-h-6"
                        />
                      </div>
                    }
                    value={
                      <div className="w-full flex justify-between items-center">
                        <span>
                          {coachData?.calendarStatus === 0
                            ? "Pending"
                            : "Added"}
                        </span>
                        <span>
                          {coachData?.calendarStatus === 0 ? (
                            <>
                              <IoCloseCircle className="text-[red]" />
                            </>
                          ) : (
                            <>
                              <FaCheck className="text-[#3aa7a3]" />
                            </>
                          )}
                        </span>
                      </div>
                    }
                  />
                </div>
                {coachData && (
                  <div className="col-span-1 row-span-4">
                    <div ref={profileRef} className="w-full flex flex-col">
                      <ProfileStatus
                        data={coachData}
                        coachCertificateList={coachData?.coachCertificatesList}
                        coachcredentialsList={
                          coachData?.coachingCredentialsList
                        }
                        toggleOpenInstructionModal={toggleOpenInstructionModal}
                        getStatus={getStatus}
                        viewList={viewList}
                        toggleViewList={toggleViewList}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </ProfileAccordianStyleWrapper>
          <ProfileAccordianStyleWrapper
            defaultOpen={true}
            actions={null}
            header={
              <div className="flex flex-col md:w-1/2 space-y-1.5 ">
                <MundialHeadingText sizeVariant="sm">
                  More About you
                </MundialHeadingText>
                <p className="text-[14px] font-normal text-[#013338]">
                  Tell us more about yourself to give coachees a clearer picture
                  of who you <br />
                  are as a coach and why they should choose you for their
                  coaching journey.
                </p>
              </div>
            }
          >
            <div className="">
              <div className="flex min-h-fit flex-col w-full h-full  pb-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
                  {isEditing ? (
                    <>
                      <div className="col-span-1 flex flex-col ">
                        <RegisterTextInputField
                          name="coach.title_line"
                          defaultValue={coachData?.title_line}
                          textLabel={"Profile Headline"}
                          validationOptions={{
                            required: "Profile Headline is a  required field !",
                          }}
                          validationError={
                            methods.formState.errors.coach?.title_line?.message
                          }
                        ></RegisterTextInputField>
                        {isEditing && (
                          <div className="flex flex-row justify-start gap-3 items-center py-2">
                            <button
                              type="button"
                              onClick={() => setopenTitleLineSuggestion(true)}
                              className="flex flex-row justify-center items-center text-[0.65rem] = text-[#013338]   bg-white hover:bg-[#013338] hover:text-white rounded-full"
                            >
                              <HelpIcon
                                onClick={() => setopenTitleLineSuggestion(true)}
                                sx={{ fontSize: "1.1rem" }}
                              />
                            </button>
                            <em className="text-[0.70rem] text-[#013338] font-semibold">
                              ** The profile headline will be visible at the top
                              of your profile page.
                            </em>
                          </div>
                        )}
                        <CustomModalWrapper
                          backdropClose={true}
                          open={openTitleLineSuggestion}
                          title="Profile Headline Tips"
                          onClose={() => setopenTitleLineSuggestion(false)}
                        >
                          <div className="w-full py-1 flex flex-col">
                            <div className="w-full font-medium text-base py-1 ">
                              We suggest you some tips to add the profile
                              headline.
                            </div>
                            <ul className="flex flex-col justify-start items-start list-disc px-4 pt-6">
                              <li>
                                <b>Keep it Concise</b> : Keep your headline
                                clear and under 15 words.
                              </li>
                              <li>
                                <b>Be Specific</b>: Mention your coaching
                                specialty or unique approach.
                              </li>
                              <li>
                                <b> Stay Authentic</b>: Use language that
                                reflects your coaching style.
                              </li>
                              <li>
                                <b>Highlight Key Benefits</b>: Consider adding a
                                benefit or outcome that potential clients can
                                expect from working with you.
                              </li>
                              <li>
                                <b>Be Welcoming</b>: Make it inviting and
                                approachable.
                              </li>
                            </ul>
                          </div>
                        </CustomModalWrapper>
                      </div>
                      <div className="flex flex-col  col-span-1 row-span-2">
                        <RegisterTextInputField
                          name="coach.about_me"
                          defaultValue={coachData?.about_me}
                          textLabel={"About Me"}
                          validationOptions={{
                            required: "About Me is a required field !",
                          }}
                          multiline
                          rows={5}
                          maxRows={5}
                          slotProps={{
                            input: {
                              className: "style-scroll",
                            },
                          }}
                          validationError={
                            methods.formState.errors.coach?.about_me?.message
                          }
                        ></RegisterTextInputField>
                        {isEditing && (
                          <div className="flex flex-row justify-start gap-3 items-center py-2">
                            <button
                              type="button"
                              onClick={() => setopenAboutMeSuggestions(true)}
                              className="flex flex-row justify-center items-center text-[0.65rem] = text-[#013338]   bg-white hover:bg-[#013338] hover:text-white rounded-full"
                            >
                              <HelpIcon sx={{ fontSize: "1.1rem" }} />
                            </button>
                            <em className="text-[0.70rem] text-[#013338] font-semibold">
                              ** This section will be visible on your profile
                              page, providing insight into your coaching
                              background and approach.
                            </em>
                          </div>
                        )}
                        <CustomModalWrapper
                          backdropClose={true}
                          open={openAboutMeSuggestions}
                          title="Writing an Impactful ‘About Me’"
                          onClose={() => setopenAboutMeSuggestions(false)}
                        >
                          <div className="w-full py-1 flex flex-col">
                            <div className="w-full font-medium text-base py-1 ">
                              We suggest you some tips to add an Impactfull
                              about me.
                            </div>
                            <ul className="flex flex-col justify-start items-start list-disc px-4 ">
                              <li>
                                <b>Introduce Yourself</b>: Share your
                                background, experience, and coaching approach.
                                Make it clear what makes your coaching unique.
                              </li>
                              <li>
                                <b>Be Authentic</b>: Use your own voice to
                                express your values, style, and personality.
                              </li>
                              <li>
                                <b>Highlight Your Niche</b>: Specify your area
                                of expertise or coaching specialty to attract
                                your ideal clients.
                              </li>
                              <li>
                                <b>Focus on Value</b>: Clearly communicate the
                                benefits clients will gain from working with
                                you.
                              </li>
                              <li>
                                <b>Keep it Concise</b>: Be clear and to the
                                point, providing the necessary details without
                                overwhelming potential clients.
                              </li>
                              <li>
                                <b>Highlight Your Expertise</b>: Mention your
                                credentials, certifications, and any relevant
                                experience that adds credibility.
                              </li>
                            </ul>
                          </div>
                        </CustomModalWrapper>
                      </div>
                      <CustomSelect
                        name="coach.languages"
                        textLabel="Languages"
                        options={LanguagesList}
                        defaultValue={coachData?.languages}
                        multiple
                        validationError={
                          methods.formState.errors.coach?.languages?.message
                        }
                      />

                      <RegisterTextInputField
                        type="number"
                        name="coach.experienceYear"
                        defaultValue={coachData?.experienceYear}
                        textLabel={"Years of Experince as a Coach"}
                        validationError={
                          methods.formState.errors.coach?.experienceYear
                            ?.message
                        }
                      ></RegisterTextInputField>

                      <RegisterTextInputField
                        name="coach.linkedin_profile_link"
                        defaultValue={coachData?.linkedin_profile_link}
                        textLabel={" LinkedIn Profile"}
                        validationError={
                          methods.formState.errors.coach?.linkedin_profile_link
                            ?.message
                        }
                      ></RegisterTextInputField>
                      <RegisterTextInputField
                        name="coach.zoomMeetingURL"
                        defaultValue={coachData?.zoomMeetingURL}
                        textLabel={
                          <div className="space-y-1.5 flex flex-col">
                            <span className="text-[#013338] pb-2 text-[18px] font-medium">
                              Meeting URL
                            </span>
                            <span className="text-[14px]">
                              Please enter your unique meeting link (Zoom or
                              Microsoft Teams) for client sessions.
                            </span>
                          </div>
                        }
                        validationError={
                          methods.formState.errors.coach?.zoomMeetingURL
                            ?.message
                        }
                      ></RegisterTextInputField>
                      <DummyTextField
                        keepBorder={false}
                        textLabel="About Me"
                        value={
                          <>
                            <div className="col-span-1 w-full row-span-5 flex flex-col items-center justify-center">
                              <label
                                htmlFor="coach-profile-picture-upload"
                                className={`flex flex-col gap-4 justify-center items-center w-full  relative p-2 rounded-[5px] border border-dashed ${
                                  methods.formState.errors.coach?.image
                                    ? "border-[red]"
                                    : "border-[#3aa7a3]"
                                }`}
                              >
                                <div className="cursor-pointer w-full flex items-center justify-center text-[#3aa7a3] underline underline-offset-4 font-medium">
                                  Select from computer or drop image here
                                </div>
                                <div className="w-full flex flex-col gap-1 justify-start">
                                  <span className="text-[#3aa7a3] font-medium text-sm">
                                    Instructions for uploading proile :
                                  </span>
                                  <span className="text-[red] font-medium text-sm">
                                    **Only JPG/JPEG/PNG/WEBP image files are
                                    allowed
                                  </span>
                                  <span className="text-[red] font-medium text-sm">
                                    **Allowed Image files size limit is 5MB
                                  </span>
                                </div>
                                <DraggableImageUploadComponent
                                  type="image"
                                  children={
                                    <input
                                      accept="image/*"
                                      style={{ display: "none" }}
                                      id="coach-profile-picture-upload"
                                      type="file"
                                      {...methods.register("coach.image", {
                                        validate: (files) => {
                                          const file = files?.[0];
                                          if (file && file instanceof File) {
                                            const allowedTypes = [
                                              "image/jpeg",
                                              "image/jpg",
                                              "image/png",
                                              "image/gif",
                                              "image/webp",
                                            ];
                                            if (
                                              !allowedTypes.includes(file.type)
                                            ) {
                                              return "Only JPEG, PNG, GIF, and WEBP images are allowed.";
                                            }
                                            const maxSize = 5 * 1024 * 1024;
                                            if (file.size > maxSize) {
                                              return "Image file size must be less than 5MB.";
                                            }
                                          }
                                          return true;
                                        },
                                      })}
                                    />
                                  }
                                  labelName="coach-profile-picture-upload"
                                  icon="Image"
                                  formName="coach.image"
                                  def={coachData?.image}
                                  name="Upload Image"
                                  variant="Rectangle"
                                />
                              </label>
                              {methods.formState.errors.coach?.image && (
                                <span className="text-sm font-medium pt-4 w-full text-left text-[red]">
                                  {methods.formState.errors.coach?.image?.message?.toString()}
                                </span>
                              )}
                            </div>
                          </>
                        }
                      />
                    </>
                  ) : (
                    <>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Profile Headline"
                          value={coachData?.title_line}
                        />
                      </div>
                      <div className="col-span-1 row-span-2">
                        <DummyTextField
                          textLabel="About Me"
                          value={coachData?.about_me}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="LinkedIn Profile"
                          value={coachData?.linkedin_profile_link || "-"}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Years of Experince as a Coach"
                          value={coachData?.experienceYear?.toString()}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Languages"
                          value={coachData?.languages?.join(", ")}
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Meeting Link"
                          extraElement={
                            <span className="text-[#013338] pb-2 text-[16px] font-normal">
                              Please enter your unique meeting link (Zoom or
                              Microsoft Teams) for client sessions.
                            </span>
                          }
                          value={coachData?.zoomMeetingURL || "-"}
                        />
                      </div>

                      <div className="col-span-1 row-span-5">
                        <DummyTextField
                          textLabel={
                            <span
                              className={`${
                                coachData?.image !== ""
                                  ? "text-[#013338]"
                                  : "text-[red]"
                              } pb-2 text-[18px] font-medium`}
                            >
                              About Me*
                            </span>
                          }
                          borderStyle="dashed"
                          keepBorder={true}
                          value={
                            <div className="w-full h-full flex items-center justify-center">
                              <div
                                onMouseEnter={() => setShowCircle(true)}
                                onMouseLeave={() => setShowCircle(false)}
                                onClick={() => {
                                  if (profileRef?.current) {
                                    profileRef?.current?.scrollIntoView({
                                      behavior: "smooth",
                                    });
                                    toggleViewList({ X: true });
                                  }
                                }}
                                className="relative w-fit h-fit p-2 flex flex-row justify-center items-center rounded-full cursor-pointer "
                              >
                                {coachData?.image ? (
                                  <Avatar
                                    src={`${backendURL}/usersProfile/${coachData.image}`}
                                    alt={coachData?.name || "coach-image"}
                                    sx={{
                                      width: {
                                        xs: 200,
                                        sm: 150,
                                        md: 200,
                                        xl: 260,
                                      },
                                      height: {
                                        xs: 200,
                                        sm: 150,
                                        md: 200,
                                        xl: 260,
                                      },
                                    }}
                                  />
                                ) : (
                                  <>
                                    <Avatar
                                      sx={{
                                        backgroundColor: "#073F51",
                                        width: {
                                          xs: "4rem",
                                          sm: "6rem",
                                          md: "8rem",
                                        },
                                        height: {
                                          xs: "4rem",
                                          sm: "6rem",
                                          md: "8rem",
                                        },
                                        fontSize: "3rem",
                                        position: "relative",
                                      }}
                                    >
                                      {capitalizeFirstLetter(
                                        coachData?.name ? coachData.name : "-"
                                      )}
                                    </Avatar>
                                  </>
                                )}
                                {!completedAll ? (
                                  <CircleProgress
                                    stepsCompleted={stepsCompleted}
                                    totalSteps={6}
                                    completedAll={completedAll}
                                  />
                                ) : showCircle ? (
                                  <CircleProgress
                                    stepsCompleted={stepsCompleted}
                                    totalSteps={6}
                                    completedAll={completedAll}
                                  />
                                ) : (
                                  ""
                                )}
                                {/* <CircleProgress
                                                stepsCompleted={stepsCompleted}
                                                totalSteps={6}
                                                completedAll={completedAll}
                                              /> */}
                              </div>
                            </div>
                          }
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </ProfileAccordianStyleWrapper>
          <CoachingCredentials
            isEditing={isEditing}
            togglePageRefresh={refetch}
            coachcredentialsList={coachData?.coachingCredentialsList}
          />
          <div className="w-full col-span-2 grid grid-cols-1 md:grid-cols-1 gap-[18px] auto-rows-fr">
            <CoachCertificateUpdateModal
              coachCertificateList={coachData?.coachCertificatesList || []}
              isEditing={isEditing}
              togglePageRefresh={() => refetch()}
            />
          </div>
          <ProfileAccordianStyleWrapper
            defaultOpen={true}
            actions={null}
            header={
              <MundialHeadingText sizeVariant="sm">
                Specialties
              </MundialHeadingText>
            }
          >
            <div className="w-fulll h-full">
              <div className="flex min-h-fit flex-col w-full h-full  pb-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full  ">
                  {isEditing ? (
                    <>
                      <div className="col-span-1">
                        <CustomSelect
                          name="coach.coaching_focus_area"
                          textLabel="Coaching Focus Areas"
                          options={Coaching_Focus_Area.map((a) => a.tag)}
                          defaultValue={coachData?.coaching_focus_area?.map(
                            (a) => a.tag
                          )}
                          multiple={true}
                          validationError={
                            methods.formState.errors.coach?.coaching_focus_area
                              ?.message
                          }
                        />
                      </div>
                      <div className="col-span-1">
                        <CustomSelect
                          name="coach.industries"
                          textLabel="Industries of Expertise"
                          options={IndustriesOptions}
                          defaultValue={coachData?.industries}
                          multiple={true}
                          validationError={
                            methods.formState.errors.coach?.industries?.message
                          }
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Coaching Focus Areas"
                          value={
                            coachData?.coaching_focus_area
                              ?.map((a) => `${a.tag}`)
                              .join(", ") || "N/A"
                          }
                        />
                      </div>
                      <div className="col-span-1">
                        <DummyTextField
                          textLabel="Industries of Expertise"
                          value={coachData?.industries?.join(", ") || "N/A"}
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </ProfileAccordianStyleWrapper>
          <WorkExperience
            coachExperienceList={coachData?.coachWorkExperiencesList || []}
            isEditing={isEditing}
            togglePageRefresh={refetch}
          />
          <CoachEducationalBackground
            coachEducationBackgroundList={
              coachData?.coachEducationalBackgroundList
            }
            isEditing={isEditing}
            togglePageRefresh={refetch}
          />
          <ProfileAccordianStyleWrapper
            defaultOpen={true}
            showCollapseButton={false}
            actions={
              <>
                <FormGroup
                  sx={{ width: "100%", justifyContent: "space-between", py: 0 }}
                >
                  {isEditing ? (
                    <CustomSwitchGray
                      {...methods.register("coach.nonProfitCoaching")}
                      disabled={!isEditing}
                      defaultChecked={coachData?.nonProfitCoaching}
                    />
                  ) : (
                    <CustomSwitch
                      checked={coachData?.nonProfitCoaching}
                      defaultChecked={coachData?.nonProfitCoaching}
                      readOnly
                    />
                  )}
                </FormGroup>
              </>
            }
            header={
              <div className="flex flex-col md:w-1/2 space-y-1.5 ">
                <MundialHeadingText sizeVariant="sm">
                  Join Our Non-Profit Coaching Programs
                </MundialHeadingText>
                <p className="text-[16px] font-normal text-[#013338]">
                  Please select the slider to confirm your interest. Learn more
                  about our non-profit programs.
                </p>
              </div>
            }
          >
            <span className=""></span>
          </ProfileAccordianStyleWrapper>
          {coachData?.approve == 0 && !isEditing && (
            <WhiteRoundedBox className="w-full h-fit flex flex-col">
              <div
                ref={submitRef}
                className="flex flex-1 items-center pt-10 justify-center"
              >
                <YellowButton
                  type="button"
                  loading={loadingUpdateReview}
                  shouldDisable={loading || loadingUpdateReview}
                  onClick={() => handelReviewSubmit()}
                  text="submit for review"
                  className="max-w-fit px-7"
                />
              </div>
            </WhiteRoundedBox>
          )}
        </>
      </div>
    </FormProvider>
  );
};

export default Page;
