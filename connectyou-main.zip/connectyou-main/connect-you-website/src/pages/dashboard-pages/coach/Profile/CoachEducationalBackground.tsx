/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { FormControl, TextField } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { Controller, useForm } from "react-hook-form";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { useNotify } from "../../../../lib/Notify";
import { CoachEducationalBackground_Type } from "../../../../Types/backend/CoachEducationalBackground_Type";
import customAlert from "../../../../lib/swalExtentions";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import { YellowButton } from "../../../../components/buttons/ThemeButtons";
import Warning from "../../../../components/UI/Warning";
import MenuButton from "../../../../components/buttons/MenuButton";
import DummyTextField from "../../../../components/inputFields/DummyTextField";
import moment from "moment-timezone";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import ProfileAccordianStyleWrapper from "../../../../components/wrappers/ProfileAccordianStyleWrapper";
import ModalCloseButton from "../../../../components/buttons/ModalCloseButton";
import dayjs from "dayjs";

interface CoachEducationalBackgroundProps {
  coachEducationBackgroundList: CoachEducationalBackground_Type[] | undefined;
  togglePageRefresh: () => void;
  isEditing: boolean;
}
const CoachEducationalBackground: React.FC<CoachEducationalBackgroundProps> = ({
  coachEducationBackgroundList,
  togglePageRefresh,
  isEditing,
}) => {
  const { notifyMe } = useNotify();
  const [openEducation, setOpenEducation] = React.useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  type EducationValue = {
    organization: string;
    degree: string;
    startDate: any | null;
    endDate: any | null;
  };

  const {
    register,
    handleSubmit,
    formState: { errors: errors },
    reset,
    control,
    watch,
  } = useForm<EducationValue>({
    mode: "onChange",
    reValidateMode: "onChange",
  });

  const onsubmitEducation = handleSubmit(async (data) => {
    setLoading(true);
    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-coaching-education`,
        data
      );
      if (response.status === 200) {
        reset();
        setOpenEducation(false);
        togglePageRefresh();
        return notifyMe({
          message: "Education added successfully",
          severity: "success",
        });
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
      }
    } finally {
      setLoading(false);
    }
  });

  //delete education
  const deleteEducation = (id: string) => {
    setLoading(true);
    setPreviewEdu(null);
    customAlert
      .fire({
        title: "Are you sure?",
        text: `You want to delete it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, delete It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result: any) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI.get(
              `${backendURL}/coach/profile/education-delete/${id}`
            );
            if (response.data.success === true) {
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            customAlert.fire({
              title: `Delete!`,
              text: `Education delete successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            togglePageRefresh();
          }
        } else {
          // setPreviewEdu(
          //   coachEducationBackgroundList?.find((a) => a._id === id) || null
          // );
          return setLoading(false);
        }
      });
  };

  const [previewEdu, setPreviewEdu] =
    useState<null | CoachEducationalBackground_Type>(null);

  return (
    <>
      <ProfileAccordianStyleWrapper
        defaultOpen={true}
        actions={
          <>
            {isEditing && (
              <YellowButton
                onClick={() => setOpenEducation(true)}
                text="+add"
                className="max-w-fit px-5"
              />
            )}
          </>
        }
        header={
          <MundialHeadingText sizeVariant="sm">Education</MundialHeadingText>
        }
      >
        <div className="">
          <div className="flex min-h-fit flex-col w-full h-full  pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
              {coachEducationBackgroundList &&
              coachEducationBackgroundList?.length > 0 ? (
                coachEducationBackgroundList?.map((edu, i) => (
                  <React.Fragment key={`coach-education-list-item-${i}`}>
                    <div className="col-span-2">
                      <DummyTextField
                        borderColor={isEditing ? "seaBlue" : "darkSea"}
                        value={
                          <>
                            <div className="flex w-full flex-col md:flex-row pr-10 md:pr-0  md:items-center justify-between">
                              <span className="font-semibold">
                                {edu.degree}
                              </span>
                              <span className="font-medium">
                                {edu.organization}
                              </span>
                              <span className="font-normal">{`${moment(
                                edu.startDate
                              ).format("MMMM YYYY")}-${moment(
                                edu.endDate
                              ).format("MMMM YYYY")}`}</span>
                              <div>
                                <div className="absolute z-[10] top-0 right-0 p-1">
                                  {isEditing ? (
                                    <MenuButton
                                      options={[
                                        {
                                          label: "Preview",
                                          action: () => setPreviewEdu(edu),
                                        },
                                        {
                                          label: "Delete",
                                          action: () =>
                                            deleteEducation(edu._id),
                                        },
                                      ]}
                                    ></MenuButton>
                                  ) : (
                                    <MenuButton
                                      options={[
                                        {
                                          label: "Preview",
                                          action: () => setPreviewEdu(edu),
                                        },
                                      ]}
                                    ></MenuButton>
                                  )}
                                </div>
                              </div>
                            </div>
                          </>
                        }
                      />
                    </div>
                  </React.Fragment>
                ))
              ) : (
                <div className="flex col-span-full">
                  <Warning>
                    You have not added your education backgroud details yet !
                  </Warning>
                </div>
              )}
            </div>
          </div>
        </div>
      </ProfileAccordianStyleWrapper>

      {/* Education */}
      <CustomModalWrapper
        backdropClose={false}
        open={openEducation}
        title="Add New Educational Qualification"
        onClose={() => setOpenEducation(false)}
      >
        <form
          className="w-full  overflow-auto  px-6 "
          onSubmit={onsubmitEducation}
        >
          <div className="flex flex-col gap-10">
            <div className="flex flex-col gap-5 w-full">
              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Organization</p>
                <TextField
                  id="outlined-required"
                  placeholder="Organization"
                  fullWidth
                  multiline
                  minRows={1}
                  size="small"
                  {...register("organization", {
                    required: "Please enter organization name",
                    minLength: {
                      value: 3,
                      message: "Atleast 3 characters are required !",
                    },
                  })}
                  error={!!errors.organization}
                  helperText={errors.organization?.message}
                  FormHelperTextProps={{
                    style: {
                      marginLeft: 1,
                    },
                  }}
                />
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Degree</p>
                <TextField
                  id="outlined-required"
                  placeholder="Degree"
                  fullWidth
                  disabled={!watch("organization")}
                  size="small"
                  {...register("degree", {
                    required: "Please enter degree name",
                    minLength: {
                      value: 3,
                      message: "Atleast 3 characters are required !",
                    },
                  })}
                  error={!!errors.degree}
                  helperText={errors.degree?.message}
                  FormHelperTextProps={{
                    style: {
                      marginLeft: 1,
                    },
                  }}
                />
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Start Date</p>
                <FormControl fullWidth size="small" error={!!errors.startDate}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <Controller
                      control={control}
                      name="startDate"
                      rules={{
                        required: "Start Date is required",
                        validate: (value) => {
                          if (!value) {
                            return "Starting Date is required";
                          }
                          if (value && !dayjs(value).isValid()) {
                            return "Please select a valid date";
                          }
                          if (
                            value &&
                            !dayjs(value, "MM-DD-YYYY", true).isValid()
                          ) {
                            return "Please select a valid date in MM-DD-YYYY format";
                          }
                          // if (dayjs(value).isBefore(watch("startDate"))) {
                          //   return "End Date must be later than the start date !";
                          // }
                          return true;
                        },
                      }}
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          disableFuture
                          disabled={!watch("degree") || !watch("organization")}
                          views={["year", "month", "day"]}
                          sx={{
                            width: "100%",
                            "& .MuiInputBase-root": {
                              height: "43px",
                              overflow: "hidden",
                            },
                            "& .MuiFormLabel-root": {
                              top: -5,
                            },
                            "& .MuiInputLabel-shrink": {
                              top: 0,
                            },
                          }}
                          slotProps={{
                            inputAdornment: {
                              position: "start",
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {errors?.startDate && (
                    <p className="form-error-message">
                      {String(errors.startDate.message)}
                    </p>
                  )}
                </FormControl>
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">End Date</p>
                <FormControl fullWidth size="small" error={!!errors.endDate}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <Controller
                      control={control}
                      name="endDate"
                      rules={{
                        required: "End Date is required",
                        validate: (value) => {
                          if (!value) {
                            return "End Date is required";
                          }
                          if (value && !dayjs(value).isValid()) {
                            return "Please select a valid date";
                          }
                          if (
                            value &&
                            !dayjs(value, "MM-DD-YYYY", true).isValid()
                          ) {
                            return "Please select a valid date in MM-DD-YYYY format";
                          }
                          if (dayjs(value).isBefore(watch("startDate"))) {
                            return "End Date must be later than the start date !";
                          }
                          return true;
                        },
                      }}
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          views={["year", "month", "day"]}
                          disableFuture
                          disabled={
                            !watch("degree") ||
                            !watch("organization") ||
                            !watch("startDate")
                          }
                          sx={{
                            width: "100%",
                            "& .MuiInputBase-root": {
                              height: "43px",
                              overflow: "hidden",
                            },
                            "& .MuiFormLabel-root": {
                              top: -5,
                            },
                            "& .MuiInputLabel-shrink": {
                              top: 0,
                            },
                          }}
                          slotProps={{
                            inputAdornment: {
                              position: "start",
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {errors?.endDate && (
                    <p className="form-error-message">
                      {String(errors.endDate.message)}
                    </p>
                  )}
                </FormControl>
              </div>

              <div className="flex w-1/2 mx-auto">
                <YellowButton
                  shouldDisable={
                    loading ||
                    !watch("degree") ||
                    !watch("organization") ||
                    !watch("startDate") ||
                    Object.keys(errors).length > 0
                  }
                  loading={loading}
                  type="submit"
                  text="Save"
                />
              </div>
            </div>
          </div>
        </form>
      </CustomModalWrapper>

      <CustomModalWrapper
        open={!!previewEdu}
        onClose={() => setPreviewEdu(null)}
        title={"Educational Background Details"}
      >
        <>
          <div className="w-full flex flex-col space-y-2 text-[#013338] bg-white p-4 rounded-md shadow-md">
            <span className="text-lg font-semibold">
              {`${previewEdu?.degree} at ${previewEdu?.organization}`}
            </span>

            <span className="text-sm text-gray-600">
              {`${moment(previewEdu?.startDate).format("MMMM YYYY")} - ${moment(
                previewEdu?.endDate
              ).format("MMMM YYYY")}`}
            </span>

            <span className="text-[#3aa7a3] font-medium text-xs">
              Added:{" "}
              {moment(previewEdu?.createdAt).format("DD MMMM YYYY hh:mm A")}
            </span>
          </div>
          {/* {previewEdu && (
            <div className="w-full py-4 flex items-center justify-center">
              <CancelButton
                text="Delete"
                onClick={() => {
                  deleteEducation(previewEdu?._id);
                }}
                className="max-w-fit px-5"
              />
            </div>
          )} */}
          <ModalCloseButton onClick={() => setPreviewEdu(null)} />
        </>
      </CustomModalWrapper>
    </>
  );
};

export default CoachEducationalBackground;
