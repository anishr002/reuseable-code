import React, { useEffect, useState } from "react";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  TextField,
} from "@mui/material";
import MUIAutocomplete from "@mui/material/Autocomplete";
import { Edit, HelpOutline } from "@mui/icons-material";
import { useNotify } from "../../../../lib/Notify";
import { Coach_Data_Type } from "../../../../Types/backend/Coach_Data_Type";
import SubmitModalHeader from "../../../../components/wrappers/SubmitModalHeader";
import { EricksonPartnerOptions } from "../../../../Options/Options";
import DummyTextField from "../../../../components/inputFields/DummyTextField";
import { FaCheck } from "react-icons/fa";
import { IoCloseCircle } from "react-icons/io5";
import LoadingElement from "../../../../components/UI/LoadingElement";

interface EricksonReferenceProps {
  userData: Pick<Coach_Data_Type, "refering_partner" | "refered_by_partner">;
  togglePageRefresh: () => void;
  allowEdit?: boolean;
}
const EricksonReference: React.FC<EricksonReferenceProps> = ({
  userData,
  togglePageRefresh,
  allowEdit = true,
}) => {
  const { notifyMe } = useNotify();
  const [loading, setLoading] = useState<boolean>(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [openConfirmDialog, setOpenConfirmDialog] = useState(false);
  const [region, setRegion] = useState<string | null>(null);
  const [country, setCountry] = useState<string | null>(null);

  useEffect(() => {
    if (userData && userData.refering_partner) {
      setRegion(userData.refering_partner.region);
      setCountry(userData.refering_partner.country);
    }
  }, [userData]);

  const handleConfirmDialog = (confirmed: boolean) => {
    setOpenConfirmDialog(false);
    if (confirmed) {
      setOpenDialog(true);
    } else {
      handleSkipPartnerDetails();
    }
  };

  const handleSkipPartnerDetails = async () => {
    try {
      setLoading(true);
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-more`,
        {
          refered_by_partner: 2,
          refering_partner: null,
        }
      );
      if (response.status === 200) {
        togglePageRefresh();
        notifyMe({
          message: "Profile updated successfully",
          severity: "success",
        });
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      notifyMe({ message: "Failed to update profile", severity: "error" });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitPartnerDetails = async () => {
    if (!region || !country) {
      notifyMe({
        message: "Please select both region and country",
        severity: "error",
      });
      return;
    }
    try {
      setLoading(true);
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-more`,
        {
          refered_by_partner: 1,
          refering_partner: { region, country },
        }
      );
      if (response.status === 200) {
        togglePageRefresh();
        notifyMe({
          message: "Profile updated successfully",
          severity: "success",
        });
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      notifyMe({ message: "Failed to update profile", severity: "error" });
    } finally {
      setLoading(false);
      setOpenDialog(false);
    }
  };

  return (
    <>
      <div className="col-span-1">
        <DummyTextField
          borderColor={allowEdit ? "seaBlue" : "darkSea"}
          textLabel={
            <div className="flex flex-row items-center justify-between w-full text-[#013338] pb-2 text-[18px] font-medium">
              <span>Did an Erickson partner refer you to us?</span>
              {allowEdit && (
                <IconButton
                  sx={{
                    color: userData?.refered_by_partner
                      ? "#3aa7a3"
                      : "action.active",
                    transition: "0.3s",
                    "&:hover": { transform: "scale(1.0)" },
                  }}
                  onClick={() => setOpenConfirmDialog(true)}
                >
                  {userData?.refered_by_partner === 0 ? (
                    <HelpOutline />
                  ) : (
                    <Edit />
                  )}
                </IconButton>
              )}
            </div>
          }
          extraElement={
            userData?.refered_by_partner === 0 ? (
              <span className="text-[#013338] font-normal text-[14px]">
                If yes, please select the partner's country from the dropdown
                menu.
              </span>
            ) : null
          }
          value={
            loading ? (
              <div>
                <LoadingElement className="max-w-10 max-h-10" />
              </div>
            ) : (
              <div className=" w-full flex items-center justify-between">
                {userData?.refered_by_partner === 1 ? (
                  <span className="text-[#3aa7a3]">Yes</span>
                ) : (
                  <span className="text-red-700">No</span>
                )}
                {userData?.refered_by_partner === 1 ? (
                  <FaCheck className="text-[#3aa7a3]"></FaCheck>
                ) : (
                  <IoCloseCircle className="text-red-700"></IoCloseCircle>
                )}
              </div>
            )
          }
        />
      </div>
      {userData?.refered_by_partner === 1 && userData?.refering_partner && (
        <div className="col-span-1">
          <DummyTextField
            borderColor={allowEdit ? "seaBlue" : "darkSea"}
            textLabel={
              <div className="flex flex-row items-center justify-between w-full text-[#013338] pb-2 text-[18px] font-medium">
                <span>Referring Erickson partner</span>
                {allowEdit && (
                  <IconButton
                    sx={{
                      color:
                        userData?.refered_by_partner === 1
                          ? "#3aa7a3"
                          : "action.active",
                      transition: "0.3s",
                      "&:hover": { transform: "scale(1.0)" },
                    }}
                    onClick={() => setOpenConfirmDialog(true)}
                  >
                    <Edit />
                  </IconButton>
                )}
              </div>
            }
            value={
              <div className=" flex w-full items-center justify-start gap-1">
                <span> {userData?.refering_partner.region}</span>
                <span>{`(${userData?.refering_partner.country})`}</span>
              </div>
            }
          />
        </div>
      )}
      {/* Confirmation Dialog */}
      <Dialog open={openConfirmDialog}>
        <DialogTitle sx={{ fontFamily: "Quicksand" }}>
          <SubmitModalHeader
            title="Referral Confirmation"
            onClose={() => {
              setOpenDialog(false);
              setOpenConfirmDialog(false);
            }}
          />
        </DialogTitle>
        <DialogContent sx={{ fontFamily: "Quicksand" }}>
          Did an Erickson partner refer you to us? If yes, please select the
          partner's country from the dropdown menu.
        </DialogContent>
        <DialogActions
          sx={{
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            p: 3,
          }}
        >
          <Button
            variant="outlined"
            sx={{
              color: "white",
              backgroundColor: "red",
              borderColor: "red",
              minWidth: "10.3rem",
              borderRadius: "20px",
              fontFamily: "Quicksand",
              "&:hover": {
                borderColor: "red",
                backgroundColor: "white",
                color: "red",
              },
            }}
            onClick={() => handleConfirmDialog(false)}
            color="error"
          >
            No
          </Button>
          <Button
            variant="outlined"
            sx={{
              color: "white",
              backgroundColor: "#EBBE34",
              borderColor: "#EBBE34",
              minWidth: "10.3rem",
              borderRadius: "20px",
              fontFamily: "Quicksand",
              "&:hover": {
                borderColor: "#EBBE34",
                backgroundColor: "white",
                color: "#EBBE34",
              },
            }}
            onClick={() => setOpenConfirmDialog(false)}
            color="warning"
          >
            Ask Me Later
          </Button>
          <Button
            onClick={() => handleConfirmDialog(true)}
            color="primary"
            variant="outlined"
            sx={{
              color: "white",
              backgroundColor: "#3aa7a3",
              borderColor: "#3aa7a3",
              minWidth: "10.3rem",
              borderRadius: "20px",
              fontFamily: "Quicksand",
              "&:hover": {
                borderColor: "#3aa7a3",
                backgroundColor: "white",
                color: "#3aa7a3",
              },
            }}
          >
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog for selecting region and country */}
      <Dialog open={openDialog}>
        <DialogTitle>
          <SubmitModalHeader
            title="Select Partner Details"
            onClose={() => {
              setOpenDialog(false);
              setOpenConfirmDialog(false);
            }}
          />
        </DialogTitle>
        <DialogContent
          sx={{
            minWidth: 400,
            p: 6,
            display: "flex",
            flexDirection: "column",
            gap: 2,
            overflow: "visible",
            fontFamily: "Quicksand",
          }}
        >
          <MUIAutocomplete
            options={EricksonPartnerOptions}
            getOptionLabel={(option) => option.region}
            onChange={(_, newValue) => {
              setRegion(newValue?.region || null);
              setCountry(null);
            }}
            renderInput={(params) => <TextField {...params} label="Region" />}
          />
          {region && (
            <MUIAutocomplete
              options={
                EricksonPartnerOptions.find((r) => r.region === region)
                  ?.countries || []
              }
              value={country}
              onChange={(_, newValue) => setCountry(newValue)}
              renderInput={(params) => (
                <TextField {...params} label="Country" />
              )}
              sx={{ mt: 2 }}
            />
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            variant="outlined"
            sx={{
              color: "white",
              backgroundColor: "red",
              borderColor: "red",
              minWidth: "10.3rem",
              borderRadius: "20px",
              fontFamily: "Quicksand",
              "&:hover": {
                borderColor: "red",
                backgroundColor: "white",
                color: "red",
              },
            }}
            onClick={() => setOpenDialog(false)}
            color="error"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmitPartnerDetails}
            variant="outlined"
            sx={{
              color: "white",
              backgroundColor: "#EBBE34",
              borderColor: "#EBBE34",
              minWidth: "10.3rem",
              borderRadius: "20px",
              fontFamily: "Quicksand",
              "&:hover": {
                borderColor: "#EBBE34",
                backgroundColor: "white",
                color: "#EBBE34",
              },
            }}
            color="primary"
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default EricksonReference;
