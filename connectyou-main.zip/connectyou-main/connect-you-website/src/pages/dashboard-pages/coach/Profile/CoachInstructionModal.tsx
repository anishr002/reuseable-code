import Logo from "/loginLogo.png";
import { Box, Button, Modal, Typography } from "@mui/material";
import { Coach_Data_Type } from "../../../../Types/backend/Coach_Data_Type";
import ModalCloseButton from "../../../../components/buttons/ModalCloseButton";

const CoachInstructionModal = ({
  coachCertificateList,
  coachcredentialsList,
  UserData,
  open,
  toggleOpenModal,
}: {
  coachCertificateList: number;
  coachcredentialsList: number;
  open: boolean;
  toggleOpenModal: () => void;
  UserData: Pick<
    Coach_Data_Type,
    | "image"
    | "name"
    | "Lname"
    | "gender"
    | "emailVerified"
    | "calendarStatus"
    | "approve"
  >;
}) => {
  return (
    <>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => toggleOpenModal()}
        sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        {/* Modal data start */}
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: 300, sm: 450 },
            height: 450,
            overflow: "auto",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,
            py: 4,
            borderRadius: 1,
          }}
        >
          <ModalCloseButton onClick={() => toggleOpenModal()} />
          <Box
            sx={{
              width: "100%",
              display: "flex",
              justifyContent: "start",
              alignItems: "start",
              flexDirection: "column",
              p: 2,
              gap: 2,
            }}
          >
            <img
              src={Logo}
              alt="Website-Logo"
              className="w-1/2 py-10 object-contain mx-auto"
            />
            <Typography
              variant="h6"
              sx={{
                fontWeight: 600,
                width: "100%",
                textAlign: "center",
                color: "#013338",
                fontFamily: "Quicksand",
              }}
            >
              You are Almost There !
            </Typography>

            <>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: 600,
                  width: "100%",
                  textAlign: "center",
                  color: "black",
                  fontFamily: "Quicksand",
                  px: 1,
                }}
              >
                Please complete these steps mentioned below, so that your
                profile can be reviewed and approved to get listed in the
                coaches section of the portal.
              </Typography>

              {[
                {
                  Step: 1,
                  completed:
                    UserData.image !== "" &&
                    UserData.name !== "" &&
                    UserData.Lname !== "" &&
                    UserData.gender !== ""
                      ? true
                      : false,
                  label: "Add a Profile Picture, and add personal details",
                  description: `Once you have created a Coach Profile on the Connect You Portal, you can add your details in the profile, start by adding the profile picture of your choice, and add your personal information.`,
                },
                {
                  Step: 2,
                  completed: UserData.emailVerified === 1,
                  label: "Complete the Email Verification.",
                  description:
                    "Verify the email address you have provided while creating this profile.",
                },
                {
                  Step: 3,
                  completed: UserData.calendarStatus === 1,
                  label: "Add your Google Calendar",
                  description:
                    "Sync your Google calendar with our platform to get updated, notified, and organized.",
                },
                // {
                //   Step: 4,
                //   completed: false,
                //   label: "Add a Username",
                //   description:
                //     "Add your unique username that can help you sign in or get identified on the portal.",
                // },
                // {
                //   Step: 5,
                //   completed: false,
                //   label: "Select your preferred time zone.",
                //   description:
                //     "Choose a time zone of your preference. Note that your time zone will be used to add booking times and available slots for booking your sessions.",
                // },
                // {
                //   Step: 6,
                //   completed: false,
                //   label: "Add a Meeting Link",
                //   description:
                //     "Add a meeting link of your preference, that a coachee can follow to join the session they book with you.",
                // },
                {
                  Step: 7,
                  completed: coachCertificateList > 0,
                  label: "Add Certificates",
                  description:
                    "Add the certifications you have acquired. These certifications are visible to the public and can be used in advanced filters in the coaches list. At least one certificate is required to get listed in the marketplace.",
                },
                {
                  Step: 8,
                  completed: coachcredentialsList > 0,
                  label: "Add Coaching Credentials",
                  description:
                    "Add your coaching credentials. These credentials are visible to the public and can be used in advanced filters in the coaches list. At least one credential is required to get listed in the marketplace.",
                },
                {
                  Step: 9,
                  completed: UserData.approve === 1,
                  label: "Get profile approval from the Admin",
                  description: `Once you have completed all the steps, you can submit your profile for approval from the admin.`,
                },
              ].map((int, i) => (
                <Typography
                  key={i}
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                    width: "100%",
                    textAlign: "left",
                    color: `${int.completed ? "#3aa7a3" : "red"}`,
                    fontFamily: "Quicksand",
                    px: 1,
                  }}
                >
                  {i + 1}. {int.label} {!int.completed && "(Pending)"}
                </Typography>
              ))}
              <Typography
                variant="caption"
                sx={{
                  fontWeight: 300,
                  width: "100%",
                  textAlign: "center",
                  color: "black",
                  fontFamily: "Quicksand",
                  px: 1,
                }}
              >
                You can view your Progress in the Profile Status Card, available
                on your profile page's left hand side section.
              </Typography>
              <Button
                variant="outlined"
                onClick={() => toggleOpenModal()}
                sx={{
                  px: 1,
                  color: "white",
                  backgroundColor: "#EBBE34",
                  borderColor: "#EBBE34",
                  borderRadius: "20px",
                  fontFamily: "Quicksand",
                  mx: "auto",
                  "&:hover": {
                    borderColor: "white",
                    backgroundColor: "white",
                    color: "#EBBE34",
                  },
                }}
              >
                CONTINUE
              </Button>
            </>
          </Box>
        </Box>
      </Modal>
    </>
  );
};

export default CoachInstructionModal;
