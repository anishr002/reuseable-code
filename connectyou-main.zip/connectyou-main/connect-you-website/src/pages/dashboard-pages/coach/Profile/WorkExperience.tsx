/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { Controller, useForm } from "react-hook-form";
import { Checkbox, FormControl, TextField } from "@mui/material";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { useNotify } from "../../../../lib/Notify";
import { CoachWorkExp_Type } from "../../../../Types/backend/CoachWorkExp_Type";
import { updateHubSpotInfo } from "../../../../lib/hubspot";
import customAlert from "../../../../lib/swalExtentions";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import { YellowButton } from "../../../../components/buttons/ThemeButtons";
import Warning from "../../../../components/UI/Warning";
import MenuButton from "../../../../components/buttons/MenuButton";
import moment from "moment-timezone";
import DummyTextField from "../../../../components/inputFields/DummyTextField";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import ProfileAccordianStyleWrapper from "../../../../components/wrappers/ProfileAccordianStyleWrapper";
import dayjs from "dayjs";
import ModalCloseButton from "../../../../components/buttons/ModalCloseButton";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

interface WorkExperienceProps {
  coachExperienceList: CoachWorkExp_Type[];
  togglePageRefresh: () => void;
  isEditing: boolean;
}
const WorkExperience: React.FC<WorkExperienceProps> = ({
  coachExperienceList,
  togglePageRefresh,
  isEditing,
}) => {
  const [Open, setOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const { notifyMe } = useNotify();

  type ExperienceValue = {
    organization: string;
    position: string;
    startDate: any | null;
    endDate: any | null;
    endDateCheckbox: any | null;
  };

  const {
    register,
    handleSubmit,
    formState: { errors: errors, isDirty },
    reset,
    control,
    watch,
    trigger,
    clearErrors,
  } = useForm<ExperienceValue>({
    mode: "onChange",
    reValidateMode: "onChange",
  });

  const [previewExp, setpreviewExp] = useState<CoachWorkExp_Type | null>(null);
  const endDateCheckboxExperience = watch("endDateCheckbox");

  const onhandleSubmit = handleSubmit(async (data) => {
    const isValid = await trigger(); // This triggers validation of all fields

    if (!isValid || !isDirty || Object.keys(errors).length > 0) {
      return notifyMe({
        message: "Please fix the errors before submitting.",
        severity: "warning",
      });
    }
    setLoading(true);

    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/profile/profile-update-coaching-experience`,
        data
      );
      if (response.status === 200) {
        reset();
        setOpen(false);
        togglePageRefresh();
        updateHubSpotInfo({ userType: "coach" });
        return notifyMe({
          message: "Coaching experience added successfully",
          severity: "success",
        });
      }
    } catch (error: any) {
      console.log("submit error", error);
      if (
        error.response.status === 500 ||
        error.response.status === 400 ||
        error.response.status === 401 ||
        error.response.status === 403 ||
        error.response.status === 404 ||
        error.response.status === 409
      ) {
        return notifyMe({
          message: error.response.data.message
            ? error.response.data.message
            : "Something went wrong",
          severity: "error",
        });
      }
    } finally {
      setLoading(false);
    }
  });

  const deleteExperience = (id: string) => {
    setLoading(true);
    setpreviewExp(null);
    customAlert
      .fire({
        title: "Are you sure?",
        text: `You want to delete it`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: `Yes, delete It!`,
        cancelButtonText: "Not, Now",
        reverseButtons: true,
      })
      .then(async (result: any) => {
        if (result.isConfirmed) {
          setLoading(true);
          try {
            const response = await httpAPI.get(
              `${backendURL}/coach/profile/experience-delete/${id}`
            );
            if (response.data.success === true) {
              return setLoading(false);
            }
          } catch (error) {
            console.error("Error accepting:", error);
          } finally {
            setLoading(false);
            customAlert.fire({
              title: `Delete!`,
              text: `Experience delete successfully`,
              icon: "success",
              showConfirmButton: false,
              timer: 1500,
            });
            togglePageRefresh();
            updateHubSpotInfo({ userType: "coach" });
          }
        } else {
          // setpreviewExp(coachExperienceList.find((a) => a._id === id) || null);
          return setLoading(false);
        }
      });
  };

  return (
    <>
      <ProfileAccordianStyleWrapper
        defaultOpen={true}
        actions={
          <>
            {isEditing && (
              <YellowButton
                onClick={() => setOpen(true)}
                text="+add"
                className="max-w-fit px-5"
              />
            )}
          </>
        }
        header={
          <MundialHeadingText sizeVariant="sm">
            Work Experience
          </MundialHeadingText>
        }
      >
        <div className="">
          <div className="flex min-h-fit flex-col w-full h-full  pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[18px] gap-y-[18px] w-full">
              {coachExperienceList && coachExperienceList.length > 0 ? (
                coachExperienceList.map((work, i) => (
                  <React.Fragment key={`coach-work-experience-list-item-${i}`}>
                    <div className="col-span-2">
                      <DummyTextField
                        borderColor={isEditing ? "seaBlue" : "darkSea"}
                        value={
                          <>
                            <div className="flex w-full break-words whitespace-normal flex-col md:flex-row md:items-center pr-10 md:pr-0 justify-between">
                              <span className="font-semibold">
                                {work.position}
                              </span>
                              <span className="font-medium">
                                {work.organization}
                              </span>
                              <span className="font-normal">{`${moment(
                                work.startDate
                              ).format("MMMM YYYY")}-${
                                work.workingOn
                                  ? "Present"
                                  : moment(work.endDate).format("MMMM YYYY")
                              }`}</span>
                              <div>
                                <div className="absolute right-0 top-0 p-1 z-10">
                                  {isEditing ? (
                                    <MenuButton
                                      options={[
                                        {
                                          label: "Preview",
                                          action: () => setpreviewExp(work),
                                        },
                                        {
                                          label: "Delete",
                                          action: () =>
                                            deleteExperience(work._id),
                                        },
                                        // {
                                        //   label: "Edit",
                                        //   action: () => undefined,
                                        // },
                                      ]}
                                    ></MenuButton>
                                  ) : (
                                    <MenuButton
                                      options={[
                                        {
                                          label: "Preview",
                                          action: () => setpreviewExp(work),
                                        },
                                      ]}
                                    ></MenuButton>
                                  )}
                                </div>
                              </div>
                            </div>
                          </>
                        }
                      />
                    </div>
                  </React.Fragment>
                ))
              ) : (
                <div className="flex col-span-full">
                  <Warning>You have not added your work history yet !</Warning>
                </div>
              )}
            </div>
          </div>
        </div>
      </ProfileAccordianStyleWrapper>

      {/* add Experience */}
      <CustomModalWrapper
        backdropClose={false}
        open={Open}
        title=" Add New Work Experience"
        onClose={() => setOpen(false)}
      >
        <form className="w-full  pt-5  px-6" onSubmit={onhandleSubmit}>
          <div className="flex flex-col gap-10">
            <div className="flex flex-col gap-5 w-full">
              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Organization</p>
                <TextField
                  id="outlined-required"
                  placeholder="Organization"
                  fullWidth
                  multiline
                  minRows={1}
                  size="small"
                  {...register("organization", {
                    required: "Please enter organization name",
                    minLength: {
                      value: 3,
                      message: "Atleast 3 characters are required !",
                    },
                  })}
                  error={!!errors.organization}
                  helperText={errors.organization?.message}
                  FormHelperTextProps={{
                    style: {
                      marginLeft: 1,
                    },
                  }}
                />
              </div>
              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Position</p>
                <TextField
                  id="outlined-required"
                  placeholder="Position"
                  fullWidth
                  disabled={!watch("organization")}
                  size="small"
                  {...register("position", {
                    required: "Please enter position",
                    minLength: {
                      value: 3,
                      message: "Atleast 3 characters are required !",
                    },
                  })}
                  error={!!errors.position}
                  helperText={errors.position?.message}
                  FormHelperTextProps={{
                    style: {
                      marginLeft: 1,
                    },
                  }}
                />
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-base font-medium">Start Date</p>
                <FormControl fullWidth size="small" error={!!errors.startDate}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <Controller
                      control={control}
                      name="startDate"
                      rules={{
                        required: "Start Date is required",
                        validate: (value) => {
                          if (!value) {
                            return "Starting Date is required";
                          }
                          if (value && !dayjs(value).isValid()) {
                            return "Please select a valid date";
                          }
                          if (
                            value &&
                            !dayjs(value, "MM-DD-YYYY", true).isValid()
                          ) {
                            return "Please select a valid date in MM-DD-YYYY format";
                          }
                          // if (dayjs(value).isBefore(watch("startDate"))) {
                          //   return "End Date must be later than the start date !";
                          // }
                          return true;
                        },
                      }}
                      render={({ field }) => (
                        <DatePicker
                          disableFuture
                          disabled={
                            !watch("organization") || !watch("position")
                          }
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          views={["year", "month", "day"]}
                          sx={{
                            width: "100%",
                            "& .MuiInputBase-root": {
                              height: "43px",
                              overflow: "hidden",
                            },
                            "& .MuiFormLabel-root": {
                              top: -5,
                            },
                            "& .MuiInputLabel-shrink": {
                              top: 0,
                            },
                          }}
                          slotProps={{
                            inputAdornment: {
                              position: "start",
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {errors?.startDate && (
                    <p className="form-error-message">
                      {String(errors.startDate.message)}
                    </p>
                  )}
                </FormControl>
                <span
                  onClick={() => clearErrors("endDate")}
                  className="flex items-center"
                >
                  <Checkbox
                    {...label}
                    defaultChecked={false}
                    {...register("endDateCheckbox")}
                  />
                  <p className="text-sm font-medium">
                    I’m currently in this role.
                  </p>
                </span>
              </div>
              {!endDateCheckboxExperience && (
                <div className="flex flex-col gap-2">
                  <p
                    className={`text-base font-medium ${
                      endDateCheckboxExperience ? "line-through " : ""
                    }`}
                  >
                    End Date
                  </p>
                  <FormControl fullWidth size="small" error={!!errors.endDate}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <Controller
                        control={control}
                        name="endDate"
                        rules={{
                          validate: (value) => {
                            if (!endDateCheckboxExperience && !value) {
                              return "End Date is required";
                            }
                            if (value && !dayjs(value).isValid()) {
                              return "Please select a valid date";
                            }
                            if (
                              value &&
                              !dayjs(value, "MM-DD-YYYY", true).isValid()
                            ) {
                              return "Please select a valid date in MM-DD-YYYY format";
                            }
                            if (dayjs(value).isBefore(watch("startDate"))) {
                              return "End Date must be later than the start date !";
                            }
                            return true;
                          },
                        }}
                        render={({ field }) => (
                          <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DatePicker
                              minDate={watch("startDate")}
                              disabled={
                                endDateCheckboxExperience ||
                                !watch("position") ||
                                !watch("organization") ||
                                !watch("startDate")
                              }
                              disableFuture
                              value={field.value}
                              onChange={(value) => {
                                field.onChange(value);
                              }}
                              views={["year", "month", "day"]}
                              sx={{
                                width: "100%",
                                "& .MuiInputBase-root": {
                                  height: "43px",
                                  overflow: "hidden",
                                },
                                "& .MuiFormLabel-root": {
                                  top: -5,
                                },
                                "& .MuiInputLabel-shrink": {
                                  top: 0,
                                },
                              }}
                              slotProps={{
                                inputAdornment: {
                                  position: "start",
                                },
                              }}
                            />
                          </LocalizationProvider>
                        )}
                      />
                    </LocalizationProvider>
                    {errors?.endDate && (
                      <p className="form-error-message">
                        {String(errors?.endDate.message)}
                      </p>
                    )}
                  </FormControl>
                </div>
              )}
              <div className="flex w-1/2 mx-auto">
                <YellowButton
                  shouldDisable={
                    loading ||
                    !watch("organization") ||
                    !watch("position") ||
                    !watch("startDate") ||
                    (endDateCheckboxExperience
                      ? !endDateCheckboxExperience
                      : !watch("endDate")) ||
                    Object.keys(errors).length > 0
                  }
                  loading={loading}
                  type="submit"
                  text="Save"
                />
              </div>
            </div>
          </div>
        </form>
      </CustomModalWrapper>
      <CustomModalWrapper
        open={!!previewExp}
        onClose={() => setpreviewExp(null)}
        title={"Work Details"}
      >
        <>
          <div className="w-full flex flex-col space-y-2 text-[#013338] bg-white p-4 rounded-md shadow-md">
            <span className="text-lg font-semibold">
              {`${previewExp?.position} at ${previewExp?.organization}`}
            </span>

            <span className="text-sm text-gray-600">
              {`${moment(previewExp?.startDate).format("MMMM YYYY")} - ${
                previewExp?.workingOn
                  ? "Present"
                  : moment(previewExp?.endDate).format("MMMM YYYY")
              }`}
            </span>

            <span className="text-[#3aa7a3] font-medium text-xs">
              Added:{" "}
              {moment(previewExp?.createdAt).format("DD MMMM YYYY hh:mm A")}
            </span>
          </div>
          {/* {previewExp && (
            <div className="w-full py-4 flex items-center justify-center">
              <CancelButton
                text="Delete"
                onClick={() => {
                  deleteExperience(previewExp?._id);
                }}
                className="max-w-fit px-5"
              />
            </div>
          )} */}
          <ModalCloseButton onClick={() => setpreviewExp(null)} />
        </>
      </CustomModalWrapper>
    </>
  );
};

export default WorkExperience;
