/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { Fragment, useCallback, useState } from "react";
import CreatePageHeading, {
  HeadingText,
} from "../../../../contexts/context-hooks/useCreateHeading";
import customAlert from "../../../../lib/swalExtentions";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import WhiteRoundedBox from "../../../../components/dashboard-components/WhiteRoundedBox";
import {
  IconButton,
  Pagination,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  ThemeProvider,
} from "@mui/material";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import LoadingElement from "../../../../components/UI/LoadingElement";
import Warning from "../../../../components/UI/Warning";
import { FaFile, FaFileDownload } from "react-icons/fa";
import dayjs from "dayjs";
import { LightTooltip } from "../Profile/CircleProgress";
import { useNavigate } from "react-router-dom";
import PayoutReportsModel from "./PayoutReportsModel";

const tableHeaders = [
  "Dated",
  "Amount",
  "Approval Status",
  "Approved Date",
  "Payment Status",
  "Receipt",
];

const PayoutHistory = () => {
  const [loading, setLoading] = useState<boolean>(false);

  const [totalPages, setTotalPages] = React.useState<number>(0);
  const [pageNo, setPageNo] = React.useState<number>(1);

  interface Row {
    _id: string;
    amount: string;
    status: number;
    currency: string;
    createdAt: string;
    receipt: string;
    updatedAt: string;
    approveDate: string;
    transactionId: string;
    paid: boolean;
    confirmedDate: string;
    failed: boolean;
    failureReason: string;
  }
  const [rows, setData] = React.useState<Row[]>([]);
  const fetchData = useCallback(async (pageNo: number) => {
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/payout/payout-history?pageNo=${pageNo}`
      );
      if (response.status === 200) {
        setData(response.data.payoutList);
        // alert(JSON.stringify(response.data.payoutList));
        setTotalPages(response.data.totalPages);
        return setLoading(false);
      }
    } catch (error: any) {
      customAlert.fire({
        title: "Something went wrong",
        text:
          error?.response?.data?.message ||
          "There was some error while fetching the payout history",
      });
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData(pageNo || 1);
  }, [pageNo, fetchData]);

  //handel pagination
  const handlePagination = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    setLoading(true);
    setPageNo(page);
  };
  const navigate = useNavigate();

  return (
    <>
      <CreatePageHeading>
        <HeadingText> Payout History</HeadingText>
      </CreatePageHeading>
      <div className="flex w-full  ">
        <WhiteRoundedBox className="w-full min-h-full ">
          <ThemeProvider theme={{}}>
            <TableContainer>
              <Table stickyHeader>
                <TableHead
                  sx={{
                    zIndex: 2,
                    backgroundColor: "white",
                    borderBottom: "2px solid #3aa7a3",
                  }}
                >
                  <TableRow>
                    <TableCell
                      colSpan={tableHeaders.length}
                      sx={{
                        border: 0,
                        p: 0.4,
                        boxShadow: "none",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        mb: 2,
                      }}
                    >
                      <MundialHeadingText
                        variant="darksea"
                        sizeVariant="md"
                        className="flex justify-center items-center"
                      >
                        PAYMENT OVERVIEW
                        {rows.length > 0 && (
                          <PayoutReportsModel>
                            <LightTooltip title="Get Invoice">
                              <IconButton
                                onClick={() => {
                                  navigate(`/c/finances/payout-history`);
                                }}
                                size="small"
                                sx={{
                                  ml: 1,
                                  color: "#3aa7a3",
                                  "&:hover": {
                                    color: "#ebbd33",
                                  },
                                }}
                              >
                                <FaFileDownload className="text-inherit" />
                              </IconButton>
                            </LightTooltip>
                          </PayoutReportsModel>
                        )}
                      </MundialHeadingText>
                    </TableCell>
                  </TableRow>
                  <TableRow sx={{ borderBottom: "2px solid #3aa7a3", p: 0 }}>
                    {tableHeaders.map((a, i) => (
                      <TableCell
                        colSpan={1}
                        key={`header-${i}`}
                        sx={{
                          borderBottom: "2px solid #3aa7a3",
                          textAlign: "left",
                          px: 0,
                          py: 0.6,
                          width: "fit-content",
                        }}
                      >
                        <span className="text-[#013338] font-semibold">
                          {a}
                        </span>
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell
                        colSpan={tableHeaders.length}
                        sx={{ border: 0 }}
                      >
                        <LoadingElement variant="dynamic" />
                      </TableCell>
                    </TableRow>
                  ) : rows.length > 0 ? (
                    rows.map((row, i) => (
                      <Fragment key={`session-${i}`}>
                        <TableRow
                          sx={{
                            color: "#013338",
                            borderBottom: "1px solid #3aa7a3",
                          }}
                        >
                          {/* Requested On */}
                          <TableCell
                            sx={{ borderBottom: `1px solid #ddd`, px: 0 }}
                          >
                            <p className="text-[#013338] font-medium text-[16px]">
                              {dayjs(row.createdAt).format(
                                "MMMM DD, YYYY hh:mm A"
                              ) || "-"}
                            </p>
                          </TableCell>
                          {/* Amount */}
                          <TableCell
                            sx={{ borderBottom: `1px solid #ddd`, px: 0 }}
                          >
                            <p className="text-[#013338] font-medium text-[18px]">
                              {`${"$"}${(Number(row.amount) / 100).toFixed(2)}`}
                            </p>
                          </TableCell>

                          {/* Approval Status */}
                          <TableCell
                            sx={{ borderBottom: `1px solid #ddd`, px: 0 }}
                          >
                            <p className="text-[#013338] font-bold uppercase text-[14px]">
                              {row.status === 0 ? (
                                <span className="text-[#ebbd33]">Pending</span>
                              ) : row.status === 1 ? (
                                <span className="text-[#3aa7a3]">Approved</span>
                              ) : row.status === -1 ? (
                                <span className="text-red-500">Failed</span>
                              ) : (
                                <span className="text-red-500">Unknown</span>
                              )}
                            </p>
                          </TableCell>

                          {/* Approved Date */}
                          <TableCell
                            sx={{ borderBottom: `1px solid #ddd`, px: 0 }}
                          >
                            <p className="text-[#013338] font-medium text-[16px]">
                              {row.status === 1
                                ? dayjs(row.approveDate).format(
                                    "MMMM DD, YYYY hh:mm A"
                                  )
                                : "-"}
                              {/*  */}
                            </p>
                          </TableCell>

                          {/* Transaction ID */}
                          <TableCell
                            sx={{ borderBottom: `1px solid #ddd`, px: 0 }}
                          >
                            <p className="text-[#013338] font-semibold uppercase text-[16px]">
                              {row.status === 0 ? (
                                <span className="text-[#ebbd33]">
                                  Pending Approval
                                </span>
                              ) : row?.paid ? (
                                <span className="text-[#3aa7a3]">Paid</span>
                              ) : (
                                <span className="text-[#ebbd33]">
                                  Processing
                                </span>
                              )}
                            </p>
                          </TableCell>

                          {/* Receipt */}
                          <TableCell
                            sx={{ borderBottom: `1px solid #ddd`, px: 0 }}
                          >
                            {row.status === 1 && row?.receipt ? (
                              <IconButton>
                                <a
                                  href={`${backendURL}/receipt/${row?.receipt}`}
                                  target="_blank"
                                  download
                                  className="text-[#3aa7a3] hover:text-[#ebbd33] text-[1.2rem]"
                                >
                                  <FaFile />
                                </a>
                              </IconButton>
                            ) : (
                              <span className="font-semibold text-[#013338]">
                                N/A
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                        {row.status === -1 && row.failed ? (
                          <>
                            <TableRow
                              sx={{
                                color: "#013338",
                                borderBottom: "1px solid #3aa7a3",
                              }}
                            >
                              <TableCell colSpan={tableHeaders.length}>
                                {row.failureReason}
                              </TableCell>
                            </TableRow>
                          </>
                        ) : null}
                      </Fragment>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={tableHeaders.length}
                        align="center"
                        sx={{ minHeight: 250, border: 0 }}
                      >
                        <div className="flex justify-center items-center min-h-[200px]">
                          <Warning variant="yellow">
                            You do not have any payout requests yet!
                          </Warning>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
                {totalPages > 1 && (
                  <TableRow sx={{ position: "sticky", bottom: 0 }}>
                    <TableCell
                      colSpan={tableHeaders.length}
                      sx={{ p: 0, border: 0 }}
                    >
                      <Paper
                        elevation={0}
                        sx={{
                          display: "flex",
                          background: "white",
                          justifyConten: "space-between",
                          width: "100%",
                          alignItems: "center",
                          borderRadius: 0,
                          height: { md: "3rem", lg: "3.5rem", xl: "4rem" },
                          borderTop: "1px solid #3aa7a3",
                        }}
                      >
                        <Pagination
                          count={totalPages}
                          page={pageNo}
                          onChange={handlePagination}
                          sx={{
                            width: "100%",
                            background: "white",
                            "& .MuiPaginationItem-root": { color: "#013338" }, // Default color
                            "& .Mui-selected": {
                              backgroundColor: "#3aa7a3 !important",
                              color: "white !important",
                            }, // Active page
                          }}
                        />
                      </Paper>
                    </TableCell>
                  </TableRow>
                )}
              </Table>
            </TableContainer>
          </ThemeProvider>
        </WhiteRoundedBox>
      </div>
    </>
  );
};
export default PayoutHistory;
