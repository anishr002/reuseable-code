/* eslint-disable @typescript-eslint/no-explicit-any */
import WhiteRoundedBox from "../../../../components/dashboard-components/WhiteRoundedBox";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import { YellowButton } from "../../../../components/buttons/ThemeButtons";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { useNotify } from "../../../../lib/Notify";
import FinnanceSkeleton from "../../../../components/Skeletons/FinnanceSkeleton";
import formatNumber from "../../../../util/formatNumber";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import {
  CircularProgress,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import useCheckPendingVerification from "../../../../components/hooks/useCheckPendingVerification";
import { useForm } from "react-hook-form";
import Warning from "../../../../components/UI/Warning";
import LoadingElement from "../../../../components/UI/LoadingElement";
import CreatePageHeading, {
  HeadingText,
} from "../../../../contexts/context-hooks/useCreateHeading";
import { LightTooltip } from "../Profile/CircleProgress";
import { FaHistory } from "react-icons/fa";
import Swal from "sweetalert2";

interface RequirementType {
  stripeCountryDetails: {
    code: string;
    label: string;
    phone: string;
    currency: string;
  };
  currency: string;
  usdAmount: string;
  convertedAmount: string;
  minimumRequiredAmount: string;
}

const Page = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { notifyMe } = useNotify();
  const [loadingBankingDetails, setLoadingBankingDetails] =
    useState<boolean>(false);
  const [show_account_create_component, set_show_account_create_component] =
    useState<boolean>(false); //
  const [show_stripe_account_onboarding, set_show_stripe_account_onboarding] =
    useState<boolean>(false); //
  const [show_account_management_session, set_show_account_management_session] =
    useState<boolean>(false); //faching data

  useEffect(() => {
    const fetchCoachDetails = async () => {
      setLoadingBankingDetails(true);
      try {
        const response = await httpAPI.get(
          `${backendURL}/coach/stripe/account-details`
        );
        if (response.status === 200) {
          set_show_account_create_component(
            response.data.data.stripe_onboardStatus == 2 ? true : false
          );
          set_show_stripe_account_onboarding(
            response.data.data.stripe_onboardStatus == 0 ? true : false
          );
          set_show_account_management_session(
            response.data.data.stripe_onboardStatus == 1 ? true : false
          );
        }
      } catch (error) {
        console.error("Fetching error", error);
        notifyMe({ message: "Something went wrong", severity: "error" });
      } finally {
        setLoadingBankingDetails(false);
      }
    };
    fetchCoachDetails();
  }, [location.pathname]);
  const [loadingFinnancialDetails, setLoadingFinnancialDetails] =
    useState<boolean>(false);
  const [loadingWithdraw, setLoadingWithdraw] = useState<boolean>(false);
  const [openPayoutModal, setOpenPayoutModal] = useState<boolean>(false);
  const [pageUpdated, setPageUpdated] = useState<boolean>(false);
  const [totalBalance, setTotalBalance] = useState<number>(0); //totalBalance
  const [totalpayoutAmount, setTotalpayoutAmount] = useState<number>(0); //totalpayoutAmountce
  const [totalRevenue, setTotalRevenue] = useState<number>(0); //totalRevenue

  const fetchData = async () => {
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/payout/payout-history?pageNo=1`
      );
      if (response.status === 200) {
        setTotalBalance(response.data.totalBalance);
        setTotalpayoutAmount(response.data.payoutBalance);
        setTotalRevenue(response.data.totalRevenue);
        // setData(response.data.payoutList);
        // setTotalPages(response.data.totalPages);
        return setLoadingFinnancialDetails(false);
      }
    } catch (error: any) {
      console.log({ error });
      // dispatch(logout());
      // logoutLocal();
      // return navigate("/");
    } finally {
      setLoadingFinnancialDetails(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [pageUpdated]);

  const [bankStatus, setBankStatus] = useState(false);

  const fetchBankData = async () => {
    setLoadingFinnancialDetails(true);
    try {
      const response = await httpAPI.get(`${backendURL}/coach/profile/profile`);
      if (response.status === 200) {
        // console.log(response.data.data);
        if (response.data.data.stripe_addStatus === 1) {
          setBankStatus(true);
        } else setBankStatus(false);
        return setLoadingFinnancialDetails(false);
      }
    } catch (error) {
      console.log(error);
      return;
    } finally {
      setLoadingFinnancialDetails(false);
    }
  };

  useEffect(() => {
    fetchBankData();
  }, []);

  const {
    BankAccountsStatus,
    pending,
    refresh,
    loading: pendingStatusLoading,
  } = useCheckPendingVerification();

  useEffect(() => {
    refresh();
  }, []);

  interface BankAccounts {
    id: string;
    object: string;
    account_holder_name: string;
    account_holder_type: string;
    account_type: string | null;
    bank_name: string;
    country: string;
    currency: string;
    fingerprint: string;
    last4: string;
    metadata: Record<string, unknown>;
    routing_number: string;
    status: "new" | "verified" | "rejected";
    account: string;
  }

  const [showError, setShowError] = useState<boolean>(false);
  const [bankList_loading, setBankList_loading] = useState<boolean>(false);
  const [bankList, setBankList] = useState<BankAccounts[]>([]);
  const [selectedBank, setSelectedBank] = useState<string | null>(null);

  const fetchBankListData = async () => {
    if (!openPayoutModal) {
      return;
    }
    setBankList_loading(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/stripe/account-bank-list`
      );
      if (response.status === 200) {
        setBankList(response.data.data.data);
        // console.log("bank list", response.data.data.data);
      }
    } catch (error) {
      console.log(error);
      return;
    } finally {
      setBankList_loading(false);
    }
  };

  useEffect(() => {
    fetchBankListData();
  }, [openPayoutModal]);

  type FormValues = {
    amount: number;
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm<FormValues>({ mode: "onChange", reValidateMode: "onChange" });

  // const onSubmit = handleSubmit(async (data) => {
  //   if (!selectedBank) {
  //     setShowError(true);
  //     return;
  //   }
  //   setLoadingWithdraw(true);
  //   try {
  //     const bankDetails = bankList.find((bank) => bank.id === selectedBank);
  //     if (!bankDetails) {
  //       setLoadingWithdraw(false);
  //       setOpenPayoutModal(false);
  //       return Swal.fire({
  //         title: "Bank Details Error",
  //         text: "Selected bank details not found.",
  //         icon: "error",
  //       });
  //     }
  //     const response = await httpAPI.post(
  //       `${backendURL}/coach/payout/payout-amount-request`,
  //       {
  //         Req_amount: data.amount,
  //         bankDetails,
  //       }
  //     );
  //     if (response.status === 200) {
  //       setOpenPayoutModal(false);
  //       const resData = response.data;
  //       if (resData.success === false) {
  //         // alert(JSON.stringify(resData));
  //         if (resData.action === "REVALIDATION_REQUIRED") {
  //           return Swal.fire({
  //             title: resData.title || "Revalidation Required",
  //             text:
  //               resData.message ||
  //               "Looks like your bank details are incomplete. Please revalidate your banking details and currency...",
  //             icon: "error",
  //             showCancelButton: true,
  //             confirmButtonText: "Revalidate",
  //             cancelButtonText: "Later",
  //             allowEscapeKey: false,
  //             allowOutsideClick: false,
  //           }).then(async (result) => {
  //             if (result.isConfirmed) {
  //               Swal.fire({
  //                 title: "Loading...",
  //                 text: "Please wait while we request the revalidation of your bank account.",
  //                 showConfirmButton: false,
  //               });
  //               const revalRes = await httpAPI.get(
  //                 `${backendURL}/coach/stripe/revalidate-account`
  //               );
  //               console.log({ revalRes });
  //               if (revalRes.status === 200) {
  //                 if (revalRes.data.success === false) {
  //                   return Swal.fire({
  //                     title:
  //                       revalRes.data.title || "Account revalidation failed!",
  //                     text:
  //                       revalRes.data.text +
  //                       ", By clicking refresh, you will be able to add the KYC and bank details again.",
  //                     confirmButtonText: "Refresh Account",
  //                     cancelButtonText: "Later",
  //                     allowEscapeKey: false,
  //                     allowOutsideClick: false,
  //                   }).then(async (result) => {
  //                     if (result.isConfirmed) {
  //                       const refreshRes = await httpAPI.get(
  //                         `${backendURL}/coach/stripe/refresh-account`
  //                       );
  //                       if (refreshRes.status === 200) {
  //                         return Swal.fire({
  //                           title: revalRes.data.title || "Account Refreshed !",
  //                           text: "Your bank details are cleared,Please complete your KYC again and select only the supported country and currency to receive payouts.",
  //                         });
  //                       }
  //                     }
  //                   });
  //                 }
  //                 return Swal.fire({
  //                   title: revalRes.data.title || "Account revalidated !",
  //                   text: "Your bank details are revalidated, Please check your bank detail by click on the view information button.",
  //                 });
  //               } else {
  //                 return Swal.fire({
  //                   title: resData.title || "Revalidation failed",
  //                   text: "There was some internal server error Please try again later.",
  //                 });
  //               }
  //             } else if (result.isDenied || result.isDismissed) {
  //               return Swal.fire({
  //                 title: resData.title || "Revalidation Required",
  //                 text: "Your bank details need revalidation as they are incomplete, you have skipped the revalidation, You cannot withdraw any amount untill you update your bank details.",
  //               });
  //             }
  //           });
  //         }
  //         return Swal.fire({
  //           title: resData.title || "Error",
  //           text: resData.message || "Something went wrong",
  //           icon: "error",
  //           confirmButtonText: "OK",
  //         });
  //       }
  //       setOpenPayoutModal(false);
  //       reset();
  //       setPageUpdated((prev) => !prev);
  //       notifyMe({
  //         message: "Your request for payout has been submitted!",
  //         severity: "success",
  //       });
  //       return;
  //     }
  //     notifyMe({
  //       message: "Unexpected response from server",
  //       severity: "error",
  //     });
  //   } catch (error: any) {
  //     setOpenPayoutModal(false);
  //     console.error("submit error", error);

  //     const errResponse = error?.response;
  //     if (
  //       errResponse &&
  //       [400, 401, 403, 404, 409, 500].includes(errResponse.status)
  //     ) {
  //       Swal.fire({
  //         title: errResponse.data.title || "Error",
  //         text: errResponse.data.message || "Server Error, Please try again.",
  //         icon: "error",
  //         confirmButtonText: "OK",
  //       });
  //     } else {
  //       Swal.fire({
  //         title: "Network Error",
  //         text: "Please check your internet connection and try again.",
  //         icon: "error",
  //         confirmButtonText: "OK",
  //       });
  //     }
  //   } finally {
  //     setLoadingWithdraw(false);
  //   }
  // });

  const onSubmit = handleSubmit(async (data) => {
    if (!selectedBank) {
      setShowError(true);
      return;
    }

    setLoadingWithdraw(true);

    try {
      const bankDetails = bankList.find((bank) => bank.id === selectedBank);

      if (!bankDetails) {
        setLoadingWithdraw(false);
        setOpenPayoutModal(false);
        return Swal.fire({
          title: "Bank Details Error",
          text: "Selected bank details not found.",
          icon: "error",
        });
      }

      const response = await httpAPI.post(
        `${backendURL}/coach/payout/payout-amount-request`,
        {
          Req_amount: data.amount,
          bankDetails,
        }
      );

      const resData = response.data;

      setLoadingWithdraw(false);
      setOpenPayoutModal(false);
      if (!resData.success) {
        if (resData.action === "REVALIDATION_REQUIRED") {
          const result = await Swal.fire({
            title: resData.title || "Revalidation Required",
            text:
              resData.message ||
              "Looks like your bank details are incomplete. Please revalidate your banking details and currency.",
            icon: "error",
            showCancelButton: true,
            confirmButtonText: "Revalidate",
            cancelButtonText: "Later",
            allowEscapeKey: false,
            allowOutsideClick: false,
          });

          if (result.isConfirmed) {
            Swal.fire({
              title: "Loading...",
              text: "Requesting bank account revalidation.",
              showConfirmButton: false,
              allowOutsideClick: false,
              allowEscapeKey: false,
              didOpen: () => {
                Swal.showLoading();
              },
            });

            try {
              const revalRes = await httpAPI.get(
                `${backendURL}/coach/stripe/revalidate-account`
              );
              Swal.close();

              if (!revalRes.data.success) {
                const retry = await Swal.fire({
                  title: revalRes.data.title || "Revalidation Failed",
                  text:
                    revalRes.data.text ||
                    "Something went wrong. You can refresh your account to complete onboarding again.",
                  icon: "warning",
                  showCancelButton: true,
                  confirmButtonText: "Refresh Account",
                  cancelButtonText: "Later",
                });

                if (retry.isConfirmed) {
                  const refreshRes = await httpAPI.get(
                    `${backendURL}/coach/stripe/refresh-account`
                  );
                  if (refreshRes.status === 200) {
                    return Swal.fire({
                      title: "Account Refreshed",
                      text: "Your account has been reset. Please re-complete onboarding and re-add supported bank details.",
                      icon: "success",
                    });
                  }
                }
              } else {
                return Swal.fire({
                  title: revalRes.data.title || "Account Revalidated",
                  text: "Your bank details were revalidated successfully.",
                  icon: "success",
                });
              }
            } catch (err) {
              console.log(err);
              Swal.close();
              return Swal.fire({
                title: "Revalidation Error",
                text: "Something went wrong during revalidation. Please try again later.",
                icon: "error",
              });
            }
          } else {
            return Swal.fire({
              title: resData.title || "Revalidation Skipped",
              text: "You skipped bank revalidation. Withdrawals are not allowed until revalidation is completed.",
              icon: "info",
            });
          }

          return;
        }

        // Handle generic failure
        return Swal.fire({
          title: resData.title || "Error",
          text: resData.message || "Something went wrong",
          icon: "error",
        });
      }

      // Success case
      setOpenPayoutModal(false);
      reset();
      setPageUpdated((prev) => !prev);

      notifyMe({
        message: "Your request for payout has been submitted!",
        severity: "success",
      });
    } catch (error: any) {
      setOpenPayoutModal(false);
      console.error("submit error", error);

      const errResponse = error?.response;

      if (
        errResponse &&
        [400, 401, 403, 404, 409, 500].includes(errResponse.status)
      ) {
        Swal.fire({
          title: errResponse.data?.title || "Server Error",
          text:
            errResponse.data?.message || "Something went wrong on the server.",
          icon: "error",
        });
      } else {
        Swal.fire({
          title: "Network Error",
          text: "Please check your internet connection and try again.",
          icon: "error",
        });
      }
    } finally {
      setLoadingWithdraw(false);
    }
  });

  const [requirementData, setRequirementData] =
    useState<RequirementType | null>(null);

  const [loadingMinwith, setloadingMinwith] = useState<boolean>(false);
  const reqAmou = watch("amount");
  const fetchRequirementData = async () => {
    try {
      setloadingMinwith(true);
      const response = await httpAPI.get(
        `${backendURL}/coach/payout/payout-requirement?usdAmount=${
          reqAmou ?? 0
        }`
      );
      // console.log({ response });
      if (response.status === 200) {
        setloadingMinwith(false);
        return setRequirementData(response.data?.data);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setloadingMinwith(false);
    }
  };
  useEffect(() => {
    fetchRequirementData();
  }, [reqAmou]);

  return (
    <>
      <CreatePageHeading>
        <HeadingText> Finances</HeadingText>
      </CreatePageHeading>
      <div className="w-full h-full flex flex-col space-y-[18px]">
        <div className="grid grid-cols-1 lg:grid-cols-2 w-full gap-x-[18px] gap-y-[18px] auto-rows-fr">
          <div className="col-span-1 flex-1 w-full h-full ">
            <WhiteRoundedBox className="flex-1 h-full w-full">
              {loadingBankingDetails ? (
                <FinnanceSkeleton variant="banking" />
              ) : (
                <div className="flex-1 min-w-[300px] sm:w-full  flex flex-col justify-between">
                  <div>
                    <MundialHeadingText sizeVariant="sm">
                      STRIPE ACCOUNT
                    </MundialHeadingText>
                    <p className="text-md text-gray-600 mt-2">
                      We partner with Stripe to keep your personal bank details
                      secure.
                      {show_account_management_session
                        ? `You have already complete the integration process, you can view / edit your bank account details by clicking on the "View Account Details" button.`
                        : `Add or create a Stripe account to start accepting payments.`}
                    </p>
                  </div>
                  <div className="flex justify-between mt-4">
                    <p className="text-[#3AA7A3] text-[18px]  font-bold underline  hover:cursor-pointer">
                      Need help?
                    </p>
                    <YellowButton
                      text={
                        show_account_create_component
                          ? "Add My Info"
                          : show_stripe_account_onboarding
                          ? "Add My Info"
                          : show_account_management_session
                          ? "View Account Details"
                          : "Check Info"
                      }
                      style={{ width: "fit-content" }}
                      className="px-4"
                      onClick={() => navigate("banking-details")}
                    />
                  </div>
                </div>
              )}
            </WhiteRoundedBox>
          </div>
          <div className="col-span-1 flex-1 w-full h-full ">
            <WhiteRoundedBox className="flex-1 h-full w-full">
              {loadingFinnancialDetails ? (
                <FinnanceSkeleton variant="stats" />
              ) : (
                <div className="flex-1 min-w-[300px] sm:w-full  ">
                  <div className="flex items-center w-full justify-between">
                    <MundialHeadingText
                      sizeVariant="sm"
                      className="pb-3 flex items-center "
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        width: "100%",
                      }}
                    >
                      PAYMENT OVERVIEW
                      <LightTooltip title="View Payout History">
                        <IconButton
                          onClick={() => {
                            navigate(`payout-history`);
                          }}
                          size="small"
                          sx={{
                            color: "#3aa7a3",
                            "&:hover": {
                              color: "#ebbd33",
                            },
                          }}
                        >
                          <FaHistory className="text-inherit" />
                        </IconButton>
                      </LightTooltip>
                    </MundialHeadingText>
                  </div>
                  <hr className="border-[#3AA7A3]" />
                  <div className="mt-4 space-y-3 font-semibold text-[#013338]">
                    <div className="flex justify-between px-2">
                      <p className="text-[18px] font-medium">Total Revenue</p>
                      <span className="font-semibold">
                        ${formatNumber(totalRevenue)}
                      </span>
                    </div>
                    <div className="flex justify-between px-2">
                      <p className="text-[18px] font-medium">Total Pay-Out</p>
                      <span className="font-semibold">
                        ${formatNumber(totalpayoutAmount)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-2 rounded-md font-semibold bg-[#3AA7A3] text-white">
                      <p className="text-[18px] font-medium">Total Balance</p>
                      <span className="font-semibold">
                        ${formatNumber(totalBalance)}
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-center pt-7">
                    <YellowButton
                      text="withdraw"
                      disabledToolTip={
                        totalBalance < 1
                          ? "You do not have minimum balance to request a withdrawal."
                          : ""
                      }
                      onClick={() => setOpenPayoutModal(true)}
                      shouldDisable={
                        BankAccountsStatus === 0 ||
                        pending.length > 0 ||
                        totalBalance < 1 ||
                        !bankStatus
                      }
                      style={{ width: "fit-content" }}
                      className="px-4"
                      loading={pendingStatusLoading}
                    />
                  </div>
                </div>
              )}
            </WhiteRoundedBox>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 w-full gap-x-[18px] gap-y-[18px] ">
          {bankStatus && totalBalance < 1 && (
            <div className="col-span-1 md:col-span-1 w-full h-fit ">
              <WhiteRoundedBox>
                <Warning variant="red">
                  You do not have minimum balance to request a withdrawal.
                </Warning>
              </WhiteRoundedBox>
            </div>
          )}
          {!bankStatus && (
            <div className="col-span-1 md:col-span-1  w-full h-full ">
              <WhiteRoundedBox>
                <Warning variant="seagreen">
                  <p className=" ">
                    To request for payout, Please complete you Stripe Account
                    Integration.
                    <Link className="pl-1 text-blue-600" to={`banking-details`}>
                      Click here
                    </Link>
                  </p>
                </Warning>
              </WhiteRoundedBox>
            </div>
          )}
          {(BankAccountsStatus === 0 || pending.length > 0) && (
            <div className="col-span-1 md:col-span-1 w-full h-fit ">
              <WhiteRoundedBox>
                <Warning variant="yellow">
                  Please complete/update your KYC details to enable Withdrawals.
                </Warning>
              </WhiteRoundedBox>
            </div>
          )}
        </div>
      </div>

      <CustomModalWrapper
        open={openPayoutModal}
        onClose={() => setOpenPayoutModal(false)}
        children={
          <>
            {bankList_loading ? (
              <div className="flex flex-1 justify-center items-center">
                <CircularProgress size={32} sx={{ color: "#3aa7a3" }} />
              </div>
            ) : (
              <form className="w-full " onSubmit={onSubmit}>
                <div className="flex flex-col gap-10">
                  {bankList?.length > 0 ? (
                    <div className="flex flex-col gap-5 w-full">
                      <div className="">
                        <TextField
                          id="outlined-required"
                          label="Amount"
                          fullWidth
                          size="small"
                          {...register("amount", {
                            required: "Please enter amount",
                            pattern: {
                              value: /^\d+(\.\d{1,2})?$/,
                              message:
                                "Please enter a valid number (up to 2 decimal places)",
                            },

                            min: {
                              value: 1,
                              message: `Please enter an amount between 1 and your total balance: ${formatNumber(
                                totalBalance
                              )}`,
                            },
                            max: {
                              value: totalBalance,
                              message: `Please enter an amount between 1 and your total balance: ${formatNumber(
                                totalBalance
                              )}`,
                            },
                          })}
                          error={!!errors.amount}
                          helperText={errors.amount?.message}
                          slotProps={{
                            input: {
                              startAdornment: (
                                <span className="text-[#3aa7a3] font-semibold mr-2 text-sm">
                                  $
                                </span>
                              ),
                            },
                            formHelperText: {
                              style: {
                                marginLeft: 1,
                              },
                            },
                          }}
                          sx={{
                            "& input[type=number]::-webkit-outer-spin-button": {
                              "-webkit-appearance": "none",
                              margin: 0,
                            },
                            "& input[type=number]::-webkit-inner-spin-button": {
                              "-webkit-appearance": "none",
                              margin: 0,
                            },
                            "& input[type=number]": {
                              "-moz-appearance": "textfield",
                            },
                          }}
                        />
                      </div>
                      <div className="flex flex-col">
                        <FormControl
                          className="w-full max-w-md"
                          variant="outlined"
                        >
                          <InputLabel id="bank-select-label">
                            Select Bank
                          </InputLabel>

                          <Select
                            label="Select Bank"
                            value={selectedBank || ""}
                            onChange={(event) => {
                              setShowError(false);
                              setSelectedBank(event.target.value);
                            }}
                            className="shadow-md text-sm rounded-lg transition-all duration-300 hover:shadow-lg"
                            disabled={loadingWithdraw}
                            MenuProps={{
                              PaperProps: {
                                style: {
                                  fontSize: "0.875rem", // Set the menu text size if needed
                                },
                              },
                            }}
                          >
                            {bankList_loading ? (
                              <MenuItem disabled>
                                <div className="flex items-center justify-center w-full">
                                  <CircularProgress
                                    size={20}
                                    className="mr-2"
                                  />
                                  <span className="text-gray-600">
                                    Loading banks...
                                  </span>
                                </div>
                              </MenuItem>
                            ) : bankList.length > 0 ? (
                              bankList.map((bank) => (
                                <MenuItem
                                  key={bank.id}
                                  value={bank.id}
                                  className="hover:bg-gray-100 transition-colors duration-200 flex items-center"
                                >
                                  <span>
                                    {bank.bank_name} (**** {bank.last4})
                                  </span>
                                </MenuItem>
                              ))
                            ) : (
                              <MenuItem disabled>
                                <span className="text-gray-600">
                                  No banks available
                                </span>
                              </MenuItem>
                            )}
                          </Select>
                        </FormControl>
                        <p
                          className={`${
                            showError ? "flex" : "hidden"
                          } font-normal text-sm leading-6 tracking-wide text-left mt-1 ml-1 text-[#d32f2f]`}
                        >
                          Please select Bank
                        </p>
                      </div>
                      {selectedBank && (
                        <div className="w-full max-w-md mt-6 p-4 flex flex-col justify-center  items-center border border-[#3aa7a3] rounded-[5px]">
                          <MundialHeadingText
                            sizeVariant="xs"
                            className="w-fit"
                          >
                            Bank Details
                          </MundialHeadingText>

                          {loadingWithdraw ? (
                            <div className="flex justify-center mt-4">
                              <LoadingElement
                                style={{
                                  height: 30,
                                }}
                                className="max-h-fit "
                              />
                            </div>
                          ) : (
                            <div className="text-center text-[#013338] mt-4 space-y-2">
                              <p className="text-lg font-medium">
                                {
                                  bankList.find(
                                    (bank) => bank.id === selectedBank
                                  )?.bank_name
                                }
                              </p>
                              <p className="text-sm">
                                <span className="font-semibold">
                                  Account Holder:
                                </span>{" "}
                                {
                                  bankList.find(
                                    (bank) => bank.id === selectedBank
                                  )?.account_holder_name
                                }
                              </p>
                              <p className="text-sm">
                                <span className="font-semibold">
                                  Routing Number:
                                </span>{" "}
                                {
                                  bankList.find(
                                    (bank) => bank.id === selectedBank
                                  )?.routing_number
                                }
                              </p>
                              <p className="text-sm">
                                <span className="font-semibold">
                                  Last 4 Digits:
                                </span>{" "}
                                ****{" "}
                                {
                                  bankList.find(
                                    (bank) => bank.id === selectedBank
                                  )?.last4
                                }
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                      {requirementData && selectedBank && reqAmou > 0 ? (
                        <div className="w-full max-w-md mt-6 p-4  flex-col justify-center items-center border border-[#3aa7a3] rounded-[5px]">
                          <MundialHeadingText
                            sizeVariant="xs"
                            className="w-fit mx-auto"
                          >
                            Minimum Withdrawal Details
                          </MundialHeadingText>

                          {loadingMinwith ? (
                            <div className="flex justify-center mt-4">
                              <LoadingElement
                                style={{ height: 30 }}
                                className="max-h-fit"
                              />
                            </div>
                          ) : (
                            <div className="text-center text-[#013338] mt-4 space-y-2">
                              {requirementData?.stripeCountryDetails
                                ?.currency && (
                                <p className="text-sm">
                                  <span className="font-semibold mr-1.5">
                                    Native Currency:
                                  </span>
                                  <span className="uppercase">
                                    {
                                      requirementData.stripeCountryDetails
                                        .currency
                                    }
                                  </span>
                                </p>
                              )}

                              {!isNaN(
                                Number(requirementData?.minimumRequiredAmount)
                              ) && (
                                <p className="text-sm">
                                  <span className="font-semibold mr-1.5">
                                    Minimum Withdrawal Amount:
                                  </span>
                                  {`${requirementData.currency?.toUpperCase()} ${
                                    requirementData.minimumRequiredAmount || 0
                                  }`}
                                </p>
                              )}

                              {Number(requirementData?.convertedAmount) > 0 && (
                                <p className="text-sm">
                                  <span className="font-semibold mr-1.5">
                                    Requested Amount:
                                  </span>
                                  {`${requirementData.currency?.toUpperCase()} ${
                                    requirementData.convertedAmount
                                  }`}
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      ) : null}

                      <div className="w-1/2 mx-auto pt-4 flex justify-end items-center">
                        <YellowButton
                          text="Withdraw Now"
                          loading={loadingWithdraw}
                          type="submit"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-1 pb-5 flex-col  space-y-5">
                      <Warning variant="yellow">
                        Incomplete Account Setup !
                      </Warning>
                      <p className="text-base text-center">
                        Please visit the banking page and follow the
                        instructions to fulfill all the required steps for the
                        payout process.
                      </p>
                      <Link to={`banking-details`}>
                        <YellowButton
                          text="Add My Info"
                          style={{ width: "100%" }}
                        />
                      </Link>
                    </div>
                  )}
                </div>
              </form>
            )}
          </>
        }
        title={`Available Balance : $${formatNumber(totalBalance)}`}
      />
    </>
  );
};

export default Page;
