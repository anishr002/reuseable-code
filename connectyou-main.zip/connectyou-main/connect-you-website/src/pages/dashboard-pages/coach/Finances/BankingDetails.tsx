/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  loadConnectAndInitialize,
  StripeConnectInstance,
} from "@stripe/connect-js";
import {
  ConnectAccountManagement,
  ConnectAccountOnboarding,
  ConnectComponentsProvider,
} from "@stripe/react-connect-js";
import { useEffect, useState } from "react";
import MUIAutocomplete from "@mui/material/Autocomplete";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import { ThreeDots } from "react-loader-spinner";
import { Controller, useForm } from "react-hook-form";
import { Box, TextField } from "@mui/material";
import usePageScrollAndTitle from "../../../../components/hooks/usePageScrollAndTitle";
import { useNotify } from "../../../../lib/Notify";
import { CountriesOptions } from "../../../../Options/Options";
import {
  DarkThemeButton,
  YellowButton,
} from "../../../../components/buttons/ThemeButtons";
import MundialHeadingText from "../../../../components/UI/MundialHeadingText";
import WhiteRoundedBox from "../../../../components/dashboard-components/WhiteRoundedBox";
import Warning from "../../../../components/UI/Warning";
import PopAlert from "../../../../util/PopAlert";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import getIP from "./getIp";

// interface CoachDetails {
//   persionId_number: number;
//   stripe_accID: number;
//   stripe_onboardStatus: number;
// }

const BankingDetails = () => {
  //live connectyou stripe pk public key
  const stripePublicKey = import.meta.env.VITE_STRIPE_PK;

  usePageScrollAndTitle({
    title: `Banking Details`,
  });
  const { notifyMe } = useNotify();
  // const [coachDetails, setCoachDetails] = useState<CoachDetails>();
  const [onboardingDone, setOnboardingDone] = useState<boolean>(false); //faching data
  const [PageUpdated, setPageUpdated] = useState<boolean>(false); //faching data
  const [loadingPage, setLoadingPage] = useState<boolean>(false); //faching data
  const [loadingSubmit, setLoadingSubmit] = useState<boolean>(false); //faching data

  const [show_account_create_component, set_show_account_create_component] =
    useState<boolean>(false); //
  const [show_stripe_account_onboarding, set_show_stripe_account_onboarding] =
    useState<boolean>(false); //
  const [show_account_management_session, set_show_account_management_session] =
    useState<boolean>(false); //faching data

  //fetch coach stripe account details
  const fetchCoachDetails = async () => {
    setLoadingPage(true);
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/stripe/account-details`
      );
      // console.log({ response });
      if (response.status === 200) {
        set_show_account_create_component(
          response.data.data.stripe_onboardStatus == 2 ? true : false
        );
        set_show_stripe_account_onboarding(
          response.data.data.stripe_onboardStatus == 0 ? true : false
        );
        set_show_account_management_session(
          response.data.data.stripe_onboardStatus == 1 ? true : false
        );
      }
    } catch (error) {
      console.error("Fetching error", error);
      notifyMe({ message: "Something went wrong", severity: "error" });
    } finally {
      setLoadingPage(false);
    }
  };

  //fetch coach stripe account details
  const updateOnboardingAccountDetails = async () => {
    try {
      const response = await httpAPI.get(
        `${backendURL}/coach/stripe/account-details-update`
      );
      if (response.status === 200) {
        return setOnboardingDone(true);
      }
    } catch (error) {
      console.error("Fetching error", error);
      notifyMe({ message: "Something went wrong", severity: "error" });
    }
  };

  // useEffect(() => {
  //   console.log({ CountriesOptions: CountriesOptions.length });
  // }, [CountriesOptions]);

  useEffect(() => {
    fetchCoachDetails();
  }, [PageUpdated]);

  const [stripe_account_onboarding, setstripe_account_onboarding] =
    useState<StripeConnectInstance | null>(null);
  const [
    stripe_account_management_session,
    setstripe_account_management_session,
  ] = useState<StripeConnectInstance | null>(null);

  const FetchOnboarding = async () => {
    try {
      const fetchClientSecret = async () => {
        const response = await httpAPI.get(
          `${backendURL}/coach/stripe/stripe-account-onboarding`
        );
        console.log("stripe-account-onboarding", response);
        if (response.status === 200) {
          if (response?.data?.success) {
            const clientSecret = response.data.clientSecret;
            return clientSecret;
          } else {
            set_show_account_create_component(true);
          }
        }
      };
      const data = await loadConnectAndInitialize({
        publishableKey: stripePublicKey,
        fetchClientSecret: fetchClientSecret,
        appearance: {
          overlays: "drawer",
          variables: {
            colorPrimary: "#013338",
            fontFamily: "Quicksand",
            formAccentColor: "#3aa7a3",
          },
        },
      });
      return data;
    } catch (error: any) {
      console.log(error);
      PopAlert.error({
        message:
          error.response.data.message ||
          "Something went wrong while loading the account onboarding component, Please try again later.",
      });
      return null;
    }
  };
  const FetchManagementSession = async () => {
    try {
      const fetchClientSecret = async () => {
        const response = await httpAPI.get(
          `${backendURL}/coach/stripe/account-management-session`
        );
        if (response.status === 200) {
          const clientSecret = response.data.clientSecret;
          return clientSecret;
        }
      };
      const data = await loadConnectAndInitialize({
        publishableKey: stripePublicKey,
        fetchClientSecret: fetchClientSecret,
        appearance: {
          overlays: "dialog",
          variables: {
            colorPrimary: "#013338",
            fontFamily: "Quicksand",
            formAccentColor: "#3aa7a3",
          },
        },
      });
      return data;
    } catch (error: any) {
      console.log(error);
      PopAlert.error({
        message:
          error.response.data.message ||
          "Something went wrong while loading the account management component, Please try again later.",
      });
      return null;
    }
  };

  useEffect(() => {
    const fetchA = async () => {
      const data = await FetchOnboarding();
      setstripe_account_onboarding(data);
    };
    const fetchB = async () => {
      const data = await FetchManagementSession();
      setstripe_account_management_session(data);
    };
    fetchA();
    fetchB();
  }, [
    PageUpdated,
    show_stripe_account_onboarding,
    onboardingDone,
    show_account_management_session,
  ]);

  // //fetch stripe account onboarding session secret
  // const [stripe_account_onboarding] = useState(() => {
  //   const fetchClientSecret = async () => {
  //     const response = await httpAPI.get(
  //       `${backendURL}/coach/stripe/stripe-account-onboarding`
  //     );
  //     if (response.status === 200) {
  //       // console.log("stripe-account-onboarding", response.data.clientSecret);
  //       const clientSecret = response.data.clientSecret;
  //       return clientSecret;
  //     }
  //   };
  //  awiat loadConnectAndInitialize({
  //     publishableKey: stripePublicKey,
  //     fetchClientSecret: fetchClientSecret,
  //     appearance: {
  //       overlays: "drawer",
  //       variables: {
  //         colorPrimary: "#013338",
  //         fontFamily: "Quicksand",
  //         formAccentColor: "#3aa7a3",
  //       },
  //     },
  //   });
  // });

  // //fetch stripe account management session secret

  // const [account_management_session] = useState(() => {
  //   const fetchClientSecret = async () => {
  //     // Fetch the AccountSession client secret
  //     const response = await httpAPI.get(
  //       `${backendURL}/coach/stripe/account-management-session`
  //     );
  //     if (response.status === 200) {
  //       // console.log("account-management-session", response.data.clientSecret);
  //       const clientSecret = response.data.clientSecret;
  //       return clientSecret;
  //     }
  //   };
  //  await loadConnectAndInitialize({
  //     publishableKey: stripePublicKey,
  //     fetchClientSecret: fetchClientSecret,
  //     appearance: {
  //       overlays: "dialog",
  //       variables: {
  //         colorPrimary: "#013338",
  //         fontFamily: "Quicksand",
  //         formAccentColor: "#3aa7a3",
  //       },
  //     },
  //   });
  // });
  //handle add country
  const [openEddress, setOpenEddress] = useState<boolean>(false); //for open address form modal
  type FormValues = {
    country: any | null;
  };
  const { control, handleSubmit, reset } = useForm<FormValues>({
    defaultValues: {
      country: null,
    },
    mode: "onChange",
  });

  interface CountryData {
    code: string;
    label: string;
    phone: string;
    currency: string;
  }

  const onSubmit = async (data: { country: CountryData }) => {
    setLoadingSubmit(true);
    // return alert(JSON.stringify(data?.country));
    const ip = await getIP();
    try {
      const response = await httpAPI.post(
        `${backendURL}/coach/stripe/create-account`,
        {
          code: data?.country?.code,
          label: data?.country?.label,
          phone: data?.country?.phone,
          currency: data?.country?.currency,
          ip: ip,
        }
      );
      if (response.status === 200) {
        reset();
        setOpenEddress(false);
        set_show_account_create_component(false);
        const Message = "Country added successfully";
        notifyMe({ message: Message, severity: "success" });
        // setTimeout(reloadWindow, 2000);
        return setPageUpdated((prev) => !prev);
      }
    } catch (error: any) {
      console.log("submit error on on submit for bank acc details 1", error);
      const errorMessage =
        error?.response?.data?.message || "Something went wrong";
      notifyMe({ message: errorMessage, severity: "error" });
    } finally {
      setLoadingSubmit(false);
    }
  };

  if (loadingPage) {
    return (
      <div className="flex w-full h-screen justify-center items-center">
        <ThreeDots
          visible={true}
          height="80"
          width="80"
          color="#3aa7a3"
          radius="9"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          wrapperClass=""
        />
      </div>
    );
  }
  return (
    <>
      <div className="flex gap-5 flex-col sm:flex-row  flex-wrap">
        {show_account_create_component && (
          <WhiteRoundedBox>
            <div className="flex flex-col space-y-8 py-9 w-full p-4 ">
              <div className="text-center mx-auto w-full px-10">
                <MundialHeadingText sizeVariant="md">
                  Click the button below to start the account setup by selecting
                  your country.
                </MundialHeadingText>
              </div>
              <div className="flex w-full justify-center">
                <YellowButton
                  text="Start Now"
                  onClick={() => setOpenEddress(true)}
                />
              </div>
              <div className="w-full flex flex-col">
                <Warning>
                  <span className="text-[red] text-xs font-semibold">
                    **Important: The selected country will be used to configure
                    your bank account integration. This choice is permanent and
                    cannot be modified later. Please ensure it is accurate
                    before proceeding.
                  </span>
                </Warning>
              </div>
            </div>
          </WhiteRoundedBox>
        )}
        {!show_account_create_component &&
          show_stripe_account_onboarding &&
          stripe_account_onboarding && (
            <WhiteRoundedBox className=" flex flex-col w-full">
              <MundialHeadingText sizeVariant="sm">
                Stripe Account Integration
              </MundialHeadingText>
              <ConnectComponentsProvider
                connectInstance={stripe_account_onboarding}
              >
                <ConnectAccountOnboarding
                  onLoadError={() => window.location.reload}
                  onExit={() => {
                    updateOnboardingAccountDetails();
                  }}
                  fullTermsOfServiceUrl="{{URL}}"
                  recipientTermsOfServiceUrl="{{URL}}"
                  privacyPolicyUrl="{{URL}}"
                  skipTermsOfServiceCollection={false}
                  collectionOptions={{
                    fields: "eventually_due",
                    futureRequirements: "include",
                  }}
                  onStepChange={(stepChange) => {
                    console.log(`User entered to the step: ${stepChange.step}`);
                  }}
                />
              </ConnectComponentsProvider>
              {onboardingDone && (
                <div className="flex w-full justify-end">
                  <div className="flex py-5  w-full flex-col md:flex-row  md:items-center justify-between">
                    <MundialHeadingText sizeVariant="xs" variant="seablue">
                      Your account setup is complete.
                    </MundialHeadingText>
                    <DarkThemeButton
                      className="p-2"
                      style={{ padding: "2px 10px" }}
                      text="View account management settings"
                      onClick={() => {
                        setLoadingPage(true);
                        setTimeout(() => window.location.reload(), 3000);
                      }}
                    ></DarkThemeButton>
                  </div>
                </div>
              )}
            </WhiteRoundedBox>
          )}

        {!show_account_create_component &&
          show_account_management_session &&
          stripe_account_management_session && (
            <div className="flex flex-col w-full p-4 bg-white rounded-sm shadow-md">
              <MundialHeadingText sizeVariant="sm" className="pb-4">
                Account Details
              </MundialHeadingText>
              <ConnectComponentsProvider
                connectInstance={stripe_account_management_session}
              >
                <ConnectAccountManagement
                  collectionOptions={{
                    fields: "eventually_due",
                    futureRequirements: "include",
                  }}
                />
              </ConnectComponentsProvider>
            </div>
          )}
      </div>

      {/* add country modal  */}
      <CustomModalWrapper
        open={openEddress}
        onClose={() => setOpenEddress(false)}
        title="Select Your Country"
      >
        <form className="w-full pt-4" onSubmit={handleSubmit(onSubmit)}>
          <div className="w-full pb-4 text-sm font-medium text-[#013338]">
            **Please select the country where your bank is located. This will be
            used to set up your bank account integration.
          </div>
          <div className="flex flex-col gap-10 w-full">
            <div className="flex flex-col gap-5 w-full">
              {/* country */}
              <span className="w-full">
                <Controller
                  name="country"
                  control={control}
                  defaultValue={null}
                  render={({
                    field: { onChange, value },
                    fieldState: { error },
                  }) => (
                    <MUIAutocomplete
                      size="small"
                      id="country-select-demo"
                      fullWidth
                      options={CountriesOptions}
                      value={value}
                      onChange={(_event, newValue) => {
                        onChange(newValue);
                      }}
                      autoHighlight
                      getOptionLabel={(option) => option.label}
                      isOptionEqualToValue={(option, value) =>
                        option.code === value?.code
                      }
                      renderOption={(props, option) => (
                        <Box
                          component="li"
                          sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
                          {...props}
                          key={option.code}
                        >
                          <img
                            loading="lazy"
                            width="20px"
                            srcSet={`https://flagcdn.com/w40/${option.code.toLowerCase()}.png 2x`}
                            src={`https://flagcdn.com/w20/${option.code.toLowerCase()}.png`}
                            alt=""
                          />
                          {option.label}
                        </Box>
                      )}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Country"
                          error={!!error}
                          helperText={error ? error.message : null}
                          inputProps={{
                            ...params.inputProps,
                            // autoComplete: "new-password",
                          }}
                          FormHelperTextProps={{
                            sx: { ml: 0 },
                          }}
                        />
                      )}
                    />
                  )}
                  rules={{ required: "Country selection is required" }}
                />
              </span>
            </div>
            <div className="flex flex-col gap-5  py- 4 w-full  mx-auto">
              <p className="text-xs text-gray-500 mt-2">
                By continuing, you agree to the{" "}
                <a
                  href="https://stripe.com/en-ca/connect-account/legal"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline text-[#3aa7a3]"
                >
                  Stripe Connected Account Agreement
                </a>{" "}
                and{" "}
                <a
                  href="https://stripe.com/en-ca/privacy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline text-[#3aa7a3]"
                >
                  Stripe’s Privacy Policy
                </a>
                .
              </p>
            </div>
            <div className="flex flex-col gap-5 w-1/2 mx-auto">
              <YellowButton text="Save" loading={loadingSubmit} type="submit" />
            </div>
          </div>
        </form>
      </CustomModalWrapper>
    </>
  );
};

export default BankingDetails;
