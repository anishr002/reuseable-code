import React, {
  forwardRef,
  ReactNode,
  useImperativeHandle,
  useState,
} from "react";
import CustomModalWrapper from "../../../../components/wrappers/CustomModalWrapper";
import { DarkThemeButtonTransparent } from "../../../../components/buttons/ThemeButtons";
import DownloadReceipts from "./DownloadReceipts";

interface Props {
  children?: ReactNode;
  childrenWrapperProps?: React.HTMLAttributes<HTMLDivElement>;
}
const PayoutReportsModel = forwardRef(
  ({ children, childrenWrapperProps = {} }: Props, ref) => {
    const [open, setOpen] = useState<boolean>(false);
    const OpenM = () => setOpen(true);
    const CloseM = () => setOpen(false);
    useImperativeHandle(ref, () => ({
      Open: () => {
        OpenM();
      },
      Close: () => {
        CloseM();
      },
    }));

    const { onClick = undefined, ...childrenWrapperRestProps } =
      childrenWrapperProps;
    const [isActive, setisActive] = useState<"Monthly" | "Yearly" | "Custom">(
      "Monthly"
    );

    return (
      <>
        <div
          onClick={(e) => {
            onClick?.(e);
            OpenM();
          }}
          {...childrenWrapperRestProps}
        >
          {children}
        </div>
        <CustomModalWrapper
          open={open}
          onClose={CloseM}
          title="Download Payouts Receipt"
        >
          <div className="flex flex-col  space-y-2">
            <div className="flex md:flex-row flex-col w-full items-center justify-center gap-4 md:h-[45px]">
              <DarkThemeButtonTransparent
                text="Monthly"
                isActive={isActive === "Monthly"}
                onClick={() => setisActive("Monthly")}
                className="h-[35px]"
              />
              <DarkThemeButtonTransparent
                text="Yearly"
                isActive={isActive === "Yearly"}
                onClick={() => setisActive("Yearly")}
                className="h-[35px]"
              />
              <DarkThemeButtonTransparent
                text="Custom"
                isActive={isActive === "Custom"}
                onClick={() => setisActive("Custom")}
                className="h-[35px]"
              />
            </div>
            <div className="flex w-full">
              <DownloadReceipts activeTab={isActive} />
            </div>
          </div>
        </CustomModalWrapper>
      </>
    );
  }
);

export default PayoutReportsModel;
