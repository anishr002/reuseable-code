/* eslint-disable @typescript-eslint/no-explicit-any */
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import React, { useState } from "react";
import { useForm, SubmitHandler, Controller } from "react-hook-form";
import {
  MenuItem,
  Select,
  FormControl,
  Typography,
  Box,
  ThemeProvider,
  createTheme,
} from "@mui/material";
import { useSelector } from "react-redux";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { useNotify } from "../../../../lib/Notify";
import backendURL, { httpAPI } from "../../../../util/AxiosAPI";
import FilePreview from "../../../../components/utility/FilePreview";
import ReceiptsError from "../../../../components/wrappers/ReceiptsError";
import usePageScrollAndTitle from "../../../../components/hooks/usePageScrollAndTitle";
import { CancelButton, YellowButton } from "../../../../components/buttons/ThemeButtons";

const customThemeRep = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          "& fieldset": {
            borderColor: "#3aa7a3",
          },
          "&:hover fieldset": {
            borderColor: "#3aa7a3",
          },
          "&.Mui-focused fieldset": {
            borderColor: "#3aa7a3",
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: "#3aa7a3",
          },
          "& .MuiSelect-icon": {
            color: "#3aa7a3",
          },
        },
        icon: {
          color: "#3aa7a3",
        },
        select: {
          color: "#3aa7a3",
        },
      },
    },
    MuiInputLabel: {
      styleOverrides: {
        root: {
          color: "#3aa7a3",
        },
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: {
          color: "#3aa7a3",
        },
      },
    },
    MuiListItemText: {
      styleOverrides: {
        primary: {
          color: "#3aa7a3",
        },
      },
    },
    MuiInputBase: {
      styleOverrides: {
        root: {
          "& .MuiSelect-select": {
            color: "#3aa7a3",
          },
          "&.MuiSelect-select:empty": {
            color: "#3aa7a3",
          },
        },
      },
    },
  },
});

const MonthlyReceipts: React.FC = () => {
  const {
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    control,
  } = useForm<{ month: string; year: string }>({ mode: "onSubmit" });
  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [noOrder, setNoOrders] = useState<boolean>(false);
  const { notifyMe } = useNotify();
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const years = Array.from({ length: 3 }, (_, i) =>
    (new Date().getFullYear() - i).toString()
  );

  const loginUserData = useSelector((state: any) => state.login.userdata);
  const _id = loginUserData._id;
  const onSubmit: SubmitHandler<{ month: string; year: string }> = async (
    data
  ) => {
    setShowDownload(false);
    setNoOrders(false);
    setLoading(true);
    try {
      // console.log(data);
      setLoading(true);
      const response = await httpAPI.get(
        `${backendURL}/${
          loginUserData?.userType === "coach" ? "coach" : "user"
        }/payments/history/gen-rec/monthly/${_id}/${data.month}/${data.year}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setReceipt(response.data.receipt);
          setShowDownload(true);
          setNoOrders(false);
        } else {
          setShowDownload(false);
          setNoOrders(true);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.log("faching error", error);
      return notifyMe({ message: "Something went wrong", severity: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      className="flex flex-col w-full gap-6 py-5 px-4"
      onSubmit={handleSubmit(onSubmit)}
    >
      <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
        <FormControl fullWidth error={!!errors.month}>
          <span className="text-[18px] text-[#3aa7a3] font-medium pb-1">
            Month
          </span>
          <Controller
            name="month"
            control={control}
            defaultValue=""
            rules={{
              required: "Please select a month",
            }}
            render={({ field }) => (
              <Select
                {...field}
                size="small"
                displayEmpty={true}
                hiddenLabel={true}
                sx={{
                  borderColor: errors.month ? "red" : "inherit",
                  "& .MuiSvgIcon-root": { color: "#3aa7a3" },
                }}
                IconComponent={(params) => (
                  <KeyboardArrowDownIcon
                    {...params}
                    sx={{ color: "#3aa7a3" }}
                  />
                )}
              >
                <MenuItem sx={{ color: "#3aa7a3" }} disabled value="">
                  Please Select
                </MenuItem>
                {months.map((month) => (
                  <MenuItem sx={{ color: "#013338" }} key={month} value={month}>
                    {month}
                  </MenuItem>
                ))}
              </Select>
            )}
          />

          {errors.month && (
            <Typography variant="caption" color="error">
              {errors.month.message}
            </Typography>
          )}
        </FormControl>

        <FormControl fullWidth error={!!errors.year}>
          <span className="text-[18px] text-[#3aa7a3] font-medium pb-1">
            Year
          </span>
          <Controller
            name="year"
            control={control}
            defaultValue=""
            rules={{
              required: "Please select a year",
            }}
            disabled={!watch("month")}
            render={({ field }) => (
              <Select
                {...field}
                size="small"
                hiddenLabel={true}
                displayEmpty={true}
                sx={{
                  borderColor: errors.year ? "red" : "inherit",
                  "& .MuiSvgIcon-root": { color: "#3aa7a3" }, // Change icon color
                }}
                IconComponent={(params) => (
                  <KeyboardArrowDownIcon
                    {...params}
                    sx={{ color: "#3aa7a3" }}
                  />
                )}
              >
                <MenuItem disabled value="" sx={{ color: "#3aa7a3" }}>
                  Please select
                </MenuItem>
                {years.map((year) => (
                  <MenuItem sx={{ color: "#013338" }} key={year} value={year}>
                    {year}
                  </MenuItem>
                ))}
              </Select>
            )}
          />
          {errors.year && (
            <Typography variant="caption" color="error">
              {errors.year.message}
            </Typography>
          )}
        </FormControl>
      </div>
      <Box
        sx={{
          display: "flex",
          mx: "auto",
          gap: 2,
          flexDirection: "column",
          width: "100%",
        }}
      >
        <div className="flex w-full justify-center items-center">
          {!receipt ? (
            <YellowButton
              text="Get Receipt"
              loading={loading}
              shouldDisable={
                loading ||
                !watch("year") ||
                !watch("month") ||
                Object.keys(errors).length > 0
              }
            />
          ) : (
            <CancelButton
              text="Clear"
              onClick={() => {
                setReceipt(null);
                setShowDownload(false);
                setNoOrders(false);
                setLoading(false);
                reset();
              }}
            ></CancelButton>
          )}
        </div>
        {showDownload && receipt && (
          <FilePreview
            file={receipt}
            fileUrl={`${backendURL}/receipt/${receipt}`}
          />
        )}
      </Box>
      {noOrder && (
        <ReceiptsError>
          You do not have any orders during this period. Please change the
          filter and try again.
        </ReceiptsError>
      )}
    </form>
  );
};

const YearlyReceipts: React.FC = () => {
  const {
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    control,
  } = useForm<{ year: string }>({ mode: "onSubmit" });
  const { notifyMe } = useNotify();
  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [noOrder, setNoOrders] = useState<boolean>(false);

  const years = Array.from({ length: 3 }, (_, i) =>
    (new Date().getFullYear() - i).toString()
  );

  const loginUserData = useSelector((state: any) => state.login.userdata);
  const _id = loginUserData._id;

  const onSubmit: SubmitHandler<{ year: string }> = async (data) => {
    setNoOrders(false);
    setShowDownload(false);
    setLoading(true);
    try {
      setLoading(true);
      const response = await httpAPI.get(
        `${backendURL}/${
          loginUserData?.userType === "coach" ? "coach" : "user"
        }/payments/history/gen-rec/yearly/${_id}/${data.year}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setReceipt(response.data.receipt);
          setShowDownload(true);
          setNoOrders(false);
        } else {
          setNoOrders(true);
          setShowDownload(false);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.log("faching error", error);
      return notifyMe({ message: "Something went wrong", severity: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      className="flex flex-col w-full gap-6 py-5 px-4"
      onSubmit={handleSubmit(onSubmit)}
    >
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <span
            className="text-[#3aa7a3] pb-2 text-[18px] font-medium"
            id="demo-simple-select-label"
          >
            Year
          </span>
          <Controller
            name="year"
            control={control}
            defaultValue=""
            rules={{
              required: "Please select a year",
            }}
            render={({ field }) => (
              <Select
                {...field}
                size="small"
                hiddenLabel={true}
                displayEmpty={true}
                error={!!errors.year}
                sx={{
                  borderColor: errors.year ? "red" : "inherit",
                  "& .MuiSvgIcon-root": { color: "#3aa7a3" },
                }}
                IconComponent={(params) => (
                  <KeyboardArrowDownIcon
                    {...params}
                    sx={{ color: "#3aa7a3" }}
                  />
                )}
              >
                <MenuItem disabled value="" sx={{ color: "#013338" }}>
                  Please select
                </MenuItem>
                {years.map((y) => (
                  <MenuItem value={y} sx={{ color: "#013338" }}>
                    {y}
                  </MenuItem>
                ))}
              </Select>
            )}
          />
        </FormControl>
        {errors?.year && (
          <p className="text-red-600 text-sm font-semibold">
            {errors?.year?.message}
          </p>
        )}
      </Box>

      <Box
        sx={{
          display: "flex",
          mx: "auto",
          gap: 2,
          flexDirection: "column",
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {!receipt ? (
          <YellowButton
            loading={loading}
            text="get receipt"
            shouldDisable={
              loading || !watch("year") || Object.keys(errors).length > 0
            }
          ></YellowButton>
        ) : (
          <CancelButton
            onClick={() => {
              setReceipt(null);
              setShowDownload(false);
              setNoOrders(false);
              setLoading(false);
              reset();
            }}
            text="Clear
            "
          ></CancelButton>
        )}

        {showDownload && receipt && (
          <FilePreview
            file={receipt}
            fileUrl={`${backendURL}/receipt/${receipt}`}
          />
        )}
      </Box>
      {noOrder && (
        <ReceiptsError>
          You do not have any orders during this period. Please change the
          filter and try again.
        </ReceiptsError>
      )}
    </form>
  );
};

const CustomReceipts: React.FC = () => {
  const {
    handleSubmit,
    watch,
    formState: { errors },
    reset,
    control,
  } = useForm<{ from: string; to: string }>({ mode: "onChange" });
  const { notifyMe } = useNotify();
  const [loading, setLoading] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [noOrder, setNoOrders] = useState<boolean>(false);

  const loginUserData = useSelector((state: any) => state.login.userdata);
  const _id = loginUserData._id;

  const onSubmit: SubmitHandler<{ from: string; to: string }> = async (
    data
  ) => {
    setShowDownload(false);
    setNoOrders(false);
    setLoading(true);

    try {
      const response = await httpAPI.get(
        `${backendURL}/${
          loginUserData?.userType === "coach" ? "coach" : "user"
        }/payments/history/gen-rec/periodic/${_id}/${dayjs(data.from).format(
          "YYYY-MM-DD"
        )}/${dayjs(data.to).format("YYYY-MM-DD")}`
      );
      if (response.status === 200) {
        if (response.data.noOrders === false) {
          setReceipt(response.data.receipt);
          setShowDownload(true);
          setNoOrders(false);
        } else {
          setNoOrders(true);
          setShowDownload(false);
        }
        return setLoading(false);
      }
    } catch (error) {
      console.error("Fetching error", error);
      notifyMe({ message: "Something went wrong", severity: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      className="flex flex-col w-full gap-6 py-5 px-4"
      onSubmit={handleSubmit(onSubmit)}
    >
      <div className="flex  md:flex-row items-center justify-center md:items-start md:justify-start flex-col gap-4">
        {/* From Date */}
        <Box>
          <span className="text-[#3aa7a3] font-medium">From</span>
          <FormControl fullWidth>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <Controller
                name="from"
                control={control}
                rules={{
                  required: "Please select a date to End at",
                  validate: (value) => {
                    if (!value) {
                      return "Start date is required";
                    }
                    const dayValue = dayjs(value); // Create dayjs object
                    if (!dayValue.isValid()) {
                      return "Please select a valid date";
                    }
                    if (value && !dayjs(value, "YYYY-MM-DD", true).isValid()) {
                      return "Please select a valid date in YYYY-MM-DD format";
                    }
                    return true;
                  },
                }}
                render={({ field: { onChange, value, ...restField } }) => (
                  <DatePicker
                    {...restField}
                    value={value ? dayjs(value) : null}
                    onChange={(newValue) => {
                      const formattedDate = newValue
                        ? dayjs(newValue).format("YYYY-MM-DD")
                        : null;
                      onChange(formattedDate);
                    }}
                    disableFuture
                    views={["year", "month", "day"]}
                    slotProps={{
                      inputAdornment: {
                        position: "start",
                      },
                      textField: {
                        hiddenLabel: true,
                        error: !!errors.from,
                        helperText: errors.from?.message,
                        size: "small",
                        sx: {
                          "& .MuiOutlinedInput-root": {
                            "& fieldset": { borderColor: "#3aa7a3" },
                            "&:hover fieldset": { borderColor: "#3aa7a3" },
                            "&.Mui-focused fieldset": {
                              borderColor: "#3aa7a3",
                            },
                          },
                          "& .MuiInputBase-input": {
                            color: "#3aa7a3",
                          },
                          "& .MuiInputBase-input::placeholder": {
                            color: "#3aa7a3",
                            opacity: 1,
                          },
                          "& .MuiSvgIcon-root": {
                            color: "#3aa7a3",
                          },
                        },
                      },
                    }}
                  />
                )}
              />
            </LocalizationProvider>
          </FormControl>
        </Box>

        {/* To Date */}
        <Box>
          <span className="text-[#3aa7a3] font-medium">To</span>
          <FormControl fullWidth>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <Controller
                name="to"
                control={control}
                rules={{
                  required: "Please select a date to End at",
                  validate: (value) => {
                    if (!watch("from")) {
                      return "Please choose start date first";
                    }
                    if (!value) {
                      return "End date is required";
                    }
                    const dayValue = dayjs(value); // Create dayjs object
                    if (!dayValue.isValid()) {
                      return "Please select a valid date";
                    }
                    if (value && !dayjs(value, "YYYY-MM-DD", true).isValid()) {
                      return "Please select a valid date in YYYY-MM-DD format";
                    }
                    if (value && dayjs(value).isBefore(watch("from"))) {
                      return "End date must be later then the starting date";
                    }
                    return true;
                  },
                }}
                render={({ field: { onChange, value, ...restField } }) => (
                  <DatePicker
                    {...restField}
                    disabled={!watch("from")}
                    value={value ? dayjs(value) : null}
                    onChange={(newValue) => {
                      const formattedDate = newValue
                        ? dayjs(newValue).format("YYYY-MM-DD")
                        : null;
                      onChange(formattedDate);
                    }}
                    disableFuture
                    views={["year", "month", "day"]}
                    slotProps={{
                      inputAdornment: {
                        position: "start",
                      },
                      textField: {
                        hiddenLabel: true,
                        error: !!errors.to,
                        helperText: errors.to?.message,
                        size: "small",
                        sx: {
                          "& .MuiOutlinedInput-root": {
                            "& fieldset": { borderColor: "#3aa7a3" },
                            "&:hover fieldset": { borderColor: "#3aa7a3" },
                            "&.Mui-focused fieldset": {
                              borderColor: "#3aa7a3",
                            },
                          },
                          "& .MuiInputBase-input": {
                            color: "#3aa7a3",
                          },
                          "& .MuiInputBase-input::placeholder": {
                            color: "#3aa7a3",
                            opacity: 1,
                          },
                          "& .MuiSvgIcon-root": {
                            color: "#3aa7a3",
                          },
                        },
                      },
                    }}
                  />
                )}
              />
            </LocalizationProvider>
          </FormControl>
        </Box>
      </div>

      <Box
        sx={{
          display: "flex",
          mx: "auto",
          gap: 2,
          flexDirection: "column",
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {!receipt ? (
          <YellowButton
            text="Get Receipt"
            loading={loading}
            shouldDisable={
              loading ||
              !watch("from") ||
              !watch("to") ||
              Object.keys(errors).length > 0
            }
          />
        ) : (
          <CancelButton
            text="clear"
            onClick={() => {
              setReceipt(null);
              setShowDownload(false);
              setNoOrders(false);
              setLoading(false);
              reset();
            }}
          ></CancelButton>
        )}

        {showDownload && receipt && (
          <FilePreview
            file={receipt}
            fileUrl={`${backendURL}/receipt/${receipt}`}
          />
        )}
      </Box>
      {noOrder && (
        <ReceiptsError>
          You do not have any orders during this period. Please change the
          filter and try again.
        </ReceiptsError>
      )}
    </form>
  );
};

const DownloadReceipts = ({
  activeTab,
}: {
  activeTab: "Custom" | "Monthly" | "Yearly";
}) => {
  usePageScrollAndTitle({
    title: `Download Invoices - ${activeTab}`,
  });

  return (
    <ThemeProvider theme={customThemeRep}>
      {activeTab === "Monthly" && <MonthlyReceipts />}
      {activeTab === "Yearly" && <YearlyReceipts />}
      {activeTab === "Custom" && <CustomReceipts />}
    </ThemeProvider>
  );
};

export { customThemeRep };

export default DownloadReceipts;
