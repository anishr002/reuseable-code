import watermark70 from "../assets/backgrounds/70percent-bg.png";
import watermark80 from "../assets/backgrounds/80percent-bg.png";

export interface TestType {
  quote: string;
  author: string;
  watermark: string | null;
}
const TestimonialsArr: TestType[] = [
  {
    quote:
      "80% of people who receive coaching report increased self-confidence",
    author: "Institute of Coaching",
    watermark: watermark80,
  },
  {
    quote:
      '“Coaching helps people create and maintain better work-life balance while driving personal growth and development."',
    author: " BBC Worklife",
    watermark: null,
  },
  {
    quote:
      "Over 70% of individuals who received coaching benefit from improved work performance, relationship, and more effective communication skills",
    author: "Institute of Coaching",
    watermark: watermark70,
  },
  {
    quote:
      '"Coaching offers individuals the ability to discover clarity and take actionable steps to achieve personal and professional goals.',
    author: "New York Times",
    watermark: null,
  },
];

export default TestimonialsArr;
