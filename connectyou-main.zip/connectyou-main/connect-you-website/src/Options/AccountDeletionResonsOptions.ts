const AccountDeletionResonsOptions: string[] = [
  "Privacy concerns",
  "Not useful",
  "Technical issues",
  "Found an alternative",
  "Too expensive",
  "Temporary deactivation",
  "Other reasons",
];

export default AccountDeletionResonsOptions;
