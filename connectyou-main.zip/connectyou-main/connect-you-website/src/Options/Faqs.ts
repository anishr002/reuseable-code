interface FAQs_Type {
  question: string;
  answer: string;
}

const aboutConnectYouOptions: FAQs_Type[] = [
  {
    question: "What is connect you?",
    answer: `Connect You is an online marketplace connecting coaches with individuals seeking coaching services. It provides a platform for coaches to showcase their expertise and for clients to find the right coach for their needs.`,
  },
  {
    question: "How does Connect You work?",
    answer: `Coaches create profiles outlining their specialties, experience, and availability. Clients can search for coaches based on their needs and preferences, view coach profiles, and book sessions directly through the platform.`,
  },
  {
    question: "What types of coaches are available on Connect You?",
    answer: `Connect You offers a diverse range of coaches specializing in various areas such as life coaching, career coaching, wellness coaching, executive coaching, and more.`,
  },
  {
    question: "How do I book a coaching session?",
    answer: `Simply browse through coach profiles, select a coach that matches your needs, and schedule a session directly through their profile. You can choose the date, time, and duration of the session that works best for you.`,
  },
  {
    question: "Are the coaches on Connect You certified?",
    answer: `Many coaches on Connect You are certified professionals with recognized coaching credentials. You can view a coach's certifications and credentials on their profile.`,
  },
  {
    question: "What are the payment options available?",
    answer: `Connect You offers secure payment processing for coaching sessions. Clients can pay for sessions using credit/debit cards, PayPal, or other accepted payment methods.`,
  },
  {
    question: "Is my information secure on Coaching certified?",
    answer: `Connect You takes data security and privacy seriously. We use industry-standard encryption and security measures to protect your personal information.`,
  },
  {
    question: "Can I cancel or reschedule a coaching session?",
    answer: `Yes, you can cancel or reschedule a coaching session by writing to us at [email address] at least 24 hours before your scheduled time. Sessions canceled within 24 hours of scheduled time are non-refundable.`,
  },
];

const faqsGeneralOptions: FAQs_Type[] = [
  {
    question: "How is coaching different from therapy?",
    answer:
      " Coaching is future-focused, helping you clarify goals and take actionable steps to achieve them. While therapy addresses past challenges, coaching empowers you to create your ideal future.",
  },
  {
    question: "What can coaching help me achieve?",
    answer:
      "Coaching can help you with personal growth, career advancement, leadership skills, wellness, and more. It’s tailored to your unique goals.",
  },
  {
    question: "What type of coaching is right for me?",
    answer:
      "That depends on your goals. Explore our niches to find the area that aligns with what you want to achieve—whether it’s personal growth, career advancement, leadership development, or wellness. Need help deciding? Contact us, and we’ll guide you to the perfect fit.",
  },
  {
    question: "Can I work with a coach in my language?",
    answer:
      "Yes! Our global network includes multilingual coaches fluent in a variety of languages. Let us match you with a coach who can best support your needs in your preferred language.",
  },
  {
    question: "Is coaching online or in-person?",
    answer:
      "Most sessions are conducted online to offer maximum flexibility and convenience. However, depending on the coach and location, in-person options may be available. You can choose the format that works best for you.",
  },
  {
    question: "What are coaching sessions like?",
    answer:
      "Each session is a collaborative conversation tailored to your goals. Your coach will provide insights, strategies, and support to help you move forward. Your first session will be an introductory session where you meet your coach, discuss your overarching goal, and ensure a good fit. After that, you can book sessions in 45-minute or 60-minute formats, depending on your needs.",
  },
  {
    question: "How does pricing work?",
    answer:
      "Pricing varies by coach and session type. You’ll see each coach’s rate listed next to their profile. You can choose to pay per session or save by purchasing a package of sessions. For corporate clients, we offer custom quotes tailored to your organization’s needs.",
  },
];

const coachFaqOptions: FAQs_Type[] = [
  {
    question: " Do I need to be certified to apply?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Non eius tempora sequi repudiandae cum fuga cumque ab qui nemo quidem.,",
  },
  {
    question: "Can I set my own rates?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Non eius tempora sequi repudiandae cum fuga cumque ab qui nemo quidem.,",
  },
  {
    question: "How does the platform handle payments?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Non eius tempora sequi repudiandae cum fuga cumque ab qui nemo quidem.,",
  },
  {
    question: "How will clients find me?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Non eius tempora sequi repudiandae cum fuga cumque ab qui nemo quidem.,",
  },
];

const faqOptions: {
  aboutConnectYouOptions: FAQs_Type[];
  faqsGeneralOptions: FAQs_Type[];
  coachFaqOptions: FAQs_Type[];
} = {
  aboutConnectYouOptions: aboutConnectYouOptions,
  faqsGeneralOptions: faqsGeneralOptions,
  coachFaqOptions: coachFaqOptions,
};

const faqsOptionsArray = [
  ...aboutConnectYouOptions,
  ...faqsGeneralOptions,
  ...coachFaqOptions,
];

export default faqsGeneralOptions;
export {
  coachFaqOptions,
  aboutConnectYouOptions,
  faqOptions,
  faqsOptionsArray,
};
export type { FAQs_Type };
