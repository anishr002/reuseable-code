export interface GenderOptions_Type {
  label: string;
  value: string;
}
const GenderOptions: GenderOptions_Type[] = [
  { label: "Male", value: "Male" },
  { label: "Female", value: "Female" },
  { label: "Others", value: "Others" },
];

export default GenderOptions;
