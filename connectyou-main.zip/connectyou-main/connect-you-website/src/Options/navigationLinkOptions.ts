import {
  MdOutlineAccountCircle,
  MdOutlineAttachMoney,
  MdOutlineBadge,
  MdOutlineCalendarMonth,
  MdOutlineChat,
  MdOutlineDashboard,
  MdOutlineToday,
  MdOutlineWorkHistory,
} from "react-icons/md";
import { PiBookOpenTextBold } from "react-icons/pi";
import { IconType } from "react-icons/lib";
type linkType = {
  name: string;
  link: string;
  icon?: IconType;
};
interface navigationLinkOptionsType {
  top: linkType[];
  footer: linkType[];
  policies: linkType[];
  coachDashboard: linkType[];
  coacheeDashboard: linkType[];
}

const navigationLinkOptions: navigationLinkOptionsType = {
  top: [
    { name: "about", link: "/about" },
    { name: "For Individuals", link: "/individuals" },
    // { name: "coaches", link: "/become-a-coach" },
    { name: "For Businesses", link: "/businesses" },
    { name: "Log In", link: "/login" },
  ],
  footer: [
    { name: "About", link: "/about" },
    { name: "Find A Coach", link: "/find-a-coach/list" },
    // { name: "Find A Coach", link: "/coach" },
    { name: "For Individuals", link: "/individuals" },
    { name: "For Businesses", link: "/businesses" },
    { name: "FAQs", link: "/faqs" },
    // { name: "Become A Coach", link: "/signup-coach" },
  ],
  policies: [
    { name: "Privacy Policies", link: "/privacy-policy" },
    { name: "Terms Of Use", link: "/terms-of-service" },
    { name: "Cookie Policies", link: "/cookie-policy" },
  ],

  coachDashboard: [
    {
      name: "Dashboard",
      link: "/c/dashboard",
      icon: MdOutlineDashboard,
    },
    {
      name: "Bookings",
      link: "/c/bookings",
      icon: MdOutlineCalendarMonth,
    },
    {
      name: "Sessions",
      link: "/c/sessions",
      icon: MdOutlineToday,
    },
    {
      name: "Availability",
      link: "/c/availability",
      icon: MdOutlineWorkHistory,
    },
    { name: "Chat", link: "/c/chat", icon: MdOutlineChat },
    {
      name: "Resources",
      link: "/c/resources",
      icon: PiBookOpenTextBold,
    },
    {
      name: "Finances",
      link: "/c/finances",
      icon: MdOutlineAttachMoney,
    },
    {
      name: "Profile",
      link: "/c/profile",
      icon: MdOutlineAccountCircle,
    },
  ],
  coacheeDashboard: [
    {
      name: "Dashboard",
      link: "/u/dashboard",
      icon: MdOutlineDashboard,
    },
    {
      name: "Bookings",
      link: "/u/bookings",
      icon: MdOutlineCalendarMonth,
    },
    {
      name: "Coaches",
      link: "/u/my-coaches",
      icon: MdOutlineBadge,
    },
    { name: "Chat", link: "/u/chat", icon: MdOutlineChat },
    {
      name: "Resources",
      link: "/u/resources",
      icon: PiBookOpenTextBold,
    },
    {
      name: "Payments",
      link: "/u/payments",
      icon: MdOutlineAttachMoney,
    },
    {
      name: "Profile",
      link: "/u/profile",
      icon: MdOutlineAccountCircle,
    },
  ],
};
export default navigationLinkOptions;
export type { linkType, navigationLinkOptionsType };
