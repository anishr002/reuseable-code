import { Focus_Area_type } from "../Types/backend/Coach_Data_Type";

const Coaching_Focus_Area: Focus_Area_type[] = [
  {
    category: "Leadership & Management",
    label: "Build confidence and amplify your impact as a people leader",
    tag: "Leadership Confidence",
  },
  {
    category: "Leadership & Management",
    label:
      "Master delegation, feedback, and holding others accountable with ease",
    tag: "Delegation Skills",
  },
  {
    category: "Leadership & Management",
    label: "Step into a new leadership role with clarity and success",
    tag: "Leadership Transition",
  },
  {
    category: "Leadership & Management",
    label: "Lead with vision, emotional intelligence, and authentic influence",
    tag: "Visionary Leadership",
  },
  {
    category: "Leadership & Management",
    label: "Navigate conflict and lead team dynamics with calm authority",
    tag: "Conflict Navigation",
  },

  {
    category: "Communication & Presence",
    label: "Communicate powerfully in high-stakes, high-visibility moments",
    tag: "Strategic Communication",
  },
  {
    category: "Communication & Presence",
    label: "Become a confident, compelling speaker and presenter",
    tag: "Public Speaking",
  },
  {
    category: "Communication & Presence",
    label: "Deliver feedback that is clear, direct, and growth-focused",
    tag: "Feedback Delivery",
  },
  {
    category: "Communication & Presence",
    label: "Strengthen your executive presence and strategic influence",
    tag: "Executive Presence",
  },
  {
    category: "Communication & Presence",
    label:
      "Navigate and lead tough conversations with composure and compassion",
    tag: "Courageous Conversations",
  },
  {
    category: "Stress, Balance & Boundaries",
    label:
      "Build lasting resilience and sustain high performance under pressure",
    tag: "Stress Resilience",
  },
  {
    category: "Stress, Balance & Boundaries",
    label: "Create a healthy, values-aligned work-life balance",
    tag: "Work-Life Balance",
  },
  {
    category: "Stress, Balance & Boundaries",
    label: "Set empowered boundaries and say no with confidence",
    tag: "Boundary Setting",
  },
  {
    category: "Stress, Balance & Boundaries",
    label: "Protect and replenish your energy for long-term leadership impact",
    tag: "Energy Management",
  },
  {
    category: "Stress, Balance & Boundaries",
    label: "Take time for yourself—guilt-free and growth-driven",
    tag: "Self-Care Practices",
  },

  {
    category: "Career Growth & Confidence",
    label: "Gain strategic clarity on your next leadership move",
    tag: "Career Clarity",
  },
  {
    category: "Career Growth & Confidence",
    label: "Build unshakable confidence and self-trust in your role",
    tag: "Role Confidence",
  },
  {
    category: "Career Growth & Confidence",
    label: "Prepare for your next promotion or executive step",
    tag: "Leadership Preparation",
  },
  {
    category: "Career Growth & Confidence",
    label: "Break through leadership plateaus with energy and momentum",
    tag: "Career Momentum",
  },
  {
    category: "Career Growth & Confidence",
    label: "Own your voice, advocate for your growth, and lead your future",
    tag: "Voice and Advocacy",
  },
];

export default Coaching_Focus_Area;
