export default interface mongoLocationType {
    type: "Point";
    coordinates: number[]; // array of numbers representing the coordinates
  }