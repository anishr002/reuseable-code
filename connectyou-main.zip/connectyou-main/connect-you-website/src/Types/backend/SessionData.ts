import BookedSession_TImeline_Type from "./BookedSession_TImeline_Type";
import { Coach_Data_Type } from "./Coach_Data_Type";
import { Coachee_Data_Type } from "./Coachee_Data_Type";
import Review_Type from "./Review_Type";

interface Currency {
  code: string;
  label: string;
  phone: string;
  currency: string;
  symbol: string;
  _id: string;
}
interface SessionDetails {
  _id: string;
  title: string;
  price: number;
  type: number;
  deleted: number;
  description: string;
  currency: Currency;
}
interface SessionData {
  _id: string;
  cartId: string;
  bookingId: string;
  userId: string;
  coachId: string;
  sessionId: string;
  coachTimeZone: string;
  sessionType: string;
  sessionDate: string;
  sessionDateUpdated: string;
  amount: number;
  sessionStatus: number;
  refundsStatus: string;
  sessionCancelBy: string;
  sessionCompletedUser: number;
  sessionCompletedCoach: number;
  messageCancel: string;
  completedCoachMSG: string;
  completedUserMSG: string;
  absentee: string;
  markedBy: string;
  createdAt: string;
  updatedAt: string;
  sessionCompletedDate: string;
  coachRemarks: string;
  coacheeRemarks: string;
  reasonForIncomplete: string;
  coacheeActionTime: string;
  coachActionTime: string;
  rescheduled: boolean;
}

interface OrderDetails {
  _id: string;
  amount: string;
  receipt: string;
  TransactionID: string;
  paid: string;
  createdAt: string;
}

export interface Rating extends Review_Type {
  userDetails: Pick<Coachee_Data_Type, "name" | "lastName" | "image" | "_id">;
}
export default interface Sessions extends SessionData {
  coacheeDetails: Partial<Coachee_Data_Type>;
  coachDetails: Partial<Coach_Data_Type>;
  sessionDetails: SessionDetails;
  orderDetails: OrderDetails;
  reviewDetails: Rating;
  timeline: BookedSession_TImeline_Type[];
}
