export interface CoachEducationalBackground_Type {
  _id: string;
  organization: string;
  degree: string;
  startDate: string;
  endDate: string;
  coachId: string;
  createdAt: string;
  updatedAt: string;
}
