export default interface Review_Type {
  _id: string;
  ratingNumber: number;
  remarks: string;
  title: string;
  coachId: string;
  userId?: string;
  bookingId?: string;
  orderId?: string;
  createdAt: string;
  updatedAt: string;
}
