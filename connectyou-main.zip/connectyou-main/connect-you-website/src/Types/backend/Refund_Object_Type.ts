/* eslint-disable @typescript-eslint/no-explicit-any */
export interface Refund_Object_Type {
  cartId: string;
  bookings_id: string;
  booked_session_id: string;
  userId: string;
  coachId: string;
  sessionId: string;
  coachTimeZone: string;
  userTimeZone: string;
  sessionType: string;
  sessionDate: Date;
  sessionDateUpdated: Date;
  charge: string;
  amount: string;
  session_cancel_remark: string;
  cancel_requested_by: string;
  refund_status: number; /// 0 for pending , 1 for approved // 2 for denied
  refund_id: string;
  refund_transaction_id: string;
  refund_charge_id: string;
  refund_created: string;
  refund_amount: string;
  refund_stripe_status: string;
  createdAt: string;
  refunded_details: {
    paid: string;
    payment_intent: string;
    payment_method: string;
    receipt_email: string;
    receipt_url: string;
    processed_charge_id: string;
    billing_details: Record<any, any>;
    payment_method_details: Record<any, any>;
  };
}
