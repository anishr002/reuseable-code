export interface CoachWorkExp_Type {
  _id: string;
  organization: string;
  position: string;
  workingOn: boolean;
  startDate: string;
  endDate: string;
  coachId: string;
  updatedAt: string;
  createdAt: string;
}
