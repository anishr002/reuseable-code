import mongoLocationType from "./mongoLocationType";

export interface Coachee_Data_Type {
  name: string;
  userName: string;
  lastName?: string;
  email: string;
  emailVerified: number; // 1 for verified, 0 for not verified
  password: string;
  gender?: "Male" | "Female" | "Other";
  DOB?: Date;
  image: string;
  location?: mongoLocationType;
  areas_of_interest: string[];
  country: string;
  city: string;
  fullAddress: string;
  deleteReq: number; // 2 for delete request, 1 for request approved
  timeZone: string;
  my_invitation_code: string; // Unique string
  live: number; // 0 for not live, 1 for live
  lastSeen: string;
  hub_spot_id: string;
  userType: string;
  _id: string;
  createdAt: string;
  updatedAt: string;
  aboutMe?: string;
  occupation?: string;
  myDescription?: string[];
  countryCode?: string;
  phoneCode?: string;
}
