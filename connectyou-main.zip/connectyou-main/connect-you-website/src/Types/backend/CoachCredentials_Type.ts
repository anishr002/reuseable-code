export interface CoachCredentials_Type {
  _id: string;
  title: string;
  image: string;
  workingOn: boolean;
  startDate: string;
  endDate: string;
  coachId: string;
  createdAt: string;
  updatedAt: string;
}
