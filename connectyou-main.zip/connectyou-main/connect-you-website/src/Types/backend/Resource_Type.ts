interface ResourcesData {
  _id: string;
  title: string;
  description: string;
  availableFor: "coach" | "coachee" | "all";
  createdAt: Date;
  updatedAt: Date;
}

interface ResourcesModule_Type {
  resourceId: string;
  title: string;
  description: string;
  thumbnailImage: string;
  pdfFile: string;
  createdAt: Date;
  updatedAt: Date;
  _id: string;
}

interface ResourceDetails extends ResourcesData {
  modules: ResourcesModule_Type[];
}

export type { ResourcesData, ResourcesModule_Type, ResourceDetails };
