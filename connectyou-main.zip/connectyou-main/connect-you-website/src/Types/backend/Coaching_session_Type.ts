interface Currency {
  code: string;
  label: string;
  phone: string;
  currency: string;
  symbol: string;
}

export interface Timeslot {
  from: string;
  to: string;
}

export default interface Coaching_session_Type {
  title: string;
  price: number;
  description: string;
  type: number;
  _id: string;
  currency: Currency;
  createdAt: string;
  coachId: string;
  duration: number;
  status: boolean;
  stripePriceId: string;
  stripeProductId: string;
}
