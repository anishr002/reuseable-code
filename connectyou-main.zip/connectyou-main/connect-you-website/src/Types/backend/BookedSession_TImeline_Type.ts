export default interface BookedSession_TImeline_Type {
  bookedSessionId: string;
  userId: string;
  coachId: string;
  sessionId: string;
  action: string;
  message: string;
  actionBy: string;
  createdAt?: Date;
  updatedAt?: Date;
}
