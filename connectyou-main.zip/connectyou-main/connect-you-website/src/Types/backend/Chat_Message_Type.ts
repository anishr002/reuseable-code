export type messageReadStatus = "read" | "delivered" | "sent" | "failed" | "";

export default interface Chat_Message_Type {
  _id: string;
  senderId: string;
  receiverId: string;
  chatRoomId: string;
  message: string;
  messageType: string;
  messageReadStatusCoach: messageReadStatus;
  messageReadStatusUser: messageReadStatus;
  files: string[];
  createdAt: string;
  updatedAt: string;
}

