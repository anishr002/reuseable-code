import { TimeSlot } from "../../components/hooks/useCreateAvailableTimeSlots";

/**
 * @returns date: YYYY-MM-DD
 */

export type DisabledSlot = {
  date: string; // ISO or "YYYY-MM-DD" format
  slots: TimeSlot[];
};
