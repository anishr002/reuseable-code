export interface CoachCertificate_Type {
  _id: string;
  title: string;
  certificateFile: string;
  coachId: string;
  createdAt: string;
  updatedAt: string;
}
