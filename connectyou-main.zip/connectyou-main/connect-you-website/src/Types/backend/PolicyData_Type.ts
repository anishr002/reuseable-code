export default interface PolicyData {
    data: string;
    _id: string;
  }