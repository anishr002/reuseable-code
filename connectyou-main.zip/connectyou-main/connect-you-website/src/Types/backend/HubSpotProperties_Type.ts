export interface HubSpotProperties_Type_Coach {
  firstname: string;
  lastname: string;
  gender: string;
  full_address: string;
  email: string;
  country: string;
  city: string;
  date_of_birth: string;
  languages: string;
  coaching_specialities: string;
  coaching_experience: string;
  coaching_certifications: string;
  npo_coach: boolean;
  registered_as_coach: boolean;
  years_of_experience: string;
  b2b_coach: string; // later maybe we have to switch this to a boolean as the admin might have mistakenly added this as a string on the hub spot portal
}
export interface HubSpotProperties_Type_Coachee {
  firstname: string;
  lastname: string;
  gender: string;
  date_of_birth: string;
  email: string;

  languages: string;
  full_address: string;
  country: string;
  city: string;
  areas_of_interest: string;
  b2b_training: boolean;
  is_connectyou_coachee: boolean;
  npo_training: boolean;
}

