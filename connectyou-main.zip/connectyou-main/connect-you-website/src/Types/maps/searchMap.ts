import { FcAbout } from "react-icons/fc";
import {
  FaBalanceScale,
  FaBriefcase,
  FaCookieBite,
  FaEnvelope,
  FaHome,
  FaInfoCircle,
  FaQuestion,
  FaShieldAlt,
  FaShoppingCart,
  FaUser,
} from "react-icons/fa";
import { SearchOtpionTypes } from "../UI/SearchMap";
import ActionProvider from "../../util/ProvideActions";
import { IoMdLogOut } from "react-icons/io";
import { logout } from "../../slices/Login";
import logoutLocal from "../../util/logoutLocal";
import scrollToEl from "../../util/scrollToEl";
import { faqOptions } from "../../Options/Faqs";

const coacheeOptions: SearchOtpionTypes[] = [
  {
    keyword: ["notification", "alerts", "coachee notifications"],
    label: "All Notifications",
    route: "/u/notifications",
    userType: "coachee",
    subLabel: "Stay updated with your scheduled sessions and other alerts",
  },
  {
    keyword: ["dashboard", "coachee", "coachee dashboard"],
    label: "Dashboard",
    route: "/u/dashboard",
    userType: "coachee",
    subLabel: "Track your sessions and progress in a compact view ",
  },
  {
    keyword: ["forgot", "password", "reset", "recover"],
    label: " Forgot Password",
    route: "/forgot-password/coachee",
    userType: "coachee",
    subLabel: "Recover your account with a new password",
  },
  {
    keyword: ["my-coaches", "find-a-coach", "coaches"],
    label: "My Coaches",
    route: "/u/my-coaches",
    userType: "coachee",
    subLabel: "Find and manage your coaches",
  },
  {
    keyword: ["bookings", "upcoming", "completed", "canceled"],
    label: "Bookings",
    route: "/u/bookings",
    userType: "coachee",
    subLabel: "Manage and view your upcoming, completed, and canceled sessions",
  },
  {
    keyword: ["upcoming", "bookings", "booking", "sessions"],
    label: "Upcoming Sessions",
    route: "/u/bookings/upcoming",
    userType: "coachee",
    subLabel: "Your upcoming sessions",
  },
  {
    keyword: ["completed", "bookings", "booking", "sessions"],
    label: "Completed Sessions",
    route: "/u/bookings/completed",
    userType: "coachee",
    subLabel: "Your completed sessions",
  },
  {
    keyword: ["canceled", "bookings", "booking", "sessions"],
    label: "Canceled Sessions",
    route: "/u/bookings/canceled",
    userType: "coachee",
    subLabel: "Your canceled sessions",
  },
  {
    keyword: ["chat", "coachee chat"],
    label: "Chat",
    route: "/u/chat",
    userType: "coachee",
    subLabel: "Communicate with your coaches and other coachees",
  },
  {
    keyword: ["payments", "coachee payments", "rahul"],
    label: "Payments",
    route: "/u/payments",
    userType: "coachee",
    subLabel: "Manage your payment methods and history",
  },
  {
    keyword: ["profile", "coachee profile"],
    label: "Profile",
    route: "/u/profile",
    userType: "coachee",
    subLabel: "View and update your personal information",
  },
  {
    keyword: ["resources", "coachee resources"],
    label: "Resources",
    route: "/u/resources",
    userType: "coachee",
    subLabel: "Access learning materials and resources",
  },
  {
    keyword: ["cart"],
    label: "Cart",
    route: "/cart",
    userType: "coachee",
    action: () => undefined,
    subLabel: "Your Shopping Cart",
    Icon: FaShoppingCart,
  },
];

const coachOptions: SearchOtpionTypes[] = [
  {
    keyword: ["dashboard", "coach", "coach dashboard"],
    label: " Dashboard",
    route: "/c/dashboard",
    userType: "coach",
    subLabel: "Manage your coaching sessions and profile",
  },
  {
    keyword: ["notification", "alerts", "coach notifications"],
    label: "All Notifications",
    route: "/c/notifications",
    userType: "coach",
    subLabel: "Stay updated with your coaching activities",
  },
  {
    keyword: ["forgot", "password", "reset", "recover"],
    label: " Forgot Password",
    route: "/forgot-password/coach",
    userType: "coach",
    subLabel: "Recover your account with a new password",
  },
  {
    keyword: ["bookings", "sessions"],
    label: "Bookings",
    route: "/c/bookings",
    userType: "coach",
    subLabel: "View and manage your bookings",
  },
  {
    keyword: ["bookings", "upcoming"],
    label: "Upcoming Sessions",
    route: "/c/bookings/upcoming",
    userType: "coach",
    subLabel: "Sessions that are scheduled to happen",
  },
  {
    keyword: ["bookings", "completed"],
    label: "Completed Sessions",
    route: "/c/bookings/completed",
    userType: "coach",
    subLabel: "Sessions that have been completed",
  },
  {
    keyword: ["bookings", "canceled"],
    label: "Canceled Sessions",
    route: "/c/bookings/canceled",
    userType: "coach",
    subLabel: "Sessions that were canceled",
  },
  {
    keyword: ["availability", "schedule"],
    label: "Availability",
    route: "/c/availability",
    userType: "coach",
    subLabel: "Set and manage your availability",
  },
  {
    keyword: ["sessions", "my sessions"],
    label: "My Sessions",
    route: "/c/sessions",
    userType: "coach",
    subLabel: "View your personal coaching sessions",
  },
  {
    keyword: ["finances", "financials"],
    label: "Finances",
    route: "/c/finances",
    userType: "coach",
    subLabel: "Manage your earnings and banking details",
  },
  {
    keyword: ["finances", "banking", "bank details"],
    label: "Banking Details",
    route: "/c/finances/banking-details",
    userType: "coach",
    subLabel: "View and update your banking information",
  },
  {
    keyword: ["finances", "payout", "payment history"],
    label: "Payout History",
    route: "/c/finances/payout-history",
    userType: "coach",
    subLabel: "Review your past payouts",
  },
  {
    keyword: ["resources", "coach resources"],
    label: "Resources",
    route: "/c/resources",
    userType: "coach",
    subLabel: "Access coaching materials and resources",
  },
  {
    keyword: ["profile", "user profile", "my profile"],
    label: "Profile",
    route: "/c/profile",
    userType: "coach",
    subLabel: "View and edit your profile",
  },
  {
    keyword: ["chat", "coach chat", "message"],
    label: "Chat",
    route: "/c/chat",
    userType: "coach",
    subLabel: "Communicate with your coachee",
  },
  ...[...faqOptions.coachFaqOptions].map(
    (faq): SearchOtpionTypes => ({
      keyword: [...faq.question.split(" "), ...faq.answer.split(" ")],
      label: faq.question,
      userType: "coach",
      action: () => {
        ActionProvider?.navigate?.(`/faqs`, {
          state: {
            open: `${faq.question}`,
          },
        });
        // scrollToEl(faq.question);
      },
      subLabel: "Seacrh this in the faq",
      Icon: FaQuestion,
    })
  ),
];

const globalOptions: SearchOtpionTypes[] = [
  {
    keyword: ["home", "ConnectYou"],
    label: " Home",
    route: "/",
    userType: "global",
    action: () => undefined,
    subLabel: "Home",
    Icon: FaHome,
  },
  {
    keyword: ["home", "let's", "connect", "contact us", "help", "ConnectYou"],
    label: "Let's Connect",
    // route: "",
    userType: "global",
    action: () => {
      ActionProvider?.navigate?.(`/#lets-connect`);
      scrollToEl("lets-connect");
    },
    subLabel: "Home",
    Icon: FaHome,
  },
  {
    keyword: ["Explore Coaching", "Explore", " Coaching", "ConnectYou"],
    label: "Explore Coaching",
    userType: "global",
    action: () => {
      ActionProvider?.navigate?.(`/#explore-coaching`);
      scrollToEl("explore-coaching");
    },
    subLabel: "Home",
    Icon: FaHome,
  },
  {
    keyword: ["Explore Coaching", "Explore", " Coaching", "ConnectYou"],
    label: "Meet Our World-Class Coaches",
    userType: "global",
    action: () => {
      ActionProvider?.navigate?.(`/#feature-coaches`);
      scrollToEl("feature-coaches");
    },
    subLabel:
      "Explore profiles of some of our top coaches, each with unique specialties and a track record of inspiring success.",
    Icon: FaHome,
  },
  {
    keyword: ["about", "about ConnectYou"],
    label: " About",
    route: "/about",
    userType: "global",
    subLabel: "About ConnectYou",
    Icon: FcAbout,
  },
  {
    keyword: [
      "Story",
      "connect you",
      "erickson",
      "coaching ",
      "About",
      "ConnectYou",
    ],
    label: "The Story of ConnectYou",
    userType: "global",
    action: () => {
      ActionProvider?.navigate?.(`/about/#connect-you-story`);
      scrollToEl("connect-you-story");
    },
    subLabel: "About connect you",
    Icon: FcAbout,
  },
  {
    keyword: ["find", "coach", "find a coach", "connect with coach"],
    label: " Find a Coach",
    route: "/find-a-coach/list",
    userType: "global",
    subLabel: "Find the perfect coach for you",
  },

  {
    keyword: ["faq", "faqs", "help", "questions"],
    label: " FAQs",
    route: "/faqs",
    userType: "global",
    subLabel: "Find answers to frequently asked questions",
  },
  {
    keyword: ["about"],
    label: "About",
    route: "/about",
    userType: "global",
    action: () => undefined,
    subLabel: "About Us",
    Icon: FaInfoCircle,
  },
  {
    keyword: ["individuals"],
    label: "Individuals",
    route: "/individuals",
    userType: "global",
    action: () => undefined,
    subLabel: "For Individuals",
    Icon: FaUser,
  },
  {
    keyword: ["businesses"],
    label: "Businesses",
    route: "/businesses",
    userType: "global",
    action: () => undefined,
    subLabel: "For Businesses",
    Icon: FaBriefcase,
  },

  {
    keyword: ["get-in-touch"],
    label: "Get in Touch",
    route: "/get-in-touch",
    userType: "global",
    action: () => undefined,
    subLabel: "Contact Us",
    Icon: FaEnvelope,
  },
  {
    keyword: ["privacy-policy", "policy", "policies"],
    label: "Privacy Policy",
    route: "/privacy-policy",
    userType: "global",
    action: () => undefined,
    subLabel: "Our Privacy Policy",
    Icon: FaShieldAlt,
  },
  {
    keyword: ["terms-of-service", "policy", "policies"],
    label: "Terms of Service",
    route: "/terms-of-service",
    userType: "global",
    action: () => undefined,
    subLabel: "Terms and Conditions",
    Icon: FaBalanceScale,
  },
  {
    keyword: ["cookie-policy", "policy", "policies"],
    label: "Cookie Policy",
    route: "/cookie-policy",
    userType: "global",
    action: () => undefined,
    subLabel: "Cookie Usage",
    Icon: FaCookieBite,
  },
  {
    keyword: ["logout", "signout"],
    label: "Logout",
    userType: "global",
    action: () => {
      ActionProvider?.dispatch?.(logout());
      logoutLocal();
    },
    subLabel: "Logout this account",
    Icon: IoMdLogOut,
  },
  ...[
    ...faqOptions.aboutConnectYouOptions,
    ...faqOptions.faqsGeneralOptions,
  ].map(
    (faq): SearchOtpionTypes => ({
      keyword: [...faq.question.split(" "), ...faq.answer.split(" ")],
      label: faq.question,
      userType: "global",
      action: () => {
        ActionProvider?.navigate?.(`/faqs`, {
          state: {
            open: `${faq.question}`,
          },
        });
        // scrollToEl(faq.question);
      },
      subLabel: "Seacrh this in the faq",
      Icon: FaQuestion,
    })
  ),
];

const SearchMap: SearchOtpionTypes[] = [
  ...coacheeOptions,
  ...coachOptions,
  ...globalOptions,
];

const getSearchSuggestionsList = (userType?: "coach" | "coachee") => {
  let map: SearchOtpionTypes[] = [];
  if (userType) {
    map = SearchMap.filter((s) => ["global", userType].includes(s.userType));
  } else {
    map = SearchMap.filter((s) => s.userType === "global");
  }
  return map;
};

export default getSearchSuggestionsList;
