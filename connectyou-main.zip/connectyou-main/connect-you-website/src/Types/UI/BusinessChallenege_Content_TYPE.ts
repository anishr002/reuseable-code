export default interface Business_Challenege_Content_TYPE {
  image: string;
  heading: string;
  description: string;
}
