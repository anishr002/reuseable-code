export default interface Coaching_Programs_Tabs_Data_TYPE {
  index: number;
  name: string;
  content: {
    image: string;
    heading: string;
    description: string;
  };
}
