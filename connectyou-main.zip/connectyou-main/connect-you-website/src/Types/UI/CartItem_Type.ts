import { Coach_Data_Type } from "../backend/Coach_Data_Type";

export default interface CartItem_Type {
  _id: string;
  coachId: string;
  userId: string;
  cartId: string;
  sessionId: string;
  sessionDate: string;
  coachData: Pick<
    Coach_Data_Type,
    "_id" | "name" | "Lname" | "userName" | "gender" | "image" | "timeZone"
  >;
  sessionData: Session;
}

interface Session {
  _id: string;
  title: string;
  price: number;
  type: number;
  description: string;
  stripePriceId: string;
  currency: string;
  currencySymbol: string;
}
