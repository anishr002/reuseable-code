import { IconType } from "react-icons/lib";

export interface SearchOtpionTypes {
  userType: "coach" | "coachee" | "global";
  label: string;
  subLabel?: string;
  route?: string;
  keyword: string[];
  action?: () => void | Promise<void> | undefined;
  Icon?: IconType;
}
