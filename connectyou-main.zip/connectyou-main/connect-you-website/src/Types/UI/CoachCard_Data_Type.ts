type Coachcredentials = {
  title: string;
  image: string;
  startDate: string;
  workingOn: boolean;
  endDate: string;
};

type CoachEducation = {
  degree: string;
  endDate: string;
  organization: string;
  startDate: string;
  workingOn: boolean;
};

type Coachexperiences = {
  organization: string;
  position: string;
  startDate: string;
  workingOn: boolean;
  endDate: string;
};

type coachcertificates = {
  [key: string]: string;
};

export default interface CoachCard_Data_Type {
  _id: string;
  name: string;
  email: string;
  gender: string;
  DOB: string;
  image: string;
  about_me: string;
  city: string;
  Lname: string;
  experienceYear: number;
  country: string;
  freeTrial: string;
  emailVerified: number;
  title_line: string;
  averageRating: number;
  experience: number;
  totalRatings: number;
  about: string;
  languages: string[];
  coachingSpecialities: [string];
  coachcredentials: Coachcredentials[];
  industries: string[];
  createdAt: string;
  timeZone: string;
  fullAddress: string;
  coachexperiences: Coachexperiences[];
  coacheducations: CoachEducation[];
  coachcertificates: coachcertificates[];
}
