const express = require("express");
const router = express.Router();
const { body, param } = require("express-validator");
const controller = require("./controller");
router.use(express.json());
router.use(express.urlencoded({ extended: true }));
/////////////
const AUTHCoach = require("../../middleware/authTokenCoach");
const AUTHCoachee = require("../../middleware/authTokenUser");
const AUTHAdmin = require("../../middleware/authTokenAdmin");
const validation = require("../../middleware/validation");

// OAuth Redirect URI
router.get("/oauth", controller.OAUTH);
router.get("/oauth/callback", controller.OAUTH_Callback);
router.get("/refresh-token", controller.Refresh_OAUTH_Token);
// oatuh apis end -------

///-------  api-v3 -- for production ------///
router.post(
  "/api-v3/contacts/create-hub-contact",
  [
    body("properties")
      .exists()
      .withMessage("Please attach properties to the req body")
      .isObject()
      .withMessage("Invalid body attachments"),
  ],
  controller.create_hubspot_contact
);

router.post(
  "/api-v3/contacts/coach/update-hub-contact",
  AUTHCoach.authTokenCoach,
  controller.update_hubspot_contact_coach
);

router.post(
  "/api-v3/contacts/coachee/update-hub-contact",
  AUTHCoachee.authTokenUser,
  controller.update_hubspot_contact_coachee
);

// if any user registration fails due to some reasons we add the lead to the hubspot
router.post(
  "/api-v3/leads/coachee/generate-hub-lead",
  controller.generateHubLead
);

router.post(
  "/api-v3/properties/add-hub-contact-properties",
  // AUTHAdmin.authTokenAdmin,
  controller.add_property_fields
);
router.get(
  "/api-v3/properties/list-hub-contact-properties/:object",
  // AUTHAdmin.authTokenAdmin,
  controller.listGruopAndProps
);

const syncController = require("./syncData");
router.post(
  "/api-v3/sync-data/sync-coaches",
  [
    body("filter")
      .trim()
      .exists()
      .withMessage("Please provide coach status filter "),
  ],
  validation.response,
  AUTHAdmin.authTokenAdmin,
  syncController.syncCoachesFromHubspot
);

module.exports = router;
