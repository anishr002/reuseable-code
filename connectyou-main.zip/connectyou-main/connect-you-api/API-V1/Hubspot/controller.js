require("dotenv").config();
const CLIENT_ID = process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.CLIENT_SECRET;
const SCOPES = "contacts";
const REDIRECT_URI = "//";
const HUBSPOT_ACCESS_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
const axios = require("axios");
const hubspot = require("@hubspot/api-client");
const { default: mongoose } = require("mongoose");
const userModel = require("../../models/user");
const CoachModel = require("../../models/coach");
const {
  checkHubspotExistance,
  updateHubData_coachee,
  updateHubData_coach,
} = require("./updater");

const HUB_SPOT_FIELDS = require("./structure");

const hubspotClient = new hubspot.Client({
  accessToken: HUBSPOT_ACCESS_TOKEN,
});

// error handler for this file
const handleErrors = async ({ req, res, error, message }) => {
  // console.error("Error in hubspot controller :", error);
  return res.status(error?.response?.status || 500).json({
    message: error?.message || message || "Failed to create contact",
    error: error?.response?.data || error?.message,
  });
};

exports.OAUTH = async (req, res) => {
  const hubspotAuthUrl = `https://router.hubspot.com/oauth/authorize?client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&scope=${SCOPES}`;
  res.redirect(hubspotAuthUrl);
};

exports.OAUTH_Callback = async (req, res) => {
  const { code } = req.query;
  if (!code) {
    return res.status(400).send("Authorization code is missing");
  }
  try {
    const response = await axios.post(
      "https://api.hubapi.com/oauth/v1/token",
      null,
      {
        params: {
          grant_type: "authorization_code",
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          redirect_uri: REDIRECT_URI,
          code: code,
        },
      }
    );
    const { access_token, refresh_token } = response.data;
    // Store the access token and refresh token securely
    // (e.g., in a database or environment variables)
    process.env.HUBSPOT_ACCESS_TOKEN = access_token;
    process.env.HUBSPOT_REFRESH_TOKEN = refresh_token;
    return res
      .status(200)
      .send("Authorization successful. You can now make API calls.");
  } catch (error) {
    console.error("Error exchanging authorization code:", error);
    return res.status(500).send("Error during OAuth token exchange");
  }
};

async function refreshAccessToken() {
  const response = await axios.post(
    "https://api.hubapi.com/oauth/v1/token",
    null,
    {
      params: {
        grant_type: "refresh_token",
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        refresh_token: process.env.HUBSPOT_REFRESH_TOKEN,
      },
    }
  );
  const { access_token } = response.data;
  process.env.HUBSPOT_ACCESS_TOKEN = access_token;
}

/// api -v3--- for production ------// //
// // Function to refresh the OAuth access token using refresh token //
exports.Refresh_OAUTH_Token = async (req, res) => {
  try {
    await refreshAccessToken();
    return res.status(200).send("Access token refreshed successfully.");
  } catch (error) {
    return res.status(500).send("Error refreshing access token");
  }
};

// api -v3--- for production ------//
// create hub contact
exports.create_hubspot_contact = async (req, res) => {
  try {
    let hubSpotId;
    let response;
    let entity;
    const { _id, properties, userType } = req.body;
    if (!mongoose.Types.ObjectId.isValid(_id)) {
      throw new Error("Invalid request");
    }
    // console.log({ userType, properties, _id });
    const entity_id = new mongoose.Types.ObjectId(_id);
    if (userType === "coachee") {
      const coachee = await userModel
        .find({ _id: entity_id })
        .select("-_id email");
      entity = { model: userModel, data: coachee[0] };
    } else if (userType === "coach") {
      const coach = await CoachModel.find({
        _id: entity_id,
      }).select("-_id email");
      entity = { model: CoachModel, data: coach[0] };
    }
    // console.log({ entity });
    if (!entity || !entity.model || !entity.data) {
      const error = new Error("Entity data not found !");
      error.status = 404;
      throw error;
    }
    const email = entity.data.email;
    // console.log({ email });
    const checkHub = await checkHubspotExistance({ email });
    // console.log({checkHub})
    if (checkHub.exists) {
      try {
        const res = await hubspotClient.crm.contacts.basicApi.update(
          checkHub.data.id,
          {
            properties: properties,
          }
        );
        hubSpotId = checkHub.data.id;
        response = res;
      } catch (error) {
        console.error({
          "error in create_hubspot_contact-update-block": {
            error: error?.response?.message,
          },
        });
        throw new Error("Internal server error");
      }
    } else {
      try {
        const res = await hubspotClient.crm.contacts.basicApi.create({
          properties: properties,
        });
        hubSpotId = res.id;
        response = res;
      } catch (error) {
        console.error({
          "error in create_hubspot_contact-create-block": {
            error: error?.response?.message,
          },
        });
        throw new Error("Internal server error");
      }
    }
    await entity.model.updateOne(
      { _id: entity_id },
      {
        $set: {
          hub_spot_id: hubSpotId,
        },
      }
    );
    return res.status(200).json({
      success: true,
      message: "Success adding hubspot contact !",
    });
  } catch (error) {
    handleErrors({
      req,
      res,
      error,
      message: "Error creating Hubspot contact",
    });
  }
};

//  In case of failed registration of either coach or the coachee we  add a lead type contact to the hub spot portal to ensure
// that the email and the name of the user who tried to register with ConnectYou is
// added to the list of potential customers

exports.generateHubLead = async (req, res) => {
  try {
    const properties = req.body;
    const { email } = properties;
    properties.hs_lead_status = "ATTEMPTED_TO_CONTACT";
    const checkHub = await checkHubspotExistance({ email });
    if (checkHub.exists) {
      try {
        await hubspotClient.crm.contacts.basicApi.update(checkHub.data.id, {
          properties: properties,
        });
      } catch (error) {
        console.error({ "error in create_hubspot_contact": { error } });
        throw new Error("Internal server error");
      }
    } else {
      try {
        await hubspotClient.crm.contacts.basicApi.create({
          properties: properties,
        });
      } catch (error) {
        console.error({ "error in create_hubspot_contact": { error } });
        throw new Error("Internal server error");
      }
    }
    return res.status(200).json({
      success: true,
      message: "Success adding hubspot contact !",
    });
  } catch (error) {
    handleErrors({
      req,
      res,
      error,
      message: "Error creating Hubspot contact",
    });
  }
};

// api -v3--- for production ------//
// update existing husbpot contact
exports.update_hubspot_contact_coach = async (req, res) => {
  try {
    const _id = req.coach._id;
    if (!mongoose.Types.ObjectId.isValid(_id)) {
      const error = new Error("Invalid request");
      error.status = 400;
      throw error;
    }
    const coachId = new mongoose.Types.ObjectId(_id);
    await updateHubData_coach({ coachId });
    return res.status(200).json({
      success: true,
      message: "Updated hubspot data successfully",
    });
  } catch (error) {
    handleErrors({ req, res, error });
  }
};

exports.update_hubspot_contact_coachee = async (req, res) => {
  try {
    const _id = req.user._id;
    if (!mongoose.Types.ObjectId.isValid(_id)) {
      const error = new Error("Invalid request");
      error.status = 400;
      throw error;
    }
    const coacheeId = new mongoose.Types.ObjectId(_id);
    await updateHubData_coachee({ coacheeId });
    return res
      .status(200)
      .json({ success: true, message: "Updated hubspot data successfully" });
  } catch (error) {
    handleErrors({ req, res, error });
  }
};

// api -v3--- for production ------// for modify or retriving the list of  the porperties names /
// internal names and the group names of the properties on the hubspot portal
exports.add_property_fields = async (req, res) => {
  try {
    const inputs = HUB_SPOT_FIELDS;
    // console.log({ inputs });
    // Send request to HubSpot API to create custom properties
    const response = await hubspotClient.crm.properties.batchApi.create(
      "contacts",
      { inputs }
    );
    console.log(
      "Custom properties created successfully (Number):",
      response.results.length
    );
    return res.status(200).json({
      message: "Custom properties created successfully!",
      data: response,
    });
  } catch (error) {
    console.log(error);
    handleErrors({ req, res, error });
  }
};

exports.listGruopAndProps = async (req, res) => {
  try {
    const object = req.params.object || "contacts";
    const [response, nextRes] = await Promise.all([
      hubspotClient.crm.properties.coreApi.getAll(object),
      hubspotClient.crm.properties.groupsApi.getAll(object),
    ]);
    const properties = response.results.map((property) => ({
      group: property.groupName,
      internal_name: property.name,
      label: property.label,
    }));
    return res.json({
      success: true,
      properties,
      groups: nextRes.results,
    });
  } catch (error) {
    console.error(
      "Error fetching properties from HubSpot:",
      error?.response?.message
    );
    handleErrors({
      req,
      res,
      error,
      message: "Error fetching properties from HubSpot",
    });
  }
};
