require("dotenv").config();
const CoachModel = require("../../models/coach");
const HUBSPOT_ACCESS_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
const hubspot = require("@hubspot/api-client");
const mongoose = require("mongoose");
const transportEmail = require("../../lib/email");
const {
  createBulkEntryRecord,
} = require("../../models/bulk_users_entry_Model");
const generateCsvFile = require("../../lib/generateCsvFile");
const { validateEmailForDB } = require("../../utils/emailDbValidation");
const hubspotClient = new hubspot.Client({
  accessToken: HUBSPOT_ACCESS_TOKEN,
});

const generateUniqueName = (firstName) => {
  const randomDigits = Math.floor(100 + Math.random() * 999);
  const timestamp = Date.now().toString();
  return `${firstName.slice(0, 3)}_${randomDigits}_cy_coach_${timestamp}`;
};
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

exports.syncCoachesFromHubspot = async (req, res) => {
  try {
    const { filter: f } = req.body;
    // console.log({ f });
    const failedEntries = [];
    const successfullEntries = [];
    let after = 0;
    let contacts = [];
    let hasMore = true;
    // let responses = [];
    try {
      const filter = {
        propertyName: "coach_status",
        operator: "EQ",
        value: f,
      };
      const filterGroup = { filters: [filter] };

      let properties = [
        "firstname",
        "lastname",
        "email",
        "phone",
        "coach_status",
        "languages_spoken_salesforce_", // languages
        "other_languages_", // languages
        "if_you_were_to_describe_your_professional_status_in_one_sentence__wha_wold_you_say_", // title line
        "what_is_your_coaching_specialty_",
        "years_of_working_experience", // experienceYearStr :string
        "working_experience_industries",
        "functions_experience", // industries
        "bio", // about me
        "focus_areas_genera`l",
        "other_industries",
        "other_functional_areas",
        "ip_country", // country
        "want_to_volunteer", //npo
        "ip_city", // city
        "what_sets_me_apart_as_a_coach__up_to_50_words_", // bio or about me
        "gender",
        "hs_linkedin_url",
      ];

      while (hasMore) {
        const publicObjectSearchRequest = {
          filterGroups: [filterGroup],
          properties,
          limit: 100,
          after,
        };

        const response = await hubspotClient.crm.contacts.searchApi.doSearch(
          publicObjectSearchRequest
        );
        // console.log({ response });
        const contactV = response.results;
        contacts.push(...contactV);
        // responses.push(response);

        // Check for more pages
        if (response.paging?.next?.after) {
          after = response.paging.next.after;
          await delay(350);
        } else {
          hasMore = false;
        }
      }

      if (contacts.length === 0) {
        return res.status(200).json({
          success: false,
          message: "No contacts found in the specified Hubspot list",
          data: {
            successfullEntries: 0,
            failedEntries: 0,
            successNumber: 0,
            failureNumber: 0,
            contactsFound: 0,
          },
        });
      }
      // this block is added for testing purposes only when there are results there are more things to happen
      // else {
      //   return res.status(200).json({
      //     success: true,
      //     message: "No contacts found in the specified Hubspot list",
      //     data: {
      //       successfullEntries: 0,
      //       failedEntries: 0,
      //       successNumber: 0,
      //       failureNumber: 0,
      //       contactsFound: contacts.length,
      //       contacts: contacts,
      //       responses: responses,
      //     },
      //   });
      // }
      for (const contact of contacts) {
        try {
          const p = contact.properties;
          // console.log({ p });
          const languages = [
            ...(p.languages_spoken_salesforce_?.split(/[;,]/) || []),
            ...(p.other_languages_?.split(/[;,]/) || []),
          ]
            .map((lang) => lang.trim())
            .filter(Boolean);

          const industries = [
            ...(p.working_experience_industries?.split(/[;,]/) || []),
            ...(p.other_industries?.split(/[;,]/) || []),
          ]
            .map((ind) => ind.trim())
            .filter(Boolean);

          const coachingSpecialities = [
            ...(p.functions_experience?.split(/[;,]/) || []),
            ...(p.focus_areas_general?.split(/[;,]/) || []),
            ...(p.other_functional_areas?.split(/[;,]/) || []),
          ]
            .map((s) => s.trim())
            .filter(Boolean);

          const newCoach = {
            email: p.email || "",
            firstName: p.firstname || "",
            lastName: p.lastname || "",
            phone: p.phone || "",
            languages,
            industries,
            coachingSpecialities,
            experienceYear: parseInt(p.years_of_working_experience, 10) || 0,
            nonProfitCoaching: p.want_to_volunteer === "yes",
            registrationType: "hubspot_sync",
            userName: generateUniqueName(p.firstname),
            name: p.firstname || "",
            Lname: p.lastname || "",
            title_line:
              p.if_you_were_to_describe_your_professional_status_in_one_sentence__wha_wold_you_say_ ||
              "",
            about_me:
              p.bio && p.bio !== ""
                ? p.bio
                : p.what_sets_me_apart_as_a_coach__up_to_50_words_ || "",
            // country: p.ip_country || "",
            // city: p.ip_city || "",
            linkedin_profile_link: p?.hs_linkedin_url ? p.hs_linkedin_url : "",
            hub_spot_id: contact.id,
            ...(p.gender && ["Male", "Female", "Other"].includes(p.gender)
              ? { gender: p.gender }
              : {}),
          };
          const avail = await validateEmailForDB(newCoach.email);
          if (avail) {
            // return res.send({ newCoach, p });
            const createdCoach = await CoachModel.create(newCoach);
            // console.log({ newCoach });
            if (newCoach) {
              successfullEntries.push({
                ...newCoach,
                id: createdCoach._id,
              });
            } else {
              failedEntries.push({
                ...newCoach,
                failureReason: "Database Error Occurred",
              });
            }
          } else {
            failedEntries.push({
              ...newCoach,
              failureReason: "Duplicate key error, Email already exists",
            });
          }
        } catch (error) {
          console.error(
            `Error processing contact ${contact.id} / ${contact?.properties?.email}:`,
            error.message
          );
          failedEntries.push({
            email: contact.properties?.email || "unknown",
            firstName: contact.properties?.firstname || "unknown",
            lastName: contact.properties?.lastname || "unknown",
            hubspotContactId: contact.id,
            failureReason: error.message,
          });
        }
      }
    } catch (hubspotError) {
      console.error("Error fetching contacts from Hubspot:", hubspotError);
      return res.status(500).json({
        success: false,
        message: "Error fetching contacts from Hubspot list",
      });
    }

    // // Send emails to successfully created coaches
    try {
      if (successfullEntries.length > 0) {
        await Promise.allSettled(
          successfullEntries.map((coach) =>
            transportEmail.createEmail({
              mailOptions: {
                from: "ConnectYou <itadmin@erickson.edu>",
                // to: [`blossom.reactdev02@gmail.com`],
                to: [coach.email],
                subject:
                  "Congratulations, ConnectYou Account registration was successfull!",
                template: "coachCreated",
                context: {
                  name: `${coach.firstName} ${coach.lastName}`,
                  email: coach.email,
                },
              },
            })
          )
        );
      }
    } catch (emailError) {
      console.error("Error sending emails:", emailError);
    }

    // Generate CSV files for successful and failed entries
    const timestamp = Date.now().toString();
    const successFile = successfullEntries.length
      ? await generateCsvFile(
          successfullEntries,
          `successfull_coach_entries_${timestamp}.csv`
        )
      : null;
    const failureFile = failedEntries.length
      ? await generateCsvFile(
          failedEntries,
          `failed_coach_entries_${timestamp}.csv`
        )
      : null;

    // Create record of the bulk operation
    await createBulkEntryRecord({
      dataSource: "HUBSPOT",
      entry_type: "Bulk_Coach_Entry",
      result:
        failedEntries.length === 0
          ? "Success"
          : successfullEntries.length > failedEntries.length
          ? "Partial Success"
          : "Failure",
      successFilepath: successFile,
      failureFilepath: failureFile,
      successCount: successfullEntries.length,
      failureCount: failedEntries.length,
      uploadedBy: req.admin?._id || "Unknown",
      // hub_list_ID: listID,
    });

    return res.status(200).json({
      success: true,
      message: "Coaches synced from Hubspot successfully.",
      data: {
        successfullEntries,
        failedEntries,
        successNumber: successfullEntries.length,
        failureNumber: failedEntries.length,
        contactsFound: contacts.length,
      },
      files: {
        success: successFile,
        failure: failureFile,
      },
    });
  } catch (error) {
    console.error("Error in syncCoachesFromHubspot API handler:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

// coach properties that can be accessed for use //
/**
 *@params properties: [
          "firstname",
          "lastname",
          "email",
          "phone",
          "coach_status",
          "languages_spoken_salesforce_",
          "other_languages_",
          "if_you_were_to_describe_your_professional_status_in_one_sentence__wha_wold_you_say_",
          "what_is_your_coaching_specialty_",
          "years_of_working_experience",
          "working_experience_industries",
          "functions_experience",
          "bio",
          "focus_areas_general",
          "ip_country",
          "ip_city",
          "what_sets_me_apart_as_a_coach__up_to_50_words_"
        ],
 */
