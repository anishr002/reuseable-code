const HUB_SPOT_FIELDS = [
  {
    name: "registered_as_coach",
    label: "Registered As a Coach",
    type: "enumeration",
    fieldType: "booleancheckbox",
    options: [
      { value: "true", label: "Yes" },
      { value: "false", label: "No" },
    ],
    description: "If the user is registered as a coach.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "languages",
    label: "Languages Preferred",
    type: "string",
    fieldType: "textarea",
    description: "Languages preferred by the coach.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "coaching_specialities",
    label: "Coaching Specialities",
    type: "string",
    fieldType: "textarea",
    description: "Coaching Specialities.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "coaching_certifications",
    label: "Coaching Certifications",
    type: "string",
    fieldType: "textarea",
    description: "Coaching certificates.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "coaching_experience",
    label: "Coaching Experience",
    type: "string",
    fieldType: "textarea",
    description: "Years of Experience.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "years_of_experience",
    label: "Years of Coaching Experience",
    type: "string",
    fieldType: "textarea",
    description: "Years of Experience.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "npo_coach",
    label: "NPO Coach",
    type: "enumeration",
    fieldType: "booleancheckbox",
    options: [
      { value: "true", label: "Yes" },
      { value: "false", label: "No" },
    ],
    description: "If the coach is involved in NPO coaching.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "b2b_coach",
    label: "B2B Coach",
    type: "string",
    fieldType: "textarea",
    description: "If the coach is involved in B2B coaching.",
    groupName: "connectyou_coach_info",
  },
  {
    name: "full_address",
    label: "Full Address",
    type: "string",
    fieldType: "textarea",
    description: "Full address of the coach",
    groupName: "connectyou_coach_info",
  },
  {
    name: "b2b_training",
    label: "B2B Training",
    type: "enumeration",
    fieldType: "booleancheckbox",
    options: [
      { value: "true", label: "Yes" },
      { value: "false", label: "No" },
    ],
    description: "If the coach provides B2B training.",
    groupName: "connectyou_coachee_info",
  },
  {
    name: "npo_training",
    label: "NPO Training",
    type: "enumeration",
    fieldType: "booleancheckbox",
    options: [
      { value: "true", label: "Yes" },
      { value: "false", label: "No" },
    ],
    description: "If the coach provides NPO training.",
    groupName: "connectyou_coachee_info",
  },
  {
    name: "areas_of_interest",
    label: "Areas of Interest",
    type: "string",
    fieldType: "textarea",
    description: "Areas of interest selected by the user.",
    groupName: "connectyou_coachee_info",
  },
  {
    name: "is_connectyou_coachee",
    label: "Is ConnectYou Coachee",
    type: "enumeration",
    fieldType: "booleancheckbox",
    options: [
      { value: "true", label: "Yes" },
      { value: "false", label: "No" },
    ],
    description: "If the user is a ConnectYou coachee.",
    groupName: "connectyou_coachee_info",
  },
];
module.exports = HUB_SPOT_FIELDS;


/* 

    type: "enumeration",
    fieldType: "booleancheckbox", - for 2 option, 
    fieldType: "checkbox", - for more than 2 option, 
    


*/