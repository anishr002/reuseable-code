const mongoose = require("mongoose");
require("dotenv").config();
const hubspot = require("@hubspot/api-client");
const HUBSPOT_ACCESS_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
const hubspotClient = new hubspot.Client({
  accessToken: HUBSPOT_ACCESS_TOKEN,
});
const CoachModel = require("../../models/coach");
const userModel = require("../../models/user");

const checkHubspotExistance = async ({ email }) => {
  try {
    const searchBody = {
      filterGroups: [
        {
          filters: [
            {
              propertyName: "email",
              operator: "EQ",
              value: email,
            },
          ],
        },
      ],
      properties: ["email", "firstname", "lastname"],
      limit: 1,
    };
    try {
      const response = await hubspotClient.crm.contacts.searchApi.doSearch(
        searchBody
      );
      // console.log({ response: response.results });
      if (response.results && response.results.length > 0) {
        return {
          exists: true,
          data: response.results[0],
        };
      }
      return {
        exists: false,
        data: null,
      };
    } catch (error) {
      console.error("Error searching contact on hubspot", { error });
      throw new Error(
        "Hubspot APIs not responding, Unable to retrive hubspot data"
      );
    }
  } catch (error) {
    console.error("Error in checkHubspotExistance:", error.message);
    throw error;
  }
};

const updateHubData_coach = async ({ coachId }) => {
  try {
    const coach = await CoachModel.aggregate([
      {
        $match: {
          _id: coachId,
        },
      },
      {
        $lookup: {
          from: "coachexperiences",
          localField: "_id",
          foreignField: "coachId",
          as: "coach_work_experience",
          pipeline: [
            {
              $project: {
                organization: 1,
                position: 1,
                startDate: 1,
                endDate: 1,
                workingOn: 1,
                createdAt: 1,
              },
            },
            {
              $sort: {
                createdAt: -1,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coach_certificates",
          pipeline: [
            {
              $project: {
                title: 1,
                createdAt: 1,
              },
            },
            {
              $sort: {
                createdAt: -1,
              },
            },
          ],
        },
      },
      {
        $project: {
          _id: 1,
          email: 1,
          name: 1,
          Lname: 1,
          gender: 1,
          DOB: 1,
          city: 1,
          country: 1,
          fullAddress: 1,
          languages: 1,
          coachingSpecialities: 1,
          experienceYear: 1,
          nonProfitCoaching: 1,
          hub_spot_id: 1,
          coach_work_experience: 1,
          coach_certificates: 1,
        },
      },
    ]);
    // console.log({ coach });
    if (!coach || coach.length === 0) {
      const error = new Error("Entity Data not found");
      error.status = 404;
      throw error;
    }
    const exitsOnHub = await checkHubspotExistance({ email: coach[0].email });
    // console.log({ exitsOnHub });

    const certificationString = coach[0].coach_certificates
      ?.map((item) => item.title)
      ?.join(", ");
    const formatDate = (date) => {
      if (!date) return "Present";
      const options = { year: "numeric", month: "short" };
      return new Date(date).toLocaleDateString(undefined, options);
    };
    const experienceString = coach[0].coach_work_experience
      ?.map((item) => {
        const startDate = formatDate(item.startDate);
        const endDate =
          item.workingOn === "true" ? "Present" : formatDate(item.endDate);
        return `${item.organization} as ${item.position} (${startDate} - ${endDate})`;
      })
      ?.join(", ");

    const hubData = {
      email: coach[0].email,
      firstname: coach[0].name,
      lastname: coach[0].Lname,
      gender: coach[0].gender,
      date_of_birth: coach[0].DOB,
      city: coach[0].city,
      country: coach[0].country,
      // full_address: coach[0].fullAddress,
      languages: coach[0].languages?.join(", "),
      coaching_specialities: coach[0].coachingSpecialities?.join(", "),
      years_of_experience: coach[0].experienceYear,
      npo_coach: coach[0].nonProfitCoaching,
      coaching_certifications: certificationString,
      coaching_experience: experienceString,
      npo_training: false,
      registered_as_coach: true,
      is_connectyou_coachee: false,
      // b2b_coach : " string ",  //TBA
    };
    //!exitsOnHub.exists === dont exists
    let response;
    let hubspotId;
    if (exitsOnHub.exists === false) {
      try {
        const res = await hubspotClient.crm.contacts.basicApi.create({
          properties: hubData,
        });
        hubspotId = res.id;
        response = res;
      } catch (error) {
        console.error("Error in updateHubData_coach", {
          error: error,
        });
        throw new Error(
          "Hubspot APIs not responsding , error updating hubspot data "
        );
      }
    } else {
      try {
        const res = await hubspotClient.crm.contacts.basicApi.update(
          exitsOnHub.data.id,
          {
            properties: hubData,
          }
        );
        hubspotId = res.id;
        response = res;
      } catch (error) {
        console.error("Error in updateHubData_coach", {
          error: error,
        });
        throw new Error(
          "Hubspot APIs not responsding , error updating hubspot data "
        );
      }
    }
    await CoachModel.updateOne(
      {
        _id: coachId,
      },
      {
        $set: {
          hub_spot_id: hubspotId,
        },
      }
    );
    return response;
  } catch (error) {
    console.error("Error in updateHubData_coach:", error.message);
  }
};

const updateHubData_coachee = async ({ coacheeId }) => {
  try {
    const coachee = await userModel.find({
      _id: coacheeId,
    });
    if (coachee.length === 0) {
      const error = new Error("Entity Data not found");
      error.status = 404;
      throw error;
    }
    // console.log({ coachee: coachee[0] });
    const exitsOnHub = await checkHubspotExistance({ email: coachee[0].email });

    const hubspotData = {
      firstname: coachee[0].name,
      email: coachee[0].email,
      gender: coachee[0].gender,
      date_of_birth: coachee[0].DOB,
      city: coachee[0].city,
      country: coachee[0].country,
      // full_address: coachee[0].fullAddress,
      areas_of_interest: coachee[0].areas_of_interest?.join(", "),
      npo_coach: false,
      registered_as_coach: false,
      is_connectyou_coachee: true,
      // npo_training : boolean // TBA
      // b2b_training : boolean // TBA
    };
    let response;
    let hubSpotId;

    if (!exitsOnHub.exists) {
      try {
        const responseD = await hubspotClient.crm.contacts.basicApi.create({
          properties: hubspotData,
        });
        hubSpotId = responseD.id;
      } catch (error) {
        console.error("Error in updateHubData_coachee", {
          error: error,
        });
        throw new Error(
          "Hubspot APIs not responding, error updating hubspot data "
        );
      }
    } else {
      try {
        response = await hubspotClient.crm.contacts.basicApi.update(
          exitsOnHub.data.id,
          {
            properties: hubspotData,
          }
        );
        hubSpotId = exitsOnHub.data.id;
      } catch (error) {
        // console.error("Error in updateHubData_coachee", {
        //   error: error.message,
        // });
        throw new Error(
          "Hubspot APIs not responding, error updating hubspot data "
        );
      }
    }
    await userModel.updateOne(
      { _id: coacheeId },
      { $set: { hub_spot_id: hubSpotId } }
    );
    return response;
  } catch (error) {
    console.error("Error in updateHubData_coachee:", error.message);
    throw new Error("Error updating hubspot contact");
  }
};

module.exports = {
  checkHubspotExistance,
  updateHubData_coach,
  updateHubData_coachee,
};
