const { validationResult } = require("express-validator");
require("dotenv").config();
const moment = require("moment-timezone");
//environment variables
const Stripe = require("stripe");
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const cartModel = require("../../../models/cart");
const bookingModal = require("../../../models/booking");
const bookedSessionModal = require("../../../models/booked_session");
const { saveTimelineEntry } = require("../../../models/bookedSessionTimeLine");

exports.create = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    const items = req.body.items;
    if (!Array.isArray(items)) {
      return res
        .status(401)
        .json({ success: false, message: "Provide at least one session" });
    }
    const productArray = items.map((p) => {
      return {
        price: p.stripePriceId,
        quantity: 1,
      };
    });
    const coachIds = [...new Set(items.map((p) => p.coachId))];
    let booking = await new bookingModal({
      userId: userId,
      coachId: coachIds,
      // currency: "usd",
    }).save();

    const bookingArray = items.map((p) => {
      return {
        cartId: p.cartId,
        bookingId: booking._id,
        userId: userId,
        coachId: p.coachId,
        coachTimeZone: p.coachTimeZone,
        sessionId: p.sessionId,
        amount: p.amount,
        sessionType: p.sessionType,
        sessionDate: p.sessionDate,
        sessionDateUpdated: p.sessionDate,
      };
    });

    const insertedSessions = await bookedSessionModal.insertMany(bookingArray);
    insertedSessions.map((session) => {
      saveTimelineEntry({
        bookedSessionId: session._id,
        bookingId: booking._id,
        action: "Session Booked",
        message: `Coaching session was booked by coachee.`,
        actionBy: "Coachee",
      });
    });
    try {
      const session = await stripe.checkout.sessions.create({
        line_items: productArray,
        mode: "payment",

        success_url: `${process.env.FRONTEND_URL_web}/u/bookings`,
        cancel_url: `${process.env.FRONTEND_URL_web}/cart`,
        payment_method_types: ["card"],
        metadata: {
          bookingId: booking._id.toString(),
          userId: userId.toString(),
          sessionCount: bookingArray.length.toString(),
        },
        payment_intent_data: {
          metadata: {
            bookingId: booking._id.toString(), // Available in charge.succeeded
            userId: userId.toString(),
            sessionCount: bookingArray.length.toString(),
          },
        },
      });
      const response = {
        success: true,
        paymentLink: session.url,
        message: "session url created successfully",
      };
      return res.status(200).json(response);
    } catch (error) {
      console.log({ "Error while creating payment link for stripe ": error });
      return res
        .status(500)
        .json({ success: false, message: "Server error", error: error });
    }
  } catch (err) {
    console.log(err);
    //Server error
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
