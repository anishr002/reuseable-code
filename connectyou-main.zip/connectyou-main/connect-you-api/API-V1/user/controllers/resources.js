const resourceModel = require("../../../models/resources");
const { validationResult } = require("express-validator");
const mongoose = require("mongoose");

exports.ListResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let data = await resourceModel.find({
      $or: [{ availableFor: "coachee" }, { availableFor: "all" }],
    });
    return res.status(200).json({
      success: true,
      data,
      message: "Coachee resources list get successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.DetailsResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let id = req.params.id;
    let data = await resourceModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(id),
          $or: [{ availableFor: "coachee" }, { availableFor: "all" }],
        },
      },
      {
        $lookup: {
          from: "resources_modules",
          localField: "_id",
          foreignField: "resourceId",
          as: "modules",
        },
      },
    ]);
    return res.status(200).json({
      success: true,
      data: data[0],
      message: "Coachee resources list get successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
