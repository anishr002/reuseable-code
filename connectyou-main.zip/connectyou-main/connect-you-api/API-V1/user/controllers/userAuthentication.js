const { validationResult } = require("express-validator");
const moment = require("moment-timezone");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const mongoose = require("mongoose");
require("dotenv").config();
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const userModel = require("../../../models/user");
const path = require("path");
const FailedLoginModal = require("../../../models/failedLoginAttempts");
const {
  CreateNotification,
  CreateForgetPasswordReqNotification,
  CreatePasswordResetNotification,
  CreateUserLoginNotification,
  CreateWelcomeNotification,
  CreateAdminLevelNotification,
  WaringLoginNotification,
} = require("../../../models/notificationModal");

const transportEmail = require("../../../lib/email");
const { passwordRecoveryUpdateEmail } = require("../../../utils/quickEmails");

//register new user
exports.register = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { name, email, password, userName, timezone, lastName } = req.body;
    const bcryptPassword = await bcrypt.hash(password, 10);
    const saveData = await new userModel({
      name,
      email,
      lastName,
      password: bcryptPassword,
      userName,
      timeZone: timezone,
      my_invitation_code: new Date(),
    }).save();
    let data = {
      _id: saveData._id,
      name: saveData.name,
      email: saveData.email,
      gender: saveData.gender,
      DOB: saveData.DOB,
      userType: "coachee",
      createdAt: saveData.createdAt,
      image: saveData.image,
      userName: saveData.userName,
      emailVerified: saveData.emailVerified,
      timeZone: saveData.timeZone,
    };
    const authToken = await jwt.sign(data, JWT_SECRET);
    data.token = authToken;
    const responce = {
      success: true,
      data,
      message: "User register successfully",
    };
    function capitalizeFirstLetter(str) {
      if (!str) return "";
      return str.charAt(0).toUpperCase() + str.slice(1);
    }
    const capitalizedUserName = capitalizeFirstLetter(saveData.name);
    const mailOptions = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: saveData.email,
      subject: "Welcome to Coach Marketplace!",
      template: "welcomeUser",
      context: {
        name: `${capitalizedUserName} ${saveData.lastName}`,
        email: saveData.email,
      },
    };
    Promise.all([
      transportEmail.createEmail({ mailOptions }),
      CreateWelcomeNotification({ user_id: data._id }),
      CreateAdminLevelNotification({
        heading: `${saveData.name} have just signed up on the Portal !`,
        description: `A new user have signed up on the portal, check details by clicking on the view button.`,
        url: `/coachee/detail/${data._id}`,
        notification_type: "promotion",
      }),
    ]);
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    // Mongoose validation error
    if (err.name === "ValidationError") {
      const firstErrorField = Object.keys(err.errors)[0];
      const errorMessage = err.errors[firstErrorField].message;
      return res.status(400).json({ success: false, message: errorMessage });
    }
    // Mongoose validation error
    // Duplicate key error (e.g., unique constraint)
    if (err.code === 11000 && err.keyPattern && err.keyValue) {
      const duplicateField = Object.keys(err.keyPattern)[0];
      const duplicateValue = err.keyValue[duplicateField];

      let errorMessage = `Duplicate key error: ${duplicateField} '${duplicateValue}' already exists.`;
      return res.status(400).json({ success: false, message: errorMessage });
    }
    //Server error
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//login user
exports.login = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, password, location } = req.body;

    const userData = await userModel.find({
      $or: [{ email: email }, { userName: email }],
    });
    if (userData.length > 0) {
      const allowLogin = await CheckFailedLoginStatus(
        userData[0]._id,
        location,
        userData[0]
      );
      if (allowLogin.success === false) {
        await addFailedLoginAttempt(userData[0]._id);
        return res.status(403).json(allowLogin.responce);
      }
      const bcryptData = await bcrypt.compare(password, userData[0].password);
      if (!bcryptData) {
        await addFailedLoginAttempt(userData[0]._id);
        return res
          .status(401)
          .json({ success: false, message: "Invalid credentials" });
      }
      if (userData[0].block == 1) {
        const responce = { success: false, message: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (userData[0].delete == 1 || userData[0].deleteReq != 0) {
        const responce = { success: false, message: "Invalid credentials" };
        return res.status(403).json(responce);
      }

      let data = {
        _id: userData[0]._id,
        name: userData[0].name,
        email: userData[0].email,
        gender: userData[0].gender,
        DOB: userData[0].DOB,
        userType: "coachee",
        createdAt: userData[0].createdAt,
        userName: userData[0].userName,
        image: userData[0].image,
        emailVerified: userData[0].emailVerified,
        timeZone: userData[0].timeZone,
      };
      const authToken = await jwt.sign(data, JWT_SECRET);
      data.token = authToken;
      const responce = {
        success: true,
        data,
        message: "User login successfully",
      };
      await Promise.all([
        ClearLoginFailureRecord(userData[0]._id),
        CreateUserLoginNotification({ user_id: userData[0]._id }),
      ]);
      return res.status(200).json(responce);
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Password reset process start
//send email on given mail for password reset process
exports.sendEmail_passwordReset = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, timezone } = req.body;
    const userData = await userModel.find({ email });
    if (userData.length > 0) {
      if (userData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      const otp = Math.floor(10000 + Math.random() * 90000);
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: email,
        subject: "Forgot Password",
        template: "send-otp-forget-password",
        context: {
          name: `${userData[0].name} ${userData[0].lastName}`,
          email: userData[0].email,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        console.log({ error });
        const responce = {
          success: false,
          message: "Something went wrong",
        };
        return res.status(500).json(responce);
      } else {
        const currentDate = moment().tz(timezone).format("YYYY-MM-DD HH:mm:ss");
        const otpExpiry = moment(currentDate)
          .add(5, "minutes")
          .format("YYYY-MM-DD HH:mm:ss");

        await userModel.findByIdAndUpdate(
          { _id: userData[0]._id },
          {
            $set: {
              otp: otp,
              otpType: "password-reset-process",
              otpDate: otpExpiry,
            },
          }
        );
        const responce = {
          success: true,
          message: "Email send successfully",
        };
        return res.status(200).json(responce);
      }
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for password reset process
exports.OTPverification_passwordReset = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, timezone, otp, password } = req.body;

    const [userData, verifyType] = await Promise.all([
      userModel.find({ email }),
      userModel.find({ otp, otpType: "password-reset-process" }),
    ]);
    if (userData.length > 0) {
      if (userData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }

      if (otp != userData[0].otp) {
        const responce = { success: false, error: "otp not matched" };
        return res.status(403).json(responce);
      }
      const isOtpExpired = moment().isAfter(userData[0].otpDate);
      if (isOtpExpired) {
        const responce = {
          success: false,
          message: "OTP verification maximum time exceeded",
        };
        return res.status(401).json(responce);
      }
      if (verifyType.length == 0) {
        const responce = {
          success: false,
          message: "Something went wrong try again after some time",
        };
        return res.status(401).json(responce);
      }
      const bcryptPassword = await bcrypt.hash(password, 10);

      await userModel.findByIdAndUpdate(
        { _id: userData[0]._id },
        {
          $set: {
            password: bcryptPassword,
            emailVerified: 1,
            otp: 0,
            otpType: "",
            otpDate: "",
          },
        }
      );
      const responce = {
        success: true,
        message: "Your password updated successfully",
      };
      return res.status(200).json(responce);
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//forgot Password process start
//send email on given mail for password reset process
exports.forgotPasswordSendEmail = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, timezone } = req.body;
    const coachData = await userModel.find({ email });
    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }

      if (coachData[0].delete == 1) {
        const responce = { success: false, error: "Your account is deleted" };
        return res.status(403).json(responce);
      }

      const otp = Math.floor(10000 + Math.random() * 90000);

      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: email,
        subject: "Forgot Password",
        template: "send-otp-forget-password",
        context: {
          name: `${coachData[0].name} ${coachData[0].lastName}`,
          email: coachData[0].email,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        console.log({ error });
        const responce = {
          success: false,
          message: "Something went wrong",
        };
        return res.status(500).json(responce);
      } else {
        const currentDate = moment().tz(timezone).format("YYYY-MM-DD HH:mm:ss");
        const otpExpiry = moment(currentDate)
          .add(5, "minutes")
          .format("YYYY-MM-DD HH:mm:ss");

        await userModel.findByIdAndUpdate(
          { _id: coachData[0]._id },
          {
            $set: {
              otp: otp,
              otpType: "password-forgot-process",
              otpDate: otpExpiry,
            },
          }
        );
        const responce = {
          success: true,
          message: "Email send successfully",
        };
        await CreateForgetPasswordReqNotification({
          user_id: coachData[0]._id,
        });
        return res.status(200).json(responce);
      }
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for password reset process
exports.forgotPasswordOTPverification = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, otp } = req.body;

    const [coachData, verifyType] = await Promise.all([
      userModel.find({ email }),
      userModel.find({ otp, otpType: "password-forgot-process" }),
    ]);

    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, message: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (coachData[0].delete == 1) {
        const responce = { success: false, message: "Your account is deleted" };
        return res.status(403).json(responce);
      }

      if (otp != coachData[0].otp) {
        const responce = { success: false, message: "otp not matched" };
        return res.status(403).json(responce);
      }
      const isOtpExpired = moment().isAfter(coachData[0].otpDate);
      if (isOtpExpired) {
        const responce = {
          success: false,
          message: "OTP verification maximum time exceeded",
        };
        return res.status(401).json(responce);
      }
      // console.log({ verifyType });
      if (verifyType.length == 0) {
        const responce = {
          success: false,
          message: "Something went wrong try again after some time",
        };
        return res.status(401).json(responce);
      }
      await userModel.findByIdAndUpdate(
        { _id: coachData[0]._id },
        {
          $set: {
            emailVerified: 1,
            otp: 0,
            otpType: "",
            otpDate: "",
          },
        }
      );
      const responce = {
        success: true,
        message: "Your otp verified successfully",
      };
      return res.status(200).json(responce);
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for password reset process
exports.forgotPasswordNewPassword = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, password } = req.body;

    const [coachData] = await Promise.all([userModel.find({ email })]);

    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (coachData[0].delete == 1) {
        const responce = { success: false, error: "Your account is deleted" };
        return res.status(403).json(responce);
      }
      const bcryptPassword = await bcrypt.hash(password, 10);
      await userModel.findByIdAndUpdate(
        { _id: coachData[0]._id },
        {
          $set: {
            password: bcryptPassword,
          },
        }
      );
      const responce = {
        success: true,
        message: "Your password updated successfully",
      };
      res.status(200).json(responce);
      await Promise.all([
        ClearLoginFailureRecord(coachData[0]._id),
        CreatePasswordResetNotification({ user_id: coachData[0]._id }),
      ]);
      await passwordRecoveryUpdateEmail(
        `${coachData[0].name} ${coachData[0].lastName}`,
        coachData[0].email
      );
      return;
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const CheckFailedLoginStatus = async (id, location, User) => {
  const user = await FailedLoginModal.findOne({ user_id: id });
  if (!user) return { success: true, response: null };
  if (user.failedAttempts.length >= 2) {
    await sendWarningEmail(User.name, location, User.email);
  }
  if (user.failedAttempts.length >= 2) {
    await CreateNotification({
      user_id: id,
      heading: "There was an failed login attempt to your account.",
      description: `There was a failed login attempt for your account at ${new Date().toLocaleDateString()}, If this was not you Please Contact us and report this to maintin security of your account.`,
      url: `/get-in-touch`,
      notification_type: "authentication",
    });
  }
  if (user.failedAttempts.length >= 4) {
    const responce = {
      success: false,
      message:
        "Too Many  Failed Login Attempts, your account has been blocked for 1 hour.",
    };
    return { success: false, responce };
  } else return { success: true, response: null };
};

const addFailedLoginAttempt = async (id) => {
  try {
    const user = await FailedLoginModal.findOneAndUpdate(
      { user_id: id }, // Search by user ID
      {
        $push: { failedAttempts: new Date().toString() }, // Push a string (current date)
      },
      {
        new: true, // Return the updated document
        upsert: true, // If no document is found, create a new one
      }
    );
    // Optionally return the updated user document

    return user;
  } catch (error) {
    throw new Error("Failed to update failed login attempts");
  }
};
const sendWarningEmail = async (name, location, email) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: "Suspisious Login Attempts",
    template: "securitywarning",
    context: {
      name: name,
      email: email,
      type: "user",
      location: location,
    },
  };
  await transportEmail.createEmail({ mailOptions });
};

const ClearLoginFailureRecord = async (id) => {
  try {
    const user = await FailedLoginModal.deleteOne({ user_id: id });
    return;
  } catch (error) {
    console.log(error);
  }
};

exports.ping = async (req, res) => {
  try {
    return res
      .status(200)
      .json({ success: true, message: "Server connection successfull" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
