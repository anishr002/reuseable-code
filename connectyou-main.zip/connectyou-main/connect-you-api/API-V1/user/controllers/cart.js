const { validationResult } = require("express-validator");
require("dotenv").config();
const moment = require("moment-timezone");
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const cartModel = require("../../../models/cart");
const mongoose = require("mongoose");
const bookingModal = require("../../../models/booked_session");
const bookingModel = require("../../../models/booking");
const coachSessionModel = require("../../../models/coachSession");
//add rating on order

function checkPurchaseBlocked(
  sessionDate,
  timeZone,
  UserBookingList,
  cartDetailsList
) {
  // Convert sessionDate to UTC
  const sessionDateUTC = moment
    .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
    .utc();

  // console.log(
  //   "sessionDateUTC",
  //   sessionDateUTC.toISOString(),
  //   "sessionDate",
  //   sessionDate
  // );

  // Helper function to check for overlapping dates
  const isWithin24Hours = (dateToCompare) => {
    const bookingDateUTC = moment(dateToCompare);
    const hoursDifference = Math.abs(
      sessionDateUTC.diff(bookingDateUTC, "hours")
    );
    // console.log(
    //   "Comparing with:",
    //   bookingDateUTC.toISOString(),
    //   "hoursDifference:",
    //   hoursDifference
    // );
    return hoursDifference <= 23;
  };
  const isWithinanHours = (dateToCompare) => {
    const bookingDateUTC = moment(dateToCompare);
    const hoursDifference = Math.abs(
      sessionDateUTC.diff(bookingDateUTC, "hours")
    );
    // console.log(
    //   "Comparing with:",
    //   bookingDateUTC.toISOString(),
    //   "hoursDifference:",
    //   hoursDifference
    // );
    return hoursDifference <= 1;
  };

  // Check both arrays
  const haveBooking = UserBookingList.some((booking) =>
    isWithin24Hours(booking.sessionDateUpdated)
  );
  const haveCart = cartDetailsList.some((cart) =>
    isWithinanHours(cart.sessionDate)
  );
  const isBlocked = haveBooking || haveCart;

  // console.log("Purchase Blocked:", isBlocked);
  let haveDataIn = null;
  if (haveBooking && haveCart) {
    haveDataIn = "both Booking & Cart"; // Conflict in both Booking and Cart
  } else if (haveBooking) {
    haveDataIn = "Booking";
  } else if (haveCart) {
    haveDataIn = "Cart";
  }
  return {
    purchaseBlocked: isBlocked,
    haveDataIn,
  };
}

async function checkUserFreeSessionExxhausted({
  userId,
  coachId,
  sessionId,
  cartId,
}) {
  try {
    const [sessionType, bookingsData, cartData] = await Promise.all([
      coachSessionModel
        .findById({ _id: new mongoose.Types.ObjectId(sessionId) })
        .select("-_id type"),
      bookingModel.aggregate([
        {
          $match: {
            userId: new mongoose.Types.ObjectId(userId),
            // coachId: new mongoose.Types.ObjectId(coachId),// commented so only 3 with all coaches, other wise with a particular coach
            paid: 1,
          },
        },
        {
          $lookup: {
            from: "booked_sessions",
            localField: "_id",
            foreignField: "bookingId",
            as: "confirmed_sessions",
          },
        },

        {
          $unwind: "$confirmed_sessions",
        },
        {
          $match: {
            "confirmed_sessions.sessionType": "1",
            "confirmed_sessions.sessionStatus": { $ne: 2 },
          },
        },

        {
          $group: {
            _id: null,
            totalBookings: { $sum: 1 },
          },
        },
      ]),
      cartModel.aggregate([
        {
          $match: {
            $or: [
              { cartId: cartId },
              { userId: new mongoose.Types.ObjectId(userId) },
            ],
            // coachId: new mongoose.Types.ObjectId(coachId), //commented so only 3 with all coaches, other wise with a particular coach
            expired: false,
          },
        },
        {
          $lookup: {
            from: "coachsessions",
            localField: "sessionId",
            foreignField: "_id",
            as: "sessions",
          },
        },
        { $unwind: "$sessions" },
        {
          $match: {
            "sessions.type": 1,
          },
        },
        {
          $group: {
            _id: null,
            totalItems: { $sum: 1 },
          },
        },
      ]),
    ]);

    // Extract the count
    const totalBookings =
      (bookingsData.length > 0 ? bookingsData[0].totalBookings : 0) +
        (cartData.length > 0 ? cartData[0].totalItems : 0) || 0;

    if (sessionType.type === 1) {
      if (totalBookings >= 3) {
        return true;
      } else return false;
    } else return false;
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
}

exports.addSession = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { coachId, sessionId, sessionDate, timeZone, cartId, userId } =
      req.body;
    const blockFree = await checkUserFreeSessionExxhausted({
      userId,
      coachId,
      sessionId,
    });

    if (blockFree) {
      return res.status(403).json({
        success: false,
        message: `Only 3 Free sessions can be booked for the same coach.`,
      });
    }
    let sessionDateUTC = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .utc()
      .toDate();
    const cartDetailsList = await cartModel.find({ userId });
    let match = { userId, sessionStatus: 0, coachId };
    const UserBookingList = await bookingModal.find(match);
    // const check = checkPurchaseBlocked(
    //   sessionDateUTC,
    //   timeZone,
    //   UserBookingList,
    //   cartDetailsList
    // );
    // // have added this validation on 26-12- to prevent user from booking a  session within 24 hours or already booked session / and cart
    // if (check.purchaseBlocked) {
    //   return res.status(403).json({
    //     success: false,
    //     data: null,
    //     message: `You have already a Session in ${check.haveDataIn} that the same time slot, Please select another date and try again`,
    //   });
    // } else {
    await new cartModel({
      userId,
      cartId,
      coachId,
      sessionId,
      sessionDate: sessionDateUTC,
    }).save();

    const responce = {
      success: true,
      message: "session added successfully",
    };
    return res.status(200).json(responce);
    // }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.listSession = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { cartId, userId } = req.body;
    const matchConditions = {
      expired: false,
    };
    const orConditions = [];
    if (cartId && cartId !== "") {
      orConditions.push({ cartId: cartId });
    }
    if (userId && mongoose.Types.ObjectId.isValid(userId)) {
      orConditions.push({ userId: new mongoose.Types.ObjectId(userId) });
    }
    matchConditions.$or = orConditions;

    const cartList = await cartModel.aggregate([
      {
        $match: matchConditions,
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          coachId: 1,
          sessionId: 1,
          sessionDate: 1,
          coachData: {
            _id: "$coachData._id",
            name: "$coachData.name",
            Lname: "$coachData.Lname",
            userName: "$coachData.userName",
            gender: "$coachData.gender",
            image: "$coachData.image",
            timeZone: "$coachData.timeZone",
          },
          sessionData: {
            _id: "$sessionData._id",
            title: "$sessionData.title",
            price: "$sessionData.price",
            type: "$sessionData.type",
            description: "$sessionData.description",
            stripePriceId: "$sessionData.stripePriceId",
            currency: "$sessionData.currency.currency",
            currencySymbol: "$sessionData.currency.symbol",
          },
        },
      },
    ]);
    const responce = {
      success: true,
      data: cartList,
      message: "session list get successfully",
    };

    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.removeSession = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const sessionId = req.params.id;
    await cartModel.findByIdAndDelete(sessionId);
    const responce = {
      success: true,
      message: "session removed successfully",
    };

    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach booked date and time
exports.cartDate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(401).json(responce);
  }
  try {
    const { sessionDate, cartId, userId, timeZone, coachId } = req.body;
    const startOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .startOf("day")
      .utc()
      .toDate();
    const endOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .endOf("day")
      .utc()
      .toDate();

    let userIdOPT = userId ? new mongoose.Types.ObjectId(userId) : null;
    const twentyMinutesAgo = new Date(Date.now() - 20 * 60 * 1000);

    let aggregateData = [
      {
        $match: {
          $and: [
            { sessionDate: { $gte: startOfDay, $lt: endOfDay } },
            { expired: false },
            {
              $or: [
                {
                  $or: [
                    { cartId: cartId },
                    ...(userIdOPT ? [{ userId: userIdOPT }] : []),
                  ],
                },
                {
                  $and: [
                    { createdAt: { $gte: twentyMinutesAgo } },
                    { coachId: new mongoose.Types.ObjectId(coachId) },
                  ],
                },
              ],
            },
          ],
        },
      },
      {
        $project: {
          _id: 0,
          sessionDate: 1,
        },
      },
    ];

    const data = await cartModel.aggregate(aggregateData);
    const bookedDate = data.map((entry) => ({
      from: entry.sessionDate,
      to: moment(entry.sessionDate).add(1, "hour").toISOString(),
    }));

    const responce = {
      success: true,
      data: bookedDate,
      message: "coach details retrieved successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.DisabledcartDateForCoach = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(401).json(responce);
  }
  try {
    const { sessionDate, cartId, userId, timeZone, coachId } = req.body;
    const startOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .subtract(1, "days")
      .startOf("day")
      .utc()
      .toDate();
    const endOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .add(1, "days")
      .endOf("day")
      .utc()
      .toDate();

    let userIdOPT = userId ? new mongoose.Types.ObjectId(userId) : null;
    const twentyMinutesAgo = new Date(Date.now() - 20 * 60 * 1000);
    const selectedDate = moment(sessionDate, "DD-MM-YYYY").format("DD-MM-YYYY");

    let aggregateData = [
      {
        $match: {
          $and: [
            { coachId: new mongoose.Types.ObjectId(coachId) },
            { sessionDate: { $gte: startOfDay, $lt: endOfDay } },
            { expired: false },
            {
              $or: [
                {
                  $or: [
                    { cartId: cartId },
                    ...(userIdOPT ? [{ userId: userIdOPT }] : []),
                  ],
                },
                {
                  $and: [{ createdAt: { $gte: twentyMinutesAgo } }],
                },
              ],
            },
          ],
        },
      },
      {
        $project: {
          _id: 0,
          sessionDate: 1,
        },
      },
    ];

    const data = await cartModel.aggregate(aggregateData);
    // console.log(data);
    // console.log(sessionDate);
    const bookedDate = data.flatMap((entry) => {
      const baseDate = moment(entry.sessionDate).tz(timeZone); // Ensure baseDate is in the correct time zone
      const selectedMoment = moment.tz(selectedDate, "DD-MM-YYYY", timeZone); // Parse selectedDate directly in the time zone

      let direction;
      const timeRanges = [];
      const currentHour = baseDate; // Extract the hour part of baseDate

      // console.log("baseDate", baseDate, "selectedMoment", selectedMoment);
      if (selectedMoment.isBefore(baseDate, "day")) {
        // console.log("running block 1");
        direction = "negative";
      } else if (selectedMoment.isAfter(baseDate, "day")) {
        // console.log("running block 2 ");
        direction = "positive";
      } else if (selectedMoment.isSame(baseDate, "day")) {
        // console.log("running block 3");
        direction = "same";
      }

      let startHour;
      let endHour;

      if (direction === "positive") {
        startHour = "00:00";
        endHour = currentHour.add(1, "hour").format("HH:mm");
      } else if (direction === "negative") {
        startHour = currentHour.format("HH:mm");
        endHour = "23:59";
      } else if (direction === "same") {
        startHour = "00:00";
        endHour = "23:59";
      }

      console.log("startHour", startHour, "endHour", endHour);
      const slots = generateTimeSlots(startHour, endHour, "00:00");
      // Generate time slots from startHour to endHour
      timeRanges.push(slots);
      // console.log("timeRanges", timeRanges);
      return timeRanges;
    });
    const returnData = bookedDate.flat() || [];
    // console.log(bookedDate.flat());
    const responce = {
      success: true,
      data: returnData,
      message: "coach details retrieved successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

function generateTimeSlots(
  //this fun return an array of the slots in key and value form
  startTime,
  // can be passed as the initial time to start generating the aval slots with the provided gap between them
  endTime,
  // can be passed as the last time to start generating the aval slots with the provided gap between them
  slotGap
  // string in the form of minutes to be passed as gap between the two consequtive slots
  // the ffap should be passed as "hh:mm"
) {
  // Convert startTime and endTime to Date objects for easier manipulation

  const start = new Date();
  const end = new Date();

  // Parse the provided start and end times into hours and minutes
  const [startHour, startMinute] = startTime.split(":").map(Number);
  const [endHour, endMinute] = endTime.split(":").map(Number);

  // Set the start and end Date objects with parsed hours and minutes
  start.setHours(startHour, startMinute, 0, 0);
  end.setHours(endHour, endMinute, 0, 0);

  // If the date is today, ensure the start time is not before the current time

  // Parse the slot gap into hours and minutes
  const [gapHours, gapMinutes] = slotGap.split(":").map(Number);

  const slots = [];

  while (start < end) {
    // Calculate the slot's end time (1 hour duration)
    const slotEnd = new Date(start);
    slotEnd.setHours(start.getHours() + 1);

    // Only add the slot if the slot's end is within the range
    if (slotEnd <= end) {
      slots.push({
        from: start.toTimeString().slice(0, 5),
        to: slotEnd.toTimeString().slice(0, 5),
      });
    }

    // Move the start time forward by the gap duration
    start.setMinutes(start.getMinutes() + 60 + (gapHours * 60 + gapMinutes));
  }
  return slots;
}
