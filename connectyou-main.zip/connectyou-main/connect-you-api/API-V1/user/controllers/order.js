require("dotenv").config();
const { validationResult } = require("express-validator");
const moment = require("moment-timezone");
//import the modals
const bookingModal = require("../../../models/booking");
const booked_sessionModal = require("../../../models/booked_session");
const rescheduled_sessionsModal = require("../../../models/rescheduled_sessions");
const completedOrders = require("../../../models/completedOrders");
const mongoose = require("mongoose");
//SMTP setup

const {
  CreateAdminLevelNotification,
  CreateNotification,
} = require("../../../models/notificationModal");
const {
  request_refund,
  refund_request_model,
} = require("../../../models/refund_request");
const { getCoachData } = require("../../../lib/coach");
const {
  coacheeSessionEventUpdateEmailer,
  coachSessionEventUpdateEmailer,
} = require("../../../utils/quickEmails");
const { getUserData } = require("../../../lib/coachee");
const {
  addEventToCoachsCalendar,
  removeCoachCalendarEvent,
} = require("../../../lib/googleCalender");
const capitalizeFirstLetter = require("../../../lib/capitalizeFirstLetter");
const { formatMomemtTimeToStr } = require("../../../lib/formatMomemtTimeToStr");
const { saveTimelineEntry } = require("../../../models/bookedSessionTimeLine");

//get booked session data
const getBookedSessionData = async (id) => {
  try {
    const Data = await booked_sessionModal.aggregate([
      {
        $match: {
          _id: mongoose.Types.ObjectId.createFromHexString(id),
        },
      },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          amount: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          title: "$sessionData.title",
          google_event_id: 1,
          sessionType: 1,
          cartId: 1,
          sessionId: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
          sessionStatus: 1,
        },
      },
    ]);
    if (Data.length > 0) {
      return Data[0];
    } else {
      throw (error = "server error");
    }
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

//order details
const getOrderDetails = async (orderId) => {
  try {
    const orderData = await bookingModal.find({ _id: orderId });
    if (orderData.length == 0) {
      throw (error = "Order details not found");
    }
    return orderData[0];
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};
//user order list
exports.orderList = async (req, res) => {
  try {
    const userId = req.user._id; //login coach-id
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "booked_sessionsData",
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          amount: 1,
          receipt: 1,
          coachData: {
            $map: {
              input: "$coachData",
              as: "coach",
              in: {
                _id: "$$coach._id",
                name: "$$coach.name",
                Lname: "$$coach.Lname",
                userName: "$$coach.userName",
                gender: "$$coach.gender",
                email: "$$coach.email",
                image: "$$coach.image",
                timeZone: "$$coach.timeZone",
              },
            },
          },
          bookedSessionsCount: { $size: "$booked_sessionsData" },
          upcomingCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 0] },
              },
            },
          },
          completedCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 1] },
              },
            },
          },
          canceledCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 2] },
              },
            },
          },
        },
      },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      totalPages,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//user order list with a coach
exports.withCoachOrderList = async (req, res) => {
  try {
    const userId = req.user._id; //login coach-id
    const coachId = req.params.coachId; //login coach-id
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
          userId: new mongoose.Types.ObjectId(userId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "booked_sessionsData",
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          amount: 1,
          receipt: 1,
          coachData: {
            $map: {
              input: "$coachData",
              as: "coach",
              in: {
                _id: "$$coach._id",
                name: "$$coach.name",
                Lname: "$$coach.Lname",
                userName: "$$coach.userName",
                gender: "$$coach.gender",
                email: "$$coach.email",
                image: "$$coach.image",
                timeZone: "$$coach.timeZone",
                zoomMeetingURL: "$$coach.zoomMeetingURL",
              },
            },
          },
          bookedSessionsCount: { $size: "$booked_sessionsData" },
          upcomingCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 0] },
              },
            },
          },
          completedCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 1] },
              },
            },
          },
          canceledCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 2] },
              },
            },
          },
        },
      },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      totalPages,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//order details
exports.orderDetails = async (req, res) => {
  try {
    const userId = req.user._id; //login coach-id
    const orderId = req.params.id;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(orderId),
          userId: new mongoose.Types.ObjectId(userId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "bookingId",
          as: "ratingsData",
        },
      },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          pipeline: [
            {
              $lookup: {
                from: "coaches",
                localField: "coachId",
                foreignField: "_id",
                as: "coachData",
              },
            },
            { $unwind: "$coachData" },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
            {
              $group: {
                _id: "$coachData._id", // Group by coach's ID
                coachData: { $first: "$coachData" },
                sessions: {
                  $push: {
                    _id: "$_id",
                    sessionDate: "$sessionDate",
                    sessionDateUpdated: "$sessionDateUpdated",
                    sessionStatus: "$sessionStatus",
                    absentee: "$absentee",
                    sessionAmount: "$amount",
                    sessionCancelBy: "$sessionCancelBy",
                    messageCancel: "$messageCancel",
                    sessionCompletedUser: "$sessionCompletedUser",
                    sessionCompletedCoach: "$sessionCompletedCoach",
                    sessionCompletedCoachTime: "$sessionCompletedCoachTime",
                    completedCoachMSG: "$completedCoachMSG",
                    completedUserMSG: "$completedUserMSG",
                    sessionData: {
                      _id: "$sessionData._id",
                      coachId: "$sessionData.coachId",
                      title: "$sessionData.title",
                      price: "$sessionData.price",
                      type: "$sessionData.type",
                      description: "$sessionData.description",
                    },
                  },
                },
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          receipt: 1,
          orderStatus: 1,
          ratingsData: 1,
          customer: {
            customer_city: "$customer_city",
            customer_country: "$customer_country",
            customer_email: "$customer_email",
            customer_line1: "$customer_line1",
            customer_line2: "$customer_line2",
            customer_name: "$customer_name",
            customer_phone: "$customer_phone",
            customer_postal_code: "$customer_postal_code",
            customer_state: "$customer_state",
          },
          cardDetails: {
            amount: "$amount",
            cardBrand: "$cardBrand",
            cardCountry: "$cardCountry",
            card_exp_month: "$card_exp_month",
            card_exp_year: "$card_exp_year",
            card_last4: "$card_last4",
            currency: "$currency",
          },
          booked_sessionsData: {
            $map: {
              input: "$booked_sessionsData",
              as: "session",
              in: {
                coachData: {
                  _id: "$$session.coachData._id",
                  name: "$$session.coachData.name",
                  Lname: "$$session.coachData.Lname",
                  image: "$$session.coachData.image",
                  gender: "$$session.coachData.gender",
                  title_line: "$$session.coachData.title_line",
                  zoomMeetingURL: "$$session.coachData.zoomMeetingURL",
                  timeZone: "$$session.coachData.timeZone",
                },
                sessions: "$$session.sessions",
                sessionCompleted: {
                  $cond: {
                    if: {
                      $and: [
                        // Ensure there are no sessions with sessionStatus == 0
                        {
                          $eq: [
                            {
                              $size: {
                                $filter: {
                                  input: "$$session.sessions",
                                  as: "s",
                                  cond: { $eq: ["$$s.sessionStatus", 0] },
                                },
                              },
                            },
                            0,
                          ],
                        },
                        // Ensure at least one session has sessionStatus == 1
                        {
                          $gt: [
                            {
                              $size: {
                                $filter: {
                                  input: "$$session.sessions",
                                  as: "s",
                                  cond: { $eq: ["$$s.sessionStatus", 1] },
                                },
                              },
                            },
                            0,
                          ],
                        },
                      ],
                    },
                    then: true,
                    else: false,
                  },
                },
              },
            },
          },
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderData[0],
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//ordered session details
exports.orderSessionDetails = async (req, res) => {
  try {
    const userId = req.user._id; //login coach-id
    const orderId = req.params.id;
    const bookedSessionId = req.params.bookedSessionId;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(orderId),
          userId: new mongoose.Types.ObjectId(userId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "bookingId",
          as: "ratingsData",
        },
      },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$bookingId", "$$bookingId"] },
                    {
                      $eq: [
                        "$_id",
                        new mongoose.Types.ObjectId(bookedSessionId),
                      ],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "coaches",
                localField: "coachId",
                foreignField: "_id",
                as: "coachData",
              },
            },
            { $unwind: "$coachData" },

            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
            {
              $lookup: {
                from: "rescheduled_sessions",
                localField: "_id",
                foreignField: "bookedSessionId",
                as: "rescheduled_sessionsData",
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      { $unwind: "$booked_sessionsData" },
      {
        $project: {
          _id: 1,
          // payment_intent: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          ratingsData: 1,
          booked_sessionsData: {
            _id: "$booked_sessionsData._id",
            sessionDate: "$booked_sessionsData.sessionDate",
            sessionDateUpdated: "$booked_sessionsData.sessionDateUpdated",
            sessionStatus: "$booked_sessionsData.sessionStatus",
            absentee: "$booked_sessionsData.absentee",
            sessionAmount: "$booked_sessionsData.amount",
            sessionCancelBy: "$booked_sessionsData.sessionCancelBy",
            messageCancel: "$booked_sessionsData.messageCancel",
            sessionCompletedUser: "$booked_sessionsData.sessionCompletedUser",
            sessionCompletedCoach: "$booked_sessionsData.sessionCompletedCoach",
            sessionCompletedCoachTime:
              "$booked_sessionsData.sessionCompletedCoachTime",
            completedCoachMSG: "$booked_sessionsData.completedCoachMSG",
            completedUserMSG: "$booked_sessionsData.completedUserMSG",
            sessionData: {
              _id: "$booked_sessionsData.sessionData._id",
              coachId: "$booked_sessionsData.sessionData.coachId",
              title: "$booked_sessionsData.sessionData.title",
              price: "$booked_sessionsData.sessionData.price",
              type: "$booked_sessionsData.sessionData.type",
              description: "$booked_sessionsData.sessionData.description",
            },
            coachData: {
              _id: "$booked_sessionsData.coachData._id",
              name: "$booked_sessionsData.coachData.name",
              Lname: "$booked_sessionsData.coachData.Lname",
              image: "$booked_sessionsData.coachData.image",
              gender: "$booked_sessionsData.coachData.gender",
              title_line: "$booked_sessionsData.coachData.title_line",
              zoomMeetingURL: "$booked_sessionsData.coachData.zoomMeetingURL",
              timeZone: "$booked_sessionsData.coachData.timeZone",
            },
            rescheduled_sessionsData:
              "$booked_sessionsData.rescheduled_sessionsData",
          },
        },
      },
    ]);
    const responce = {
      success: true,
      data: orderData[0],
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session reschedule
exports.reSchedule = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login coach-id
    const {
      bookingId,
      bookedSessionId,
      sessionDate,
      sessionDateOld,
      coachId,
      coachTimeZone,
      message,
    } = req.body;
    let [data1, data2, coachData, userData, oldBookedSessionData] =
      await Promise.all([
        new rescheduled_sessionsModal({
          bookingId,
          bookedSessionId,
          userId,
          coachId,
          coachTimeZone,
          sessionDate: sessionDateOld,
          rescheduledBy: "coachee",
          message,
        }).save(),
        booked_sessionModal.findByIdAndUpdate(
          { _id: bookedSessionId },
          {
            $set: {
              sessionDateUpdated: sessionDate,
            },
          }
        ),
        getCoachData(coachId),
        getUserData(userId),
        getBookedSessionData(bookedSessionId),
      ]);
    const newBookedSessionData = await getBookedSessionData(bookedSessionId);
    if (coachData.calendarStatus === 1) {
      await addEventToCoachsCalendar(newBookedSessionData);
      removeCoachCalendarEvent(oldBookedSessionData);
    }

    Promise.allSettled([
      coacheeSessionEventUpdateEmailer({
        subject: "Session Rescheduled",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
          <tr>
            <td style="padding: 15px 20px; background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 4px;">
              <p style="margin: 0; color: #065f46; font-size: 16px; font-weight: 600;">
                🔄 Session Rescheduled
              </p>
            </td>
          </tr>
        </table>`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session Rescheduled!",
        sessionPrice: `$${Number(newBookedSessionData.amount).toFixed(2)}`,
        sessionTitle: newBookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          newBookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `Rescheduled`,
        emailSummaryTitle: "Your Coaching Session Has Been Rescheduled",
        highlightSummary: `Your coaching session with ${coachData.name} ${coachData.Lname} has been successfully rescheduled. Please check the new time and prepare accordingly.`,
        highlightSubSummary:
          "We appreciate your flexibility. If you have any concerns or need to make further changes, feel free to log in to your account or contact our support team. We’re here to ensure a smooth coaching experience.",
      }),
      coachSessionEventUpdateEmailer({
        subject: "Session Rescheduled",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
          <tr>
            <td style="padding: 15px 20px; background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 4px;">
              <p style="margin: 0; color: #065f46; font-size: 16px; font-weight: 600;">
                🔄 Session Rescheduled
              </p>
            </td>
          </tr>
        </table>`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        title: "Session Rescheduled by coachee!",
        sessionPrice: `$${Number(newBookedSessionData.amount).toFixed(2)}`,
        sessionTitle: newBookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          newBookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `Rescheduled`,
        emailSummaryTitle:
          "Your Coaching Session Has Been Rescheduled by the coachee",
        highlightSummary: `Your coaching session with ${userData.name} ${userData.lastName} has been rescheduled. Please check the new time and prepare accordingly.`,
        highlightSubSummary:
          "We appreciate your flexibility. For any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      CreateNotification({
        user_id: userId,
        heading: "Session has been rescheduled.",
        description: `Your session  ${
          coachData.name ? "with " + coachData.name : ""
        } ${
          coachData.Lname ? coachData.Lname : ""
        } has been rescheduled.Please check session details for more information.`,
        url: `/u/booking/details/${bookingId}`,
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session has been rescheduled.",
        description: `Your session  ${
          userData.name ? "with " + userData.name : ""
        } has been rescheduled.Please check session details for more information.`,
        url: `/c/booking/details/${bookingId}`,
      }),
      CreateAdminLevelNotification({
        heading: `Coachee ${userData.name} have rescheduled a session.`,
        description: `Coachee ${userData.name} have rescheduled the session with coach ${coachData.name}`,
        url: `/bookings/detail/${bookingId}`,
      }),
      saveTimelineEntry({
        bookedSessionId: newBookedSessionData._id,
        action: "Rescheduled",
        message: `Coaching session was rescheduled.`,
        actionBy: "Coachee",
      }),
    ]);

    const responce = {
      success: true,
      message: "meeting rescheduled successfully",
    };

    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session cancel
exports.sessionCancel = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    const { coachId, bookingId, bookedSessionId, message } = req.body;
    const [coachData, userData, orderDetailsData, bookedSessionData] =
      await Promise.all([
        getCoachData(coachId),
        getUserData(userId),
        getOrderDetails(bookingId),
        getBookedSessionData(bookedSessionId),
      ]);

    if (bookedSessionData.sessionType === "0") {
      const refund_data = {
        cartId: bookedSessionData.cartId,
        bookings_id: bookingId,
        booked_session_id: bookedSessionId,
        userId,
        coachId: coachId,
        sessionId: bookedSessionData.sessionId,
        coachTimeZone: coachData.timeZone,
        userTimeZone: userData.timeZone,
        sessionType: "0",
        sessionDate: bookedSessionData.sessionDate,
        sessionDateUpdated: bookedSessionData.sessionDateUpdated,
        charge: orderDetailsData.chargeId,
        amount: Number(bookedSessionData.amount) * 100,
        session_cancel_remark: message,
      };
      await Promise.allSettled([
        request_refund({ data: refund_data }),
        booked_sessionModal.findByIdAndUpdate(
          { _id: mongoose.Types.ObjectId.createFromHexString(bookedSessionId) },
          {
            $set: {
              sessionStatus: 2, //canceled
              sessionCancelBy: "coachee", //cancel by user
              messageCancel: message,
            },
          }
        ),
      ]);
    } else {
      await booked_sessionModal.findByIdAndUpdate(
        { _id: bookedSessionId },
        {
          $set: {
            sessionStatus: 2, //canceled
            sessionCancelBy: "coachee", //cancel by user
            messageCancel: message,
          },
        }
      );
    }
    const responce = {
      success: true,
      message: "meeting Conceled successfully",
    };
    res.status(200).json(responce);
    if (coachData.calendarStatus === 1) {
      removeCoachCalendarEvent(bookedSessionData);
    } else {
      console.log(
        "This coach Dont have google calender , cant remove any even "
      );
    }
    Promise.allSettled([
      coachSessionEventUpdateEmailer({
        subject: "Session canceled by coachee",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
        <tr>
          <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
            <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
              ⚠️ Session canceled
            </p>
          </td>
        </tr>
      </table>`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        title: "Session canceled !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `canceled`,
        emailSummaryTitle:
          "Your Coaching Session Has Been Canceled by the coachee",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${userData.name} ${userData.lastName} has been canceled.`,
        highlightSubSummary:
          "For any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      coacheeSessionEventUpdateEmailer({
        subject: "Session canceled",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
        <tr>
          <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
            <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
              ⚠️ Session canceled
            </p>
          </td>
        </tr>
      </table>`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session canceled !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `canceled`,
        emailSummaryTitle: "Your Coaching Session Has Been Canceled",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${coachData.name} ${coachData.Lname} has been canceled.`,
        highlightSubSummary:
          "If you believe this cancellation was in error or wish to reschedule, please log in to your account for further options. Should you need any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session has been canceled.",
        description: `Your session  ${
          userData.name ? "with " + userData.name : ""
        } has been canceled.Please check session details for more information.`,
        url: `/c/booking/details/${bookingId}`,
      }),
      CreateNotification({
        user_id: userId,
        heading: "Session has been canceled.",
        description: `Your session  ${
          coachData.name ? "with " + coachData.name : ""
        } ${
          coachData.Lname ? coachData.Lname : ""
        } has been canceled. Please check session details for more information.`,
        url: `/u/booking/details/${bookingId}`,
      }),
      CreateAdminLevelNotification({
        heading: `Coachee ${userData.name} have canceled a session.`,
        description: `Coachee ${userData.name} have canceled the session with coach ${coachData.name}`,
        url: `/bookings/detail/${bookingId}`,
        notification_type: "bookings",
      }),
      saveTimelineEntry({
        bookedSessionId: bookedSessionData._id,
        action: "Cacncelled",
        message: `Coaching session was cancelled`,
        actionBy: "Coachee",
      }),
    ]).catch((error) => {
      console.error("sessionCompletedEmail error:", error);
    });
    return;
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

// session Absent
exports.sessionIncomplete = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const user_id = req.user._id;
    const { bookedSessionId, absentee, reasonForIncomplete, coachId } =
      req.body;
    await booked_sessionModal.findByIdAndUpdate(
      { _id: bookedSessionId },
      {
        $set: {
          sessionStatus: 3, // incomplete
          absentee: absentee,
          reasonForIncomplete: reasonForIncomplete,
          markedBy: "coachee",
        },
      }
    );
    const [coachData, userData, bookedSessionData] = await Promise.all([
      getCoachData(coachId),
      getUserData(user_id),
      getBookedSessionData(bookedSessionId),
    ]);
    Promise.allSettled([
      coachSessionEventUpdateEmailer({
        subject: "Session marked as incomplete",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
      <tr>
        <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
          <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
            ⚠️ Session marked as incomplete
          </p>
        </td>
      </tr>
    </table>`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        title: "Session marked as Incomplete !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `Incomplete`,
        emailSummaryTitle:
          "Your Coaching Session was marked as incomplete by your coachee",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${userData.name} ${userData.lastName} has been marked as incomplete.`,
        highlightSubSummary:
          "If you believe this action was in error or wish to reschedule, please log in to your account for further options. Should you need any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      coacheeSessionEventUpdateEmailer({
        subject: "Session marked as incomplete",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
      <tr>
        <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
          <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
            ⚠️ Session marked as incomplete
          </p>
        </td>
      </tr>
    </table>`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session not completed !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `Incomplete`,
        emailSummaryTitle: "Your Coaching Session was marked as incomplete",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${coachData.name} ${coachData.Lname} has been marked as incomplete.`,
        highlightSubSummary:
          "If you believe this action was in error or wish to reschedule, please log in to your account for further options. Should you need any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      CreateNotification({
        user_id: user_id,
        heading: "Session marked as Incomplete.",
        description: `You have recently marked one of your session as incomplete. Please contact support if this was a mistake.`,
        url: `/u/bookings/canceled`,
        notification_type: "bookings",
      }),
      saveTimelineEntry({
        bookedSessionId: bookedSessionData._id,
        action: "Marked as Incomplete",
        message: `Coaching session was marked as incomplete.`,
        actionBy: "Coachee",
      }),
    ]);
    const responce = {
      success: true,
      message: "Session marked as incomplete",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session complete
exports.sessionComplete = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    const { coachId, bookingId, bookedSessionId, message } = req.body;
    const [coachData, userData, orderDetailsData, bookedSessionData] =
      await Promise.all([
        getCoachData(coachId),
        getUserData(userId),
        getOrderDetails(bookingId),
        getBookedSessionData(bookedSessionId),
      ]);
    await new completedOrders({
      coachId: bookedSessionData.coachId,
      orderId: bookedSessionData._id,
      chargeId: orderDetailsData.chargeId,
      // amount: Number(bookedSessionData.amount || 0) * 0.8 * 100,  // originally was 0.8 // ie 20% fee collection
      amount: Number(bookedSessionData.amount || 0) * 0.6 * 100, // updated to 0.6 ie 40% fee collection
      orderAmount: bookedSessionData.amount,
      currency: orderDetailsData.currency,
    }).save();

    await booked_sessionModal.findByIdAndUpdate(
      { _id: bookedSessionId },
      {
        $set: {
          sessionStatus: 1, //complete
          sessionCompletedUser: 1,
          completedUserMSG: message,
          sessionCompletedDate: new Date().toISOString(),
        },
      }
    );

    if (coachData.calendarStatus === 1) {
      removeCoachCalendarEvent(bookedSessionData);
    } else {
      console.log(
        "This coach dont have any google calender added, session marked complete and calender not updateable"
      );
    }

    Promise.allSettled([
      coachSessionEventUpdateEmailer({
        subject: "Congratulations, Session was marked as Completed",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
  <tr>
    <td style="padding: 15px 20px; background-color: #f3f3f3; border-left: 4px solid #28a745; border-radius: 4px;">
      <p style="margin: 0; color: #013338; font-size: 16px; font-weight: 600;">
        ✅ Session Completed
      </p>
    </td>
  </tr>
</table>
`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        title: "Session Completed !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `Completed`,
        emailSummaryTitle:
          "Session has been marked as completed by the coachee. Thank You for Attending Your Coaching Session",
        highlightSummary: `We sincerely appreciate your time and engagement in your recent coaching session with ${userData.name} ${userData.lastName}. We hope the experience provided valuable insights and meaningful guidance as you continue on your journey.`,
        highlightSubSummary:
          "If you wish to schedule another session or need any assistance, please do not hesitate to contact us.",
      }),
      coacheeSessionEventUpdateEmailer({
        subject: "Session Completed",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
  <tr>
    <td style="padding: 15px 20px; background-color: #f3f3f3; border-left: 4px solid #28a745; border-radius: 4px;">
      <p style="margin: 0; color: #013338; font-size: 16px; font-weight: 600;">
        ✅ Session Completed
      </p>
    </td>
  </tr>
</table>
`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session Completed !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `Completed`,
        emailSummaryTitle: "Thank You for Attending Your Coaching Session",
        highlightSummary: `We sincerely appreciate your time and engagement in your recent coaching session with ${coachData.name} ${coachData.Lname}. We hope the experience provided valuable insights and meaningful guidance as you continue on your journey.`,
        highlightSubSummary:
          "We would appreciate your feedback. You may leave a review for the coach or the session by logging into your account on our platform. If you wish to schedule another session or need any assistance, please do not hesitate to contact us.",
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session completed.",
        description: `Your session  ${
          userData.name ? "with " + `${userData.name} ${userData.lastName}` : ""
        } has been completed.Please check session details for more information.`,
        url: `/c/bookings`,
        notification_type: "bookings",
      }),
      CreateNotification({
        user_id: userId,
        heading: "Session completed.",
        description: `Your session  ${
          coachData.name ? "with " + `${coachData.name}` : ""
        } ${
          coachData.Lname ? coachData.Lname : ""
        } has been completed. Please check session details for more information.`,
        url: `/u/booking/details/${bookingId}`,
        notification_type: "bookings",
      }),
      CreateAdminLevelNotification({
        heading: `Coachee ${userData.name} have completed a booked session.`,
        description: `Coachee ${userData.name} have completed the booked session with coach ${coachData.name}`,
        url: `/bookings/detail/${bookingId}`,
        notification_type: "bookings",
      }),
      saveTimelineEntry({
        bookedSessionId: bookedSessionData._id,
        action: "Completed",
        message: `Coaching session was marked as completed`,
        actionBy: "Coachee",
      }),
    ]).catch((error) => {
      console.error("sessionCompletedEmail error:", error);
    });
    const responce = {
      success: true,
      message: "meeting completed successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//User list
exports.coachList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id

    const coachList = await bookingModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                Lname: 1,
                email: 1,
                image: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: "$coachData",
      },
      {
        $replaceRoot: {
          newRoot: {
            coachData: "$coachData",
            createdAt: "$createdAt",
          },
        },
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $group: {
          _id: "$coachData._id",
          name: { $first: "$coachData.name" },
          Lname: { $first: "$coachData.Lname" },
          email: { $first: "$coachData.email" },
          image: { $first: "$coachData.image" },
        },
      },
    ]);

    const response = {
      success: true,
      coachList,
      message: "users list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.refund_status = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const booked_session_id = req.params.booked_session_id;
    const refund_Obj = await refund_request_model.find({
      booked_session_id:
        mongoose.Types.ObjectId.createFromHexString(booked_session_id),
    });
    return res.status(200).json({
      success: true,
      message: "Retrieved Refund Request Status successfully",
      data: refund_Obj,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
