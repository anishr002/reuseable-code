const puppeteer = require("puppeteer");
const moment = require("moment-timezone");
const mongoose = require("mongoose");
const bookingModal = require("../../../models/booking");
const { validationResult } = require("express-validator");
const userModel = require("../../../models/user");

exports.get = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { userId } = req.params;
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const filter = !isNaN(req.query.filter) ? Number(req.query.filter) || 0 : 0;
    // const monthFilter = req.query.month || "all";

    let matchCri = {
      userId: new mongoose.Types.ObjectId(userId),
      paid: 1,
    };

    if (filter === 2) {
      matchCri.amount = { $eq: 0 };
    } else if (filter === 1) {
      matchCri.amount = { $gt: 0 };
    }

    // if (monthFilter !== "all") {
    //   const startOfMonth = moment()
    //     .year(new Date().getFullYear())
    //     .month(monthFilter)
    //     .startOf("month")
    //     .startOf("day");

    //   const endOfMonth = moment()
    //     .year(new Date().getFullYear())
    //     .month(monthFilter)
    //     .endOf("month")
    //     .endOf("day");

    //   matchCri.createdAt = {
    //     $gte: startOfMonth.toDate(),
    //     $lte: endOfMonth.toDate(),
    //   };
    // }

    const orderData = await bookingModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "booked_sessionsData",
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          amount: 1,
          coachData: {
            $map: {
              input: "$coachData",
              as: "coach",
              in: {
                _id: { $ifNull: ["$$coach._id", null] },
                name: { $ifNull: ["$$coach.name", ""] },
                email: { $ifNull: ["$$coach.email", ""] },
                image: { $ifNull: ["$$coach.image", ""] },
                timeZone: { $ifNull: ["$$coach.timeZone", ""] },
              },
            },
          },
          bookedSessionsCount: { $size: "$booked_sessionsData" },
          billingAddress: {
            customer_city: "$customer_city",
            customer_country: "$customer_country",
            customer_email: "$customer_email",
            customer_line1: "$customer_line1",
            customer_line2: "$customer_line2",
            customer_name: "$customer_name",
            customer_phone: "$customer_phone",
            customer_postal_code: "$customer_postal_code",
            customer_state: "$customer_state",
          },
          customer_email: 1,
          cardBrand: 1,
          cardCountry: 1,
          card_exp_year: 1,
          card_last4: 1,
          amountPaid: "$amount",
          transactionId: "$TransactionID",
          orderId: "$orderId",
          receipt: 1,
          currency: 1,
        },
      },

      { $sort: { createdAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);

    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;

    const response = {
      success: true,
      data: orderDataListData,
      totalPages,
      currentPage: pageNo,
      message: "User orders retrieved successfully",
    };

    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generateMonthlyRcpt = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }

  try {
    const { userId, month, year } = req.params;
    // console.log({
    //   month,
    //   year,
    //   userId,
    // });
    let matchCri = {
      userId: new mongoose.Types.ObjectId(userId),
      paid: 1,
    };
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const monthIndex = monthNames.findIndex(
      (m) => m.toLowerCase() === month.toLowerCase()
    );
    if (monthIndex === -1) {
      throw new Error("Invalid month name");
    }
    const startOfMonth = moment()
      .year(parseInt(year))
      .month(monthIndex)
      .startOf("month")
      .startOf("day");

    const endOfMonth = moment()
      .year(parseInt(year))
      .month(monthIndex)
      .endOf("month")
      .endOf("day");

    matchCri.createdAt = {
      $gte: startOfMonth.toDate(),
      $lte: endOfMonth.toDate(),
    };

    const orderData = await bookingModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "booked_sessionsData",
        },
      },
      {
        $unwind: "$booked_sessionsData",
      },
      {
        $lookup: {
          from: "coachsessions",
          localField: "booked_sessionsData.sessionId",
          foreignField: "_id",
          as: "sessionDetails",
        },
      },
      {
        $unwind: "$sessionDetails",
      },
      {
        $lookup: {
          from: "coaches",
          localField: "sessionDetails.coachId",
          foreignField: "_id",
          as: "sessionDetails.coachData",
        },
      },
      {
        $unwind: "$sessionDetails.coachData",
      },
      {
        $group: {
          _id: "$_id",
          userId: { $first: "$userId" },
          chargeId: { $first: "$chargeId" },
          amount: { $first: "$amount" },
          currency: { $first: "$currency" },
          cardBrand: { $first: "$cardBrand" },
          card_exp_month: { $first: "$card_exp_month" },
          card_exp_year: { $first: "$card_exp_year" },
          card_fingerprint: { $first: "$card_fingerprint" },
          card_last4: { $first: "$card_last4" },
          cardCountry: { $first: "$cardCountry" },
          customer_city: { $first: "$customer_city" },
          customer_country: { $first: "$customer_country" },
          customer_line1: { $first: "$customer_line1" },
          customer_line2: { $first: "$customer_line2" },
          customer_postal_code: { $first: "$customer_postal_code" },
          customer_state: { $first: "$customer_state" },
          customer_email: { $first: "$customer_email" },
          customer_name: { $first: "$customer_name" },
          customer_phone: { $first: "$customer_phone" },
          TransactionID: { $first: "$TransactionID" },
          orderId: { $first: "$orderId" },
          createdAt: { $first: "$createdAt" },
          sessionDetails: {
            $push: {
              _id: "$sessionDetails._id",
              title: "$sessionDetails.title",
              price: "$sessionDetails.price",
              coachDetails: {
                _id: "$sessionDetails.coachData._id",
                name: "$sessionDetails.coachData.name",
                Lname: "$sessionDetails.coachData.Lname",
                userName: "$sessionDetails.coachData.userName",
                email: "$sessionDetails.coachData.email",
              },
            },
          },
        },
      },
      { $sort: { createdAt: -1 } },
    ]);

    const userDetails = await userModel.findOne({ _id: userId });
    const receipt =
      orderData.length === 0
        ? ""
        : await generateInvoice({
            customerDetails: {
              name: userDetails.name,
              lastName: userDetails.lastName,
              email: userDetails.email,
              address: userDetails.fullAddress,
            },
            orders: orderData,
            period: `For ${month} ${year}`,
          });
    const response = {
      success: true,
      data: orderData,
      receipt: receipt,
      noOrders: orderData.length === 0,
      message: "User orders retrieved successfully for the specified month",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generateYearly = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }

  try {
    const { userId, year } = req.params;
    let matchCri = {
      userId: new mongoose.Types.ObjectId(userId),
      paid: 1,
    };
    const startOfYear = moment().year(parseInt(year)).startOf("year");
    const endOfYear = moment().year(parseInt(year)).endOf("year");

    matchCri.createdAt = {
      $gte: startOfYear.toDate(),
      $lte: endOfYear.toDate(),
    };

    const orderData = await bookingModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "booked_sessionsData",
        },
      },
      {
        $unwind: "$booked_sessionsData",
      },
      {
        $lookup: {
          from: "coachsessions",
          localField: "booked_sessionsData.sessionId",
          foreignField: "_id",
          as: "sessionDetails",
        },
      },
      {
        $unwind: "$sessionDetails",
      },
      {
        $lookup: {
          from: "coaches",
          localField: "sessionDetails.coachId",
          foreignField: "_id",
          as: "sessionDetails.coachData",
        },
      },
      {
        $unwind: "$sessionDetails.coachData",
      },
      {
        $group: {
          _id: "$_id",
          userId: { $first: "$userId" },
          chargeId: { $first: "$chargeId" },
          amount: { $first: "$amount" },
          currency: { $first: "$currency" },
          cardBrand: { $first: "$cardBrand" },
          card_exp_month: { $first: "$card_exp_month" },
          card_exp_year: { $first: "$card_exp_year" },
          card_fingerprint: { $first: "$card_fingerprint" },
          card_last4: { $first: "$card_last4" },
          cardCountry: { $first: "$cardCountry" },
          customer_city: { $first: "$customer_city" },
          customer_country: { $first: "$customer_country" },
          customer_line1: { $first: "$customer_line1" },
          customer_line2: { $first: "$customer_line2" },
          customer_postal_code: { $first: "$customer_postal_code" },
          customer_state: { $first: "$customer_state" },
          customer_email: { $first: "$customer_email" },
          customer_name: { $first: "$customer_name" },
          customer_phone: { $first: "$customer_phone" },
          TransactionID: { $first: "$TransactionID" },
          orderId: { $first: "$orderId" },
          createdAt: { $first: "$createdAt" },
          sessionDetails: {
            $push: {
              _id: "$sessionDetails._id",
              title: "$sessionDetails.title",
              price: "$sessionDetails.price",
              coachDetails: {
                _id: "$sessionDetails.coachData._id",
                name: "$sessionDetails.coachData.name",
                Lname: "$sessionDetails.coachData.Lname",
                userName: "$sessionDetails.coachData.userName",
                email: "$sessionDetails.coachData.email",
              },
            },
          },
        },
      },
      { $sort: { createdAt: -1 } },
    ]);

    const userDetails = await userModel.findOne({ _id: userId });

    const receipt =
      orderData.length === 0
        ? ""
        : await generateInvoice({
            customerDetails: {
              name: userDetails.name,
              lastName: userDetails.lastName,
              email: userDetails.email,
              address: userDetails.fullAddress,
            },
            orders: orderData,
            period: `For year ${year}`,
          });
    const response = {
      success: true,
      data: orderData,
      receipt: receipt,
      noOrders: orderData.length === 0,
      message: "User orders retrieved successfully for the specified month",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generatePeriodic = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { userId, from, upto } = req.params;
    // console.log({ from, upto });
    let matchCri = {
      userId: new mongoose.Types.ObjectId(userId),
      paid: 1,
    };
    const start = moment(`${from}`, "YYYY-MM-DD").startOf("day");
    const end = moment(`${upto}`, "YYYY-MM-DD").endOf("day");
    matchCri.createdAt = {
      $gte: start.toDate(),
      $lte: end.toDate(),
    };
    // console.log({ matchCri });
    const orderData = await bookingModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "booked_sessionsData",
        },
      },
      {
        $unwind: "$booked_sessionsData",
      },
      {
        $lookup: {
          from: "coachsessions",
          localField: "booked_sessionsData.sessionId",
          foreignField: "_id",
          as: "sessionDetails",
        },
      },
      {
        $unwind: "$sessionDetails",
      },
      {
        $lookup: {
          from: "coaches",
          localField: "sessionDetails.coachId",
          foreignField: "_id",
          as: "sessionDetails.coachData",
        },
      },
      {
        $unwind: "$sessionDetails.coachData",
      },
      {
        $group: {
          _id: "$_id",
          userId: { $first: "$userId" },
          chargeId: { $first: "$chargeId" },
          amount: { $first: "$amount" },
          currency: { $first: "$currency" },
          cardBrand: { $first: "$cardBrand" },
          card_exp_month: { $first: "$card_exp_month" },
          card_exp_year: { $first: "$card_exp_year" },
          card_fingerprint: { $first: "$card_fingerprint" },
          card_last4: { $first: "$card_last4" },
          cardCountry: { $first: "$cardCountry" },
          customer_city: { $first: "$customer_city" },
          customer_country: { $first: "$customer_country" },
          customer_line1: { $first: "$customer_line1" },
          customer_line2: { $first: "$customer_line2" },
          customer_postal_code: { $first: "$customer_postal_code" },
          customer_state: { $first: "$customer_state" },
          customer_email: { $first: "$customer_email" },
          customer_name: { $first: "$customer_name" },
          customer_phone: { $first: "$customer_phone" },
          TransactionID: { $first: "$TransactionID" },
          orderId: {
            $first: "$orderId",
          },
          createdAt: { $first: "$createdAt" },
          sessionDetails: {
            $push: {
              _id: "$sessionDetails._id",
              title: "$sessionDetails.title",
              price: "$sessionDetails.price",
              coachDetails: {
                _id: "$sessionDetails.coachData._id",
                name: "$sessionDetails.coachData.name",
                Lname: "$sessionDetails.coachData.Lname",
                userName: "$sessionDetails.coachData.userName",
                email: "$sessionDetails.coachData.email",
              },
            },
          },
        },
      },
      { $sort: { createdAt: -1 } },
    ]);

    // console.log({ orderData });
    const userDetails = await userModel.findOne({ _id: userId });
    const receipt =
      orderData.length === 0
        ? ""
        : await generateInvoice({
            customerDetails: {
              name: userDetails.name,
              lastName: userDetails.lastName,
              email: userDetails.email,
              address: userDetails.fullAddress,
            },
            orders: orderData,
            period: `For ${from} to ${upto}`,
          });

    const response = {
      success: true,
      data: orderData,
      receipt: receipt,
      noOrders: orderData.length === 0,
      message:
        "User orders retrieved successfully for the specified time period",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

async function generateInvoice({
  customerDetails,
  orders,
  period,
  invoice_number = `CY_INV${Date.now()}`,
}) {
  const date = new Date().toLocaleDateString();
  let invoiceContent = "";
  orders.forEach((order, orderIndex) => {
    // console.log({ order });
    let sessionRows = "";
    let orderTotal = 0;
    order.sessionDetails.forEach((session) => {
      orderTotal += session.price;
      sessionRows += `
        <tr>
          <td style="padding: 8px 10px">
            <b style="color:#013338;font-size:16px;"> ${session.title}</b><br/>
                          ${session.coachDetails.name} ${
        session.coachDetails.Lname
      }<br/>${session.coachDetails.email}
          </td>
          <td style="padding: 8px 10px; text-align: right">
            $${session.price.toFixed(2)}
          </td>
        </tr>
      `;
    });

    invoiceContent += `
      <tr>
        <td colspan="100%" style="padding: 10px 0">
          <h3 style="margin: 0; font-size: 18px; color: #025e5a">
            Order : ${orderIndex + 1}
          </h3>
        </td>
      </tr>
      <tr>
        <td style="padding: 16px 0; border-bottom: 2px solid #ccc">
          <!-- Order Info Table -->
          <table
            cellpadding="0"
            cellspacing="0"
            border="0"
            style="width: 100%; border-collapse: collapse; background-color: #f9f9f9;"
          >
            <thead>
              <tr style="background-color: #f5fafa">
                <th style="padding: 12px 10px; text-align: left; font-weight: 600; color: #013338;">
                 Order ID
                </th>
                <th style="padding: 12px 10px; text-align: left; font-weight: 600; color: #013338;">
                  Transaction ID
                </th>
                <th style="padding: 12px 10px; text-align: left; font-weight: 600; color: #013338;">
                  Dated
                </th>
                <th style="padding: 12px 10px; text-align: left; font-weight: 600; color: #013338;">
                  Customer
                </th>
                <th style="padding: 12px 10px; text-align: right; font-weight: 600; color: #013338;">
                  Total Price
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="padding: 10px">${order.orderId}</td>
                <td style="padding: 10px">${order.TransactionID || "--"}</td>
                <td style="padding: 10px">${moment(order.createdAt).format(
                  "DD MMMM YYYY hh:mm A"
                )}</td>
                <td style="padding: 10px;word-break: break-all">${
                  order.customer_name || "-"
                }</td>
                <td style="padding: 10px; text-align: right">
                  $${orderTotal.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
  
          <!-- Order Items Table -->
          <table
            cellpadding="0"
            cellspacing="0"
            border="0"
            style="width: 100%; border-collapse: collapse; margin-top: 8px;"
          >
            <thead>
              <tr style="background-color: #eef6f6">
                <th style="padding: 8px 10px; text-align: left">Item</th>
                <th style="padding: 8px 10px; text-align: right">Price</th>
              </tr>
            </thead>
            <tbody>
              ${sessionRows}
            </tbody>
          </table>
        </td>
      </tr>
    `;
  });

  const htmlTemplate = `<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment History</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <!-- Fallback font styles embedded for email clients that don't support web fonts -->
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap");
    </style>
  </head>
  <body
    style="
      margin: 0;
      padding: 0;
      font-family: 'Quicksand', 'Helvetica Neue', Helvetica, Arial, sans-serif;
      color: #333;
      line-height: 1.6;
      background-color: #ffffff !important;
      width: 800px;
      margin: 0 auto;
    "
  >
    <table
      cellpadding="0"
      cellspacing="0"
      border="0"
      style="width: 100%; background-color: #f0f0f0"
    >
      <tr>
        <td>
          <!-- MAIN EMAIL CONTAINER -->
          <table
            cellpadding="0"
            cellspacing="0"
            border="0"
            style="width: 100%; margin: 0 auto; height: 100%"
          >
            <!-- HEADER - Extends full width -->

            <!-- Invoice Header Starts -->
            <tr>
              <td style="padding: 0">
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; position: relative"
                >
                  <!-- Invoice Number Top-Right -->
                  <tr>
                    <td style="padding: 0; position: relative">
                      <!-- Centered Logo -->
                      <table width="100%">
                        <tr>
                          <td
                            style="
                              background-color: #ffffff;
                              padding: 40px 0;
                              text-align: center;
                            "
                          >
                            <img
                              src="https://api.connectyou.global/logo/loginLogo.png"
                              alt="ConnectYou.Global Logo"
                              style="max-width: 280px; height: auto"
                            />
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Hero Header -->
                  <tr>
                    <td style="padding: 0">
                      <table
                        cellpadding="20"
                        cellspacing="0"
                        border="0"
                        style="width: 100%"
                      >
                        <tr>
                          <td
                            style="
                              background: linear-gradient(
                                135deg,
                                #013338 0%,
                                #025e5a 100%
                              );
                              padding: 10px 70px;
                              text-align: center;
                            "
                          >
                            <h1
                              style="
                                color: #ffffff;
                                margin: 0;
                                font-size: 28px;
                                font-weight: 700;
                                letter-spacing: 0.5px;
                              "
                            >
                              Payment History Detail
                            </h1>
                            <p
                              style="
                                color: #ebbd33;
                                margin: 10px 0 0 0;
                                font-size: 18px;
                                font-weight: 400;
                                letter-spacing: 0.3px;
                              "
                            >
                              Thank you for choosing ConnectYou.Global
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Powered by -->
                  <tr>
                    <td
                      style="
                        background-color: #f5fafa;
                        padding: 8px 40px;
                        text-align: center;
                      "
                    >
                      <p style="margin: 0; font-size: 14px; color: #013338">
                        Powered by Erickson Coaching International
                      </p>
                    </td>
                  </tr>

                  <!-- Split: Issued To / Details -->
                  <tr>
                    <td
                      style="background-color: #ffffff; padding: 25px 40px 10px"
                    >
                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <!-- Issued To -->
                          <td width="50%" style="vertical-align: top">
                            <h3
                              style="
                                margin: 0 0 8px 0;
                                color: #013338;
                                font-size: 18px;
                              "
                            >
                              Issued To:
                            </h3>
                            <p style="margin: 0; color: #444; font-size: 14px">
                              ${customerDetails.name} ${customerDetails.lastName}<br />
                              ${customerDetails.email}<br />
                              ${customerDetails.address}<br />
                            </p>
                          </td>
                          <!-- Transaction Info -->
                          <td
                            width="50%"
                            style="text-align: right; vertical-align: top"
                          >
                            <table align="right">
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Invoice No. :
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${invoice_number}
                                </td>
                              </tr>

                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Date Issued:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${date}
                                </td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Transaction Time Period :
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${period}
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- HEADER - Extends full width -->
            <!-- MAIN CONTENT AREA -->
            <!-- Main Content / Booking Table -->
            <tr>
              <td style="padding: 30px 40px; background-color: #ffffff">
                <h2
                  style="margin-bottom: 20px; color: #013338; font-size: 20px"
                >
                  Payment History
                </h2>
                <div
                  style="
                    width: 100%;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                  "
                >
                  <table
                    cellpadding="0"
                    cellspacing="0"
                    border="0"
                    style="width: 100%; border-collapse: collapse"
                  >
                    <tbody>
                      <!-- Repeat this block for each order -->
                      ${invoiceContent}
                      <!-- End of Order Block -->
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>

            <!-- MAIN CONTENT AREA -->
            <!-- FOOTER - Extends full width -->
            <tr>
              <td
                style="
                  background-color: #013338;
                  padding: 0;
                  width: 100%;
                  column-span: all;
                "
              >
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%"
                >
                  <!-- Company Info -->
                  <tr>
                    <td style="padding: 30px 40px 10px; text-align: center">
                      <table
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                        style="margin: 0 auto; text-align: center"
                      >
                        <tr>
                          <td
                            style="
                              padding: 8px 0;
                              color: white;
                              font-size: 14px;
                              font-style: italic;
                            "
                          >
                            Warm regards,
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 5px 0;
                              color: #ffffff;
                              font-size: 16px;
                              font-weight: bold;
                            "
                          >
                            Erickson Coaching International
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: white;
                              font-size: 13px;
                            "
                          >
                            Founders of ConnectYou
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: #78a5a4;
                              font-size: 12px;
                            "
                          >
                            www.connectyou.global | support@connectyou.com
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Invoice Info -->
                  <!-- Disclaimer -->
                  <tr>
                    <td
                      style="
                        padding: 15px 40px;
                        text-align: center;
                        background-color: #002326;
                      "
                    >
                      <p
                        style="
                          margin: 0;
                          color: #5f8886;
                          font-size: 12px;
                          line-height: 1.6;
                        "
                      >
                        This receipt has been issued for your records. Please
                        retain a copy for personal or business accounting. If
                        you have any questions regarding this invoice, feel free
                        to
                        <a
                          href="https://connectyou.global/get-in-touch"
                          style="color: #3aa7a3; text-decoration: none"
                          >contact us</a
                        >
                        or email us at
                        <a
                          href="mailto:support@connectyou.com"
                          style="color: #3aa7a3; text-decoration: none"
                          >support@connectyou.com</a
                        >. <br /><br />
                        Please note: This is a system-generated receipt. All
                        amounts are inclusive of applicable taxes unless
                        otherwise stated.
                      </p>
                    </td>
                  </tr>
                  <!-- Copyright -->
                  <tr>
                    <td style="padding: 10px 40px 25px; text-align: center">
                      <p style="margin: 0; color: #78a5a4; font-size: 13px">
                        &copy; 2024 ConnectYou.Global. All rights reserved.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- FOOTER - Extends full width -->
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
`;

  let browser;
  if (process.env.BACKEND_URL == "http://localhost:7000") {
    browser = await puppeteer.launch();
  } else {
    browser = await puppeteer.launch({
      executablePath: "/usr/bin/chromium-browser",
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
  }
  const page = await browser.newPage();

  await page.setContent(htmlTemplate, { waitUntil: "networkidle0" });

  const pdfPath = `paymment_history_invoice_${customerDetails.lastName}_${
    customerDetails.name
  }_${Date.now()}.pdf`;

  await page.pdf({
    path: `${__dirname}/../../../public/receipt/${pdfPath}`,
    format: "A4",
    printBackground: true,
  });

  await browser.close();

  return pdfPath;
}
