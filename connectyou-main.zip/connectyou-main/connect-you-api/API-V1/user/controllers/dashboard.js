const { validationResult } = require("express-validator");
require("dotenv").config();
//environment variables
//import the modals
const orderModal = require("../../../models/booking");
const sessionModal = require("../../../models/coachSession");
const userModel = require("../../../models/user");
const CoachModel = require("../../../models/coach");
const chatMessageModel = require("../../../models/chatMessage");
const completedOrdersModal = require("../../../models/completedOrders");
const sessionBookingModal = require("../../../models/booked_session");
const mongoose = require("mongoose");

//user order list
exports.orderList = async (req, res) => {
  try {
    const userId = req.user._id;
    const [sessionCounts, userdata] = await Promise.all([
      sessionBookingModal.aggregate([
        {
          $match: { userId },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "bookingId",
            foreignField: "_id",
            as: "bookingInfo",
          },
        },
        { $unwind: "$bookingInfo" },
        { $match: { "bookingInfo.paid": 1 } },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            pending: {
              $sum: { $cond: [{ $eq: ["$sessionStatus", 0] }, 1, 0] },
            },
            completed: {
              $sum: { $cond: [{ $eq: ["$sessionStatus", 1] }, 1, 0] },
            },
            canceled: {
              $sum: { $cond: [{ $eq: ["$sessionStatus", 2] }, 1, 0] },
            },
          },
        },
      ]),
      CoachModel.countDocuments({ approve: 1 }),
    ]);

    const {
      total = 0,
      pending = 0,
      completed = 0,
      canceled = 0,
    } = sessionCounts[0] || {};

    const response = {
      success: true,
      totalSessions: total,
      pendingSessions: pending,
      completedSessions: completed,
      canceledSessions: canceled,
      userdata,
      message: "User orders retrieved successfully",
    };

    return res.status(200).json(response);
  } catch (err) {
    console.error("Error in orderList:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach Completed  order list
exports.completedOrdersList = async (req, res) => {
  try {
    const userId = req.user._id; //login user-id
    const orderList = await sessionBookingModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
          sessionStatus: 1,
        },
      },
      { $sort: { updatedAt: -1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          sessionCompletedDate: 1,
          caachName: "$coachData.name",
          coachLName: "$coachData.Lname",
          coachAvatar: "$coachData.image",
          title: "$sessionData.title",
          type: "$sessionData.type",
          price: "$sessionData.price",
          description: "$sessionData.description",
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderList,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach last  order
exports.lastOrders = async (req, res) => {
  try {
    const userId = req.user._id; //login user-id
    const orderList = await orderModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
        },
      },
      { $sort: { createdAt: -1 } },
      { $limit: 1 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          bookingDate: 1,
          bookingTime: 1,
          coachId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          completedDateTime: 1,
          userAvatar: "$userData.name",
          userAvatar: "$userData.image",
          title: "$sessionData.title",
          type: "$sessionData.type",
          price: "$sessionData.price",
          description: "$sessionData.description",
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderList,
      message: "Coach orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//upcoming sessions
exports.upcomingSessions = async (req, res) => {
  try {
    const userId = req.user._id; //login user-id
    const sessionBookingData = await sessionBookingModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
          sessionStatus: 0,
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "bookingId",
          foreignField: "_id",
          as: "orderDetails",
        },
      },
      {
        $match: {
          "orderDetails.paid": 1,
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          bookingId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          sessionStatus: 1,
          userTimeZone: "$userData.timeZone",
          coachData: {
            _id: "$coachData._id",
            name: "$coachData.name",
            image: "$coachData.image",
            gender: "$coachData.gender",
          },
          sessionData: {
            _id: "$sessionData._id",
            coachId: "$sessionData.coachId",
            title: "$sessionData.title",
            price: "$sessionData.price",
            type: "$sessionData.type",
            description: "$sessionData.description",
          },
        },
      },
      { $limit: 5 },
      { $sort: { sessionDateUpdated: 1 } },
    ]);

    const responce = {
      success: true,
      data: sessionBookingData,
      message: "Coach upcoming Sessions get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//file upload
exports.upReadMessageCount = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    let data = await chatMessageModel.countDocuments({
      $and: [
        {
          $or: [{ senderId: userId }, { receiverId: userId }],
        },
        {
          readByUser: 0,
        },
      ],
    });

    const response = {
      success: true,
      data,
      message: "coach unread message count retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
