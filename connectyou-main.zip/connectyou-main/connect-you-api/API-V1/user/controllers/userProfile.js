const mongoose = require("mongoose");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
const path = require("path");
const moment = require("moment-timezone");
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const userModel = require("../../../models/user");
const userAccDeleteModal = require("../../../models/userAccDelete");
const deviceModal = require("../../../models/webToken");
const booked_sessions = require("../../../models/booked_session");
const bookingModal = require("../../../models/booking");

const {
  GetUsersNotification,
  ReadNotification,
  CreatePasswordResetNotification,
  CreateNotification,
  CreateAdminLevelNotification,
  MarkAllAsRead,
} = require("../../../models/notificationModal");
const transportEmail = require("../../../lib/email");

const {
  fetchnotification_preferrences,
  addOrUpdatenotification_preferrences,
} = require("../../../models/notification_preferrence");
const CoachModel = require("../../../models/coach");
const {
  sendAccountDeletionEmail,
  passwordRecoveryUpdateEmail,
} = require("../../../utils/quickEmails");

//user profile
exports.profile = async (req, res) => {
  try {
    const userId = req.user._id; //login coach-id
    const userData = await userModel.find({ _id: userId });
    if (userData.length > 0) {
      let data = {
        _id: userData[0]._id,
        name: userData[0].name,
        email: userData[0].email,
        gender: userData[0].gender,
        image: userData[0].image,
        DOB: userData[0].DOB,
        createdAt: userData[0].createdAt,
        userName: userData[0].userName,
        emailVerified: userData[0].emailVerified,
        timeZone: userData[0].timeZone,
        userType: userData[0].userType,
        areas_of_interest: userData[0].areas_of_interest || [],
        country: userData[0].country,
        city: userData[0].city,
        fullAddress: userData[0].fullAddress,
        aboutMe: userData[0].aboutMe,
        occupation: userData[0].occupation,
        myDescription: userData[0].myDescription,
        lastName: userData[0].lastName,
      };
      const authToken = await jwt.sign(data, JWT_SECRET);
      data.token = authToken;
      const responce = {
        success: true,
        data,
        message: "User profile get successfully",
      };
      return res.status(200).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//user profile-update
exports.profileUpdate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    const updatedData = req.body;
    const imageFile = req.file;
    if (imageFile) {
      updatedData.image = imageFile.filename;
    } else {
      delete updatedData.image;
    }
    const userData = await userModel.findByIdAndUpdate(
      { _id: userId },
      { $set: updatedData },
      { new: true }
    );

    let data = {
      _id: userData._id,
      name: userData.name,
      email: userData.email,
      gender: userData.gender,
      DOB: userData.DOB,
      image: userData.image,
      createdAt: userData.createdAt,
      updatedAt: userData.updatedAt,
      userName: userData.userName,
      emailVerified: userData.emailVerified,
      timeZone: userData.timeZone,
      userType: userData.userType,
      areas_of_interest: userData.areas_of_interest,
      country: userData.country,
      city: userData.city,
      fullAddress: userData.fullAddress,
    };

    const authToken = await jwt.sign(data, JWT_SECRET);
    data.token = authToken;
    const responce = {
      success: true,
      data,
      message: "User profile updated successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//user password-update
exports.passwordUpdate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    const { old_password, new_password } = req.body;
    const bcryptPassword = await bcrypt.hash(new_password, 10);
    const userData = await userModel.find({ _id: userId });
    if (userData.length > 0) {
      const bcryptData = await bcrypt.compare(
        old_password,
        userData[0].password
      );
      if (!bcryptData) {
        return res.status(401).json({
          success: false,
          message: "Incorrect old password. Please try again.",
        });
      } else {
        await userModel.findByIdAndUpdate(
          { _id: userId },
          { $set: { password: bcryptPassword } },
          { new: true }
        );
        const responce = {
          success: true,
          message: "Password updated successfully",
        };
        res.status(200).json(responce);
        await passwordRecoveryUpdateEmail(
          `${userData[0].name} ${userData[0].lastName}`,
          userData[0].email
        );
        await CreatePasswordResetNotification({ user_id: userData[0]._id });
        return;
      }
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Email verification start
//send email on given mail for email verificaton
exports.sendEmail = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { timezone } = req.body;
    const userId = req.user._id; //login user-id
    const userData = await userModel.find({ _id: userId });
    if (userData.length > 0) {
      const otp = Math.floor(10000 + Math.random() * 90000);
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: userData[0].email,
        subject: "Email verificaton",
        template: "send-otp",
        context: {
          name: userData[0].name,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        console.log({ error });
        const responce = {
          success: false,
          message: "Something went wrong",
        };
        return res.status(500).json(responce);
      } else {
        const otpExpiry = moment()
          .tz("Asia/Kolkata")
          .add(5, "minutes")
          .format("YYYY-MM-DD HH:mm:ss");

        await userModel.findByIdAndUpdate(
          { _id: userData[0]._id },
          {
            $set: {
              otp: otp,
              otpType: "Email-verification",
              otpDate: otpExpiry,
            },
          }
        );
        const responce = {
          success: true,
          message: "Email send successfully",
        };
        return res.status(200).json(responce);
      }
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for email verificaton
exports.OTPverification = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { timezone, otp } = req.body;
    const userId = req.user._id; //login user-id
    const userData = await userModel.find({ _id: userId });
    if (userData.length > 0) {
      if (otp != userData[0].otp) {
        const responce = {
          success: false,
          message: "The OTP you entered is incorrect",
        };
        return res.status(403).json(responce);
      }
      const otpExpiryDate = moment(userData[0].otpDate).tz("Asia/Kolkata");
      const isOtpExpired = moment().tz("Asia/Kolkata").isAfter(otpExpiryDate);

      if (isOtpExpired) {
        const responce = {
          success: false,
          message: "OTP verification maximum time exceeded",
        };
        return res.status(401).json(responce);
      }
      await userModel.findByIdAndUpdate(
        { _id: userData[0]._id },
        {
          $set: {
            emailVerified: 1,
            otp: 0,
            otpType: "",
            otpDate: "",
          },
        }
      );
      const responce = {
        success: true,
        message: "Your email verified successfully",
      };
      await CreateNotification({
        user_id: userId,
        heading: "Email Verified !",
        description:
          "Your Email address has been verified successfully, Thank you !",
        url: "/u/profile",
        notification_type: "authentication",
      });
      return res.status(200).json(responce);
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach password-check for delete account
exports.accountDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { password, reason, message } = req.body;
    const userId = req.user._id; //login user-id
    const userData = await userModel.find({ _id: userId });
    if (userData.length > 0) {
      const bcryptData = await bcrypt.compare(password, userData[0].password);
      if (!bcryptData) {
        return res.status(401).json({
          success: false,
          message: "Incorrect old password. Please try again.",
        });
      } else {
        await new userAccDeleteModal({
          userId,
          reason,
          message,
        }).save();
        await userModel.findByIdAndUpdate(
          { _id: userId },
          { $set: { deleteReq: 2 } }
        );
        const responce = {
          success: true,
          message: "Account deleted successfully",
        };

        await sendAccountDeletionEmail(
          `${userData[0].name} ${userData[0].lastName}`,
          userData[0].email
        );
        await CreateAdminLevelNotification({
          heading: `${userData[0].name} ${userData[0].lastName} have just deleted their account !`,
          description: `A new Coachee have deleted their account, check details by clicking on the view button.`,
          url: `/coach/detail/${userData[0]._id}`,
          notification_type: "alerts",
        });
        return res.status(200).json(responce);
      }
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//add coachee device Tokan
exports.deviceTokanAdd = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { token, deviceId } = req.body;
    const userId = req.user._id; //login user-id
    await deviceModal.deleteMany({ deviceId });
    new deviceModal({
      userId,
      userType: "coachee",
      deviceId: deviceId,
      deviceToken: token,
    }).save();
    const responce = {
      success: true,
      message: "Data save successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//delete device Tokan
exports.unsubscibeWebPush = async (req, res) => {
  try {
    const { token, deviceId } = req.body;
    const userId = req.user._id; //login user-id
    await deviceModal.deleteMany({ deviceId });
    const response = {
      success: true,
      message: "Web Push Notification Unsubscribed.",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getAllNotifications = async (req, res) => {
  try {
    const { _id } = req.body;
    const page = req.query.page || 1;
    const limit = req.query.limit || 10;
    const filter = req.query.filter || 0;
    const notifications = await GetUsersNotification({
      _id,
      page,
      limit,
      filter,
    });

    if (!notifications.success) {
      return res
        .status(500)
        .json({ success: false, message: "Internal Server error" });
    } else {
      return res.status(200).json({
        success: true,
        message: "Fetched User's Notification",
        data: notifications.Notifications,
        totalPages: notifications.totalPages,
        unreadNotifications: notifications.unreadNotifications,
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.markAsRead = async (req, res) => {
  try {
    const { _id } = req.body;
    const Read = await ReadNotification({ _id });
    if (!Read.success) {
      return res.status(500).json({ success: false, message: Read.message });
    } else {
      return res.status(200).json({
        success: true,
        message: "Notifications marked as read",
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.ReadAll = async (req, res) => {
  try {
    const { _id } = req.body;
    const Read = await MarkAllAsRead({ entityId: _id });
    if (!Read.success) {
      return res.status(500).json({ success: false, message: Read.message });
    } else {
      return res.status(200).json({
        success: true,
        message: "All Notifications marked as read",
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getnotificationPrefs = async (req, res) => {
  try {
    const entityId = req.user._id;
    const fetchData = await fetchnotification_preferrences({ entityId });
    if (!fetchData.success) {
      return res.status(fetchData.status).json({
        success: fetchData.success,
        message: fetchData.message,
        data: fetchData.fetchData,
      });
    } else {
      return res.status(fetchData.status).json({
        success: fetchData.success,
        message: fetchData.message,
        data: fetchData.data,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.updatenotificationoPrefs = async (req, res) => {
  try {
    const preferrences = req.body.preferrences;
    const pauseAll = req.body.pauseAll;
    const entityId = req.user._id;
    const updatedData = await addOrUpdatenotification_preferrences({
      entityId,
      preferrences: preferrences,
      pauseAll,
    });
    if (!updatedData.success) {
      return res.status(updatedData.status).json({
        success: updatedData.success,
        message: updatedData.message,
        data: updatedData.fetchData,
      });
    } else {
      return res.status(updatedData.status).json({
        success: updatedData.success,
        message: updatedData.message,
        data: updatedData.data,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

//login coach
exports.updateSideNav = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id

    const coachData = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(coachId),
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);

    if (coachData.length > 0) {
      let data = {
        _id: coachData[0]._id,
        name: coachData[0].name,
        Lname: coachData[0].Lname,
        email: coachData[0].email,
        gender: coachData[0].gender,
        approve: coachData[0].approve,
        DOB: coachData[0].DOB,
        createdAt: coachData[0].createdAt,
        image: coachData[0].image,
        userName: coachData[0].userName,
        averageRating: coachData[0].averageRating,
        totalRatings: coachData[0].totalRatings,
        userType: "coach",
        timeZone: coachData[0].timeZone,
        my_invitation_code: coachData[0].my_invitation_code,
      };
      const responce = {
        success: true,
        data,
        message: "Coach login successfully",
      };
      return res.status(200).json(responce);
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.userBookedDate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(401).json(responce);
  }
  try {
    const userId = req.params.id;
    const { sessionDate, timeZone, coachId } = req.body;
    const selectedDate = moment(sessionDate, "DD-MM-YYYY").format("DD-MM-YYYY");
    const startOfDay = moment
      .tz(selectedDate, "DD-MM-YYYY HH:mm", timeZone)
      .subtract(1, "days") // 24 hours before the selected date
      .startOf("day")
      .utc()
      .toDate();

    const endOfDay = moment
      .tz(selectedDate, "DD-MM-YYYY HH:mm", timeZone)
      .add(1, "days") // 24 hours later the selected date
      .endOf("day")
      .utc()
      .toDate();

    // console.log("tocheck btween", selectedDate);
    const data = await bookingModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId), // Match by userId
          coachId: new mongoose.Types.ObjectId(coachId),
          paid: 1, // Ensure 'paid' field is 1
        },
      },
      {
        $lookup: {
          from: "booked_sessions", // The collection to join
          let: { bookingId: "$_id" }, // Define variable for `bookingId`
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$coachId", new mongoose.Types.ObjectId(coachId)] },
                    { $eq: ["$bookingId", "$$bookingId"] }, // Match with bookingId
                    { $eq: ["$sessionStatus", 0] }, // Match sessionStatus
                    { $gte: ["$sessionDateUpdated", startOfDay] }, // Match sessionDateUpdated >= startOfDay
                    { $lt: ["$sessionDateUpdated", endOfDay] }, // Match sessionDateUpdated < endOfDay
                  ],
                },
              },
            },
          ],
          as: "booked_session_data", // Output array field
        },
      },
      { $unwind: "$booked_session_data" }, // Unwind the array field
      {
        $project: {
          _id: 0, // Exclude _id from the output
          sessionDateUpdated: "$booked_session_data.sessionDateUpdated", // Include sessionDateUpdated
        },
      },
    ]);

    // const adata = await booked_sessions
    //   .find({
    //     userId: new mongoose.Types.ObjectId(userId),
    //     sessionStatus: 0,
    //     sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
    //   })
    //   .select("-_id sessionDateUpdated");
    // console.log({data});
    const bookedDate = data.flatMap((entry) => {
      const baseDate = moment(entry.sessionDateUpdated).tz(timeZone); // Ensure baseDate is in the correct time zone
      const selectedMoment = moment.tz(selectedDate, "DD-MM-YYYY", timeZone); // Parse selectedDate directly in the time zone

      let direction;
      const timeRanges = [];
      const currentHour = baseDate; // Extract the hour part of baseDate

      if (selectedMoment.isBefore(baseDate, "day")) {
        direction = "negative";
      } else if (selectedMoment.isAfter(baseDate, "day")) {
        direction = "positive";
      } else if (selectedMoment.isSame(baseDate, "day")) {
        direction = "same";
      }

      let startHour;
      let endHour;

      if (direction === "positive") {
        startHour = "00:00";
        endHour = currentHour.format("HH:mm");
      } else if (direction === "negative") {
        startHour = currentHour.format("HH:mm");
        endHour = "23:59";
      } else if (direction === "same") {
        startHour = "00:00";
        endHour = "23:59";
      }
      // console.log(startHour, endHour);
      const slots = generateTimeSlots(startHour, endHour, "00:00");
      // Generate time slots from startHour to endHour
      timeRanges.push(slots);
      // console.log("timeRanges", timeRanges);
      return timeRanges;
    });
    const returnData = bookedDate.flat() || [];
    // console.log("bookedDate", bookedDate);
    const responce = {
      success: true,
      data: returnData,
      message: "coach details retrieved successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

function generateTimeSlots(
  //this fun return an array of the slots in key and value form
  startTime,
  // can be passed as the initial time to start generating the aval slots with the provided gap between them
  endTime,
  // can be passed as the last time to start generating the aval slots with the provided gap between them
  slotGap
  // string in the form of minutes to be passed as gap between the two consequtive slots
  // the ffap should be passed as "hh:mm"
) {
  // Convert startTime and endTime to Date objects for easier manipulation

  const start = new Date();
  const end = new Date();

  // Parse the provided start and end times into hours and minutes
  const [startHour, startMinute] = startTime.split(":").map(Number);
  const [endHour, endMinute] = endTime.split(":").map(Number);

  // Set the start and end Date objects with parsed hours and minutes
  start.setHours(startHour, startMinute, 0, 0);
  end.setHours(endHour, endMinute, 0, 0);

  // If the date is today, ensure the start time is not before the current time

  // Parse the slot gap into hours and minutes
  const [gapHours, gapMinutes] = slotGap.split(":").map(Number);

  const slots = [];

  while (start < end) {
    // Calculate the slot's end time (1 hour duration)
    const slotEnd = new Date(start);
    slotEnd.setHours(start.getHours() + 1);

    // Only add the slot if the slot's end is within the range
    if (slotEnd <= end) {
      slots.push({
        from: start.toTimeString().slice(0, 5),
        to: slotEnd.toTimeString().slice(0, 5),
      });
    }

    // Move the start time forward by the gap duration
    start.setMinutes(start.getMinutes() + 60 + (gapHours * 60 + gapMinutes));
  }
  return slots;
}

exports.profileUpdateAddress = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const user = req.user._id; //login coach-id
    const { selectedAddress, city, country, lat, lng } = req.body;
    await userModel.findByIdAndUpdate(
      { _id: user },
      {
        $set: {
          city,
          country,
          fullAddress: selectedAddress,
          location: { type: "Point", coordinates: [lng, lat] },
        },
      },
      { new: true }
    );

    const response = {
      success: true,
      message: "Coachee profile updated successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getLiveStatuses = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      const error = new Error("Invalid URL");
      error.status = 400;
      throw error;
    }
    const _id = new mongoose.Types.ObjectId(id);
    const data = await CoachModel.find({ _id: _id }).select(
      "_id live lastSeen name Lname"
    );
    const response = {
      success: true,
      message: "Coach live status fetched",
      data: data[0],
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getMyProfile = async (req, res) => {
  try {
    const uId = req.user._id;
    const userId = new mongoose.Types.ObjectId(uId);
    const data = await userModel.findOne(
      {
        _id: userId,
      },
      `-password 
      -__v 
      -updatedAt 
      -block 
      -freeTrial 
      -approve 
      -delete 
      -deleteReq 
      -hub_spot_id 
      -block
      -delete
      -deleteReq
      -otp
      -otpType
      -otpDate 
      -emailVerified
      `
    );
    if (data) {
      return res.status(200).json({
        success: true,
        message: "Profile fetched successfully",
        data: data,
      });
    } else {
      return res.status(401).json({
        success: false,
        message: "Profile Not found, logout requested",
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: `Internal Server Error`,
    });
  }
};
