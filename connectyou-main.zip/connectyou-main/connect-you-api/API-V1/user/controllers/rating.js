const { validationResult } = require("express-validator");
require("dotenv").config();
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const userModel = require("../../../models/user");
const orderRatingModal = require("../../../models/orderRating");
const deviceModal = require("../../../models/webToken");
let admin = require("firebase-admin");
const {
  CreateNotification,
  CreateAdminLevelNotification,
} = require("../../../models/notificationModal");
const CoachModel = require("../../../models/coach");

//add rating on order
exports.orderRating = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const userId = req.user._id; //login user-id
    const { coachId, bookingId, ratingNumber, message, coachee_name } =
      req.body;
    const rating = await new orderRatingModal({
      coachId,
      userId,
      bookingId,
      ratingNumber,
      message,
    }).save();

    // const deviceData = await deviceModal
    //   .find({ userId: coachId, userType: "coach" })
    //   .select("deviceToken");
    // let registrationToken = deviceData.map((device) => device.deviceToken);
    // const notification = {
    //   notification: {
    //     title: "You have a new Review",
    //     body: `${capitalizeFirstLetter(
    //       coachee_name
    //     )} has added a review on your coach profile.`,
    //   },
    //   data: {
    //     url: `https://connectyou.global/coach/detail/${coachId}`,
    //   },
    //   tokens: registrationToken,
    // };
    // if (registrationToken.length > 0) {
    //   try {
    //     const response = await admin
    //       .messaging()
    //       .sendEachForMulticast(notification);
    //     console.log("Push Notification Sent Successfully", response);
    //   } catch (error) {
    //     console.log("error sending push notification for order:", error);
    //   }
    // }
    const coach = await CoachModel.findOne({ _id: coachId }).select("name");
    await Promise.all([
      CreateNotification({
        user_id: coachId,
        heading: `${capitalizeFirstLetter(
          coachee_name
        )} has added a review on your profile.`,
        description: `There is a new review on your profile added by ${capitalizeFirstLetter(
          coachee_name
        )},You can see details by clicking on the view button.`,
        url: `/coach/detail/${coachId}#rev-${rating._id}`,
        notification_type: "promotion",
      }),
      CreateAdminLevelNotification({
        url: `/coach/detail/${coachId}`,
        notification_type: "bookings",
        heading: `Coachee ${capitalizeFirstLetter(
          coachee_name
        )} have added a review.`,
        description: `Coachee ${capitalizeFirstLetter(
          coachee_name
        )} have added ${ratingNumber} stars and a review on ${
          coach.name
        }'s Profile, click on the view button to see more, `,
      }),
    ]);

    const responce = {
      success: true,
      message: "Rating submited successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

function capitalizeFirstLetter(str) {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}

//order details
exports.RecentRating = async (req, res) => {
  try {
    const ratingData = await orderRatingModal.aggregate([
      { $sort: { createdAt: -1 } },
      // { $limit: 10 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $project: {
          _id: 1,
          message: 1,
          createdAt: 1,
          ratingNumber: 1,
          Userid: "$userData._id",
          name: "$userData.name",
          image: "$userData.image",
          gender: "$userData.gender",
        },
      },
    ]);

    const responce = {
      success: true,
      data: ratingData,
      message: "Rating get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
