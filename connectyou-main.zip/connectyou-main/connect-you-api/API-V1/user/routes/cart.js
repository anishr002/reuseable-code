const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");
const moment = require("moment-timezone");
//import modals

//import controllers
const cartController = require("../controllers/cart");

//import middlewere

const Auth = require("../../../middleware/authTokenUser");
//order rating
router.post(
  "/add-session",
  [
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .isMongoId()
      .withMessage("Please enter valid coachId")
      .escape(),
    body("userId")
      .optional()
      .trim()
      .isMongoId()
      .withMessage("Please enter valid userId")
      .escape(),
    body("cartId")
      .trim()
      .isString()
      .notEmpty()
      .withMessage("Please enter cartId"),
    body("sessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter sessionId")
      .isMongoId()
      .withMessage("Please enter valid sessionId")
      .escape(),
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      }),
  ],
  cartController.addSession
);

router.post(
  "/list-session",
  [
    body("userId")
      .optional()
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .isMongoId()
      .withMessage("Please enter valid userId")
      .escape(),
    body("cartId")
      .trim()
      .isString()
      .withMessage("cartID must be a string")
      .notEmpty()
      .withMessage("Please enter cartId"),
  ],
  cartController.listSession
);
router.get("/remove-session/:id", cartController.removeSession);

router.post(
  "/cart-added-date",
  [
    body("userId")
      .optional()
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .isMongoId()
      .withMessage("Please enter valid userId")
      .escape(),
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .isMongoId()
      .withMessage("Please enter valid coachId")
      .escape(),
    body("cartId").trim().notEmpty().withMessage("Please enter cartId"),
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      }),
  ],
  cartController.cartDate
);

router.post(
  "/coach-cart-added-date-disabled",
  [
    body("userId")
      .optional()
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .isMongoId()
      .withMessage("Please enter valid userId")
      .escape(),
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .isMongoId()
      .withMessage("Please enter valid coachId")
      .escape(),
    body("cartId").trim().notEmpty().withMessage("Please enter cartId"),
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      }),
  ],
  cartController.DisabledcartDateForCoach
);
module.exports = router;
