const express = require("express");
const router = express.Router();
router.use(express.json());
const { param } = require("express-validator");
const controller = require("../controllers/resources");
const Auth = require("../../../middleware/authTokenUser");

router.get("/list-all-resources", Auth.authTokenUser, controller.ListResource);

router.get(
  "/resources/details/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invailid URL"),
  ],
  Auth.authTokenUser,
  controller.DetailsResource
);

module.exports = router;
