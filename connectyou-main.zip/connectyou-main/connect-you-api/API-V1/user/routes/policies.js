const express = require("express");
const router = express.Router();
router.use(express.json());

const controller = require("../../../Admin/controllers/policy");

router.get("/no-auth/list-all-terms-conditions", controller.listAllTerms);
router.get("/no-auth/list-all-privacy-policies", controller.listAllPolicies);
router.get("/no-auth/list-cookie-policy", controller.listCookiePolicies);


module.exports = router;
