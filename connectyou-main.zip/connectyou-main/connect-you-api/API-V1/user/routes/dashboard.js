const express = require("express");
const router = express.Router();
router.use(express.json());

//import modals

const Auth = require("../../../middleware/authTokenUser");
router.use(Auth.authTokenUser);
//import controllers
const dashboard = require("../controllers/dashboard");

router.get("/orderList", dashboard.orderList);
router.get("/completed-orderList", dashboard.completedOrdersList);
router.get("/last-order", dashboard.lastOrders);
router.get("/upcoming-sessions", dashboard.upcomingSessions);
router.get("/unread-count", dashboard.upReadMessageCount);

module.exports = router;
