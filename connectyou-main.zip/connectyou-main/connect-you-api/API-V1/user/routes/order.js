const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
let admin = require("firebase-admin");
const moment = require("moment-timezone");
// let serviceAccount = require("./web-push-notification-7401d-firebase-adminsdk-r5wza-1c4f2f3a5b.json");

//import modals
const orderModal = require("../../../models/booking");

//import controllers
const order = require("../controllers/order");

//import middlewere

const Auth = require("../../../middleware/authTokenUser");

router.use(Auth.authTokenUser);

//order list
router.get("/order-list", order.orderList);
router.get("/with-coach-order-list/:coachId", order.withCoachOrderList);
router.get("/order-details/:id", order.orderDetails);
router.get("/order-details/:id/:bookedSessionId", order.orderSessionDetails);

router.post(
  "/order-details/session-reschedule",
  [
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .escape(),
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("sessionDateOld")
      .trim()
      .notEmpty()
      .withMessage("Please enter sessionDateOld"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      })
      .customSanitizer((value, { req }) => {
        const { timeZone } = req.body;
        if (!moment.tz.zone(timeZone)) {
          throw new Error("Invalid time zone.");
        }
        return moment.tz(value, "DD-MM-YYYY HH:mm", timeZone).utc().toDate();
      }),
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .escape(),
    body("coachTimeZone")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachTimeZone"),
    body("message").optional().trim(),
  ],
  order.reSchedule
);

router.post(
  "/order-details/session-cancel",
  [
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .escape(),
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .escape(),
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("message").trim().notEmpty().withMessage("Please enter message"),
  ],
  order.sessionCancel
);

router.post(
  "/order-details/mark-session-incomplete",
  [
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("absentee")
      .trim()
      .notEmpty()
      .withMessage("Please enter reason for incompletion")
      .escape(),
    body("reasonForIncomplete").trim().optional(),
  ],
  order.sessionIncomplete
);

router.post(
  "/order-details/session-complete",
  [
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .escape(),
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .escape(),
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("message").trim().notEmpty().withMessage("Please enter message"),
  ],
  order.sessionComplete
);

router.get("/coach-list", order.coachList);

router.post("/send", async (req, res) => {
  const { title, body } = req.body;
  try {
    let registrationToken = [
      "fyGIpG37rS_kSdY0izpwts:APA91bEbxoH_mqvHKLlMc_5QpGJ-yq8Qwp74H98XgQlTK4rdeWOs26OkRryVq3oM8-Ln-mxcsE1ptsbRLAXLtN37SIQIhnh5I2sGKLSi_E7SYC5gjY2uk1UV8nDYpm08McazYyziF-Wo",
      "fyGIpG37rS_kSdY0izpwts:APA91bFctIOSNp2Yg6t2pdSBu5M3XLW62n3qjsUkxDR9amaqVonyXJwmpX2NM8rft9wbZ2Oel2QRFAeV4fb1Gpq8JhOkaN517eqElLlhdHB3HsPjz2I3AuzfKKyKJvQvr3I3pMvivIk1",
      "fyGIpG37rS_kSdY0izpwts:APA91bGiMTV_rCsOSKKd57qvERJCj-UOZPqMaPI0d4h1ELsMbrGlyATFtvtRs0uz9gn3yP1dLHaqp3H4vh8Wifi9Cy107swFg4wDQmoOwvM5BxusKr4oPBRSmDf6vYcAmmbWBUphvymu",
      "fyGIpG37rS_kSdY0izpwts:APA91bEfYPu_3MYdTrt6IdbOYgFe4tWwvsHXu9gtcBIzQe3HUSbBZ_P18oU9FrC99FMz5QedXUuIjHTagQ2TtIKx31042Ns6PqhanN-hvzDI0rAunO-NJpKzQ51SeWtguTlCLdGvmGpy",
      "fyGIpG37rS_kSdY0izpwts:APA91bFUkpTWehQtsZrn1dmR4xlhucbfL_sIYcrHZQ95L-qyu_hoK8CP0HZkoxVjzapteSOawe8bpSXhtEBVU3Za_QanNJvxEoDkLFmhirQ9FxGBYGe9xtqjQ0Gz7SVgcuJymhJPVVfA",
    ];
    const message = {
      notification: {
        title,
        body,
      },
      tokens: registrationToken,
    };

    try {
      // const response = await admin.messaging().send(message);
      const response = await admin.messaging().sendEachForMulticast(message);
      // console.log("Successfully push notification order:", response);
    } catch (error) {
      console.error("Error push notification order::", error.responses);
      res.send(error);
    }
  } catch (error) {
    console.log(error);
    res.send(error);
  }
});

router.get(
  "/refunds/refund-status/:booked_session_id",
  [
    param("booked_session_id")
      .trim()
      .notEmpty()
      .withMessage("Please enter booked_session_id")
      .isMongoId()
      .withMessage("Please enter a valid url"),
  ],
  order.refund_status
);

module.exports = router;
