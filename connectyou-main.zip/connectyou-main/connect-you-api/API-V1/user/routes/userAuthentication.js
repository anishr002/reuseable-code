const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");
router.use(express.json());
//import middlewere

const Auth = require("../../../middleware/authTokenUser");
//import modals
const userModel = require("../../../models/user");

//import controllers
const userAuthentication = require("../controllers/userAuthentication");
const { checkEmailOrUserName } = require("../../../lib/chackAvail");

router.get("/ping", userAuthentication.ping);
const verificationMiddlewar = require("../../../middleware/emailVerification");

//coach register
router.post(
  "/register",
  [
    body("name").trim().notEmpty().withMessage("Please enter name").escape(),
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        await checkEmailOrUserName({
          property: { email: value },
          message: "E-mail already exist",
        });
      }),
    body("userName")
      .trim()
      .notEmpty()
      .withMessage("Please enter userName")
      .escape()
      .custom(async (value) => {
        await checkEmailOrUserName({
          property: { userName: value },
          message: "User Name already exist",
        });
      }),
    body("password")
      .trim()
      .notEmpty()
      .withMessage("Please enter password")
      .isLength({ min: 8 })
      .withMessage("Password must be at least 8 characters long")
      // .matches(
      //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()\-_=+{};:,<.>]).+$/
      // )
      // .withMessage(
      //   "Password must include at least one lowercase letter, one uppercase letter, one number, and one special character"
      // )
      .escape(),
    // body("gender")
    //   .trim()
    //   .notEmpty()
    //   .withMessage("Please enter gender")
    //   .isIn(["Male", "Female", "Other"])
    //   .withMessage("Gender must be one of (Male, Female, Other)")
    //   .escape(),
    // body("DOB")
    //   .trim()
    //   .notEmpty()
    //   .withMessage("Please enter DOB")
    //   .isDate()
    //   .withMessage("Please enter valid DOB  (YYYY-MM-DD)")
    //   .escape(),
  ],
  userAuthentication.register
);

//coach login
router.post(
  "/login",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email or user name")
      .escape()
      .custom(async (value) => {
        const user = await userModel.find({
          $or: [{ email: value }, { userName: value }],
        });
        if (user.length == 0) {
          throw new Error("Invalid credentials");
        }
      }),
    body("password")
      .trim()
      .notEmpty()
      .withMessage("Please enter password")
      .escape(),
  ],
  verificationMiddlewar.CheckAccountVerifiedStatus,
  userAuthentication.login
);

//send email on given mail for password reset process
router.post(
  "/send-email-password-reset-process",
  Auth.authTokenUser,
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        const user = await userModel.find({ email: value });
        if (user.length == 0) {
          throw new Error("This email does not exist in our database");
        }
      }),
    body("timezone").trim().notEmpty().withMessage("Please enter timezone"),
  ],
  userAuthentication.sendEmail_passwordReset
);

//otp verification for password reset process
router.post(
  "/otp-verification-password-reset-process",
  Auth.authTokenUser,
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        const user = await userModel.find({ email: value });
        if (user.length == 0) {
          throw new Error("This email does not exist in our database");
        }
      }),
    body("timezone").trim().notEmpty().withMessage("Please enter timezone"),
    body("otp").trim().notEmpty().withMessage("Please enter otp").escape(),
    body("password")
      .trim()
      .notEmpty()
      .withMessage("Please enter password")
      .isLength({ min: 8 })
      .withMessage("Password must be at least 8 characters long")
      .escape(),
  ],
  userAuthentication.OTPverification_passwordReset
);

//forgot password process
//send otp in email
router.post(
  "/forgot-password-send-otp",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        const user = await userModel.find({ email: value });
        if (user.length == 0) {
          throw new Error("This email does not exist in our database");
        }
      }),

    body("timezone").trim().notEmpty().withMessage("Please enter timezone"),
  ],
  userAuthentication.forgotPasswordSendEmail
);
//forgot password process verify otp
router.post(
  "/forgot-password-verify-otp",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        const user = await userModel.find({ email: value });
        if (user.length == 0) {
          throw new Error("This email does not exist in our database");
        }
      }),
    body("otp").trim().notEmpty().withMessage("Please enter otp").escape(),
  ],
  userAuthentication.forgotPasswordOTPverification
);

//forgot password process updated password
router.post(
  "/forgot-password-update",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        const user = await userModel.find({ email: value });
        if (user.length == 0) {
          throw new Error("This email does not exist in our database");
        }
      }),
    body("password")
      .trim()
      .notEmpty()
      .withMessage("Please enter password")
      .escape(),
  ],
  userAuthentication.forgotPasswordNewPassword
);

module.exports = router;
