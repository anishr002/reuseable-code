const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");

//import modals

//import controllers
const ratingController = require("../controllers/rating");

//import middlewere

const Auth = require("../../../middleware/authTokenUser");

// router.use(Auth.authTokenUser);

//order rating
router.post(
  "/order-rating-submit",
  Auth.authTokenUser,
  [
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .isMongoId()
      .withMessage("Please enter valid coachId")
      .escape(),
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .isMongoId()
      .withMessage("Please enter valid bookingId")
      .escape(),
    body("ratingNumber")
      .trim()
      .notEmpty()
      .withMessage("Please enter ratingNumber")
      .isNumeric()
      .withMessage("Rating must be a number"),
    body("message").optional().trim(),
  ],
  ratingController.orderRating
);

router.get("/recent-rating", ratingController.RecentRating);
module.exports = router;
