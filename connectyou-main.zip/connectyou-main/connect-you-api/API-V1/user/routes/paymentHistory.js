const express = require("express");
const router = express.Router();
router.use(express.json());
const { param } = require("express-validator");

const Auth = require("../../../middleware/authTokenUser");
const controller = require("../controllers/paymentHistory");

router.use(Auth.authTokenUser);

router.get("/history/list-all/:userId", controller.get);

router.get(
  "/history/gen-rec/monthly/:userId/:month/:year",
  [
    param("month").trim().exists().withMessage("Please specify the month"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  controller.generateMonthlyRcpt
);

router.get(
  "/history/gen-rec/yearly/:userId/:year",
  [param("year").trim().exists().withMessage("Please specify the year")],
  controller.generateYearly
);

router.get(
  "/history/gen-rec/periodic/:userId/:from/:upto",
  [
    param("from")
      .trim()
      .exists()
      .withMessage("Please specify the range to start from."),
    param("upto")
      .trim()
      .exists()
      .withMessage("Please specify the range to end at."),
  ],
  controller.generatePeriodic
);

module.exports = router;
