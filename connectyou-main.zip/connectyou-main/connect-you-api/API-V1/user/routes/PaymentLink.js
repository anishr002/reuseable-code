const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");

//import controllers
const PaymentLink = require("../controllers/PaymentLink");

//import middlewere

const Auth = require("../../../middleware/authTokenUser");
const { default: mongoose } = require("mongoose");

router.use(Auth.authTokenUser);

// created payment session
router.post(
  "/create",
  [
    body("items")
      .isArray()
      .withMessage("items must be an array")
      .notEmpty()
      .withMessage("Items cannot be empty")
      .custom((items) => {
        items.forEach((item, index) => {
          // Validate that the IDs are valid MongoDB ObjectIds
          // if (!mongoose.Types.ObjectId.isValid(item.cartId)) {
          //   throw new Error(`Invalid cartId in item ${index + 1}`);
          // }
          if (!mongoose.Types.ObjectId.isValid(item.coachId)) {
            throw new Error(`Invalid coachId in item ${index + 1}`);
          }
          if (!mongoose.Types.ObjectId.isValid(item.sessionId)) {
            throw new Error(`Invalid sessionId in item ${index + 1}`);
          }
          // Validate the rest of the fields (non-ID fields)
          if (
            typeof item.stripePriceId !== "string" ||
            !item.stripePriceId.trim()
          ) {
            throw new Error(`stripePriceId is required in item ${index + 1}`);
          }

          if (
            typeof item.coachTimeZone !== "string" ||
            !item.coachTimeZone.trim()
          ) {
            throw new Error(`coachTimeZone is required in item ${index + 1}`);
          }
          if (typeof item.amount !== "number" || isNaN(item.amount)) {
            throw new Error(
              `amount is required and must be a valid number in item ${
                index + 1
              }`
            );
          }

          if (typeof item.sessionType !== "number" || isNaN(item.sessionType)) {
            throw new Error(
              `sessionType is required and must be a valid number in item ${
                index + 1
              }`
            );
          }
          if (
            typeof item.sessionDate !== "string" ||
            !item.sessionDate.trim()
          ) {
            throw new Error(`sessionDate is required in item ${index + 1}`);
          }

          // Optional: Add more validation for amount (e.g., check if it's a valid decimal)
          if (isNaN(parseFloat(item.amount))) {
            throw new Error(
              `amount must be a valid number in item ${index + 1}`
            );
          }

          // Optional: Check if sessionDate is a valid ISO8601 date
          if (
            !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|([+-])(\d{2}):(\d{2}))?$/.test(
              item.sessionDate
            )
          ) {
            throw new Error(
              `sessionDate must be a valid ISO 8601 date in item ${index + 1}`
            );
          }
        });
        return true;
      }),
  ],
  PaymentLink.create
);

module.exports = router;
