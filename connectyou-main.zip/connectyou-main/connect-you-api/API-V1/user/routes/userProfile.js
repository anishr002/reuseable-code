const moment = require("moment-timezone");
const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");

//import modals
const userModel = require("../../../models/user");

//import controllers
const userProfile = require("../controllers/userProfile");

//import middlewere

const Auth = require("../../../middleware/authTokenUser");
const { default: mongoose } = require("mongoose");
const {
  multerErrorHandler,
  uploadProfilePicture,
} = require("../../../middleware/uploader");

// router.use(Auth.authTokenUser);

//user profile
router.get("/profile", Auth.authTokenUser, userProfile.profile);
router.get("/token-verify", (req, res) => {
  return res.status(200).json({ message: "token verified" });
});

//user profile-update
router.post(
  "/profile-update",
  multerErrorHandler(uploadProfilePicture.single("image"), "5 MB"),
  [
    body("name").trim().optional().escape(),
    body("gender")
      .trim()
      .optional()
      .isIn(["Male", "Female", "Other"])
      .withMessage("Gender must be one of (Male, Female, Other)")
      .escape(),
    body("DOB")
      .trim()
      .optional()
      .isDate()
      .withMessage("Please enter valid DOB  (YYYY-MM-DD)")
      .escape(),
  ],
  Auth.authTokenUser,

  userProfile.profileUpdate
);
//user profile-update
router.post(
  "/profile-update-more",
  Auth.authTokenUser,
  userProfile.profileUpdate
);

//user password-update
router.post(
  "/password-update",
  [
    body("old_password")
      .trim()
      .notEmpty()
      .withMessage("Please enter old_password")
      .escape(),
    body("new_password")
      .trim()
      .notEmpty()
      .withMessage("Please enter new password")
      .isLength({ min: 8 })
      .withMessage("new password must be at least 8 characters long")
      .escape(),
  ],
  Auth.authTokenUser,

  userProfile.passwordUpdate
);

//send otp for email verification
router.post(
  "/send-email",
  [body("timezone").trim().notEmpty().withMessage("Please enter timezone")],
  Auth.authTokenUser,

  userProfile.sendEmail
);
//verify otp for email verification
router.post(
  "/otp-verification",
  [
    body("timezone").trim().notEmpty().withMessage("Please enter timezone"),
    body("otp").trim().notEmpty().withMessage("Please enter otp").escape(),
  ],
  Auth.authTokenUser,

  userProfile.OTPverification
);

//coach profile delete request
router.post(
  "/account-delete-request",
  [
    body("password").trim().notEmpty().withMessage("Please enter password"),
    body("reason")
      .notEmpty()
      .withMessage("Please enter reason")
      .isArray()
      .withMessage("Reason must be an array")
      .custom((value) => {
        if (value.length === 0) {
          throw new Error("Reason array cannot be empty");
        }
        value.forEach((reason, index) => {
          if (typeof reason !== "string" || !reason.trim()) {
            throw new Error(
              `Reason at index ${index} must be a non-empty string`
            );
          }
        });
        return true;
      }),
    body("message").trim().optional(),
  ],
  Auth.authTokenUser,

  userProfile.accountDelete
);

//add coach device Tokan
router.post(
  "/token-add",
  [
    body("deviceId").trim().notEmpty().withMessage("Please enter deviceId"),
    body("token").trim().notEmpty().withMessage("Please enter token"),
  ],
  Auth.authTokenUser,

  userProfile.deviceTokanAdd
);

router.post(
  "/unsubscribe-web-push-serv",
  Auth.authTokenUser,
  userProfile.unsubscibeWebPush
);
// new added for notifications of user
router.post(
  "/get-all-notifications",
  Auth.authTokenUser,
  userProfile.getAllNotifications
);
router.put(
  "/notification/mark-as-read",
  Auth.authTokenUser,
  userProfile.markAsRead
);
router.put(
  "/notification/mark-all-as-read",
  Auth.authTokenUser,
  userProfile.ReadAll
);

router.get(
  "/notification/get-preferrences",
  Auth.authTokenUser,
  userProfile.getnotificationPrefs
);
router.post(
  "/notification/update-preferrences",
  Auth.authTokenUser,
  userProfile.updatenotificationoPrefs
);

router.post(
  "/user-booked-date/:id",
  [
    param("id").trim().isMongoId().withMessage("Invalid url"),
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      }),
  ],
  userProfile.userBookedDate
);

router.post(
  "/profile-update-address",
  Auth.authTokenUser,
  userProfile.profileUpdateAddress
);
router.get(
  "/get-live-status/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Please enter a valid url")
      .isMongoId()
      .withMessage("Inavlid URL"),
  ],
  Auth.authTokenUser,
  userProfile.getLiveStatuses
);

router.get("/profile/data", Auth.authTokenUser, userProfile.getMyProfile);
module.exports = router;
