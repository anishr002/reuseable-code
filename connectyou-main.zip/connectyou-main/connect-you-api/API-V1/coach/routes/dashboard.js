const express = require("express");
const router = express.Router();
router.use(express.json());

//import modals

const Auth = require("../../../middleware/authTokenCoach");
router.use(Auth.authTokenCoach);
//import controllers
const dashboard = require("../controllers/dashboard");

router.get("/orderList", dashboard.orderList);
router.get("/completed-orderList", dashboard.completedOrdersList);
router.get("/last-order", dashboard.lastOrders);
router.get("/upcoming-sessions", dashboard.upcomingSessions);

module.exports = router;
