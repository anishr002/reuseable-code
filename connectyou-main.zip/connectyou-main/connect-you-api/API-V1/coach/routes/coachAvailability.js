const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const path = require("path");
//import controllers
const coachAvailability = require("../controllers/coachAvailability");

//import middlewere
const Auth = require("../../../middleware/authTokenCoach");

//add new session
router.post(
  "/coachAvailability-add",
  Auth.authTokenCoach,
  coachAvailability.AddcoachAvailability
);
router.get(
  "/coachAvailability-data",
  Auth.authTokenCoach,
  coachAvailability.getcoachAvailability
);
router.get(
  "/coachAvailability-data/:id",
  coachAvailability.getcoachAvailabilityOfCoach
);

module.exports = router;
