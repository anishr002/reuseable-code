const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const path = require("path");
const multer = require("multer");
//import modals
const coachSessionModal = require("../../../models/coachSession");

//import controllers
const coachSession = require("../controllers/Session");

//import middlewere
const Auth = require("../../../middleware/authTokenCoach");

//add new session
router.post(
  "/session-add",
  Auth.authTokenCoach,
  [
    body("title").trim().notEmpty().withMessage("Please enter title"),
    body("price")
      .trim()
      .notEmpty()
      .withMessage("Please enter price")
      .isFloat({ min: 0.5, max: 9999 })
      .withMessage("Price must be a positive number between 0.50 and 9999.")
      .escape(),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please enter description"),
    body("duration").trim().notEmpty().withMessage("Please enter description"),
  ],
  coachSession.AddSession
);
// session update
router.post(
  "/session-edit",
  Auth.authTokenCoach,
  [
    body("sessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter sessionId")
      .escape(),
    body("title").trim().notEmpty().withMessage("Please enter title"),
    body("price").trim().notEmpty().withMessage("Please enter price").escape(),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please enter description"),
    body("duration").trim().notEmpty().withMessage("Please enter description"),
  ],
  coachSession.EditSession
);
//delete session
router.get(
  "/session-delete/:id",
  Auth.authTokenCoach,
  coachSession.DeleteSession
);
//get the session list
router.get("/session-list", Auth.authTokenCoach, coachSession.ListSession);
router.get("/session-list-for-user/:id", coachSession.ListSessionForUser);
router.get("/session-details/:id/:coachId", coachSession.sessionDetails);

module.exports = router;
