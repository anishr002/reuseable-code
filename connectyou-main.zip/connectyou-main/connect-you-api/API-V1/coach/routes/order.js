const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");
const moment = require("moment-timezone");
//import modals
const orderModal = require("../../../models/booking");

//import controllers
const order = require("../controllers/order");

//import middlewere.

const Auth = require("../../../middleware/authTokenCoach");

router.get("/order-orderReminder", order.orderReminder);
//order list
router.get("/order-list", Auth.authTokenCoach, order.orderList);
router.get(
  "/with-coachee-order-list/:coacheeId",
  Auth.authTokenCoach,
  order.withCoacheeOrderList
);
router.get("/order-details/:id", Auth.authTokenCoach, order.orderDetails);
router.get(
  "/order-details/:id/:bookedSessionId",
  Auth.authTokenCoach,
  order.orderSessionDetails
);
router.post(
  "/order-details/session-reschedule",
  Auth.authTokenCoach,
  [
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .escape(),
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("sessionDateOld")
      .trim()
      .notEmpty()
      .withMessage("Please enter sessionDateOld"),
    body("coachTimeZone")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachTimeZone"),
    body("message").optional().trim(),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      })
      .customSanitizer((value, { req }) => {
        const { coachTimeZone } = req.body;
        if (!moment.tz.zone(coachTimeZone)) {
          throw new Error("Invalid time zone.");
        }
        return moment
          .tz(value, "DD-MM-YYYY HH:mm", coachTimeZone)
          .utc()
          .toDate();
      }),
    body("userId")
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .escape(),
  ],
  order.reSchedule
);

router.post(
  "/order-details/session-cancel",
  Auth.authTokenCoach,
  [
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .escape(),
    body("userId")
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .escape(),
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("message").trim().notEmpty().withMessage("Please enter message"),
  ],
  order.sessionCancel
);

router.post(
  "/order-details/mark-session-incomplete",
  Auth.authTokenCoach,
  [
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("absentee")
      .trim()
      .notEmpty()
      .withMessage("Please enter reason for incompletion")
      .escape(),
    body("reasonForIncomplete").trim().optional(),
  ],
  order.sessionIncomplete
);

router.post(
  "/order-details/session-complete",
  Auth.authTokenCoach,
  [
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .escape(),
    body("userId")
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .escape(),
    body("bookedSessionId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookedSessionId")
      .escape(),
    body("message").trim().notEmpty().withMessage("Please enter message"),
  ],
  order.sessionComplete
);

module.exports = router;
