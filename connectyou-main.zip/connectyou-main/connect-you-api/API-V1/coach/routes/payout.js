const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");

//import modals
const orderModal = require("../../../models/booking");

//import controllers
const payout = require("../controllers/payout");

//import middlewere

const Auth = require("../../../middleware/authTokenCoach");

router.use(Auth.authTokenCoach);

router.post(
  "/payout-amount-request",
  [
    body("Req_amount")
      .trim()
      .notEmpty()
      .withMessage("Please enter amount")
      .escape()
      .isFloat({ gt: 0 })
      .withMessage("Amount must be a number greater than 0")
      .custom((value) => {
        if (!/^\d+(\.\d{1,2})?$/.test(value)) {
          throw new Error(
            "Amount must be a valid number with up to two decimal places"
          );
        }
        return true;
      })
      .withMessage("Invalid amount format"),
  ],
  payout.payoutRequest
);

router.get("/payout-history", payout.payoutHistory);
router.get("/payout-requirement", payout.getMinimumReqAmount);

module.exports = router;
