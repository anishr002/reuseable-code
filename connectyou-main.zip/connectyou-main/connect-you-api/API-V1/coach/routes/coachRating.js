const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");

//import modals
const orderModal = require("../../../models/booking");

//import controllers
const rating = require("../controllers/rating");

//import middlewere

const Auth = require("../../../middleware/authTokenCoach");

router.get("/coach-rating-list/:id", rating.CoachRating);

router.get('/coach-rating-list-recent',rating.findRecent )



module.exports = router;