const express = require("express");
const router = express.Router();
router.use(express.json());
const { body } = require("express-validator");
const StripeManage = require("../controllers/StripeManage");
const Auth = require("../../../middleware/authTokenCoach");
router.use(Auth.authTokenCoach);

router.post(
  "/create-account",
  [
    body("code")
      .trim()
      .isString()
      .withMessage("Inavlid Country, Please contact support")
      .notEmpty()
      .withMessage("Please select a valid country from the options."),
    body("label")
      .trim()
      .isString()
      .withMessage("Inavlid Country, Please contact support")
      .notEmpty()
      .withMessage("Please select a valid country from the options."),
  ],
  StripeManage.createAccount
);

router.get("/revalidate-account", StripeManage.revalidateStripeDetails);
router.get("/refresh-account", StripeManage.refreshBankAndStripeAccount);
//get the account details
router.get("/account-details", StripeManage.accountDetails);
//get the account details
router.get("/account-details-update", StripeManage.updateAccountDetails);
//get the account bank list details
router.get("/account-bank-list", StripeManage.accountBankList);
//not use
router.get(
  "/stripe-account-onboarding-link",
  StripeManage.stripe_account_onboarding_link
);
//in use
router.get(
  "/stripe-account-onboarding",
  StripeManage.stripe_account_onboarding
);
router.get(
  "/account-management-session",
  StripeManage.account_management_Session
);

module.exports = router;
