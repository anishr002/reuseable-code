const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const moment = require("moment-timezone");
//import modals
const CoachModel = require("../../../models/coach");
//import controllers
const coachProfile = require("../controllers/coachProfile");

//import middlewere
const Auth = require("../../../middleware/authTokenCoach");
const { default: mongoose } = require("mongoose");
const {
  multerErrorHandler,
  uploadProfilePicture,
  uploadCredentials,
  certificateUpload,
  uploadCoachAgreement,
} = require("../../../middleware/uploader");

//coach profile
router.get("/profile", Auth.authTokenCoach, coachProfile.profile);
router.get("/updateSideNav", Auth.authTokenCoach, coachProfile.updateSideNav);
router.get("/token-verify", Auth.authTokenCoach, (req, res) => {
  return res.status(200).json({ message: "token verified" });
});

router.get("/coach-list", coachProfile.coachList);
router.get("/coach-list4", coachProfile.coachList4);

router.get(
  "/coach-details/:id",
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  coachProfile.coachDetails
);

router.post(
  "/coach-booked-date/:id",
  [
    param("id").trim().isMongoId().withMessage("Invalid url"),
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("userId")
      .optional()
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .isMongoId()
      .withMessage("Please enter valid userId"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      }),
  ],
  coachProfile.coachBookedDate
);
router.post(
  "/coach-booked-date-for-coach",
  Auth.authTokenCoach,
  [
    body("timeZone").trim().notEmpty().withMessage("Please enter timeZone"),
    body("userId")
      .trim()
      .notEmpty()
      .withMessage("Please enter userId")
      .isMongoId()
      .withMessage("Please enter valid userId"),
    body("sessionDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter a session date.")
      .custom((value) => {
        const parsedDate = moment(value, "DD-MM-YYYY HH:mm", true);
        if (!parsedDate.isValid()) {
          throw new Error(
            "Session date must be a valid date in the format DD-MM-YYYY HH:mm."
          );
        }
        return true;
      }),
  ],
  coachProfile.coachBookedDateForCoach
);

router.post(
  "/profile-update",
  Auth.authTokenCoach,
  multerErrorHandler(uploadProfilePicture.single("image"), "5 MB"),
  [
    body("name").trim().optional().escape(),
    body("Lname").trim().optional().escape(),
    body("gender")
      .trim()
      .optional()
      .isIn(["Male", "Female", "Other"])
      .withMessage("Gender must be one of (Male, Female, Other)")
      .escape(),
    body("DOB")
      .trim()
      .optional()
      .isDate()
      .withMessage("Please enter valid DOB  (YYYY-MM-DD)")
      .escape(),
  ],
  coachProfile.profileUpdate
);

router.post(
  "/profile-update-more",
  Auth.authTokenCoach,
  coachProfile.profileUpdateMore
);

router.post(
  "/profile-update-address",
  Auth.authTokenCoach,
  coachProfile.profileUpdateAddress
);

router.post(
  "/profile-update-coaching-credentials",
  Auth.authTokenCoach,
  multerErrorHandler(uploadCredentials.single("image"), "7 MB"),
  [
    body("title").trim().notEmpty().withMessage("Please enter title").escape(),
    body("endDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter the date of completion")
      .escape(),
  ],
  coachProfile.profileUpdateCoachCredentials
);

router.post(
  "/profile-update-free-trial",
  Auth.authTokenCoach,
  [
    body("freeTrial")
      .trim()
      .notEmpty()
      .withMessage("Please enter freeTrial")
      .escape(),
  ],
  coachProfile.profileUpdateFreeTriyl
);

//update-coaching-experience
router.post(
  "/profile-update-coaching-experience",
  Auth.authTokenCoach,
  [
    body("organization")
      .trim()
      .notEmpty()
      .withMessage("Please enter organization")
      .escape(),
    body("position")
      .trim()
      .notEmpty()
      .withMessage("Please enter position")
      .escape(),
    body("startDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter startDate")
      .escape(),
  ],
  coachProfile.profileUpdateCoachExperience
);

//education update
router.post(
  "/profile-update-coaching-education",
  Auth.authTokenCoach,
  [
    body("organization")
      .trim()
      .notEmpty()
      .withMessage("Please enter organization")
      .escape(),
    body("degree")
      .trim()
      .notEmpty()
      .withMessage("Please enter degree")
      .escape(),
    body("startDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter startDate")
      .escape(),
    body("endDate")
      .trim()
      .notEmpty()
      .withMessage("Please enter endDate")
      .escape(),
  ],
  coachProfile.profileUpdateCoachEducation
);

//update certificat
router.post(
  "/profile-update-certificate",
  multerErrorHandler(certificateUpload.single("certificateFile"), "7 MB"),
  Auth.authTokenCoach,
  [body("title").trim().notEmpty().withMessage("Please enter title").escape()],
  coachProfile.profileUpdateCertificate
);

//delete certificate
router.get(
  "/certificate-delete/:id",
  Auth.authTokenCoach,
  coachProfile.profileUpdateDeleteCertificate
);

//password update
router.post(
  "/password-update",
  Auth.authTokenCoach,
  [
    body("old_password")
      .trim()
      .notEmpty()
      .withMessage("Please enter old_password")
      .escape(),
    body("new_password")
      .trim()
      .notEmpty()
      .withMessage("Please enter new_password")
      .isLength({ min: 8 })
      .withMessage("new_password must be at least 8 characters long")
      .escape(),
  ],
  coachProfile.passwordUpdate
);

//delete Coaching Credentials
router.get(
  "/credentials-delete/:id",
  Auth.authTokenCoach,
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  coachProfile.coachCredentialsDelete
);

//delete Coaching Experience
router.get(
  "/experience-delete/:id",
  Auth.authTokenCoach,
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  coachProfile.coachExperienceDelete
);

//delete education
router.get(
  "/education-delete/:id",
  Auth.authTokenCoach,
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  coachProfile.coachEducationDelete
);

//calendar routes
router.get(
  "/get-calendar-url",
  Auth.authTokenCoach,
  coachProfile.googleCalandarURL
);

// redirect google calender url
router.get("/oauth2callback", coachProfile.oauth2callback);

//submit profile for review
router.get(
  "/profile-submit",
  Auth.authTokenCoach,
  coachProfile.profileSubmitForReview
);

//send email on given mail for email verificaton
router.post(
  "/send-email",
  Auth.authTokenCoach,
  [body("timezone").trim().notEmpty().withMessage("Please enter timezone")],
  coachProfile.sendEmail
);

//otp verification for email verificaton
router.post(
  "/otp-verification",
  Auth.authTokenCoach,
  [
    body("timezone").trim().notEmpty().withMessage("Please enter timezone"),
    body("otp").trim().notEmpty().withMessage("Please enter otp").escape(),
  ],
  coachProfile.OTPverification
);

//coach profile delete request
router.post(
  "/account-delete-request",
  Auth.authTokenCoach,
  [
    body("password").trim().notEmpty().withMessage("Please enter password"),
    body("reason")
      .notEmpty()
      .withMessage("Please enter reason")
      .isArray()
      .withMessage("Reason must be an array")
      .custom((value) => {
        if (value.length === 0) {
          throw new Error("Reason array cannot be empty");
        }
        value.forEach((reason, index) => {
          if (typeof reason !== "string" || !reason.trim()) {
            throw new Error(
              `Reason at index ${index} must be a non-empty string`
            );
          }
        });
        return true;
      }),
    body("message").trim().optional(),
  ],
  coachProfile.accountDelete
);

//add coach device Tokan
router.post(
  "/token-add",
  Auth.authTokenCoach,
  [
    body("deviceId").trim().notEmpty().withMessage("Please enter deviceId"),
    body("token").trim().notEmpty().withMessage("Please enter token"),
  ],
  coachProfile.deviceTokanAdd
);
//updated code

//ne wroute for deleteing the FCM token

router.post(
  "/unsubscribe-web-push-serv",
  Auth.authTokenCoach,
  coachProfile.unsubscibeWebPush
);

router.post(
  "/get-all-notifications",
  Auth.authTokenCoach,
  coachProfile.getAllNotifications
);
router.put(
  "/notification/mark-as-read",
  Auth.authTokenCoach,
  coachProfile.markAsRead
);

router.put(
  "/notification/mark-all-as-read",
  Auth.authTokenCoach,
  coachProfile.ReadAll
);

router.get(
  "/notification/get-preferrences",
  Auth.authTokenCoach,
  coachProfile.getnotificationPrefs
);

router.post(
  "/notification/update-preferrences",
  Auth.authTokenCoach,
  coachProfile.updatenotificationoPrefs
);

router.get(
  "/my-referrals/:id",
  Auth.authTokenCoach,
  coachProfile.getConncections
);

router.put(
  "/request-profile-approval/:id",
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  Auth.authTokenCoach,
  coachProfile.createNewApprovalReq
);

router.put(
  "/profile-completion-status-update",
  [body("coach_id").trim().isMongoId().withMessage("Please specify coach Id")],
  Auth.authTokenCoach,
  coachProfile.checkCompletionStatus
);

router.put(
  "/agreement/submit-signed-agreement",
  Auth.authTokenCoach,
  multerErrorHandler(uploadCoachAgreement.single("agreement_file"), "10 MB"),
  coachProfile.submitAgreement
);

router.get(
  "/agreement/agreement-status",
  Auth.authTokenCoach,
  coachProfile.CheckAgreementStatus
);

router.get(
  "/get-live-status/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Please enter a valid url")
      .isMongoId()
      .withMessage("Inavlid URL"),
  ],
  Auth.authTokenCoach,
  coachProfile.getLiveStatuses
);

router.get("/profile/data", Auth.authTokenCoach, coachProfile.getMyProfile);
module.exports = router;
