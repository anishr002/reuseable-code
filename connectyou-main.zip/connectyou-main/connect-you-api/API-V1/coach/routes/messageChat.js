const express = require("express");
const path = require("path");
const multer = require("multer");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");
//import modals
const orderModal = require("../../../models/booking");



//import controllers
const messageChat = require("../controllers/messageChat");

//import middlewere
const Auth = require("../../../middleware/authTokenCoach");
const { uploadChatFiles, multerErrorHandler } = require("../../../middleware/uploader");

router.get("/user-list", Auth.authTokenCoach, messageChat.userList);
router.get("/user-list2", Auth.authTokenCoach, messageChat.userList2);
router.get(
  "/unread-count",
  Auth.authTokenCoach,
  messageChat.upReadMessageCount
);
router.post("/message-file", multerErrorHandler(uploadChatFiles.array("files") , "20 MB"), messageChat.fileUpload);

module.exports = router;
