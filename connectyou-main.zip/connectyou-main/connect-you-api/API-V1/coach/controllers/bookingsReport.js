const xlsx = require("xlsx");
const path = require("path");
const puppeteer = require("puppeteer");

const moment = require("moment-timezone");
const mongoose = require("mongoose");

const { validationResult } = require("express-validator");
const BookingsModel = require("../../../models/booking");
const CoachModel = require("../../../models/coach");

exports.generateMonthly = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { coachId, month, year } = req.params;
    const filter = req.query; // 4 means all the session 0=pending / upcoming ,1=complited,2=cancel), 3 means not handled  or unhandled as well

    let matchCri = {
      coachId: new mongoose.Types.ObjectId(coachId),
      paid: 1,
    };

    const startOfMonth = moment(`${year}-${month}`, "YYYY-MMMM")
      .startOf("month")
      .startOf("day");

    const endOfMonth = moment(`${year}-${month}`, "YYYY-MMMM")
      .endOf("month")
      .endOf("day");

    matchCri.createdAt = {
      $gte: startOfMonth.toDate(),
      $lte: endOfMonth.toDate(),
    };

    let innerMatch = {
      coachId: new mongoose.Types.ObjectId(coachId),
    };
    if (filter.filter !== "all") {
      innerMatch.sessionStatus = returnNumber(filter.filter);
    }
    // console.log({
    //   innerMatch,
    // });
    const bookingsData = await BookingsModel.aggregate([
      { $match: matchCri },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "confirmed_session",
          pipeline: [
            {
              $match: innerMatch,
            },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "session_details",
              },
            },
            {
              $unwind: {
                path: "$session_details",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "user_details",
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$confirmed_session",
        },
      },
      {
        $project: {
          _id: 0,
          orderId: "$orderId",
          bookingDate: "$createdAt",
          transaction_id: "$TransactionID",
          customer_email: "$customer_email",
          customer_name: "$customer_name",
          sessionDate: "$confirmed_session.sessionDate",
          sessionStatus: "$confirmed_session.sessionStatus",
          title: "$confirmed_session.session_details.title",
          price: "$confirmed_session.session_details.price",
          user_name: {
            $arrayElemAt: ["$confirmed_session.user_details.name", 0],
          },
          user_email: {
            $arrayElemAt: ["$confirmed_session.user_details.email", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          bookingDate: 1,
          transaction_id: 1,
          customer_email: 1,
          customer_name: 1,
          sessionDate: 1,
          sessionStatus: 1,
          title: 1,
          price: 1,
          user_name: 1,
          user_email: 1,
          orderId: "$orderId",
        },
      },
      { $sort: { bookingDate: -1 } },
    ]);

    const userDetails = await CoachModel.findOne({ _id: coachId }).select(
      "name Lname email -_id"
    );
    // console.log(
    //   { bookingsData },
    //   { matchCri },
    //   { innerMatch },
    //   { userDetails }
    // );

    const report =
      bookingsData.length === 0
        ? ""
        : await generateExcelSheet({
            data: bookingsData,
            fileName: "Bookings_Report",
            coachDetails: {
              name: `${userDetails.name} ${userDetails.Lname}`,
              email: userDetails.email,
            },
          });

    const response = {
      success: true,
      data: bookingsData,
      report: report,
      noOrders: bookingsData.length === 0,
      message:
        "Coach bookings report retrieved successfully for the specified month",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generateYearly = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }

  try {
    const { coachId, year } = req.params;
    const filter = req.query;

    let matchCri = {
      coachId: new mongoose.Types.ObjectId(coachId),
      paid: 1,
    };

    const startOfYear = moment(`${year}-01`, "YYYY-MM")
      .startOf("year")
      .startOf("day");
    const endOfYear = moment(`${year}-12`, "YYYY-MM")
      .endOf("year")
      .endOf("day");

    matchCri.createdAt = {
      $gte: startOfYear.toDate(),
      $lte: endOfYear.toDate(),
    };
    let innerMatch = {
      coachId: new mongoose.Types.ObjectId(coachId),
    };
    if (filter.filter !== "all") {
      innerMatch.sessionStatus = returnNumber(filter.filter);
    }
    // console.log({
    //   innerMatch,
    // });

    const bookingsData = await BookingsModel.aggregate([
      { $match: matchCri },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "confirmed_session",
          pipeline: [
            {
              $match: innerMatch,
            },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "session_details",
              },
            },
            {
              $unwind: {
                path: "$session_details",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "user_details",
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$confirmed_session",
        },
      },
      {
        $project: {
          _id: 0,
          orderId: "$orderId",
          bookingDate: "$createdAt",
          transaction_id: "$TransactionID",
          customer_email: "$customer_email",
          customer_name: "$customer_name",
          sessionDate: "$confirmed_session.sessionDate",
          sessionStatus: "$confirmed_session.sessionStatus",
          title: "$confirmed_session.session_details.title",
          price: "$confirmed_session.session_details.price",
          user_name: {
            $arrayElemAt: ["$confirmed_session.user_details.name", 0],
          },
          user_email: {
            $arrayElemAt: ["$confirmed_session.user_details.email", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          bookingDate: 1,
          transaction_id: 1,
          customer_email: 1,
          customer_name: 1,
          sessionDate: 1,
          sessionStatus: 1,
          title: 1,
          price: 1,
          user_name: 1,
          user_email: 1,
          orderId: "$orderId",
        },
      },
      { $sort: { bookingDate: -1 } }, // Sort the results by booking creation date in descending order
    ]);

    const userDetails = await CoachModel.findOne({ _id: coachId }).select(
      "name Lname email -_id"
    );

    const report =
      bookingsData.length === 0
        ? ""
        : await generateExcelSheet({
            data: bookingsData,
            fileName: "Bookings_Report",
            coachDetails: {
              name: `${userDetails.name} ${userDetails.Lname}`,
              email: userDetails.email,
            },
          });

    const response = {
      success: true,
      data: bookingsData,
      report: report,
      noOrders: bookingsData.length === 0,
      message:
        "Coach bookings report retrieved successfully for the specified Year",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generatePeriodic = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { coachId, from, upto } = req.params;
    const filter = req.query;

    let matchCri = {
      coachId: new mongoose.Types.ObjectId(coachId),
      paid: 1,
    };

    const start = moment(`${from}`, "YYYY-MM-DD").startOf("day");
    const end = moment(`${upto}`, "YYYY-MM-DD").endOf("day");
    // console.log({ start, end });
    matchCri.createdAt = {
      $gte: start.toDate(),
      $lte: end.toDate(),
    };
    let innerMatch = {
      coachId: new mongoose.Types.ObjectId(coachId),
    };
    if (filter.filter !== "all") {
      innerMatch.sessionStatus = returnNumber(filter.filter);
    }
    // console.log({
    //   innerMatch,
    // });
    const bookingsData = await BookingsModel.aggregate([
      { $match: matchCri },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          as: "confirmed_session",
          pipeline: [
            {
              $match: innerMatch,
            },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "session_details",
              },
            },
            {
              $unwind: {
                path: "$session_details",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "user_details",
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$confirmed_session",
        },
      },
      {
        $project: {
          _id: 0,
          orderId: "$orderId",
          bookingDate: "$createdAt",
          transaction_id: "$TransactionID",
          customer_email: "$customer_email",
          customer_name: "$customer_name",
          sessionDate: "$confirmed_session.sessionDate",
          sessionStatus: "$confirmed_session.sessionStatus",
          title: "$confirmed_session.session_details.title",
          price: "$confirmed_session.session_details.price",
          user_name: {
            $arrayElemAt: ["$confirmed_session.user_details.name", 0],
          },
          user_email: {
            $arrayElemAt: ["$confirmed_session.user_details.email", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          bookingDate: 1,
          transaction_id: 1,
          customer_email: 1,
          customer_name: 1,
          sessionDate: 1,
          sessionStatus: 1,
          title: 1,
          price: 1,
          user_name: 1,
          user_email: 1,
          orderId: "$orderId",
        },
      },
      { $sort: { bookingDate: -1 } }, // Sort the results by booking creation date in descending order
    ]);

    const userDetails = await CoachModel.findOne({ _id: coachId }).select(
      "name Lname email -_id"
    );

    const report =
      bookingsData.length === 0
        ? ""
        : await generateExcelSheet({
            data: bookingsData,
            fileName: "Bookings_Report",
            coachDetails: {
              name: `${userDetails.name} ${userDetails.Lname}`,
              email: userDetails.email,
            },
          });

    const response = {
      success: true,
      data: bookingsData,
      report: report,
      noOrders: bookingsData.length === 0,
      message:
        "Coach bookings report retrieved successfully for the specified period",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const generateExcelSheet = async ({
  data,
  fileName = "Bookings_Report",
  coachDetails = { name: "Coach Name", email: "Coach Email" },
}) => {
  const uniqueFileName = `${Date.now()}_Coach_${fileName}.xlsx`;

  const filePath = path.resolve(
    __dirname,
    `../../../public/reports/${uniqueFileName}`
  );

  const headers = [
    "Order Id",
    "Transaction Id",
    "Customer Name",
    "Customer Email",
    "Session Title",
    "Session Price",
    "Session Date",
    "Session Status",
    "Booking Date",
    "Coachee Name",
    "Coachee Email",
  ];

  // Prepare rows
  const rows = data.map((entry) => ({
    "Order Id": entry.orderId || "--",
    "Transaction Id": entry.transaction_id || "--",
    "Customer Name": entry.customer_name || "--",
    "Customer Email": entry.customer_email || "--",
    "Session Title": entry.title || "--",
    "Session Price": entry.price || 0,
    "Session Date": entry.sessionDate
      ? new Date(entry.sessionDate).toLocaleDateString()
      : "--",
    "Session Status":
      (entry.sessionStatus === 1 && "Completed") ||
      (entry.sessionStatus === 0 && "Upcoming") ||
      (entry.sessionStatus === 2 && "canceled") ||
      (entry.sessionStatus === 3 && "Pending-Confirmation") ||
      "--",
    "Booking Date": entry.bookingDate
      ? new Date(entry.bookingDate).toLocaleDateString()
      : "--",
    "Coachee Name": entry.user_name || "--",
    "Coachee Email": entry.user_email || "--",
  }));

  // Calculate total revenue
  const totalRevenue = rows.reduce(
    (sum, row) => sum + (row["Session Price"] || 0),
    0
  );

  // Create the workbook and worksheet
  const workbook = xlsx.utils.book_new();
  const worksheet = xlsx.utils.json_to_sheet([], { skipHeader: true });

  // Add the top row for Coach details
  const coachName = `Coach Name: ${coachDetails.name}`;
  const coachEmail = `Coach Email: ${coachDetails.email}`;

  // Merge cells to create a table-like layout for coach details
  worksheet["A1"] = { v: coachName, t: "s" }; // First cell for Coach Name
  worksheet["G1"] = { v: coachEmail, t: "s" }; // First cell for Coach Email
  worksheet["!merges"] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } }, // Merge cells for Coach Name
    { s: { r: 0, c: 6 }, e: { r: 0, c: 10 } }, // Merge cells for Coach Email
  ];

  // Add an empty row for separation
  worksheet["A2"] = { v: "", t: "s" };

  // Add the headers row
  xlsx.utils.sheet_add_aoa(worksheet, [headers], { origin: "A3" });

  // Add the data rows
  xlsx.utils.sheet_add_json(worksheet, rows, {
    origin: "A4",
    skipHeader: true,
  });

  // Add total revenue at the end
  const totalRevenueRow = [
    "",
    "",
    "",
    "",
    "Total Revenue",
    totalRevenue,
    "",
    "",
    "",
    "",
    "",
  ];
  xlsx.utils.sheet_add_aoa(worksheet, [totalRevenueRow], {
    origin: `A${rows.length + 5}`,
  });

  // Append the worksheet to the workbook
  xlsx.utils.book_append_sheet(workbook, worksheet, "Bookings");

  // Write the workbook to the file system
  xlsx.writeFile(workbook, filePath);

  return uniqueFileName;
};
const returnNumber = (filter) => {
  switch (filter) {
    case "upcoming":
      return 0;
    case "completed":
      return 1;
    case "canceled":
      return 2;
    default:
      return 0;
  }
};
