const xlsx = require("xlsx");
const path = require("path");
const puppeteer = require("puppeteer");

const moment = require("moment-timezone");
const mongoose = require("mongoose");

const { validationResult } = require("express-validator");
const createdModal = require("../../../models/coachPayout");
const CoachModel = require("../../../models/coach");

exports.generateMonthlyRcpt = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { coachId, month, year } = req.params;
    let matchCri = {
      coachId: new mongoose.Types.ObjectId(coachId),
      status: 1,
    };
    const startOfMonth = moment(`${year}-${month}`, "YYYY-MMMM")
      .startOf("month")
      .startOf("day");

    const endOfMonth = moment(`${year}-${month}`, "YYYY-MMMM")
      .endOf("month")
      .endOf("day");

    matchCri.createdAt = {
      $gte: startOfMonth.toDate(),
      $lte: endOfMonth.toDate(),
    };

    const payoutData = await createdModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
    ]);
    const userDetails = await CoachModel.findOne({ _id: coachId });
    const receipt =
      payoutData.length === 0
        ? ""
        : await generateInvoice({
            customerEmail: userDetails.email,
            customerName: `${userDetails.name} ${userDetails.Lname}`,
            transactions: payoutData,
            period: `For the month ${String(month)?.toUpperCase()} - ${year}`,
            address: userDetails.fullAddress,
          });

    const response = {
      success: true,
      data: payoutData,
      receipt: receipt,
      noOrders: payoutData.length === 0,
      message: "Coach payouts retrieved successfully for the specified month",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generateYearly = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }

  try {
    const { coachId, year } = req.params;

    let matchCri = {
      coachId: new mongoose.Types.ObjectId(coachId),
      status: 1,
    };
    const startOfYear = moment(`${year}-01`, "YYYY-MM")
      .startOf("year")
      .startOf("day");
    const endOfYear = moment(`${year}-12`, "YYYY-MM")
      .endOf("year")
      .endOf("day");

    matchCri.createdAt = {
      $gte: startOfYear.toDate(),
      $lte: endOfYear.toDate(),
    };

    const payoutData = await createdModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
    ]);
    const userDetails = await CoachModel.findOne({ _id: coachId });
    const receipt =
      payoutData.length === 0
        ? ""
        : await generateInvoice({
            customerEmail: userDetails.email,
            customerName: `${userDetails.name} ${userDetails.Lname}`,
            transactions: payoutData,
            period: `For Jan to Dec ${year}`,
            address: userDetails.fullAddress,
          });
    const response = {
      success: true,
      data: payoutData,
      receipt: receipt,
      noOrders: payoutData.length === 0,
      message: "Coach payouts retrieved successfully for the specified year",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.generatePeriodic = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { coachId, from, upto } = req.params;
    let matchCri = {
      coachId: new mongoose.Types.ObjectId(coachId),
      status: 1,
    };
    // console.log({ coachId, from, upto });
    const start = moment(`${from}`, "YYYY-MM-DD").startOf("day");
    const end = moment(`${upto}`, "YYYY-MM-DD").endOf("day");
    matchCri.createdAt = {
      $gte: start.toDate(),
      $lte: end.toDate(),
    };
    // console.log({ q: matchCri.createdAt });

    const payoutData = await createdModal.aggregate([
      {
        $match: matchCri,
      },
      { $sort: { createdAt: -1 } },
    ]);
    const userDetails = await CoachModel.findOne({ _id: coachId });
    const receipt =
      payoutData.length === 0
        ? ""
        : await generateInvoice({
            address: userDetails.fullAddress,
            customerEmail: userDetails.email,
            customerName: `${userDetails.name} ${userDetails.Lname}`,
            transactions: payoutData,
            period: `${String(from)?.toLocaleUpperCase()} to ${String(
              upto
            )?.toLocaleUpperCase()}`,
          });
    const response = {
      success: true,
      data: payoutData,
      receipt: receipt,
      noOrders: payoutData.length === 0,
      message: "Coach payouts retrieved successfully for the specified month",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const generateInvoice = async ({
  customerName,
  customerEmail,
  transactions,
  period,
  address,
}) => {
  const date = new Date().toLocaleDateString();
  let transactionRows = "";
  let invoice_number = "";
  let totalAmount = 0;
  transactions.forEach((transaction, index) => {
    const approvedDate = transaction.updatedAt
      ? moment(transaction.updatedAt).format("MMMM-DD-YYYY hh:mm A")
      : "-";
    const requestedDate = transaction.createdAt
      ? moment(transaction.createdAt).format("MMMM-DD-YYYY hh:mm A")
      : "-";
    const amount = (transaction.amount / 100).toFixed(2);
    const transactionId = transaction.transactionId;
    totalAmount += parseFloat(amount);
    transactionRows += `
      <tr style="border-bottom: 1px solid #e0e0e0;">
        <td style="padding: 12px 10px;">${index + 1}</td>
        <td style="padding: 12px 10px;">$${amount}</td>
        <td style="padding: 12px 10px;">${transactionId}</td>
        <td style="padding: 12px 10px;">${requestedDate}</td>
        <td style="padding: 12px 10px; text-align: right;">${approvedDate}</td>
      </tr>
    `;
  });

  const htmlTemplate = `<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment Confirmation</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <!-- Fallback font styles embedded for email clients that don't support web fonts -->
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap");
      
      /* PDF-specific styles to ensure proper page breaks */
      @media print {
        table {
          page-break-inside: auto;
        }
        
        tr {
          page-break-inside: auto !important;
          page-break-after: auto;
        }
        
        td, th {
          page-break-inside: auto !important;
        }
        
        thead {
          display: table-header-group;
        }
        
        tfoot {
          display: table-footer-group;
        }
      }
    </style>
  </head>
  <body
    style="
      margin: 0;
      padding: 0;
      font-family: 'Quicksand', 'Helvetica Neue', Helvetica, Arial, sans-serif;
      color: #333;
      line-height: 1.6;
      background-color: #ffffff !important;
      width: 800px;
      margin: 0 auto;
    "
  >
    <table
      cellpadding="0"
      cellspacing="0"
      border="0"
      style="width: 100%; background-color: #ffffff"
    >
      <tr>
        <td>
          <!-- MAIN EMAIL CONTAINER -->
          <table
            cellpadding="0"
            cellspacing="0"
            border="0"
            style="width: 100%; margin: 0 auto;"
          >
            <!-- HEADER - Extends full width -->

            <!-- Invoice Header Starts -->
            <tr>
              <td style="padding: 0">
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; position: relative"
                >
                  <!-- Invoice Number Top-Right -->
                  <tr>
                    <td style="padding: 0; position: relative">
                      <!-- Centered Logo -->
                      <table width="100%">
                        <tr>
                          <td
                            style="
                              background-color: #ffffff;
                              padding: 40px 0;
                              text-align: center;
                            "
                          >
                            <img
                              src="https://api.connectyou.global/logo/loginLogo.png"
                              alt="ConnectYou.Global Logo"
                              style="max-width: 280px; height: auto"
                            />
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Hero Header -->
                  <tr>
                    <td style="padding: 0">
                      <table
                        cellpadding="20"
                        cellspacing="0"
                        border="0"
                        style="width: 100%"
                      >
                        <tr>
                          <td
                            style="
                              background: linear-gradient(
                                135deg,
                                #013338 0%,
                                #025e5a 100%
                              );
                              padding: 10px 70px;
                              text-align: center;
                            "
                          >
                            <h1
                              style="
                                color: #ffffff;
                                margin: 0;
                                font-size: 28px;
                                font-weight: 700;
                                letter-spacing: 0.5px;
                              "
                            >
                              Payout Receipt
                            </h1>
                            <p
                              style="
                                color: #ebbd33;
                                margin: 10px 0 0 0;
                                font-size: 18px;
                                font-weight: 400;
                                letter-spacing: 0.3px;
                              "
                            >
                              Thank you for choosing ConnectYou.Global
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Powered by -->
                  <tr>
                    <td
                      style="
                        background-color: #f5fafa;
                        padding: 8px 40px;
                        text-align: center;
                      "
                    >
                      <p style="margin: 0; font-size: 14px; color: #013338">
                        Powered by Erickson Coaching International
                      </p>
                    </td>
                  </tr>

                  <!-- Split: Issued To / Details -->
                  <tr>
                    <td
                      style="background-color: #ffffff; padding: 25px 40px 10px"
                    >
                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <!-- Issued To -->
                          <td width="50%" style="vertical-align: top">
                            <h3
                              style="
                                margin: 0 0 8px 0;
                                color: #013338;
                                font-size: 18px;
                              "
                            >
                              Issued To:
                            </h3>
                            <p style="margin: 0; color: #444; font-size: 14px">
                              ${customerName}<br />
                              ${customerEmail}<br />
                              ${address}<br />
                            </p>
                          </td>
                          <!-- Transaction Info -->
                          <td
                            width="50%"
                            style="text-align: right; vertical-align: top"
                          >
                            <table align="right">
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Invoice No. :
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${invoice_number}
                                </td>
                              </tr>
                              <tr></tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Date Issued:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${date}
                                </td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                 Transaction Period : 
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${period}
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- HEADER - Extends full width -->
            <!-- MAIN CONTENT AREA -->
            <!-- Main Content / Booking Table -->
            <tr>
              <td style="padding: 30px 40px; background-color: #ffffff">
                <h2
                  style="margin-bottom: 20px; color: #013338; font-size: 20px"
                >
                  Payment details
                </h2>
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; border-collapse: collapse; page-break-after: auto; page-break-before: auto; page-break-inside: auto;"
                >
                  <thead>
                    <tr
                      style="
                        background-color: #f5fafa;
                        border-bottom: 1px solid #e0e0e0;
                      "
                    >
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Sr. No
                      </th>
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Amount
                      </th>
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        TransactionID
                      </th>
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Requested On
                      </th>
                      <th
                        style="
                          text-align: right;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Approved On
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    ${transactionRows}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td
                        colspan="4"
                        style="
                          padding: 12px 10px;
                          text-align: right;
                          font-size: 15px;
                          font-weight: 600;
                          color: #013338;
                          border-top: 2px solid #025e5a;
                        "
                      >
                        Total
                      </td>
                      <td
                        style="
                          padding: 12px 10px;
                          text-align: right;
                          font-size: 15px;
                          font-weight: 600;
                          color: #013338;
                          border-top: 2px solid #025e5a;
                        "
                      >
                        $${totalAmount.toFixed(2)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </td>
            </tr>

            <!-- MAIN CONTENT AREA -->
            <!-- FOOTER - Extends full width -->
            <tr>
              <td
                style="
                  background-color: #013338;
                  padding: 0;
                  width: 100%;
                "
              >
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%"
                >
                  <!-- Company Info -->
                  <tr>
                    <td style="padding: 30px 40px 10px; text-align: center">
                      <table
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                        style="margin: 0 auto; text-align: center"
                      >
                        <tr>
                          <td
                            style="
                              padding: 8px 0;
                              color: white;
                              font-size: 14px;
                              font-style: italic;
                            "
                          >
                            Warm regards,
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 5px 0;
                              color: #ffffff;
                              font-size: 16px;
                              font-weight: bold;
                            "
                          >
                            Erickson Coaching International
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: white;
                              font-size: 13px;
                            "
                          >
                            Founders of ConnectYou
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: #78a5a4;
                              font-size: 12px;
                            "
                          >
                            www.connectyou.global | support@connectyou.com
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Invoice Info -->
                  <!-- Disclaimer -->
                  <tr>
                    <td
                      style="
                        padding: 15px 40px;
                        text-align: center;
                        background-color: #002326;
                      "
                    >
                      <p
                        style="
                          margin: 0;
                          color: #5f8886;
                          font-size: 12px;
                          line-height: 1.6;
                        "
                      >
                        This receipt has been issued for your records. Please
                        retain a copy for personal or business accounting. If
                        you have any questions regarding this invoice, feel free
                        to
                        <a
                          href="https://connectyou.global/get-in-touch"
                          style="color: #3aa7a3; text-decoration: none"
                          >contact us</a
                        >
                        or email us at
                        <a
                          href="mailto:support@connectyou.com"
                          style="color: #3aa7a3; text-decoration: none"
                          >support@connectyou.com</a
                        >. <br /><br />
                        Please note: This is a system-generated receipt. All
                        amounts are inclusive of applicable taxes unless
                        otherwise stated.
                      </p>
                    </td>
                  </tr>
                  <!-- Copyright -->
                  <tr>
                    <td style="padding: 10px 40px 25px; text-align: center">
                      <p style="margin: 0; color: #78a5a4; font-size: 13px">
                        &copy; 2024 ConnectYou.Global. All rights reserved.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- FOOTER - Extends full width -->
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
`;

  let browser;
  if (process.env.BACKEND_URL === "http://localhost:7000") {
    browser = await puppeteer.launch();
  } else {
    browser = await puppeteer.launch({
      executablePath: "/usr/bin/chromium-browser",
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
  }
  const page = await browser.newPage();

  await page.setContent(htmlTemplate, { waitUntil: "networkidle0" });

  const pdfPath = `${Date.now()}_transaction_receipt_${customerName}.pdf`;

  const publicDir = path.resolve(__dirname, "../../../public");

  await page.pdf({
    path: path.join(publicDir, "receipt", pdfPath),
    format: "A4",
    printBackground: true,
    margin: {
      top: "10mm",
      bottom: "10mm",
      left: "10mm",
      right: "10mm",
    },
  });

  await browser.close();

  return pdfPath;
};
