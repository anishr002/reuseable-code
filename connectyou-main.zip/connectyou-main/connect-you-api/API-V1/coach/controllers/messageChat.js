const mongoose = require("mongoose");
const chatRoomModel = require("../../../models/Chatroom");
const chatmessageModel = require("../../../models/chatMessage");
const userModle = require("../../../models/user");
const orderModal = require("../../../models/booking");
const { validationResult } = require("express-validator");

exports.joinroom = async (data, socket, io) => {
  try {
    const userData = socket.request.userData; //token data
    const senderId = userData._id; //user _id
    const receiverId = data.receiverId;
    // console.log({
    //   senderId,
    //   receiverId,
    //   data,
    // });
    let and1 = [];
    let and2 = [];
    if (senderId) {
      and1.push({ userId1: senderId });
      and2.push({ userId2: senderId });
    }
    if (receiverId) {
      and1.push({ userId2: receiverId });
      and2.push({ userId1: receiverId });
    }
    let orConditions = [];
    if (and1.length > 0) {
      orConditions.push({ $and: and1 });
    }
    if (and2.length > 0) {
      orConditions.push({ $and: and2 });
    }

    if (senderId && receiverId) {
      orConditions = [
        { $and: [{ userId1: senderId }, { userId2: receiverId }] },
        { $and: [{ userId2: senderId }, { userId1: receiverId }] },
      ];
    }
    // console.log({ orConditions });

    const chatRoomData = await chatRoomModel.find({
      $or: orConditions,
    });
    let chatRoomId;
    if (chatRoomData.length > 0) {
      chatRoomId = chatRoomData[0]._id;
    } else {
      const saveData = new chatRoomModel({
        userId1: senderId,
        userId2: receiverId,
      });
      let SaveData = await saveData.save();
      chatRoomId = SaveData._id;
    }
    //join the room
    chatRoomId = chatRoomId.toString();
    socket.join(chatRoomId);
    let updateData = {};
    if (userData.userType == "coach") {
      // updateData.readByCoach = 1;
      // updateData.messageReadStatusCoach = "read";
    }
    if (userData.userType == "coachee") {
      // updateData.readByUser = 1;
      // updateData.messageReadStatusUser = "read";
    }
    await chatmessageModel.updateMany(
      {
        chatRoomId: chatRoomId,
      },
      {
        $set: updateData,
      }
    );
    let messageData = await chatmessageModel.find({ chatRoomId: chatRoomId });
    io.emit("new-message", {
      message: "New User joined the chat room !",
    });
    const responce = {
      success: true,
      messageData,
      chatRoomId,
      message: "Data get successfully",
    };
    return io.to(chatRoomId).emit("join-room", responce);
  } catch (error) {
    console.log(error);
  }
};

exports.sendMessage = async (data, socket, io) => {
  try {
    const userData = socket.request.userData; //token data
    const senderId = userData._id; //user _id
    const receiverId = data.receiverId;
    const user = await getEntityAndData(receiverId);
    // console.log({
    //   userData,
    //   senderId,
    //   receiverId,
    //   user,
    // });
    const chatRoomId = data.chatRoomId;
    const chatMsg = data.message;
    const files = data.files;
    const readByCoach = data.readByCoach;
    const readByUser = data.readByUser;
    let insertData = {
      senderId: senderId,
      receiverId: receiverId,
      chatRoomId: chatRoomId,
      message: chatMsg,
      files: files,
    };
    if (userData.userType === "coach") {
      insertData.messageReadStatusCoach = "read";
    } else if (userData.userType === "coachee") {
      insertData.messageReadStatusUser = "read";
    }
    if (user && user.data) {
      if (user.data.userType === "coach") {
        if (user.data.live === 1) {
          insertData.messageReadStatusCoach = "delivered";
        } else {
          insertData.messageReadStatusCoach = "sent";
        }
      } else if (user.data.userType === "coachee" && user.data.live === 1) {
        if (user.data.live === 1) {
          insertData.messageReadStatusUser = "delivered";
        } else {
          insertData.messageReadStatusUser = "sent";
        }
      }
    }
    if (readByCoach) {
      insertData.readByCoach = readByCoach;
    }
    if (readByUser) {
      insertData.readByUser = readByUser;
    }
    const saveData = new chatmessageModel(insertData);
    let SaveData = await saveData.save();
    socket.join(chatRoomId);
    const sender = await getSenderDetails({ senderId });
    const responce = { data: SaveData, message: "Data get successfully" };
    // io.emit("new-message", { message: "A new message has been posted!" });
    socket.to(receiverId).emit("got-new-message", {
      senderId: sender._id,
      message: SaveData.message,
      image: sender.image,
      from: `${sender.name} ${
        sender.Lname ? sender.Lname : sender.lastName ? sender.lastName : ""
      }`,
    });
    return io.to(chatRoomId).emit("receive-message", responce);
  } catch (error) {
    console.log(error);
  }
};

exports.coachInbox = async (data, socket, io) => {
  try {
    const userData = socket.request.userData; //token data
    const coachId = userData._id; //user _id
    const userList = await orderModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
          pipeline: [
            {
              $lookup: {
                from: "chatmessages",
                let: { id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$senderId", "$$id"] },
                              {
                                $eq: [
                                  "$receiverId",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$receiverId", "$$id"] },
                              {
                                $eq: [
                                  "$senderId",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  {
                    $sort: { createdAt: -1 },
                  },
                ],
                as: "chatmessages",
              },
            },
            {
              $lookup: {
                from: "chatrooms",
                let: { id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$userId1", "$$id"] },
                              {
                                $eq: [
                                  "$userId2",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$userId2", "$$id"] },
                              {
                                $eq: [
                                  "$userId1",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                ],
                as: "chatroomsData",
              },
            },
            {
              $addFields: {
                chatmessagesData: { $arrayElemAt: ["$chatmessages", 0] },
                chatMessagesCount: {
                  $size: {
                    $filter: {
                      input: "$chatmessages",
                      as: "message",
                      cond: { $eq: ["$$message.readByCoach", 0] },
                    },
                  },
                },
                latestChatMessage: { $arrayElemAt: ["$chatmessages", 0] }, // Get latest chat message
              },
            },
            {
              $unwind: {
                path: "$chatmessages",
                preserveNullAndEmptyArrays: true,
              },
            },
          ],
        },
      },
      {
        $unwind: "$userData",
      },
      {
        $sort: {
          createdAt: -1, // Sort by order creation date (assuming createdAt is in orderModal)
        },
      },
      {
        $group: {
          _id: "$userData._id",
          name: { $first: "$userData.name" },
          email: { $first: "$userData.email" },
          image: { $first: "$userData.image" },
          live: { $first: "$userData.live" },
          lastSeen: { $first: "$userData.lastSeen" },
          latestOrderCreatedAt: { $first: "$createdAt" }, // Keep track of the latest order date
          latestMessageCreatedAt: {
            $first: "$userData.chatmessagesData.createdAt",
          },
          ChatData: { $first: "$userData.chatmessagesData" },
          chatroomsId: {
            $first: { $arrayElemAt: ["$userData.chatroomsData._id", 0] },
          },
          totalChatMessages: { $first: "$userData.chatMessagesCount" },
        },
      },
      {
        $sort: {
          latestMessageCreatedAt: -1, // sort by latest message first
          latestOrderCreatedAt: -1, // fallback: sort by latest order
        },
      },
    ]);
    socket.join(coachId);
    const responce = {
      data: userList,
      message: "Inbox data get successfully",
    };

    return io.to(coachId).emit("inbox-data-coach", responce);
  } catch (error) {
    console.log(error);
  }
};

exports.userInbox = async (data, socket, io) => {
  try {
    const userData = socket.request.userData; //token data
    const userId = userData._id; //user _id

    const userList = await orderModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
          pipeline: [
            {
              $lookup: {
                from: "chatmessages",
                let: { id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$senderId", "$$id"] },
                              {
                                $eq: [
                                  "$receiverId",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$receiverId", "$$id"] },
                              {
                                $eq: [
                                  "$senderId",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  {
                    $sort: { createdAt: -1 },
                  },
                ],
                as: "chatmessages",
              },
            },
            {
              $lookup: {
                from: "chatrooms",
                let: { id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$userId1", "$$id"] },
                              {
                                $eq: [
                                  "$userId2",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$userId2", "$$id"] },
                              {
                                $eq: [
                                  "$userId1",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                ],
                as: "chatroomsData",
              },
            },
            {
              $addFields: {
                chatmessagesData: { $arrayElemAt: ["$chatmessages", 0] }, // Fetch latest message
                chatMessagesCount: {
                  $size: {
                    $filter: {
                      input: "$chatmessages",
                      as: "message",
                      cond: { $eq: ["$$message.readByUser", 0] },
                    },
                  },
                },
                latestMessage: { $arrayElemAt: ["$chatmessages", 0] },
              },
            },
          ],
        },
      },
      {
        $unwind: "$coachData",
      },
      {
        $sort: {
          createdAt: -1, // Sort by order creation date (assuming createdAt is in orderModal)
        },
      },
      {
        $group: {
          _id: "$coachData._id",
          name: { $first: "$coachData.name" },
          Lname: { $first: "$coachData.Lname" },
          email: { $first: "$coachData.email" },
          image: { $first: "$coachData.image" },
          live: { $first: "$coachData.live" },
          lastSeen: { $first: "$coachData.lastSeen" },
          latestOrderCreatedAt: { $first: "$createdAt" },
          latestMessageCreatedAt: {
            $first: "$coachData.chatmessagesData.createdAt",
          },
          ChatData: { $first: "$coachData.chatmessagesData" },
          chatroomsId: {
            $first: { $arrayElemAt: ["$coachData.chatroomsData._id", 0] },
          },
          totalChatMessages: { $first: "$coachData.chatMessagesCount" },
        },
      },
      {
        $sort: {
          latestMessageCreatedAt: -1, // sort by latest message first
          latestOrderCreatedAt: -1, // fallback: sort by latest order
        },
      },
    ]);
    socket.join(userId);

    const responce = {
      data: userList,
      message: "Inbox data get successfully",
    };

    return io.to(userId).emit("inbox-data-user", responce);
  } catch (error) {
    console.log(error);
  }
};

exports.markMessageRead = async (data, socket, io) => {
  try {
    const userData = socket?.request?.userData;
    const loginUserId = userData?._id;
    const { chatRoomId } = data;
    if (!mongoose.Types.ObjectId.isValid(chatRoomId)) {
      console.log("Invalid chatRoomId");
      return;
    }
    const chatRoomData = await chatRoomModel.findById(chatRoomId);
    if (!chatRoomData) {
      console.log("Chat room not found");
      return;
    }
    const isCoach = userData.userType === "coach";
    const updateData = isCoach
      ? { readByCoach: 1, messageReadStatusCoach: "read" }
      : { readByUser: 1, messageReadStatusUser: "read" };
    const readFilter = isCoach
      ? {
          readByCoach: 0,
          messageReadStatusCoach: { $in: ["delivered", "sent", ""] },
        }
      : {
          readByUser: 0,
          messageReadStatusUser: { $in: ["delivered", "sent", ""] },
        };
    await chatmessageModel.updateMany(
      {
        chatRoomId: chatRoomId,
        ...readFilter,
      },
      {
        $set: updateData,
      }
    );
    io.to(
      chatRoomData.userId2.toString() === loginUserId.toString()
        ? chatRoomData.userId1.toString()
        : chatRoomData.userId2.toString()
    ).emit("message-status-updated", {
      from:
        chatRoomData.userId1.toString() === loginUserId.toString()
          ? chatRoomData.userId1.toString()
          : chatRoomData.userId2.toString(),
    });
    return io
      .to(chatRoomId)
      .emit("new-message", { message: "mark message read" });
  } catch (error) {
    console.log("markMessageRead error:", error);
  }
};

exports.TypingStatus = async (data, socket, io) => {
  try {
    const { from, to, isTyping } = data;
    return io.to(to).emit("typing-status", {
      sendingTo: to,
      userId: from,
      isTyping: isTyping,
    });
  } catch (error) {
    console.log("TypingStatus error:", error);
  }
};

exports.markAsDelivered = async (data, socket, io) => {
  try {
    const { userType, userId } = data;
    let match = { receiverId: userId };
    let updatedData = {};
    let statusField = "";
    if (userType === "coach") {
      match.messageReadStatusCoach = { $in: ["sent", "failed"] };
      updatedData.messageReadStatusCoach = "delivered";
      statusField = "messageReadStatusCoach";
    } else if (userType === "coachee") {
      match.messageReadStatusUser = { $in: ["sent", "failed"] };
      updatedData.messageReadStatusUser = "delivered";
      statusField = "messageReadStatusUser";
    }
    const affectedMessages = await chatmessageModel
      .find(match)
      .select("senderId");
    await chatmessageModel.updateMany(match, { $set: updatedData });
    const uniqueSenderIds = [
      ...new Set(affectedMessages.map((msg) => msg.senderId.toString())),
    ];
    uniqueSenderIds.forEach((senderId) => {
      io.to(senderId).emit("message-status-updated", {
        type: "delivered",
        receiverId: userId,
        forUserType: userType,
      });
    });
  } catch (error) {
    console.log("markAsDelivered error:", error);
  }
};

//end socket APIs

//User list
exports.userList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id

    const userList = await orderModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
          pipeline: [
            {
              $lookup: {
                from: "chatmessages",
                let: { id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$senderId", "$$id"] },
                              {
                                $eq: [
                                  "$receiverId",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$receiverId", "$$id"] },
                              {
                                $eq: [
                                  "$senderId",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  {
                    $sort: {
                      createdAt: -1,
                    },
                  },
                  { $limit: 1 },
                ],
                as: "chatmessages",
              },
            },
            {
              $unwind: {
                path: "$chatmessages",
                preserveNullAndEmptyArrays: true,
              },
            },
          ],
        },
      },
      {
        $unwind: "$userData",
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $replaceRoot: {
          newRoot: {
            userData: "$userData",
            createdAt: "$createdAt",
          },
        },
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $group: {
          _id: "$userData._id",
          name: { $first: "$userData.name" },
          email: { $first: "$userData.email" },
          image: { $first: "$userData.image" },
          ChatData: { $first: "$userData.chatmessages" },
        },
      },
    ]);
    const response = {
      success: true,
      userList,
      message: "users list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//file upload
exports.fileUpload = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const files = req.files; // This will contain your uploaded files
    // Handle your message and files here
    if (!files || files.length === 0) {
      return res.status(400).json({ error: "No files uploaded." });
    }
    const fileNameList = files.map((file) => file.filename);
    const response = {
      success: true,
      fileNameList,
      message: "users list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//User list
exports.userList2 = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    // const userId = req.coach._id; //login coach-id
    const userId = "670cc6ee76f609b3684880cf"; //login coach-id
    // const userList2 = await orderModal.aggregate([
    //   {
    //     $match: {
    //       coachId: new mongoose.Types.ObjectId(coachId),
    //     },
    //   },
    //   {
    //     $lookup: {
    //       from: "users",
    //       localField: "userId",
    //       foreignField: "_id",
    //       as: "userData",
    //       pipeline: [
    //         {
    //           $lookup: {
    //             from: "chatmessages",
    //             let: { id: "$_id" },
    //             pipeline: [
    //               {
    //                 $match: {
    //                   $expr: {
    //                     $or: [
    //                       {
    //                         $and: [
    //                           { $eq: ["$senderId", "$$id"] },
    //                           {
    //                             $eq: [
    //                               "$receiverId",
    //                               new mongoose.Types.ObjectId(coachId),
    //                             ],
    //                           },
    //                         ],
    //                       },
    //                       {
    //                         $and: [
    //                           { $eq: ["$receiverId", "$$id"] },
    //                           {
    //                             $eq: [
    //                               "$senderId",
    //                               new mongoose.Types.ObjectId(coachId),
    //                             ],
    //                           },
    //                         ],
    //                       },
    //                     ],
    //                   },
    //                 },
    //               },
    //               {
    //                 $sort: {
    //                   createdAt: -1,
    //                 },
    //               },
    //               { $limit: 1 },
    //             ],
    //             as: "chatmessages",
    //           },
    //         },
    //         {
    //           $unwind: {
    //             path: "$chatmessages",
    //             preserveNullAndEmptyArrays: true,
    //           },
    //         },
    //       ],
    //     },
    //   },
    //   {
    //     $unwind: "$userData",
    //   },
    //   {
    //     $sort: {
    //       createdAt: -1,
    //     },
    //   },
    //   {
    //     $replaceRoot: {
    //       newRoot: {
    //         userData: "$userData",
    //         createdAt: "$createdAt",
    //       },
    //     },
    //   },
    //   {
    //     $sort: {
    //       createdAt: -1,
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: "$userData._id",
    //       name: { $first: "$userData.name" },
    //       email: { $first: "$userData.email" },
    //       image: { $first: "$userData.image" },
    //       ChatData: { $first: "$userData.chatmessages" },
    //     },
    //   },
    // ]);
    // const userList3 = await orderModal.aggregate([
    //   {
    //     $match: {
    //       coachId: new mongoose.Types.ObjectId(coachId),
    //     },
    //   },
    //   {
    //     $lookup: {
    //       from: "users",
    //       localField: "userId",
    //       foreignField: "_id",
    //       as: "userData",
    //       pipeline: [
    //         {
    //           $lookup: {
    //             from: "chatmessages",
    //             let: { id: "$_id" },
    //             pipeline: [
    //               {
    //                 $match: {
    //                   $expr: {
    //                     $or: [
    //                       {
    //                         $and: [
    //                           { $eq: ["$senderId", "$$id"] },
    //                           { $eq: ["$receiverId", new mongoose.Types.ObjectId(coachId)] },
    //                         ],
    //                       },
    //                       {
    //                         $and: [
    //                           { $eq: ["$receiverId", "$$id"] },
    //                           { $eq: ["$senderId", new mongoose.Types.ObjectId(coachId)] },
    //                         ],
    //                       },
    //                     ],
    //                   },
    //                 },
    //               },
    //               {
    //                 $sort: { createdAt: -1 },
    //               },
    //               { $limit: 1 },
    //             ],
    //             as: "chatmessages",
    //           },
    //         },
    //         {
    //           $unwind: {
    //             path: "$chatmessages",
    //             preserveNullAndEmptyArrays: true,
    //           },
    //         },
    //       ],
    //     },
    //   },
    //   {
    //     $unwind: "$userData",
    //   },
    //   {
    //     $sort: {
    //       createdAt: -1, // Sort by order creation date (assuming createdAt is in orderModal)
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: "$userData._id",
    //       name: { $first: "$userData.name" },
    //       email: { $first: "$userData.email" },
    //       image: { $first: "$userData.image" },
    //       latestOrderCreatedAt: { $first: "$createdAt" }, // Keep track of the latest order date
    //       chatData: { $first: "$userData.chatmessages" },
    //     },
    //   },
    //   {
    //     $sort: {
    //       latestOrderCreatedAt: -1, // Sort users by latest order date
    //     },
    //   },
    // ]);
    const userList = await orderModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(userId),
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
          pipeline: [
            {
              $lookup: {
                from: "chatmessages",
                let: { id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$senderId", "$$id"] },
                              {
                                $eq: [
                                  "$receiverId",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$receiverId", "$$id"] },
                              {
                                $eq: [
                                  "$senderId",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  {
                    $sort: { createdAt: -1 },
                  },
                  { $limit: 1 },
                ],
                as: "chatmessages",
              },
            },
            {
              $unwind: {
                path: "$chatmessages",
                preserveNullAndEmptyArrays: true,
              },
            },
          ],
        },
      },
      {
        $unwind: "$coachData",
      },
      {
        $sort: {
          createdAt: -1, // Sort by order creation date (assuming createdAt is in orderModal)
        },
      },
      {
        $group: {
          _id: "$coachData._id",
          name: { $first: "$coachData.name" },
          Lname: { $first: "$coachData.Lname" },
          email: { $first: "$coachData.email" },
          image: { $first: "$coachData.image" },
          latestOrderCreatedAt: { $first: "$createdAt" }, // Keep track of the latest order date
          ChatData: { $first: "$coachData.chatmessages" },
        },
      },
      {
        $sort: {
          latestOrderCreatedAt: -1, // Sort users by latest order date
        },
      },
    ]);
    const response = {
      success: true,
      userList: userList,
      message: "users list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//file upload
exports.upReadMessageCount = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    let data = await chatmessageModel.countDocuments({
      $and: [
        {
          $or: [{ senderId: coachId }, { receiverId: coachId }],
        },
        {
          readByCoach: 0,
        },
      ],
    });

    const response = {
      success: true,
      data,
      message: "coach unread message count retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const CoachModel = require("../../../models/coach");
const userModel = require("../../../models/user");
const getEntityAndData = require("../../../lib/getUserData");
const getSenderDetails = async ({ senderId }) => {
  try {
    const [coachResult, userResult] = await Promise.allSettled([
      CoachModel.findById({
        _id: new mongoose.Types.ObjectId(senderId),
      }).select("_id name Lname  email image"),
      userModel
        .findById({ _id: new mongoose.Types.ObjectId(senderId) })
        .select("_id name lastName email image"),
    ]);

    if (coachResult.value) {
      return coachResult.value;
    }

    if (userResult.value) {
      return userResult.value;
    }

    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};
