const crypto = require("crypto");
const { validationResult } = require("express-validator");
const moment = require("moment-timezone");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
const Stripe = require("stripe");
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const CoachModel = require("../../../models/coach");
const coachSessionModal = require("../../../models/coachSession");
//SMTP setup
const nodemailer = require("nodemailer");
const hbs = require("nodemailer-express-handlebars");
const path = require("path");
const FailedLoginModal = require("../../../models/failedLoginAttempts");
const {
  CreatePasswordResetNotification,
  CreateWelcomeNotification,
  CreateForgetPasswordReqNotification,
  CreateUserLoginNotification,
  CreateNotification,
  CreateAdminLevelNotification,
  WaringLoginNotification,
} = require("../../../models/notificationModal");
const { createRefferals } = require("../../../models/referral");

const transportEmail = require("../../../lib/email");
const { passwordRecoveryUpdateEmail } = require("../../../utils/quickEmails");
const {
  needsCardPayments,
  transferRestrictedCountries,
} = require("../../../api-v2/webhooks/stripe/stripe");

//create user
const generateUniqueCode = async (username) => {
  let code;
  let exists = true;
  const namePart = username.substring(0, 5).toUpperCase().padEnd(5, "X");
  while (exists) {
    const randomPart = crypto.randomBytes(2).toString("hex").toUpperCase();
    code = `${namePart}${randomPart}`;
    exists = await CoachModel.exists({ my_invitation_code: code });
  }
  return code;
};
//register new coach
exports.register = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  const coachIP =
    req.headers["x-forwarded-for"]?.split(",")[0].trim() ||
    req.socket?.remoteAddress;

  let registered_id = "";
  let freeSession_ID = "";
  // return console.log(req.body);
  try {
    const {
      name,
      Lname,
      email,
      userName,
      password,
      timezone,
      referral,
      country,
      currency,
      countryCode,
      phoneCode,
    } = req.body;
    const bcryptPassword = await bcrypt.hash(password, 10);

    // const my_invitation_code = await generateUniqueCode(userName);
    const saveData = await new CoachModel({
      name,
      Lname,
      email,
      userName,
      password: bcryptPassword,
      timeZone: timezone,
      country,
      currency,
      countryCode,
      phoneCode,
    }).save();

    registered_id = saveData._id;
    // return console.log({ saveData });
    //create defult/free session
    const customer = await stripe.customers.create({
      name: `${name} ${Lname}`,
      email: email,
      description: "coach",
      metadata: {
        coach_id: saveData._id.toString(), // Store the coach ID
      },
    });
    const sessionData = await new coachSessionModal({
      coachId: saveData._id,
      title: "Chemistry session",
      type: 1,
      price: 0,
      description:
        "It's a FREE opportunity to discover if this is a good match for a coaching partnership",
    }).save();
    freeSession_ID = sessionData._id;
    const product = await stripe.products.create({
      name: sessionData.title,
      description: sessionData.description,
      metadata: {
        coach_id: saveData._id.toString(), // Store the coach ID
        session_id: sessionData._id.toString(), // Store the session ID
        type: 1,
      },
    });
    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: 0,
      currency: "usd",
      metadata: {
        coach_id: saveData._id.toString(), // Store the coach ID
        session_id: sessionData._id.toString(), // Store the session ID
        type: 1,
      },
    });
    await coachSessionModal.findByIdAndUpdate(
      { _id: sessionData._id },
      {
        $set: {
          stripePriceId: price.id,
          stripeProductId: product.id,
          invoice_prefix: customer.invoice_prefix,
          stripe_customerID: customer.id,
        },
      }
    );
    const capabilities = {
      transfers: { requested: true },
    };
    const isRequestingCardsPayments = needsCardPayments.includes(
      countryCode?.toUpperCase()
    );
    const hasTransferRestrictions = transferRestrictedCountries.includes(
      countryCode?.toUpperCase()
    );

    if (isRequestingCardsPayments && !hasTransferRestrictions) {
      Object.assign(capabilities, {
        card_payments: {
          requested: true,
        },
      });
    }
    const account = await stripe.accounts.create({
      type: "custom",
      country: countryCode, // 2-letter code (e.g., "IN", "GB", etc.)
      email: email,
      business_type: "individual",
      individual: {
        first_name: name,
        last_name: Lname,
        email: email,
      },
      business_profile: {
        url: "https://connectyou.global",
        mcc: "8299", // Business classification (Coaching/Training)
      },
      capabilities: capabilities,
      metadata: {
        coachId: saveData?._id.toString(),
        coachEmail: String(saveData?.email),
      },
      ...(isRequestingCardsPayments && !hasTransferRestrictions
        ? {
            tos_acceptance: {
              date: Math.floor(Date.now() / 1000),
              ip: coachIP,
            },
          }
        : {
            tos_acceptance: {
              service_agreement: "recipient",
            },
          }),
    });

    await CoachModel.findByIdAndUpdate(
      { _id: saveData._id },
      {
        $set: {
          invoice_prefix: customer.invoice_prefix,
          stripe_customerID: customer.id,
          stripe_accID: account.id,
          accHolderId: account.individual.id,
          stripe_addStatus: 1,
          stripe_onboardStatus: 0,
          "stripeCountryDetails.hasTransferRestrictions":
            hasTransferRestrictions,
        },
      }
    );

    let data = {
      _id: saveData._id,
      name: saveData.name,
      Lname: saveData.Lname,
      email: saveData.email,
      gender: saveData.gender,
      DOB: saveData.DOB,
      approve: saveData.approve,
      createdAt: saveData.createdAt,
      image: saveData.image,
      userName: saveData.userName,
      timeZone: saveData.timeZone,
      averageRating: 0,
      totalRatings: 0,
      userType: "coach",
      my_invitation_code: saveData.my_invitation_code,
      country: saveData.country,
      currency: saveData.currency,
      countryCode: saveData.countryCode,
      phoneCode: saveData.phoneCode,
    };
    const authToken = await jwt.sign(data, JWT_SECRET);
    data.token = authToken;
    const responce = {
      success: true,
      data,
      message: "Coach register successfully",
    };
    Promise.all([
      CreateWelcomeNotification({ user_id: data._id }),
      CreateAdminLevelNotification({
        heading: `${saveData.name} ${saveData.Lname} have just signed up on the Portal !`,
        description: `A new coach have signed up on the portal, check details by clicking on the view button.`,
        url: `/coach/detail/${saveData._id}`,
      }),
    ]);
    const isInvited = await CoachModel.findOne({
      my_invitation_code: referral,
    });

    if (isInvited) {
      createRefferals({
        user_id: isInvited._id,
        referral,
        connection: saveData._id,
      });
      CreateNotification({
        user_id: isInvited._id,
        heading: `${saveData.name} ${saveData.Lname} have accepted your sign up invitation for ConnectYou.`,
        description: `${saveData.name} have accepted your invitation and joined ConnectYou using your invitation code. You will recieve your referral reward once the user verifies thier email.`,
        url: `/c/profile`,
        notification_type: "promotion",
      });
    }

    const mailOptions = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: saveData.email,
      subject: "Welcome Coach",
      template:
        saveData.registrationType === "bulk_upload"
          ? "coachCreated"
          : "welcomeCoach",
      context: {
        name: `${saveData.name} ${saveData.Lname}`,
        email: saveData.email,
      },
    };
    transportEmail.createEmail({ mailOptions });
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    // Mongoose validation error
    if (err.name === "ValidationError") {
      const firstErrorField = Object.keys(err.errors)[0];
      const errorMessage = err.errors[firstErrorField].message;
      return res.status(400).json({ success: false, message: errorMessage });
    }
    // Mongoose validation error
    // Duplicate key error (e.g., unique constraint)
    if (err.code === 11000 && err.keyPattern && err.keyValue) {
      const duplicateField = Object.keys(err.keyPattern)[0];
      const duplicateValue = err.keyValue[duplicateField];

      let errorMessage = `Duplicate key error: ${duplicateField} '${duplicateValue}' already exists.`;
      return res.status(400).json({ success: false, message: errorMessage });
    }
    //Server error
    await Promise.all([
      CoachModel.findByIdAndDelete({
        _id: registered_id,
      }),
      coachSessionModal.findByIdAndDelete({
        _id: freeSession_ID,
      }),
    ]);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//login coach
exports.login = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, password, location } = req.body;
    const coachData = await CoachModel.aggregate([
      {
        $match: {
          $or: [{ email: email }, { userName: email }],
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);

    if (coachData.length > 0) {
      // console.log({ coachData });
      const allowLogin = await CheckFailedLoginStatus(
        coachData[0]._id,
        coachData[0],
        location
      );
      if (allowLogin.success === false) {
        await addFailedLoginAttempt(coachData[0]._id);
        return res.status(403).json(allowLogin.responce);
      }
      const bcryptData = await bcrypt.compare(password, coachData[0].password);
      if (!bcryptData) {
        await addFailedLoginAttempt(coachData[0]._id);
        return res
          .status(401)
          .json({ success: false, message: "Invalid credentials" });
      }
      if (coachData[0].delete == 1 || coachData[0].deleteReq != 0) {
        const responce = { success: false, message: "Invalid credentials" };
        return res.status(403).json(responce);
      }
      if (coachData[0].block == 1) {
        const responce = { success: false, message: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (
        coachData[0]?.registrationType === "bulk_upload" ||
        coachData[0]?.registrationType === "hubspot_sync"
      ) {
        const sessionData = await new coachSessionModal({
          coachId: coachData[0]._id,
          title: "Chemistry session",
          type: 1,
          price: 0,
          description:
            "It's a FREE opportunity to discover if this is a good match for a coaching partnership",
        }).save();
        const product = await stripe.products.create({
          name: "Chemistry session",
          description:
            "It's a FREE opportunity to discover if this is a good match for a coaching partnership",
          metadata: {
            coach_id: coachData[0]._id.toString(), // Store the coach ID
            session_id: sessionData._id.toString(), // Store the session ID
            type: 1,
          },
        });
        const price = await stripe.prices.create({
          product: product.id,
          unit_amount: 0,
          currency: "usd",
          metadata: {
            coach_id: coachData[0]._id.toString(),
            session_id: sessionData._id.toString(),
            type: 1,
          },
        });
        const customer = await stripe.customers.create({
          name: `${coachData[0].name} ${coachData[0].Lname}`,
          email: coachData[0].email,
          description: "coach",
          metadata: {
            coach_id: coachData[0]._id.toString(),
          },
        });
        await coachSessionModal.findByIdAndUpdate(
          { _id: sessionData._id },
          {
            $set: {
              stripePriceId: price.id,
              stripeProductId: product.id,
              invoice_prefix: customer.invoice_prefix,
              stripe_customerID: customer.id,
            },
          }
        );
        await CoachModel.findByIdAndUpdate(
          { _id: coachData[0]._id },
          {
            $set: {
              registrationType:
                coachData[0].registrationType === "bulk_upload"
                  ? "bulk_to_manual"
                  : "hubspot_sync_to_manual",
              invoice_prefix: customer.invoice_prefix,
              stripe_customerID: customer.id,
            },
          }
        );
      }
      let data = {
        _id: coachData[0]._id,
        name: coachData[0].name,
        Lname: coachData[0].Lname,
        email: coachData[0].email,
        gender: coachData[0].gender,
        approve: coachData[0].approve,
        DOB: coachData[0].DOB,
        createdAt: coachData[0].createdAt,
        image: coachData[0].image,
        userName: coachData[0].userName,
        averageRating: coachData[0].averageRating,
        totalRatings: coachData[0].totalRatings,
        userType: "coach",
        timeZone: coachData[0].timeZone,
        my_invitation_code: coachData[0].my_invitation_code,
      };
      const authToken = await jwt.sign(data, JWT_SECRET);
      data.token = authToken;
      const responce = {
        success: true,
        data,
        message: "Coach login successfully",
      };
      await ClearLoginFailureRecord(coachData[0]._id);
      await CreateUserLoginNotification({ user_id: data._id });
      return res.status(200).json(responce);
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.sendEmail_passwordReset = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, timezone } = req.body;
    const coachData = await CoachModel.find({ email });
    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }

      const otp = Math.floor(10000 + Math.random() * 90000);

      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: email,
        subject: "Forgot Password",
        template: "send-otp-forget-password",
        context: {
          _id: coachData[0]._id,
          name: coachData[0].name,
          email: coachData[0].email,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        const responce = {
          success: false,
          message: "Something went wrong while sending OTP",
        };
        return res.status(500).json(responce);
      } else {
        const currentDate = moment().tz(timezone).format("YYYY-MM-DD HH:mm:ss");
        const otpExpiry = moment(currentDate)
          .add(5, "minutes")
          .format("YYYY-MM-DD HH:mm:ss");

        await CoachModel.findByIdAndUpdate(
          { _id: coachData[0]._id },
          {
            $set: {
              otp: otp,
              otpType: "password-reset-process",
              otpDate: otpExpiry,
            },
          }
        );
        const responce = {
          success: true,
          message: "Email send successfully",
        };
        return res.status(200).json(responce);
      }
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for password reset process
exports.OTPverification_passwordReset = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, timezone, otp, password } = req.body;

    const [coachData, verifyType] = await Promise.all([
      CoachModel.find({ email }),
      CoachModel.find({ otp, otpType: "password-reset-process" }),
    ]);
    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (otp != coachData[0].otp) {
        const responce = {
          success: false,
          error: "The OTP you entered is incorrect",
        };
        return res.status(403).json(responce);
      }
      const isOtpExpired = moment().tz(timezone).isAfter(coachData[0].otpDate);
      if (isOtpExpired) {
        const responce = {
          success: false,
          message: "OTP verification maximum time exceeded",
        };
        return res.status(401).json(responce);
      }
      if (verifyType.length == 0) {
        const responce = {
          success: false,
          message: "Something went wrong try again after some time",
        };
        return res.status(401).json(responce);
      }
      const bcryptPassword = await bcrypt.hash(password, 10);

      await CoachModel.findByIdAndUpdate(
        { _id: coachData[0]._id },
        {
          $set: {
            password: bcryptPassword,
            emailVerified: 1,
            otp: 0,
            otpType: "",
            otpDate: "",
          },
        }
      );
      const responce = {
        success: true,
        message: "Your password updated successfully",
      };
      return res.status(200).json(responce);
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//forgot Password process start
//send email on given mail for password reset process
exports.forgotPasswordSendEmail = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, timezone } = req.body;
    const coachData = await CoachModel.find({ email });
    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }

      if (coachData[0].delete == 1) {
        const responce = { success: false, error: "Your account is deleted" };
        return res.status(403).json(responce);
      }

      const otp = Math.floor(10000 + Math.random() * 90000);

      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: email,
        subject: "Forgot Password",
        template: "send-otp-forget-password",
        context: {
          _id: coachData[0]._id,
          name: coachData[0].name,
          email: coachData[0].email,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        const responce = {
          success: false,
          message: "Something went wrong",
        };
        return res.status(500).json(responce);
      } else {
        const currentDate = moment().tz(timezone).format("YYYY-MM-DD HH:mm:ss");
        const otpExpiry = moment(currentDate)
          .add(5, "minutes")
          .format("YYYY-MM-DD HH:mm:ss");

        await CoachModel.findByIdAndUpdate(
          { _id: coachData[0]._id },
          {
            $set: {
              otp: otp,
              otpType: "password-forgot-process",
              otpDate: otpExpiry,
            },
          }
        );
        const responce = {
          success: true,
          message: "Email send successfully",
        };
        await CreateForgetPasswordReqNotification({
          user_id: coachData[0]._id,
        });
        return res.status(200).json(responce);
      }
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for password reset process
exports.forgotPasswordOTPverification = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, otp } = req.body;

    const [coachData, verifyType] = await Promise.all([
      CoachModel.find({ email }),
      CoachModel.find({ otp, otpType: "password-forgot-process" }),
    ]);

    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, message: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (coachData[0].delete == 1) {
        const responce = { success: false, message: "Your account is deleted" };
        return res.status(403).json(responce);
      }

      if (otp != coachData[0].otp) {
        const responce = {
          success: false,
          message: "The OTP you entered is incorrect",
        };
        return res.status(403).json(responce);
      }
      const isOtpExpired = moment().isAfter(coachData[0].otpDate);
      if (isOtpExpired) {
        const responce = {
          success: false,
          message: "OTP verification maximum time exceeded",
        };
        return res.status(401).json(responce);
      }
      if (verifyType.length == 0) {
        const responce = {
          success: false,
          message: "Something went wrong try again after some time",
        };
        return res.status(401).json(responce);
      }
      await CoachModel.findByIdAndUpdate(
        { _id: coachData[0]._id },
        {
          $set: {
            emailVerified: 1,
            otp: 0,
            otpType: "",
            otpDate: "",
          },
        }
      );
      const responce = {
        success: true,
        message: "Your otp verified successfully",
      };
      return res.status(200).json(responce);
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for password reset process
exports.forgotPasswordNewPassword = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, password } = req.body;

    const [coachData] = await Promise.all([CoachModel.find({ email })]);

    if (coachData.length > 0) {
      if (coachData[0].block == 1) {
        const responce = { success: false, error: "Your account is blocked" };
        return res.status(403).json(responce);
      }
      if (coachData[0].delete == 1) {
        const responce = { success: false, error: "Your account is deleted" };
        return res.status(403).json(responce);
      }
      const bcryptPassword = await bcrypt.hash(password, 10);
      await CoachModel.findByIdAndUpdate(
        { _id: coachData[0]._id },
        {
          $set: {
            password: bcryptPassword,
          },
        }
      );
      const responce = {
        success: true,
        message: "Your password updated successfully",
      };
      await Promise.all([
        ClearLoginFailureRecord(coachData[0]._id),
        passwordRecoveryUpdateEmail(
          `${coachData[0].name} ${coachData[0].Lname}`,
          coachData[0].email
        ),
        CreatePasswordResetNotification({ user_id: coachData[0]._id }),
      ]);
      return res.status(200).json(responce);
    } else {
      const responce = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const CheckFailedLoginStatus = async (id, Coach, location) => {
  const user = await FailedLoginModal.findOne({ user_id: id });
  if (!user) return { success: true, response: null };
  if (user.failedAttempts.length >= 2) {
    await sendWarningEmail(Coach.name, location, Coach.email);
  }
  if (user.failedAttempts.length >= 2) {
    await CreateNotification({
      user_id: id,
      heading: "There was an failed login attempt to your account.",
      description: `There was a failed login attempt for your account at ${new Date().toLocaleDateString()}, If this was not you Please Contact us and report this to maintin security of your account.`,
      url: `/get-in-touch`,
      notification_type: "alerts",
    });
  }
  if (user.failedAttempts.length >= 4) {
    const responce = {
      success: false,
      message:
        "Too Many  Failed Login Attempts, your account has been blocked for 1 hour.",
    };
    return { success: false, responce };
  } else return { success: true, response: null };
};

const addFailedLoginAttempt = async (id) => {
  try {
    const user = await FailedLoginModal.findOneAndUpdate(
      { user_id: id }, // Search by user ID
      {
        $push: { failedAttempts: new Date().toString() }, // Push a string (current date)
      },
      {
        new: true, // Return the updated document
        upsert: true, // If no document is found, create a new one
      }
    );
    // Optionally return the updated user document
    return user;
  } catch (error) {
    throw new Error("Failed to update failed login attempts");
  }
};

const sendWarningEmail = async (name, location, email) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: "Suspisious Login Attempts",
    template: "securitywarning",
    context: {
      name: name,
      email: email,
      type: "coach",
      location: location,
    },
  };
  await transportEmail.createEmail({ mailOptions });
};

const ClearLoginFailureRecord = async (id) => {
  try {
    const user = await FailedLoginModal.deleteOne({ user_id: id });
    return;
  } catch (error) {
    console.log(error);
  }
};

exports.oldregister = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  const coachIP =
    req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  let registered_id = "";
  try {
    const {
      name,
      Lname,
      email,
      userName,
      password,
      timezone,
      referral,
      country,
      currency,
      countryCode,
      phoneCode,
    } = req.body;
    const bcryptPassword = await bcrypt.hash(password, 10);

    // const my_invitation_code = await generateUniqueCode(userName);
    const saveData = await new CoachModel({
      name,
      Lname,
      email,
      userName,
      password: bcryptPassword,
      timeZone: timezone,
      country,
      currency,
      countryCode,
      phoneCode,
    }).save();
    registered_id = saveData._id;
    // console.log({ saveData });
    //create defult/free session
    const customer = await stripe.customers.create({
      name: `${name} ${Lname}`,
      email: email,
      description: "coach",
      metadata: {
        coach_id: saveData._id.toString(), // Store the coach ID
      },
    });
    const sessionData = await new coachSessionModal({
      coachId: saveData._id,
      title: "Chemistry session",
      type: 1,
      price: 0,
      description:
        "It's a FREE opportunity to discover if this is a good match for a coaching partnership",
    }).save();

    //add session in stipe as a product
    const product = await stripe.products.create({
      name: sessionData.title,
      description: sessionData.description,
      metadata: {
        coach_id: saveData._id.toString(), // Store the coach ID
        session_id: sessionData._id.toString(), // Store the session ID
        type: 1,
      },
    });
    //set created product price
    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: 0,
      currency: "usd",
      metadata: {
        coach_id: saveData._id.toString(), // Store the coach ID
        session_id: sessionData._id.toString(), // Store the session ID
        type: 1,
      },
    });
    //create customar : add coach as a seller in stripe//

    //add priceId in coach profile
    await coachSessionModal.findByIdAndUpdate(
      { _id: sessionData._id },
      {
        $set: {
          stripePriceId: price.id,
          stripeProductId: product.id,
          invoice_prefix: customer.invoice_prefix,
          stripe_customerID: customer.id,
        },
      }
    );

    const account = await stripe.accounts.create({
      type: "custom",
      country: countryCode, // 2-letter code (e.g., "IN", "GB", etc.)
      email: email,
      business_type: "individual",
      individual: {
        first_name: name,
        last_name: Lname,
        email: email,
      },
      business_profile: {
        url: "https://connectyou.global",
        mcc: "8299", // Business classification (Coaching/Training)
      },
      capabilities: {
        transfers: {
          requested: true,
        },
      },
      metadata: {
        coachId: saveData._id.toString(),
        coachEmail: String(saveData.email),
      },
      ...(saveData.country !== "United States"
        ? {
            tos_acceptance: {
              service_agreement: "recipient",
            },
          }
        : {}),
    });

    await CoachModel.findByIdAndUpdate(
      { _id: saveData._id },
      {
        $set: {
          invoice_prefix: customer.invoice_prefix,
          stripe_customerID: customer.id,
          stripe_accID: account.id,
          accHolderId: account.individual.id,
          stripe_addStatus: 1,
          stripe_onboardStatus: 0,
        },
      }
    );
    let data = {
      _id: saveData._id,
      name: saveData.name,
      Lname: saveData.Lname,
      email: saveData.email,
      gender: saveData.gender,
      DOB: saveData.DOB,
      approve: saveData.approve,
      createdAt: saveData.createdAt,
      image: saveData.image,
      userName: saveData.userName,
      timeZone: saveData.timeZone,
      averageRating: 0,
      totalRatings: 0,
      userType: "coach",
      my_invitation_code: saveData.my_invitation_code,
      country: saveData.country,
      currency: saveData.currency,
      countryCode: saveData.countryCode,
      phoneCode: saveData.phoneCode,
    };
    const authToken = await jwt.sign(data, JWT_SECRET);
    data.token = authToken;
    const responce = {
      success: true,
      data,
      message: "Coach register successfully",
    };
    Promise.all([
      CreateWelcomeNotification({ user_id: data._id }),
      CreateAdminLevelNotification({
        heading: `${saveData.name} ${saveData.Lname} have just signed up on the Portal !`,
        description: `A new coach have signed up on the portal, check details by clicking on the view button.`,
        url: `/coach/detail/${saveData._id}`,
      }),
    ]);
    const isInvited = await CoachModel.findOne({
      my_invitation_code: referral,
    });

    if (isInvited) {
      createRefferals({
        user_id: isInvited._id,
        referral,
        connection: saveData._id,
      });
      CreateNotification({
        user_id: isInvited._id,
        heading: `${saveData.name} ${saveData.Lname} have accepted your sign up invitation for ConnectYou.`,
        description: `${saveData.name} have accepted your invitation and joined ConnectYou using your invitation code. You will recieve your referral reward once the user verifies thier email.`,
        url: `/c/profile`,
        notification_type: "promotion",
      });
    }

    const mailOptions = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: saveData.email,
      subject: "Welcome Coach",
      template:
        saveData.registrationType === "bulk_upload"
          ? "coachCreated"
          : "welcomeCoach",
      context: {
        name: `${saveData.name} ${saveData.Lname}`,
        email: saveData.email,
      },
    };
    transportEmail.createEmail({ mailOptions });
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    // Mongoose validation error
    if (err.name === "ValidationError") {
      const firstErrorField = Object.keys(err.errors)[0];
      const errorMessage = err.errors[firstErrorField].message;
      return res.status(400).json({ success: false, message: errorMessage });
    }
    // Mongoose validation error
    // Duplicate key error (e.g., unique constraint)
    if (err.code === 11000 && err.keyPattern && err.keyValue) {
      const duplicateField = Object.keys(err.keyPattern)[0];
      const duplicateValue = err.keyValue[duplicateField];

      let errorMessage = `Duplicate key error: ${duplicateField} '${duplicateValue}' already exists.`;
      return res.status(400).json({ success: false, message: errorMessage });
    }
    //Server error
    await CoachModel.findByIdAndDelete({
      _id: registered_id,
    });
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
