const resourceModel = require("../../../models/resources");
const { validationResult } = require("express-validator");
const mongoose = require("mongoose");

exports.ListResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let data = await resourceModel.find({
      $or: [{ availableFor: "coach" }, { availableFor: "all" }],
    });
    return res.status(200).json({
      success: true,
      data,
      message: "Coach resources list get successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.DetailsResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  let id = req.params.id;
  try {
    let data = await resourceModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(id),
          $or: [{ availableFor: "coach" }, { availableFor: "all" }],
        },
      },
      {
        $lookup: {
          from: "resources_modules",
          localField: "_id",
          foreignField: "resourceId",
          as: "modules",
        },
      },
    ]);
    return res.status(200).json({
      success: true,
      data: data[0],
      message: "Coach resources list get successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
