const { validationResult } = require("express-validator");
require("dotenv").config();

const Stripe = require("stripe");
//environment variables
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const CoachModel = require("../../../models/coach");
const {
  needsCardPayments,
  transferRestrictedCountries,
  CountriesOptions,
} = require("../../../api-v2/webhooks/stripe/stripe");

//checking account added or not in stripe
exports.accountDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      let data = {
        persionId_number: coachData[0].persionId_number ? 1 : 0,
        stripe_accID: coachData[0].stripe_accID ? 1 : 0,
        stripe_onboardStatus: coachData[0].stripe_onboardStatus, //0 for not added and 1 for added and 2 for account not created
      };
      const responce = {
        success: true,
        data,
        message: "account details",
      };
      // console.log({ responce });
      return res.status(200).json(responce);
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (err) {
    console.log("StripAccountError", err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

//checking account added or not in stripe
exports.accountBankList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      if (coachData[0].stripe_accID == "") {
        const responce = {
          success: false,
          data: [],
          message: "account not added yet!",
        };
        // console.log({ responce });
        return res.status(200).json(responce);
      }
      const externalAccounts = await stripe.accounts.listExternalAccounts(
        coachData[0].stripe_accID,
        {
          object: "bank_account",
        }
      );
      const responce = {
        success: true,
        data: externalAccounts,
        message: "account bank details",
      };
      // console.log({ responce });
      return res.status(200).json(responce);
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (err) {
    console.log("StripAccountError", err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

//update account status of stripe
exports.updateAccountDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      await CoachModel.findByIdAndUpdate(
        { _id: coachId },
        {
          $set: {
            stripe_onboardStatus: 1,
          },
        },
        { new: true }
      );
      const responce = {
        success: true,
        message: "account details updated",
      };

      return res.status(200).json(responce);
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (err) {
    console.log("StripAccountError", err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

// { country: CountryData }
// ///
//     code: string;
//     label: string;
//     phone: string;
//     currency: string;
//create coach account on stripe
exports.createAccount = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    // return console.log(req.body);
    const { code, label, phone, currency, ip } = req.body;
    const coachIP = ip || getClientIP(req) || `ip-unav ::: ${coachId}`;
    console.log({ coachIP });
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      const capabilities = {
        transfers: { requested: true },
      };
      const isRequestingCardsPayments = needsCardPayments.includes(
        code?.toUpperCase()
      );
      const hasTransferRestrictions = transferRestrictedCountries.includes(
        code?.toUpperCase()
      );

      if (isRequestingCardsPayments && !hasTransferRestrictions) {
        Object.assign(capabilities, {
          card_payments: { requested: true },
        });
      }
      const account = await stripe.accounts.create({
        type: "custom",
        business_type: "individual",
        country: String(code)?.toUpperCase(), // 2-letter code (e.g., "IN", "GB", etc.)
        email: coachData[0].email,
        individual: {
          first_name: coachData[0]?.name,
          last_name: coachData[0]?.Lname,
          email: coachData[0]?.email,
        },
        business_profile: {
          url: "https://connectyou.global",
          mcc: "8299",
        },
        capabilities: capabilities,
        ...(isRequestingCardsPayments && !hasTransferRestrictions
          ? {
              tos_acceptance: {
                date: Math.floor(Date.now() / 1000),
                ip: coachIP,
                service_agreement: "full",
              },
            }
          : {
              tos_acceptance: {
                service_agreement: "recipient",
              },
            }),
        metadata: {
          coachId: String(coachData[0]._id), //coach id
          coachEmail: String(coachData[0].email), //coach email
        },
      });
      // console.log({ account });
      await CoachModel.findByIdAndUpdate(
        { _id: coachId },
        {
          $set: {
            stripe_accID: account.id,
            accHolderId: account.individual.id,
            stripe_addStatus: 1,
            stripe_onboardStatus: 0,
            stripeCountryDetails: {
              code: code,
              label: label,
              phone: phone,
              currency: currency,
              hasTransferRestrictions: hasTransferRestrictions,
            },
          },
        },
        { new: true }
      );
      return res.status(200).json({
        success: true,
        data: account,
        message: "Account created successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message:
          "Profile details unavailable at the moment, Please try again later",
      });
    }
  } catch (err) {
    console.log("StripAccountError", err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

//onboarding session
exports.stripe_account_onboarding = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      if (!coachData[0]?.stripe_accID || coachData[0]?.stripe_accID == "") {
        const responce = {
          success: false,
          clientSecret: "",
          message: "account not created",
        };
        return res.status(200).json(responce);
      }
      try {
        const accountSession = await stripe.accountSessions.create({
          account: coachData[0].stripe_accID,
          components: {
            account_onboarding: {
              enabled: true,
              features: {
                external_account_collection: true,
              },
            },
          },
        });
        const responce = {
          success: true,
          clientSecret: accountSession.client_secret,
          message: "Dashboard URL get successfully",
        };
        return res.status(200).json(responce);
      } catch (error) {
        console.log(error);
        return res.status(400).json({ success: false, message: error.message });
      }
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

//coach stripe account managment
exports.account_management_Session = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      if (coachData[0].stripe_accID == "") {
        const responce = {
          success: false,
          clientSecret: "",
          message: "account onboarding not created",
        };
        return res.status(200).json(responce);
      }
      try {
        const accountSession = await stripe.accountSessions.create({
          account: coachData[0].stripe_accID,
          components: {
            account_management: {
              enabled: true,
              features: {
                external_account_collection: true,
              },
            },
          },
        });
        console.log({
          accountSession,
        });
        return res.status(200).json({
          success: true,
          clientSecret: accountSession.client_secret,
          message: "Dashboard URL get successfully",
        });
      } catch (error) {
        console.log(error);
        return res.status(400).json({ success: false, message: error.message });
      }
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

//not use
//stripe account onboarding link
exports.stripe_account_onboarding_link = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      if (coachData[0].stripe_accID == "") {
        const responce = {
          success: false,
          message: "Add bank holder details first",
        };
        return res.status(400).json(responce);
      }
      try {
        const accountLink = await stripe.accountLinks.create({
          account: coachData[0].stripe_accID, // The Stripe account ID you just created
          refresh_url: `${process.env.FRONTEND_URL_web}/c/kyc-details`, // Redirect if session expires
          return_url: `${process.env.FRONTEND_URL_web}/c/kyc-details`, // Redirect after completion
          type: "account_onboarding",
        });
        console.log({
          accountLink,
        });

        return res.status(200).json({
          success: true,
          url: accountLink.url,
          message: "stripe_account_onboarding URL get successfully",
        });
      } catch (error) {
        console.log(error);
        return res.status(400).json({ success: false, message: error.message });
      }
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

function getClientIP(req) {
  const xForwardedFor = req.headers["x-forwarded-for"];
  if (typeof xForwardedFor === "string") {
    return xForwardedFor.split(",")[0].trim();
  }

  return (
    req.connection?.remoteAddress ||
    req.socket?.remoteAddress ||
    req.connection?.socket?.remoteAddress ||
    null
  );
}

exports.revalidateStripeDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: paramError.errors[0].msg,
    });
  }
  try {
    const coachId = req.coach._id;
    const coachData = await CoachModel.findOne({ _id: coachId });
    if (!coachData) {
      return res.status(404).json({
        success: false,
        message: "Your account details are not found right now",
      });
    }
    const bankDetails = await this.getBankDetails(coachData.stripe_accID);
    if (!bankDetails) {
      return res.status(200).json({
        success: false,
        title: "No Bank Account Found",
        message:
          "You have not added any bank account to your Stripe onboarding. Would you like to refresh the details or complete onboarding again?",
      });
    }
    const bankObj = CountriesOptions.find(
      (a) => a.code?.toUpperCase() === bankDetails.country?.toUpperCase()
    );
    if (!bankObj) {
      return res.status(200).json({
        success: false,
        title: "Unsupported Bank Account Found",
        message:
          "You have not added any bank account to your Stripe onboarding. Would you like to refresh the details or complete onboarding again?",
      });
    }
    await CoachModel.findByIdAndUpdate(
      coachId,
      {
        $set: {
          stripeCountryDetails: {
            code: bankObj.code,
            label: bankObj.label,
            phone: bankObj.phone,
            currency: bankObj.currency,
          },
        },
      },
      { new: true }
    );
    return res.status(200).json({
      success: true,
      message: "Stripe country details revalidated successfully",
    });
  } catch (err) {
    console.error("Stripe Account Error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Something went wrong. Please try again later.",
    });
  }
};
exports.refreshBankAndStripeAccount = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: paramError.errors[0].msg,
    });
  }
  try {
    const coachId = req.coach._id;
    const coachData = await CoachModel.findOne({ _id: coachId });
    if (!coachData) {
      return res.status(404).json({
        success: false,
        message:
          "Your account details are not found right now, Please try again later",
      });
    }
    await CoachModel.findByIdAndUpdate(
      coachId,
      {
        $set: {
          stripe_onboardStatus: 0,
          stripe_addStatus: 0,
        },
        $unset: {
          stripe_accID: 1,
          stripeCountryDetails: 1,
          accHolderId: 1,
        },
      },
      { new: true }
    );
    return res.status(200).json({
      success: true,
      message: "Account details revoked successfully",
    });
  } catch (err) {
    console.error("Stripe Account Error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Something went wrong. Please try again later.",
    });
  }
};





/*
 * Retrieves bank country and currency from a Stripe account's external bank account.
 * @param {string} stripeAccID - The Stripe connected account ID.
 * @returns {Promise<{country: string, currency: string} | null>}
 */
exports.getBankDetails = async (stripeAccID) => {
  if (!stripeAccID) throw new Error("Missing Stripe account ID");

  try {
    const bankAccounts = await stripe.accounts.listExternalAccounts(
      stripeAccID,
      {
        object: "bank_account",
        limit: 1, // adjust if multiple accounts are expected
      }
    );

    const bank = bankAccounts.data[0];
    if (!bank) return null;
    return {
      country: bank.country,
      currency: bank.currency,
    };
  } catch (err) {
    console.error("Stripe bank details fetch error:", err.message);
    return null;
  }
};
