const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
//import the modals
const coachAvailabilityModal = require("../../../models/coachAvailability");
const CoachModel = require("../../../models/coach");
const { CreateNotification } = require("../../../models/notificationModal");

//Add new session
exports.AddcoachAvailability = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const data = req.body;
    await coachAvailabilityModal.updateOne({ coachId }, data, {
      upsert: true,
    });
    const response = {
      success: true,
      message: "coach availability added successfully",
    };
    await CreateNotification({
      user_id: coachId,
      heading: `Weekly availability updated !`,
      description: `Your weekly availability was updated successfully, you can review it by clickng on the view button.`,
      url: `/c/availability`,
      notification_type: "alerts",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
//Add new session
exports.getcoachAvailability = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const [data, coachData] = await Promise.all([
      coachAvailabilityModal.find({ coachId }),
      CoachModel.find({ _id: coachId }).select("timeZone"),
    ]);

    const response = {
      success: true,
      data: data[0],
      coachTimeZone: coachData[0].timeZone,
      message: "coach availability get successfully",
    };

    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getcoachAvailabilityOfCoach = async (req, res) => {
  try {
    const coachId = req.params.id; //login coach-id
    const [data, coachData] = await Promise.all([
      coachAvailabilityModal.find({ coachId }),
      CoachModel.find({ _id: coachId }).select("timeZone"),
    ]);
    const response = {
      success: true,
      data: data[0],
      coachTimeZone: coachData[0].timeZone,
      message: "coach availability get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
