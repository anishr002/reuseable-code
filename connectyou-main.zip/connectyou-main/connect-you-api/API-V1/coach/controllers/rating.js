const { validationResult } = require("express-validator");
require("dotenv").config();
const mongoose = require("mongoose");
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const orderRatingModal = require("../../../models/orderRating");

//order details
exports.CoachRating = async (req, res) => {
  try {
    const coachId = req.params.id;
    const ratingData = await orderRatingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $project: {
          _id: 1,
          message: 1,
          createdAt: 1,
          ratingNumber: 1,
          Userid: "$userData._id",
          name: "$userData.name",
          image: "$userData.image",
          gender: "$userData.gender",
        },
      },
    ]);

    const responce = {
      success: true,
      data: ratingData,
      message: "Rating get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.findRecent = async (req, res) => {
  try {
    const limit = Number(req.query.limit || 10);
    const data = await orderRatingModal.aggregate([
      {
        $match: {
          ratingNumber: { $gte: 4 },
        },
      },
      { $sort: { createdAt: -1 } }, // Sort by createdAt (latest first)
      {
        $group: {
          _id: "$userId", // Group by userId (unique document for each user)
          latestRating: { $first: "$$ROOT" }, // Get the latest document for each user
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $project: {
          _id: "$latestRating._id",
          message: "$latestRating.message",
          createdAt: "$latestRating.createdAt",
          ratingNumber: "$latestRating.ratingNumber",
          Userid: "$userData._id",
          name: "$userData.name",
          image: "$userData.image",
          gender: "$userData.gender",
        },
      },
      { $limit: limit }, // Limit the number of documents (if needed)
    ]);

    return res.status(200).json({
      success: true,
      message: "Fetched Recent Ratings successfully",
      data,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
