require("dotenv").config();
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const mongoose = require("mongoose");
const moment = require("moment-timezone");
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const CoachModel = require("../../../models/coach");
const coachCertificateModal = require("../../../models/coachCertificate");
const CoachCredentialsModal = require("../../../models/CoachCredentials");
const CoachExperienceModal = require("../../../models/CoachExperience");
const CoachEducationModal = require("../../../models/CoachEducation");
const coachGTokenModal = require("../../../models/coachGToken");
const coachAccDeleteModal = require("../../../models/coachAccDelete");
const deviceModal = require("../../../models/webToken");
const booked_sessions = require("../../../models/booked_session");

const oAuth2Client = require("../../../oAuth2Client");
const {
  GetUsersNotification,
  ReadNotification,
  CreatePasswordResetNotification,
  CreateNotification,
  CreateAdminLevelNotification,
  MarkAllAsRead,
} = require("../../../models/notificationModal");
const {
  getMyReferralsData,
  getRewardPoints,
} = require("../../../models/referral");
const userModal = require("../../../models/user");
const {
  createApprovalReqest,
} = require("../../../models/coachProfileApproval");
const {
  updateCoachProfileComplitionStatus,
} = require("../../../models/CoachProfileCompletionStatus");

const transportEmail = require("../../../lib/email");
const {
  fetchnotification_preferrences,
  addOrUpdatenotification_preferrences,
} = require("../../../models/notification_preferrence");
const {
  fetchAgreementStatus,
  requestCoachAgreementapproval,
} = require("../../../models/coach_agreement");
const { checkGoogleCalendarAccess } = require("../../../lib/coach");
const userModel = require("../../../models/user");
const {
  sendAccountDeletionEmail,
  passwordRecoveryUpdateEmail,
} = require("../../../utils/quickEmails");

//coach profile
exports.profile = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(coachId),
        },
      },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachexperiences",
          localField: "_id",
          foreignField: "coachId",
          as: "coachexperiences",
        },
      },
      {
        $lookup: {
          from: "coacheducations",
          localField: "_id",
          foreignField: "coachId",
          as: "coacheducations",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);
    if (coachData.length > 0) {
      let data = {
        name: coachData[0].name,
        userName: coachData[0].userName,
        Lname: coachData[0].Lname,
        email: coachData[0].email,
        gender: coachData[0].gender,
        DOB: coachData[0].DOB,
        approve: coachData[0].approve,
        image: coachData[0].image,
        createdAt: coachData[0].createdAt,
        freeTrial: coachData[0].freeTrial,
        about_me: coachData[0].about_me,
        title_line: coachData[0].title_line,
        languages: coachData[0].languages,
        fullAddress: coachData[0].fullAddress,
        country: coachData[0].country,
        industries: coachData[0].industries,
        city: coachData[0].city,
        zoomMeetingURL: coachData[0].zoomMeetingURL,
        linkedin_profile_link: coachData[0].linkedin_profile_link,
        coachingSpecialities: coachData[0].coachingSpecialities,
        coaching_focus_area: coachData[0].coaching_focus_area,
        zoomId: coachData[0].zoomId,
        zoomAccStatus: coachData[0].zoomAccStatus,
        calendarStatus: coachData[0].calendarStatus,
        updateStatus: coachData[0].updateStatus,
        averageRating: coachData[0].averageRating,
        totalRatings: coachData[0].totalRatings,
        timeZone: coachData[0].timeZone,
        emailVerified: coachData[0].emailVerified,
        experienceYear: coachData[0].experienceYear,
        deleteReq: coachData[0].deleteReq,
        userType: "coach",
        stripe_accID: coachData[0].stripe_accID,
        stripe_addStatus: coachData[0].stripe_addStatus,
        hub_spot_id: coachData[0].hub_spot_id,
        _id: coachData[0]._id,
        refered_by_partner: coachData[0].refered_by_partner || 0,
        nonProfitCoaching: coachData[0].nonProfitCoaching
          ? coachData[0].nonProfitCoaching
          : false,
        refering_partner: coachData[0].refering_partner,
        // need to verify names
        coachcredentials: coachData[0].coachcredentials,
        coachexperiences: coachData[0].coachexperiences,
        coacheducations: coachData[0].coacheducations,
        coachcertificates: coachData[0].coachcertificates,
        // same as above but with different var names//
        coachCertificatesList: coachData[0].coachcertificates,
        coachEducationalBackgroundList: coachData[0].coacheducations,
        coachingCredentialsList: coachData[0].coachcredentials,
        coachWorkExperiencesList: coachData[0].coachexperiences,
      };
      const response = {
        success: true,
        data,
        message: "Coach profile get successfully",
      };
      return res.status(200).json(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update
exports.profileUpdate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const updatedData = req.body;
    // updatedData.approve = 0;
    const imageFile = req.file;
    if (imageFile) {
      updatedData.image = imageFile.filename;
    } else {
      delete updatedData.image;
    }
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { $set: updatedData },
      { new: true }
    );
    const coachData = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(coachId),
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);

    let data = {
      _id: coachData[0]._id,
      name: coachData[0].name,
      email: coachData[0].email,
      gender: coachData[0].gender,
      DOB: coachData[0].DOB,
      approve: coachData[0].approve,
      image: coachData[0].image,
      createdAt: coachData[0].createdAt,
      Lname: coachData[0].Lname,
      userName: coachData[0].userName,
      averageRating: coachData[0].averageRating,
      totalRatings: coachData[0].totalRatings,
      timeZone: coachData[0].timeZone,
      emailVerified: coachData[0].emailVerified,
      userType: "coach",
    };

    const authToken = await jwt.sign(data, JWT_SECRET);
    data.token = authToken;

    const response = {
      success: true,
      data,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachData[0]._id,
      Section: "Personal Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log({ err });
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update address
exports.profileUpdateAddress = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { selectedAddress, city, country, lat, lng } = req.body;
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      {
        $set: {
          city,
          country,
          fullAddress: selectedAddress,
          // approve: 0,
          location: { type: "Point", coordinates: [lng, lat] },
        },
      },
      { new: true }
    );

    const response = {
      success: true,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Address Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update free triyl
exports.profileUpdateFreeTriyl = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { freeTrial } = req.body;
    const freeTrialUpdate = freeTrial === "true" ? "false" : "true";
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { $set: { freeTrial: freeTrialUpdate } },
      // { $set: { freeTrial: freeTrialUpdate, approve: 0 } },
      { new: true }
    );

    const response = {
      success: true,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Free Trial Information",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update other/more
exports.profileUpdateMore = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const updatedData = req.body;

    // updatedData.approve = 0;
    const coachData = await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { $set: updatedData },
      { new: true }
    );

    let data = {
      _id: coachData._id,
      name: coachData.name,
      email: coachData.email,
      gender: coachData.gender,
      DOB: coachData.DOB,
      approve: coachData.approve,
      image: coachData.image,
      createdAt: coachData.createdAt,
      title_line: coachData.title_line,
      about_me: coachData.about_me,
      userName: coachData.userName,
      emailVerified: coachData.emailVerified,
      userType: "coach",
    };
    const authToken = await jwt.sign(data, JWT_SECRET);
    data.token = authToken;
    const response = {
      success: true,
      data,
      message: "Coach profile updated successfully",
    };

    await sendNotificationOnUpdates({
      user_id: coachData._id,
      Section: "Professional Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update other/more
exports.profileUpdateCoachCredentials = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { title, endDate } = req.body;
    const imageFile = req.file;
    await new CoachCredentialsModal({
      coachId: coachId,
      title,
      image: imageFile.filename,
      endDate,
    }).save();
    // await CoachModel.findByIdAndUpdate(
    //   { _id: coachId },
    //   { $set: { approve: 0 } },
    //   { new: true }
    // );
    const response = {
      success: true,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Coaching Credentail Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update Experience
exports.profileUpdateCoachExperience = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { organization, position, startDate, endDate } = req.body;
    // endDateCheckbox: any | null;

    await new CoachExperienceModal({
      coachId: coachId,
      organization,
      position,
      startDate,
      endDate,
      workingOn: req.body.endDateCheckbox,
    }).save();
    // await CoachModel.findByIdAndUpdate(
    //   { _id: coachId },
    //   { $set: { approve: 0 } },
    //   { new: true }
    // );
    const response = {
      success: true,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Experience Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update-certificate
exports.profileUpdateCertificate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { title } = req.body;
    const certificateFile = req.file;
    const certificateFilename = certificateFile.filename;
    await new coachCertificateModal({
      coachId: coachId,
      title,
      certificateFile: certificateFilename,
    }).save();
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { $set: { approve: 0 } },
      { new: true }
    );
    const response = {
      success: true,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Certification Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update-delete-certificate
exports.profileUpdateDeleteCertificate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const certificateId = req.params.id;

    await coachCertificateModal.deleteOne({
      _id: certificateId,
      coachId,
    });
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { $set: { approve: 0 } },
      { new: true }
    );
    const response = {
      success: true,
      message: "Certificate deleted successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile-update Education
exports.profileUpdateCoachEducation = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { organization, degree, startDate, endDate } = req.body;
    // endDateCheckbox: any | null;

    await new CoachEducationModal({
      coachId: coachId,
      organization,
      degree,
      startDate,
      endDate,
    }).save();
    // await CoachModel.findByIdAndUpdate(
    //   { _id: coachId },
    //   { $set: { approve: 0 } },
    //   { new: true }
    // );
    const response = {
      success: true,
      message: "Coach profile updated successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Education Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach password-update
exports.passwordUpdate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { old_password, new_password } = req.body;
    const bcryptPassword = await bcrypt.hash(new_password, 10);
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      const bcryptData = await bcrypt.compare(
        old_password,
        coachData[0].password
      );
      if (!bcryptData) {
        return res.status(401).json({
          success: false,
          message: "Incorrect old password. Please try again.",
        });
      } else {
        await CoachModel.findByIdAndUpdate(
          { _id: coachId },
          { $set: { password: bcryptPassword } },
          { new: true }
        );
        const response = {
          success: true,
          message: "Password updated successfully",
        };
        res.status(200).json(response);
        await passwordRecoveryUpdateEmail(
          `${coachData[0].name} ${coachData[0].Lname}`,
          coachData[0].email,
          true
        );
        await CreatePasswordResetNotification({ user_id: coachData[0]._id });
        return;
      }
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach list
exports.coachList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    // console.log({ q: req.query });
    let matchCriteria = {};
    let matchCriteria2 = {};
    let industriesMatch = {};
    let coachCredentialsMatch = {};
    if (req.query.coachCredentials) {
      let coachCredentialsArray = req.query.coachCredentials
        .split(/,(?![^()]*\))/)
        .map((item) => item.trim());
      if (coachCredentialsArray.length > 0) {
        coachCredentialsMatch = {
          "coachcredentials.title": {
            $all: coachCredentialsArray,
          },
        };
      }
    }

    if (req.query.rating) {
      let rating = Number(req.query.rating);
      matchCriteria.averageRating = { $gte: rating };
    }

    if (req.query.country && req.query.country != "null") {
      let country = req.query.country.trim();
      matchCriteria.country = { $regex: new RegExp(country, "i") };
    }
    // experience Year filter
    if (req.query.yearsOfExpFrom && req.query.yearsOfExpFrom !== "") {
      let yearsOfExpFrom = req.query.yearsOfExpFrom.trim();
      let yearsOfExpTo = req.query.yearsOfExpTo.trim();
      matchCriteria.experienceYear = {
        $gte: Number(yearsOfExpFrom),
        $lte: Number(yearsOfExpTo),
      };
    }

    if (req.query.coachName) {
      let coachName = req.query.coachName.trim();
      matchCriteria.name = { $regex: new RegExp(coachName, "i") };
    }

    // Check if gender is provided and add it to match criteria
    if (req.query.gender) {
      let genderArray = req.query.gender.split(",");
      matchCriteria.gender = { $in: genderArray };
    }

    // Check if languages are provided and add them to match criteria
    if (req.query.languages) {
      let languages = req.query.languages.split(",");
      matchCriteria2.$expr = {
        $setIsSubset: [languages, "$languages"],
      };
    }

    if (req.query.industries) {
      let industries = req.query.industries.split(",");
      industriesMatch.$expr = {
        $setIsSubset: [industries, "$industries"],
      };
    }

    // Check if specialities are provided and add them to match criteria
    if (req.query.specialities) {
      let coachingSpecialities = req.query.specialities.split(",");
      matchCriteria.$expr = {
        ...matchCriteria.$expr,
        $setIsSubset: [coachingSpecialities, "$coachingSpecialities"],
      };
    }
    let basicMatch = {
      delete: 0,
      approve: 1,
      // calendarStatus: 1,
      image: { $ne: "" },
    };

    if (req.query.npcoaching === "true") {
      basicMatch.nonProfitCoaching = {
        $exists: true,
        $eq: true,
      };
    }
    const match = { $match: matchCriteria }; //filter provoided data
    const match2 = { $match: matchCriteria2 }; //filter languages data
    const industriesMatchFilter = { $match: industriesMatch }; //filter industries Match data
    const coachCredentialsMatchFilter = { $match: coachCredentialsMatch };
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    const coachList = await CoachModel.aggregate([
      {
        $match: basicMatch,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $match: {
          coachcredentials: { $ne: [] },
          coachcertificates: { $ne: [] },
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: 0,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
      match,
      match2,
      industriesMatchFilter,
      coachCredentialsMatchFilter,
      {
        $project: {
          _id: 1,
          name: 1,
          Lname: 1,
          freeTrial: 1,
          image: 1,
          about_me: 1,
          title_line: 1,
          gender: 1,
          averageRating: 1,
          totalRatings: 1,
          country: 1,
          city: 1,
          userName: 1,
          languages: 1,
          industries: 1,
          coachingSpecialities: 1,
          experienceYear: 1,
          coachcredentials: 1,
        },
      },

      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (coachList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(coachList[0].pageInfo[0].count / limit);
    }

    const coachListData = coachList[0].data;
    const response = {
      success: true,
      coachList: coachListData,
      totalPages,
      currentPage: pageNo,
      message: "coach list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach list for home page
exports.coachList4 = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachList1 = await CoachModel.aggregate([
      {
        $match: {
          delete: 0,
          approve: 1,
          // calendarStatus: 1,
          image: { $ne: "" },
          // zoomMeetingURL: { $ne: "" },
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $match: {
          coachcredentials: { $ne: [] },
          coachcertificates: { $ne: [] },
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: { $avg: "$ordersRatingsData.ratingNumber" },
              else: null,
            },
          },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          Lname: 1,
          freeTrial: 1,
          image: 1,
          about_me: 1,
          title_line: 1,
          gender: 1,
          averageRating: 1,
          country: 1,
          city: 1,
          userName: 1,
        },
      },
      {
        $limit: 10,
      },
      { $sort: { createdAt: -1 } },
      {
        $project: {
          password: 0, // Exclude the password field
        },
      },
    ]);

    const response = {
      success: true,
      coachList1: coachList1,
      message: "coach list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach details without token
exports.coachDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(404).json(response);
  }
  try {
    const id = req.params.id;
    const coachDetail = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(id),
          delete: 0,
          approve: 1,
          // calendarStatus: 1,
          image: { $ne: "" },
        },
      },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "coachexperiences",
          localField: "_id",
          foreignField: "coachId",
          as: "coachexperiences",
        },
      },
      {
        $lookup: {
          from: "coacheducations",
          localField: "_id",
          foreignField: "coachId",
          as: "coacheducations",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: { $size: "$ordersRatingsData" },
        },
      },
      {
        $project: {
          name: 1,
          Lname: 1,
          userName: 1,
          email: 1,
          gender: 1,
          DOB: 1,
          approve: 1,
          image: 1,
          createdAt: 1,
          about_me: 1,
          title_line: 1,
          languages: 1,
          timeZone: 1,
          fullAddress: 1,
          coachingSpecialities: 1,
          coachcredentials: {
            $map: {
              input: "$coachcredentials",
              as: "credential",
              in: {
                title: "$$credential.title",
                image: "$$credential.image",
                startDate: "$$credential.startDate",
                workingOn: "$$credential.workingOn",
                endDate: "$$credential.endDate",
              },
            },
          },
          coachcertificates: {
            $map: {
              input: "$coachcertificates",
              as: "coachcertificates",
              in: {
                title: "$$coachcertificates.title",
                certificateFile: "$$coachcertificates.certificateFile",
                startDate: "$$coachcertificates.startDate",
                workingOn: "$$coachcertificates.workingOn",
                endDate: "$$coachcertificates.endDate",
              },
            },
          },
          coachexperiences: {
            $map: {
              input: "$coachexperiences",
              as: "experience",
              in: {
                organization: "$$experience.organization",
                position: "$$experience.position",
                startDate: "$$experience.startDate",
                workingOn: "$$experience.workingOn",
              },
            },
          },
          coacheducations: {
            $map: {
              input: "$coacheducations",
              as: "education",
              in: {
                degree: "$$education.degree",
                endDate: "$$education.endDate",
                organization: "$$education.organization",
                startDate: "$$education.startDate",
              },
            },
          },
          totalRatings: 1,
          averageRating: 1,
          experienceYear: 1,
          country: 1,
          city: 1,
          industries: 1,
        },
      },
    ]);

    if (coachDetail.length > 0) {
      let data = {
        name: coachDetail[0].name,
        Lname: coachDetail[0].Lname,
        userName: coachDetail[0].userName,
        email: coachDetail[0].email,
        gender: coachDetail[0].gender,
        DOB: coachDetail[0].DOB,
        approve: coachDetail[0].approve,
        image: coachDetail[0].image,
        createdAt: coachDetail[0].createdAt,
        about_me: coachDetail[0].about_me,
        title_line: coachDetail[0].title_line,
        languages: coachDetail[0].languages,
        timeZone: coachDetail[0].timeZone,
        fullAddress: coachDetail[0].fullAddress,
        coachingSpecialities: coachDetail[0].coachingSpecialities,
        coachcredentials: coachDetail[0].coachcredentials,
        coachcertificates: coachDetail[0].coachcertificates,
        coachexperiences: coachDetail[0].coachexperiences,
        coacheducations: coachDetail[0].coacheducations,
        totalRatings: coachDetail[0].totalRatings,
        averageRating: coachDetail[0].averageRating,
        experienceYear: coachDetail[0].experienceYear,
        country: coachDetail[0].country,
        city: coachDetail[0].city,
        industries: coachDetail[0].industries,
      };
      const response = {
        success: true,
        coachDetails: data,
        message: "coach details retrieved successfully",
      };
      return res.status(200).json(response);
    } else {
      return res
        .status(404)
        .json({ success: false, message: "Coach not found" });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach booked date and time
exports.coachBookedDate = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(401).json(response);
  }
  try {
    const id = req.params.id;
    const { sessionDate, userId, timeZone } = req.body;
    const startOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .startOf("day")
      .utc()
      .toDate();
    const endOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .endOf("day")
      .utc()
      .toDate();
    const data = await booked_sessions
      .find({
        $or: [
          {
            coachId: new mongoose.Types.ObjectId(id),
            sessionStatus: 0,
            sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
          },
          {
            userId: new mongoose.Types.ObjectId(userId),
            sessionStatus: 0,
            sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
          },
        ],
      })
      .select("-_id sessionDateUpdated");
    const bookedDate = data.map((entry) => ({
      from: entry.sessionDateUpdated,
      to: moment(entry.sessionDateUpdated).add(1, "hour").toISOString(),
    }));
    const response = {
      success: true,
      data: bookedDate,
      message: "coach details retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
//Coach booked date and time
exports.coachBookedDateForCoach = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(401).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { sessionDate, timeZone, userId } = req.body;

    const startOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .startOf("day")
      .utc()
      .toDate();
    const endOfDay = moment
      .tz(sessionDate, "DD-MM-YYYY HH:mm", timeZone)
      .endOf("day")
      .utc()
      .toDate();
    const data = await booked_sessions
      .find({
        $or: [
          {
            coachId: new mongoose.Types.ObjectId(coachId),
            sessionStatus: 0,
            sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
          },
          {
            userId: new mongoose.Types.ObjectId(userId),
            sessionStatus: 0,
            sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
          },
        ],
      })
      .select("-_id sessionDateUpdated");
    const bookedDate = data.map((entry) => ({
      from: entry.sessionDateUpdated,
      to: moment(entry.sessionDateUpdated).add(1, "hour").toISOString(),
    }));
    const response = {
      success: true,
      data: bookedDate,
      message: "coach details retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Delete Coaching Credentials
exports.coachCredentialsDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(404).json(response);
  }
  try {
    const id = req.params.id;
    await CoachCredentialsModal.deleteOne({ _id: id });
    // await CoachModel.findByIdAndUpdate(
    //   { _id: coachId },
    //   { $set: { approve: 0 } },
    //   { new: true }
    // );
    const response = {
      success: true,
      message: "coach Credentials deleted successfully",
    };
    await sendNotificationOnUpdates({
      user_id: id,
      Section: "Coaching Credentail Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Delete Coaching Credentials
exports.coachExperienceDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(404).json(response);
  }
  try {
    const id = req.params.id;
    await CoachExperienceModal.deleteOne({ _id: id });
    // await CoachModel.findByIdAndUpdate(
    //   { _id: coachId },
    //   { $set: { approve: 0 } },
    //   { new: true }
    // );

    const response = {
      success: true,
      message: "coach Experience deleted successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Experience Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Delete education
exports.coachEducationDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(404).json(response);
  }
  try {
    const id = req.params.id;
    await CoachEducationModal.deleteOne({ _id: id });
    // await CoachModel.findByIdAndUpdate(
    //   { _id: coachId },
    //   { $set: { approve: 0 } },
    //   { new: true }
    // );
    const response = {
      success: true,
      message: "coach Education deleted successfully",
    };
    await sendNotificationOnUpdates({
      user_id: coachId,
      Section: "Education Details",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//add google calendar
exports.googleCalandarURL = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const authUrl = oAuth2Client.generateAuthUrl({
      access_type: "offline",
      scope: ["https://www.googleapis.com/auth/calendar.events.owned"],
      prompt: "consent",
      state: coachId.toString(),
    });
    const response = {
      success: true,
      data: authUrl,
      message: "Google Calender auth link retrieved successfully",
    };
    await CreateNotification({
      user_id: coachId,
      heading: "Google Calendar Added !",
      description:
        "Google Calendar has been linked with you profile successfully, you will recieve all your schedules, meetings details and alert via google calendar.",
      url: "/c/profile",
      notification_type: "authentication",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//google calender redirect url
exports.oauth2callback = async (req, res) => {
  try {
    const code = req.query.code;
    const coachId = req.query.state;
    if (code && coachId) {
      const { tokens } = await oAuth2Client.getToken(code);
      await coachGTokenModal.updateOne(
        { coachId: coachId },
        {
          $set: {
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            scope: tokens.scope,
            token_type: tokens.token_type,
            expiry_date: tokens.expiry_date,
          },
        },
        { upsert: true }
      );

      await CoachModel.findByIdAndUpdate(
        { _id: coachId },
        {
          $set: {
            calendarStatus: 1,
            calendarAddedDate: new Date().toISOString().split("T")[0],
          },
        },
        { new: true }
      );

      return res.redirect(
        `${process.env.FRONTEND_URL_web}/c/profile?gatsuccess=completed`
      );
    } else {
      return res.redirect(
        `${process.env.FRONTEND_URL_web}/c/profile?gatsuccess=aborted`
      );
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach profile submit for review
exports.profileSubmitForReview = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { $set: { updateStatus: 1 } },
      { new: true }
    );
    await createApprovalReqest({ coach_id: coachId });

    function capitalizeFirstLetter(str) {
      if (!str) return "";
      return str.charAt(0).toUpperCase() + str.slice(1);
    }
    const capitalizedName = capitalizeFirstLetter(coachData.name);
    const mailOptions = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: ["blossom.reactdev@gmail.com"],
      subject: `Request for Profile Approval from ${capitalizedName}`,
      template: "approvalReqCoach-admin",
      context: {
        coachName: capitalizedName,
        coachEmail: coachData.email,
        urlLink: `/coach/detail/${coachData._id}`,
      },
    };
    await transportEmail.createEmail({ mailOptions });
    const response = {
      success: true,
      message: "Approval sended successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Email verification start
//send email on given mail for email verificaton
exports.sendEmail = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { timezone } = req.body;
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      const otp = Math.floor(10000 + Math.random() * 90000);

      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: coachData[0].email,
        subject: "Email verificaton",
        template: "send-otp",
        context: {
          name: coachData[0].name,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        console.log({ error });
        const response = {
          success: false,
          message: "Something went wrong",
        };
        return res.status(500).json(response);
      } else {
        const otpExpiry = moment()
          .tz("Asia/Kolkata")
          .add(5, "minutes")
          .format("YYYY-MM-DD HH:mm:ss");

        await CoachModel.findByIdAndUpdate(
          { _id: coachData[0]._id },
          {
            $set: {
              otp: otp,
              otpType: "Email-verification",
              otpDate: otpExpiry,
            },
          }
        );
        const response = {
          success: true,
          message: "Email send successfully",
        };
        return res.status(200).json(response);
      }
    } else {
      const response = { success: false, message: "Invalid credentials" };
      return res.status(401).json(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//otp verification for email verificaton
exports.OTPverification = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { timezone, otp } = req.body;
    const coachId = req.coach._id; //login coach-id
    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      if (otp != coachData[0].otp) {
        const response = {
          success: false,
          message: "The OTP you entered is incorrect",
        };
        return res.status(403).json(response);
      }
      const otpExpiryDate = moment(coachData[0].otpDate).tz("Asia/Kolkata");
      const isOtpExpired = moment().tz("Asia/Kolkata").isAfter(otpExpiryDate);

      if (isOtpExpired) {
        const response = {
          success: false,
          message: "OTP verification maximum time exceeded",
        };
        return res.status(401).json(response);
      }
      await CoachModel.findByIdAndUpdate(
        { _id: coachData[0]._id },
        {
          $set: {
            emailVerified: 1,
            otp: 0,
            otpType: "",
            otpDate: "",
          },
        }
      );
      const response = {
        success: true,
        message: "Your email verified successfully",
      };
      await CreateNotification({
        user_id: coachId,
        heading: "Email Verified !",
        description:
          "Your Email address has been verified successfully, Thank you !",
        url: "/u/profile",
        notification_type: "authentication",
      });
      return res.status(200).json(response);
    } else {
      const response = {
        success: false,
        message: "Something went wrong try again after some time",
      };
      return res.status(401).json(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach password-check for delete account
exports.accountDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { password, reason, message } = req.body;

    const coachData = await CoachModel.find({ _id: coachId });
    if (coachData.length > 0) {
      const bcryptData = await bcrypt.compare(password, coachData[0].password);
      if (!bcryptData) {
        return res.status(401).json({
          success: false,
          message: "Incorrect Password. Please try again.",
        });
      } else {
        await new coachAccDeleteModal({
          coachId,
          reason,
          message,
        }).save();
        await CoachModel.findByIdAndUpdate(
          { _id: coachId },
          { $set: { deleteReq: 2 } }
        );
        const response = {
          success: true,
          message: "Account deleted successfully",
        };
        await sendAccountDeletionEmail(
          `${coachData[0].name} ${coachData[0].Lname}`,
          coachData[0].email
        );
        await CreateAdminLevelNotification({
          heading: `${coachData[0].name} ${coachData[0].Lname} have just deleted their account !`,
          description: `A coach have deleted their account, check details by clicking on the view button.`,
          url: `/coach/detail/${coachData[0]._id}`,
          notification_type: "authentication",
        });
        return res.status(200).json(response);
      }
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//add coach device Tokan
exports.deviceTokanAdd = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { token, deviceId } = req.body;
    const coachId = req.coach._id; //login coach-id
    await deviceModal.deleteMany({ deviceId });
    new deviceModal({
      userId: coachId,
      userType: "coach",
      deviceId: deviceId,
      deviceToken: token,
    }).save();
    const response = {
      success: true,
      message: "Data save successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//remove coach token
exports.unsubscibeWebPush = async (req, res) => {
  try {
    const { token, deviceId } = req.body;
    const coachId = req.coach._id; //login coach-id
    await deviceModal.deleteMany({ deviceId });
    const response = {
      success: true,
      message: "Web Push Notification Unsubscribed.",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getAllNotifications = async (req, res) => {
  try {
    const { _id } = req.body;
    const page = req.query.page || 1;
    const limit = req.query.limit || 10;
    const filter = req.query.filter || 0;
    const notifications = await GetUsersNotification({
      _id,
      page,
      limit,
      filter,
    });

    if (!notifications.success) {
      return res
        .status(500)
        .json({ success: false, message: "Internal Server error" });
    } else {
      return res.status(200).json({
        success: true,
        message: "Fetched User's Notification",
        data: notifications.Notifications,
        totalPages: notifications.totalPages,
        unreadNotifications: notifications.unreadNotifications,
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.markAsRead = async (req, res) => {
  try {
    const { _id } = req.body;
    const Read = await ReadNotification({ _id });
    if (!Read.success) {
      return res.status(500).json({ success: false, message: Read.message });
    } else {
      return res.status(200).json({
        success: true,
        message: "Notifications marked as read",
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.ReadAll = async (req, res) => {
  try {
    const { _id } = req.body;
    const Read = await MarkAllAsRead({ entityId: _id });
    if (!Read.success) {
      return res.status(500).json({ success: false, message: Read.message });
    } else {
      return res.status(200).json({
        success: true,
        message: "All Notifications marked as read",
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getnotificationPrefs = async (req, res) => {
  try {
    const entityId = req.coach._id;
    const fetchData = await fetchnotification_preferrences({ entityId });
    if (!fetchData.success) {
      return res.status(fetchData.status).json({
        success: fetchData.success,
        message: fetchData.message,
        data: fetchData.fetchData,
      });
    } else {
      return res.status(fetchData.status).json({
        success: fetchData.success,
        message: fetchData.message,
        data: fetchData.data,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.updatenotificationoPrefs = async (req, res) => {
  try {
    const preferrences = req.body.preferrences;
    const pauseAll = req.body.pauseAll;
    const entityId = req.coach._id;
    const updatedData = await addOrUpdatenotification_preferrences({
      entityId,
      preferrences: preferrences,
      pauseAll,
    });
    if (!updatedData.success) {
      return res.status(updatedData.status).json({
        success: updatedData.success,
        message: updatedData.message,
        data: updatedData.fetchData,
      });
    } else {
      return res.status(updatedData.status).json({
        success: updatedData.success,
        message: updatedData.message,
        data: updatedData.data,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getConncections = async (req, res) => {
  try {
    const id = req.params.id;
    const connectiondata = await getMyReferralsData({ _id: id });
    const points = await getRewardPoints({ user_id: id });
    const pointsMultiplier = 50;
    if (connectiondata.success === false) {
      return res.status(404).json({ success: false, message: "No data found" });
    } else {
      return res.status(200).json({
        success: connectiondata.success,
        message: "Fetched Referrals Data successfully",
        data: connectiondata.data,
        points: points.data.totalVerifiedCount * pointsMultiplier || 0,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

const sendNotificationOnUpdates = async ({ user_id, Section }) => {
  const heading = ` ${Section} section updated !`;
  const description = `${Section} have been updated on your coach profile successfully, you can review them by clicking on the view button.`;
  const url = `/c/profile`;
  const done = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "authentication",
  });
  return { success: done.success };
};

exports.createNewApprovalReq = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coach_id = req.params.id;
    const newReq = await createApprovalReqest({ coach_id });

    if (newReq.success === false) {
      return res
        .status(500)
        .json({ success: false, message: "Internal Server error" });
    } else {
      return res.status(200).json({
        success: true,
        message: "Request submitted for approval from adminstrator.",
        data: newReq,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

//login coach
exports.updateSideNav = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id; //login coach-id

    const coachData = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(coachId),
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);

    if (coachData.length > 0) {
      let data = {
        _id: coachData[0]._id,
        name: coachData[0].name,
        Lname: coachData[0].Lname,
        email: coachData[0].email,
        gender: coachData[0].gender,
        approve: coachData[0].approve,
        DOB: coachData[0].DOB,
        createdAt: coachData[0].createdAt,
        image: coachData[0].image,
        userName: coachData[0].userName,
        averageRating: coachData[0].averageRating,
        totalRatings: coachData[0].totalRatings,
        userType: "coach",
        timeZone: coachData[0].timeZone,
        my_invitation_code: coachData[0].my_invitation_code,
      };
      const authToken = await jwt.sign(data, JWT_SECRET);
      data.token = authToken;
      const response = {
        success: true,
        data,
        message: "Coach login successfully",
      };
      return res.status(200).json(response);
    } else {
      const response = { success: false, message: "Invalid credentials" };
      return res.status(401).json(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.checkCompletionStatus = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { coach_id, data } = req.body;
    const statusChecked = await updateCoachProfileComplitionStatus({
      coach_id,
      data,
    });
    if (!statusChecked.success) {
      return res.status(500).json({
        success: false,
        message: "There was some unexpected server error",
      });
    } else {
      return res.status(200).json({
        success: true,
        message: "Coach profile completion validated",
        data: statusChecked.data,
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.CheckAgreementStatus = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id;
    const agreement_data = await fetchAgreementStatus({ coachId });
    return res.status(agreement_data.status).json({
      success: agreement_data.success,
      message: agreement_data.message,
      status: agreement_data.status,
      data: agreement_data.data,
      error: agreement_data.error,
      agreement_file: agreement_data.agreement_file,
      original_agreement: agreement_data.original_agreement,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.submitAgreement = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.coach._id;
    const agreement_file = req.file;
    if (!agreement_file || agreement_file.mimetype !== "application/pdf") {
      return res.status(400).json({
        success: false,
        message: "Please provide the signed agreement file in pdf format !",
      });
    }
    const agreement_data = await requestCoachAgreementapproval({
      coachId,
      agreement_file_name: agreement_file.filename,
    });
    return res.status(agreement_data.status).json({
      success: agreement_data.success,
      message: agreement_data.message,
      status: agreement_data.status,
      data: agreement_data.data,
      error: agreement_data.error,
      agreement_file: agreement_data.agreement_file,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getLiveStatuses = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      const error = new Error("Invalid URL");
      error.status = 400;
      throw error;
    }
    const _id = new mongoose.Types.ObjectId(id);
    const data = await userModel
      .find({ _id: _id })
      .select("_id live lastSeen name");
    const response = {
      success: true,
      message: "Coachee live status fetched",
      data: data[0],
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.getMyProfile = async (req, res) => {
  try {
    const cId = req.coach._id;
    const CoachId = new mongoose.Types.ObjectId(cId);
    const data = await CoachModel.findOne(
      {
        _id: CoachId,
      },
      `-password 
      -__v 
      -updatedAt 
      -block 
      -freeTrial 
      -approve 
      -delete 
      -deleteReq 
      -hub_spot_id 
      -block
      -delete
      -deleteReq
      -otp
      -otpType
      -otpDate 
      -registrationType
      -persionId_number
      -invoice_prefix
      -stripe_customerID
      -accHolderId
      -stripe_accID
      -stripe_addStatus
      -stripe_onboardStatus
      -currency
      -stripeCountryDetails
      -bankAccountID
      -updateStatus
      -Bcountry
      -Bcity
      -bankAccount_holder_name
      -bankAccount_routing_number
      -bankAccount_account_number
      -persionId_number
      -idProofFront
      -idProofBack
      -calendarStatus
      -calendarAddedDate
      -zoomMeetingURL
      -linkedin_profile_link
      -coachingSpecialities
      -emailVerified
      `
    );
    if (data) {
      return res.status(200).json({
        success: true,
        message: "Admin Profile fetched successfully",
        data: data,
      });
    } else {
      return res.status(401).json({
        success: false,
        message: "Admin Profile Not found, logout requested",
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: `Internal Server Error`,
    });
  }
};
