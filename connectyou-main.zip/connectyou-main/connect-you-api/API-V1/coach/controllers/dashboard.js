const { validationResult } = require("express-validator");
require("dotenv").config();
//environment variables
//import the modals
const orderModal = require("../../../models/booking");
const sessionModal = require("../../../models/coachSession");
const userModel = require("../../../models/user");
const coachPayoutModal = require("../../../models/coachPayout");
const completedOrdersModal = require("../../../models/completedOrders");
const sessionBookingModal = require("../../../models/booked_session");
const orderRatingModal = require("../../../models/orderRating");
const mongoose = require("mongoose");

//coach order list
exports.orderList = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const [
      totalSessions,
      pendingSessions,
      completedSessions,
      canceledSessions,
      payoutAmount,
      revenue,
      ratingList,
    ] = await Promise.all([
      sessionBookingModal.countDocuments({ coachId: coachId }),
      sessionBookingModal.countDocuments({
        coachId: coachId,
        sessionStatus: 0,
      }),
      sessionBookingModal.countDocuments({
        coachId: coachId,
        sessionStatus: 1,
      }),
      sessionBookingModal.countDocuments({
        coachId: coachId,
        sessionStatus: 2,
      }),
      coachPayoutModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        { $group: { _id: null, totalAmount: { $sum: "$amount" } } },
        {
          $project: {
            totalAmount: {
              $ifNull: ["$totalAmount", 0],
            },
          },
        },
      ]),
      sessionBookingModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
            sessionStatus: 1,
          },
        },
        {
          $facet: {
            totalRevenue: [
              {
                $group: {
                  _id: null,
                  total: { $sum: "$amount" },
                },
              },
            ],
          },
        },
        {
          $project: {
            totalRevenue: {
              $ifNull: [{ $arrayElemAt: ["$totalRevenue.total", 0] }, 0],
            },
          },
        },
      ]),
      orderRatingModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        { $sort: { createdAt: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "userData",
          },
        },
        { $unwind: "$userData" },
        {
          $project: {
            _id: 1,
            message: 1,
            createdAt: 1,
            ratingNumber: 1,
            Userid: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
          },
        },
      ]),
    ]);

    const totalRevenue1 =
      revenue.length > 0 ? Number(revenue[0].totalRevenue) * 0.6 : 0;
    const payoutAmount1 =
      payoutAmount.length > 0 ? Number(payoutAmount[0].totalAmount) / 100 : 0;
    const totalBalance1 = totalRevenue1 - payoutAmount1;
    const responce = {
      success: true,
      totalSessions,
      pendingSessions,
      completedSessions,
      canceledSessions,
      totalBalance: totalBalance1,
      totalRevenue: totalRevenue1,
      payoutAmount: payoutAmount1,
      ratingList,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach Completed  order list
exports.completedOrdersList = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const orderList = await sessionBookingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
          sessionStatus: 1,
        },
      },
      { $sort: { updatedAt: -1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          sessionCompletedDate: 1,
          userAvatar: "$userData.name",
          userAvatar: "$userData.image",
          title: "$sessionData.title",
          type: "$sessionData.type",
          price: "$sessionData.price",
          description: "$sessionData.description",
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderList,
      message: "Coach orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach last  order
exports.lastOrders = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const orderList = await sessionBookingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
        },
      },
      { $sort: { createdAt: -1 } },
      { $limit: 1 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          completedDateTime: 1,
          userAvatar: "$userData.name",
          userAvatar: "$userData.image",
          title: "$sessionData.title",
          type: "$sessionData.type",
          price: "$sessionData.price",
          description: "$sessionData.description",
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderList,
      message: "Coach orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//upcoming sessions
exports.upcomingSessions = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const sessionBookingData = await sessionBookingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
          sessionStatus: 0,
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "bookingId",
          foreignField: "_id",
          as: "orderDetails",
        },
      },
      {
        $match: {
          "orderDetails.paid": 1,
        },
      },

      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          bookingId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          coachTimeZone: "$coachData.timeZone",
          customer: {
            customer_city: 1,
            customer_country: 1,
            customer_email: 1,
            customer_line1: 1,
            customer_line2: 1,
            customer_name: 1,
            customer_phone: 1,
            customer_postal_code: 1,
            customer_state: 1,
          },
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
            timeZone: "$userData.timeZone",
          },
          sessionData: {
            _id: "$sessionData._id",
            coachId: "$sessionData.coachId",
            title: "$sessionData.title",
            price: "$sessionData.price",
            type: "$sessionData.type",
            description: "$sessionData.description",
          },
        },
      },
      { $limit: 5 },
      { $sort: { sessionDateUpdated: 1 } },
    ]);

    const responce = {
      success: true,
      data: sessionBookingData,
      message: "Coach upcoming Sessions get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
