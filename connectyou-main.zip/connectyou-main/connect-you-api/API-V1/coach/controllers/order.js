const { validationResult } = require("express-validator");
const { google } = require("googleapis");
const axios = require("axios");
const path = require("path");
const Stripe = require("stripe");
let admin = require("firebase-admin");
const moment = require("moment-timezone");
require("dotenv").config();
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const bookingModal = require("../../../models/booking");
const booked_sessionModal = require("../../../models/booked_session");
const rescheduled_sessionsModal = require("../../../models/rescheduled_sessions");
const CoachModel = require("../../../models/coach");
const userModel = require("../../../models/user");
const sessionModal = require("../../../models/coachSession");
const coachGTokenModal = require("../../../models/coachGToken");
const mongoose = require("mongoose");
const deviceModal = require("../../../models/webToken");

const oAuth2Client = require("../../../oAuth2Client");
const {
  CreateAdminLevelNotification,
  CreateNotification,
} = require("../../../models/notificationModal");
const calendar = google.calendar({ version: "v3", auth: oAuth2Client });

//get the accesstoken from google
const transportEmail = require("../../../lib/email");
const createdModal = require("../../../models/booked_session");
const { request_refund } = require("../../../models/refund_request");
const { getGoogleAccessToken, getCoachData } = require("../../../lib/coach");
const { getUserData } = require("../../../lib/coachee");
const {
  coachSessionEventUpdateEmailer,
  coacheeSessionEventUpdateEmailer,
} = require("../../../utils/quickEmails");
const { saveTimelineEntry } = require("../../../models/bookedSessionTimeLine");
const {
  removeCoachCalendarEvent,
  addEventToCoachsCalendar,
} = require("../../../lib/googleCalender");
const { formatMomemtTimeToStr } = require("../../../lib/formatMomemtTimeToStr");

//get booked session data
const getBookedSessionData = async (id) => {
  try {
    const Data = await booked_sessionModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(id),
        },
      },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          amount: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          title: "$sessionData.title",
          google_event_id: 1,
          sessionType: 1,
          cartId: 1,
          sessionId: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
        },
      },
    ]);
    if (Data.length > 0) {
      return Data[0];
    } else {
      throw (error = "server error");
    }
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};
//order details
const getOrderDetails = async (orderId) => {
  try {
    const orderData = await bookingModal.find({ _id: orderId });
    if (orderData.length == 0) {
      throw (error = "Order details not found");
    }
    return orderData[0];
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

//session remider email
//send session remider email to coach
const sessionRemiderEmailCoach = async (
  userName,
  coachName,
  sessionDate,
  sessionTime,
  coachEmail,
  zoomMeetingURL
) => {
  try {
    let userName1 = capitalizeFirstLetter(userName);
    let coachName1 = capitalizeFirstLetter(coachName);
    let setTime = `${formatTimeTo12hStr(sessionTime.split("-")[0])}-
    ${formatTimeTo12hStr(sessionTime.split("-")[1])}`;
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: coachEmail,
      subject: `Reminder: Upcoming Coaching Session with  ${userName1}`,
      template: "sessionRemiderCoach",
      context: {
        userName: userName1,
        coachName: coachName1,
        sessionDate,
        sessionTime: setTime,
        zoomMeetingURL,
      },
    };
    await transportEmail.createEmail({ mailOptions: mailOptionsForUser });
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

//send session remider email to user
const sessionRemiderEmailUser = async (
  userName,
  coachName,
  sessionDate,
  sessionTime,
  userEmail,
  zoomMeetingURL
) => {
  try {
    let userName1 = capitalizeFirstLetter(userName);
    let coachName1 = capitalizeFirstLetter(coachName);
    let setTime = `${formatTimeTo12hStr(sessionTime.split("-")[0])}-
    ${formatTimeTo12hStr(sessionTime.split("-")[1])}`;
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userEmail,
      subject: `Reminder: Upcoming Coaching Session with  ${coachName1}`,
      template: "sessionRemiderUser",
      context: {
        userName: userName1,
        coachName: coachName1,
        sessionDate,
        sessionTime: setTime,
        zoomMeetingURL,
      },
    };
    await transportEmail.createEmail({ mailOptions: mailOptionsForUser });
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

//coach order list
exports.orderList = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$bookingId", "$$bookingId"] },
                    { $eq: ["$coachId", new mongoose.Types.ObjectId(coachId)] },
                  ],
                },
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      {
        $addFields: {
          totalBookedAmount: {
            $sum: "$booked_sessionsData.amount",
          },
        },
      },

      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
            timeZone: "$userData.timeZone",
          },
          bookedSessionsCount: { $size: "$booked_sessionsData" },
          totalBookedAmount: 1,
          upcomingCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 0] },
              },
            },
          },
          completedCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 1] },
              },
            },
          },
          canceledCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 2] },
              },
            },
          },
        },
      },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);

    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      totalPages,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//with a coachee order list of a coach
exports.withCoacheeOrderList = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const coacheeId = req.params.coacheeId; //login coach-id
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
          userId: new mongoose.Types.ObjectId(coacheeId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$bookingId", "$$bookingId"] },
                    { $eq: ["$coachId", new mongoose.Types.ObjectId(coachId)] },
                  ],
                },
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      {
        $addFields: {
          totalBookedAmount: {
            $sum: "$booked_sessionsData.amount",
          },
        },
      },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
            timeZone: "$userData.timeZone",
          },
          bookedSessionsCount: { $size: "$booked_sessionsData" },
          totalBookedAmount: 1,
          upcomingCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 0] },
              },
            },
          },
          completedCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 1] },
              },
            },
          },
          canceledCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 2] },
              },
            },
          },
        },
      },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      totalPages,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//order details
exports.orderDetails = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const orderId = req.params.id;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(orderId),
          coachId: new mongoose.Types.ObjectId(coachId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$bookingId", "$$bookingId"] },
                    { $eq: ["$coachId", new mongoose.Types.ObjectId(coachId)] },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
          ],
          as: "booked_sessionsData",
        },
      },

      {
        $project: {
          _id: 1,
          // payment_intent: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
            timeZone: "$userData.timeZone",
          },
          coachData: {
            _id: "$coachData._id",
            name: "$coachData.name",
            Lname: "$coachData.Lname",
            image: "$coachData.image",
            gender: "$coachData.gender",
            title_line: "$coachData.title_line",
            zoomMeetingURL: "$coachData.zoomMeetingURL",
            timeZone: "$coachData.timeZone",
          },
          booked_sessionsData: {
            $map: {
              input: "$booked_sessionsData",
              as: "session",
              in: {
                _id: "$$session._id",
                sessionDate: "$$session.sessionDate",
                sessionDateUpdated: "$$session.sessionDateUpdated",
                sessionStatus: "$$session.sessionStatus",
                absentee: "$$session.absentee",
                sessionAmount: "$$session.amount",
                sessionCancelBy: "$$session.sessionCancelBy",
                messageCancel: "$$session.messageCancel",
                sessionCompletedUser: "$$session.sessionCompletedUser",
                sessionCompletedCoach: "$$session.sessionCompletedCoach",
                completedCoachMSG: "$$session.completedCoachMSG",
                completedUserMSG: "$$session.completedUserMSG",
                sessionData: {
                  _id: "$$session.sessionData._id",
                  coachId: "$$session.sessionData.coachId",
                  title: "$$session.sessionData.title",
                  price: "$$session.sessionData.price",
                  type: "$$session.sessionData.type",
                  description: "$$session.sessionData.description",
                },
              },
            },
          },
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderData[0],
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//ordered session details
exports.orderSessionDetails = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const orderId = req.params.id;
    const bookedSessionId = req.params.bookedSessionId;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(orderId),
          coachId: new mongoose.Types.ObjectId(coachId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "bookingId",
          as: "ratingsData",
        },
      },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$bookingId", "$$bookingId"] },
                    {
                      $eq: [
                        "$_id",
                        new mongoose.Types.ObjectId(bookedSessionId),
                      ],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "coaches",
                localField: "coachId",
                foreignField: "_id",
                as: "coachData",
              },
            },
            { $unwind: "$coachData" },
            {
              $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "userData",
              },
            },
            { $unwind: "$userData" },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
            {
              $lookup: {
                from: "rescheduled_sessions",
                localField: "_id",
                foreignField: "bookedSessionId",
                as: "rescheduled_sessionsData",
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      { $unwind: "$booked_sessionsData" },
      {
        $project: {
          _id: 1,
          // payment_intent: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          ratingsData: 1,
          booked_sessionsData: {
            _id: "$booked_sessionsData._id",
            sessionDate: "$booked_sessionsData.sessionDate",
            sessionDateUpdated: "$booked_sessionsData.sessionDateUpdated",
            sessionStatus: "$booked_sessionsData.sessionStatus",
            absentee: "$booked_sessionsData.absentee",
            sessionAmount: "$booked_sessionsData.amount",
            sessionCancelBy: "$booked_sessionsData.sessionCancelBy",
            messageCancel: "$booked_sessionsData.messageCancel",
            sessionCompletedUser: "$booked_sessionsData.sessionCompletedUser",
            sessionCompletedCoach: "$booked_sessionsData.sessionCompletedCoach",
            completedCoachMSG: "$booked_sessionsData.completedCoachMSG",
            completedUserMSG: "$booked_sessionsData.completedUserMSG",
            sessionData: {
              _id: "$booked_sessionsData.sessionData._id",
              coachId: "$booked_sessionsData.sessionData.coachId",
              title: "$booked_sessionsData.sessionData.title",
              price: "$booked_sessionsData.sessionData.price",
              type: "$booked_sessionsData.sessionData.type",
              description: "$booked_sessionsData.sessionData.description",
            },
            coachData: {
              _id: "$booked_sessionsData.coachData._id",
              name: "$booked_sessionsData.coachData.name",
              Lname: "$booked_sessionsData.coachData.Lname",
              image: "$booked_sessionsData.coachData.image",
              gender: "$booked_sessionsData.coachData.gender",
              title_line: "$booked_sessionsData.coachData.title_line",
              zoomMeetingURL: "$booked_sessionsData.coachData.zoomMeetingURL",
              timeZone: "$booked_sessionsData.coachData.timeZone",
            },
            userData: {
              _id: "$booked_sessionsData.userData._id",
              name: "$booked_sessionsData.userData.name",
              image: "$booked_sessionsData.userData.image",
              gender: "$booked_sessionsData.userData.gender",
              timeZone: "$booked_sessionsData.userData.timeZone",
            },
            rescheduled_sessionsData:
              "$booked_sessionsData.rescheduled_sessionsData",
          },
        },
      },
    ]);
    const responce = {
      success: true,
      data: orderData[0],
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session reschedule
exports.reSchedule = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const {
      bookingId,
      bookedSessionId,
      sessionDate,
      sessionDateOld,
      userId,
      coachTimeZone,
      message,
    } = req.body;
    let [data1, data2, coachData, userData] = await Promise.all([
      new rescheduled_sessionsModal({
        bookingId,
        bookedSessionId,
        userId,
        coachId,
        coachTimeZone,
        sessionDate: sessionDateOld,
        rescheduledBy: "coach",
        message,
      }).save(),
      booked_sessionModal.findByIdAndUpdate(
        { _id: bookedSessionId },
        {
          $set: {
            sessionDateUpdated: sessionDate,
          },
        }
      ),
      getCoachData(coachId),
      getUserData(userId),
    ]);
    const newBookedSessionData = await getBookedSessionData(bookedSessionId);
    if (coachData.calendarStatus === 1) {
      await addEventToCoachsCalendar(newBookedSessionData);
    }
    Promise.all([
      coacheeSessionEventUpdateEmailer({
        subject: "Session Rescheduled by coach",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
          <tr>
            <td style="padding: 15px 20px; background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 4px;">
              <p style="margin: 0; color: #065f46; font-size: 16px; font-weight: 600;">
                🔄 Session Rescheduled by coach
              </p>
            </td>
          </tr>
        </table>`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session Rescheduled by coach !",
        sessionPrice: `$${Number(newBookedSessionData.amount).toFixed(2)}`,
        sessionTitle: newBookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          newBookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `Rescheduled`,
        emailSummaryTitle:
          "Your Coaching Session Has Been Rescheduled by the coach.",
        highlightSummary: `Your coaching session with ${coachData.name} ${coachData.Lname} has been rescheduled. Please check the new time and prepare accordingly.`,
        highlightSubSummary:
          "We appreciate your flexibility. If you have any concerns or need to make further changes, feel free to log in to your account or contact our support team. We’re here to ensure a smooth coaching experience.",
      }),
      coachSessionEventUpdateEmailer({
        subject: "Session Rescheduled",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
          <tr>
            <td style="padding: 15px 20px; background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 4px;">
              <p style="margin: 0; color: #065f46; font-size: 16px; font-weight: 600;">
                🔄 Session Rescheduled
              </p>
            </td>
          </tr>
        </table>`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        title: "Session Rescheduled by you!",
        sessionPrice: `$${Number(newBookedSessionData.amount).toFixed(2)}`,
        sessionTitle: newBookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          newBookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `Rescheduled`,
        emailSummaryTitle:
          "Your Coaching Session Has Been successfully Rescheduled !",
        highlightSummary: `Your coaching session with ${userData.name} ${userData.lastName} has been rescheduled. Please check the new time and prepare accordingly.`,
        highlightSubSummary:
          "We appreciate your flexibility. For any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      saveTimelineEntry({
        bookedSessionId: newBookedSessionData._id,
        action: "Session Rescheduled",
        message: `Coaching session was rescheduled.`,
        actionBy: "Coach",
      }),
      CreateNotification({
        user_id: userId,
        heading: "Session has been rescheduled.",
        description: `Your session  ${
          coachData.name ? "with " + coachData.name : ""
        } ${
          coachData.Lname ? coachData.Lname : ""
        } has been rescheduled.Please check session details for more information.`,
        url: `/u/booking/details/${bookingId}`,
        notification_type: "bookings",
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session has been rescheduled.",
        description: `Your session  ${
          userData.name ? "with " + userData.name : ""
        } has been rescheduled.Please check session details for more information.`,
        url: `/c/booking/details/${bookingId}`,
        notification_type: "bookings",
      }),
      CreateAdminLevelNotification({
        heading: `Coach ${coachData.name} have rescheduled a booked session.`,
        description: `Coach ${coachData.name} have rescheduled the booked session with coachee ${userData.name}`,
        url: `/bookings/detail/${bookingId}`,
        notification_type: "bookings",
      }),
    ]);
    const responce = {
      success: true,
      message: "meeting rescheduled successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session cancel
exports.sessionCancel = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    const { userId, bookingId, bookedSessionId, message } = req.body;
    const [coachData, userData, orderDetailsData, bookedSessionData] =
      await Promise.all([
        getCoachData(coachId),
        getUserData(userId),
        getOrderDetails(bookingId),
        getBookedSessionData(bookedSessionId),
      ]);
    if (bookedSessionData.sessionType == "0") {
      const refund_data = {
        cartId: bookedSessionData.cartId,
        bookings_id: bookingId,
        booked_session_id: bookedSessionId,
        userId,
        coachId: coachId,
        sessionId: bookedSessionData.sessionId,
        coachTimeZone: coachData.timeZone,
        userTimeZone: userData.timeZone,
        sessionType: "0",
        sessionDate: bookedSessionData.sessionDate,
        sessionDateUpdated: bookedSessionData.sessionDateUpdated,
        charge: orderDetailsData.chargeId,
        amount: Number(bookedSessionData.amount) * 100,
        session_cancel_remark: message,
        cancel_requested_by: "coach",
      };
      await request_refund({ data: refund_data });
      // const refund = await stripe.refunds.create({
      //   charge: orderDetailsData.chargeId,
      //   amount: Number(bookedSessionData.amount) * 100,
      // });

      await booked_sessionModal.findByIdAndUpdate(
        { _id: bookedSessionId },
        {
          $set: {
            sessionStatus: 2, //canceled
            sessionCancelBy: "coach", //cancel by user
            messageCancel: message,
          },
        }
      );
    } else {
      await booked_sessionModal.findByIdAndUpdate(
        { _id: bookedSessionId },
        {
          $set: {
            sessionStatus: 2, //canceled
            sessionCancelBy: "coach", //cancel by user
            messageCancel: message,
          },
        }
      );
    }
    const responce = {
      success: true,
      message: "Session canceled successfully",
    };

    res.status(200).json(responce);
    if (coachData.calendarStatus === 1) {
      removeCoachCalendarEvent(bookedSessionData);
    }
    Promise.allSettled([
      coachSessionEventUpdateEmailer({
        subject: "Session canceled",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
            <tr>
              <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
                <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
                  ⚠️ Session canceled
                </p>
              </td>
            </tr>
          </table>`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        title: "Session canceled!",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `canceled`,
        emailSummaryTitle: `You have canceled a coaching session that was suppoded to commence on ${formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        )}.`,
        highlightSummary: `If this was not you Please contact support for help, or report any unauthorised action performed by your account to the support team.`,
        highlightSubSummary:
          "For any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      coacheeSessionEventUpdateEmailer({
        subject: "Session canceled by coach",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
            <tr>
              <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
                <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
                  ⚠️ Session canceled by coach
                </p>
              </td>
            </tr>
          </table>`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session canceled  by coach !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `canceled`,
        emailSummaryTitle: "Your Coaching Session Has Been Canceled by coach",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${coachData.name} ${coachData.Lname} has been canceled`,
        highlightSubSummary:
          "Please log in to your account for further options. Should you need any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),

      saveTimelineEntry({
        bookedSessionId: bookedSessionData._id,
        action: "Canceled",
        message: `Coaching session was canceled by coach`,
        actionBy: "Coach",
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session has been canceled.",
        description: `Your session  ${
          userData.name ? "with " + userData.name : ""
        } has been canceled.Please check session details for more information.`,
        url: "/c/booking",
        notification_type: "bookings",
      }),
      CreateNotification({
        user_id: userId,
        heading: "Session has been canceled.",
        description: `Your session  ${
          coachData.name ? "with " + coachData.name : ""
        } ${
          coachData.Lname ? coachData.Lname : ""
        } has been canceled. And a request for refund has been initiated. Please check session details for more information.`,
        url: "/u/booking",
        notification_type: "bookings",
      }),
      CreateAdminLevelNotification({
        heading: `Coach ${coachData.name} have cacnelled a booked session.`,
        description: `Coach ${coachData.name} have cacnelled the booked session with coachee ${userData.name}`,
        url: `/bookings/detail/${bookingId}`,
        notification_type: "bookings",
      }),
    ]).catch((error) => {
      console.error("sessionCompletedEmail error:", error);
    });
    return;
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

// session Absent
exports.sessionIncomplete = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id;
    const { bookedSessionId, absentee, reasonForIncomplete, userId } = req.body;
    await booked_sessionModal.findByIdAndUpdate(
      { _id: bookedSessionId },
      {
        $set: {
          sessionStatus: 3, // incomplete
          absentee: absentee,
          reasonForIncomplete: reasonForIncomplete,
          markedBy: "coach",
        },
      }
    );
    const [coachData, userData, bookedSessionData] = await Promise.all([
      getCoachData(coachId),
      getUserData(userId),
      getBookedSessionData(bookedSessionId),
    ]);
    Promise.allSettled([
      coachSessionEventUpdateEmailer({
        subject: "Session marked as incomplete",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
      <tr>
        <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
          <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
            ⚠️ Session marked as incomplete
          </p>
        </td>
      </tr>
    </table>`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        recipient: `${coachData.name} ${coachData.Lname}`,
        title: "Session marked as Incomplete",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `Incomplete`,
        emailSummaryTitle:
          "You have recently marked a coaching session as incomplete.",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${userData.name} ${userData.lastName} has been marked as incomplete.`,
        highlightSubSummary:
          "If you believe this action was in error or wish to reschedule, please log in to your account for further options. Should you need any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      coacheeSessionEventUpdateEmailer({
        subject: "Session marked as incomplete",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
      <tr>
        <td style="padding: 15px 20px; background-color: #fdf2f2; border-left: 4px solid #ee1a1a; border-radius: 4px;">
          <p style="margin: 0; color: #b91c1c; font-size: 16px; font-weight: 600;">
            ⚠️ Session marked as incomplete!
          </p>
        </td>
      </tr>
    </table>`,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session not completed !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `Incomplete`,
        emailSummaryTitle:
          "Your coach has marked the coaching session as incomplete.",
        highlightSummary: `We regret to inform you that your scheduled coaching session with ${coachData.name} ${coachData.Lname} has been marked as incomplete.`,
        highlightSubSummary:
          "If you believe this action was in error or wish to reschedule, please log in to your account for further options. Should you need any assistance, feel free to contact our support team. We're here to help you continue your growth journey.",
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session marked as Incomplete.",
        description: `You have recently marked one of your session as incomplete. Please contact support if this was a mistake.`,
        url: `/c/bookings/canceled`,
        notification_type: "bookings",
      }),
      saveTimelineEntry({
        bookedSessionId: bookedSessionData._id,
        action: "Marked as Incomplete",
        message: `Coaching session was marked as incomplete.`,
        actionBy: "Coach",
      }),
    ]);
    const responce = {
      success: true,
      message: "Session marked as incomplete",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session complete
exports.sessionComplete = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }

  try {
    const coachId = req.coach._id; //login coach-id
    const { userId, bookingId, bookedSessionId, message } = req.body;

    const [coachData, userData, orderDetailsData, bookedSessionData] =
      await Promise.all([
        getCoachData(coachId),
        getUserData(userId),
        getOrderDetails(bookingId),
        getBookedSessionData(bookedSessionId),
      ]);

    await booked_sessionModal.findByIdAndUpdate(
      { _id: bookedSessionId },
      {
        $set: {
          sessionCompletedCoach: 1,
          completedCoachMSG: message,
          sessionCompletedCoachTime: new Date(),
        },
      }
    );
    if (coachData.calendarStatus === 1) {
      removeCoachCalendarEvent(bookedSessionData);
    }
    Promise.allSettled([
      coachSessionEventUpdateEmailer({
        subject: "Session was marked as Completed",
        email: coachData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
     <tr>
       <td style="padding: 15px 20px; background-color: #f3f3f3; border-left: 4px solid #28a745; border-radius: 4px;">
         <p style="margin: 0; color: #013338; font-size: 16px; font-weight: 600;">
           Session marked as Completed
         </p>
       </td>
     </tr>
   </table>
   `,
        recipient: `${coachData.name} ${coachData.Lname}`,
        coacheeName: `${userData.name} ${userData.lastName}`,
        title: "Session marked as Completed !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          coachData?.timeZone
        ),
        sessionStatus: `Marked as Completed`,
        emailSummaryTitle: "Coach, you have marked the session as completed.",
        highlightSummary: `We sincerely appreciate your time and engagement in your recent coaching session with ${userData.name} ${userData.lastName}. This session will be marked as completed automatically withing 24Hours even if the coahcee do not update the status of the session, We hope the experience provided valuable insights and meaningful guidance as you continue on your journey.`,
        highlightSubSummary:
          "If this action was not performed by you please contact support.",
      }),
      coacheeSessionEventUpdateEmailer({
        subject: "Session marked as Completed by your coach.",
        email: userData.email,
        action: `<table cellpadding="0" cellspacing="0" border="0" style="width: 100%; margin-bottom: 25px;">
     <tr>
       <td style="padding: 15px 20px; background-color: #f3f3f3; border-left: 4px solid #28a745; border-radius: 4px;">
         <p style="margin: 0; color: #013338; font-size: 16px; font-weight: 600;">
           ✅ Session marked as completed by coach!
         </p>
       </td>
     </tr>
   </table>
   `,
        coachName: `${coachData.name} ${coachData.Lname}`,
        coachProfileLink: `${process.env.FRONTEND_URL_web}/find-a-coach/details/${coachData._id}/about`,
        recipient: `${userData.name} ${userData.lastName}`,
        title: "Session Completed !",
        sessionPrice: `$${Number(bookedSessionData.amount).toFixed(2)}`,
        sessionTitle: bookedSessionData.title,
        sessionTime: formatMomemtTimeToStr(
          bookedSessionData?.sessionDateUpdated,
          userData?.timeZone
        ),
        sessionStatus: `Completed by coach`,
        emailSummaryTitle:
          "Your coach have marked the session as completed, you can update the status of you coahcing session, you have booked with coach, as described below, for the next 24 hours. After which the session will be marked as completed and you will not be eligible for the refund.",
        highlightSummary: `We sincerely appreciate your time and engagement in your recent coaching session with ${coachData.name} ${coachData.Lname}. We hope the experience provided valuable insights and meaningful guidance as you continue on your journey.`,
        highlightSubSummary:
          "We would appreciate your feedback. You may leave a review for the coach or the session by logging into your account on our platform. If you wish to schedule another session or need any assistance, please do not hesitate to contact us.",
      }),
      CreateNotification({
        user_id: coachId,
        heading: "Session has been completed.",
        description: `Your session  ${
          userData.name ? "with " + userData.name : ""
        } has been marked as completed by you. Please check session details for more information.`,
        url: `/c/booking/details/${bookingId}`,
        notification_type: "bookings",
      }),
      CreateNotification({
        user_id: userId,
        heading: "Session has been completed.",
        description: `Your session  ${
          coachData.name ? "with " + coachData.name : ""
        } ${
          coachData.Lname ? coachData.Lname : ""
        } has been marked as complete by the coach. Please check session details for more information.`,
        url: `/u/booking/details/${bookingId}`,
        notification_type: "bookings",
      }),
      CreateAdminLevelNotification({
        heading: `Coach ${coachData.name} have completed a booked session.`,
        description: `Coach ${coachData.name} have completed the booked session with coachee ${userData.name}`,
        url: `/bookings/detail/${bookingId}`,
        notification_type: "bookings",
      }),
      saveTimelineEntry({
        bookedSessionId: bookedSessionData._id,
        action: "Completed",
        message: `Coaching session was marked as completed`,
        actionBy: "Coach",
      }),
    ]).catch((error) => {
      console.error("sessionCompletedEmail error:", error);
    });

    const responce = {
      success: true,
      message: "Session marked as completed",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//update session remider session db
const sessionRemiderUpdate = async (sessionBooking_id) => {
  try {
    await booked_sessionModal.findByIdAndUpdate(
      { _id: sessionBooking_id },
      { $set: { remindarStatus: 1 } }
    );
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

//orderReminder
exports.orderReminder = async (req, res) => {
  try {
    const timeZone = req.query.timeZone; // "Asia/Kolkata";
    if (!timeZone) {
      const responce = {
        success: false,
        message: "Timezone not provoided",
      };
      return res.status(401).json(responce);
    }
    const testDateInAsiaKolkata = moment.tz(timeZone);
    const currentUTC = testDateInAsiaKolkata.clone().utc().toDate();
    const currentUTC_plus_5 = testDateInAsiaKolkata
      .clone()
      .utc()
      .add(5, "minutes")
      .toDate();
    const currentUTC_minus_5 = testDateInAsiaKolkata
      .clone()
      .utc()
      .subtract(5, "minutes")
      .toDate();

    const sessionBookingData = await booked_sessionModal.aggregate([
      {
        $match: {
          status: 0,
          remindarStatus: 0,
          remindarDateTime: {
            $lte: currentUTC_plus_5,
            $gte: currentUTC_minus_5,
          },
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coacheData",
        },
      },
      { $unwind: "$coacheData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          bookingDate: 1,
          bookingTime: 1,
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            userName: "$userData.userName",
            email: "$userData.email",
          },
          coacheData: {
            _id: "$coacheData._id",
            name: "$coacheData.name",
            Lname: "$coacheData.Lname",
            userName: "$coacheData.userName",
            email: "$coacheData.email",
            zoomMeetingURL: "$coacheData.zoomMeetingURL",
          },
          sessionData: {
            _id: "$sessionData._id",
            title: "$sessionData.title",
            description: "$sessionData.description",
            price: "$sessionData.price",
          },
        },
      },
    ]);
    if (sessionBookingData.length > 0) {
      const sendEmails = sessionBookingData.map(async (session) => {
        const sessionBooking_id = session._id;
        const userName = session.userData.name;
        const userEmail = session.userData.email;
        const coachName = session.coacheData.name;
        const coachEmail = session.coacheData.email;
        const zoomMeetingURL = session.coacheData.zoomMeetingURL;
        const bookingDate = session.bookingDate;
        const bookingTime = session.bookingTime;

        //  send email to coaches and users
        await Promise.all([
          sessionRemiderEmailCoach(
            userName,
            coachName,
            bookingDate,
            bookingTime,
            coachEmail,
            zoomMeetingURL
          ),
          sessionRemiderEmailUser(
            userName,
            coachName,
            bookingDate,
            bookingTime,
            userEmail,
            zoomMeetingURL
          ),
          sessionRemiderUpdate(sessionBooking_id),

          CreateNotification({
            user_id: session.coacheData._id,
            heading: "Upcoming session.",
            description: `Your have an upcoming ${
              session.userData.name ? "with " + session.userData.name : ""
            }.Please check session details for more information.`,
            url: "/c/booking",
            notification_type: "bookings",
          }),
          CreateNotification({
            user_id: session.userData._id,
            heading: "Upcoming session.",
            description: `Your have an upcoming ${
              session.coachData.name ? "with " + session.coachData.name : ""
            } ${
              session.coachData.Lname ? session.coachData.Lname : ""
            }. Please check session details for more information.`,
            url: "/u/booking",
            notification_type: "bookings",
          }),
        ]);
      });
      await Promise.all(sendEmails);
    }
    const responce = {
      success: true,
      currentUTC,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
