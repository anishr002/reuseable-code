const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
const Stripe = require("stripe");
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const coachSessionModal = require("../../../models/coachSession");
const { default: mongoose } = require("mongoose");
const { CreateNotification } = require("../../../models/notificationModal");

//Add new session
exports.AddSession = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    // const { title, price, description,currency } = req.body;
    const { title, price, description, duration } = req.body;
    const sessionData = await new coachSessionModal({
      coachId,
      title,
      price,
      description,
      duration,
      // currency:currency
    }).save();
    const product = await stripe.products.create({
      name: title,
      description: description,
      metadata: {
        coach_id: coachId.toString(), // Store the coach ID
        session_id: sessionData._id.toString(), // Store the session ID
        type: 0,
      },
    });

    const stripePrice = await stripe.prices.create({
      product: product.id,
      unit_amount: Number(price) * 100,
      currency: "usd",
      metadata: {
        coach_id: coachId.toString(), // Store the coach ID
        session_id: sessionData._id.toString(), // Store the session ID
        type: 0,
      },
    });

    await coachSessionModal.findByIdAndUpdate(
      { _id: sessionData._id },
      { $set: { stripePriceId: stripePrice.id, stripeProductId: product.id } }
    );

    const response = {
      success: true,
      message: "Session added successfully",
    };
    await CreateNotification({
      user_id: coachId,
      heading: `You have added a new session.`,
      description: `There is a new session added to your profile,You can see details by clicking on the view button.`,
      url: `/coach/detail/${coachId}`,
    });

    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Add new session
exports.EditSession = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const { title, price, description, sessionId, duration } = req.body;
    const sessionData1 = await coachSessionModal.find({ _id: sessionId });
    if (sessionData1.length == 0) {
      const response = {
        success: false,
        message: "Something went wrong",
      };
      return res.status(500).json(response);
    }
    await coachSessionModal.findByIdAndUpdate(
      { _id: sessionId },
      {
        $set: {
          coachId,
          title,
          price,
          description,
          duration,
        },
      },
      { new: true }
    );
    await stripe.products.update(sessionData1[0].stripeProductId, {
      name: title,
      description: description,
    });

    await stripe.prices.update(sessionData1[0].stripePriceId, {
      active: false,
    });
    const stripePrice = await stripe.prices.create({
      product: sessionData1[0].stripeProductId,
      unit_amount: Number(price) * 100,
      currency: "usd",
      metadata: {
        coach_id: coachId.toString(), // Store the coach ID
        session_id: sessionId.toString(), // Store the session ID
        type: 0,
      },
    });
    await coachSessionModal.findByIdAndUpdate(
      { _id: sessionId },
      { $set: { stripePriceId: stripePrice.id } }
    );
    const response = {
      success: true,
      message: "Session updated successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session delete
exports.DeleteSession = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    const sessionId = req.params.id;
    const sessionData1 = await coachSessionModal.find({
      _id: sessionId,
      coachId: coachId,
    });
    if (sessionData1.length == 0) {
      const response = {
        success: false,
        message: "Something went wrong",
      };
      return res.status(500).json(response);
    }

    await coachSessionModal.findByIdAndUpdate(
      { _id: sessionId },
      { $set: { deleted: 1 } }
    );
    const response = {
      success: true,
      message: "Session deleted successfully",
    };
    await CreateNotification({
      user_id: coachId,
      heading: `You have deleted a session.`,
      description: `You have deleted a listed session from your profile,You can see details by clicking on the view button.`,
      url: `/c/sessions`,
      notification_type: "alerts",
    });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//AListSession for coach admin
exports.ListSession = async (req, res) => {
  try {
    const coachId = req.coach._id; //login coach-id
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    const sessionList = await coachSessionModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
          deleted: 0,
          // status: true,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (sessionList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(sessionList[0].pageInfo[0].count / limit);
    }
    const sessionListData = sessionList[0].data;
    const response = {
      success: true,
      data: sessionListData,
      message: "Session list get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//ListSessionForUser for website
exports.ListSessionForUser = async (req, res) => {
  try {
    const coachId = req.params.id;
    const sessionList = await coachSessionModal.find({
      coachId,
      deleted: 0,
      status: true,
    });
    const response = {
      success: true,
      data: sessionList,
      message: "Session list get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//session detials
exports.sessionDetails = async (req, res) => {
  try {
    const sessionId = req.params.id;
    const coachId = req.params.coachId;
    const sessionList = await coachSessionModal.find({
      _id: sessionId,
      coachId,
      status: true,
    });
    const response = {
      success: true,
      data: sessionList[0],
      message: "Session list get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
