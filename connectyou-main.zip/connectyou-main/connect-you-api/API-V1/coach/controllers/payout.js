const { validationResult } = require("express-validator");
const { google } = require("googleapis");
const axios = require("axios");
const path = require("path");
const Stripe = require("stripe");
require("dotenv").config();
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const orderModal = require("../../../models/booking");
const completedOrderModal = require("../../../models/completedOrders");
const coachPayoutModel = require("../../../models/coachPayout");
const CoachModel = require("../../../models/coach");
const { default: mongoose } = require("mongoose");
const {
  CreateNotification,
  CreateAdminLevelNotification,
} = require("../../../models/notificationModal");
const { getConversionRates } = require("../../../lib/conversionRate");
const { minimumPayoutAmounts } = require("../../../lib/stripe");

//payout request
exports.payoutRequest = async (req, res) => {
  // 1. Validate input params
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      title: "Validation Error",
      message: errors.array()[0].msg,
    });
  }
  try {
    const coachId = req.coach._id;
    const { Req_amount, bankDetails } = req.body;
    const result = await CoachModel.aggregate([
      { $match: { _id: new mongoose.Types.ObjectId(coachId) } },
      {
        $lookup: {
          from: "completedorders",
          localField: "_id",
          foreignField: "coachId",
          as: "coachOrders",
        },
      },
      { $unwind: { path: "$coachOrders", preserveNullAndEmptyArrays: true } },
      {
        $group: {
          _id: "$_id",
          stripeCountryDetails: { $first: "$stripeCountryDetails" },
          stripe_accID: { $first: "$stripe_accID" },
          bankAccountID: { $first: "$bankAccountID" },
          currency: { $first: "$currency" },
          totalAmount: { $sum: "$coachOrders.amount" },
        },
      },
      {
        $project: {
          _id: 1,
          stripeCountryDetails: 1,
          stripe_accID: 1,
          bankAccountID: 1,
          currency: 1,
          totalAmount: 1,
        },
      },
    ]);
    if (!result || !result[0]) {
      return res.status(404).json({
        success: false,
        title: "Bank details unavailable",
        message:
          "Your bank details are not available at this moment, Please try again later.",
      });
    }
    const coachData = result[0];
    const coachBalanceUSD = coachData.totalAmount / 100;
    if (Req_amount > coachBalanceUSD) {
      return res.status(400).json({
        success: false,
        title: "Insufficient Balance",
        message: `Your available balance is $${coachBalanceUSD.toFixed(
          2
        )} USD, which is less than your requested payout amount.`,
      });
    }

    const currency = coachData.stripeCountryDetails?.currency;
    if (!coachData.stripeCountryDetails) {
      console.warn(
        "Coach's Stripe bank country details not found asking (stripeCountryDetails) for revalidation"
      );
      return res.status(200).json({
        success: false,
        action: "REVALIDATION_REQUIRED",
        title: "Please revalidate your details",
        message:
          "Looks like that Your Banking details are incomplete, Please revalidate your banking and currency details . (Please select Euro if your bank country supports payments in Euro to have smooth transactions and  avoid extra cross border Surcharge)",
      });
    }
    // console.log({ currency });
    const ratesData = await getConversionRates();
    // console.log({ ratesData });
    if (!ratesData || !ratesData.rates) {
      return res.status(500).json({
        success: false,
        title: "Conversion Rate unavailable",
        message:
          "Unable to fetch currency conversion rates at the moment, Please try again later.",
      });
    }
    const minPayoutObj = minimumPayoutAmounts?.find(
      (item) => item?.currency === currency
    );

    if (!minPayoutObj) {
      return res.status(400).json({
        success: false,
        title: "Unsupported Country",
        message: `Payouts are not supported for Currency: ${currency}`,
      });
    }
    const countryRate = ratesData.rates[currency];
    if (!countryRate) {
      return res.status(400).json({
        success: false,
        title: "Currency Error",
        message: `Conversion rate for currency ${currency} is unavailable at the moment, Please try again later or contact support for help.`,
      });
    }
    const requestedLocalAmount = Req_amount * countryRate;
    if (requestedLocalAmount < minPayoutObj.minAmount) {
      return res.status(400).json({
        success: false,
        title: "Amount is too Low",
        message: `Minimum payout amount for your country (${currency}) is ${
          minPayoutObj.minAmount
        } ${currency}. Your requested amount equals ${requestedLocalAmount.toFixed(
          2
        )} ${currency}.`,
      });
    }
    // console.log({
    //   currency,
    //   minPayoutObj,
    //   requestedLocalAmount,
    //   countryRate,
    //   ratesData,
    //   Req_amount,
    //   coachData,
    //   coachBalanceUSD,
    // });

    try {
      await new coachPayoutModel({
        coachId,
        amount: Math.round(Req_amount * 100), // convert to cents
        bankId: bankDetails.id,
        bankName: bankDetails.bank_name,
        banklast4: bankDetails.last4,
        bankFingerprint: bankDetails.fingerprint,
        reqAccount: bankDetails.account,
        currency: coachData?.stripeCountryDetails?.currency,
      }).save();
    } catch (saveError) {
      console.error("Error saving payout request:", saveError);
      return res.status(500).json({
        success: false,
        title: "Database Error",
        message: "Could not save payout request. Please try again later.",
      });
    }
    await Promise.all([
      CreateNotification({
        user_id: coachId,
        heading: `Your payout request for Amount $${Req_amount} has been submitted.`,
        description: `A payout request has been submitted from your account for $${Req_amount}. Please review details in your dashboard.`,
        url: `/c/payment`,
        notification_type: "payments",
      }),
      CreateAdminLevelNotification({
        heading: `New payout request of Amount $${Req_amount}`,
        description: `A coach requested a payout of $${Req_amount}. Please review.`,
        url: `/payout/detail/${coachId}`,
        notification_type: "payments",
      }),
    ]);
    return res.status(200).json({
      success: true,
      title: "Payout Requested",
      message: "Your payout request has been submitted successfully!",
    });
  } catch (err) {
    console.error("Server error in payoutRequest:", err);
    return res.status(500).json({
      success: false,
      title: "Server Error",
      message: "An unexpected error occurred. Please try again later.",
    });
  }
};

//payout history
exports.payoutHistory = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.coach._id; //login coach-id
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    const [totalRevenueData, payoutData] = await Promise.all([
      completedOrderModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        {
          $facet: {
            totalRevenue: [
              {
                $group: {
                  _id: null,
                  total: { $sum: "$amount" },
                },
              },
            ],
          },
        },
        {
          $project: {
            totalRevenue: {
              $ifNull: [{ $arrayElemAt: ["$totalRevenue.total", 0] }, 0],
            },
          },
        },
      ]),
      await coachPayoutModel.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        {
          $sort: { createdAt: -1 },
        },
        {
          $facet: {
            pageInfo: [{ $count: "count" }],
            totalBalance: [
              {
                $group: {
                  _id: null,
                  total: { $sum: "$amount" },
                },
              },
            ],
            data: [{ $skip: skip }, { $limit: limit }],
          },
        },
        {
          $project: {
            pageInfo: {
              $ifNull: [{ $arrayElemAt: ["$pageInfo.count", 0] }, 1],
            },
            totalBalance: {
              $ifNull: [{ $arrayElemAt: ["$totalBalance.total", 0] }, 0],
            },
            data: 1,
          },
        },
      ]),
    ]);
    const totalRevenue = Number(totalRevenueData[0].totalRevenue) / 100;
    const totalPayout = Number(payoutData[0].totalBalance) / 100;
    const totalBalance = totalRevenue - totalPayout;
    const totalPages = Math.ceil(payoutData[0].pageInfo / limit);
    const responce = {
      success: true,
      totalRevenue: totalRevenue,
      payoutList: payoutData[0].data,
      payoutBalance: totalPayout,
      totalBalance: totalBalance,
      totalPages,
      message: "Data retrieved successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getMinimumReqAmount = async (req, res) => {
  try {
    const { usdAmount = 0 } = req.query;
    const coachId = req.coach._id;
    // console.log({ usdAmount });
    if (isNaN(usdAmount)) {
      return res.status(400).json({
        success: false,
        title: "Invalid Amount",
        message: "Please provide a valid USD amount in the query.",
      });
    }

    const coach = await CoachModel.findById(coachId).lean();

    if (!coach || !coach.stripeCountryDetails?.currency) {
      return res.status(404).json({
        success: false,
        title: "Coach Not Found",
        message: "Unable to retrieve Your native currency details.",
      });
    }

    const coachCurrency = coach.stripeCountryDetails.currency;
    const ratesData = await getConversionRates();

    if (!ratesData || !ratesData.rates[coachCurrency]) {
      return res.status(500).json({
        success: false,
        title: "Conversion Rate Error",
        message: `Conversion rate for your native currency ${coachCurrency?.toUpperCase()} is unavailable.`,
      });
    }

    const conversionRate = ratesData.rates[coachCurrency];
    const convertedAmount = parseFloat(usdAmount) * conversionRate;

    const minPayoutData = minimumPayoutAmounts.find(
      (item) => item.currency === coachCurrency?.toUpperCase()
    );
    if (!minPayoutData) {
      return res.status(400).json({
        success: false,
        title: "Unsupported Country",
        message: `Minimum payout information not found for ${coachCurrency}.`,
      });
    }
    const data = {
      stripeCountryDetails: coach.stripeCountryDetails,
      currency: minPayoutData.currency,
      usdAmount: parseFloat(usdAmount),
      convertedAmount: convertedAmount.toFixed(2),
      minimumRequiredAmount: minPayoutData.minAmount,
    };
    // console.log({ data });
    return res.status(200).json({
      success: true,
      data,
      message: "Fetched minimum withdraw amount details successfully !",
    });
  } catch (err) {
    console.error("Server error in getMinimumReqAmount:", err);
    return res.status(500).json({
      success: false,
      title: "Server Error",
      message: "An unexpected error occurred. Please try again later.",
    });
  }
};
/*
Example res 

{
  "success": true,
  "data": {
    "countryCode": "IN",
    "currency": "INR",
    "usdAmount": 50,
    "convertedAmount": "4287.56",
    "minimumRequiredAmount": 1000
  }
}

*/
