# COACH-MARKETPLACE-# # node.js app COACH-MARKETPLACE-

## Project Overview

This is a Node.js MVC application built for a multi-user platform, including Admin, Coach, and User roles. It provides functionalities such as booking, payments, session management, and chat features. The app also includes an authentication system with OAuth2, a dashboard for both admins and users, and multiple resources management.

## Project Hosted Location:

The project is hosted at /var/www/erection-coaching/APIs.

## Web Server:

This project uses Nginx as the web server for reverse proxying requests to the backend.

# Technologies Used

Node.js: # JavaScript runtime for building server-side applications
Express.js: # Web framework for building RESTful APIs and handling HTTP requests
MongoDB: # NoSQL database for storing application data
OAuth2: # Authentication protocol for secure login
Stripe API: # Payment processing API
Firebase: # For web push notifications
Mongoose: # MongoDB object modeling for Node.js
Socket.IO: # Real-time web socket communication for chat and notifications
Moment.js: # For date and time manipulation
Nodemailer: # Email sending service for notifications and alerts
Puppeteer: # Headless browser for generating PDFs or screenshots
XLSX: # Library for handling Excel file generation and parsing

## Project Structure : #COACH-MARKETPLACE- : folders

├── Admin/ # Administrative panel module
│ ├── controllers/ # Admin control logic
│ │ ├── booking.js # Manages booking operations
│ │ ├── Coach.js # Coach management operations
│ │ ├── contactUs.js # Contact form management
│ │ ├── dashboard.js # Admin dashboard logic
│ │ ├── policy.js # Policy management
│ │ ├── Profile.js # Admin profile management
│ │ └── User.js # User management operations
│ └── routes/ # Admin route definitions
│ ├── booking.js # Booking related routes
│ ├── Coach.js # Coach management routes
│ ├── contactUs.js # Contact form routes
│ ├── dashboard.js # Dashboard routes
│ ├── PaymentsHistory.js # Payment history routes
│ ├── policy.js # Policy management routes
│ ├── Profile.js # Profile management routes
│ └── User.js # User management routes
│
├── API-V1/ # API Version 1 module
│ ├── coach/ # Coach-specific functionality
│ │ ├── controllers/ # Coach controllers
│ │ │ ├── bookingsReport.js # Booking report generation
│ │ │ ├── coachAuthentication.js # Coach auth logic
│ │ │ ├── coachAvailability.js # Availability management
│ │ │ ├── coachProfile.js # Profile management
│ │ │ ├── dashboard.js # Coach dashboard
│ │ │ ├── messageChat.js # Chat functionality
│ │ │ ├── order.js # Order management
│ │ │ ├── paymentHistory.js # Payment history
│ │ │ ├── payout.js # Payout processing
│ │ │ ├── rating.js # Rating system
│ │ │ ├── resources.js # Resource management
│ │ │ ├── Session.js # Session handling
│ │ │ └── StripeManage.js # Stripe integration
│ │ └── routes/ # Coach routes
│ │ ├── bookingReport.js # Booking report routes
│ │ ├── coachAuthentication.js # Auth routes
│ │ ├── coachAvailability.js # Availability routes
│ │ ├── coachProfile.js # Profile routes
│ │ ├── coachRating.js # Rating routes
│ │ ├── coachSession.js # Session routes
│ │ ├── dashboard.js # Dashboard routes
│ │ ├── messageChat.js # Chat routes
│ │ ├── order.js # Order routes
│ │ ├── paymentHistory.js # Payment history routes
│ │ ├── payout.js # Payout routes
│ │ ├── resources.js # Resource routes
│ │ └── StripeManage.js # Stripe routes
│ └── user/ # User-specific functionality
│ ├── controllers/ # User controllers
│ │ ├── cart.js # Shopping cart logic
│ │ ├── dashboard.js # User dashboard
│ │ ├── order.js # Order processing
│ │ ├── paymentHistory.js # Payment tracking
│ │ ├── PaymentLink.js # Payment link generation
│ │ ├── rating.js # User rating system
│ │ ├── resources.js # Resource access
│ │ ├── userAuthentication.js # User auth
│ │ └── userProfile.js # Profile management
│ └── routes/ # User routes
│ ├── cart.js # Cart routes
│ ├── dashboard.js # Dashboard routes
│ ├── order.js # Order routes
│ ├── paymentHistory.js # Payment routes
│ ├── PaymentLink.js # Payment link routes
│ ├── policies.js # Policy routes
│ ├── rating.js # Rating routes
│ ├── resources.js # Resource routes
│ ├── userAuthentication.js # Auth routes
│ └── userProfile.js # Profile routes
│
├── middleware/ # Authentication middleware
│ ├── authTokenAdmin.js # Admin authentication
│ ├── authTokenCoach.js # Coach authentication
│ └── authTokenUser.js # User authentication
│
├── models/ # Database schemas
│ ├── admin.js # Admin model
│ ├── booked_session.js # Booked sessions
│ ├── booking.js # Booking management
│ ├── cart.js # Sessions cart
│ ├── chatMessage.js # Chat messages
│ ├── Chatroom.js # Chat rooms
│ ├── coach.js # Coach profile
│ ├── coachAccDelete.js # Coach account deletion
│ ├── coachAvailability.js # Coach availability
│ ├── CoachBankAccountChangeHistory.js # Bank changes
│ ├── coachCertificate.js # Certifications
│ ├── CoachCredentials.js # Coach credentials
│ ├── CoachEducation.js # Education details
│ ├── coacheeResource.js # Coachee resources
│ ├── coacheeResourceSection.js # Resource sections
│ ├── CoachExperience.js # Work experience
│ ├── CoachForgetPasswordRequest.js # Password reset
│ ├── coachGToken.js # Google tokens
│ ├── coachPayout.js # Payout handling
│ ├── coachProfileApproval.js # Profile approval
│ ├── CoachProfileCompletionStatus.js # Profile status
│ ├── coachResource.js # Coach resources
│ ├── coachResourceSection.js # Resource sections
│ ├── coachSession.js # Coaching sessions
│ ├── completedOrders.js # Completed orders
│ ├── contactUs.js # Contact messages
│ ├── failedLoginAttempts.js # Login security
│ ├── notificationModal.js # Notifications
│ ├── orderRating.js # Order ratings
│ ├── privacyPolicy.js # Privacy policies
│ ├── referral.js # Referral system
│ ├── rescheduled_sessions.js # Rescheduling
│ ├── termAndConditions.js # Terms of service
│ ├── user.js # User profile
│ ├── userAccDelete.js # User account deletion
│ ├── UserForgetPasswordRequest.js # Password reset
│ └── webToken.js # JWT handling
│
├── public/ # Static assets
│ ├── certificate/ # Coach certificates
│ ├── coachID/ # Coach identification
│ ├── credentials/ # Credential documents
│ ├── messageFile/ # Chat attachments
│ ├── receipt/ # Payment receipts
│ ├── reports/ # Generated reports
│ ├── resourcesImage/ # Resource images
│ └── usersProfile/ # Profile pictures
│
├── .env # Environment variables
├── .gitignore # Git ignore rules
├── genStaticFolders.js # Static folder generator
├── index.js # Application entry point
├── oAuth2Client.js # OAuth2 configuration
├── package.json # Project dependencies
├── README.md # Project documentation
└── web-push-notification-7401d-firebase-adminsdk-r5wza-1c4f2f3a5b.json # Firebase config

# Scripts :

# Make sure all dependencies are installed by running:

npm install

# Start the project by running the following command in your terminal:

npm start

# Run the following command to create all the required folders in the public directory.

npm run folder-setup

# MIDDLEWARES

#

# API ENDPOINS AND CONTROLLERS
# connect-you-api
