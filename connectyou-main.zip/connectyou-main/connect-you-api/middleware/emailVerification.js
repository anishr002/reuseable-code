require("dotenv").config();
const bcrypt = require("bcrypt");
const moment = require("moment-timezone");
const coachModel = require("../models/coach");
const coacheeModel = require("../models/user");
const transportEmail = require("../lib/email");

const matchEntity = async ({ email }) => {
  try {
    let Entity;
    const [coach, coachee] = await Promise.all([
      coachModel.exists({
        $or: [{ email: email }, { userName: email }],
      }),
      coacheeModel.exists({
        $or: [{ email: email }, { userName: email }],
      }),
    ]);
    if (coach) {
      Entity = coachModel;
    } else if (coachee) {
      Entity = coacheeModel;
    } else {
      return null;
    }
    return Entity;
  } catch (error) {
    console.log(error);
    return null;
  }
};

exports.CheckAccountVerifiedStatus = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const Entity = await matchEntity({ email: email });
    if (!Entity) {
      return res.status(404).json({
        success: false,
        message: "The Account your are looking for is not available",
      });
    }
    const user = await Entity.find({
      $or: [{ email: email }, { userName: email }],
    }).select("email emailVerified password");
    const bcryptData = await bcrypt.compare(password, user[0].password);
    if (!bcryptData) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials" });
    }
    const isVerifiedUser = user[0].emailVerified === 1;
    if (!isVerifiedUser) {
      return res.status(200).json({
        success: false,
        message: "Your account is not verified, Please verify your email.",
        requirement: "email-verification",
      });
    }
    return next();
  } catch (error) {
    console.error("Error at verifyOtp middleware:", error.message);
    const response = { success: false, message: "Server error" };
    return res.status(500).json(response);
  }
};

// for email verification
exports.generateEmailVerificationOTP = async (req, res, next) => {
  try {
    const { email } = req.body;
    const otp = Math.floor(10000 + Math.random() * 90000);
    const currentDate = moment().tz("Asia/Kolkata");
    const otpExpiry = currentDate
      .clone()
      .add(15, "minutes")
      .format("YYYY-MM-DD HH:mm:ss");

    if (!otp && !otpExpiry) {
      return res.status(500).json({
        success: false,
        message: "Something went wrong, Please try again",
      });
    } else {
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: email,
        subject: "Account verification",
        template: "accountVerification",
        context: {
          email: email,
          otp,
        },
      };
      const tryEmail = await transportEmail.createEmail({ mailOptions });
      if (tryEmail.success === false) {
        return res.status(500).json({
          success: false,
          message: "Unable to generate OTP email, Please try again",
        });
      }
      const otpObject = {
        otp,
        otpExpiry,
        otpType: "User-Registration-Verification",
        deliverEmail: true,
      };
      req.otpGen = true;
      req.otpObject = otpObject;
    }
    return next();
  } catch (error) {
    console.error("Error at verifyOtp middleware:", error.message);
    const response = {
      success: false,
      message:
        error.message === "Error mailing user"
          ? "Some error occured while requesting OTP"
          : "Server error",
    };
    return res.status(500).json(response);
  }
};

exports.verifyEmailVerificationOTP = async (req, res, next) => {
  try {
    const { email, receivedOTP } = req.body;
    const Entity = await matchEntity({ email: email });
    if (!Entity) {
      return res.status(404).json({
        success: false,
        message: "The Account your are looking for is not available",
      });
    }
    const user = await Entity.find({ email }).select(
      "_id email emailVerified otp otpType otpDate firstName lastNam Lname userType name"
    );
    if (user.length === 0) {
      const response = {
        success: false,
        message: "User Not found, Please try registring again.",
      };
      return res.status(404).json(response);
    }
    if (user.length > 0) {
      console.log({
        now: moment().tz("Asia/Kolkata"),
        otpDate: moment(user[0].otpDate).tz("Asia/Kolkata"),
      });
      const isOtpExpired = moment()
        .tz("Asia/Kolkata")
        .isAfter(moment.tz(user[0].otpDate, "Asia/Kolkata"));

      const isTypeMisMatch =
        user[0].otpType !== "User-Registration-Verification";
      if (isOtpExpired || isTypeMisMatch) {
        const response = {
          success: false,
          message: `Entered OTP has been expired or invalid, Please request a new OTP`,
        };
        return res.status(401).json(response);
      }
      if (receivedOTP !== user[0].otp) {
        const response = {
          success: false,
          message: "The OTP you entered is incorrect.",
        };
        return res.status(400).json(response);
      } else if (receivedOTP === user[0].otp) {
        const mailOptions = {
          from: "ConnectYou <itadmin@erickson.edu>",
          to: user[0].email,
          subject: "Account verified !",
          template:
            user[0].userType === "coach"
              ? "coachAccountVerificationSuccess"
              : "coacheeAccountVerificationSuccess",
          context: {
            name:
              user[0].userType === "coachee"
                ? ` ${user[0].name}  ${user[0].lastName}`
                : ` ${user[0].name} ${user[0].Lname}`,
            eamil: user[0].email,
            dashboardLink: `https://connectyou.global/${
              user[0].userType === "coach" ? `c/profile` : `u/profile`
            }`,
          },
        };
        await transportEmail.createEmail({ mailOptions });
        await Entity.updateOne(
          { email, _id: user[0]._id },
          {
            $set: {
              emailVerified: 1,
              otp: "",
              otpDate: "",
              otpType: "",
            },
          }
        );
        req.otpVerification = true;
        req.user = user[0];
        return next();
      }
    }
  } catch (error) {
    console.error("Error at verifyOtp middleware:", error.message);
    const response = { success: false, message: "Server error" };
    return res.status(500).json(response);
  }
};
