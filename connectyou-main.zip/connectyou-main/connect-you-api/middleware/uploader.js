const path = require("path");
const multer = require("multer");

// main middleware handler to handle all the errors and if any error occurs send an response !!

const multerErrorHandler = (uploadHandler, limit) => {
  return (req, res, next) => {
    uploadHandler(req, res, (err) => {
      if (err) {
        if (err.code === "LIMIT_FILE_SIZE") {
          return res.status(400).json({
            success: false,
            message: `File size exceeds the allowed limit of ${limit}.`,
          });
        }
        return res.status(400).json({
          success: false,
          message: err.message || "File upload failed.",
        });
      }
      next();
    });
  };
};

const checkFileType = (req, res, next) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }
  if (
    req.file.mimetype !== "text/csv" &&
    req.file.mimetype !== "application/vnd.ms-excel"
  ) {
    return res.status(400).json({ error: "Only CSV files are allowed" });
  }
  next();
};

// profile- picture
const profilePictureUploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/usersProfile"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const uploadProfilePicture = multer({
  storage: profilePictureUploadStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit // coach / coachee profile picture
});

// credentials uploader
const storageCredentials = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/credentials"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const uploadCredentials = multer({
  storage: storageCredentials,
  limits: { fileSize: 7 * 1024 * 1024 }, //7MB limit // coach credentials picture
});

//for upload certificate
const certificateStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/certificate"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const certificateUpload = multer({
  storage: certificateStorage,
  limits: { fileSize: 7 * 1024 * 1024 }, //7MB limit // coach certificate picture
});

//set storage and file name for coach id upload
const coachIDstorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/coachID"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const uploadcoachID = multer({
  storage: coachIDstorage,
  limits: { fileSize: 10 * 1024 * 1024 }, //10MB limit // coach idnetity doc
});

// chat files
const chatFileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/messageFile"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const uploadChatFiles = multer({
  storage: chatFileStorage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB Limit in chats
});

// add resource sectiono
const resourceStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/resourceFiles"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const uploadResource = multer({
  storage: resourceStorage,
  limits: { fileSize: 15 * 1024 * 1024 }, 
});

// add signed  agreement  section
const agreementStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/coachAgreements"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const uploadCoachAgreement = multer({
  storage: agreementStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 5MB Limit in chats
});

//upload admin- csv / other files
const filesStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/files"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const uploadFiles = multer({
  storage: filesStorage,
  limits: { fileSize: 10 * 1024 * 1024 },
});

// exports the multer middle wares
module.exports = {
  multerErrorHandler,
  uploadProfilePicture,
  uploadCredentials,
  certificateUpload,
  uploadcoachID,
  uploadChatFiles,
  uploadResource,
  uploadCoachAgreement,
  uploadFiles,
  checkFileType,
};
