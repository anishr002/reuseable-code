const jwt = require("jsonwebtoken");
require("dotenv").config();
const CoachModel = require("../models/coach");
exports.authTokenCoach = async (req, res, next) => {
  try {
    const tokenHeader = req.header("Authorization");
    if (!tokenHeader) {
      const response = { success: false, error: "Please provide bearer token" };
      return res.status(400).json(response);
    }
    const token = tokenHeader.replace("Bearer ", "");
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await CoachModel.find({ _id: decoded._id });
    if (user.length == 0) {
      const response = { success: false, message: "Unauthorized user" };
      return res.status(403).json(response);
    }

    if (user.length > 0) {
      if (user[0].block == 1) {
        const response = { success: false, message: "Your account is blocked" };
        return res.status(403).json(response);
      } else if (user[0].delete == 1) {
        const response = { success: false, message: "Your account is deleted" };
        return res.status(403).json(response);
      } else if (user[0].deleteReq != 0) {
        const response = { success: false, message: "Your account is deleted" };
        return res.status(403).json(response);
      } else {
        req.coach = user[0];
      }
    }
    return next();
  } catch (error) {
    console.error("Error in authTokenCoach middleware:", error.message);
    if (error.name === "JsonWebTokenError") {
      const response = { success: false, message: "Invalid token" };
      return res.status(401).json(response);
    } else if (error.name === "TokenExpiredError") {
      const response = { success: false, message: "Token expired" };
      return res.status(401).json(response);
    } else if (error.message === "invalid signature") {
      const response = {
        success: false,
        error: "Login session expired, Please Login again.",
      };
      return res.status(401).json(response);
    } else {
      const response = { success: false, message: "Server error" };
      return res.status(500).json(response);
    }
  }
};
