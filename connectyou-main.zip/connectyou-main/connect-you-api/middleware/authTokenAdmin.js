const jwt = require("jsonwebtoken");
require("dotenv").config();
const User = require("../models/admin");

// Middleware to authenticate users

exports.authTokenAdmin = async (req, res, next) => {
  try {
    const tokenHeader = req.header("Authorization");
    if (!tokenHeader) {
      const responce = { success: false, error: "Please provide bearer token" };
      return res.status(400).json(responce);
    }
    const token = tokenHeader.replace("Bearer ", "");
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded._id);
    if (!user) {
      const responce = { success: false, error: "Unauthorized user" };
      return res.status(401).json(responce);
    }
    req.admin = user;
    return next();
  } catch (error) {
    console.error("Error in authTokenCoach middleware:", error.message);
    if (error.name === "JsonWebTokenError") {
      const responce = { success: false, error: "Invalid token" };
      return res.status(401).json(responce);
    } else if (error.name === "TokenExpiredError") {
      const responce = { success: false, error: "Token expired" };
      return res.status(401).json(responce);
    } else if (error.message === "invalid signature") {
      const responce = {
        success: false,
        error: "Login session expired, Please Login again.",
      };
      return res.status(401).json(responce);
    } else {
      const responce = { success: false, error: "Server error" };
      return res.status(500).json(responce);
    }
  }
};
