const { validationResult } = require("express-validator");

exports.response = async (req, res, next) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  } else {
    return next();
  }
};
