const cron = require("node-cron");
const coachPayoutModel = require("../models/coachPayout");
const { autoApproveCoachPayout } = require("../lib/payout");
const CoachModel = require("../models/coach");
const autoPayout = async () => {
  const now = new Date();
  const payoutsToRetry = await coachPayoutModel.find({
    status: 0,
    paid: false,
    retryCount: { $lt: 3 },
    processing: { $ne: true }, // optional: skip locked ones
  });
  console.log({ payoutsToRetry: payoutsToRetry.length });
  for (const payout of payoutsToRetry) {
    console.log({ "Retrying payout approval for ": payout._id });
    try {
      await autoApproveCoachPayout(payout, coachPayoutModel);
      // Update retry count and lastRetryAt without triggering post-save
      await coachPayoutModel.findOneAndUpdate(
        { _id: payout._id },
        {
          $inc: { retryCount: 1 },
          $set: { lastRetryAt: now },
        }
      );
    } catch (err) {
      console.error(`Retry failed for payout ${payout._id}:`, err.message);
    }
  }
};

cron.schedule("*/15 * * * *", autoPayout, { runOnInit: true });
console.log("✅ Cron job active");

require("dotenv").config();
const Stripe = require("stripe");
const stripe = Stripe(process.env.STRIPE_SK);
const confirmPendingPayouts = async () => {
  console.log("🔍 Checking pending Stripe payouts...");

  const pendingPayouts = await coachPayoutModel.find({
    status: 1,
    paid: false,
    payoutId: { $exists: true, $ne: null },
  });

  console.log(`Found ${pendingPayouts.length} pending payouts to verify.`);

  for (const payout of pendingPayouts) {
    try {
      const coach = await CoachModel.findById(payout.coachId);
      if (!coach || !coach.stripe_accID) {
        console.warn(`Coach or stripe_accID missing for payout ${payout._id}`);
        continue;
      }
      const stripePayout = await stripe.payouts.retrieve(payout.payoutId, {
        stripeAccount: coach.stripe_accID,
      });

      if (stripePayout.status === "paid") {
        console.log(`✅ Payout ${payout.payoutId} marked as paid.`);

        await coachPayoutModel.findByIdAndUpdate(payout._id, {
          $set: {
            paid: true,
            confirmedDate: new Date().toISOString(),
          },
        });
      } else {
        console.log(`⏳ Payout ${payout.payoutId} still in status: ${stripePayout.status}`);
      }
    } catch (err) {
      console.error(`❌ Failed to check payout ${payout._id}:`, err.message);
    }
  }
};

cron.schedule("*/5 * * * *", confirmPendingPayouts, { runOnInit: true });
console.log("🕒 Stripe payout confirmation cron active");