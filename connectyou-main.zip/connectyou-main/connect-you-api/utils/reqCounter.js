const dayjs = require("moment-timezone");
const APILog = require("../models/apiLogs");

let requestCount = 0;
let requestCountPerDay = 0;
const apiCallMap = new Map(); // endpoint => [{ time, ip }, ...]
const writeToDBInterval = 12 * 60 * 60 * 1000; // every day and night
// const writeToDBInterval = 1 * 60 * 1000; // every minute

// Shutdown logger
const shutdownTime = () => {
  console.log(`Requests before server shutdown: ${requestCountPerDay}`);
  console.log(
    `Server stopped at ${dayjs()
      .tz("Asia/Calcutta")
      .format("DD MMMM YYYY hh:mm A")}`
  );
};

// Save API Logs to DB
const saveAPIlog = async () => {
  const summary = new Map();

  for (const [endpoint, calls] of apiCallMap.entries()) {
    const ipMap = new Map();

    calls.forEach(({ ip }) => {
      if (!ipMap.has(ip)) {
        ipMap.set(ip, { ipAddress: ip, requested: 1 });
      } else {
        const existing = ipMap.get(ip);
        existing.requested += 1;
        ipMap.set(ip, existing);
      }
    });

    summary.set(endpoint, {
      count: calls.length,
      ips: Object.fromEntries(ipMap), // <-- important fix here
    });
  }

  const totalMinutesInDay = 24 * 60;
  const avgPerMinute = requestCountPerDay / totalMinutesInDay;

  const logDoc = new APILog({
    totalRequestIn24Hours: requestCountPerDay,
    averageRequestsPerMinute: parseFloat(avgPerMinute.toFixed(2)),
    endpoints: Object.fromEntries(summary), // <-- important fix here
  });

  try {
    await logDoc.save();
    // console.log("✅ Log saved to DB");
  } catch (err) {
    // console.error("❌ Failed to save API log:", err);
  }
  console.log(
    `Requests saved for interval ${writeToDBInterval}ms: ${requestCountPerDay}`
  );
  apiCallMap.clear();
  requestCount = 0;
  requestCountPerDay = 0;
};

// Auto save logs every interval
setInterval(saveAPIlog, writeToDBInterval);

// Handle graceful shutdown
const gracefulShutdown = (signal) => {
  console.log(`Caught ${signal}. Shutting down...`);
  shutdownTime();
  process.exit(0);
};

// Catch shutdown signals
["SIGINT", "SIGTERM", "beforeExit"].forEach((signal) => {
  process.on(signal, () => gracefulShutdown(signal));
});

// Catch uncaught errors
process.on("uncaughtException", (err) => {
  console.error("💥 Uncaught Exception:", err);
  shutdownTime();
  process.exit(0);
});

process.on("unhandledRejection", (reason) => {
  console.error("💥 Unhandled Rejection:", reason);
  shutdownTime();
  process.exit(0);
});

// Track requests per hour
setInterval(() => {
  console.log(`Requests in the last hour: ${requestCount}`);
  requestCount = 0;
}, 1000 * 60 * 60);

// Middleware to count requests
exports.reqCounterModule = (req, res, next) => {
  requestCount++;
  requestCountPerDay++;

  const endpoint = `${req.method} ${req.originalUrl.split("?")[0]}`;
  const time = new Date().toISOString();
  const ip =
    req.headers["x-forwarded-for"]?.split(",")[0] ||
    req.connection.remoteAddress;

  if (!apiCallMap.has(endpoint)) {
    apiCallMap.set(endpoint, []);
  }

  apiCallMap.get(endpoint).push({ time, ip });

  next();
};
