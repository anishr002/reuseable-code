const moment = require("moment-timezone");
const path = require("path");
const puppeteer = require("puppeteer");
/**
 *
 * @param customerDetails : {
 * name,
 * lastName,
 * email,
 * address
 * }
 * @param orders  :{
 * array of orders}
 * @param invoice_number: stirng
 * @param transaction_id : string
 */

const generatePaymentReceipt = async ({
  customerDetails,
  orders,
  invoice_number = `CY_INV${Date.now()}`,
  transaction_id,
  order_id,
}) => {
  // Get the curren
  // t date in a readable format
  // console.log(
  //   "genderating recp",
  //   customerDetails,
  //   orders,
  //   invoice_number,
  //   transaction_id
  // );
  const date = moment().format("DD MMMM YYYY hh:mm A");
  let invoiceContent = "";
  let orderTotal = 0;
  orders.forEach((order, orderIndex) => {
    let sessionRows = "";
    order.sessionDetails.forEach((session, sessionIndex) => {
      orderTotal += session.price;
      sessionRows += `
         
            <tr>
                          <td
                            style="padding: 10px; font-size: 14px; color: #333"
                          >
                          ${sessionIndex + 1}
                          </td>
                          <td
                            style="padding: 10px; font-size: 14px; color: #333"
                          >
                         <b style="color:#013338;font-size:16px;"> ${
                           session.title
                         }</b><br/>
                          ${session.coachDetails.name} ${
        session.coachDetails.Lname
      }<br/>${session.coachDetails.email}
                          </td>
                          <td
                            style="
                              padding: 10px;
                              font-size: 16px;
                              text-align: right;
                              color: #333;
                            "
                          >
                          $${session.price.toFixed(2)}
                          </td>
                        </tr>
      `;
    });

    invoiceContent += ` ${sessionRows}`;
  });

  const htmlTemplate = `
  <html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment Confirmation</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <!-- Fallback font styles embedded for email clients that don't support web fonts -->
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap");
    </style>
  </head>
  <body
    style="
      margin: 0;
      padding: 0;
      font-family: 'Quicksand', 'Helvetica Neue', Helvetica, Arial, sans-serif;
      color: #333;
      line-height: 1.6;
      background-color: #ffffff !important;
      width: 800px;
      margin: 0 auto;
    "
  >
    <table
      cellpadding="0"
      cellspacing="0"
      border="0"
      style="width: 100%; background-color: #f0f0f0"
    >
      <tr>
        <td>
          <!-- MAIN EMAIL CONTAINER -->
          <table
            cellpadding="0"
            cellspacing="0"
            border="0"
            style="width: 100%; margin: 0 auto; height: 100%"
          >
            <!-- HEADER - Extends full width -->

            <!-- Invoice Header Starts -->
            <tr>
              <td style="padding: 0">
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; position: relative"
                >
                  <!-- Invoice Number Top-Right -->
                  <tr>
                    <td style="padding: 0; position: relative">
                      <!-- Centered Logo -->
                      <table width="100%">
                        <tr>
                          <td
                            style="
                              background-color: #ffffff;
                              padding: 40px 0;
                              text-align: center;
                            "
                          >
                            <img
                              src="https://api.connectyou.global/logo/loginLogo.png"
                              alt="ConnectYou.Global Logo"
                              style="max-width: 280px; height: auto"
                            />
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Hero Header -->
                  <tr>
                    <td style="padding: 0">
                      <table
                        cellpadding="20"
                        cellspacing="0"
                        border="0"
                        style="width: 100%"
                      >
                        <tr>
                          <td
                            style="
                              background: linear-gradient(
                                135deg,
                                #013338 0%,
                                #025e5a 100%
                              );
                              padding: 10px 70px;
                              text-align: center;
                            "
                          >
                            <h1
                              style="
                                color: #ffffff;
                                margin: 0;
                                font-size: 28px;
                                font-weight: 700;
                                letter-spacing: 0.5px;
                              "
                            >
                              Payment Receipt
                            </h1>
                            <p
                              style="
                                color: #ebbd33;
                                margin: 10px 0 0 0;
                                font-size: 18px;
                                font-weight: 400;
                                letter-spacing: 0.3px;
                              "
                            >
                              Thank you for choosing ConnectYou.Global
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Powered by -->
                  <tr>
                    <td
                      style="
                        background-color: #f5fafa;
                        padding: 8px 40px;
                        text-align: center;
                      "
                    >
                      <p style="margin: 0; font-size: 14px; color: #013338">
                        Powered by Erickson Coaching International
                      </p>
                    </td>
                  </tr>

                  <!-- Split: Issued To / Details -->
                  <tr>
                    <td
                      style="background-color: #ffffff; padding: 25px 40px 10px"
                    >
                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <!-- Issued To -->
                          <td width="50%" style="vertical-align: top">
                            <h3
                              style="
                                margin: 0 0 8px 0;
                                color: #013338;
                                font-size: 18px;
                              "
                            >
                              Issued To:
                            </h3>
                            <p style="margin: 0; color: #444; font-size: 14px">
                              ${customerDetails.name} ${
    customerDetails.lastName
  }<br />
                              ${customerDetails.email}<br />
                              ${customerDetails.address}<br />
                            </p>
                          </td>
                          <!-- Transaction Info -->
                          <td
                            width="50%"
                            style="text-align: right; vertical-align: top"
                          >
                            <table align="right">
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Invoice No. :
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${invoice_number}
                                </td>
                              </tr>
                              <tr></tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Date Issued:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${date || "-"}
                                </td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                  "
                                >
                                  Order ID:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${order_id || "-"}
                                </td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                  "
                                >
                                  Transaction ID:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${transaction_id || "-"}
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- HEADER - Extends full width -->
            <!-- MAIN CONTENT AREA -->
            <!-- Main Content / Booking Table -->
            <tr>
              <td style="padding: 30px 40px; background-color: #ffffff">
                <h2
                  style="margin-bottom: 20px; color: #013338; font-size: 20px"
                >
                  Order Summary
                </h2>
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; border-collapse: collapse"
                >
                  <!-- Table Headers -->
                  <thead>
                    <tr
                      style="
                        background-color: #f5fafa;
                        border-bottom: 1px solid #e0e0e0;
                      "
                    >
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Sr. No
                      </th>
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Booking Details
                      </th>
                      <th
                        style="
                          text-align: right;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Price
                      </th>
                    </tr>
                  </thead>

                  <!-- Sample Rows -->
                  <tbody>
                    <td
                      cellpadding="0"
                      cellspacing="0"
                      border="0"
                      style="
                        width: 100%;
                        border-collapse: collapse;
                        min-height: 500px;
                        display: table;
                      "
                    >
                      <!-- Table Body with Growing Space -->
                      <tbody style="height: 100%; display: table-row-group">
                        <!-- Item Rows -->
                        ${invoiceContent}
                        <!-- Add more rows as needed -->
                        <!-- Filler Row to Push Total Down -->
                        <tr>
                          <td colspan="3" style="height: 150px">&nbsp;</td>
                        </tr>
                        <!-- Total Row -->
                        <tr>
                          <td
                            colspan="2"
                            style="
                              padding: 12px 10px;
                              text-align: right;
                              font-size: 15px;
                              font-weight: 600;
                              color: #013338;
                              border-top: 2px solid #025e5a;
                            "
                          >
                            Total
                          </td>
                          <td
                            style="
                              padding: 12px 10px;
                              text-align: right;
                              font-size: 15px;
                              font-weight: 600;
                              color: #013338;
                              border-top: 2px solid #025e5a;
                            "
                          >
                            $${orderTotal.toFixed(2)}
                          </td>
                        </tr>
                      </tbody>
                    </td>
                  </tbody>
                </table>
              </td>
            </tr>

            <!-- MAIN CONTENT AREA -->
            <!-- FOOTER - Extends full width -->
            <tr>
              <td
                style="
                  background-color: #013338;
                  padding: 0;
                  width: 100%;
                  column-span: all;
                "
              >
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%"
                >
                  <!-- Company Info -->
                  <tr>
                    <td style="padding: 30px 40px 10px; text-align: center">
                      <table
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                        style="margin: 0 auto; text-align: center"
                      >
                        <tr>
                          <td
                            style="
                              padding: 8px 0;
                              color: white;
                              font-size: 14px;
                              font-style: italic;
                            "
                          >
                            Warm regards,
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 5px 0;
                              color: #ffffff;
                              font-size: 16px;
                              font-weight: bold;
                            "
                          >
                            Erickson Coaching International
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: white;
                              font-size: 13px;
                            "
                          >
                            Founders of ConnectYou
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: #78a5a4;
                              font-size: 12px;
                            "
                          >
                            www.connectyou.global | support@connectyou.com
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Invoice Info -->
                  <!-- Disclaimer -->
                  <tr>
                    <td
                      style="
                        padding: 15px 40px;
                        text-align: center;
                        background-color: #002326;
                      "
                    >
                      <p
                        style="
                          margin: 0;
                          color: #5f8886;
                          font-size: 12px;
                          line-height: 1.6;
                        "
                      >
                        This receipt has been issued for your records. Please
                        retain a copy for personal or business accounting. If
                        you have any questions regarding this invoice, feel free
                        to
                        <a
                          href="https://connectyou.global/get-in-touch"
                          style="color: #3aa7a3; text-decoration: none"
                          >contact us</a
                        >
                        or email us at
                        <a
                          href="mailto:support@connectyou.com"
                          style="color: #3aa7a3; text-decoration: none"
                          >support@connectyou.com</a
                        >. <br /><br />
                        Please note: This is a system-generated receipt. All
                        amounts are inclusive of applicable taxes unless
                        otherwise stated.
                      </p>
                    </td>
                  </tr>
                  <!-- Copyright -->
                  <tr>
                    <td style="padding: 10px 40px 25px; text-align: center">
                      <p style="margin: 0; color: #78a5a4; font-size: 13px">
                        &copy; 2024 ConnectYou.Global. All rights reserved.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- FOOTER - Extends full width -->
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>

  `;

  // removed tax line row from the receipt template of payment receipt , can be added back at the bottom of the table
  // <tr>
  //     <td colspan="3" style="text-align: right;"><strong>Tax (10%):</strong></td>
  //     <td>$00.00</td>
  // </tr>
  // Generate the PDF
  let browser;
  if (process.env.BACKEND_URL == "http://localhost:7000") {
    //for local
    browser = await puppeteer.launch();
  } else {
    //for server
    browser = await puppeteer.launch({
      executablePath: "/usr/bin/chromium-browser",
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
  }
  const page = await browser.newPage();
  // Set the content of the page to the HTML template
  await page.setContent(htmlTemplate, { waitUntil: "networkidle0" });
  // Define the PDF filename
  const pdfPath = `payment_receipt_${customerDetails.lastName}_${
    customerDetails.name
  }_${Date.now()}.pdf`;
  // Generate the PDF
  const resolvedPath = path.resolve(__dirname, "../public/receipt", pdfPath);
  await page.pdf({
    path: resolvedPath,
    format: "A4",
    printBackground: true,
  });
  await browser.close();
  console.log(pdfPath);
  return pdfPath; // Return the path to the generated PDF
};

module.exports = generatePaymentReceipt;
