const CoachModel = require("../models/coach");
const userModel = require("../models/user");

exports.validateEmailForDB = async (email) => {
  try {
    const responses = await Promise.allSettled([
      CoachModel.exists({ email }),
      userModel.exists({ email }),
    ]);
    const emailExists = responses.some(
      (res) => res.status === "fulfilled" && res.value
    );
    if (emailExists) {
      return false;
    }
    return true;
  } catch (error) {
    console.error("Error validating email:", error);
    return false;
  }
};
