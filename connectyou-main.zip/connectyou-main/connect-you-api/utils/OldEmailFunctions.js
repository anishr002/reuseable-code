//send session completed confiration email to user
const sessionCompletedEmailUser = async (
  userName,
  coachName,
  sessionDate,
  userEmail,
  timeZone
) => {
  try {
    let userName1 = capitalizeFirstLetter(userName);
    let coachName1 = capitalizeFirstLetter(coachName);
    const sessionUpdatedDate = moment
      .tz(sessionDate, timeZone)
      .format("DD-MM-YYYY");

    const sessionUpdatedTime = `${moment
      .tz(sessionDate, timeZone)
      .format("hh:mm A")} - ${moment
      .tz(sessionDate, timeZone)
      .add(1, "hours")
      .format("hh:mm A")}`;
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userEmail,
      subject: `Your Coaching Session with ${coachName1} Has Been Completed`,
      template: "sessionCompletedUser",
      context: {
        userName: userName1,
        coachName: coachName1,
        sessionDate: sessionUpdatedDate,
        sessionTime: sessionUpdatedTime,
      },
    };
    await transportEmail.createEmail({ mailOptions: mailOptionsForUser });
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};
//send session cancel confiration email to user
const sessionCancelEmailUser = async (
  userName,
  coachName,
  sessionDate,
  userEmail,
  timeZone
) => {
  try {
    let userName1 = capitalizeFirstLetter(userName);
    let coachName1 = capitalizeFirstLetter(coachName);
    const sessionUpdatedDate = moment
      .tz(sessionDate, timeZone)
      .format("DD-MM-YYYY");

    const sessionUpdatedTime = `${moment
      .tz(sessionDate, timeZone)
      .format("hh:mm A")} - ${moment
      .tz(sessionDate, timeZone)
      .add(1, "hours")
      .format("hh:mm A")}`;
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userEmail,
      subject: `Confirmation of Coaching Session Cancellation`,
      template: "sessionCancelUser",
      context: {
        userName: userName1,
        coachName: coachName1,
        sessionDate: sessionUpdatedDate,
        sessionTime: sessionUpdatedTime,
      },
    };
    await transportEmail.createEmail({ mailOptions: mailOptionsForUser });
  } catch (error) {
    console.log(error);
  }
};
