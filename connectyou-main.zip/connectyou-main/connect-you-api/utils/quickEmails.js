const capitalizeFirstLetter = require("../lib/capitalizeFirstLetter");
const transportEmail = require("../lib/email");
const { CreateNotification } = require("../models/notificationModal");
const mongoose = require("mongoose");
const moment = require("moment-timezone");
const path = require("path");
const sendAccountDeletionEmail = async (name, email) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: "Account Deleted",
    template: "accountDeletedMail",
    context: {
      name: name,
      email: email,
    },
  };
  await transportEmail.createEmail({ mailOptions });
};

const passwordRecoveryUpdateEmail = async (name, email, bool) => {
  try {
    const mailOptions = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: email,
      subject: "Password Updated !",
      template: bool ? "passwordUpdated" : "passwordReset",
      context: {
        name: name,
        email: email,
        date: new Date().toLocaleString(),
      },
    };
    await transportEmail.createEmail({ mailOptions });
  } catch (error) {
    console.log(error);
  }
};

const sendAccountBlockedMail = async (name, email) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: "Account Blocked",
    template: "blockedAccountMail",
    context: {
      name: name,
      email: email,
    },
  };
  await transportEmail.createEmail({ mailOptions });
};

const paymentConfirmationUser = async ({
  userName,
  amount,
  transactionID,
  userEmail,
  fileName,
  receiverId,
  image,
}) => {
  let userName1 = capitalizeFirstLetter(userName);
  let amount1 = amount == 0 ? amount : amount / 100;
  const mailOptionsForUser = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: userEmail,
    subject: `Payment Confirmed: Your Coaching Session confirmation`,
    template: "paymentConfirmationUpdateEmail",
    context: {
      userName: userName1,
      amount: amount1,
      transactionID,
      image: `${process.env.BACKEND_URL}/usersProfile/${image}`,
      date: moment().format("DD-MMMM-YYYY hh:mm A"),
    },
    attachments: [
      {
        filename: fileName,
        path: path.join(__dirname, "..", "public", "receipt", fileName),
        //location of recipt from the function ../public/receipt
      },
    ],
  };
  try {
    await CreateNotification({
      user_id: mongoose.Types.ObjectId.createFromHexString(receiverId),
      notification_type: "payments",
      heading: "Payment successfull",
      description: `Your transaction : #${transactionID},amounting $${amount1}, paid on ${moment().format(
        "DD-MMMM-YYYY hh:mm A"
      )} was successfully processed. The receipt for the transaction have been emailed to you on the registered email address, and can be downloaded from the booking details section.`,
    });
    await transportEmail.createEmail({ mailOptions: mailOptionsForUser });
  } catch (error) {
    console.log(error);
  }
};

const coacheeSessionEventUpdateEmailer = async ({
  email,
  title,
  recipient,
  emailSummaryTitle,
  highlightSummary,
  highlightSubSummary,
  sessionTitle,
  sessionTime,
  sessionStatus,
  sessionPrice,
  coachName,
  coachProfileLink,
  subject,
  action,
}) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: subject,
    template: "coacheeSessionEventsUpdate",
    context: {
      email,
      title,
      recipient,
      emailSummaryTitle,
      highlightSummary,
      highlightSubSummary,
      sessionTitle,
      sessionTime,
      sessionStatus,
      sessionPrice,
      coachName,
      coachProfileLink,
      action,
    },
  };

  await transportEmail.createEmail({ mailOptions });
};

const coachSessionEventUpdateEmailer = async ({
  email,
  title,
  recipient,
  emailSummaryTitle,
  highlightSummary,
  highlightSubSummary,
  sessionTitle,
  sessionTime,
  sessionStatus,
  sessionPrice,
  coacheeName,
  subject,
  action,
}) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: subject,
    template: "coachSessionEventsUpdate",
    context: {
      email,
      title,
      recipient,
      emailSummaryTitle,
      highlightSummary,
      highlightSubSummary,
      sessionTitle,
      sessionTime,
      sessionStatus,
      sessionPrice,
      coacheeName,
      action,
    },
  };

  await transportEmail.createEmail({ mailOptions });
};

module.exports = {
  sendAccountDeletionEmail,
  passwordRecoveryUpdateEmail,
  sendAccountBlockedMail,
  paymentConfirmationUser,
  coacheeSessionEventUpdateEmailer,
  coachSessionEventUpdateEmailer,
};
