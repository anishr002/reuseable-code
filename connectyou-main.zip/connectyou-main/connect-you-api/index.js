require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const app = express();
const { createServer } = require("http");
const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");
const { listenToNewAlerts } = require("./models/notificationModal");
const CoachModel = require("./models/coach");
const userModel = require("./models/user");
const portNo = process.env.PORT;
const jwtSecret = process.env.JWT_SECRET;
const PORT = Number(portNo);
let admin = require("firebase-admin");
let serviceAccount = require("./web-push-notification-7401d-firebase-adminsdk-r5wza-1c4f2f3a5b.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const { reqCounterModule } = require("./utils/reqCounter");
const db = require("./db");
(async () => {
  try {
    await db.connect();
  } catch (error) {
    console.error("Database connection error:", error);
  }
})();

const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: [process.env.FRONTEND_URL_Admin, process.env.FRONTEND_URL_web],
    credentials: true,
  },
});
const messageChat = require("./API-V1/coach/controllers/messageChat");
let onlineUsers = {};
const onConnection = async (socket) => {
  let userData = socket.request.userData;
  socket.join(socket.request.userData._id);
  socket.on("user-online", async (data) => {
    onlineUsers[data.userId] = socket.id;
    // console.log(`${data.userId} is online`);
    console.log(`users online : ${Object.keys(onlineUsers).length}`);
    await messageChat.markAsDelivered(data, socket, io);
  });
  socket.on("user-offline", (userId) => {
    delete onlineUsers[userId];
    // console.log(`${userId} is offline`);
    console.log(`users online : ${Object.keys(onlineUsers).length}`);
  });

  if (userData && userData.userType && userData.userType == "coachee") {
    let userId = socket.request.userData._id;
    socket.userId = userId;
    await userModel.findByIdAndUpdate({ _id: userId }, { $set: { live: 1 } });

    // io.emit("new-message", { message: "A new message has been posted!" });
    io.emit("new-connected-users", { live: 1 });
  }
  if (userData && userData.userType && userData.userType == "coach") {
    let coachId = socket.request.userData._id;
    socket.coachId = coachId;
    await CoachModel.findByIdAndUpdate({ _id: coachId }, { $set: { live: 1 } });
    // io.emit("new-message", { message: "A new message has been posted!" });
    io.emit("new-connected-coaches", { live: 1 });
  }
  socket.on("disconnect", async () => {
    if (socket.userId) {
      await userModel.findByIdAndUpdate(
        { _id: socket.userId },
        { $set: { live: 0, lastSeen: new Date() } }
      );
      io.emit("new-diconnected-users", { live: 0 });
    }
    if (socket.coachId) {
      await CoachModel.findByIdAndUpdate(
        { _id: socket.coachId },
        { $set: { live: 0, lastSeen: new Date() } }
      );
      io.emit("new-diconnected-coaches", { live: 0 });
    }
    for (const userId in onlineUsers) {
      if (onlineUsers[userId] === socket.id) {
        delete onlineUsers[userId];
        console.log(`${userId} has been disconnected`);
        break;
      }
    }
  });
  //Join the room event
  socket.on("join-room", (data) => messageChat.joinroom(data, socket, io));
  //send and receive message event
  socket.on("send-message", (data) =>
    messageChat.sendMessage(data, socket, io)
  );
  //get the inbox data
  socket.on("coach-inbox", (data) => messageChat.coachInbox(data, socket, io));
  socket.on("user-inbox", (data) => messageChat.userInbox(data, socket, io));
  socket.on("mark-message-read", (data) =>
    messageChat.markMessageRead(data, socket, io)
  );
  socket.on("tying-message-starts", (data) =>
    messageChat.TypingStatus(data, socket, io)
  );
  socket.on("tying-message-stops", (data) =>
    messageChat.TypingStatus(data, socket, io)
  );
  socket.on(`message-delivery-status-delivered`, (data) =>
    messageChat.markAsDelivered(data, socket, io)
  );
  socket.on("listen-alerts", (data) => listenToNewAlerts({ data, socket, io })); // this line added on 11/21/24/ for adding push live socket notifications
};

exports.emitNewNotification = async ({ listener_id, data }) => {
  return io.to(listener_id).emit("new-alert", data);
};

io.on("connection", onConnection);
io.engine.use((req, res, next) => {
  const isHandshake = req._query.sid === undefined;
  if (!isHandshake) {
    return next();
  }
  const header = req.headers["authorization"];

  if (!header) {
    return next(new Error("no token"));
  }
  if (!header.startsWith("bearer ")) {
    return next(new Error("invalid token"));
  }
  const token = header.substring(7);
  jwt.verify(token, jwtSecret, (err, decoded) => {
    if (err) {
      return next(new Error("invalid token"));
    }
    req.userData = decoded;
    return next();
  });
});

const corsOptions = {
  origin: [process.env.FRONTEND_URL_Admin, process.env.FRONTEND_URL_web],
  credentials: true,
};

app.use(cors(corsOptions));
app.set("trust proxy", true);
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use(reqCounterModule);

// routes
const adminRouter = require("./routers/admin");
app.use("/admin", adminRouter);
const coachRouter = require("./routers/coach");
app.use("/coach", coachRouter);
const userRouter = require("./routers/user");
app.use("/user", userRouter);
const hubRouter = require("./API-V1/Hubspot/router");
app.use("/hub", hubRouter);
const API_V2_Router = require("./api-v2/Router");
app.use("/api-v2", API_V2_Router);
//stripe listen --forward-to localhost:7000/webhook
const stripeWebhook = require("./api-v2/webhooks/stripe/stripe");
const { startConversionRateJob } = require("./lib/initConversionRateJob");
app.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  stripeWebhook.stripeWebhookRouter
);
startConversionRateJob();
setTimeout(() => require("./services/cron"), 5000);
server.listen(PORT, () => console.log(`Server running on port  ${PORT}`));
