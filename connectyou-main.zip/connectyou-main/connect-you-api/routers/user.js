const express = require("express");
const router = express.Router();

const userAuthentication = require("../API-V1/user/routes/userAuthentication");
router.use("/authentication", userAuthentication);
const userProfile = require("../API-V1/user/routes/userProfile");
router.use("/profile", userProfile);
const PaymentLink = require("../API-V1/user/routes/PaymentLink");
router.use("/PaymentLink", PaymentLink);
const userOrder = require("../API-V1/user/routes/order");
router.use("/order", userOrder);
const userRating = require("../API-V1/user/routes/rating");
router.use("/rating", userRating);
const dashboardRouteUser = require("../API-V1/user/routes/dashboard");
router.use("/dashboard", dashboardRouteUser);
const cartRouteUser = require("../API-V1/user/routes/cart");
router.use("/cart", cartRouteUser);
const policyRouter = require("../API-V1/user/routes/policies");
router.use("/policies", policyRouter);
const paymentHistoryRouter = require("../API-V1/user/routes/paymentHistory");
router.use("/payments", paymentHistoryRouter);
const resourceRouterUser = require("../API-V1/user/routes/resources");
router.use("/resource", resourceRouterUser);

module.exports = router;
