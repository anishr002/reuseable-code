const { google } = require("googleapis");
const { OAuth2 } = google.auth;
require("dotenv").config();
const google_clientId = process.env.google_clientId;
const google_clientSecret = process.env.google_clientSecret;
const BACKEND_URL = process.env.BACKEND_URL;

const redirectUri = `${BACKEND_URL}/coach/profile/oauth2callback`;
const oAuth2Client = new OAuth2(
  google_clientId,
  google_clientSecret,
  redirectUri
);

module.exports = oAuth2Client;
