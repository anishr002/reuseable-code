const { validationResult } = require("express-validator");
const coachPayoutModel = require("../../models/coachPayout");
const CoachModel = require("../../models/coach");
const completedOrderModal = require("../../models/completedOrders");
const { default: mongoose } = require("mongoose");
const RejectedCoachPayoutModel = require("../../models/rejectedCoachPayout");
const {
  reverseTransferSafely,
  roundDownToNearest10,
  adjustAmountToBalance,
} = require("../../lib/stripe");
require("dotenv").config();
const Stripe = require("stripe");
const { getConversionRates } = require("../../lib/conversionRate");
const { CreateNotification } = require("../../models/notificationModal");
const stripe = Stripe(process.env.STRIPE_SK);

exports.coachPayoutApprove = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  let createdTransferId = null;
  let coachPayoutData = undefined;
  try {
    const payoutId = req.params.id; // payout id
    const { coachId } = req.body; // coach id
    const balance = await stripe.balance.retrieve();
    const availableBalance = balance.available?.find(
      (a) => a?.currency?.toUpperCase() === "USD"
    );
    // console.log("Platform Account balance details ", {
    //   availableBalance,
    //   balance: balance.available,
    // });
    const [totalRevenueData, totalPayoutAmount, cP, coachData] =
      await Promise.all([
        completedOrderModal.aggregate([
          {
            $match: {
              coachId: new mongoose.Types.ObjectId(coachId),
            },
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amount" },
            },
          },
        ]),
        coachPayoutModel.aggregate([
          {
            $match: {
              coachId: new mongoose.Types.ObjectId(coachId),
              status: 1,
            },
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amount" },
            },
          },
        ]),
        coachPayoutModel.findOne({ _id: payoutId }),
        CoachModel.findOne({ _id: coachId }),
      ]);
    if (!cP || !coachData) {
      let message;
      if (!coachPayoutData) {
        message = "Coach's payout details not found !";
      }
      if (!coachData) {
        message = "Coach's details not found !";
      }
      const response = {
        success: false,
        message: message,
      };
      return res.status(400).json(response);
    }
    if (!coachData?.stripe_accID) {
      return res.status(200).json({
        success: false,
        message:
          "The requested bank account for coach was removed, Please reject this request, so the coach can request again with new added KYC approved bank account.",
        title: "Expired or Invalid request",
      });
    }
    coachPayoutData = cP;
    const bankAccounts = await stripe.accounts.listExternalAccounts(
      coachData.stripe_accID,
      { object: "bank_account", limit: 1 }
    );
    if (
      !bankAccounts ||
      !bankAccounts.data ||
      bankAccounts.data?.length === 0
    ) {
      return res.status(200).json({
        success: false,
        message:
          "The requested bank account for coach was removed, Please reject this request, so the coach can request again with new added KYC approved bank account.",
        title: "Expired or Invalid request",
      });
    }
    const bankCurrency =
      bankAccounts.data[0]?.currency?.toUpperCase() ||
      coachData.stripeCountryDetails?.currency;
    const currency = coachData.stripeCountryDetails?.currency;
    const ratesData = await getConversionRates();
    const countryRate = bankCurrency
      ? ratesData.rates[bankCurrency]
      : ratesData.rates[currency];
    if (!countryRate) {
      return res.status(400).json({
        success: false,
        title: "Currency Error",
        message: `Conversion rate for currency ${currency} is unavailable at the moment, Please try again later or contact support for help.`,
      });
    }
    const totalRevenue =
      totalRevenueData.length > 0 ? totalRevenueData[0].totalAmount : 0;
    const totalPayout =
      totalPayoutAmount.length > 0 ? totalPayoutAmount[0].totalAmount : 0;
    const totalBalance = totalRevenue - totalPayout;
    if (coachPayoutData.amount > totalBalance) {
      const response = {
        success: false,
        message: "Coach have Insufficient balance for the payout.",
      };
      return res.status(400).json(response);
    }
    if (coachPayoutData.amount > availableBalance) {
      const response = {
        success: false,
        message:
          "Insufficient balance in your stripe account to approve the payout",
      };
      return res.status(400).json(response);
    }
    if (coachPayoutData.payoutId) {
      try {
        const payout = await stripe.payouts.retrieve(coachPayoutData.payoutId);
        if (payout.status === "paid") {
          await coachPayoutModel.findOneAndUpdate(
            { _id: coachPayoutData.payoutId },
            {
              paid: true,
              status: 1,
              confirmedDate: new Date().toISOString(),
            }
          );
          return res.status(400).json({
            success: false,
            message: "This payout request has already been processed.",
          });
        }
      } catch (stripeError) {
        console.error(
          "Stripe payout retrieval error at approve function:",
          stripeError.message
        );
        return res.status(500).json({
          success: false,
          message: "Unable to verify payout status with Stripe.",
        });
      }
    }
    // transfer funds to coach's connect account
    let transferId;
    const requestedConnectStripeId = coachData.stripe_accID;
    if (!coachPayoutData.transferId) {
      let transfer;
      try {
        transfer = await stripe.transfers.create({
          amount: coachPayoutData.amount,
          currency: "usd",
          destination: requestedConnectStripeId,
        });
        // console.log({ transfer });
        createdTransferId = transfer.id;
        if (createdTransferId) {
          await coachPayoutModel.updateOne(
            {
              coachId: new mongoose.Types.ObjectId(coachId),
            },
            {
              $set: {
                transferId: transfer.id,
                transfer_transactionId: transfer.balance_transaction,
                transfer_destination: transfer.destination,
                transfer_destination_paymentId: transfer.destination_payment,
                currency: "usd",
                status: 1, // 1 for approved by admin
                transferredOn: new Date().toISOString(),
              },
            }
          );
        }
        transferId = transfer.id;
      } catch (error) {
        console.log("Error while creating a transfer", { error });
        return res.status(500).json({
          success: false,
          message:
            error?.message ||
            "Unable to process the transfer to recipients bank country",
        });
      }
    } else {
      transferId = coachPayoutData.transferId;
    }
    if (transferId) {
      const coachStripeBalance = await stripe.balance.retrieve({
        stripeAccount: coachData.stripe_accID,
      });
      const requestedLocalAmount = Number(coachPayoutData.amount) * countryRate;
      const availableCurrency =
        coachStripeBalance.available.find(
          (bal) => bal?.currency?.toUpperCase() === bankCurrency
        ) ||
        coachStripeBalance.available.find(
          (bal) =>
            bal?.currency?.toUpperCase() ===
            coachPayoutData?.currency?.toUpperCase()
        );
    //   console.log({
    //     coachStripeBalance: coachStripeBalance,
    //     "Bank currency of coach:": bankCurrency,
    //     coachCur: coachPayoutData?.currency,
    //     "Available currency found:": availableCurrency,
    //     am: coachPayoutData.amount,
    //     requestedLocalAmount,
    //   });
      if (!availableCurrency) {
        const payoutRequestTime = await coachPayoutModel.findOne(
          {
            transferId: transferId,
          },
          "transferredOn"
        );
        const now = new Date();
        const transferDate = new Date(payoutRequestTime?.transferredOn);
        const msIn24Hours = 24 * 60 * 60 * 1000;
        const isLessThan24Hours =
          transferDate instanceof Date &&
          !isNaN(transferDate.getTime()) &&
          now.getTime() - transferDate.getTime() < msIn24Hours;
        if (isLessThan24Hours) {
          return res.status(200).json({
            success: false,
            title: "Transfer pending.",
            message:
              "The payout transfer to this request still pending sometimes It may take upto 24hours. Please wait at least 24 hours before trying again,or you can cancel the transfer and payout by rejecting this payout.",
          });
        }
        if (createdTransferId) {
          await reverseTransferSafely(
            createdTransferId,
            coachPayoutData.amount
          );
          await coachPayoutModel.updateOne(
            { _id: payoutId },
            {
              $set: { status: 0 },
              $unset: {
                transferId: "",
                transfer_transactionId: "",
                transfer_destination: "",
                transfer_destination_paymentId: "",
                currency: "",
              },
            }
          );
        }
        const response = {
          success: false,
          message: `Insufficient funds in the coach's account for the requested payout of ${
            coachPayoutData.currency
          }${
            coachPayoutData.amount / 100
          }. Please ensure there are sufficient funds or transfer additional funds to the account.`,
        };
        return res.status(400).json(response);
      }
      const txnId = `CY_CP_TXN_${Math.floor(
        10000 + Math.random() * 90000
      )}_${Date.now()}`;
      try {
        const localPayoutAmount = adjustAmountToBalance(
          requestedLocalAmount,
          availableCurrency?.amount
        );
        // console.log({
        //   localPayoutAmount,
        //   amountToBePaid: roundDownToNearest10(localPayoutAmount),
        // });
        let payout;
        try {
          payout = await stripe.payouts.create(
            {
              amount: roundDownToNearest10(localPayoutAmount),
              currency: availableCurrency.currency,
              destination: coachPayoutData.bankId,
              metadata: {
                coachId: coachData._id.toString(),
                coachPayoutId: coachPayoutData._id.toString(),
                transactionId: txnId,
                type: "payout",
              },
            },
            {
              stripeAccount: coachData.stripe_accID,
            }
          );
        } catch (error) {
          console.log("Error while creating the payout, stripe Error", {
            error,
          });
          return res.status(500).json({
            success: false,
            message: `Error while creating the payout of amount ${
              coachPayoutData.currency
            }${coachPayoutData.amount / 100}, Stripe: ${error?.message}`,
          });
        }
        let payData;
        if (payout) {
          payData = await coachPayoutModel.findByIdAndUpdate(
            {
              _id: payoutId,
            },
            {
              $set: {
                payoutId: payout.id,
                payout_transactionId: payout.balance_transaction,
                payout_destination: payout.destination,
                payout_type: payout.type,
                status: 1, // 1 for approved by admin
                approveDate: new Date().toISOString(),
                transactionId: txnId,
                localAmountTransferred: roundDownToNearest10(localPayoutAmount),
                localCurrency: availableCurrency.currency,
              },
            },
            { new: true }
          );
        } else {
          if (createdTransferId) {
            await this.reverseTransferSafely(
              createdTransferId,
              coachPayoutData.amount
            );
            await coachPayoutModel.updateOne(
              { _id: payoutId },
              {
                $set: { status: 0 },
                $unset: {
                  transferId: "",
                  transfer_transactionId: "",
                  transfer_destination: "",
                  transfer_destination_paymentId: "",
                  currency: "",
                },
              }
            );
          }
          return res.status(500).json({
            success: false,
            message: `Error while creating the payout of amount ${
              coachPayoutData.currency
            }${coachPayoutData.amount / 100}`,
          });
        }
        // console.log({ payout, payData });
        if (payData) {
          const response = {
            success: true,
            coachData,
            payout,
            message: "Coach Payout has been approved successfully",
          };
          Promise.allSettled([
            CreateNotification({
              user_id: coachId,
              heading: `Your payout request for Amount ${"$"} ${
                coachPayoutData.amount / 100
              } have been approved.`,
              description: ` Your request for the sum of amount ${"$"} ${
                coachPayoutData.amount / 100
              } have been approved by the administrator, You will receive the transfer shortly. The status of you payout request will be updated once the payout is confirmed, and you will be notified about the confirmation. If this was not you Please report this immediately.`,
              url: `/c/finances/payout-history`,
              notification_type: "admin",
            }),
          ]);
          return res.status(200).json(response);
        } else {
          if (createdTransferId) {
            await reverseTransferSafely(
              createdTransferId,
              coachPayoutData.amount
            );
            await coachPayoutModel.updateOne(
              { _id: payoutId },
              {
                $set: { status: 0 },
                $unset: {
                  transferId: "",
                  transfer_transactionId: "",
                  transfer_destination: "",
                  transfer_destination_paymentId: "",
                  currency: "",
                },
              }
            );
          }
          return res.status(500).json({
            success: false,
            message: `Error while approving the payout of amount ${
              coachPayoutData.currency
            }${coachPayoutData.amount / 100}`,
          });
        }
      } catch (payoutError) {
        console.log("Payout creation failed:", payoutError);
        if (createdTransferId) {
          await reverseTransferSafely(
            createdTransferId,
            coachPayoutData.amount
          );
          await coachPayoutModel.updateOne(
            { _id: payoutId },
            {
              $set: { status: 0 },
              $unset: {
                transferId: "",
                transfer_transactionId: "",
                transfer_destination: "",
                transfer_destination_paymentId: "",
                currency: "",
              },
            }
          );
        }
        return res.status(500).json({
          success: false,
          message: `Failed to create payout: ${payoutError.message}`,
        });
      }
    } else {
      return res.status(500).json({
        success: false,
        message: `Unable to process the transfer of ${
          coachPayoutData.currency
        }${coachPayoutData.amount / 100} to coach's connect stripe account`,
      });
    }
  } catch (err) {
    console.log("Main error:", err);
    if (createdTransferId) {
      await reverseTransferSafely(createdTransferId, coachPayoutData.amount);
      try {
        await coachPayoutModel.updateOne(
          { _id: payoutId },
          {
            $set: { status: 0 },
            $unset: {
              transferId: "",
              transfer_transactionId: "",
              transfer_destination: "",
              transfer_destination_paymentId: "",
              currency: "",
            },
          }
        );
      } catch (dbError) {
        console.log("Database cleanup failed:", dbError);
      }
    }
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.RejectPayoutRequest = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    return res
      .status(400)
      .json({ success: false, message: paramError.errors[0].msg });
  }
  try {
    const pId = req.params.id;
    const payoutId = new mongoose.Types.ObjectId(pId);
    const payoutDetails = await coachPayoutModel.findOne({ _id: payoutId });
    if (!payoutDetails) {
      return res
        .status(404)
        .json({ success: false, message: "Payout request not found" });
    }
    if (payoutDetails.payoutId) {
      try {
        const payout = await stripe.payouts.retrieve(payoutDetails.payoutId);
        if (payout.status === "paid") {
          await coachPayoutModel.findOneAndUpdate(
            { _id: payoutId },
            {
              paid: true,
              status: 1,
              confirmedDate: new Date().toISOString(),
            }
          );
          return res.status(400).json({
            success: false,
            message:
              "This payout request has already been processed and paid out.",
          });
        }
      } catch (stripeError) {
        console.error("Stripe payout retrieval error:", stripeError.message);
        return res.status(500).json({
          success: false,
          message:
            "Unable to verify payout status with Stripe." +
            `Stripe: ${stripeError.message}`,
        });
      }
    }
    // Attempt transfer reversal if transferId is present
    if (payoutDetails.transferId) {
      try {
        const reversal = await reverseTransferSafely(
          payoutDetails.transferId,
          payoutDetails.amount
        );
        console.log("Reversal successful:", reversal.id);
      } catch (err) {
        return res.status(500).json({
          success: false,
          message: `Transfer reversal failed: ${err.message}, This payout may already have been paid.`,
        });
      }
    }
    const rejectedPayout = await RejectedCoachPayoutModel.create({
      ...payoutDetails.toObject(),
      _id: undefined,
    });
    await coachPayoutModel.findOneAndDelete({ _id: payoutId });
    return res.status(200).json({
      success: true,
      message: "Payout request rejected and transfer reversed (if any)",
      data: rejectedPayout,
    });
  } catch (error) {
    console.error("Error in RejectPayoutRequest:", error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
// only for reading
exports.payoutHistory = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const pageNo = Number(req.query.pageNo) || 1;
    const limit = 20;
    const skip = pageNo * limit - limit;
    const filterOption = req.query.filterOption;
    let matchPipe = {};
    if (!isNaN(Number(filterOption)) && Number(filterOption) !== 2) {
      matchPipe.status = Number(filterOption);
    } else matchPipe = {};
    const payoutHistory = await coachPayoutModel.aggregate([
      {
        $match: matchPipe,
      },
      {
        $lookup: {
          from: "coaches",
          let: { coachId: "$coachId" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ["$_id", "$$coachId"],
                },
              },
            },
            {
              $lookup: {
                from: "coach-payouts",
                let: { coachId: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $eq: ["$coachId", "$$coachId"],
                      },
                    },
                  },
                  {
                    $group: {
                      _id: "$coachId",
                      totalAmountApproved: {
                        $sum: {
                          $cond: [{ $eq: ["$status", 1] }, "$amount", 0], // Sum for status 1
                        },
                      },
                      totalAmountPending: {
                        $sum: {
                          $cond: [{ $eq: ["$status", 0] }, "$amount", 0], // Sum for status 0
                        },
                      },
                    },
                  },
                ],
                as: "coachPayouts",
              },
            },
          ],
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "completedorders",
          localField: "coachId",
          foreignField: "coachId",
          as: "completedOrdersData",
        },
      },
      {
        $addFields: {
          totalAmount: {
            $sum: "$completedOrdersData.amount",
          },
        },
      },
      {
        $project: {
          _id: 1,
          coachId: 1,
          createdAt: 1,
          approveDate: 1,
          status: 1,
          paid: 1,
          amount: 1,
          totalAmount: 1,
          totalPayout: {
            $ifNull: [
              {
                $arrayElemAt: [
                  "$coachData.coachPayouts.totalAmountApproved",
                  0,
                ],
              },
              0,
            ],
          },
          totalPayoutPending: {
            $ifNull: [
              {
                $arrayElemAt: ["$coachData.coachPayouts.totalAmountPending", 0],
              },
              0,
            ],
          },
          coachData: {
            coachId: "$coachData._id",
            name: "$coachData.name",
            Lname: "$coachData.Lname",
            email: "$coachData.email",
            image: "$coachData.image",
          },
        },
      },

      { $sort: { createdAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (payoutHistory[0].pageInfo.length > 0) {
      totalPages = Math.ceil(payoutHistory[0].pageInfo[0].count / limit);
    }
    const payoutHistoryData = payoutHistory[0].data;
    const response = {
      success: true,
      payoutHistory: payoutHistoryData,
      totalPages,
      currentPage: pageNo,
      message: "Data retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.coachPayoutHistory = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const coachId = req.params.id; //coach id form the param
    const pageNo = Number(req.query.pageNo) || 1;
    const limit = 10;
    const skip = pageNo * limit - limit;
    const [coachData, totalRevenueData, payoutData] = await Promise.all([
      CoachModel.findOne({ _id: coachId }).select("_id name Lname email image"),
      completedOrderModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        {
          $facet: {
            totalRevenue: [
              {
                $group: {
                  _id: null,
                  total: { $sum: "$amount" },
                },
              },
            ],
          },
        },
        {
          $project: {
            totalRevenue: {
              $ifNull: [{ $arrayElemAt: ["$totalRevenue.total", 0] }, 0],
            },
          },
        },
      ]),
      coachPayoutModel.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        {
          $sort: { createdAt: -1 },
        },
        {
          $facet: {
            pageInfo: [{ $count: "count" }],
            totalBalance: [
              {
                $group: {
                  _id: null,
                  total: {
                    $sum: {
                      $cond: [{ $eq: ["$status", 1] }, "$amount", 0], // Sum for status 1
                    },
                  },
                  totalAmountPending: {
                    $sum: {
                      $cond: [{ $eq: ["$status", 0] }, "$amount", 0], // Sum for status 0
                    },
                  },
                },
              },
            ],
            data: [{ $skip: skip }, { $limit: limit }],
          },
        },
        {
          $project: {
            pageInfo: {
              $ifNull: [{ $arrayElemAt: ["$pageInfo.count", 0] }, 1],
            },
            totalBalance: {
              $ifNull: [{ $arrayElemAt: ["$totalBalance.total", 0] }, 0],
            },
            totalAmountPending: {
              $ifNull: [
                { $arrayElemAt: ["$totalBalance.totalAmountPending", 0] },
                0,
              ],
            },
            data: 1,
          },
        },
      ]),
    ]);
    const totalRevenue = Number(totalRevenueData[0].totalRevenue) / 100;
    const pendingPayout = Number(payoutData[0].totalAmountPending) / 100;
    const totalPayout = Number(payoutData[0].totalBalance) / 100;
    const totalBalance = totalRevenue - totalPayout;
    const totalPages = Math.ceil(payoutData[0].pageInfo / limit);
    const response = {
      success: true,
      payoutList: payoutData[0].data,
      balanceDetails: {
        totalRevenue: totalRevenue,
        payoutBalance: totalPayout,
        payoutBalancePending: pendingPayout,
        totalBalance: totalBalance,
      },
      coachData,
      totalPages,
      currentPage: pageNo,
      message: "Coach Payout Data retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
