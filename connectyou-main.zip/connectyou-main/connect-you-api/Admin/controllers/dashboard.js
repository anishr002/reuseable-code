const { validationResult } = require("express-validator");
require("dotenv").config();
const mongoose = require("mongoose");
//environment variables
//import the modals

const bookingModal = require("../../models/booking");
const sessionBookingModal = require("../../models/booked_session");
const coachSessionModel = require("../../models/coachSession");
const userModel = require("../../models/user");
const CoachModel = require("../../models/coach");
const coachPayoutModal = require("../../models/coachPayout");
const coachPayoutModel = require("../../models/coachPayout");
//coach order list
exports.orderList = async (req, res) => {
  try {
    const [
      orderCount,
      sessionCount,
      orderCountCompleted,
      userCount,
      coachCount,
      payoutAmount,
      revenue,
      totalAddedSessions,
    ] = await Promise.all([
      sessionBookingModal.countDocuments(),
      sessionBookingModal.countDocuments({ sessionStatus: 1 }),
      sessionBookingModal.countDocuments({ sessionStatus: 1 }),
      userModel.countDocuments({ delete: 0 }),
      CoachModel.countDocuments({ delete: 0 }),
      coachPayoutModal.aggregate([
        { $group: { _id: null, totalAmount: { $sum: "$amount" } } },
        {
          $project: {
            totalAmount: {
              $ifNull: ["$totalAmount", 0],
            },
          },
        },
      ]),
      sessionBookingModal.aggregate([
        {
          $match: {
            sessionStatus: 1, // Match sessionStatus equal to 1
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "bookingId",
            foreignField: "_id",
            as: "bookingDetails",
          },
        },
        {
          $unwind: "$bookingDetails",
        },
        {
          $match: {
            "bookingDetails.paid": 1,
          },
        },
        {
          $group: {
            _id: null, // Group everything together
            totalRevenue: { $sum: "$amount" }, // Calculate the sum of the amount field
          },
        },
        {
          $project: {
            totalRevenue: { $ifNull: ["$totalRevenue", 0] }, // Handle cases where totalRevenue is null
          },
        },
      ]),
      coachSessionModel.countDocuments(),
    ]);
    // Calculate total revenue (80% of total revenue from bookings)
    const totalRevenue1 =
      revenue.length > 0 ? Number(revenue[0]?.totalRevenue) * 0.6 : 0;
    // Calculate payout amount (convert to correct scale if needed, e.g., divide by 100)
    const payoutAmount1 =
      payoutAmount.length > 0 ? Number(payoutAmount[0]?.totalAmount) / 100 : 0;
    // Calculate total balance (remaining revenue after payouts)
    const totalBalance1 = totalRevenue1 - payoutAmount1;
    // Calculate total due payouts (total revenue - payout amount)
    const totalDuePayouts = totalRevenue1 - payoutAmount1;
    // Calculate total commission (20% of total revenue from bookings)
    const totalCommission =
      revenue.length > 0 ? Number(revenue[0]?.totalRevenue) * 0.4 : 0;

    const responce = {
      success: true,
      countData: {
        totalBalance: totalBalance1,
        totalRevenue: Number(revenue[0]?.totalRevenue),
        payoutAmount: payoutAmount1,
        totalDuePayouts,
        totalCommission,
        orderCount,
        sessionCount,
        orderCountCompleted,
        userCount,
        coachCount,
        totalAddedSessions,
      },
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
//coach Completed  order list
exports.completedOrdersList = async (req, res) => {
  try {
    const orderList = await sessionBookingModal.aggregate([
      {
        $match: {
          sessionStatus: 1,
        },
      },
      { $sort: { updatedAt: -1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          sessionDateUpdated: 1,
          coachId: 1,
          bookingId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          sessionCompletedDate: 1,
          userName: "$userData.name",
          userPhoto: "$userData.image",
          coachName: "$coachData.name",
          coachLName: "$coachData.Lname",
          coachUserName: "$coachData.userName",
          coachPhoto: "$coachData.image",
          title: "$sessionData.title",
          type: "$sessionData.type",
          price: "$sessionData.price",
          description: "$sessionData.description",
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderList,
      message: "Coach orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach last  order
exports.lastOrders = async (req, res) => {
  try {
    const orderList = await sessionBookingModal.aggregate([
      { $sort: { createdAt: -1 } },
      { $limit: 1 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          bookingDate: 1,
          bookingTime: 1,
          coachId: 1,
          createdAt: 1,
          sessionId: 1,
          updatedAt: 1,
          userId: 1,
          orderStatus: 1,
          completedDateTime: 1,
          userAvatar: "$userData.name",
          userAvatar: "$userData.image",
          title: "$sessionData.title",
          type: "$sessionData.type",
          price: "$sessionData.price",
          description: "$sessionData.description",
        },
      },
    ]);

    const responce = {
      success: true,
      data: orderList,
      message: "Coach orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//upcoming sessions
exports.upcomingSessions = async (req, res) => {
  try {
    const sessionBookingData = await sessionBookingModal.aggregate([
      {
        $match: {
          status: 0,
        },
      },
      { $sort: { bookingDateTime: 1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },

      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      { $unwind: "$sessionData" },
      {
        $project: {
          _id: 1,
          bookingDate: 1,
          bookingTime: 1,
          userData_id: "$userData._id",
          userDataName: "$userData.name",
          userAvatar: "$userData.image",
          session_id: "$sessionData._id",
          title: "$sessionData.title",
          description: "$sessionData.description",
          sessionPrice: "$sessionData.price",
          createdAt: 1,
        },
      },
    ]);

    const responce = {
      success: true,
      data: sessionBookingData,
      message: "Coach upcoming Sessions get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//payout history recent
exports.payoutHistoryRecent = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const payoutHistory = await coachPayoutModel.aggregate([
      {
        $sort: { createdAt: -1 },
      },
      {
        $lookup: {
          from: "coaches",
          let: { coachId: "$coachId" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ["$_id", "$$coachId"],
                },
              },
            },
            {
              $lookup: {
                from: "coach-payouts",
                let: { coachId: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $eq: ["$coachId", "$$coachId"],
                        $eq: ["$status", 1],
                      },
                    },
                  },
                  {
                    $group: {
                      _id: "$coachId",
                      totalAmount: { $sum: "$amount" },
                    },
                  },
                ],
                as: "coachPayouts",
              },
            },
          ],
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "completedorders",
          localField: "coachId",
          foreignField: "coachId",
          as: "completedOrdersData",
        },
      },
      {
        $addFields: {
          totalAmount: {
            $sum: "$completedOrdersData.amount",
          },
        },
      },
      {
        $project: {
          _id: 1,
          coachId: 1,
          createdAt: 1,
          approveDate: 1,
          status: 1,
          amount: 1,
          totalAmount: 1,
          totalPayout: {
            $ifNull: [
              { $arrayElemAt: ["$coachData.coachPayouts.totalAmount", 0] },
              0,
            ],
          },
          coachData: {
            coachId: "$coachData._id",
            name: "$coachData.name",
            userName: "$coachData.userName",
            Lname: "$coachData.Lname",
            email: "$coachData.email",
            image: "$coachData.image",
          },
        },
      },
    ]);

    const responce = {
      success: true,
      payoutHistory,
      message: "Data retrieved successfully",
    };

    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//payout history recent
exports.registrationState = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const currentYear = new Date().getFullYear();
    let userArray = Array(12).fill(0);
    let coachArray = Array(12).fill(0);
    const [userData, coachData] = await Promise.all([
      userModel.aggregate([
        {
          $match: {
            createdAt: {
              $gte: new Date(`${currentYear}-01-01T00:00:00.000Z`),
              $lte: new Date(`${currentYear}-12-31T23:59:59.999Z`),
            },
          },
        },
        {
          $group: {
            _id: { $month: "$createdAt" },
            count: { $sum: 1 },
          },
        },
        {
          $sort: { _id: 1 },
        },
      ]),
      CoachModel.aggregate([
        {
          $match: {
            createdAt: {
              $gte: new Date(`${currentYear}-01-01T00:00:00.000Z`),
              $lte: new Date(`${currentYear}-12-31T23:59:59.999Z`),
            },
          },
        },
        {
          $group: {
            _id: { $month: "$createdAt" },
            count: { $sum: 1 },
          },
        },
        {
          $sort: { _id: 1 },
        },
      ]),
    ]);

    userData.forEach((data) => {
      const monthIndex = data._id - 1;
      userArray[monthIndex] = data.count;
    });
    coachData.forEach((data) => {
      const monthIndex = data._id - 1;
      coachArray[monthIndex] = data.count;
    });

    const currentMonth = new Date().getMonth();
    userArray = userArray.slice(0, currentMonth + 1);
    coachArray = coachArray.slice(0, currentMonth + 1);

    const responce = {
      success: true,
      userArray,
      coachArray,
      message: "Data retrieved successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.bookingStats = async (req, res) => {
  try {
    const stats = await sessionBookingModal.aggregate([
      {
        $lookup: {
          from: "bookings",
          localField: "bookingId",
          foreignField: "_id",
          as: "bookingDetails",
        },
      },
      {
        $unwind: "$bookingDetails",
      },
      {
        $match: {
          "bookingDetails.paid": 1,
        },
      },
      {
        $group: {
          _id: "$sessionStatus",
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          sessionStatus: "$_id",
          count: 1,
        },
      },
    ]);
    let totalBookings = 0;
    let completedBookings = 0;
    let pendingBookings = 0;
    let canceledBookings = 0;
    stats.forEach((stat) => {
      totalBookings += stat.count;
      if (stat.sessionStatus === 0) pendingBookings = stat.count;
      else if (stat.sessionStatus === 1) completedBookings = stat.count;
      else if (stat.sessionStatus === 2) canceledBookings = stat.count;
    });
    const response = {
      success: true,
      status: 200,
      stats,
      message: "Booking stats fetched successfully",
      data: {
        totalBookings,
        completedBookings,
        pendingBookings,
        canceledBookings,
      },
    };
    // console.log({
    //   totalBookings,
    //   completedBookings,
    //   pendingBookings,
    //   canceledBookings,
    // });
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
