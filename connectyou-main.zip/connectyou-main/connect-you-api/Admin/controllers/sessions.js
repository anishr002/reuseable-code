const defaultCoachSessionModel = require("../../models/defaultCoachSession");

exports.listAllSessions = async (req, res) => {
  try {
    const sessions = await defaultCoachSessionModel.find({ deleted: 0 });
    return res.status(200).json({
      success: true,
      data: sessions,
      total: sessions.length,
      message: "Defualt Sessions fetched successfully",
    });
  } catch (error) {
    console.error("Error listing sessions:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch sessions",
      error: error.message,
    });
  }
};

exports.addSession = async (req, res) => {
  try {
    
    const {
      type,
      title,
      price,
      description,
      duration,
      status,
      currency,
      stripePriceId,
      stripeProductId,
    } = req.body;

    if (!title || !price || !description) {
      return res.status(400).json({
        success: false,
        message: "Title, price, and description are required.",
      });
    }
    const newSession = new defaultCoachSessionModel({
      type,
      title,
      price,
      description,
      duration,
      status,
      currency, 
      stripePriceId,
      stripeProductId,
    });
    const savedSession = await newSession.save();
    return res.status(201).json({
      success: true,
      data: savedSession,
      message: "Session created successfully",
    });
  } catch (error) {
    console.error("Error adding session:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to create session",
      error: error.message,
    });
  }
};
