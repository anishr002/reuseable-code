const puppeteer = require("puppeteer");
const moment = require("moment-timezone");
const { validationResult } = require("express-validator");
const mongoose = require("mongoose");
const Stripe = require("stripe");
const path = require("path");
require("dotenv").config();

//environment variables
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const CoachModel = require("../../models/coach");
const completedOrderModal = require("../../models/completedOrders");
const coachPayoutModel = require("../../models/coachPayout");
const orderRatingModal = require("../../models/orderRating");
const chatRoomModel = require("../../models/Chatroom");
const chatMessageModel = require("../../models/chatMessage");
const { CreateNotification } = require("../../models/notificationModal");
const resourceModel = require("../../models/resources");
const coachResourceSectionModale = require("../../models/coachResourceSection");
const {
  getApproalReqs,
  acceptApprovalReqeust,
  rejectApprovalRequest,
  approvvalReqHistory,
} = require("../../models/coachProfileApproval");

// email
const transportEmail = require("../../lib/email");
const {
  updateAgreementClause,
  getAgreement,
} = require("../../models/coach_agreement_clause");

const {
  getAgreementList,
  approveCoachAgreement,
  rejectCoachAgreement,
  revokeCoachAgreement,
} = require("../../models/coach_agreement");
const { sendAccountBlockedMail } = require("../../utils/quickEmails");
const ShortlistsModel = require("../../models/ShortlistedCoaches");

//Coach list
exports.coachList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let pageNo = req.query.pageNo || 1;
    let filter = req.query.filter;
    let searchTerm = req.query.searchTerm;
    filter = Number(filter);
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    let filterOption = {
      delete: 0,
    };
    if (filter == 1 || filter == 0) {
      filterOption.approve = filter;
    }
    if (searchTerm && searchTerm.trim() !== "") {
      const escapedSearchTerm = searchTerm
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filterOption.$or = [
        { email: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { name: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { Lname: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { gender: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
      ];
    }
    const coachList = await CoachModel.aggregate([
      {
        $match: filterOption,
      },
      { $sort: { updatedAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);

    let totalPages = 1;
    if (coachList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(coachList[0].pageInfo[0].count / limit);
    }
    const coachListData = coachList[0].data;
    const response = {
      success: true,
      coachList: coachListData,
      totalPages,
      currentPage: pageNo,
      message: "coach list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach details
exports.coachDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param

    const coachData = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(coachId),
          delete: 0,
        },
      },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachexperiences",
          localField: "_id",
          foreignField: "coachId",
          as: "coachexperiences",
        },
      },
      {
        $lookup: {
          from: "coacheducations",
          localField: "_id",
          foreignField: "coachId",
          as: "coacheducations",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);
    if (coachData.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    if (coachData.length > 0) {
      let data = {
        _id: coachData[0]._id,
        name: coachData[0].name,
        Lname: coachData[0].Lname,
        email: coachData[0].email,
        gender: coachData[0].gender,
        DOB: coachData[0].DOB,
        approve: coachData[0].approve,
        image: coachData[0].image,
        createdAt: coachData[0].createdAt,
        freeTrial: coachData[0].freeTrial,
        about_me: coachData[0].about_me,
        title_line: coachData[0].title_line,
        languages: coachData[0].languages,
        fullAddress: coachData[0].fullAddress,
        zoomMeetingURL: coachData[0].zoomMeetingURL,
        coachingSpecialities: coachData[0].coachingSpecialities,
        coachcredentials: coachData[0].coachcredentials,
        coachexperiences: coachData[0].coachexperiences,
        coacheducations: coachData[0].coacheducations,
        coachcertificates: coachData[0].coachcertificates,
        zoomId: coachData[0].zoomId,
        zoomAccStatus: coachData[0].zoomAccStatus,
        calendarStatus: coachData[0].calendarStatus,
        updateStatus: coachData[0].updateStatus,
        block: coachData[0].block,
        emailVerified: coachData[0].emailVerified,
        averageRating: coachData[0].averageRating,
        totalRatings: coachData[0].totalRatings,
        refered_by_partner: coachData[0].refered_by_partner,
        nonProfitCoaching: coachData[0].nonProfitCoaching,
        refering_partner: coachData[0].refering_partner,
      };
      const response = {
        success: true,
        data,
        message: "Coach data get successfully",
      };
      return res.status(200).json(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach block
exports.coachBlock = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    const coachDetails = await CoachModel.find({ _id: coachId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    const blockStatus = coachDetails[0].block == 0 ? 1 : 0;
    const coachUpdatedDetails = await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { block: blockStatus },
      { new: true }
    );
    const blockStatusText =
      coachDetails[0].block == 0 ? "blocked" : "unblocked";
    const response = {
      success: true,
      coachData: coachUpdatedDetails,
      message: `coach ${blockStatusText} successfully`,
    };
    res.status(200).json(response);
    if (blockStatusText === "blocked") {
      await sendAccountBlockedMail(
        `${coachDetails[0].name} ${coachDetails[0].Lname}`,
        coachDetails[0].email
      );
    }
    return;
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach profile approve
exports.coachProfileApprove = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    const coachDetails = await CoachModel.find({ _id: coachId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    const approveStatus = coachDetails[0].approve == 0 ? 1 : 0;
    const updateStatus = coachDetails[0].approve == 0 ? 2 : 1;
    const coachUpdatedDetails = await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { approve: approveStatus, updateStatus: updateStatus },
      { new: true }
    );
    const approveStatusText =
      coachDetails[0].approve == 0 ? "approved" : "rejected";
    if (coachDetails[0].approve == 0) {
      function capitalizeFirstLetter(str) {
        if (!str) return "";
        return str.charAt(0).toUpperCase() + str.slice(1);
      }
      const capitalizedName = capitalizeFirstLetter(coachDetails[0].name);
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: [
          "ekta@erickson.edu",
          "blossom.reactdev@gmail.com",
          coachDetails[0].email,
        ],
        subject: `Your Coach Marketplace Account is Now Active!`,
        template: "approvalCoachProfile",
        context: {
          name: capitalizedName,
          email: coachDetails[0].email,
        },
      };
      await transportEmail.createEmail({ mailOptions });
    }
    const response = {
      success: true,
      coachData: coachUpdatedDetails,
      message: `Coach profile ${approveStatusText} successfully`,
    };
    if (approveStatusText === "approved") {
      await CreateNotification({
        user_id: coachId,
        heading: "Profile has been approved Coach! Congrats",
        description:
          "Your profile has been approved by the adminstrator, your profile has been listed in teh coaches section of the portal, have a look by clicking on the view buttoon. ",
        url: `/find-a-coach/details/${coachId}`,
        notification_type: "admin",
      });
    }
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach account delete
exports.coachDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    const coachDetails = await CoachModel.find({ _id: coachId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { delete: 1 },
      { new: true }
    );
    const response = {
      success: true,
      message: `Coach account deleted successfully`,
    };

    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
//coach rating list
exports.CoachRating = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coachId = req.params.id;
    const ratingData = await orderRatingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $project: {
          _id: 1,
          message: 1,
          createdAt: 1,
          ratingNumber: 1,
          Userid: "$userData._id",
          name: "$userData.name",
          image: "$userData.image",
          gender: "$userData.gender",
        },
      },
    ]);

    const responce = {
      success: true,
      data: ratingData,
      message: "Rating get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach inbox data
exports.CoachInbox = async (req, res) => {
  try {
    const coachId = req.params.id;
    const inboxData = await chatRoomModel.aggregate([
      {
        $match: {
          $or: [
            { userId1: new mongoose.Types.ObjectId(coachId) },
            { userId2: new mongoose.Types.ObjectId(coachId) },
          ],
        },
      },
      {
        $lookup: {
          from: "chatmessages",
          let: { id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    {
                      $eq: ["$chatRoomId", "$$id"],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "users",
                let: { id: "$senderId", id2: "$receiverId" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$_id", "$$id2"] },

                              {
                                $ne: [
                                  "$_id",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$_id", "$$id"] },
                              {
                                $ne: [
                                  "$_id",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  { $project: { _id: 1, name: 1, image: 1 } },
                ],
                as: "userProfile",
              },
            },
            { $unwind: "$userProfile" },
          ],
          as: "ChatData",
        },
      },
      { $unwind: "$ChatData" },
      { $sort: { "ChatData.createdAt": -1 } },
      {
        $group: {
          _id: "$ChatData.chatRoomId",
          count: { $sum: 1 },
          ChatData: { $first: "$ChatData" },
        },
      },
      { $sort: { "ChatData.createdAt": -1 } },
    ]);

    const responce = {
      success: true,
      data: inboxData,
      message: "Coach inbox data get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach chat list
exports.CoachMessagesList = async (req, res) => {
  try {
    const chatRoomId = req.params.id;
    let messageData = await chatMessageModel.find({ chatRoomId: chatRoomId });
    const responce = {
      success: true,
      data: messageData,
      message: "Coach message data get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getprofileApprovalList = async (req, res) => {
  try {
    const pageNo = Number(req.query.pageNo) || 1;
    const limit = Number(req.query.limit) || 10;
    const skip = (pageNo - 1) * limit; // Adjusting this calculation
    const searchTerm = req.query.searchTerm;
    const pendingReqs = await getApproalReqs({ skip, limit, searchTerm });
    if (pendingReqs.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else
      return res.status(200).json({
        success: true,
        message: "Fethced Profile approval status successfully",
        data: pendingReqs.data,
        totalPages: pendingReqs.totalPages,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getprofileApprovalHistory = async (req, res) => {
  try {
    const pageNo = Number(req.query.pageNo) || 1;
    const limit = Number(req.query.limit) || 10;

    const skip = (pageNo - 1) * limit; // Adjusting this calculation
    const pendingReqs = await approvvalReqHistory({ limit, skip });

    if (pendingReqs.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else
      return res.status(200).json({
        success: true,
        message: "Fethced Profile approval status successfully",
        data: pendingReqs.data,
        totalPages: pendingReqs.totalPages,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.newCoachProfileApprove = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coach_id = req.params.coach_id;
    const coachData = await CoachModel.find({ _id: coach_id });
    const req_id = req.params.req_id;
    const action = await acceptApprovalReqeust({ coach_id, req_id });

    if (action.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else {
      function capitalizeFirstLetter(str) {
        if (!str) return "";
        return str.charAt(0).toUpperCase() + str.slice(1);
      }
      const capitalizedName = capitalizeFirstLetter(coachData[0].name);
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: [
          // "ekta@erickson.edu",
          "blossom.reactdev@gmail.com",
          coachData[0].email,
        ],
        subject: `Your Coach Marketplace Account is Now Active!`,
        template: "approvalCoachProfile",
        context: {
          coachName: capitalizedName,
        },
      };
      Promise.allSettled([
        CreateNotification({
          user_id: coach_id,
          heading: "Profile has been approved Coach! Congrats",
          description:
            "Your profile has been approved by the adminstrator, your profile has been listed in teh coaches section of the portal, have a look by clicking on the view buttoon. ",
          url: `/coach/detail/${coach_id}`,
          notification_type: "admin",
        }),
        transportEmail.createEmail({ mailOptions }),
      ]);
      return res.status(200).json({
        success: true,
        message: "Coach profile has been approved",
        data: action,
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.newCoachProfileDecline = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coach_id = req.params.coach_id;
    const req_id = req.params.req_id;
    const note = req.body.note;
    const action = await rejectApprovalRequest({ coach_id, req_id, note });
    // console.log(coach_id, req_id);
    if (action.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else
      return res.status(200).json({
        success: true,
        message: "Coach Profile approval has been declined.",
        data: action,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.ListCoachesAll = async (req, res) => {
  try {
    const matchPipe = {};
    const coachList = await CoachModel.find(matchPipe).select(
      "_id name Lname email image"
    );
    if (coachList) {
      return res.status(200).json({
        success: true,
        message: "Fethced coach List successfully",
        data: coachList,
      });
    } else
      return res.status(500).json({
        success: false,
        message: "Unexpected Error while fetching coaches",
      });
  } catch (error) {
    console.error({ error });
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.add_coach_agreement = async (req, res) => {
  try {
    const agreement = req.file;
    if (!agreement || agreement.mimetype !== "application/pdf") {
      return res.status(400).json({
        success: false,
        message:
          agreement.mimetype !== "application/pdf"
            ? "Only pdf are accepted"
            : "Please add the agreement file",
      });
    }
    const added_agreement = await updateAgreementClause({
      file: agreement?.filename,
    });
    return res.status(added_agreement.status).json({
      success: added_agreement.success,
      message: added_agreement.message,
      status: added_agreement.status,
      data: added_agreement.data,
      error: added_agreement.error,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.get_coach_agreement = async (req, res) => {
  try {
    const added_agreement = await getAgreement();
    return res.status(added_agreement.status).json({
      success: added_agreement.success,
      message: added_agreement.message,
      status: added_agreement.status,
      data: added_agreement.data,
      error: added_agreement.error,
    });
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.get_coach_agreement_lists = async (req, res) => {
  try {
    const { pageNo, limit, filter, searchTerm } = req.query;
    const added_agreement = await getAgreementList({
      limit: !isNaN(Number(limit)) ? Number(limit) : 10,
      pageNo: !isNaN(Number(pageNo)) ? Number(pageNo) : 1,
      searchTerm,
      filter: !isNaN(Number(filter)) ? Number(filter) : 3,
    });

    return res.status(added_agreement.status).json({
      success: added_agreement.success,
      message: added_agreement.message,
      status: added_agreement.status,
      data: added_agreement.data,
      totalPages: added_agreement.totalPages,
      error: added_agreement.error,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.approve = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { _id, coachId } = req.params;
    const modified = await approveCoachAgreement({ _id, coachId });
    if (modified) {
      return res.status(200).json({
        ...modified,
      });
    } else throw new Error("Error ocurred while performing the task");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.decline = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { _id, coachId } = req.params;
    const remarks = req.body.remarks;
    const modified = await rejectCoachAgreement({ _id, coachId, remarks });
    if (modified) {
      return res.status(200).json({
        ...modified,
      });
    } else throw new Error("Error ocurred while performing the task");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.revoke = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { _id, coachId } = req.params;
    const remarks = req.body.remarks;
    const modified = await revokeCoachAgreement({ _id, coachId, remarks });
    if (modified) {
      return res.status(200).json({
        ...modified,
      });
    } else throw new Error("Error ocurred while performing the task");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

/// added 05-14-2025 ,, shortlisted for compnay
exports.coachListShortlisted = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let pageNo = req.query.pageNo || 1;
    let filter = req.query.filter;
    let searchTerm = req.query.searchTerm;
    filter = Number(filter);
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    let filterOption = {
      delete: 0,
    };

    if (searchTerm && searchTerm.trim() !== "") {
      const escapedSearchTerm = searchTerm
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filterOption.$or = [
        { email: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { name: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { Lname: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { gender: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
      ];
    }
    const coachList = await CoachModel.aggregate([
      {
        $match: filterOption,
      },
      {
        $lookup: {
          from: "shortlists",
          localField: "_id",
          foreignField: "coachId",
          as: "shortlisted",
        },
      },
      {
        $unwind: {
          path: "$shortlisted",
          preserveNullAndEmptyArrays: false, // exclude if no shortlist exists
        },
      },
      {
        $match: {
          "shortlisted.status": true, // only those explicitly shortlisted
        },
      },
      { $sort: { updatedAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);

    let totalPages = 1;
    if (coachList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(coachList[0].pageInfo[0].count / limit);
    }
    const coachListData = coachList[0].data;
    const response = {
      success: true,
      coachList: coachListData,
      totalPages,
      currentPage: pageNo,
      message: "coach list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.shortlistForCompany = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: errors.array()[0].msg,
    });
  }

  try {
    const { coachId } = req.params;
    const id = new mongoose.Types.ObjectId(coachId);
    const coachData = await CoachModel.findOne({ _id: id }).select("_id email");
    if (!coachData) {
      return res.status(404).json({
        success: false,
        message: "Coach not found",
      });
    }

    const result = await ShortlistsModel.updateOne(
      { coachId: coachData._id },
      {
        $set: {
          coachId: coachData._id,
          email: coachData.email,
          status: true, // assuming you're setting it to shortlisted
          companyName: "ConnectYou",
        },
      },
      { upsert: true }
    );

    if (result.modifiedCount > 0 || result.upsertedCount > 0) {
      return res.status(200).json({
        success: true,
        message: "Coach has been shortlisted for company!",
      });
    } else {
      return res.status(200).json({
        success: true,
        message: "Coach was already shortlisted.",
      });
    }
  } catch (err) {
    console.error("Shortlist error:", err);
    return res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

exports.Unlist = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { coachId } = req.params;
    const id = new mongoose.Types.ObjectId(coachId);
    const result = ShortlistsModel.deshortlist(id);
    if (result) {
      const response = {
        success: true,
        message: "Coach has been unlisted from shortlisted coaches",
      };
      return res.status(200).json(response);
    } else {
      return res
        .status(400)
        .json({ success: false, message: "Something went wrong" });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.shortlistStatus = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: paramError.errors[0].msg,
    });
  }

  try {
    const { coachId } = req.params;
    const id = new mongoose.Types.ObjectId(coachId);
    const result = await ShortlistsModel.findOne({ coachId: id });

    const response = {
      success: true,
      message: "Coach shortlist status fetched successfully",
      data: null,
      shortlistStatus: "New",
    };
    if (result) {
      response.data = result;
      response.shortlistStatus = result.status ? "Shortlisted" : "Unlisted";
    }
    return res.status(200).json(response);
  } catch (err) {
    console.error("Error checking shortlist status:", err);
    return res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

const XLSX = require("xlsx");
const RejectedCoachPayoutModel = require("../../models/rejectedCoachPayout");
const { getConversionRates } = require("../../lib/conversionRate");
const { minimumPayoutAmounts } = require("../../lib/stripe");

exports.exportShortlistedCoaches = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: paramError.errors[0].msg,
    });
  }

  const skip = parseInt(req.query.skip || "0");
  const limit = parseInt(req.query.limit || "1000");

  try {
    const pipeline = [
      {
        $lookup: {
          from: "shortlists",
          localField: "_id",
          foreignField: "coachId",
          as: "shortlisted",
        },
      },
      {
        $unwind: {
          path: "$shortlisted",
          preserveNullAndEmptyArrays: false,
        },
      },
      {
        $match: {
          "shortlisted.status": true,
        },
      },
      { $sort: { updatedAt: -1 } },
      {
        $project: {
          name: 1,
          Lname: 1,
          userName: 1,
          email: 1,
          gender: 1,
          DOB: 1,
          about_me: 1,
          title_line: 1,
          zoomMeetingURL: 1,
          linkedin_profile_link: 1,
          languages: 1,
          industries: 1,
          coachingSpecialities: 1,
          experienceYear: 1,
          timeZone: 1,
          nonProfitCoaching: 1,
          city: 1,
          fullAddress: 1,
          country: 1,
          countryCode: 1,
          phoneCode: 1,
        },
      },
      {
        $facet: {
          data: [{ $skip: skip }, { $limit: limit + 1 }], // fetch 1 extra for "hasMore"
        },
      },
    ];

    const result = await CoachModel.aggregate(pipeline);
    const data = result[0]?.data || [];

    const hasMore = data.length > limit;
    const slicedData = hasMore ? data.slice(0, limit) : data;

    const jsonData = slicedData.map((doc) => ({
      FirstName: doc.name,
      LastName: doc.Lname,
      Username: doc.userName,
      Email: doc.email,
      Gender: doc.gender,
      DOB: doc.DOB,
      About: doc.about_me,
      Title: doc.title_line,
      ZoomURL: doc.zoomMeetingURL,
      LinkedIn: doc.linkedin_profile_link,
      Languages: doc.languages?.join(", "),
      Industries: doc.industries?.join(", "),
      Specialities: doc.coachingSpecialities?.join(", "),
      Experience: doc.experienceYear,
      TimeZone: doc.timeZone,
      NonProfit: doc.nonProfitCoaching ? "Yes" : "No",
      City: doc.city,
      FullAddress: doc.fullAddress,
      Country: doc.country,
      CountryCode: doc.countryCode,
      PhoneCode: doc.phoneCode,
    }));

    // Generate Excel
    const worksheet = XLSX.utils.json_to_sheet(jsonData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "ShortlistedCoaches");
    const xlsxBuffer = XLSX.write(workbook, {
      type: "buffer",
      bookType: "xlsx",
    });
    const xlsxBase64 = xlsxBuffer.toString("base64");

    // Generate CSV
    const csv = XLSX.utils.sheet_to_csv(worksheet);

    return res.status(200).json({
      success: true,
      count: jsonData.length,
      hasMore,
      data: jsonData,
      files: {
        xlsx: `data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,${xlsxBase64}`,
        csv: `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`,
      },
    });
  } catch (err) {
    console.error("Error exporting shortlisted coaches:", err);
    return res.status(500).json({
      success: false,
      message: "Server error during export",
    });
  }
};

function adjustAmountToBalance(amount, availableBalance) {
  return Math.min(amount, availableBalance);
}

/**
 * Rounds amount down to the nearest 10 units
 * @param {number} amount - Amount in cents/smallest currency unit
 * @returns {number} - Rounded-down amount (e.g., 852 → 850)
 */
function roundDownToNearest10(amount) {
  return Math.floor(Number(amount) / 10) * 10;
}
