const { validationResult } = require("express-validator");
const {
  listTermCon,
  addUpdateTermCon,
} = require("../../models/termAndConditions");
const {
  listPrivacyPol,
  addUpdatePrivacyPol,
} = require("../../models/privacyPolicy");
const {
  listCookiePolicies,
  addUpdateCookiePolicies,
} = require("../../models/cookiePolicies");

const handleValidations = (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
};

const handleError = ({
  req,
  res,
  error,
  message = "There was some unexpected Internal server error",
  status = 500,
}) => {
  console.log(error);
  return res.status(status).json({ success: false, message, data: null });
};

exports.listAllTerms = async (req, res) => {
  try {
    const getList = await listTermCon();
    if (getList.success) {
      return res.status(200).json({
        success: true,
        message: "Terms and conditions listed successfully",
        data: getList.data,
      });
    } else
      handleError({
        req,
        res,
        error,
        status: 500,
        message: "Some Error Occured while Fetching Terms and conditions List.",
      });
  } catch (error) {
    return handleError({ req, res, error });
  }
};

exports.updateExTermAndCondition = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { text } = req.body;
    const updateTerm = await addUpdateTermCon(text);
    if (updateTerm.success) {
      return res.status(200).json({
        success: true,
        message: "Updated a clause in T&Cs.",
        data: updateTerm.data,
      });
    } else
      return handleError({
        req,
        res,
        error,
        message: "There was some error",
        status: 500,
      });
  } catch (error) {
    return handleError({ req, res, error });
  }
};

// privacyPolicy

exports.listAllPolicies = async (req, res) => {
  try {
    const getList = await listPrivacyPol();
    if (getList.success) {
      return res.status(200).json({
        success: true,
        message: "Privacy Policy listed successfully",
        data: getList.data,
      });
    } else
      handleError({
        req,
        res,
        error,
        status: 500,
        message: "Some Error Occured while Fetching Terms and conditions List.",
      });
  } catch (error) {
    return handleError({ req, res, error });
  }
};

exports.updateExPrivacyPol = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { text } = req.body;
    const updateTerm = await addUpdatePrivacyPol(text);
    if (updateTerm.success) {
      return res.status(200).json({
        success: true,
        message: "Updated a clause in T&Cs.",
        data: updateTerm.data,
      });
    } else
      return handleError({
        req,
        res,
        error,
        message: "There was some error",
        status: 500,
      });
  } catch (error) {
    return handleError({ req, res, error });
  }
};

// cookie policies
exports.listCookiePolicies = async (req, res) => {
  try {
    const getList = await listCookiePolicies();
    if (getList.success) {
      return res.status(200).json({
        success: true,
        message: "Cookie Policy listed successfully",
        data: getList.data,
      });
    } else
      handleError({
        req,
        res,
        error,
        status: 500,
        message: "Some Error Occured while Fetching Terms and conditions List.",
      });
  } catch (error) {
    return handleError({ req, res, error });
  }
};

exports.addUpdateCookiePolicies = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { text } = req.body;
    const updateTerm = await addUpdateCookiePolicies(text);
    if (updateTerm.success) {
      return res.status(200).json({
        success: true,
        message: "add/update cookie policies",
        data: updateTerm.data,
      });
    } else
      return handleError({
        req,
        res,
        error,
        message: "There was some error",
        status: 500,
      });
  } catch (error) {
    return handleError({ req, res, error });
  }
};
