const { validationResult } = require("express-validator");
require("dotenv").config();
const mongoose = require("mongoose");
//environment variables
//import the modals

const bookingModal = require("../../models/booking");
const CoachModel = require("../../models/coach");
const userModel = require("../../models/user");

//booking history
exports.bookingHistory = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const searchTerm = req.query.searchTerm
      ? req.query.searchTerm !== ""
        ? req.query.searchTerm
        : null
      : null;
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$bookingId", "$$bookingId"] }],
                },
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      {
        $addFields: {
          totalBookedAmount: {
            $sum: "$booked_sessionsData.amount",
          },
        },
      },
      ...(searchTerm
        ? [
            {
              $match: {
                $or: [
                  { "userData.name": { $regex: searchTerm, $options: "i" } },
                  { "coachData.name": { $regex: searchTerm, $options: "i" } },
                  { "coachData.Lname": { $regex: searchTerm, $options: "i" } },
                ],
              },
            },
          ]
        : []),
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          coachData: {
            $map: {
              input: "$coachData",
              as: "coach",
              in: {
                _id: "$$coach._id",
                name: "$$coach.name",
                Lname: "$$coach.Lname",
                userName: "$$coach.userName",
                gender: "$$coach.gender",
                email: "$$coach.email",
                image: "$$coach.image",
                timeZone: "$$coach.timeZone",
              },
            },
          },
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
            timeZone: "$userData.timeZone",
          },
          bookedSessionsCount: { $size: "$booked_sessionsData" },
          totalBookedAmount: 1,
          upcomingCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 0] },
              },
            },
          },
          completedCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 1] },
              },
            },
          },
          canceledCount: {
            $size: {
              $filter: {
                input: "$booked_sessionsData",
                as: "session",
                cond: { $eq: ["$$session.sessionStatus", 2] },
              },
            },
          },
        },
      },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);

    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      totalPages,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//booking history details
exports.bookingHistoryDetails = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let bookingId = req.params.id; //coach id form the param
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(bookingId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "bookingId",
          as: "ratingsData",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          pipeline: [
            {
              $lookup: {
                from: "coaches",
                localField: "coachId",
                foreignField: "_id",
                as: "coachData",
              },
            },
            { $unwind: "$coachData" },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
            {
              $group: {
                _id: "$coachData._id", // Group by coach's ID
                coachData: { $first: "$coachData" },
                sessions: {
                  $push: {
                    _id: "$_id",
                    sessionDate: "$sessionDate",
                    sessionDateUpdated: "$sessionDateUpdated",
                    sessionStatus: "$sessionStatus",
                    sessionAmount: "$amount",
                    sessionCancelBy: "$sessionCancelBy",
                    messageCancel: "$messageCancel",
                    sessionCompletedUser: "$sessionCompletedUser",
                    sessionCompletedCoach: "$sessionCompletedCoach",
                    completedCoachMSG: "$completedCoachMSG",
                    completedUserMSG: "$completedUserMSG",
                    sessionData: {
                      _id: "$sessionData._id",
                      coachId: "$sessionData.coachId",
                      title: "$sessionData.title",
                      price: "$sessionData.price",
                      type: "$sessionData.type",
                      description: "$sessionData.description",
                    },
                  },
                },
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          ratingsData: 1,
          receipt: 1,
          userData: {
            _id: "$userData._id",
            name: "$userData.name",
            image: "$userData.image",
            gender: "$userData.gender",
            timeZone: "$userData.timeZone",
          },
          customer: {
            customer_city: "$customer_city",
            customer_country: "$customer_country",
            customer_email: "$customer_email",
            customer_line1: "$customer_line1",
            customer_line2: "$customer_line2",
            customer_name: "$customer_name",
            customer_phone: "$customer_phone",
            customer_postal_code: "$customer_postal_code",
            customer_state: "$customer_state",
          },
          cardDetails: {
            amount: "$amount",
            cardBrand: "$cardBrand",
            cardCountry: "$cardCountry",
            card_exp_month: "$card_exp_month",
            card_exp_year: "$card_exp_year",
            card_last4: "$card_last4",
            currency: "$currency",
          },
          booked_sessionsData: {
            $map: {
              input: "$booked_sessionsData",
              as: "session",
              in: {
                coachData: {
                  _id: "$$session.coachData._id",
                  name: "$$session.coachData.name",
                  Lname: "$$session.coachData.Lname",
                  image: "$$session.coachData.image",
                  gender: "$$session.coachData.gender",
                  title_line: "$$session.coachData.title_line",
                  zoomMeetingURL: "$$session.coachData.zoomMeetingURL",
                  timeZone: "$$session.coachData.timeZone",
                },
                sessions: "$$session.sessions",
                sessionCompleted: {
                  $cond: {
                    if: {
                      $and: [
                        // Ensure there are no sessions with sessionStatus == 0
                        {
                          $eq: [
                            {
                              $size: {
                                $filter: {
                                  input: "$$session.sessions",
                                  as: "s",
                                  cond: { $eq: ["$$s.sessionStatus", 0] },
                                },
                              },
                            },
                            0,
                          ],
                        },
                        // Ensure at least one session has sessionStatus == 1
                        {
                          $gt: [
                            {
                              $size: {
                                $filter: {
                                  input: "$$session.sessions",
                                  as: "s",
                                  cond: { $eq: ["$$s.sessionStatus", 1] },
                                },
                              },
                            },
                            0,
                          ],
                        },
                      ],
                    },
                    then: true,
                    else: false,
                  },
                },
              },
            },
          },
        },
      },
    ]);
    const responce = {
      success: true,
      data: orderData[0],
      message: "Orders details get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//booking history details
exports.bookingHistorySessionDetails = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let bookingId = req.params.id; //coach id form the param
    const bookedSessionId = req.params.bookedSessionId;
    const orderData = await bookingModal.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(bookingId),
          paid: 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "booked_sessions",
          let: { bookingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$bookingId", "$$bookingId"] },
                    {
                      $eq: [
                        "$_id",
                        new mongoose.Types.ObjectId(bookedSessionId),
                      ],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "coaches",
                localField: "coachId",
                foreignField: "_id",
                as: "coachData",
              },
            },
            { $unwind: "$coachData" },
            {
              $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "userData",
              },
            },
            { $unwind: "$userData" },

            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
            {
              $lookup: {
                from: "rescheduled_sessions",
                localField: "_id",
                foreignField: "bookedSessionId",
                as: "rescheduled_sessionsData",
              },
            },
          ],
          as: "booked_sessionsData",
        },
      },
      { $unwind: "$booked_sessionsData" },
      {
        $project: {
          _id: 1,
          // payment_intent: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          booked_sessionsData: {
            _id: "$booked_sessionsData._id",
            sessionDate: "$booked_sessionsData.sessionDate",
            sessionDateUpdated: "$booked_sessionsData.sessionDateUpdated",
            sessionStatus: "$booked_sessionsData.sessionStatus",
            sessionAmount: "$booked_sessionsData.amount",
            sessionCancelBy: "$booked_sessionsData.sessionCancelBy",
            messageCancel: "$booked_sessionsData.messageCancel",
            sessionCompletedUser: "$booked_sessionsData.sessionCompletedUser",
            sessionCompletedCoach: "$booked_sessionsData.sessionCompletedCoach",
            completedCoachMSG: "$booked_sessionsData.completedCoachMSG",
            completedUserMSG: "$booked_sessionsData.completedUserMSG",
            sessionData: {
              _id: "$booked_sessionsData.sessionData._id",
              coachId: "$booked_sessionsData.sessionData.coachId",
              title: "$booked_sessionsData.sessionData.title",
              price: "$booked_sessionsData.sessionData.price",
              type: "$booked_sessionsData.sessionData.type",
              description: "$booked_sessionsData.sessionData.description",
            },
            coachData: {
              _id: "$booked_sessionsData.coachData._id",
              name: "$booked_sessionsData.coachData.name",
              Lname: "$booked_sessionsData.coachData.Lname",
              image: "$booked_sessionsData.coachData.image",
              gender: "$booked_sessionsData.coachData.gender",
              title_line: "$booked_sessionsData.coachData.title_line",
              zoomMeetingURL: "$booked_sessionsData.coachData.zoomMeetingURL",
              timeZone: "$booked_sessionsData.coachData.timeZone",
            },
            userData: {
              _id: "$booked_sessionsData.userData._id",
              name: "$booked_sessionsData.userData.name",
              image: "$booked_sessionsData.userData.image",
              gender: "$booked_sessionsData.userData.gender",
            },
            rescheduled_sessionsData:
              "$booked_sessionsData.rescheduled_sessionsData",
          },
        },
      },
    ]);
    const responce = {
      success: true,
      data: orderData[0],
      message: "Orders details get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//booking history coach
exports.bookingHistoryCoach = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    let [coachData, orderData] = await Promise.all([
      CoachModel.findOne({ _id: coachId }).select(
        "_id name Lname email image userName timeZone"
      ),
      bookingModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
            paid: 1,
          },
        },
        { $sort: { createdAt: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "userData",
          },
        },
        { $unwind: "$userData" },
        {
          $lookup: {
            from: "coaches",
            localField: "coachId",
            foreignField: "_id",
            as: "coachData",
          },
        },
        {
          $lookup: {
            from: "booked_sessions",
            let: { bookingId: "$_id" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [{ $eq: ["$bookingId", "$$bookingId"] }],
                  },
                },
              },
            ],
            as: "booked_sessionsData",
          },
        },
        {
          $addFields: {
            totalBookedAmount: {
              $sum: "$booked_sessionsData.amount",
            },
          },
        },

        {
          $project: {
            _id: 1,
            createdAt: 1,
            userId: 1,
            orderStatus: 1,
            coachData: {
              $map: {
                input: "$coachData",
                as: "coach",
                in: {
                  _id: "$$coach._id",
                  name: "$$coach.name",
                  Lname: "$$coach.Lname",
                  userName: "$$coach.userName",
                  gender: "$$coach.gender",
                  email: "$$coach.email",
                  image: "$$coach.image",
                  timeZone: "$$coach.timeZone",
                },
              },
            },
            userData: {
              _id: "$userData._id",
              name: "$userData.name",
              image: "$userData.image",
              gender: "$userData.gender",
              timeZone: "$userData.timeZone",
            },
            bookedSessionsCount: { $size: "$booked_sessionsData" },
            totalBookedAmount: 1,
            upcomingCount: {
              $size: {
                $filter: {
                  input: "$booked_sessionsData",
                  as: "session",
                  cond: { $eq: ["$$session.sessionStatus", 0] },
                },
              },
            },
            completedCount: {
              $size: {
                $filter: {
                  input: "$booked_sessionsData",
                  as: "session",
                  cond: { $eq: ["$$session.sessionStatus", 1] },
                },
              },
            },
            canceledCount: {
              $size: {
                $filter: {
                  input: "$booked_sessionsData",
                  as: "session",
                  cond: { $eq: ["$$session.sessionStatus", 2] },
                },
              },
            },
          },
        },
        {
          $facet: {
            pageInfo: [{ $count: "count" }],
            data: [{ $skip: skip }, { $limit: limit }],
          },
        },
      ]),
    ]);
    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      totalPages,
      coachData,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//booking history user/coachee
exports.bookingHistoryUser = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let userId = req.params.id; //coach id form the param
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    let [userData, orderData] = await Promise.all([
      userModel
        .findOne({ _id: userId })
        .select("_id name email image userName timeZone"),
      bookingModal.aggregate([
        {
          $match: {
            userId: new mongoose.Types.ObjectId(userId),
            paid: 1,
          },
        },
        { $sort: { createdAt: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "userData",
          },
        },
        { $unwind: "$userData" },
        {
          $lookup: {
            from: "coaches",
            localField: "coachId",
            foreignField: "_id",
            as: "coachData",
          },
        },
        {
          $lookup: {
            from: "booked_sessions",
            let: { bookingId: "$_id" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [{ $eq: ["$bookingId", "$$bookingId"] }],
                  },
                },
              },
            ],
            as: "booked_sessionsData",
          },
        },
        {
          $addFields: {
            totalBookedAmount: {
              $sum: "$booked_sessionsData.amount",
            },
          },
        },

        {
          $project: {
            _id: 1,
            createdAt: 1,
            userId: 1,
            orderStatus: 1,
            coachData: {
              $map: {
                input: "$coachData",
                as: "coach",
                in: {
                  _id: "$$coach._id",
                  name: "$$coach.name",
                  Lname: "$$coach.Lname",
                  userName: "$$coach.userName",
                  gender: "$$coach.gender",
                  email: "$$coach.email",
                  image: "$$coach.image",
                  timeZone: "$$coach.timeZone",
                },
              },
            },
            userData: {
              _id: "$userData._id",
              name: "$userData.name",
              image: "$userData.image",
              gender: "$userData.gender",
              timeZone: "$userData.timeZone",
            },
            bookedSessionsCount: { $size: "$booked_sessionsData" },
            totalBookedAmount: 1,
            upcomingCount: {
              $size: {
                $filter: {
                  input: "$booked_sessionsData",
                  as: "session",
                  cond: { $eq: ["$$session.sessionStatus", 0] },
                },
              },
            },
            completedCount: {
              $size: {
                $filter: {
                  input: "$booked_sessionsData",
                  as: "session",
                  cond: { $eq: ["$$session.sessionStatus", 1] },
                },
              },
            },
            canceledCount: {
              $size: {
                $filter: {
                  input: "$booked_sessionsData",
                  as: "session",
                  cond: { $eq: ["$$session.sessionStatus", 2] },
                },
              },
            },
          },
        },
        {
          $facet: {
            pageInfo: [{ $count: "count" }],
            data: [{ $skip: skip }, { $limit: limit }],
          },
        },
      ]),
    ]);

    let totalPages = 1;
    if (orderData[0].pageInfo.length > 0) {
      totalPages = Math.ceil(orderData[0].pageInfo[0].count / limit);
    }
    const orderDataListData = orderData[0].data;
    const responce = {
      success: true,
      data: orderDataListData,
      userData,
      totalPages,
      currentPage: pageNo,
      message: "User orders get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
