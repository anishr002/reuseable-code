const mongoose = require("mongoose");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
//environment variables
const JWT_SECRET = process.env.JWT_SECRET;
//import the modals
const adminModal = require("../../models/admin");
const {
  GetUsersNotification,
  CreatePasswordResetNotification,
  CreateNotification,
  ReadNotification,
  WaringLoginNotification,
  MarkAllAsRead,
} = require("../../models/notificationModal");
const APILog = require("../../models/apiLogs");

//register new coach
exports.register = async (req, res) => {
  try {
    const bcryptPassword = await bcrypt.hash("12345678", 10);
    await new adminModal({
      name: "Admin",
      email: "admin@blossom.coder.com",
      password: bcryptPassword,
    }).save();
    const responce = {
      success: true,
      message: "Admin register successfully",
      data: {
        email: "admin@blossom.coder.com",
      },
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    //Server error
    return res
      .status(500)
      .json({ success: false, message: err.message || "Server error" });
  }
};

//login user
exports.login = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { email, password } = req.body;

    const adminData = await adminModal.find({ email });
    if (adminData.length > 0) {
      const bcryptData = await bcrypt.compare(password, adminData[0].password);
      if (!bcryptData) {
        await WaringLoginNotification({ user_id: adminData[0]._id });
        return res
          .status(401)
          .json({ success: false, message: "Invalid credentials" });
      }
      let data = {
        _id: adminData[0]._id,
        name: adminData[0].name,
        email: adminData[0].email,
        address: adminData[0].address,
        createdAt: adminData[0].createdAt,
      };
      const authToken = await jwt.sign(data, JWT_SECRET);
      data.token = authToken;
      const responce = {
        success: true,
        data,
        message: "Admin login successfully",
      };
      await CreateNotification({
        user_id: adminData[0]._id,
        heading: "Account was signed in on a new device.",
        description:
          "The account was recenlty signed in on an unrecognised device, Please ignore if it was you.",
        url: "/profile",
        notification_type: "alerts",
      });
      return res.status(200).json(responce);
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Update Password
exports.updatePassword = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }

  try {
    const { oldPassword, newPassword } = req.body;
    const adminId = req.admin._id; //admin id
    const adminData = await adminModal.find({ _id: adminId });
    if (adminData.length > 0) {
      const bcryptData = await bcrypt.compare(
        oldPassword,
        adminData[0].password
      );
      if (!bcryptData) {
        return res
          .status(401)
          .json({ success: false, message: "Invalid credentials" });
      } else {
        const bcryptPassword = await bcrypt.hash(newPassword, 10);
        await adminModal.findByIdAndUpdate(
          { _id: adminData[0]._id },
          { password: bcryptPassword },
          { new: true }
        );
        const responce = {
          success: true,
          message: "Admin password updated successfully",
        };
        await CreatePasswordResetNotification({ user_id: adminData[0]._id });
        return res.status(200).json(responce);
      }
    } else {
      const responce = { success: false, message: "Invalid credentials" };
      return res.status(401).json(responce);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getAllNotifications = async (req, res) => {
  try {
    const id = req.body._id;
    const { page, limit, filter } = req.query;
    const notifications = await GetUsersNotification({
      _id: id,
      page,
      limit,
      filter,
    });
    if (!notifications.success) {
      return res.status(500).json({
        success: false,
        message: "There was osme some internal server error",
      });
    } else
      return res.status(200).json({
        success: notifications.success,
        message: "Fethced Notifications List Successfully",
        data: notifications.Notifications,
        totalPages: notifications.totalPages,
        unreadNotifications: notifications.unreadNotifications,
        totalEnteries: notifications.totalEnteries,
      });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.markAsRead = async (req, res) => {
  try {
    const { _id } = req.body;
    const Read = await ReadNotification({ _id });
    if (!Read.success) {
      return res.status(500).json({ success: false, message: Read.message });
    } else {
      return res.status(200).json({
        success: true,
        message: "Notifications marked as read",
      });
    }
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.ReadAll = async (req, res) => {
  try {
    const { _id } = req.body;
    const Read = await MarkAllAsRead({
      entityId: mongoose.Types.ObjectId.createFromHexString(_id),
    });
    if (!Read.success) {
      return res.status(500).json({ success: false, message: Read.message });
    } else {
      return res.status(200).json({
        success: true,
        message: "All Notifications marked as read",
      });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.getApiPar = async (req, res) => {
  try {
    // Get page and limit from query, set defaults
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;

    const skip = (page - 1) * limit;

    const [data, total] = await Promise.all([
      APILog.find({})
        .sort({ createdAt: -1 }) // : latest first
        .skip(skip)
        .limit(limit),
      APILog.countDocuments(),
    ]);

    return res.status(200).json({
      success: true,
      message: "Request fulfilled",
      currentPage: page,
      totalPages: Math.ceil(total / limit),
      totalLogs: total,
      data,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
};

exports.getProfile = async (req, res) => {
  try {
    const aId = req.admin._id;
    const adminId = new mongoose.Types.ObjectId(aId);
    const data = await adminModal.findOne(
      {
        _id: adminId,
      },
      "-password -__v -updatedAt"
    );
    if (data) {
      return res.status(200).json({
        success: true,
        message: "Admin Profile fetched successfully",
        data: data,
      });
    } else {
      return res.status(401).json({
        success: false,
        message: "Admin Profile Not found, logout requested",
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: `Internal Server Error`,
    });
  }
};
