const resourceModel = require("../../models/resources");
const resourceModuleModel = require("../../models/resourceModules");
const { default: mongoose } = require("mongoose");
exports.ListResource = async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 10;
    const page = Number(req.query.page) || 1;
    const skip = Math.abs((page - 1) * limit);

    const data = await resourceModel.aggregate([
      {
        $facet: {
          data: [{ $skip: skip }, { $limit: limit }],
          pageInfo: [
            { $count: "totalItems" },
            {
              $addFields: {
                page: page,
                totalPages: {
                  $ceil: {
                    $divide: ["$totalItems", limit],
                  },
                },
              },
            },
          ],
        },
      },
    ]);
    const resources = data[0]?.data || [];
    const pageInfo = data[0]?.pageInfo?.[0] || { totalPages: 0, page };
    return res.status(200).json({
      success: true,
      data: resources,
      message: "Coach resources list fetched successfully",
      pageInfo: {
        totalPages: pageInfo.totalPages,
        currentPage: pageInfo.page,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.DetailsResource = async (req, res) => {
  try {
    let id = req.params.id;
    let data = await resourceModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(id),
        },
      },
      {
        $lookup: {
          from: "resources_modules",
          localField: "_id",
          foreignField: "resourceId",
          as: "modules",
        },
      },
    ]);
    return res.status(200).json({
      success: true,
      data: data[0],
      message: "Resources details fetched successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.addResource = async (req, res) => {
  try {
    const { title, description, availableFor } = req.body;
    await new resourceModel({
      title,
      description,
      availableFor,
    }).save();
    return res.status(200).json({
      success: true,
      message: "Coach resource added successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.updateResource = async (req, res) => {
  try {
    const id = req.params.id;
    const { title, description, availableFor } = req.body;
    const updated = await resourceModel.findByIdAndUpdate(
      id,
      {
        $set: {
          title,
          description,
          availableFor,
        },
      },
      { new: true }
    );
    if (!updated) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }
    return res.status(200).json({
      success: true,
      message: "Coach resource updated successfully",
      data: updated,
    });
  } catch (error) {
    console.log("Update Resource Error:", error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.deleteResource = async (req, res) => {
  try {
    const id = req.params.id;
    const deletedResource = await resourceModel.findByIdAndDelete(id);
    if (!deletedResource) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }
    await resourceModuleModel.deleteMany({
      resourceId: mongoose.Types.ObjectId.createFromHexString(id),
    });
    return res.status(200).json({
      success: true,
      message: "Coachee resource and associated modules removed successfully",
    });
  } catch (error) {
    console.error("Error in deleteResource:", error);
    return res.status(500).json({
      success: false,
      message: "Server error while deleting resource",
    });
  }
};

//add resources Modules
exports.addResourceModule = async (req, res) => {
  try {
    const resourceId = req.params.id;
    const { title, description } = req.body;
    const imageFile = req.files?.image?.[0];
    const pdfFile = req.files?.pdf?.[0];
    const image = imageFile ? imageFile.filename : "";
    const pdf = pdfFile ? pdfFile.filename : "";
    const module = await new resourceModuleModel({
      resourceId,
      title,
      description,
      thumbnailImage: image,
      pdfFile: pdf,
    }).save();
    if (module) {
      return res.status(200).json({
        success: true,
        message: "Resource  module has been  added successfully",
      });
    } else {
      return res.status(500).json({ success: false, message: "Server error" });
    }
  } catch (error) {
    console.error("Add Resource Module Error:", error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.removeModule = async (req, res) => {
  try {
    const resourceId = req.params.id;
    const removed = await resourceModuleModel.findOneAndDelete({
      _id: mongoose.Types.ObjectId.createFromHexString(resourceId),
    });
    if (removed) {
      return res.status(200).json({
        success: true,
        message: "Resource module has been removed successfully",
      });
    } else
      return res
        .status(500)
        .json({ success: false, message: "Internal Server error" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.EditModule = async (req, res) => {
  try {
    const resourceId = req.params.id;
    const { description, title } = req.body;
    const imageFile = req.files?.image?.[0];
    const pdfFile = req.files?.pdf?.[0];
    const image = imageFile ? imageFile.filename : "";
    const pdf = pdfFile ? pdfFile.filename : "";
    const updates = {
      description,
      title,
    };
    if (imageFile) {
      updates.thumbnailImage = image;
    }
    if (pdfFile) {
      updates.pdfFile = pdf;
    }
    const removed = await resourceModuleModel.updateOne(
      {
        _id: mongoose.Types.ObjectId.createFromHexString(resourceId),
      },
      { $set: { ...updates } }
    );
    if (removed) {
      return res.status(200).json({
        success: true,
        message: "Resource Module has been Updated successfully",
      });
    } else
      return res
        .status(500)
        .json({ success: false, message: "Internal Server error" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
