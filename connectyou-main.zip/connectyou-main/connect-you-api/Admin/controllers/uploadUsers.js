const mongoose = require("mongoose");
const moment = require("moment-timezone");
const fs = require("fs");
const csvParser = require("csv-parser");
const CoachModel = require("../../models/coach");

const transportEmail = require("../../lib/email");
const generateCsvFile = require("../../lib/generateCsvFile");
const {
  createBulkEntryRecord,
  bulk_users_entry_Model,
} = require("../../models/bulk_users_entry_Model");
const { validateEmailForDB } = require("../../utils/emailDbValidation");

exports.getHistory = async (req, res) => {
  try {
    // console.log({ query: req.query });
    const { pageNo = 1, limit = 10 } = req.query;

    const data = await bulk_users_entry_Model.aggregate([
      { $sort: { createdAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [
            { $skip: (Number(pageNo) - 1) * Number(limit) },
            { $limit: Number(limit) },
          ],
        },
      },
    ]);

    // console.log({ data });
    const returnData = data[0]?.data;
    const totalCount = data[0]?.pageInfo[0]?.count || 0;
    const response = {
      data: returnData,
      totalPages: Math.ceil(totalCount / limit),
      message: "Fetched bulk entry history successfully",
      success: true,
    };
    return res.status(200).json(response);
  } catch (error) {
    console.error("Error at uploadCoaches API handler:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

exports.uploadCoaches = async (req, res) => {
  try {
    if (!req.file) {
      return res
        .status(400)
        .json({ success: false, message: "No file uploaded" });
    }
    const csvFile = req.file;
    const failedEntries = [];
    const successfullEntries = [];
    // console.log({ csvFile });
    try {
      const stream = fs.createReadStream(csvFile.path).pipe(csvParser());
      for await (const row of stream) {
        try {
          // console.log("Processing row:", row);
          const newRow = {
            ...row,
            languages: row.languages
              ? row.languages.split(",").map((lang) => lang.trim())
              : [],
            industries: row.industries
              ? row.industries.split(",").map((ind) => ind.trim())
              : [],
            coachingSpecialities: row.coachingSpecialities
              ? row.coachingSpecialities.split(",").map((spec) => spec.trim())
              : [],
            experienceYear: parseInt(row.experienceYear, 10),
            nonProfitCoaching: row.nonProfitCoaching === "yes",
            registrationType: "bulk_upload",
            userName: generateUniqueName(row.firstName),
            name: row.firstName,
            Lname: row.lastName,
            DOB: moment(row.date_of_birth, "DD-MM-YYYY").toDate(),
            ...(row?.gender &&
            [("Male", "Female", "Other")].includes(row.gender)
              ? { gender: row.gender }
              : {}),
          };
          const avail = await validateEmailForDB(newRow.email);
          if (avail) {
            const createdCoach = await CoachModel.create(newRow);
            if (createdCoach) {
              successfullEntries.push(row);
            } else {
              row.failureReason = "Data base Error Occurred";
              failedEntries.push(row);
            }
          } else {
            row.failureReason = "Duplicate key Error, Email Already Exists";
            failedEntries.push(row);
          }
        } catch (error) {
          console.error(`Error inserting row for ${row.email} `, error.message);
          row.failureReason = error.message;
          failedEntries.push(row);
        }
      }
    } catch (streamError) {
      console.error("Error processing CSV file:", streamError);
      return res
        .status(500)
        .json({ success: false, message: "Error reading CSV file" });
    }
    // console.log({ successfullEntries, failedEntries });
    try {
      if (successfullEntries.length > 0) {
        await Promise.allSettled(
          successfullEntries.map((coach) =>
            transportEmail.createEmail({
              mailOptions: {
                from: "ConnectYou <itadmin@erickson.edu>",
                to: [coach.email],
                subject:
                  "Congratulations, ConnectYou Account registration was successfull!",
                template: "coachCreated",
                context: {
                  name: `${coach.firstName} ${coach.lastName}`,
                  email: coach.email,
                },
              },
            })
          )
        );
      }
    } catch (emailError) {
      console.error("Error sending emails:", emailError);
    }
    const timestamp = Date.now().toString();
    const successFile = successfullEntries.length
      ? await generateCsvFile(
          successfullEntries,
          `successfull_coach_entries_${timestamp}.csv`
        )
      : null;
    const failureFile = failedEntries.length
      ? await generateCsvFile(
          failedEntries,
          `failed_coach_entries_${timestamp}.csv`
        )
      : null;
    await createBulkEntryRecord({
      entry_type: "Bulk_Coach_Entry",
      result:
        failedEntries.length === 0
          ? "Success"
          : successfullEntries.length > failedEntries.length
          ? "Partial Success"
          : "Failure",
      successFilepath: successFile,
      failureFilepath: failureFile,
      successCount: successfullEntries.length,
      failureCount: failedEntries.length,
      uploadedBy: req.admin?._id || "Unknown",
    });

    return res.status(200).json({
      success: true,
      message: "Coaches uploaded successfully.",
      data: {
        successfullEntries,
        failedEntries,
        successNumber: successfullEntries.length,
        failureNumber: failedEntries.length,
      },
      files: {
        success: successFile,
        failure: failureFile,
      },
    });
  } catch (error) {
    console.error("Error at uploadCoaches API handler:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const generateUniqueName = (firstName) => {
  const randomDigits = Math.floor(100 + Math.random() * 999);
  const timestamp = Date.now().toString();
  return `${firstName.slice(0, 3)}_${randomDigits}_cy_coach_${timestamp}`;
};
