const nodemailer = require("nodemailer");
const hbs = require("nodemailer-express-handlebars");
const path = require("path");
const { validationResult } = require("express-validator");
const { create, list, remove } = require("../../models/contactUs");
const transportEmail = require("../../lib/email");

exports.submitForm = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    const { fullName, email, subject, message, organizationType } = req.body;
    const submission = await create({
      fullName,
      email,
      subject,
      message,
      organizationType,
    });
    if (submission.success) {
      await sendThanksMail({ fullName, email, message, subject });
      return res.status(200).json({
        success: true,
        message: "Form submitted successfully.",
        data: submission.data,
      });
    } else
      return res.status(500).json({
        success: false,
        message: "There was some error while submitting the form.",
        data: null,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "There was some unexpected internal server error.",
      data: null,
    });
  }
};

exports.listAll = async (req, res) => {
  try {
    const page = req.query.page || 1;
    const limit = req.query.limit || 20;
    const listing = await list({ page, limit });
    if (listing.success) {
      return res.status(200).json({
        success: true,
        message: "Fetched contact us list successfully.",
        data: listing.data,
        totalPages: listing.totalPages,
        currentPage: listing.currentPage,
      });
    } else
      return res.status(500).json({
        success: false,
        message:
          "There was some error while fetching the contact form submission list.",
        data: null,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "There was some unexpected internal server error.",
      data: null,
    });
  }
};

const sendThanksMail = async ({ fullName, email, subject, message }) => {
  const capitalizedUserName = capitalizeFirstLetter(fullName);
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: "Welcome to ConnectYou!",
    template: "contact_us",
    context: {
      name: capitalizedUserName,
      email: email,
      subject: subject,
      message: message,
    },
  };
  await transportEmail.createEmail({ mailOptions });
};

function capitalizeFirstLetter(str) {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}

exports.removeOne = async (req, res) => {
  try {
    const id = req.params.id;
    // console.log(id);
    const listing = await remove({ id });
    if (listing.success) {
      return res.status(200).json({
        success: true,
        message: "Entry removed successfully.",
        data: listing.data,
      });
    } else
      return res.status(500).json({
        success: false,
        message: "There was some error while removing this entry.",
        data: null,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "There was some unexpected internal server error.",
      data: null,
    });
  }
};
