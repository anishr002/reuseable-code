const { validationResult } = require("express-validator");
require("dotenv").config();
const mongoose = require("mongoose");
const {
  refund_request_model,
  approve_refund,
  cancel_refund,
} = require("../../models/refund_request");
const stripe = require("stripe")(process.env.STRIPE_SK);

const handleError = (req, res, status, message, error) => {
  console.log(error);
  return res.status(error.status || status || 500).json({
    success: false,
    message: message || "Internal Server Error",
    data: null,
    error: error,
  });
};

exports.fetchStripeBalance = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 transactions per page
    const startingAfter = req.query.starting_after || null;
    const filterType = parseInt(req.query.filter, 10) || 0; // 0 = all, 1 = debit, 2 = credit
    const balance = await stripe.balance.retrieve();
    const availableBalance =
      balance.available?.find((a) => a?.currency?.toUpperCase() === "USD")
        ?.amount / 100;
    const allTransactions = await stripe.balanceTransactions.list({
      limit: 100,
    });

    const filteredTransactions = allTransactions.data.filter((txn) => {
      if (filterType === 1) return txn.amount < 0; //
      if (filterType === 2) return txn.amount > 0; //
      return true;
    });

    const totalCount = filteredTransactions.length;
    const totalPages = Math.ceil(totalCount / limit);

    const paginatedTransactions = filteredTransactions.slice(
      startingAfter
        ? filteredTransactions.findIndex((txn) => txn.id === startingAfter) + 1
        : 0,
      startingAfter
        ? filteredTransactions.findIndex((txn) => txn.id === startingAfter) +
            1 +
            limit
        : limit
    );

    const totalDebit =
      filteredTransactions
        .filter((txn) => txn.amount < 0)
        .reduce((sum, txn) => sum + Math.abs(txn.amount), 0) / 100;

    const totalCredit =
      filteredTransactions
        .filter((txn) => txn.amount > 0)
        .reduce((sum, txn) => sum + txn.amount, 0) / 100;

    return res.status(200).json({
      success: true,
      message: "Stripe Balance retrieved successfully",
      balance: availableBalance,
      debit: totalDebit.toFixed(2),
      credit: totalCredit.toFixed(2),
      transactions: paginatedTransactions,
      totalPages,
      totalCount,
      limit,
      hasMore: totalPages > 1, // Simplified check for demonstration
    });
  } catch (error) {
    console.error(
      "Error fetching Stripe balance or transactions:",
      error.message
    );
    handleError(req, res, 500, "Some Internal Server Error occurred", error);
  }
};

exports.fetchRefundRequests = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 transactions per page
    const page = parseInt(req.query.page, 10) || 1;
    const listing = req.query.type;
    const filterType = parseInt(req.query.filter, 10); // 3 = all, 1 = approved, 2 = denied , 0 : pending
    let matchCriteria = {};
    if (listing === "history" && filterType !== 3) {
      matchCriteria.refund_status = { $ne: 0 };
    }
    if (filterType !== 3) {
      matchCriteria.refund_status = { $eq: filterType };
    }

    const transactions = await refund_request_model.aggregate([
      {
        $match: matchCriteria,
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      {
        $unwind: {
          path: "$coachData",
          preserveNullAndEmptyArrays: true, // In case coach data is missing
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      {
        $unwind: {
          path: "$userData",
          preserveNullAndEmptyArrays: true, // In case user data is missing
        },
      },
      {
        $lookup: {
          from: "coachSession",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      {
        $unwind: {
          path: "$sessionData",
          preserveNullAndEmptyArrays: true, // In case session data is missing
        },
      },
      {
        $project: {
          _id: 1,
          cartId: 1,
          bookings_id: 1,
          booked_session_id: 1,
          userId: 1,
          coachId: 1,
          sessionId: 1,
          coachTimeZone: 1,
          userTimeZone: 1,
          sessionType: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
          charge: 1,
          amount: 1,
          session_cancel_remark: 1,
          cancel_requested_by: 1,
          refund_status: 1,
          refund_id: 1,
          refund_transaction_id: 1,
          refund_charge_id: 1,
          refund_created: 1,
          refund_amount: 1,
          refund_stripe_status: 1,
          createdAt: 1,
          userData: {
            name: { $ifNull: ["$userData.name", ""] },
            _id: "$userData._id",
            email: { $ifNull: ["$userData.email", ""] },
            gender: { $ifNull: ["$userData.gender", ""] },
            image: { $ifNull: ["$userData.image", ""] },
          },
          coachData: {
            name: { $ifNull: ["$coachData.name", ""] },
            _id: "$coachData._id",
            email: { $ifNull: ["$coachData.email", ""] },
            gender: { $ifNull: ["$coachData.gender", ""] },
            image: { $ifNull: ["$coachData.image", ""] },
          },
          sessionData: {
            title: { $ifNull: ["$sessionData.title", ""] },
            _id: "$sessionData._id",
            price: { $ifNull: ["$sessionData.price", ""] },
            description: { $ifNull: ["$sessionData.description", ""] },
          },
        },
      },
      {
        $sort: { createdAt: -1 },
      },
      {
        $skip: (page - 1) * limit,
      },
      {
        $limit: limit,
      },
    ]);

    // Calculating total pages and pending count based on the filtered data
    const totalCount = await refund_request_model.countDocuments(matchCriteria);
    const totalPages = Math.ceil(totalCount / limit);
    const pendingCount = await refund_request_model.countDocuments({
      refund_status: 0,
    });

    return res.status(200).json({
      success: true,
      message: "Refund requests fetched successfully",
      transactions,
      totalPages,
      pendingCount,
    });
  } catch (error) {
    console.error("Error fetching refund requests:", error.message);
    handleError(req, res, 500, "Some Internal Server Error occurred", error);
  }
};

exports.aprrove_refund_req = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const refund_id = req.params.refund_id;
    const reqApprove = await approve_refund({ refund_id });
    return res.status(reqApprove.status).json({
      success: reqApprove.success,
      data: reqApprove.data,
      error: reqApprove.error,
      message: reqApprove.message,
    });
  } catch (error) {
    console.error("Error fetching refund requests:", error.message);
    handleError(req, res, 500, "Some Internal Server Error occurred", error);
  }
};

exports.cancel_refund_req = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const refund_id = req.params.refund_id;
    const reqDeny = await cancel_refund({ refund_id });
    return res.status(reqDeny.status).json({
      success: reqDeny.success,
      data: reqDeny.data,
      error: reqDeny.error,
      message: reqDeny.message,
    });
  } catch (error) {
    console.error("Error fetching refund requests:", error.message);
    handleError(req, res, 500, "Some Internal Server Error occurred", error);
  }
};

exports.fetchRefundRequestsDetails = async (req, res) => {
  try {
    const { refund_id } = req.params;
    // console.log({ refund_id });
    let matchCriteria = {
      _id: new mongoose.Types.ObjectId(refund_id),
    };
    const data = await refund_request_model.aggregate([
      {
        $match: matchCriteria,
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      {
        $unwind: {
          path: "$coachData",
          preserveNullAndEmptyArrays: true, // In case coach data is missing
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      {
        $unwind: {
          path: "$userData",
          preserveNullAndEmptyArrays: true, // In case user data is missing
        },
      },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionData",
        },
      },
      {
        $unwind: {
          path: "$sessionData",
          preserveNullAndEmptyArrays: true, // In case session data is missing
        },
      },
      {
        $project: {
          _id: 1,
          cartId: 1,
          bookings_id: 1,
          booked_session_id: 1,
          userId: 1,
          coachId: 1,
          sessionId: 1,
          coachTimeZone: 1,
          userTimeZone: 1,
          sessionType: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
          charge: 1,
          amount: 1,
          session_cancel_remark: 1,
          cancel_requested_by: 1,
          refund_status: 1,
          refund_id: 1,
          refund_transaction_id: 1,
          refund_charge_id: 1,
          refund_created: 1,
          refund_amount: 1,
          refund_stripe_status: 1,
          createdAt: 1,
          userData: {
            name: { $ifNull: ["$userData.name", ""] },
            _id: "$userData._id",
            email: { $ifNull: ["$userData.email", ""] },
            gender: { $ifNull: ["$userData.gender", ""] },
            image: { $ifNull: ["$userData.image", ""] },
          },
          coachData: {
            name: { $ifNull: ["$coachData.name", ""] },
            Lname: { $ifNull: ["$coachData.Lname", ""] },
            _id: "$coachData._id",
            email: { $ifNull: ["$coachData.email", ""] },
            gender: { $ifNull: ["$coachData.gender", ""] },
            image: { $ifNull: ["$coachData.image", ""] },
          },
          sessionData: {
            title: { $ifNull: ["$sessionData.title", ""] },
            _id: "$sessionData._id",
            price: { $ifNull: ["$sessionData.price", ""] },
            description: { $ifNull: ["$sessionData.description", ""] },
          },
        },
      },
    ]);
    if (!data.length > 0) {
      return res.status(404).json({
        success: false,
        message: "Refund requests was not found",
        data: null,
      });
    }
    return res.status(200).json({
      success: true,
      message: "Refund requests fetched successfully",
      data: data[0],
    });
  } catch (error) {
    console.error("Error fetching refund requests:", error.message);
    handleError(req, res, 500, "Some Internal Server Error occurred", error);
  }
};
