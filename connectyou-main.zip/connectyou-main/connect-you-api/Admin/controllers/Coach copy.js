const puppeteer = require("puppeteer");
const moment = require("moment-timezone");
const { validationResult } = require("express-validator");
const mongoose = require("mongoose");
const Stripe = require("stripe");
const nodemailer = require("nodemailer");
const hbs = require("nodemailer-express-handlebars");
const path = require("path");
require("dotenv").config();
//environment variables
const stripe = Stripe(process.env.STRIPE_SK);
//import the modals
const CoachModel = require("../../models/coach");
const completedOrderModal = require("../../models/completedOrders");
const coachPayoutModel = require("../../models/coachPayout");
const orderRatingModal = require("../../models/orderRating");
const chatRoomModel = require("../../models/Chatroom");
const chatMessageModel = require("../../models/chatMessage");
const { CreateNotification } = require("../../models/notificationModal");
const resourceModel = require("../../models/resources");
const coachResourceSectionModale = require("../../models/coachResourceSection");
const {
  getApproalReqs,
  acceptApprovalReqeust,
  rejectApprovalRequest,
  approvvalReqHistory,
} = require("../../models/coachProfileApproval");

// email
const transportEmail = require("../../lib/email");
const {
  updateAgreementClause,
  getAgreement,
} = require("../../models/coach_agreement_clause");

const {
  getAgreementList,
  approveCoachAgreement,
  rejectCoachAgreement,
  revokeCoachAgreement,
} = require("../../models/coach_agreement");
const { sendAccountBlockedMail } = require("../../utils/quickEmails");

//Coach list
exports.coachList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let pageNo = req.query.pageNo || 1;
    let filter = req.query.filter;
    let searchTerm = req.query.searchTerm;
    filter = Number(filter);
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    let filterOption = {
      delete: 0,
    };
    if (filter == 1 || filter == 0) {
      filterOption.approve = filter;
    }
    if (searchTerm && searchTerm.trim() !== "") {
      const escapedSearchTerm = searchTerm
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filterOption.$or = [
        { email: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { name: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { Lname: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { gender: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
      ];
    }
    const coachList = await CoachModel.aggregate([
      {
        $match: filterOption,
      },
      { $sort: { updatedAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);

    let totalPages = 1;
    if (coachList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(coachList[0].pageInfo[0].count / limit);
    }
    const coachListData = coachList[0].data;
    const response = {
      success: true,
      coachList: coachListData,
      totalPages,
      currentPage: pageNo,
      message: "coach list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach details
exports.coachDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param

    const coachData = await CoachModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(coachId),
          delete: 0,
        },
      },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachexperiences",
          localField: "_id",
          foreignField: "coachId",
          as: "coachexperiences",
        },
      },
      {
        $lookup: {
          from: "coacheducations",
          localField: "_id",
          foreignField: "coachId",
          as: "coacheducations",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);
    if (coachData.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    if (coachData.length > 0) {
      let data = {
        _id: coachData[0]._id,
        name: coachData[0].name,
        Lname: coachData[0].Lname,
        email: coachData[0].email,
        gender: coachData[0].gender,
        DOB: coachData[0].DOB,
        approve: coachData[0].approve,
        image: coachData[0].image,
        createdAt: coachData[0].createdAt,
        freeTrial: coachData[0].freeTrial,
        about_me: coachData[0].about_me,
        title_line: coachData[0].title_line,
        languages: coachData[0].languages,
        fullAddress: coachData[0].fullAddress,
        zoomMeetingURL: coachData[0].zoomMeetingURL,
        coachingSpecialities: coachData[0].coachingSpecialities,
        coachcredentials: coachData[0].coachcredentials,
        coachexperiences: coachData[0].coachexperiences,
        coacheducations: coachData[0].coacheducations,
        coachcertificates: coachData[0].coachcertificates,
        zoomId: coachData[0].zoomId,
        zoomAccStatus: coachData[0].zoomAccStatus,
        calendarStatus: coachData[0].calendarStatus,
        updateStatus: coachData[0].updateStatus,
        block: coachData[0].block,
        emailVerified: coachData[0].emailVerified,
        averageRating: coachData[0].averageRating,
        totalRatings: coachData[0].totalRatings,
        refered_by_partner: coachData[0].refered_by_partner,
        nonProfitCoaching: coachData[0].nonProfitCoaching,
        refering_partner: coachData[0].refering_partner,
      };
      const response = {
        success: true,
        data,
        message: "Coach data get successfully",
      };
      return res.status(200).json(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach block
exports.coachBlock = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    const coachDetails = await CoachModel.find({ _id: coachId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    const blockStatus = coachDetails[0].block == 0 ? 1 : 0;
    const coachUpdatedDetails = await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { block: blockStatus },
      { new: true }
    );
    const blockStatusText =
      coachDetails[0].block == 0 ? "blocked" : "unblocked";
    const response = {
      success: true,
      coachData: coachUpdatedDetails,
      message: `coach ${blockStatusText} successfully`,
    };
    res.status(200).json(response);
    if (blockStatusText === "blocked") {
      await sendAccountBlockedMail(
        `${coachDetails[0].name} ${coachDetails[0].Lname}`,
        coachDetails[0].email
      );
    }
    return;
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach profile approve
exports.coachProfileApprove = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    const coachDetails = await CoachModel.find({ _id: coachId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    const approveStatus = coachDetails[0].approve == 0 ? 1 : 0;
    const updateStatus = coachDetails[0].approve == 0 ? 2 : 1;
    const coachUpdatedDetails = await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { approve: approveStatus, updateStatus: updateStatus },
      { new: true }
    );
    const approveStatusText =
      coachDetails[0].approve == 0 ? "approved" : "rejected";
    if (coachDetails[0].approve == 0) {
      function capitalizeFirstLetter(str) {
        if (!str) return "";
        return str.charAt(0).toUpperCase() + str.slice(1);
      }
      const capitalizedName = capitalizeFirstLetter(coachDetails[0].name);
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: [
          "ekta@erickson.edu",
          "blossom.reactdev@gmail.com",
          coachDetails[0].email,
        ],
        subject: `Your Coach Marketplace Account is Now Active!`,
        template: "approvalCoachProfile",
        context: {
          name: capitalizedName,
          email: coachDetails[0].email,
        },
      };
      await transportEmail.createEmail({ mailOptions });
    }
    const response = {
      success: true,
      coachData: coachUpdatedDetails,
      message: `Coach profile ${approveStatusText} successfully`,
    };
    if (approveStatusText === "approved") {
      await CreateNotification({
        user_id: coachId,
        heading: "Profile has been approved Coach! Congrats",
        description:
          "Your profile has been approved by the adminstrator, your profile has been listed in teh coaches section of the portal, have a look by clicking on the view buttoon. ",
        url: `/find-a-coach/details/${coachId}`,
        notification_type: "admin",
      });
    }
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//Coach account delete
exports.coachDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    const coachDetails = await CoachModel.find({ _id: coachId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "Coach data not found",
      };
      return res.status(404).json(response);
    }
    await CoachModel.findByIdAndUpdate(
      { _id: coachId },
      { delete: 1 },
      { new: true }
    );
    const response = {
      success: true,
      message: `Coach account deleted successfully`,
    };

    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//payout history
exports.payoutHistory = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 20;
    const skip = pageNo * limit - limit;
    const filterOption = req.query.filterOption;

    let matchPipe = {};
    if (!isNaN(Number(filterOption)) && Number(filterOption) !== 2) {
      matchPipe.status = Number(filterOption);
    } else matchPipe = {};
    // console.log(matchPipe);
    const payoutHistory = await coachPayoutModel.aggregate([
      {
        $match: matchPipe,
      },
      {
        $lookup: {
          from: "coaches",
          let: { coachId: "$coachId" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ["$_id", "$$coachId"],
                },
              },
            },
            {
              $lookup: {
                from: "coach-payouts",
                let: { coachId: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $eq: ["$coachId", "$$coachId"],
                      },
                    },
                  },
                  {
                    $group: {
                      _id: "$coachId",
                      totalAmountApproved: {
                        $sum: {
                          $cond: [{ $eq: ["$status", 1] }, "$amount", 0], // Sum for status 1
                        },
                      },
                      totalAmountPending: {
                        $sum: {
                          $cond: [{ $eq: ["$status", 0] }, "$amount", 0], // Sum for status 0
                        },
                      },
                    },
                  },
                ],
                as: "coachPayouts",
              },
            },
          ],
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $lookup: {
          from: "completedorders",
          localField: "coachId",
          foreignField: "coachId",
          as: "completedOrdersData",
        },
      },
      {
        $addFields: {
          totalAmount: {
            $sum: "$completedOrdersData.amount",
          },
        },
      },
      {
        $project: {
          _id: 1,
          coachId: 1,
          createdAt: 1,
          approveDate: 1,
          status: 1,
          amount: 1,
          totalAmount: 1,
          totalPayout: {
            $ifNull: [
              {
                $arrayElemAt: [
                  "$coachData.coachPayouts.totalAmountApproved",
                  0,
                ],
              },
              0,
            ],
          },
          totalPayoutPending: {
            $ifNull: [
              {
                $arrayElemAt: ["$coachData.coachPayouts.totalAmountPending", 0],
              },
              0,
            ],
          },
          coachData: {
            coachId: "$coachData._id",
            name: "$coachData.name",
            Lname: "$coachData.Lname",
            email: "$coachData.email",
            image: "$coachData.image",
          },
        },
      },

      { $sort: { createdAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (payoutHistory[0].pageInfo.length > 0) {
      totalPages = Math.ceil(payoutHistory[0].pageInfo[0].count / limit);
    }
    const payoutHistoryData = payoutHistory[0].data;
    const response = {
      success: true,
      payoutHistory: payoutHistoryData,
      totalPages,
      currentPage: pageNo,
      message: "Data retrieved successfully",
    };

    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach payout history
exports.coachPayoutHistory = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let coachId = req.params.id; //coach id form the param
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    const [coachData, totalRevenueData, payoutData] = await Promise.all([
      CoachModel.findOne({ _id: coachId }).select("_id name Lname email image"),
      completedOrderModal.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        {
          $facet: {
            totalRevenue: [
              {
                $group: {
                  _id: null,
                  total: { $sum: "$amount" },
                },
              },
            ],
          },
        },
        {
          $project: {
            totalRevenue: {
              $ifNull: [{ $arrayElemAt: ["$totalRevenue.total", 0] }, 0],
            },
          },
        },
      ]),
      await coachPayoutModel.aggregate([
        {
          $match: {
            coachId: new mongoose.Types.ObjectId(coachId),
          },
        },
        {
          $sort: { createdAt: -1 },
        },
        {
          $facet: {
            pageInfo: [{ $count: "count" }],
            totalBalance: [
              {
                $group: {
                  _id: null,
                  total: {
                    $sum: {
                      $cond: [{ $eq: ["$status", 1] }, "$amount", 0], // Sum for status 1
                    },
                  },
                  totalAmountPending: {
                    $sum: {
                      $cond: [{ $eq: ["$status", 0] }, "$amount", 0], // Sum for status 0
                    },
                  },
                },
              },
            ],
            data: [{ $skip: skip }, { $limit: limit }],
          },
        },
        {
          $project: {
            pageInfo: {
              $ifNull: [{ $arrayElemAt: ["$pageInfo.count", 0] }, 1],
            },
            totalBalance: {
              $ifNull: [{ $arrayElemAt: ["$totalBalance.total", 0] }, 0],
            },
            totalAmountPending: {
              $ifNull: [
                { $arrayElemAt: ["$totalBalance.totalAmountPending", 0] },
                0,
              ],
            },
            data: 1,
          },
        },
      ]),
    ]);
    const totalRevenue = Number(totalRevenueData[0].totalRevenue) / 100;
    const pendingPayout = Number(payoutData[0].totalAmountPending) / 100;
    const totalPayout = Number(payoutData[0].totalBalance) / 100;
    const totalBalance = totalRevenue - totalPayout;
    const totalPages = Math.ceil(payoutData[0].pageInfo / limit);
    const responce = {
      success: true,
      payoutList: payoutData[0].data,
      balanceDetails: {
        totalRevenue: totalRevenue,
        payoutBalance: totalPayout,
        payoutBalancePending: pendingPayout,
        totalBalance: totalBalance,
      },
      coachData,
      totalPages,
      currentPage: pageNo,
      message: "Data retrieved successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach payout approve

exports.coachPayoutApprove = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const balance = await stripe.balance.retrieve();
    const availableBalance = balance.available[0].amount;
    let payoutId = req.params.id; //coach id form the params
    const { coachId } = req.body;
    const [totalRevenueData, totalPayoutAmount, coachPayoutData, coachData] =
    
      await Promise.all([
        completedOrderModal.aggregate([
          {
            $match: {
              coachId: new mongoose.Types.ObjectId(coachId),
            },
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amount" },
            },
          },
        ]),
        coachPayoutModel.aggregate([
          {
            $match: {
              coachId: new mongoose.Types.ObjectId(coachId),
              status: 1,
            },
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amount" },
            },
          },
        ]),
        coachPayoutModel.findOne({ _id: payoutId }).select("_id amount bankId"),
        CoachModel.findOne({ _id: coachId }),
      ]);

    let totalRevenue = 0;
    let totalPayout = 0;
    totalRevenue =
      totalRevenueData.length > 0 ? totalRevenueData[0].totalAmount : 0;
    totalPayout =
      totalPayoutAmount.length > 0 ? totalPayoutAmount[0].totalAmount : 0;
    let totalBalance = totalRevenue - totalPayout;
    if (coachPayoutData.amount > totalBalance) {
      const responce = {
        success: false,
        message: "Insufficient balance",
      };
      return res.status(400).json(responce);
    }

    if (coachPayoutData.amount > availableBalance) {
      // console.log("Insufficient balance");
      const responce = {
        success: false,
        message: "Insufficient balance",
      };
      return res.status(400).json(responce);
    }
    const stripebalance = await stripe.balance.retrieve({
      stripeAccount: coachData.stripe_accID,
    });
    const availableCurrency = stripebalance.available.find(
      (bal) => bal.amount >= Number(coachPayoutData.amount)
    );
    if (!availableCurrency) {
      const responce = {
        success: false,
        message:
          "Insufficient (balance) funds in the coach's account for the transfer.",
      };
      return res.status(400).json(responce);
    }
    // stripe.transfers.create
    const payout = await stripe.payouts.create(
      {
        amount: Number(coachPayoutData.amount),
        currency: availableCurrency.currency,
        destination: coachPayoutData.bankId,
      },
      {
        stripeAccount: coachData.stripe_accID,
      }
    );

    const payData = await coachPayoutModel.findByIdAndUpdate(
      {
        _id: payoutId,
      },
      {
        $set: {
          payoutId: payout.id,
          payout_transactionId: payout.balance_transaction,
          payout_destination: payout.destination,
          payout_type: payout.type,
          status: 1, // 1 for approved
          approveDate: new Date(),
          transactionId: `TXN${Math.floor(10000 + Math.random() * 90000)}`,
        },
      },
      { new: true }
    );

    if (payData) {
      const receipt = await generateInvoice({
        customerEmail: coachData.email,
        customerName: `${coachData.name} ${coachData.Lname}`,
        transactions: [payData],
        period: `Receipt For the transaction - ${payData.transactionId}`,
      });

      await coachPayoutModel.findByIdAndUpdate(
        {
          _id: payoutId,
        },
        { $set: { receipt: receipt } }
      );
      const responce = {
        success: true,
        coachData,
        payout,
        message: "Payout approved successfully",
      };
      await CreateNotification({
        user_id: coachId,
        heading: `Your payout request for Amount ${
          coachPayoutData?.currency ? coachPayoutData?.currency : ""
        } ${coachPayoutData.amount / 100} have been approved.`,
        description: ` Your request for the sum of amount ${
          coachPayoutData?.currency ? coachPayoutData?.currency : ""
        } ${
          coachPayoutData.amount / 100
        } have been approved by the adminstrator, You will receive the transfer shortly. If this was not you Please report this immediately.`,
        url: `/c/payment`,
        notification_type: "admin",
      });
      await paymentConfirmationCoach({
        userName: `${coachData.name} ${coachData.Lname}`,
        amount: `${
          coachPayoutData?.currency
            ? coachPayoutData?.currency.toUpperCase()
            : "$"
        } ${coachPayoutData.amount / 100}`,
        transactionID: payData.transactionId,
        userEmail: coachData.email,
        fileName: receipt,
      });
      return res.status(200).json(responce);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Error while approving the payout." });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach rating list
exports.CoachRating = async (req, res) => {
  try {
    const coachId = req.params.id;
    const ratingData = await orderRatingModal.aggregate([
      {
        $match: {
          coachId: new mongoose.Types.ObjectId(coachId),
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $project: {
          _id: 1,
          message: 1,
          createdAt: 1,
          ratingNumber: 1,
          Userid: "$userData._id",
          name: "$userData.name",
          image: "$userData.image",
          gender: "$userData.gender",
        },
      },
    ]);

    const responce = {
      success: true,
      data: ratingData,
      message: "Rating get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach inbox data
exports.CoachInbox = async (req, res) => {
  try {
    const coachId = req.params.id;
    const inboxData = await chatRoomModel.aggregate([
      {
        $match: {
          $or: [
            { userId1: new mongoose.Types.ObjectId(coachId) },
            { userId2: new mongoose.Types.ObjectId(coachId) },
          ],
        },
      },
      {
        $lookup: {
          from: "chatmessages",
          let: { id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    {
                      $eq: ["$chatRoomId", "$$id"],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "users",
                let: { id: "$senderId", id2: "$receiverId" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$_id", "$$id2"] },

                              {
                                $ne: [
                                  "$_id",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$_id", "$$id"] },
                              {
                                $ne: [
                                  "$_id",
                                  new mongoose.Types.ObjectId(coachId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  { $project: { _id: 1, name: 1, image: 1 } },
                ],
                as: "userProfile",
              },
            },
            { $unwind: "$userProfile" },
          ],
          as: "ChatData",
        },
      },
      { $unwind: "$ChatData" },
      { $sort: { "ChatData.createdAt": -1 } },
      {
        $group: {
          _id: "$ChatData.chatRoomId",
          count: { $sum: 1 },
          ChatData: { $first: "$ChatData" },
        },
      },
      { $sort: { "ChatData.createdAt": -1 } },
    ]);

    const responce = {
      success: true,
      data: inboxData,
      message: "Coach inbox data get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//coach chat list
exports.CoachMessagesList = async (req, res) => {
  try {
    const chatRoomId = req.params.id;
    let messageData = await chatMessageModel.find({ chatRoomId: chatRoomId });
    const responce = {
      success: true,
      data: messageData,
      message: "Coach message data get successfully",
    };
    return res.status(200).json(responce);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const sendACcountApprovedEmail = async (name, email) => {
  const mailOptions = {
    from: "ConnectYou <itadmin@erickson.edu>",
    to: email,
    subject: "Account Approval successful",
    template: "accountapprovalEmail",
    context: {
      name: name,
      email: email,
    },
  };
  await transportEmail.createEmail({ mailOptions });
};

exports.getprofileApprovalList = async (req, res) => {
  try {
    const pageNo = Number(req.query.pageNo) || 1;
    const limit = Number(req.query.limit) || 10;
    const skip = (pageNo - 1) * limit; // Adjusting this calculation
    const searchTerm = req.query.searchTerm;
    const pendingReqs = await getApproalReqs({ skip, limit, searchTerm });
    if (pendingReqs.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else
      return res.status(200).json({
        success: true,
        message: "Fethced Profile approval status successfully",
        data: pendingReqs.data,
        totalPages: pendingReqs.totalPages,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getprofileApprovalHistory = async (req, res) => {
  try {
    const pageNo = Number(req.query.pageNo) || 1;
    const limit = Number(req.query.limit) || 10;

    const skip = (pageNo - 1) * limit; // Adjusting this calculation
    const pendingReqs = await approvvalReqHistory({ limit, skip });

    if (pendingReqs.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else
      return res.status(200).json({
        success: true,
        message: "Fethced Profile approval status successfully",
        data: pendingReqs.data,
        totalPages: pendingReqs.totalPages,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.newCoachProfileApprove = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coach_id = req.params.coach_id;
    const coachData = await CoachModel.find({ _id: coach_id });
    const req_id = req.params.req_id;
    const action = await acceptApprovalReqeust({ coach_id, req_id });

    if (action.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else {
      function capitalizeFirstLetter(str) {
        if (!str) return "";
        return str.charAt(0).toUpperCase() + str.slice(1);
      }
      const capitalizedName = capitalizeFirstLetter(coachData[0].name);
      const mailOptions = {
        from: "ConnectYou <itadmin@erickson.edu>",
        to: [
          // "ekta@erickson.edu",
          "blossom.reactdev@gmail.com",
          coachData[0].email,
        ],
        subject: `Your Coach Marketplace Account is Now Active!`,
        template: "approvalCoachProfile",
        context: {
          coachName: capitalizedName,
        },
      };
      Promise.allSettled([
        CreateNotification({
          user_id: coach_id,
          heading: "Profile has been approved Coach! Congrats",
          description:
            "Your profile has been approved by the adminstrator, your profile has been listed in teh coaches section of the portal, have a look by clicking on the view buttoon. ",
          url: `/coach/detail/${coach_id}`,
          notification_type: "admin",
        }),
        transportEmail.createEmail({ mailOptions }),
      ]);
      return res.status(200).json({
        success: true,
        message: "Coach profile has been approved",
        data: action,
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.newCoachProfileDecline = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const coach_id = req.params.coach_id;
    const req_id = req.params.req_id;
    const note = req.body.note;
    const action = await rejectApprovalRequest({ coach_id, req_id, note });
    // console.log(coach_id, req_id);
    if (action.success === false) {
      return res.status(500).json({ success: false, message: "Server error" });
    } else
      return res.status(200).json({
        success: true,
        message: "Coach Profile approval has been declined.",
        data: action,
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const generateInvoice = async ({
  customerName,
  customerEmail,
  transactions,
  period,
}) => {
  const date = new Date().toLocaleDateString();

  let transactionRows = "";
  let totalAmount = 0;

  transactions.forEach((transaction, index) => {
    totalAmount += transaction.amount;

    transactionRows += `
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 12px;">${index + 1}</td>
        <td style="padding: 12px;">${new Date(
          transaction.approveDate
        ).toLocaleDateString()}</td>
        <td style="padding: 12px;">${transaction.payout_type}</td>
        <td style="padding: 12px;">${
          transaction.transactionId ? transaction.transactionId : "N/A"
        }</td>
        <td style="padding: 12px;">$${(transaction.amount / 100).toFixed(
          2
        )}</td>
      </tr>
    `;
  });

  const htmlTemplate = `<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Transaction History Receipt</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f4f4f4;
            }
            .invoice {
                background: #fff;
                border: 1px solid #ddd;
                border-radius: 10px;
                padding: 30px;
                max-width: 800px;
                margin: auto;
                box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            }
            .header {
                text-align: center;
                border-bottom: 2px solid #eee;
                padding-bottom: 20px;
                margin-bottom: 20px;
            }
            .header img {
                max-width: 150px;
            }
            .header h1 {
                color: #333;
                margin: 10px 0;
            }
            .header p {
                color: #777;
                margin: 0;
            }
            .details {
                margin: 20px 0;
                border-top: 1px dashed #ccc;
                padding-top: 10px;
            }
            .details div {
                margin-bottom: 5px;
            }
            .transactions {
                margin: 20px 0;
                border-top: 1px solid #eee;
                padding-top: 10px;
            }
            .transactions table {
                width: 100%;
                border-collapse: collapse;
            }
            .transactions th, .transactions td {
                border: 1px solid #ddd;
                padding: 12px;
                text-align: left;
            }
            .transactions th {
                background-color: #f2f2f2;
            }
            .footer {
                margin-top: 30px;
                text-align: center;
                font-size: 12px;
                color: #888;
            }
        </style>
    </head>
    <body>

    <div class="invoice">
        <div class="header">
            <img src="https://api.connectyou.global/logo/loginLogo.png" alt="ConnectYou">
            <h1>Transaction History Receipt</h1>
            <p>Date: ${date}</p>
            <p> ${period}</p>
        </div>

        <div class="details">
            <h3>Coach Details</h3>
            <div><strong>Name:</strong> ${customerName}</div>
            <div><strong>Email:</strong> ${customerEmail}</div>
        </div>

        <div class="transactions">
            <h3>Transaction Details</h3>
            <table>
                <thead>
                    <tr>
                        <th style="padding: 12px; text-align: left;">No.</th>
                        <th style="padding: 12px; text-align: left;">Approval Date</th>
                        <th style="padding: 12px; text-align: left;">Payout Type</th>
                        <th style="padding: 12px; text-align: left;">Transaction ID</th>
                        <th style="padding: 12px; text-align: left;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${transactionRows}
                    <tr style="background-color: #f9f9f9;">
                        <td colspan="4" style="text-align: right; padding: 12px; font-weight: bold;">Total Amount:</td>
                        <td style="padding: 12px; font-weight: bold;">$${(
                          totalAmount / 100
                        ).toFixed(2)}</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="footer">
            <p>Thank you for your trust!</p>
            <p>For any queries, contact us at info@connectyou.com</p>
        </div>
    </div>

    </body>
    </html>`;

  let browser;
  if (process.env.BACKEND_URL === "http://localhost:7000") {
    browser = await puppeteer.launch();
  } else {
    browser = await puppeteer.launch({
      executablePath: "/usr/bin/chromium-browser",
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
  }
  const page = await browser.newPage();

  await page.setContent(htmlTemplate, { waitUntil: "networkidle0" });

  const pdfPath = `${Date.now()}_transaction_receipt_${customerName}.pdf`;

  const publicDir = path.resolve(__dirname, "../../public");
  await page.pdf({
    path: path.join(publicDir, "receipt", pdfPath),
    format: "A4",
    printBackground: true,
  });

  await browser.close();

  return pdfPath;
};

exports.ListCoachesAll = async (req, res) => {
  try {
    const matchPipe = {};
    const coachList = await CoachModel.find(matchPipe).select(
      "_id name Lname email image"
    );
    if (coachList) {
      return res.status(200).json({
        success: true,
        message: "Fethced coach List successfully",
        data: coachList,
      });
    } else
      return res.status(500).json({
        success: false,
        message: "Unexpected Error while fetching coaches",
      });
  } catch (error) {
    console.error({ error });
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

// helper functions
function capitalizeFirstLetter(str) {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}

const paymentConfirmationCoach = async ({
  userName,
  amount,
  transactionID,
  userEmail,
  fileName,
  curency,
}) => {
  try {
    const publicPath = path.resolve(__dirname, "../../public"); // Adjust relative path as needed
    const resolvedPath = path.join(publicPath, "receipt", fileName);
    let userName1 = capitalizeFirstLetter(userName);
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userEmail,
      subject: `Payout Confirmed: Payout has been approved and transefered to your account.`,
      template: "paymentCnfCoach",
      context: {
        userName: userName1,
        amount: amount,
        transactionID,
        date: moment().format("MM-DD-YYYY hh:mm A"),
      },
      attachments: [
        {
          filename: fileName,
          path: resolvedPath,
        },
      ],
    };
    const trye = await transportEmail.createEmail({
      mailOptions: mailOptionsForUser,
    });
    console.log(trye);
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

exports.add_coach_agreement = async (req, res) => {
  try {
    const agreement = req.file;
    if (!agreement || agreement.mimetype !== "application/pdf") {
      return res.status(400).json({
        success: false,
        message:
          agreement.mimetype !== "application/pdf"
            ? "Only pdf are accepted"
            : "Please add the agreement file",
      });
    }
    const added_agreement = await updateAgreementClause({
      file: agreement?.filename,
    });
    return res.status(added_agreement.status).json({
      success: added_agreement.success,
      message: added_agreement.message,
      status: added_agreement.status,
      data: added_agreement.data,
      error: added_agreement.error,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.get_coach_agreement = async (req, res) => {
  try {
    const added_agreement = await getAgreement();
    return res.status(added_agreement.status).json({
      success: added_agreement.success,
      message: added_agreement.message,
      status: added_agreement.status,
      data: added_agreement.data,
      error: added_agreement.error,
    });
  } catch (error) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.get_coach_agreement_lists = async (req, res) => {
  try {
    const { pageNo, limit, filter, searchTerm } = req.query;
    const added_agreement = await getAgreementList({
      limit: !isNaN(Number(limit)) ? Number(limit) : 10,
      pageNo: !isNaN(Number(pageNo)) ? Number(pageNo) : 1,
      searchTerm,
      filter: !isNaN(Number(filter)) ? Number(filter) : 3,
    });

    return res.status(added_agreement.status).json({
      success: added_agreement.success,
      message: added_agreement.message,
      status: added_agreement.status,
      data: added_agreement.data,
      totalPages: added_agreement.totalPages,
      error: added_agreement.error,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

exports.approve = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { _id, coachId } = req.params;
    const modified = await approveCoachAgreement({ _id, coachId });
    if (modified) {
      return res.status(200).json({
        ...modified,
      });
    } else throw new Error("Error ocurred while performing the task");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.decline = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { _id, coachId } = req.params;
    const remarks = req.body.remarks;
    const modified = await rejectCoachAgreement({ _id, coachId, remarks });
    if (modified) {
      return res.status(200).json({
        ...modified,
      });
    } else throw new Error("Error ocurred while performing the task");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
exports.revoke = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { _id, coachId } = req.params;
    const remarks = req.body.remarks;
    const modified = await revokeCoachAgreement({ _id, coachId, remarks });
    if (modified) {
      return res.status(200).json({
        ...modified,
      });
    } else throw new Error("Error ocurred while performing the task");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
