const { validationResult } = require("express-validator");
const mongoose = require("mongoose");
require("dotenv").config();
//environment variables

//import the modals
const userModel = require("../../models/user");
const chatRoomModel = require("../../models/Chatroom");
const chatMessageModel = require("../../models/chatMessage");
const orderRatingModal = require("../../models/orderRating");
const userResourceModle = require("../../models/coacheeResource");
const userResourceSectionModale = require("../../models/resourceModules");

const transportEmail = require("../../lib/email");
const { sendAccountBlockedMail } = require("../../utils/quickEmails");
//User list
exports.userList = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    let pageNo = req.query.pageNo || 1;
    let searchTerm = req.query.searchTerm;
    pageNo = Number(pageNo);
    const limit = 10;
    const skip = pageNo * limit - limit;
    let filterOption = {
      delete: 0,
    };
    if (searchTerm && searchTerm.trim() !== "") {
      const escapedSearchTerm = searchTerm
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filterOption.$or = [
        { email: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { name: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
        { gender: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
      ];
    }

    const userList = await userModel.aggregate([
      {
        $match: filterOption,
      },
      { $sort: { createdAt: -1 } },
      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalPages = 1;
    if (userList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(userList[0].pageInfo[0].count / limit);
    }
    const userListData = userList[0].data;
    const response = {
      success: true,
      userList: userListData,
      totalPages,
      currentPage: pageNo,
      message: "User list retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//User details
exports.userDetails = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    let userId = req.params.id; //coach id form the param
    const userDataDetails = await userModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(userId),
          delete: 0,
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "userId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
    ]);
    if (userDataDetails.length == 0) {
      const response = {
        success: false,
        message: "User data not found",
      };
      return res.status(404).json(response);
    }
    const response = {
      success: true,
      userData: userDataDetails[0],
      message: "User data retrieved successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//User block
exports.userBlock = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    let userId = req.params.id; //coach id form the param
    const userDetails = await userModel.find({ _id: userId });
    if (userDetails.length == 0) {
      const response = {
        success: false,
        message: "User data not found",
      };
      return res.status(404).json(response);
    }
    const blockStatus = userDetails[0].block == 0 ? 1 : 0;
    const userUpdatedDetails = await userModel.findByIdAndUpdate(
      { _id: userId },
      { block: blockStatus },
      { new: true }
    );
    const blockStatusText = userDetails[0].block == 0 ? "blocked" : "unblocked";
    const response = {
      success: true,
      userData: userUpdatedDetails,
      message: `User ${blockStatusText} successfully`,
    };
    res.status(200).json(response);
    if (blockStatusText === "blocked") {
      await sendAccountBlockedMail(
        `${userDetails[0].name} ${userDetails[0].Lname}`,
        userDetails[0].email
      );
    }
    return;
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//user account delete
exports.userDelete = async (req, res) => {
  // Validate request parameters
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const response = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(response);
  }
  try {
    let userId = req.params.id; //user id form the param
    const coachDetails = await userModel.find({ _id: userId });
    if (coachDetails.length == 0) {
      const response = {
        success: false,
        message: "User data not found",
      };
      return res.status(404).json(response);
    }

    await userModel.findByIdAndUpdate(
      { _id: userId },
      { delete: 1 },
      { new: true }
    );

    const response = {
      success: true,
      message: `User account deleted successfully`,
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//user inbox list
exports.userInbox = async (req, res) => {
  try {
    const userId = req.params.id;
    const inboxData = await chatRoomModel.aggregate([
      {
        $match: {
          $or: [
            { userId1: new mongoose.Types.ObjectId(userId) },
            { userId2: new mongoose.Types.ObjectId(userId) },
          ],
        },
      },
      {
        $lookup: {
          from: "chatmessages",
          let: { id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    {
                      $eq: ["$chatRoomId", "$$id"],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "coaches",
                let: { id: "$senderId", id2: "$receiverId" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $or: [
                          {
                            $and: [
                              { $eq: ["$_id", "$$id2"] },
                              {
                                $ne: [
                                  "$_id",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                          {
                            $and: [
                              { $eq: ["$_id", "$$id"] },
                              {
                                $ne: [
                                  "$_id",
                                  new mongoose.Types.ObjectId(userId),
                                ],
                              },
                            ],
                          },
                        ],
                      },
                    },
                  },
                  { $project: { _id: 1, name: 1, Lname: 1, image: 1 } },
                ],
                as: "coachProfile",
              },
            },
            { $unwind: "$coachProfile" },
          ],
          as: "ChatData",
        },
      },
      { $unwind: "$ChatData" },
      { $sort: { "ChatData.createdAt": -1 } },
      {
        $group: {
          _id: "$ChatData.chatRoomId",
          count: { $sum: 1 },
          ChatData: { $first: "$ChatData" },
        },
      },
      { $sort: { "ChatData.createdAt": -1 } },
    ]);

    const response = {
      success: true,
      data: inboxData,
      message: "Coach inbox data get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//user chat message list
exports.userMessagesList = async (req, res) => {
  try {
    const chatRoomId = req.params.id;
    let messageData = await chatMessageModel.find({ chatRoomId: chatRoomId });
    const response = {
      success: true,
      data: messageData,
      message: "Coach message data get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.userPostedRatings = async (req, res) => {
  try {
    const coacheeId = req.params.id;
    const ratingData = await orderRatingModal.aggregate([
      {
        $match: {
          userId: new mongoose.Types.ObjectId(coacheeId),
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachData",
        },
      },
      { $unwind: "$coachData" },
      {
        $project: {
          _id: 1,
          message: 1,
          createdAt: 1,
          ratingNumber: 1,
          coachId: "$coachData._id",
          name: "$coachData.name",
          Lname: "$coachData.Lname",
          image: "$coachData.image",
          gender: "$coachData.gender",
        },
      },
    ]);
    const response = {
      success: true,
      data: ratingData,
      message: "Rating get successfully",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.ListResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    let data = await userResourceModle.find();
    return res.status(200).json({
      success: true,
      data,
      message: "Coach resources list get successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.DetailsResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  let id = req.params.id;
  try {
    let data = await userResourceModle.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(id),
        },
      },
      {
        $lookup: {
          from: "user_resource_sections",
          localField: "_id",
          foreignField: "resourceId",
          as: "resource_sections_data",
        },
      },
    ]);
    return res.status(200).json({
      success: true,
      data: data[0],
      message: "user resources list get successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.addResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const { title, description } = req.body;
    await new userResourceModle({
      title,
      description,
    }).save();
    return res.status(200).json({
      success: true,
      message: "user resource added successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.updateResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const id = req.params.id;
    const { title, description } = req.body;
    await userResourceModle.findByIdAndUpdate(
      { _id: id },
      {
        $set: {
          title,
          description,
        },
      }
    );
    return res.status(200).json({
      success: true,
      message: "Coach resource added successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.deleteResource = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const id = req.params.id;
    await userResourceModle.findByIdAndDelete({ _id: id });
    return res.status(200).json({
      success: true,
      message: "Coachee resource removed successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

//add resources section
exports.addResourceSection = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const resourceId = req.params.id;
    const { description } = req.body;
    const imageFile = req.file;
    // console.log({ description });
    let image = "";
    if (imageFile) {
      image = imageFile.filename;
    }
    let data = await new userResourceSectionModale({
      resourceId: resourceId,
      description,
      image,
    }).save();
    // console.log({ data });
    return res.status(200).json({
      success: true,
      message: "Coach resource added successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.removeSection = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const resourceId = req.params.id;
    const removed = await userResourceSectionModale.findOneAndDelete({
      _id: new mongoose.Types.ObjectId(resourceId),
    });
    // console.log({ removed });
    if (removed) {
      return res.status(200).json({
        success: true,
        message: "Coachee resource removed successfully",
      });
    } else
      return res
        .status(404)
        .json({ success: false, message: "Resource not found" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.EditSection = async (req, res) => {
  const paramError = validationResult(req);
  if (!paramError.isEmpty()) {
    const responce = { success: false, message: paramError.errors[0].msg };
    return res.status(400).json(responce);
  }
  try {
    const resourceId = req.params.id;
    const { description } = req.body;
    const imageFile = req.file;
    const updates = {
      description,
    };
    if (imageFile) {
      updates.image = imageFile.filename;
    }
    const removed = await userResourceSectionModale.updateOne(
      {
        _id: resourceId,
      },
      { $set: { ...updates } }
    );
    if (removed) {
      return res.status(200).json({
        success: true,
        message: "Coachee resource Updated successfully",
      });
    } else
      return res
        .status(500)
        .json({ success: false, message: "Internal Server error" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
