const express = require("express");
const router = express.Router();
router.use(express.json());
const path = require("path");
const { body, query, param } = require("express-validator");
const auth = require("../../middleware/authTokenAdmin");
const validation = require("../../middleware/validation");
const controller = require("../controllers/sessions");

router.get(
  "/list-all",
  auth.authTokenAdmin,
  validation.response,
  controller.listAllSessions
);
router.get(
  "/add-new-session",
  [

  ],
  auth.authTokenAdmin,
  validation.response,
  controller.listAllSessions
);

module.exports = router;
