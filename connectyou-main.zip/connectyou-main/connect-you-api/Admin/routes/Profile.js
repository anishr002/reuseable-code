const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query } = require("express-validator");

//import modals
const adminModal = require("../../models/admin");
const Auth = require("../../middleware/authTokenAdmin");
//import controllers
const profileController = require("../controllers/Profile");

//admin register
router.get("/register", profileController.register);

//admin login
router.post(
  "/login",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter email")
      .isEmail()
      .withMessage("Please enter a valid email address")
      .escape()
      .custom(async (value) => {
        const user = await adminModal.find({ email: value });
        if (user.length == 0) {
          throw new Error("Invalid credentials");
        }
      }),
    body("password")
      .trim()
      .notEmpty()
      .withMessage("Please enter password")
      .escape(),
  ],
  profileController.login
);

//admin updated password
router.post(
  "/update-password",
  Auth.authTokenAdmin,
  [
    body("oldPassword")
      .trim()
      .notEmpty()
      .withMessage("Please enter oldPassword")
      .escape(),
    body("newPassword")
      .trim()
      .notEmpty()
      .withMessage("Please enter newPassword")
      .isLength({ min: 8 })
      .withMessage("new password must be at least 8 characters long")
      .escape(),
  ],
  profileController.updatePassword
);

router.post(
  "/profile/get-all-notifications",
  Auth.authTokenAdmin,
  profileController.getAllNotifications
);

router.put(
  "/profile/notification/mark-as-read",
  Auth.authTokenAdmin,
  profileController.markAsRead
);

router.put(
  "/profile/notification/mark-all-as-read",
  Auth.authTokenAdmin,
  profileController.ReadAll
);

router.get("/api-logs", Auth.authTokenAdmin, profileController.getApiPar);
router.get("/profile/data", Auth.authTokenAdmin, profileController.getProfile);

module.exports = router;
