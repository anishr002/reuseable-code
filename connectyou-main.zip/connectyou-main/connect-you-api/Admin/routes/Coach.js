const {
  multerErrorHandler,
  uploadCoachAgreement,
} = require("../../middleware/uploader");
const express = require("express");
const multer = require("multer");
const router = express.Router();
router.use(express.json());
const path = require("path");
const { body, query, param } = require("express-validator");
const coachController = require("../controllers/Coach");
const Auth = require("../../middleware/authTokenAdmin");
router.use(Auth.authTokenAdmin);
router.get("/list", coachController.coachList);
router.get(
  "/details/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  coachController.coachDetails
);
router.get(
  "/details/rating/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  coachController.CoachRating
);
router.put(
  "/block/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  coachController.coachBlock
);
router.put(
  "/profile-approve/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  coachController.coachProfileApprove
);
router.put(
  "/account-delete/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  coachController.coachDelete
);

//payouts
const payoutController = require("../controllers/Payouts");
router.get("/payout-history", payoutController.payoutHistory);
router.get(
  "/payout-history/coach/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  payoutController.coachPayoutHistory
);
router.post(
  "/payout-reject/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  payoutController.RejectPayoutRequest
);

router.post(
  "/payout-approve/:id",
  [
    param("id").trim().isMongoId().withMessage("Invailid URL"),
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please provoid coachId")
      .isMongoId()
      .withMessage("Please provoid valid coachID")
      .escape(),
  ],
  payoutController.coachPayoutApprove
);

// payouts

router.get(
  "/coach-inbox/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  coachController.CoachInbox
);
router.get(
  "/coach-message-list/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  coachController.CoachMessagesList
);

router.get(
  "/new-profile-approval-requests",
  coachController.getprofileApprovalList
);

router.get(
  "/profile-approval-requests-history",
  coachController.getprofileApprovalHistory
);

router.post(
  "/new-profile-approve/:coach_id/:req_id",
  [param("coach_id").isMongoId().withMessage("Invailid URL")],
  [param("req_id").isMongoId().withMessage("Invailid URL")],
  coachController.newCoachProfileApprove
);
router.post(
  "/new-profile-decline/:coach_id/:req_id",
  [param("coach_id").isMongoId().withMessage("Invailid URL")],
  [param("req_id").isMongoId().withMessage("Invailid URL")],
  coachController.newCoachProfileDecline
);
router.get("/coach-booking-reports/coach-list", coachController.ListCoachesAll);
const coachReportsController = require("../../API-V1/coach/controllers/bookingsReport");
router.get(
  "/coach-booking-reports/gen-rep/monthly/:coachId/:month/:year",
  [
    param("coachId").trim().isMongoId().withMessage("Invalid url"),
    param("month").trim().exists().withMessage("Please specify the month"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  coachReportsController.generateMonthly
);
router.get(
  "/coach-booking-reports/gen-rep/yearly/:coachId/:year",
  [
    param("coachId").trim().isMongoId().withMessage("Invalid url"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  coachReportsController.generateYearly
);
router.get(
  "/coach-booking-reports/gen-rep/periodic/:coachId/:from/:upto",
  [
    param("coachId").trim().isMongoId().withMessage("Invalid url"),
    param("from")
      .trim()
      .exists()
      .withMessage("Please specify the range to start from."),
    param("upto")
      .trim()
      .exists()
      .withMessage("Please specify the range to end at."),
  ],
  coachReportsController.generatePeriodic
);
router.put(
  "/agreement/add-agreement",
  multerErrorHandler(uploadCoachAgreement.single("agreement_file"), "10 MB"),
  coachController.add_coach_agreement
);
router.get("/agreement/get-agreement", coachController.get_coach_agreement);
router.get(
  "/agreement/list-agreements",
  coachController.get_coach_agreement_lists
);
router.put(
  "/agreement/approve-agreements/:_id/:coachId",
  [
    param("_id")
      .trim()
      .exists()
      .withMessage("Please provide the request _id")
      .isMongoId()
      .withMessage("Please enter a valid URI"),
    param("coachId")
      .trim()
      .exists()
      .withMessage("Please provide the coachId.")
      .isMongoId()
      .withMessage("Please enter a valid URI"),
  ],
  coachController.approve
);
router.put(
  "/agreement/reject-agreements/:_id/:coachId",
  [
    param("_id")
      .trim()
      .exists()
      .withMessage("Please provide the request _id")
      .isMongoId()
      .withMessage("Please enter a valid URI"),
    param("coachId")
      .trim()
      .exists()
      .withMessage("Please provide the coachId.")
      .isMongoId()
      .withMessage("Please enter a valid URI"),
    body("remarks")
      .exists()
      .withMessage("Please add remarks to proceed")
      .isString()
      .withMessage("Remarks must be string")
      .trim()
      .escape(),
  ],
  coachController.decline
);
router.put(
  "/agreement/revoke-agreements/:_id/:coachId",
  [
    param("_id")
      .trim()
      .exists()
      .withMessage("Please provide the request _id")
      .isMongoId()
      .withMessage("Please enter a valid URI"),
    param("coachId")
      .trim()
      .exists()
      .withMessage("Please provide the coachId.")
      .isMongoId()
      .withMessage("Please enter a valid URI"),
    body("remarks")
      .exists()
      .withMessage("Please add remarks to proceed")
      .isString()
      .withMessage("Remarks must be string")
      .trim()
      .escape(),
  ],
  coachController.revoke
);
router.get("/shortlisted-for-company", coachController.coachListShortlisted);
router.put(
  "/shortlist/list/:coachId",
  [
    param("coachId")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL")
      .escape(),
  ],
  coachController.shortlistForCompany
);
router.put(
  "/shortlist/un-list/:coachId",
  [
    param("coachId")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL")
      .escape(),
  ],
  coachController.Unlist
);
router.get(
  "/shortlist/status/:coachId",
  [
    param("coachId")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL")
      .escape(),
  ],
  coachController.shortlistStatus
);
router.get("/shortlist/export", coachController.exportShortlistedCoaches);

module.exports = router;
