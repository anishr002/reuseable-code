const express = require("express");
const router = express.Router();
router.use(express.json());
router.use(express.urlencoded({ extended: true }));

const { body, param } = require("express-validator");
const auth = require("../../middleware/authTokenAdmin");
const {
  multerErrorHandler,
  uploadFiles,
  checkFileType,
} = require("../../middleware/uploader");
const controller = require("../controllers/uploadUsers");

router.post(
  "/coach/upload-coaches",
  auth.authTokenAdmin,
  multerErrorHandler(uploadFiles.single("file"), "10 MB"),
  checkFileType,
  controller.uploadCoaches
);
router.get("/history", auth.authTokenAdmin, controller.getHistory);

module.exports = router;
