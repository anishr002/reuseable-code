const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, param } = require("express-validator");
const Auth = require("../../middleware/authTokenAdmin");
const policyController = require("../controllers/policy");

router.get(
  "/list-all-terms-conditions",
  Auth.authTokenAdmin,
  policyController.listAllTerms
);

router.post(
  "/add-update-terms-conditions",
  [body("text").trim().notEmpty().withMessage("Please enter text")],
  Auth.authTokenAdmin,
  policyController.updateExTermAndCondition
);

//privacy policies
router.get(
  "/list-all-privacy-policy",
  Auth.authTokenAdmin,
  policyController.listAllPolicies
);

router.post(
  "/add-update-privacy-policy",
  [body("text").trim().notEmpty().withMessage("Please enter text")],
  Auth.authTokenAdmin,
  policyController.updateExPrivacyPol
);

//privacy policies
router.get(
  "/list-cookie-policy",
  Auth.authTokenAdmin,
  policyController.listCookiePolicies
);

router.post(
  "/add-update-cookie-policy",
  [body("text").trim().notEmpty().withMessage("Please enter text")],
  Auth.authTokenAdmin,
  policyController.addUpdateCookiePolicies
);

module.exports = router;
