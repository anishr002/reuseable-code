const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const userController = require("../controllers/User");
const Auth = require("../../middleware/authTokenAdmin");
const {
  uploadResource,
  multerErrorHandler,
} = require("../../middleware/uploader");
router.use(Auth.authTokenAdmin);
router.get("/list", userController.userList);
router.get(
  "/details/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  userController.userDetails
);

router.put(
  "/block/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  userController.userBlock
);
router.put(
  "/account-delete/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  userController.userDelete
);

router.get(
  "/user-inbox/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  userController.userInbox
);
router.get(
  "/user-message-list/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  userController.userMessagesList
);

router.get(
  "/details/rating/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  userController.userPostedRatings
);

router.post(
  "/user-resource/add",
  [
    body("title").trim().notEmpty().withMessage("Please provoid title"),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please provoid description"),
  ],
  userController.addResource
);

router.post(
  "/user-resource/update-resource/:id",
  [
    body("title").trim().notEmpty().withMessage("Please provoid title"),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please provoid description"),
    param("id").trim().isMongoId().withMessage("Invailid URL"),
  ],
  userController.updateResource
);
router.put(
  "/user-resource/remove-resource/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  userController.deleteResource
);

router.get("/user-resource/list", userController.ListResource);

router.get(
  "/user-resource/details/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  userController.DetailsResource
);

router.post(
  "/user-resource/add-section/:id",
  multerErrorHandler(uploadResource.single("image"), "5 MB"),
  [
    param("id").trim().isMongoId().withMessage("Invailid URL"),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please provoid description"),
  ],
  userController.addResourceSection
);
router.post(
  "/user-resource/update-section/:id",
  multerErrorHandler(uploadResource.single("image"), "5 MB"),
  [
    param("id").trim().isMongoId().withMessage("Invailid URL"),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please provoid description"),
  ],
  userController.EditSection
);

router.put(
  "/user-resource/remove-section/:id",
  [param("id").trim().isMongoId().withMessage("Invailid URL")],
  userController.removeSection
);

module.exports = router;
