const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, param } = require("express-validator");
const Auth = require("../../middleware/authTokenAdmin");
const {
  uploadResource,
  multerErrorHandler,
} = require("../../middleware/uploader");
const controller = require("../controllers/resources");
const validation = require("../../middleware/validation");
router.use(Auth.authTokenAdmin);

router.post(
  "/add-resource",
  [
    body("title").trim().notEmpty().withMessage("Please provoid title"),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please provoid description"),
  ],
  validation.response,
  controller.addResource
);

router.put(
  "/remove-resource/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  validation.response,
  controller.deleteResource
);

router.post(
  "/update-resource/:id",
  [
    param("id").isMongoId().withMessage("Invailid URL"),
    body("title").trim().notEmpty().withMessage("Please provide title"),
    body("description")
      .trim()
      .notEmpty()
      .withMessage("Please provide description"),
  ],
  validation.response,
  controller.updateResource
);

router.get("/list", controller.ListResource);

router.get(
  "/details/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  validation.response,
  controller.DetailsResource
);

router.post(
  "/add-module/:id",
  multerErrorHandler(
    uploadResource.fields([
      { name: "image", maxCount: 1 },
      { name: "pdf", maxCount: 1 },
    ]),
    "15 MB"
  ),
  [param("id").isMongoId().withMessage("Invalid URL")],
  validation.response,
  controller.addResourceModule
);

router.post(
  "/update-module/:id",
  multerErrorHandler(
    uploadResource.fields([
      { name: "image", maxCount: 1 },
      { name: "pdf", maxCount: 1 },
    ]),
    "15 MB"
  ),
  [param("id").isMongoId().withMessage("Invalid URL")],
  validation.response,
  controller.EditModule
);

router.put(
  "/remove-module/:id",
  [param("id").isMongoId().withMessage("Invailid URL")],
  validation.response,
  controller.removeModule
);

module.exports = router;
