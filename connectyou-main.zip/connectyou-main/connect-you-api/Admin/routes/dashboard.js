const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");

//import controllers
const dashboard = require("../controllers/dashboard");

//import middlewere
const Auth = require("../../middleware/authTokenAdmin");
router.use(Auth.authTokenAdmin);
router.get("/orderList", dashboard.orderList);
router.get("/completed-orderList", dashboard.completedOrdersList);
router.get("/last-order", dashboard.lastOrders);
router.get("/upcoming-sessions", dashboard.upcomingSessions);
router.get("/payout-history-recent", dashboard.payoutHistoryRecent);
router.get("/registration-state", dashboard.registrationState);

// new apis
router.get("/booking-stats", dashboard.bookingStats);

module.exports = router;
