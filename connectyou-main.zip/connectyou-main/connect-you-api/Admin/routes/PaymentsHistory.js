const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");

//import controllers
const dashboard = require("../controllers/dashboard");

//import middlewere
const Auth = require("../../middleware/authTokenAdmin");
router.use(Auth.authTokenAdmin);

const coachPayoutController = require("../../API-V1/coach/controllers/paymentHistory");
//coach
router.get(
  "/coach/payout-history-coach/gen-rec/monthly/:coachId/:month/:year",
  [
    param("coachId").trim().isMongoId().withMessage("Invalid url"),
    param("month").trim().exists().withMessage("Please specify the month"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  Auth.authTokenAdmin,
  coachPayoutController.generateMonthlyRcpt
);
router.get(
  "/coach/payout-history-coach/gen-rec/yearly/:coachId/:year",
  [
    param("coachId").trim().isMongoId().withMessage("Invalid url"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  Auth.authTokenAdmin,
  coachPayoutController.generateYearly
);

router.get(
  "/coach/payout-history-coach/gen-rec/periodic/:coachId/:from/:upto",
  [
    param("coachId").trim().isMongoId().withMessage("Invalid url"),
    param("from")
      .trim()
      .exists()
      .withMessage("Please specify the range to start from."),
    param("upto")
      .trim()
      .exists()
      .withMessage("Please specify the range to end at."),
  ],
  Auth.authTokenAdmin,
  coachPayoutController.generatePeriodic
);

//coachee
const coacheeHistoryController = require("../../API-V1/user/controllers/paymentHistory");

router.get(
  "/coachee/transaction-history-coachee/gen-rec/monthly/:userId/:month/:year",
  [
    param("userId").trim().isMongoId().withMessage("Invalid url"),
    param("month").trim().exists().withMessage("Please specify the month"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  Auth.authTokenAdmin,
  coacheeHistoryController.generateMonthlyRcpt
);
router.get(
  "/coachee/transaction-history-coachee/gen-rec/yearly/:userId/:year",
  [
    param("userId").trim().isMongoId().withMessage("Invalid url"),
    param("year").trim().exists().withMessage("Please specify the year"),
  ],
  Auth.authTokenAdmin,
  coacheeHistoryController.generateYearly
);

router.get(
  "/coachee/transaction-history-coachee/gen-rec/periodic/:userId/:from/:upto",
  [
    param("userId").trim().isMongoId().withMessage("Invalid url"),
    param("from")
      .trim()
      .exists()
      .withMessage("Please specify the range to start from."),
    param("upto")
      .trim()
      .exists()
      .withMessage("Please specify the range to end at."),
  ],
  Auth.authTokenAdmin,
  coacheeHistoryController.generatePeriodic
);

const paymentManagementController = require("../controllers/payments");
router.get(
  "/transactions/fetch-stripe-balance",
  Auth.authTokenAdmin,
  paymentManagementController.fetchStripeBalance
);

router.get(
  "/refunds/fetch-request-list",
  Auth.authTokenAdmin,
  paymentManagementController.fetchRefundRequests
);

router.put(
  "/refunds/actions/approve-request/:refund_id",
  [
    param("refund_id")
      .exists()
      .withMessage("Please enter Req Params")
      .isMongoId()
      .withMessage("Please enter correct URL"),
  ],
  Auth.authTokenAdmin,
  paymentManagementController.aprrove_refund_req
);

router.put(
  "/refunds/actions/cancel-request/:refund_id",
  [
    param("refund_id")
      .exists()
      .withMessage("Please enter Req Params")
      .isMongoId()
      .withMessage("Please enter correct URL"),
  ],
  Auth.authTokenAdmin,
  paymentManagementController.cancel_refund_req
);
router.get(
  "/refunds/refund-request-details/:refund_id",
  [
    param("refund_id")
      .exists()
      .withMessage("Please enter Req Params")
      .isMongoId()
      .withMessage("Please enter correct URL"),
  ],
  Auth.authTokenAdmin,
  paymentManagementController.fetchRefundRequestsDetails
);

module.exports = router;
