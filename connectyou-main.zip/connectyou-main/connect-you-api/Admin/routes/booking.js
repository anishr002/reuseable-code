const express = require("express");
const router = express.Router();
router.use(express.json());
const { param } = require("express-validator");
const bookingController = require("../controllers/booking");
const Auth = require("../../middleware/authTokenAdmin");
router.use(Auth.authTokenAdmin);
router.get("/booking-history", bookingController.bookingHistory);
router.get(
  "/booking-history-details/:id",
  bookingController.bookingHistoryDetails
);
router.get(
  "/booking-history-session-details/:id/:bookedSessionId",
  bookingController.bookingHistorySessionDetails
);
router.get(
  "/booking-history/coach/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL Parameter")
      .escape(),
  ],
  bookingController.bookingHistoryCoach
);
router.get(
  "/booking-history/user/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL Parameter")
      .escape(),
  ],
  bookingController.bookingHistoryUser
);
module.exports = router;
