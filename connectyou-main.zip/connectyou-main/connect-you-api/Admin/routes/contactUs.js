const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, param } = require("express-validator");
const controller = require("../controllers/contactUs");

const Auth = require("../../middleware/authTokenAdmin");

router.post(
  "/new-contact-us",
  [body("email").trim().notEmpty().withMessage("Please enter email")],
  controller.submitForm
);

router.get("/list-all-subs", Auth.authTokenAdmin, controller.listAll);

router.put(
  "/remove-enquiry/:id",
  [[param("id").isMongoId().withMessage("Invailid URL")]],
  Auth.authTokenAdmin,
  controller.removeOne
);

module.exports = router;
