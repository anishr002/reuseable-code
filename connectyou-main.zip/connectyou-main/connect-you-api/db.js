const moment = require("moment-timezone");
require("dotenv").config();
const mongoose = require("mongoose");
const databaseUrl = process.env.MONGO_DB_URL;

let isConnectedBool = false;

exports.connect = async () => {
  if (isConnectedBool) {
    console.log("Using existing MongoDB connection.");
    return;
  }
  try {
    await mongoose.connect(databaseUrl);
    isConnectedBool = true;
    console.log(
      `Database connection established successfully at ${moment()
        .tz("Asia/Calcutta")
        .format("DD MMMM YYYY hh:mm A")} `
    );
  } catch (error) {
    console.error("Database connection error:", error);
  }
};

// Function to disconnect from the database
exports.disconnect = async () => {
  if (!isConnectedBool) return;
  try {
    await mongoose.disconnect();
    isConnectedBool = false;
    console.log(
      `Database disconnected at ${moment()
        .tz("Asia/Calcutta")
        .format("DD MMMM YYYY hh:mm A")} `
    );
  } catch (error) {
    console.error("Database disconnection error:", error);
  }
};

exports.isConnected = () => {
  return isConnectedBool;
};
