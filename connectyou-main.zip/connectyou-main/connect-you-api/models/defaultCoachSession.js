const mongoose = require("mongoose");
const { Schema } = mongoose;

const CurrencySchema = new mongoose.Schema({
  code: { type: String, default: "US" },
  label: { type: String, default: "United States" },
  phone: { type: String, default: "1" },
  currency: { type: String, default: "USD" },
  symbol: { type: String, default: "$" },
});

const schema = new Schema(
  {
    type: { type: Number, default: 0 },
    title: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String, required: true },
    duration: { type: Number, default: 30 },
    status: { type: Boolean, default: true },
    currency: { type: CurrencySchema, default: () => ({}) },
    stripePriceId: { type: String, default: "" },
    stripeProductId: { type: String, default: "" },
    deleted: { type: Number, default: 0 },
  },
  { timestamps: true }
);

schema.statics.getAllSessions = async function () {
  return this.find({ deleted: 0 }); // returns an array of sessions
};

schema.statics.toggleStatus = async function (sessionId) {
  if (!sessionId || !mongoose.Types.ObjectId.isValid(sessionId)) {
    throw new Error("Inavlid session ID");
  }
  const session = await this.findById(sessionId);
  if (!session) throw new Error("Session not found");
  session.status = !session.status;
  await session.save();
  return session;
};

const defaultCoachSessionModel = mongoose.model(
  "default_coach_session",
  schema
);

module.exports = defaultCoachSessionModel;
