const mongoose = require("mongoose");
const Schema = new mongoose.Schema(
  {
    fullName: { type: String, default: "" },
    email: { type: String, required: true },
    subject: { type: String, default: "" },
    message: { type: String, default: "" },
    deleted: { type: Number, default: 0 },
    organizationType: {
      type: String,
      default: "",
    },
  },
  {
    timestamps: true,
  }
);

const ContactModel = mongoose.model("contact_form", Schema);

const create = async ({
  fullName,
  email,
  subject,
  message,
  organizationType,
}) => {
  try {
    const newForm = await ContactModel.create({
      fullName,
      email,
      subject,
      message,
      organizationType,
    });
    if (newForm) {
      return {
        success: true,
        message: "Form submission successfull.",
        data: newForm,
      };
    } else
      return { success: false, message: "Internal server error", data: null };
  } catch (error) {
    console.log(error);
    return { success: false, message: "Internal server error", data: null };
  }
};

const list = async ({ page = 1, limit = 20 }) => {
  try {
    const skip = (page - 1) * limit;
    const result = await ContactModel.aggregate([
      { $match: { deleted: 0 } },
      {
        $facet: {
          data: [{ $skip: skip }, { $limit: limit }],
          totalCount: [{ $count: "count" }],
        },
      },
    ]);

    const data = result[0].data;
    const totalCount = result[0].totalCount[0]?.count || 0;
    const totalPages = Math.ceil(totalCount / limit);

    return {
      success: true,
      message: "Fetched the forms submission list successfully.",
      data,
      totalPages,
      currentPage: page,
    };
  } catch (error) {
    console.log(error);
    return {
      success: false,
      message: "Server Error while fetching list...",
    };
  }
};

const remove = async ({ id }) => {
  try {
    const deleted = await ContactModel.updateOne(
      { _id: id },
      { $set: { deleted: 1 } }
    );
    if (deleted) {
      return {
        success: true,
        data: deleted,
        message: "Removed entry successfully",
      };
    } else {
      return {
        success: false,
        data: null,
        message: "Error removing an entry.",
      };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Internal server error" };
  }
};

module.exports = { ContactModel, create, list, remove };
