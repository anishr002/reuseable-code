const mongoose = require("mongoose");
const { Schema } = mongoose;

const FocusSchema = new Schema(
  {
    category: { type: String, default: "" },
    label: { type: String, default: "" },
    tag: { type: String, default: "" },
  },
  {
    _id: false,
    timestamps: false,
  }
);

const StripeCountryDetailsSchema = new Schema(
  {
    code: { type: String, default: "" },
    label: { type: String, default: "" },
    phone: { type: String, default: "" },
    currency: { type: String, default: "" },
    account_service: { type: String, default: "" },
    hasTransferRestrictions: { type: Boolean, default: false },
  },
  {
    _id: false,
    timestamps: false,
  }
);

const SchemaModal = new Schema(
  {
    //type
    registrationType: {
      type: String,
      default: "manual",
      enum: [
        "manual",
        "bulk_upload",
        "bulk_to_manual",
        "hubspot_sync",
        "hubspot_sync_to_manual",
      ],
    },
    userType: { type: String, default: "coach" },
    // personal details
    name: { type: String, required: true },
    Lname: { type: String, default: "" },
    userName: { type: String, default: "" },
    email: { type: String, required: true, unique: true, lowercase: true },
    emailVerified: { type: Number, default: 0 }, //1 for verified and 0 for not verified
    password: { type: String, default: "" }, // test //
    gender: { type: String, enum: ["Male", "Female", "Other", "Non-binary"] },
    DOB: { type: Date },
    image: { type: String, default: "" },
    about_me: { type: String, default: "" },
    title_line: { type: String, default: "" },
    //stripe start
    persionId_number: { type: String, default: "" },
    invoice_prefix: { type: String, default: "" },
    stripe_customerID: { type: String, default: "" },
    accHolderId: { type: String, default: "" },
    stripe_accID: { type: String, default: "" },
    stripe_addStatus: { type: Number, default: 0 }, //0 for not added and 1 for added
    stripe_onboardStatus: { type: Number, default: 2 }, //0 for not added and 1 for added and 2 for account not created
    currency: { type: String, default: "" },
    stripeCountryDetails: {
      type: StripeCountryDetailsSchema,
      default: undefined,
    },
    //stripe end
    bankAccountID: { type: String, default: "" },
    updateStatus: { type: Number, default: 0 }, //0 for not update 1 for updated
    Bcountry: { type: String, default: "" },
    Bcity: { type: String, default: "" },
    bankAccount_holder_name: { type: String, default: "" },
    bankAccount_routing_number: { type: String, default: "" },
    bankAccount_account_number: { type: String, default: "" },
    persionId_number: { type: String, default: "" },
    idProofFront: { type: String, default: "" },
    idProofBack: { type: String, default: "" },
    // ssn_last_4: { type: String, default: "" },
    //googleCalender
    calendarStatus: { type: Number, default: 0 }, //0 for not and 1 for yes
    calendarAddedDate: { type: String, default: "" },
    //admin-actions
    block: { type: Number, default: 0 }, // block status:1||unblock status:0
    freeTrial: { type: String, default: true },
    approve: { type: Number, default: 0 }, //approve status:1||reject status:0
    delete: { type: Number, default: 0 }, //delete status:1
    deleteReq: { type: Number, default: 0 }, //delete request:2,request approved:1
    // ..otps
    otp: { type: String },
    otpType: { type: String, default: "" },
    otpDate: { type: String },
    //profile
    zoomMeetingURL: { type: String, default: "" },
    linkedin_profile_link: { type: String, default: "" }, // new property
    languages: { type: [String], default: [] },
    industries: { type: [String], default: [] },
    coachingSpecialities: { type: [String], default: [] },
    coaching_focus_area: { type: [FocusSchema], default: [] },
    experienceYear: { type: Number, default: 0 },
    experienceYearStr: { type: String, default: "" },
    timeZone: { type: String, default: "" },
    refered_by_partner: { type: Number, default: 0 },
    nonProfitCoaching: { type: Boolean, default: false },
    refering_partner: {
      type: {
        region: { type: String, required: false },
        country: { type: String, required: false },
      },
      default: null,
    },
    //address //
    location: {
      type: {
        type: String,
        enum: ["Point"],
      },
      coordinates: {
        type: [Number],
      },
    },
    city: { type: String, default: "" },
    fullAddress: { type: String, default: "" },
    country: { type: String, default: "" },
    countryCode: { type: String, default: "" },
    phoneCode: { type: String, default: "" },

    // activity
    live: { type: Number, default: 0 }, //0 for not 1 for live
    lastSeen: { type: String, default: "" }, // last time turn live to 0
    //hubspot
    hub_spot_id: { type: String, default: "" }, // once the contact is created on hubspot we store it here so that we can later use this to create updated into his hub contact.
    // my_invitation_code: { type: String, unique: true },
  },
  { timestamps: true }
);

SchemaModal.index({ location: "2dsphere" });
const CoachModel = mongoose.model("coach", SchemaModal, "coaches");

module.exports = CoachModel;
