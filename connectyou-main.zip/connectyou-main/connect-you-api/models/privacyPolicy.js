const mongoose = require("mongoose");
const Schema = new mongoose.Schema(
  {
    data: { type: String },
  },
  { timestamps: true }
);
const PrivacyPolicyModel = mongoose.model("privacy_policy", Schema);

// Function to add a new Privacy Policy
const addUpdatePrivacyPol = async (text) => {
  try {
    const data = await PrivacyPolicyModel.findOneAndUpdate(
      {},
      { $set: { data: text } },
      {
        new: true,
        upsert: true,
      }
    );

    if (data) {
      return { success: true, data, message: "Added new Privacy Policy" };
    } else {
      return { success: false, data: null, message: "Some Error occurred " };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Some Error occurred " };
  }
};

const listPrivacyPol = async () => {
  try {
    const data = await PrivacyPolicyModel.find();
    if (data) {
      return { success: true, data, message: "Retrieved Privacy Policies" };
    } else {
      return { success: false, data: null, message: "No Policies found" };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Some Error occurred " };
  }
};

module.exports = {
  PrivacyPolicyModel,
  listPrivacyPol,
  addUpdatePrivacyPol,
};
