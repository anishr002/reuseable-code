const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    coachId: mongoose.Schema.Types.ObjectId,
    title: { type: String, required: true },
    certificateFile: { type: String, default: "" },
  },
  { timestamps: true }
);

const createdModal = mongoose.model("coachCertificate", createdSchema);
module.exports = createdModal;
