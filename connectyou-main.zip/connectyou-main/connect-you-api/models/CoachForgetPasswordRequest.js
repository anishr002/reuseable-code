const mongoose = require("mongoose");

const requestSchema = mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "Coach" },
    otp: String,
    expireAt: { type: Date, default: Date.now, index: { expires: "15m" } }, // TTL index
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model(
  "CoachForgetPasswordRequest",
  requestSchema,
  "CoachForgetPasswordRequests"
);
