const mongoose = require("mongoose");
const { autoApproveCoachPayout } = require("../lib/payout");
const { Schema } = mongoose;

const CoachPayoutSchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId },
    transferId: { type: String },
    transfer_transactionId: { type: String },
    transfer_destination: { type: String },
    transfer_destination_paymentId: { type: String },
    amount: { type: Number },
    currency: { type: String },
    localAmountTransferred: { type: Number },
    localCurrency: { type: String },
    //bank details
    bankId: { type: String },
    bankName: { type: String },
    banklast4: { type: String },
    bankFingerprint: { type: String },
    reqAccount: { type: String },
    //bank details end
    payoutId: { type: String, default: "" },
    payout_transactionId: { type: String, default: "" },
    payout_destination: { type: String, default: "" },
    payout_type: { type: String, default: "" },
    // others
    status: { type: Number, default: 0 }, //0 for pending request and 1 for approved by admin
    approveDate: { type: String, default: "" },
    transferredOn: { type: String, default: "" },
    transferedArrivedAt: { type: String, default: "" },
    transactionId: { type: String, default: "" },
    receipt: { type: String, default: "" },
    paid: { type: Boolean, default: false },
    confirmedDate: { type: String, default: "" },
    retryCount: { type: Number, default: 0 },
    lastRetryAt: { type: Date, default: null },
    failed: { type: Boolean, default: false },
    failureReason: { type: String, default: "" },
  },
  { timestamps: true }
);

CoachPayoutSchema.post("save", async function (doc, next) {
  if (doc.status !== 0) return next();
  await autoApproveCoachPayout(doc);
  next();
});

const coachPayoutModel = mongoose.model("coach-payout", CoachPayoutSchema);

module.exports = coachPayoutModel;
