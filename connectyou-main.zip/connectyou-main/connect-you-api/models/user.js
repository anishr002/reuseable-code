const mongoose = require("mongoose");
const { Schema } = mongoose;

const SchemaModal = new Schema(
  {
    hub_spot_id: { type: String, default: "" }, // once the contact is created on hubspot we store it here so that we can later use this to create updated into his hub contact.
    emailVerified: { type: Number, default: 0 }, //1 for verified and 0 for not verified
    userName: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    userType: { type: String, default: "coachee" },
    password: { type: String, required: true, minlength: 6 },
    // personal details
    my_invitation_code: { type: String, unique: true },
    name: { type: String, required: true },
    lastName: { type: String, default: "" },
    gender: { type: String, enum: ["Male", "Female", "Other"] },
    DOB: { type: Date },
    image: { type: String, default: "" },
    aboutMe: { type: String, default: "" },
    myDescription: { type: [String], default: [] },
    // address and location detials
    timeZone: { type: String, default: "" },
    country: { type: String, default: "" },
    city: { type: String, default: "" },
    fullAddress: { type: String, default: "" },
    countryCode: { type: String, default: "" },
    location: {
      type: {
        type: String,
        enum: ["Point"],
      },
      coordinates: {
        type: [Number],
      },
    },
    phoneCode: { type: String, default: "" },
    // additinal details
    areas_of_interest: { type: [String], default: [] },
    occupation: { type: String, default: "" },
    // a// activity status
    live: { type: Number, default: 0 }, //0 for not 1 for live
    lastSeen: { type: String, default: "" }, // last time turn live to 0
    //actions
    block: { type: Number, default: 0 }, // block status:1||unblock status:0
    delete: { type: Number, default: 0 }, //delete status:1
    deleteReq: { type: Number, default: 0 }, //delete request:2,request approved:1
    // otp actions
    otp: { type: String },
    otpType: { type: String, default: "" },
    otpDate: { type: String },
    //coachee address  fields
  },
  { timestamps: true }
);

const userModel = mongoose.model("user", SchemaModal);
module.exports = userModel;
