const mongoose = require("mongoose");
const booked_session_model = require("./booked_session");
const { CreateNotification } = require("./notificationModal");
require("dotenv").config();
const stripe = require("stripe")(process.env.STRIPE_SK);
const { Schema } = mongoose;

const addressSchema = new Schema(
  {
    city: { type: String, default: "" },
    country: { type: String, default: "" },
    line1: { type: String, default: "" },
    line2: { type: String, default: "" },
    postal_code: { type: String, default: "" },
    state: { type: String, default: "" },
  },
  { _id: false }
);

const billingDetailsSchema = new Schema(
  {
    address: addressSchema,
    email: { type: String, default: "" },
    name: { type: String, default: "" },
    phone: { type: String, default: "" },
  },
  { _id: false }
);

const refundedDetailsSchema = new Schema(
  {
    processed_charge_id: { type: String, default: "" },
    billing_details: billingDetailsSchema,
    created: { type: String, default: "" },
    paid: { type: Boolean, default: false },
    payment_intent: { type: String, default: "" },
    payment_method: { type: String, default: "" },
    receipt_email: { type: String, default: "" },
    receipt_url: { type: String, default: "" },
    payment_method_details: {
      type: Object,
      default: {},
    },
  },
  { _id: false }
);

const presentmentDetailsSchema = new Schema(
  {
    presentment_amount: { type: Number, default: 0 },
    presentment_currency: { type: String, default: "" },
  },
  { _id: false }
);

const refundRequestSchema = new Schema(
  {
    refund_TXN_ID: { type: String, default: "" },
    cartId: { type: String },
    bookings_id: { type: mongoose.Schema.Types.ObjectId },
    booked_session_id: { type: mongoose.Schema.Types.ObjectId },
    userId: { type: mongoose.Schema.Types.ObjectId },
    coachId: { type: mongoose.Schema.Types.ObjectId },
    sessionId: { type: mongoose.Schema.Types.ObjectId },
    coachTimeZone: { type: String, default: "" },
    userTimeZone: { type: String, default: "" },
    sessionType: { type: String, default: "" },
    sessionDate: { type: Date },
    sessionDateUpdated: { type: Date },
    charge: { type: String, default: "" },
    amount: { type: String, default: "" },
    session_cancel_remark: { type: String, default: "" },
    cancel_requested_by: { type: String, default: "user" },
    refund_status: { type: Number, default: 0 }, // 0=pending, 1=approved, 2=denied
    refund_id: { type: String, default: "" },
    refund_transaction_id: { type: String, default: "" },
    refund_charge_id: { type: String, default: "" },
    refund_created: { type: String, default: "" },
    refund_amount: { type: String, default: "" },
    refund_stripe_status: { type: String, default: "" },
    payment_intent: { type: String, default: "" },
    presentment_details: presentmentDetailsSchema,
    stripe_refund_req_status: { type: String, default: "" },
    refunded_details: refundedDetailsSchema,
  },
  {
    timestamps: true,
  }
);

const refund_request_model = mongoose.model(
  "refund_request",
  refundRequestSchema
);

const request_refund = async ({ data }) => {
  try {
    const newReq = await refund_request_model.create({
      ...data,
    });
    if (newReq) {
      return {
        success: true,
        error: null,
        message: "Successfully created a refund request",
        data: newReq,
        status: 200,
      };
    } else {
      return {
        success: false,
        error: error,
        message: "Error Creating Refund Request",
        data: null,
        status: 404,
      };
    }
  } catch (error) {
    console.log(error);
    return {
      success: false,
      error: error,
      message: "Error Creating Refund Request",
      data: null,
      status: 500,
    };
  }
};

const approve_refund = async ({ refund_id }) => {
  try {
    // Fetch the refund request from the database
    const request = await refund_request_model.findOne({
      _id: mongoose.Types.ObjectId.createFromHexString(refund_id),
    });

    if (!request) {
      return {
        success: false,
        error: null,
        message: "Request Not Found",
        data: null,
        status: 404,
      };
    }

    // Check if a refund already exists in Stripe
    if (request.refund_id) {
      try {
        const existingRefund = await stripe.refunds.retrieve(request.refund_id);

        // If refund exists in Stripe, return its details
        if (existingRefund) {
          await Promise.allSettled([
            refund_request_model.findByIdAndUpdate(
              {
                _id: mongoose.Types.ObjectId.createFromHexString(refund_id),
              },
              {
                $set: {
                  refund_status: 1,
                  refund_id: existingRefund.id,
                  refund_transaction_id: existingRefund.balance_transaction,
                  refund_charge_id: existingRefund.charge,
                  refund_created: existingRefund.created,
                  refund_amount: existingRefund.amount,
                  refund_stripe_status: existingRefund.status,
                },
              },
              { upsert: true }
            ),
            booked_session_model.findByIdAndUpdate(
              { _id: request.booked_session_id },
              {
                $set: {
                  refundsID: existingRefund.id,
                  refundsTransaction: existingRefund.balance_transaction,
                  refundsCharge: existingRefund.charge,
                  refundsCreated: existingRefund.created,
                  refundsStatus: existingRefund.status,
                  refundsAmount: existingRefund.amount,
                },
              },
              { upsert: true }
            ),
          ]);

          return {
            success: false,
            error: null,
            message: "Refund already processed",
            data: {
              refund_id: existingRefund.id,
              refund_transaction_id: existingRefund.balance_transaction,
              refund_amount: existingRefund.amount,
              refund_status: existingRefund.status,
            },
            status: 200,
          };
        }
      } catch (stripeError) {
        // If refund ID is invalid or not found, log the error and proceed
        console.error(
          `Stripe refund retrieval error for ID ${request.refund_id}:`,
          stripeError.message
        );
      }
    }

    // Create a new refund via Stripe
    // console.log({ request });
    const refund = await stripe.refunds.create({
      charge: request.charge,
      amount: Number(request.amount),
      metadata: {
        cartId: request.cartId.toString(),
        bookings_id: request.bookings_id.toString(),
        booked_session_id: request.booked_session_id.toString(),
        userId: request.userId.toString(),
        sessionId: request.sessionId.toString(),
        coachId: request.coachId.toString(),
        charge: request.charge.toString(),
        charge: request.charge.toString(),
      },
    });
    // Update refund data in both refund_request_model and booked_session_model
    const [refundData, bookedsessionData] = await Promise.allSettled([
      refund_request_model.findByIdAndUpdate(
        {
          _id: mongoose.Types.ObjectId.createFromHexString(refund_id),
        },
        {
          $set: {
            refund_status: 1,
            refund_id: refund.id,
            refund_transaction_id: refund.balance_transaction,
            refund_charge_id: refund.charge,
            refund_created: refund.created,
            refund_amount: refund.amount,
            refund_stripe_status: refund.status,
          },
        },
        { upsert: true }
      ),
      booked_session_model.findByIdAndUpdate(
        { _id: request.booked_session_id },
        {
          $set: {
            refundsID: refund.id,
            refundsTransaction: refund.balance_transaction,
            refundsCharge: refund.charge,
            refundsCreated: refund.created,
            refundsStatus: refund.status,
            refundsAmount: refund.amount,
          },
        },
        { upsert: true }
      ),
    ]);

    if (
      refundData.status === "fulfilled" &&
      bookedsessionData.status === "fulfilled"
    ) {
      await CreateNotification({
        user_id: request.userId,
        heading: "Refund has been approved.",
        notification_type: "payments",
        description: `Your Refund request has been approved by the adminstrator, If you have any queries feel free to reach the support : support@connectyou.com, See Details by clicking on the view button.`,
        url: `/u/booking/details/${request.bookings_id}/session/details/${request.booked_session_id}/${request.coachId}`,
      });
      return {
        success: true,
        error: null,
        message: "Refund has been approved",
        data: {
          bookedsessionData,
          refundData,
        },
        status: 200,
      };
    }
  } catch (error) {
    console.error("Error approving refund:", error);
    return {
      success: false,
      error,
      message: "Error Approving Refund Request",
      data: null,
      status: 500,
    };
  }
};

const list_all_requests = async ({ page = 1, limit = 10 }) => {
  try {
    const skip = (page - 1) * limit;
    const [list, totalCount] = await Promise.all([
      refund_request_model.find().skip(skip).limit(limit).exec(),
      refund_request_model.countDocuments(),
    ]);
    return {
      success: true,
      message: "Refund Requests Fetched Successfully",
      data: list,
      pagination: {
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page,
        limit,
      },
      status: 200,
    };
  } catch (error) {
    console.log(error);
    return {
      success: false,
      error: error,
      message: "Error Fetching Refund Requests",
      data: null,
      status: 500,
    };
  }
};

const cancel_refund = async ({ refund_id }) => {
  try {
    const request = await refund_request_model.findOne({
      _id: mongoose.Types.ObjectId.createFromHexString(refund_id),
    });
    if (request) {
      // Check if a refund already exists in Stripe
      if (request.refund_id) {
        try {
          const existingRefund = await stripe.refunds.retrieve(
            request.refund_id
          );

          // If refund exists in Stripe, return its details
          if (existingRefund) {
            await Promise.allSettled([
              refund_request_model.findByIdAndUpdate(
                {
                  _id: mongoose.Types.ObjectId.createFromHexString(refund_id),
                },
                {
                  $set: {
                    refund_status: 1,
                    refund_id: existingRefund.id,
                    refund_transaction_id: existingRefund.balance_transaction,
                    refund_charge_id: existingRefund.charge,
                    refund_created: existingRefund.created,
                    refund_amount: existingRefund.amount,
                    refund_stripe_status: existingRefund.status,
                  },
                },
                { upsert: true }
              ),
              booked_session_model.findByIdAndUpdate(
                { _id: request.booked_session_id },
                {
                  $set: {
                    refundsID: existingRefund.id,
                    refundsTransaction: existingRefund.balance_transaction,
                    refundsCharge: existingRefund.charge,
                    refundsCreated: existingRefund.created,
                    refundsStatus: existingRefund.status,
                    refundsAmount: existingRefund.amount,
                  },
                },
                { upsert: true }
              ),
            ]);
            return {
              success: false,
              error: null,
              message: "Refund already processed",
              data: {
                refund_id: existingRefund.id,
                refund_transaction_id: existingRefund.balance_transaction,
                refund_amount: existingRefund.amount,
                refund_status: existingRefund.status,
              },
              status: 200,
            };
          }
        } catch (stripeError) {
          // If refund ID is invalid or not found, log the error and proceed
          console.error(
            `Stripe refund retrieval error for ID ${request.refund_id}:`,
            stripeError.message
          );
        }
      }

      const cancel_req = await refund_request_model.updateOne(
        {
          _id: mongoose.Types.ObjectId.createFromHexString(refund_id),
        },
        {
          $set: {
            refund_status: 2,
          },
        },
        { $upsert: true }
      );
      if (cancel_req.acknowledged) {
        await CreateNotification({
          user_id: request.userId,
          heading: "Refund was not approved.",
          description: `Your Refund request has been denied by the adminstrator, If you have any queries feel free to reach the support : support@connectyou.com, See Details by clicking on the view button.`,
          url: `/u/booking/details/${request.bookings_id}/session/details/${request.booked_session_id}/${request.coachId}`,
          notification_type: "payments",
        });
        return {
          success: true,
          error: null,
          message: "Refund has been canceled",
          data: cancel_req,
          status: 200,
        };
      }
    } else {
      return {
        success: false,
        error: null,
        message: "Request Not Found",
        data: null,
        status: 404,
      };
    }
  } catch (error) {
    console.log(error);
    return {
      success: false,
      error: error,
      message: "Error Cancelling the Refund Request",
      data: null,
      status: 500,
    };
  }
};

module.exports = {
  refund_request_model,
  request_refund,
  approve_refund,
  list_all_requests,
  cancel_refund,
};
