const cron = require("node-cron");
const { CreateNotification } = require("./notificationModal");
const mongoose = require("mongoose");

const IncompleteStepSchema = new mongoose.Schema({
  step: { type: Number, required: true }, // Added `required: true` to ensure validation
  label: { type: String, required: true },
  description: { type: String, required: true },
  _id: false,
});

const CoachProfileStatusSchema = new mongoose.Schema({
  coach_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "coaches",
    required: true,
    unique: true,
  },
  inCompleteSteps: { type: [IncompleteStepSchema], default: [] },
});

const CoachProfileStatusModel = mongoose.model(
  "coach_profile_status",
  CoachProfileStatusSchema
);

const updateCoachProfileComplitionStatus = async ({ coach_id, data }) => {
  try {
    // Transform the data to match the schema structure
    const inCompleteSteps = data.map((step) => ({
      step: step.Step,
      label: step.label,
      description: step.description,
    }));
    // Use `findOneAndUpdate` to either update or insert a document
    const result = await CoachProfileStatusModel.findOneAndUpdate(
      { coach_id }, // Query to find the document by coach_id
      { $set: { inCompleteSteps } }, // Update or set the inCompleteSteps array
      { upsert: true, new: true } // Create a new document if none exists, and return the updated document
    );
    return {
      success: true,
      data: result,
      message: "Profile completion status updated successfully.",
    };
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Internal Server Error " };
  }
};

// Function to send notifications for each label in inCompleteSteps
async function sendNotificationsForIncompleteSteps() {
  try {
    // Fetch documents with non-empty inCompleteSteps
    const documents = await CoachProfileStatusModel.find({
      inCompleteSteps: { $exists: true, $ne: [] },
    });
    for (const doc of documents) {
      const user_id = doc.coach_id;
      // Send a notification for each object in inCompleteSteps array
      for (const step of doc.inCompleteSteps) {
        const heading = `Reminder ! ${step.label}`;
        const description =
          step.step === 9
            ? `You have completed all the steps to complete your coach profile, submit your profile for approval by clicking on the "Submit for review" button on your profile page. Once approved you will be listed in the coach marketplace.`
            : `${step.description}, click on the view button to see your profile.`;
        const url = `/c/profile`;
        await CreateNotification({
          user_id,
          heading,
          description,
          url,
          notification_type: "systemUpdates",
        });
      }
    }
  } catch (error) {
    console.error("Error sending notifications:", error);
  }
}
//testing for every minute //// cron.schedule("* * * * *", async () => {
// Schedule the cron job to run every day at 8 AM // cron.schedule("0 8 * * *", async () => {
cron.schedule("0 8 * * *", async () => {
  console.log("Running cron job to send notifications for incomplete steps...");
  await sendNotificationsForIncompleteSteps();
});

module.exports = {
  CoachProfileStatusModel,
  updateCoachProfileComplitionStatus,
};
