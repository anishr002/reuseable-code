const mongoose = require("mongoose");
const { Schema } = mongoose;

const bookingSchema = new Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId },
    coachId: [mongoose.Schema.Types.ObjectId],
    chargeId: { type: String, default: "" },
    amount: { type: Number, default: 0 },
    currency: { type: String, default: "usd" },
    payment_intent: { type: String, default: "" },
    paymentCreated: { type: Number, default: 0 },
    cardBrand: { type: String, default: "" },
    card_exp_month: { type: String, default: "" },
    card_exp_year: { type: String, default: "" },
    card_fingerprint: { type: String, default: "" },
    card_last4: { type: String, default: "" },
    cardCountry: { type: String, default: "" },
    customer_city: { type: String, default: "" },
    customer_country: { type: String, default: "" },
    customer_line1: { type: String, default: "" },
    customer_line2: { type: String, default: "" },
    customer_postal_code: { type: String, default: "" },
    customer_state: { type: String, default: "" },
    customer_email: { type: String, default: "" },
    customer_name: { type: String, default: "" },
    customer_phone: { type: String, default: "" },
    receipt: { type: String, default: "" },
    TransactionID: { type: String, default: "" },
    orderId: { type: String, default: "" },
    orderStatus: { type: Number, default: 0 }, //0=pending,1=complited,2=cancel
    refundsID: { type: String, default: "" },
    refundsTransaction: { type: String, default: "" },
    refundsCharge: { type: String, default: "" },
    refundsCreated: { type: String, default: "" },
    refundsStatus: { type: String, default: "" },
    paid: { type: Number, default: 0 }, //0=pending,1=done
  },
  { timestamps: true }
);

const ordersModel = mongoose.model("booking", bookingSchema);
module.exports = ordersModel;
