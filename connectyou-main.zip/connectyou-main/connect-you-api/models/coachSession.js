const mongoose = require("mongoose");
const { Schema } = mongoose;

const CurrencySchema = new mongoose.Schema({
  code: { type: String, default: "US" },
  label: { type: String, default: "United States" },
  phone: { type: String, default: "1" },
  currency: { type: String, default: "USD" },
  symbol: { type: String, default: "$" },
});

const coachSessionModal = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId, required: true },
    type: { type: Number, default: 0 }, // 0 is paid and 1 is free
    title: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String, required: true },
    duration: { type: Number, default: 30 }, // in mins
    status: { type: Boolean, default: true }, // true when enabled and false when disabled
    currency: { type: CurrencySchema, default: () => ({}) },
    stripePriceId: { type: String, default: "" },
    stripeProductId: { type: String, default: "" },
    deleted: { type: Number, default: 0 }, // 1 is deleted
  },
  { timestamps: true }
);

const coachSessionModel = mongoose.model("coachSession", coachSessionModal);
module.exports = coachSessionModel;
