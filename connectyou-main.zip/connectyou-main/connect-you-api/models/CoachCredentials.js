const mongoose = require("mongoose");
const { Schema } = mongoose;

const CoachCredentialsModal = new Schema(
  {
    coachId: mongoose.Schema.Types.ObjectId,
    title: { type: String, required: true },
    image: { type: String, required: true },
    // startDate: { type: Date, },
    endDate: { type: Date },
    // workingOn: { type: Boolean , default:false },
  },
  { timestamps: true }
);

const cretedModal = mongoose.model("CoachCredentials", CoachCredentialsModal);
module.exports = cretedModal;
