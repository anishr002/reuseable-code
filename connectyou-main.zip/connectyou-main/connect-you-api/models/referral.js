const mongoose = require("mongoose");

const ReferralSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId }, // sender of invite link
    referral: { type: String }, // senders invite code
    connection: { type: mongoose.Schema.Types.ObjectId }, // reciever of invite link
  },
  {
    timestamps: true,
  }
);

const ReferralModel = mongoose.model("referral", ReferralSchema);

const getMyReferralsData = async ({ _id }) => {
  try {
    const ObjectId = require("mongoose").Types.ObjectId;
    const data = await ReferralModel.aggregate([
      {
        $match: {
          user_id: new ObjectId(_id), // Filter by the specified user_id
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "coaches",
          localField: "connection",
          foreignField: "_id",
          as: "coachDetails",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "connection",
          foreignField: "_id",
          as: "userDetails",
        },
      },
      {
        $project: {
          connections: {
            $concatArrays: [
              {
                $ifNull: [
                  {
                    $map: {
                      input: "$coachDetails",
                      as: "coach",
                      in: {
                        _id: "$$coach._id",
                        name: {
                          $concat: ["$$coach.name", " ", "$$coach.Lname"],
                        },
                        image: "$$coach.image",
                      },
                    },
                  },
                  [],
                ],
              },
              {
                $ifNull: [
                  {
                    $map: {
                      input: "$userDetails",
                      as: "user",
                      in: {
                        _id: "$$user._id",
                        name: "$$user.name",
                        image: "$$user.image",
                      },
                    },
                  },
                  [],
                ],
              },
            ],
          },
        },
      },
      {
        $unwind: "$connections",
      },
      {
        $replaceRoot: { newRoot: "$connections" },
      },
    ]);

    if (!data) {
      return { success: false, message: "No Data", data: null };
    } else
      return {
        success: true,
        message: "Referrals Data Received.",
        data,
      };
  } catch (error) {
    console.log(error);
    return { success: false, message: "No Data", data: null };
  }
};

const createRefferals = async ({ user_id, referral = "", connection }) => {
  try {
    const data = await ReferralModel.create({
      user_id,
      referral,
      connection,
    });
    if (!data) {
      return { success: false, data: null };
    } else return { success: true, data };
  } catch (error) {
    console.log(error);
    return { success: false, message: "No Data", data: null };
  }
};

const getRewardPoints = async ({ user_id }) => {
  try {
    const ObjectId = require("mongoose").Types.ObjectId;
    const data = await ReferralModel.aggregate([
      {
        $match: {
          user_id: new ObjectId(user_id),
        },
      },
      // Unwind the connections first
      {
        $group: {
          _id: null,
          connections: { $addToSet: "$connection" }, // Get unique connections
        },
      },
      // Now do the lookups on the unique connections
      {
        $lookup: {
          from: "coaches",
          let: { connections: "$connections" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $in: ["$_id", "$$connections"] },
                    { $eq: ["$emailVerified", 1] },
                  ],
                },
              },
            },
          ],
          as: "verifiedCoaches",
        },
      },
      {
        $lookup: {
          from: "users",
          let: { connections: "$connections" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $in: ["$_id", "$$connections"] },
                    { $eq: ["$emailVerified", 1] },
                  ],
                },
              },
            },
          ],
          as: "verifiedUsers",
        },
      },
      {
        $project: {
          _id: 0,
          totalVerifiedCount: {
            $add: [{ $size: "$verifiedCoaches" }, { $size: "$verifiedUsers" }],
          },
          // Optional: include individual counts for debugging
          coachCount: { $size: "$verifiedCoaches" },
          userCount: { $size: "$verifiedUsers" },
        },
      },
    ]);

    // Output the counts
    const result =
      data.length > 0
        ? data[0]
        : { totalVerifiedCount: 0, coachCount: 0, userCount: 0 };

    // console.log("Total verified connections:", result.totalVerifiedCount);
    // console.log("Verified coaches:", result.coachCount);
    // console.log("Verified users:", result.userCount);
    return { success: true, data: result };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

module.exports = {
  ReferralModel,
  getMyReferralsData,
  createRefferals,
  getRewardPoints,
};
