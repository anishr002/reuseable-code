const mongoose = require("mongoose");

const APILog = mongoose.model(
  "APILog",
  new mongoose.Schema(
    {
      endpoints: {
        type: Map,
        of: new mongoose.Schema(
          {
            count: {
              type: Number,
              default: 0,
            },
            ips: {
              type: Map,
              of: new mongoose.Schema(
                {
                  ipAddress: { type: String, required: true },
                  requested: { type: Number, default: 1 },
                },
                { _id: false }
              ),
              default: {},
            },
          },
          { _id: false }
        ),
        default: {},
      },
      totalRequestIn24Hours: {
        type: Number,
        default: 0,
      },
      averageRequestsPerMinute: {
        type: Number,
        default: 0.0,
      },
    },
    {
      timestamps: true, // Adds createdAt and updatedAt fields automatically
    }
  )
);

module.exports = APILog;
