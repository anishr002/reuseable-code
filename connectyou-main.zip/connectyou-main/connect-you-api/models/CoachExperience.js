const mongoose = require("mongoose");
const { Schema } = mongoose;

const CoachExperienceModal = new Schema(
  {
    coachId: mongoose.Schema.Types.ObjectId,
    organization: { type: String, required: true },
    position: { type: String, required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date },
    workingOn: { type: Boolean, default: false },
  },
  { timestamps: true }
);

const cretedModal = mongoose.model("CoachExperience", CoachExperienceModal);
module.exports = cretedModal;
