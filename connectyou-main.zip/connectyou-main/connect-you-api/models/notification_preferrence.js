const mongoose = require("mongoose");
const { Schema } = mongoose;

const notification_preferrencesSchema = new Schema(
  {
    entityId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      unique: true,
    },
    preferrences: {
      authentication: { type: Boolean, default: true },
      admin: { type: Boolean, default: true },
      promotion: { type: Boolean, default: true },
      bookings: { type: Boolean, default: true },
      alerts: { type: Boolean, default: true },
      payments: { type: Boolean, default: true },
      newsletter: { type: Boolean, default: true },
      systemUpdates: { type: Boolean, default: true },
      locationBased: { type: Boolean, default: true },
      others: { type: Boolean, default: true },
    },
    pauseAll: { type: Boolean, default: false },
  },
  { timestamps: true }
);

const notification_preferrences = mongoose.model(
  "notification_preferrences",
  notification_preferrencesSchema
);

const addOrUpdatenotification_preferrences = async ({
  entityId,
  preferrences,
  pauseAll = false,
}) => {
  try {
    const existingpreferrences = await notification_preferrences.findOne({
      entityId,
    });

    if (existingpreferrences) {
      existingpreferrences.preferrences = {
        ...existingpreferrences.preferrences,
        ...preferrences,
      };
      existingpreferrences.pauseAll = pauseAll;
      const data = await existingpreferrences.save();
      return {
        success: true,
        status: 200,
        message: "Updated Notification preferrence.",
        data: data,
        error: null,
      };
    } else {
      // Create new preferrences if none exist
      const newpreferrences = new notification_preferrences({
        entityId,
        preferrences,
        pauseAll,
      });
      const data = await newpreferrences.save();
      return {
        success: true,
        status: 200,
        message: "Updated Notification preferrence.",
        data: data,
        error: null,
      };
    }
  } catch (error) {
    console.error("Error adding or updating notification preferrences:", error);
    throw new Error("Error adding or updating notification preferrences");
  }
};

const fetchnotification_preferrences = async ({ entityId }) => {
  try {
    const preferrences = await notification_preferrences.findOne({ entityId });
    return preferrences
      ? {
          status: 200,
          success: true,
          message: "Notification Preferrences retrieved successfully",
          data: preferrences,
        }
      : {
          status: 404,
          success: true,
          message: "Notification Preferrences not found",
          data: null,
        };
  } catch (error) {
    console.error("Error fetching notification preferrences:", error);
    throw new Error("Internal Server Error Occurred");
  }
};

module.exports = {
  notification_preferrences,
  addOrUpdatenotification_preferrences,
  fetchnotification_preferrences,
};
