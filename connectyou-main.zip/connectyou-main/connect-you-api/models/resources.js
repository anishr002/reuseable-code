const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    title: { type: String, default: "" },
    description: { type: String, default: "" },
    availableFor: {
      type: String,
      enum: ["coach", "coachee", "all"],
      default: "all",
    },
  },
  { timestamps: true }
);

const resourceModel = mongoose.model("resource", createdSchema);
module.exports = resourceModel;
