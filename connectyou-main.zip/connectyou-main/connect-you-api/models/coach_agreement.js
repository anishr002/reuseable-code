const mongoose = require("mongoose");
const { coach_agreement_clausees_model } = require("./coach_agreement_clause");

const coach_aggreement = new mongoose.Schema(
  {
    coachId: {
      type: mongoose.Types.ObjectId,
      ref: "coach",
      unique: true,
      required: true,
    },
    dateOfSubmission: { type: Date },
    dateOfApproval: { type: Date },
    /// signed and uploaded by the coach for approval. ///
    agreement_file: { type: String },
    //  //admin fields // //
    approve: { type: Number, default: 0 },
    /// 0 for pending , 1 for approved , 2 for rejected, 3 for need to sign again ///
    status: { type: Number, default: 0 },
    // status 0 for not added by coach , 1 for pending and 2 for aprroval either aapproved or rejected.
    remarks: { type: String, default: "" },
    discontinue: { type: Number, default: 0 }, /// if 0 in term, 1 for discontinued ///
  },
  { timestamps: true }
);

const coach_agreement_model = mongoose.model(
  "coach_aggreement",
  coach_aggreement
);

const fetchAgreementStatus = async ({ coachId }) => {
  try {
    const [agreementStatus, original_agreement] = await Promise.all([
      coach_agreement_model.findOne({
        coachId: new mongoose.Types.ObjectId(coachId),
      }),
      coach_agreement_clausees_model.find({}),
    ]);

    if (!agreementStatus) {
      return {
        success: true,
        message: "No agreement record found",
        status: 200,
        data: null,
        error: null,
        agreement_file: original_agreement[0].file,
        original_agreement: original_agreement[0].file,
      };
    } else {
      return {
        success: true,
        message: "Coach agreement record retrieved!",
        status: 200,
        data: agreementStatus,
        original_agreement: original_agreement[0].file,
        agreement_file:
          agreementStatus.status === 2 && agreementStatus.approve === 0
            ? original_agreement[0].file
            : agreementStatus.agreement_file,
        error: null,
      };
    }
  } catch (error) {
    console.log(error);
    return {
      success: true,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error: error,
    };
  }
};

const approveCoachAgreement = async ({ _id, coachId }) => {
  try {
    const agreementStatus = await coach_agreement_model.updateOne(
      {
        _id: new mongoose.Types.ObjectId(_id),
        coachId: new mongoose.Types.ObjectId(coachId),
      },
      { $set: { approve: 1, dateOfApproval: new Date(), status: 2 } },
      { $upsert: true }
    );

    if (agreementStatus.matchedCount === 0) {
      return {
        success: false,
        message: "No agreement record found",
        status: 404,
        data: null,
        error: null,
      };
    }
    // console.log({ agreementStatus });

    return {
      success: true,
      message: "Coach agreement approved successfully!",
      status: 200,
      data: agreementStatus,
      error: null,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};

const rejectCoachAgreement = async ({ _id, coachId, remarks }) => {
  try {
    const agreementStatus = await coach_agreement_model.updateOne(
      {
        _id: new mongoose.Types.ObjectId(_id),
        coachId: new mongoose.Types.ObjectId(coachId),
      },
      { $set: { approve: 2, status: 2, remarks: remarks } },
      { $upsert: true }
    );
    // console.log({ agreementStatus });
    if (agreementStatus.matchedCount === 0) {
      return {
        success: false,
        message: "No agreement record found",
        status: 404,
        data: null,
        error: null,
      };
    }
    return {
      success: true,
      message: "Coach agreement rejected successfully!",
      status: 200,
      data: agreementStatus,
      error: null,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};
const revokeCoachAgreement = async ({ _id, coachId, remarks }) => {
  try {
    const agreementStatus = await coach_agreement_model.updateOne(
      {
        _id: new mongoose.Types.ObjectId(_id),
        coachId: new mongoose.Types.ObjectId(coachId),
      },
      { $set: { approve: 2, status: 2, remarks: remarks, discontinue: 1 } },
      { $upsert: true }
    );
    // console.log({ agreementStatus });
    if (agreementStatus.matchedCount === 0) {
      return {
        success: false,
        message: "No agreement record found",
        status: 404,
        data: null,
        error: null,
      };
    }
    return {
      success: true,
      message: "Coach agreement have been revoked successfully!",
      status: 200,
      data: agreementStatus,
      error: null,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};

const requestCoachAgreementapproval = async ({
  coachId,
  agreement_file_name,
}) => {
  try {
    const agreementStatus = await coach_agreement_model.findOneAndUpdate(
      { coachId },
      {
        $set: {
          status: 1,
          approve: 0,
          agreement_file: agreement_file_name,
          dateOfSubmission: new Date(),
        },
      },
      { new: true, upsert: true }
    );

    return {
      success: true,
      message: agreementStatus
        ? "Coach agreement updated successfully!"
        : "Coach agreement created successfully!",
      status: 200,
      data: agreementStatus,
      error: null,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};

const listAgreements = async ({ coachId }) => {
  try {
    const agreementStatus = await coach_agreement_model.aggregate({
      coachId: mongoose.Types.ObjectId.createFromHexString(coachId),
    });
    if (!agreementStatus) {
      return {
        success: false,
        message: "No agreement record found",
        status: 404,
        data: null,
        error: null,
      };
    } else {
      return {
        success: true,
        message: "Coach agreement record retrieved!",
        status: 200,
        data: agreementStatus,
        error: null,
      };
    }
  } catch (error) {
    console.log(error);
    return {
      success: true,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error: error,
    };
  }
};

const legalAggreementTerms = [
  {
    heading: "Scope of Agreement",
    content: [
      "ConnectYou provides a marketplace for accredited coaches to offer coaching services to clients.",
      "This Agreement governs the relationship between ConnectYou and the Coach, including service terms, compensation, and responsibilities.",
    ],
  },
  {
    heading: "Coach Eligibility & Responsibilities",
    content: [
      "The Coach must be ICF-accredited and maintain active credentials.",
      "The Coach agrees to deliver coaching sessions professionally and adhere to the ICF Code of Ethics.",
      "The Coach is responsible for updating availability, responding to client inquiries, and managing session schedules.",
    ],
  },
  {
    heading: "Commission & Payment Structure",
    content: [
      "For B2C clients, ConnectYou will deduct 20% of the session fee as a platform service charge. The remaining amount will be paid to the Coach.",
      "For B2B coaching engagements, a separate commission structure may apply, which will be communicated on a case-by-case basis.",
      "Coaches can withdraw their earnings at any time using the available withdrawal options.",
      "Coaches are responsible for any applicable withdrawal platform fees, if charged by the payment provider.",
      "If a client is eligible for a refund, the Coach's earnings will be adjusted accordingly based on the refund policy.",
    ],
  },
  {
    heading: "Session Management",
    content: [
      "Coaches can set their own session rates, subject to platform minimums and maximums.",
      "Coaches may reschedule or cancel sessions in accordance with ConnectYou’s cancellation policy.",
      "Coaches may not solicit clients off-platform or engage in direct transactions outside ConnectYou.",
    ],
  },
  {
    heading: "Termination & Modifications",
    content: [
      "Either party may terminate this Agreement with 7 days’ notice.",
      "ConnectYou reserves the right to update commission structures with prior notice to coaches.",
    ],
  },
  {
    heading: "Confidentiality & Data Protection",
    content: [
      "The Coach agrees to keep client information confidential and comply with GDPR and data privacy laws.",
      "ConnectYou will handle Coach payments and personal data securely.",
    ],
  },
  {
    heading: "Agreement Acceptance",
    content: [
      "By accepting this Agreement, the Coach acknowledges and agrees to comply with the terms outlined above.",
    ],
  },
];

const getAgreementList = async ({
  limit = 10,
  page = 1,
  searchTerm = "",
  filter = 3,
}) => {
  try {
    // Define the filter option for the agreement model
    let filterOption = {};

    // Apply the filter logic for the 'approve' status in the agreement model
    if (filter !== 3) {
      filterOption.approve = filter; // Filter by approved (1) or pending (0) agreements
    }

    // Aggregate query to fetch agreements
    const [agreementsData] = await coach_agreement_model.aggregate([
      {
        $match: filterOption, // Apply filterOption for the agreements model
      },
      {
        $lookup: {
          from: "coaches", // Coaches collection
          localField: "coachId", // Local field in agreement
          foreignField: "_id", // Foreign field in coaches collection
          as: "coachDetails", // Attach coach details to each agreement
        },
      },
      {
        $unwind: {
          path: "$coachDetails", // Flatten coachDetails
          preserveNullAndEmptyArrays: true, // Include agreements with no coach match
        },
      },
      {
        $match: {
          // Apply search term logic only on coach fields if searchTerm is provided
          $or: [
            {
              "coachDetails.email": {
                $regex: `.*${searchTerm.trim()}.*`,
                $options: "i",
              },
            },
            {
              "coachDetails.name": {
                $regex: `.*${searchTerm.trim()}.*`,
                $options: "i",
              },
            },
            {
              "coachDetails.Lname": {
                $regex: `.*${searchTerm.trim()}.*`,
                $options: "i",
              },
            },
            {
              "coachDetails.gender": {
                $regex: `.*${searchTerm.trim()}.*`,
                $options: "i",
              },
            },
          ],
        },
      },
      {
        $project: {
          // Include all agreement fields (you can list specific ones if needed)
          _id: 1,
          dateOfSubmission: 1,
          dateOfApproval: 1,
          agreement_file: 1,
          approve: 1,
          status: 1,
          remarks: 1,
          discontinue: 1,
          createdAt: 1,
          "coachDetails._id": 1,
          "coachDetails.email": 1,
          "coachDetails.name": 1,
          "coachDetails.Lname": 1,
          "coachDetails.gender": 1,
          "coachDetails.image": 1,
        },
      },
      { $sort: { createdAt: -1 } },
      {
        $facet: {
          agreements: [
            { $skip: (page - 1) * limit }, // Skip based on pagination
            { $limit: limit }, // Limit the number of results
          ],
          totalCount: [
            { $count: "totalCount" }, // Count the total number of agreements
          ],
        },
      },
    ]);

    const totalCount =
      agreementsData.totalCount.length > 0
        ? agreementsData.totalCount[0].totalCount
        : 0;
    const totalPages = Math.ceil(totalCount / limit);

    return {
      success: true,
      message: "Agreements fetched successfully!",
      status: 200,
      data: agreementsData.agreements,
      error: null,
      totalPages,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};

module.exports = {
  fetchAgreementStatus,
  approveCoachAgreement,
  rejectCoachAgreement,
  requestCoachAgreementapproval,
  listAgreements,
  coach_agreement_model,
  legalAggreementTerms,
  revokeCoachAgreement,
  getAgreementList,
};
