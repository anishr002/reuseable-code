const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ShortlistSchema = new Schema(
  {
    status: {
      type: Boolean,
      default: true,
    },
    coachId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "coach",
      required: true,
      index: true,
    },
    email: {
      type: String,
      required: true,
    },
    companyName: { type: String, default: "" },
  },
  { timestamps: true }
);

// Static method to set status to false
ShortlistSchema.statics.deshortlist = async function (coachId) {
  return this.findOneAndUpdate({ coachId }, { status: false }, { new: true });
};

const ShortlistsModel = mongoose.model("shortlist", ShortlistSchema);

module.exports = ShortlistsModel;
