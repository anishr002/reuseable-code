const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    resourceId: { type: mongoose.Schema.Types.ObjectId, ref: "resource" },
    title: { type: String, default: "" },
    description: { type: String, default: "" },
    thumbnailImage: { type: String, default: "" },
    pdfFile: { type: String, default: "" },
  },
  { timestamps: true }
);

const resource_Module_Model = mongoose.model("resources_module", createdSchema);
module.exports = resource_Module_Model;
