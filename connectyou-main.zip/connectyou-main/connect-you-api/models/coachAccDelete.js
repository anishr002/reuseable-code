const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId, ref: "coach" },
    reason: { type: [String], default: [] },
    message: { type: String, default: "" },
  },
  { timestamps: true }
);

const createdModal = mongoose.model("coachAccDelete", createdSchema);
module.exports = createdModal;
