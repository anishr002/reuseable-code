const mongoose = require("mongoose");
const { Schema } = mongoose;

const SchemaModal = new Schema(
  {
    dataSource: {
      type: String,
      enum: ["HUBSPOT", "CSV-File"],
      default: "CSV-File",
    },
    entry_type: {
      type: String,
      enum: ["Bulk_Coach_Entry", "Bulk_Coachee_Entry"],
    },
    result: { type: String, enum: ["Success", "Partial Success", "Failure"] },
    successFilepath: { type: String },
    failureFilepath: { type: String },
    successCount: { type: Number },
    failureCount: { type: Number },
    hub_list_ID: { type: String, default: "" },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId },
  },
  { timestamps: true }
);

const bulk_users_entry_Model = mongoose.model("bulk_users_entry", SchemaModal);

const createBulkEntryRecord = async ({
  dataSource = "CSV-File",
  entry_type,
  result,
  successFilepath,
  failureFilepath,
  successCount,
  failureCount,
  uploadedBy,
  hub_list_ID = "",
}) => {
  try {
    const entry = await bulk_users_entry_Model.create({
      dataSource,
      entry_type,
      result,
      successFilepath,
      failureFilepath,
      successCount,
      failureCount,
      uploadedBy,
      hub_list_ID,
    });
    return !!entry;
  } catch (error) {
    console.error("Error creating bulk entry record:", error);
    return false;
  }
};

module.exports = { bulk_users_entry_Model, createBulkEntryRecord };
