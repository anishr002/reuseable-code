const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    title: { type: String, default: "" },
    description: { type: String, default: "" },
  },
  { timestamps: true }
);

const createdModal = mongoose.model("coachee_resource", createdSchema);
module.exports = createdModal;
