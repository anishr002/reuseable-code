const mongoose = require("mongoose");

const chatroom = new mongoose.Schema(
  {
    userId1: { type: mongoose.Schema.Types.ObjectId },
    userId2: { type: mongoose.Schema.Types.ObjectId },
  },
  { timestamps: true }
);

const chatRoomModel = mongoose.model("chatRoom", chatroom);
module.exports = chatRoomModel;
