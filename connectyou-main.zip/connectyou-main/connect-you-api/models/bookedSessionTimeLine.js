const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    bookedSessionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "booked_session",
    },
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      default: "000000000000000000000000",
    },
    // userId: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "user",
    //   default: "",
    // },
    // coachId: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "coach",
    //   default: "",
    // },
    // sessionId: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "booked_session",
    //   default: "",
    // },
    action: { type: String, default: "" },
    message: { type: String, default: "" },
    actionBy: { type: String, default: "" },
  },
  {
    timestamps: true,
  }
);

const bookedSessionTimelineModel = mongoose.model(
  "booked_session_timeline",
  createdSchema
);

const saveTimelineEntry = async (entryData) => {
  try {
    const newEntry = new bookedSessionTimelineModel(entryData);
    const savedEntry = await newEntry.save();
    return { success: true, data: savedEntry };
  } catch (error) {
    console.error("Error saving timeline entry:", error);
    return { success: false, error: error.message || "Failed to save entry" };
  }
};

const getTimelineByMatch = async (match = {}) => {
  try {
    const results = await bookedSessionTimelineModel
      .find(match)
      .sort({ createdAt: -1 }); // newest first
    return { success: true, data: results };
  } catch (error) {
    console.error("Error fetching timeline entries:", error);
    return {
      success: false,
      error: error.message || "Failed to fetch entries",
    };
  }
};

module.exports = {
  bookedSessionTimelineModel,
  saveTimelineEntry,
  getTimelineByMatch,
};
