const mongoose = require("mongoose");
const { Schema } = mongoose;

const SchemaModal = new Schema(
  {
    name: { type: String, rdefault: "ConectYou Admin" },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true, minlength: 8 },
    address: { type: String, default: "" },
  },
  { timestamps: true }
);

const adminModal = mongoose.model("admin", SchemaModal);
module.exports = adminModal;
