const mongoose = require("mongoose");
const Schema = new mongoose.Schema(
  {
    data: { type: String },
  },
  { timestamps: true }
);
const cookiePoliciesModel = mongoose.model("cookie-policies", Schema);

// Function to update a cookie Policies by ID
const addUpdateCookiePolicies = async (text) => {
  try {
    const data = await cookiePoliciesModel.findOneAndUpdate(
      {},
      { $set: { data: text } },
      {
        new: true,
        upsert: true,
      }
    );
    if (data) {
      return { success: true, data, message: "Updated cookie Policies" };
    } else {
      return {
        success: false,
        data: null,
        message: "cookie Policies not found",
      };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Some Error occurred " };
  }
};

// Function to list all Terms and Conditions
const listCookiePolicies = async () => {
  try {
    const data = await cookiePoliciesModel.find();
    if (data) {
      return { success: true, data, message: "Retrieved cookie policies" };
    } else {
      return {
        success: false,
        data: null,
        message: "No cookie policies found",
      };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Some Error occurred " };
  }
};

module.exports = {
  cookiePoliciesModel,
  addUpdateCookiePolicies,
  listCookiePolicies,
};
