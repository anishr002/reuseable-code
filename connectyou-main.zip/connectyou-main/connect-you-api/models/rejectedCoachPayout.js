const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId },
    transferId: { type: String },
    transfer_transactionId: { type: String },
    transfer_destination: { type: String },
    transfer_destination_paymentId: { type: String },
    amount: { type: Number },
    currency: { type: String },
    //bank details
    bankId: { type: String },
    bankName: { type: String },
    banklast4: { type: String },
    bankFingerprint: { type: String },
    reqAccount: { type: String },
    status: { type: Number, default: 2 },
  },
  { timestamps: true }
);

const RejectedCoachPayoutModel = mongoose.model(
  "rejected-coach-payout",
  createdSchema
);
module.exports = RejectedCoachPayoutModel;
