const mongoose = require("mongoose");

const Schema = new mongoose.Schema({
  coachId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "coach",
    required: true,
  },
  bankAccountID: { type: String, default: "" },
  bankAccount_holder_name: { type: String, default: "" },
  bankAccount_routing_number: { type: String, default: "" },
  bankAccount_account_number: { type: String, default: "" },
  bankAccount_Replaced_Date: { type: Date, default: Date.now },
});

const CoachBankAccountChangeModel = mongoose.model(
  "coach_bank_account_update",
  Schema
);

const addCoachAccountChangeHistory = async ({
  coachId,
  bankAccountID,
  bankAccount_holder_name,
  bankAccount_routing_number,
  bankAccount_account_number,
}) => {
  try {
    const data = await CoachBankAccountChangeModel.create({
      coachId,
      bankAccountID,
      bankAccount_holder_name,
      bankAccount_routing_number,
      bankAccount_account_number,
    });
    if (data) {
      return { success: true, data };
    } else {
      return { success: false, data: null };
    }
  } catch (error) {
    return { success: false, data: null };
    console.log(error);
  }
};

module.exports = { CoachBankAccountChangeModel, addCoachAccountChangeHistory };
