const CoachModel = require("./coach");
const mongoose = require("mongoose");
const {
  CreateNotification,
  CreateAdminLevelNotification,
} = require("./notificationModal");
const requestSchema = new mongoose.Schema({
  coach_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "coach",
    required: true,
  },
  requestedOn: { type: Date, default: Date.now },
  requestStatus: {
    type: String,
    enum: ["Pending", "Approved", "Declined", "Expired"],
    default: "Pending",
  },
  reqClosed: {
    type: Number,
    default: 0,
    required: true,
  },
  reqClosedOn: {
    type: Date,
    default: null, // Initially, this can be null until the request is closed
  },
  rejectionNotes: { type: String, default: null },
  idealTime: { type: Number, default: 0 }, // Duration in milliseconds
});

// Mongoose pre-save middleware to automatically set `reqClosed` and `reqClosedOn`
requestSchema.pre("save", function (next) {
  // If requestStatus has changed from "Pending" to another status
  if (this.isModified("requestStatus") && this.requestStatus !== "Pending") {
    this.reqClosed = 1;
    if (!this.reqClosedOn) {
      this.reqClosedOn = Date.now();
    }
  }
  // Ensure `reqClosedOn` is set when `reqClosed` is updated to 1
  if (
    this.isModified("reqClosed") &&
    this.reqClosed === 1 &&
    !this.reqClosedOn
  ) {
    this.reqClosedOn = Date.now();
  }

  if (this.isModified("reqClosed")) {
    this.idealTime = this.reqClosedOn - this.requestedOn;
  } // Duration in milliseconds
  next();
});

const coachProfileApReqModal = mongoose.model(
  "coachProlifeApprovalReq",
  requestSchema
);

const createApprovalReqest = async ({ coach_id }) => {
  try {
    const prevReqs = await getPreviousOpenReqs({ coach_id });
    if (prevReqs.data.length > 0) {
      await closePreviousReqs({ coach_id });
    }
    const newReq = await coachProfileApReqModal.create({ coach_id });
    const coach = await CoachModel.findOne({ _id: coach_id }).select("name");
    if (!newReq) {
      return { success: false, data: null };
    } else {
      await Promise.all([
        CreateNotification({
          heading: "Profile has been submitted for review.",
          description:
            "Coach Your profile has been submitted for the approval from the adminstrator, you will receive a notification upon approval thanks !",
          url: "/c/profile",
          user_id: coach_id,
        }),
        CreateAdminLevelNotification({
          heading: `A Coach is awaiting approval`,
          description: `Coach ${coach.name} have requested for the profile approval, to see ore information click on the view button.`,
          url: `/coach/detail/${coach_id}`,
        }),
      ]);
      return { success: true, data: newReq };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

const acceptApprovalReqeust = async ({ req_id, coach_id }) => {
  try {
    const request = await coachProfileApReqModal.findById(req_id);
    if (!request) {
      return { success: false, message: "Request not found" };
    }
    request.requestStatus = "Approved";
    request.reqClosed = 1;
    const reqUpdate = await request.save();
    const coachUpdate = await CoachModel.updateOne(
      { _id: coach_id },
      { $set: { approve: 1 } }
    );

    return { success: true, data: { coachUpdate, reqUpdate } };
  } catch (error) {
    console.error(error);
    return { success: false, data: null };
  }
};

const rejectApprovalRequest = async ({ coach_id, req_id, note }) => {
  try {
    const request = await coachProfileApReqModal.findById(req_id);
    if (!request) {
      return { success: false, message: "Request not found" };
    }
    request.requestStatus = "Declined";
    request.rejectionNotes = note;
    request.reqClosed = 1;
    const reqUpdate = await request.save();
    const coachUpdate = await CoachModel.updateOne(
      { _id: coach_id },
      { $set: { approve: 0 } }
    );
    await CreateNotification({
      heading: "Profile was not approved coach.",
      description: request.rejectionNotes,
      url: "/c/profile",
      user_id: coach_id,
    });
    return { success: true, data: { coachUpdate, reqUpdate } };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

const getPreviousOpenReqs = async ({ coach_id }) => {
  try {
    const match = {
      coach_id,
      requestStatus: { $ne: "Approved" },
      reqClosed: { $ne: 1 },
    };
    const openReqs = await coachProfileApReqModal.find(match);
    return { success: true, data: openReqs };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};
const closePreviousReqs = async ({ coach_id }) => {
  try {
    const match = {
      coach_id,
      requestStatus: { $ne: "Approved" },
      reqClosed: { $ne: 1 },
    };
    const requestsToExpire = await coachProfileApReqModal.find(match);

    // Update each request individually to trigger middleware
    const previousReqsClosed = await Promise.all(
      requestsToExpire.map(async (req) => {
        req.requestStatus = "Expired";
        await req.save();
        return req;
      })
    );
    return { success: true, data: previousReqsClosed };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

//for admin //
const approvvalReqHistory = async ({ limit, skip }) => {
  try {
    const openReqs = await coachProfileApReqModal.aggregate([
      {
        $lookup: {
          from: "coaches", // The target collection to join with
          localField: "coach_id", // Field from `coachProfileApReqModal`
          foreignField: "_id", // Field from `coach` collection
          as: "coachInfo", // The field that will contain the resulting array from the join
        },
      },
      {
        $unwind: {
          // If each `coachProfileApReqModal` document matches exactly one `coach` document
          path: "$coachInfo", // This will flatten the `coachInfo` array into an object
          preserveNullAndEmptyArrays: true, // If no match, `coachInfo` will be null (optional)
        },
      },
      {
        $project: {
          // Project the desired fields
          _id: 1,
          // Include the _id of the coachProfileApReqModal document
          name: "$coachInfo.name",
          Lname: "$coachInfo.Lname",
          email: "$coachInfo.email",
          emailVerified: "$coachInfo.emailVerified",
          gender: "$coachInfo.gender",
          approve: "$coachInfo.approve",
          requestedOn: 1, // From the `coachProfileApReqModal` collection
          coach_id: 1,
          reqClosedOn: 1,
          requestStatus: 1,
          idealTime: 1,
        },
      },
      {
        $sort: { requestedOn: -1 }, // Sort by requestedOn in descending order (newest first)
      },
      {
        $skip: Number(skip), // Skip the number of documents as per pagination
      },
      {
        $limit: Number(limit), // Limit the number of documents returned
      },
    ]);

    const totalPages = Math.ceil(
      (await coachProfileApReqModal.countDocuments()) / limit
    );
    return { success: true, data: openReqs, totalPages };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

const getApproalReqs = async ({ skip, limit, searchTerm }) => {
  try {
    const match = {
      requestStatus: { $eq: "Pending" },
      reqClosed: { $eq: 0 },
    };

    let lookupStage = {
      from: "coaches", // The target collection to join with
      localField: "coach_id", // Field from `coachProfileApReqModal`
      foreignField: "_id", // Field from `coach` collection
      as: "coachInfo", // The field that will contain the resulting array from the join
    };

    if (searchTerm && searchTerm.trim() !== "") {
      const escapedSearchTerm = searchTerm
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      lookupStage.pipeline = [
        {
          $match: {
            $or: [
              { email: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
              { name: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
              { Lname: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
              { gender: { $regex: `.*${escapedSearchTerm}.*`, $options: "i" } },
            ],
          },
        },
      ];
    }
    const openReqs = await coachProfileApReqModal.aggregate([
      {
        $match: match, // First, apply the match condition as you did before
      },
      {
        $lookup: lookupStage,
      },
      {
        $unwind: {
          path: "$coachInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          coachInfo: { $ne: null }, // Only include documents where coachInfo is not null
        },
      },
      {
        $project: {
          _id: 1,
          name: "$coachInfo.name",
          Lname: "$coachInfo.Lname",
          email: "$coachInfo.email",
          emailVerified: "$coachInfo.emailVerified",
          gender: "$coachInfo.gender",
          approve: "$coachInfo.approve",
          requestedOn: 1,
          coach_id: 1,
        },
      },
      {
        $sort: { requestedOn: -1 }, // Sort by requestedOn in descending order (newest first)
      },
      {
        $skip: Number(skip), // Skip the number of documents as per pagination
      },
      {
        $limit: Number(limit), // Limit the number of documents returned
      },
    ]);
    const totalPages = Math.ceil(
      (await coachProfileApReqModal.countDocuments({ reqClosed: 0 })) / limit
    );

    return { success: true, data: openReqs, totalPages };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

module.exports = {
  coachProfileApReqModal,
  acceptApprovalReqeust,
  getPreviousOpenReqs,
  approvvalReqHistory,
  createApprovalReqest,
  closePreviousReqs,
  rejectApprovalRequest,
  getApproalReqs,
};
