const mongoose = require("mongoose");

const chatmessage = new mongoose.Schema(
  {
    senderId: mongoose.Schema.Types.ObjectId,
    receiverId: mongoose.Schema.Types.ObjectId,
    chatRoomId: mongoose.Schema.Types.ObjectId,
    message: { type: String, default: "" },
    files: { type: [String], default: [] },
    readByCoach: { type: Number, default: 0 }, //0 for not 1 for read
    readByUser: { type: Number, default: 0 }, //0 for not 1 for read
    messageReadStatusCoach: {
      type: String,
      enum: ["read", "delivered", "sent", "failed", ""],
      default: "sent",
    },
    messageReadStatusUser: {
      type: String,
      enum: ["read", "delivered", "sent", "failed", ""],
      default: "sent",
    },
  },
  { timestamps: true }
);

const chatMessageModel = mongoose.model("chatMessage", chatmessage);
module.exports = chatMessageModel;
