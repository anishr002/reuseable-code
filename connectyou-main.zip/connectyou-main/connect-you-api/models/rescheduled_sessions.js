const mongoose = require("mongoose");
const { Schema } = mongoose;

const creaedSchema = new Schema(
  {
    bookingId: mongoose.Schema.Types.ObjectId,
    bookedSessionId: mongoose.Schema.Types.ObjectId,
    userId: mongoose.Schema.Types.ObjectId,
    coachId: mongoose.Schema.Types.ObjectId,
    coachTimeZone: { type: String, default: "" },
    sessionDate: Date,
    rescheduledBy: { type: String, default: "" }, //user || coach
    message: { type: String, default: "" },
  },
  { timestamps: true }
);

const createdModal = mongoose.model("rescheduled_sessions", creaedSchema);
module.exports = createdModal;
