const mongoose = require("mongoose");
const Schema = new mongoose.Schema(
  {
    data: { type: String },
  },
  { timestamps: true }
);
const TermsAndConditionModel = mongoose.model("terms_conditions", Schema);

// Function to update a Terms and Conditions by ID
const addUpdateTermCon = async (text) => {
  try {
    const data = await TermsAndConditionModel.findOneAndUpdate(
      {},
      { $set: { data: text } },
      {
        new: true,
        upsert: true,
      }
    );
    if (data) {
      return { success: true, data, message: "Updated Terms and Conditions" };
    } else {
      return {
        success: false,
        data: null,
        message: "Terms and Conditions not found",
      };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Some Error occurred " };
  }
};

// Function to list all Terms and Conditions
const listTermCon = async () => {
  try {
    const data = await TermsAndConditionModel.find();
    if (data) {
      return { success: true, data, message: "Retrieved Terms and Conditions" };
    } else {
      return {
        success: false,
        data: null,
        message: "No Terms and Conditions found",
      };
    }
  } catch (error) {
    console.log(error);
    return { success: false, data: null, message: "Some Error occurred " };
  }
};

module.exports = {
  TermsAndConditionModel,
  listTermCon,
  addUpdateTermCon,
};
