const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    resourceId: mongoose.Schema.Types.ObjectId,
    description: { type: String, default: "" },
    image: { type: String, default: "" },
  },
  { timestamps: true }
);

const createdModal = mongoose.model("coach_resource_section", createdSchema);
module.exports = createdModal;
