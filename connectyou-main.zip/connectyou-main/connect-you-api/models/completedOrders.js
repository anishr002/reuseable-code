const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId },
    orderId: { type: mongoose.Schema.Types.ObjectId },
    chargeId: { type: String },
    amount: { type: Number },
    orderAmount: { type: Number },
    currency: { type: String },
    platformFee: { type: Number, default: 0 },
    platformFeePaid: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

const completedOrdersModel = mongoose.model("completedOrders", createdSchema);
module.exports = completedOrdersModel;
