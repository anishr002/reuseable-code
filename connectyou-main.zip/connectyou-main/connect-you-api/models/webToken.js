const mongoose = require("mongoose");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    userId: mongoose.Schema.Types.ObjectId,
    userType: String,
    deviceId: String,
    deviceToken: String,
  },
  { timestamps: true }
);

const createdModal = mongoose.model("web-token", createdSchema);
module.exports = createdModal;
