const mongoose = require("mongoose");
const adminModal = require("./admin");

const indexFile = require("../index");
const {
  fetchnotification_preferrences,
} = require("./notification_preferrence");

const NotificationSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId },
    heading: { type: String },
    description: { type: String },
    url: { type: String },
    readStatus: { type: Boolean, default: false }, // true for read and false for unread
    notification_type: {
      type: String,
      enum: [
        "authentication",
        "admin",
        "promotion",
        "bookings",
        "alerts",
        "payments",
        "newsletter",
        "systemUpdates",
        "locationBased",
        "others",
      ],
      required: true,
    }, // Type of notification
  },
  { timestamps: true }
);

const NotificationModel = mongoose.model("notification", NotificationSchema);

/**
 * 
 * @param type =  "authentication",
        "admin",
        "promotion",
        "bookings",
        "alerts",
        "payments",
        "newsletter",
        "systemUpdates",
        "locationBased",
        "others",} param0 
 *
 */
const CreateNotification = async ({
  user_id,
  heading,
  description,
  url,
  notification_type = "others",
}) => {
  // console.log({ "Incoming notification create req:": heading });
  try {
    const userPreferrence = await fetchnotification_preferrences({
      entityId: user_id,
    });
    if (userPreferrence.data) {
      /*   if notification_type is set to false in this data then dont 
      create that notification else create one .
      data: {entityId:string,
      pauseAll : boolean ,
      preferrences : {
        admin: false;
        alerts: false;
        authentication: false;
        bookings: false;
        locationBased: false;
        newsletter: false;
        payments: false;
        promotion: false;
        socialMedia: false;
        systemUpdates: false;
      }} */
      const preferrences = userPreferrence.data.preferrences;
      const pauseAll = userPreferrence.data.pauseAll;
      if (pauseAll) {
        // console.log("User have paused all the Notifications");
        return {
          success: false,
          message: `User have paused all the Notifications.`,
        };
      }
      if (preferrences[notification_type] === false) {
        // console.log( `Notifications for ${notification_type} are disabled by the user.`);
        return {
          success: false,
          message: `Notifications for ${notification_type} are disabled by the user.`,
        };
      }
    }

    const newNotifi = await NotificationModel.create({
      user_id,
      heading,
      description,
      url,
      notification_type,
    });

    if (!newNotifi) {
      return {
        success: false,
        notification: null,
        message: "Error While creating notification",
      };
    } else {
      await indexFile.emitNewNotification({
        listener_id: user_id,
        data: newNotifi,
      });
      return {
        success: true,
        notification: newNotifi,
        message: "Notification Created",
      };
    }
  } catch (error) {
    console.log(error);
    return { success: false, message: error.message };
  }
};

const ReadNotification = async ({ _id }) => {
  try {
    const notifi = await NotificationModel.updateOne(
      { _id },
      { $set: { readStatus: true } }
    );
    if (!notifi) {
      return { success: false, message: "Unable to mark as read" };
    } else return { success: true, message: "Notification marked as Read." };
  } catch (error) {
    console.log(error);
    return { success: false, message: error.message };
  }
};

const DeletedNotification = async ({ _id }) => {
  try {
    const notifi = await NotificationModel.deleteOne({ _id });
    if (!notifi) {
      return { success: false, message: "Unable to Delete notification" };
    } else
      return { success: true, message: "Notification deletion successful." };
  } catch (error) {
    console.log(error);
    return { success: false, message: error.message };
  }
};

const GetUsersNotification = async ({
  _id,
  limit = 10,
  page = 1,
  filter = 0,
}) => {
  try {
    const skip = Number(limit) * Number(page) - Number(limit);
    const ObjectId = require("mongoose").Types.ObjectId;
    const matchPipe = { user_id: new ObjectId(_id) };
    if (Number(filter) === 1) {
      matchPipe.readStatus = false;
    } else if (Number(filter) === 2) {
      matchPipe.readStatus = true;
    }

    const [Notifications, totalEnteries, totalPages, unreadNotifications] =
      await Promise.all([
        NotificationModel.aggregate([
          { $match: matchPipe },
          { $sort: { createdAt: -1 } },
          { $skip: Number(skip) },
          { $limit: Number(limit) },
        ]),
        NotificationModel.countDocuments({ user_id: new ObjectId(_id) }),
        NotificationModel.countDocuments(matchPipe).then((count) =>
          Math.ceil(count / Number(limit))
        ),
        NotificationModel.countDocuments({ user_id: _id, readStatus: false }),
      ]);
    return {
      success: true,
      Notifications,
      totalPages,
      unreadNotifications,
      totalEnteries,
    };
  } catch (error) {
    console.log(error);
    return { success: false, message: error.message };
  }
};

const CreateForgetPasswordReqNotification = async ({ user_id }) => {
  const heading = "A Password reset request was sent for your account.";
  const description =
    "A password reset request was sent for your account, if it was you, please ignore. If you have any concerns, Please feel free to contact us.";
  const url = "/get-in-touch";
  const make = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "authentication",
  });
  return { success: make.success };
};

const CreatePasswordResetNotification = async ({ user_id }) => {
  const heading = "Your account password has been reset.";
  const description =
    "Your account password has been updated successfully. You can continue using the new password.If this was not you, Please feel free to contact us.";
  const url = "/get-in-touch";
  const make = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "authentication",
  });
  return { success: make.success };
};

const CreateUserLoginNotification = async ({ user_id }) => {
  const heading = "Your account was logged in.";
  const description = `Your account was logged in on a device. Please ignore if it was you, Feel free to contact us for support.`;
  const url = "/get-in-touch";
  const make = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "authentication",
  });
  return { success: make.success };
};

const WaringLoginNotification = async ({ user_id }) => {
  try {
    const heading = "Someone tried to login your account";
    const description = `Some one was trying to access into your account with incorrect password, Please ignore if it was you, Feel free to contact us for support.`;
    const url = "/get-in-touch";
    const make = await CreateNotification({
      user_id,
      heading,
      description,
      url,
      notification_type: "authentication",
    });
    return { success: make.success };
  } catch (error) {
    console.log(error);
    return { success: false };
  }
};

const CreateWelcomeNotification = async ({ user_id }) => {
  const heading =
    "Congratulations, Your account has been registered with ConnectYou.";
  const description = `Your account is now registered. You can explore more features now. Please verify your email, in the profile section, if allready confirmed please ignore.`;
  const url = "/";
  const make = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "promotion",
  });
  return { success: make.success };
};

const CreateBookingNotification = async ({ user_id, type, endp }) => {
  const heading = "Booking Confirmed !";
  const description = `A booking has been successfully confirmed, have a look by clicking on view button`;
  const url = `${endp}`;
  const make = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "bookings",
  });
  return { success: make.success };
};

const CreateBookingUpdateNotification = async ({
  user_id,
  type,
  endp,
  heading,
  description,
}) => {
  const url = `/${type}/booking/${endp}`;
  const make = await CreateNotification({
    user_id,
    heading,
    description,
    url,
    notification_type: "bookings",
  });
  return { success: make.success };
};

// for admins

const CreateAdminLevelNotification = async ({
  heading,
  description,
  url,
  notification_type = "admin",
}) => {
  try {
    const admin = await adminModal.find().select("_id");
    const id = admin[0]?._id || "";
    if (id && id !== "") {
      const newNotiication = await CreateNotification({
        user_id: id,
        heading,
        description,
        url,
        notification_type,
      });
      return { success: true, data: newNotiication, notification_type };
    } else
      return {
        success: false,
        data: null,
      };
  } catch (error) {
    console.log(error);
    return { success: false, data: null };
  }
};

const listenToNewAlerts = async ({ data, socket, io }) => {
  try {
    const listener_id = data._id;
    if (socket.rooms.has(listener_id)) {
      return;
    }
    socket.join(listener_id);
    const responce = {
      success: true,
      listener_id: listener_id,
      message: "Listening to new notification alerts",
    };
    return io.to(listener_id).emit("listening-to-alerts", responce);
  } catch (error) {
    console.log(error);
  }
};

const MarkAllAsRead = async ({ entityId }) => {
  try {
    const changes = await NotificationModel.updateMany(
      { user_id: entityId },
      { $set: { readStatus: true } },
      { $upsert: true }
    );
    console.log({ changes, entityId });
    if (changes.acknowledged) {
      return {
        success: true,
        message: "All user notifications marked as read.",
        data: changes,
      };
    } else
      return {
        success: false,
        message: "There was some error marking the notifications as read.",
        data: null,
      };
  } catch (error) {
    console.error(error);
    return { success: false, message: "Internal server error", data: null };
  }
};

module.exports = {
  NotificationModel,
  listenToNewAlerts,
  CreateNotification,
  ReadNotification,
  DeletedNotification,
  GetUsersNotification,
  CreateForgetPasswordReqNotification,
  CreatePasswordResetNotification,
  CreateUserLoginNotification,
  CreateWelcomeNotification,
  CreateBookingNotification,
  CreateBookingUpdateNotification,
  CreateAdminLevelNotification,
  WaringLoginNotification,
  MarkAllAsRead,
};
