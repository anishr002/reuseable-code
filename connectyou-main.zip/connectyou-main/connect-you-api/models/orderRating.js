const mongoose = require("mongoose");
const { notifyReviewAdded } = require("../lib/notifyReviewUpdate");
const { Schema } = mongoose;

const createdSchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId, ref: "coach" },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
    bookingId: { type: mongoose.Schema.Types.ObjectId, ref: "booked_session" }, // from booked_session model / Id.
    orderId: { type: mongoose.Schema.Types.ObjectId, ref: "booking" }, // from booking model
    ratingNumber: { type: Number, default: 0 },
    title: { type: String, default: "" },
    remarks: { type: String, default: "" },
    deleted: { type: Number, default: 0 }, //0 for active 1 for deleted
  },
  { timestamps: true }
);

createdSchema.post("save", async function (doc, next) {
  try {
    console.log("✅ Rating saved successfully:", {
      doc: doc._id,
      by: doc.userId,
    });
    notifyReviewAdded({ reviewDoc: doc, type: "added" });
    next();
  } catch (err) {
    console.error("Error in post-save hook:", err);
    next(err);
  }
});

createdSchema.post("updateOne", async function (res, next) {
  try {
    const filter = this.getFilter(); 
    const updatedDoc = await this.model.findOne(filter);
    if (updatedDoc) {
      notifyReviewAdded({ reviewDoc: updatedDoc, type: "updated" });
    }
    next();
  } catch (err) {
    console.error("Error in post-updateOne hook:", err);
    next(err);
  }
});

// createdSchema.post(
//   "deleteOne",
//   { document: false, query: true },
//   async function (res, next) {
//     try {
//       const filter = this.getFilter();
//       const deletedDoc = await this.model.findOne(filter).lean(); 
//       if (deletedDoc) {
//         notifyReviewAdded({ reviewDoc: deletedDoc, type: "deleted" });
//       }
//       next();
//     } catch (err) {
//       console.error("Error in post-deleteOne hook:", err);
//       next(err);
//     }
//   }
// );

const reviewModel = mongoose.model("orders-rating", createdSchema);
module.exports = reviewModel;
