const mongoose = require("mongoose");

const FailedLoginAttemptSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId, required: true },
    failedAttempts: {
      type: [String],
      default: [],
    },
  },
  { timestamps: true }
);

FailedLoginAttemptSchema.index({ createdAt: 1 }, { expireAfterSeconds: 3600 });

const FailedLoginModal = mongoose.model(
  "failedLoginAttempt",
  FailedLoginAttemptSchema
);

module.exports = FailedLoginModal;
