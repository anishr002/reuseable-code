const mongoose = require("mongoose");

const coach_aggreement_clauses = new mongoose.Schema(
  {
    dateOfRevision: { type: Date },
    file: { type: String },
  },
  { timestamps: true }
);

const coach_agreement_clausees_model = mongoose.model(
  "coach_aggreement_clause",
  coach_aggreement_clauses
);

const updateAgreementClause = async ({ file }) => {
  try {
    const updatedAgreement =
      await coach_agreement_clausees_model.findOneAndUpdate(
        {}, // No filter → It will update the first document found
        { $set: { file, dateOfRevision: new Date() } }, // Update file & revision date
        { upsert: true, new: true } // Create if not found, return updated doc
      );
    return {
      success: true,
      message: "Agreement updated successfully!",
      status: 200,
      data: updatedAgreement,
      error: null,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};

const getAgreement = async () => {
  try {
    const agreement = await coach_agreement_clausees_model.findOne({});
    if (agreement)
      return {
        success: true,
        message: "Agreement fetched successfully!",
        status: 200,
        data: agreement,
        error: null,
      };
    else {
      return {
        success: true,
        message: "Agreement not found !",
        status: 404,
        data: null,
        error: null,
      };
    }
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "Internal server error occurred!",
      status: 500,
      data: null,
      error,
    };
  }
};



module.exports = {
  coach_agreement_clausees_model,
  updateAgreementClause,
  getAgreement,
};
