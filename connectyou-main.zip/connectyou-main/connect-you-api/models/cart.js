const mongoose = require("mongoose");
const { Schema } = mongoose;

const cartSchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId },
    sessionId: { type: mongoose.Schema.Types.ObjectId },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      default: "000000000000000000000000",
    },
    sessionDate: Date,
    cartId: String,
    expired: { type: Boolean, default: false },
    createdAt: {
      type: Date,
      default: Date.now,
      expires: 1200,
    },
  },
  { timestamps: true }
);

const cartModel = mongoose.model("cart", cartSchema);

module.exports = cartModel;
