const cron = require("node-cron");
const mongoose = require("mongoose");
const { CreateNotification } = require("./notificationModal");
const { Schema } = mongoose;
const userModel = require("./user");
const CoachModel = require("./coach");
const completedOrders = require("./completedOrders");
const bookingModal = require("./booking");
const moment = require("moment-timezone");

const creaedSchema = new Schema(
  {
    // ceonnected docs
    cartId: { type: String },
    bookingId: { type: mongoose.Schema.Types.ObjectId },
    // goggle - events management
    google_event_id: { type: String, default: "" },
    google_htmlLink: { type: String, default: "" },
    google_event_status: { type: String, default: "" },
    // coach data
    coachId: { type: mongoose.Schema.Types.ObjectId },
    coachTimeZone: { type: String, default: "" },
    // coachee data
    userId: { type: mongoose.Schema.Types.ObjectId },
    userTimeZone: { type: String, default: "" },
    // session details
    sessionType: { type: String, default: "" },
    sessionId: { type: mongoose.Schema.Types.ObjectId },
    sessionDate: { type: Date },
    sessionDateUpdated: { type: Date },
    amount: { type: Number },
    // completion status
    sessionStatus: { type: Number, default: 0 }, //0=pending,1=completed,2=cancel / /3-incomplete /
    // remakrs
    coachRemarks: { type: String, default: "" },
    coacheeRemarks: { type: String, default: "" },
    absentee: {
      type: String,
      default: "",
      enum: ["coachee", "coach", "others", ""],
    },
    markedBy: {
      type: String,
      default: "",
      enum: ["coachee", "coach", "others", ""],
    },
    reasonForIncomplete: { type: String, default: "" },
    coacheeActionTime: { type: Date, default: "" },
    coachActionTime: { type: Date, default: "" },
    rescheduled: { type: Boolean, default: false },
    //refunds
    refundsID: { type: String, default: "" },
    refundsTransaction: { type: String, default: "" },
    refundsCharge: { type: String, default: "" },
    refundsCreated: { type: String, default: "" },
    refundsStatus: { type: String, default: "" },
    refundsAmount: { type: Number, default: 0 },

    // old system
    sessionCompletedDate: { type: Date },
    sessionCancelBy: { type: String, default: "" }, //user || coach
    sessionCompletedUser: { type: Number, default: 0 },
    sessionCompletedCoach: { type: Number, default: 0 },
    messageCancel: { type: String, default: "" }, //cancel or complited message by user
    completedCoachMSG: { type: String, default: "" },
    completedUserMSG: { type: String, default: "" },
    sessionCompletedCoachTime: { type: Date },
  },
  { timestamps: true }
);

const bookingModel = mongoose.model("booked_session", creaedSchema);
module.exports = bookingModel;

// this will automatically turn sessionoStatus to 1 if 0, completed after 24 h of marked as complete by the coach
cron.schedule("0 * * * *", async () => {
  // cron.schedule("* * * * *", async () => {
  // Run this job every hour
  console.log("Running scheduled job...");
  const currentTime = new Date();
  const cutoffTime = new Date(currentTime.getTime() - 24 * 60 * 60 * 1000);
  // const cutoffTime = new Date(currentTime.getTime() - 1 * 60 * 1000);
  try {
    const sessionsToUpdate = await bookingModel.find({
      sessionCompletedCoach: 1,
      sessionStatus: 0,
      sessionCompletedCoachTime: { $lte: cutoffTime },
    });
    const updatePromises = sessionsToUpdate.map(async (session) => {
      session.sessionStatus = 1;
      session.sessionCompletedDate = new Date().toISOString();
      session.completionMessage =
        "Session was marked as completed automatically after 24 hours of coach marking it as completed.";
      const orderDetailsData = await bookingModal.find({
        _id: session.bookingId,
      });
      new completedOrders({
        coachId: session.coachId,
        orderId: session._id,
        chargeId: orderDetailsData.chargeId,
        // amount: Number(bookedSessionData.amount || 0) * 0.8 * 100,  // originally was 0.8 // ie 20% fee collection
        amount: Number(session.amount || 0) * 0.6 * 100, // updated to 0.6 ie 40% fee collection
        orderAmount: session.amount,
        currency: orderDetailsData.currency,
      }).save();
      return session.save();
    });
    await Promise.all(updatePromises);
    console.log(
      `Updated session status to complete for ${sessionsToUpdate.length} sessions that were marked as completed by coach.`
    );
  } catch (error) {
    console.error("Error running scheduled job:", error);
  }
});

// auto reminder for updating session status if session passed date but not marked as complete or cancel, ie sessionStatus === 0
cron.schedule("0 */12 * * *", async () => {
  // Run this job every 12 hour
  const currentTime = new Date();
  try {
    const sessionsToUpdate = await bookingModel.aggregate([
      // Match sessions with sessionStatus 0 and sessionDateUpdated less than the current time
      {
        $match: {
          sessionStatus: 0,
          sessionDateUpdated: { $lt: currentTime },
        },
      },

      {
        $lookup: {
          from: "bookings",
          localField: "bookingId",
          foreignField: "_id",
          as: "confirmed_sessions",
        },
      },

      {
        $match: {
          "confirmed_sessions.paid": 1,
        },
      },
      {
        $project: {
          _id: 1,
          cartId: 1,
          bookingId: 1,
          userId: 1,
          coachId: 1,
          sessionId: 1,
          coachTimeZone: 1,
          sessionType: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
          amount: 1,
          sessionStatus: 1,
          refundsID: 1,
          refundsTransaction: 1,
          refundsCharge: 1,
          refundsCreated: 1,
          refundsStatus: 1,
          refundsAmount: 1,
          sessionCancelBy: 1,
          sessionCompletedUser: 1,
          sessionCompletedCoach: 1,
          messageCancel: 1,
          completedCoachMSG: 1,
          completedUserMSG: 1,
          __v: 1,
          createdAt: 1,
          updatedAt: 1,
        },
      },
    ]);

    const updatePromises = sessionsToUpdate.map((session) => {
      // console.log({
      //   coachID: session.coachId,
      //   userID: session.userId,
      //   bookingsID: session.bookingId,
      //   sessionId: session.sessionId,
      // });
      CreateNotification({
        user_id: session.coachId,
        heading: "Pending session status update !",
        description: `Your booked session with a coachee have passed the due date and the status for session hasn't been updated yet. Please update the session status for security reasons. Click on the view button to see more details Thnak you !`,
        url: `/c/booking/details/${session.bookingId}/session/details/${session._id}`,
        notification_type: "bookings",
      });
      CreateNotification({
        user_id: session.userId,
        heading: "Pending session status update !",
        description: `Your booked session with a coach have passed the due date and the status for session hasn't been updated yet. Please update the session status for security reasons. Click on the view button to see more details Thnak you !`,
        url: `/u/booking/details/${session.bookingId}/session/details/${session._id}/${session.coachId}`,
        notification_type: "bookings",
      });
    });
    await Promise.all(updatePromises);
    console.log(
      `sent in app notifications to coach and user both for ${sessionsToUpdate.length} sessions.`
    );
  } catch (error) {
    console.error("Error running scheduled job:", error);
  }
});

/// reminder for upcoming sessions
cron.schedule("0 */12 * * *", async () => {
  // run this every 12 h
  const currentTime = new Date();

  try {
    const upcomingSessions = await bookingModel.aggregate([
      {
        $match: {
          sessionStatus: 0,
          sessionDateUpdated: { $gte: currentTime }, // Session date must be in the future
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "bookingId",
          foreignField: "_id",
          as: "confirmed_sessions",
        },
      },
      {
        $match: {
          "confirmed_sessions.paid": 1,
        },
      },
      {
        $project: {
          _id: 1,
          cartId: 1,
          bookingId: 1,
          userId: 1,
          coachId: 1,
          sessionId: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
        },
      },
    ]);

    const notificationPromises = upcomingSessions.map(async (session) => {
      // Retrieve user and coach time zones
      const user = await userModel
        .findOne({ _id: new mongoose.Types.ObjectId(session.userId) })
        .select("timeZone -_id");
      const coach = await CoachModel.findOne({
        _id: new mongoose.Types.ObjectId(session.coachId),
      }).select("timeZone -_id");

      if (!user?.timeZone || !coach?.timeZone) {
        console.warn("Missing timeZone information for user or coach:", {
          userId: session.userId,
          coachId: session.coachId,
        });
        return null;
      }

      const sessionTimeInUserTZ = moment(session.sessionDateUpdated).tz(
        user.timeZone
      );
      const sessionTimeInCoachTZ = moment(session.sessionDateUpdated).tz(
        coach.timeZone
      );

      const currentTimeInUserTZ = moment(currentTime).tz(user.timeZone);
      const currentTimeInCoachTZ = moment(currentTime).tz(coach.timeZone);
      const hoursLeftUser = sessionTimeInUserTZ.diff(
        currentTimeInUserTZ,
        "hours"
      );
      const hoursLeftCoach = sessionTimeInCoachTZ.diff(
        currentTimeInCoachTZ,
        "hours"
      );
      // console.log({
      //   currentTimeInUserTZ: currentTimeInUserTZ.format("DD-MM-YYYY  hh:mm A "),
      //   hoursLeftUser,
      //   currentTimeInCoachTZ: currentTimeInCoachTZ.format(
      //     "DD-MM-YYYY  hh:mm A "
      //   ),
      //   hoursLeftCoach,
      //   sessionTimeInUserTZ: sessionTimeInUserTZ.format("DD-MM-YYYY  hh:mm A "),
      //   sessionTimeInCoachTZ: sessionTimeInCoachTZ.format(
      //     "DD-MM-YYYY  hh:mm A "
      //   ),
      //   user_timeZone: user?.timeZone,
      //   coach_timeZone: coach.timeZone,
      // });

      // Skip notifications if time is negative or more than 24 hours
      if (hoursLeftUser <= 0 || hoursLeftUser > 24) {
        console.log(
          `Skipped user notification for session ${session._id}: Hours left ${hoursLeftUser}`
        );
      } else {
        // Notify the user
        await CreateNotification({
          user_id: session.userId,
          heading: "Upcoming session reminder!",
          description: `You have an upcoming session starting in ${hoursLeftUser} hour(s) (${sessionTimeInUserTZ.format(
            "hh:mm A"
          )} - ${sessionTimeInUserTZ
            .add(1, "hours")
            .format(
              "hh:mm A"
            )} ) . Please ensure you're ready. Click the view button for details.`,
          url: `/u/booking/details/${session.bookingId}/session/details/${session._id}/${session.coachId}`,
          notification_type: "bookings",
        });
      }

      if (hoursLeftCoach <= 0 || hoursLeftCoach > 24) {
        console.log(
          `Skipped coach notification for session ${session._id}: Hours left ${hoursLeftCoach}`
        );
      } else {
        // Notify the coach
        await CreateNotification({
          user_id: session.coachId,
          heading: "Upcoming session reminder!",
          description: `You have an upcoming session starting in ${hoursLeftCoach} hour(s) (${sessionTimeInCoachTZ.format(
            "hh:mm A"
          )} - ${sessionTimeInCoachTZ
            .add(1, "hours")
            .format(
              "hh:mm A"
            )} ) . Please ensure you're prepared. Click the view button for details.`,
          url: `/c/booking/details/${session.bookingId}/session/details/${session._id}`,
          notification_type: "bookings",
        });
      }
    });

    await Promise.all(notificationPromises);

    console.log(
      `Processed reminder notifications for upcomingSessions : ${upcomingSessions.length} sessions.`
    );
  } catch (error) {
    console.error(
      "Error running scheduled job for upcoming session reminders:",
      error
    );
  }
});
