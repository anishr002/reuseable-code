const mongoose = require("mongoose");
const { Schema } = mongoose;

const CoachEducationModal = new Schema(
  {
    coachId: mongoose.Schema.Types.ObjectId,
    organization: { type: String, required: true },
    degree: { type: String, required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date },
  },
  { timestamps: true }
);

const cretedModal = mongoose.model("CoachEducation", CoachEducationModal);
module.exports = cretedModal;
