const mongoose = require("mongoose");
const { Schema } = mongoose;

// Define the time range schema
const timeRangeSchema = new Schema(
  {
    from: String,
    to: String,
  },
  { _id: false }
);
// Define the time range schema
const timeRangeSchemaForAllDay = new Schema(
  {
    from: { type: String },
    to: { type: String },
  },
  { _id: false }
);

// Define the availability schema
const availabilitySchema = new Schema(
  {
    id: {
      type: Number,
      required: true,
    },
    name: { type: String },
    unavailable: {
      type: Boolean,
      default: true,
    },
    allday: {
      type: Boolean,
      default: false,
    },
    availability: [timeRangeSchema],
  },
  { _id: false }
);

// Define the coach availability schema for each day of the week
const coachAvailabilitySchema = new Schema(
  {
    coachId: { type: mongoose.Schema.Types.ObjectId, required: true },
    allDayTimeSlot: {
      type: timeRangeSchemaForAllDay,
      default: { from: "", to: "" },
    },
    availability: { type: [availabilitySchema], default: [] },
    repeatAvailibility: { type: Boolean },
  },
  { timestamps: true }
);

const CoachAvailabilityModel = mongoose.model(
  "coachAvailability",
  coachAvailabilitySchema
);

module.exports = CoachAvailabilityModel;
