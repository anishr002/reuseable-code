const fs = require("fs");
const path = require("path");
// List of required folders inside the public directory
const requiredFolders = [
  "public/certificate",
  "public/credentials",
  "public/messageFile",
  "public/reports",
  "public/usersProfile",
  "public/coachID",
  "public/logo",
  "public/receipt",
  "public/resourceFiles",
  "public/coachAgreements",
  "public/files",
];
function createPublicFolders() {
  requiredFolders.forEach((folderName) => {
    const folderPath = path.join(__dirname, folderName);
    // Checking if the folder exists, if not, then create it
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath, { recursive: true });
      console.log(`Folder created: ${folderName}`);
    }
  });
}
createPublicFolders();

// in  package.json add script :  "setpublicfolders": "node genStaticFolders.js"
// run in terminal : npm run setpublicfolders
