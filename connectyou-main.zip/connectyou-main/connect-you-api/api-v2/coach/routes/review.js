const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const controller = require("../controllers/review");
const coachAuth = require("../../../middleware/authTokenCoach");
const validation = require("../../../middleware/validation");

router.get(
  "/get-all-reviews",
  coachAuth.authTokenCoach,
  validation.response,
  controller.getAllReview
);

module.exports = router;
