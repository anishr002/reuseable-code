const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const controller = require("../controllers/resources");
const coachAuth = require("../../../middleware/authTokenCoach");
const validation = require("../../../middleware/validation");

router.get(
  "/module/details/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL"),
  ],
  coachAuth.authTokenCoach,
  validation.response,
  controller.getModuleDetails
);

module.exports = router;
