const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const controller = require("../controllers/coachingSessions");
const coachAuth = require("../../../middleware/authTokenCoach");
const validation = require("../../../middleware/validation");
router.get(
  "/session-details/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL"),
  ],
  coachAuth.authTokenCoach,
  validation.response,
  controller.getSessionDetails
);

router.put(
  "/session-toggle-status/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL"),
    body("status").exists().withMessage("Please provide status"),
  ],
  coachAuth.authTokenCoach,
  validation.response,
  controller.toggleStatus
);

module.exports = router;
