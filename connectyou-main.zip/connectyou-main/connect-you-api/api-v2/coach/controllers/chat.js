const { default: mongoose } = require("mongoose");
const chatMessageModel = require("../../../models/chatMessage");

exports.getMessageStatus = async (req, res) => {
  try {
    const coachId = req.coach._id;
    const { id } = req.params;
    const data = await chatMessageModel.aggregate([
      {
        $match: {
          _id: mongoose.Types.ObjectId.createFromHexString(id),
          $or: [{ senderId: coachId }, { receiverId: coachId }],
        },
      },
    ]);
    // console.log({ data });
    return res.status(200).json({
      success: true,
      message: "Fetched message details sucessfully ",
      data: data[0],
    });
  } catch (error) {
    console.log(`Error in getMessageStatus controller at apiv2: ${error}`);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
};
