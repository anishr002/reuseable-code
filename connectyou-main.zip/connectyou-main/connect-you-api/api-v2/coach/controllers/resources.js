const mongoose = require("mongoose");
const resource_Module_Model = require("../../../models/resourceModules");

exports.getModuleDetails = async (req, res) => {
  try {
    const { id } = req.params;
    const data = await resource_Module_Model.aggregate([
      {
        $match: {
          _id: mongoose.Types.ObjectId.createFromHexString(id),
        },
      },
      {
        $lookup: {
          from: "resources",
          localField: "resourceId",
          foreignField: "_id",
          as: "resource_details",
          pipeline: [
            {
              $match: {
                $or: [{ availableFor: "coach" }, { availableFor: "all" }],
              },
            },
          ],
        },
      },
      {
        $match: {
          resource_details: {
            $ne: [],
          },
        },
      },
    ]);
    if (data) {
      return res.status(200).json({
        message: "Fetched module details successfully",
        success: true,
        data: data[0],
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
      });
    }
  } catch (error) {
    console.log(`error at getModuleDetails  ${error}`);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};
