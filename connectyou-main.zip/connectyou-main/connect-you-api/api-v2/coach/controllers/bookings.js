const mongoose = require("mongoose");
const ErrorResponse = require("../../../lib/errorResponse");
const bookedSessionsModel = require("../../../models/booked_session");

exports.listAllBookings = async (req, res) => {
  try {
    const coachId = req.coach._id; // Login coachee-id
    const status = req.params.status; // "upcoming" / "completed" / "canceled" / "absent" / "all"
    const page = Number(req.query.pageNo) || 1;
    const limit = Number(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    // console.log({ page, limit, skip });
    const { searchQuery, fromDate, toDate } = req.query;
    let match = {
      coachId: coachId,
    };
    if (status !== "all") {
      switch (status) {
        case "upcoming":
          match.sessionStatus = 0;
          break;
        case "completed":
          match.sessionStatus = 1;
          break;
        case "canceled":
          match = {
            $and: [
              { coachId: coachId },
              {
                $or: [{ sessionStatus: 2 }, { sessionStatus: 3 }],
              },
            ],
          };
          break;
        // Optionally handle "absent" or other statuses here
        default:
          break;
      }
    }

    let queryMatch = {};
    if (searchQuery) {
      queryMatch = {
        $or: [
          { "coacheeDetails.name": { $regex: new RegExp(searchQuery, "i") } },
          { "coachDetails.Lname": { $regex: new RegExp(searchQuery, "i") } },
          { "coachDetails.name": { $regex: new RegExp(searchQuery, "i") } },
          { "sessionDetails.title": { $regex: new RegExp(searchQuery, "i") } },
        ],
      };
    }

    let dateQuery = {};
    if (fromDate && toDate) {
      const start = moment(`${fromDate}`, "YYYY-MM-DD").startOf("day");
      const end = moment(`${toDate}`, "YYYY-MM-DD").endOf("day");
      dateQuery.createdAt = {
        $gte: start.toDate(),
        $lte: end.toDate(),
      };
    }

    const sessions = await bookedSessionsModel.aggregate([
      {
        $match: match,
      },
      {
        $lookup: {
          from: "bookings",
          localField: "bookingId",
          foreignField: "_id",
          as: "orderDetails",
          pipeline: [
            {
              $project: {
                _id: 1,
                amount: 1,
                receipt: 1,
                TransactionID: 1,
                paid: 1,
                createdAt: 1,
              },
            },
          ],
        },
      },
      {
        $match: {
          "orderDetails.paid": 1,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "coacheeDetails",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                lastName: 1,
                email: 1,
                image: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$coacheeDetails" },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachDetails",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                email: 1,
                image: 1,
                Lname: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$coachDetails" },
      {
        $lookup: {
          from: "coachsessions",
          localField: "sessionId",
          foreignField: "_id",
          as: "sessionDetails",
          pipeline: [
            {
              $project: {
                _id: 1,
                title: 1,
                price: 1,
                type: 1,
                deleted: 1,
                description: 1,
                currency: 1,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          as: "reviewDetails",
          let: {
            coachId: "$coachId",
            bookingId: "$_id",
            userId: "$userId",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$coachId", "$$coachId"] },
                    { $eq: ["$bookingId", "$$bookingId"] },
                    { $eq: ["$userId", "$$userId"] },
                    { $eq: ["$deleted", 0] },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "userDetails",
                pipeline: [
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      lastName: 1,
                      image: 1,
                    },
                  },
                ],
              },
            },
            {
              $unwind: {
                path: "$userDetails",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $project: {
                userDetails: 1,
                coachId: 1,
                userId: 1,
                bookingId: 1,
                orderId: 1,
                ratingNumber: 1,
                title: 1,
                remarks: 1,
                createdAt: 1,
                updatedAt: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$reviewDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$orderDetails",
        },
      },
      { $unwind: "$sessionDetails" },
      {
        $lookup: {
          from: "booked_session_timelines",
          as: "timeline",
          localField: "_id",
          foreignField: "bookedSessionId",
        },
      },
      ...(searchQuery ? [{ $match: queryMatch }] : []),
      ...(fromDate && toDate ? [{ $match: dateQuery }] : []),
      {
        $project: {
          _id: 1,
          cartId: 1,
          bookingId: 1,
          userId: 1,
          coachId: 1,
          sessionId: 1,
          coachTimeZone: 1,
          sessionType: 1,
          sessionDate: 1,
          sessionDateUpdated: 1,
          amount: 1,
          sessionStatus: 1,
          refundsStatus: 1,
          sessionCancelBy: 1,
          sessionCompletedUser: 1,
          sessionCompletedCoach: 1,
          messageCancel: 1,
          completedCoachMSG: 1,
          completedUserMSG: 1,
          absentee: 1,
          markedBy: 1,
          createdAt: 1,
          updatedAt: 1,
          sessionCompletedDate: 1,
          coachDetails: 1,
          coacheeDetails: 1,
          sessionDetails: 1,
          orderDetails: 1,
          reviewDetails: 1,
          timeline: 1,
        },
      },
      {
        $facet: {
          data: [
            { $sort: { sessionDateUpdated: -1 } },
            { $skip: skip },
            { $limit: limit },
          ],
          totalCount: [{ $count: "total" }],
        },
      },
    ]);

    // Extract total count from facet result; if none, default to 0.
    const totalCount =
      sessions[0].totalCount && sessions[0].totalCount.length > 0
        ? sessions[0].totalCount[0].total
        : 0;

    const response = {
      success: true,
      data: sessions[0].data,
      currentPage: page,
      totalPages: Math.ceil(totalCount / limit),
      message: "Coach Sessions retrieved successfully!",
    };
    return res.status(200).json(response);
  } catch (err) {
    return ErrorResponse({ error: err, res });
  }
};
