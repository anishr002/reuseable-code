const { default: mongoose } = require("mongoose");
const ErrorResponse = require("../../../lib/errorResponse");
const coachingSessionModel = require("../../../models/coachSession");

exports.getSessionDetails = async (req, res) => {
  try {
    const sessionId = req.params.id;
    const coachId = req.coach._id;
    const session = await coachingSessionModel
      .find({
        _id: mongoose.Types.ObjectId.createFromHexString(sessionId),
        coachId,
        deleted: 0,
      })
      .select("-deleted");
    let response = {};
    let status;
    if (session.length > 0) {
      status = 200;
      response = {
        success: true,
        message: "Fetched coaching session details successfully !",
        data: session[0],
      };
    } else {
      status = 500;
      response = {
        success: false,
        message: "Something went wrong",
      };
    }
    return res.status(status).json(response);
  } catch (error) {
    return ErrorResponse({ error, res });
  }
};

exports.toggleStatus = async (req, res) => {
  try {
    const sessionId = req.params.id;
    const coachId = req.coach._id;
    const sessionstatus = req.body.status;
    // console.log(req.body);
    const session = await coachingSessionModel.updateOne(
      {
        _id: mongoose.Types.ObjectId.createFromHexString(sessionId),
        coachId,
        // status: true,
        deleted: 0,
      },
      {
        $set: {
          status: sessionstatus,
        },
      },
      {
        upsert: true,
      }
    );
    let response = {};
    let status;
    if (session.acknowledged) {
      status = 200;
      response = {
        success: true,
        message: "coaching session updated successfully !",
        data: session[0],
      };
    } else {
      status = 500;
      response = {
        success: false,
        message: "Something went wrong",
      };
    }
    // console.log({ response });
    return res.status(status).json(response);
  } catch (error) {
    return ErrorResponse({ error, res });
  }
};
