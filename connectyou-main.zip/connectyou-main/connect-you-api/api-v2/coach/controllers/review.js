const mongoose = require("mongoose");
const ReviewModel = require("../../../models/orderRating");

exports.getAllReview = async (req, res) => {
  try {
    const coachId = req.coach._id;
    const pagination = req.query.paginated;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    const search = req.query.search?.trim() || "";
    const data = await ReviewModel.aggregate([
      {
        $match: {
          coachId: coachId,
          //   deleted: 0,
        },
      },
      {
        $lookup: {
          from: "users",
          as: "userDetails",
          localField: "userId",
          foreignField: "_id",
          pipeline: [
            {
              $match: {
                block: 0,
              },
            },
            {
              $project: {
                _id: 1,
                image: 1,
                name: 1,
                lastName: 1,
                email: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$userDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      ...(search
        ? [
            {
              $match: {
                $or: [
                  {
                    "userDetails.name": {
                      $regex: search,
                      $options: "i",
                    },
                  },
                  {
                    "userDetails.lastName": {
                      $regex: search,
                      $options: "i",
                    },
                  },
                ],
              },
            },
          ]
        : []),
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $facet: {
          meta: [{ $count: "total" }],
          data:
            pagination === "true" ? [{ $skip: skip }, { $limit: limit }] : [],
        },
      },
      {
        $addFields: {
          total: { $arrayElemAt: ["$meta.total", 0] },
        },
      },
    ]);
    const result = data[0] || { data: [], total: 0 };
    return res.status(200).json({
      success: true,
      message: "Coach's reviews retrieved successfully",
      data: result.data,
      totalCount: result.total,
      page,
      totalPages: Math.ceil(result.total / limit),
    });
  } catch (error) {
    console.error("Error in getAllReview / api-v2-coach:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};
