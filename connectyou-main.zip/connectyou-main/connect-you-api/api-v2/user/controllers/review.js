const mongoose = require("mongoose");
const { saveTimelineEntry } = require("../../../models/bookedSessionTimeLine");
const orderRatingModal = require("../../../models/orderRating");

exports.add = async (req, res) => {
  try {
    const userId = req.user._id;
    const { coachId, bookingId, orderId, ratingNumber, remarks, title } =
      req.body;
    const rating = await new orderRatingModal({
      title,
      userId,
      coachId,
      bookingId,
      orderId,
      ratingNumber,
      remarks,
    }).save();

    if (rating) {
      await saveTimelineEntry({
        bookedSessionId: bookingId,
        action: "Review Added",
        message: `Added a review to the coach's profile for the session.`,
        actionBy: "Coachee",
      });
      const response = {
        success: true,
        message: "Review saved successfully",
      };
      return res.status(200).json(response);
    } else throw new Error("Something went wrong while saving review");
  } catch (error) {
    console.log("Error in api-v2-usre-review-controller", {
      error: error?.response?.data?.message || error,
    });
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

exports.edit = async (req, res) => {
  try {
    const userId = req.user._id;
    const { reviewId, updatedData } = req.body;
    const update = await orderRatingModal.updateOne(
      {
        userId,
        _id: mongoose.Types.ObjectId.createFromHexString(reviewId),
      },
      { $set: updatedData }
    );
    if (update.modifiedCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Review not found or no changes made",
      });
    }
    return res.status(200).json({
      success: true,
      message: "Review updated successfully",
    });
  } catch (error) {
    console.log("Error in api-v2-user-review-controller", {
      error: error?.response?.data?.message || error,
    });
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

exports.delete = async (req, res) => {
  try {
    const userId = req.user._id;
    const { reviewId } = req.params;
    const result = await orderRatingModal.deleteOne({
      _id: mongoose.Types.ObjectId.createFromHexString(reviewId),
      userId: userId,
    });
    if (result.deletedCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Review not found or not authorized to delete",
      });
    }
    return res.status(200).json({
      success: true,
      message: "Review deleted successfully",
    });
  } catch (error) {
    console.log("Error in api-v2-user-review-controller", {
      error: error?.response?.data?.message || error,
    });
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

exports.getAll = async (req, res) => {
  try {
  } catch (error) {
    console.log("Error in api-v2-usre-review-controller", {
      error: error?.response?.data?.message || error,
    });
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};
