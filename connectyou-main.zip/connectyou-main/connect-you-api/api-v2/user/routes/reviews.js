const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const controller = require("../controllers/review");
const coacheeAuth = require("../../../middleware/authTokenUser");
const validation = require("../../../middleware/validation");

router.post(
  "/add-review",
  [
    body("coachId")
      .trim()
      .notEmpty()
      .withMessage("Please enter coachId")
      .isMongoId()
      .withMessage("Please enter valid coachId")
      .escape(),
    body("orderId")
      .trim()
      .notEmpty()
      .withMessage("Please enter orderId")
      .isMongoId()
      .withMessage("Please enter valid orderId")
      .escape(),
    body("bookingId")
      .trim()
      .notEmpty()
      .withMessage("Please enter bookingId")
      .isMongoId()
      .withMessage("Please enter valid bookingId")
      .escape(),
    body("ratingNumber")
      .trim()
      .notEmpty()
      .withMessage("Please enter ratingNumber")
      .isNumeric()
      .withMessage("Rating must be a number"),
    body("title")
      .exists()
      .withMessage("Please add title for the review")
      .isString()
      .withMessage("Title must be a string")
      .trim(),
    body("remarks")
      .optional()
      .isString()
      .withMessage("Title must be a string")
      .trim(),
  ],
  coacheeAuth.authTokenUser,
  validation.response,
  controller.add
);
router.put(
  "/edit-review",
  [
    body("reviewId")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL"),
  ],
  coacheeAuth.authTokenUser,
  validation.response,
  controller.edit
);
router.delete(
  "/delete-review/:reviewId",
  [
    param("reviewId")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isMongoId()
      .withMessage("Invalid URL"),
  ],
  coacheeAuth.authTokenUser,
  validation.response,
  controller.delete
);
router.get(
  "/get-all-reviews",
  [],
  coacheeAuth.authTokenUser,
  validation.response,
  controller.getAll
);

module.exports = router;
