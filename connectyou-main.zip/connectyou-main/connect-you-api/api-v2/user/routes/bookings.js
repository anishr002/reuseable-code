const express = require("express");
const router = express.Router();
router.use(express.json());
const { body, query, param } = require("express-validator");
const controller = require("../controllers/bookings");
const coacheeAuth = require("../../../middleware/authTokenUser");
const validation = require("../../../middleware/validation");
router.get(
  "/bookings-list/:status",
  [
    param("status")
      .trim()
      .exists()
      .withMessage("Invalid URL")
      .isString()
      .withMessage("Invalid URL"),
  ],
  coacheeAuth.authTokenUser,
  validation.response,
  controller.listAllBookings
);



module.exports = router;
