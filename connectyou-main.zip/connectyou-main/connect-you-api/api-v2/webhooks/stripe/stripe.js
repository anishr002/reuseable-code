require("dotenv").config();
const Stripe = require("stripe");
const stripe = Stripe(process.env.STRIPE_SK);
const endpointSecret = process.env.ENDPOINT_SECRET;
const { handleRefundSuccedded } = require("./controllers/refund");
const paymentController = require("./controllers/payment");
const payoutController = require("./controllers/payouts");
const accountController = require("./controllers/account");

exports.stripeWebhookRouter = async (request, response) => {
  const sig = request.headers["stripe-signature"];
  let event;
  try {
    event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
  } catch (error) {
    response.status(400).send(`Stripe Webhook Error: ${error.message}`);
    return;
  }
  try {
    switch (event.type) {
      case "checkout.session.completed":
        console.log("checkout session completed");
        paymentController.ChargeCreated(event);
        break;
      case "charge.succeeded":
        console.log(`charge.succeeded`);
        paymentController.ChargeSuccedded(event);
        break;
      case "refund.created":
        const refundCreated = event.data.object;
        console.log("Refund Created:", refundCreated.id);
        break;
      case "charge.refunded":
      case "refund.update":
        const refundedCharge = event.data.object;
        console.log("Refund Completed for charge:", refundedCharge.id);
        handleRefundSuccedded(refundedCharge);
        break;
      case "payout.created":
        payoutController.payoutCreated(event);
        break;
      case "payout.paid":
        payoutController.payoutPaid(event);
        break;
      case "payout.failed":
        payoutController.payoutFailed(event);
        break;
      case "account.updated":
        accountController.updated(event);
        break;
      default:
        console.log(`Unhandled event type ${event.type} detected in webhook`);
    }
    return response
      .status(200)
      .send("Received Stripe webhook event successfully");
  } catch (error) {
    console.error(`Error handling Stripe${event.type} event: ${error}`);
    return response.status(500).send(`Internal Server Error: ${error.message}`);
  }
};
// us platform account
exports.transferRestrictedCountries = [
  "CA", // Canada (FINTRAC regulations)
  "SG", // Singapore (MAS compliance)
  "JP", // Japan (FX Law + PSA)
  "IR", // Iran (global sanctions)
  "KP", // North Korea (sanctions)
  "CU", // Cuba (sanctions)
  "SY", // Syria (sanctions)
  "RU", // Russia (sanctions post-2022)
  "MM", // Myanmar (sanctions)
  "AF", // Afghanistan (sanctions)
  "CH", // Switzerland
  "DE", // germany
  "PT", // Portugal
  "AU",
  "GB",
  "AT",
  "BE",
  "DK", // Denmark
  "FI", // Finland
  "FR", // france
  "IE", // Ireland
  "IT", // Italy
  "NL", // Netherlands
  "NZ", // New Zealand
  "NO", // Norway
  "ES", // Spain
  "SE", // Sweden
  "TT",
  "AE",
];

// us platform account
exports.needsCardPayments = [
  "US", // United States
  // "CA", // Canada
  "SG", // Singapore
  "CH", // Switzerland
  "DE", // Germany
  "JP", // Japan
  // "AU", // Australia
  // "GB", // United Kingdom
  // "IE", // Ireland
  // "FR", // France
  // "NL", // Netherlands
  // "ES", // Spain
  // "IT", // Italy
  // "BE", // Belgium
  // "AT", // Austria
  // "FI", // Finland
  // "DK", // Denmark
  // "SE", // Sweden
  // "PT", // Portugal
  // "NO", // Norway
  // "NZ", // New Zealand
];

exports.CountriesOptions = [
  { code: "AU", label: "Australia", phone: "61", currency: "AUD" },
  { code: "AT", label: "Austria", phone: "43", currency: "EUR" },
  { code: "BE", label: "Belgium", phone: "32", currency: "EUR" },
  // { code: "BR", label: "Brazil", phone: "55", currency: "BRL" },
  { code: "BG", label: "Bulgaria", phone: "359", currency: "BGN" },
  { code: "CA", label: "Canada", phone: "1", currency: "CAD" },
  { code: "HR", label: "Croatia", phone: "385", currency: "EUR" },
  { code: "CY", label: "Cyprus", phone: "357", currency: "EUR" },
  { code: "CZ", label: "Czech Republic", phone: "420", currency: "EUR" },
  { code: "DK", label: "Denmark", phone: "45", currency: "EUR" },
  { code: "EE", label: "Estonia", phone: "372", currency: "EUR" },
  { code: "FI", label: "Finland", phone: "358", currency: "EUR" },
  { code: "FR", label: "France", phone: "33", currency: "EUR" },
  { code: "DE", label: "Germany", phone: "49", currency: "EUR" },
  // { code: "GH", label: "Ghana", phone: "233", currency: "GHS" },
  // { code: "GI", label: "Gibraltar", phone: "350", currency: "GIP" },
  { code: "GR", label: "Greece", phone: "30", currency: "EUR" },
  { code: "HK", label: "Hong Kong", phone: "852", currency: "HKD" },
  { code: "HU", label: "Hungary", phone: "36", currency: "HUF" },
  // { code: "IN", label: "India", phone: "91", currency: "INR" },
  // { code: "ID", label: "Indonesia", phone: "62", currency: "IDR" },
  { code: "IE", label: "Ireland", phone: "353", currency: "EUR" },
  { code: "IT", label: "Italy", phone: "39", currency: "EUR" },
  { code: "JP", label: "Japan", phone: "81", currency: "JPY" },
  // { code: "KE", label: "Kenya", phone: "254", currency: "KES" },
  { code: "LV", label: "Latvia", phone: "371", currency: "EUR" },
  { code: "LI", label: "Liechtenstein", phone: "423", currency: "CHF" },
  { code: "LT", label: "Lithuania", phone: "370", currency: "EUR" },
  { code: "LU", label: "Luxembourg", phone: "352", currency: "EUR" },
  { code: "MY", label: "Malaysia", phone: "60", currency: "MYR" },
  { code: "MT", label: "Malta", phone: "356", currency: "EUR" },
  { code: "MX", label: "Mexico", phone: "52", currency: "MXN" },
  { code: "NL", label: "Netherlands", phone: "31", currency: "EUR" },
  { code: "NZ", label: "New Zealand", phone: "64", currency: "NZD" },
  // { code: "NG", label: "Nigeria", phone: "234", currency: "NGN" },
  { code: "NO", label: "Norway", phone: "47", currency: "NOK" },
  { code: "PL", label: "Poland", phone: "48", currency: "PLN" },
  { code: "PT", label: "Portugal", phone: "351", currency: "EUR" },
  { code: "RO", label: "Romania", phone: "40", currency: "RON" },
  { code: "SG", label: "Singapore", phone: "65", currency: "SGD" },
  { code: "SK", label: "Slovakia", phone: "421", currency: "EUR" },
  { code: "SI", label: "Slovenia", phone: "386", currency: "EUR" },
  // { code: "ZA", label: "South Africa", phone: "27", currency: "ZAR" },
  { code: "ES", label: "Spain", phone: "34", currency: "EUR" },
  { code: "SE", label: "Sweden", phone: "46", currency: "SEK" },
  { code: "CH", label: "Switzerland", phone: "41", currency: "CHF" },
  { code: "TH", label: "Thailand", phone: "66", currency: "THB" },
  {
    code: "AE",
    label: "United Arab Emirates",
    phone: "971",
    currency: "AED",
  },
  { code: "GB", label: "United Kingdom", phone: "44", currency: "GBP" },
  { code: "US", label: "United States", phone: "1", currency: "USD" },
];
