const capitalizeFirstLetter = require("../../../../lib/capitalizeFirstLetter");
const { getUserData } = require("../../../../lib/coachee");
const { refund_request_model } = require("../../../../models/refund_request");
const moment = require("moment-timezone");
const transportEmail = require("../../../../lib/email");

const handleRefundSuccedded = async (refundedCharge) => {
  try {
    const tsxId = `CY_REF${Date.now()}_R`;
    const refundObj = await refund_request_model.findOneAndUpdate(
      {
        charge: refundedCharge.id,
      },
      {
        $set: {
          refund_TXN_ID: tsxId,
          refund_stripe_status: refundedCharge.status,
          presentment_details: refundedCharge.presentment_details,
          stripe_refund_req_status: refundedCharge.status,
          refunded_details: {
            processed_charge_id: refundedCharge.id,
            billing_details: refundedCharge.billing_details,
            created: refundedCharge.created,
            paid: refundedCharge.paid,
            payment_intent: refundedCharge.payment_intent,
            payment_method: refundedCharge.payment_method,
            receipt_email: refundedCharge.receipt_email,
            receipt_url: refundedCharge.receipt_url,
            payment_method_details: refundedCharge.payment_method_details,
          },
        },
      },
      { upsert: true }
    );
    // console.log({ refundObj });
    const userDetails = await getUserData(refundObj.userId);
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userDetails.email,
      subject: `Refund Update`,
      template: "refundSuccess",
      context: {
        name: `${capitalizeFirstLetter(
          userDetails.name
        )} ${capitalizeFirstLetter(userDetails.lastName)}`,
        email: userDetails.email,
        amount: `$${refundObj.amount / 100}`,
        transactionID: tsxId,
        date: moment().format("MM/DD/YYYY hh:mm A"),
        receipt_url: refundObj.receipt_url,
      },
    };
    transportEmail.createEmail({ mailOptions: mailOptionsForUser });
  } catch (error) {
    console.log(error);
  }
};
module.exports = {
  handleRefundSuccedded,
};
