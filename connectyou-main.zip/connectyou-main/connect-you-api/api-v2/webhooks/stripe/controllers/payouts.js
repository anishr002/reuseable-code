const CoachModel = require("../../../../models/coach");
const puppeteer = require("puppeteer");
const moment = require("moment-timezone");
const path = require("path");
const coachPayoutModel = require("../../../../models/coachPayout");
const { CreateNotification } = require("../../../../models/notificationModal");
const { default: mongoose } = require("mongoose");
const transportEmail = require("../../../../lib/email");
const { reverseTransferSafely } = require("../../../../lib/stripe");

exports.payoutCreated = async (event) => {
  try {
    const payout = event.data.object;
    const metadata = payout.metadata;
    console.log(
      `Payout Created for coachPayoutId: ${metadata.coachPayoutId} , coachID :coachPayoutId: ${metadata.coachId}`
    );
  } catch (error) {
    console.error("Error handling payout.created event:", error);
  }
};

exports.payoutPaid = async (event) => {
  try {
    const payout = event.data.object;
    // console.log({ "payout paid web hook handler": payout });
    if (payout.status !== "paid") {
      console.warn(
        `Received payout.paid event but payout.status is '${payout.status}', skipping.`
      );
      return;
    }
    const metadata = payout.metadata || {};
    const { coachId, coachPayoutId, transactionId } = metadata;
    if (!coachId || !coachPayoutId) {
      console.warn(
        "Missing coachId or coachPayoutId in payout metadata:",
        metadata
      );
      return;
    }
    const [coachPayoutData, coachData] = await Promise.all([
      coachPayoutModel.findById(coachPayoutId),
      CoachModel.findById(coachId),
    ]);
    if (!coachPayoutData) {
      console.warn(`Payout record not found for ID: ${coachPayoutId}`);
      return;
    }
    if (!coachData) {
      console.warn(`Coach record not found for ID: ${coachId}`);
      return;
    }
    const updatedPayout = await coachPayoutModel.findByIdAndUpdate(
      coachPayoutId,
      {
        $set: {
          paid: true,
          payoutId: payout.id,
          payout_transactionId: payout.balance_transaction,
          payout_destination: payout.destination,
          payout_type: payout.type,
          confirmedDate: new Date().toISOString(),
        },
      },
      { new: true }
    );
    let receipt = null;
    try {
      receipt = await generateInvoice({
        customerEmail: coachData.email,
        customerName: `${coachData.name} ${coachData.Lname}`,
        address: coachData.fullAddress,
        transactions: [updatedPayout],
        transactionID: transactionId,
      });
      if (receipt) {
        await coachPayoutModel.findByIdAndUpdate(coachPayoutId, {
          $set: { receipt },
        });
      }
    } catch (err) {
      console.error("Failed to generate or save invoice receipt:", err);
    }
    try {
      await paymentConfirmationCoach({
        userName: `${coachData.name} ${coachData.Lname}`,
        amount: `$${(coachPayoutData.amount / 100).toFixed(2)}`,
        transactionID: updatedPayout.transactionId,
        userEmail: coachData.email,
        fileName: receipt,
      });
    } catch (err) {
      console.error("Failed to send payout confirmation email:", err);
    }
    try {
      await CreateNotification({
        user_id: coachId,
        heading: `Your payout of $${(coachPayoutData.amount / 100).toFixed(
          2
        )} was successful.`,
        description: `The requested payout of $${(
          coachPayoutData.amount / 100
        ).toFixed(
          2
        )} has been transferred to your linked bank account. Contact support if this wasn't you.`,
        url: `/c/finances/payout-history`,
        notification_type: "admin",
      });
    } catch (err) {
      console.error("Failed to create notification:", err);
    }
    console.log(`✅ Payout marked as paid and confirmed for coach ${coachId}`);
  } catch (error) {
    console.error("❌ Error handling payout.paid event:", error);
  }
};

function capitalizeFirstLetter(str) {
  if (!str) return "";
  return str?.charAt(0)?.toUpperCase() + str.slice(1);
}

const generateInvoice = async ({
  customerName,
  customerEmail,
  address,
  transactions,
  transactionID,
}) => {
  const date = new Date().toLocaleDateString();
  let transactionRows = "";
  let totalAmount = 0;
  transactions.forEach((transaction, index) => {
    const approvedDate = transaction.updatedAt
      ? moment(transaction.updatedAt).format("MMMM-DD-YYYY hh:mm A")
      : "-";
    const requestedDate = transaction.createdAt
      ? moment(transaction.createdAt).format("MMMM-DD-YYYY hh:mm A")
      : "-";

    const amount = (transaction.amount / 100).toFixed(2);
    totalAmount += parseFloat(amount);

    transactionRows += `
      <tr style="border-bottom: 1px solid #e0e0e0;">
        <td style="padding: 12px 10px;">${index + 1}</td>
        <td style="padding: 12px 10px;">$${amount}</td>
        <td style="padding: 12px 10px;">${requestedDate}</td>
        <td style="padding: 12px 10px; text-align: right;">${approvedDate}</td>
      </tr>
    `;
  });

  const htmlTemplate = `
  <html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment Confirmation</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <!-- Fallback font styles embedded for email clients that don't support web fonts -->
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap");
    </style>
  </head>
  <body
    style="
      margin: 0;
      padding: 0;
      font-family: 'Quicksand', 'Helvetica Neue', Helvetica, Arial, sans-serif;
      color: #333;
      line-height: 1.6;
      background-color: #ffffff !important;
      width: 800px;
      margin: 0 auto;
    "
  >
    <table
      cellpadding="0"
      cellspacing="0"
      border="0"
      style="width: 100%; background-color: #f0f0f0"
    >
      <tr>
        <td>
          <!-- MAIN EMAIL CONTAINER -->
          <table
            cellpadding="0"
            cellspacing="0"
            border="0"
            style="width: 100%; margin: 0 auto; height: 100%"
          >
            <!-- HEADER - Extends full width -->

            <!-- Invoice Header Starts -->
            <tr>
              <td style="padding: 0">
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; position: relative"
                >
                  <!-- Invoice Number Top-Right -->
                  <tr>
                    <td style="padding: 0; position: relative">
                      <!-- Centered Logo -->
                      <table width="100%">
                        <tr>
                          <td
                            style="
                              background-color: #ffffff;
                              padding: 40px 0;
                              text-align: center;
                            "
                          >
                            <img
                              src="https://api.connectyou.global/logo/loginLogo.png"
                              alt="ConnectYou.Global Logo"
                              style="max-width: 280px; height: auto"
                            />
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Hero Header -->
                  <tr>
                    <td style="padding: 0">
                      <table
                        cellpadding="20"
                        cellspacing="0"
                        border="0"
                        style="width: 100%"
                      >
                        <tr>
                          <td
                            style="
                              background: linear-gradient(
                                135deg,
                                #013338 0%,
                                #025e5a 100%
                              );
                              padding: 10px 70px;
                              text-align: center;
                            "
                          >
                            <h1
                              style="
                                color: #ffffff;
                                margin: 0;
                                font-size: 28px;
                                font-weight: 700;
                                letter-spacing: 0.5px;
                              "
                            >
                              Payout Receipt
                            </h1>
                            <p
                              style="
                                color: #ebbd33;
                                margin: 10px 0 0 0;
                                font-size: 18px;
                                font-weight: 400;
                                letter-spacing: 0.3px;
                              "
                            >
                              Thank you for choosing ConnectYou.Global
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <!-- Powered by -->
                  <tr>
                    <td
                      style="
                        background-color: #f5fafa;
                        padding: 8px 40px;
                        text-align: center;
                      "
                    >
                      <p style="margin: 0; font-size: 14px; color: #013338">
                        Powered by Erickson Coaching International
                      </p>
                    </td>
                  </tr>

                  <!-- Split: Issued To / Details -->
                  <tr>
                    <td
                      style="background-color: #ffffff; padding: 25px 40px 10px"
                    >
                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <!-- Issued To -->
                          <td width="50%" style="vertical-align: top">
                            <h3
                              style="
                                margin: 0 0 8px 0;
                                color: #013338;
                                font-size: 18px;
                              "
                            >
                              Issued To:
                            </h3>
                            <p style="margin: 0; color: #444; font-size: 14px">
                              ${customerName}<br />
                              ${customerEmail}<br />
                              ${address}<br />
                            </p>
                          </td>
                          <!-- Transaction Info -->
                          <td
                            width="50%"
                            style="text-align: right; vertical-align: top"
                          >
                            <table align="right">
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Transaction ID:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${transactionID}
                                </td>
                              </tr>
                              <tr></tr>
                              <tr>
                                <td
                                  style="
                                    color: #013338;
                                    font-weight: 600;
                                    font-size: 14px;
                                    padding-bottom: 6px;
                                  "
                                >
                                  Date Issued:
                                </td>
                                <td
                                  style="
                                    color: #444;
                                    font-size: 14px;
                                    padding-left: 10px;
                                  "
                                >
                                  ${date}
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- HEADER - Extends full width -->
            <!-- MAIN CONTENT AREA -->
            <!-- Main Content / Booking Table -->
            <tr>
              <td style="padding: 30px 40px; background-color: #ffffff">
                <h2
                  style="margin-bottom: 20px; color: #013338; font-size: 20px"
                >
                  Payment details
                </h2>
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%; border-collapse: collapse"
                >
                  <thead>
                    <tr
                      style="
                        background-color: #f5fafa;
                        border-bottom: 1px solid #e0e0e0;
                      "
                    >
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Sr. No
                      </th>
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Amount
                      </th>
                      <th
                        style="
                          text-align: left;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Requested On
                      </th>
                      <th
                        style="
                          text-align: right;
                          padding: 12px 10px;
                          font-size: 14px;
                          color: #013338;
                          font-weight: 600;
                          border-bottom: 2px solid #025e5a;
                        "
                      >
                        Approved On
                      </th>
                    </tr>
                  </thead>

                  <!-- Sample Rows -->
                  <tbody>
                    <td
                      cellpadding="0"
                      cellspacing="0"
                      border="0"
                      style="
                        width: 100%;
                        border-collapse: collapse;
                        min-height: 500px;
                        display: table;
                      "
                    >
                      <!-- Table Body with Growing Space -->
                      <tbody style="height: 100%; display: table-row-group">
                        <!-- Item Rows -->
                        ${transactionRows}
                        <!-- Add more rows as needed -->
                        <!-- Filler Row to Push Total Down -->
                        <tr>
                          <td colspan="4" style="height: 150px">&nbsp;</td>
                        </tr>
                        <!-- Total Row -->
                        <tr>
                          <td
                            colspan="3"
                            style="
                              padding: 12px 10px;
                              text-align: right;
                              font-size: 15px;
                              font-weight: 600;
                              color: #013338;
                              border-top: 2px solid #025e5a;
                            "
                          >
                            Total
                          </td>
                          <td
                            style="
                              padding: 12px 10px;
                              text-align: right;
                              font-size: 15px;
                              font-weight: 600;
                              color: #013338;
                              border-top: 2px solid #025e5a;
                            "
                          >
                            $${totalAmount.toFixed(2)}
                          </td>
                        </tr>
                      </tbody>
                    </td>
                  </tbody>
                </table>
              </td>
            </tr>

            <!-- MAIN CONTENT AREA -->
            <!-- FOOTER - Extends full width -->
            <tr>
              <td
                style="
                  background-color: #013338;
                  padding: 0;
                  width: 100%;
                  column-span: all;
                "
              >
                <table
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  style="width: 100%"
                >
                  <!-- Company Info -->
                  <tr>
                    <td style="padding: 30px 40px 10px; text-align: center">
                      <table
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                        style="margin: 0 auto; text-align: center"
                      >
                        <tr>
                          <td
                            style="
                              padding: 8px 0;
                              color: white;
                              font-size: 14px;
                              font-style: italic;
                            "
                          >
                            Warm regards,
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 5px 0;
                              color: #ffffff;
                              font-size: 16px;
                              font-weight: bold;
                            "
                          >
                            Erickson Coaching International
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: white;
                              font-size: 13px;
                            "
                          >
                            Founders of ConnectYou
                          </td>
                        </tr>
                        <tr>
                          <td
                            style="
                              padding: 4px 0;
                              color: #78a5a4;
                              font-size: 12px;
                            "
                          >
                            www.connectyou.global | support@connectyou.com
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Invoice Info -->
                  <!-- Disclaimer -->
                  <tr>
                    <td
                      style="
                        padding: 15px 40px;
                        text-align: center;
                        background-color: #002326;
                      "
                    >
                      <p
                        style="
                          margin: 0;
                          color: #5f8886;
                          font-size: 12px;
                          line-height: 1.6;
                        "
                      >
                        This receipt has been issued for your records. Please
                        retain a copy for personal or business accounting. If
                        you have any questions regarding this invoice, feel free
                        to
                        <a
                          href="https://connectyou.global/get-in-touch"
                          style="color: #3aa7a3; text-decoration: none"
                          >contact us</a
                        >
                        or email us at
                        <a
                          href="mailto:support@connectyou.com"
                          style="color: #3aa7a3; text-decoration: none"
                          >support@connectyou.com</a
                        >. <br /><br />
                        Please note: This is a system-generated receipt. All
                        amounts are inclusive of applicable taxes unless
                        otherwise stated.
                      </p>
                    </td>
                  </tr>
                  <!-- Copyright -->
                  <tr>
                    <td style="padding: 10px 40px 25px; text-align: center">
                      <p style="margin: 0; color: #78a5a4; font-size: 13px">
                        &copy; 2024 ConnectYou.Global. All rights reserved.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- FOOTER - Extends full width -->
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
`;

  let browser;
  if (process.env.BACKEND_URL === "http://localhost:7000") {
    browser = await puppeteer.launch();
  } else {
    browser = await puppeteer.launch({
      executablePath: "/usr/bin/chromium-browser",
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
  }
  const page = await browser.newPage();

  await page.setContent(htmlTemplate, { waitUntil: "networkidle0" });

  const pdfPath = `${Date.now()}_transaction_receipt_${customerName}.pdf`;

  const publicDir = path.resolve(__dirname, "../../../../public");
  await page.pdf({
    path: path.join(publicDir, "receipt", pdfPath),
    format: "A4",
    printBackground: true,
  });

  await browser.close();

  return pdfPath;
};

const paymentConfirmationCoach = async ({
  userName,
  amount,
  transactionID,
  userEmail,
  fileName,
  curency,
}) => {
  try {
    const publicDir = path.resolve(__dirname, "../../../../public");
    const resolvedPath = path.join(publicDir, "receipt", fileName);
    let userName1 = capitalizeFirstLetter(userName);
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userEmail,
      subject: `Payout Confirmed: Payout has been transefered successfully to your account.`,
      template: "paymentCnfCoach",
      context: {
        userName: userName1,
        amount: amount,
        transactionID,
        date: moment().format("MM-DD-YYYY hh:mm A"),
      },
      attachments: [
        {
          filename: fileName,
          path: resolvedPath,
        },
      ],
    };
    await transportEmail.createEmail({
      mailOptions: mailOptionsForUser,
    });
  } catch (error) {
    console.log(error);
    throw (error = "server error");
  }
};

// paymentConfirmationCoach({
//   userName: `${coachData.name} ${coachData.Lname}`,
//   amount: `${
//     coachPayoutData?.currency ? coachPayoutData?.currency.toUpperCase() : "$"
//   } ${coachPayoutData.amount / 100}`,
//   transactionID: payData.transactionId,
//   userEmail: coachData.email,
//   fileName: receipt,
// });
// const receipt = await generateInvoice({
//   customerEmail: coachData.email,
//   customerName: `${coachData.name} ${coachData.Lname}`,
//   address: `${coachData.fullAddress}`,
//   transactions: [payData],
//   transactionID: txnId,
// });

// if (receipt) {
//   await coachPayoutModel.findByIdAndUpdate(
//     {
//       _id: payoutId,
//     },
//     { $set: { receipt: receipt } }
//   );
// }

exports.payoutFailed = async (event) => {
  try {
    const payoutData = event.data.object;
    const payoutId = payoutData.id;
    const stripeAccountId = event.account; // The connected account ID
    const failureCode = payoutData.failure_code;
    const failureMessage = payoutData.failure_message;

    console.log("Processing payout.failed webhook:", {
      payoutId,
      stripeAccountId,
      failureCode,
      failureMessage,
      amount: payoutData.amount,
      currency: payoutData.currency,
    });

    const payoutRecord = await coachPayoutModel.findOne({
      payoutId: payoutId,
    });

    if (!payoutRecord) {
      console.warn(`No payout record found for Stripe payout ID: ${payoutId}`);
      return;
    }
    const coachData = await CoachModel.findById(payoutRecord.coachId);
    if (!coachData) {
      console.warn(`No coach data found for payout: ${payoutId}`);
      return;
    }
    let failureReason = `Payout failed: ${failureCode || "Unknown error"}`;
    if (failureMessage) {
      failureReason += ` - ${failureMessage}`;
    }
    const updatedPayout = await coachPayoutModel.findByIdAndUpdate(
      payoutRecord._id,
      {
        $set: {
          failed: true,
          failureReason: failureReason,
          status: -1,
          failedDate: new Date().toISOString(),
        },
      },
      { new: true }
    );
    // console.log("Payout marked as failed:", {
    //   payoutId: updatedPayout._id,
    //   coachId: updatedPayout.coachId,
    //   amount: updatedPayout.amount,
    //   failureReason,
    // });
    await CreateNotification({
      user_id: payoutRecord.coachId,
      heading: `Payout Failed - $${payoutRecord.amount / 100}`,
      description: `Your payout request for $${
        payoutRecord.amount / 100
      } has failed. Reason: ${failureReason}. Please check your bank account details and try again. If you need assistance, please contact support.`,
      url: `/c/finances/payout-history`,
      notification_type: "admin",
    });

    if (payoutRecord.transferId) {
      try {
        console.log(
          `Transfer ${payoutRecord.transferId} was successful but payout failed. Consider your reversal policy.`
        );
        // Uncomment below if you want to automatically reverse failed payouts
        await reverseTransferSafely(
          payoutRecord.transferId,
          payoutRecord.amount
        );
        await coachPayoutModel.findByIdAndUpdate(payoutRecord._id, {
          $unset: {
            transferId: "",
            transfer_transactionId: "",
            transfer_destination: "",
            transfer_destination_paymentId: "",
            currency: "",
          },
        });
      } catch (reverseError) {
        console.error("Error handling transfer reversal:", reverseError);
      }
    }
  } catch (error) {
    console.error("Error processing payout.failed webhook:", error);
  }
};
