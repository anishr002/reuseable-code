const moment = require("moment-timezone");
const ordersModel = require("../../../../models/booking");
const mongoose = require("mongoose");
const cartModel = require("../../../../models/cart");
const { addEventToCoachsCalendar } = require("../../../../lib/googleCalender");
const {
  CreateAdminLevelNotification,
  CreateNotification,
} = require("../../../../models/notificationModal");
const capitalizeFirstLetter = require("../../../../lib/capitalizeFirstLetter");
const transportEmail = require("../../../../lib/email");
const { getUserData } = require("../../../../lib/coachee");
const generatePaymentReceipt = require("../../../../utils/generateReceipt");
const { paymentConfirmationUser } = require("../../../../utils/quickEmails");

exports.ChargeCreated = async (event) => {
  try {
    const checkoutData = event.data.object;
    const metadata = checkoutData.metadata || {};
    let userId = metadata.userId ?? null;
    let sessionCount = metadata.sessionCount ?? null;
    let bookingId = metadata.bookingId ?? null;
    let payment_intent2 = checkoutData.payment_intent ?? null;
    let customer_email1 = checkoutData.customer_details?.email ?? null;
    let customer_name1 = checkoutData.customer_details?.name ?? null;
    let customer_phone1 = checkoutData.customer_details?.phone ?? null;
    let customer_city1 = checkoutData.customer_details?.address?.city ?? null;
    let customer_country1 =
      checkoutData.customer_details?.address?.country ?? null;
    let customer_line11 = checkoutData.customer_details?.address?.line1 ?? null;
    let customer_line21 = checkoutData.customer_details?.address?.line2 ?? null;
    let customer_postal_code1 =
      checkoutData.customer_details?.address?.postal_code ?? null;
    let customer_state1 = checkoutData.customer_details?.address?.state ?? null;
    await createMeeting(bookingId);
    const orderDataUpdate = {
      userId,
      payment_intent: payment_intent2 || "",
      customer_email: customer_email1,
      customer_name: customer_name1,
      customer_phone: customer_phone1,
      customer_city: customer_city1,
      customer_country: customer_country1,
      customer_line1: customer_line11,
      customer_line2: customer_line21,
      customer_postal_code: customer_postal_code1,
      customer_state: customer_state1,
      paid: 1,
    };
    await ordersModel.findOneAndUpdate(
      { _id: bookingId },
      {
        $set: orderDataUpdate,
      },
      {
        new: true,
      }
    );
  } catch (error) {
    console.error(`Error in stripe controller ChargeCreated ${error}`);
  }
};

exports.ChargeSuccedded = async (event) => {
  try {
    const charge_succeeded = event.data.object;
    const metadata2 = charge_succeeded.metadata || {};
    const Number5 = Math.floor(10000 + Math.random() * 90000);
    const Number7 = Math.floor(10000 + Math.random() * 90000);
    const TransactionID = `CY_TXN${Number5}_${Date.now()}`;
    const orderId = `CY_ODR${Number7}_${Date.now()}`;
    //payment details
    let chargeId = charge_succeeded.id;
    let amount = charge_succeeded.amount;
    let paymentCreated = charge_succeeded.created;
    let currency = charge_succeeded.currency;
    let payment_intent1 = charge_succeeded.payment_intent;
    //card details
    let cardBrand = charge_succeeded.payment_method_details.card.brand;
    let cardCountry = charge_succeeded.payment_method_details.card.country;
    let card_exp_month = charge_succeeded.payment_method_details.card.exp_month;
    let card_exp_year = charge_succeeded.payment_method_details.card.exp_year;
    let card_last4 = charge_succeeded.payment_method_details.card.last4;
    let card_fingerprint =
      charge_succeeded.payment_method_details.card.fingerprint;
    //customer details
    let customer_city = charge_succeeded.billing_details.address.city;
    let customer_country = charge_succeeded.billing_details.address.country;
    let customer_state = charge_succeeded.billing_details.address.state;
    let customer_line1 = charge_succeeded.billing_details.address.line1;
    let customer_line2 = charge_succeeded.billing_details.address.line2;
    let customer_postal_code =
      charge_succeeded.billing_details.address.postal_code;
    let customer_email = charge_succeeded.billing_details.email;
    let customer_name = charge_succeeded.billing_details.name;
    let customer_phone = charge_succeeded.billing_details.phone;

    await ordersModel.findOneAndUpdate(
      { _id: new mongoose.Types.ObjectId(metadata2.bookingId) },
      {
        $set: {
          TransactionID,
          orderId,
          chargeId,
          amount,
          currency,
          payment_intent: payment_intent1,
          paymentCreated,
          cardBrand,
          card_exp_month,
          card_exp_year,
          card_fingerprint,
          card_last4,
          cardCountry,
          customer_city,
          customer_country,
          customer_line1,
          customer_line2,
          customer_postal_code,
          customer_state,
          customer_email,
          customer_name,
          customer_phone,
          paid: 1,
        },
      }
    );
    const [userData, orderData] = await Promise.all([
      getUserData(metadata2.userId),
      ordersModel.aggregate([
        {
          $match: {
            _id: new mongoose.Types.ObjectId(metadata2.bookingId),
            paid: 1,
          },
        },
        { $sort: { createdAt: -1 } },
        {
          $lookup: {
            from: "booked_sessions",
            localField: "_id",
            foreignField: "bookingId",
            as: "booked_sessionsData",
          },
        },
        {
          $unwind: "$booked_sessionsData",
        },
        {
          $lookup: {
            from: "coachsessions",
            localField: "booked_sessionsData.sessionId",
            foreignField: "_id",
            as: "sessionDetails",
          },
        },
        {
          $unwind: "$sessionDetails",
        },
        {
          $lookup: {
            from: "coaches",
            localField: "sessionDetails.coachId",
            foreignField: "_id",
            as: "sessionDetails.coachData",
          },
        },
        {
          $unwind: "$sessionDetails.coachData",
        },
        {
          $group: {
            _id: "$_id",
            userId: { $first: "$userId" },
            chargeId: { $first: "$chargeId" },
            amount: { $first: "$amount" },
            currency: { $first: "$currency" },
            cardBrand: { $first: "$cardBrand" },
            card_exp_month: { $first: "$card_exp_month" },
            card_exp_year: { $first: "$card_exp_year" },
            card_fingerprint: { $first: "$card_fingerprint" },
            card_last4: { $first: "$card_last4" },
            cardCountry: { $first: "$cardCountry" },
            customer_city: { $first: "$customer_city" },
            customer_country: { $first: "$customer_country" },
            customer_line1: { $first: "$customer_line1" },
            customer_line2: { $first: "$customer_line2" },
            customer_postal_code: { $first: "$customer_postal_code" },
            customer_state: { $first: "$customer_state" },
            customer_email: { $first: "$customer_email" },
            customer_name: { $first: "$customer_name" },
            customer_phone: { $first: "$customer_phone" },
            TransactionID: {
              $first: { $ifNull: ["$TransactionID", "N/A"] },
            },
            orderId: {
              $first: { $ifNull: ["$orderId", "N/A"] },
            },
            createdAt: { $first: "$createdAt" },
            sessionDetails: {
              $push: {
                _id: "$sessionDetails._id",
                title: "$sessionDetails.title",
                price: "$sessionDetails.price",
                coachDetails: {
                  _id: "$sessionDetails.coachData._id",
                  name: "$sessionDetails.coachData.name",
                  Lname: "$sessionDetails.coachData.Lname",
                  userName: "$sessionDetails.coachData.userName",
                  email: "$sessionDetails.coachData.email",
                },
              },
            },
          },
        },
        { $sort: { createdAt: -1 } },
      ]),
    ]);
    const filePath2 =
      orderData.length === 0
        ? ""
        : await generatePaymentReceipt({
            customerDetails: {
              name: userData.name,
              lastName: userData.lastName,
              email: userData.email,
              address: userData.fullAddress,
            },
            orders: orderData,
            transaction_id: TransactionID,
            order_id: orderId,
          });

    await Promise.all([
      ordersModel.updateOne(
        { _id: new mongoose.Types.ObjectId(metadata2.bookingId) },
        {
          $set: {
            receipt: filePath2,
          },
        }
      ),
      paymentConfirmationUser({
        userName: userData.name,
        amount: amount,
        transactionID: TransactionID,
        userEmail: userData.email,
        fileName: filePath2,
        receiverId: metadata2.userId,
        image: userData.image,
      }),
      CreateAdminLevelNotification({
        heading: `There was a booking confirmed!`,
        description: `A coachee have booked a ession, check details by click on the view button.`,
        url: `/bookings/details/${metadata2.bookingId}`,
        notification_type: "payments",
      }),
    ]);
  } catch (error) {
    console.error(`Error in stripe controller chargesuccedded : ${error}`);
  }
};

const createMeeting = async (meetingId) => {
  try {
    const orderData = await ordersModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(meetingId),
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userData",
        },
      },
      { $unwind: "$userData" },
      {
        $lookup: {
          from: "booked_sessions",
          localField: "_id",
          foreignField: "bookingId",
          pipeline: [
            {
              $lookup: {
                from: "coaches",
                localField: "coachId",
                foreignField: "_id",
                as: "coachData",
              },
            },
            { $unwind: "$coachData" },
            {
              $lookup: {
                from: "coachsessions",
                localField: "sessionId",
                foreignField: "_id",
                as: "sessionData",
              },
            },
            { $unwind: "$sessionData" },
          ],
          as: "booked_sessionsData",
        },
      },

      {
        $project: {
          _id: 1,
          createdAt: 1,
          userId: 1,
          orderStatus: 1,
          userData: 1,
          booked_sessionsData: {
            $map: {
              input: "$booked_sessionsData",
              as: "session",
              in: {
                booked_sessionId: "$$session._id",
                cartId: "$$session.cartId",
                sessionDate: "$$session.sessionDate",
                sessionDateUpdated: "$$session.sessionDateUpdated",
                session_id: "$$session.sessionData._id",
                coachId: "$$session.sessionData.coachId",
                title: "$$session.sessionData.title",
                price: "$$session.sessionData.price",
                type: "$$session.sessionData.type",
                description: "$$session.sessionData.description",
                coach_id: "$$session.coachData._id",
                name: "$$session.coachData.name",
                Lname: "$$session.coachData.Lname",
                email: "$$session.coachData.email",
                image: "$$session.coachData.image",
                gender: "$$session.coachData.gender",
                title_line: "$$session.coachData.title_line",
                zoomMeetingURL: "$$session.coachData.zoomMeetingURL",
                timeZone: "$$session.coachData.timeZone",
              },
            },
          },
        },
      },
    ]);
    let bookingArray = orderData[0]?.booked_sessionsData;
    const cartIds = [...new Set(bookingArray.map((p) => p.cartId))];
    await cartModel.deleteMany({ _id: { $in: cartIds } });
    // seprated the items in the cart acc to the coach Id
    const sessionList = Object.values(
      bookingArray.reduce((acc, booking) => {
        if (!acc[booking.coachId]) {
          acc[booking.coachId] = [];
        }
        acc[booking.coachId].push(booking);
        return acc;
      }, {})
    );
    let userData = orderData[0].userData;
    let bookingId = orderData[0]._id;
    sessionList.map((sessions) => {
      sessionConfirmationEmailCoach2(sessions, userData, bookingId);
      for (const session of sessions) {
        addEventToCoachsCalendar(session);
      }
    });
    sessionConfirmationEmailUser2(sessionList, userData, bookingId);
    return true;
  } catch (error) {
    console.log(`Error in Create Meeting Function ${error}`);
  }
};

const sessionConfirmationEmailCoach2 = async (
  sessionList,
  userData,
  bookingId
) => {
  try {
    // console.log({ coachData: sessionList[0] });
    const coachEmail = sessionList[0].email;
    const coachName = sessionList[0].name;
    const timeZone = sessionList[0].timeZone;
    const zoomURL = sessionList[0].zoomMeetingURL;
    sessionList = sessionList.map((sessions) => {
      const sessionUpdatedDate = moment(sessions.sessionDate)
        .tz(timeZone)
        .format("DD-MM-YYYY");
      const sessionUpdatedTime = `${moment(sessions.sessionDate)
        .tz(timeZone)
        .format("hh:mm A")} - ${moment(sessions.sessionDate)
        .tz(timeZone)
        .add(1, "hours")
        .format("hh:mm A")}`;
      return {
        ...sessions, // Keep existing session data
        sessionUpdatedDate, // Add new sessionUpdatedDate
        sessionUpdatedTime, // Add new sessionUpdatedTime
      };
    });
    const bookingDetailsLink = encodeURI(
      `${process.env.FRONTEND_URL_web}/c/bookings/upcoming?details=${bookingId}`
    );
    const userName = userData.name;
    let userName1 = capitalizeFirstLetter(userName);
    let coachName1 = capitalizeFirstLetter(coachName);
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: coachEmail,
      subject: `Coaching Session Confirmation with ${userName1}`,
      template: "sessionConfirmationEmailCoach",
      context: {
        userName: `${userName1} ${userData.lastName}`,
        coachName: coachName1,
        zoomURL,
        timeZone,
        sessionList,
        image: userData.image,
        backendURL: `${process.env.BACKEND_URL}`,
      },
    };

    Promise.all([
      CreateNotification({
        heading: "Congratulations, you have a new session booking.",
        description: `${userName1} ${userData.lastName} have booked your session, check more details by clicking on the view button.`,
        user_id: `${sessionList[0].coachId}`,
        url: bookingDetailsLink,
        type: "bookings",
      }),
      transportEmail.createEmail({ mailOptions: mailOptionsForUser }),
    ]);
  } catch (error) {
    console.log(error);
  }
};

const sessionConfirmationEmailUser2 = async (
  sessionList,
  userData,
  bookingId
) => {
  try {
    // console.log({ coacheeData: userData });
    const userEmail = userData.email;
    const userName = userData.name;
    const timeZone = userData.timeZone;
    sessionList = sessionList.map((sessionsArray) => {
      return sessionsArray.map((sessions) => {
        const sessionUpdatedDate = moment(sessions.sessionDate)
          .tz(timeZone)
          .format("DD-MM-YYYY");
        const sessionUpdatedTime = `${moment(sessions.sessionDate)
          .tz(timeZone)
          .format("hh:mm A")} - ${moment(sessions.sessionDate)
          .tz(timeZone)
          .add(1, "hours")
          .format("hh:mm A")}`;
        // Return the updated session object with the new values
        return {
          ...sessions, // Keep existing session data
          sessionUpdatedDate, // Add new sessionUpdatedDate
          sessionUpdatedTime, // Add new sessionUpdatedTime
        };
      });
    });

    let userName1 = capitalizeFirstLetter(userName);
    const mailOptionsForUser = {
      from: "ConnectYou <itadmin@erickson.edu>",
      to: userEmail,
      subject: `${userName1} Your Coaching Session Confirmation.`,
      template: "sessionConfirmationEmailUser",
      context: {
        userName: userName1,
        timeZone,
        sessionList,
        bookingId,
        backendURL: `${process.env.BACKEND_URL}`,
        image: userData.image,
      },
    };
    Promise.all([
      CreateNotification({
        user_id: userData._id,
        heading: "Payment successfull !",
        type: "bookings",
        description:
          "You payment was successfull, sessions that were in your cart have been booked successfully, for more details click on the view button. ",
        url: `${process.env.FRONTEND_URL_web}/u/bookings/upcoming?details=${bookingId}`,
      }),
      transportEmail.createEmail({ mailOptions: mailOptionsForUser }),
    ]);
  } catch (error) {
    console.log(error);
  }
};
