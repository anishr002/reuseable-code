const CoachModel = require("../../../../models/coach");
exports.updated = async (event) => {
  try {
    console.log("Processing account.updated webhook:", event.id);
    const account = event.data.object;
    const accountId = account.id;
    const coach = await CoachModel.findOne({ stripe_accID: accountId });
    if (!coach) {
      console.log(`coach not found for Stripe account ID: ${accountId}`);
      return;
    }
    const updateData = {};
    if (account.default_currency) {
      updateData.currency = account.default_currency.toUpperCase();
    }
    if (account.country) {
      const countryDetails = {
        code: account.country,
        currency: account.default_currency?.toUpperCase() || "",
      };
      updateData.stripeCountryDetails = countryDetails;
    }
    if (account.individual?.id) {
      updateData.accHolderId = account.individual.id;
    }
    updateData.stripe_addStatus = 1;
    await CoachModel.findByIdAndUpdate(
      coach._id,
      { $set: updateData },
      { new: true }
    );
    // console.log(
    //   `Successfully updated coach ${coach.email} with account data:`,
    //   updateData
    // );
  } catch (error) {
    console.error("Error processing account.updated webhook:", error);
    throw error;
  }
};
