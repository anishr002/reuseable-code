const express = require("express");
const router = express.Router();

const validationRoutes = require("./public-apis/routes/validations");
router.use("/public/validate", validationRoutes);
//public apis
const publicCoachRoutes = require("./public-apis/routes/coach");
router.use("/public/coach", publicCoachRoutes);
const publicSessionRoutes = require("./public-apis/routes/session");
router.use("/public/sessions", publicSessionRoutes);

//secure apis
// /coach/
const coachBookingRoutes = require("./coach/routes/bookings");
router.use("/auth/coach/bookings", coachBookingRoutes);
const coachSessionsRoutes = require("./coach/routes/coachingSessions");
router.use("/auth/coach/sessions", coachSessionsRoutes);
const coachReviewsRoutes = require("./coach/routes/review");
router.use("/auth/coach/reviews", coachReviewsRoutes);
const coachChatRoutes = require("./coach/routes/chat");
router.use("/auth/coach/chat", coachChatRoutes);
const coachResourcesRoutes = require("./coach/routes/resources");
router.use("/auth/coach/resources", coachResourcesRoutes);

// /coachee/
const coacheeBookingRoutes = require("./user/routes/bookings");
router.use("/auth/coachee/bookings", coacheeBookingRoutes);
const coacheeReviewRoutes = require("./user/routes/reviews");
router.use("/auth/coachee/reviews", coacheeReviewRoutes);
const coacheeChatRoutes = require("./user/routes/chat");
router.use("/auth/coachee/chat", coacheeChatRoutes);

module.exports = router;
