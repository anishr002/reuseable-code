require("dotenv").config();
const jwt = require("jsonwebtoken");
const coachModel = require("../../../models/coach");
const coacheeModel = require("../../../models/user");
const transportEmail = require("../../../lib/email");

const matchEntity = async ({ email }) => {
  try {
    let Entity;
    const [coach, coachee] = await Promise.allSettled([
      coachModel.find({
        $or: [{ email: email }, { userName: email }],
      }),
      coacheeModel.find({
        $or: [{ email: email }, { userName: email }],
      }),
    ]);
    // console.log({ coach, coachee });
    if (coach.value.length > 0) {
      Entity = { model: coachModel, data: coach.value[0] };
    } else if (coachee.value.length > 0) {
      Entity = { model: coacheeModel, data: coachee.value[0] };
    } else {
      return null;
    }
    return Entity;
  } catch (error) {
    console.log(error);
    return null;
  }
};

exports.validateUserName = async (req, res) => {
  try {
    let decoded;
    const tokenHeader = req.header("Authorization");
    if (tokenHeader) {
      const token = tokenHeader.replace("Bearer ", "");
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    }
    const { username } = req.params;
    if (decoded && decoded.userName === username) {
      return res.status(200).json({
        success: true,
        message: "You are using your current username.",
        availability: true,
      });
    }
    const match = { userName: username };

    const [coach, coachee] = await Promise.allSettled([
      coachModel.find(match),
      coacheeModel.find(match),
    ]);
    // console.log({ coach, coachee });
    if (coach.value.length === 0 && coachee.value.length === 0) {
      return res.status(200).json({
        success: true,
        message: "Username is available",
        availability: true,
      });
    } else {
      return res.status(200).json({
        success: true,
        message: "Username is not available, Please try another username",
        availability: false,
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || "Internal server error",
    });
  }
};

exports.requestOTPRes = async (req, res) => {
  try {
    const { email } = req.body;
    const otpGen = req.otpGen;
    const otpObject = req.otpObject;
    const Entity = await matchEntity({ email: email });
    // console.log({ Entity });
    if (!Entity) {
      return res.status(404).json({
        success: false,
        message: "The Account your are looking for is not available",
      });
    } else {
      if (otpObject.deliverEmail && otpGen && otpObject) {
        // console.log(otpObject);
        const update = await Entity.model.updateOne(
          { email },
          {
            $set: {
              otp: otpObject.otp,
              otpDate: otpObject.otpExpiry,
              otpType: otpObject.otpType,
            },
          }
        );
        // console.log({ update });
        if (update.modifiedCount > 0) {
          return res.status(200).json({
            scuccess: true,
            message: "OTP has been sent successfully to the registered email.",
          });
        } else {
          throw new Error("Unable to update OTP request, Please try again.");
        }
      } else {
        throw new Error("There was some internal server error");
      }
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.verifyEmailVerificationOTPRes = async (req, res) => {
  try {
    const otpVerification = req.otpVerification;
    if (otpVerification) {
      return res.status(200).json({
        success: true,
        message: "OTP verification was successfull, registration completed.",
      });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Something Went wrong !" });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};
