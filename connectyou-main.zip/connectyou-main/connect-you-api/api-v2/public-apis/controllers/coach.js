const mongoose = require("mongoose");
const CoachModel = require("../../../models/coach");
const coachingSessionsModel = require("../../../models/coachSession");

exports.getApprovedCoaches = async (req, res) => {
  try {
    // console.log({ q: req.query });
    let matchCriteria = {};
    let matchCriteria2 = {};
    let industriesMatch = {};
    let coachCredentialsMatch = {};
    if (req.query.coachCredentials) {
      let coachCredentialsArray = req.query.coachCredentials
        .split(/,(?![^()]*\))/)
        .map((item) => item.trim());
      if (coachCredentialsArray.length > 0) {
        coachCredentialsMatch = {
          "coachcredentials.title": {
            $in: coachCredentialsArray,
          },
        };
      }
    }
    if (req.query.rating) {
      let rating = Number(req.query.rating);
      matchCriteria.averageRating = { $gte: rating };
    }
    if (
      req.query.country &&
      req.query.country !== "null" &&
      req.query.country !== ""
    ) {
      let countries = req.query.country.split(",");
      matchCriteria2.country = { $in: countries };
    }
    // experience Year filter
    const { yearsOfExpFrom, yearsOfExpTo, falseUpperBoundExp } = req.query;
    let experienceQuery = {};
    if (
      yearsOfExpFrom &&
      !isNaN(yearsOfExpFrom) &&
      Number(yearsOfExpFrom) !== 0
    ) {
      experienceQuery.$gte = Number(yearsOfExpFrom);
    }
    if (
      yearsOfExpTo &&
      !isNaN(yearsOfExpTo) &&
      Number(yearsOfExpTo) !== 0 &&
      falseUpperBoundExp !== "true"
    ) {
      experienceQuery.$lte = Number(yearsOfExpTo);
    }
    if (Object.keys(experienceQuery).length > 0) {
      matchCriteria.experienceYear = experienceQuery;
    }
    if (req.query.searchQuery) {
      let searchQuery = req.query.searchQuery.trim();
      matchCriteria.$or = [
        { name: { $regex: new RegExp(searchQuery, "i") } },
        { Lname: { $regex: new RegExp(searchQuery, "i") } },
        // { email: { $regex: new RegExp(searchQuery, "i") } },
        { country: { $regex: new RegExp(searchQuery, "i") } },
        { city: { $regex: new RegExp(searchQuery, "i") } },
        { userName: { $regex: new RegExp(searchQuery, "i") } },
      ];
    }

    if (req.query.gender) {
      let genderArray = req.query.gender.split(",");
      matchCriteria.gender = { $in: genderArray };
    }

    // Check if languages are provided and add them to match criteria
    if (req.query.languages) {
      let languages = req.query.languages.split(",");
      matchCriteria2.$expr = {
        $setIsSubset: [languages, "$languages"],
      };
    }

    if (req.query.industries) {
      let industries = req.query.industries.split(",");
      industriesMatch.$expr = {
        $setIsSubset: [industries, "$industries"],
      };
    }

    // Check if specialities are provided and add them to match criteria
    if (req.query.specialities) {
      let coachingSpecialities = req.query.specialities.split(",");
      matchCriteria.$expr = {
        ...matchCriteria.$expr,
        $setIsSubset: [coachingSpecialities, "$coachingSpecialities"],
      };
    }
    if (req.query.coaching_focus) {
      let coaching_focusFilter = req.query.coaching_focus.split(",");
      console.log({ coaching_focusFilter });
      matchCriteria.$expr = {
        ...matchCriteria.$expr,
        $gt: [
          {
            $size: {
              $setIntersection: [
                coaching_focusFilter,
                {
                  $map: {
                    input: { $ifNull: ["$coaching_focus_area", []] },
                    as: "focus",
                    in: "$$focus.tag",
                  },
                },
              ],
            },
          },
          0,
        ],
      };
    }

    let basicMatch = {
      delete: 0,
      approve: 1,
      // calendarStatus: 1,
      image: { $ne: "" },
    };

    if (req.query.npcoaching === "true") {
      basicMatch.nonProfitCoaching = {
        $exists: true,
        $eq: true,
      };
    }
    let priceQuery = {};
    const { priceFrom, priceTo, falseUpperBoundPrice } = req.query;
    if (priceFrom || priceTo) {
      priceQuery = {
        deleted: 0,
        status: true,
      };
      if (priceFrom && !isNaN(priceFrom) && Number(priceFrom) !== 0) {
        priceQuery.price = { ...priceQuery.price, $gte: Number(priceFrom) };
      }
      if (
        priceTo &&
        !isNaN(priceTo) &&
        Number(priceTo) !== 0 &&
        falseUpperBoundPrice !== "true"
      ) {
        priceQuery.price = { ...priceQuery.price, $lte: Number(priceTo) };
      }
    }
    // console.log({ priceQuery });

    const match = { $match: matchCriteria }; //filter provoided data
    const match2 = { $match: matchCriteria2 }; //filter languages data
    const industriesMatchFilter = { $match: industriesMatch }; //filter industries Match data
    const coachCredentialsMatchFilter = { $match: coachCredentialsMatch };
    let pageNo = req.query.pageNo || 1;
    pageNo = Number(pageNo);
    const limit = Number(req.query.limit) || 10;
    const skip = pageNo * limit - limit;

    const coachList = await CoachModel.aggregate([
      {
        $match: basicMatch,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $match: {
          $expr: {
            $or: [
              { $ne: ["$coachcredentials", []] },
              { $ne: ["$coachcertificates", []] },
            ],
          },
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: 0,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
      match,
      match2,
      industriesMatchFilter,
      coachCredentialsMatchFilter,
      ...(Object.keys(priceQuery).length > 0
        ? [
            {
              $lookup: {
                from: "coachsessions",
                let: { coachId: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: { $eq: ["$coachId", "$$coachId"] },
                      ...priceQuery,
                    },
                  },
                ],
                as: "matchedSessions",
              },
            },
            {
              $match: {
                matchedSessions: { $ne: [] },
              },
            },
          ]
        : []),
      {
        $project: {
          _id: 1,
          name: 1,
          Lname: 1,
          freeTrial: 1,
          image: 1,
          about_me: 1,
          title_line: 1,
          gender: 1,
          averageRating: 1,
          totalRatings: 1,
          country: 1,
          city: 1,
          userName: 1,
          languages: 1,
          industries: 1,
          coachingSpecialities: 1,
          experienceYear: 1,
          coachcredentials: 1,
        },
      },

      {
        $facet: {
          pageInfo: [{ $count: "count" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    ]);
    let totalResults = 0;
    let totalPages = 1;
    if (coachList[0].pageInfo.length > 0) {
      totalPages = Math.ceil(coachList[0].pageInfo[0].count / limit);
      totalResults = coachList[0].pageInfo[0].count;
    }
    const coachListData = coachList[0].data;
    const response = {
      success: true,
      coachList: coachListData,
      totalPages,
      totalResults,
      limit,
      currentPage: pageNo,
      message: "Coaches list retrieved successfully.",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getCoachDetails = async (req, res) => {
  try {
    const id = req.params.id;
    const coachDetail = await CoachModel.aggregate([
      {
        $match: {
          _id: mongoose.Types.ObjectId.createFromHexString(id),
          delete: 0,
          approve: 1,
          // calendarStatus: 1,
          image: { $ne: "" },
        },
      },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "coachexperiences",
          localField: "_id",
          foreignField: "coachId",
          as: "coachexperiences",
        },
      },
      {
        $lookup: {
          from: "coacheducations",
          localField: "_id",
          foreignField: "coachId",
          as: "coacheducations",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: null,
            },
          },
          totalRatings: { $size: "$ordersRatingsData" },
        },
      },
      {
        $project: {
          name: 1,
          Lname: 1,
          userName: 1,
          email: 1,
          gender: 1,
          DOB: 1,
          approve: 1,
          image: 1,
          createdAt: 1,
          about_me: 1,
          title_line: 1,
          languages: 1,
          timeZone: 1,
          fullAddress: 1,
          coachingSpecialities: 1,
          coachcredentials: {
            $map: {
              input: "$coachcredentials",
              as: "credential",
              in: {
                title: "$$credential.title",
                image: "$$credential.image",
                startDate: "$$credential.startDate",
                workingOn: "$$credential.workingOn",
                endDate: "$$credential.endDate",
              },
            },
          },
          coachcertificates: {
            $map: {
              input: "$coachcertificates",
              as: "coachcertificates",
              in: {
                title: "$$coachcertificates.title",
                certificateFile: "$$coachcertificates.certificateFile",
                startDate: "$$coachcertificates.startDate",
                workingOn: "$$coachcertificates.workingOn",
                endDate: "$$coachcertificates.endDate",
              },
            },
          },
          coachexperiences: {
            $map: {
              input: "$coachexperiences",
              as: "experience",
              in: {
                organization: "$$experience.organization",
                position: "$$experience.position",
                startDate: "$$experience.startDate",
                workingOn: "$$experience.workingOn",
              },
            },
          },
          coacheducations: {
            $map: {
              input: "$coacheducations",
              as: "education",
              in: {
                degree: "$$education.degree",
                endDate: "$$education.endDate",
                organization: "$$education.organization",
                startDate: "$$education.startDate",
              },
            },
          },
          totalRatings: 1,
          averageRating: 1,
          experienceYear: 1,
          country: 1,
          city: 1,
          industries: 1,
        },
      },
    ]);

    if (coachDetail.length > 0) {
      let data = {
        name: coachDetail[0].name,
        Lname: coachDetail[0].Lname,
        userName: coachDetail[0].userName,
        email: coachDetail[0].email,
        gender: coachDetail[0].gender,
        DOB: coachDetail[0].DOB,
        approve: coachDetail[0].approve,
        image: coachDetail[0].image,
        createdAt: coachDetail[0].createdAt,
        about_me: coachDetail[0].about_me,
        title_line: coachDetail[0].title_line,
        languages: coachDetail[0].languages,
        timeZone: coachDetail[0].timeZone,
        fullAddress: coachDetail[0].fullAddress,
        coachingSpecialities: coachDetail[0].coachingSpecialities,
        coachcredentials: coachDetail[0].coachcredentials,
        coachcertificates: coachDetail[0].coachcertificates,
        coachexperiences: coachDetail[0].coachexperiences,
        coacheducations: coachDetail[0].coacheducations,
        totalRatings: coachDetail[0].totalRatings,
        averageRating: coachDetail[0].averageRating,
        experienceYear: coachDetail[0].experienceYear,
        country: coachDetail[0].country,
        city: coachDetail[0].city,
        industries: coachDetail[0].industries,
      };
      const response = {
        success: true,
        data: data,
        message: "coach details retrieved successfully !",
      };
      return res.status(200).json(response);
    } else {
      return res
        .status(404)
        .json({ success: false, message: "Coach not found" });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.getCoachSessionsListing = async (req, res) => {
  try {
    const coachId = req.params.id;
    const sessionList = await coachingSessionsModel.find({
      coachId,
      deleted: 0,
      status: true,
    });
    const response = {
      success: true,
      data: sessionList,
      message: "Session for the coach retrieved successfully !",
    };
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server error" });
  }
};

//only for coachee // with added token requirment // my coahces
exports.myCoaches = async (req, res) => {
  try {
    const coacheeId = req.user._id;
    console.log(coacheeId);
    let matchCriteria = {};
    let matchCriteria2 = {};
    let industriesMatch = {};
    let coachCredentialsMatch = {};

    if (req.query.coachCredentials) {
      let coachCredentialsArray = req.query.coachCredentials
        .split(/,(?![^()]*\))/)
        .map((item) => item.trim());
      if (coachCredentialsArray.length > 0) {
        coachCredentialsMatch = {
          "coachcredentials.title": {
            $in: coachCredentialsArray,
          },
        };
      }
    }

    if (req.query.rating) {
      let rating = Number(req.query.rating);
      matchCriteria.averageRating = { $gte: rating };
    }

    if (
      req.query.country &&
      req.query.country !== "null" &&
      req.query.country !== ""
    ) {
      let countries = req.query.country.split(",");
      matchCriteria2.country = { $in: countries };
    }

    // experience Year filter
    const { yearsOfExpFrom, yearsOfExpTo, falseUpperBoundExp } = req.query;
    let experienceQuery = {};
    if (
      yearsOfExpFrom &&
      !isNaN(yearsOfExpFrom) &&
      Number(yearsOfExpFrom) !== 0
    ) {
      experienceQuery.$gte = Number(yearsOfExpFrom);
    }
    if (
      yearsOfExpTo &&
      !isNaN(yearsOfExpTo) &&
      Number(yearsOfExpTo) !== 0 &&
      falseUpperBoundExp !== "true"
    ) {
      experienceQuery.$lte = Number(yearsOfExpTo);
    }
    if (Object.keys(experienceQuery).length > 0) {
      matchCriteria.experienceYear = experienceQuery;
    }

    if (req.query.searchQuery) {
      let searchQuery = req.query.searchQuery.trim();
      matchCriteria.$or = [
        { name: { $regex: new RegExp(searchQuery, "i") } },
        { Lname: { $regex: new RegExp(searchQuery, "i") } },
        { country: { $regex: new RegExp(searchQuery, "i") } },
        { city: { $regex: new RegExp(searchQuery, "i") } },
        { userName: { $regex: new RegExp(searchQuery, "i") } },
      ];
    }

    if (req.query.gender) {
      let genderArray = req.query.gender.split(",");
      matchCriteria.gender = { $in: genderArray };
    }

    if (req.query.languages) {
      let languages = req.query.languages.split(",");
      matchCriteria2.$expr = {
        $setIsSubset: [languages, "$languages"],
      };
    }

    if (req.query.industries) {
      let industries = req.query.industries.split(",");
      industriesMatch.$expr = {
        $setIsSubset: [industries, "$industries"],
      };
    }

    if (req.query.specialities) {
      let coachingSpecialities = req.query.specialities.split(",");
      matchCriteria.$expr = {
        ...matchCriteria.$expr,
        $setIsSubset: [coachingSpecialities, "$coachingSpecialities"],
      };
    }

    if (req.query.coaching_focus) {
      let coaching_focusFilter = req.query.coaching_focus.split(",");

      matchCriteria.$expr = {
        ...matchCriteria.$expr,
        $gt: [
          {
            $size: {
              $setIntersection: [
                coaching_focusFilter,
                {
                  $map: {
                    input: { $ifNull: ["$coaching_focus_area", []] },
                    as: "focus",
                    in: "$$focus.tag",
                  },
                },
              ],
            },
          },
          0,
        ],
      };
    }

    let basicMatch = {
      delete: 0,
      approve: 1,
      image: { $ne: "" },
    };

    if (req.query.npcoaching === "true") {
      basicMatch.nonProfitCoaching = {
        $exists: true,
        $eq: true,
      };
    }
    let priceQuery = {};
    const { priceFrom, priceTo, falseUpperBoundPrice } = req.query;
    if (priceFrom || priceTo) {
      priceQuery = {
        deleted: 0,
        status: true,
      };
      if (priceFrom && !isNaN(priceFrom) && Number(priceFrom) !== 0) {
        priceQuery.price = { ...priceQuery.price, $gte: Number(priceFrom) };
      }
      if (
        priceTo &&
        !isNaN(priceTo) &&
        Number(priceTo) !== 0 &&
        falseUpperBoundPrice !== "true"
      ) {
        priceQuery.price = { ...priceQuery.price, $lte: Number(priceTo) };
      }
    }
    // console.log({ priceQuery });
    const coachList = await CoachModel.aggregate([
      {
        $match: basicMatch,
      },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "coachcredentials",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcredentials",
        },
      },
      {
        $lookup: {
          from: "coachcertificates",
          localField: "_id",
          foreignField: "coachId",
          as: "coachcertificates",
        },
      },
      {
        $lookup: {
          from: "orders-ratings",
          localField: "_id",
          foreignField: "coachId",
          as: "ordersRatingsData",
        },
      },
      {
        $lookup: {
          from: "bookings",
          let: { coachId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$coachId", "$$coachId"] },
                    { $eq: ["$userId", coacheeId] },
                    { $eq: ["$paid", 1] },
                  ],
                },
              },
            },
          ],
          as: "orderData",
        },
      },
      {
        $lookup: {
          from: "booked_sessions",
          let: { coachId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$coachId", "$$coachId"] },
                    { $eq: ["$userId", coacheeId] },
                  ],
                },
              },
            },
          ],
          as: "bookingData",
        },
      },
      {
        $match: {
          $or: [{ orderData: { $ne: [] } }, { bookingData: { $ne: [] } }],
        },
      },
      {
        $match: {
          $expr: {
            $or: [
              { $ne: ["$coachcredentials", []] },
              { $ne: ["$coachcertificates", []] },
            ],
          },
        },
      },
      {
        $addFields: {
          averageRating: {
            $cond: {
              if: { $gt: [{ $size: "$ordersRatingsData" }, 0] },
              then: {
                $round: [{ $avg: "$ordersRatingsData.ratingNumber" }, 2],
              },
              else: 0,
            },
          },
          totalRatings: {
            $size: "$ordersRatingsData",
          },
        },
      },
      { $match: matchCriteria },
      { $match: matchCriteria2 },
      { $match: industriesMatch },
      { $match: coachCredentialsMatch },
      ...(Object.keys(priceQuery).length > 0
        ? [
            {
              $lookup: {
                from: "coachsessions",
                let: { coachId: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: { $eq: ["$coachId", "$$coachId"] },
                      ...priceQuery,
                    },
                  },
                ],
                as: "matchedSessions",
              },
            },
            {
              $match: {
                matchedSessions: { $ne: [] },
              },
            },
          ]
        : []),
      {
        $project: {
          _id: 1,
          name: 1,
          Lname: 1,
          freeTrial: 1,
          image: 1,
          about_me: 1,
          title_line: 1,
          gender: 1,
          averageRating: 1,
          totalRatings: 1,
          country: 1,
          city: 1,
          userName: 1,
          languages: 1,
          industries: 1,
          coachingSpecialities: 1,
          experienceYear: 1,
          coachcredentials: 1,
        },
      },
    ]);
    const response = {
      success: true,
      myCoaches: coachList,
      message: " My Coaches list retrieved successfully.",
    };
    // console.log(coachList);
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};


// added on- 04-29-2025- unpushed
exports.disabledSessionoDateSlotsGen = async (req, res) => {
  try {
    const { maxDateStr, userId, timeZone, coachId } = req.body;
    const today = dayjs().tz(timeZone).startOf("day");
    const maxDate = dayjs(maxDateStr).tz(timeZone).endOf("day");
    let allSlots = [];
    for (
      let currDate = today;
      currDate.isBefore(maxDate) || currDate.isSame(maxDate, "day");
      currDate = currDate.add(1, "day")
    ) {
      const startOfDay = currDate.startOf("day").utc().toDate();
      const endOfDay = currDate.endOf("day").utc().toDate();
      const data = await booked_sessions
        .find({
          $or: [
            {
              coachId: new mongoose.Types.ObjectId(coachId),
              sessionStatus: 0,
              sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
            },
            ...(userId
              ? userId !== "" && mongoose.Types.ObjectId.isValid(userId)
                ? {
                    userId: new mongoose.Types.ObjectId(userId),
                    sessionStatus: 0,
                    sessionDateUpdated: { $gte: startOfDay, $lt: endOfDay },
                  }
                : {}
              : {}),
          ],
        })
        .select("-_id sessionDateUpdated");
      const slots = data.map((entry) => {
        const from = dayjs(entry.sessionDateUpdated).tz(timeZone);
        return {
          from: from.format("HH:mm"),
          to: from.add(1, "hour").format("HH:mm"),
        };
      });
      if (slots.length > 0) {
        allSlots.push({
          date: currDate.format("YYYY-MM-DD"), // or return as `currDate` if using dayjs object directly
          slots,
        });
      }
    }
    return res.status(200).json({
      success: true,
      data: allSlots,
      message: "Disabled slots retrieved successfully",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};
