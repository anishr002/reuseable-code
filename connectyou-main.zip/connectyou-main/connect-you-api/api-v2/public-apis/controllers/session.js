const sessionModel = require("../../../models/coachSession");
const mongoose = require("mongoose");

exports.getDetails = async (req, res) => {
  try {
    const sessionId = req.params.id;
    const data = await sessionModel.aggregate([
      {
        $match: {
          _id: mongoose.Types.ObjectId.createFromHexString(sessionId),
        },
      },
      {
        $lookup: {
          from: "coaches",
          localField: "coachId",
          foreignField: "_id",
          as: "coachDetails",
          pipeline: [
            {
              $project: {
                _id: 1,
                timeZone: 1,
                name: 1,
                Lname: 1,
                email: 1,
                live: 1,
                lastSeen: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$coachDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
    let status = 200;
    let response = {};
    if (data) {
      response = {
        success: true,
        data: data[0],
        message: "Fetched Session details successfully",
      };
      status = 200;
    } else {
      status = 404;
      response = {
        success: false,
        message: "Session not found !",
      };
    }
    return res.status(status).json(response);
  } catch (error) {
    console.error("Error in getAllReview / api-v2-coach:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};
