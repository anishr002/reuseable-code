// setup router
const express = require("express");
const router = express.Router();
// router config
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
// validators setup
const { body, param } = require("express-validator");
const verificationMiddlewar = require("../../../middleware/emailVerification");
//controller
const controller = require("../controllers/validation");
const validation = require("../../../middleware/validation");

router.get(
  "/username-avalibility/:username",
  [
    param("username")
      .trim()
      .exists()
      .withMessage("Please enter username")
      .isString()
      .withMessage("Username can only contain characters"),
  ],
  validation.response,
  controller.validateUserName
);

router.post(
  "/get-email-verification-otp",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter a valid email")
      .escape(),
  ],
  validation.response,
  verificationMiddlewar.generateEmailVerificationOTP,
  controller.requestOTPRes
);

router.post(
  "/verify-email-verification-otp",
  [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Please enter a valid email")
      .escape(),
    body("receivedOTP")
      .trim()
      .notEmpty()
      .withMessage("Please enter a valid OTP")
      .escape(),
  ],
  validation.response,
  verificationMiddlewar.verifyEmailVerificationOTP,
  controller.verifyEmailVerificationOTPRes
);
// exporrt router
module.exports = router;
