// setup router
const express = require("express");
const router = express.Router();
// router config
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
const { body, param } = require("express-validator");
const controller = require("../controllers/coach");
const validation = require("../../../middleware/validation");
const coacheeAuth = require("../../../middleware/authTokenUser");

router.get("/fetch-coach-list", controller.getApprovedCoaches);
router.get(
  "/fetch-coach-details/:id",
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  validation.response,
  controller.getCoachDetails
);
router.get(
  "/fetch-coach-sessions-list/:id",
  [param("id").trim().isMongoId().withMessage("Invalid url")],
  validation.response,
  controller.getCoachSessionsListing
);
router.get(
  "/fetch-coach-list/my-coaches/:coacheeId",
  [param("coacheeId").trim().isMongoId().withMessage("Invalid url")],
  validation.response,
  coacheeAuth.authTokenUser,
  controller.myCoaches
);


router.get(
  "/fetch-disabled-coach-session-dates/:coachId",
  [param("coachId").trim().isMongoId().withMessage("Invalid url")],
  validation.response,
  coacheeAuth.authTokenUser,
  controller.disabledSessionoDateSlotsGen
);

module.exports = router;
