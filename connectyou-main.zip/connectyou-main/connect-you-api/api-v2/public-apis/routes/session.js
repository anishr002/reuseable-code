// setup router
const express = require("express");
const router = express.Router();
// router config
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
const { param } = require("express-validator");
const controller = require("../controllers/session");
const validation = require("../../../middleware/validation");

router.get(
  "/session-details/:id",
  [
    param("id")
      .trim()
      .exists()
      .withMessage("Inavlid URL")
      .isMongoId()
      .withMessage("Invalid URL"),
  ],
  validation.response,
  controller.getDetails
);

module.exports = router;
