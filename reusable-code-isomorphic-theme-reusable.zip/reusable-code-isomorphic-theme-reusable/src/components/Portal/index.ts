export { Portal } from '@/components/Portal/Portal';
export { OptionalPortal } from '@/components/Portal/OptionalPortal';

export type { PortalProps } from '@/components/Portal/Portal';
export type { OptionalPortalProps } from '@/components/Portal/OptionalPortal';
