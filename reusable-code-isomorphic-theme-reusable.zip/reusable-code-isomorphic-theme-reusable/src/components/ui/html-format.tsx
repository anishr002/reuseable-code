import React from 'react';

export const HtmlFormat = ({ description }: { description: string }) => {
  return (
    <div dangerouslySetInnerHTML={{ __html: description }} className='truncate max-w-[17rem]'></div>
  )
}

export const HtmlFormatEmail = ({ description }: { description: string }) => {
  return (
    <div style={{ maxWidth: '400px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} dangerouslySetInnerHTML={{ __html: description }} ></div>
  )
}

export const HtmlFormatDetails = ({ description }: { description: string }) => {
  return (
    <span dangerouslySetInnerHTML={{ __html: description }}></span>
  )
}
