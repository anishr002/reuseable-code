import cn from '@/utils/class-names';
import moment from 'moment';

interface DateCellProps {
  date: string; // Expecting the date as a string
  className?: string;
  dateFormat?: string;
  dateClassName?: string;
  timeFormat?: string;
  timeClassName?: string;
}

export default function DateCell({
  date,
  className,
  timeClassName,
  dateClassName,
  dateFormat = 'MMMM D, YYYY', // Default date format
  timeFormat = 'h:mm A', // Default time format
}: DateCellProps) {
  
  // Parse the date string with moment
  const parsedDate = moment(date); 

  // Check if the parsed date is valid
  if (!parsedDate.isValid()) {
    return <div>Invalid Date</div>; // Handle invalid date cases
  }

  return (
    <div className={cn('grid gap-1', className)}>
      {/* Display the formatted date */}
      <time
        dateTime={parsedDate.format('YYYY-MM-DD')}
        className={cn('font-medium text-gray-700', dateClassName)}
      >
        {parsedDate.format(dateFormat)}
      </time>
      {/* Display the formatted time */}
      <time
        dateTime={parsedDate.format('HH:mm:ss')}
        className={cn('text-[13px] text-gray-500', timeClassName)}
      >
        {parsedDate.format(timeFormat)}
      </time>
    </div>
  );
}
