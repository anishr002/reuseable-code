import { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import toast from 'react-hot-toast';
import { useDropzone } from 'react-dropzone';
import UploadIcon from '@/components/shape/upload';
import { FieldError, Loader, Text } from 'rizzui';
import cn from '@/utils/class-names';
import { PiPencilSimple } from 'react-icons/pi';
import Spinner from '../spinner';

interface UploadZoneProps {
  name: string;
  initialImageUrl?: string;
  setValue?: any;
  className?: string;
  error?: string;
  getValues?:any;

}

export default function AvatarUpload({
  name,
  initialImageUrl,
  error,
  className,
  setValue,
  getValues

}: UploadZoneProps) {
  const [imagePreview, setImagePreview] = useState<string | null>(getValues(name) || null);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    // Set the initial image from backend
    if (initialImageUrl) {
      setImagePreview(initialImageUrl);
    }
  }, [initialImageUrl]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      const previewUrl = URL.createObjectURL(file);
      setImagePreview(previewUrl);
      setIsUploading(true);
      setTimeout(() => {
        setIsUploading(false);
       setValue(name, file);
      }, 2000);
    }
  
  },[name, setValue]);

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
  });

  return (
    <div className={cn('grid gap-5', className)}>
      <div
        className={cn(
          'relative grid h-40 w-40 place-content-center rounded-full border-[1.8px]'
        )}
      >
        {imagePreview ? (
          <>
            <figure className="absolute inset-0 rounded-full">
              <Image
                fill
                alt="user avatar"
                src={imagePreview}
                className="rounded-full"
              />
            </figure>
            <div
              {...getRootProps()}
              className={cn(
                'absolute inset-0 grid place-content-center rounded-full bg-black/70'
              )}
            >
              {isUploading ? (
                <Spinner />
              ) : (
                <PiPencilSimple className="h-5 w-5 text-white" />
              )}

              <input {...getInputProps()} />
            </div>
          </>
        ) : (
          <div
            {...getRootProps()}
            className={cn(
              'absolute inset-0 z-10 grid cursor-pointer place-content-center'
            )}
          >
            <input {...getInputProps()} />
            <UploadIcon className="mx-auto h-12 w-12" />
            {isUploading ? (
              <Loader variant="spinner" className="justify-center" />
            ) : (
              <Text className="font-medium">Drop or select file</Text>
            )}
          </div>
        )}
      </div>
      {error && <FieldError error={error} />}
    </div>
  );
}
