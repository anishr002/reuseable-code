'use client';

import Image from 'next/image';
import isEmpty from 'lodash/isEmpty';
import prettyBytes from 'pretty-bytes';
import { useCallback, useEffect, useState } from 'react';
import { useDropzone,FileWithPath } from 'react-dropzone';
import { PiTrashBold } from 'react-icons/pi';
import { Text, FieldError } from 'rizzui';
import cn from '@/utils/class-names';
import UploadIcon from '@/components/shape/upload';
import { endsWith } from 'lodash';

interface UploadZoneProps {
  label?: string;
  name: string;
  getValues: any;
  setValue: any;
  className?: string;
  error?: string;
  files?: any;
  setFiles?: any;
  type?: string
}

interface FileType {
  name: string;
  url: string;
  size: number;

}

export default function UploadZone({
  label,
  name,
  className,
  getValues,
  setValue,
  error,
  files,
  setFiles,
  type,
}: UploadZoneProps) {
  const onDrop = useCallback(
    (acceptedFiles: FileWithPath[]) => {
      const file = acceptedFiles[0];
      const filePreviews = acceptedFiles.map((file) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      );
      setFiles(filePreviews);
      setValue(name, file);
    },
    [name, setValue]
  );

  function handleRemoveFile(index: number) {
    const updatedFiles = [...files];
    updatedFiles.splice(index, 1);
    setFiles(updatedFiles);

    // Update the form state
    const remainingFiles = updatedFiles.map((file:any) => ({
      name: file.name,
      size: file.size,
      url: file.preview,
    }));
    setValue(name, remainingFiles);
  }

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
  });

  return (
    <div className={cn('grid @container', className)}>
      {label && (
        <span className="mb-1.5 block text-gray-900">
          {label}
        </span>
      )}
      <div className="rounded-md border-[1.8px]">
        <div
          {...getRootProps()}
          className={cn(
            'flex cursor-pointer items-center gap-4 px-6 py-5 transition-all duration-300',
            isEmpty(files) ? 'justify-center' : 'justify-start'
          )}
        >
          <input {...getInputProps()} />
          <UploadIcon className="h-12 w-12" />
          <Text className="text-base font-medium">Drop or select file</Text>
        </div>
      </div>

      {!isEmpty(files) && (
        <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-[repeat(auto-fit,_minmax(140px,_1fr))]">
          {files?.map((file:any, index:any) => (
            <div key={index} className="relative">
              <figure className="group relative h-40 rounded-md bg-gray-50">
                <MediaPreview name={file?.name} url={file?.preview} />
                <button
                  type="button"
                  onClick={() => handleRemoveFile(index)}
                  className="absolute right-0 top-0 rounded-full bg-gray-700/70 p-1.5 opacity-20 transition duration-300 hover:bg-red-dark group-hover:opacity-100"
                >
                  <PiTrashBold className="text-white" />
                </button>
              </figure>
              <MediaCaption name={file.name} size={file.size} />
            </div>
          ))}
        </div>
      )}

      {error && <FieldError error={error} />}
    </div>
  );
}

export function MediaPreview({ name, url }: { name: string; url: string }) {
  return endsWith(name, '.pdf') ? (
    <object data={url} type="application/pdf" width="100%" height="100%">
      <p>
        Alternative text - include a link <a href={url}>to the PDF!</a>
      </p>
    </object>
  ) : (
    <Image
      fill
      src={url}
      alt={name}
      className="transform rounded-md object-contain"
    />
  );
}

export  function MediaCaption({ name, size }: Readonly<{ name: string; size: number }>) {
  return (
    <div className="mt-1 text-xs">
      <p className="break-words font-medium text-gray-700">{name}</p>
      <p className="mt-1 font-mono">{prettyBytes(size)}</p>
    </div>
  );
}
