import { siteConfig } from '@/config/site.config';
import Image from 'next/image';

interface IconProps extends React.SVGProps<SVGSVGElement> {
  iconOnly?: boolean;
}

export default function Logo({ iconOnly = false, ...props }: IconProps) {
  return (
<div>
<Image
  width={401}
  height={51}
  src={ siteConfig.logo}
  alt="TridhyaTech"
  sizes="(max-width: 768px) 100vw"
/>
</div>

  );
}
