"use client";

import React, { useState, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import Spinner from "@/components/ui/spinner";
import { routes } from "@/config/routes";
import { useSelector } from "react-redux";
import { menuItems, InternalmenuItems, nonPermissionModules } from "@/layouts/hydrogen/menu-items";

type MenuItem = {
  title: string;
  href: string;
  dropdownItems?: SubMenuItem[];
};

type SubMenuItem = {
  title: string;
  href: string;
};

// Combine internal, external, and non-permission modules
const combinedMenuItems = [
  ...menuItems.map((item) => {
    const internalItem = InternalmenuItems.find(
      (internal) => internal.title === item.title
    );
    if (internalItem?.dropdownItems) {
      return {
        ...item,
        dropdownItems: [
          ...(item.dropdownItems || []),
          ...internalItem.dropdownItems,
        ],
      };
    }
    return item;
  }),
  ...nonPermissionModules,
];

const checkPermissions = (userData: any, path: string) => {
  const isEditRoute = path.includes("edit");
  const isCreateRoute = path.includes("create");
  const nonPermissionModule = nonPermissionModules.find((module) => module.href === path);

  if (nonPermissionModule) {
    // If it's a non-permission module, allow access
    return true;
  }

  const allowedModules = userData?.permissions?.reduce((acc: any[], module: any) => {
    if (module?.subModules?.length > 0) {
      module.subModules.forEach((subModule: any) => {
        acc.push({
          main_module_title: module?.name,
          sub_module_title: subModule?.name,
          permissions: subModule?.permissions,
        });
      });
    } else {
      acc.push({
        main_module_title: module?.name,
        sub_module_title: module?.name,
        permissions: module?.permissions,
      });
    }
    return acc;
  }, []);

  if (isEditRoute) {
    const basePath = path.split('/edit')[0];
    // Find matching permission for the base route (ignoring ID and edit)
    const matchedMenuItem:any = combinedMenuItems?.find((menu: any) => {
      const href = typeof menu?.href === 'function' ? menu.href('dummy-id') : menu?.href;
      return (
        basePath.startsWith(href) ||
        menu?.dropdownItems?.some((subMenu: any) => {
          const subHref = typeof subMenu?.href === 'function' ? subMenu.href('dummy-id') : subMenu?.href;
          return basePath.startsWith(subHref);
        })
      );
    });

    if (!matchedMenuItem) return false;

    let matchedPermission;
    if (matchedMenuItem?.dropdownItems) {
      const matchedSubMenu = matchedMenuItem.dropdownItems.find((subMenu:any) => {
        const subHref = typeof subMenu?.href === 'function' ? subMenu.href('dummy-id') : subMenu?.href;
        return basePath.startsWith(subHref);
      });
      matchedPermission = allowedModules?.find(
        (item: any) => item?.sub_module_title === matchedSubMenu?.title
      );
    } else {
      matchedPermission = allowedModules?.find(
        (item: any) => item?.main_module_title === matchedMenuItem?.title
      );
    }

    // Check for both 'view' and 'edit' permissions
    if (matchedPermission?.permissions?.includes("view") &&
      matchedPermission?.permissions?.includes("edit")) {
      return matchedPermission;
    }

    return false;
  }

  const matchedMenuItem:any = combinedMenuItems?.find((menu:any) => {
    return menu?.href === path || menu?.dropdownItems?.some((subMenu:any) => subMenu?.href === path);
  });

  if (!matchedMenuItem) return false;

  let matchedPermission;
  if (matchedMenuItem?.dropdownItems) {
    const matchedSubMenu = matchedMenuItem.dropdownItems.find((subMenu:any) => subMenu?.href === path);
    matchedPermission = allowedModules?.find((item: any) => item?.sub_module_title === matchedSubMenu?.title);
  } else {
    matchedPermission = allowedModules?.find((item: any) => item?.main_module_title === matchedMenuItem?.title);
  }

  if (isCreateRoute) {
    return matchedPermission?.permissions?.includes("create") ? matchedPermission : false;
  }

  return matchedPermission?.permissions?.includes("view") ? matchedPermission : false;
};



const findNextAccessibleRoute = (userData: any) => {
  for (const menuItem of combinedMenuItems as MenuItem[]) {
    // Skip permission checks for non-permission modules
    if (nonPermissionModules.some((module) => module.title === menuItem.title)) {
      return menuItem.href;
    }

    const matchedPermission = userData?.permissions?.find(
      (module: any) => module?.name === menuItem.title && module?.permissions.includes("view")
    );

    if (matchedPermission) return menuItem.href;

    if (menuItem?.dropdownItems?.length) {
      for (const subMenuItem of menuItem.dropdownItems) {
        const matchedSubPermission = userData?.permissions?.find(
          (module: any) => module?.name === subMenuItem.title && module?.permissions.includes("view")
        );
        if (matchedSubPermission) return subMenuItem.href;
      }
    }
  }
  return routes.notFound;
};

// Higher-Order Component to wrap protected components
const WithAuth = (WrappedComponent: React.ComponentType<any>) => {
  const AuthComponent = (props: any) => {
    const router = useRouter();
    const [isLoading, setIsLoading] = useState(true);
    const userData = useSelector((state: any) => state.auth.userData);
    const path = usePathname();
    const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;

    useEffect(() => {
      const handleAuthentication = () => {

        if (token && path === routes.signIn) {
          router.replace(routes.jobBoard.dashboard);
          return;
        }
        // If no token, redirect to sign-in page
        if (!token) {
          router.replace(routes.signIn);
          return;
        }

        // Handle profile settings, notifications separately

        const specialPaths = [routes.profileSettings, routes.notifications,];
        if (specialPaths.some(route => path.includes(route))) {
          setIsLoading(false);
          return;
        }

        // Check user permissions based on the current route
        const matchedPermission = checkPermissions(userData, path);

        // If on dashboard and no view permission, redirect to the next accessible route
        if (!matchedPermission && path === routes.jobBoard.dashboard) {
          const nextRoute: any = findNextAccessibleRoute(userData);
          router.replace(nextRoute);
          return;
        }

        if (!matchedPermission) {
          // No permission found, redirect to access denied page
          router.replace(routes.accessDenied);
          return;
        }

        // Ensure user has the `view` permission
        if (matchedPermission?.permissions?.includes("view")) {
          setIsLoading(false);
        } else {
          router.replace(routes.notFound);
        }
      };

      handleAuthentication();
    }, [token, userData, router, path]);

    if (isLoading) {
      return (
        <div className="flex justify-center items-center col-span-full">
          <Spinner />
        </div>
      );
    }

    return <WrappedComponent {...props} />;
  };

  return AuthComponent;
};

export default WithAuth;
