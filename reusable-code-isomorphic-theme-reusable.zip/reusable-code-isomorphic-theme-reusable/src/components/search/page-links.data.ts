import { routes } from '@/config/routes';

// Note: do not add href in the label object, it is rendering as label
export const pageLinks = [
  {
    name: 'Roles and Permissions',
    href: routes.rolesPermissions.rolesPermissions,
  },
  {
    name: 'Blog-Management',
    href: routes.blogManagement.blogs,
  },
  {
    name: 'Blog-Categories',
    href: routes.blogManagement.categories,
  },
  {
    name: 'FAQ-Management',
    href: routes.FAQManagement,
  },
  {
    name: 'Contact Us',
    href: routes.contactUs
  },
  {
    name: 'Testimonial Management',
    href: routes.testimonial
  },
  {
    name: 'CMS Pages',
  },
  {
    name: 'Terms and Conditions',
    href: routes.cmsPages.termsConditions
  },
  {
    name: 'Privacy Policy',
    href: routes.cmsPages.privacyPolicy
  },
  {
    name: 'About Us',
    href: routes.cmsPages.aboutUs
  }

 
  // {
  //   name: 'Products',
  //   href: routes.eCommerce.products,
  // },
  // {
  //   name: 'Product Details',
  //   href: routes.eCommerce.productDetails(DUMMY_ID),
  // },
  // {
  //   name: 'Create Product',
  //   href: routes.eCommerce.createProduct,
  // },
  // {
  //   name: 'Edit Product',
  //   href: routes.eCommerce.ediProduct(DUMMY_ID),
  // },
  // {
  //   name: 'Categories',
  //   href: routes.eCommerce.categories,
  // },
  // {
  //   name: 'Create Category',
  //   href: routes.eCommerce.createCategory,
  // },
  // {
  //   name: 'Edit Category',
  //   href: routes.eCommerce.editCategory(DUMMY_ID),
  // },
  // {
  //   name: 'Orders',
  //   href: routes.eCommerce.orders,
  // },
  // {
  //   name: 'Order Details',
  //   href: routes.eCommerce.orderDetails(DUMMY_ID),
  // },
  // {
  //   name: 'Create Order',
  //   href: routes.eCommerce.createOrder,
  // },
  // {
  //   name: 'Edit Order',
  //   href: routes.eCommerce.editOrder(DUMMY_ID),
  // },
  // {
  //   name: 'Reviews',
  //   href: routes.eCommerce.reviews,
  // },
  // {
  //   name: 'Shop',
  //   href: routes.eCommerce.shop,
  // },
  // {
  //   name: 'Cart',
  //   href: routes.eCommerce.cart,
  // },
  // {
  //   name: 'Checkout & Payment',
  //   href: routes.eCommerce.checkout,
  // },
  // // label start
  // {
  //   name: 'Widgets',
  // },
  // // label end
  // {
  //   name: 'Cards',
  //   href: routes.widgets.cards,
  // },
  // {
  //   name: 'Icons',
  //   href: routes.widgets.icons,
  // },
  // {
  //   name: 'Charts',
  //   href: routes.widgets.charts,
  // },
  // {
  //   name: 'Banners',
  //   href: routes.widgets.banners,
  // }, 
];
