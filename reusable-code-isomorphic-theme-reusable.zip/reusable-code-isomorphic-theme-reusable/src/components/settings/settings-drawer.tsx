'use client';

import SimpleBar from '@/components/ui/simplebar';
import AppDirection from '@/components/settings/app-direction';
import ThemeSwitcher from '@/components/settings/theme-switcher';
import ColorOptions from './color-options';
import {useUpdateSiteSettings} from './useUpdateSettings';
import { useState } from 'react';
import { useDirection } from '@/hooks/use-direction';

const defaultColorPreset = {
  lighter: "#d7e3fe",
  light: "#608efb",
  default: "#3872fa",
  dark: "#1d58d8",
  foreground: "#ffffff"
};

export default function SettingsDrawer() {
  const { updateSiteSettings } = useUpdateSiteSettings();
  const [themeMode, setThemeMode] = useState('light');
  const [colorPreset, setColorPreset] = useState(defaultColorPreset);
  const [colorName,setColorName] = useState('Blue');
  const { direction } = useDirection();


  return (
      <SimpleBar className="h-[calc(100%-138px)]">
        <div className="px-5 py-6">
        <ThemeSwitcher direction={direction} setThemeMode={setThemeMode} updateSiteSettings={updateSiteSettings} />
        <AppDirection updateSiteSettings={updateSiteSettings} themeMode={themeMode} colorPreset={colorPreset} />
        <ColorOptions themeMode={themeMode} direction={direction} updateSiteSettings={updateSiteSettings} setColorPreset={setColorPreset} setColorName={setColorName} />
        </div>
      </SimpleBar>
  );
}
