import { useDispatch } from 'react-redux';
import { updateColor } from '@/redux/slices/site-setting/siteSettingSlice';
import toast from 'react-hot-toast';

export const useUpdateSiteSettings = () => {
  const dispatch = useDispatch();

  const updateSiteSettings = async (settings: any) => {
    try {
      const res = await dispatch(updateColor(settings));

      if (res.payload.status === false || res.payload.status === 0) {
        toast.error(res.payload.message);
      } else {
        toast.success('Settings updated successfully');
      }
    } catch (error) {
      console.error('Failed to update settings', error);
      toast.error('An error occurred while updating settings');
    }
  };

  return { updateSiteSettings };
};
