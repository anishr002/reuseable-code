'use client';

export { default as useLocalStorage } from 'react-use/lib/useLocalStorage';
