import { Option } from "types";

export const statuses = {
   INPROGRESS: 'In Progress',
    Completed: 'Completed',
    Open: 'Open',
    Closed: 'Closed',
};

export const priorities = {
    Low: 'Low',
    High: 'High',
    Medium: 'Medium',
};

export const Status = [
    { value: 'Active', label: 'Active' },
    { value: 'Inactive', label: 'Inactive' },
];



export const Roles = {
    OrgAdmin: "org_admin",
    OrganizationBranchAdmin: "org_branch_admin",
    BackOffice: "back_office",
    Student: "student",
    Parents: "parents",
    Teacher: "teacher",
    Librarian: "librarian",
    OrganizationAdminStaff: 'org_admin_staff',
    OrganizationBranchAdminStaff: 'org_branch_admin_staff'
};

export const RolesPermissions = {
    SuperAdmin: "Super Admin",
    OrgAdmin: "Organization Admin",
    OrganizationBranchAdmin: "Organization Branch Admin",
    BackOffice: "Back Office",
    Student: "Student",
    Parents: "Parents",
    Teacher: "Teacher"
} as const;

export const PaginationObject = {
    page: 1,
    pageSize: 5,
    sortBy: 'name',
    sortOrder: 'Desc'
};

export const UsersLimit = {
    Unlimited: 1,
    Limited: 2
};

export const STATUS = {
    ACTIVE: 1,
    IN_ACTIVE: 2
};


export const STATUSDATA = {
    ACTIVE: 1,
    PRIVATE: 2,
    UPCOMING: 3
};


export const VISIBILITY = {
    SHOW: 1,
    HIDE: 2,
};

export const LEVEL = {
    BEGINNER: 1,
    INTERMEDIATE: 2,
    ADVANCE: 3,

};
export const ACTION = {
    ACTIVATE: 1,
    DEACTIVATE: 2,

};

export const STATUSVALUENAME: Option[] = [
    {
      value: 1,
      label: 'Active',
    },
    {
      value: 2,
      label: 'In Active',
    },
  ];

  export const STATUSValueName = [
    {
        value: 1,
        name: 'Active',
    },
    {
        value: 2,
        name: 'In Active',
    },
];



export const Gender = [
    {
        value: 'male',
        name: 'Male',
    },
    {
        value: 'female',
        name: 'Female',
    },
];

export const BloodGroup = [
    {
        value: 'O+',
        name: 'O+',
    },
    {
        value: 'O-',
        name: 'O-',
    },
    {
        value: 'A+',
        name: 'A+',
    },
    {
        value: 'A-',
        name: 'A-',
    },
    {
        value: 'B+',
        name: 'B+',
    },
    {
        value: 'B-',
        name: 'B-',
    },
    {
        value: 'AB+',
        name: 'AB+',
    },
    {
        value: 'AB-',
        name: 'AB-',
    },
];


export const ROLES = {
    TRUE: true,
    FALSE: false
};

export const PERMISSION = {
    WRITE: 'Write',
    UPDATE: 'Update',
    DELETE: 'Delete',
    READ: 'Read'

};

export const PERMISSIONSDATA = [
    "view",
    "create",
    "edit",
    "delete",
 ] as const;

export const countPerPage = 5;

export const YesNo = [
    {
        value: true,
        name: 'Yes',
    },
    {
        value: false,
        name: 'No',
    },
];

export const Months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

export const Days = [
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
];


export const fullMonths = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
];

export const daysOptions = [
    { name: "Sunday", value: "Sunday" },
    { name: "Monday", value: "Monday" },
    { name: "Tuesday", value: "Tuesday" },
    { name: "Wednesday", value: "Wednesday" },
    { name: "Thursday", value: "Thursday" },
    { name: "Friday", value: "Friday" },
    { name: "Saturday", value: "Saturday" }
];

export const daysArray = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];


export const YESNO = {
    YES: 'Yes',
    NO: 'No',
};

export const CMSSLUG = {
    ABOUTUS : "about_us",
    TERMCONDITIONS : 'terms_and_conditions',
    PRIVACYPOLICY : 'privacy_policy'
};