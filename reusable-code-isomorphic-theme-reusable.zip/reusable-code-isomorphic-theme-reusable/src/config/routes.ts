
export const routes = {
  searchAndFilter: {
    realEstate: '/search/real-estate',
    nft: '/search/nft',
    flight: '/search/flight',
  },
  executive: {
    dashboard: '/executive',
  },
  jobBoard: {
    dashboard: '/dashboard',
  },
  analytics: '/analytics',
  financial: {
    dashboard: '/financial',
  },
  
  eventCalendar: '/event-calendar',
  rolesPermissions: {
    create: '/roles-permissions/roles/create',
    rolesPermissions: '/roles-permissions/roles',
    edit: (id: string) => `/roles-permissions/roles/${id}/edit`,
  },
  adminUsers : '/users',
  widgets: {
    cards: '/widgets/cards',
    icons: '/widgets/icons',
    charts: '/widgets/charts',
    maps: '/widgets/maps',
    banners: '/widgets/banners',
  },
  tables: {
    basic: '/tables/basic',
    collapsible: '/tables/collapsible',
    enhanced: '/tables/enhanced',
    pagination: '/tables/pagination',
    search: '/tables/search',
    stickyHeader: '/tables/sticky-header',
  },
  multiStep: '/multi-step',
  forms: {
    profileSettings: '/forms/profile-settings',
    notificationPreference: '/forms/profile-settings/notification',
    personalInformation: '/forms/profile-settings/profile',
    newsletter: '/forms/newsletter',
  },
  emailTemplates: '/email-templates',
  profile: '/profile',
  welcome: '/welcome',
  comingSoon: '/coming-soon',
  accessDenied: '/access-denied',
  notFound: '/not-found',
  maintenance: '/maintenance',
  blank: '/blank',
  auth: {
    signUp1: '/auth/sign-up-1',
    // sign in
    signIn1: '/auth/sign-in-1',

    // forgot password
    forgotPassword1: '/auth/forgot-password',
    resetPassWord : '/auth/reset-password'
  },
  signIn: '/signin',
  FAQManagement : '/faq-management',
  blogManagement: {
    categories: '/blog-management/categories',
    createCategory: '/blog-management/categories/create',
    editCategory: (id: string) => `/blog-management/categories/${id}/edit`,
    blogs : '/blog-management/blogs',
    blogCreate : '/blog-management/blogs/create',
    blogEdit : (id: string) => `/blog-management/blogs/${id}/edit`
  },
  cmsPages : {
    termsConditions : '/cms-pages/terms-conditions',
    privacyPolicy : '/cms-pages/privacy-policy',
    aboutUs : '/cms-pages/about-us'
  },
  contactUs : '/contact-us',
  testimonial : '/testimonial',
  profileSettings: '/profile-settings',
  notifications : '/notifications'
};
