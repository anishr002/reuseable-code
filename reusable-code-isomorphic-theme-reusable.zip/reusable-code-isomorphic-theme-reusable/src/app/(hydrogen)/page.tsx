import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject(),
};

export default function FileDashboardPage() {
  return <h1>Dashboard</h1>;
}
