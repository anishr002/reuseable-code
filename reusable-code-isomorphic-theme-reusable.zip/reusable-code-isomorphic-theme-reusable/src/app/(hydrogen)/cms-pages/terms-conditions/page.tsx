import PageHeader from '@/app/shared/page-header';
import { routes } from '@/config/routes';
import Link from 'next/link';
import { Button } from 'rizzui';
import { PiPlusBold } from 'react-icons/pi';

import { metaObject } from '@/config/site.config';
import BlogTable from '@/app/shared/blog-management/blogs/blog-table/table';
import AddUpdateTermsConditions from '@/app/shared/cms-pages/terms-conditions';

export const metadata = {
  ...metaObject('Terms and Conditions'),
};



export default function BlankPage() {
  return (
    <>
      
      <AddUpdateTermsConditions />
    </>
  );
}
