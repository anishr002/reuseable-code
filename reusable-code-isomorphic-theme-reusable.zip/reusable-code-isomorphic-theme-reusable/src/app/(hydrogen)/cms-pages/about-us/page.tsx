import { metaObject } from '@/config/site.config';
import AddUpdateAboutUsData from '@/app/shared/cms-pages/about-us';

export const metadata = {
  ...metaObject('About Us'),
};

export default function BlankPage() {
  return (

      <AddUpdateAboutUsData />
  );
}
