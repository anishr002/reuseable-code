import { metaObject } from '@/config/site.config';
import AddUpdatePrivacyPolicy from '@/app/shared/cms-pages/private-policy';

export const metadata = {
  ...metaObject('Privacy Policy'),
};


export default function BlankPage() {
  return (
    <>
      <AddUpdatePrivacyPolicy />
    </>
  );
}
