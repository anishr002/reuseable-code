import RolesGrid from '@/app/shared/roles-permissions/roles-grid';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Roles and Permissions'),
};

export default function BlankPage() {
  return (
      <RolesGrid />
  );
}
