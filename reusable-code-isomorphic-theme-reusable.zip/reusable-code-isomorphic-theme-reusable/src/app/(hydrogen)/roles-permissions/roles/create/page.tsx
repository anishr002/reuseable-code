
import { metaObject } from '@/config/site.config';
import { routes } from '@/config/routes';
import CreateRole from '@/app/shared/roles-permissions/create-role';


export const metadata = {
  ...metaObject('Create Role'),
};

const pageHeader = {
    title: 'Roles and Permissions',
    breadcrumb: [
      {
        name: 'Roles and Permissions',
      },
      {
        href: routes.rolesPermissions.rolesPermissions,
        name: 'Roles',
      },
      {
        name: 'Create',
      },
    ],
  };

export default function CreateRolePage() {
  return (
      <CreateRole type="Create" title="Add a new Role" pageHeader={pageHeader}/>
  );
}
