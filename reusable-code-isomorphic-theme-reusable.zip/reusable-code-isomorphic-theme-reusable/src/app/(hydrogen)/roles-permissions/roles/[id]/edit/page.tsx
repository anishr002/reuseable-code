import { routes } from '@/config/routes';
import { metaObject } from '@/config/site.config';
import { Metadata } from 'next';
import CreateRole from '@/app/shared/roles-permissions/create-role';

type Props = {
  params: { id: string };
};

/**
 * for dynamic metadata
 * @link: https://nextjs.org/docs/app/api-reference/functions/generate-metadata#generatemetadata-function
 */

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  // read route params
  const id = params.id;

  return metaObject(`Edit ${id}`);
}

const pageHeader = {
  title: 'Roles and Permissions',
  breadcrumb: [  
      {
        name: 'Roles and Permissions',
      },
      {
        href: routes.rolesPermissions.rolesPermissions,
        name: 'Roles',
      },
    {
      name: 'Edit',
    },
  ],
};


export default function EditRolePage({ params }: any) {
  return (
      <CreateRole id={params.id} title='Edit Role' type='Edit' pageHeader={pageHeader}/>
  );
}
