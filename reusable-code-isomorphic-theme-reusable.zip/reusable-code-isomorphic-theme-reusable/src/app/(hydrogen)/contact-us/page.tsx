import { metaObject } from '@/config/site.config';
import ContactUsTable from '@/app/shared/contact-us/contact-us-table/table';

export const metadata = {
  ...metaObject('Contact Us')
}

;

const ContactUsPage = () => {
 
  return (
        <ContactUsTable/>
  );
};

export default ContactUsPage ;
