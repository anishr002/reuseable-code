import { metaObject } from '@/config/site.config';
import NotificationTable from '@/app/shared/notifications/notification-table/table';

export const metadata = {
  ...metaObject('Notifications')
};

const NotificationsPage = () => {
 
  return (
        <NotificationTable/>
  );
};

export default NotificationsPage ;
