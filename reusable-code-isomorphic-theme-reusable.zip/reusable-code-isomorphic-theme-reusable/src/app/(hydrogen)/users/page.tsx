import AdminUserTable from '@/app/shared/users/users-table/table';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Admin Users'),
};

export default function BlankPage() {
   return (
      <AdminUserTable/>
  );
};

