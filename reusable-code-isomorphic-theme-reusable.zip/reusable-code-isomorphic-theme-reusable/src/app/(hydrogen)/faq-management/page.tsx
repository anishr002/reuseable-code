
import FAQManagement from '@/app/shared/faq-management/faq-table/table';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('FAQs Management')
}

const FAQPage = () => {

  return (
      <FAQManagement />
  );
};

export default FAQPage;
