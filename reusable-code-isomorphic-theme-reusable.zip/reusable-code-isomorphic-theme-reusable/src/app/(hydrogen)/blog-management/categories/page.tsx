
import CategoryPageHeader from '@/app/shared/blog-management/category/category-page-header';
import BlogCategory from '@/app/shared/blog-management/category/category-table/table';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Category'),
};

const pageHeader = {
  title: 'Category',
  breadcrumb: [
    {
      name: "Blog Management"
    },
    {
      name: 'Category',
    },
  ],
};

export default function BlankPage() {
  return (
    <>
      <CategoryPageHeader
        title={pageHeader.title}
        breadcrumb={pageHeader.breadcrumb}
      />
      <BlogCategory />
    </>
  );
}

