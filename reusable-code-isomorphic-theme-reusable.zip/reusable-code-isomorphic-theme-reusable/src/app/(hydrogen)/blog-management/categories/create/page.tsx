import PageHeader from '@/app/shared/page-header';
import { routes } from '@/config/routes';

import { metaObject } from '@/config/site.config';
import CreateBlogs from '@/app/shared/blog-management/blogs/create-blog';
import CreateBlogCategory from '@/app/shared/blog-management/category/create-category';

export const metadata = {
  ...metaObject('Create Blog'),
};

const pageHeader = {
    title: 'Category',
    breadcrumb: [
      {
        name: "Blog Management"
      },
      {
        name: 'Category',
      },
    ],
  };

export default function CreateCategoryPage() {
  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
      </PageHeader>
      <CreateBlogCategory type='Create' title='Create Category' />
    </>
  );
}
