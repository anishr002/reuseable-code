'use client';

import NavigationTab from '@/app/shared/blog-management/category/tab-navigation';
import React from 'react';


export default function EditCategoryPage({ params }: any) {
  return (
  <NavigationTab params = {params}/>
  );
}

