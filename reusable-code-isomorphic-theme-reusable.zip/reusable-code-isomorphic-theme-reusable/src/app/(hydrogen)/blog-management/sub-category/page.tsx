
import { metaObject } from '@/config/site.config';
import BlogSubCategory from '@/app/shared/blog-management/category/sub-category-table/table';
// export const metadata = {
//   ...metaObject('Sub-Category'),
// };


export default function SubCategoryPage() {
  return (
      <BlogSubCategory />
  );
}
