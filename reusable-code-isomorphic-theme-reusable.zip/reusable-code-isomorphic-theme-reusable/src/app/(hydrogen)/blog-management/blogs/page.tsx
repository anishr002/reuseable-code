
import { metaObject } from '@/config/site.config';
import BlogTable from '@/app/shared/blog-management/blogs/blog-table/table';
export const metadata = {
  ...metaObject('Blogs'),
};


export default function BlankPage() {
  return (
      <BlogTable />
  );
}
