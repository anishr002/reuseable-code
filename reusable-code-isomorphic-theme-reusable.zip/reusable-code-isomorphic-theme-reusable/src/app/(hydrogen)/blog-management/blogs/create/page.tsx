import PageHeader from '@/app/shared/page-header';
import { routes } from '@/config/routes';

import { metaObject } from '@/config/site.config';
import CreateBlogs from '@/app/shared/blog-management/blogs/create-blog';

export const metadata = {
  ...metaObject('Create Blog'),
};

const pageHeader = {
  title: 'Blogs',
  breadcrumb: [
    {
      name: 'Blog Management',
    },
    {
      href : routes.blogManagement.blogs,  
      name: 'Blogs',
    },
    {
        name: 'Create',
    },
  ],
};

export default function BlankPage() {
  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
      </PageHeader>
      <CreateBlogs type='Create'/>
    </>
  );
}
