import { routes } from '@/config/routes';
import PageHeader from '@/app/shared/page-header';
import { metaObject } from '@/config/site.config';
import { Metadata } from 'next';
import CreateBlogs from '@/app/shared/blog-management/blogs/create-blog';

type Props = {
  params: { id: string };
};

/**
 * for dynamic metadata
 * @link: https://nextjs.org/docs/app/api-reference/functions/generate-metadata#generatemetadata-function
 */

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  // read route params

  return metaObject(`Edit Blog`);
}

const pageHeader = {
    title: 'Blogs',
    breadcrumb: [
      {
        name: 'Blog Management',
      },
      {
        href : routes.blogManagement.blogs,  
        name: 'Blogs',
      },
      {
          name: 'Edit' 
      }   
    ],
  };

export default function EditBlogPage({ params }: any) {
  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
      </PageHeader>
      <CreateBlogs id={params.id} type='Edit' />
    </>
  );
}
