import { metaObject } from '@/config/site.config';
import ReviewsTable from '@/app/shared/testimonial/testimonial-table/table';

export const metadata = {
  ...metaObject('Testimonial Management'),
};

;

export default function TestimonialPage() {
    return (
      <ReviewsTable/>
  );
}
