'use client';

import React from 'react';
import PageHeader from '@/app/shared/page-header';
import { Button, Title, ActionIcon } from 'rizzui';
import { PiPlusBold, PiXBold } from 'react-icons/pi';
import { useModal } from '@/app/shared/modal-views/use-modal';
import AddReviews from '@/app/shared/testimonial/AddReviews';

export function CreateTestimonialModalView({type,title,isModalView,data,id} : any) {
  const { closeModal } = useModal();
  return (
    <div className="m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">
      <div className="mb-7 flex items-center justify-between">
        <Title as="h4" className="font-semibold">
         {title}
        </Title>
        <ActionIcon size="sm" variant="text" onClick={() => closeModal()}>
          <PiXBold className="h-auto w-5" />
        </ActionIcon>
      </div>
      <AddReviews title={title} type={type} isModalView={isModalView} data={data} id = {id} />
    </div>
  );
}

type PageHeaderTypes = {
  title: string;
  className?: string;
};

export default function TestimonialPageHeader({
  title,
  className,
}: PageHeaderTypes) {
  const { openModal } = useModal();
  return (
      <PageHeader title={title} className={className}>
        <Button
          as="span"
          className="mt-4 w-full cursor-pointer @lg:mt-0 @lg:w-auto "
          onClick={() =>
            openModal({
              view: <CreateTestimonialModalView 
              type="Create"
              title={"Add Reviews"}
              isModalView={false} />,
              customSize: '720px',
            })
          }
        >
          <PiPlusBold className="me-1 h-4 w-4" />
          Add Reviews
        </Button>
      </PageHeader>
  );
}
