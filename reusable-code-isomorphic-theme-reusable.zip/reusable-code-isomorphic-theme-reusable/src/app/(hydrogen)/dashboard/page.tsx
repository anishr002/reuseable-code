import { metaObject } from '@/config/site.config';
import JobBoardPageMain from './main-page';

export const metadata = {
  ...metaObject('Dashboard'),
};

export default function JobBoardPage() {
  return <JobBoardPageMain />;
}
