'use client';

import WithAuth from '@/components/protected-router';
import JobDashboard from '@/app/shared/job-dashboard';

 function JobBoardPageMain() {
  return <JobDashboard />;
}

export default WithAuth(JobBoardPageMain);
