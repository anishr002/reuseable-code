'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { Socket } from 'socket.io-client';
import { useDispatch, useSelector } from 'react-redux';
import socket from '@/utils/socket.io/socket';
import { addNotification } from '@/redux/slices/notification/notificationsSlice';
import toast from 'react-hot-toast';

const SocketContext = createContext<Socket | null>(null);


export const SocketProvider = ({ children }: { children: React.ReactNode }) => {
    const dispatch = useDispatch();
    const [isConnected, setIsConnected] = useState<boolean | null>(null);
    const userData = useSelector((state: any) => state.auth.userData);

    useEffect(() => {
        // Request permission for notifications
        const requestNotificationPermission = async () => {
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
                console.warn('Notification permission not granted');
            }
        };
        requestNotificationPermission();
        socket.connect();
        socket.on('connect', () => {
            console.log(`Connected to server`);
        })

        socket.on('receivedNotification', (notification) => {
            dispatch(addNotification(notification));
            toast.success(notification.massage);
            if (document.hidden) {
                new Notification('New Notification', {
                    body: notification.message,
                });
            }
        });

        return () => {
            socket.off('notification');
            socket.disconnect();
        };
    }, [dispatch]);

    useEffect(() => {
        if (socket) {
            const onConnect = () => {
                setIsConnected(true);
                socket.emit("joinRoom", userData._id);
                console.log('Socket Connected');
            };

            const onDisconnect = () => {
                setIsConnected(false);
                console.log('Socket Disconnected');
            };

            socket.on('connect', onConnect);
            socket.on('disconnect', onDisconnect);

            return () => {
                socket.off('connect', onConnect);
                socket.off('disconnect', onDisconnect);
            };
        }
    }, [socket, userData]);

    return (
        <SocketContext.Provider value={socket}>
            {children}
        </SocketContext.Provider>
    );
};


export const useSocket = () => {
    return useContext(SocketContext);
};
