'use client';

import Link from 'next/link';
import { SubmitHandler } from 'react-hook-form';
import { PiArrowRightBold } from 'react-icons/pi';
import {  Password, Button, Input } from 'rizzui';
import { Form } from '@/components/ui/form';
import { routes } from '@/config/routes';
import { loginSchema, LoginSchema } from '@/utils/validators/login.schema';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import { signIn } from '@/redux/slices/auth/signInSlice';
import { useTheme } from 'next-themes';
import socket from '@/utils/socket.io/socket';

const initialValues: LoginSchema = {
  email: '',
  password: '',
  // rememberMe: true,
};

export default function SignInForm() {
  const dispatch = useDispatch();
  const { loading } = useSelector((state: any) => state.auth);
  const router = useRouter();
  const { theme, setTheme } = useTheme();


  const onSubmit: SubmitHandler<LoginSchema> = async (data) => {
    const payload = {
      ...data,
      loginType :"adminSite"
    };

    await dispatch(signIn(payload)).then((result: any) => {
     if(result?.payload?.status){
          setTheme(result?.payload?.data?.settingData?.appearance || 'light');
          localStorage.setItem('iso-direction',result?.payload?.data?.settingData?.direction); 
          localStorage.setItem('isomorphic-preset', JSON.stringify(result?.payload?.data?.settingData?.colors));
          localStorage.setItem('isomorphic-preset-name', result?.payload?.data?.settingData?.colorName); 
          socket.emit("joinRoom", result?.payload?.data?._id);
          router.replace(routes.jobBoard.dashboard);
     }
    });
  };
  return (
      <Form<LoginSchema>
        validationSchema={loginSchema}
        onSubmit={onSubmit}
        useFormProps={{
          defaultValues: initialValues,
        }}
      >
        {({ register, formState: { errors } }) => (
          <div className="space-y-5">
            <Input
              type="email"
              size="lg"
              label="Email"
              placeholder="Enter your email"
              className="[&>label>span]:font-medium"
              inputClassName="text-sm"
              {...register('email')}
              error={errors.email?.message}
            />
            <Password
              label="Password"
              placeholder="Enter your password"
              size="lg"
              className="[&>label>span]:font-medium"
              inputClassName="text-sm"
              {...register('password')}
              error={errors.password?.message}
            />
            <div className="flex items-center justify-between pb-2">
              {/* <Checkbox
                {...register('rememberMe')}
                label="Remember Me"
                className="[&>label>span]:font-medium"
              /> */}
              <Link
                href={routes.auth.forgotPassword1}
                className="h-auto p-0 text-sm font-semibold text-blue underline transition-colors hover:text-gray-900 hover:no-underline"
              >
                Forget Password?
              </Link>
            </div>
            <Button
              className="w-full bg-blue-dark hover:enabled:bg-blue disabled:bg-light-blue text-white"
              type="submit"
              size="lg"
              isLoading={loading}
              disabled={loading}
            >
              <span >Sign in</span>{' '}
              <PiArrowRightBold className="ms-2 mt-0.5 h-5 w-5" />
            </Button>
          </div>
        )}
      </Form>
  );
}
