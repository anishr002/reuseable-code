import AxiosDefault from "@/services/AxiosDefault";
import { paginationOptions } from "@/hooks/use-pagination";
import { Pagination } from "types";

export const addReviewTestimonial = async (data: any): Promise<any> => {
    const response = await AxiosDefault({
        url: "/v1/testimonial",
        method: "POST",
        data,
        contentType: "multipart/form-data",
    });
    const responseData: any = response.data;
    return responseData;
};

export const getAllTestimonial = async (paginationData: Pagination): Promise<any> => {
    const queryString: string = paginationOptions(paginationData);
    const baseUrl = '/v1/testimonial';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
      url,
      method: 'GET',
    });
    return response.data;
};

export const getReviewTestimonial = async (id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/testimonial/${id}`,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const updateReviewTestimonial = async (data: string, id: any): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/testimonial/${id}`,
        method: "PUT",
        data,
        contentType: "multipart/form-data",
    });
    const responseData: any = response.data;
    return responseData;
};

export const deleteReviewTestimonial = async (data: string) => {
    const response = await AxiosDefault({
        url: `/v1/testimonial/delete`,
        method: "POST",
        contentType: "application/json",
        data
    });
    const responseData: any = response.data;
    return responseData;
};


