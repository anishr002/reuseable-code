import AxiosDefault from "@/services/AxiosDefault";
import { CategoryFormInput } from "@/utils/validators/create-category.schema";

export const cmsUpdate = async (data: CategoryFormInput,slug:string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/cms/${slug}`,
        method: "POST",
        data,
        contentType: "application/json",
    });
    const responseData = response.data;
    return responseData;
};

export const cmsGet = async (slug: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/cms/${slug}`,
        method: "GET",
    });
    const responseData  = response.data;
    return responseData;
};



