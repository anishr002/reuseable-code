import AxiosDefault from "@/services/AxiosDefault";
import { paginationOptions } from "@/hooks/use-pagination";
import { Pagination } from "types";

export const AddFAQ = async (data: any): Promise<any> => {
    const response = await AxiosDefault({
        url: "/v1/faq",
        method: "POST",
        data,
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

export const GetAllFAQsList = async (paginationData: Pagination): Promise<any> => {
    const queryString = paginationOptions(paginationData);
    const baseUrl = '/v1/faq';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
        url,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const GetFAQById = async (id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/faq/${id}`,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const UpdateFAQById = async (data: string, id: any): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/faq/${id}`,
        method: "PUT",
        data,
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

export const DeleteFAQById = async (data: string) => {
    const response = await AxiosDefault({
        url: `/v1/faq/delete`,
        method: "POST",
        contentType: "application/json",
        data
    });
    const responseData: any = response.data;
    return responseData;
};


