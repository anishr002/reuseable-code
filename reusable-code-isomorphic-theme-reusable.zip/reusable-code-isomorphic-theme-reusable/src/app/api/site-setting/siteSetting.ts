import AxiosDefault from "@/services/AxiosDefault";

export const colorUpdate = async (data: any): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/setting`,
        method: "PUT",
        data,
        contentType: "application/json",
    });
    const responseData = response.data;
    return responseData;
};