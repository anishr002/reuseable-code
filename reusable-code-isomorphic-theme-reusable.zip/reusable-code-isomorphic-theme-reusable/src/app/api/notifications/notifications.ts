import { paginationOptions } from "@/hooks/use-pagination";
import AxiosDefault from "@/services/AxiosDefault";
import { Pagination } from "types";

export const notificationDetails = async (contactUsId: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/contact-us/${contactUsId}`,
        method: "GET",
    });
    const responseData  = response.data;
    return responseData;
};

export const getAllNotificationsListing = async (paginationData: Pagination): Promise<any> => {
    const queryString = paginationOptions(paginationData);
    const baseUrl = '/v1/notification';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
        url,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const getAllUnReadNotifications = async (paginationData: Pagination): Promise<any> => {
    const queryString = paginationOptions(paginationData);
    const baseUrl = '/v1/notification/unread-list';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
        url,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const NotificationRead = async (id:any): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/notification/read`,
        method: "PATCH",
        data : id,
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

export const NotificationReadAll = async (): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/notification/read-all`,
        method: "PATCH",
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

