import { APIResponse, Pagination, rolesData } from "types";
import AxiosDefault from "@/services/AxiosDefault";
import { paginationOptions } from "@/hooks/use-pagination";

export const GetAllRoles = async (paginationData: Pagination) => {
    const queryString = paginationOptions(paginationData);
    const baseUrl = '/v1/role';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
        url,
        method: 'GET',
        contentType: "application/json",
    });

    const responseData: APIResponse = response.data;
    return responseData;
};

export const AddNewRole = async (data:any) => {
    const response = await AxiosDefault({
        url: "/v1/role",
        method: "POST",
        data,
        contentType: "application/json",
    });
    const responseData: APIResponse = response.data;
    return responseData;
};

export const GetSingleRole = async (id: string) => {
    const url = `/v1/role/${id}`;
    const response = await AxiosDefault({
        url,
        method: 'GET',
        contentType: "application/json",
    });

    const responseData: APIResponse = response.data;
    return responseData;
};

export const GetAllPermissionEntity = async (data: any) => {
    const url = "/v1/role-permission/get-role-permission";
    const response = await AxiosDefault({
        url,
        data,
        method: 'POST',
        contentType: "application/json",

    });

    const responseData: APIResponse = response.data;
    return responseData;
};

export const UpdateRolePermission = async (data: any) => {
    const response = await AxiosDefault({
        url: `/v1/role-permission/update`,
        method: "PUT",
        data,
        contentType: "application/json",
    });
    const responseData: APIResponse = response.data;
    return responseData;
};

export const UpdateRole = async (data: rolesData,id: string) => {
    const response = await AxiosDefault({
        url: `/v1/role/${id}`,
        method: "PUT",
        data,
        contentType: "application/json",
    });
    const responseData: APIResponse = response.data;
    return responseData;
};

export const DeleteRoleById = async ( id: string) => {
    const response = await AxiosDefault({
        url: `/v1/role/${id}`,
        method: "DELETE",
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

export const GetModuleList = async (data:any) => {
    const response = await AxiosDefault({
        url: "/v1/role/module/list",
        method: "POST",
        data,
        contentType: "application/json",
    });
    const responseData: APIResponse = response.data;
    return responseData;
};
