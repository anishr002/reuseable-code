import { type NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import GoogleProvider from 'next-auth/providers/google';
import { env } from '@/env.mjs';
import { pagesOptions } from './pages-options';
import axios from 'axios';

export const authOptions: NextAuthOptions = {
  debug: true,
  pages: {
    ...pagesOptions,
  },
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  callbacks: {
    async session({ session, token }) {
      return {
        ...session,
        user: {
          ...session.user,
          id: token.idToken as string,
        },
      };
    },
    async jwt({ token, user }) {
      if (user) {
        // return user as JWT
        token.user = user;
      }
      return token;
    },
    async redirect({ url, baseUrl }) {
      // const parsedUrl = new URL(url, baseUrl);
      // if (parsedUrl.searchParams.has('callbackUrl')) {
      //   return `${baseUrl}${parsedUrl.searchParams.get('callbackUrl')}`;
      // }
      // if (parsedUrl.origin === baseUrl) {
      //   return url;
      // }
      return baseUrl;
    },
  },
  providers: [
    CredentialsProvider({
      id: 'credentials',
      name: 'Credentials',
      credentials: {},
      async authorize(credentials: any) {
        try {
          // Replace with your actual external API endpoint
          const response = await axios.post('http://172.16.1.124:3000/users/login', {
            email: credentials?.email,
            password: credentials?.password
          });
    
          const user = response.data; // Assuming API returns the user object
          console.log(user,'60')
    
          if (user) {
            return user; // Return the user object if credentials are valid
          }
          return null; // Return null if credentials are invalid
        } catch (error) {
          console.error('Error during sign-in:', error);
          return null; // Return null if there's an error
        }
      },
      // async authorize(credentials: any) {
      //   debugger;
      //   console.log(credentials,'51')
      //   // You need to provide your own logic here that takes the credentials
      //   // submitted and returns either a object representing a user or value
      //   // that is false/null if the credentials are invalid
      //   const user = {
      //     email: 'admin@admin.com',
      //     password: 'Admin@123',
      //   };
      //   debugger;
      //   const userss = credentials;
      //   debugger;
      //   if (
      //     isEqual(user, {
      //       email: credentials?.email,
      //       password: credentials?.password,
      //     })
      //   ) {
      //     return user as any;
      //   }
      //   return null;
      // },
    }),
    GoogleProvider({
      clientId: env.GOOGLE_CLIENT_ID || '',
      clientSecret: env.GOOGLE_CLIENT_SECRET || '',
      allowDangerousEmailAccountLinking: true,
    }),
  ],
};
