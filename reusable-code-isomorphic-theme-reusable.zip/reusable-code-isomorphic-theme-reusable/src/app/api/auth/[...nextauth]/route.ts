import NextAuth from 'next-auth';
import { authOptions } from './auth-options';
const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };

// app/api/auth/[...nextauth]/route.ts
// import NextAuth from 'next-auth';
// import CredentialsProvider from 'next-auth/providers/credentials';
// import axios from 'axios';

// export const authOptions = {
//   providers: [
//     CredentialsProvider({
//       credentials: {
//         email: { label: 'Email', type: 'text' },
//         password: { label: 'Password', type: 'password' }
//       },
//       async authorize(credentials) {
//         try {
//           const response = await axios.post('http://172.16.0.164:3000/v1/users/login', {
//             email: credentials?.email,
//             password: credentials?.password,
//             loginType :"adminSite"
//           });

//           if (response.data && response.data.token) {
//             return {
//               id: response.data.user.id,
//               email: response.data.user.email,
//               token: response.data.token
//             };
//           } else {
//             return null;
//           }
//         } catch (error) {
//           console.error('Error during login:', error);
//           throw new Error('Invalid email or password');
//         }
//       }
//     })
//   ],
//   pages: {
//     signIn: '/auth/signin', // Specify the path to your custom sign-in page
//   },
//   callbacks: {
//     async session({ session, token }) {
//       if (token) {
//         session.user = token;
//       }
//       return session;
//     },
//     async jwt({ token, user }) {
//       if (user) {
//         token.id = user.id;
//         token.email = user.email;
//         token.token = user.token;
//       }
//       return token;
//     }
//   },
//   session: {
//     strategy: 'jwt'
//   },
//   secret: process.env.NEXTAUTH_SECRET,
// };

// export default NextAuth(authOptions);

