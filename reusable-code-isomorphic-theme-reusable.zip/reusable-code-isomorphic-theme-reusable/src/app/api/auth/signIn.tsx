import AxiosDefault from "@/services/AxiosDefault";
import { UserChangePassword, UserProfile } from "types";

type RequestData = {
  email: string;
  password: string;
};

type ApiResponse = {
  success: boolean;
  message: string;
  token: string;
  data?: any
};

export const Signin = async (data: RequestData): Promise<ApiResponse> => {
  const response = await AxiosDefault({
    url: "/v1/users/login",
    method: "POST",
    data,
    contentType: "application/json",
  });
  const responseData: ApiResponse = response.data;
  return responseData;
};

export async function getUserPermissions(signInData: RequestData) {
  const response = await Signin(signInData);
  if (!response.success) {
    throw new Error('Failed to sign in');
  }

  return response.data;
}



export const SignUp = async (data: RequestData): Promise<ApiResponse> => {
  const response = await AxiosDefault({
    url: "/v1/users/signup",
    method: "POST",
    data,
    contentType: "application/json",
  });
  const responseData: ApiResponse = response.data;
  return responseData;
};

export const ForgetPassword = async (data: RequestData): Promise<ApiResponse> => {
  const response = await AxiosDefault({
    url: "/v1/users/forgot-password",
    method: "POST",
    data,
    contentType: "application/json",
  });
  const responseData: ApiResponse = response.data;
  return responseData;
};

export const ForgetPasswordReset = async (data: RequestData): Promise<ApiResponse> => {
  const response = await AxiosDefault({
    url: "/v1/users/reset-password",
    method: "POST",
    data,
    contentType: "application/json",
  });
  const responseData: ApiResponse = response.data;
  return responseData;
};

export const  getUserProfileDetails = async (): Promise<any> => {
  const response = await AxiosDefault({
      url: `/v1/users/profile`,
      method: "GET",
  });
  const responseData  = response?.data;
  return responseData;
};

export const updateUserProfile = async (data: UserProfile): Promise<any> => {
  const response = await AxiosDefault({
      url: `/v1/users/edit-profile`,
      method: "PUT",
      data,
      contentType: "multipart/form-data",
  });
  const responseData = response?.data;
  return responseData;
};

export const changeUserPassword = async (data: UserChangePassword): Promise<ApiResponse> => {
  const response = await AxiosDefault({
    url: "/v1/users/change-password",
    method: "POST",
    data,
    contentType: "application/json",
  });
  const responseData: ApiResponse = response.data;
  return responseData;
};
