import AxiosDefault from "@/services/AxiosDefault";
import { paginationOptions } from "@/hooks/use-pagination";
import { Pagination } from "types";

export const CreateAdmin = async (data: any): Promise<any> => {
    const response = await AxiosDefault({
        url: "/v1/admin",
        method: "POST",
        data: data,
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

export const GetAllAdminsListWithPagination = async (paginationData: Pagination): Promise<any> => {
    const queryString = paginationOptions(paginationData);
    const url = `/v1/admin${queryString ? `?${queryString}` : ''}`;
    const response = await AxiosDefault({
        url,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const GetAdminById = async (id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/admin/${id}`,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};

export const UpdateAdminById = async (data: string, id: any): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/admin/${id}`,
        method: "PUT",
        data,
        contentType: "application/json",
    });
    const responseData: any = response.data;
    return responseData;
};

export const DeleteadminById = async (data: string) => {
    const response = await AxiosDefault({
        url: `/v1/admin/delete`,
        method: "POST",
        contentType: "application/json",
        data
    });
    const responseData: any = response.data;
    return responseData;
};


