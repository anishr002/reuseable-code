import AxiosDefault from "@/services/AxiosDefault";
import { paginationOptions } from "@/hooks/use-pagination";
import { Pagination } from "types";
import { CategoryFormInput } from "@/utils/validators/create-category.schema";

export const AddBlogCategory = async (data: CategoryFormInput): Promise<any> => {
    const response = await AxiosDefault({
        url: "/v1/category",
        method: "POST",
        data,
        contentType: "multipart/form-data",
    });
    const responseData = response.data;
    return responseData;
};

export const GetAllCategoriesList = async (paginationData: Pagination): Promise<any> => {
    const queryString: string = paginationOptions(paginationData);
    const baseUrl = '/v1/category';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
      url,
      method: 'GET',
    });
    return response.data;
  };

  export const GetAllCategoriesForDropdown = async (paginationData: Pagination): Promise<any> => {
    const queryString: string = paginationOptions(paginationData);
    const baseUrl = '/v1/category/get-category';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
      url,
      method: 'GET',
    });
    return response.data;
  };

export const GetBlogCategoryId = async (id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/category/${id}`,
        method: "GET",
    });
    const responseData  = response.data;
    return responseData;
};

export const UpdateBlogCategory = async (data: CategoryFormInput, id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/category/${id}`,
        method: "PUT",
        data,
        contentType: "multipart/form-data",
    });
    const responseData = response.data;
    return responseData;
};

export const DeleteBlogCategory = async (data: string) => {
    const response = await AxiosDefault({
        url: `/v1/category/delete`,
        method: "POST",
        contentType: "application/json",
        data
    });
    const responseData  = response;
    return responseData;
};


export const createBlog = async (data: CategoryFormInput): Promise<any> => {
    const response = await AxiosDefault({
        url: "/v1/blog",
        method: "POST",
        data,
        contentType: "multipart/form-data",
    });
    const responseData = response.data;
    return responseData;
};

export const getAllBlogList = async (paginationData: Pagination): Promise<any> => {
    const queryString: string = paginationOptions(paginationData);
    const baseUrl = '/v1/blog';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
      url,
      method: 'GET',
    });
    return response.data;
  };

export const getBlogDetails = async (id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/blog/${id}`,
        method: "GET",
    });
    const responseData  = response.data;
    return responseData;
};

export const updateBlog = async (data: CategoryFormInput, id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/blog/${id}`,
        method: "PUT",
        data,
        contentType: "multipart/form-data",
    });
    const responseData = response.data;
    return responseData;
};

export const deleteBlog = async (data: string) => {
    const response = await AxiosDefault({
        url: `/v1/blog/delete`,
        method: "POST",
        contentType: "application/json",
        data
    });
    const responseData  = response.data;
    return responseData;
};

export const GetAllSubCategories = async ( id: string, paginationData: Pagination): Promise<any> => {
    const queryString: string = paginationOptions(paginationData);
    const baseUrl = `/v1/subcategory/list/${id}`;
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
      url,
      method: 'GET',
    });
    return response.data;
  };

  export const AddSubCategory = async (data: CategoryFormInput): Promise<any> => {
    const response = await AxiosDefault({
        url: "/v1/subcategory",
        method: "POST",
        data,
        contentType: "multipart/form-data",
    });
    const responseData = response.data;
    return responseData;
};

export const UpdateSubCategory = async (data: CategoryFormInput, id: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/subcategory/${id}`,
        method: "PUT",
        data,
        contentType: "multipart/form-data",
    });
    const responseData = response.data;
    return responseData;
};

export const deleteSubCategory = async (data: string) => {
    const response = await AxiosDefault({
        url: `/v1/subcategory/delete`,
        method: "POST",
        contentType: "application/json",
        data
    });
    const responseData  = response.data;
    return responseData;
};
