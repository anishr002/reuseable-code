import { paginationOptions } from "@/hooks/use-pagination";
import AxiosDefault from "@/services/AxiosDefault";
import { Pagination } from "types";

export const contactUsDetails = async (contactUsId: string): Promise<any> => {
    const response = await AxiosDefault({
        url: `/v1/contact-us/${contactUsId}`,
        method: "GET",
    });
    const responseData  = response.data;
    return responseData;
};

export const getAllContactUsListing = async (paginationData: Pagination): Promise<any> => {
    const queryString = paginationOptions(paginationData);
    const baseUrl = '/v1/contact-us';
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const response = await AxiosDefault({
        url,
        method: "GET",
    });
    const responseData: any = response.data;
    return responseData;
};


