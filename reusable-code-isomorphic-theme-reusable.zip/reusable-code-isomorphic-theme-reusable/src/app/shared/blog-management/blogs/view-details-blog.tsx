import React from 'react';
import { PiXBold } from 'react-icons/pi';
import { ActionIcon, Button, Title } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';
import Image from 'next/image';
import { getStatusBadgeForView } from '@/utils/status-badge';
import { HtmlFormatDetails } from '@/components/ui/html-format';

const BlogDetails = ({ data }: any) => {
  const { closeModal } = useModal();
  
  return (
    <div className="flex flex-col gap-6 p-6 @container [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900">
      <div className="flex items-center justify-between">
        <Title as="h4" className="font-semibold">
          View Blog Details
        </Title>
        <ActionIcon size="sm" variant="text" onClick={closeModal}>
          <PiXBold className="h-auto w-5" />
        </ActionIcon>
      </div>

      <div className="flex flex-col gap-4">
        <div className="text-sm">
          <strong>Blog Title:</strong> {data?.title ?? '-'}
        </div>
        <div className="text-sm">
          <strong>Category:</strong> {data?.categoryId?.name ?? '-'}
        </div>
        <div className="text-sm">
          <strong>SubCategory:</strong> {data?.subCategoryId?.name ?? '-'}
        </div>
        <div className="text-sm">
          <strong>Status:</strong> {getStatusBadgeForView(Number(data?.status))}
        </div>
        <div className="text-sm">
          <strong>Content:</strong>
          <div 
            className="ml-2 p-2 border rounded-lg max-h-96 min-h-32 overflow-y-auto bg-gray-50"
          >
            {data?.content ? (
              <HtmlFormatDetails description={data?.content} />
            ) : (
              '-'
            )}
          </div>
        </div>
        <div className='flex justify-between items-start'> 
        <div className="text-sm">
          <strong>Thumbnail Image:</strong>
          <div className="image-preview mt-2 max-h-64 overflow-hidden">
            {data?.thumbnailImage ? (
              <Image
                src={data?.thumbnailImage}
                alt="Blog Thumbnail"
                height={200}
                width={150}
                className="rounded-lg"
                style={{ maxHeight: '150px' }}
              />
            ) : (
              '-'
            )}
          </div>
        </div>
        <div className="text-sm">
          <strong>Header Image:</strong>
          <div className="image-preview mt-2 max-h-64 overflow-hidden">
            {data?.headerImage ? (
              <Image
                src={data?.headerImage}
                alt="Header Image"
                height={200}
                width={150}
                className="rounded-lg"
                style={{ maxHeight: '150px' }}
              />
            ) : (
              '-'
            )}
          </div>
        </div>
        </div>
      </div>

      <div className="flex items-center justify-end gap-4">
        <Button variant="outline" onClick={closeModal} className="w-full @xl:w-auto">
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default BlogDetails;
