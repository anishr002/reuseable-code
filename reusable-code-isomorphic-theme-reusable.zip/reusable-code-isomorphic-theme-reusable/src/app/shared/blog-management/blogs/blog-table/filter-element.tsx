'use client';

import React, { useEffect, useState } from 'react';
import { PiTrashDuotone } from 'react-icons/pi';
import StatusField from '@/components/controlled-table/status-field';
import { Button, Badge, Text } from 'rizzui';
import { useDispatch} from 'react-redux';
import { STATUSVALUENAME } from '@/enums';
import { getAllBlogCategories } from '@/redux/slices/blog-management/blogcategorySlice';
import Spinner from '@/components/ui/spinner';


type FilterElementProps = {
  isFiltered: boolean;
  filters: { [key: string]: any };
  updateFilter: (columnId: string, filterValue: string | any[]) => void;
  handleReset: () => void;
};
export default function BlogFilterElement({
  isFiltered,
  filters,
  updateFilter,
  handleReset,
}: Readonly<FilterElementProps>) {

    const [categoryList,setCategoryList] = useState([]);
    const dispatch = useDispatch();

  useEffect(() =>{
    dispatch(getAllBlogCategories({}))
    .then((res: any) => {
        if (res?.payload?.length > 0) {
            const categories = res?.payload?.map((item: any) => ({
                value: item?._id,
                label: item?.name,
            }));
            setCategoryList(categories);
        }
    })
    .catch((error: any) => {
        console.error('Error fetching classes for attendance:', error);
    });
  },[dispatch]);

  return (
    <>
    {
      categoryList?.length > 0  ?
      <>
      <StatusField
        label="Status"
        options={STATUSVALUENAME}
        value={filters['filterByStatus']}
        onChange={(value: string) => {
          updateFilter('filterByStatus', value);
        }}
        getOptionValue={(option: { value: any }) => option.value}
        getOptionDisplayValue={(option: { label: string }) =>
          renderOptionDisplayValue(option.label)
        }
        displayValue={(selected) =>
          STATUSVALUENAME.find((option) => option.value == selected)
            ?.label ?? ''
        }
      />

      <StatusField
        label="Category"
        options={categoryList}
        value={filters['filterByCategory']}
        onChange={(value: string) => {
          updateFilter('filterByCategory', value);
        }}
        getOptionValue={(option: { value: any }) => option.value}
        getOptionDisplayValue={(option: { label: any }) =>
          renderOptionDisplayValue(option.label as string)
        }
        displayValue={(selected: any) => {
           const roleValue:any = categoryList?.find((option:any) => option?.value === selected);
           return roleValue?.label || '' ;
           }}
      />
      </> : <Spinner/>
    }
    
      {isFiltered ? (
        <Button
          size="sm"
          onClick={() => {
            handleReset();
          }}
          className="h-8 bg-gray-200/70"
          variant="flat"
        >
          <PiTrashDuotone className="me-1.5 h-[17px] w-[17px]" /> Clear
        </Button>
      ) : null}
    </>
  );
}

function renderOptionDisplayValue(value: string) {
  switch (value) {
    case 'pending':
      return (
        <div className="flex items-center">
          <Badge color="warning" renderAsDot />
          <Text className="ms-2 font-medium capitalize text-orange-dark">
            {value}
          </Text>
        </div>
      );
    case 'publish':
      return (
        <div className="flex items-center">
          <Badge color="success" renderAsDot />
          <Text className="ms-2 font-medium capitalize text-green-dark">
            {value}
          </Text>
        </div>
      );

    default:
      return (
        <div className="flex items-center">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="ms-2 font-medium capitalize text-gray-600">
            {value}
          </Text>
        </div>
      );
  }
}
