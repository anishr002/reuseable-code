"use client";

import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import { getBlogColumns } from './column';
import BlogFilterElement from './filter-element';
import { deleteBlogById, getAllBlogListAction } from '@/redux/slices/blog-management/blogmanagementSlice';
import PageHeader from '@/app/shared/page-header';
import { routes } from '@/config/routes';
import Link from 'next/link';
import { Button } from 'rizzui';
import { PiPlusBold } from 'react-icons/pi';
import PermissionWrapper from '@/app/shared/PermissionWrapper';
import WithAuth from '@/components/protected-router';

const initialFilterState = {
  filterByCategory : '',
  filterByStatus : ''
};

const pageHeader = {
  title: 'Blogs',
  breadcrumb: [
    {
      name: 'Blog Management',
    },
    {
      name: 'Blogs',
    },
  ],
};


 function BlogTable() {
  const [pageSize, setPageSize] = useState(10);
  const dispatch = useDispatch();
  const blogList = useSelector((state: any) => state.blogs.getBlogList);

  const handleChangePage = async (paginationParams: Pagination) => {
    let { page, pageSize, sortBy, search, filterByStatus,filterByCategory } = paginationParams;
    try {
      const response = await dispatch(getAllBlogListAction({ page, pageSize, sortBy, search, filterByStatus,filterByCategory }));

      if (response?.payload) {
        const { total, data } = response.payload;
        const maxPage: number = Math.ceil(total / pageSize);
        if (page > maxPage) {
          page = maxPage > 0 ? maxPage : 1;
          const adjustedResponse = await dispatch(getAllBlogListAction({ page, pageSize, sortBy, search, filterByStatus,filterByCategory }));

          if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
            return adjustedResponse;
          }
        }
        if (data && data.length !== 0) {
          return data;
        }
      }
      return [];

    } catch (error) {
      console.error('Error fetching admin list:', error);
      return [];
    }
  };

  const handleDeleteById = async (id: string | string[]) => {
    try {
      const res = await dispatch(deleteBlogById({ id }));
      if (res.payload.status === false || res.payload.status === 0) {
          toast.error(res.payload.message);
      } else {
          toast.success(res.payload.message);
          await dispatch(getAllBlogListAction({ sortBy: 'createdAt:desc'}));
      }
  } catch (error) {
      console.error(error);
  }

  };
  return (
    <>
     <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
        <PermissionWrapper moduleName="blog-list" action='create'>
          <Link
            href={routes.blogManagement.blogCreate}
            className="w-full @lg:w-auto"
          >
            <Button as="span" className="w-full @lg:w-auto">
              <PiPlusBold className="me-1.5 h-[17px] w-[17px]" />
              Create Blog
            </Button>
          </Link>
        </PermissionWrapper>
      </PageHeader>
        <Table
        data={blogList?.data && blogList?.data?.data?.length > 0 ? blogList?.data?.data : []}
        getColumns={(props:any) => getBlogColumns({...props})}
        pageSize={pageSize}
        setPageSize={setPageSize}
        page={blogList?.data?.page}
        sortBy={blogList?.data?.sortBy}
        total={blogList?.data?.total}
        isLoading={blogList?.loading}
        initialFilterState={initialFilterState}
        FilterElement ={BlogFilterElement}
        handleChangePage={handleChangePage}
        handleDeleteById ={handleDeleteById}
        isScroll={false}
        isToggleColumns={true}
        isSearch={true}
        isDrawerFilter = {true}
        moduleName='blog-list'
      />
    </>
  );
}

export default WithAuth(BlogTable);
