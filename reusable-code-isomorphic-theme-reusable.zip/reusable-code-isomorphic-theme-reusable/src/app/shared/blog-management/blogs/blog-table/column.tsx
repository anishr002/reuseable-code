'use client';

import { Tooltip, Checkbox, ActionIcon } from 'rizzui';
import { HeaderCell } from '@/components/ui/table';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import AvatarCard from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import DeletePopover from '@/app/shared/delete-popover';
import { getStatusBadge } from '@/utils/status-badge';
import { BlogType, Columns, User } from 'types';
import Link from 'next/link';
import { routes } from '@/config/routes';
import { useModal } from '@/app/shared/modal-views/use-modal';
import BlogDetails from '../view-details-blog';

export const getBlogColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  canEdit,
  canView,
  canDelete
}: Columns) =>{
  const columns = [
    canDelete && {
      title: (
        <div className="flex items-center gap-3 whitespace-nowrap ps-3">
          <Checkbox
            title={'Select All'}
            onChange={handleSelectAll}
            checked={checkedItems.length === data.length}
            className="cursor-pointer"
          />
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 10,
      render: (_: any, row: User) => (
        <div className="inline-flex ps-3">
          <Checkbox
            className="cursor-pointer"
            checked={checkedItems.includes(row._id)}
            {...(onChecked && { onChange: () => onChecked(row._id) })}
          />
        </div>
      ),
    },
    {
      title: <HeaderCell title="Title" 
       sortable
      ascending={
        sortConfig === 'title:asc'
      } />,
      onHeaderCell: () => onHeaderCellClick('title'),
      dataIndex: 'Title',
      key: 'title',
      width: 300,
      render: (_: string, row: BlogType) => (
        <AvatarCard
          src={row?.thumbnailImage}
          name={row?.title}
          // description={row.?.}
          avatarProps={{
            name: row?.title,
            size: 'lg',
            className: 'rounded-lg',
          }}
        />
      ),
    },
    {
      title: (
        <HeaderCell
          title="Category"
          sortable
          ascending={
            sortConfig === 'categoryId:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('categoryId'),
      dataIndex: 'Category',
      key: 'categoryId',
      width: 150,
      render: (_: any, row: any) => {
        return row?.categoryId ? row?.categoryId?.name : '-';
      },
    },
    {
      title: (
        <HeaderCell
          title="SubCategory"
          sortable
          ascending={
            sortConfig === 'subCategoryId:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('subCategoryId'),
      dataIndex: 'Category',
      key: 'subCategoryId',
      width: 150,
      render: (_: any, row: any) => {
        return row?.subCategoryId ? row?.subCategoryId?.name : '-';
      },
    },
    {
      title: (
        <HeaderCell
          title="Created At"
          sortable
          ascending={
            sortConfig  === 'createdAt:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'Created At',
      key: 'createdAt',
      width: 120,
      render: (_: any, row: any) => {
        return row ? <DateCell date={row?.createdAt} /> : '-';
      },
    },
    {
      title: <HeaderCell title="Status" />,
      dataIndex: 'Status',
      key: 'status',
      width: 120,
      render: (_: any, row: any) => {
        return (row ? getStatusBadge(Number(row?.status)) : '-');
      },
    },
    {
      title: <></>,
      dataIndex: 'action',
      key: 'action',
      width: 100,
      render: (_: string, row: any) => (
        <RenderAction row={row} onDeleteItem={onDeleteItem} canEdit={canEdit} canView={canView} canDelete={canDelete} />
      ),
    },
  ];
  return columns;
};


  const RenderAction = ({
    row,
    onDeleteItem,
    canEdit,
    canView,
    canDelete
  }: {
    row: any;
    onDeleteItem: (id: string) => void;
    canEdit?: boolean;
    canView?: boolean;
    canDelete?: boolean;
  }) => {
    const { openModal } = useModal();
  
    return (
      <div className="flex items-center justify-start gap-3 pe-4">
        {canView && canEdit && (
          <Tooltip
            size="sm"
            content="Edit Blog"
            placement="top"
            color="invert"
          >
            <Link href={routes.blogManagement.blogEdit(row._id)}>
              <ActionIcon size="sm" variant="outline" aria-label="Edit Blog">
                <PencilIcon className="h-4 w-4" />
              </ActionIcon>
            </Link>
          </Tooltip>
        )}
  
        {canView && (
          <Tooltip
            size="sm"
            content="View Blog"
            placement="top"
            color="invert"
          >
            <ActionIcon
              size="sm"
              variant="outline"
              onClick={() =>
                openModal({
                  view: <BlogDetails data={row} />,
                  customSize: '750px',
                })
              }
            >
              <EyeIcon className="h-4 w-4" />
            </ActionIcon>
          </Tooltip>
        )}
  
        {canDelete && (
          <DeletePopover
            title="Delete the blog"
            description="Are you sure you want to delete this blog?"
            onDelete={() => onDeleteItem(row._id)}
          />
        )}
      </div>
    );
  };
  
