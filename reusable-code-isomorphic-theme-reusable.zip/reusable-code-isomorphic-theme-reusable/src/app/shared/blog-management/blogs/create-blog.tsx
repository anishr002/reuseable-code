/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { SubmitHandler, Controller } from 'react-hook-form';
import SelectLoader from '@/components/loader/select-loader';
import QuillLoader from '@/components/loader/quill-loader';
import { Button, Input } from 'rizzui';
import cn from '@/utils/class-names';
import { Form } from '@/components/ui/form';
import UploadZone from '@/components/ui/file-upload/upload-zone';
import { HorizontalFormBlockWrapper } from '@/components/horizontal-form-blockwrapper';
import { BlogFormInput, blogFormSchema } from '@/utils/validators/create-blog.schema';
import { STATUSVALUENAME } from '@/enums';
import { useDispatch, useSelector } from 'react-redux';
import { getAllBlogCategories, getAllSubCategoriesList } from '@/redux/slices/blog-management/blogcategorySlice';
import { createBlogAction, getAllBlogListAction, getBlogIdAction, resetGetBlogDetails, updateBlogById } from '@/redux/slices/blog-management/blogmanagementSlice';
import toast from 'react-hot-toast';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
const Select = dynamic(() => import('rizzui').then((mod) => mod.Select), {
  ssr: false,
  loading: () => <SelectLoader />,
});
const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[168px]" />,
});


export default function CreateBlogs({
  id,
  isModalView = true,
  type,
}: {
  id?: string;
  isModalView?: boolean;
  type?: string;
}) {
  const dispatch = useDispatch();
  const route = useRouter();
  const singleBlogData = useSelector((state: any) => state.blogs.getBlogDetails);
  const [isLoading, setIsLoading] = useState(false);
  const [categoryList, setCategoryList] = useState<any[]>([]);
  const [thumbnailFiles, setThumbnailFiles] = useState<any[]>([]);
  const [headerFiles, setHeaderFiles] = useState<any[]>([]);
  const [subCategories, setSubCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null); 

  useEffect(() => {
    dispatch(getAllBlogCategories({}))
      .then((res: any) => {
        if (res?.payload?.length > 0) {
          const categories = res?.payload?.map((item: any) => ({
            value: item?._id,
            label: item?.name,
          }));
          setCategoryList(categories);
        }
      })
      .catch((error: any) => {
        console.error('Error fetching classes for attendance:', error);
      });
    if (type == 'Edit') {
      dispatch(getBlogIdAction(id)).then((res:any) => {
        if (res?.payload?.status == 4) {
          route.push(routes.notFound);
        };
      });
    }
  }, [dispatch, id, type]);

  useEffect(() => {
    if (type === 'Edit' && !singleBlogData?.singleBlogloading) {
      const thumbnailFile = singleBlogData?.data?.thumbnailImage
        ? [{
            name: singleBlogData?.data?.thumbnailImage?.slice(12),
            preview: singleBlogData?.data?.thumbnailImage,
            path: singleBlogData?.data?.thumbnailImage,
            size: 2,
          }]
        : [];
  
      const headerFile = singleBlogData?.data?.headerImage
        ? [{
            name: singleBlogData?.data?.headerImage?.slice(12),
            preview: singleBlogData?.data?.headerImage,
            path: singleBlogData?.data?.headerImage,
            size: 2,
          }]
        : [];
  
      setThumbnailFiles(thumbnailFile);
      setHeaderFiles(headerFile);
  
      const categoryId = singleBlogData?.data?.categoryId?._id;
      if (categoryId) {
        setSelectedCategory(categoryId); 
        fetchSubCategories(categoryId); 
      }
    }
  }, [type, singleBlogData]);
  

  const appendImageToFormData = (formData: FormData, fileData: any, key: string) => {
    if (fileData) {
      const file = Array.isArray(fileData) ? fileData[0] : fileData;
      if (file instanceof File) {
        formData.append(key, file);
      }
    }
  };

  const fetchSubCategories = async (categoryId: string) => {
    const paginationData = {sortBy :'createdAt:desc',isPagination:false};
    dispatch(getAllSubCategoriesList({id:categoryId,paginationData}))
      .then((res: any) => {
        if (res?.payload?.data) {
          const subCategories = res?.payload?.data?.map((item: any) => ({
            value: item?._id,
            label: item?.name,
          }));
          setSubCategories(subCategories);
        }
      })
      .catch((error: any) => {
        console.error('Error fetching subcategoried for blog:', error);
      });
  };

 
  
  const onSubmit: SubmitHandler<BlogFormInput> = async (data: any) => {
    try {
      setIsLoading(true);
      const formData = new FormData();
      formData.append('title', data.title);
      formData.append('content', data.content);
      formData.append('categoryId', data.categoryId);
      formData.append('status', data.status);
      formData.append('subCategoryId', data.subCategoryId);
  
      // Handle images
      appendImageToFormData(formData, data.thumbnailImage, 'thumbnailImage');
      appendImageToFormData(formData, data.headerImage, 'headerImage');
  
      const action = type === 'Edit'
        ? updateBlogById({ data: formData, id })
        : createBlogAction(formData);
  
      const res = await dispatch(action);
      const status = res?.payload?.status;
      const message = res?.payload?.message;
  
      if (status === false || status === 0) {
        toast.error(message);
      } else {
        toast.success(message);
        dispatch(resetGetBlogDetails());
        dispatch(getAllBlogListAction({ sortBy: 'createdAt:desc' }));
        route.push(routes.blogManagement.blogs);
      }
    } catch (error) {
      console.error('Submit Error:', error);
    } finally {
      setIsLoading(false);
    }
  };
  

  const handleCancel = () =>{
    dispatch(resetGetBlogDetails());
  };

  const getDisplayValue = (selected: any, categoryList: any[]) =>
    categoryList.find((option: any) => option.value === selected)?.label ?? '';
  

  return (
    singleBlogData?.singleBlogloading ?
      <Spinner /> :
      (<Form<BlogFormInput>
        validationSchema={blogFormSchema}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'onChange',
          defaultValues: {
            title: singleBlogData?.data?.title ?? '',
            content: singleBlogData?.data?.content ?? '',
            categoryId: singleBlogData?.data?.categoryId?._id ?? '',
            thumbnailImage: [singleBlogData?.data?.thumbnailImage] ?? [],
            headerImage: [singleBlogData?.data?.headerImage] ?? [],
            status: singleBlogData?.data?.status ?? "",
            subCategoryId :  singleBlogData?.data?.subCategoryId?._id ?? ""
          },
        }}
        className="isomorphic-form flex flex-grow flex-col @container"
      >
        {({ register, control, getValues, setValue, formState: { errors } }) => {

           const handleCategoryChange = (categoryId: any) => {
            setSelectedCategory(categoryId);
            setSubCategories([]);
            setValue('subCategoryId',[]);
            fetchSubCategories(categoryId);
            
          };
          return (
          <>
            <div className="flex-grow pb-10">
              <div
                className={cn(
                  'grid grid-cols-1 ',
                  isModalView
                    ? 'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                    : 'gap-5'
                )}
              >
                <HorizontalFormBlockWrapper
                  title={type === 'Edit' ? 'Edit blog' : 'Add new blog:'}
                  description={`${type} your blog information from here`}
                  isModalView={isModalView}
                >
                  <Input
                    label="Blog Title"
                    placeholder="blog title"
                    {...register('title')}
                    error={errors.title?.message}
                  />

                  <Controller
                    name="categoryId"
                    control={control}
                    render={({ field: { name, onChange, value } }) => (
                      <Select
                        options={categoryList}
                        value={value}
                        onChange={(e:any) => {
                          onChange(e);
                          handleCategoryChange(e);
                        }}
                        name={name}
                        label="Category"
                        error={errors?.categoryId?.message}
                        getOptionValue={(option: any) => option.value}
                        displayValue={(selected: any) => getDisplayValue(selected, categoryList)}
                        disabled={type == 'View' ? true : false}
                        dropdownClassName="!z-[1]"
                      />
                    )}
                  />

              <Controller
                name="subCategoryId"
                control={control}
                render={({ field: {name, onChange, value } }) => (
                  <Select
                    options={subCategories}
                    value={value}
                     name={name}
                    onChange={onChange}
                    label="Subcategory"
                    getOptionValue={(option: any) => option.value}
                    displayValue={(selected: any) => getDisplayValue(selected, subCategories)}
                    disabled={type === 'View' || !selectedCategory} 
                  />
                )}
              />

                  <Controller
                    name="status"
                    control={control}
                    render={({ field: { name, onChange, value } }) => (
                      <Select
                        options={STATUSVALUENAME}
                        value={value}
                        onChange={onChange}
                        name={name}
                        label="Status"
                        placeholder="select status"
                        error={errors?.status?.message}
                        getOptionValue={(option) => option.value}
                        displayValue={(selected: any) => getDisplayValue(selected, STATUSVALUENAME)}
                        dropdownClassName="!z-[1]"
                        disabled={type == 'View' ? true : false}
                      />
                    )}
                  />

                  <div className="col-span-2">
                    <Controller
                      control={control}
                      name="content"
                      render={({ field: { onChange, value } }) => (
                        <QuillEditor
                          value={value}
                          onChange={onChange}
                          label="Content"
                          className="[&>.ql-container_.ql-editor]:min-h-[100px]"
                          labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                          error={errors?.content?.message}
                        />
                      )}
                    />
                  </div>
                </HorizontalFormBlockWrapper>
                <HorizontalFormBlockWrapper
                  title="Upload new thumbnail image"
                  description="Upload your blog thumbnail image here"
                  isModalView={isModalView}
                >
                  <UploadZone
                    name="thumbnailImage"
                    getValues={getValues}
                    setValue={setValue}
                    files={thumbnailFiles}
                    setFiles={setThumbnailFiles} 
                    type = {type}
                    className="col-span-full"
                  />
                </HorizontalFormBlockWrapper>
                <HorizontalFormBlockWrapper
                  title="Upload new header image"
                  description="Upload your blog image here"
                  isModalView={isModalView}
                >
                  <UploadZone
                    name="headerImage"
                    getValues={getValues}
                    setValue={setValue}
                    files={headerFiles}
                    setFiles={setHeaderFiles}
                    type = {type}
                    className="col-span-full"
                  />
                </HorizontalFormBlockWrapper>
              </div>
            </div>

            <div
              className={cn(
                'sticky bottom-0 z-40 flex items-center justify-end gap-3 bg-gray-0/10 backdrop-blur @lg:gap-4 @xl:grid @xl:auto-cols-max @xl:grid-flow-col',
                isModalView ? '-mx-10 -mb-7 px-10 py-5' : 'py-1'
              )}
            >
              <Link href={routes.blogManagement.blogs}>
                <Button onClick={handleCancel} variant="outline" className="w-full @xl:w-auto">
                  Cancel
                </Button>
              </Link>
              <Button
                type="submit"
                isLoading={isLoading}
                className="w-full @xl:w-auto"
              >
                {id ? 'Update' : 'Create'} Blog
              </Button>
            </div>
          </>
          )
}}
      </Form>)
  );
}

