'use client';

import { HeaderCell } from '@/components/ui/table';
import { Checkbox, Title, Tooltip, ActionIcon } from 'rizzui';
import PencilIcon from '@/components/icons/pencil';
import DeletePopover from '@/app/shared/delete-popover';
import { getStatusBadge } from '@/utils/status-badge';
import { useModal } from '@/app/shared/modal-views/use-modal';
import CreateCategory from '../create-category';
import EyeIcon from '@/components/icons/eye';
import { BlogSubCategory, Columns } from 'types';
import DateCell from '@/components/ui/date-cell';
import Image from 'next/image';
import categoryBlog from '@public/category-blog.jpg';
import CreateBlogSubCategory from '../create-subcategory';


export const getSubCategoryColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  canEdit,
  canView,
  canDelete
}: Columns) => [
    canDelete && {

      title: (
        <div className="flex items-center gap-2 whitespace-nowrap ps-3">
          <Checkbox
            title={'Select All'}
            onChange={handleSelectAll}
            checked={checkedItems.length === data.length}
            className="cursor-pointer"
          />
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 10,
      render: (_: any, row: BlogSubCategory) => (
        <div className="inline-flex ps-3">
          <Checkbox
            className="cursor-pointer"
            checked={checkedItems.includes(row._id)}
            {...(onChecked && { onChange: () => onChecked(row._id) })}
          />
        </div>
      ),
    },
    {
      title: <HeaderCell title="Image" />,
      dataIndex: 'image',
      key: 'image',
      width: 100,
      render: (_: any, row: BlogSubCategory) => (
        <figure className="relative aspect-square w-12 overflow-hidden rounded-lg bg-gray-100">
          <Image
            alt={row?.name}
            src={row?.subCategoryImage ?? categoryBlog}
            fill
            sizes="(max-width: 768px) 100vw"
            className="object-cover"
          />
        </figure>
      ),
    },
    {
      title: (
        <HeaderCell
          title="SubCategory Name"
          sortable
          ascending={
            sortConfig === 'name:asc'
          }
        />
      ),
      dataIndex: 'SubCategory Name',
      key: 'name',
      width: 150,
      onHeaderCell: () => onHeaderCellClick('name'),
      render: (_: any, row: BlogSubCategory) => {
        return (
          <Title as="h6" className="!text-sm font-medium">
            {row?.name}
          </Title>);
      },
    },
    {
      title: <HeaderCell title="Status"
      sortable
          ascending={
            sortConfig === 'status:asc'
          } />,
          onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'Status',
      key: 'status',
      width: 120,
      render: (_: any, row: BlogSubCategory) => {
        return (row ? getStatusBadge(Number(row?.status)) : '-');
      },
    },
    {
      title: (
        <HeaderCell
          title="Created At"
          sortable
          ascending={
            sortConfig  === 'createdAt:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'Created At',
      key: 'createdAt',
      width: 120,
      render: (_: any, row: any) => {
        return row ? <DateCell date={row?.createdAt} /> : '-';
      },
    },
    {
      title: <></>,
      dataIndex: 'action',
      key: 'action',
      width: 100,
      render: (_: string, row: any) => (
        <RenderAction row={row} onDeleteItem={onDeleteItem} canEdit={canEdit} canView={canView} canDelete={canDelete} />
      ),
    },
  ];

const RenderAction = ({
  row,
  onDeleteItem,
  canEdit,
  canView,
  canDelete
}: {
  row: any;
  onDeleteItem: (id: string) => void;
  canEdit?: boolean;
  canView?: boolean;
  canDelete?: boolean;
}) => {
  const { openModal } = useModal();
  return (
    <div className="flex items-center justify-start gap-3 pe-4">
      {canEdit && <Tooltip
        size="sm"
        content={'Edit SubCategory'}
        placement="top"
        color="invert"
      >
         <ActionIcon
          as="span"
          size="sm"
          variant="outline"
          onClick={() =>
            openModal({
              view: (
                <CreateBlogSubCategory
                  type="Edit"
                  title={"Edit SubCategory"}
                  id={row?._id}
                  data={row && row}
                />
              ),
              customSize: '750px',
            })
          }
          className="hover:!border-gray-900 hover:text-gray-700"
        >
          <PencilIcon className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>}
      {canView && <Tooltip
        size="sm"
        content={"View SubCategory"}
        placement="top"
        color="invert"
      >
        <ActionIcon
          size="sm"
          variant="outline"
          onClick={() =>
            openModal({
              view: (
                <CreateBlogSubCategory
                  type="View"
                  title={"View SubCategory"}
                  id={row?._id}
                  data={row}
                />
              ),
              customSize: '750px',
            })
          }
        >
          <EyeIcon className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>}
      {canDelete && <DeletePopover
        title={`Delete the category`}
        description={`Are you sure you want to delete this #${row?.name} category?`}
        onDelete={() => onDeleteItem(row._id)}
      />}
    </div>
  );
};
