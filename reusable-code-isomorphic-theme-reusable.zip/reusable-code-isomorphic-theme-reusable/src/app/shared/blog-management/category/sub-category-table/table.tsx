"use client";

import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import { deleteSubCategoryById, getAllSubCategoriesList } from '@/redux/slices/blog-management/blogcategorySlice';
import {getSubCategoryColumns } from './columns';
import WithAuth from '@/components/protected-router';
import { useParams } from 'next/navigation';
import PermissionWrapper from '@/app/shared/PermissionWrapper';
import ModalButton from '@/app/shared/modal-button';
import CreateBlogSubCategory from '../create-subcategory';


const BlogSubCategory = () => {
  const [pageSize, setPageSize] = useState(10);
  const dispatch = useDispatch();
  const params = useParams();

  const subCategoryList = useSelector((state: any) => state.blogcategory.subCategoryList);

  const handleChangePage = async (paginationParams: Pagination) => {
    let { page, pageSize, sortBy, search } = paginationParams;

    const paginationData = {
      page,
      pageSize,
      sortBy, 
      search 
    };

    try {
      const response = await dispatch(getAllSubCategoriesList({id:params?.id,paginationData}));

      if (response?.payload) {
        const { total, data } = response.payload;
        const maxPage: number = Math.ceil(total / pageSize);
        if (page > maxPage) {
          page = maxPage > 0 ? maxPage : 1;
          const paginationData = {
            page,
            pageSize,
            sortBy, 
            search 
          };
          const adjustedResponse = await dispatch(getAllSubCategoriesList({id:params?.id,paginationData}));

          if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
            return adjustedResponse;
          }
        }
        if (data && data.length !== 0) {
          return data;
        }
      }
      return [];

    } catch (error) {
      console.error('Error fetching admin list:', error);
      return [];
    }
  };

  const handleDeleteById = async (id: string | string[]) => {
    try {
      const res = await dispatch(deleteSubCategoryById({ id }));
      if (res.payload.status === false || res.payload.status === 0) {
        toast.error(res.payload?.message);
      } else {
        const paginationData = {
          sortBy: 'createdAt:desc' 
        };
        toast.success(res.payload.data?.message);
        await dispatch(getAllSubCategoriesList({id : params?.id,paginationData  }));
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>  
    <div className="col-span-full flex items-center justify-end gap-4">
    <PermissionWrapper moduleName="blog-category" action='create'>  
    <ModalButton 
      label="Create SubCategory" 
      view={<CreateBlogSubCategory title='Create SubCategory' type='Create'/>} 
      customSize = '750px'
      className="w-60"
      />
    </PermissionWrapper>
  </div>
      <Table
        data={subCategoryList?.data?.data?.length > 0 ? subCategoryList?.data?.data : []}
        getColumns={(props: any) => getSubCategoryColumns({ ...props })}
        pageSize={pageSize}
        setPageSize={setPageSize}
        page={subCategoryList?.data?.page}
        sortBy={subCategoryList?.data?.sortBy}
        total={subCategoryList?.data?.total}
        isLoading={subCategoryList?.loading}
        handleChangePage={handleChangePage}
        handleDeleteById={handleDeleteById}
        isScroll={false}
        isToggleColumns={false}
        isSearch={true}
        isDrawerFilter={false}
        moduleName='blog-category'
      />
  </>

  );
};
export default WithAuth(BlogSubCategory);
