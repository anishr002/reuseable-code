'use client';

import { useEffect, useState } from 'react';
import { PiXBold } from 'react-icons/pi';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { Input, Button, ActionIcon, Title, Select } from 'rizzui';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import Spinner from '@/components/ui/spinner';
import { STATUSVALUENAME } from '@/enums';
import { SubcategoryFormInput, subCategoryFormSchema } from '@/utils/validators/create-subcategory-schema';
import UploadZone, { MediaCaption, MediaPreview } from '@/components/ui/file-upload/upload-zone';
import { addSubCategory, getAllSubCategoriesList, updateSubCategoryId } from '@/redux/slices/blog-management/blogcategorySlice';
import { useParams } from 'next/navigation';

export default function CreateBlogSubCategory({ id, type = "Create", title, data }: Readonly<{ id?: string, type: string, title: string, data?: any }>) {
  const { closeModal } = useModal();
  const params = useParams();
  const [isLoading, setIsLoading] = useState(false);
  const [subCategoryFiles, setSubCategoryFiles] = useState<any[]>([]);
  const dispatch = useDispatch();
  const rolesList = useSelector((state: any) => state.rolespermissions.getallRolesData);


  useEffect(() => {
    if (type === 'Edit' || type === 'View') {
      const subcategoryFile = data?.subCategoryImage
        ? [{
          name: data?.subCategoryImage?.slice(12),
          preview: data?.subCategoryImage,
          path: data?.subCategoryImage,
          size: 2,
        }]
        : [];

      setSubCategoryFiles(subcategoryFile);
    }
  }, [type, data]);

  const onSubmit: SubmitHandler<SubcategoryFormInput> = async (data) => {
    setIsLoading(true);
    const payload = {
      ...data,
      categoryId: params?.id
    };
    const paginationData = {sortBy :'createdAt:desc'};
    try {
      if (type == 'Edit') {
        await dispatch(updateSubCategoryId({ data: payload, id })).then((res: any) => {
          if (
            (res?.payload?.status === false) ||
            (res?.payload?.status === 0)
          ) {
            toast.error(res?.payload?.message);
          } else {
            toast.success(res?.payload?.message);
            setIsLoading(false);
            closeModal();
            dispatch(getAllSubCategoriesList({ id: params?.id , paginationData}));
          }
        });
      } else {
        await dispatch(addSubCategory(payload)).then((res: any) => {
          if (
            (res?.payload?.status === false) ||
            (res?.payload?.status === 0)
          ) {
            toast.error(res?.payload?.message);
          } else {
            dispatch(getAllSubCategoriesList({ id: params?.id , paginationData}));
            toast.success(res?.payload?.message);
            setIsLoading(false);
            closeModal();
           
          }
        });
      }
    } catch (error) {
      console.log(error);
    }
  };
 
  const getDisplayValue = (selected: any, List: any[]) =>
    List.find((option: any) => option.value === selected)?.label ?? '';

  return (
    <>
      {
        rolesList?.loading ?
          <div className='h-36 bg-background shadow-xl rounded-xl dark:bg-gray-100 inset-0 flex items-center justify-center bg-opacity-50 z-50'> <Spinner /> </div> :
          (
            <Form<SubcategoryFormInput>
              onSubmit={onSubmit}
              validationSchema={subCategoryFormSchema}
              useFormProps={{
                defaultValues: {
                  name: data?.name ?? "",
                  status: data?.status ?? "",
                  subCategoryImage : data?.subCategoryImage ?? ""
                }
              }}
              className="grid grid-cols-1 gap-6 p-6 @container md:grid-cols-2 [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900"
            >
              {({ register, control, setValue, getValues, formState: { errors } }) => {
                return (
                  <>
                    <div className="col-span-full flex items-center justify-between">
                      <Title as="h4" className="font-semibold">
                        {title}
                      </Title>
                      <ActionIcon size="sm" variant="text" onClick={closeModal}>
                        <PiXBold className="h-auto w-5" />
                      </ActionIcon>
                    </div>
                    <Input
                      label="SubCategory Name"
                      placeholder="Enter subcategory name"
                      {...register('name')}
                      error={errors.name?.message}
                      disabled={type == 'View' ? true : false}
                    />
                    <Controller
                      name="status"
                      control={control}
                      render={({ field: { name, onChange, value } }) => (
                        <Select
                          options={STATUSVALUENAME}
                          value={value}
                          onChange={onChange}
                          name={name}
                          label="Status"
                          error={errors?.status?.message}
                          getOptionValue={(option) => option.value}
                          displayValue={(selected: any) => getDisplayValue(selected, STATUSVALUENAME)}
                          dropdownClassName="!z-[1]"
                          disabled={type == 'View' ? true : false}
                        />
                      )}
                    />
                    {
                      type == 'View' ?
                      <> 
                      <span className="col-span-full text-black text-sm mb-1.5 font-medium">SubCategory Image</span>
                      <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-[repeat(auto-fit,_minmax(140px,_1fr))]">
                      {subCategoryFiles?.map((file:any, index:any) => (
                        <div key={index} className="relative">
                          <figure className="group relative h-40 rounded-md bg-gray-50">
                            <MediaPreview name={file?.name} url={file?.preview} />
                          </figure>
                          <MediaCaption name={file.name} size={file.size} />
                        </div>
                      ))}
                    </div>
                    </> :
                    <UploadZone
                    name="subCategoryImage"
                    getValues={getValues}
                    setValue={setValue}
                    files={subCategoryFiles}
                    setFiles={setSubCategoryFiles}
                    type={type}
                    className="col-span-full"
                  />

                    }
                    
                    <div className="col-span-full flex items-center justify-end gap-4">
                      <Button
                        variant="outline"
                        onClick={closeModal}
                        className="w-full @xl:w-auto"
                      >
                        Cancel
                      </Button>
                      {type !== "View" && <Button
                        type="submit"
                        isLoading={isLoading}
                        className="w-full @xl:w-auto"
                      >
                        {title}
                      </Button>}
                    </div>
                  </>
                );
              }}
            </Form>
          )
      }
    </>
  );
}
