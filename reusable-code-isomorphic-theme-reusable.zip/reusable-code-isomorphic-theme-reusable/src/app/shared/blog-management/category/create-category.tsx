'use client';

import { useEffect, useState } from 'react';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { Input, Button, Select } from 'rizzui';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { useDispatch, useSelector } from 'react-redux';
import { STATUSVALUENAME } from '@/enums';
import { CategoryFormInput, categoryFormSchema } from '@/utils/validators/create-category.schema';
import { addBlogCategory, getAllBlogCategoriesList, getBlogCategoryById, updateBlogCategoryId } from '@/redux/slices/blog-management/blogcategorySlice';
import toast from 'react-hot-toast';
import UploadZone, { MediaCaption, MediaPreview } from '@/components/ui/file-upload/upload-zone';
import cn from '@/utils/class-names';
import { HorizontalFormBlockWrapper } from '@/components/horizontal-form-blockwrapper';
import { routes } from '@/config/routes';
import { useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';


export default function CreateBlogCategory({ id, type = "Create", title, data, isModalView = true,
}: Readonly<{ id?: string, type?: string, title?: string, data?: CategoryFormInput, isModalView?: boolean }>) {
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const route = useRouter();
  const singleCategoryData = useSelector((state: any) => state.blogcategory.getBlogCategoryById);

  const [isLoading, setIsLoading] = useState(false);
  const [categoryFiles, setCategoryFiles] = useState<any[]>([]);

  useEffect(() => {
    if (type == 'Edit' || type == 'View') {
      dispatch(getBlogCategoryById(id)).then((res: any) => {
        if (res?.payload?.status == 4) {
          route.push(routes.notFound);
        }
      });
    }
  }, [id, dispatch]);


  useEffect(() => {
    if (type === 'Edit' || type === 'View' && !singleCategoryData?.singleloading) {
      const thumbnailFile = singleCategoryData?.data?.categoryImage
        ? [{
          name: singleCategoryData?.data?.categoryImage?.slice(12),
          preview: singleCategoryData?.data?.categoryImage,
          path: singleCategoryData?.data?.categoryImage,
          size: 2,
        }]
        : [];

      setCategoryFiles(thumbnailFile);
    }
  }, [type, singleCategoryData]);

  const onSubmit: SubmitHandler<CategoryFormInput> = async (data) => {
    setIsLoading(true);
    try {
      const action = type === 'Edit' ? updateBlogCategoryId({ data, id }) : addBlogCategory(data);
      const res = await dispatch(action);
      const status = res?.payload?.status;
      const message = res?.payload?.message;
      if (status === false || status === 0) {
        toast.error(message);
        setIsLoading(false);
      } else {
        toast.success(message);
        if (isModalView == false) {
          closeModal();
        }
        setIsLoading(false);
        dispatch(getAllBlogCategoriesList({ sortBy: 'createdAt:desc' }));
        route.push(routes.blogManagement.categories);
      }
    } catch (error) {
      console.log(error);
    }

  };

  const handleClose = () => {
    if (isModalView) {
      route.push(routes.blogManagement.categories);
    } else {
      closeModal();
    }
  };
  return (
    singleCategoryData?.singleloading ?
      <Spinner /> :
      (<Form<CategoryFormInput>
        validationSchema={categoryFormSchema}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'onChange',
          defaultValues: {
            name: singleCategoryData?.data?.name ?? "",
            status: singleCategoryData?.data?.status ?? "",
          },
        }}
        className="isomorphic-form flex flex-grow flex-col @container"
      >
        {({ register, control, setValue, getValues, formState: { errors } }) => {
          return (
            <>
              <div className="flex-grow pb-10">
                <div
                  className={cn(
                    'grid grid-cols-1 ',
                    isModalView
                      ? 'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                      : 'gap-5'
                  )}
                >
                  <HorizontalFormBlockWrapper
                    title={type == 'Create' ? 'Add new category:' : 'Edit category:'}
                    description={`${type} your category information from here`}
                    isModalView={isModalView}
                  >
                    <Input
                      label="Category Name"
                      placeholder="category name"
                      {...register('name')}
                      error={errors.name?.message}
                      disabled={type == 'View' ? true : false}
                    />
                    <Controller
                      name="status"
                      control={control}
                      render={({ field: { name, onChange, value } }) => (
                        <Select
                          options={STATUSVALUENAME}
                          value={value}
                          onChange={onChange}
                          name={name}
                          label="Status"
                          error={errors?.status?.message}
                          getOptionValue={(option) => option.value}
                          displayValue={(selected) =>
                            STATUSVALUENAME.find((option) => option.value == selected)
                              ?.label ?? ''
                          }
                          disabled={type == 'View' ? true : false}
                        />
                      )}
                    />
                  </HorizontalFormBlockWrapper>
                  <HorizontalFormBlockWrapper
                    title="Upload new category image"
                    description="Upload your category image here"
                    isModalView={isModalView}
                  >
                    {type === 'View' ? (
                      <>
                        <span className="col-span-full text-black text-sm mb-1.5 font-medium">Category Image</span>
                        {categoryFiles.length === 0 ? (
                          <div className="mt-5 text-gray-500">-</div>
                        ) : (
                          <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-[repeat(auto-fit,_minmax(140px,_1fr))]">
                            {categoryFiles.map((file: any, index: any) => (
                              <div key={index} className="relative">
                                <figure className="group relative h-40 rounded-md bg-gray-50">
                                  <MediaPreview name={file?.name} url={file?.preview} />
                                </figure>
                                <MediaCaption name={file.name} size={file.size} />
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      <UploadZone
                        name="categoryImage"
                        getValues={getValues}
                        setValue={setValue}
                        files={categoryFiles}
                        setFiles={setCategoryFiles}
                        type={type}
                        className="col-span-full"
                      />
                    )}
                  </HorizontalFormBlockWrapper>

                </div>
              </div>

              <div
                className={cn(
                  'sticky bottom-0 z-40 flex items-center justify-end gap-3 bg-gray-0/10 backdrop-blur @lg:gap-4 @xl:grid @xl:auto-cols-max @xl:grid-flow-col',
                  isModalView ? '-mx-10 -mb-7 px-10 py-5' : 'py-1'
                )}
              >
                <Button
                  variant="outline"
                  onClick={() => handleClose()}
                  className="w-full @xl:w-auto"
                >
                  Cancel
                </Button>
                {type !== "View" &&
                  <Button
                    type="submit"
                    isLoading={isLoading}
                    className="w-full @xl:w-auto"
                  >
                    {title}
                  </Button>}
              </div>
            </>
          );
        }}
      </Form>)
  );
}
