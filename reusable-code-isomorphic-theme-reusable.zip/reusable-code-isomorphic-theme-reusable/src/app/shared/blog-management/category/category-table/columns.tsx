'use client';

import { HeaderCell } from '@/components/ui/table';
import { Checkbox, Title, Tooltip, ActionIcon } from 'rizzui';
import PencilIcon from '@/components/icons/pencil';
import DeletePopover from '@/app/shared/delete-popover';
import { getStatusBadge } from '@/utils/status-badge';
import { useModal } from '@/app/shared/modal-views/use-modal';
import CreateCategory from '../create-category';
import EyeIcon from '@/components/icons/eye';
import { BlogCategory, Columns } from 'types';
import DateCell from '@/components/ui/date-cell';
import Link from 'next/link';
import { routes } from '@/config/routes';
import Image from 'next/image';
import categoryBlog from '@public/category-blog.jpg';
import { CreateCategoryModalView } from '../category-page-header';


export const getCategoryColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  canEdit,
  canView,
  canDelete
}: Columns) => [
    canDelete && {

      title: (
        <div className="flex items-center gap-2 whitespace-nowrap ps-3">
          <Checkbox
            title={'Select All'}
            onChange={handleSelectAll}
            checked={checkedItems.length === data.length}
            className="cursor-pointer"
          />
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 10,
      render: (_: any, row: BlogCategory) => (
        <div className="inline-flex ps-3">
          <Checkbox
            className="cursor-pointer"
            checked={checkedItems.includes(row._id)}
            {...(onChecked && { onChange: () => onChecked(row._id) })}
          />
        </div>
      ),
    },
    {
      title: <HeaderCell title="Image" />,
      dataIndex: 'image',
      key: 'image',
      width: 100,
      render: (_: any, row: BlogCategory) => (
        <figure className="relative aspect-square w-12 overflow-hidden rounded-lg bg-gray-100">
          <Image
            alt={row?.name}
            src={row?.categoryImage ?? categoryBlog}
            fill
            sizes="(max-width: 768px) 100vw"
            className="object-cover"
          />
        </figure>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Category Name"
          sortable
          ascending={
            sortConfig === 'name:asc'
          }
        />
      ),
      dataIndex: 'Category Name',
      key: 'name',
      width: 150,
      onHeaderCell: () => onHeaderCellClick('name'),
      render: (_: any, row: BlogCategory) => {
        return (
          <Title as="h6" className="!text-sm font-medium">
            {row?.name}
          </Title>);
      },
    },
    {
      title: <HeaderCell title="Status"
      sortable
          ascending={
            sortConfig === 'status:asc'
          } />,
          onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'Status',
      key: 'status',
      width: 120,
      render: (_: any, row: BlogCategory) => {
        return (row ? getStatusBadge(Number(row?.status)) : '-');
      },
    },
    {
      title: (
        <HeaderCell
          title="Created At"
          sortable
          ascending={
            sortConfig  === 'createdAt:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'Created At',
      key: 'createdAt',
      width: 120,
      render: (_: any, row: any) => {
        return row ? <DateCell date={row?.createdAt} /> : '-';
      },
    },
    {
      title: <></>,
      dataIndex: 'action',
      key: 'action',
      width: 100,
      render: (_: string, row: any) => (
        <RenderAction row={row} onDeleteItem={onDeleteItem} canEdit={canEdit} canView={canView} canDelete={canDelete} />
      ),
    },
  ];

const RenderAction = ({
  row,
  onDeleteItem,
  canEdit,
  canView,
  canDelete
}: {
  row: any;
  onDeleteItem: (id: string) => void;
  canEdit?: boolean;
  canView?: boolean;
  canDelete?: boolean;
}) => {
  const { openModal } = useModal();
  return (
    <div className="flex items-center justify-start gap-3 pe-4">
      {canEdit && <Tooltip
        size="sm"
        content={'Edit Category'}
        placement="top"
        color="invert"
      >
         <Link href={routes.blogManagement.editCategory(row._id)}>
            <ActionIcon size="sm" variant="outline">
              <PencilIcon className="h-4 w-4" />
            </ActionIcon>
          </Link>
      </Tooltip>}
      {canView && <Tooltip
        size="sm"
        content={"View Category"}
        placement="top"
        color="invert"
      >
        <ActionIcon
          size="sm"
          variant="outline"
          onClick={() =>
            openModal({
              view: <CreateCategoryModalView 
                      type="View"
                      title={"View Category"}
                      id={row?._id}
                      data={row}/>,
                      customSize: '720px',
            })
          }
        >
          <EyeIcon className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>}
      {canDelete && <DeletePopover
        title={`Delete the category`}
        description={`Are you sure you want to delete this #${row?.name} category?`}
        onDelete={() => onDeleteItem(row._id)}
      />}
    </div>
  );
};
