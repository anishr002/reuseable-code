"use client";
import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import { deleteBlogCategoryById, getAllBlogCategoriesList } from '@/redux/slices/blog-management/blogcategorySlice';
import { getCategoryColumns } from './columns';
import WithAuth from '@/components/protected-router';


const BlogCategory = () => {
  const [pageSize, setPageSize] = useState(10);
  const dispatch = useDispatch();
  const categoryList = useSelector((state: any) => state.blogcategory.getBlogCategyList);

  const handleChangePage = async (paginationParams: Pagination) => {
    let { page, pageSize, sortBy, search } = paginationParams;
    try {
      const response = await dispatch(getAllBlogCategoriesList({ page, pageSize, sortBy, search }));

      if (response?.payload) {
        const { total, data } = response.payload;
        const maxPage: number = Math.ceil(total / pageSize);
        if (page > maxPage) {
          page = maxPage > 0 ? maxPage : 1;
          const adjustedResponse = await dispatch(getAllBlogCategoriesList({ page, pageSize, sortBy, search }));

          if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
            return adjustedResponse;
          }
        }
        if (data && data.length !== 0) {
          return data;
        }
      }
      return [];

    } catch (error) {
      console.error('Error fetching admin list:', error);
      return [];
    }
  };

  const handleDeleteById = async (id: string | string[]) => {
    try {
      const res = await dispatch(deleteBlogCategoryById({ id }));
      if (res.payload.status === false || res.payload.status === 0) {
        toast.error(res.payload?.message);
      } else {
        toast.success(res.payload.data?.message);
        await dispatch(getAllBlogCategoriesList({ sortBy: 'createdAt:desc' }));
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Table
        data={categoryList?.data?.data?.length > 0 ? categoryList?.data?.data : []}
        getColumns={(props: any) => getCategoryColumns({ ...props })}
        pageSize={pageSize}
        setPageSize={setPageSize}
        page={categoryList?.data?.page}
        sortBy={categoryList?.data?.sortBy}
        total={categoryList?.data?.total}
        isLoading={categoryList?.loading}
        handleChangePage={handleChangePage}
        handleDeleteById={handleDeleteById}
        isScroll={false}
        isToggleColumns={false}
        isSearch={true}
        isDrawerFilter={false}
        moduleName='blog-category'
      />
    </>

  );
};
export default WithAuth(BlogCategory);
