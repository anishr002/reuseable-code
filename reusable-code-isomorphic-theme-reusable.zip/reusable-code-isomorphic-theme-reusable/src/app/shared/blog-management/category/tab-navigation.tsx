'use client';

import React, { useState } from 'react';
import cn from '@/utils/class-names';
import PageHeader from '@/app/shared/page-header';
import CreateBlogCategory from '@/app/shared/blog-management/category/create-category';
import { routes } from '@/config/routes';
import SubCategoryPage from '@/app/(hydrogen)/blog-management/sub-category/page';

const pageHeader = {
  title: 'Edit Category',
  breadcrumb: [
    {
      href: routes.blogManagement.categories,
      name: 'Categories',
    },
    {
      name: 'Edit',
    },
  ],
}

export default function NavigationTab({ params }: any) {
  const tabs = [
    { id: 'Category' },
    { id: 'Sub Category' },

  ];
  const [active, setActive] = useState(tabs[0].id);

  function handleTabClick(id: string) {
    setActive(() => id);
  }
  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
      </PageHeader>


      <div className="mx-auto mt-10 w-full max-w-[1294px] @2xl:mt-7 @6xl:mt-0">
        <div className="-mx-4 mb-16 flex items-center justify-around border-b-2 border-b-gray-200 font-medium sm:mx-0 md:justify-start md:gap-8">
          {tabs.map((item, index) => (
            <button
              key={index}
              className={cn(
                'relative pb-4 font-semibold capitalize text-gray-500 focus:outline-none @4xl:pb-5 md:px-4',
                active === item.id && 'text-gray-1000'
              )}
              onClick={() => handleTabClick(item.id)}
            >
              <span>{item.id}</span>
              {active === item.id && (
                <span className="absolute inset-x-0 -bottom-0.5 z-10 h-0.5 bg-gray-1000"></span>
              )}
            </button>
          ))}
        </div>
        <div>
          {active === 'Category' && <CreateBlogCategory id={params.id} title='Edit Category' type={"Edit"} />}
          {active === 'Sub Category' && <SubCategoryPage />}
        </div>
      </div>
    </>
  );
}

