"use client";
import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import { getFAQsColumns } from '@/app/shared/faq-management/faq-table/columns';
import { deleteFAQById, getAllFAQsList } from '@/redux/slices/faq-management/faqManagementSlice';
import toast from 'react-hot-toast';
import { useModal } from '@/app/shared/modal-views/use-modal';
import PermissionWrapper from '../../PermissionWrapper';
import PageHeader from '../../page-header';
import ModalButton from '../../modal-button';
import AddFAQs from '../add-faqs';
import WithAuth from '@/components/protected-router';


const pageHeader = {
  title: 'FAQs Management',
};

const FAQManagement = () => {

  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const [pageSize, setPageSize] = useState(10);
  const fAQList = useSelector((state: any) => state.faqsmanagement.getFAQsList);

  const handleChangePage = async (paginationParams: Pagination) => {
    let { page, pageSize, sortBy, search} = paginationParams;
    try {
      const response = await dispatch(getAllFAQsList({ page, pageSize, sortBy, search}));

      if (response?.payload) {
        const { total, data } = response.payload;
        const maxPage: number = Math.ceil(total / pageSize);
        if (page > maxPage) {
          page = maxPage > 0 ? maxPage : 1;
          const adjustedResponse = await dispatch(getAllFAQsList({ page, pageSize, sortBy, search}));

          if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
            return adjustedResponse;
          }
        }
        if (data && data.length !== 0) {
          return data;
        }
      }
      return [];

    } catch (error) {
      console.error('Error fetching admin list:', error);
      return [];
    }
  };

  const handleDeleteById = async (id: string | string[]) => {
    try {
        const res = await dispatch(deleteFAQById({ id }));
        if (res.payload.status === false || res.payload.status === 0) {
            toast.error(res.payload.message);
        } else {
            toast.success(res.payload.message);
            closeModal();
            await dispatch(getAllFAQsList({ sortBy: 'createdAt:desc' }));
        }
    } catch (error) {
        console.error(error);
    }
};
  return (
    <>
    <PageHeader title={pageHeader.title}>
        <PermissionWrapper moduleName="faqs" action='create'>
          <ModalButton label="Add FAQ" view={<AddFAQs type='Create' title="Add FAQ" />} customSize="750px" />
        </PermissionWrapper>
      </PageHeader>
        <Table
        data={fAQList?.data && fAQList?.data?.data?.length > 0 ? fAQList?.data?.data : []}
        getColumns={(props:any) => getFAQsColumns({...props})}
        pageSize={pageSize}
        setPageSize={setPageSize}
        page={fAQList?.data?.page}
        sortBy={fAQList?.data?.sortBy}
        total={fAQList?.data?.total}
        isLoading={fAQList?.loading}
        handleChangePage={handleChangePage}
        handleDeleteById ={handleDeleteById}
        isScroll={false}
        isToggleColumns={false}
        isSearch={true}
        isDrawerFilter = {false}
        moduleName='faqs'
      />
    </>
  );
};

export default WithAuth(FAQManagement);

