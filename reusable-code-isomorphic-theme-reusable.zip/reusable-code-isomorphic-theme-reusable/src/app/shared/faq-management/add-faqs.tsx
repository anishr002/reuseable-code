'use client';

import { useState } from 'react';
import { PiXBold } from 'react-icons/pi';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { Input, Button, ActionIcon, Title } from 'rizzui';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';
import QuillEditor from '@/components/ui/quill-editor';
import { CreateFAQsInput, createFAQsSchema } from '@/utils/validators/create-faqs.schema';
import { addFAQ, getAllFAQsList, updateFAQById } from '@/redux/slices/faq-management/faqManagementSlice';
import { STATUSVALUENAME } from '@/enums';
import SelectLoader from '@/components/loader/select-loader';
import dynamic from 'next/dynamic';
const Select = dynamic(() => import('rizzui').then((mod) => mod.Select), {
    ssr: false,
    loading: () => <SelectLoader />,
  });


export default function AddFAQs({ id, type = "Create", data, title }: Readonly<{ id?: string, type: string, title: string, loading?: boolean, data?: CreateFAQsInput }>) {
    const { closeModal } = useModal();
    const [reset, setReset] = useState({});
    const [isLoading, setIsLoading] = useState(false);
    const dispatch = useDispatch();

    const onSubmit: SubmitHandler<CreateFAQsInput> = async (data) => {
        try {
            const action = type === 'Edit' ? updateFAQById({ data, id }) : addFAQ(data);
            const res = await dispatch(action);
            const status = res?.payload?.status;
            const message = res?.payload?.message;
            if (status === false || status === 0) {
                toast.error(message);
            } else {
                toast.success(message);
                closeModal();
                dispatch(getAllFAQsList({ sortBy: 'createdAt:desc' }));
            }
        } catch (error) {
            console.log(error);
        }
        setIsLoading(true);
        setTimeout(() => {
            setIsLoading(false);
            setReset({
                questionText: '',
                answer: '',
            });
            closeModal();
        }, 600);
    };

    const getDisplayValue = (selected: any, List: any[]) =>
        List.find((option: any) => option.value === selected)?.label ?? '';

    return (
        <Form<CreateFAQsInput>
            resetValues={reset}
            onSubmit={onSubmit}
            validationSchema={createFAQsSchema}
            useFormProps={{
                mode: 'onChange',
                defaultValues: {
                    questionText: data?.questionText ?? '',
                    answer: data?.answer ?? '',
                    status : data?.status ?? ""
                },
            }}
            className="grid grid-cols-1 gap-6 p-6 @container md:grid-cols-1 [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900"
        >
            {({ register, control, formState: { errors } }) => {
                return (
                    <>
                        <div className="col-span-full flex items-center justify-between">
                            <Title as="h4" className="font-semibold">
                                {title}
                            </Title>
                            <ActionIcon size="sm" variant="text" onClick={closeModal}>
                                <PiXBold className="h-auto w-5" />
                            </ActionIcon>
                        </div>
                        <Input
                            label="Question"
                            placeholder="Enter a question here"
                            {...register('questionText')}
                            error={errors?.questionText?.message}
                            disabled={type == 'View' ? true : false}
                        />
                          <Controller
                            name="status"
                            control={control}
                            render={({ field: { name, onChange, value } }) => (
                                <Select
                                    options={STATUSVALUENAME}
                                    value={value}
                                    onChange={onChange}
                                    name={name}
                                    label="Status"
                                    // className="col-span-full"
                                    error={errors?.status?.message}
                                    getOptionValue={(option:any) => option.value}
                                    displayValue={(selected: any) => getDisplayValue(selected, STATUSVALUENAME)}
                                    dropdownClassName="!z-[1]"
                                    disabled={type == 'View' ? true : false}
                                />
                            )}
                        />

                        <Controller
                            control={control}
                            name="answer"
                            render={({ field: { onChange, value } }) => (
                                <QuillEditor
                                    value={value}
                                    onChange={onChange}
                                    label="Answer"
                                    className="@3xl:col-span-2 [&>.ql-container_.ql-editor]:min-h-[100px]"
                                    labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                                    error={errors?.answer?.message}
                                    readOnly={type === 'View' ? true : false}
                                />
                            )}
                        />
                        <div className="col-span-full flex items-center justify-end gap-4">
                            <Button
                                variant="outline"
                                onClick={closeModal}
                                className="w-full @xl:w-auto"
                            >
                                Cancel
                            </Button>
                            {type !== "View" && <Button
                                type="submit"
                                isLoading={isLoading}
                                className="w-full @xl:w-auto"
                            >
                                {type === 'Edit' ? "Save" : "Add FAQ"}
                            </Button>}
                        </div>
                    </>
                );
            }}
        </Form>
    );
}
