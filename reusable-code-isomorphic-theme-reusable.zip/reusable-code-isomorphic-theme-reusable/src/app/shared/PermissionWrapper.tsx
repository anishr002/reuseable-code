'use client';
import { ReactNode } from 'react';
import { HasPermission } from '@/hooks/use-permissions';

interface PermissionWrapperProps {
  children: ReactNode;
  moduleName: string;
  action: string;
}

export default function PermissionWrapper({ children, moduleName, action }: PermissionWrapperProps) {
  const hasPermission = HasPermission(moduleName, action);
  if (!hasPermission) {
    return null ;
  }
  return <>{children}</>;
}
