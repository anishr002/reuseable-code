'use client';

import { useEffect, useState } from 'react';
import { SubmitHandler, Controller } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { Button, Password} from 'rizzui';
import HorizontalFormBlockWrapper from '@/app/shared/account-settings/horiozontal-block';
import {
  passwordFormSchema,
  PasswordFormTypes,
} from '@/utils/validators/password-settings.schema';
import { ProfileHeader } from '@/app/(hydrogen)/profile-settings/profile-header';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import { chnagePassword } from '@/redux/slices/auth/signInSlice';
import { getProfileDetails } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';

export default function PasswordSettingsView() {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const profileData = useSelector((state:any) => state.rolespermissions.profileData);

  useEffect(()=>{
   dispatch(getProfileDetails());
  },[dispatch]);

  const onSubmit: SubmitHandler<PasswordFormTypes> = async (data) => {
    console.log('password')
    setIsLoading(true);
    await dispatch(chnagePassword(data)).then((res: any) => {
      if (
        (res?.payload?.status === false) ||
        (res?.payload?.status === 0)
      ) {
        toast.error(res?.payload?.message);
        setIsLoading(false);
      } else {
        toast.success(res?.payload?.message);
        setIsLoading(false);
      }
    });
  };

  return (
      <Form<PasswordFormTypes>
        validationSchema={passwordFormSchema}
        onSubmit={onSubmit}
        className="@container"
        useFormProps={{
          mode: 'onChange',
          defaultValues: {
            old_password : "", 
            new_password : "",
            confirm_password: "",
            
          },
        }}
      >
        {({ register, control, formState: { errors }, getValues }) => {
          console.log(errors,'58');
          return (
            <>
              <ProfileHeader
                title={`${profileData?.data?.firstName} ${profileData?.data?.lastName}` }
                description={profileData?.data?.email}
                profileImage = {profileData?.data?.profileImage}
              />

              <div className="mx-auto w-full max-w-screen-2xl">
                <HorizontalFormBlockWrapper
                  title="Current Password"
                  titleClassName="text-base font-medium"
                >
                  <Password
                    {...register('old_password')}
                    placeholder="Enter your password"
                    error={errors.old_password?.message}
                  />
                </HorizontalFormBlockWrapper>

                <HorizontalFormBlockWrapper
                  title="New Password"
                  titleClassName="text-base font-medium"
                >
                  <Controller
                    control={control}
                    name="new_password"
                    render={({ field: { onChange, value } }) => (
                      <Password
                        placeholder="Enter your password"
                        helperText={
                          getValues()?.new_password?.length < 8 &&
                          'Your current password must be more than 8 characters'
                        }
                        onChange={onChange}
                        error={errors.new_password?.message}
                      />
                    )}
                  />
                </HorizontalFormBlockWrapper>

                <HorizontalFormBlockWrapper
                  title="Confirm New Password"
                  titleClassName="text-base font-medium"
                >
                  <Controller
                    control={control}
                    name="confirm_password"
                    render={({ field: { onChange, value } }) => (
                      <Password
                        placeholder="Enter your password"
                        onChange={onChange}
                        error={errors.new_password?.message}
                      />
                    )}
                  />
                </HorizontalFormBlockWrapper>

                <div className="mt-6 flex w-auto items-center justify-end gap-3">
                  <Button type="submit" variant="solid" isLoading={isLoading}>
                    Update Password
                  </Button>
                </div>
              </div>
            </>
          );
        }}
      </Form>
  );
}
