'use client';

import toast from 'react-hot-toast';
import {PiEnvelopeSimple } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import {Input } from 'rizzui';
import FormGroup from '@/app/shared/form-group';
import FormFooter from '@/components/form-footer';
import {
  personalInfoFormSchema,
  PersonalInfoFormTypes,
} from '@/utils/validators/personal-info.schema';
import AvatarUpload from '@/components/ui/file-upload/avatar-upload';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '@/components/ui/spinner';
import { getProfileDetails, updateProfile } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';

export default function PersonalInfoView() {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const profileData = useSelector((state:any) => state.rolespermissions.profileData);

  useEffect(()=>{
   dispatch(getProfileDetails());
  },[dispatch]);

  const onSubmit = async (data:any) => {
    setIsLoading(true);
    const formData = new FormData();
    formData.append('firstName', data.firstName);
    formData.append('lastName', data.lastName);
    formData.append('email', data.email);
    formData.append('role',  profileData?.data?.role?._id);
    if (data?.profileImage && typeof data?.profileImage !== 'string') {
      formData.append('profileImage', data?.profileImage);
    }
    await dispatch(updateProfile(formData)).then((res: any) => {
      if (
        (res?.payload?.status === false) ||
        (res?.payload?.status === 0)
      ) {
        toast.error(res?.payload?.message);
        setIsLoading(false);
      } else {
        toast.success(res?.payload?.message);
        dispatch(getProfileDetails());
        setIsLoading(false);
      }
    });
  };

  return (
    profileData?.singleloading ? 
    <Spinner/> :
    <Form<PersonalInfoFormTypes>
      validationSchema={personalInfoFormSchema}
      // resetValues={reset}
      onSubmit={onSubmit}
      className="@container"
      useFormProps={{
        mode: 'onChange',
        defaultValues : {
          firstName : profileData?.data?.firstName ?? '',
          lastName : profileData?.data?.lastName ?? '',
          email : profileData?.data?.email ?? '',
          profileImage :  profileData?.data?.profileImage ?? '',
          role : profileData?.data?.role?.roleName ?? '',
        },
      }}
    >
      {({ register, control, setValue, getValues, formState: { errors } }) => {
        return (
          <>
            <FormGroup
              title="Personal Info"
              description="Update your photo and personal details here"
              className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
            />

            <div className="mb-10 grid gap-7 divide-y divide-dashed divide-gray-200 @2xl:gap-9 @3xl:gap-11">
              <FormGroup
                title="Name"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  placeholder="First Name"
                  {...register('firstName')}
                  error={errors.firstName?.message}
                  className="flex-grow"
                />
                <Input
                  placeholder="Last Name"
                  {...register('lastName')}
                  error={errors.lastName?.message}
                  className="flex-grow"
                />
              </FormGroup>

              <FormGroup
                title="Email Address"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  className="col-span-full"
                  prefix={
                    <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                  }
                  type="email"
                  placeholder="georgia.young@example.com"
                  {...register('email')}
                  error={errors.email?.message}
                />
              </FormGroup>

              <FormGroup
                title="Your Photo"
                description="This will be displayed on your profile."
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <div className="flex flex-col gap-6 @container @3xl:col-span-2">
                  <AvatarUpload
                    name="profileImage"
                    setValue={setValue}
                    getValues={getValues}
                    error={errors?.profileImage?.message as string}
                  />
                </div>
              </FormGroup>

              <FormGroup
                title="Role"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                 <Input
                  placeholder="Role"
                  {...register('role')}
                   disabled = {true}
                  className="flex-grow"
                />
              </FormGroup>
            </div>

            <FormFooter
              isLoading={isLoading}
              altBtnText="Cancel"
              submitBtnText="Save"
            />
          </>
        );
      }}
    </Form>
  );
}

