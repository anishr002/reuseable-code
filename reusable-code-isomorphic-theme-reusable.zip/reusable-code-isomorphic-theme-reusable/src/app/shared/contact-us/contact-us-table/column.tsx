'use client';

import { Tooltip, ActionIcon } from 'rizzui';
import { HeaderCell } from '@/components/ui/table';
import EyeIcon from '@/components/icons/eye';
import AvatarCard from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import { useModal } from '../../modal-views/use-modal';
import { Columns } from 'types';
import ContactUsDetails from '../contact-us-details';

export const getContactUsColumns = ({
  data,
  sortConfig,
  onHeaderCellClick,
}: Columns) => [
    {
      title: <HeaderCell title="User Name" 
       sortable
      ascending={
        sortConfig === 'username:asc'
      }/>,
      onHeaderCell: () => onHeaderCellClick('username'),
      dataIndex: 'User Name',
      key: 'username',
      width: 250,
      render: (_: any, row: any) => {
        return (
          <AvatarCard
            src={row?.avatar}
            name={row?.username}
            description={row.email}
          />);
      }
    },
    {
      title: (
        <HeaderCell
          title="Mobile number"
          sortable
          ascending={
            sortConfig === 'mobileNumber:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('mobileNumber'),
      dataIndex: 'Mobile number',
      key: 'mobileNumber',
      width: 250,
      render: (_: any, row: any) => {
        return row?.mobileNumber ? row?.mobileNumber : '-';
      },
    },
    
    {
      title: <HeaderCell title="User Query" />,
      dataIndex: 'User Query',
      key: 'query',
      width: 250,
      render: (_: any, row: any) => {
        return (row ? row?.query : '-');
      },
    },
    {
        title: (
          <HeaderCell
            title="Created At"
            sortable
            ascending={
              sortConfig === 'createdAt:asc'
            }
          />
        ),
        onHeaderCell: () => onHeaderCellClick('createdAt'),
        dataIndex: 'Created At',
        key: 'createdAt',
        width: 200,
        render: (_: any, row: any) => {
          return row ? <DateCell date={row?.createdAt} /> : '-';
        },
      },
    {
      title: <></>,
      dataIndex: 'action',
      key: 'action',
      width: 140,
      render: (_: string, row: any) => (
        <RenderAction row={row}/>
      ),
    },
  ];

const RenderAction = ({
  row,
}: {
  row: any;
}) => {
  const { openModal } = useModal();
  return (
      <div className="flex items-center justify-start gap-3 pe-4">
        <Tooltip
          size="sm"
          content={"View Message"}
          placement="top"
          color="invert"
        >
          <ActionIcon
            size="sm"
            variant="outline"
            onClick={() =>
              openModal({
                view: (<ContactUsDetails data={row}/>),
                customSize: '750px',
              })
            }
          >
            <EyeIcon className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
      </div>
  );
};
