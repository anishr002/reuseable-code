"use client";

import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import { getAllContactUsList } from '@/redux/slices/cms-pages/cms-pagesSlice';
import { getContactUsColumns } from './column';
import PageHeader from '../../page-header';
import WithAuth from '@/components/protected-router';

const pageHeader = {
    title: 'Contact Us',
  };
  

 function ContactUsTable() {
    const [pageSize, setPageSize] = useState(10);
    const dispatch = useDispatch();
    const contactUsList = useSelector((state: any) => state.cmspages.getAllContactUs);


    const handleChangePage = async (paginationParams: Pagination) => {
      let { page, pageSize, sortBy, search } = paginationParams;
      try {
        const response = await dispatch(getAllContactUsList({ page, pageSize, sortBy, search}));
  
        if (response?.payload) {
          const { total, data } = response.payload;
          const maxPage: number = Math.ceil(total / pageSize);
          if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            const adjustedResponse = await dispatch(getAllContactUsList({ page, pageSize, sortBy, search}));
  
            if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
              return adjustedResponse;
            }
          }
          if (data && data.length !== 0) {
            return data;
          }
        }
        return [];
  
      } catch (error) {
        console.error('Error fetching admin list:', error);
        return [];
      }
    };

    return (
        <>
          <PageHeader title={pageHeader.title}>
          </PageHeader>
            <Table
                data={contactUsList?.data && contactUsList?.data?.data?.length > 0 ? contactUsList?.data?.data : []}
                getColumns={(props: any) => getContactUsColumns({ ...props })}
                pageSize={pageSize}
                setPageSize={setPageSize}
                page={contactUsList?.data?.page}
                sortBy={contactUsList?.data?.sortBy}
                total={contactUsList?.data?.total}
                isLoading={contactUsList?.loading}
                handleChangePage={handleChangePage}
                isScroll={false}
                isToggleColumns={false}
                isSearch={true}
                isDrawerFilter={false}
            />
        </>
    );
}

export default WithAuth(ContactUsTable);
