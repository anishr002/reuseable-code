'use client';

import React, { useEffect, useState } from 'react';
import { PiCheckBold, PiXBold } from 'react-icons/pi';
import { permissions } from '@/app/shared/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
import {
  ActionIcon,
  AdvancedCheckbox,
  Title,
  Button,
} from 'rizzui';
import { Form } from '@/components/ui/form';
import {
  RolePermissionInput,
} from '@/utils/validators/edit-role.schema';
import { useDispatch, useSelector } from 'react-redux';
import { Module } from 'types';
import { getModuleList, getSingleRoleById } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';
import Spinner from '@/components/ui/spinner';

export default function ViewRole({ id, title }: { id: string, title: string }) {
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const [selectedPermissions, setSelectedPermissions] = useState<{ [key: string]: string[] }>({});
  const [modules, setModules] = useState<Module[]>([]);
  const moduleData = useSelector((state: any) => state.rolespermissions.moduleListData);

  useEffect(() => {
    async function fetchModules() {
      try {
        dispatch(getModuleList({ role_id: "" }))
          .then((res: any) => {
            if (res?.payload?.data?.length > 0) {
              setModules(res.payload.data);
            }
          })
          .catch((error: any) => {
            console.error('Error fetching modules:', error);
          });
      } catch (error) {
        console.error('Failed to fetch modules:', error);
      }
    }

    fetchModules();

    if (id) {
      try {
        dispatch(getSingleRoleById(id))
          .then((res: any) => {
            if (res?.payload?.data) {
              const roleData = res.payload.data;
              setModules(res.payload.data.permissions);
              const permissionsMap: { [key: string]: string[] } = {};

              roleData.permissions.forEach((module: any) => {
                if (module.subModules?.length > 0) {
                  module.subModules.forEach((subModule: any) => {
                    permissionsMap[`${module._id}-${subModule._id}`] = subModule.permissions;
                  });
                } else {
                  permissionsMap[module._id] = module.permissions;
                }
              });

              setSelectedPermissions(permissionsMap);
            }
          })
          .catch((error: any) => {
            console.error('Error fetching role data:', error);
          });
      } catch (error) {
        console.error('Failed to fetch role data:', error);
      }
    }
  }, [dispatch, id]);

  const isChecked = (moduleId: string, subModuleId: string | null, permission: string) => {
    const key = subModuleId ? `${moduleId}-${subModuleId}` : moduleId;
    return (selectedPermissions[key] || []).includes(permission);
  };

  return (
    <Form<RolePermissionInput>
      onSubmit={() => { }}
      useFormProps={{
        defaultValues: {
        },
      }}
      className="grid grid-cols-1 gap-6 p-6  @container [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900"
    >
      {({ register, control, watch, formState: { errors } }) => {
        return (
          <>
            <div className="flex items-center justify-between">
              <Title as="h4" className="font-semibold">
                {title}
              </Title>
              <ActionIcon variant="text" onClick={() => closeModal()}>
                <PiXBold className="h-5 w-5" />
              </ActionIcon>
            </div>
            <div className="overflow-x-auto relative">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border p-2 text-left">Module</th>
                    <th className="border p-2 text-left">Sub-Module</th>
                    {permissions.map(({ label }) => (
                      <th key={label} className="border p-2 text-center w-1/12">
                        {label.charAt(0).toUpperCase() + label.slice(1)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    if (moduleData?.loading) {
                      return (
                        <tr>
                          <td colSpan={permissions.length + 2} className="p-6">
                            <div className="flex justify-center items-center">
                              <Spinner className="h-8 w-8" />
                            </div>
                          </td>
                        </tr>
                      );
                    }

                    if (modules?.length === 0) {
                      return (
                        <tr>
                          <td colSpan={permissions.length + 2} className="p-6 text-center text-gray-500">
                            No data available
                          </td>
                        </tr>
                      );
                    }

                    return modules?.map((module) => (
                      <React.Fragment key={module._id}>
                        {module?.subModules?.length > 0 ? (
                          module?.subModules?.map((submodule, subIndex) => (
                            <tr key={submodule._id}>
                              {subIndex === 0 && (
                                <td rowSpan={module.subModules.length} className="border p-2 font-semibold text-left">
                                  {module.title}
                                </td>
                              )}
                              <td className="border p-2 text-left text-gray-600">{submodule.title}</td>
                              {permissions.map(({ value: permissionValue }) => (
                                <td key={permissionValue} className="border p-2 text-center">
                                  <AdvancedCheckbox
                                    name={`submodule.${submodule._id}.${permissionValue?.toLowerCase()}`}
                                    value={permissionValue}
                                    inputClassName="[&:checked~span>.icon]:block"
                                    contentClassName="flex items-center justify-center"
                                    checked={isChecked(module._id, submodule._id, permissionValue)}
                                    disabled

                                  >
                                    <PiCheckBold className="icon me-1 hidden h-[14px] w-[14px] md:h-4 md:w-4" />
                                  </AdvancedCheckbox>
                                </td>
                              ))}
                            </tr>
                          ))
                        ) : (
                          <tr key={module._id}>
                            <td className="border p-2 font-semibold text-left">{module.title}</td>
                            <td className="border p-2 text-left text-gray-600">-</td>
                            {permissions.map(({ value: permissionValue }) => (
                              <td key={permissionValue} className="border p-2 text-center">
                                <AdvancedCheckbox
                                  name={`module.${module._id}.${permissionValue?.toLowerCase()}`}
                                  value={permissionValue}
                                  inputClassName="[&:checked~span>.icon]:block"
                                  contentClassName="flex items-center justify-center"
                                  checked={isChecked(module._id, null, permissionValue)}
                                  disabled
                                >
                                  <PiCheckBold className="icon me-1 hidden h-[14px] w-[14px] md:h-4 md:w-4" />
                                </AdvancedCheckbox>
                              </td>
                            ))}
                          </tr>
                        )}
                      </React.Fragment>
                    ));
                  })()}
                </tbody>
              </table>
            </div>

            <div className="col-span-full flex items-center justify-end gap-4">
              <Button
                variant="outline"
                onClick={closeModal}
                className="w-full @xl:w-auto"
              >
                Cancel
              </Button>
            </div>
          </>
        );
      }}
    </Form>
  );
}
