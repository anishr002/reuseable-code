'use client';

import RoleCard from '@/app/shared/roles-permissions/role-card';
import Spinner from '@/components/ui/spinner';
import { HasPermission } from '@/hooks/use-permissions';
import { getAllRoles } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';
import cn from '@/utils/class-names';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { PERMISSIONSDATA } from 'types';
import PageHeader from '@/app/shared/page-header';
import Link from 'next/link';
import { routes } from '@/config/routes';
import { Button } from 'rizzui';
import { PiPlusBold } from 'react-icons/pi';
import WithAuth from '@/components/protected-router';
import { RolesPermissions } from '@/enums';


interface RolesGridProps {
  className?: string;
  gridClassName?: string;
}

const pageHeader = {
  title: 'Roles and Permissions',
  breadcrumb: [
    {
      
      name: 'Roles and Permissions',
    },
    {
      name: 'Roles',
    },
  ],
};

function RolesGrid({
  className,
  gridClassName,
}: RolesGridProps) {
  const dispatch = useDispatch();
  const rolesListData = useSelector((state: any) => state.rolespermissions.getallRolesData);
  const canEdit = HasPermission('roles', PERMISSIONSDATA.Edit);
  const canDelete = HasPermission('roles', PERMISSIONSDATA.Delete);

  useEffect(() => {
    dispatch(getAllRoles({}));
  }, [dispatch]);


  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
        <Link
          href={routes.rolesPermissions.create}
          className="w-full @lg:w-auto"
        >
          <Button as="span" className="w-full @lg:w-auto">
            <PiPlusBold className="me-1.5 h-[17px] w-[17px]" />
            Create Role
          </Button>
        </Link>
      </PageHeader>

      <div className={cn('@container', className)}>
        {rolesListData?.loading ? (
          <div className="flex justify-center items-center h-screen">
            <Spinner className="h-8 w-8" />
          </div>
        ) : (
          <div
            className={cn(
              'grid grid-cols-1 gap-6 @[36.65rem]:grid-cols-2 @[56rem]:grid-cols-3 @[78.5rem]:grid-cols-4 @[100rem]:grid-cols-5',
              gridClassName
            )}
          >
            {rolesListData?.data?.data?.length > 0 &&
              [...rolesListData?.data?.data]
                .sort((a: any, b: any) => (a.roleName === RolesPermissions.SuperAdmin ? -1 : 1))
                .map((role: any) => (
                  <RoleCard key={role._id} {...role} canEdit={canEdit} canDelete={canDelete} />
                ))}
          </div>
        )}
      </div>
    </>
  );
}
export default WithAuth(RolesGrid);
