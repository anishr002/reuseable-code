'use client';

import React, { useEffect, useState } from 'react';
import { PiCheckBold, PiChecksBold, PiFilesBold } from 'react-icons/pi';
import { RgbaColorPicker } from 'react-colorful';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { ActionIcon, AdvancedCheckbox, Title, Input, Tooltip, Button, Select } from 'rizzui';
import { useCopyToClipboard } from '@/hooks/use-copy-to-clipboard';
import { CreateRoleInput, createRoleSchema } from '@/utils/validators/create-role.schema';
import Spinner from '@/components/ui/spinner';
import WidgetCard from '@/components/cards/widget-card';
import { permissions } from '@/app/shared/roles-permissions/utils';
import { addNewRole, getAllRoles, getModuleList, getSingleRoleById, updateRoleById } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Module } from 'types';
import toast from 'react-hot-toast';
import { rgbaToHex } from '@/utils/rgba-hex-color';
import { useRouter } from 'next/navigation';
import { hexToRgba } from '@/utils/hex-to-rgb';
import PageHeader from '@/app/shared/page-header';
import { routes } from '@/config/routes';
import Link from 'next/link';
import { PERMISSIONSDATA, STATUSVALUENAME } from '@/enums';

function CreateRole({ type, data, title, loading, id, pageHeader }: Readonly<{ type?: string, data?: any, title?: string, loading?: any, id?: string, pageHeader?: any }>) {
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [defaultValues, setDefaultValues] = useState({
    roleName: '',
    roleColor: { r: 0, g: 0, b: 0, a: 1 },
    status: ''
  });
  const [selectedPermissions, setSelectedPermissions] = useState<{ [key: string]: string[] }>({});
  const [copyToClipboardState, copyToClipboard] = useCopyToClipboard();
  const [modules, setModules] = useState<Module[]>([]);
  const dispatch = useDispatch();
  const moduleData = useSelector((state: any) => state.rolespermissions.moduleListData);

  const route = useRouter();

  const onSubmit: SubmitHandler<CreateRoleInput> = async (data) => {
    setIsLoading(true);
    const payload: any = {
      roleName: data.roleName,
      status: 1,
      roleColor: rgbaToHex(data?.roleColor),
      permissions: [],
    };

    const moduleNameMap: { [key: string]: string } = {};
    const subModuleNameMap: { [key: string]: string } = {};

    modules.forEach(module => {
      moduleNameMap[module._id] = module.name;
      module.subModules.forEach(subModule => {
        subModuleNameMap[subModule._id] = subModule.name;
      });
    });

    const moduleMap: { [key: string]: any } = {};

    Object.keys(selectedPermissions).forEach((key) => {
      const [moduleId, subModuleId] = key.split('-');
      const permissionsForModule = selectedPermissions[key];

      if (!moduleMap[moduleId]) {
        moduleMap[moduleId] = {
          module: moduleNameMap[moduleId],
          permissions: subModuleId ? [] : permissionsForModule,
          subModules: [],
        };
      }

      if (subModuleId) {
        moduleMap[moduleId].subModules.push({
          name: subModuleNameMap[subModuleId],
          permissions: permissionsForModule,
        });
      }
    });

    payload.permissions = Object.values(moduleMap);

    try {
      if (type === 'Edit') {
        await dispatch(updateRoleById({ data: payload, id })).then((res: any) => {
          if (res?.payload?.status === false || res?.payload?.status === 0) {
            toast.error(res?.payload?.message);
            setIsLoading(false);
          } else {
            toast.success(res?.payload?.message);
            setIsLoading(false);
            dispatch(getAllRoles({ sortBy: 'createdAt:desc' }));
            route.push(routes.rolesPermissions.rolesPermissions);
          }
        });
      } else {
        await dispatch(addNewRole(payload)).then((res: any) => {
          if (res?.payload?.status === false || res?.payload?.status === 0) {
            toast.error(res?.payload?.message);
            setIsLoading(false);
          } else {
            toast.success(res?.payload?.message);
            setIsLoading(false);
            dispatch(getAllRoles({ sortBy: 'createdAt:desc' }));
            route.push(routes.rolesPermissions.rolesPermissions);
          }
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    const fetchModules = async () => {
        try {
            const res = await dispatch(getModuleList({ role_id: "" }));
            if (res?.payload?.data?.length > 0) {
                setModules(res.payload.data);
            }
        } catch (error) {
            console.error('Error fetching modules:', error);
        }
    };

    const fetchRoleData = async () => {
        if (id) {
            try {
                const res = await dispatch(getSingleRoleById(id));
                if (res?.payload?.data) {
                    const roleData = res.payload.data;

                    setDefaultValues({
                        roleName: roleData?.roleName,
                        roleColor: hexToRgba(roleData?.roleColor ?? '#000000ff'),
                        status: roleData?.status ?? ""
                    });

                    const permissionsMap: { [key: string]: string[] } = {};
                    roleData.permissions.forEach((module: any) => {
                        if (module.subModules?.length > 0) {
                            module.subModules.forEach((subModule: any) => {
                                permissionsMap[`${module._id}-${subModule._id}`] = subModule.permissions;
                            });
                        } else {
                            permissionsMap[module._id] = module.permissions;
                        }
                    }); 

                    setSelectedPermissions(permissionsMap);
                }
            } catch (error) {
                console.error('Error fetching role data:', error);
            }
        }
    };

    fetchModules();
    fetchRoleData();
}, [dispatch, id]);


  

  const handleCopyToClipboard = (rgba: string) => {
    copyToClipboard(rgba);
    setIsCopied(true);
    setTimeout(() => {
      setIsCopied(false);
    }, 3000);
  };

  const handlePermissionChange = (moduleId: string, subModuleId: string | null, permission: string) => {
    setSelectedPermissions((prevSelected) => {
      const key = subModuleId ? `${moduleId}-${subModuleId}` : moduleId;
      const currentPermissions = prevSelected[key] || [];

      let updatedPermissions: any;
      if (permission === 'view') {
        // If "view" is unchecked, remove all permissions
        if (currentPermissions.includes('view')) {
          updatedPermissions = [];
        } else {
          // If "view" is checked, keep all other permissions intact and add "view"
          updatedPermissions = [...currentPermissions, 'view'];
        }
      } else {
        // For "create", "edit", and "delete" permissions
        if (currentPermissions.includes(permission)) {
          // Remove the permission if it's already selected
          updatedPermissions = currentPermissions.filter((perm) => perm !== permission);
        } else {
          // Add the permission if it's not selected
          updatedPermissions = [...currentPermissions, permission];

          // Ensure "view" is also checked when any other permission is selected
          if (!currentPermissions.includes('view')) {
            updatedPermissions.push('view');
          }
        }
      }

      const newSelectedPermissions = {
        ...prevSelected,
        [key]: updatedPermissions,
      };

      return newSelectedPermissions;
    });
  };



  const isChecked = (moduleId: string, subModuleId: string | null, permission: string) => {
    const key = subModuleId ? `${moduleId}-${subModuleId}` : moduleId;
    return (selectedPermissions[key] || []).includes(permission);
  };

  const getDisplayValue = (selected: any, List: any[]) =>
    List.find((option: any) => option.value === selected)?.label ?? '';

  return (
    <>

      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
        <Link
          href={routes.rolesPermissions.rolesPermissions}
          className="mt-4 w-full @lg:mt-0 @lg:w-auto"
        >
          <Button as="span" className="w-full @lg:w-auto" variant="outline">
            Cancel
          </Button>
        </Link>
      </PageHeader>
      <div className='flex flex-col lg:flex-row gap-7'>
        <div className='w-full'>
          <WidgetCard
            rounded="lg"
            className="col-span-full px-4"
            title=""
          >
            {!defaultValues?.roleName && type == 'Edit' ? (
              <Spinner />
            ) : <Form<CreateRoleInput>
              onSubmit={onSubmit}
              validationSchema={createRoleSchema}
              useFormProps={{
                defaultValues: {
                  roleName: defaultValues?.roleName,
                  roleColor: defaultValues?.roleColor,
                  status: defaultValues?.status ?? ""
                }
              }}
              className="flex flex-grow flex-col gap-6 p-2 @container [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900"
            >
              {({ register, control, watch, formState: { errors, defaultValues } }) => {
                const getColor = watch('roleColor');
                const colorCode = `rgba(${getColor?.r ?? 0}, ${getColor?.g ?? 0}, ${getColor?.b ?? 0}, ${getColor?.a ?? 0})`;

                return (
                  <>
                    <div className="flex items-center justify-between">
                      <Title as="h4" className="font-semibold">
                        {title}
                      </Title>
                    </div>

                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between">
                        <div className="w-1/2 pr-2">
                          <Input
                            label="Role Name"
                            placeholder="Role name"
                            {...register('roleName')}
                            error={errors.roleName?.message}
                          />
                        </div>
                        <div className="w-1/2 pl-2">
                          <Controller
                            name="status"
                            control={control}
                            render={({ field: { name, onChange, value } }) => (
                              <Select
                                options={STATUSVALUENAME}
                                value={value}
                                onChange={onChange}
                                name={name}
                                label="Status"
                                error={errors?.status?.message}
                                getOptionValue={(option) => option.value}
                                displayValue={(selected: any) => getDisplayValue(selected, STATUSVALUENAME)}
                                dropdownClassName="!z-[1]"
                                disabled={type === 'View'}
                              />
                            )}
                          />
                        </div>
                      </div>
                      <div className="w-1/2">
                        <Input
                          label="Role Color"
                          placeholder="Role Color"
                          readOnly
                          inputClassName="hover:border-muted"
                          suffix={
                            <Tooltip
                              size="sm"
                              content={isCopied ? 'Copied to Clipboard' : 'Click to Copy'}
                              placement="top"
                              className="z-[1000]"
                            >
                              <ActionIcon
                                variant="text"
                                title="Click to Copy"
                                onClick={() => handleCopyToClipboard(colorCode)}
                                className="-mr-3"
                              >
                                {isCopied ? (
                                  <PiChecksBold className="h-[18px] w-[18px]" />
                                ) : (
                                  <PiFilesBold className="h-4 w-4" />
                                )}
                              </ActionIcon>
                            </Tooltip>
                          }
                          value={colorCode}
                        />
                        <Controller
                          control={control}
                          name="roleColor"
                          render={({ field: { onChange, value } }) => (
                            <RgbaColorPicker color={value} onChange={onChange} className='mt-2' />
                          )}
                        />
                      </div>
                    </div>
                    <div className="overflow-x-auto relative">
                      <table className="min-w-full border-collapse">
                        <thead>
                          <tr className="bg-gray-100">
                            <th className="border p-2 text-left">Module</th>
                            <th className="border p-2 text-left">Sub-Module</th>
                            {permissions.map(({ label }) => (
                              <th key={label} className="border p-2 text-center w-1/12">
                                {label.charAt(0).toUpperCase() + label.slice(1)}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {(() => {
                            if (moduleData?.loading) {
                              return (
                                <tr>
                                  <td colSpan={permissions.length + 2} className="p-6">
                                    <div className="flex justify-center items-center">
                                      <Spinner className="h-8 w-8" />
                                    </div>
                                  </td>
                                </tr>
                              );
                            }

                            if (modules?.length === 0) {
                              return (
                                <tr>
                                  <td colSpan={permissions.length + 2} className="p-6 text-center text-gray-500">
                                    No data available
                                  </td>
                                </tr>
                              );
                            }

                            return modules?.map((module: any) => (
                              <React.Fragment key={module._id}>
                                {module?.subModules?.length > 0 ? (
                                  module?.subModules?.map((submodule: any, subIndex: any) => (
                                    <tr key={submodule._id}>
                                      {subIndex === 0 && (
                                        <td
                                          rowSpan={module.subModules.length}
                                          className="border p-2 font-semibold text-left"
                                        >
                                          {module.title}
                                        </td>
                                      )}
                                      <td className="border p-2 text-left text-gray-600">{submodule.title}</td>
                                      {PERMISSIONSDATA.map((permissionValue: any) => (
                                        <td key={permissionValue} className="border p-2 text-center">
                                          {submodule.permissions.includes(permissionValue) ? (
                                            <AdvancedCheckbox
                                              name={`submodule.${submodule._id}.${permissionValue.toLowerCase()}`}
                                              value={permissionValue}
                                              inputClassName="[&:checked~span>.icon]:block"
                                              contentClassName="flex items-center justify-center"
                                              onChange={() =>
                                                handlePermissionChange(module._id, submodule._id, permissionValue)
                                              }
                                              checked={isChecked(module._id, submodule._id, permissionValue)}
                                            >
                                              <PiCheckBold className="icon me-1 hidden h-[14px] w-[14px] md:h-4 md:w-4" />
                                            </AdvancedCheckbox>
                                          ) : (
                                            <span>-</span>
                                          )}
                                        </td>
                                      ))}
                                    </tr>
                                  ))
                                ) : (
                                  <tr key={module._id}>
                                    <td className="border p-2 font-semibold text-left">{module?.title}</td>
                                    <td className="border p-2 text-left text-gray-600">-</td>
                                    {PERMISSIONSDATA.map((permissionValue: any) => (
                                      <td key={permissionValue} className="border p-2 text-center">
                                        {module.permissions.includes(permissionValue) ? (
                                          <AdvancedCheckbox
                                            name={`module.${module._id}.${permissionValue.toLowerCase()}`}
                                            value={permissionValue}
                                            inputClassName="[&:checked~span>.icon]:block"
                                            contentClassName="flex items-center justify-center"
                                            onChange={() => handlePermissionChange(module._id, null, permissionValue)}
                                            checked={isChecked(module._id, null, permissionValue)}
                                          >
                                            <PiCheckBold className="icon me-1 hidden h-[14px] w-[14px] md:h-4 md:w-4" />
                                          </AdvancedCheckbox>
                                        ) : (
                                          <span>-</span>
                                        )}
                                      </td>
                                    ))}
                                  </tr>
                                )}
                              </React.Fragment>
                            ));
                          })()}
                        </tbody>
                      </table>
                    </div>
                    <div className="flex items-center justify-end gap-4">
                      <Button
                        variant="outline"
                        onClick={() => route.push(routes.rolesPermissions.rolesPermissions)}
                        className="w-full @xl:w-auto"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        isLoading={isLoading}
                        className="w-full @xl:w-auto"
                      >
                        {type == 'Edit' ? "Edit Role" : "Create Role"}
                      </Button>
                    </div>
                  </>
                );
              }}
            </Form>}
          </WidgetCard>
        </div>
      </div>
    </>

  );
}
export default CreateRole;
