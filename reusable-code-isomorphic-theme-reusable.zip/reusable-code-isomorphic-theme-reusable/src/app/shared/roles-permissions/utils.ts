import { ROLES } from '@/config/constants';
import { PERMISSIONSDATA, STATUSES } from 'types';

export const statuses = Object.values(STATUSES).map((status) => ({
  label: status,
  value: status,
}));

export const permissions = Object.values(PERMISSIONSDATA).map((permission) => ({
  label:  permission,
  value: permission,
}));

export const roles = Object.entries(ROLES).map(([key, value]) => ({
  label: value,
  value: key,
}));
