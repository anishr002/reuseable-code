'use client';

import { useCallback, useMemo } from 'react';
import dynamic from 'next/dynamic';
import { useTable } from '@/hooks/use-table';
import { useColumn } from '@/hooks/use-column';
import ControlledTable from '@/components/controlled-table';
import { Pagination, PERMISSIONSDATA } from 'types';
import { HasPermission } from '@/hooks/use-permissions';

const TableFooter = dynamic(() => import('@/app/shared/table-footer'), {
  ssr: false,
});

const defaultDeleteFunction = (id: string | string[]) => { };
const emptyHandleChangePage = async (paginationParams?: Pagination) => {
  return Promise.resolve();
};

export default function Table({
  data = [],
  getColumns,
  initialFilterState = {},
  pageSize = 10,
  setPageSize,
  page,
  total,
  handleDeleteById = defaultDeleteFunction,
  handleChangePage = emptyHandleChangePage,
  isLoading,
  isToggleColumns,
  isSearch,
  isScroll,
  isDrawerFilter,
  FilterElement,
  moduleName
}: Readonly<{
  data: any[];
  handleDeleteById?: (id: string | string[], paginationParams?: Pagination) => any;
  handleChangePage?: (paginationParams: Pagination) => Promise<any>;
  getColumns: any;
  initialFilterState?: Record<string, any>;
  pageSize?: number;
  setPageSize?: any;
  sortOrder?: any;
  sortBy?: any;
  page?: any;
  total?: any;
  isLoading?: boolean,
  isToggleColumns?: any,
  isSearch?: any,
  isScroll?: any,
  isDrawerFilter?: boolean,
  FilterElement?: any,
  moduleName?: string
}>) {
  const canEdit = HasPermission(moduleName, PERMISSIONSDATA.Edit);
  const canDelete = HasPermission(moduleName, PERMISSIONSDATA.Delete);
  const canCreate = HasPermission(moduleName, PERMISSIONSDATA.Create);
  const canView = HasPermission(moduleName, PERMISSIONSDATA.View);

  const onHeaderCellClick = (value: string) => ({
    onClick: () => {
      handleSort(value);
    },
  });

  const onDeleteItem = useCallback((id: string) => {
    handleDelete(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const {
    isFiltered,
    tableData,
    currentPage,
    handlePaginate,
    filters,
    updateFilter,
    searchTerm,
    handleSearch,
    sortConfig,
    handleSort,
    selectedRowKeys,
    setSelectedRowKeys,
    handleRowSelect,
    handleSelectAll,
    handleDelete,
    handleReset,
  } = useTable(data, pageSize, handleDeleteById, page, pageSize, handleChangePage, initialFilterState);

  const columns = useMemo(
    () =>
      getColumns({
        data,
        sortConfig,
        checkedItems: selectedRowKeys,
        onHeaderCellClick,
        onDeleteItem,
        onChecked: handleRowSelect,
        handleSelectAll,
        canCreate,
        canEdit,
        canView,
        canDelete
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      selectedRowKeys,
      onHeaderCellClick,
      sortConfig,
      onDeleteItem,
      handleRowSelect,
      handleSelectAll,
      canCreate,
      canEdit,
      canView,
      canDelete
    ]
  );


  const { visibleColumns, checkedColumns, setCheckedColumns } =
    useColumn(columns);

  const pagination = pageSize > 0 && {
    pageSize,
    setPageSize,
    total: Number(total) ? Number(total) : 0,
    current: currentPage,
    onChange: (page: number) => handlePaginate(page),
  };

  return (
    <div className="mt-2">
      <ControlledTable
        variant="modern"
        data={tableData}
        isLoading={isLoading}
        showLoadingText={true}
        // @ts-ignore
        columns={visibleColumns}
        paginatorOptions={pagination}
        filterOptions={{
          searchTerm,
          onSearchClear: () => {
            handleSearch('');
          },
          onSearchChange: (event) => {
            handleSearch(event.target.value);
          },
          hasSearched: isFiltered,
          columns,
          checkedColumns,
          setCheckedColumns,
          enableDrawerFilter: true,
        }}
        filterElement={
          isDrawerFilter && <FilterElement
            filters={filters}
            isFiltered={isFiltered}
            updateFilter={updateFilter}
            handleReset={handleReset}
          />}
        tableFooter={
          <TableFooter
            checkedItems={selectedRowKeys}
            handleDelete={(ids: string[]) => {
              setSelectedRowKeys([]);
              handleDelete(ids);
            }}
          />
        }
        className="rounded-md border border-muted text-sm shadow-sm [&_.rc-table-placeholder_.rc-table-expanded-row-fixed>div]:h-60 [&_.rc-table-placeholder_.rc-table-expanded-row-fixed>div]:justify-center [&_.rc-table-row:last-child_td.rc-table-cell]:border-b-0 [&_thead.rc-table-thead]:border-t-0"
      />
    </div>
  );
}
