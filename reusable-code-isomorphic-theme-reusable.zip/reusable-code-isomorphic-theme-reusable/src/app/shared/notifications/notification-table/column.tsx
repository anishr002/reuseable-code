'use client';

import { HeaderCell } from '@/components/ui/table';
import DateCell from '@/components/ui/date-cell';
import { Columns } from 'types';

export const getNotificationsColumns = ({
  data,
  sortConfig,
  onHeaderCellClick,
}: Columns) => [
    {
      title: (
        <HeaderCell
          title="Message"
          sortable
          ascending={
            sortConfig === 'message:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('message'),
      dataIndex: 'Message',
      key: 'message',
      width: 300,
      render: (_: any, row: any) => {
        return row?.message ? row?.message : '-';
      },
    },

    {
      title: (
        <HeaderCell
          title="Created At"
          sortable
          ascending={
            sortConfig === 'createdAt:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'Created At',
      key: 'createdAt',
      width: 100,
      render: (_: any, row: any) => {
        return row ? <DateCell date={row?.createdAt} /> : '-';
      },
    },
  ];

