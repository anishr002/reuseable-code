"use client";

import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import { getNotificationsColumns } from './column';
import PageHeader from '../../page-header';
import WithAuth from '@/components/protected-router';
import { getAllNotificationsList } from '@/redux/slices/notification/notificationsSlice';

const initialFilterState = {
    filterBy: '',
    filterByStatus: ''
};

const pageHeader = {
    title: 'Notification List',
  };
  

 const NotificationTable = () => {
    const [pageSize, setPageSize] = useState(10);
    const dispatch = useDispatch();
    const notificationList = useSelector((state: any) => state.notification.notificationList);


    const handleChangePage = async (paginationParams: Pagination) => {
      let { page, pageSize, sortBy, search } = paginationParams;
      try {
        const response = await dispatch(getAllNotificationsList({ page, pageSize, sortBy, search}));
  
        if (response?.payload) {
          const { total, data } = response.payload;
          const maxPage: number = Math.ceil(total / pageSize);
          if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            const adjustedResponse = await dispatch(getAllNotificationsList({ page, pageSize, sortBy, search}));
  
            if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
              return adjustedResponse;
            }
          }
          if (data && data.length !== 0) {
            return data;
          }
        }
        return [];
  
      } catch (error) {
        console.error('Error fetching admin list:', error);
        return [];
      }
    };

    return (
        <>
          <PageHeader title={pageHeader.title}>
          </PageHeader>
            <Table
                data={notificationList?.data && notificationList?.data?.data?.length > 0 ? notificationList?.data?.data : []}
                getColumns={(props: any) => getNotificationsColumns({ ...props })}
                pageSize={pageSize}
                setPageSize={setPageSize}
                page={notificationList?.data?.page}
                sortBy={notificationList?.data?.sortBy}
                total={notificationList?.data?.total}
                isLoading={notificationList?.loading}
                initialFilterState={initialFilterState}
                handleChangePage={handleChangePage}
                isScroll={false}
                isToggleColumns={false}
                isSearch={true}
                isDrawerFilter={false}
            />
        </>
    );
}

export default WithAuth(NotificationTable);
