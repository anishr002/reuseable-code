'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { SubmitHandler, Controller } from 'react-hook-form';
import QuillLoader from '@/components/loader/quill-loader';
import { Button, Input, Text } from 'rizzui';
import cn from '@/utils/class-names';
import { Form } from '@/components/ui/form';
import { HorizontalFormBlockWrapper } from '@/components/horizontal-form-blockwrapper';
import { useDispatch, useSelector } from 'react-redux';
import { getCmsBySlug, updateCmsById } from '@/redux/slices/cms-pages/cms-pagesSlice';
import Spinner from '@/components/ui/spinner';
import toast from 'react-hot-toast';
import { CMSFormInput, cmsFormSchema } from '@/utils/validators/cms-pages.schema';
import { CMSSLUG } from '@/enums';
import { useRouter } from 'next/navigation';
import { routes } from '@/config/routes';
import PageHeader from '../page-header';
import WithAuth from '@/components/protected-router';
import { HtmlFormatDetails } from '@/components/ui/html-format';
import { HasPermission } from '@/hooks/use-permissions';
import { PERMISSIONSDATA } from 'types';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[168px]" />,
});

const pageHeader = {
  title: 'Terms and Conditions',
  breadcrumb: [
    {
      name: 'CMS Pages',
    },
    {
      name: 'Terms and Conditions',
    },
  ],
};

function AddUpdateTermsConditions() {
  const dispatch = useDispatch();
  const route = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const termsAndConditionsData = useSelector((state: any) => state.cmspages.getCmsBySlug);
  const canEdit = HasPermission("cms", PERMISSIONSDATA.Edit);
  const canCreate = HasPermission("cms", PERMISSIONSDATA.Create);

  useEffect(() => {
    dispatch(getCmsBySlug(CMSSLUG.TERMCONDITIONS));
  }, [dispatch]);

  const onSubmit: SubmitHandler<CMSFormInput> = async (data) => {
    setIsLoading(true);
    await dispatch(updateCmsById({ data, slug: CMSSLUG.TERMCONDITIONS })).then((res: any) => {
      if (
        (res?.payload?.status === false) ||
        (res?.payload?.status === 0)
      ) {
        toast.error(res?.payload?.message);
        setIsLoading(false);
      } else {
        toast.success(res?.payload?.message);
        setIsLoading(false);
        dispatch(getCmsBySlug(CMSSLUG.TERMCONDITIONS));
      }
    });
  };

  console.log(termsAndConditionsData?.data?.content, 'termsAndConditionsData?.data?.content')
  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
      </PageHeader>
      {termsAndConditionsData?.loading ?
        <Spinner /> :
        (<Form<CMSFormInput>
          validationSchema={cmsFormSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'onChange',
            defaultValues: {
              title: termsAndConditionsData?.data?.title,
              content: termsAndConditionsData?.data?.content ?? ""
            },
          }}
          className="isomorphic-form flex flex-grow flex-col @container"
        >
          {({ register, control, formState: { errors } }) => (
            <>
              <div className="flex-grow pb-10">
                <div
                  className={cn(
                    'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                  )}
                >
                  <HorizontalFormBlockWrapper
                    title={'Add terms and conditions'}
                    description={'Terms and conditions of use'}

                  >
                    <Input
                      label="Title"
                      placeholder="title"
                      className='col-span-full'
                      {...register('title')}
                      error={errors.title?.message}
                      disabled={!canEdit || !canEdit}
                    />

                    <div className="col-span-2">
                      {canEdit || canCreate ? (
                        <Controller
                          control={control}
                          name="content"
                          render={({ field: { onChange, value } }) => (
                            <QuillEditor
                              value={value}
                              onChange={onChange}
                              label="Content"
                              className="[&>.ql-container_.ql-editor]:min-h-[200px]"
                              labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                              error={errors.content?.message}
                            />
                          )}
                        />
                      ) : (
                        <div>
                          <Text className="text-sm mb-1.5 font-medium text-muted-foreground">
                            Content:
                          </Text>
                          {/* Check if content is available */}
                          {termsAndConditionsData?.data?.content ? (
                            <HtmlFormatDetails description={termsAndConditionsData?.data?.content} />
                          ) : (
                            <div className="text-sm text-gray-500">No content available</div>
                          )}
                        </div>
                      )}
                    </div>

                  </HorizontalFormBlockWrapper>

                </div>
              </div>

              <div
                className={cn(
                  'sticky bottom-0 z-40 flex items-center justify-end gap-3 bg-gray-0/10 backdrop-blur @lg:gap-4 @xl:grid @xl:auto-cols-max @xl:grid-flow-col -mx-10 -mb-7 px-10 py-5'
                )}
              >
                <Button variant="outline" className="w-full @xl:w-auto" onClick={() => route.push(routes.jobBoard.dashboard)}>
                  Cancel
                </Button>
                {canEdit || canCreate ? <Button
                  type="submit"
                  isLoading={isLoading}
                  className="w-full @xl:w-auto"
                >
                  Save
                </Button> : null}
              </div>
            </>
          )}
        </Form>)}
    </>
  );
}
export default WithAuth(AddUpdateTermsConditions);
