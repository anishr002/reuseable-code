'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { SubmitHandler, Controller } from 'react-hook-form';
import QuillLoader from '@/components/loader/quill-loader';
import { Button, Input, Text } from 'rizzui';
import cn from '@/utils/class-names';
import { Form } from '@/components/ui/form';
import { HorizontalFormBlockWrapper } from '@/components/horizontal-form-blockwrapper';
import { CMSSLUG } from '@/enums';
import { useDispatch, useSelector } from 'react-redux';
import { getCmsBySlug, updateCmsById } from '@/redux/slices/cms-pages/cms-pagesSlice';
import { CMSFormInput, cmsFormSchema } from '@/utils/validators/cms-pages.schema';
import toast from 'react-hot-toast';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { useRouter } from 'next/navigation';
import PageHeader from '../page-header';
import WithAuth from '@/components/protected-router';
import { HasPermission } from '@/hooks/use-permissions';
import { PERMISSIONSDATA } from 'types';
import { HtmlFormatDetails } from '@/components/ui/html-format';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[168px]" />,
});

const pageHeader = {
  title: 'Privacy Policy',
  breadcrumb: [
    {
      name: 'CMS Pages',
    },
    {
      name: 'Privacy Policy',
    },
  ],
};


function AddUpdatePrivacyPolicy() {
  const dispatch = useDispatch();
  const route = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const privacyPolicyData = useSelector((state: any) => state.cmspages.getCmsBySlug);
  const canEdit = HasPermission("cms", PERMISSIONSDATA.Edit);
  const canCreate = HasPermission("cms", PERMISSIONSDATA.Create);

  useEffect(() => {
    dispatch(getCmsBySlug(CMSSLUG.PRIVACYPOLICY));
  }, [dispatch]);

  const onSubmit: SubmitHandler<CMSFormInput> = async (data) => {
    setIsLoading(true);
    await dispatch(updateCmsById({ data, slug: CMSSLUG.PRIVACYPOLICY })).then((res: any) => {
      if (
        (res?.payload?.status === false) ||
        (res?.payload?.status === 0)
      ) {
        toast.error(res?.payload?.message);
        setIsLoading(false);
      } else {
        toast.success(res?.payload?.message);
        setIsLoading(false);
        dispatch(getCmsBySlug(CMSSLUG.PRIVACYPOLICY));
      }
    });
  };

  return (
    <>
      <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
      </PageHeader>
      {
        privacyPolicyData?.loading ?
          <Spinner /> :
          (<Form<CMSFormInput>
            validationSchema={cmsFormSchema}
            onSubmit={onSubmit}
            useFormProps={{
              mode: 'onChange',
              defaultValues: {
                title: privacyPolicyData?.data?.title,
                content: privacyPolicyData?.data?.content
              },
            }}
            className="isomorphic-form flex flex-grow flex-col @container"
          >
            {({ register, control, formState: { errors } }) => (
              <>
                <div className="flex-grow pb-10">
                  <div
                    className={cn(
                      'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                    )}
                  >
                    <HorizontalFormBlockWrapper
                      title={'Add Privacy Policies'}
                      description={'Privacy Policies of use'}

                    >
                      <Input
                        label="Title"
                        placeholder="title"
                        className='col-span-full'
                        {...register('title')}
                        disabled={!canEdit || !canEdit}
                        error={errors.title?.message}
                      />
                      <div className="col-span-2">
                          <Controller
                            control={control}
                            name="content"
                            render={({ field: { onChange, value } }) => (
                              <QuillEditor
                                value={value}
                                onChange={onChange}
                                label="Content"
                                className="[&>.ql-container_.ql-editor]:min-h-[200px]"
                                labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                                error={errors.content?.message}
                              />
                            )}
                          />
                      </div>
                    </HorizontalFormBlockWrapper>

                  </div>
                </div>

                <div
                  className={cn(
                    'sticky bottom-0 z-40 flex items-center justify-end gap-3 bg-gray-0/10 backdrop-blur @lg:gap-4 @xl:grid @xl:auto-cols-max @xl:grid-flow-col -mx-10 -mb-7 px-10 py-5'
                  )}
                >
                  <Button variant="outline" className="w-full @xl:w-auto" onClick={() => route.push(routes.jobBoard.dashboard)}>
                    Cancel
                  </Button>
                  {canEdit || canCreate ? <Button
                    type="submit"
                    isLoading={isLoading}
                    className="w-full @xl:w-auto"
                  >
                    Save
                  </Button> : null}
                </div>
              </>
            )}
          </Form>)
      }
    </>

  );
}

export default WithAuth(AddUpdatePrivacyPolicy);
