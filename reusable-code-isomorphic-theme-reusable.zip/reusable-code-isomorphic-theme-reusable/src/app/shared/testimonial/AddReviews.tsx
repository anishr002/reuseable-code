'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { Controller } from 'react-hook-form';
import SelectLoader from '@/components/loader/select-loader';
import QuillLoader from '@/components/loader/quill-loader';
import { Button, Input } from 'rizzui';
import cn from '@/utils/class-names';
import { Form } from '@/components/ui/form';
import UploadZone from '@/components/ui/file-upload/upload-zone';
import { CreateReviewsInput, reviewsSchema } from '@/utils/validators/create-review.schema';
import { STATUSVALUENAME } from '@/enums';
import toast from 'react-hot-toast';
import { useModal } from '../modal-views/use-modal';
import { useDispatch } from 'react-redux';
import { HorizontalFormBlockWrapper } from '@/components/horizontal-form-blockwrapper';
import { addReview, getAllReviewList, updateReviewbyId } from '@/redux/slices/testimonial/reviewsSlice';
const Select = dynamic(() => import('rizzui').then((mod) => mod.Select), {
  ssr: false,
  loading: () => <SelectLoader />,
});
const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[168px]" />,
});

export default function AddReviews({
  id,
  type,
  title,
  isModalView = true,
  data
}: Readonly<{
  id?: string;
  title: string;
  type: string;
  isModalView?: boolean;
  data?: CreateReviewsInput;
}>) {
  const dispatch = useDispatch();
  const {closeModal} = useModal();
  const [isLoading, setIsLoading] = useState(false);
  const [testimonialFiles,setTestimonialFiles] = useState<any[]>([]);


  useEffect(()=>{
    if (type === 'Edit') {    
      const headerFile = data?.testimonialImage
        ? [{
            name: data?.testimonialImage?.slice(12),
            preview: data?.testimonialImage,
            path: data?.testimonialImage,
            size: 4,
          }]
        : [];
  
      setTestimonialFiles(headerFile);
    }
  },[data,type]);

  const onSubmit = async (data:any) => {
    setIsLoading(true);
    const formData = new FormData();
    formData.append('userName', data.userName);
    formData.append('message', data.message);
    formData.append('status', data.status); 
  const file = data?.testimonialImage;

  if (file instanceof File) {
    formData.append('testimonialImage', file);
  }


    try {
        const action = type === 'Edit' ? updateReviewbyId({ data:formData, id }) : addReview(formData);
        const res = await dispatch(action);
        const status = res?.payload?.status;
        const message = res?.payload?.message;
        if (status === false || status === 0) {
            toast.error(message);
            setIsLoading(false);
        } else {
            toast.success(message);
            closeModal();
            setIsLoading(false);
            dispatch(getAllReviewList({ sortBy: 'createdAt:desc' }));
        }
    } catch (error) {
        console.log(error);
        setIsLoading(false);
    }
};

const getDisplayValue = (selected: any, STATUSVALUENAME: any[]) =>
  STATUSVALUENAME.find((option: any) => option.value === selected)?.label ?? '';

  return (
    <div className="m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">
      <Form<CreateReviewsInput>
        validationSchema={reviewsSchema}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'onChange',
          defaultValues: {
            userName : data?.userName ?? "",
            message : data?.message ?? "",
            status : data?.status ?? "",
            testimonialImage : [data?.testimonialImage] ?? []
          },
        }}
        className="isomorphic-form flex flex-grow flex-col @container"
      >
        {({ register, control, getValues, setValue, formState: { errors } }) => (
          <>
            <div className="flex-grow pb-10">
              <div
                className={cn(
                  'grid grid-cols-1 ',
                  isModalView
                    ? 'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                    : 'gap-5'
                )}
              >
                <HorizontalFormBlockWrapper
                  title={`${type} reviews:`}
                  description={`${type} your review information from here`}
                  isModalView={isModalView}
                >
                  <Input
                    label="Name"
                    placeholder="name"
                    {...register('userName')}
                    error={errors.userName?.message}
                  />

                  <Controller
                    name="status"
                    control={control}
                    render={({ field: { name, onChange, value } }) => (
                      <Select
                        options={STATUSVALUENAME}
                        value={value}
                        onChange={onChange}
                        name={name}
                        label="Status"
                        // className="col-span-full"
                        error={errors?.status?.message}
                        getOptionValue={(option) => option.value}
                        displayValue={(selected: any) => getDisplayValue(selected, STATUSVALUENAME)}
                        dropdownClassName="!z-[1]"
                        disabled={type == 'View' ? true : false}
                      />
                    )}
                  />

                  <div className="col-span-2">
                    <Controller
                      control={control}
                      name="message"
                      render={({ field: { onChange, value } }) => (
                        <QuillEditor
                          value={value}
                          onChange={onChange}
                          label="Description"
                          className="[&>.ql-container_.ql-editor]:min-h-[100px]"
                          error={errors.message?.message}
                          labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                        />
                      )}
                    />
                  </div>
                </HorizontalFormBlockWrapper>
                <HorizontalFormBlockWrapper
                  title="Upload new image"
                  description="Upload image here"
                  isModalView={isModalView}
                >
                  <UploadZone
                    name="testimonialImage"
                    label='Testimonial Image'
                    getValues={getValues}
                    setValue={setValue}
                    files={testimonialFiles}
                    setFiles={setTestimonialFiles}
                    className="col-span-full"
                  />
                </HorizontalFormBlockWrapper>
              </div>
            </div>

            <div
              className={cn(
                'sticky bottom-0 z-40 flex items-center justify-end gap-3 bg-gray-0/10 backdrop-blur @lg:gap-4 @xl:grid @xl:auto-cols-max @xl:grid-flow-col',
                isModalView ? '-mx-10 -mb-7 px-10 py-5' : 'py-1'
              )}
            >
              <Button variant="outline" className="w-full @xl:w-auto" onClick={() => closeModal()}>
                Cancel
              </Button>
              <Button
                type="submit"
                isLoading={isLoading}
                className="w-full @xl:w-auto"
              >
                {id ? 'Update' : 'Add'} Review
              </Button>
            </div>
          </>
        )}
      </Form>
    </div>
  );
}
