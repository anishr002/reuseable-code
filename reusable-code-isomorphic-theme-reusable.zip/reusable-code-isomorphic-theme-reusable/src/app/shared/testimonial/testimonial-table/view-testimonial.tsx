import React from 'react';
import { PiXBold } from 'react-icons/pi';
import { ActionIcon, Button, Title } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';
import Image from 'next/image';
import { getStatusBadgeForView } from '@/utils/status-badge';
import { HtmlFormatDetails } from '@/components/ui/html-format';

const TestimonialDetails = ({ data, title }: any) => {
  const { closeModal } = useModal();
  return (
    <div className="flex flex-col gap-6 p-6 @container [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900">
      <div className="flex items-center justify-between">
        <Title as="h4" className="font-semibold">
          {title}
        </Title>
        <ActionIcon size="sm" variant="text" onClick={closeModal}>
          <PiXBold className="h-auto w-5" />
        </ActionIcon>
      </div>

      <div className="flex flex-col gap-4">
        <div className="text-sm">
          <strong>User Name:</strong> {data?.userName ?? '-'}
        </div>
        <div className="text-sm">
          <strong>Status:</strong> {getStatusBadgeForView(Number(data?.status)) ?? '-'}
        </div>
        <div className="text-sm flex">
          <strong>Review:</strong>
          <span className="ml-2">
            {data?.message ? <HtmlFormatDetails description={data?.message} /> : '-'}
          </span>
        </div>
        <div className="text-sm">
          <strong>Testimonial Image:</strong>
          <div className="image-preview mt-2">
            {data?.testimonialImage ? (
              <Image
                src={data?.testimonialImage}
                alt="Testimonial Image"
                height={200}
                width={150}
                className="rounded-lg"
              />
            ) : (
              '-'
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center justify-end gap-4">
        <Button variant="outline" onClick={closeModal} className="w-full @xl:w-auto">
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default TestimonialDetails;
