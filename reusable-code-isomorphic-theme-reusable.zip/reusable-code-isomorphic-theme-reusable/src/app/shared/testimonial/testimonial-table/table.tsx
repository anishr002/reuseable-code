"use client";

import Table from '@/app/shared/table/table';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import { getReviewsColumns } from './column';
import { deleteReview, getAllReviewList } from '@/redux/slices/testimonial/reviewsSlice';
import TestimonialPageHeader from '@/app/(hydrogen)/testimonial/testimonial-page-header';
import WithAuth from '@/components/protected-router';
import toast from 'react-hot-toast';

const pageHeader = {
  title: 'Testimonial Management',
};


function ReviewsTable() {
  const [pageSize, setPageSize] = useState(10);
  const dispatch = useDispatch();
  const reviewsList = useSelector((state: any) => state.reviewstestimonial.getReviewsList);

  const handleChangePage = async (paginationParams: Pagination) => {
    let { page, pageSize, sortBy, search, filterBy, filterByStatus } = paginationParams;
    try {
      const response = await dispatch(getAllReviewList({ page, pageSize, sortBy, search, filterBy, filterByStatus }));

      if (response?.payload) {
        const { total, data } = response.payload;
        const maxPage: number = Math.ceil(total / pageSize);
        if (page > maxPage) {
          page = maxPage > 0 ? maxPage : 1;
          const adjustedResponse = await dispatch(getAllReviewList({ page, pageSize, sortBy, search, filterBy, filterByStatus }));

          if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
            return adjustedResponse;
          }
        }
        if (data && data.length !== 0) {
          return data;
        }
      }
      return [];

    } catch (error) {
      console.error('Error fetching admin list:', error);
      return [];
    }
  };


  // const handleChangePage = async (paginationParams: Pagination) => {
  //   let { page, pageSize, sortBy, search } = paginationParams;
  //   const response = await dispatch(getAllReviewList({ page, pageSize, sortBy, search }));
  //   const { total } = response.payload;
  //   const maxPage: number = Math.ceil(total / pageSize);

  //   if (page > maxPage) {
  //     page = maxPage > 0 ? maxPage : 1;
  //   }
  //   const adjustedResponse = await dispatch(getAllReviewList({ page, pageSize, sortBy, search }));
  //   return adjustedResponse;
  // };

  const handleDeleteById = async (id: string | string[]) => {
    try {
      const res = await dispatch(deleteReview({ id }));
      if (res.payload.status === false || res.payload.status === 0) {
        toast.error(res.payload.message);
      } else {
        toast.success(res.payload.message);
        await dispatch(getAllReviewList({ sortBy: 'createdAt:desc' }));
      }
    } catch (error) {
      console.error(error);
    }
  };


  return (
    <>
      <TestimonialPageHeader
        title={pageHeader.title}
      />
      <Table
        data={reviewsList?.data && reviewsList?.data?.data?.length > 0 ? reviewsList?.data?.data : []}
        getColumns={(props: any) => getReviewsColumns({ ...props })}
        pageSize={pageSize}
        setPageSize={setPageSize}
        page={reviewsList?.data?.page}
        sortBy={reviewsList?.data?.sortBy}
        total={reviewsList?.data?.total}
        isLoading={reviewsList?.loading}
        handleChangePage={handleChangePage}
        handleDeleteById={handleDeleteById}
        isScroll={false}
        isToggleColumns={false}
        isSearch={true}
        isDrawerFilter={false}
        moduleName='testimonial'
      />
    </>
  );
}

export default WithAuth(ReviewsTable);
