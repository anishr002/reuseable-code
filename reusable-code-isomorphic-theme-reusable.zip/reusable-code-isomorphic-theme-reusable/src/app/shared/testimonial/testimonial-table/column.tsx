'use client';

import { Tooltip, Checkbox, ActionIcon } from 'rizzui';
import { HeaderCell } from '@/components/ui/table';
import EyeIcon from '@/components/icons/eye';
import AvatarCard from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import { useModal } from '../../modal-views/use-modal';
import { Columns, User } from 'types';
import PencilIcon from '@/components/icons/pencil';
import { HtmlFormat } from '@/components/ui/html-format';
import { getStatusBadge } from '@/utils/status-badge';
import TestimonialDetails from './view-testimonial';
import { CreateTestimonialModalView } from '@/app/(hydrogen)/testimonial/testimonial-page-header';
import DeletePopover from '../../delete-popover';

export const getReviewsColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  canEdit,
  canView,
  canDelete
}: Columns) => [
    {

      title: (
        <div className="flex items-center gap-3 whitespace-nowrap ps-3">
          <Checkbox
            title={'Select All'}
            onChange={handleSelectAll}
            checked={checkedItems.length === data.length}
            className="cursor-pointer"
          />
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 30,
      render: (_: any, row: User) => (
        <div className="inline-flex ps-3">
          <Checkbox
            className="cursor-pointer"
            checked={checkedItems.includes(row._id)}
            {...(onChecked && { onChange: () => onChecked(row._id) })}
          />
        </div>
      ),
    },
    {
      title: <HeaderCell title="Name" 
      sortable
            ascending={
              sortConfig  === 'userName:asc'
            }
      />,
      onHeaderCell: () => onHeaderCellClick('userName'),
      dataIndex: 'Name',
      key: 'username',
      width: 250,
      render: (_: any, row: any) => {
        return (
          <AvatarCard
            src={row?.avatar}
            name={row?.userName}
            // description={row.email}
          />);
      }
    },
    {
      title: (
        <HeaderCell
          title="Review"
        />
      ),
      dataIndex: 'Review',
      key: 'message',
      width: 200,
      render: (_: any, row: any) => {
        return row ? <HtmlFormat description={row?.message} /> : '-';
      },
    },
    {
      title: <HeaderCell title="Status"
      sortable
            ascending={
              sortConfig === 'status:asc'
            } />,
            onHeaderCell: () => onHeaderCellClick('status'),

      dataIndex: 'Status',
      key: 'status',
      width: 120,
      render: (_: any, row: any) => {
        return (row ? getStatusBadge(Number(row?.status)) : '-');
      },
    },
    {
        title: 
          <HeaderCell
            title="Created At"
            sortable
            ascending={
              sortConfig === 'createdAt:asc'
            }
          />,
        onHeaderCell: () => onHeaderCellClick('createdAt'),
        dataIndex: 'createdAt',
        key: 'createdAt',
        width: 200,
        render: (_: any, row: any) => {
          return row ? <DateCell date={row?.createdAt} /> : '-';
        },
      },
    {
      title: <></>,
      dataIndex: 'action',
      key: 'action',
      width: 140,
      render: (_: string, row: any) => (
<RenderAction row={row} onDeleteItem={onDeleteItem} canEdit={canEdit} canView={canView} canDelete={canDelete} />      ),
    },
  ];

const RenderAction = ({
  row,
  onDeleteItem,
  canEdit,
  canView,
  canDelete
}: {
  row: any;
  onDeleteItem: (id: string) => void;
  canEdit?: boolean;
  canView?: boolean;
  canDelete?: boolean;
}) => {
  const { openModal } = useModal();
  return (
      <div className="flex items-center justify-start gap-3 pe-4">
       {canEdit && <Tooltip
          size="sm"
          content={'Edit Review'}
          placement="top"
          color="invert"
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            onClick={() =>
              openModal({
                view: (
                  <CreateTestimonialModalView
                    type="Edit"
                    title={"Edit Review"}
                    id={row?._id}
                    data={row && row}
                    isModalView={false}
                  />
                ),
                customSize: '950px',
              })
            }
            className="hover:!border-gray-900 hover:text-gray-700"
          >
            <PencilIcon className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>}
       {canView && <Tooltip
          size="sm"
          content={"View Review"}
          placement="top"
          color="invert"
        >
          <ActionIcon
            size="sm"
            variant="outline"
            onClick={() =>
              openModal({
                view: (<TestimonialDetails title=' View Testimonial Details'  data={row && row}/>),
                customSize: '950px',
              })
            }
          >
            <EyeIcon className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>}
        {canDelete && <DeletePopover
        title={`Delete the review`}
        description={`Are you sure you want to delete this review?`}
        onDelete={() => onDeleteItem(row._id)}
      />}
      </div>
  );
};
