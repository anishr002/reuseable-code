'use client';

import { useEffect, useState } from 'react';
import { PiXBold } from 'react-icons/pi';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { Input, Button, ActionIcon, Title, Select } from 'rizzui';
import {
  CreateUserInput,
  createUserSchema,
} from '@/utils/validators/create-user.schema';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { useDispatch, useSelector } from 'react-redux';
import { adminCreate, getAllAdminList, updateAdminById } from '@/redux/slices/user-management/usermanagementSlice';
import toast from 'react-hot-toast';
import { getAllRoles } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';
import Spinner from '@/components/ui/spinner';
import { RolesPermissions, STATUSVALUENAME } from '@/enums';

export default function CreateUser({ id, type = "Create", title, data }: Readonly<{ id?: string, type: string, title: string, data?: any }>) {
  const { closeModal } = useModal();
  const [reset, setReset] = useState({});
  const [roleList, setRoleList] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();
  const rolesList = useSelector((state: any) => state.rolespermissions.getallRolesData);

  useEffect(() => {
    dispatch(getAllRoles({}))
      .then((res: any) => {
        if (res?.payload?.data?.length > 0) {
          const roles = res?.payload?.data?.map((item: any) => ({
            value: item?._id,
            label: item?.roleName,
          }));
          setRoleList(roles);
        }
      })
      .catch((error: any) => {
        console.error('Error fetching classes for attendance:', error);
      });
  }, [dispatch]);


  const onSubmit: SubmitHandler<CreateUserInput> = async (data) => {
    const selectedRole = roleList.find((role) => role.value === data?.role);
    const payload = {
      ...data,
      userType: selectedRole?.label === RolesPermissions.SuperAdmin ? 1 : 2,
    };

    setIsLoading(true);
    try {
      if (type == 'Edit') {
        await dispatch(updateAdminById({ data: payload, id })).then((res: any) => {
          if (
            (res?.payload?.status === false) ||
            (res?.payload?.status === 0)
          ) {
            toast.error(res?.payload?.message);
          } else {
            toast.success(res?.payload?.message);
            setIsLoading(false);
            closeModal();
            dispatch(getAllAdminList({ sortBy: 'createdAt:desc' }));
          }
        });
      } else {
        await dispatch(adminCreate(payload)).then((res: any) => {
          if (
            (res?.payload?.status === false) ||
            (res?.payload?.status === 0)
          ) {
            toast.error(res?.payload?.message);
          } else {
            toast.success(res?.payload?.message);
            setIsLoading(false);
            closeModal();
            dispatch(getAllAdminList({ sortBy: 'createdAt:desc' }));
          }
        });
      }
    } catch (error) {
      console.log(error);
    }

    setTimeout(() => {
      setIsLoading(false);
      setReset({
        firstName: '',
        lastName: '',
        email: '',
        role: '',
        permissions: '',
        status: '',
      });
      closeModal();
    }, 600);
  };

  const getDisplayValue = (selected: any, List: any[]) =>
    List.find((option: any) => option.value === selected)?.label ?? '';

  return (

    <>
      {
        rolesList?.loading ?
          <div className='h-36 bg-background shadow-xl rounded-xl dark:bg-gray-100 inset-0 flex items-center justify-center bg-opacity-50 z-50'> <Spinner /> </div> :
          (
            <Form<CreateUserInput>
              resetValues={reset}
              onSubmit={onSubmit}
              validationSchema={createUserSchema}
              useFormProps={{
                defaultValues: {
                  firstName: data?.firstName ?? "",
                  lastName: data?.lastName ?? "",
                  email: data?.email ?? "",
                  role: data?.role?._id ?? "",
                  status: data?.status ?? ""
                }
              }}
              className="grid grid-cols-1 gap-6 p-6 @container md:grid-cols-2 [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900"
            >
              {({ register, control, formState: { errors } }) => {
                return (
                  <>
                    <div className="col-span-full flex items-center justify-between">
                      <Title as="h4" className="font-semibold">
                        {title}
                      </Title>
                      <ActionIcon size="sm" variant="text" onClick={closeModal}>
                        <PiXBold className="h-auto w-5" />
                      </ActionIcon>
                    </div>
                    <Input
                      label="First Name"
                      placeholder="Enter user's first name"
                      {...register('firstName')}
                      error={errors.firstName?.message}
                      disabled={type == 'View' ? true : false}
                    />
                    <Input
                      label="Last Name"
                      placeholder="Enter user's last name"
                      {...register('lastName')}
                      error={errors.lastName?.message}
                      disabled={type == 'View' ? true : false}
                    />
                    <Input
                      label="Email"
                      placeholder="Enter user's Email Address"
                      className="col-span-full"
                      {...register('email')}
                      error={errors.email?.message}
                      disabled={type == 'View' ? true : false}
                    />



                    <Controller
                      name="role"
                      control={control}
                      render={({ field: { name, onChange, value } }) => (
                        <Select
                          options={roleList}
                          value={value}
                          onChange={onChange}
                          name={name}
                          label="Role"
                          className="col-span-full"
                          error={errors?.role?.message}
                          getOptionValue={(option: any) => option.value}
                          displayValue={(selected: any) => getDisplayValue(selected, roleList)}
                          disabled={type == 'View' ? true : false}
                          dropdownClassName="!z-[1]"
                        />
                      )}
                    />



                    <Controller
                      name="status"
                      control={control}
                      render={({ field: { name, onChange, value } }) => (
                        <Select
                          options={STATUSVALUENAME}
                          value={value}
                          onChange={onChange}
                          name={name}
                          label="Status"
                          className="col-span-full"
                          error={errors?.status?.message}
                          getOptionValue={(option) => option.value}
                          displayValue={(selected: any) => getDisplayValue(selected, STATUSVALUENAME)}
                          dropdownClassName="!z-[1]"
                          disabled={type == 'View' ? true : false}
                        />
                      )}
                    />
                    <div className="col-span-full flex items-center justify-end gap-4">
                      <Button
                        variant="outline"
                        onClick={closeModal}
                        className="w-full @xl:w-auto"
                      >
                        Cancel
                      </Button>
                      {type !== "View" && <Button
                        type="submit"
                        isLoading={isLoading}
                        className="w-full @xl:w-auto"
                      >
                        {type} User
                      </Button>}
                    </div>
                  </>
                );
              }}
            </Form>
          )
      }
    </>

  );
}
