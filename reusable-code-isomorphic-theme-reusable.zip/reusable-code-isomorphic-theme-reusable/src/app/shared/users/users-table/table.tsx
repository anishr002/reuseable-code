"use client";

import Table from '@/app/shared/table/table';
import { getUserColumns } from '@/app/shared/users/users-table/columns';
import { useState } from 'react';
import { Pagination } from 'types';
import { useDispatch, useSelector } from 'react-redux';
import { deleteAdminById, getAllAdminList } from '@/redux/slices/user-management/usermanagementSlice';
import dynamic from 'next/dynamic';
import toast from 'react-hot-toast';
import PageHeader from '@/app/shared/page-header';
import ModalButton from '@/app/shared/modal-button';
import CreateUser from '@/app/shared/users/create-user';
import PermissionWrapper from '@/app/shared/PermissionWrapper';
import WithAuth from '@/components/protected-router';

const FilterElement = dynamic(
  () => import('@/app/shared/users/users-table/filter-element'),
  { ssr: false }
);

const initialFilterState = {
  filterBy : '',
  filterByStatus : ''
};  

const pageHeader = {
  title: 'Admin Users',
  breadcrumb: [
    {
        name: 'Roles and Permissions',
    },
    {
      name: 'Admin Users',
    },
  ],
};

 function AdminUserTable() {
  const [pageSize, setPageSize] = useState(10);
  const dispatch = useDispatch();
  const adminList = useSelector((state: any) => state.usermanagement.getAdminList);
  const [loading, setLoading] = useState(false);

  const handleChangePage = async (paginationParams: Pagination) => {
    if (loading) return;
    let { page, pageSize, sortBy, search, filterBy, filterByStatus } = paginationParams;
    try {
      setLoading(true);
        const response = await dispatch(getAllAdminList({ page, pageSize, sortBy, search, filterBy, filterByStatus }));
      
      if (response?.payload) {
        const { total, data } = response.payload;
          const maxPage: number = Math.ceil(total / pageSize);
          if (page > maxPage) {
          page = maxPage > 0 ? maxPage : 1;
            const adjustedResponse = await dispatch(getAllAdminList({ page, pageSize, sortBy, search, filterBy, filterByStatus }));
          
          if (adjustedResponse?.payload?.data && adjustedResponse.payload.data.length !== 0) {
            setLoading(false);
            return adjustedResponse.payload.data;
          }
        }
          if (data && data.length !== 0) {
          setLoading(false);
          return data;
        }
      }
        setLoading(false);
      return [];
  
    } catch (error) {
      console.error('Error fetching admin list:', error);
      setLoading(false);
      return [];
    }
  };
  
  const handleDeleteById = async (id: string | string[]) => {
    try {
      const res = await dispatch(deleteAdminById({ id }));
      if (res.payload.status === false || res.payload.status === 0) {
          toast.error(res.payload.message);
      } else {
          toast.success(res.payload.message);
          await dispatch(getAllAdminList({ sortBy: 'createdAt:desc'}));
      }
  } catch (error) {
      console.error(error);
  }

  };
  return (
    <> 
    <PageHeader title={pageHeader.title} breadcrumb={pageHeader.breadcrumb}>
    <PermissionWrapper moduleName="staffs" action='create'>  
    <ModalButton 
      label="Add New User" 
      view={<CreateUser title='Add New User' type='Create'/>} 
      customSize = '750px'
      />
    </PermissionWrapper>
  </PageHeader>
      <Table
        data={adminList?.data && adminList?.data?.data?.length > 0 ? adminList?.data?.data : []}
        getColumns={(props:any) => getUserColumns({...props})}
        pageSize={pageSize}
        setPageSize={setPageSize}
        page={adminList?.data?.page}
        sortBy={adminList?.data?.sortBy}
        total={adminList?.data?.total}
        isLoading={adminList?.loading}
        initialFilterState={initialFilterState}
        FilterElement ={FilterElement && FilterElement}
        handleChangePage={handleChangePage}
        handleDeleteById ={handleDeleteById}
        isScroll={false}
        isToggleColumns={false}
        isSearch={true}
        isDrawerFilter = {true}
        moduleName='staffs'
      />
      </>
  );
}
export default WithAuth(AdminUserTable);
