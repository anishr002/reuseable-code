'use client';

import React, { useEffect, useState } from 'react';
import { PiTrashDuotone } from 'react-icons/pi';
import StatusField from '@/components/controlled-table/status-field';
import { Button, Badge, Text } from 'rizzui';
import { useDispatch} from 'react-redux';
import { getAllRoles } from '@/redux/slices/roles-permissions/rolesPermissionsSlice';
import { STATUSVALUENAME } from '@/enums';
import Spinner from '@/components/ui/spinner';


type FilterElementProps = {
  isFiltered: boolean;
  filters: { [key: string]: any };
  updateFilter: (columnId: string, filterValue: string | any[]) => void;
  handleReset: () => void;
};
export default function FilterElement({
  isFiltered,
  filters,
  updateFilter,
  handleReset,
}: Readonly<FilterElementProps>) {

  const [roleList,setRoleList] = useState([]);
  const dispatch = useDispatch();

  useEffect(() =>{
    dispatch(getAllRoles({}))
    .then((res: any) => {
        if (res?.payload?.data?.length > 0) {
            const roles = res.payload?.data?.map((item: any) => ({
                value: item._id,
                label: item.roleName,
            }));
            setRoleList(roles);
        }
    })
    .catch((error: any) => {
        console.error('Error fetching classes for attendance:', error);
    });
  },[dispatch]);


  return (
    <>
    {
      roleList?.length > 0 ?
      <>
       <StatusField
        label="Status"
        options={STATUSVALUENAME}
        value={filters['filterByStatus']}
        onChange={(value: string) => {
          updateFilter('filterByStatus', value);
        }}
        getOptionValue={(option: { value: any }) => option.value}
        getOptionDisplayValue={(option: { label: string }) =>
          renderOptionDisplayValue(option.label)
        }
        displayValue={(selected) =>
          STATUSVALUENAME.find((option) => option.value == selected)
            ?.label ?? ''
        }
      />

      <StatusField
        label="Role"
        options={roleList}
        value={filters['filterBy']}
        onChange={(value: string) => {
          updateFilter('filterBy', value);
        }}
        getOptionValue={(option: { value: any }) => option.value}
        getOptionDisplayValue={(option: { label: any }) =>
          renderOptionDisplayValue(option.label as string)
        }
        displayValue={(selected: any) => {
           const roleValue:any = roleList?.find((option:any) => option?.value === selected);
           return roleValue?.label || '' ;
           }}
      />
      </> : <Spinner/> 
    }
   
      {isFiltered ? (
        <Button
          size="sm"
          onClick={() => {
            handleReset();
          }}
          className="h-8 bg-gray-200/70"
          variant="flat"
        >
          <PiTrashDuotone className="me-1.5 h-[17px] w-[17px]" /> Clear
        </Button>
      ) : null}
    </>
  );
}

function renderOptionDisplayValue(value: string) {
  switch (value) {
    case 'pending':
      return (
        <div className="flex items-center">
          <Badge color="warning" renderAsDot />
          <Text className="ms-2 font-medium capitalize text-orange-dark">
            {value}
          </Text>
        </div>
      );
    case 'publish':
      return (
        <div className="flex items-center">
          <Badge color="success" renderAsDot />
          <Text className="ms-2 font-medium capitalize text-green-dark">
            {value}
          </Text>
        </div>
      );

    default:
      return (
        <div className="flex items-center">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="ms-2 font-medium capitalize text-gray-600">
            {value}
          </Text>
        </div>
      );
  }
}
