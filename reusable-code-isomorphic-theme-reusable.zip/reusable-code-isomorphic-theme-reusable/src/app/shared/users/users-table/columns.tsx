'use client';

import { Tooltip, Checkbox, ActionIcon } from 'rizzui';
import { HeaderCell } from '@/components/ui/table';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import AvatarCard from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import DeletePopover from '@/app/shared/delete-popover';
import { getStatusBadge } from '@/utils/status-badge';
import { useModal } from '../../modal-views/use-modal';
import CreateUser from '../create-user';
import { Columns, User } from 'types';

export const getUserColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  canEdit,
  canView,
  canDelete
}: Columns) => [
    canDelete ? {

      title: (
        <div className="flex items-center gap-3 whitespace-nowrap ps-3">
          <Checkbox
            title={'Select All'}
            onChange={handleSelectAll}
            checked={checkedItems.length === data.length}
            className="cursor-pointer"
          />
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 30,
      render: (_: any, row: User) => (
        <div className="inline-flex ps-3">
          <Checkbox
            className="cursor-pointer"
            checked={checkedItems.includes(row._id)}
            {...(onChecked && { onChange: () => onChecked(row._id) })}
          />
        </div>
      ),
    } : null,
    {
      title: <HeaderCell title="Name"
      sortable
      ascending={
        sortConfig === 'full_name:asc'
      } />,
      onHeaderCell: () => onHeaderCellClick('full_name'),
      dataIndex: 'Name',
      key: 'firstName',
      width: 250,
      render: (_: any, row: any) => {
        return (
          <AvatarCard
            src={row?.avatar}
            name={`${row.firstName} ${row.lastName}`}
            description={row.email}
          />);
      }
    },
    {
      title: (
        <HeaderCell
          title="Role"
          sortable
          ascending={
            sortConfig === 'role:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('role'),
      dataIndex: 'Role',
      key: 'role',
      width: 250,
      render: (_: any, row: any) => {
        return row?.role ? row?.role?.roleName : '-';
      },
    },
    {
      title: (
        <HeaderCell
          title="Created At"
          sortable
          ascending={
            sortConfig === 'createdAt:asc'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'Created At',
      key: 'createdAt',
      width: 200,
      render: (_: any, row: any) => {
        return row ? <DateCell date={row?.createdAt} /> : '-';
      },
    },
    {
      title: <HeaderCell title="Status"  sortable
      ascending={
        sortConfig === 'status:asc'
      }/>,
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'Status',
      key: 'status',
      width: 120,
      render: (_: any, row: any) => {
        return (row ? getStatusBadge(Number(row?.status)) : '-');
      },
    },
    {
      title: <></>,
      dataIndex: 'action',
      key: 'action',
      width: 140,
      render: (_: string, row: any) => (
        <RenderAction row={row} onDeleteItem={onDeleteItem} canEdit={canEdit} canView={canView} canDelete={canDelete} />
      ),
    },
  ];

const RenderAction = ({
  row,
  onDeleteItem,
  canEdit,
  canView,
  canDelete
}: {
  row: any;
  onDeleteItem: (id: string) => void;
  canEdit?: boolean;
  canView?: boolean;
  canDelete?: boolean;

}) => {
  const { openModal } = useModal();
  return (
    <div className="flex items-center justify-start gap-3 pe-4">
      {canEdit && canView && <Tooltip
        size="sm"
        content={'Edit Admin User'}
        placement="top"
        color="invert"
      >
        <ActionIcon
          as="span"
          size="sm"
          variant="outline"
          onClick={() =>
            openModal({
              view: (
                <CreateUser
                  type="Edit"
                  title={"Edit Admin User"}
                  id={row?._id}
                  data={row && row}
                />
              ),
              customSize: '750px',
            })
          }
          className="hover:!border-gray-900 hover:text-gray-700"
        >
          <PencilIcon className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>}
      {canView && <Tooltip
        size="sm"
        content={"View Admin User"}
        placement="top"
        color="invert"
      >
        <ActionIcon
          size="sm"
          variant="outline"
          onClick={() =>
            openModal({
              view: (
                <CreateUser
                  type="View"
                  title={"View Admin User"}
                  id={row?._id}
                  data={row}
                />
              ),
              customSize: '750px',
            })
          }
        >
          <EyeIcon className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>}
      {canDelete && canView && <DeletePopover
        title={`Delete the User`}
        description={`Are you sure you want to delete this user?`}
        onDelete={() => onDeleteItem(row._id)}
      />}
    </div>
  );
};
