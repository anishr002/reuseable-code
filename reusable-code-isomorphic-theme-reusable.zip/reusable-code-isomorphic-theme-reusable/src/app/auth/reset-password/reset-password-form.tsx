'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button, Text, Password } from 'rizzui';
import { SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { routes } from '@/config/routes';
import {
  resetPasswordSchema,
  ResetPasswordSchema,
} from '@/utils/validators/reset-password.schema';
import { resetPassWord } from '@/redux/slices/auth/signInSlice';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';
import { useRouter, useSearchParams } from 'next/navigation';

const initialValues = {
  password: '',
  confirmPassword: '',
};

export default function ResetPasswordForm() {
  const [reset, setReset] = useState({});
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const userSearchParams = useSearchParams();
  const router = useRouter();


  const onSubmit: SubmitHandler<ResetPasswordSchema> = async (data) => {
    setLoading(true);
    const payload = {
      new_password : data.confirmPassword,
      resetPasswordToken: userSearchParams.get('token') ? userSearchParams.get('token') : '',
    };
    await dispatch(resetPassWord(payload)).then((res: any) => {
      if (
        (res?.payload && res?.payload?.status === false) ||
        (res?.payload && res?.payload?.status === 0)
      ) {
        setLoading(false);
        toast.error(res?.payload && res?.payload?.message);
      } else {
        setLoading(false);
        toast.success(res?.payload && res?.payload?.message);
        router.push(routes.signIn);
      }
    });

    setReset(initialValues);
  };

  return (
    <>
      <Form<ResetPasswordSchema>
        validationSchema={resetPasswordSchema}
        resetValues={reset}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'onChange',
          defaultValues: initialValues,
        }}
        className="pt-1.5"
      >
        {({ register, formState: { errors } }) => (
          <div className="space-y-6">
            <Password
              label="Password"
              placeholder="Enter your password"
              size="lg"
              className="[&>label>span]:font-medium"
              inputClassName="text-sm"
              {...register('password')}
              error={errors.password?.message}
            />
            <Password
              label="Confirm Password"
              placeholder="Enter confirm password"
              size="lg"
              className="[&>label>span]:font-medium"
              inputClassName="text-sm"
              {...register('confirmPassword')}
              error={errors.confirmPassword?.message}
            />
            <Button  
             className="mt-2 w-full bg-blue-dark hover:enabled:bg-blue"
             type="submit"
             isLoading={loading} 
             size="lg"
             >
              Reset Password
            </Button>
          </div>
        )}
      </Form>
      <Text className="mt-6 text-center text-[15px] leading-loose text-gray-500 lg:mt-8 lg:text-start xl:text-base">
        Don’t want to reset your password?{' '}
        <Link
          href={routes.signIn}
          className="font-bold text-gray-700 transition-colors hover:text-blue"
        >
          Sign In
        </Link>
      </Text>
    </>
  );
}
