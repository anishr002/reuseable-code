import UnderlineShape from '@/components/shape/underline';
import Image from 'next/image';
import AuthWrapperOne from '@/app/shared/auth-layout/auth-wrapper-one';
import ResetPasswordForm from './reset-password-form';
import { siteConfig } from '@/config/site.config';

export default function SignIn() {
  return (
    <div className='h-screen overflow-hidden'>
    <AuthWrapperOne
      title={
        <>
          Reset your{' '}
          <span className="relative inline-block">
            password!
            <UnderlineShape className="absolute -bottom-2 end-0 h-2.5 w-28 text-blue xl:-bottom-1.5 xl:w-36" />
          </span>
        </>
      }
      bannerTitle="The simplest way to manage your workspace."
      bannerDescription="Amet minim mollit non deserunt ullamco est sit aliqua dolor do
      amet sint velit officia consequat duis."
      pageImage={
        <div className="relative mx-auto w-[400px] xl:w-[500px] 2xl:w-[650px] h-[300px] xl:h-[400px] 2xl:h-[500px]">
            <Image
              src={siteConfig.signInImage}
              alt="Sign Up Thumbnail"
              fill
              priority
              sizes="(max-width: 768px) 100vw"
              className="object-cover"
            />
          </div>
      }
    >
      <ResetPasswordForm />
    </AuthWrapperOne>
    </div>
  );
}
