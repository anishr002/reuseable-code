'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button, Text, Input } from 'rizzui';
import { SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { routes } from '@/config/routes';
import { forgetPassword } from '@/redux/slices/auth/signInSlice';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';
import { useRouter } from 'next/navigation';
import {
  ForgotPasswordSchema,
  forgotPasswordSchema,
} from '@/utils/validators/forgot-password-schema';

const initialValues = {
  emailOrMobile: '',
};

export default function ForgetPasswordForm() {
  const [reset, setReset] = useState({});
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const router = useRouter();

  const onSubmit: SubmitHandler<ForgotPasswordSchema> = async (data) => {
    setLoading(true);
    let payload = {
      ...data,
      webType: 'isomorphic',
    };
    await dispatch(forgetPassword(payload)).then((res: any) => {
      if (
        (res?.payload && res?.payload?.status === false) ||
        (res?.payload && res?.payload?.status === 0)
      ) {
        toast.error(res?.payload && res?.payload.message);
        setLoading(false);
      } else {
        setLoading(false);
        toast.success(res?.payload && res?.payload.message);
        router.push(routes.signIn);
      }
    });

    setReset(initialValues);
  };

  return (
    <>
      <Form<ForgotPasswordSchema>
        validationSchema={forgotPasswordSchema}
        resetValues={reset}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'onChange',
          defaultValues: initialValues,
        }}
        className="pt-1.5"
      >
        {({ register, formState: { errors } }) => (
          <div className="space-y-6">
            <Input
              type="email"
              size="lg"
              label="Email"
              placeholder="Enter your email"
              className="[&>label>span]:font-medium"
              inputClassName="text-sm"
              {...register('emailOrMobile')}
              error={errors.emailOrMobile?.message}
            />
            <Button
              className="mt-2 w-full bg-blue-dark hover:enabled:bg-blue"
              type="submit"
              size="lg"
              isLoading={loading}
            >
              Reset Password
            </Button>
          </div>
        )}
      </Form>
      <Text className="mt-6 text-center text-[15px] leading-loose text-gray-500 lg:mt-8 lg:text-start xl:text-base">
        Don’t want to reset your password?{' '}
        <Link
          href={routes.signIn}
          className="font-bold text-gray-700 transition-colors hover:text-blue"
        >
          Sign In
        </Link>
      </Text>
    </>
  );
}
