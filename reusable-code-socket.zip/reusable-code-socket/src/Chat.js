import React, { useEffect, useState, useCallback } from 'react';
import io from 'socket.io-client';
import { ObjectId } from 'bson';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBell } from '@fortawesome/free-solid-svg-icons';

const Chat = () => {
    const [socket, setSocket] = useState(null);
    const [messages, setMessages] = useState([]);
    const [message, setMessage] = useState('');
    const [groupId,] = useState();
    const [userId,] = useState(new ObjectId().toString());
    const [receiverId,] = useState(new ObjectId().toString());
    const [isPersonalChat, ] = useState(false);
    const [username, setUsername] = useState('');
    const [isConnected, setIsConnected] = useState(false);
    const [notifications, setNotifications] = useState([{id:'', message: ''}]);
    const [showNotifications, setShowNotifications] = useState(false);
    const [notificationCount, setNotificationCount] = useState(0);

    const handleReceivedMessage = useCallback((messageData) => {
        if(!isPersonalChat){
            if (messageData) {
                setMessages((prevMessages) => {
                    console.log('Updating messages:', [...prevMessages, messageData]);
                    let messageDataa = {
                        id: prevMessages.length  + 1,
                        ...messageData
                    }
                    return [...prevMessages, messageDataa];
                });
    
                if (!isPersonalChat && messageData.creator_id !== userId) {
                    setNotifications((prevNotifications) => {
                        
                        let newNotification = {
                            id: prevNotifications.length + 1,
                            message :  `New message from ${messageData.username}: ${messageData.message}`
                        }
                        return [...prevNotifications, newNotification];
                    });
                    setNotificationCount((prevCount) => {
                        return prevCount + 1;
                    });
                }
            } else {
                console.log('messageData is undefined or null');
            }
        }else{
            setMessages([]);
            setMessage('');
        }
    }, [isPersonalChat, userId]);

    useEffect(() => {
        const socketIo = io(process.env.REACT_APP_API_BASE_URL);
        setSocket(socketIo);

        if (socketIo) {
            socketIo.on('receivedMessage', handleReceivedMessage);

            return () => {
                socketIo.off('receivedMessage', handleReceivedMessage);
                socketIo.disconnect();
            };
        }
    }, [handleReceivedMessage]);

    // const handleSwitchChat = () => {
    //     setIsPersonalChat((prevIsPersonalChat) => !prevIsPersonalChat);
    //     setMessages([]);
    //     setNotifications([{id:'', message: ''}]);
    //     const socketIo = io(process.env.REACT_APP_API_BASE_URL);
    //     socketIo.on('receivedMessage', handleReceivedMessage);
    // }

    const handleConnectToChat = () => {
        if (socket) {
            if (isPersonalChat) {
                socket.emit('connectPersonalChat', { creator_id: userId, username });
            } else {
                socket.emit('connectChatGroup', { group_id: groupId, username });
            }
            setIsConnected(true);
        }
    };

    const handleSendMessage = () => {
        if (!isConnected) return;

        if (isPersonalChat) {
            socket.emit('personalChat', {
                message,
                creator_id: userId,
                receiver_id: receiverId,
                username
            });
        } else {
            socket.emit('sendMessage', {
                message,
                creator_id: userId,
                group_id: groupId,
                username
            });
        }
        setMessage('');
    };

    const handleNotificationClick = () => {
        setShowNotifications(!showNotifications);
        if (showNotifications) {
            setNotificationCount(0);
        }
    };

    const validNotifications = notifications.filter(notif => notif.id && notif.message);

    return (
        <div>
            <h1>Chat Application</h1>
            {!isConnected ? (
                <div className='connect-chat'>
                    <div className='messageInputs'>
                        <input
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Enter your username..."
                        />
                        <button onClick={handleConnectToChat} disabled={!username.trim()}>
                            Connect to Chat
                        </button>
                    </div>
                </div>
            ) : (
                <div>
                    {/* <button onClick={handleSwitchChat}>
                        Switch to {isPersonalChat ? 'Group' : 'Personal'} Chat
                    </button>
                    <h2>{isPersonalChat ? 'Personal Chat' : 'Group Chat'}</h2> */}
                     <h2>Group Chat</h2> 
                    <div className='chatContainer'>
                        {validNotifications && validNotifications.length > 0 && (
                            <div className='notifications'>
                                <div className='notificationIconWrapper'>
                                    <FontAwesomeIcon
                                        icon={faBell}
                                        className='notificationIcon'
                                        onClick={handleNotificationClick}
                                    />
                                    {notificationCount > 0 && (
                                        <div className='notificationCount'>{notificationCount}</div>
                                    )}
                                </div>
                                {showNotifications && (
                                    <div className='notificationList'>
                                        {notifications.map((notif) => (
                                            <div key={notif.id} className="notificationItem">{notif?.message}</div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}
                        {/* {isPersonalChat && (
                            <h2 className='personalChatName'>{username}</h2>
                        )} */}
                        <div className='messages' style={{ overflowY: messages.length > 0 ? 'scroll' : '' }}>
                            {messages.map((msg) => {
                                return (
                                    <div
                                        key={msg.id}
                                        className="messageContainer"
                                        id={msg.creator_id === userId ? 'You' : 'Other'}
                                    >
                                        <div className="messageIndividual">
                                            <div className='username text-left'>
                                                <strong>{"~"}{msg.username}</strong>
                                            </div>
                                            <div className='messageText'>
                                                {msg.message}
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>

                        <div className='messageInputs'>
                            <input
                                type="text"
                                value={message}
                                onChange={(e) => setMessage(e.target.value)}
                                placeholder='Message...'
                            />
                            <button onClick={handleSendMessage} disabled={!message.trim()}>
                                Send
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Chat;