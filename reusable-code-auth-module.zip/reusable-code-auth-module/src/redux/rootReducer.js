// ** Reducers Imports
import layoutSlice from '../redux/layout'
import navlayoutSlice from '../redux/navbar'

// const rootReducer = { navbar, layout };

// export default rootReducer;


import { combineReducers } from "@reduxjs/toolkit";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import authSlice from './authSlice';
// import authSlice from "./slices/authSlice";


// Reducers

const persistConfig = {
    key: "root",
    storage,
};

const appReducer = combineReducers({
    auth: authSlice,
    navbar:navlayoutSlice,
    layout:layoutSlice
});
const rootReducer = (state, action) => {
    if (action.type === "login/logoutdata") {
        state = undefined;
    }
    return appReducer(state, action);
};
export const persistedReducer = persistReducer(persistConfig, rootReducer);
export default rootReducer;

