import { lazy } from "react";

// ** Router imports
import { useRoutes, Navigate } from "react-router-dom";

// ** Layouts
import BlankLayout from "@layouts/BlankLayout";

// ** Hooks Imports
import { useLayout } from "@hooks/useLayout";

// ** Utils
import { getRoutes } from "./routes/index";
import { useSelector } from "react-redux";

// ** Components

const Login = lazy(() => import("../views/auth/LoginHookForm"));

const Register = lazy(() => import("../views/auth/Register"));
const ForgotPassword = lazy(() =>
  import("../views/auth/ForgotPasswordHookForm")
);
const ResetPassword = lazy(() => import("../views/auth/ResetPasswordFormik"));
const Error = lazy(() => import("../views/error/Error"));

const Router = (props) => {
  const { UserData } = useSelector((state) => state.root.authentication);

  // ** Hooks
  const { layout } = useLayout();

  const allRoutes = getRoutes(layout, UserData);

  const getHomeRoute = () => {
    // const user = UserData?.token;
    const user = localStorage.getItem("accessToken");
    if (user) {
      return "/home";
    } else {
      return "/login";
    }
  };
  const getErrorElemnet = () => {
    const user = localStorage.getItem("accessToken");

    if (user) {
      return <Error />;
    } else {
      return <Navigate to={"/login"} />;
    }
  };
  const routes = useRoutes([
    {
      path: "/",
      index: true,
      element: <Navigate replace to={getHomeRoute()} />,
    },
    {
      path: "/login",
      element: <Login />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "/register",
      element: <Register />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "/forgot-password",
      element: <ForgotPassword />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "reset-password",
      element: <ResetPassword />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "*",
      element: <BlankLayout />,
      children: [{ path: "*", element: getErrorElemnet() }],
    },
    ...allRoutes,
  ]);

  return routes;
};

export default Router;
