// ** React Imports
import { lazy } from "react";

const Home = lazy(() => import("../../views/Home"));
const SecondPage = lazy(() => import("../../views/SecondPage"));

// ** Merge Routes
const HomeRoutes = [
  {
    path: "home",
    element: <Home />,
    meta: {
      className: "home-aplication",
    },
    id: "home",
    permission: ["Admin", "Software Engineer"],
  },
  {
    path: "second-page",
    element: <SecondPage />,
    meta: {
      className: "dashboard-aplication",
    },
    id: "secondPage",
    permission: ["Software Engineer"],
  },
];

export default HomeRoutes;
