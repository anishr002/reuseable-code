// ** React Imports
import { Fragment, lazy } from "react";
// ** Layouts
import BlankLayout from "@layouts/BlankLayout";
import VerticalLayout from "@src/layouts/VerticalLayout";
import HorizontalLayout from "@src/layouts/HorizontalLayout";
import LayoutWrapper from "@src/@core/layouts/components/layout-wrapper";

// ** Route Components
import PublicRoute from "@components/routes/PublicRoute";
import PrivateRoute from "@components/routes/PrivateRoute";

// ** Utils
import { isObjEmpty } from "@utils";
import Home from "./Home";

import { isUserLoggedIn } from "@utils";

const getLayout = {
  blank: <BlankLayout />,
  vertical: <VerticalLayout />,
  horizontal: <HorizontalLayout />,
};

// ** Document title
const TemplateTitle = "%s - Vuexy React Admin Template";

const DefaultRoute = "/home";

// ** Merge Routes
const Routes = [...Home];

const getRouteMeta = (route) => {
  if (isObjEmpty(route.element.props)) {
    if (route.meta) {
      return { routeMeta: route.meta };
    } else {
      return {};
    }
  }
};

const MergeLayoutRoutes = (layout, defaultLayout, userData) => {
  const LayoutRoutes = [];

  if (Routes) {
    Routes.filter((route) => {
      // let Role = JSON.parse(localStorage.getItem('userData'));
      // const sectionExists = userData?.role?.filter((item) => item.section === route.id);
      let isBlank = false;
      const RouteAdd = () => {
        let RouteTag = PrivateRoute;
        // ** Check for public or private route
        if (route.meta) {
          route.meta.layout === "blank" ? (isBlank = true) : (isBlank = false);
          RouteTag = route.meta.publicRoute ? PublicRoute : PrivateRoute;
        }
        if (route.element) {
          const Wrapper =
            isObjEmpty(route.element.props) && isBlank === false
              ? LayoutWrapper
              : Fragment;

          route.element = (
            <Wrapper {...(isBlank === false ? getRouteMeta(route) : {})}>
              <RouteTag route={route}>{route.element}</RouteTag>
            </Wrapper>
          );
        }
        // Push route to LayoutRoutes
        LayoutRoutes.push(route);
      };

      let userRoleObject = JSON.parse(localStorage.getItem("userData"));

      let userRole = userRoleObject?.role?.role_name;
      console.log("########", userRole);
      const routePermission = route.permission;

      // If user is logged in and userData is in local storage
      if (isUserLoggedIn() && userRole) {
        //Compare the permissions and user role
        // console.log(routePermission, "routePermission");
        if (routePermission?.indexOf(userRole) >= 0) {
          RouteAdd(route);
        }
        return LayoutRoutes;
      }
      // ** If none of the above render component
      // return <route.component {...props} />;
    });
  }
  return LayoutRoutes;
};

const getRoutes = (layout, userData) => {
  const defaultLayout = layout || "vertical";
  const layouts = ["vertical", "horizontal", "blank"];

  const AllRoutes = [];

  layouts.forEach((layoutItem) => {
    const LayoutRoutes = MergeLayoutRoutes(layoutItem, defaultLayout, userData);

    AllRoutes.push({
      path: "",
      element: getLayout[layoutItem] || getLayout[defaultLayout],
      children: LayoutRoutes,
    });
  });
  return AllRoutes;
};

export { DefaultRoute, TemplateTitle, Routes, getRoutes };
