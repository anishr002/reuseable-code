import axios from "axios";
import jwtDefaultConfig from "./jwtDefaultConfig";
import CustomToast, { ErrorCss } from "../../../utility/toast/CustomeToast";
import { store } from "../../../redux/store";
import toast from "react-hot-toast";

const jwtConfig = { ...jwtDefaultConfig };

let isAlreadyFetchingAccessToken = false;
let subscribers = [];

const onAccessTokenFetched = (accessToken) => {
  subscribers = subscribers.filter((callback) => callback(accessToken));
};

const addSubscriber = (callback) => {
  subscribers.push(callback);
};

const getToken = () => {
  return localStorage.getItem(jwtConfig.storageTokenKeyName);
};

const login = (...args) => {
  return axios.post(jwtConfig.loginEndpoint, ...args);
};

const register = (...args) => {
  return axios.post(jwtConfig.registerEndpoint, ...args);
};

const refreshToken = () => {
  return axios.post(jwtConfig.refreshEndpoint, {
    refreshToken: localStorage.getItem(jwtConfig.storageRefreshTokenKeyName),
  });
};

const axiosInstance = axios.create({
  baseURL: `${import.meta.env.VITE_APP_API_URL}`, // Set your API base URL here
});

// ** Request Interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    // ** Get token from localStorage
    const accessToken = getToken();

    // ** If token is present add it to request's Authorization Header
    if (accessToken) {
      // ** eslint-disable-next-line no-param-reassign
      config.headers.Authorization = `${jwtConfig.tokenType} ${accessToken}`;
    }
    // Check if the request config has a 'contentType' property

    if (config.contentType) {
      config.headers["Content-Type"] = config.contentType;
    } else {
      // If not, use the existing logic to determine content type based on the URL
      config.headers["Content-Type"] = "application/json";
    }
    return config;
  },
  (error) => Promise.reject(error)
);
// ** Add request/response interceptor
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );

      setTimeout(() => {
        localStorage.clear();
        const resetStore = async () => {
          store.dispatch({ type: "RESET" });
        };
        resetStore();

        window.location.href = `/`;
        window.location.reload(false);
      }, 1000);
    }

    return Promise.reject(error);
  }
);

export {
  onAccessTokenFetched,
  addSubscriber,
  getToken,
  axiosInstance as axios,
  login,
  register,
  refreshToken,
};
