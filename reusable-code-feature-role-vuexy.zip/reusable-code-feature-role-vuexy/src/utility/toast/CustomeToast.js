import { X } from "react-feather";
import toast from "react-hot-toast";

const CustomToast = ({ message, type }) => {
  return (
    <div className="d-flex justify-content-center align-items-center">
      <div className="me-2">{message}</div>
      <X className="cursor-pointer" onClick={() => toast?.dismiss()} />
    </div>
  );
};
const SuccessCss = () => {
  return {
    duration: 10000, // 5 minutes in milliseconds
    position: "top-right",
    className: "text-success",
    style: {
      minWidth: "fit-content",
      background: "#e5f8ed",
      fontColor: "green",
    },
  };
};
const ErrorCss = () => {
  return {
    duration: 10000, // 5 minutes in milliseconds
    position: "top-right",
    className: "text-danger",
    style: {
      minWidth: "fit-content",
      background: "#fceaea",
      fontColor: "red",
    },
  };
};
export { SuccessCss, ErrorCss };
export default CustomToast;
