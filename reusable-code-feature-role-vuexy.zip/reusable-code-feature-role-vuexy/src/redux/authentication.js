// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast from "../utility/toast/CustomeToast";
import { ErrorCss, SuccessCss } from "../utility/toast/CustomeToast";
import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";
import toast from "react-hot-toast";

export const AuthSlice = createSlice({
  name: "Authentication",
  initialState: {
    UserData: { token: localStorage.getItem("accessToken") },
    isLoading: false,
  },
  reducers: {
    handleLogin: (state, action) => {
      state.UserData = { ...state.UserData, ...action.payload };
    },
  },
});

export const { handleLogin } = AuthSlice.actions;
// export const { initialState } = AuthSlice;

export const LoginAPI = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    return await axios.post("users/login", data).then((response) => {
      dispatch(loadingFlag(false));
      console.log("#######2322", response);
      localStorage.setItem("accessToken", response?.data?.data?.auth_token);
      localStorage.setItem("userData", JSON.stringify(response?.data?.data));
      dispatch(handleLogin(response?.data?.data));
      toast(
        <CustomToast message={"Login Successfully!"} type={"success"} />,
        SuccessCss()
      );
      navigate(`/home`);
      return response;
    });
  } catch (error) {
    dispatch(loadingFlag(false));
    console.log("#########", error);
    toast(
      <CustomToast
        message={error?.response?.data.error || error?.response?.data.message}
        type={"error"}
      />,
      ErrorCss()
    );
    return error;
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const ForgotPasswordApi =
  (data, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.post("users/forgot-password", data).then((response) => {
        toast(
          <CustomToast message={response?.data.message} type={"success"} />,
          SuccessCss()
        );
        dispatch(loadingFlag(false));
        navigate(`/login`);
      });
    } catch (error) {
      toast(
        <CustomToast
          message={error?.response?.data.message || error?.response?.data.error}
          type={"error"}
        />,
        ErrorCss()
      );

      console.log("###", error);
      dispatch(loadingFlag(false));
      // navigate(`/${data?.role_type === 'super-admin' ? 'administrator/login' : 'organization/login'}`);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const changePasswordApi =
  (data, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.post("users/reset-password", data).then((response) => {
        toast(
          <CustomToast message={response?.data.message} type={"success"} />,
          SuccessCss()
        );
        localStorage.clear();
        dispatch({ type: "RESET" });
        dispatch(handleLogin({ token: undefined }));
        dispatch(loadingFlag(false));
        navigate(`/login`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
      dispatch(loadingFlag(false));
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const checkTokenExpiryApi =
  (token, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.get(`verifyTokenExpiration/${token}`).then((response) => {});

      return { status: true };
    } catch (error) {
      navigate(`/link-expired`);

      console.log("###", error);
      dispatch(loadingFlag(false));
      return { status: false };
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export default AuthSlice.reducer;
