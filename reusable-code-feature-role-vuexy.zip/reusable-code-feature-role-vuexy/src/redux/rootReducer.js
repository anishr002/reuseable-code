import storage from "redux-persist/lib/storage";
import { persistReducer } from "redux-persist";
import { combineReducers } from "@reduxjs/toolkit";
// ** Reducers Imports
import layout from "./layout";
import navbar from "./navbar";
import authentication from "./authentication";

const persistConfig = {
  key: "root",
  storage,
};

const rootReducer = combineReducers({
  navbar,
  layout,
  authentication,
});

const appReducer = (state, action) => {
  if (action.type === "RESET") {
    localStorage.clear();
    return rootReducer(undefined, action);
  }

  return rootReducer(state, action);
};

export const persistedReducer = persistReducer(persistConfig, appReducer);

export default rootReducer;
