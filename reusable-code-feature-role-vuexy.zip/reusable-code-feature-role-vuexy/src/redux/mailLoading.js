// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";

export const MainLoading = createSlice({
  name: "MainLoading",
  initialState: {
    isLoading: false,
    edit: false,
  },
  reducers: {
    loadingFlag: (state, action) => {
      state.isLoading = action.payload;
    },
  },
});

export const { loadingFlag } = MainLoading.actions;

export default MainLoading.reducer;
