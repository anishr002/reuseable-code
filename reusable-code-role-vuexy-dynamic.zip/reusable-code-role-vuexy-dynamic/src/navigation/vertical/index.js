import {
  Feather,
  Framer,
  HelpCircle,
  Home,
  Layout,
  List,
  Phone,
  Pocket,
  Star,
  Tool,
  Trello,
  Type,
  UserPlus,
} from "react-feather";
import { MODULE_NAME } from "../../configs/constant";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

const Automation = [
  {
    id: MODULE_NAME.DASHBOARD,
    title: "Dashboard",
    icon: Home,
    navLink: `${prefix}/dashboard`,
  },
  {
    id: "roles",
    title: "Admin Users",
    icon: Trello,
    children: [
      {
        id: "roles",
        title: "Admin User Roles",
        icon: List,
        navLink: `${prefix}/role-management`,
        parent: "Role Management",
      },
      {
        id: "staffs",
        title: "Admin Users",
        icon: UserPlus,
        navLink: `${prefix}/staff-management`,
        parent: "Admin Management",
      },
    ],
  },
  {
    id: "faqs",
    title: "Faqs Management",
    icon: HelpCircle,
    navLink: `${prefix}/faq-management`,
  },
  {
    id: "blog-category",
    title: "Blog Management",
    icon: Feather,
    children: [
      {
        id: "blog-list",
        title: "Blogs",
        icon: List,
        navLink: `${prefix}/blog-management`,
        parent: "Role Management",
      },
      {
        id: "blog-category",
        title: "Category",
        icon: Framer,
        navLink: `${prefix}/category-management`,
        parent: "Blog Management",
      },
    ],
  },
  {
    id: "cms",
    title: "CMS Management",
    icon: Layout,
    children: [
      {
        id: "cms",
        title: "Terms & Conditions",
        icon: Type,
        navLink: `${prefix}/cms-management/terms-conditions`,
        parent: "CMS Management",
      },
      {
        id: "cms",
        title: "Privacy Policy",
        icon: Tool,
        navLink: `${prefix}/cms-management/privacy-policy`,
        parent: "CMS Management",
      },
      {
        id: "cms",
        title: "About Us",
        icon: Pocket,
        navLink: `${prefix}/cms-management/about-us`,
        parent: "CMS Management",
      },
    ],
  },
  {
    id: "contact-us",
    title: "Contact Us",
    icon: Phone,
    navLink: `${prefix}/contact-us-enquiry`,
  },
  {
    id: "testimonial",
    title: "Testimonials",
    icon: Star,
    navLink: `${prefix}/testimonial-management`,
  },
  {
    id: "testimonial",
    title: "Form Builder",
    icon: Star,
    navLink: `${prefix}/form-builder`,
  },
];

export default Automation;
