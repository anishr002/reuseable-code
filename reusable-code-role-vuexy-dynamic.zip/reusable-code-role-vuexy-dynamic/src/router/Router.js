import React, { lazy, useEffect } from "react";
import { useRoutes, Navigate, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import BlankLayout from "@layouts/BlankLayout";
import { useLayout } from "@hooks/useLayout";
import { getRoutes } from "./routes/index";
import { getHomeRouteForLoggedInUser } from "../utility/Utils";
import { MAIN_PAGE_TITLE_DEFAULT, PAGE_TITLE } from "../configs/constant";
import PublicRoute from "../@core/components/routes/PublicRoute";

const Login = lazy(() => import("../views/auth/LoginHookForm"));
const Register = lazy(() => import("../views/auth/Register"));
const ForgotPassword = lazy(() =>
  import("../views/auth/ForgotPasswordHookForm")
);
const ResetPassword = lazy(() => import("../views/auth/ResetPasswordFormik"));
const ErrorComponent = lazy(() => import("../views/error/Error"));

const Router = () => {
  const { UserData } = useSelector((state) => state.root.authentication);
  const { layout } = useLayout();
  const location = useLocation();

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const allRoutes = getRoutes(layout, UserData, prefix);

  const getHomeRoute = () => {
    const user = localStorage.getItem("accessToken");
    return user
      ? getHomeRouteForLoggedInUser(user, UserData, prefix)
      : `${prefix}/login`;
  };

  const getErrorElement = () => {
    const user = localStorage.getItem("accessToken");
    return user ? <ErrorComponent /> : <Navigate to={`${prefix}/login`} />;
  };

  const routes = useRoutes([
    {
      path: `${prefix}/`,
      index: true,
      element: <Navigate replace to={getHomeRoute()} />,
      title: PAGE_TITLE.LOGIN,
    },
    {
      path: `${prefix}/login`,
      element: (
        <PublicRoute>
          <Login />
        </PublicRoute>
      ),
      title: PAGE_TITLE.LOGIN,
      meta: { layout: "blank" },
    },
    {
      path: `${prefix}/register`,
      element: <Register />,
      title: PAGE_TITLE.REGISTER,
      meta: { layout: "blank" },
    },
    {
      path: `${prefix}/forgot-password`,
      element: (
        <PublicRoute>
          <ForgotPassword />
        </PublicRoute>
      ),
      title: PAGE_TITLE.FORGOT_PASSWORD,
      meta: { layout: "blank" },
    },
    {
      path: `${prefix}/reset-password`,
      element: (
        <PublicRoute>
          <ResetPassword />
        </PublicRoute>
      ),
      title: PAGE_TITLE.RESET_PASSWORD,
      meta: { layout: "blank" },
    },

    {
      path: `${prefix}/page-not-found`,
      element: <ErrorComponent />,
      // title: PAGE_TITLE.RESET_PASSWORD,
      meta: { layout: "blank" },
    },
    {
      path: "*",
      element: <BlankLayout />,
      children: [{ path: "*", element: getErrorElement() }],
    },
    ...allRoutes,
  ]);

  useEffect(() => {
    if (routes?.props?.match?.route) {
      const isChildren = routes?.props?.match?.route?.children;
      const findPath = routes?.props?.match?.route?.children?.filter((i) =>
        location.pathname?.includes(i.path)
      );
      document.title = isChildren
        ? findPath[0]?.title
        : routes?.props?.match?.route?.title ?? MAIN_PAGE_TITLE_DEFAULT;
    }
  }, [location.pathname, routes]);

  return routes;
};

export default Router;
