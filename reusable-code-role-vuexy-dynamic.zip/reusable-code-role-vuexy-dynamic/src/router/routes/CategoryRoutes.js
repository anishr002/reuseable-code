// ** React Imports
import { lazy } from "react";
import { PAGE_TITLE } from "../../configs/constant";
const CategoryManagement = lazy(() =>
  import("../../views/category-management/index")
);
const AddEdit = lazy(() => import("../../views/category-management/AddEdit"));

// ** Merge Routes
const CategoryRoutes = [
  {
    path: "category-management",
    element: <CategoryManagement />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "blog-category",
    title: PAGE_TITLE.CATEGORY_MANAGEMENT,
  },
  {
    path: "category-management/add",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "blog-category",
    title: PAGE_TITLE.CATEGORY_MANAGEMENT,
  },
  {
    path: "category-management/edit/:id",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "blog-category",
    title: PAGE_TITLE.CATEGORY_MANAGEMENT,
  },
];

export default CategoryRoutes;
