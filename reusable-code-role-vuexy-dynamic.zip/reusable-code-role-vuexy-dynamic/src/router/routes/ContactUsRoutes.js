import { PAGE_TITLE } from "../../configs/constant";
import ContactUs from "../../views/contact-us/ContactUs";

// ** Merge Routes
const ContactUsRoutes = [
  {
    path: "contact-us-enquiry",
    element: <ContactUs />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "contact-us",
    title: PAGE_TITLE.CONTACT_US,
  },
];

export default ContactUsRoutes;
