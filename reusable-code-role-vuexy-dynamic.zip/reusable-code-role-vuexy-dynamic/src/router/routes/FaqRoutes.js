// ** React Imports
import { lazy } from "react";
import { PAGE_TITLE } from "../../configs/constant";
const FaqManagement = lazy(() => import("../../views/faq-management/index"));
const AddEdit = lazy(() => import("../../views/faq-management/AddEdit"));

// ** Merge Routes
const FaqRoutes = [
  {
    path: "faq-management",
    element: <FaqManagement />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "faqs",
    title: PAGE_TITLE.FAQS_MANAGEMENT,
  },
  {
    path: "faq-management/add",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "faqs",
    title: PAGE_TITLE.FAQS_MANAGEMENT,
  },
  {
    path: "faq-management/edit/:id",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "faqs",
    title: PAGE_TITLE.FAQS_MANAGEMENT,
  },
];

export default FaqRoutes;
