// ** React Imports
import { lazy } from "react";
import { MODULE_NAME, PAGE_TITLE } from "../../configs/constant";
import Profile from "../../views/Profile";
import Notifications from "../../views/Notifications";
import FormBuilderReact from "../../views/form-builders/index";
import FormBuilderComponents from "../../views/form-builders/FormBuilderReact";

const Dashboard = lazy(() => import("../../views/Dashboard"));

// ** Merge Routes
const HomeRoutes = [
  {
    path: "dashboard",
    element: <Dashboard />,
    meta: {
      className: "dashboard-aplication",
    },
    id: MODULE_NAME.DASHBOARD,
    title: PAGE_TITLE?.DASHBOARD,
  },
  {
    path: "profile",
    element: <Profile />,
    meta: {
      className: "dashboard-aplication",
    },
    id: "profile",
    title: PAGE_TITLE?.PROFILE,
  },
  {
    path: "notifications",
    element: <Notifications />,
    meta: {
      className: "dashboard-aplication",
    },
    id: "notifications",
    title: PAGE_TITLE?.NOTIFICATION,
  },
  {
    path: `form-builder`,
    element: <FormBuilderReact />,
    title: PAGE_TITLE.RESET_PASSWORD,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "testimonial",
  },
  {
    path: `form-builder/add`,
    element: <FormBuilderComponents />,
    title: PAGE_TITLE.RESET_PASSWORD,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "testimonial",
  },
  {
    path: `form-builder/edit/:id`,
    element: <FormBuilderComponents />,
    title: PAGE_TITLE.RESET_PASSWORD,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "testimonial",
  },
];

export default HomeRoutes;
