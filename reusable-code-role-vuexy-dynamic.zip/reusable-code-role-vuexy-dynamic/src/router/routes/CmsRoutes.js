import { PAGE_TITLE } from "../../configs/constant";
import TermsAndConditions from "../../views/cms-management/TermsAndConditions";
import PrivacyPolicy from "../../views/cms-management/PrivacyPolicy";
import AboutUs from "../../views/cms-management/AboutUs";

// ** Merge Routes
const CmsRoutes = [
  {
    path: "cms-management/terms-conditions",
    element: <TermsAndConditions />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "cms",
    title: PAGE_TITLE.TERMS_CONDITIONS,
  },
  {
    path: "cms-management/privacy-policy",
    element: <PrivacyPolicy />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "cms",
    title: PAGE_TITLE.PRIVACY_POLICY,
  },
  {
    path: "cms-management/about-us",
    element: <AboutUs />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "cms",
    title: PAGE_TITLE.ABOUT_AS,
  },
];

export default CmsRoutes;
