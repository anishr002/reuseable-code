// ** React Imports
import { lazy } from "react";

import AddEdit from "../../views/admin-management/AddEdit";
import { PAGE_TITLE } from "../../configs/constant";

const AdminManagement = lazy(() =>
  import("../../views/admin-management/index")
);

// ** Merge Routes
const AdminStaffRoute = [
  {
    path: "staff-management",
    element: <AdminManagement />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "staffs",
    title: PAGE_TITLE.ADMIN_USER_MANAGEMENT,
  },
  {
    path: "staff-management/add",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "staffs",
    title: PAGE_TITLE.ADMIN_USER_MANAGEMENT,
  },
  {
    path: "staff-management/edit/:id",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "staffs",
    title: PAGE_TITLE.ADMIN_USER_MANAGEMENT,
  },
];

export default AdminStaffRoute;
