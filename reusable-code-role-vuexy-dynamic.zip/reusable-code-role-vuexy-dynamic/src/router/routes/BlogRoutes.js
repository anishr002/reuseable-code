// ** React Imports
import { lazy } from "react";
import { PAGE_TITLE } from "../../configs/constant";

const Blogs = lazy(() => import("../../views/blog-management/index"));
const AddEdit = lazy(() => import("../../views/blog-management/AddEdit"));

// ** Merge Routes
const BlogRoutes = [
  {
    path: "blog-management",
    element: <Blogs />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "blog-list",
    title: PAGE_TITLE.BLOGS_MANAGEMENT,
  },
  {
    path: "blog-management/add",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "blog-list",
    title: PAGE_TITLE.BLOGS_MANAGEMENT,
  },
  {
    path: "blog-management/edit/:id",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "blog-list",
    title: PAGE_TITLE.BLOGS_MANAGEMENT,
  },
];

export default BlogRoutes;
