// ** React Imports
import { lazy } from "react";
import { PAGE_TITLE } from "../../configs/constant";

const Role = lazy(() => import("../../views/role-management/index"));
const AddEditRole = lazy(() => import("../../views/role-management/AddEdit"));

// ** Merge Routes
const RolesRoutes = [
  {
    path: "role-management",
    element: <Role />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "roles",
    title: PAGE_TITLE.ROLE_MANAGEMENT,
  },
  {
    path: "role-management/add",
    element: <AddEditRole />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "roles",
    title: PAGE_TITLE.ROLE_MANAGEMENT,
  },
  {
    path: "role-management/edit/:id",
    element: <AddEditRole />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "roles",
    title: PAGE_TITLE.ROLE_MANAGEMENT,
  },
  {
    path: "role-management/view/:id",
    element: <AddEditRole />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "roles",
    title: PAGE_TITLE.ROLE_MANAGEMENT,
  },
];

export default RolesRoutes;
