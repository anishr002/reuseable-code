// ** React Imports
import { Fragment } from "react";
// ** Layouts
import BlankLayout from "@layouts/BlankLayout";
import LayoutWrapper from "@src/@core/layouts/components/layout-wrapper";
import HorizontalLayout from "@src/layouts/HorizontalLayout";
import VerticalLayout from "@src/layouts/VerticalLayout";

// ** Route Components
import PrivateRoute from "@components/routes/PrivateRoute";
import PublicRoute from "@components/routes/PublicRoute";

// ** Utils
import { isObjEmpty } from "@utils";
import Dashboard from "./Dashboard";

import { MODULE_NAME } from "../../configs/constant";
import AdminStaffRoute from "./AdminUserRoutes";
import BlogRoutes from "./BlogRoutes";
import CategoryRoutes from "./CategoryRoutes";
import CmsRoutes from "./CmsRoutes";
import ContactUsRoutes from "./ContactUsRoutes";
import FaqRoutes from "./FaqRoutes";
import RolesRoutes from "./RolesRoutes";
import TestimonialRoutes from "./TestimonialRoutes";

const getLayout = {
  blank: <BlankLayout />,
  vertical: <VerticalLayout />,
  horizontal: <HorizontalLayout />,
};

// ** Document title
const TemplateTitle = "%s - Vuexy React Admin Template";

const findFirstExistingSection = (userData) => {
  const sectionOrder = [
    MODULE_NAME.DASHBOARD,
    "roles",
    "staffs",
    "faqs",
    "blog-list",
    "blog-category",
    "testimonial",
    "cms",
    "contact-us",
    "profile",
    "notifications",
  ];

  for (const sectionName of sectionOrder) {
    const restOfPagesAdded = Array.isArray(userData.permissions)
      ? [
          ...userData.permissions,
          {
            permissions: ["read", "read-write"],
            name: "profile",
          },
        ]
      : [
          {
            permissions: ["read", "read-write"],
            name: "profile",
          },
        ];

    const foundSection = restOfPagesAdded.reduce((acc, item) => {
      if (acc) {
        return acc;
      }

      if (item.name === sectionName) {
        return item;
      }

      const foundSubModule = item.subModules?.find(
        (subModule) => subModule.name === sectionName
      );
      if (foundSubModule) {
        return foundSubModule;
      }

      return null;
    }, null);

    if (foundSection && foundSection?.permissions?.length > 0) {
      switch (sectionName) {
        case MODULE_NAME.DASHBOARD:
          return `dashboard`;
        case "roles":
          return `role-management`;
        case "staffs":
          return `staff-management`;
        case "profile":
          return `profile`;
        case "faqs":
          return "faq-management";
        case "blog-list":
          return "blog-management";
        case "blog-category":
          return "blog-category";
        case "testimonial":
          return "testimonial-management";
        case "cms":
          return "cms-management";
        case "contact-us":
          return "contact-us-list";
        case "notifications":
          return "notifications";
        default:
          return `login`;
      }
    }
  }
  // Return the login path
  return `/login`;
};

const DefaultRoute = "/dashboard";

// ** Merge Routes
const AllRoutesAutomation = [
  Dashboard,
  RolesRoutes,
  AdminStaffRoute,
  FaqRoutes,
  CategoryRoutes,
  BlogRoutes,
  CmsRoutes,
  ContactUsRoutes,
  TestimonialRoutes,
];

// ** Merge Routes
const Routes = AllRoutesAutomation.flat();

const getRouteMeta = (route) => {
  if (isObjEmpty(route.element.props)) {
    if (route.meta) {
      return { routeMeta: route.meta };
    } else {
      return {};
    }
  }
};

const mergeLayoutRoutes = (layout, defaultLayout, userData) => {
  const LayoutRoutes = [];

  if (Routes) {
    Routes.filter((route) => {
      const sectionExists = userData?.permissions?.reduce((acc, item) => {
        if (acc) {
          return acc;
        } // If a match is found, return it

        if (item.name === route?.id) {
          return item;
        }

        const foundSubModule = item.subModules?.find(
          (subModule) => subModule.name === route?.id
        );
        if (foundSubModule) {
          return foundSubModule;
        }

        return null;
      }, null);

      let isBlank = false;
      const routeAdd = () => {
        let RouteTag = PrivateRoute;

        // ** Check for public or private route
        if (route?.meta) {
          if (route?.meta?.layout === "blank") {
            isBlank = true;
          } else {
            isBlank = false;
          }

          RouteTag = route?.meta?.publicRoute ? PublicRoute : PrivateRoute;
        }

        if (route?.element) {
          const Wrapper =
            isObjEmpty(route?.element?.props) && isBlank === false
              ? LayoutWrapper
              : Fragment;

          route.element = (
            <Wrapper {...(isBlank === false ? getRouteMeta(route) : {})}>
              <RouteTag route={route}>{route.element}</RouteTag>
            </Wrapper>
          );
        }

        // Push route to LayoutRoutes
        LayoutRoutes.push(route);
      };

      if (sectionExists && sectionExists?.permissions?.length > 0) {
        if (
          route?.meta?.layout === layout ||
          ((route?.meta === undefined || route?.meta?.layout === undefined) &&
            defaultLayout === layout)
        ) {
          // const userRole = "all" //this is static for now, it will dynamic by api

          if (sectionExists?.permissions?.length > 0) {
            routeAdd();
          }
        }
        return LayoutRoutes;
      } else {
        const routePermission = route?.id;

        if (
          routePermission === "profile" ||
          routePermission === "notifications"
        ) {
          routeAdd();
        }
      }
    });
  }
  return LayoutRoutes;
};

const getRoutes = (layout, userData, prefix) => {
  const defaultLayout = layout || "vertical";
  const layouts = ["vertical", "horizontal", "blank"];

  const AllRoutes = [];

  layouts.forEach((layoutItem) => {
    const LayoutRoutes = mergeLayoutRoutes(layoutItem, defaultLayout, userData);

    AllRoutes.push({
      path: prefix === "" ? "" : prefix.replace("/", ""),
      element: getLayout[layoutItem] || getLayout[defaultLayout],
      children: LayoutRoutes,
    });
  });
  return AllRoutes;
};

export {
  DefaultRoute,
  findFirstExistingSection,
  getRoutes,
  Routes,
  TemplateTitle,
};
