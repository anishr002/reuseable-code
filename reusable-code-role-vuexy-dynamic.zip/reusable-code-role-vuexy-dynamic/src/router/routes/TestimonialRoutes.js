// ** React Imports
import { lazy } from "react";
import { PAGE_TITLE } from "../../configs/constant";
const TestimonialManagement = lazy(() =>
  import("../../views/testimonial-management/index")
);
const AddEdit = lazy(() =>
  import("../../views/testimonial-management/AddEdit")
);

// ** Merge Routes
const TestimonialRoutes = [
  {
    path: "testimonial-management",
    element: <TestimonialManagement />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "testimonial",
    title: PAGE_TITLE.TESTIMONIAL_MANAGEMENT,
  },
  {
    path: "testimonial-management/add",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "testimonial",
    title: PAGE_TITLE.TESTIMONIAL_MANAGEMENT,
  },
  {
    path: "testimonial-management/edit/:id",
    element: <AddEdit />,
    meta: {
      className: "dashboard-org-admin",
    },
    id: "testimonial",
    title: PAGE_TITLE.TESTIMONIAL_MANAGEMENT,
  },
];

export default TestimonialRoutes;
