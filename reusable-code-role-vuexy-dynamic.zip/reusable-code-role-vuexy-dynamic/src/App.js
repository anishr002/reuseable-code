import React, { Suspense } from "react";

// ** Router Import
import Router from "./router/Router";
import Spinner from "./@core/components/spinner/Fallback-spinner";
import { SocketContextProvider } from "./utility/context/SocketProvider";

const App = () => {
  return (
    <Suspense fallback={<Spinner />}>
      <SocketContextProvider>
        <Router />
      </SocketContextProvider>
    </Suspense>
  );
};

export default App;
