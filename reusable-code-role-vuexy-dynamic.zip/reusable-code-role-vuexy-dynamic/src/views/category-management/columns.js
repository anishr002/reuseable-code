import { Edit2, Trash2 } from "react-feather";
import { Link } from "react-router-dom";
import { Badge } from "reactstrap";
import { deleteCategoryAPI } from "../../redux/categoryManagement";
import { showAlert } from "../../@core/components/CutomAlert/CutomAlert";

export const columns = [
  {
    name: "Name",
    minWidth: "150px",
    sortable: "name",
    cell: (row) => <div className="truncate-text">{row?.name}</div>,
  },
  {
    name: "Status",
    sortable: "status",
    minWidth: "150px",
    selector: (row) => {
      return (
        <Badge
          color={String(row?.status) === "1" ? "success" : "danger"}
          className={String(row?.status) === "1" ? "custom-badge" : ""}
          pill
        >
          {String(row?.status) === "1" ? "Active" : "InActive"}
        </Badge>
      );
    },
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => {
      return (
        <div className="d-flex">
          {row?.writePermission?.includes("edit") ? (
            <Link to={`edit/${row?.id}`} className="text-decoration-none">
              <Edit2
                size={16}
                className="me-2 cursor-pointer icon-color-cust"
              />
            </Link>
          ) : (
            <Edit2
              size={16}
              className="me-2 cursor-not-allowed icon-color-cust"
            />
          )}

          <Trash2
            size={16}
            color="red"
            className={
              row?.writePermission?.includes("delete")
                ? "cursor-pointer icon-color-cust"
                : "cursor-not-allowed icon-color-cust"
            }
            onClick={
              row?.writePermission?.includes("delete")
                ? () => showAlert(row?.id, deleteCategoryAPI, "Category")
                : () => {}
            }
          />
        </div>
      );
    },
  },
];
