import Spinner from "@components/spinner/Loading-spinner";
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect } from "react";
import { Controller, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
} from "reactstrap";
import * as Yup from "yup";

import {
  addCategoryAPI,
  editCategoryAPI,
  getCategoryDetailesAPI,
} from "../../redux/categoryManagement";
import withPermissionCheck from "../withPermissionCheck";

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { singleCategoryDetailes } = useSelector(
    (state) => state?.root?.CategorySlice
  );

  const isEditRoute = () => location.pathname.includes("edit");
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validationSchema = Yup.object().shape({
    category_name: Yup.string()
      .trim()
      .required("Category Name is required")
      .max(50, "Category Name cannot exceed 50 characters"),
    status_of_category: Yup.object().nullable().required("Status is required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      category_name: "",
      status_of_category: null,
    },
  });

  useEffect(() => {
    if (isEditRoute()) {
      dispatch(getCategoryDetailesAPI(id));
    }
  }, [dispatch, id]);

  useEffect(() => {
    if (isEditRoute()) {
      if (singleCategoryDetailes) {
        setValue(
          "status_of_category",
          singleCategoryDetailes?.status === 1
            ? { value: 1, label: "Active" }
            : { value: 2, label: "Inactive" }
        );
        setValue("category_name", singleCategoryDetailes?.name);
      }
    }
  }, [singleCategoryDetailes, setValue]);

  const onSubmit = (data) => {
    const payload = {
      name: data?.category_name,
      status: data?.status_of_category?.value,
    };

    isEditRoute()
      ? dispatch(editCategoryAPI(payload, navigate, id))
      : dispatch(addCategoryAPI(payload, navigate));
  };

  return (
    <Card>
      <CardHeader>
        <CardText tag="h3">{id ? "Edit" : "Add"} Category</CardText>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-1" onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="category_name">
                    Category Name<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="category_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.category_name}
                        placeholder="ex. Lifestyle & Wellness"
                        {...field}
                      />
                    )}
                  />
                  {errors.category_name && (
                    <FormFeedback>{errors.category_name.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="status_of_category">
                    Status<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="status_of_category"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={[
                          { value: 1, label: "Active" },
                          { value: 2, label: "Inactive" },
                        ]}
                        className={`react-select ${
                          errors.status_of_category && "is-invalid"
                        }`}
                        classNamePrefix="select"
                        isSearchable
                        placeholder="Select Status"
                      />
                    )}
                  />
                  {errors.status_of_category && (
                    <FormFeedback className="d-block">
                      {errors.status_of_category.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              <Link to={`${prefix}/category-management`}>
                <Button color="primary" className="me-1">
                  Cancel
                </Button>
              </Link>
              <Button color="primary" type="submit" className="d-flex">
                {isEditRoute() ? "Save" : "Add"}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

const CategoryAddEditWithPermission = withPermissionCheck(
  AddEdit,
  "blog-category",
  "/category-management"
);

export default CategoryAddEditWithPermission;
