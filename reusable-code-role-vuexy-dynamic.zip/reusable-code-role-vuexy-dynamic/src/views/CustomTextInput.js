import React from "react";

const CustomTextInput = ({ label, isRequired, customValidation, onChange }) => {
  const [value, setValue] = React.useState("");
  const [error, setError] = React.useState("");

  const handleChange = (e) => {
    const newValue = e.target.value;
    setValue(newValue);

    // Custom validation logic
    const validationError = customValidation ? customValidation(newValue) : "";
    if (isRequired && !newValue) {
      setError(`${label} is required`);
    } else if (validationError) {
      setError(validationError);
    } else {
      setError("");
    }

    // Propagate change
    onChange(newValue);
  };

  return (
    <div>
      <input type="text" value={value} onChange={handleChange} />
      {error && <div className="error">{error}</div>}
    </div>
  );
};

export default CustomTextInput;
