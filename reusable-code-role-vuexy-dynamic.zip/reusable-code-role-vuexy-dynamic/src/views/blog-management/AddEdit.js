import Spinner from "@components/spinner/Loading-spinner";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useEffect, useRef, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
} from "reactstrap";
import * as Yup from "yup";
import placholderImg from "../../assets/images/pages/placeholder-thumbnail.webp";
import {
  addBlogAPI,
  editBlogAPI,
  getBlogDetailesAPI,
  getCategoryDropDownAPI,
} from "../../redux/blogManagement";
import { onSetLogo } from "../../utility/Utils";
import withPermissionCheck from "../withPermissionCheck";

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { singleBlogDetailes, CategoryDropdown } = useSelector(
    (state) => state?.root?.blogManagementSlice
  );
  const { skin } = useSelector((state) => state?.root?.layout);
  const quillRef = useRef(null);
  const [editorError, setEditorError] = useState(false);

  const [avatarForHeader, setAvatarForHeader] = useState("");
  const [avatarForThumbnail, setAvatarForThumbnail] = useState("");

  const [headerImg, setHeaderImg] = useState(null);
  const [thumbnailImg, setThumbnailImg] = useState(null);

  const isEditRoute = () => location.pathname.includes("edit");
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validationSchema = Yup.object().shape({
    title: Yup.string()
      .trim()
      .required("Title is required")
      .max(100, "Title cannot exceed 100 characters"),
    content: Yup.string().trim().required("Content is required"),
    status: Yup.object().nullable().required("Status is required"),
    category: Yup.object().nullable().required("Category is required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      title: "",
      content: "",
      status: null,
    },
  });

  useEffect(() => {
    if (isEditRoute()) {
      dispatch(getBlogDetailesAPI(id));
    }
    dispatch(getCategoryDropDownAPI());
  }, [dispatch, id]);

  useEffect(() => {
    if (isEditRoute() && singleBlogDetailes) {
      setValue("title", singleBlogDetailes?.title);
      setValue("content", singleBlogDetailes?.content);
      setValue(
        "status",
        singleBlogDetailes?.status === 1
          ? { value: 1, label: "Active" }
          : { value: 2, label: "Inactive" }
      );

      const categorySelect = CategoryDropdown?.find(
        (item) => item?._id === singleBlogDetailes?.category_id?._id
      );
      setValue("category", {
        value: categorySelect?._id,
        label: categorySelect?.name,
      });
      setAvatarForHeader(singleBlogDetailes?.header_image);
      setHeaderImg(singleBlogDetailes?.header_image);
      setThumbnailImg(singleBlogDetailes?.thumbnail_image);
      setAvatarForThumbnail(singleBlogDetailes?.thumbnail_image);
    }
  }, [singleBlogDetailes, setValue]);

  const handleEditorChange = (content) => {
    const trimmedContent = content.trim();
    setValue("content", content);

    const length = quillRef?.current?.getEditor()?.getText().trim();
    const onlyWhitespace = trimmedContent.length === 0;

    // Trigger error if content is empty or only contains spaces
    setEditorError(length <= 1 || onlyWhitespace);
  };

  const handleKeyUp = () => {
    const editor = quillRef?.current?.getEditor();
    const content = editor?.getText()?.trim(); // Get text content without HTML tags
    const contentLength = editor?.getLength(); // Get content length (Quill editor counts characters including whitespaces)

    // Update the form value with the editor's current content
    setValue("content", editor.root.innerHTML);

    // Check if the content is only whitespace or empty
    const onlyWhitespace = content.length === 0;

    // Set error state if content is invalid
    setEditorError(contentLength <= 1 || onlyWhitespace);

    // Clear errors if content is valid
    if (contentLength > 1 && !onlyWhitespace) {
      clearErrors("content");
    }
  };

  const onSubmit = (data) => {
    const payload = {
      title: data?.title,
      content: data?.content,
      status: data?.status?.value,
      category_id: data?.category?.value,
    };

    const length = quillRef?.current?.getEditor()?.getLength() || 0;
    const trimmedContent = quillRef?.current?.getEditor()?.getText().trim();
    const onlyWhitespace = trimmedContent.length === 0;

    // Validate editor content before submitting
    if (length <= 1 || onlyWhitespace) {
      setEditorError(true);
      return;
    }

    if (typeof headerImg !== "string") {
      payload["header_image"] = headerImg;
    }
    if (typeof thumbnailImg !== "string") {
      payload["thumbnail_image"] = thumbnailImg;
    }

    // Uncomment for actual API calls
    isEditRoute()
      ? dispatch(editBlogAPI(payload, navigate, id))
      : dispatch(addBlogAPI(payload, navigate));
  };

  const handleImgReset = (type) => {
    if (type === "header") {
      setAvatarForHeader("");
      setHeaderImg(null);
    } else {
      setAvatarForThumbnail("");
      setThumbnailImg(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardText tag="h3">{id ? "Edit" : "Add"} Blog</CardText>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-1" onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="title">
                    Title<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="title"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.title}
                        placeholder="Enter title"
                        {...field}
                      />
                    )}
                  />
                  {errors.title && (
                    <FormFeedback>{errors.title.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="status">
                    Status<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="status"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={[
                          { value: 1, label: "Active" },
                          { value: 2, label: "Inactive" },
                        ]}
                        className={`react-select ${
                          errors.status && "is-invalid"
                        }`}
                        classNamePrefix="select"
                        isSearchable
                        placeholder="Select Status"
                      />
                    )}
                  />
                  {errors.status && (
                    <FormFeedback className="d-block">
                      {errors.status.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="category">
                    Category<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="category"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={CategoryDropdown?.map((i) => ({
                          value: i?._id,
                          label: i?.name,
                        }))}
                        className={`react-select ${
                          errors.category && "is-invalid"
                        }`}
                        classNamePrefix="select"
                        isSearchable
                        placeholder="Select Category"
                      />
                    )}
                  />
                  {errors.category && (
                    <FormFeedback className="d-block">
                      {errors.category.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <Row className="mt-2">
              <Col sm="6">
                <Label className="form-label" for="content">
                  Thumbnail Image
                </Label>
                <div className="border-end pe-3 d-flex align-item-center mt-75 mb-2">
                  <div className="me-2">
                    <img
                      className="rounded-circle me-100"
                      src={avatarForThumbnail || placholderImg}
                      height="100"
                      width="100"
                      //   onError={handleImageError}
                      alt="thumbnail-img"
                    />
                  </div>
                  <div className="d-flex flex-column justify-content-center ms-1">
                    <Button
                      tag={Label}
                      className="mb-75  py-1 px-2"
                      size="sm"
                      color="primary"
                      outline
                    >
                      Upload
                      <Input
                        type="file"
                        onChange={(e) =>
                          onSetLogo(e, setThumbnailImg, setAvatarForThumbnail)
                        }
                        hidden
                        accept="image/*"
                      />
                    </Button>
                    <Button
                      color="flat-danger"
                      size="sm"
                      onClick={() => handleImgReset("thumbnail")}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              </Col>

              <Col sm="6">
                <Label className="form-label" for="content">
                  Header Image
                </Label>
                <div className="border-end pe-3 d-flex align-item-center mt-75 mb-2">
                  <div className="me-2">
                    <img
                      className="rounded-circle me-100"
                      src={avatarForHeader || placholderImg}
                      height="100"
                      width="100"
                      //   onError={handleImageError}
                      alt="heder-img"
                    />
                  </div>
                  <div className="d-flex flex-column justify-content-center ms-1">
                    <Button
                      tag={Label}
                      className="mb-75  py-1 px-2"
                      size="sm"
                      color="primary"
                      outline
                    >
                      Upload
                      <Input
                        type="file"
                        onChange={(e) =>
                          onSetLogo(e, setHeaderImg, setAvatarForHeader)
                        }
                        hidden
                        accept="image/*"
                      />
                    </Button>
                    <Button
                      color="flat-danger"
                      size="sm"
                      onClick={() => handleImgReset("header")}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              </Col>
            </Row>

            <Row className="mt-2">
              <Col xs={12} className="mt-1">
                <Label className="form-label" for="content">
                  Content<span className="text-danger">*</span>
                </Label>
                <div style={{ textAlign: "left" }}>
                  <Controller
                    name="content"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <ReactQuill
                        ref={quillRef}
                        theme="snow"
                        value={field.value}
                        onChange={handleEditorChange}
                        onKeyUp={handleKeyUp}
                        modules={modules}
                        formats={formats}
                        className={`react-quill-container ${
                          skin === "dark" ? "dark-theme" : "light-theme"
                        }`}
                      />
                    )}
                  />
                  {(errors.content || editorError) && (
                    <FormFeedback className="d-block">
                      {errors.content?.message || "Content is required"}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              <Link to={`${prefix}/blog-management`}>
                <Button color="primary" className="me-1">
                  Cancel
                </Button>
              </Link>
              <Button color="primary" type="submit" className="d-flex">
                {isEditRoute() ? "Save" : "Add"}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

// Modules and formats for the ReactQuill editor
const modules = {
  toolbar: [
    [{ header: "1" }, { header: "2" }, { font: [] }],
    [{ list: "ordered" }, { list: "bullet" }],
    ["bold", "italic", "underline", "strike", "blockquote"],
    [{ align: [] }, { color: [] }, { background: [] }],
    [{ script: "sub" }, { script: "super" }],
    ["link", "image", "video"],
    ["clean"],
  ],
};

const formats = [
  "header",
  "font",
  "list",
  "bullet",
  "bold",
  "italic",
  "underline",
  "strike",
  "blockquote",
  "align",
  "color",
  "background",
  "script",
  "link",
  "image",
  "video",
];

const BlogAddEditWithPermission = withPermissionCheck(
  AddEdit,
  "blog-list",
  "/blog-management"
);

export default BlogAddEditWithPermission;
