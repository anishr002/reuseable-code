import "@styles/react/libs/tables/react-dataTable-component.scss";
import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Button, Card, CardHeader, CardText } from "reactstrap";
import CustomHeader from "../../@core/components/customHeader/customHeader";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";
import {
  getBlogsApiCall,
  getCategoryDropDownAPI,
  setPaginationBlogs,
} from "../../redux/blogManagement";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import { columns } from "./columns";

const Blogs = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { blogsData, paginationBlog, CategoryDropdown } = useSelector(
    (state) => state?.root?.blogManagementSlice
  );
  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const { UserData } = useSelector((state) => state.root?.authentication);

  const [currentPage, setCurrentPage] = useState(paginationBlog?.page);
  const [pageSize, setPageSize] = useState(paginationBlog?.limit);
  const [sortBy, setSortBy] = useState(paginationBlog?.sortBy);
  const [orderBy, setOrderBy] = useState(paginationBlog?.orderBy);
  const [defaultStatusSelect, setDefaultStatusSelect] = useState(null);
  const [defaultCategorySelect, setDefaultCategorySelect] = useState(null);

  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const writePermission = UserData?.permissions?.reduce((acc, section) => {
    if (acc) {
      return acc;
    }
    if (section.name === "blog-list") {
      return section;
    }
    const foundSubModule = section.subModules?.find(
      (subModule) => subModule.name === "blog-list"
    );
    if (foundSubModule) {
      return foundSubModule;
    }
    return null;
  }, null);

  const data = blogsData?.data?.map((item) => ({
    ...item,
    title: item?.title,
    category: item?.category_id?.name,
    id: item?._id,
    status: item?.status,
    writePermission: writePermission?.permissions,
  }));

  const statusDropdownData = [
    { value: 1, label: "Active" },
    { value: 2, label: "InActive" },
  ];

  useEffect(() => {
    dispatch(getCategoryDropDownAPI());
  }, []);

  useEffect(() => {
    dispatch(
      setPaginationBlogs({
        page: currentPage,
        limit: pageSize,
        sortBy,
        orderBy,
      })
    );
    dispatch(
      getBlogsApiCall({
        page: currentPage,
        limit: pageSize,
        sortBy: `${sortBy}:${orderBy}`,
        search: searchValue,
        filterByStatus: defaultStatusSelect?.value,
        filterByCategory: defaultCategorySelect?.value,
      })
    );
  }, [
    currentPage,
    pageSize,
    sortBy,
    orderBy,
    debouncedValue,
    defaultStatusSelect,
    defaultCategorySelect,
  ]);

  const handleSort = (column, order) => {
    setSortBy(column?.sortable);
    setOrderBy(order);
  };

  const changePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handleStatusChange = (e) => {
    setDefaultStatusSelect(e);
  };
  const handleCategoryChange = (e) => {
    setDefaultCategorySelect(e);
  };
  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Blogs</CardText>
        {writePermission?.permissions?.length > 0 &&
          writePermission?.permissions.includes("create") && (
            <Button
              color="primary"
              className="d-flex ms-auto "
              onClick={() => navigate("add")}
            >
              ADD
            </Button>
          )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationBlog.limit}
          paginationTotalRows={blogsData?.total}
          currentPage={paginationBlog.page}
          paginationDefaultPage={paginationBlog.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={changePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          sortIcon={<ChevronDown size={10} />}
          noDataComponent={<NoDataComponent />}
          data={data}
          onSort={handleSort}
          persistTableHead={true}
          sortServer
          paginationServer
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handleFilter}
              StatusFilter={statusDropdownData}
              is_filter={true}
              is_more={true}
              defaultStatusSelect={defaultStatusSelect}
              setDefaultStatusSelect={handleStatusChange}
              defaultCategorySelect={defaultCategorySelect}
              setDefaultCategorySelect={handleCategoryChange}
              CategoryFilter={CategoryDropdown}
            />
          }
        />
      </div>
    </Card>
  );
};

export default Blogs;
