import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

const withPermissionCheck = (
  WrappedComponent,
  permissionType,
  redirectPath
) => {
  return (props) => {
    const navigate = useNavigate();
    const location = useLocation();

    const { UserData } = useSelector((state) => state.root?.authentication);

    const isEditRoute = () => location.pathname.includes("edit");

    const hasCreatePermission = UserData?.permissions?.some((section) => {
      if (section.name === permissionType) {
        return section.permissions.includes("create");
      }
      return section.subModules?.some(
        (subModule) =>
          subModule.name === permissionType &&
          subModule.permissions.includes("create")
      );
    });

    const hasEditPermission = UserData?.permissions?.some((section) => {
      if (section.name === permissionType) {
        return section.permissions.includes("edit");
      }
      return section.subModules?.some(
        (subModule) =>
          subModule.name === permissionType &&
          subModule.permissions.includes("edit")
      );
    });

    useEffect(() => {
      // Redirect if trying to edit but no edit permission
      if (isEditRoute() && !hasEditPermission) {
        navigate(redirectPath);
      }

      // Redirect if trying to add but no create permission
      if (!isEditRoute() && !hasCreatePermission) {
        navigate(redirectPath);
      }
    }, [
      hasCreatePermission,
      hasEditPermission,
      navigate,
      props.match?.params?.id,
    ]);

    return hasCreatePermission || hasEditPermission ? (
      <WrappedComponent {...props} />
    ) : null;
  };
};

export default withPermissionCheck;
