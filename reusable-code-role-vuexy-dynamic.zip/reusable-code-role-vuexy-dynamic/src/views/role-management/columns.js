import { Edit2, Eye, Trash2 } from "react-feather";
import { Link } from "react-router-dom";
import { Badge } from "reactstrap";
import { deleteRoleAPI } from "../../redux/roleManagement";
import { showAlert } from "../../@core/components/CutomAlert/CutomAlert";

export const columns = [
  {
    name: "Role",
    minWidth: "150px",
    sortable: "role_name",
    cell: (row) => <div className="truncate-text">{row?.role_name}</div>,
  },
  {
    name: "Status",
    sortable: "status",
    minWidth: "150px",
    selector: (row) => {
      return (
        <Badge
          color={String(row?.status) === "1" ? "success" : "danger"}
          className={String(row?.status) === "1" ? "custom-badge" : ""}
          pill
        >
          {String(row?.status) === "1" ? "Active" : "InActive"}
        </Badge>
      );
    },
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => {
      return row?.role_name === "Super Admin" ? (
        <div className="d-flex"></div>
      ) : (
        <div className="d-flex">
          {row?.writePermission?.includes("edit") ? (
            <Link to={`edit/${row?.id}`} className="text-decoration-none">
              <Edit2
                size={16}
                className="me-2 cursor-pointer icon-color-cust"
              />
            </Link>
          ) : (
            <Edit2
              size={16}
              className="me-2 cursor-not-allowed icon-color-cust"
            />
          )}

          <Trash2
            size={16}
            color="red"
            className={
              row?.writePermission?.includes("delete")
                ? "me-2 cursor-pointer icon-color-cust"
                : "me-2 cursor-not-allowed icon-color-cust"
            }
            onClick={
              row?.writePermission?.includes("delete")
                ? () => showAlert(row?.id, deleteRoleAPI, "Role")
                : () => {}
            }
          />

          <Link to={`view/${row?.id}`} className="text-decoration-none">
            <Eye
              size={16}
              color="black"
              className="cursor-pointer icon-color-cust"
            />
          </Link>
        </div>
      );
    },
  },
];
