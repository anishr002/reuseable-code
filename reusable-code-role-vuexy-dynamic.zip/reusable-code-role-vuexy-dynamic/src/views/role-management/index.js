import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { columns } from "./columns";
import { Card, Button, CardHeader, CardText } from "reactstrap";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getRolesAPI, setPaginationRole } from "../../redux/roleManagement";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import CustomHeader from "../../@core/components/customHeader/customHeader";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";
import "@styles/react/libs/tables/react-dataTable-component.scss";

const Role = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { RolesList, paginationRole } = useSelector(
    (state) => state?.root?.RoleManagement
  );

  const { UserData } = useSelector((state) => state.root?.authentication);
  const [currentPage, setCurrentPage] = useState(paginationRole?.page);
  const [pageSize, setPageSize] = useState(paginationRole?.limit);
  const [sortBy, setSortBy] = useState(paginationRole?.sortBy);
  const [orderBy, setOrderBy] = useState(paginationRole?.orderBy);
  const [defaultStatusSelect, setDefaultStatusSelect] = useState(null);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);

  const writePermission = UserData?.permissions?.reduce((acc, section) => {
    if (acc) {
      return acc;
    } // If a match is found, return it
    if (section.name === "roles") {
      return section;
    }
    const foundSubModule = section.subModules?.find(
      (subModule) => subModule.name === "roles"
    );
    if (foundSubModule) {
      return foundSubModule;
    }
    return null;
  }, null);

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const data = RolesList?.data?.map((item) => ({
    role_name: item?.role_name,
    id: item?._id,
    status: item?.status,
    writePermission: writePermission?.permissions,
  }));

  const statusDropdownData = [
    { value: 1, label: "Active" },
    { value: 2, label: "InActive" },
  ];

  useEffect(() => {
    dispatch(
      setPaginationRole({
        page: currentPage,
        limit: pageSize,
        sortBy,
        orderBy,
      })
    );
    dispatch(
      getRolesAPI({
        page: currentPage,
        limit: pageSize,
        sortBy: `${sortBy}:${orderBy}`,
        search: searchValue,
        filterByStatus: defaultStatusSelect?.value,
      })
    );
  }, [
    currentPage,
    pageSize,
    sortBy,
    orderBy,
    debouncedValue,
    defaultStatusSelect,
  ]);

  const handleSort = (column, order) => {
    setSortBy(column?.sortable);
    setOrderBy(order);
  };

  const chnagePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handleStatusChange = (e) => {
    setDefaultStatusSelect(e);
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Admin User Roles</CardText>
        {writePermission?.permissions?.length > 0 &&
          writePermission?.permissions.includes("create") && (
            <Button
              color="primary"
              className="d-flex ms-auto "
              onClick={() => navigate("add")}
            >
              ADD
            </Button>
          )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationRole.limit}
          paginationTotalRows={RolesList?.total}
          currentPage={paginationRole.page}
          paginationDefaultPage={paginationRole.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={chnagePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          noDataComponent={<NoDataComponent />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={handleSort}
          persistTableHead={true}
          sortServer
          paginationServer
          // customStyles={customStyles}
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handleFilter}
              StatusFilter={statusDropdownData}
              is_filter={true}
              defaultStatusSelect={defaultStatusSelect}
              setDefaultStatusSelect={handleStatusChange}
            />
          }
        />
      </div>
    </Card>
  );
};

export default Role;
