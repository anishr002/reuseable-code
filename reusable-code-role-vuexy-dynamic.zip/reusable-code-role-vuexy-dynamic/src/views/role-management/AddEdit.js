import Spinner from "@components/spinner/Loading-spinner";
import { yupResolver } from "@hookform/resolvers/yup";
import { Fragment, useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
} from "reactstrap";
import * as Yup from "yup";
import {
  addRoleAPI,
  editRoleAPI,
  getModuleListAPI,
  getRoleDetailestAPI,
} from "../../redux/roleManagement";
import withPermissionCheck from "../withPermissionCheck";

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { singleRoleDetailes, ModuleListing } = useSelector(
    (state) => state?.root?.RoleManagement
  );
  const { skin } = useSelector((state) => state?.root?.layout);

  const [permissions, setPermissions] = useState({});

  const isEdit = () => location.pathname.includes("edit");
  const isView = () => location.pathname.includes("view");
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validation_schema = Yup.object().shape({
    role_name: Yup.string()
      .trim()
      .required("Role is required")
      .max(100, "Role cannot exceed 100 characters"),
    status_of_role: Yup.object().nullable().required("Status is required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(validation_schema),
    defaultValues: {
      role_name: "",
      status_of_role: null,
    },
  });

  useEffect(() => {
    if (isEdit() || isView()) {
      dispatch(getRoleDetailestAPI(id));
    }
    dispatch(getModuleListAPI());
  }, [dispatch, id]);

  useEffect(() => {
    if (isEdit() || isView()) {
      if (singleRoleDetailes) {
        setValue(
          "status_of_role",
          singleRoleDetailes?.status === 1
            ? { value: 1, label: "Active" }
            : { value: 2, label: "Inactive" }
        );
        setValue("role_name", singleRoleDetailes?.role_name);

        const initialPermissions = {};
        singleRoleDetailes?.permissions?.forEach((module) => {
          if (module.subModules.length > 0) {
            module.subModules.forEach((subModule) => {
              initialPermissions[subModule.name] = subModule.permissions.reduce(
                (acc, permission) => {
                  acc[permission] = true;
                  return acc;
                },
                {}
              );
            });
          } else {
            initialPermissions[module.name] = module.permissions.reduce(
              (acc, permission) => {
                acc[permission] = true;
                return acc;
              },
              {}
            );
          }
        });
        setPermissions(initialPermissions);
      }
    } else if (ModuleListing.length > 0) {
      const initialPermissions = {};
      ModuleListing.forEach((module) => {
        if (module.subModules.length > 0) {
          module.subModules.forEach((subModule) => {
            initialPermissions[subModule.name] = { view: true };
          });
        } else {
          initialPermissions[module.name] = { view: true };
        }
      });
      setPermissions(initialPermissions);
    }
  }, [ModuleListing, singleRoleDetailes, setValue]);

  const handleCheckboxChange = (role, permissionType) => {
    setPermissions((prevPermissions) => {
      const updatedPermissions = {
        ...prevPermissions[role],
        [permissionType]: !prevPermissions[role]?.[permissionType],
      };

      if (permissionType !== "view" && updatedPermissions[permissionType]) {
        updatedPermissions.view = true;
      }

      if (permissionType === "view" && !updatedPermissions.view) {
        updatedPermissions.edit = false;
        updatedPermissions.delete = false;
        updatedPermissions.create = false;
      }

      const isAnyOtherPermissionSelected =
        updatedPermissions.edit ||
        updatedPermissions.delete ||
        updatedPermissions.create;
      if (isAnyOtherPermissionSelected) {
        updatedPermissions.view = true;
      }

      return {
        ...prevPermissions,
        [role]: updatedPermissions,
      };
    });
  };

  const convertToPermissionsArray = () => {
    const permissionsArray = ModuleListing.map((module) => {
      let subModulesArray = [];

      if (module.subModules && module.subModules.length > 0) {
        subModulesArray = module.subModules.map((subModule) => ({
          name: subModule.name,
          permissions: Object.entries(permissions[subModule.name] || {})
            .filter(([key, value]) => value)
            .map(([key]) => key),
        }));
      }

      return {
        module: module.name,
        subModules: subModulesArray.length > 0 ? subModulesArray : [],
        permissions: !module.subModules.length
          ? Object.entries(permissions[module.name] || {})
              .filter(([key, value]) => value)
              .map(([key]) => key)
          : [],
      };
    });

    return permissionsArray;
  };

  const on_submit = (data) => {
    const payload = {
      role_name: data?.role_name,
      status: data?.status_of_role?.value,
      permissions: convertToPermissionsArray(),
    };

    isEdit()
      ? dispatch(editRoleAPI(payload, navigate, id))
      : dispatch(addRoleAPI(payload, navigate));
  };

  const titleDynamic = () => {
    if (isView()) {
      return "View Role";
    }
    return id ? "Edit Role" : "Add Role";
  };

  const checkExistanceItem = (permissions) => {
    let permissionsResult = permissions ? [...permissions] : []; // Example array

    const requiredPermissions = ["view", "create", "edit", "delete"];

    // Add any missing permissions to the array
    requiredPermissions.forEach((permission) => {
      if (!permissions.includes(permission)) {
        permissionsResult.push(permission);
      }
    });

    return permissionsResult;
  };

  const ensureFourElements = (perm = []) => {
    const requiredPermissions = ["view", "create", "edit", "delete"];

    // Map through requiredPermissions and check if the perm array has the required permission.
    // If it does, keep it; otherwise, insert an empty string.
    const updatedPermissions = requiredPermissions.map((permItem) =>
      perm.includes(permItem) ? permItem : ""
    );

    return updatedPermissions;
  };

  return (
    <Card>
      <CardHeader>
        <CardText tag="h3">{titleDynamic()}</CardText>
        {isView() && (
          <Button
            color="primary"
            tag={Link}
            to={`${prefix}/role-management`}
            className="me-2 mt-3"
          >
            Back
          </Button>
        )}
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-1" onSubmit={handleSubmit(on_submit)}>
            <Row>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="role_name">
                    Role{!isView() && <span className="text-danger">*</span>}
                  </Label>
                  <Controller
                    name="role_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.role_name}
                        placeholder="Role"
                        {...field}
                        disabled={isView()}
                      />
                    )}
                  />
                  {errors.role_name && (
                    <FormFeedback>{errors.role_name.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="status_of_role">
                    Status{!isView() && <span className="text-danger">*</span>}
                  </Label>
                  <Controller
                    name="status_of_role"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={[
                          { value: 1, label: "Active" },
                          { value: 2, label: "Inactive" },
                        ]}
                        className={`react-select ${
                          errors.status_of_role && "is-invalid"
                        }`}
                        classNamePrefix="select"
                        isSearchable
                        placeholder="Select Status"
                        isDisabled={isView()}
                      />
                    )}
                  />
                  {errors.status_of_role && (
                    <FormFeedback className="d-block">
                      {errors.status_of_role.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <Row className="mt-2">
              <Col xs={12} md={12} className="mt-1">
                <CardText tag="h5" className="mb-1">
                  Role Permissions
                </CardText>
                <div className="overflow-x-auto relative">
                  <table
                    className={`w-100 min-w-full border-collapse ${
                      skin === "dark" ? "bg-gray-800" : "bg-white"
                    }`}
                  >
                    <thead>
                      <tr
                        className={`bg-gray-100 ${
                          skin === "dark" ? "text-white" : "text-gray-800"
                        }`}
                      >
                        <th className="border p-2 text-left">
                          <CardText>Module</CardText>
                        </th>
                        <th className="border p-2 text-left">Sub-Module</th>
                        {checkExistanceItem(ModuleListing[0]?.permissions)?.map(
                          (permission, index) => (
                            <th
                              key={permission}
                              className="border p-2 text-center w-1/12"
                            >
                              {permission.charAt(0).toUpperCase() +
                                permission.slice(1)}
                            </th>
                          )
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {ModuleListing?.map((module) => (
                        <Fragment key={module?.title}>
                          {module?.subModules?.length === 0 && (
                            <tr
                              className={`${
                                skin === "dark"
                                  ? "text-white bg-gray-800"
                                  : "text-gray-800 bg-white"
                              }`}
                            >
                              <td className="border p-2 font-semibold text-left">
                                {module?.title}
                              </td>
                              <td className="border p-2 text-left text-gray-600">
                                -
                              </td>
                              {ensureFourElements(module?.permissions)?.map(
                                (permission) => (
                                  <td
                                    key={permission}
                                    className="border p-2 text-center"
                                  >
                                    {permission === "" ? (
                                      "-"
                                    ) : (
                                      <Input
                                        type="checkbox"
                                        checked={
                                          permissions[module.name]?.[permission]
                                        }
                                        onChange={() =>
                                          handleCheckboxChange(
                                            module.name,
                                            permission
                                          )
                                        }
                                        disabled={isView()}
                                      />
                                    )}
                                  </td>
                                )
                              )}
                            </tr>
                          )}
                          {module?.subModules?.map((subModule, subIndex) => (
                            <tr
                              key={subModule?.title}
                              className={`${
                                skin === "dark"
                                  ? "text-white bg-gray-800"
                                  : "text-gray-800 bg-white"
                              }`}
                            >
                              {subIndex === 0 && (
                                <td
                                  rowSpan={module?.subModules?.length}
                                  className="border p-2 font-semibold text-left align-top"
                                >
                                  {module.title}
                                </td>
                              )}
                              <td className="border p-2 text-left text-gray-600">
                                {subModule.title}
                              </td>
                              {ensureFourElements(subModule?.permissions)?.map(
                                (permission) => (
                                  <td
                                    key={permission}
                                    className="border p-2 text-center"
                                  >
                                    {permission === "" ? (
                                      "-"
                                    ) : (
                                      <Input
                                        type="checkbox"
                                        checked={
                                          permissions[subModule.name]?.[
                                            permission
                                          ]
                                        }
                                        onChange={() =>
                                          handleCheckboxChange(
                                            subModule.name,
                                            permission
                                          )
                                        }
                                        disabled={isView()}
                                      />
                                    )}
                                  </td>
                                )
                              )}
                            </tr>
                          ))}
                        </Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              {!isView() && (
                <>
                  <Button
                    color="primary"
                    tag={Link}
                    to={`${prefix}/role-management`}
                    className="me-2 mt-3"
                  >
                    Cancel
                  </Button>
                  <Button color="primary" type="submit" className="mt-3">
                    {id ? "Edit" : "Add"} Role
                  </Button>
                </>
              )}
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

const RoleAddEditWithPermission = withPermissionCheck(
  AddEdit,
  "roles",
  "/role-management"
);

export default RoleAddEditWithPermission;
