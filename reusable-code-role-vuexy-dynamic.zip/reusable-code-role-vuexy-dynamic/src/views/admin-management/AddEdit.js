// ** React Imports
import "cleave.js/dist/addons/cleave-phone.us";
import { Controller, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
// ** Reactstrap Imports
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
} from "reactstrap";

import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import * as Yup from "yup";

import Spinner from "@components/spinner/Loading-spinner";
import {
  addAdminUserApi,
  editAdminUserAPI,
  getAdminUserDetailestAPI,
  getRoleDropdownDataAPI,
} from "../../redux/adminManagement";
import withPermissionCheck from "../withPermissionCheck";

const validationSchema = (isEdit) => {
  const baseSchema = {
    first_name: Yup.string()
      .trim()
      .required("First Name is required")
      .max(50, "First Name cannot exceed 50 characters"),
    last_name: Yup.string()
      .trim()
      .required("Last Name is required")
      .max(50, "Last Name cannot exceed 50 characters"),
    role: Yup.object().nullable().required("Role is required"),
    admin_status: Yup.object().nullable().required("Status is required"),
    email: Yup.string()
      .trim()
      .email("Please enter a valid email address")
      .required("Email is required"),
  };

  return Yup.object().shape(baseSchema);
};

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { roleDropdownData, singleAdminUserDetailes } = useSelector(
    (state) => state?.root?.AdminManagmentSlice
  );
  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const isEditRoute = () => location.pathname.includes("edit");
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const initialValues = {
    admin_status: { value: 1, label: "Active" },
    role: null,
    email: "",
    first_name: "",
    last_name: "",
  };

  const schema = validationSchema(id);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
    values: initialValues,
  });

  useEffect(() => {
    id && dispatch(getAdminUserDetailestAPI(id, "edit"));
    if (!isEditRoute()) {
      dispatch(getRoleDropdownDataAPI());
    }
  }, [id]);

  const roleOptions = roleDropdownData?.map((item) => ({
    value: item?._id,
    label: item?.role_name,
  }));

  const statusOptions = [
    { value: 1, label: "Active" },
    { value: 2, label: "InActive" },
  ];

  useEffect(() => {
    if (singleAdminUserDetailes && id) {
      const { email, first_name, last_name, role, status } =
        singleAdminUserDetailes;

      initialValues.admin_status = statusOptions?.find(
        (p) => p.value === status
      );
      initialValues.role = roleOptions?.find((p) => p.value === role?._id);
      initialValues.email = email;
      initialValues.first_name = first_name;
      initialValues.last_name = last_name;

      Object?.entries(initialValues)?.forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [singleAdminUserDetailes, roleDropdownData]);

  const onSubmit = (data) => {
    const payload = {
      ...data,
      role: data?.role?.value,
      user_type: data?.role?.label === "Super Admin" ? 1 : 2,
      status: data?.admin_status?.value,
    };
    id && delete payload.email;
    id && delete payload?.user_type;
    delete payload?.admin_status;

    isEditRoute()
      ? dispatch(editAdminUserAPI(payload, id, navigate))
      : dispatch(addAdminUserApi(payload, navigate));
  };
  return (
    <Card>
      <CardHeader>
        <CardText tag="h3"> {id ? "Edit" : "Add"} Admin User</CardText>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="first_name">
                    First Name{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      <small>*</small>
                    </span>
                  </Label>
                  <Controller
                    name="first_name"
                    id="first_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.first_name}
                        placeholder="First Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.first_name && (
                    <FormFeedback>{errors.first_name.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="last_name">
                    Last Name{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="last_name"
                    id="last_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.last_name}
                        placeholder="Last Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.last_name && (
                    <FormFeedback>{errors.last_name.message}</FormFeedback>
                  )}
                </div>
              </Col>
            </Row>
            <Row>
              <Col md="12">
                <div className="mb-1">
                  <Label className="form-label" for="email">
                    Email{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name={`email`}
                    control={control}
                    defaultValue={""}
                    render={({ field }) => (
                      <Input
                        type="email"
                        className="form-control"
                        placeholder="demo@gmail.com"
                        {...field}
                        invalid={errors?.email?.message}
                        disabled={id}
                      />
                    )}
                  />
                  <FormFeedback className="d-block">
                    {errors?.email?.message}
                  </FormFeedback>
                </div>
              </Col>
            </Row>

            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="role">
                    Role{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="role"
                    id="role"
                    control={control}
                    defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={roleOptions}
                        className="react-select"
                        classNamePrefix="select"
                        invalid={errors.role}
                        menuShouldScrollIntoView={true}
                        styles={{
                          control: (baseStyles, state) => ({
                            ...baseStyles,
                            borderColor: errors.role ? "red" : "#d8d6de",
                          }),
                        }}
                        isSearchable
                        placeholder="Manager"
                        menuPortalTarget={document.body}
                      />
                    )}
                  />
                  {errors && errors.role && (
                    <FormFeedback className="d-block">
                      {errors.role.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="admin_status">
                    Status{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="admin_status"
                    id="admin_status"
                    control={control}
                    defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={statusOptions}
                        className="react-select"
                        classNamePrefix="select"
                        invalid={errors.admin_status}
                        styles={{
                          control: (baseStyles, state) => ({
                            ...baseStyles,
                            borderColor: errors.admin_status
                              ? "red"
                              : "#d8d6de",
                          }),
                        }}
                        isSearchable
                        placeholder="Active"
                      />
                    )}
                  />
                  {errors && errors.admin_status && (
                    <FormFeedback className="d-block">
                      {errors.admin_status.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              <Link to={`${prefix}/staff-management`}>
                <Button color="primary" className="me-1">
                  Cancel
                </Button>
              </Link>
              <Button color="primary" type="submit" className="d-flex">
                {isEditRoute() ? "Save" : "Add"}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

const AdminAddEditWithPermission = withPermissionCheck(
  AddEdit,
  "staffs",
  "/staff-management"
);

export default AdminAddEditWithPermission;
