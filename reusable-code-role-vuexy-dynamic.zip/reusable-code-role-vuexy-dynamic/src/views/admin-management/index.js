import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { columns } from "./columns";
import { Card, Button, CardHeader, CardText } from "reactstrap";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  getAdminUsersAPI,
  getRoleDropdownDataAPI,
  setPaginationAdmin,
} from "../../redux/adminManagement";

import CustomHeader from "../../@core/components/customHeader/customHeader";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import "@styles/react/libs/tables/react-dataTable-component.scss";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";

const AdminManagement = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { AdminUserList, paginationAdminUser } = useSelector(
    (state) => state?.root?.AdminManagmentSlice
  );
  const { roleDropdownData } = useSelector(
    (state) => state?.root?.AdminManagmentSlice
  );
  const { UserData } = useSelector((state) => state.root?.authentication);

  const [defaultRoleSelect, setDefaultRoleSelect] = useState(null);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const [currentPage, setCurrentPage] = useState(paginationAdminUser?.page);
  const [pageSize, setPageSize] = useState(paginationAdminUser?.limit);
  const [sortBy, setSortBy] = useState(paginationAdminUser?.sortBy);
  const [orderBy, setOrderBy] = useState(paginationAdminUser?.orderBy);

  const writePermission = UserData?.permissions?.reduce((acc, section) => {
    // If a match is found, return it
    if (acc) {
      return acc;
    }
    if (section.name === "staffs") {
      return section;
    }
    const foundSubModule = section.subModules?.find(
      (subModule) => subModule.name === "staffs"
    );
    if (foundSubModule) {
      return foundSubModule;
    }
    return null;
  }, null);

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const data = AdminUserList?.data?.map((item) => ({
    ...item,
    writePermission: writePermission?.permissions,
  }));

  useEffect(() => {
    dispatch(getRoleDropdownDataAPI());
  }, []);

  useEffect(() => {
    dispatch(
      setPaginationAdmin({
        page: currentPage,
        limit: pageSize,
        sortBy,
        orderBy,
      })
    );
    dispatch(
      getAdminUsersAPI({
        page: currentPage,
        limit: pageSize,
        sortBy: `${sortBy}:${orderBy}`,
        search: searchValue,
        filterBy: defaultRoleSelect?.value,
      })
    );
  }, [
    currentPage,
    pageSize,
    sortBy,
    orderBy,
    debouncedValue,
    defaultRoleSelect,
  ]);

  const handleSort = (column, order) => {
    setSortBy(column?.sortable);
    setOrderBy(order);
  };

  const chnagePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };
  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handleRoleChange = (e) => {
    setDefaultRoleSelect(e);
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Admin Users</CardText>
        {writePermission?.permissions?.length > 0 &&
          writePermission?.permissions.includes("create") && (
            <Button
              color="primary"
              className="d-flex ms-auto "
              onClick={() => navigate("add")}
            >
              ADD
            </Button>
          )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationAdminUser.limit}
          paginationTotalRows={AdminUserList?.total}
          currentPage={paginationAdminUser.page}
          paginationDefaultPage={paginationAdminUser.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={chnagePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          noDataComponent={<NoDataComponent />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={handleSort}
          persistTableHead={true}
          sortServer
          paginationServer
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handleFilter}
              AdminRoles={roleDropdownData}
              is_filter={true}
              defaultRoleSelect={defaultRoleSelect}
              setDefaultRoleSelect={handleRoleChange}
            />
          }
        />
      </div>
    </Card>
  );
};

export default AdminManagement;
