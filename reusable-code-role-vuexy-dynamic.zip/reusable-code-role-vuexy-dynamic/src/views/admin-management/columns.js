import moment from "moment";
import React, { useState } from "react";
import { Edit2, Eye, Trash2 } from "react-feather";
import { Link } from "react-router-dom";
import { Badge, Modal, ModalBody, ModalHeader } from "reactstrap";
import { showAlert } from "../../@core/components/CutomAlert/CutomAlert";
import {
  deleteAdminUserAPI,
  getAdminUserDetailestAPI,
} from "../../redux/adminManagement"; // Import your API
import { store } from "../../redux/store"; // Import store

export const columns = [
  {
    name: "Admin Name",
    minWidth: "150px",
    sortable: "full_name",
    cell: (row) => (
      <div className="truncate-text">
        {`${row?.first_name ?? ""} ${row?.last_name ?? ""}`}
      </div>
    ),
  },
  {
    name: "Email",
    sortable: "email",
    minWidth: "250px",
    selector: (row) => row.email,
  },
  {
    name: "Role",
    sortable: "role",
    minWidth: "150px",
    selector: (row) => (
      <div className="truncate-text">
        {row?.role ? row?.role?.role_name : "-"}
      </div>
    ),
  },
  {
    name: "Date & Time",
    sortable: "createdAt",
    minWidth: "250px",
    selector: (row) => moment(row.createdAt).format("D MMM YYYY, h:mmA"),
  },
  {
    name: "Status",
    sortable: "status",
    minWidth: "150px",
    selector: (row) => {
      return (
        <Badge
          color={row?.status === 1 ? "success" : "danger"}
          className={row?.status === 1 ? "custom-badge" : ""}
          pill
        >
          {row.status === 1 ? "Active" : "InActive"}
        </Badge>
      );
    },
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => <ActionsCell row={row} />,
  },
];

const ActionsCell = ({ row }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [adminDetails, setAdminDetails] = useState(null);

  const toggleModal = () => setModalOpen(!modalOpen);

  const handleViewClick = async (id) => {
    try {
      await store.dispatch(getAdminUserDetailestAPI(id, "column")); // API call to fetch details
      const { singleAdminUserDetailes } =
        store.getState().root.AdminManagmentSlice; // Get details from the store
      setAdminDetails(singleAdminUserDetailes);
      setModalOpen(true);
    } catch (error) {
      console.error("Error fetching admin details:", error);
    }
  };

  return (
    <div className="d-flex">
      {row?.writePermission?.includes("edit") ? (
        <Link to={`edit/${row?._id}`} className="text-decoration-none">
          <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
        </Link>
      ) : (
        <Edit2 size={16} className="me-2 cursor-not-allowed icon-color-cust" />
      )}

      <Trash2
        size={16}
        color="red"
        className={
          row?.writePermission?.includes("delete")
            ? "me-2 cursor-pointer icon-color-cust"
            : "me-2 cursor-not-allowed icon-color-cust"
        }
        onClick={
          row?.writePermission?.includes("delete")
            ? () => showAlert(row?._id, deleteAdminUserAPI, "Admin User")
            : () => {}
        }
      />

      <Eye
        size={16}
        color="black"
        className="cursor-pointer icon-color-cust"
        onClick={() => handleViewClick(row?._id)} // Fetch details on click
      />

      {/* Modal for viewing admin details */}
      <Modal isOpen={modalOpen} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>Admin User Details</ModalHeader>
        <ModalBody>
          {adminDetails ? (
            <div>
              <p>
                <strong>Name:</strong> {adminDetails.first_name}{" "}
                {adminDetails.last_name}
              </p>
              <p>
                <strong>Email:</strong> {adminDetails.email}
              </p>
              <p>
                <strong>Role:</strong> {adminDetails.role?.role_name}
              </p>
              <p>
                <strong>Status:</strong>{" "}
                {adminDetails.status === 1 ? "Active" : "Inactive"}
              </p>
              {/* Add more fields as needed */}
            </div>
          ) : (
            <p>Loading details...</p>
          )}
        </ModalBody>
      </Modal>
    </div>
  );
};
