import React, { useState } from "react";
import { Edit2, Trash2, Eye } from "react-feather";
import { Link } from "react-router-dom";
import { Badge, Modal, ModalHeader, ModalBody } from "reactstrap";
import { deleteFaqAPI, getFaqDetailesAPI } from "../../redux/faqManagement"; // Import necessary APIs
import { showAlert } from "../../@core/components/CutomAlert/CutomAlert";
import { store } from "../../redux/store"; // Import store
import { stripHtmlTags } from "../../utility/Utils";

export const columns = [
  {
    name: "Question",
    minWidth: "150px",
    sortable: "question",
    cell: (row) => <div className="truncate-text">{row?.questionText}</div>,
  },
  {
    name: "Answer",
    sortable: "answer",
    minWidth: "150px",
    selector: (row) => (
      <div className="truncate-text">{stripHtmlTags(row?.answer)}</div>
    ),
  },
  {
    name: "Status",
    sortable: "status",
    minWidth: "150px",
    selector: (row) => {
      return (
        <Badge
          color={String(row?.status) === "1" ? "success" : "danger"}
          className={String(row?.status) === "1" ? "custom-badge" : ""}
          pill
        >
          {String(row?.status) === "1" ? "Active" : "InActive"}
        </Badge>
      );
    },
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => <ActionsCell row={row} />,
  },
];

const ActionsCell = ({ row }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [faqDetails, setFaqDetails] = useState(null);
  const skin = store?.getState()?.root?.layout?.skin;

  const toggleModal = () => setModalOpen(!modalOpen);

  const handleViewClick = async (id) => {
    try {
      await store.dispatch(getFaqDetailesAPI(id, "column")); // API call to fetch FAQ details
      const { singleFaqDetailes } = store.getState().root.faqManagementSlice; // Get details from the store
      setFaqDetails(singleFaqDetailes);
      toggleModal();
    } catch (error) {
      console.error("Error fetching FAQ details:", error);
    }
  };

  return (
    <div className="d-flex">
      {row?.writePermission?.includes("edit") ? (
        <Link to={`edit/${row?.id}`} className="text-decoration-none">
          <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
        </Link>
      ) : (
        <Edit2 size={16} className="me-2 cursor-not-allowed icon-color-cust" />
      )}

      <Trash2
        size={16}
        color="red"
        className={
          row?.writePermission?.includes("delete")
            ? "me-2 cursor-pointer icon-color-cust"
            : "me-2 cursor-not-allowed icon-color-cust"
        }
        onClick={
          row?.writePermission?.includes("delete")
            ? () => showAlert(row?.id, deleteFaqAPI, "Faq")
            : () => {}
        }
      />

      <Eye
        size={16}
        color="black"
        className="cursor-pointer icon-color-cust"
        onClick={() => handleViewClick(row?.id)} // Fetch details on click
      />

      {/* Modal for viewing FAQ details */}
      <Modal isOpen={modalOpen} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>FAQ Details</ModalHeader>
        <ModalBody>
          {faqDetails ? (
            <div>
              <p className="break-text">
                <strong>Question:</strong> {faqDetails.questionText}
              </p>
              <p>
                <strong>Answer:</strong>
              </p>
              <div
                style={{
                  maxHeight: "300px", // Set a fixed height for the scrollable area
                  overflowY: "auto", // Enable vertical scrolling
                  padding: "10px",
                  border: "1px solid #ddd", // Optional: add a border for better visibility
                  borderRadius: "5px",
                  backgroundColor: skin === "dark" ? "#283046" : "#f8f9fa", // Optional: light background for readability
                }}
                dangerouslySetInnerHTML={{ __html: faqDetails.answer }} // Use the FAQ answer content as HTML
              ></div>
              <p className="pt-2">
                <strong>Status:</strong>{" "}
                {faqDetails.status === 1 ? "Active" : "Inactive"}
              </p>
            </div>
          ) : (
            <p>Loading details...</p>
          )}
        </ModalBody>
      </Modal>
    </div>
  );
};
