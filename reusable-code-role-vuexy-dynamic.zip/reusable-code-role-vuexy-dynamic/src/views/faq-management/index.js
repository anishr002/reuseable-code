import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { columns } from "./columns";
import { Card, Button, CardHeader, CardText } from "reactstrap";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getFaqApiCall, setPaginationFaq } from "../../redux/faqManagement";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import CustomHeader from "../../@core/components/customHeader/customHeader";
import "@styles/react/libs/tables/react-dataTable-component.scss";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";

const Faqs = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { FaqsData, paginationFaq } = useSelector(
    (state) => state?.root?.faqManagementSlice
  );

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);

  const [currentPage, setCurrentPage] = useState(paginationFaq?.page);
  const [pageSize, setPageSize] = useState(paginationFaq?.limit);
  const [sortBy, setSortBy] = useState(paginationFaq?.sortBy);
  const [orderBy, setOrderBy] = useState(paginationFaq?.orderBy);
  const [defaultStatusSelect, setDefaultStatusSelect] = useState(null);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const writePermission = UserData?.permissions?.reduce((acc, section) => {
    if (acc) return acc; // If a match is found, return it
    if (section.name === "faqs") {
      return section;
    }
    const foundSubModule = section.subModules?.find(
      (subModule) => subModule.name === "faqs"
    );
    if (foundSubModule) {
      return foundSubModule;
    }
    return null;
  }, null);

  const data = FaqsData?.data?.map((item) => ({
    questionText: item?.questionText,
    answer: item?.answer,
    id: item?._id,
    status: item?.status,
    writePermission: writePermission?.permissions,
  }));

  const statusDropdownData = [
    { value: 1, label: "Active" },
    { value: 2, label: "InActive" },
  ];

  useEffect(() => {
    dispatch(
      setPaginationFaq({
        page: currentPage,
        limit: pageSize,
        sortBy,
        orderBy,
      })
    );
    dispatch(
      getFaqApiCall({
        page: currentPage,
        limit: pageSize,
        sortBy: `${sortBy}:${orderBy}`,
        search: searchValue,
        filterByStatus: defaultStatusSelect?.value,
      })
    );
  }, [
    currentPage,
    pageSize,
    sortBy,
    orderBy,
    debouncedValue,
    defaultStatusSelect,
  ]);

  const handleSort = (column, order) => {
    setSortBy(column?.sortable);
    setOrderBy(order);
  };

  const changePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };

  const handle_filter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handleStatusChange = (e) => {
    setDefaultStatusSelect(e);
  };
  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Faqs</CardText>
        {writePermission?.permissions?.length > 0 &&
          writePermission?.permissions.includes("create") && (
            <Button
              color="primary"
              className="d-flex ms-auto "
              onClick={() => navigate("add")}
            >
              ADD
            </Button>
          )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationFaq.limit}
          paginationTotalRows={FaqsData?.total}
          currentPage={paginationFaq.page}
          paginationDefaultPage={paginationFaq.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={changePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          noDataComponent={<NoDataComponent />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={handleSort}
          persistTableHead={true}
          sortServer
          paginationServer
          // customStyles={customStyles}
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handle_filter}
              StatusFilter={statusDropdownData}
              is_filter={true}
              defaultStatusSelect={defaultStatusSelect}
              setDefaultStatusSelect={handleStatusChange}
            />
          }
        />
      </div>
    </Card>
  );
};

export default Faqs;
