import Spinner from "@components/spinner/Loading-spinner";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useEffect, useRef, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
} from "reactstrap";
import * as Yup from "yup";
import {
  addFaqAPI,
  editFaqAPI,
  getFaqDetailesAPI,
} from "../../redux/faqManagement";
import withPermissionCheck from "../withPermissionCheck";

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { singleFaqDetailes } = useSelector(
    (state) => state?.root?.faqManagementSlice
  );
  const { skin } = useSelector((state) => state?.root?.layout);

  const quillRef = useRef(null);
  const [editorError, setEditorError] = useState(false);

  const isEditRoute = () => location.pathname.includes("edit");

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validationSchema = Yup.object().shape({
    questionText: Yup.string()
      .trim()
      .required("Question is required")
      .max(250, "Question cannot exceed 250 characters"),
    answer: Yup.string().trim().required("Answer is required"),
    status: Yup.object().nullable().required("Status is required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      questionText: "",
      answer: "",
      status: null,
    },
  });

  useEffect(() => {
    if (isEditRoute()) {
      dispatch(getFaqDetailesAPI(id, "edit"));
    }
  }, [dispatch, id]);

  useEffect(() => {
    if (isEditRoute() && singleFaqDetailes) {
      setValue("questionText", singleFaqDetailes?.questionText);
      setValue("answer", singleFaqDetailes?.answer);
      setValue(
        "status",
        singleFaqDetailes?.status === 1
          ? { value: 1, label: "Active" }
          : { value: 2, label: "Inactive" }
      );
    }
  }, [singleFaqDetailes, setValue]);

  const handleKeyUp = () => {
    const editor = quillRef?.current?.getEditor();
    const content = editor?.getText()?.trim(); // Get text content without HTML tags
    const contentLength = editor?.getLength(); // Get content length (Quill editor counts characters including whitespaces)

    // Update the form value with the editor's current content
    setValue("answer", editor.root.innerHTML);

    // Check if the content is only whitespace or empty
    const onlyWhitespace = content.length === 0;

    // Set error state if content is invalid
    setEditorError(contentLength <= 1 || onlyWhitespace);

    // Clear errors if content is valid
    if (contentLength > 1 && !onlyWhitespace) {
      clearErrors("answer");
    }
  };

  const handleKeyDown = (event) => {
    console.log("Key down:", event);
  };

  const handleEditorChange = (content) => {
    const trimmedContent = content.trim();
    setValue("answer", content);

    const length = quillRef?.current?.getEditor()?.getText().trim();
    const onlyWhitespace = trimmedContent.length === 0;

    // Trigger error if content is empty or only contains spaces
    setEditorError(length <= 1 || onlyWhitespace);
  };

  const onSubmit = (data) => {
    const payload = {
      questionText: data?.questionText,
      answer: data?.answer,
      status: data?.status?.value,
    };

    const length = quillRef?.current?.getEditor()?.getLength() || 0;
    const trimmedContent = quillRef?.current?.getEditor()?.getText().trim();
    const onlyWhitespace = trimmedContent.length === 0;

    // Validate editor content before submitting
    if (length <= 1 || onlyWhitespace) {
      setEditorError(true);
      return;
    }

    // API call
    isEditRoute()
      ? dispatch(editFaqAPI(payload, navigate, id))
      : dispatch(addFaqAPI(payload, navigate));
  };

  return (
    <Card>
      <CardHeader>
        <CardText tag="h3">{id ? "Edit" : "Add"} FAQ</CardText>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-1" onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="questionText">
                    Question<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="questionText"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.questionText}
                        placeholder="Enter question"
                        {...field}
                      />
                    )}
                  />
                  {errors.questionText && (
                    <FormFeedback>{errors.questionText.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="status">
                    Status<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="status"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={[
                          { value: 1, label: "Active" },
                          { value: 2, label: "Inactive" },
                        ]}
                        className={`react-select ${
                          errors.status && "is-invalid"
                        }`}
                        classNamePrefix="select"
                        isSearchable
                        placeholder="Select Status"
                      />
                    )}
                  />
                  {errors.status && (
                    <FormFeedback className="d-block">
                      {errors.status.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>
            <Row className="mt-2">
              <Col xs={12} className="mt-1">
                <Label className="form-label" for="answer">
                  Answer<span className="text-danger">*</span>
                </Label>
                <div style={{ textAlign: "left" }}>
                  <Controller
                    name="answer"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <ReactQuill
                        ref={quillRef}
                        theme="snow"
                        value={field.value}
                        onChange={handleEditorChange}
                        onKeyUp={handleKeyUp}
                        onKeyDown={handleKeyDown}
                        modules={modules}
                        className={`react-quill-container ${
                          skin === "dark" ? "dark-theme" : "light-theme"
                        }`}
                        formats={formats}
                      />
                    )}
                  />
                  {(errors.answer || editorError) && (
                    <FormFeedback className="d-block">
                      {errors.answer?.message || "Answer is required"}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              <Link to={`${prefix}/faq-management`}>
                <Button color="primary" className="me-1">
                  Cancel
                </Button>
              </Link>
              <Button color="primary" type="submit" className="d-flex">
                {isEditRoute() ? "Save" : "Add"}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

// Modules and formats for the ReactQuill editor
const modules = {
  toolbar: [
    [{ header: "1" }, { header: "2" }, { font: [] }],
    [{ list: "ordered" }, { list: "bullet" }],
    ["bold", "italic", "underline", "strike", "blockquote"],
    [{ align: [] }, { color: [] }, { background: [] }],
    [{ script: "sub" }, { script: "super" }],
    ["link", "image"],
    ["clean"],
  ],
};

const formats = [
  "header",
  "font",
  "list",
  "bullet",
  "bold",
  "italic",
  "underline",
  "strike",
  "blockquote",
  "align",
  "color",
  "background",
  "script",
  "link",
  "image",
  // "video",
];

const FaqAddEditWithPermission = withPermissionCheck(
  AddEdit,
  "faqs",
  "/faq-management"
);

export default FaqAddEditWithPermission;
