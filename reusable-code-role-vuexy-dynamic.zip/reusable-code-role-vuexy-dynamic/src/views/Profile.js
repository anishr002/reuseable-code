// ** React Imports
import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import "cleave.js/dist/addons/cleave-phone.us";
import AvtarUser from "../assets/images/portrait/avatar-blank.png";
import { useDispatch, useSelector } from "react-redux";
// ** Reactstrap Imports
import {
  Card,
  CardBody,
  CardTitle,
  Form,
  Label,
  Input,
  Button,
  FormFeedback,
  CardHeader,
  Row,
  Col,
} from "reactstrap";
import Spinner from "@components/spinner/Loading-spinner";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

import { onSetLogo } from "../utility/Utils";
import { editProfileAPI, getProfileAPI } from "../redux/profile";

const Profile = () => {
  const { profileData } = useSelector((state) => state?.root.ProfileSlice);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const dispatch = useDispatch();
  const [avatar, setAvatar] = useState("");
  const [imageObj, setImageObj] = useState(null);

  const validationSchema = Yup.object().shape({
    first_name: Yup.string()
      .trim()
      .required("First Name is required")
      .max(50, "First Name cannot exceed 50 characters"),
    last_name: Yup.string()
      .trim()
      .required("Last name is required")
      .max(50, "Last Name cannot exceed 50 characters"),
    email: Yup.string()
      .trim()
      .email("Please enter a valid email address")
      .notRequired("Email is required"),
    role: Yup.object().nullable().notRequired("Please select role type"),
  });

  const initialValues = {
    first_name: "",
    last_name: "",
    email: profileData?.email || "",
    role: profileData?.user_type === 1 ? "Super Admin" : "",
  };

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    values: initialValues,
    mode: "onChange",
  });

  useEffect(() => {
    dispatch(getProfileAPI());
  }, []);

  const onSubmit = (data) => {
    delete data?.email;
    delete data?.role;
    const payload = { ...data };

    if (typeof imageObj !== "string") {
      payload.profile_image = imageObj;
    }
    delete payload.imageObj;

    dispatch(editProfileAPI({ ...payload }));
  };

  const handleImgReset = () => {
    setAvatar("");
    setImageObj(null);
  };

  useEffect(() => {
    if (profileData) {
      Object.entries(initialValues).forEach(([key, value]) => {
        if (key === "role") {
          setValue(key, profileData[`${key}`]?.role_name);
        } else {
          setValue(key, profileData[`${key}`]);
        }
      });
      setAvatar(profileData?.profile_image);
      setImageObj(profileData?.profile_image);
    }
  }, [profileData]);

  const handleImageError = (e) => {
    // Replace the broken image with a default avatar or placeholder
    e.target.src = AvtarUser;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle tag="h4">Profile</CardTitle>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col sm="4">
                <div className="border-end pe-3 d-flex align-item-center mt-75 mb-2">
                  <div className="me-2">
                    <img
                      className="rounded-circle me-100"
                      src={avatar || AvtarUser}
                      height="100"
                      width="100"
                      onError={handleImageError}
                      alt="profile_img"
                      role="presentation"
                    />
                  </div>
                  <div className="d-flex flex-column justify-content-center ms-1">
                    <Button
                      tag={Label}
                      className="mb-75  py-1 px-2"
                      size="sm"
                      color="primary"
                      outline
                    >
                      Upload Logo
                      <Input
                        type="file"
                        onChange={(e) => onSetLogo(e, setImageObj, setAvatar)}
                        hidden
                        accept="image/*"
                      />
                    </Button>
                    <Button
                      color="flat-danger"
                      size="sm"
                      onClick={handleImgReset}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              </Col>
              <Col sm="8">
                <div className="ms-2">
                  <CardTitle>Image Specifications</CardTitle>
                  <ol>
                    <li>Min. 400 x 400px</li>
                    <li>Max. 100KB</li>
                    {/* <li>Your face or company logo</li> */}
                  </ol>
                </div>
              </Col>
            </Row>

            {/* <CardTitle>Details</CardTitle> */}
            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="first_name">
                    First Name{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="first_name"
                    id="first_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.first_name}
                        placeholder="First Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.first_name && (
                    <FormFeedback>{errors.first_name.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="last_name">
                    Last Name{" "}
                    <span className="text-danger" style={{ fontSize: "17px" }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="last_name"
                    name="last_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        placeholder="Last Name"
                        invalid={errors.last_name}
                        {...field}
                      />
                    )}
                  />
                  {errors.last_name && (
                    <FormFeedback>{errors.last_name.message}</FormFeedback>
                  )}
                </div>
              </Col>
            </Row>
            <Row className="d-flex align-items-center">
              <Col md={"6"}>
                <div className="mb-1">
                  <Label className="form-label" for="email">
                    Email
                  </Label>
                  <Controller
                    name="email"
                    id="email"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="email"
                        className="form-control"
                        placeholder="dom@yopmail.com"
                        {...field}
                        invalid={errors?.email}
                        disabled
                      />
                    )}
                  />
                  <FormFeedback className="d-block">
                    {errors?.email?.message}
                  </FormFeedback>
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="role">
                    Role
                  </Label>
                  <Controller
                    name="role"
                    id="role"
                    control={control}
                    render={({ field }) => (
                      <Input
                        autoFocus
                        type="text"
                        className="form-control"
                        invalid={errors.role}
                        placeholder="Role"
                        {...field}
                        disabled={true}
                      />
                    )}
                  />
                  {errors && errors.role && (
                    <FormFeedback className="d-block">
                      {errors.role.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              <Button color="primary" type="submit" className="d-flex">
                Save
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

export default Profile;
