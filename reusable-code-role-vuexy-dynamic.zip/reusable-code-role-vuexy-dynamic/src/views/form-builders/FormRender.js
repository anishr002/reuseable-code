// src/components/FormRenderer.js
import React from "react";
import { Form } from "react-formio";

const FormRenderer = ({ formSchema }) => {
  const onFormSubmit = (submission) => {
    console.log("Form Submission Data:", submission);
  };

  return (
    <div>
      {/* <h3>Form Preview</h3> */}
      <Form form={formSchema} onSubmit={onFormSubmit} />
    </div>
  );
};

export default FormRenderer;
