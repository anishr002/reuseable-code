import React, { useState } from "react";
import { Edit2, Trash2, Eye } from "react-feather";
import { Link } from "react-router-dom";
import { Badge, Modal, ModalHeader, ModalBody } from "reactstrap";
import { showAlert } from "../../@core/components/CutomAlert/CutomAlert";
import { store } from "../../redux/store"; // Import store
import { stripHtmlTags } from "../../utility/Utils";
import { deleteFormsAPI, getFormDetailesAPI } from "../../redux/FormBuilder";

export const columns = [
  {
    name: "Title",
    minWidth: "150px",
    sortable: "title",
    cell: (row) => <div className="truncate-text">{row?.title}</div>,
  },
  {
    name: "description",
    sortable: "description",
    minWidth: "150px",
    selector: (row) => (
      <div className="truncate-text">{stripHtmlTags(row?.description)}</div>
    ),
  },
  {
    name: "Status",
    sortable: "status",
    minWidth: "150px",
    selector: (row) => {
      return (
        <Badge
          color={String(row?.status) === "1" ? "success" : "danger"}
          className={String(row?.status) === "1" ? "custom-badge" : ""}
          pill
        >
          {String(row?.status) === "1" ? "Active" : "InActive"}
        </Badge>
      );
    },
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => <ActionsCell row={row} />,
  },
];

const ActionsCell = ({ row }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [faqDetails, setFaqDetails] = useState(null);
  const skin = store?.getState()?.root?.layout?.skin;

  const toggleModal = () => setModalOpen(!modalOpen);

  const handleViewClick = async (id) => {
    try {
      await store.dispatch(getFormDetailesAPI(id, "column")); // API call to fetch FAQ details
      const { singleFormDetailes } = store.getState().root.formBuilderSlice; // Get details from the store
      setFaqDetails(singleFormDetailes);
      toggleModal();
    } catch (error) {
      console.error("Error fetching FAQ details:", error);
    }
  };

  return (
    <div className="d-flex">
      <Link to={`edit/${row?.id}`} className="text-decoration-none">
        <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
      </Link>

      <Trash2
        size={16}
        color="red"
        className={"me-2 cursor-pointer icon-color-cust"}
        onClick={() => showAlert(row?.id, deleteFormsAPI, "Forms")}
      />

      <Eye
        size={16}
        color="black"
        className="cursor-pointer icon-color-cust"
        onClick={() => handleViewClick(row?.id)} // Fetch details on click
      />

      {/* Modal for viewing FAQ details */}
      <Modal isOpen={modalOpen} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>FAQ Details</ModalHeader>
        <ModalBody>
          {faqDetails ? (
            <div>
              <p className="break-text">
                <strong>Question:</strong> {faqDetails.questionText}
              </p>
              <p>
                <strong>Answer:</strong>
              </p>
              <div
                style={{
                  maxHeight: "300px", // Set a fixed height for the scrollable area
                  overflowY: "auto", // Enable vertical scrolling
                  padding: "10px",
                  border: "1px solid #ddd", // Optional: add a border for better visibility
                  borderRadius: "5px",
                  backgroundColor: skin === "dark" ? "#283046" : "#f8f9fa", // Optional: light background for readability
                }}
                dangerouslySetInnerHTML={{ __html: faqDetails.answer }} // Use the FAQ answer content as HTML
              ></div>
              <p className="pt-2">
                <strong>Status:</strong>{" "}
                {faqDetails.status === 1 ? "Active" : "Inactive"}
              </p>
            </div>
          ) : (
            <p>Loading details...</p>
          )}
        </ModalBody>
      </Modal>
    </div>
  );
};
