import "@styles/react/libs/tables/react-dataTable-component.scss";
import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Button, Card, CardHeader, CardText } from "reactstrap";
import CustomHeader from "../../@core/components/customHeader/customHeader";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";
import { getFormsApiCall, setPaginationForms } from "../../redux/FormBuilder";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import { columns } from "./columns";

const FormBuilderListing = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { FormsData, paginationForms } = useSelector(
    (state) => state?.root?.formBuilderSlice
  );

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);

  const [currentPage, setCurrentPage] = useState(paginationForms?.page);
  const [pageSize, setPageSize] = useState(paginationForms?.limit);
  const [sortBy, setSortBy] = useState(paginationForms?.sortBy);
  const [orderBy, setOrderBy] = useState(paginationForms?.orderBy);
  const [defaultStatusSelect, setDefaultStatusSelect] = useState(null);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);

  const data = FormsData?.data?.map((item) => ({
    title: item?.title,
    description: item?.description,
    id: item?._id,
    status: item?.status,
  }));

  const statusDropdownData = [
    { value: 1, label: "Active" },
    { value: 2, label: "InActive" },
  ];

  useEffect(() => {
    dispatch(
      setPaginationForms({
        page: currentPage,
        limit: pageSize,
        sortBy,
        orderBy,
      })
    );
    dispatch(
      getFormsApiCall({
        page: currentPage,
        limit: pageSize,
        sortBy: `${sortBy}:${orderBy}`,
        search: searchValue,
        filterByStatus: defaultStatusSelect?.value,
      })
    );
  }, [
    currentPage,
    pageSize,
    sortBy,
    orderBy,
    debouncedValue,
    defaultStatusSelect,
  ]);

  const handleSort = (column, order) => {
    setSortBy(column?.sortable);
    setOrderBy(order);
  };

  const changePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };

  const handle_filter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handleStatusChange = (e) => {
    setDefaultStatusSelect(e);
  };
  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Forms</CardText>

        <Button
          color="primary"
          className="d-flex ms-auto "
          onClick={() => navigate("add")}
        >
          ADD
        </Button>
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationForms.limit}
          paginationTotalRows={FormsData?.total}
          currentPage={paginationForms.page}
          paginationDefaultPage={paginationForms.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={changePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          noDataComponent={<NoDataComponent />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={handleSort}
          persistTableHead={true}
          sortServer
          paginationServer
          // customStyles={customStyles}
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handle_filter}
              StatusFilter={statusDropdownData}
              is_filter={true}
              defaultStatusSelect={defaultStatusSelect}
              setDefaultStatusSelect={handleStatusChange}
            />
          }
        />
      </div>
    </Card>
  );
};

export default FormBuilderListing;
