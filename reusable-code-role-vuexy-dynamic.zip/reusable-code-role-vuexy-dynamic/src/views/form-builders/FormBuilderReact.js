// src/FormBuilderApp.js
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useEffect, useState } from "react";
import { FormBuilder } from "react-formio";
import * as Yup from "yup";

import Spinner from "@components/spinner/Loading-spinner";
import { Controller, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row,
} from "reactstrap"; // Importing components from Reactstrap
import {
  addFormsAPI,
  editFormAPI,
  getFormDetailesAPI,
} from "../../redux/FormBuilder";
import FormRenderer from "./FormRender";

// import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS

const FormBuilderComponents = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { singleFormDetailes } = useSelector(
    (state) => state?.root?.formBuilderSlice
  );
  const isEditRoute = () => location.pathname.includes("edit");
  const [formSchema, setFormSchema] = useState({
    display: "form",
    components: [],
  });

  const [showModal, setShowModal] = useState(false); // Modal visibility state
  const [savedFormData, setSavedFormData] = useState(""); // State to hold saved form data

  useEffect(() => {
    if (singleFormDetailes) {
      const data = [];
      singleFormDetailes?.fields?.map((i) => {
        const copydata = { ...i };

        delete copydata.id;
        data.push(copydata);
      });
      setFormSchema({
        display: "form",
        components: data,
      });
    }
  }, [singleFormDetailes]);

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validationSchema = Yup.object().shape({
    titleText: Yup.string()
      .trim()
      .required("Title is required")
      .max(250, "Title cannot exceed 250 characters"),
    description: Yup.string()
      .trim()
      .required("Description is required")
      .max(400, "Description cannot exceed 400 characters"),
    status: Yup.object().nullable().required("Status is required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      titleText: "",
      description: "",
      status: null,
    },
  });

  useEffect(() => {
    if (isEditRoute()) {
      dispatch(getFormDetailesAPI(id, "edit"));
    }
  }, [dispatch, id]);

  useEffect(() => {
    if (isEditRoute() && singleFormDetailes) {
      setValue("titleText", singleFormDetailes?.title);
      setValue("description", singleFormDetailes?.description);
      setValue(
        "status",
        singleFormDetailes?.status === 1
          ? { value: 1, label: "Active" }
          : { value: 2, label: "Inactive" }
      );
      // setFormSchema({
      //   ...formSchema,
      //   components: singleFormDetailes?.fields || [],
      // });
    }
  }, [singleFormDetailes, setValue]);

  // Handle changes in the form builder
  const handleFormChange = (schema) => {
    setFormSchema(schema);
    // console.log("Form Schema:", schema);
  };

  // Save form schema as JSON and show in modal
  const handlePreviewForm = () => {
    const jsonData = JSON.stringify(formSchema, null, 2);
    setSavedFormData(jsonData);
    setShowModal(true); // Show the modal
  };

  // Save form schema as JSON and show in modal
  const handleAddForm = (data) => {
    // const jsonData = JSON.stringify(formSchema, null, 2);
    // setSavedFormData(jsonData);
    // setShowModal(true); // Show the modal
    // console.log("Saved Form Data as JSON:", jsonData);

    const payload = {
      title: data?.titleText,
      description: data?.description,
      fields: formSchema?.components,
      status: data?.status?.value || 1,
    };

    isEditRoute()
      ? dispatch(editFormAPI(payload, navigate, id))
      : dispatch(addFormsAPI(payload, navigate));
  };

  // Close the modal
  const handleCloseModal = () => setShowModal(false);

  return (
    <Card>
      {/* /Drag-and-Drop Form Builder */}
      <CardHeader>
        <CardText tag="h3">{id ? "Edit" : "Add"} Form</CardText>
      </CardHeader>
      <CardBody className="bg-white pt-2">
        {isLoading && !singleFormDetailes?.title ? (
          <Spinner open={close} />
        ) : (
          <>
            <Form className="mt-1" onSubmit={handleSubmit(handleAddForm)}>
              <Row>
                <Col md="4">
                  <div className="mb-1">
                    <Label className="form-label" for="titleText">
                      Title<span className="text-danger">*</span>
                    </Label>
                    <Controller
                      name="titleText"
                      control={control}
                      render={({ field }) => (
                        <Input
                          type="text"
                          className="form-control"
                          invalid={errors.titleText}
                          placeholder="Enter title"
                          {...field}
                        />
                      )}
                    />
                    {errors.titleText && (
                      <FormFeedback>{errors.titleText.message}</FormFeedback>
                    )}
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-1">
                    <Label className="form-label" for="status">
                      Status<span className="text-danger">*</span>
                    </Label>
                    <Controller
                      name="status"
                      control={control}
                      render={({ field }) => (
                        <Select
                          {...field}
                          options={[
                            { value: 1, label: "Active" },
                            { value: 2, label: "Inactive" },
                          ]}
                          className={`react-select ${
                            errors.status && "is-invalid"
                          }`}
                          classNamePrefix="select"
                          isSearchable
                          placeholder="Select Status"
                        />
                      )}
                    />
                    {errors.status && (
                      <FormFeedback className="d-block">
                        {errors.status.message}
                      </FormFeedback>
                    )}
                  </div>
                </Col>
              </Row>
              <Row className="mt-2">
                <Col xs={8} className="mt-1">
                  <Label className="form-label" for="description">
                    Description<span className="text-danger">*</span>
                  </Label>
                  <div style={{ textAlign: "left" }}>
                    <Controller
                      name="description"
                      control={control}
                      defaultValue=""
                      render={({ field }) => (
                        <Input
                          type="textarea"
                          className="form-control"
                          invalid={errors.message}
                          placeholder="Enter Description"
                          {...field}
                          style={{ height: "150px" }}
                        />
                      )}
                    />
                    {errors.description && (
                      <FormFeedback className="d-block">
                        {errors.description?.message ||
                          "Description is required"}
                      </FormFeedback>
                    )}
                  </div>
                </Col>
              </Row>
              <Row className="mt-2">
                <Col xs={12} className="mt-1">
                  <Label className="form-label" for="description">
                    Form Fields<span className="text-danger">*</span>
                  </Label>
                  <div style={{ textAlign: "left" }}>
                    <div className="border rounded p-1">
                      <FormBuilder
                        form={formSchema}
                        onChange={handleFormChange}
                        // options={{
                        //   noDefaultSubmitButton: true,
                        // }}
                      />
                    </div>
                    <div className="d-flex justify-content-end mt-2">
                      <Link to={`${prefix}/form-builder`}>
                        <Button color="primary" className="mt-1 me-1">
                          Cancel
                        </Button>
                      </Link>
                      <Button
                        onClick={handlePreviewForm}
                        className="btn btn-primary mt-1"
                      >
                        Form Preview
                      </Button>
                      <Button
                        type="submit"
                        // onClick={handleAddForm}
                        className="btn btn-primary mt-1 ms-1"
                      >
                        {`${id ? "Edit" : "Add"} Form`}
                      </Button>
                    </div>
                  </div>
                </Col>
              </Row>
            </Form>

            {/* Reactstrap Modal for displaying saved form data */}
            <Modal isOpen={showModal} toggle={handleCloseModal}>
              <ModalHeader toggle={handleCloseModal}>Form Preview</ModalHeader>
              <ModalBody>
                {/* <Form form={formSchema} onSubmit={onFormSubmit} /> */}
                <FormRenderer formSchema={formSchema} />
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={handleCloseModal}>
                  Close
                </Button>
              </ModalFooter>
            </Modal>
          </>
        )}
      </CardBody>
    </Card>
  );
};

export default FormBuilderComponents;
