import CmsComponent from "./CmsComponent";

const AboutUs = () => {
  return <CmsComponent slug="about_us" titleOfPage="About Us" />;
};

export default AboutUs;
