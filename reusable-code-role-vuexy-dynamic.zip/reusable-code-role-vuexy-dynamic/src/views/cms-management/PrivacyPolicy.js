import CmsComponent from "./CmsComponent";

const PrivacyPolicy = () => {
  return <CmsComponent slug="privacy_policy" titleOfPage="Privacy Policy" />;
};

export default PrivacyPolicy;
