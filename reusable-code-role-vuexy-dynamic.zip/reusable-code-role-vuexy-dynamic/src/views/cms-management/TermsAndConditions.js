import CmsComponent from "./CmsComponent";

const TermsAndConditions = () => {
  return (
    <CmsComponent
      slug="terms_and_conditions"
      titleOfPage="Terms & Conditions"
    />
  );
};

export default TermsAndConditions;
