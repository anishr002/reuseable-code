import moment from "moment";
import React from "react";

export const columns = [
  {
    name: "Message",
    minWidth: "150px",
    sortable: false,
    cell: (row) => <div className="truncate-text">{row?.message}</div>,
  },
  {
    name: "created At",
    sortable: false,
    minWidth: "150px",
    selector: (row) => moment(row.createdAt).format("D MMM YYYY, h:mmA"),
  },
];
