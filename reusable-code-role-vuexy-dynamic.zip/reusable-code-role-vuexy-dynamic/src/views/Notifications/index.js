import "@styles/react/libs/tables/react-dataTable-component.scss";
import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Card, CardHeader, CardText } from "reactstrap";
import CustomHeader from "../../@core/components/customHeader/customHeader";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";
import {
  getNotificationAPI,
  setPaginationNotification,
} from "../../redux/profile";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import { columns } from "./columns";

const Notifications = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { NotificationData, paginationNotification } = useSelector(
    (state) => state?.root?.ProfileSlice
  );

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const [currentPage, setCurrentPage] = useState(paginationNotification?.page);
  const [pageSize, setPageSize] = useState(paginationNotification?.limit);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);

  const data = NotificationData?.data?.map((item) => ({
    message: item?.message,
    createdAt: item?.createdAt,
    id: item?._id,
  }));

  useEffect(() => {
    dispatch(
      setPaginationNotification({
        page: currentPage,
        limit: pageSize,
      })
    );
    dispatch(
      getNotificationAPI({
        page: currentPage,
        limit: pageSize,
        search: searchValue,
      })
    );
  }, [currentPage, pageSize, debouncedValue]);

  const changePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };

  const handle_filter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Notifications</CardText>
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationNotification?.limit}
          paginationTotalRows={NotificationData?.total}
          currentPage={paginationNotification?.page}
          paginationDefaultPage={paginationNotification?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={changePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          noDataComponent={<NoDataComponent />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          persistTableHead={true}
          sortServer
          paginationServer
          // customStyles={customStyles}
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handle_filter}
            />
          }
        />
      </div>
    </Card>
  );
};

export default Notifications;
