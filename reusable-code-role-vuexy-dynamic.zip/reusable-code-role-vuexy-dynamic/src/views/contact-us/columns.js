import moment from "moment";
import React, { useState } from "react";
import { Eye } from "react-feather";
import { Modal, ModalBody, ModalHeader } from "reactstrap";
import { store } from "../../redux/store";

export const columns = [
  {
    name: "User name",
    minWidth: "150px",
    sortable: "username",
    cell: (row) => row?.username,
  },
  {
    name: "Mobile Number",
    sortable: "mobileNumber",
    minWidth: "150px",
    selector: (row) => row?.mobileNumber,
  },
  {
    name: "Email",
    sortable: "email",
    minWidth: "150px",
    selector: (row) => row?.email,
  },
  {
    name: "Date & Time",
    sortable: "createdAt",
    minWidth: "250px",
    selector: (row) => moment(row.createdAt).format("D MMM YYYY, h:mmA"),
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => <ActionsCell row={row} />,
  },
];

const ActionsCell = ({ row }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedData, setSelectedData] = useState(null);
  const skin = store?.getState()?.root?.layout?.skin;

  const toggleModal = () => setModalOpen(!modalOpen);

  const handleViewClick = (data) => {
    setSelectedData(data);
    toggleModal();
  };

  return (
    <div className="d-flex">
      <Eye
        size={16}
        className="me-2 icon-color-cust cursor-pointer"
        onClick={() => handleViewClick(row)}
      />

      {/* Modal for viewing details */}
      <Modal isOpen={modalOpen} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>View Enquiry</ModalHeader>
        <ModalBody>
          {selectedData ? (
            <div
              className={`swal-two-html ${
                skin === "dark" ? "modal-dark-theme" : "modal-light-theme"
              }`}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "10px",
                maxHeight: "400px",
                overflowY: "auto",
                textAlign: "left",
              }}
            >
              <div className="swal-two-item">
                <strong>Name:</strong> {selectedData?.username}
              </div>
              <div className="swal-two-item">
                <strong>Mobile Number:</strong> {selectedData?.mobileNumber}
              </div>
              <div className="swal-two-item">
                <strong>Email:</strong> {selectedData?.email}
              </div>
              <div className="swal-two-item">
                <strong>Query:</strong> {selectedData?.query}
              </div>
            </div>
          ) : (
            <p>Loading details...</p>
          )}
        </ModalBody>
      </Modal>
    </div>
  );
};
