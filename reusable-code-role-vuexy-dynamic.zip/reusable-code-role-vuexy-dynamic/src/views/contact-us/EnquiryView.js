import CmsComponent from "./CmsComponent";

const EnquiryView = () => {
  return <CmsComponent slug="about_us" titleOfPage="About Us" />;
};

export default EnquiryView;
