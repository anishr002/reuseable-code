import "@styles/react/libs/tables/react-dataTable-component.scss";
import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { ChevronDown } from "react-feather";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Button, Card, CardHeader, CardText } from "reactstrap";
import CustomHeader from "../../@core/components/customHeader/customHeader";
import NoDataComponent from "../../@core/components/customHeader/noDataComponent";
import TableLoading from "../../@core/components/customHeader/TableLoading";
import {
  getTestimonialApiCall,
  setPaginationTestimonial,
} from "../../redux/testimonialManagement";
import { useDebouncedValue } from "../../utility/hooks/useDebouncedValue";
import { stripHtmlTags } from "../../utility/Utils";
import { columns } from "./columns";

const Testimonial = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { TestimonialData, paginationTestimonial } = useSelector(
    (state) => state?.root?.TestimonialManagementSlice
  );

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);

  const [currentPage, setCurrentPage] = useState(paginationTestimonial?.page);
  const [pageSize, setPageSize] = useState(paginationTestimonial?.limit);
  const [sortBy, setSortBy] = useState(paginationTestimonial?.sortBy);
  const [orderBy, setOrderBy] = useState(paginationTestimonial?.orderBy);
  const [defaultStatusSelect, setDefaultStatusSelect] = useState(null);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const writePermission = UserData?.permissions?.reduce((acc, section) => {
    if (acc) {
      return acc;
    } // If a match is found, return it
    if (section.name === "testimonial") {
      return section;
    }
    const foundSubModule = section.subModules?.find(
      (subModule) => subModule.name === "testimonial"
    );
    if (foundSubModule) {
      return foundSubModule;
    }
    return null;
  }, null);

  const data = TestimonialData?.data?.map((item) => ({
    userName: item?.userName,
    message: stripHtmlTags(item?.message),
    id: item?._id,
    status: item?.status,
    createdAt: item?.createdAt,
    writePermission: writePermission?.permissions,
  }));

  const statusDropdownData = [
    { value: 1, label: "Active" },
    { value: 2, label: "InActive" },
  ];

  useEffect(() => {
    dispatch(
      setPaginationTestimonial({
        page: currentPage,
        limit: pageSize,
        sortBy,
        orderBy,
      })
    );
    dispatch(
      getTestimonialApiCall({
        page: currentPage,
        limit: pageSize,
        sortBy: `${sortBy}:${orderBy}`,
        search: searchValue,
        filterByStatus: defaultStatusSelect?.value,
      })
    );
  }, [
    currentPage,
    pageSize,
    sortBy,
    orderBy,
    debouncedValue,
    defaultStatusSelect,
  ]);

  const handleSort = (column, order) => {
    setSortBy(column?.sortable);
    setOrderBy(order);
  };

  const changePage = (page, totalRows) => {
    setCurrentPage(page);
  };

  const onLimitChnage = (currentRowsPerPage, currentPage) => {
    setPageSize(currentRowsPerPage);
  };

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handleStatusChange = (e) => {
    setDefaultStatusSelect(e);
  };
  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Testimonials</CardText>
        {writePermission?.permissions?.length > 0 &&
          writePermission?.permissions.includes("create") && (
            <Button
              color="primary"
              className="d-flex ms-auto "
              onClick={() => navigate("add")}
            >
              ADD
            </Button>
          )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: "Rows per page:",
            rangeSeparatorText: "of",
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: "All",
          }}
          paginationPerPage={paginationTestimonial?.limit}
          paginationTotalRows={TestimonialData?.total}
          currentPage={paginationTestimonial?.page}
          paginationDefaultPage={paginationTestimonial?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={changePage}
          onChangeRowsPerPage={onLimitChnage}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<TableLoading />}
          noDataComponent={<NoDataComponent />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={handleSort}
          persistTableHead={true}
          sortServer
          paginationServer
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handleFilter}
              StatusFilter={statusDropdownData}
              is_filter={true}
              defaultStatusSelect={defaultStatusSelect}
              setDefaultStatusSelect={handleStatusChange}
            />
          }
        />
      </div>
    </Card>
  );
};

export default Testimonial;
