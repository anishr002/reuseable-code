import Spinner from "@components/spinner/Loading-spinner";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import "react-quill/dist/quill.snow.css";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
} from "reactstrap";
import * as Yup from "yup";
import placholderImg from "../../assets/images/pages/placeholder-thumbnail.webp";
import {
  addTestimonialAPI,
  editTestimonialAPI,
  getTestimonialDetailesAPI,
} from "../../redux/testimonialManagement";
import { onSetLogo } from "../../utility/Utils";
import withPermissionCheck from "../withPermissionCheck";

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { singleTestimonialDetailes } = useSelector(
    (state) => state?.root?.TestimonialManagementSlice
  );
  const [avatarForTestimonialImg, setAvatarForTestimonialImg] = useState("");
  const [testimonialImage, setTestimonialImage] = useState(null);

  const isEditRoute = () => location.pathname.includes("edit");
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validationSchema = Yup.object().shape({
    userName: Yup.string()
      .trim()
      .required("Name is required")
      .max(50, "Name cannot exceed 50 characters"),
    message: Yup.string()
      .trim()
      .required("Message is required")
      .max(1000, "Message cannot exceed 1000 characters"),
    status: Yup.object().nullable().required("Status is required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      userName: "",
      message: "",
      status: null,
    },
  });

  useEffect(() => {
    if (isEditRoute()) {
      dispatch(getTestimonialDetailesAPI(id, "edit"));
    }
  }, [dispatch, id]);

  useEffect(() => {
    if (isEditRoute() && singleTestimonialDetailes) {
      setValue("userName", singleTestimonialDetailes?.userName);
      setValue("message", singleTestimonialDetailes?.message);
      setValue(
        "status",
        singleTestimonialDetailes?.status === 1
          ? { value: 1, label: "Active" }
          : { value: 2, label: "Inactive" }
      );
      setAvatarForTestimonialImg(singleTestimonialDetailes?.testimonial_image);
      setTestimonialImage(singleTestimonialDetailes?.testimonial_image);
    }
  }, [singleTestimonialDetailes, setValue]);

  const onSubmit = (data) => {
    const payload = {
      userName: data?.userName,
      message: data?.message,
      status: data?.status?.value,
    };

    if (typeof testimonialImage !== "string") {
      payload["testimonial_image"] = testimonialImage;
    }

    // Uncomment for actual API calls
    isEditRoute()
      ? dispatch(editTestimonialAPI(payload, navigate, id))
      : dispatch(addTestimonialAPI(payload, navigate));
  };

  const handleImgReset = () => {
    setAvatarForTestimonialImg("");
    setTestimonialImage(null);
  };

  const handleImageError = (e) => {
    // Replace the broken image with a default avatar or placeholder
    e.target.src = placholderImg;
  };
  return (
    <Card>
      <CardHeader>
        <CardText tag="h3">{id ? "Edit" : "Add"} Testimonial</CardText>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-1" onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="userName">
                    Name<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="userName"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.userName}
                        placeholder="Enter Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.userName && (
                    <FormFeedback>{errors.userName.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="status">
                    Status<span className="text-danger">*</span>
                  </Label>
                  <Controller
                    name="status"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={[
                          { value: 1, label: "Active" },
                          { value: 2, label: "Inactive" },
                        ]}
                        className={`react-select ${
                          errors.status && "is-invalid"
                        }`}
                        classNamePrefix="select"
                        isSearchable
                        placeholder="Select Status"
                      />
                    )}
                  />
                  {errors.status && (
                    <FormFeedback className="d-block">
                      {errors.status.message}
                    </FormFeedback>
                  )}
                </div>
              </Col>
            </Row>
            <Row className="mt-2">
              <Col xs={8} className="mt-1">
                <Label className="form-label" for="message">
                  Message<span className="text-danger">*</span>
                </Label>
                <div style={{ textAlign: "left" }}>
                  <Controller
                    name="message"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <Input
                        type="textarea"
                        className="form-control"
                        invalid={errors.message}
                        placeholder="Enter Message"
                        {...field}
                        style={{ height: "150px" }}
                      />
                    )}
                  />
                  {errors.message && (
                    <FormFeedback className="d-block">
                      {errors.message?.message || "Answer is required"}
                    </FormFeedback>
                  )}
                </div>
              </Col>
              <Col sm="6" className="mt-2">
                <Label className="form-label" for="content">
                  Testimonial Image
                </Label>
                <div className="border-end pe-3 d-flex align-item-center mt-75 mb-2">
                  <div className="me-2">
                    <img
                      className="rounded-circle me-100"
                      src={avatarForTestimonialImg || placholderImg}
                      height="100"
                      width="100"
                      alt="testimonial_image"
                      onError={handleImageError}
                    />
                  </div>
                  <div className="d-flex flex-column justify-content-center ms-1">
                    <Button
                      tag={Label}
                      className="mb-75  py-1 px-2"
                      size="sm"
                      color="primary"
                      outline
                    >
                      Upload
                      <Input
                        type="file"
                        onChange={(e) =>
                          onSetLogo(
                            e,
                            setTestimonialImage,
                            setAvatarForTestimonialImg
                          )
                        }
                        hidden
                        accept="image/*"
                      />
                    </Button>
                    <Button
                      color="flat-danger"
                      size="sm"
                      onClick={() => handleImgReset()}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-end mt-2">
              <Link to={`${prefix}/testimonial-management`}>
                <Button color="primary" className="me-1">
                  Cancel
                </Button>
              </Link>
              <Button color="primary" type="submit" className="d-flex">
                {isEditRoute() ? "Save" : "Add"}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

const TestimonialAddEditWithPermission = withPermissionCheck(
  AddEdit,
  "testimonial",
  "/testimonial-management"
);

export default TestimonialAddEditWithPermission;
