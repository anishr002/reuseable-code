import React, { useState } from "react";
import { Edit2, Trash2, Eye } from "react-feather";
import { Link } from "react-router-dom";
import { Badge, Modal, ModalHeader, ModalBody, Row, Col } from "reactstrap";
import { showAlert } from "../../@core/components/CutomAlert/CutomAlert";
import {
  deleteTestimonialAPI,
  getTestimonialDetailesAPI,
} from "../../redux/testimonialManagement";
import { store } from "../../redux/store";
import placholderImg from "../../assets/images/pages/placeholder-thumbnail.webp";
import { stripHtmlTags } from "../../utility/Utils";

// Function to handle image error
const handleImageError = (e) => {
  e.target.src = placholderImg;
};

// Modal to show testimonial details
const ViewDetailsModal = ({ isOpen, toggle, details }) => {
  return (
    <Modal isOpen={isOpen} toggle={toggle} size="lg">
      <ModalHeader toggle={toggle}>Testimonial Details</ModalHeader>
      <ModalBody>
        <Row>
          <Col md="8">
            <p>
              <strong>User Name:</strong> {details?.userName}
            </p>
            <p>
              <strong>Message:</strong>
            </p>
            <div>{stripHtmlTags(details?.message)}</div>
            <p className="pt-2">
              <strong>Status:</strong>{" "}
              {details?.status === 1 ? "Active" : "Inactive"}
            </p>
          </Col>
          <Col md="4" className="text-center">
            {details?.testimonial_image && (
              <img
                src={details?.testimonial_image}
                onError={handleImageError}
                alt="Testimonial"
                style={{
                  width: "100%",
                  maxHeight: "300px",
                  objectFit: "cover",
                }}
              />
            )}
          </Col>
        </Row>
      </ModalBody>
    </Modal>
  );
};

// Actions Cell Component
const ActionsCell = ({ row }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [testimonialDetails, setTestimonialDetails] = useState(null);

  const toggleModal = () => setModalOpen(!modalOpen);

  const handleViewClick = async (id) => {
    try {
      await store.dispatch(getTestimonialDetailesAPI(id, "column"));
      const { singleTestimonialDetailes } =
        store.getState().root.TestimonialManagementSlice;
      setTestimonialDetails(singleTestimonialDetailes);
      toggleModal();
    } catch (error) {
      console.error("Error fetching testimonial details:", error);
    }
  };

  return (
    <div className="d-flex">
      {row?.writePermission?.includes("edit") ? (
        <Link to={`edit/${row?.id}`} className="text-decoration-none">
          <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
        </Link>
      ) : (
        <Edit2 size={16} className="me-2 cursor-not-allowed icon-color-cust" />
      )}

      <Trash2
        size={16}
        color="red"
        className={
          row?.writePermission?.includes("delete")
            ? "me-2 cursor-pointer icon-color-cust"
            : "me-2 cursor-not-allowed icon-color-cust"
        }
        onClick={
          row?.writePermission?.includes("delete")
            ? () => showAlert(row?.id, deleteTestimonialAPI, "Testimonial")
            : () => {}
        }
      />

      <Eye
        size={16}
        color="black"
        className="cursor-pointer icon-color-cust"
        onClick={() => handleViewClick(row?.id)}
      />

      {/* View Details Modal */}
      <ViewDetailsModal
        isOpen={modalOpen}
        toggle={toggleModal}
        details={testimonialDetails}
      />
    </div>
  );
};

// Main columns definition
export const columns = [
  {
    name: "User Name",
    minWidth: "150px",
    sortable: "userName",
    cell: (row) => <div className="truncate-text">{row?.userName}</div>,
  },
  {
    name: "Message",
    sortable: "message",
    minWidth: "150px",
    selector: (row) => <div className="truncate-text">{row?.message}</div>,
  },
  {
    name: "Status",
    sortable: "status",
    minWidth: "150px",
    selector: (row) => (
      <Badge
        color={String(row?.status) === "1" ? "success" : "danger"}
        className={String(row?.status) === "1" ? "custom-badge" : ""}
        pill
      >
        {String(row?.status) === "1" ? "Active" : "Inactive"}
      </Badge>
    ),
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => <ActionsCell row={row} />, // Using ActionsCell here
  },
];
