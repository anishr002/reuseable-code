import { useSkin } from "@hooks/useSkin";
import { Link, useNavigate } from "react-router-dom";
import { ChevronLeft } from "react-feather";
import InputPassword from "@components/input-password-toggle";
import {
  Row,
  Col,
  CardTitle,
  CardText,
  Form,
  FormGroup,
  Label,
  Button,
  FormFeedback,
  Spinner,
} from "reactstrap";
import { Formik, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "@styles/react/pages/page-authentication.scss";

// ** Illustrations Imports
import illustrationsLight from "@src/assets/images/pages/reset-password-v2.svg";
import illustrationsDark from "@src/assets/images/pages/reset-password-v2-dark.svg";
import { useDispatch, useSelector } from "react-redux";
import { changePasswordApi } from "../../redux/authentication";
import themeConfig from "../../configs/themeConfig";

const ResetPasswordV2 = () => {
  const { skin } = useSkin();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get("token");
  const source = skin === "dark" ? illustrationsDark : illustrationsLight;
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const validationSchema = Yup.object().shape({
    new_password: Yup.string()
      .trim()
      .required("Password is required")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})/,
        "Password must be 8-16 characters and include at least one uppercase letter, one lowercase letter, and one special character"
      )
      .max(16, "Password must not exceed 16 characters"),

    confirm_password: Yup.string()
      .trim()
      .required("Password confirmation is required")
      .oneOf([Yup.ref("new_password"), null], "Passwords must match"),
  });

  const onSubmit = (values, { setSubmitting }) => {
    if (Object.values(values).every((field) => field?.length > 0)) {
      dispatch(
        changePasswordApi(
          { new_password: values.new_password, reset_password_token: token },
          navigate
        )
      );
    }
    setSubmitting(false);
  };

  return (
    <div className="auth-wrapper auth-cover">
      <Row className="auth-inner m-0">
        <Link
          className="brand-logo"
          to={`${prefix}/`}
          onClick={(e) => e.preventDefault()}
        >
          <img
            src={themeConfig.app.appLogoImage}
            style={{ width: "20%" }}
            alt="alt"
          />
        </Link>
        <Col className="d-none d-lg-flex align-items-center p-2" lg="8" sm="12">
          <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
            <img className="img-fluid" src={source} alt="Login V2" />
          </div>
        </Col>
        <Col
          className="d-flex align-items-center auth-bg px-2 p-lg-5"
          lg="4"
          sm="12"
        >
          <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
            <CardTitle tag="h2" className="font-weight-bold mb-1">
              Reset Password 🔒
            </CardTitle>
            <CardText className="mb-2">
              Your new password must be different from previously used passwords
            </CardText>
            <Formik
              initialValues={{
                new_password: "",
                confirm_password: "",
              }}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {({ errors, touched, handleSubmit, isSubmitting }) => (
                <Form
                  className="auth-reset-password-form mt-2"
                  onSubmit={handleSubmit}
                >
                  <FormGroup>
                    <Label className="form-label" for="new_password">
                      New Password
                    </Label>
                    <Field
                      name="new_password"
                      //   type="password"
                      as={InputPassword}
                      autoFocus
                      className={`input-group-merge ${
                        errors.new_password && touched.new_password
                          ? "is-invalid"
                          : ""
                      }`}
                    />
                    <ErrorMessage
                      name="new_password"
                      component={FormFeedback}
                    />
                  </FormGroup>
                  <FormGroup>
                    <Label className="form-label" for="confirm_password">
                      Confirm Password
                    </Label>
                    <Field
                      name="confirm_password"
                      //   type="password"
                      as={InputPassword}
                      className={`input-group-merge ${
                        errors.confirm_password && touched.confirm_password
                          ? "is-invalid"
                          : ""
                      }`}
                    />
                    <ErrorMessage
                      name="confirm_password"
                      component={FormFeedback}
                    />
                  </FormGroup>
                  <Button
                    color="primary"
                    type="submit"
                    block
                    disabled={isLoading}
                  >
                    Set New Password
                    {isLoading && <Spinner size="sm" className="ms-1" />}
                  </Button>
                </Form>
              )}
            </Formik>
            <p className="text-center mt-2">
              <Link to={`${prefix}/login`}>
                <ChevronLeft className="mr-25" size={14} />
                <span className="align-middle">Back to login</span>
              </Link>
            </p>
          </Col>
        </Col>
      </Row>
    </div>
  );
};

export default ResetPasswordV2;
