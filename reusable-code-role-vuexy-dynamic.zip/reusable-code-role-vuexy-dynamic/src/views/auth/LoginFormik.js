// ** React Imports
import { useSkin } from "@hooks/useSkin";
import { Link, useNavigate } from "react-router-dom";

// ** Icons Imports

// ** Custom Components
import InputPasswordToggle from "@components/input-password-toggle";

// ** Reactstrap Imports
import {
  Button,
  CardText,
  CardTitle,
  Col,
  Form,
  Input,
  Label,
  Row,
  Spinner,
} from "reactstrap";

// ** Illustrations Imports
import illustrationsDark from "@src/assets/images/pages/login-v2-dark.svg";
import illustrationsLight from "@src/assets/images/pages/login-v2.svg";

// ** Styles
import "@styles/react/pages/page-authentication.scss";

// ** Formik & Yup Imports
import { ErrorMessage, Field, Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import * as Yup from "yup";
import themeConfig from "../../configs/themeConfig";
import { loginAPI } from "../../redux/authentication";

const Login = () => {
  const { skin } = useSkin();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const source = skin === "dark" ? illustrationsDark : illustrationsLight;
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const validationSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email format").required("Required"),
    password: Yup.string().required("Required"),
  });

  const initialValues = {
    email: "",
    password: "",
  };

  const handleSubmit = (values) => {
    dispatch(loginAPI({ ...values, loginType: "adminSite" }, navigate));
  };

  return (
    <div className="auth-wrapper auth-cover">
      <Row className="auth-inner m-0">
        <Link
          className="brand-logo"
          to={`${prefix}/`}
          onClick={(e) => e.preventDefault()}
        >
          <img
            src={themeConfig.app.appLogoImage}
            style={{ width: "20%" }}
            alt="logo"
          />
        </Link>
        <Col className="d-none d-lg-flex align-items-center p-5" lg="8" sm="12">
          <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
            <img className="img-fluid" src={source} alt="Login Cover" />
          </div>
        </Col>
        <Col
          className="d-flex align-items-center auth-bg px-2 p-lg-5"
          lg="4"
          sm="12"
        >
          <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
            <CardTitle tag="h2" className="fw-bold mb-1">
              Welcome to Tridhya! 👋
            </CardTitle>
            <CardText className="mb-2">
              Please sign-in to your account and start the adventure
            </CardText>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, handleSubmit }) => (
                <Form className="auth-login-form mt-2" onSubmit={handleSubmit}>
                  <div className="mb-1">
                    <Label className="form-label" for="login-email">
                      Email
                    </Label>
                    <Field
                      as={Input}
                      type="email"
                      id="login-email"
                      name="email"
                      placeholder="john@example.com"
                      className={
                        errors.email && touched.email ? "is-invalid" : ""
                      }
                      autoFocus
                    />
                    <ErrorMessage
                      name="email"
                      component="div"
                      className="invalid-feedback"
                    />
                  </div>
                  <div className="mb-1">
                    <div className="d-flex justify-content-between">
                      <Label className="form-label" for="login-password">
                        Password
                      </Label>
                      <Link to={`${prefix}/forgot-password`}>
                        <small>Forgot Password?</small>
                      </Link>
                    </div>
                    <Field
                      as={InputPasswordToggle}
                      className={
                        errors.password && touched.password
                          ? "is-invalid input-group-merge"
                          : "input-group-merge"
                      }
                      id="login-password"
                      name="password"
                    />
                    <ErrorMessage
                      name="password"
                      component="div"
                      className="invalid-feedback"
                    />
                  </div>
                  <Button
                    type="submit"
                    color="primary"
                    disabled={isLoading}
                    block
                  >
                    {isLoading && <Spinner size="sm" className="ms-1" />}
                  </Button>
                </Form>
              )}
            </Formik>
          </Col>
        </Col>
      </Row>
    </div>
  );
};

export default Login;
