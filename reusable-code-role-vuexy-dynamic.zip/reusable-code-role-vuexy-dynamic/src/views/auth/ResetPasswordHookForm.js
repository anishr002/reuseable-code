import { useSkin } from "@hooks/useSkin";
import { Link, useNavigate } from "react-router-dom";
import { ChevronLeft } from "react-feather";
import InputPassword from "@components/input-password-toggle";
import {
  Row,
  Col,
  CardTitle,
  CardText,
  Form,
  FormGroup,
  Label,
  Button,
  FormFeedback,
  Spinner,
} from "reactstrap";
import { useForm, Controller } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

import "@styles/react/pages/page-authentication.scss";

// ** Illustrations Imports
import illustrationsLight from "@src/assets/images/pages/reset-password-v2.svg";
import illustrationsDark from "@src/assets/images/pages/reset-password-v2-dark.svg";
import { useDispatch, useSelector } from "react-redux";
import { changePasswordApi } from "../../redux/authentication";
import themeConfig from "../../configs/themeConfig";

const ResetPasswordV2 = () => {
  const { skin } = useSkin();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get("token");
  const source = skin === "dark" ? illustrationsDark : illustrationsLight;
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  const validationSchema = Yup.object().shape({
    new_password: Yup.string()
      .trim()
      .required("Password is required")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})/,
        "Password must be 8-16 characters and include at least one uppercase letter, one lowercase letter, and one special character"
      )
      .max(16, "Password must not exceed 16 characters"),

    confirm_password: Yup.string()
      .trim()
      .required("Password confirmation is required")
      .oneOf([Yup.ref("new_password"), null], "Passwords must match"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      new_password: "",
      confirm_password: "",
    },
  });

  const onSubmit = (data) => {
    if (Object.values(data).every((field) => field?.length > 0)) {
      dispatch(
        changePasswordApi(
          { new_password: data?.new_password, reset_password_token: token },
          navigate
        )
      );
    }
  };

  return (
    <div className="auth-wrapper auth-cover">
      <Row className="auth-inner m-0">
        <Link
          className="brand-logo"
          to={`${prefix}/`}
          onClick={(e) => e.preventDefault()}
        >
          <img
            src={themeConfig.app.appLogoImage}
            style={{ width: "20%" }}
            alt="logo"
          />
        </Link>
        <Col className="d-none d-lg-flex align-items-center p-5" lg="8" sm="12">
          <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
            <img className="img-fluid" src={source} alt="Login V2" />
          </div>
        </Col>
        <Col
          className="d-flex align-items-center auth-bg px-2 p-lg-5"
          lg="4"
          sm="12"
        >
          <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
            <CardTitle tag="h2" className="font-weight-bold mb-1">
              Reset Password 🔒
            </CardTitle>
            <CardText className="mb-2">
              Your new password must be different from previously used passwords
            </CardText>
            <Form
              className="auth-reset-password-form mt-2"
              onSubmit={handleSubmit(onSubmit)}
            >
              <FormGroup>
                <Label className="form-label" for="new_password">
                  New Password
                </Label>
                <Controller
                  id="new_password"
                  name="new_password"
                  control={control}
                  render={({ field }) => (
                    <InputPassword
                      autoFocus
                      className="input-group-merge"
                      invalid={errors.new_password}
                      {...field}
                    />
                  )}
                />
                {errors.new_password && (
                  <FormFeedback>{errors.new_password.message}</FormFeedback>
                )}
              </FormGroup>
              <FormGroup>
                <Label className="form-label" for="confirm_password">
                  Confirm Password
                </Label>
                <Controller
                  id="confirm_password"
                  name="confirm_password"
                  control={control}
                  render={({ field }) => (
                    <InputPassword
                      className="input-group-merge"
                      invalid={errors.confirm_password}
                      {...field}
                    />
                  )}
                />
                {errors.confirm_password && (
                  <FormFeedback>{errors.confirm_password.message}</FormFeedback>
                )}
              </FormGroup>
              <Button.Ripple
                color="primary"
                type="submit"
                disabled={isLoading}
                block
              >
                Set New Password
                {isLoading && <Spinner size="sm" className="ms-1" />}
              </Button.Ripple>
            </Form>
            <p className="text-center mt-2">
              <Link to={`${prefix}/login`}>
                <ChevronLeft className="mr-25" size={14} />
                <span className="align-middle">Back to login</span>
              </Link>
            </p>
          </Col>
        </Col>
      </Row>
    </div>
  );
};

export default ResetPasswordV2;
