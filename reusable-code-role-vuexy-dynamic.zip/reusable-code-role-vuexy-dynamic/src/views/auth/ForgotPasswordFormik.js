// ** React Imports
import { Link, useNavigate } from "react-router-dom";

// ** Custom Hooks
import { useSkin } from "@hooks/useSkin";

// ** Icons Imports
import { ChevronLeft } from "react-feather";

// ** Reactstrap Imports
import {
  Row,
  Col,
  CardTitle,
  CardText,
  Form,
  Label,
  Input,
  Button,
} from "reactstrap";

// ** Illustrations Imports
import illustrationsLight from "@src/assets/images/pages/forgot-password-v2.svg";
import illustrationsDark from "@src/assets/images/pages/forgot-password-v2-dark.svg";

// ** Styles
import "@styles/react/pages/page-authentication.scss";

// ** Formik & Yup Imports
import { Formik, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useDispatch } from "react-redux";
import { forgotPasswordApi } from "../../redux/authentication";
import themeConfig from "../../configs/themeConfig";

const ForgotPasswordFormik = () => {
  // ** Hooks
  const { skin } = useSkin();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;
  const source = skin === "dark" ? illustrationsDark : illustrationsLight;

  const validationSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email format").required("Required"),
  });

  const initialValues = {
    email: "",
  };

  const handleSubmit = (values) => {
    dispatch(forgotPasswordApi({ emailOrMobile: values?.email }, navigate));
  };

  return (
    <div className="auth-wrapper auth-cover">
      <Row className="auth-inner m-0">
        <Link
          className="brand-logo"
          to={`${prefix}/`}
          onClick={(e) => e.preventDefault()}
        >
          <img
            src={themeConfig.app.appLogoImage}
            style={{ width: "20%" }}
            alt="logo"
          />
        </Link>
        <Col className="d-none d-lg-flex align-items-center p-5" lg="8" sm="12">
          <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
            <img className="img-fluid" src={source} alt="Forgot Password" />
          </div>
        </Col>
        <Col
          className="d-flex align-items-center auth-bg px-2 p-lg-5"
          lg="4"
          sm="12"
        >
          <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
            <CardTitle tag="h2" className="fw-bold mb-1">
              Forgot Password? 🔒
            </CardTitle>
            <CardText className="mb-2">
              Enter your email and we'll send you instructions to reset your
              password
            </CardText>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={handleSubmit}
            >
              {({ handleSubmit }) => (
                <Form
                  className="auth-forgot-password-form mt-2"
                  onSubmit={handleSubmit}
                >
                  <div className="mb-1">
                    <Label className="form-label" for="email">
                      Email
                    </Label>
                    <Field
                      as={Input}
                      type="email"
                      id="email"
                      name="email"
                      placeholder="john@example.com"
                      className={({ errors, touched }) =>
                        errors.email && touched.email ? "is-invalid" : ""
                      }
                      autoFocus
                    />
                    <ErrorMessage
                      name="email"
                      component="div"
                      className="invalid-feedback"
                    />
                  </div>
                  <Button type="submit" color="primary" block>
                    Send reset link
                  </Button>
                </Form>
              )}
            </Formik>
            <p className="text-center mt-2">
              <Link to={`${prefix}/login`}>
                <ChevronLeft className="rotate-rtl me-25" size={14} />
                <span className="align-middle">Back to login</span>
              </Link>
            </p>
          </Col>
        </Col>
      </Row>
    </div>
  );
};

export default ForgotPasswordFormik;
