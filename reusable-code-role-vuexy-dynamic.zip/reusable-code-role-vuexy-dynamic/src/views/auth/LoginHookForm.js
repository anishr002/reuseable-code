// ** React Imports
import { useSkin } from "@hooks/useSkin";
import { Link, useNavigate } from "react-router-dom";

// ** Custom Components
import InputPasswordToggle from "@components/input-password-toggle";

// ** Reactstrap Imports
import {
  Button,
  CardText,
  CardTitle,
  Col,
  Form,
  Input,
  Label,
  Row,
  Spinner,
} from "reactstrap";

// ** Illustrations Imports
import illustrationsDark from "@src/assets/images/pages/login-v2-dark.svg";
import illustrationsLight from "@src/assets/images/pages/login-v2.svg";

// ** Styles
import "@styles/react/pages/page-authentication.scss";

// ** React Hook Form & Yup Imports
import { yupResolver } from "@hookform/resolvers/yup";
import { useContext } from "react";
import { Controller, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import * as Yup from "yup";
import themeConfig from "../../configs/themeConfig";
import { loginAPI } from "../../redux/authentication";
import { SocketContext } from "../../utility/context/SocketProvider";

const Login = () => {
  const { skin } = useSkin();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const { socket, isSocketConnected } = useContext(SocketContext);
  const source = skin === "dark" ? illustrationsDark : illustrationsLight;
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;
  const validationSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email format").required("Required"),
    password: Yup.string().required("Required"),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onSubmit = (data) => {
    dispatch(loginAPI({ ...data, loginType: "adminSite" }, navigate)).then(
      (res) => {
        if (res?.status === 200) {
          socket.connect();
          socket.emit("joinRoom", res?.data?.data?._id);
        }
      }
    );
  };

  return (
    <div className="auth-wrapper auth-cover">
      <Row className="auth-inner m-0">
        <Link
          className="brand-logo"
          to={`${prefix}/`}
          onClick={(e) => e.preventDefault()}
        >
          <img
            src={themeConfig.app.appLogoImage}
            style={{ width: "20%" }}
            alt="logo"
          />
        </Link>
        <Col className="d-none d-lg-flex align-items-center p-5" lg="8" sm="12">
          <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
            <img className="img-fluid" src={source} alt="Login Cover" />
          </div>
        </Col>
        <Col
          className="d-flex align-items-center auth-bg px-2 p-lg-5"
          lg="4"
          sm="12"
        >
          <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
            <CardTitle tag="h2" className="fw-bold mb-1">
              Welcome to Tridhya! 👋
            </CardTitle>
            <CardText className="mb-2">
              Please sign-in to your account and start the adventure
            </CardText>
            <Form
              className="auth-login-form mt-2"
              onSubmit={handleSubmit(onSubmit)}
            >
              <div className="mb-1">
                <Label className="form-label" for="login-email">
                  Email
                </Label>
                <Controller
                  name="email"
                  control={control}
                  render={({ field }) => (
                    <Input
                      type="email"
                      id="login-email"
                      placeholder="john@example.com"
                      autoFocus
                      className={errors.email ? "is-invalid" : ""}
                      {...field}
                    />
                  )}
                />
                {errors.email && (
                  <div className="invalid-feedback">{errors.email.message}</div>
                )}
              </div>
              <div className="mb-1">
                <div className="d-flex justify-content-between">
                  <Label className="form-label" for="login-password">
                    Password
                  </Label>
                  <Link to={`${prefix}/forgot-password`}>
                    <small>Forgot Password?</small>
                  </Link>
                </div>
                <Controller
                  name="password"
                  control={control}
                  render={({ field }) => (
                    <InputPasswordToggle
                      className={
                        errors.password
                          ? "is-invalid input-group-merge"
                          : "input-group-merge"
                      }
                      id="login-password"
                      {...field}
                    />
                  )}
                />
                {errors.password && (
                  <div className="invalid-feedback">
                    {errors.password.message}
                  </div>
                )}
              </div>
              <Button type="submit" color="primary" disabled={isLoading} block>
                Sign in
                {isLoading && <Spinner size="sm" className="ms-1" />}
              </Button>
            </Form>
          </Col>
        </Col>
      </Row>
    </div>
  );
};

export default Login;
