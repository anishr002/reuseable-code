// ** React Imports
import { useEffect } from "react";
import { NavLink } from "react-router-dom";

// ** Icons Imports
import { Disc, X, Circle } from "react-feather";

// ** Config
import themeConfig from "@configs/themeConfig";

// ** Utils
import { getUserData, getHomeRouteForLoggedInUser } from "@utils";
import { useSelector } from "react-redux";
import PropTypes from "prop-types";

// ** Toggler component (outside the main function)
const Toggler = ({ menuCollapsed, setMenuCollapsed }) => {
  return menuCollapsed ? (
    <Circle
      size={20}
      data-tour="toggle-icon"
      className="text-primary toggle-icon d-none d-xl-block"
      onClick={() => setMenuCollapsed(false)}
    />
  ) : (
    <Disc
      size={20}
      data-tour="toggle-icon"
      className="text-primary toggle-icon d-none d-xl-block"
      onClick={() => setMenuCollapsed(true)}
    />
  );
};

// ** Main Component
const VerticalMenuHeader = (props) => {
  // ** Props
  const {
    menuCollapsed,
    setMenuCollapsed,
    setMenuVisibility,
    setGroupOpen,
    menuHover,
    menuVisibility,
  } = props;

  const { UserData } = useSelector((state) => state.root.authentication);

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  // ** Vars
  const user = getUserData();

  // ** Reset open group
  useEffect(() => {
    if (!menuHover && menuCollapsed) setGroupOpen([]);
  }, [menuHover, menuCollapsed]);

  // ** Extracted variables for logo and className (refactored)
  let logoSrc = themeConfig.app.appLogoImage;

  if (menuVisibility) {
    logoSrc = themeConfig.app.appLogoImage;
  } else if (!menuHover && menuCollapsed) {
    logoSrc = themeConfig.app.appSmallLogo;
  }

  const brandClassName = () => {
    if (menuVisibility) {
      return "brand-logo text-center";
    } else if (!menuHover && menuCollapsed) {
      return "brand-logo-small text-center";
    }
    return "brand-logo text-center";
  };

  return (
    <div className="navbar-header">
      <ul className="nav navbar-nav flex-row">
        <li className="nav-item me-auto">
          <NavLink
            to={
              user
                ? getHomeRouteForLoggedInUser(user.role, UserData, prefix)
                : `${prefix}/`
            }
            className="navbar-brand"
          >
            <span className={brandClassName()}>
              <img src={logoSrc} alt="logo" />
            </span>
          </NavLink>
        </li>
        <li className="nav-item nav-toggle">
          <div className="nav-link modern-nav-toggle cursor-pointer">
            <Toggler
              menuCollapsed={menuCollapsed}
              setMenuCollapsed={setMenuCollapsed}
            />
            <X
              onClick={() => setMenuVisibility(false)}
              className="toggle-icon icon-x d-block d-xl-none"
              size={20}
            />
          </div>
        </li>
      </ul>
    </div>
  );
};

export default VerticalMenuHeader;

// ** PropTypes for validation
VerticalMenuHeader.propTypes = {
  menuVisibility: PropTypes.bool,
  menuCollapsed: PropTypes.bool.isRequired,
  setMenuCollapsed: PropTypes.func.isRequired,
  setMenuVisibility: PropTypes.func.isRequired,
  setGroupOpen: PropTypes.func.isRequired,
  menuHover: PropTypes.bool,
};

Toggler.propTypes = {
  menuCollapsed: PropTypes.bool.isRequired,
  setMenuCollapsed: PropTypes.func.isRequired,
};
