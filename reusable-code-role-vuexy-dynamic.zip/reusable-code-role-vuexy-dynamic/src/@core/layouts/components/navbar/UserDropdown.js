// ** React Imports
import { Link } from "react-router-dom";

// ** Custom Components
import Avatar from "@components/avatar";
import AvtarUser from "../../../../assets/images/portrait/avatar-blank.png";
// ** Third Party Components
import { Power, User } from "react-feather";

// ** Reactstrap Imports
import {
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  UncontrolledDropdown,
} from "reactstrap";

import { useContext, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getSetting, handleLogin } from "../../../../redux/authentication";
import { getProfileAPI, setSokectData } from "../../../../redux/profile";
import { store } from "../../../../redux/store";
import { SocketContext } from "../../../../utility/context/SocketProvider";

const UserDropdown = () => {
  const { profileData } = useSelector((state) => state?.root.ProfileSlice);
  const dispatch = useDispatch();
  const { socket, isSocketConnected } = useContext(SocketContext);

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  useEffect(() => {
    dispatch(getProfileAPI());
    dispatch(getSetting());
  }, []);

  useEffect(() => {
    socket.on("receivedNotification", (data) => dispatch(setSokectData(data)));
  }, [socket]);

  const resetStore = async () => {
    // const direction = localStorage.getItem("direction");
    // const skinTone = localStorage.getItem("skin");

    store.dispatch({ type: "RESET" });

    localStorage.clear();
    // localStorage.setItem("direction", direction);
    // localStorage.setItem("skin", skinTone);

    dispatch(handleLogin({ token: null }));
  };

  return (
    <UncontrolledDropdown tag="li" className="dropdown-user nav-item">
      <DropdownToggle
        href="/"
        tag="a"
        className="nav-link dropdown-user-link"
        onClick={(e) => e.preventDefault()}
      >
        <div className="user-nav d-sm-flex d-none">
          <span className="user-name fw-bold truncate-text">{`${
            profileData?.first_name ?? ""
          } ${profileData?.last_name ?? ""}`}</span>
          <span className="user-status">
            {profileData?.user_type === 1
              ? "Super Admin"
              : profileData?.role?.role_name ?? ""}
          </span>
        </div>
        <Avatar
          img={profileData?.profile_image || AvtarUser}
          imgHeight="40"
          imgWidth="40"
          status="online"
        />
      </DropdownToggle>
      <DropdownMenu end>
        <DropdownItem tag={Link} to={`${prefix}/profile`}>
          <User size={14} className="me-75" />
          <span className="align-middle">Profile</span>
        </DropdownItem>

        <DropdownItem
          tag={Link}
          to={`${prefix}/login`}
          onClick={() => resetStore()}
        >
          <Power size={14} className="me-75" />
          <span className="align-middle">Logout</span>
        </DropdownItem>
      </DropdownMenu>
    </UncontrolledDropdown>
  );
};

export default UserDropdown;
