// ** React Imports
import { Fragment, useEffect, useState } from "react";

// ** Custom Components

// // ** Third Party Components
import classnames from "classnames";
import { Bell } from "react-feather";
import PerfectScrollbar from "react-perfect-scrollbar";

// ** Reactstrap Imports
import {
  Badge,
  Button,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  UncontrolledDropdown,
} from "reactstrap";

import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  readAllNotificationAPI,
  readNotificationAPI,
} from "../../../../redux/profile";

const NotificationDropdown = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const notificationData = useSelector(
    (state) => state?.root?.ProfileSlice?.soket
  );

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  useEffect(() => {
    // Add event listener to handle clicks outside the dropdown
    document.addEventListener("click", handleDocumentClick);

    // Cleanup function to remove event listener when component unmounts
    return () => {
      document.removeEventListener("click", handleDocumentClick);
    };
  }, []);

  const handleDocumentClick = (e) => {
    // Check if the clicked element is outside the dropdown
    if (!e.target.closest(".dropdown-notification")) {
      setDropdownOpen(false);
    }
  };

  /*eslint-disable */
  const renderNotificationItems = () => {
    return (
      <PerfectScrollbar
        component="li"
        className="media-list scrollable-container"
        options={{
          wheelPropagation: false,
        }}
      >
        {notificationData?.data?.slice(0, 5)?.map((item, index) => {
          return (
            <a
              key={index}
              className="d-flex"
              // href={item.switch ? '#' : '/'}
              onClick={(e) => {
                if (!item.switch) {
                  dispatch(
                    readNotificationAPI({
                      notificationId: item?._id,
                    })
                  );
                  e.preventDefault();
                }
              }}
            >
              <div
                className={classnames("list-item d-flex", {
                  "align-items-start": !item.switch,
                  "align-items-center": item.switch,
                })}
              >
                {!item.switch ? (
                  <Fragment>
                    <div className="list-item-body flex-grow-1">
                      {item.message}
                      <small className="notification-text">
                        {item.subtitle}
                      </small>
                    </div>
                  </Fragment>
                ) : (
                  <Fragment>
                    {item.title}
                    {item.switch}
                  </Fragment>
                )}
              </div>
            </a>
          );
        })}
      </PerfectScrollbar>
    );
  };
  /*eslint-enable */

  return (
    <UncontrolledDropdown
      tag="li"
      className="dropdown-notification  me-25 dropdown"
      isOpen={dropdownOpen}
    >
      <DropdownToggle
        tag="a"
        className="nav-link"
        onClick={(e) => {
          setDropdownOpen(!dropdownOpen);
        }}
      >
        <Bell size={20} />
        <Badge pill color="danger" className="badge-up">
          {notificationData?.unReadCount ?? 0}
        </Badge>
      </DropdownToggle>
      <DropdownMenu end tag="ul" className="dropdown-menu-media mt-0">
        <li className="dropdown-menu-header">
          <DropdownItem className="d-flex" tag="div" header>
            <h4 className="notification-title mb-0 me-auto">Notifications</h4>
          </DropdownItem>
        </li>
        {notificationData?.data?.length > 0 ? (
          renderNotificationItems()
        ) : (
          <li
            className="align-items-center p-2"
            style={{ textAlign: "center" }}
          >
            No unread notifications
          </li>
        )}

        <li className="dropdown-menu-footer">
          {notificationData?.data?.length > 0 && (
            <Button
              color="primary"
              className="me-2"
              onClick={() => {
                dispatch(readAllNotificationAPI());
                navigate(`${prefix}/notifications`);
                setDropdownOpen(false);
              }}
            >
              Read all
            </Button>
          )}
          <Button
            color="primary"
            onClick={() => {
              navigate(`${prefix}/notifications`);
              setDropdownOpen(false);
            }}
          >
            View all
          </Button>
        </li>
      </DropdownMenu>
    </UncontrolledDropdown>
  );
};

export default NotificationDropdown;
