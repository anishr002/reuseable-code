// ** React Imports
import { Navigate } from "react-router-dom";
import React, { Suspense } from "react";
import Proptypes from "prop-types";

// ** Spinner Import
import Spinner from "../spinner/Loading-spinner";

const PrivateRoute = ({ children, route }) => {
  // ** Hooks & Vars
  const user = localStorage.getItem("accessToken");

  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

  if (route) {
    let restrictedRoute = false;

    if (route.meta) {
      restrictedRoute = route.meta.restricted;
    }
    if (!user) {
      return <Navigate to={`${prefix}/login`} />;
    }
    if (user && restrictedRoute) {
      return <Navigate to={`${prefix}/`} />;
    }
  }

  return (
    <Suspense fallback={<Spinner className="content-loader" />}>
      {children}
    </Suspense>
  );
};

export default PrivateRoute;

// ** PropTypes
PrivateRoute.propTypes = {
  children: Proptypes.any,
  route: Proptypes.any,
};
