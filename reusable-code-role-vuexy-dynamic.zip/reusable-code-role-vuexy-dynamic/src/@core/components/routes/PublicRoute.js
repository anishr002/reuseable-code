// ** React Imports
import { Suspense } from "react";
import { Navigate } from "react-router-dom";
import Proptypes from "prop-types";

// ** Utils
import { getUserData } from "@utils";

// ** Spinner Import
import Spinner from "../spinner/Loading-spinner";

const PublicRoute = ({ children }) => {
  const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;
  const user = getUserData();

  if (user) {
    return <Navigate to={`${prefix}/`} />;
  }

  return (
    <Suspense fallback={<Spinner className="content-loader" />}>
      {children}
    </Suspense>
  );
};

export default PublicRoute;

// ** PropTypes
PublicRoute.propTypes = {
  children: Proptypes.any,
};
