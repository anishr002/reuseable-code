// ** React Imports
import { useEffect, useState } from "react";

// ** Third Party Components
import classnames from "classnames";
import { Settings, X } from "react-feather";
import PerfectScrollbar from "react-perfect-scrollbar";

// ** Reactstrap Imports
import { Input, Label } from "reactstrap";

import Proptypes from "prop-types";

// ** Styles
import "@styles/react/libs/react-select/_react-select.scss";
import { useDispatch, useSelector } from "react-redux";
import { updateSetting } from "../../../redux/authentication";

const Customizer = (props) => {
  // ** Props
  const { skin, isRtl, layout, setSkin, setIsRtl } = props;

  // ** State
  const [openCustomizer, setOpenCustomizer] = useState(false);
  const [isNotification, setIsNotification] = useState(false);
  const { settingData, settingLoading } = useSelector(
    (state) => state.root?.authentication
  );

  const dispatch = useDispatch();

  useEffect(() => {
    if (settingData) {
      setIsNotification(settingData?.notification);
      setIsRtl(settingData?.direction === "RTL");
      setSkin(settingData?.appearance);
    }
  }, [settingData]);

  // ** Toggles Customizer
  const handleToggle = (e) => {
    e.preventDefault();
    setOpenCustomizer(!openCustomizer);
  };

  // ** Render Layout Skin Options
  const renderSkinsRadio = () => {
    const skinsArr = [
      {
        name: "light",
        label: "Light",
        checked: skin === "light",
      },
      {
        name: "dark",
        label: "Dark",
        checked: skin === "dark",
      },
    ];

    return skinsArr.map((radio, index) => {
      const marginCondition = index !== skinsArr.length - 1;

      if (layout === "horizontal" && radio.name === "semi-dark") {
        return null;
      }

      return (
        <div
          key={radio.name}
          className={classnames("form-check", { "mb-2 me-1": marginCondition })}
        >
          <Input
            type="radio"
            id={radio.name}
            checked={radio.checked}
            onChange={() => {
              // setSkin(radio.name);
              dispatch(
                updateSetting({ ...settingData, appearance: radio.name })
              );
            }}
          />
          <Label className="form-check-label" for={radio.name}>
            {radio.label}
          </Label>
        </div>
      );
    });
  };

  return (
    <div
      className={classnames("customizer  d-md-block", {
        open: openCustomizer,
      })}
    >
      <a
        href="/"
        className="customizer-toggle d-flex align-items-center justify-content-center"
        onClick={handleToggle}
      >
        <Settings size={14} className="spinner" />
      </a>
      <PerfectScrollbar
        className="customizer-content"
        options={{ wheelPropagation: false }}
      >
        <div className="customizer-header px-2 pt-1 pb-0 position-relative">
          <h4 className="mb-0">Settings</h4>
          <a href="/" className="customizer-close" onClick={handleToggle}>
            <X />
          </a>
        </div>
        <hr />
        <div className="px-2">
          <div className="mb-2">
            <p className="fw-bold">Skin</p>
            <div className="d-flex">{renderSkinsRadio()}</div>
          </div>

          <div className="form-switch mb-2 ps-0">
            <div className="d-flex">
              <p className="fw-bold me-auto mb-0">RTL</p>
              <Input
                type="switch"
                id="rtl"
                name="RTL"
                checked={isRtl}
                onChange={() => {
                  // setIsRtl(!isRtl);
                  dispatch(
                    updateSetting({
                      ...settingData,
                      direction: !isRtl ? "RTL" : "LTR",
                    })
                  );
                }}
              />
            </div>
          </div>

          <div className="form-switch mb-2 ps-0">
            <div className="d-flex">
              <p className="fw-bold me-auto mb-0">Notification</p>
              <Input
                type="switch"
                id="isNotification"
                name="Notification"
                checked={isNotification}
                onChange={() => {
                  // setIsNotification(!isNotification);

                  dispatch(
                    updateSetting({
                      ...settingData,
                      notification: !isNotification,
                    })
                  );
                }}
              />
            </div>
          </div>
        </div>
      </PerfectScrollbar>
    </div>
  );
};

export default Customizer;

// ** PropTypes
Customizer.propTypes = {
  skin: Proptypes.node,
  layout: Proptypes.string,
  isRtl: Proptypes.bool,
  setSkin: Proptypes.func,
  setIsRtl: Proptypes.func,
};
