import { useSelector } from "react-redux";

const NoDataComponent = () => {
  const { skin } = useSelector((state) => state?.root?.layout);

  return (
    <div
      className={`${
        skin === "dark"
          ? "table-loading-dark d-flex align-items-center justify-content-center text-white"
          : "table-loading-light d-flex align-items-center justify-content-center"
      }`}
    >
      <p className="d-flex justify-content-center">
        There are no records to display
      </p>
    </div>
  );
};

export default NoDataComponent;
