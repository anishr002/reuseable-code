import { Col, Input, InputGroup, InputGroupText, Row } from "reactstrap";
import Select from "react-select";
import { Search } from "react-feather";
import PropTypes from "prop-types";

const CustomHeader = ({
  searchValue,
  handle_filter,
  is_filter,
  is_more,
  AdminRoles,
  setDefaultRoleSelect,
  defaultRoleSelect,
  StatusFilter,
  setDefaultStatusSelect,
  defaultStatusSelect,
  defaultCategorySelect,
  setDefaultCategorySelect,
  CategoryFilter,
}) => {
  // Extracted logic for md value
  const getMdValue = () => {
    if (is_more) {
      return "4";
    } else if (StatusFilter === undefined && AdminRoles === undefined) {
      return "12";
    } else if (is_filter) {
      return "6";
    } else {
      return "12";
    }
  };

  return (
    <div className="invoice-list-table-header w-100 mr-1 ml-50 mt-2 mb-75">
      <Row>
        {!is_more && (
          <Col md="4" className="d-flex align-items-center p-0"></Col>
        )}
        <Col
          md={is_more ? "12" : "8"}
          className="d-flex align-items-sm-center justify-content-xl-end justify-content-start flex-xl-nowrap flex-wrap flex-sm-row flex-column"
        >
          <Row>
            <Col md={getMdValue()}>
              <div className="d-flex align-items-center">
                <InputGroup className="input-group-merge">
                  <InputGroupText>
                    <Search size={14} />
                  </InputGroupText>
                  <Input
                    className="dataTable-filter"
                    type="text"
                    bsSize="md"
                    id="search-input"
                    value={searchValue}
                    onChange={handle_filter}
                    placeholder="Search"
                  />
                </InputGroup>
              </div>
            </Col>
            {is_filter && AdminRoles?.length !== 0 && AdminRoles && (
              <Col md="6">
                <Select
                  options={[
                    { _id: null, role_name: "All" },
                    ...AdminRoles,
                  ]?.map((item) => ({
                    value: item?._id,
                    label: item?.role_name,
                  }))}
                  className="react-select w-100"
                  classNamePrefix="select"
                  value={defaultRoleSelect}
                  onChange={(e) => setDefaultRoleSelect(e)}
                  styles={{
                    control: (baseStyles) => ({
                      ...baseStyles,
                      borderColor: "#d8d6de",
                      minWidth: "230px",
                    }),
                  }}
                  placeholder="Select Role"
                  menuPortalTarget={document.body}
                />
              </Col>
            )}
            {is_filter && StatusFilter?.length !== 0 && StatusFilter && (
              <Col md={is_more ? "4" : "6"}>
                <Select
                  options={[
                    { value: null, label: "All" },
                    ...StatusFilter,
                  ]?.map((item) => item)}
                  className="react-select w-100"
                  classNamePrefix="select"
                  value={defaultStatusSelect}
                  onChange={(e) => setDefaultStatusSelect(e)}
                  styles={{
                    control: (baseStyles) => ({
                      ...baseStyles,
                      borderColor: "#d8d6de",
                      minWidth: "230px",
                    }),
                  }}
                  placeholder="Select Status"
                  menuPortalTarget={document.body}
                />
              </Col>
            )}
            {is_filter && CategoryFilter?.length !== 0 && CategoryFilter && (
              <Col md={is_more ? "4" : "6"}>
                <Select
                  options={[{ _id: null, name: "All" }, ...CategoryFilter]?.map(
                    (item) => ({ value: item?._id, label: item?.name })
                  )}
                  className="react-select w-100"
                  classNamePrefix="select"
                  value={defaultCategorySelect}
                  onChange={(e) => setDefaultCategorySelect(e)}
                  styles={{
                    control: (baseStyles) => ({
                      ...baseStyles,
                      borderColor: "#d8d6de",
                      minWidth: "230px",
                    }),
                  }}
                  placeholder="Select Category"
                  menuPortalTarget={document.body}
                />
              </Col>
            )}
          </Row>
        </Col>
      </Row>
    </div>
  );
};

export default CustomHeader;

CustomHeader.propTypes = {
  searchValue: PropTypes.string,
  AdminRoles: PropTypes.array,
  CategoryFilter: PropTypes.array,
  StatusFilter: PropTypes.array,
  handle_filter: PropTypes.func,
  is_filter: PropTypes.bool,
  is_more: PropTypes.bool,
  setDefaultRoleSelect: PropTypes.func,
  defaultRoleSelect: PropTypes.object,
  setDefaultStatusSelect: PropTypes.func,
  defaultStatusSelect: PropTypes.object,
  setDefaultCategorySelect: PropTypes.func,
  defaultCategorySelect: PropTypes.object,
};
