import { useSelector } from "react-redux";
import Spinner from "@components/spinner/Loading-spinner";

const TableLoading = () => {
  const { skin } = useSelector((state) => state?.root?.layout);

  return (
    <div
      className={`${
        skin === "dark" ? "table-loading-dark" : "table-loading-light"
      }`}
    >
      <Spinner open={true} />
    </div>
  );
};

export default TableLoading;
