import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2";
import { store } from "../../../redux/store";

const my_swal = withReactContent(Swal);

export const showAlert = (_id, deleteApi, nameOfTitle) => {
  const skin = store?.getState()?.root?.layout?.skin;

  return my_swal
    .fire({
      title: `Delete ${nameOfTitle}`,
      html: (
        <p>
          Are you sure
          <br />
          {`you want to delete this ${nameOfTitle?.toLowerCase()}?`}
        </p>
      ),
      icon: "warning",
      showCancelButton: false,
      confirmButtonText: "Delete",
      showCloseButton: true,
      customClass:
        skin === "dark"
          ? {
              confirmButton:
                "d-flex w-100 btn btn-primary btn-ripple btn-block",
              popup: "swal-popup-dark",
              title: "swal-title-dark",
              htmlContainer: "swal-html-dark",
              container: "swal-container-dark",
            }
          : {
              confirmButton:
                "d-flex w-100 btn btn-primary btn-ripple btn-block",
            },
      buttonsStyling: false,
    })
    .then(function (result) {
      if (result.isConfirmed) {
        store.dispatch(deleteApi(nameOfTitle === "Role" ? _id : [_id]));
      }
    });
};
