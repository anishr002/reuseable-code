import axios from "axios";
import { createBrowserHistory } from "history";
import toast from "react-hot-toast";
import { store } from "../../../redux/store";
import CustomToast, { ErrorCss } from "../../../utility/toast/CustomeToast";
import jwtDefaultConfig from "./jwtDefaultConfig";
const history = createBrowserHistory();

const jwtConfig = { ...jwtDefaultConfig };

let subscribers = [];

const onAccessTokenFetched = (accessToken) => {
  subscribers = subscribers.filter((callback) => callback(accessToken));
};

const addSubscriber = (callback) => {
  subscribers.push(callback);
};

const getToken = () => {
  return localStorage.getItem(jwtConfig.storageTokenKeyName);
};

const login = (...args) => {
  return axios.post(jwtConfig.loginEndpoint, ...args);
};

const register = (...args) => {
  return axios.post(jwtConfig.registerEndpoint, ...args);
};

const refreshToken = () => {
  return axios.post(jwtConfig.refreshEndpoint, {
    refreshToken: localStorage.getItem(jwtConfig.storageRefreshTokenKeyName),
  });
};

const axiosInstance = axios.create({
  baseURL: `${import.meta.env.VITE_APP_API_URL}`, // Set your API base URL here
});

// ** Request Interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    // ** Get token from localStorage
    const accessToken = getToken();

    // ** If token is present add it to request's Authorization Header
    if (accessToken) {
      // ** eslint-disable-next-line no-param-reassign
      config.headers.Authorization = `${jwtConfig.tokenType} ${accessToken}`;
    }
    // Check if the request config has a 'contentType' property
    if (config.contentType) {
      config.headers["Content-Type"] = config.contentType;
    } else {
      // If not, use the existing logic to determine content type based on the URL
      config.headers["Content-Type"] = "application/json";
    }
    return config;
  },
  (error) => Promise.reject(error)
);
// ** Add request/response interceptor
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

    if (error.response && error.response.status === 401) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );

      setTimeout(() => {
        localStorage.clear();
        const resetStore = async () => {
          store.dispatch({ type: "RESET" });
        };
        resetStore();

        history.push(`${prefix}/`);
        history.go(0);
      }, 1000);
    }

    if (error?.response?.data?.status === 4) {
      setTimeout(() => {
        history.push(`${prefix}/page-not-found`);
        history.go(0);
      }, 0);
      return;
    }

    return Promise.reject(error);
  }
);

export {
  addSubscriber,
  axiosInstance as axios,
  getToken,
  login,
  onAccessTokenFetched,
  refreshToken,
  register,
};
