// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";

import toast from "react-hot-toast";
import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const formBuilderSlice = createSlice({
  name: "formBuilderSlice",
  initialState: {
    FormsData: [],
    singleFormDetailes: {},
    paginationForms: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "desc",
    },
  },
  reducers: {
    setFormsData: (state, action) => {
      state.FormsData = action.payload;
    },
    setSingleFormDetailes: (state, action) => {
      state.singleFormDetailes = action.payload;
    },
    setPaginationForms: (state, action) => {
      state.paginationForms = action.payload;
    },
  },
});

export const { setFormsData, setSingleFormDetailes, setPaginationForms } =
  formBuilderSlice.actions;

export const getFormsApiCall = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("forms", { params: { ...data } }).then((response) => {
      dispatch(setFormsData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setSingleFormDetailes({}));
  }
};

export const deleteFormsAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.formBuilderSlice?.paginationForms;

  try {
    dispatch(loadingFlag(true));
    await axios.post(`forms/delete`, { formIds: id }).then((response) => {
      dispatch(
        getFormsApiCall({
          page: data?.page,
          limit: data?.limit,
          sortBy: `${data?.sortBy}:${data?.orderBy}`,
        })
      );
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editFormAPI = (data, navigate, id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.put(`forms/${id}`, data).then((response) => {
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );

      navigate(`${prefix}/form-builder`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const addFormsAPI = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));

    await axios.post("forms", data).then((response) => {
      const paginationPayload =
        getState()?.root?.formBuilderSlice?.paginationForms;

      dispatch(
        setPaginationForms({
          ...paginationPayload,
          sortBy: "createdAt",
          orderBy: "desc",
        })
      );
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
      navigate(`${prefix}/form-builder`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getFormDetailesAPI = (id, type) => async (dispatch) => {
  try {
    if (type !== "column") {
      dispatch(loadingFlag(true));
    }
    await axios.get(`forms/${id}`).then((response) => {
      dispatch(setSingleFormDetailes(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default formBuilderSlice.reducer;
