// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";

import toast from "react-hot-toast";
import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const faqManagement = createSlice({
  name: "faqManagement",
  initialState: {
    FaqsData: [],
    singleFaqDetailes: {},
    paginationFaq: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "desc",
    },
  },
  reducers: {
    setFaqData: (state, action) => {
      state.FaqsData = action.payload;
    },
    setSingleFaqDetailes: (state, action) => {
      state.singleFaqDetailes = action.payload;
    },
    setPaginationFaq: (state, action) => {
      state.paginationFaq = action.payload;
    },
  },
});

export const { setFaqData, setSingleFaqDetailes, setPaginationFaq } =
  faqManagement.actions;

export const getFaqApiCall = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("faq", { params: { ...data } }).then((response) => {
      dispatch(setFaqData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setSingleFaqDetailes({}));
  }
};

export const deleteFaqAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.faqManagementSlice?.paginationFaq;

  try {
    dispatch(loadingFlag(true));
    await axios.post(`faq/delete`, { faqIds: id }).then((response) => {
      dispatch(getFaqApiCall(data));
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editFaqAPI =
  (data, navigate, id) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.put(`faq/${id}`, data).then((response) => {
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );

        navigate(`${prefix}/faq-management`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const addFaqAPI = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));

    await axios.post("faq", data).then((response) => {
      const paginationPayload =
        getState()?.root?.faqManagementSlice?.paginationFaq;

      dispatch(
        setPaginationFaq({
          ...paginationPayload,
          sortBy: "createdAt",
          orderBy: "desc",
        })
      );
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
      navigate(`${prefix}/faq-management`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getFaqDetailesAPI = (id, type) => async (dispatch) => {
  try {
    if (type !== "column") {
      dispatch(loadingFlag(true));
    }
    await axios.get(`faq/${id}`).then((response) => {
      dispatch(setSingleFaqDetailes(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default faqManagement.reducer;
