// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";
import toast from "react-hot-toast";

export const CMSManagement = createSlice({
  name: "CMSManagement",
  initialState: {
    singleCMSPageWiseData: null,
  },
  reducers: {
    setCmsPageData: (state, action) => {
      state.singleCMSPageWiseData = action.payload;
    },
  },
});

export const { setCmsPageData } = CMSManagement.actions;

export const updateCMSDetails = (data, slug) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));

    await axios.post(`cms/${slug}`, data).then((response) => {
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getSingleCMSDetailesAPI = (slug) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`cms/${slug}`).then((response) => {
      dispatch(setCmsPageData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default CMSManagement.reducer;
