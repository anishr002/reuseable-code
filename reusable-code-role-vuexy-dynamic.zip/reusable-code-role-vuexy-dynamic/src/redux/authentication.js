// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import toast from "react-hot-toast";
import { axios } from "../@core/auth/jwt/jwtService";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { loadingFlag } from "./mailLoading";
import { getCountAndUnreadNotificationAPI } from "./profile";

export const AuthSlice = createSlice({
  name: "Authentication",
  initialState: {
    UserData: { token: localStorage.getItem("accessToken") },
    settingLoading: false,
    settingData: {},
  },
  reducers: {
    handleLogin: (state, action) => {
      state.UserData = { ...state.UserData, ...action.payload };
    },
    handleSetting: (state, action) => {
      state.settingData = { ...state.settingData, ...action.payload };
    },
    handleLoadingForSetting: (state, action) => {
      state.settingLoading = action.payload;
    },
  },
});

export const { handleLogin, handleSetting, handleLoadingForSetting } =
  AuthSlice.actions;

export const loginAPI = (data, navigate) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    return await axios.post("users/login", data).then((response) => {
      dispatch(loadingFlag(false));
      localStorage.setItem("accessToken", response?.data?.data?.auth_token);
      localStorage.setItem("userData", JSON.stringify(response?.data?.data));
      dispatch(handleLogin(response?.data?.data));

      dispatch(getCountAndUnreadNotificationAPI());

      const settingData = response?.data?.data?.settingData;
      const payload = {
        notification: settingData?.notification,
        colorName: settingData?.colorName,
        appearance: settingData?.appearance,
        direction: settingData?.direction,
        colors: settingData?.colors,
      };
      dispatch(handleSetting(payload));

      // dispatch(getSetting());

      toast(
        <CustomToast message={"Login Successfully!"} type={"success"} />,
        SuccessCss()
      );
      const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;
      navigate(prefix);
      return response;
    });
  } catch (error) {
    dispatch(loadingFlag(false));
    console.log("#########", error);
    toast(
      <CustomToast
        message={error?.response?.data.error || error?.response?.data.message}
        type={"error"}
      />,
      ErrorCss()
    );
    return error;
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const forgotPasswordApi =
  (data, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.post("users/forgot-password", data).then((response) => {
        toast(
          <CustomToast message={response?.data.message} type={"success"} />,
          SuccessCss()
        );
        dispatch(loadingFlag(false));
        navigate(`/login`);
      });
    } catch (error) {
      toast(
        <CustomToast
          message={error?.response?.data.message || error?.response?.data.error}
          type={"error"}
        />,
        ErrorCss()
      );

      console.log("###", error);
      dispatch(loadingFlag(false));
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const changePasswordApi =
  (data, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.post("users/reset-password", data).then((response) => {
        toast(
          <CustomToast message={response?.data.message} type={"success"} />,
          SuccessCss()
        );
        localStorage.clear();
        dispatch({ type: "RESET" });
        dispatch(handleLogin({ token: null }));
        dispatch(loadingFlag(false));
        navigate(`/login`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
      dispatch(loadingFlag(false));
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const checkTokenExpiryApi =
  (token, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.get(`verifyTokenExpiration/${token}`).then((response) => {});

      return { status: true };
    } catch (error) {
      navigate(`/link-expired`);

      console.log("###", error);
      dispatch(loadingFlag(false));
      return { status: false };
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const getSetting = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("setting").then((response) => {
      dispatch(handleSetting(response?.data?.data));
    });
  } catch (error) {
    console.log("#########", error);
    toast(
      <CustomToast
        message={error?.response?.data.error || error?.response?.data.message}
        type={"error"}
      />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const updateSetting = (data) => async (dispatch) => {
  try {
    dispatch(handleLoadingForSetting(true));
    await axios.put("setting", data).then((response) => {
      dispatch(handleSetting(data));

      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    console.log("#########", error);
    toast(
      <CustomToast
        message={error?.response?.data.error || error?.response?.data.message}
        type={"error"}
      />,
      ErrorCss()
    );
  } finally {
    dispatch(handleLoadingForSetting(false));
  }
};

export default AuthSlice.reducer;
