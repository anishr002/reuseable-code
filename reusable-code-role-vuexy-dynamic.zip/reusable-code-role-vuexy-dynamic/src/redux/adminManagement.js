// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import toast from "react-hot-toast";
import { axios } from "../@core/auth/jwt/jwtService";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { loadingFlag } from "./mailLoading";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const adminManagement = createSlice({
  name: "adminManagement",
  initialState: {
    AdminUserList: [],
    singleAdminUserDetailes: {},
    roleDropdownData: [],
    paginationAdminUser: {
      page: 1,
      limit: 10,
      orderBy: "desc",
      sortBy: "createdAt",
    },
  },
  reducers: {
    setAdminUserData: (state, action) => {
      state.AdminUserList = action.payload;
    },
    setSingleAdminUserDetailes: (state, action) => {
      state.singleAdminUserDetailes = action.payload;
    },
    setRoleDropdownData: (state, action) => {
      state.roleDropdownData = action.payload;
    },
    setPaginationAdmin: (state, action) => {
      state.paginationAdminUser = action.payload;
    },
  },
});

export const {
  setModuleList,
  setAdminUserData,
  setSingleAdminUserDetailes,
  setPaginationAdmin,
  setRoleDropdownData,
} = adminManagement.actions;

export const getAdminUsersAPI = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("/admin", { params: { ...data } }).then((response) => {
      dispatch(setAdminUserData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const deleteAdminUserAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.RoleManagement?.paginationAdminUser;

  try {
    dispatch(loadingFlag(true));
    await axios.post(`admin/delete`, { adminIds: id }).then((response) => {
      dispatch(getAdminUsersAPI(data));
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editAdminUserAPI =
  (data, id, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.put(`admin/${id}`, data).then((response) => {
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );
        navigate(`${prefix}/staff-management`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const addAdminUserApi = (data, navigate) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));

    await axios.post("admin", data).then((response) => {
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
      navigate(`${prefix}/staff-management`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getAdminUserDetailestAPI =
  (id, type) => async (dispatch, getState) => {
    try {
      if (type !== "column") {
        dispatch(loadingFlag(true));
      }
      await axios.get(`admin/${id}`).then((response) => {
        dispatch(setSingleAdminUserDetailes(response?.data?.data));
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const getRoleDropdownDataAPI = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("/role/lists/get").then((response) => {
      dispatch(setRoleDropdownData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default adminManagement.reducer;
