import { combineReducers } from "@reduxjs/toolkit";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
// ** Reducers Imports
import AdminManagmentSlice from "./adminManagement";
import authentication from "./authentication";
import blogManagementSlice from "./blogManagement";
import CategorySlice from "./categoryManagement";
import CMSManagementSlice from "./cmsManagement";
import ContactUsSlice from "./ContactUsEnquiry";
import faqManagementSlice from "./faqManagement";
import layout from "./layout";
import appLoading from "./mailLoading";
import navbar from "./navbar";
import ProfileSlice from "./profile";
import RoleManagement from "./roleManagement";
import TestimonialManagementSlice from "./testimonialManagement";
import formBuilderSlice from "./FormBuilder";

const persistConfig = {
  key: "root",
  storage,
};

const AutomationReducer = {
  navbar,
  layout,
  authentication,
  RoleManagement,
  AdminManagmentSlice,
  appLoading,
  ProfileSlice,
  faqManagementSlice,
  CategorySlice,
  blogManagementSlice,
  CMSManagementSlice,
  ContactUsSlice,
  TestimonialManagementSlice,
  formBuilderSlice,
};

const rootReducer = combineReducers(AutomationReducer);

const appReducer = (state, action) => {
  if (action.type === "RESET") {
    localStorage.clear();
    return rootReducer(undefined, action);
  }

  return rootReducer(state, action);
};

export const persistedReducer = persistReducer(persistConfig, appReducer);

export default rootReducer;
