// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";
import toast from "react-hot-toast";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const testimonialManagement = createSlice({
  name: "testimonialManagement",
  initialState: {
    TestimonialData: [],
    singleTestimonialDetailes: {},
    paginationTestimonial: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "desc",
    },
  },
  reducers: {
    setTestimonialData: (state, action) => {
      state.TestimonialData = action.payload;
    },
    setSingleTestimonialDetailes: (state, action) => {
      state.singleTestimonialDetailes = action.payload;
    },
    setPaginationTestimonial: (state, action) => {
      state.paginationTestimonial = action.payload;
    },
  },
});

export const {
  setTestimonialData,
  setSingleTestimonialDetailes,
  setPaginationTestimonial,
} = testimonialManagement.actions;

export const getTestimonialApiCall = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("testimonial", { params: { ...data } }).then((response) => {
      dispatch(setTestimonialData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setSingleTestimonialDetailes({}));
  }
};

export const deleteTestimonialAPI = (id) => async (dispatch, getState) => {
  const data =
    getState()?.root?.TestimonialManagementSlice?.paginationTestimonial;

  try {
    dispatch(loadingFlag(true));
    await axios
      .post(`testimonial/delete`, { testimonialIds: id })
      .then((response) => {
        dispatch(getTestimonialApiCall(data));
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );
      });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editTestimonialAPI =
  (data, navigate, id) => async (dispatch, getState) => {
    const formData = new FormData();

    for (const [key, value] of Object.entries(data)) {
      // If the value is an array, iterate over it and append each value
      if (Array.isArray(value)) {
        value.forEach((item, index) => {
          formData.append(`${key}[${index}]`, item);
        });
      } else {
        // If the value is not an array, append it directly
        formData.append(key, value);
      }
    }
    try {
      dispatch(loadingFlag(true));
      await axios
        .put(`testimonial/${id}`, formData, {
          contentType: "multipart/form-data",
        })
        .then((response) => {
          toast(
            <CustomToast message={response?.data?.message} type={"success"} />,
            SuccessCss()
          );

          const paginationPayload =
            getState()?.root?.TestimonialManagementSlice?.paginationTestimonial;

          dispatch(
            setPaginationTestimonial({
              ...paginationPayload,
              sortBy: "createdAt",
              orderBy: "desc",
            })
          );

          navigate(`${prefix}/testimonial-management`);
        });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const addTestimonialAPI =
  (data, navigate) => async (dispatch, getState) => {
    const formData = new FormData();

    for (const [key, value] of Object.entries(data)) {
      // If the value is an array, iterate over it and append each value
      if (Array.isArray(value)) {
        value.forEach((item, index) => {
          formData.append(`${key}[${index}]`, item);
        });
      } else {
        // If the value is not an array, append it directly
        formData.append(key, value);
      }
    }
    try {
      dispatch(loadingFlag(true));

      await axios
        .post("testimonial", formData, {
          contentType: "multipart/form-data",
        })
        .then((response) => {
          const paginationPayload =
            getState()?.root?.TestimonialManagementSlice?.paginationTestimonial;

          dispatch(
            setPaginationTestimonial({
              ...paginationPayload,
              sortBy: "createdAt",
              orderBy: "desc",
            })
          );
          toast(
            <CustomToast message={response?.data?.message} type={"success"} />,
            SuccessCss()
          );
          navigate(`${prefix}/testimonial-management`);
        });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const getTestimonialDetailesAPI = (id, type) => async (dispatch) => {
  try {
    if (type !== "column") {
      dispatch(loadingFlag(true));
    }
    await axios.get(`testimonial/${id}`).then((response) => {
      dispatch(setSingleTestimonialDetailes(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default testimonialManagement.reducer;
