// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import toast from "react-hot-toast";
import { axios } from "../@core/auth/jwt/jwtService";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { loadingFlag } from "./mailLoading";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const blogManagement = createSlice({
  name: "blogManagement",
  initialState: {
    blogsData: [],
    singleBlogDetailes: {},
    paginationBlog: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "desc",
    },
    CategoryDropdown: [],
  },
  reducers: {
    setBlogsData: (state, action) => {
      state.blogsData = action.payload;
    },
    setSingleBlogDetailes: (state, action) => {
      state.singleBlogDetailes = action.payload;
    },
    setPaginationBlogs: (state, action) => {
      state.paginationBlog = action.payload;
    },
    setCategoryDropDownData: (state, action) => {
      state.CategoryDropdown = action.payload;
    },
  },
});

export const {
  setBlogsData,
  setSingleBlogDetailes,
  setPaginationBlogs,
  setCategoryDropDownData,
} = blogManagement.actions;

export const getBlogsApiCall = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("blog", { params: { ...data } }).then((response) => {
      dispatch(setBlogsData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setSingleBlogDetailes({}));
  }
};

export const deleteBlogAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.blogManagementSlice?.paginationBlog;

  try {
    dispatch(loadingFlag(true));
    await axios.post(`blog/delete`, { blogIds: id }).then((response) => {
      dispatch(getBlogsApiCall(data));
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editBlogAPI =
  (data, navigate, id) => async (dispatch, getState) => {
    const formData = new FormData();

    for (const [key, value] of Object.entries(data)) {
      // If the value is an array, iterate over it and append each value
      if (Array.isArray(value)) {
        value.forEach((item, index) => {
          formData.append(`${key}[${index}]`, item);
        });
      } else {
        // If the value is not an array, append it directly
        formData.append(key, value);
      }
    }
    try {
      dispatch(loadingFlag(true));
      await axios
        .put(`blog/${id}`, formData, {
          contentType: "multipart/form-data",
        })
        .then((response) => {
          toast(
            <CustomToast message={response?.data?.message} type={"success"} />,
            SuccessCss()
          );

          navigate(`${prefix}/blog-management`);
        });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const addBlogAPI = (data, navigate) => async (dispatch, getState) => {
  const formData = new FormData();

  for (const [key, value] of Object.entries(data)) {
    // If the value is an array, iterate over it and append each value
    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        formData.append(`${key}[${index}]`, item);
      });
    } else {
      // If the value is not an array, append it directly
      formData.append(key, value);
    }
  }
  try {
    dispatch(loadingFlag(true));

    await axios
      .post("blog", formData, { contentType: "multipart/form-data" })
      .then((response) => {
        const paginationPayload =
          getState()?.root?.blogManagementSlice?.paginationBlog;

        dispatch(
          setPaginationBlogs({
            ...paginationPayload,
            sortBy: "createdAt",
            orderBy: "desc",
          })
        );
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );
        navigate(`${prefix}/blog-management`);
      });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getBlogDetailesAPI = (id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`blog/${id}`).then((response) => {
      dispatch(setSingleBlogDetailes(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};
export const getCategoryDropDownAPI = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`category/get-category?isActive=true`).then((response) => {
      dispatch(setCategoryDropDownData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default blogManagement.reducer;
