// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import toast from "react-hot-toast";
import { axios } from "../@core/auth/jwt/jwtService";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { loadingFlag } from "./mailLoading";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const RoleManagement = createSlice({
  name: "RoleManagement",
  initialState: {
    RolesList: [],
    ModuleListing: [],
    singleRoleDetailes: {},
    paginationRole: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "asc",
    },
  },
  reducers: {
    setRolesData: (state, action) => {
      state.RolesList = action.payload;
    },
    setModuleList: (state, action) => {
      state.ModuleListing = action.payload;
    },
    setSingleRoleDetailes: (state, action) => {
      state.singleRoleDetailes = action.payload;
    },
    setPaginationRole: (state, action) => {
      state.paginationRole = action.payload;
    },
  },
});

export const {
  setModuleList,
  setRolesData,
  setSingleRoleDetailes,
  setPaginationRole,
} = RoleManagement.actions;

export const getRolesAPI = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("role", { params: { ...data } }).then((response) => {
      dispatch(setRolesData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setSingleRoleDetailes({}));
  }
};

export const deleteRoleAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.RoleManagement?.paginationRole;

  try {
    dispatch(loadingFlag(true));
    await axios.delete(`role/${id}`).then((response) => {
      dispatch(getRolesAPI(data));
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editRoleAPI =
  (data, navigate, id) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.put(`role/${id}`, data).then((response) => {
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );

        navigate(`${prefix}/role-management`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const addRoleAPI = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));

    await axios.post("role", data).then((response) => {
      const paginationPayload =
        getState()?.root?.RoleManagement?.paginationRole;

      dispatch(
        setPaginationRole({
          ...paginationPayload,
          sortBy: "createdAt",
          orderBy: "desc",
        })
      );
      toast(
        <CustomToast message={response?.data?.message} type={"success"} />,
        SuccessCss()
      );
      navigate(`${prefix}/role-management`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getModuleListAPI = () => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post("role/module/list", { role_id: "" }).then((response) => {
      dispatch(setModuleList(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getRoleDetailestAPI = (id) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`role/${id}`).then((response) => {
      dispatch(setSingleRoleDetailes(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default RoleManagement.reducer;
