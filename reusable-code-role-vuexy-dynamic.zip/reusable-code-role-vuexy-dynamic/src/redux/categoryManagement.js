// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";
import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";
import toast from "react-hot-toast";

const prefix = `${import.meta.env.VITE_APP_PREFIX || ""}`;

export const CategoryManagement = createSlice({
  name: "CategoryManagement",
  initialState: {
    CategoryData: [],
    singleCategoryDetailes: {},
    paginationCategory: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "desc",
    },
  },
  reducers: {
    setCategoryData: (state, action) => {
      state.CategoryData = action.payload;
    },
    setSingleCategoryDetailes: (state, action) => {
      state.singleCategoryDetailes = action.payload;
    },
    setPaginationCategory: (state, action) => {
      state.paginationCategory = action.payload;
    },
  },
});

export const {
  setCategoryData,
  setSingleCategoryDetailes,
  setPaginationCategory,
} = CategoryManagement.actions;

export const getCategoryApiCall = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("category", { params: data }).then((response) => {
      dispatch(setCategoryData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setSingleCategoryDetailes({}));
  }
};

export const deleteCategoryAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.CategorySlice?.paginationCategory;

  try {
    dispatch(loadingFlag(true));
    await axios
      .post(`category/delete`, { categoryIds: id })
      .then((response) => {
        dispatch(getCategoryApiCall(data));
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );
      });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editCategoryAPI =
  (data, navigate, id) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));
      await axios.put(`category/${id}`, data).then((response) => {
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );

        navigate(`${prefix}/category-management`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const addCategoryAPI =
  (data, navigate) => async (dispatch, getState) => {
    try {
      dispatch(loadingFlag(true));

      await axios.post("category", data).then((response) => {
        const paginationPayload =
          getState()?.root?.CategorySlice?.paginationCategory;

        dispatch(
          setPaginationCategory({
            ...paginationPayload,
            sortBy: "createdAt",
            orderBy: "desc",
          })
        );
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );
        navigate(`${prefix}/category-management`);
      });
    } catch (error) {
      toast(
        <CustomToast message={error?.response?.data?.message} type={"error"} />,
        ErrorCss()
      );
      console.log("###", error);
    } finally {
      dispatch(loadingFlag(false));
    }
  };

export const getCategoryDetailesAPI = (id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`category/${id}`).then((response) => {
      dispatch(setSingleCategoryDetailes(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default CategoryManagement.reducer;
