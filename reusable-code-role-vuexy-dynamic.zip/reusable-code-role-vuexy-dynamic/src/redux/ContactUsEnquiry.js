// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, { ErrorCss } from "../utility/toast/CustomeToast";

import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";
import toast from "react-hot-toast";

export const ContactUsSlice = createSlice({
  name: "ContactUsSlice",
  initialState: {
    contactUsEnquiryData: [],
    singleEnquriyDetails: null,
    paginationContactUs: {
      page: 1,
      limit: 10,
      sortBy: "createdAt",
      orderBy: "desc",
    },
  },
  reducers: {
    setContactUSEnquiryData: (state, action) => {
      state.contactUsEnquiryData = action.payload;
    },
    setSingleEnquiryData: (state, action) => {
      state.singleEnquriyDetails = action.payload;
    },
    setPaginationContactUs: (state, action) => {
      state.paginationContactUs = action.payload;
    },
  },
});

export const {
  setContactUSEnquiryData,
  setSingleEnquiryData,
  setPaginationContactUs,
} = ContactUsSlice.actions;

export const getContactUsListingAPI = (parmasData) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`contact-us`, { params: parmasData }).then((response) => {
      dispatch(setContactUSEnquiryData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getSingleEnquiryDetailesAPI = (id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`contact-us/${id}`).then((response) => {
      dispatch(setSingleEnquiryData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default ContactUsSlice.reducer;
