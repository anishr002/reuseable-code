// ** Redux Imports
import { createSlice } from "@reduxjs/toolkit";
import CustomToast, {
  ErrorCss,
  SuccessCss,
} from "../utility/toast/CustomeToast";

import { axios } from "../@core/auth/jwt/jwtService";
import { loadingFlag } from "./mailLoading";
import toast from "react-hot-toast";

export const ProfileSlice = createSlice({
  name: "Profile",
  initialState: {
    soket: {},
    profileData: {},
    NotificationData: {},
    paginationNotification: {
      page: 1,
      limit: 10,
      // sortBy: "createdAt",
      // orderBy: "desc",
    },
  },
  reducers: {
    handleGetProfile: (state, action) => {
      state.profileData = action.payload;
    },
    handleEditProfile: (state, action) => {
      state.profileData = action.payload;
    },
    handleGetNotification: (state, action) => {
      state.NotificationData = { ...action.payload };
    },
    setSokectData: (state, action) => {
      state.soket = action.payload;
    },
    setPaginationNotification: (state, action) => {
      state.paginationNotification = action.payload;
    },
  },
});

export const {
  handleGetProfile,
  handleEditProfile,
  handleGetNotification,
  setSokectData,
  setPaginationNotification,
} = ProfileSlice.actions;

export const getProfileAPI = () => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("users/profile").then((response) => {
      dispatch(handleGetProfile(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editProfileAPI = (data) => async (dispatch, getState) => {
  const formData = new FormData();

  for (const [key, value] of Object.entries(data)) {
    // If the value is an array, iterate over it and append each value
    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        formData.append(`${key}[${index}]`, item);
      });
    } else {
      // If the value is not an array, append it directly
      formData.append(key, value);
    }
  }

  try {
    dispatch(loadingFlag(true));

    await axios
      .put("users/edit-profile", formData, {
        contentType: "multipart/form-data",
      })
      .then((response) => {
        dispatch(getProfileAPI());
        toast(
          <CustomToast message={response?.data?.message} type={"success"} />,
          SuccessCss()
        );
      });
  } catch (error) {
    const resultData = error?.response?.data;
    if (resultData?.message) {
      toast(
        <CustomToast message={resultData?.message} type={"error"} />,
        ErrorCss()
      );
    }

    console.log("###", error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getNotificationAPI = (data) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("notification", { params: data }).then((response) => {
      dispatch(handleGetNotification(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const readNotificationAPI = (data) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.patch("notification/read", data).then((response) => {
      dispatch(getCountAndUnreadNotificationAPI());
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const readAllNotificationAPI = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.patch("notification/read-all").then(() => {
      dispatch(getCountAndUnreadNotificationAPI());
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getCountAndUnreadNotificationAPI = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get("notification/unread-list").then((response) => {
      dispatch(setSokectData(response?.data?.data));
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data?.message} type={"error"} />,
      ErrorCss()
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default ProfileSlice.reducer;
