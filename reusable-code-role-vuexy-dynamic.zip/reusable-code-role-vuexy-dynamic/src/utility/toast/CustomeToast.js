import { X } from "react-feather";
import toast from "react-hot-toast";
import PropTypes from "prop-types";

const CustomToast = ({ message }) => {
  return (
    <div className="d-flex justify-content-center align-items-center">
      <div className="me-2">{message}</div>
      <X className="cursor-pointer" onClick={() => toast?.dismiss()} />
    </div>
  );
};

CustomToast.propTypes = {
  message: PropTypes.string,
};

const successCss = () => {
  return {
    duration: 10000, // 5 minutes in milliseconds
    position: "top-right",
    className: "text-success",
    style: {
      minWidth: "fit-content",
      background: "#e5f8ed",
      fontColor: "green",
    },
  };
};
const errorCss = () => {
  return {
    duration: 10000, // 5 minutes in milliseconds
    position: "top-right",
    className: "text-danger",
    style: {
      minWidth: "fit-content",
      background: "#fceaea",
      fontColor: "red",
    },
  };
};
export { successCss as SuccessCss, errorCss as ErrorCss };
export default CustomToast;
