import { exec } from "child_process"; // Ensure exec is imported
import fs from "fs";
import inquirer from "inquirer";
import keySender from "node-key-sender";
import path from "path";
import { fileURLToPath } from "url";
import archiver from "archiver"; // Default import from CommonJS module
import os from "os";

// Construct __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// File path for the navigation file
const navPath = path.join(__dirname, "src/navigation/vertical/index.js");

// Paths for each module to be removed
const modulePaths = {
  cms: "./src/views/cms-management",
  roles: "./src/views/role-management",
  staffs: "./src/views/admin-management",
  bloglist: "./src/views/blog-management",
  blogcategory: "./src/views/category-management",
  faqs: "./src/views/faq-management",
  testimonial: "./src/views/testimonial-management",
  contactus: "./src/views/contact-us",
};

// Redux files for each module
const reduxPaths = {
  faqs: "./src/redux/faqManagement.js",
  cms: "./src/redux/cmsManagement.js",
  roles: "./src/redux/roleManagement.js",
  staffs: "./src/redux/adminManagement.js",
  bloglist: "./src/redux/blogManagement.js",
  blogcategory: "./src/redux/categoryManagement.js",
  testimonial: "./src/redux/testimonialManagement.js",
  contactus: "./src/redux/ContactUsEnquiry.js",
};

const reduxSliceName = {
  faqs: "faqManagementSlice",
  cms: "CMSManagementSlice",
  roles: "RoleManagement",
  staffs: "AdminManagmentSlice",
  bloglist: "blogManagementSlice",
  blogcategory: "CategorySlice",
  testimonial: "TestimonialManagementSlice",
  contactus: "ContactUsSlice",
};

const routesName = {
  faqs: "FaqRoutes",
  cms: "CmsRoutes",
  roles: "RolesRoutes",
  staffs: "AdminStaffRoute",
  bloglist: "BlogRoutes",
  blogcategory: "CategoryRoutes",
  testimonial: "TestimonialRoutes",
  contactus: "ContactUsRoutes",
};

// Route files for each module
const routePaths = {
  faqs: "./src/router/routes/FaqRoutes.js",
  cms: "./src/router/routes/CmsRoutes.js",
  roles: "./src/router/routes/RolesRoutes.js",
  staffs: "./src/router/routes/AdminUserRoutes.js",
  bloglist: "./src/router/routes/BlogRoutes.js",
  blogcategory: "./src/router/routes/CategoryRoutes.js",
  testimonial: "./src/router/routes/TestimonialRoutes.js",
  contactus: "./src/router/routes/ContactUsRoutes.js",
};

const removeIdsForNavigation = {
  faqs: { name: "faqs", parent: false },
  cms: { name: "cms", parent: false },
  roles: { name: "roles", parent: true },
  staffs: { name: "staffs", parent: true },
  bloglist: { name: "blog-list", parent: true },
  blogcategory: { name: "blog-category", parent: true },
  testimonial: { name: "testimonial", parent: false },
  contactus: { name: "contact-us", parent: false },
};

// Function to remove folders and files
function removeModule(moduleName) {
  // Remove the module folder
  const modulePath = modulePaths[moduleName];
  if (modulePath && fs.existsSync(modulePath)) {
    fs.rmSync(modulePath, { recursive: true, force: true });
    console.log(`Removed: ${modulePath}`);
  }

  // Remove the Redux file
  const reduxFilePath = reduxPaths[moduleName];
  if (reduxFilePath && fs.existsSync(reduxFilePath)) {
    fs.unlinkSync(reduxFilePath);
    console.log(`Removed Redux file: ${reduxFilePath}`);
  }

  // Remove the route file
  const routeFilePath = routePaths[moduleName];
  if (routeFilePath && fs.existsSync(routeFilePath)) {
    fs.unlinkSync(routeFilePath);
    console.log(`Removed route file: ${routeFilePath}`);
  }
}

function sendKeyCombination() {
  console.log("Focusing on the editor and sending Alt + Shift + O...");

  // Step 1: Send Alt + Shift + O first
  keySender.sendCombination(["alt", "shift", "o"], (error) => {
    if (error) {
      console.error(
        `Error sending key combination Alt + Shift + O: ${error.message}`
      );
    } else {
      console.log("Alt + Shift + O sent successfully!");
    }
  });

  setTimeout(() => {
    keySender.sendCombination(["control", "s"], (error) => {
      if (error) {
        console.error(`Error sending Ctrl + S: ${error.message}`);
      } else {
        console.log("Ctrl + S sent successfully to save the file!");
      }
    });
  }, 1000);
}

// Update navigation configuration in `src/navigation/vertical/index.js`
function updateNavigation(selectedModules) {
  return new Promise((resolve) => {
    // Read the file content
    let fileContent = fs.readFileSync(navPath, "utf8");

    // Use a regular expression to find the Automation array
    const automationArrayRegex = /const Automation = \[(.*?)\];/s;
    const match = fileContent.match(automationArrayRegex);

    if (!match) {
      console.error("Automation array not found in the file.");
      return;
    }

    // Extract the existing array content
    let automationArrayContent = match[1];

    // Split the array content into lines for processing
    const automationArrayLines = automationArrayContent.split(/\n(?=\s*{)/);

    // Filter out the object with the matching ID
    const updatedArrayLines = automationArrayLines.filter((line) => {
      return !selectedModules.some((module) =>
        line.includes(`id: "${removeIdsForNavigation[`${module}`].name}"`)
      );
    });

    // Join the updated array lines back into a string, including commas between items
    const updatedArrayContent = updatedArrayLines.join("\n");

    // Construct the updated file content
    const updatedContent = fileContent.replace(
      automationArrayRegex,
      `const Automation = [\n${updatedArrayContent}\n];`
    );

    fs.writeFileSync(navPath, updatedContent, "utf8");

    // Open the file in the code editor after modifications
    exec(`code "${navPath}"`, (error) => {
      if (error) {
        console.error(`Error opening file: ${error.message}`);
      } else {
        // Focus on the editor after opening the file
        setTimeout(() => {
          sendKeyCombination(); // Simulate key combination if needed
        }, 1000); // Delay to allow the editor to open
      }
    });
    // Save the updated content back to the file
    fs.writeFileSync(navPath, updatedContent, "utf8");

    console.log("Updated navigation configuration");
    // Your logic for updating navigation
    // Simulate async operation with a timeout
    setTimeout(() => {
      console.log("Navigation updated");
      resolve(); // Resolve when done
    }, 5000); // Example delay
  });
}

// Function to update Redux root reducer
function updateRedux(selectedModules) {
  return new Promise((resolve) => {
    // Path to your rootReducer.js file
    const rootReducerPath = path.join(__dirname, "src/redux/rootReducer.js");

    // Read the current content of the rootReducer.js file
    let reducerContent = fs.readFileSync(rootReducerPath, "utf8");

    // Regular expression to find the AutomationReducer object
    const automationReducerRegex = /const AutomationReducer = \{([\s\S]*?)\};/;

    // Find the AutomationReducer object in the content
    const match = reducerContent.match(automationReducerRegex);
    if (!match) {
      console.error("AutomationReducer object not found in the file.");
      return;
    }

    // Extract the content of AutomationReducer (between { and })
    let automationReducerContent = match[1];

    // Split the content into lines for easier processing
    const automationReducerLines = automationReducerContent.split(/\n/);

    // Filter out the lines that include the reducers we want to remove
    const updatedReducerLines = automationReducerLines.filter((line) => {
      return !selectedModules.some((module) =>
        line.includes(reduxSliceName[module])
      );
    });

    // Join the updated lines back into a string
    const updatedReducerContent = updatedReducerLines.join("\n");

    // Replace the old AutomationReducer content with the new one
    reducerContent = reducerContent.replace(
      automationReducerRegex,
      `const AutomationReducer = {\n${updatedReducerContent}\n};`
    );

    fs.writeFileSync(rootReducerPath, reducerContent, "utf8");

    // Open the file in the code editor after modifications
    exec(`code "${rootReducerPath}"`, (error) => {
      if (error) {
        console.error(`Error opening file: ${error.message}`);
      } else {
        // Focus on the editor after opening the file
        setTimeout(() => {
          sendKeyCombination(); // Simulate key combination if needed
        }, 1000); // Delay to allow the editor to open
      }
    });

    // Write the updated content back to the rootReducer.js file
    fs.writeFileSync(rootReducerPath, reducerContent, "utf8");

    console.log("Updated rootReducer by removing selected modules");

    // Your logic for updating Redux
    // Simulate async operation with a timeout
    setTimeout(() => {
      console.log("Redux updated");
      resolve(); // Resolve when done
    }, 5000); // Example delay
  });
}

// Update route imports in `src/router/routes/index.js`
function updateRoutes(selectedModules) {
  return new Promise((resolve) => {
    const routesPath = path.join(__dirname, "src/router/routes/index.js");
    let routesContent = fs.readFileSync(routesPath, "utf8");

    // Regular expression to find the AllRoutesAutomation array
    const automationRoutesRegex =
      /const AllRoutesAutomation\s*=\s*\[\s*([\s\S]*?)\s*\];/s;

    // Match the AllRoutesAutomation array content
    const match = routesContent.match(automationRoutesRegex);
    if (!match) {
      console.error("AllRoutesAutomation array not found in the file.");
      return;
    }

    // Extract the content of AllRoutesAutomation (the array inside the brackets)
    let automationRoutesContent = match[1];

    // Split the content into lines for easier processing
    const automationRoutesLines = automationRoutesContent.split(/\n/);

    // Filter out the lines that include the modules you want to remove
    const updatedRoutesLines = automationRoutesLines.filter((line) => {
      return !selectedModules.some((module) =>
        line.includes(routesName[module])
      );
    });

    // Join the updated lines back into a string
    const updatedRoutesContent = updatedRoutesLines.join("\n");

    // Replace the old AllRoutesAutomation content with the new one
    routesContent = routesContent.replace(
      automationRoutesRegex,
      `const AllRoutesAutomation = [\n${updatedRoutesContent}\n];`
    );
    fs.writeFileSync(routesPath, routesContent, "utf8");

    // Open the file in the code editor after modifications
    exec(`code "${routesPath}"`, (error) => {
      if (error) {
        console.error(`Error opening file: ${error.message}`);
      } else {
        // Focus on the editor after opening the file
        setTimeout(() => {
          sendKeyCombination(); // Simulate key combination if needed
        }, 1000); // Delay to allow the editor to open
      }
    });

    // Save the updated content back to the file
    fs.writeFileSync(routesPath, routesContent, "utf8");

    console.log("Updated routes by removing unselected modules");

    setTimeout(() => {
      console.log("Routes updated");
      resolve(); // Resolve when done
    }, 5000); // Example delay
  });
}

function updateEnv(envPrefix) {
  const envPath = path.join(__dirname, ".env");
  let envContent = fs.readFileSync(envPath, "utf8");

  // Update or add the VITE_APP_PREFIX line
  if (envContent.includes("VITE_APP_PREFIX")) {
    envContent = envContent.replace(
      /VITE_APP_PREFIX=['"]?.*['"]?/,
      `VITE_APP_PREFIX=${envPrefix}`
    );
  } else {
    envContent += `\nVITE_APP_PREFIX=${envPrefix}`;
  }

  fs.writeFileSync(envPath, envContent, "utf8");
  console.log(`Updated .env with prefix: ${envPrefix}`);
}

// Create the ZIP file
function createZip() {
  return new Promise((resolve, reject) => {
    const downloadsPath = path.join(
      os.homedir(),
      "Downloads",
      "reusable-selected-module.zip"
    );
    const output = fs.createWriteStream(downloadsPath);
    const archive = archiver("zip", { zlib: { level: 9 } });

    output.on("close", function () {
      console.log(`Backup ZIP created: ${archive.pointer()} total bytes.`);
      console.log(`ZIP file saved to: ${downloadsPath}`);
      resolve(); // Resolve after ZIP is completed
    });

    archive.on("error", function (err) {
      reject(err); // Reject if an error occurs
    });

    archive.pipe(output);

    // Append files from the current directory excluding `.git` and `node_modules`
    archive.glob("**/*", {
      ignore: ["node_modules/**", ".git/**"],
    });

    archive.finalize();
  });
}

// Function to discard changes
function discardChanges() {
  return new Promise((resolve, reject) => {
    exec("git restore .", (error, stdout, stderr) => {
      if (error) {
        console.error(`Error restoring files: ${stderr}`);
        reject(error);
      } else {
        console.log("Changes discarded successfully.");
        resolve();
      }
    });
  });
}

// Main function to handle ZIP creation and then discard changes
async function processRepo() {
  try {
    await createZip(); // Step 1: Create ZIP
    await discardChanges(); // Step 2: Discard changes after ZIP is done
    console.log("ZIP creation and discarding changes completed successfully.");
  } catch (error) {
    console.error(`Error occurred: ${error.message}`);
  }
}

// Main interactive script
inquirer
  .prompt([
    {
      type: "checkbox",
      name: "modules",
      message: "Which modules do you want to keep?",
      choices: [
        new inquirer.Separator("-------------"),
        { name: "Blog Management", value: ["blogcategory", "bloglist"] },
        new inquirer.Separator("-------------"),
        { name: "Admin Management", value: ["staffs", "roles"] },
        new inquirer.Separator("-------------"),
        { name: "Testimonials", value: "testimonial" },
        { name: "Contact Us", value: "contactus" },
        { name: "CMS", value: "cms" },
        { name: "FAQs", value: "faqs" },
      ],
    },
    {
      type: "confirm",
      name: "customRoute",
      message: "Do you want a custom route like '/admin/login'?",
      default: false,
    },
    {
      type: "input",
      name: "envPrefix",
      message:
        "Enter the route prefix (no spaces, numbers, max 15 characters):",
      when: (answers) => answers.customRoute === true, // Only ask this if custom route is selected
      validate: (input) => {
        // Ensure no spaces, numbers, and length <= 15
        if (!/^[a-zA-Z]+$/.test(input)) {
          return "Prefix can only contain letters (no spaces or numbers).";
        }
        if (input.length > 15) {
          return "Prefix must be 15 characters or less.";
        }
        return true;
      },
    },
  ])
  .then((answers) => {
    const { modules, envPrefix, customRoute } = answers;
    const finalEnvPrefix = customRoute ? `/${envPrefix}` : "";

    // Separate selected and unselected modules
    const selectedModules = modules.flat();
    const unselectedModules = Object.keys(modulePaths).filter(
      (module) => !selectedModules.includes(module)
    );

    console.log("Selected Modules:", selectedModules);
    console.log("Unselected Modules:", unselectedModules);

    // Remove unselected modules
    unselectedModules.forEach((module) => {
      removeModule(module);
    });

    updateNavigation(unselectedModules)
      .then(() => updateRedux(unselectedModules))
      .then(() => updateRoutes(unselectedModules))
      .then(() => {
        console.log("All updates completed successfully.");
      })
      .catch((error) => {
        console.error(`An error occurred: ${error.message}`);
      })
      .then(() => {
        processRepo();
      })
      .catch((error) => {
        console.error(`An error occurred: ${error.message}`);
      });

    // Update the .env file
    updateEnv(finalEnvPrefix);

    console.log("Module removal and updates complete!");
  });
