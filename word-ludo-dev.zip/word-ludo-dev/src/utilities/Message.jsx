import React from "react";

const Message = ({ message }) => {
  return (
    <>
      <p>{message}</p>
    </>
  );
};

export default Message;
