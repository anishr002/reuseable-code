import { NavLink, useNavigate } from "react-router-dom";
import React, { useEffect, useMemo, useState } from "react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import { useDispatch, useSelector } from "react-redux";
import {
  getSearchWordlist,
  getWord,
  resetData,
} from "../../redux/sllices/wordOfTheDaySlice";
import { useDebouncedValue } from "../../hooks/usedebounce";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import ClearIcon from "@mui/icons-material/Clear";
import Loader from "../../Layout/Loader";

const SearchWord = ({ setWords, Words }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { transcript, browserSupportsSpeechRecognition } =
    useSpeechRecognition();
  const [searchValue, setSearchValue] = useState("");
  const [responseflag, setResponseflag] = useState(false);
  const searchdebounce = useDebouncedValue(searchValue, 900);
  const loading = useSelector((state) => state?.root?.wordOfTheDay?.loading);
  const searchDataValue = useSelector(
    (state) => state?.root?.wordOfTheDay?.searchWorddata
  );
  // console.log(first)

  useEffect(() => {
    dispatch(resetData());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useMemo(() => {
    if (transcript?.length > 0) {
      setSearchValue(transcript);
      // SpeechRecognition.stopListening()
    }
  }, [transcript]);

  const startRecording = () => {
    if (!browserSupportsSpeechRecognition) {
      alert(`Browser doesn't support speech recognition.`);
    }
    SpeechRecognition.startListening();
  };

  useEffect(() => {
    const wordIdArray = Words?.map((item) => {
      return item?._id;
    });
    if (searchValue !== "") {
      dispatch(getSearchWordlist(wordIdArray, searchValue));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchdebounce]);

  const handleClearSearch = () => {
    setSearchValue("");
  };
  return (
    <>
      <div className="">
        {/* <NavLink to="/" className="back-btn-link">
          <svg
            width="48"
            height="48"
            viewBox="0 0 48 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect width="48" height="48" rx="24" fill="#00509D" />
            <path
              d="M31 24.0001H17M17 24.0001L24 31M17 24.0001L24 17"
              stroke="white"
              stroke-width="1.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </NavLink> */}

        <div className="searchbox">
          <input
            type="text"
            id="searchInput"
            className="shadow-none"
            onChange={(e) => {
              setResponseflag(false);
              setSearchValue(e.target.value);
            }}
            value={searchValue}
            onKeyDown={handleKeyDown}
            // autoFocus
            placeholder="Search Word"
          />
          <div className="record_icon">
            {searchValue && (
              <ClearIcon onClick={handleClearSearch} fontSize="small" />
            )}
          </div>

          {/* Mike recoding Option */}
          {/* <div className="record_icon" onClick={() => startRecording()}>
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12.6666 6.66663V7.99996C12.6666 9.23764 12.1749 10.4246 11.2998 11.2998C10.4246 12.175 9.2376 12.6666 7.99992 12.6666M7.99992 12.6666C6.76224 12.6666 5.57526 12.175 4.70009 11.2998C3.82492 10.4246 3.33325 9.23764 3.33325 7.99996V6.66663M7.99992 12.6666V15.3333M5.33325 15.3333H10.6666M7.99992 0.666626C7.46949 0.666626 6.96078 0.87734 6.5857 1.25241C6.21063 1.62749 5.99992 2.13619 5.99992 2.66663V7.99996C5.99992 8.53039 6.21063 9.0391 6.5857 9.41417C6.96078 9.78924 7.46949 9.99996 7.99992 9.99996C8.53035 9.99996 9.03906 9.78924 9.41413 9.41417C9.78921 9.0391 9.99992 8.53039 9.99992 7.99996V2.66663C9.99992 2.13619 9.78921 1.62749 9.41413 1.25241C9.03906 0.87734 8.53035 0.666626 7.99992 0.666626Z"
                stroke="#090A0A"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div> */}
        </div>

        {searchValue && searchDataValue?.length > 0 ? (
          <div className="custom-multi-search-inner src_word_list">
            {searchDataValue.map((data) => {
              return (
                <div className="liating">
                  <button
                    // to={`/word-details/${data?._id}`}
                    disabled={Words.some((item) => item._id === data?._id)}
                    onClick={() => {
                      setWords((prevWords) => [...prevWords, data]);
                    }}
                  >
                    <span>{data?.word}</span>
                    <svg
                      width="24px"
                      height="24px"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                    >
                      <g id="SVGRepo_bgCarrier" stroke-width="0" />

                      <g
                        id="SVGRepo_tracerCarrier"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />

                      <g id="SVGRepo_iconCarrier">
                        {" "}
                        <path
                          fill="#000000"
                          fill-rule="evenodd"
                          d="M9 17a1 1 0 102 0v-6h6a1 1 0 100-2h-6V3a1 1 0 10-2 0v6H3a1 1 0 000 2h6v6z"
                        />{" "}
                      </g>
                    </svg>
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          searchValue &&
          !loading && <p className="text-center m-0">No Word Found</p>
        )}
        <div className="clearfix"></div>
      </div>
    </>
  );
};

export default SearchWord;
