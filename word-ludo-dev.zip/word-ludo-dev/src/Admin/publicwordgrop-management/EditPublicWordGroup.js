import React, { useEffect, useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import TextError from "../../utilities/TextError";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import Loader from "../../Layout/Loader";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import SearchWord from "./SearchWord";
import {
  addAdminPublicWordgroup,
  editPublicWordgroup,
  getSinglePublicWordGroup,
} from "../../redux/sllices/adminPublicWordgroupSlice";

const EditPublicWordGroup = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector(
    (state) => state?.root?.adminpublicwordgroup?.loading
  );
  const EditPublicWorgroupdata = useSelector(
    (state) => state?.root?.adminpublicwordgroup?.singlePublicWorgroupdata
  );
  console.log(EditPublicWorgroupdata, "EditPublicWorgroupdata");
  const [Words, setWords] = useState([]);
  const [error, seterror] = useState(false);
  // console.log(Words, "words");
  useEffect(() => {
    dispatch(getSinglePublicWordGroup(id, navigate));
  }, [id]);
  useEffect(() => {
    setWords(EditPublicWorgroupdata?.wordData);
  }, [EditPublicWorgroupdata]);

  const initialValueSchema = {
    groupName: EditPublicWorgroupdata?.publicWordGroupData?.groupName,
  };
  const validationSchema = Yup.object().shape({
    groupName: Yup.string()
      .required("Group Name is required")
      .trim("space can not be allowed")
      .min(3, "Group Name must be at least 3 characters")
      .max(50, "Group Name can be maximum 50 characters"),
  });

  const handleClick = () => {
    // console.info("You clicked the Chip.");
  };

  //Delete Chips
  const handleDelete = (_id) => {
    const filterchipsArray = Words?.filter((chipsId, index) => {
      return chipsId?._id !== _id;
    });

    setWords(filterchipsArray);
  };

  // formik submit Handler
  const onSubmit = (values, onSubmitProps) => {
    const wordgroupformdata = {
      groupName: values?.groupName,
      wordIdArray: Words?.map((wdata, index) => wdata?._id),
    };
    // console.log(wordgroupformdata);

    if (Words?.length > 0) {
      dispatch(editPublicWordgroup(id, wordgroupformdata, navigate));
      setWords([]);
      onSubmitProps.resetForm();
    }
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="quiz-form-details">
            <div className="container">
              <Formik
                initialValues={initialValueSchema}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {(formik) => {
                  const { values, setFieldValue, errors } = formik;
                  return (
                    <Form>
                      <h1 className="crt_quiz">Edit Public Word Group</h1>
                      <div className="form-field">
                        <label>
                          Public Word Group Name
                          <span>*</span>
                        </label>
                        <Field
                          name={`groupName`}
                          placeholder="Enter a Category "
                          onKeyDown={handleKeyDown}
                          type="text"
                        />
                        <ErrorMessage
                          name={`groupName`}
                          component={TextError}
                        />
                      </div>

                      <div className="form-field">
                        <label>
                          Public Word Group Words
                          <span>*</span>
                        </label>
                        <div className="custom-multi-search">
                          {Words?.map((chipsdata, index) => {
                            return (
                              <>
                                <Stack direction="row" spacing={1}>
                                  <Chip
                                    label={chipsdata?.word}
                                    variant="outlined"
                                    // onClick={handleClick}
                                    onDelete={() => {
                                      handleDelete(chipsdata?._id);
                                    }}
                                  />
                                </Stack>
                              </>
                            );
                          })}
                        </div>

                        <SearchWord setWords={setWords} Words={Words} />
                        {error && Words?.length <= 0 && (
                          <p className="error">Please enter words</p>
                        )}
                      </div>

                      <div className="d-flex">
                        <button
                          type="submit"
                          onClick={() => {
                            if (Words?.length <= 0) {
                              seterror(true);
                            }
                          }}
                          className={`primary-btn `}
                        >
                          Submit
                        </button>

                        <button
                          type="button"
                          className="primary-btn"
                          onClick={() =>
                            navigate("/admin/public-wordgroup-list")
                          }
                        >
                          Cancel
                        </button>
                      </div>
                    </Form>
                  );
                }}
              </Formik>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default EditPublicWordGroup;
