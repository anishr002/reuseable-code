import React from "react";

const Admindashboard = () => {
  return (
    <>
      <h1>Admindashboard</h1>
    </>
  );
};

export default Admindashboard;
