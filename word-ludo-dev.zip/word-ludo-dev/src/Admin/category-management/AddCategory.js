import React, { useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import TextError from "../../utilities/TextError";
import { useDispatch, useSelector } from "react-redux";
import {
  addAdminQuestion,
  editQuestion,
} from "../../redux/sllices/adminQuestionSlice";
import { useLocation, useNavigate, useNavigation } from "react-router-dom";
import Loader from "../../Layout/Loader";
import { logDOM } from "@testing-library/react";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import { addAdminCategory } from "../../redux/sllices/adminCategorySlice";

const AddCategory = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector((state) => state?.root?.adminCategory?.loading);

  const initialValueSchema = {
    name: "",
  };

  const validationSchema = Yup.object().shape({
    name: Yup.string()
      .required("Category Name is required")
      .trim("space can not be allowed")
      .min(3, "Category Name must be at least 3 characters")
      .max(50, "Category Name can be maximum 50 characters"),
  });

  const onSubmit = (values, onSubmitProps) => {
    // console.log(values);
    dispatch(addAdminCategory(values, navigate));

    onSubmitProps.resetForm();
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details">
          <div className="container">
            <Formik
              initialValues={initialValueSchema}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue, errors } = formik;
                return (
                  <Form>
                    <h1 className="crt_quiz">Create Category</h1>
                    <div className="form-field">
                      <label>
                        Category Name
                        <span>*</span>
                      </label>
                      <Field
                        name={`name`}
                        placeholder="Enter a Category "
                        onKeyDown={handleKeyDown}
                        type="text"
                      />
                      <ErrorMessage name={`name`} component={TextError} />
                    </div>

                    <div className="d-flex">
                      <button type="submit" className={`primary-btn `}>
                        Submit
                      </button>

                      <button
                        type="button"
                        className="primary-btn"
                        onClick={() => navigate("/admin/category-list")}
                      >
                        Cancel
                      </button>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </>
  );
};

export default AddCategory;
