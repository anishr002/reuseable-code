import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Pagination,
  Tooltip,
} from "@mui/material";
import {
  deleteQuiz,
  getAdminQuizlist,
} from "../../redux/sllices/adminQuizSlice";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { NavLink } from "react-router-dom";
import Message from "../../utilities/Message";
import { useDispatch, useSelector } from "react-redux";
import { useDebouncedValue } from "../../hooks/usedebounce";
import Loader from "../../Layout/Loader";
import Swal from "sweetalert2";
// import { capitalCase } from "change-case";
import moment from "moment";
import {
  deleteQuestion,
  getAdminQuestionlist,
} from "../../redux/sllices/adminQuestionSlice";
import { Box } from "@mui/system";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import ClearIcon from "@mui/icons-material/Clear";
import {
  deleteCategory,
  getAdminCategorylist,
} from "../../redux/sllices/adminCategorySlice";

export default function CategoryTable() {
  const [searchValue, setSearchValue] = useState("");
  const [pageNumber, setpageNumber] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  //store value Selection
  const loading = useSelector((state) => state?.root?.adminCategory?.loading);

  const Categorylist = useSelector(
    (state) => state?.root?.adminCategory?.adminCategorylistdata
  );
  // console.log(Categorylist?.categoryData, "Categorylist", Categorylist);

  const debouncedValue = useDebouncedValue(searchValue, 1000);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  //useEffect list API call
  useEffect(() => {
    const pages = searchValue !== "" ? 1 : pageNumber;
    dispatch(getAdminCategorylist(searchValue, pages, rowsPerPage));
  }, [debouncedValue, pageNumber, rowsPerPage]);

  // pagination page
  const handleChangePage = (event, page) => {
    setpageNumber(page);
  };

  //Quiz delete model,rowsPerPage
  const showAlert = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this Category",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      confirmButtonColor: "red",
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(
          deleteCategory(
            id,
            searchValue,
            pageNumber,
            rowsPerPage,
            Categorylist?.categoryData?.length == 1,
            setpageNumber
          )
        );
      }
    });
  };

  const StartIndex = (pageNumber - 1) * rowsPerPage + 1;

  const styles = {
    wordBreak: "break-word",
  };
  const handleClearSearch = () => {
    setSearchValue("");
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="container">
            <h1 id="heading">Manage Category</h1>
            <div className="top_bar">
              <div className="custom_search_block">
                <input
                  type="text"
                  id="searchInput"
                  placeholder="Search"
                  value={searchValue}
                  onKeyDown={handleKeyDown}
                  onChange={(e) => {
                    setSearchValue(e.target.value);
                    setTimeout(() => {
                      setpageNumber(1);
                    }, 980);
                    // setpageNumber(1);
                  }}
                />

                {searchValue && (
                  <ClearIcon onClick={handleClearSearch} fontSize="small" />
                )}
              </div>

              <NavLink
                to="/admin/add-category"
                className="primary-btn text-decoration-none"
              >
                Add Category
              </NavLink>
            </div>
          </div>
          {Categorylist?.categoryData?.length === 0 ? (
            <>
              <div className="container">
                <div className="tabel_box">
                  <p className="text-center">No Data Found</p>
                </div>
                <div className="clearfix"></div>
              </div>
            </>
          ) : (
            <>
              <div className="container">
                <div className="tabel_box manage_word3">
                  <TableContainer>
                    <Table>
                      <TableHead>
                        {" "}
                        <TableRow>
                          <TableCell>#</TableCell>
                          <TableCell>Category</TableCell>
                          <TableCell>Action</TableCell>{" "}
                        </TableRow>{" "}
                      </TableHead>

                      <TableBody>
                        {Categorylist?.categoryData?.map((row, index) => {
                          return (
                            <TableRow key={row?._id}>
                              <TableCell data-label="#">
                                {StartIndex + index}
                              </TableCell>
                              <TableCell data-label="Questions" style={styles}>
                                {row?.name}
                              </TableCell>

                              <TableCell data-label="Action">
                                <Box display="flex">
                                  <Tooltip title="Edit">
                                    <IconButton className="edit_btn">
                                      <EditIcon
                                        onClick={() => {
                                          navigate(
                                            `/admin/edit-category/${row?._id}`
                                          );
                                        }}
                                      />
                                    </IconButton>
                                  </Tooltip>
                                  <Tooltip title="Delete" data-label="Word">
                                    <IconButton className="dlt_btn">
                                      <DeleteIcon
                                        onClick={() => {
                                          showAlert(row?._id);
                                        }}
                                      />
                                    </IconButton>
                                  </Tooltip>
                                </Box>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </div>
                <div className="paginationbox pb-lg-5 pb-3">
                  <Pagination
                    count={Categorylist?.totalPages}
                    variant="outlined"
                    page={pageNumber}
                    color="primary"
                    onChange={handleChangePage}
                    style={{ display: "flex", justifyContent: "flex-end" }}
                  />
                  <div className="per_page">
                    <label for="rowperpage">Rows per page :</label>
                    <select
                      name="rowperpage"
                      value={rowsPerPage}
                      id="rowperpage"
                      onChange={(e) => {
                        setpageNumber(1);
                        setRowsPerPage(e.target.value);
                      }}
                    >
                      {/* <option value="5">5</option> */}
                      <option value="10">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                    </select>
                  </div>
                </div>
                <div className="clearfix"></div>
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
