import React, { useEffect, useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import TextError from "../../utilities/TextError";
import { useDispatch, useSelector } from "react-redux";
import {
  useLocation,
  useNavigate,
  useNavigation,
  useParams,
} from "react-router-dom";
import Loader from "../../Layout/Loader";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import {
  editCategory,
  getSingleCategoryDetail,
} from "../../redux/sllices/adminCategorySlice";

const EditCategory = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const loading = useSelector((state) => state?.root?.adminCategory?.loading);
  const Editcategorydata = useSelector(
    (state) => state?.root?.adminCategory?.singleCategorydata
  );

  const initialValueSchema = {
    name: Editcategorydata?.name,
  };

  const validationSchema = Yup.object().shape({
    name: Yup.string()
      .required("Category Name is required")
      .trim("space can not be allowed")
      .min(3, "Category Name must be at least 3 characters")
      .max(50, "Category Name can be maximum 50 characters"),
  });

  useEffect(() => {
    dispatch(getSingleCategoryDetail(id, navigate));
  }, [id]);

  const onSubmit = (values, onSubmitProps) => {
    // console.log(values);
    dispatch(editCategory(id, values, navigate));

    onSubmitProps.resetForm();
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details">
          <div className="container">
            <Formik
              initialValues={initialValueSchema}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue, errors } = formik;
                return (
                  <Form>
                    <h1 className="crt_quiz">Edit Category</h1>
                    <div className="form-field">
                      <label>
                        Category Name
                        <span>*</span>
                      </label>
                      <Field
                        name={`name`}
                        placeholder="Enter a Category "
                        onKeyDown={handleKeyDown}
                        type="text"
                      />
                      <ErrorMessage name={`name`} component={TextError} />
                    </div>

                    <div className="d-flex">
                      <button type="submit" className={`primary-btn `}>
                        Submit
                      </button>

                      <button
                        type="button"
                        className="primary-btn"
                        onClick={() => navigate("/admin/category-list")}
                      >
                        Cancel
                      </button>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </>
  );
};

export default EditCategory;
