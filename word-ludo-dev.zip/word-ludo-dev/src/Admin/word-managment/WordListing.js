import React from "react";

import WordTable from "./WordTable";

const WordListing = () => {
  return (
    <div className="container mb-4">
      {" "}
      <WordTable />
      <div className="clearfix"></div>
    </div>
  );
};

export default WordListing;
