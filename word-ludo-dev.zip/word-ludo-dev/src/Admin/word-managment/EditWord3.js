import { Formik, Form, Field, FieldArray, ErrorMessage } from "formik";
import * as Yup from "yup";
import useMulti from "../../hooks/useMulti";
import {
  addWordDetails,
  editwords,
  getEditwordDetails,
} from "../../redux/sllices/wordSlice";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Loader from "../../Layout/Loader";
import { List, AutoSizer } from "react-virtualized";

const validationSchema = Yup.object().shape({
  definition: Yup.array().of(
    Yup.object().shape({
      wordclass: Yup.string().required("Wordclass Field is required"),
      text: Yup.string().required("Text is required"),
      synonyms: Yup.array()
        .of(Yup.string().required("This field is required"))
        .required("This field is required"),
      antonyms: Yup.array()
        .of(Yup.string().required("This field is required"))
        .required("This field is required"),
      examples: Yup.array()
        .of(Yup.string().required("This field is required"))
        .required("This field is required"),
    })
  ),
  // synonyms: Yup.array()
  // .of(Yup.string().required('This field is required'))
  // .required('This field is required'),

  audioURL: Yup.string().required("audioURL is Required"),
  pronunciation: Yup.string().required("Pronunciation is Required"),
});

const EditWord = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const loading = useSelector((state) => state?.root?.words?.loading);

  useEffect(() => {
    !state?.curated && dispatch(getEditwordDetails(state?._id));
  }, []);

  const data = useSelector((state) => state?.root?.words?.editwordData);

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="container">
          <h1 id="heading">Edit Word</h1>
          <div className="admin_wordline">
            <label>Word</label>
            <input
              disabled={!!state}
              type="text"
              placeholder="Type your word"
              defaultValue={state?.curated ? state?.word?.word : data?.word}
            />

            <button disabled={!!state}>Add</button>
          </div>
          <Formik
            // initialValues={initialValues}
            validationSchema={validationSchema}
            initialValues={{
              definition: state?.curated
                ? state?.word?.definition
                : data?.definition,
              audioURL: state?.curated ? state?.word?.audioURL : data?.audioURL,
              pronunciation: state?.curated
                ? state?.word?.pronunciation
                : data?.pronunciation,
              word: state?.curated ? state?.word?.word : data?.word,
            }}
            onSubmit={(values, props) => {
              dispatch(editwords(state?._id, values, navigate));
              // navigate("/admin/word-listing");
              props.resetForm();
            }}
          >
            {({ values, setFieldValue, errors, touched }) => (
              <Form>
                <div className="form_group">
                  <label>Defination</label>
                  <FieldArray name="definition">
                    {({ push, remove }) => (
                      <div className="example_box">
                        {values?.definition?.map((defdata, index) => (
                          <div
                            className="example_box_inner defination_box_inner"
                            key={index}
                          >
                            <div>
                              {/* <AutoSizer disableHeight>
                                {({ width, height }) => (
                                  <List
                                    width={width}
                                    height={300}
                                    rowCount={values?.definition?.length}
                                    rowHeight={100}
                                    rowRenderer={({
                                      listindex,
                                      key,
                                      style,
                                    }) => (
                                      <div key={key} style={style}> */}
                              <Field
                                className="radio_box_left"
                                name={`definition[${index}].isDefault`}
                                type="radio"
                                value={true}
                                checked={values.definition[index].isDefault}
                                onChange={() => {
                                  // Update all other radio buttons to false
                                  values.definition
                                    // .filter((_, i) => i !== index)
                                    .forEach((_, i) => {
                                      setFieldValue(
                                        `definition[${i}].isDefault`,
                                        false
                                      );
                                    });

                                  // Update the selected radio button to true
                                  setFieldValue(
                                    `definition[${index}].isDefault`,
                                    true
                                  );
                                }}
                              />
                              <Field
                                as="select"
                                name={`definition[${index}].wordclass`}
                                defaultValue={defdata.wordclass}
                              >
                                <option value="">Wordclass</option>
                                <option value="noun">Noun</option>
                                <option value="verb">Verb</option>
                                <option value="adjective">Adjective</option>
                              </Field>
                              <Field
                                as="textarea"
                                name={`definition[${index}].text`}
                                placeholder="text"
                              />
                              <div className="form_group">
                                <label>Synonyms</label>
                                <Field
                                  name={`definition[${index}].synonyms`}
                                  component={useMulti}
                                  options={defdata.synonyms}
                                />
                              </div>
                              <div className="form_group">
                                <label>Antonyms</label>
                                <Field
                                  name={`definition[${index}].antonyms`}
                                  component={useMulti}
                                  options={defdata.antonyms}
                                />
                              </div>
                              <div className="form_group">
                                <label>Examples</label>
                                <FieldArray
                                  name={`definition[${index}].examples`}
                                >
                                  {({ push, remove }) => (
                                    <div>
                                      <div className="example_box">
                                        {defdata?.examples?.map(
                                          (exampledata, exampleIndex) => (
                                            // <AutoSizer disableHeight>
                                            //   {({
                                            //     width: examplewidth,
                                            //     // height,
                                            //   }) => (
                                            //     <List
                                            //       width={500}
                                            //       height={100}
                                            //       rowCount={
                                            //         values?.definition[index]
                                            //           ?.examples?.length
                                            //       }
                                            //       rowHeight={30}
                                            //       rowRenderer={({
                                            //         index: examplelistIndex,
                                            //         key: examplelistKey,
                                            //         style: examplelistStyle,
                                            //       }) => (
                                            //         <div
                                            //           key={examplelistKey}
                                            //           style={examplelistStyle}
                                            //         >
                                            <div
                                              className="example_box_inner"
                                              key={exampleIndex}
                                            >
                                              <Field
                                                name={`definition[${index}].examples[${exampleIndex}]`}
                                                as="textarea"
                                              />
                                              {exampleIndex + 1 ===
                                                defdata?.examples?.length && (
                                                <button
                                                  className="add_btn"
                                                  type="button"
                                                  disabled={
                                                    defdata?.examples[
                                                      exampleIndex
                                                    ] === ""
                                                  }
                                                  onClick={() => push("")}
                                                >
                                                  <svg
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                  >
                                                    <path
                                                      d="M12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20ZM11.25 14.75V12.75H9.25C8.83437 12.75 8.5 12.4156 8.5 12C8.5 11.5844 8.83437 11.25 9.25 11.25H11.25V9.25C11.25 8.83437 11.5844 8.5 12 8.5C12.4156 8.5 12.75 8.83437 12.75 9.25V11.25H14.75C15.1656 11.25 15.5 11.5844 15.5 12C15.5 12.4156 15.1656 12.75 14.75 12.75H12.75V14.75C12.75 15.1656 12.4156 15.5 12 15.5C11.5844 15.5 11.25 15.1656 11.25 14.75Z"
                                                      fill="#979C9E"
                                                    />
                                                  </svg>
                                                </button>
                                              )}
                                              {defdata?.examples?.length !==
                                                1 && (
                                                <button
                                                  className="remv_btn"
                                                  type="button"
                                                  onClick={() =>
                                                    remove(exampleIndex)
                                                  }
                                                >
                                                  <svg
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                  >
                                                    <path
                                                      d="M8.82857 3.65684C9.02143 3.25234 9.41786 3 9.85 3H14.15C14.5821 3 14.9786 3.25234 15.1714 3.65684L15.4286 4.1875H18.8571C19.4893 4.1875 20 4.71816 20 5.375C20 6.03184 19.4893 6.5625 18.8571 6.5625H5.14286C4.51071 6.5625 4 6.03184 4 5.375C4 4.71816 4.51071 4.1875 5.14286 4.1875H8.57143L8.82857 3.65684ZM5.14286 7.75H18.8571V19.625C18.8571 20.935 17.8321 22 16.5714 22H7.42857C6.16786 22 5.14286 20.935 5.14286 19.625V7.75ZM8.57143 10.125C8.25714 10.125 8 10.3922 8 10.7187V19.0312C8 19.3578 8.25714 19.625 8.57143 19.625C8.88571 19.625 9.14286 19.3578 9.14286 19.0312V10.7187C9.14286 10.3922 8.88571 10.125 8.57143 10.125ZM12 10.125C11.6857 10.125 11.4286 10.3922 11.4286 10.7187V19.0312C11.4286 19.3578 11.6857 19.625 12 19.625C12.3143 19.625 12.5714 19.3578 12.5714 19.0312V10.7187C12.5714 10.3922 12.3143 10.125 12 10.125ZM15.4286 10.125C15.1143 10.125 14.8571 10.3922 14.8571 10.7187V19.0312C14.8571 19.3578 15.1143 19.625 15.4286 19.625C15.7429 19.625 16 19.3578 16 19.0312V10.7187C16 10.3922 15.7429 10.125 15.4286 10.125Z"
                                                      fill="#979C9E"
                                                    />
                                                  </svg>
                                                </button>
                                              )}
                                            </div>
                                            //         </div>
                                            //       )}
                                            //     />
                                            //   )}
                                            // </AutoSizer>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </FieldArray>
                              </div>
                              {index + 1 === values?.definition?.length && (
                                <button
                                  className="add_btn"
                                  type="button"
                                  // disabled={
                                  //   values?.definition[index]?.text === ""
                                  // }
                                  onClick={() =>
                                    push({
                                      isDefault: false,
                                      wordclass: "",
                                      text: "",
                                      antonyms: [],
                                      synonyms: [],
                                      examples: [""],
                                    })
                                  }
                                  disabled={
                                    defdata?.text === "" ||
                                    defdata?.wordclass === "" ||
                                    defdata?.synonyms?.length === 0 ||
                                    defdata?.antonyms?.length === 0 ||
                                    defdata?.examples?.map(
                                      (index) => index?.text === ""
                                    )
                                  }
                                >
                                  <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20ZM11.25 14.75V12.75H9.25C8.83437 12.75 8.5 12.4156 8.5 12C8.5 11.5844 8.83437 11.25 9.25 11.25H11.25V9.25C11.25 8.83437 11.5844 8.5 12 8.5C12.4156 8.5 12.75 8.83437 12.75 9.25V11.25H14.75C15.1656 11.25 15.5 11.5844 15.5 12C15.5 12.4156 15.1656 12.75 14.75 12.75H12.75V14.75C12.75 15.1656 12.4156 15.5 12 15.5C11.5844 15.5 11.25 15.1656 11.25 14.75Z"
                                      fill="#979C9E"
                                    />
                                  </svg>
                                </button>
                              )}
                              {values?.definition?.length !== 1 && (
                                <button
                                  className="remv_btn"
                                  type="button"
                                  onClick={() => remove(index)}
                                >
                                  <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M8.82857 3.65684C9.02143 3.25234 9.41786 3 9.85 3H14.15C14.5821 3 14.9786 3.25234 15.1714 3.65684L15.4286 4.1875H18.8571C19.4893 4.1875 20 4.71816 20 5.375C20 6.03184 19.4893 6.5625 18.8571 6.5625H5.14286C4.51071 6.5625 4 6.03184 4 5.375C4 4.71816 4.51071 4.1875 5.14286 4.1875H8.57143L8.82857 3.65684ZM5.14286 7.75H18.8571V19.625C18.8571 20.935 17.8321 22 16.5714 22H7.42857C6.16786 22 5.14286 20.935 5.14286 19.625V7.75ZM8.57143 10.125C8.25714 10.125 8 10.3922 8 10.7187V19.0312C8 19.3578 8.25714 19.625 8.57143 19.625C8.88571 19.625 9.14286 19.3578 9.14286 19.0312V10.7187C9.14286 10.3922 8.88571 10.125 8.57143 10.125ZM12 10.125C11.6857 10.125 11.4286 10.3922 11.4286 10.7187V19.0312C11.4286 19.3578 11.6857 19.625 12 19.625C12.3143 19.625 12.5714 19.3578 12.5714 19.0312V10.7187C12.5714 10.3922 12.3143 10.125 12 10.125ZM15.4286 10.125C15.1143 10.125 14.8571 10.3922 14.8571 10.7187V19.0312C14.8571 19.3578 15.1143 19.625 15.4286 19.625C15.7429 19.625 16 19.3578 16 19.0312V10.7187C16 10.3922 15.7429 10.125 15.4286 10.125Z"
                                      fill="#979C9E"
                                    />
                                  </svg>
                                </button>
                              )}
                              {/* </div>
                                    )}
                                  />
                                )}
                              </AutoSizer> */}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </FieldArray>
                </div>
                <div className="form_group audio_box">
                  <label>Audio URL</label>
                  <Field as="input" name="audioURL" />
                  {errors.audioURL && touched.audioURL && (
                    <div style={{ color: "red" }}>{errors.audioURL}</div>
                  )}
                </div>
                <div className="form_group audio_box">
                  <label>Pronunciation</label>
                  <Field as="input" name="pronunciation" />
                  {errors.pronunciation && touched.pronunciation && (
                    <div style={{ color: "red" }}>{errors.pronunciation}</div>
                  )}
                </div>
                <div className="form_group text-center">
                  <button
                    className="submit_btn"
                    style={{ marginRight: "5px" }}
                    type="submit"
                  >
                    Submit
                  </button>
                  <button
                    className="submit_btn"
                    onClick={() => navigate("/admin/word-listing")}
                  >
                    Cancel
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      )}
    </>
  );
};

export default EditWord;
