import React, { useEffect, useState } from "react";
import { Formik, Form, Field, FieldArray, ErrorMessage } from "formik";
import * as Yup from "yup";
import useMulti from "../../hooks/useMulti";
import {
  AddwordonGoogleurl,
  addWordDetails,
  editwords,
  getAllwordclass,
  resetData,
} from "../../redux/sllices/wordSlice";
import { useDispatch, useSelector } from "react-redux";
import Loader from "../../Layout/Loader";
import TextError from "../../utilities/TextError";
import { NavLink, useNavigate } from "react-router-dom";

const validationSchema = Yup.object().shape({
  wlLexicalEntries: Yup.array().of(
    Yup.object().shape({
      wordClass: Yup.string().required("Wordclass is required"),
      definitions: Yup.array().of(
        Yup.object().shape({
          isDefault: Yup.boolean().required("isDefault is required"),
          definitionText: Yup.string().when(
            "isDefault",
            ([isDefault], schema) => {
              return isDefault
                ? Yup.string().required("Definition is required")
                : Yup.string();
            }
          ),
        })
      ),
    })
  ),
});

const NewAddWord = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const data = useSelector((state) => state?.root?.words?.addWordData);
  const wordClassArray = useSelector(
    (state) => state?.root?.words?.wordClassArray
  );
  const loading = useSelector((state) => state?.root?.words?.loading);
  const [searchValue, setSearchValue] = useState("");
  const [wordError, setWordError] = useState(false);
  const [formShow, setFormShow] = useState(false);

  useEffect(() => {
    dispatch(resetData());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    dispatch(getAllwordclass());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Check the length of definitions array and push a default definition if needed
  const newwlLexicalEntries = data?.wlLexicalEntries?.map((entry) => {
    if (entry.definitions.length <= 1) {
      return {
        ...entry,
        definitions: [
          ...entry.definitions,
          { isDefault: false, definitionText: "" },
        ],
      };
    }
    return entry;
  });

  const initialValues = {
    word: data?.word,
    audioURL: data?.audioURL,
    pronunciation: data?.pronunciation,
    wlLexicalEntries: newwlLexicalEntries,

    // wlLexicalEntries: [
    //   {
    //     wordClass: "Adjective",
    //     definitions: [
    //       { isDefault: true, definitionText: "hello" },
    //       { isDefault: false, definitionText: "hello" },
    //     ],
    //     synonym: ["h1"],
    //     antonym: ["h2"],
    //     example: ["1", "2", "3", "4", "5"],
    //   },
    // ],
  };

  const searchurlbase = {
    word: searchValue,
    audioURL: "",
    pronunciation: "",
    wlLexicalEntries: [
      {
        wordClass: "",
        definitions: [
          { isDefault: true, definitionText: "" },
          { isDefault: false, definitionText: "" },
        ],
        synonym: [],
        antonym: [],
        example: ["", "", "", "", ""],
      },
    ],
  };

  const AddWord = () => {
    if (searchValue === "") {
      setWordError(true);
    } else {
      dispatch(addWordDetails(searchValue, setFormShow, navigate));
    }
  };

  const keyDoenHandler = (event) => {
    if (event.key === "Enter") {
      if (searchValue === "") {
        setWordError(true);
      } else {
        !formShow &&
          dispatch(addWordDetails(searchValue, setFormShow, navigate));
      }
    }
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="container">
          <div className="d-flex align-items-center mb-3">
            <NavLink to="/admin/word-listing" className="back-btn-link m-0">
              <svg
                width="48"
                height="48"
                viewBox="0 0 48 48"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="48" height="48" rx="24" fill="#00509D" />
                <path
                  d="M31 24.0001H17M17 24.0001L24 31M17 24.0001L24 17"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </NavLink>
            <h1 id="heading" className="m-0 p-0">
              Add Word
            </h1>
          </div>
          <div className="clearfix"></div>
          <div className="new_definition">
            <div className="admin_wordline">
              <label> Enter Word</label>
              <input
                disabled={formShow}
                style={{ cursor: formShow && "not-allowed" }}
                type="text"
                className={`${formShow && "input-round"}`}
                placeholder="Type your word"
                defaultValue={formShow ? data?.word : ""}
                onKeyDown={keyDoenHandler}
                onChange={(e) => {
                  setWordError(false);
                  setSearchValue(e?.target?.value.trim());
                }}
              />

              {!formShow && <button onClick={AddWord}>Add</button>}
            </div>
            {wordError && <p style={{ color: "red" }}>Please Enter Word</p>}
            {data?.searchUrl && (
              <div className="container url_box">
                <NavLink to={data?.searchUrl} target="_blank">
                  {data?.searchUrl}
                </NavLink>
              </div>
            )}

            {formShow && (
              <Formik
                initialValues={data?.searchUrl ? searchurlbase : initialValues}
                validationSchema={validationSchema}
                onSubmit={(values, props) => {
                  const obj = JSON.parse(JSON.stringify(values));
                  obj.wlLexicalEntries.map((e) => {
                    const newDefinitions = e.definitions.filter(
                      (i) => i.definitionText !== ""
                    );
                    const newExample = e.example.filter((i) => i !== "");
                    e.definitions = newDefinitions;
                    e.example = newExample;
                  });

                  data?.searchUrl
                    ? dispatch(AddwordonGoogleurl(searchValue, obj, navigate))
                    : dispatch(editwords(data?._id, obj, navigate));
                  props.resetForm();
                }}
              >
                {({ values, setFieldValue, errors, touched }) => (
                  // console.log(errors, "errors"),
                  <Form>
                    <FieldArray name="wlLexicalEntries">
                      {({ push, remove }) => (
                        <div className="example_box">
                          {values?.wlLexicalEntries?.map(
                            (wlexicalentrydata, wlexicalentryindex) => (
                              <div
                                className="example_box_inner withboder"
                                key={wlexicalentryindex}
                              >
                                <div className="form_group with_select">
                                  <div className="top_defination">
                                    <label>Word Class</label>
                                    <div className="select_wordclass">
                                      <Field
                                        as="select"
                                        name={`wlLexicalEntries[${wlexicalentryindex}].wordClass`}
                                      >
                                        <option value="">Wordclass</option>
                                        {wordClassArray.map(
                                          (wordClass, index) => (
                                            <option
                                              key={wordClass?._id}
                                              value={wordClass?.name}
                                              disabled={
                                                !!values.wlLexicalEntries.some(
                                                  (e, i) =>
                                                    i !== wlexicalentryindex &&
                                                    e.wordClass ===
                                                      wordClass?.name
                                                )
                                              }
                                            >
                                              {wordClass?.name}
                                            </option>
                                          )
                                        )}
                                      </Field>
                                      <ErrorMessage
                                        name={`wlLexicalEntries[${wlexicalentryindex}].wordClass`}
                                        component={TextError}
                                      />
                                    </div>
                                  </div>
                                  <label>Definitions</label>
                                  <div className="example_box">
                                    <div className="example_box_inner">
                                      <div className="custom-radio">
                                        <Field
                                          className="radio_box_left1"
                                          name={`wlLexicalEntries[${wlexicalentryindex}].definitions[0].isDefault`}
                                          type="radio"
                                          value={true}
                                          defaultValue={false}
                                          disabled={
                                            values?.wlLexicalEntries[
                                              wlexicalentryindex
                                            ]?.definitions[0]?.definitionText ==
                                              undefined ||
                                            values?.wlLexicalEntries[
                                              wlexicalentryindex
                                            ]?.definitions[0]?.definitionText ==
                                              ""
                                          }
                                          checked={
                                            values?.wlLexicalEntries[
                                              wlexicalentryindex
                                            ]?.definitions[0]?.isDefault
                                          }
                                          onChange={() => {
                                            const newdefination = [
                                              ...values.wlLexicalEntries[
                                                wlexicalentryindex
                                              ]?.definitions,
                                            ];
                                            let newdefinationcopy =
                                              newdefination.map((item) => ({
                                                ...item,
                                                isDefault: false,
                                              }));
                                            newdefinationcopy[0].isDefault = true;
                                            setFieldValue(
                                              `wlLexicalEntries[${wlexicalentryindex}].definitions`,
                                              newdefinationcopy
                                            );
                                          }}
                                        />
                                        <span class="checkmark"></span>
                                      </div>
                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].definitions[0].definitionText`}
                                        as="textarea"
                                        defaultValue={""}
                                      />
                                      <ErrorMessage
                                        name={`wlLexicalEntries[${wlexicalentryindex}].definitions[0].definitionText`}
                                        component={TextError}
                                      />
                                    </div>
                                    <div className="example_box_inner">
                                      <div className="custom-radio">
                                        <Field
                                          className="radio_box_left1"
                                          name={`wlLexicalEntries[${wlexicalentryindex}].definitions[1].isDefault`}
                                          type="radio"
                                          value={true}
                                          defaultValue={false}
                                          disabled={
                                            values?.wlLexicalEntries[
                                              wlexicalentryindex
                                            ]?.definitions[1]?.definitionText ==
                                              undefined ||
                                            values?.wlLexicalEntries[
                                              wlexicalentryindex
                                            ]?.definitions[1]?.definitionText ==
                                              ""
                                          }
                                          checked={
                                            values?.wlLexicalEntries[
                                              wlexicalentryindex
                                            ]?.definitions[1]?.isDefault
                                          }
                                          onChange={() => {
                                            const newdefination = [
                                              ...values.wlLexicalEntries[
                                                wlexicalentryindex
                                              ]?.definitions,
                                            ];
                                            let newdefinationcopy =
                                              newdefination.map((item) => ({
                                                ...item,
                                                isDefault: false,
                                              }));
                                            newdefinationcopy[1].isDefault = true;
                                            setFieldValue(
                                              `wlLexicalEntries[${wlexicalentryindex}].definitions`,
                                              newdefinationcopy
                                            );
                                          }}
                                        />
                                        <span class="checkmark"></span>
                                      </div>

                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].definitions[1].definitionText`}
                                        as="textarea"
                                        defaultValue={""}
                                      />

                                      <ErrorMessage
                                        name={`wlLexicalEntries[${wlexicalentryindex}].definitions[1].definitionText`}
                                        component={TextError}
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="form_group">
                                  <label>Synonyms</label>

                                  <Field
                                    name={`wlLexicalEntries[${wlexicalentryindex}].synonym`}
                                    component={useMulti}
                                    options={wlexicalentrydata.synonym}
                                  />
                                  <ErrorMessage
                                    name={`wlLexicalEntries[${wlexicalentryindex}].synonym`}
                                    component={TextError}
                                  />
                                </div>
                                <div className="form_group">
                                  <label>Antonyms</label>
                                  <Field
                                    name={`wlLexicalEntries[${wlexicalentryindex}].antonym`}
                                    component={useMulti}
                                    options={wlexicalentrydata.antonym}
                                  />
                                  <ErrorMessage
                                    name={`wlLexicalEntries[${wlexicalentryindex}].antonym`}
                                    component={TextError}
                                  />
                                </div>

                                <div className="form_group">
                                  <label>Examples</label>
                                  <div className="example_box">
                                    <div className="example_box_inner full_width">
                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].example[0]`}
                                        as="textarea"
                                        defaultValue={""}
                                      />
                                    </div>
                                    <div className="example_box_inner full_width">
                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].example[1]`}
                                        as="textarea"
                                        defaultValue={""}
                                      />
                                    </div>
                                    <div className="example_box_inner full_width">
                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].example[2]`}
                                        as="textarea"
                                        defaultValue={""}
                                      />
                                    </div>
                                    <div className="example_box_inner full_width">
                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].example[3]`}
                                        as="textarea"
                                        defaultValue={""}
                                      />
                                    </div>
                                    <div className="example_box_inner full_width">
                                      <Field
                                        name={`wlLexicalEntries[${wlexicalentryindex}].example[4]`}
                                        as="textarea"
                                        defaultValue={""}
                                      />
                                    </div>
                                  </div>
                                </div>
                                {/* 
                              <div className="form_group">
                                <label>Examples</label>
                                <FieldArray
                                  name={`wlLexicalEntries[${wlexicalentryindex}].example`}
                                >
                                  {({ push, remove }) => (
                                    <div>
                                      <div className="example_box">
                                        {wlexicalentrydata?.example?.map(
                                          (exampledata, exampleIndex) => (
                                            <div
                                              className="example_box_inner"
                                              key={exampleIndex}
                                            >
                                              <Field
                                                name={`wlLexicalEntries[${wlexicalentryindex}].example[${exampleIndex}]`}
                                                as="textarea"
                                              />

                                              {exampleIndex + 1 ===
                                                values?.wlLexicalEntries[
                                                  wlexicalentryindex
                                                ]?.example?.length &&
                                                values?.wlLexicalEntries[
                                                  wlexicalentryindex
                                                ]?.example?.length < 5 && (
                                                  <button
                                                    className="add_btn"
                                                    type="button"
                                                    onClick={() => push("")}
                                                  >
                                                    <svg
                                                      width="24"
                                                      height="24"
                                                      viewBox="0 0 24 24"
                                                      fill="none"
                                                      xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                      <path
                                                        d="M12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20ZM11.25 14.75V12.75H9.25C8.83437 12.75 8.5 12.4156 8.5 12C8.5 11.5844 8.83437 11.25 9.25 11.25H11.25V9.25C11.25 8.83437 11.5844 8.5 12 8.5C12.4156 8.5 12.75 8.83437 12.75 9.25V11.25H14.75C15.1656 11.25 15.5 11.5844 15.5 12C15.5 12.4156 15.1656 12.75 14.75 12.75H12.75V14.75C12.75 15.1656 12.4156 15.5 12 15.5C11.5844 15.5 11.25 15.1656 11.25 14.75Z"
                                                        fill="#979C9E"
                                                      />
                                                    </svg>
                                                  </button>
                                                )}
                                              {values?.wlLexicalEntries[
                                                wlexicalentryindex
                                              ]?.example?.length !== 1 && (
                                                <button
                                                  className="remv_btn"
                                                  type="button"
                                                  onClick={() =>
                                                    remove(exampleIndex)
                                                  }
                                                >
                                                  <svg
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                  >
                                                    <path
                                                      d="M8.82857 3.65684C9.02143 3.25234 9.41786 3 9.85 3H14.15C14.5821 3 14.9786 3.25234 15.1714 3.65684L15.4286 4.1875H18.8571C19.4893 4.1875 20 4.71816 20 5.375C20 6.03184 19.4893 6.5625 18.8571 6.5625H5.14286C4.51071 6.5625 4 6.03184 4 5.375C4 4.71816 4.51071 4.1875 5.14286 4.1875H8.57143L8.82857 3.65684ZM5.14286 7.75H18.8571V19.625C18.8571 20.935 17.8321 22 16.5714 22H7.42857C6.16786 22 5.14286 20.935 5.14286 19.625V7.75ZM8.57143 10.125C8.25714 10.125 8 10.3922 8 10.7187V19.0312C8 19.3578 8.25714 19.625 8.57143 19.625C8.88571 19.625 9.14286 19.3578 9.14286 19.0312V10.7187C9.14286 10.3922 8.88571 10.125 8.57143 10.125ZM12 10.125C11.6857 10.125 11.4286 10.3922 11.4286 10.7187V19.0312C11.4286 19.3578 11.6857 19.625 12 19.625C12.3143 19.625 12.5714 19.3578 12.5714 19.0312V10.7187C12.5714 10.3922 12.3143 10.125 12 10.125ZM15.4286 10.125C15.1143 10.125 14.8571 10.3922 14.8571 10.7187V19.0312C14.8571 19.3578 15.1143 19.625 15.4286 19.625C15.7429 19.625 16 19.3578 16 19.0312V10.7187C16 10.3922 15.7429 10.125 15.4286 10.125Z"
                                                      fill="#979C9E"
                                                    />
                                                  </svg>
                                                </button>
                                              )}
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </FieldArray>
                              </div> */}

                                <div className="form_group pb-0">
                                  <div className="remove-add-btns">
                                    {values?.wlLexicalEntries?.length !== 1 && (
                                      <button
                                        className="remv_btn floatR"
                                        type="button"
                                        onClick={() =>
                                          remove(wlexicalentryindex)
                                        }
                                      >
                                        Remove WordClass
                                        <svg
                                          width="24"
                                          height="24"
                                          viewBox="0 0 24 24"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M8.82857 3.65684C9.02143 3.25234 9.41786 3 9.85 3H14.15C14.5821 3 14.9786 3.25234 15.1714 3.65684L15.4286 4.1875H18.8571C19.4893 4.1875 20 4.71816 20 5.375C20 6.03184 19.4893 6.5625 18.8571 6.5625H5.14286C4.51071 6.5625 4 6.03184 4 5.375C4 4.71816 4.51071 4.1875 5.14286 4.1875H8.57143L8.82857 3.65684ZM5.14286 7.75H18.8571V19.625C18.8571 20.935 17.8321 22 16.5714 22H7.42857C6.16786 22 5.14286 20.935 5.14286 19.625V7.75ZM8.57143 10.125C8.25714 10.125 8 10.3922 8 10.7187V19.0312C8 19.3578 8.25714 19.625 8.57143 19.625C8.88571 19.625 9.14286 19.3578 9.14286 19.0312V10.7187C9.14286 10.3922 8.88571 10.125 8.57143 10.125ZM12 10.125C11.6857 10.125 11.4286 10.3922 11.4286 10.7187V19.0312C11.4286 19.3578 11.6857 19.625 12 19.625C12.3143 19.625 12.5714 19.3578 12.5714 19.0312V10.7187C12.5714 10.3922 12.3143 10.125 12 10.125ZM15.4286 10.125C15.1143 10.125 14.8571 10.3922 14.8571 10.7187V19.0312C14.8571 19.3578 15.1143 19.625 15.4286 19.625C15.7429 19.625 16 19.3578 16 19.0312V10.7187C16 10.3922 15.7429 10.125 15.4286 10.125Z"
                                            fill="#979C9E"
                                          />
                                        </svg>
                                      </button>
                                    )}

                                    {wlexicalentryindex + 1 ===
                                      values?.wlLexicalEntries?.length &&
                                      values?.wlLexicalEntries?.length <
                                        wordClassArray.length && (
                                        <button
                                          className="add_btn floatR"
                                          type="button"
                                          onClick={() =>
                                            push({
                                              wordClass: "",
                                              definitions: [
                                                {
                                                  isDefault: true,
                                                  definitionText: "",
                                                },
                                                {
                                                  isDefault: false,
                                                  definitionText: "",
                                                },
                                              ],
                                              synonym: [],
                                              antonym: [],
                                              example: ["", "", "", "", ""],
                                            })
                                          }
                                        >
                                          Add WordClass
                                          <svg
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                          >
                                            <path
                                              d="M12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20ZM11.25 14.75V12.75H9.25C8.83437 12.75 8.5 12.4156 8.5 12C8.5 11.5844 8.83437 11.25 9.25 11.25H11.25V9.25C11.25 8.83437 11.5844 8.5 12 8.5C12.4156 8.5 12.75 8.83437 12.75 9.25V11.25H14.75C15.1656 11.25 15.5 11.5844 15.5 12C15.5 12.4156 15.1656 12.75 14.75 12.75H12.75V14.75C12.75 15.1656 12.4156 15.5 12 15.5C11.5844 15.5 11.25 15.1656 11.25 14.75Z"
                                              fill="#979C9E"
                                            />
                                          </svg>
                                        </button>
                                      )}
                                  </div>
                                </div>
                              </div>
                            )
                          )}
                        </div>
                      )}
                    </FieldArray>
                    <div className="form_group audio_box mt-3">
                      <label>Audio URL</label>
                      <Field as="input" name="audioURL" />
                    </div>
                    <div className="form_group audio_box">
                      <label>Pronunciation</label>
                      <Field as="input" name="pronunciation" />
                    </div>
                    <div className="form_group text-center">
                      <button
                        className="submit_btn"
                        style={{ marginRight: "5px" }}
                        type="submit"
                      >
                        Submit
                      </button>
                      <button
                        className="submit_btn"
                        style={{ marginRight: "5px" }}
                        onClick={() => navigate("/admin/word-listing")}
                      >
                        Cancel
                      </button>
                    </div>
                  </Form>
                )}
              </Formik>
            )}
          </div>
          <div className="clearfix"></div>
        </div>
      )}
    </>
  );
};

export default NewAddWord;
