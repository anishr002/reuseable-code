import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Pagination,
  Tooltip,
  Box,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { NavLink } from "react-router-dom";
import Message from "../../utilities/Message";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteWords,
  getAllWords,
  getSingleWordDetail,
  resetsingleData,
} from "../../redux/sllices/wordSlice";
import { useDebouncedValue } from "../../hooks/usedebounce";
import Loader from "../../Layout/Loader";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import ClearIcon from "@mui/icons-material/Clear";

export default function WordTable() {
  const dispatch = useDispatch();
  const [searchValue, setSearchValue] = useState("");
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const StartIndex = (page - 1) * rowsPerPage + 1;
  const data = useSelector((state) => state?.root?.words?.data);
  const { loading } = useSelector((state) => state?.root?.words);

  const debouncedValue = useDebouncedValue(searchValue, 1000);

  const navigate = useNavigate();

  useEffect(() => {
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const pages = searchValue !== "" ? 1 : page;
    dispatch(getAllWords(searchValue, pages, rowsPerPage));
    // setPage(1);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedValue, page, rowsPerPage]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  // useEffect(() => {
  //   const page = 1;
  //   dispatch(getAllWords(searchValue, page, rowsPerPage));
  // }, [rowsPerPage]);

  // useEffect(() => {
  //   dispatch(getAllWords(searchValue, page, rowsPerPage));
  // }, [page]);

  const MySwal = withReactContent(Swal);

  const showAlert = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this Word",
      // showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      confirmButtonColor: "red",
      // denyButtonText: `Don't save`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        if (data?.wordData?.length == 1 && page > 1) {
          setPage((pre) => pre - 1);
        }
        dispatch(
          deleteWords(
            id,
            searchValue,
            page,
            rowsPerPage,
            data?.wordData?.length == 1
          )
        );
      }
    });
  };

  function capitalize(str) {
    if (str && str.length >= 1) {
      const firstChar = str.charAt(0);
      const remainingStr = str.slice(1);
      str = firstChar.toUpperCase() + remainingStr;
    }
    return str;
  }

  const sliceStart = page * rowsPerPage;
  const sliceEnd = sliceStart + rowsPerPage;
  const displayedRows = data?.wordData?.slice(sliceStart, sliceEnd);

  const styles = {
    wordBreak: "break-word",
  };

  const handleClearSearch = () => {
    setSearchValue("");
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          <h1 id="heading">Manage Words</h1>
          <div className="top_bar">
            <div className="custom_search_block">
              <input
                type="text"
                id="searchInput"
                placeholder="Search"
                value={searchValue}
                onKeyDown={handleKeyDown}
                onChange={(e) => {
                  setSearchValue(e.target.value);
                  setTimeout(() => {
                    setPage(1);
                  }, 980);
                }}
              />
              {searchValue && (
                <ClearIcon onClick={handleClearSearch} fontSize="small" />
              )}
            </div>

            <NavLink
              to="/admin/add-word"
              className="primary-btn text-decoration-none"
            >
              Add Word
            </NavLink>
          </div>
          {data?.wordData?.length === 0 ? (
            <>
              <div className="tabel_box">
                <p className="text-center">No Data Found</p>
              </div>
            </>
          ) : (
            <>
              <div className="tabel_box manage_word">
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>#</TableCell>
                        <TableCell>Word</TableCell>
                        <TableCell>Definition</TableCell>
                        <TableCell>Curated</TableCell>
                        <TableCell>Action</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {data?.wordData?.map((row, index) => {
                        return (
                          <TableRow key={row?._id}>
                            <TableCell data-label="#">
                              {StartIndex + index}
                            </TableCell>
                            <TableCell data-label="Word">
                              {capitalize(row?.word?.word)}
                            </TableCell>
                            <TableCell data-label="Definition" style={styles}>
                              {row?.word?.wlLexicalEntries?.map(
                                (wlentrydata, i) => {
                                  return (
                                    <>
                                      {wlentrydata?.definitions.length > 0
                                        ? wlentrydata?.definitions?.map(
                                            (def, i) => {
                                              if (def.isDefault === true) {
                                                return def.definitionText;
                                              }
                                            }
                                          )
                                        : "-"}
                                    </>
                                  );
                                }
                              )}
                              {/* ?.filter((o) => o?.isDefault === false) */}
                            </TableCell>
                            <TableCell data-label="Curated">
                              {row?.curated === false ? (
                                <h6>
                                  {" "}
                                  <span className="badge bg-danger">False</span>
                                </h6>
                              ) : (
                                <h6>
                                  <span className="badge bg-success">True</span>
                                </h6>
                              )}
                            </TableCell>
                            <TableCell
                              data-label="Action"
                              style={{ width: "100px" }}
                            >
                              <Box display="flex">
                                <Tooltip title="Edit">
                                  <IconButton
                                    className="edit_btn"
                                    aria-label="edit"
                                    onClick={() => {
                                      navigate(`/admin/edit-word/${row?._id}`);

                                      // dispatch(
                                      //   getSingleWordDetail(row?._id, navigate)
                                      // );
                                    }}
                                  >
                                    <EditIcon />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Delete">
                                  <IconButton
                                    className="dlt_btn"
                                    aria-label="delete"
                                    onClick={() => showAlert(row?._id)}
                                  >
                                    <DeleteIcon />
                                  </IconButton>
                                </Tooltip>
                              </Box>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              </div>
              <div className="paginationbox">
                <Pagination
                  count={Math.ceil(data?.count / rowsPerPage)}
                  variant="outlined"
                  page={page}
                  color="primary"
                  onChange={handleChangePage}
                  style={{ display: "flex", justifyContent: "flex-end" }}
                />
                <div className="per_page">
                  <label for="rowperpage">Rows per page :</label>
                  <select
                    name="rowperpage"
                    value={rowsPerPage}
                    id="rowperpage"
                    onChange={(e) => {
                      setPage(1);
                      setRowsPerPage(e.target.value);
                    }}
                  >
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                  </select>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
