import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Pagination,
  Tooltip,
} from "@mui/material";
import {
  deleteQuiz,
  getAdminQuizlist,
  resetsingleQuizdata,
} from "../../redux/sllices/adminQuizSlice";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { NavLink } from "react-router-dom";
import Message from "../../utilities/Message";
import { useDispatch, useSelector } from "react-redux";
import { useDebouncedValue } from "../../hooks/usedebounce";
import Loader from "../../Layout/Loader";
import Swal from "sweetalert2";
// import { capitalCase } from "change-case";
import moment from "moment";
import {
  deleteQuestion,
  getAdminQuestionlist,
} from "../../redux/sllices/adminQuestionSlice";
import { Box } from "@mui/system";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import ClearIcon from "@mui/icons-material/Clear";
import { getCategorylistforDropdown } from "../../redux/sllices/adminCategorySlice";
import caticon from "../../assets/images/category_icon.svg";

export default function QuestionTable() {
  const [searchValue, setSearchValue] = useState("");
  const [pageNumber, setpageNumber] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedOption, setSelectedOption] = useState("");

  //store value Selection
  const loading = useSelector((state) => state?.root?.adminQuestion?.loading);
  const Questionslist = useSelector(
    (state) => state?.root?.adminQuestion?.adminQuestionlistdata
  );
  const Categorylist = useSelector(
    (state) => state?.root?.adminCategory?.adminCategorylistdata
  );

  const debouncedValue = useDebouncedValue(searchValue, 1000);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  //Category Dropdown list API call
  useEffect(() => {
    dispatch(getCategorylistforDropdown());
  }, []);

  //useEffect list API call
  useEffect(() => {
    const pages = searchValue !== "" ? 1 : pageNumber;
    dispatch(
      getAdminQuestionlist(searchValue, pages, rowsPerPage, selectedOption, [])
    );
  }, [debouncedValue, pageNumber, rowsPerPage, selectedOption]);

  // pagination page
  const handleChangePage = (event, page) => {
    setpageNumber(page);
  };

  //Quiz delete model,rowsPerPage
  const showAlert = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this Question",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      confirmButtonColor: "red",
    }).then((result) => {
      if (result.isConfirmed) {
        if (Questionslist?.result?.length == 1 && pageNumber > 1) {
          setpageNumber((pre) => pre - 1);
        }
        dispatch(
          deleteQuestion(
            id,
            searchValue,
            pageNumber,
            rowsPerPage,
            Questionslist?.result?.length == 1,
            selectedOption
          )
        );
      }
    });
  };

  const StartIndex = (pageNumber - 1) * rowsPerPage + 1;

  const styles = {
    wordBreak: "break-word",
  };
  const handleClearSearch = () => {
    setSearchValue("");
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="container">
            <h1 id="heading">Manage Questions</h1>
            <div className="d-flex w-100 add_category_box">
              <div className="top_bar pe-3">
                <div className="custom_search_block">
                  <input
                    type="text"
                    id="searchInput"
                    placeholder="Search"
                    value={searchValue}
                    onKeyDown={handleKeyDown}
                    onChange={(e) => {
                      setSearchValue(e.target.value);
                      setTimeout(() => {
                        setpageNumber(1);
                      }, 980);
                      // setpageNumber(1);
                    }}
                  />

                  {searchValue && (
                    <ClearIcon onClick={handleClearSearch} fontSize="small" />
                  )}
                </div>

                <NavLink
                  to="/admin/add-question"
                  className="primary-btn text-decoration-none"
                >
                  Add Question
                </NavLink>
              </div>
              <div className="question_dropdown position-relative">
                <img src={caticon} alt="" className="question_category_icon" />
                <select
                  value={selectedOption}
                  onChange={(event) => {
                    setSelectedOption(event.target.value);
                  }}
                >
                  <option value="">Category</option>
                  {Categorylist?.categoryData?.map((data, index) => {
                    return (
                      <option value={data?._id} key={index}>
                        {data?.name}
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>
          </div>
          {Questionslist?.result?.length === 0 ? (
            <>
              <div className="container">
                <div className="tabel_box">
                  <p className="text-center">No Data Found</p>
                </div>
                <div className="clearfix"></div>
              </div>
            </>
          ) : (
            <>
              <div className="container">
                <div className="tabel_box manage_word3">
                  <TableContainer>
                    <Table>
                      <TableHead>
                        {" "}
                        <TableRow>
                          <TableCell>#</TableCell>
                          <TableCell>Questions</TableCell>
                          <TableCell>Questions Category</TableCell>
                          <TableCell>Action</TableCell>{" "}
                        </TableRow>{" "}
                      </TableHead>

                      <TableBody>
                        {Questionslist?.result?.map((row, index) => {
                          return (
                            <TableRow key={row?._id}>
                              <TableCell data-label="#">
                                {StartIndex + index}
                              </TableCell>
                              <TableCell data-label="Questions" style={styles}>
                                {row?.questionText}
                              </TableCell>
                              <TableCell data-label="Questions" style={styles}>
                                {row?.categoryData?.name}
                              </TableCell>

                              <TableCell data-label="Action">
                                <Box display="flex">
                                  <Tooltip title="Edit">
                                    <IconButton className="edit_btn">
                                      <EditIcon
                                        onClick={() => {
                                          navigate(
                                            `/admin/edit-question/${row?._id}`
                                          );
                                        }}
                                      />
                                    </IconButton>
                                  </Tooltip>
                                  <Tooltip title="Delete" data-label="Word">
                                    <IconButton className="dlt_btn">
                                      <DeleteIcon
                                        onClick={() => {
                                          showAlert(row?._id);
                                        }}
                                      />
                                    </IconButton>
                                  </Tooltip>
                                </Box>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </div>
                <div className="paginationbox pb-lg-5 pb-3">
                  <Pagination
                    count={Questionslist?.totalPages}
                    variant="outlined"
                    page={pageNumber}
                    color="primary"
                    onChange={handleChangePage}
                    style={{ display: "flex", justifyContent: "flex-end" }}
                  />
                  <div className="per_page">
                    <label for="rowperpage">Rows per page :</label>
                    <select
                      name="rowperpage"
                      value={rowsPerPage}
                      id="rowperpage"
                      onChange={(e) => {
                        setpageNumber(1);
                        setRowsPerPage(e.target.value);
                      }}
                    >
                      {/* <option value="5">5</option> */}
                      <option value="10">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                    </select>
                  </div>
                </div>
                <div className="clearfix"></div>
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
