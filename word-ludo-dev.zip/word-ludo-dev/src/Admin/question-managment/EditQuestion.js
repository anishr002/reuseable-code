import React, { useEffect, useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import TextError from "../../utilities/TextError";
import { useDispatch, useSelector } from "react-redux";
import {
  addAdminQuestion,
  editQuestion,
  getSingleQuestionDetail,
} from "../../redux/sllices/adminQuestionSlice";
import {
  useLocation,
  useNavigate,
  useNavigation,
  useParams,
} from "react-router-dom";
import Loader from "../../Layout/Loader";
import { getCategorylistforDropdown } from "../../redux/sllices/adminCategorySlice";

const EditQuestion = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  const navigate = useNavigate();

  const loading = useSelector((state) => state?.root?.adminQuestion?.loading);
  const categoryloading = useSelector(
    (state) => state?.root?.adminCategory?.loading
  );
  const Categorylist = useSelector(
    (state) => state?.root?.adminCategory?.adminCategorylistdata
  );
  const singleQuestionsData = useSelector(
    (state) => state?.root?.adminQuestion?.singleQuestiondata
  );

  const [editquestionData, seteditquestionData] = useState();
  const [optmsg, setOptmsg] = useState(false);

  useEffect(() => {
    dispatch(getSingleQuestionDetail(id, seteditquestionData));
  }, [id]);

  //Category Dropdown list API call
  useEffect(() => {
    dispatch(getCategorylistforDropdown());
  }, []);

  const editmodeinitialValues = {
    questionText: singleQuestionsData?.questionText,
    rightAnswer: singleQuestionsData?.rightAnswer,
    questionType: singleQuestionsData?.questionType,
    options: singleQuestionsData?.options,
    categoryId: singleQuestionsData?.categoryId?._id,
  };

  // console.log(singleQuestionsData?.categoryId?.name);

  const initialValueSchema = {
    questionText: "",
    options: ["", "", "", ""],
    rightAnswer: "",
    questionType: "",
    categoryId: "",
  };

  const validationSchema = Yup.object().shape({
    questionText: Yup.string()
      .required("Question Text is required")
      .trim("space can not be allowed")
      .min(10, "Question Text must be at least 10 characters")
      .max(150, "Question Text can be maximum 150 characters"),
    rightAnswer: Yup.string()
      .required(" Please Write Correct Answer ")
      .trim("space can not be allowed"),
    questionType: Yup.string().required("Question Type is required"),
    categoryId: Yup.string().required("Question Categroy is required"),
    options: Yup.array().when("questionType", {
      is: "multiplechoice",
      then: () =>
        Yup.array().of(
          Yup.string()
            .trim("space can not be allowed")
            .required("Option is required")
        ),
      // otherwise: Yup.array(),
    }),
  });

  const onSubmit = (values, onSubmitProps) => {
    const NewValues = {
      ...values,
      options:
        values.questionType === "sortanswer"
          ? ["", "", "", ""]
          : values.options,
    };
    singleQuestionsData
      ? dispatch(editQuestion(singleQuestionsData?._id, NewValues, navigate))
      : dispatch(addAdminQuestion(NewValues, navigate));

    onSubmitProps.resetForm();
  };
  return (
    <>
      {loading || categoryloading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details">
          <div className="container">
            <Formik
              initialValues={
                singleQuestionsData ? editmodeinitialValues : initialValueSchema
              }
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue, errors } = formik;
                if (
                  formik?.values?.options?.some(
                    (o, i) => o === formik?.values?.rightAnswer
                  )
                ) {
                  setOptmsg(false);
                } else {
                  setOptmsg(true);
                }

                return (
                  <Form>
                    <h1 className="crt_quiz">
                      {singleQuestionsData
                        ? "Edit Question"
                        : "Create Question"}
                    </h1>
                    <div className="form-field">
                      <label>
                        Question Text
                        <span>*</span>
                      </label>
                      <Field
                        name={`questionText`}
                        placeholder="Enter a question "
                        type="text"
                        onChange={(e) => {
                          const value = e.target.value;
                          const trimmedValue = value.trimStart();
                          // Update the field value
                          setFieldValue("questionText", trimmedValue);
                        }}
                      />
                      <ErrorMessage
                        name={`questionText`}
                        component={TextError}
                      />
                    </div>
                    <div className="form-field">
                      <label>
                        Question Categroy
                        <span>*</span>
                      </label>
                      <Field as="select" name={`categoryId`}>
                        <option
                          defaultValue={singleQuestionsData?.categoryId?._id}
                        >
                          {singleQuestionsData?.categoryId?.name}
                        </option>
                        {Categorylist?.categoryData?.map((data, index) => {
                          return (
                            <option value={data._id} key={index}>
                              {data.name}
                            </option>
                          );
                        })}
                      </Field>
                      <ErrorMessage name={`categoryId`} component={TextError} />
                    </div>

                    <div className="form-field">
                      <label>
                        Question Type
                        <span>*</span>
                      </label>
                      <Field
                        as="select"
                        name={`questionType`}
                        onChange={(e) => {
                          setFieldValue("rightAnswer", "");
                          setFieldValue("questionType", e.target.value);
                        }}
                      >
                        {/* <option value="">Select question type</option> */}
                        <option value="multiplechoice">Multiple Choice</option>
                        <option value="sortanswer">Short answer</option>
                      </Field>
                      <ErrorMessage
                        name={`questionType`}
                        component={TextError}
                      />
                    </div>

                    {formik?.values?.questionType === "multiplechoice" && (
                      <>
                        <div className="option1 form-field">
                          <label>
                            Option 1<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[0] == ""}
                                value={formik?.values?.options[0]}
                                checked={
                                  formik.values.options[0] != ""
                                    ? formik.values.options[0] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span className="checkmark"></span>
                            </div>
                            <Field
                              name={`options[0]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[0]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[0]`}
                            component={TextError}
                          />
                        </div>

                        <div className="option1 form-field">
                          <label>
                            Option 2<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[1] == ""}
                                value={formik.values.options[1]}
                                checked={
                                  formik.values.options[1] != ""
                                    ? formik.values.options[1] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span class="checkmark"></span>
                            </div>
                            <Field
                              name={`options[1]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[1]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[1]`}
                            component={TextError}
                          />
                        </div>

                        <div className="option1 form-field">
                          <label>
                            Option 3<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[2] == ""}
                                value={formik.values.options[2]}
                                checked={
                                  formik.values.options[2] != ""
                                    ? formik.values.options[2] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span class="checkmark"></span>
                            </div>
                            <Field
                              name={`options[2]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[2]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[2]`}
                            component={TextError}
                          />
                        </div>
                        <div className="option1 form-field">
                          <label>
                            Option 4<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[3] == ""}
                                value={formik.values.options[3]}
                                checked={
                                  formik.values.options[3] != ""
                                    ? formik.values.options[3] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span class="checkmark"></span>
                            </div>
                            <Field
                              name={`options[3]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[3]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[3]`}
                            component={TextError}
                          />
                        </div>
                        {(optmsg || errors.rightAnswer) && (
                          <p className="error">
                            {<> Please Select Correct Answer </>}
                          </p>
                        )}
                      </>
                    )}

                    {formik?.values?.questionType === "sortanswer" && (
                      <>
                        <div className="form-field">
                          <label>Answer Box</label>
                          <Field
                            name={`rightAnswer`}
                            type="text"
                            onChange={(e) => {
                              const value = e.target.value;
                              const trimmedValue = value.trimStart();
                              // Update the field value
                              setFieldValue("rightAnswer", trimmedValue);
                            }}
                          />
                          <ErrorMessage
                            name={`rightAnswer`}
                            component={TextError}
                          />
                        </div>
                      </>
                    )}

                    <div className="d-flex">
                      <button
                        type="submit"
                        className={`primary-btn `}
                        // onClick={() => {
                        //   if (
                        //     formik.values.options[0] ===
                        //       formik?.values?.rightAnswer ||
                        //     formik.values.options[1] ===
                        //       formik?.values?.rightAnswer ||
                        //     formik.values.options[2] ===
                        //       formik?.values?.rightAnswer ||
                        //     formik.values.options[3] ===
                        //       formik?.values?.rightAnswer
                        //   ) {
                        //     setOptmsg(false);
                        //   } else {
                        //     setOptmsg(true);
                        //   }
                        // }}

                        // disabled={!(formik.dirty && formik.isValid)}
                      >
                        Submit
                      </button>

                      <button
                        type="button"
                        className="primary-btn"
                        onClick={() => navigate("/admin/question-list")}
                      >
                        Cancel
                      </button>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </>
  );
};

export default EditQuestion;
