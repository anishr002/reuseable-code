import React, { useEffect, useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import TextError from "../../utilities/TextError";
import { useDispatch, useSelector } from "react-redux";
import {
  addAdminQuestion,
  editQuestion,
} from "../../redux/sllices/adminQuestionSlice";
import { useLocation, useNavigate, useNavigation } from "react-router-dom";
import Loader from "../../Layout/Loader";
import { getCategorylistforDropdown } from "../../redux/sllices/adminCategorySlice";

const NewAddQuestion = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector((state) => state?.root?.adminQuestion?.loading);
  const categoryloading = useSelector(
    (state) => state?.root?.adminCategory?.loading
  );
  const Categorylist = useSelector(
    (state) => state?.root?.adminCategory?.adminCategorylistdata
  );

  //Category Dropdown list API call
  useEffect(() => {
    dispatch(getCategorylistforDropdown());
  }, []);
  const initialValueSchema = {
    questionText: "",
    options: ["", "", "", "", ""],
    rightAnswer: "",
    questionType: "",
    categoryId: "",
    sortAnswer: "",
  };

  const validationSchema = Yup.object().shape({
    questionText: Yup.string()
      .required("Question Text is required")
      .trim("space can not be allowed")
      .min(10, "Question Text must be at least 10 characters")
      .max(150, "Question Text can be maximum 150 characters"),
    rightAnswer: Yup.string().when("questionType", ([questionType], schema) => {
      return questionType == "multiplechoice"
        ? Yup.string().required("*Please Select Correct Answer")
        : Yup.string();
    }),
    sortAnswer: Yup.string().when("questionType", ([questionType], schema) => {
      return questionType == "sortanswer"
        ? Yup.string().required("*Please Write Correct Answer")
        : Yup.string();
    }),
    questionType: Yup.string().required("Question Type is required"),
    categoryId: Yup.string().required("Question Categroy is required"),
    options: Yup.array().when("questionType", {
      is: "multiplechoice",
      then: () =>
        Yup.array().of(
          Yup.string()
            .trim("space can not be allowed")
            .required("Option is required")
        ),

      // otherwise: Yup.array(),
    }),
  });

  const onSubmit = (values, onSubmitProps) => {
    // console.log(values, "values");
    const NewValues = {
      ...values,
      options:
        values.questionType === "sortanswer"
          ? ["", "", "", "", ""]
          : values.options,
    };

    const newSchema = {
      questionText: NewValues?.questionText,
      options: NewValues?.options,
      rightAnswer:
        values.questionType === "sortanswer"
          ? NewValues?.sortAnswer
          : NewValues?.rightAnswer,
      questionType: NewValues?.questionType,
      categoryId: NewValues?.categoryId,
    };

    // console.log(newSchema, "newSchema");
    dispatch(addAdminQuestion(newSchema, navigate));

    onSubmitProps.resetForm();
  };
  return (
    <>
      {loading || categoryloading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details">
          <div className="container">
            <Formik
              initialValues={initialValueSchema}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue, errors } = formik;
                return (
                  <Form>
                    <h1 className="crt_quiz">Create Question</h1>
                    <div className="form-field">
                      <label>
                        Question Text
                        <span>*</span>
                      </label>
                      <Field
                        name={`questionText`}
                        placeholder="Enter a question "
                        type="text"
                        onChange={(e) => {
                          const value = e.target.value;
                          const trimmedValue = value.trimStart();
                          // Update the field value
                          setFieldValue("questionText", trimmedValue);
                        }}
                      />
                      <ErrorMessage
                        name={`questionText`}
                        component={TextError}
                      />
                    </div>
                    <div className="form-field">
                      <label>
                        Question Categroy
                        <span>*</span>
                      </label>
                      <Field as="select" name={`categoryId`}>
                        <option value="">
                          {Categorylist?.categoryData?.length > 0
                            ? "Select question categroy"
                            : "No category found"}
                        </option>
                        {Categorylist?.categoryData?.length > 0 &&
                          Categorylist?.categoryData?.map((data, index) => {
                            return (
                              <option value={data?._id} key={index}>
                                {data?.name}
                              </option>
                            );
                          })}
                      </Field>
                      <ErrorMessage name={`categoryId`} component={TextError} />
                    </div>

                    <div className="form-field">
                      <label>
                        Question Type
                        <span>*</span>
                      </label>
                      <Field
                        as="select"
                        name={`questionType`}
                        onChange={(e) => {
                          //   setFieldValue("rightAnswer", "");
                          setFieldValue("questionType", e.target.value);
                        }}
                      >
                        <option value="">Select question type</option>
                        <option value="multiplechoice">Multiple Choice</option>
                        <option value="sortanswer">Short answer</option>
                      </Field>
                      <ErrorMessage
                        name={`questionType`}
                        component={TextError}
                      />
                    </div>

                    {formik?.values?.questionType === "multiplechoice" && (
                      <>
                        <div className="option1 form-field">
                          <label>
                            Option 1<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[0] == ""}
                                value={formik?.values?.options[0]}
                                checked={
                                  formik.values.options[0] != ""
                                    ? formik.values.options[0] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span className="checkmark"></span>
                            </div>
                            <Field
                              name={`options[0]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[0]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[0]`}
                            component={TextError}
                          />
                        </div>

                        <div className="option1 form-field">
                          <label>
                            Option 2<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[1] == ""}
                                value={formik.values.options[1]}
                                checked={
                                  formik.values.options[1] != ""
                                    ? formik.values.options[1] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span class="checkmark"></span>
                            </div>
                            <Field
                              name={`options[1]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[1]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[1]`}
                            component={TextError}
                          />
                        </div>

                        <div className="option1 form-field">
                          <label>
                            Option 3<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[2] == ""}
                                value={formik.values.options[2]}
                                checked={
                                  formik.values.options[2] != ""
                                    ? formik.values.options[2] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span class="checkmark"></span>
                            </div>
                            <Field
                              name={`options[2]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[2]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[2]`}
                            component={TextError}
                          />
                        </div>
                        <div className="option1 form-field">
                          <label>
                            Option 4<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[3] == ""}
                                value={formik.values.options[3]}
                                checked={
                                  formik.values.options[3] != ""
                                    ? formik.values.options[3] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span class="checkmark"></span>
                            </div>
                            <Field
                              name={`options[3]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[3]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[3]`}
                            component={TextError}
                          />
                        </div>
                        <div className="option1 form-field">
                          <label>
                            Option 5<span>*</span>
                          </label>
                          <div className="radio-options">
                            <div className="custom-radio">
                              <Field
                                name={`rightAnswer`}
                                type="radio"
                                disabled={formik.values.options[4] == ""}
                                value={formik?.values?.options[4]}
                                checked={
                                  formik.values.options[4] != ""
                                    ? formik.values.options[4] ===
                                      formik?.values?.rightAnswer
                                    : false
                                }
                              />
                              <span className="checkmark"></span>
                            </div>
                            <Field
                              name={`options[4]`}
                              type="text"
                              onChange={(e) => {
                                const value = e.target.value;
                                const trimmedValue = value.trimStart();
                                // Update the field value
                                setFieldValue("options[4]", trimmedValue);
                              }}
                            />
                          </div>
                          <ErrorMessage
                            name={`options[4]`}
                            component={TextError}
                          />
                        </div>
                        <ErrorMessage
                          name={`rightAnswer`}
                          component={TextError}
                        />
                      </>
                    )}

                    {formik?.values?.questionType === "sortanswer" && (
                      <>
                        <div className="form-field">
                          <label>Answer Box</label>
                          <Field
                            name={`sortAnswer`}
                            type="text"
                            onChange={(e) => {
                              const value = e.target.value;
                              const trimmedValue = value.trimStart();
                              // Update the field value
                              setFieldValue("sortAnswer", trimmedValue);
                            }}
                          />
                          <ErrorMessage
                            name={`sortAnswer`}
                            component={TextError}
                          />
                        </div>
                      </>
                    )}
                    <div className="d-flex">
                      <button
                        type="submit"
                        className={`primary-btn `}
                        // disabled={!(formik.dirty && formik.isValid)}
                      >
                        Submit
                      </button>

                      <button
                        type="button"
                        className="primary-btn"
                        onClick={() => navigate("/admin/question-list")}
                      >
                        Cancel
                      </button>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </>
  );
};

export default NewAddQuestion;
