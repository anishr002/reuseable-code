import React from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import { addAdminquiz, editQuiz } from "../../redux/sllices/adminQuizSlice";
import { useLocation, useNavigate } from "react-router";
import dayjs from "dayjs";
import TextError from "../../utilities/TextError";
import Loader from "../../Layout/Loader";

var checkvalid;

const AdminQuiz = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { state } = useLocation();

  const loading = useSelector((state) => state?.root?.adminQuiz?.loading);

  //formik edit mode schema
  const editmodeinitialValues = {
    quizName: state?.quizName,
    description: state?.description,
    expireDate: state?.expireDate,
    timeLimitInSec: state?.timeLimitInSec,
    questionsArray: state?.questionsData,
  };

  //formik initial schema
  const initialValueSchema = {
    quizName: "",
    description: "",
    expireDate: "",
    timeLimitInSec: "",
    questionsArray: [
      {
        questionText: "",
        questionType: "",
        options: [
          { option1: "" },
          { option2: "" },
          { option3: "" },
          { option4: "" },
        ],
        rightAnswer: null,
      },
    ],
  };

  const validationSchema = Yup.object().shape({
    quizName: Yup.string().required("Quizname is required"),
    description: Yup.string().required("Quizdescription is required"),
    expireDate: Yup.string().required("Date is required"),
    timeLimitInSec: Yup.string().required("Time is required"),
    questionsArray: Yup.array().of(
      Yup.object().shape({
        questionText: Yup.string().required("Question is required"),
        questionType: Yup.string().required("Selection is required"),
        // rightAnswer: Yup.string().required("Correct answer is required"),
      })
    ),
  });
  const onSubmit = (values, onSubmitProps) => {
    state
      ? dispatch(editQuiz(state?._id, values, navigate))
      : dispatch(addAdminquiz(values, navigate));

    // navigate("/admin/quiz-list");
    onSubmitProps.resetForm();
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details">
          <div className="container">
            <Formik
              initialValues={state ? editmodeinitialValues : initialValueSchema}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue } = formik;

                return (
                  <Form>
                    <h1 className="crt_quiz">
                      {state ? "Edit Quiz" : "Create Quiz"}
                    </h1>
                    <div className="form-field">
                      <label>
                        Quiz Name<span>*</span>
                      </label>
                      <Field
                        name="quizName"
                        placeholder="Enter a quiz name"
                        type="text"
                      />
                      <ErrorMessage name="quizName" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Description<span>*</span>
                      </label>
                      <Field
                        name="description"
                        placeholder="Enter a quiz description"
                        type="text"
                      />
                      <ErrorMessage name="description" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Expire Date<span>*</span>
                      </label>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          // minDate={currentDate}
                          disablePast
                          value={
                            state ? dayjs(formik?.values?.expireDate) : null
                          }
                          onChange={(newValue) =>
                            setFieldValue(
                              `expireDate`,
                              moment(newValue.$d).valueOf()
                            )
                          }
                        />
                      </LocalizationProvider>
                      <ErrorMessage name="expireDate" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Time Limit<span>*</span>
                      </label>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <TimePicker
                          value={
                            state ? dayjs(formik?.values?.timeLimitInSec) : null
                          }
                          format="HH:mm"
                          // disablePast
                          onChange={(newValue) =>
                            setFieldValue(
                              `timeLimitInSec`,
                              moment(newValue.$d).valueOf()
                            )
                          }
                        />
                      </LocalizationProvider>
                      <ErrorMessage
                        name="timeLimitInSec"
                        component={TextError}
                      />
                    </div>
                    <div className="form-field">
                      <label className="d-block border-bottom pb-2 mt-4 mb-3">
                        Questions
                      </label>

                      <FieldArray name={`questionsArray`}>
                        {({ push, remove }) => (
                          <div>
                            <div className="example_box">
                              {formik?.values?.questionsArray?.map(
                                (questionsdata, questionsindex) => {
                                  checkvalid =
                                    !values.questionsArray[questionsindex]
                                      .questionText ||
                                    values.questionsArray[questionsindex]
                                      .questionType === "" ||
                                    (values.questionsArray[questionsindex]
                                      .questionType == "multiplechoice" &&
                                      values.questionsArray[
                                        questionsindex
                                      ].options.some(
                                        (option) =>
                                          Object.values(option)[0] == ""
                                      )) ||
                                    values.questionsArray[questionsindex]
                                      .rightAnswer == null ||
                                    values.questionsArray[questionsindex]
                                      .rightAnswer == "";

                                  return (
                                    <div
                                      className="example_box_inner"
                                      key={questionsindex}
                                    >
                                      <div className="form-field">
                                        <label>
                                          Question {questionsindex + 1}
                                          <span>*</span>
                                        </label>
                                        <Field
                                          name={`questionsArray[${questionsindex}].questionText`}
                                          placeholder="Enter a question "
                                          type="text"
                                        />
                                        <ErrorMessage
                                          name={`questionsArray[${questionsindex}].questionText`}
                                          component={TextError}
                                        />
                                      </div>
                                      <div className="form-field">
                                        <label>
                                          Question type
                                          <span>*</span>
                                        </label>
                                        <Field
                                          as="select"
                                          name={`questionsArray[${questionsindex}].questionType`}
                                          // defaultValue={defdata.wordclass}
                                        >
                                          <option value="">
                                            Select question type
                                          </option>
                                          <option value="multiplechoice">
                                            Multiple Choice
                                          </option>
                                          <option value="sortanswer">
                                            Short answer
                                          </option>
                                        </Field>
                                        <ErrorMessage
                                          name={`questionsArray[${questionsindex}].questionType`}
                                          component={TextError}
                                        />
                                      </div>

                                      {/* start adding add options and answerbox */}
                                      {formik?.values?.questionsArray[
                                        questionsindex
                                      ]?.questionType === "multiplechoice" && (
                                        <div>
                                          <div className="option1 form-field">
                                            <label>
                                              Option 1<span>*</span>
                                            </label>
                                            <div className="radio-options">
                                              <div className="custom-radio">
                                                <Field
                                                  name={`questionsArray[${questionsindex}].rightAnswer`}
                                                  type="radio"
                                                  disabled={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[0].option1 == ""
                                                  }
                                                  value={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[0].option1
                                                  }
                                                  checked={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[0].option1 != ""
                                                      ? formik.values
                                                          .questionsArray[
                                                          questionsindex
                                                        ].options[0].option1 ===
                                                        formik?.values
                                                          ?.questionsArray[
                                                          questionsindex
                                                        ]?.rightAnswer
                                                      : false
                                                  }
                                                />
                                                <span class="checkmark"></span>
                                              </div>
                                              <Field
                                                name={`questionsArray[${questionsindex}].options[0].option1`}
                                                type="text"
                                              />
                                              <ErrorMessage
                                                name={`questionsArray[${questionsindex}].options[0].option1`}
                                                component={TextError}
                                              />
                                            </div>
                                          </div>
                                          <div className="option2 form-field">
                                            <label>
                                              Option 2<span>*</span>
                                            </label>
                                            <div className="radio-options">
                                              <div className="custom-radio">
                                                <Field
                                                  name={`questionsArray[${questionsindex}].rightAnswer`}
                                                  type="radio"
                                                  value={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[1].option2
                                                  }
                                                  disabled={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[1].option2 == ""
                                                  }
                                                  checked={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[1].option2 != ""
                                                      ? formik.values
                                                          .questionsArray[
                                                          questionsindex
                                                        ].options[1].option2 ===
                                                        formik?.values
                                                          ?.questionsArray[
                                                          questionsindex
                                                        ]?.rightAnswer
                                                      : false
                                                  }
                                                />

                                                <span class="checkmark"></span>
                                              </div>
                                              <Field
                                                name={`questionsArray[${questionsindex}].options[1].option2`}
                                                type="text"
                                              />
                                            </div>
                                          </div>
                                          <div className="option3 form-field">
                                            <label>
                                              Option 3<span>*</span>
                                            </label>
                                            <div className="radio-options">
                                              <div className="custom-radio">
                                                <Field
                                                  name={`questionsArray[${questionsindex}].rightAnswer`}
                                                  type="radio"
                                                  disabled={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[2].option3 == ""
                                                  }
                                                  value={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[2].option3
                                                  }
                                                  checked={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[2].option3 != ""
                                                      ? formik.values
                                                          .questionsArray[
                                                          questionsindex
                                                        ].options[2].option3 ===
                                                        formik?.values
                                                          ?.questionsArray[
                                                          questionsindex
                                                        ]?.rightAnswer
                                                      : false
                                                  }
                                                />
                                                <span class="checkmark"></span>
                                              </div>
                                              <Field
                                                name={`questionsArray[${questionsindex}].options[2].option3`}
                                                type="text"
                                              />
                                            </div>
                                          </div>
                                          <div className="option4 form-field">
                                            <label>
                                              Option 4<span>*</span>
                                            </label>
                                            <div className="radio-options">
                                              <div className="custom-radio">
                                                <Field
                                                  name={`questionsArray[${questionsindex}].rightAnswer`}
                                                  type="radio"
                                                  disabled={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[3].option4 == ""
                                                  }
                                                  value={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[3].option4
                                                  }
                                                  checked={
                                                    formik.values
                                                      .questionsArray[
                                                      questionsindex
                                                    ].options[3].option4 != ""
                                                      ? formik.values
                                                          .questionsArray[
                                                          questionsindex
                                                        ].options[3].option4 ===
                                                        formik?.values
                                                          ?.questionsArray[
                                                          questionsindex
                                                        ]?.rightAnswer
                                                      : false
                                                  }
                                                />
                                                <span class="checkmark"></span>
                                              </div>
                                              <Field
                                                name={`questionsArray[${questionsindex}].options[3].option4`}
                                                type="text"
                                              />
                                            </div>
                                          </div>
                                        </div>
                                      )}

                                      {formik?.values?.questionsArray[
                                        questionsindex
                                      ]?.questionType === "sortanswer" && (
                                        <div className="form-field">
                                          <label>Answer Box</label>
                                          <Field
                                            name={`questionsArray[${questionsindex}].rightAnswer`}
                                            type="text"
                                          />
                                          <ErrorMessage
                                            name={`questionsArray[${questionsindex}].rightAnswer`}
                                            component={TextError}
                                          />
                                        </div>
                                      )}

                                      {questionsindex + 1 ===
                                        values?.questionsArray?.length && (
                                        <button
                                          className={`add_btn ${
                                            checkvalid && "opacity-75"
                                          }`}
                                          type="button"
                                          disabled={checkvalid}
                                          onClick={() =>
                                            push({
                                              questionText: "",
                                              expireDate: "",
                                              timeLimitInSec: "",
                                              questionType: "",
                                              options: [
                                                { option1: "" },
                                                { option2: "" },
                                                { option3: "" },
                                                { option4: "" },
                                              ],
                                              rightAnswer: null,
                                            })
                                          }
                                        >
                                          Add Question
                                        </button>
                                      )}
                                      {values?.questionsArray?.length > 1 && (
                                        <button
                                          className="remv_btn"
                                          type="button"
                                          disabled={
                                            values?.questionsArray?.length <= 1
                                          }
                                          onClick={() => remove(questionsindex)}
                                        >
                                          Remove Question
                                        </button>
                                      )}
                                    </div>
                                  );
                                }
                              )}
                            </div>
                          </div>
                        )}
                      </FieldArray>
                    </div>

                    <div className="d-flex">
                      <button
                        type="submit"
                        className={`primary-btn ${checkvalid && "opacity-75"}`}
                        disabled={checkvalid}
                      >
                        Submit
                      </button>

                      {state && (
                        <button
                          type="button"
                          className="primary-btn"
                          onClick={() => navigate("/admin/quiz-list")}
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </>
  );
};

export default AdminQuiz;
