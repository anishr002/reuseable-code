import React, { useEffect, useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import TextError from "../../utilities/TextError";
import { useSelector } from "react-redux";
import moment from "moment";
import Loader from "../../Layout/Loader";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addAdminquiz } from "../../redux/sllices/adminQuizSlice";
import { useDebouncedValue } from "../../hooks/usedebounce";
import {
  getAdminQuestionlist,
  getAdminQuestionlistArray,
  resetArrayOnrefresh,
} from "../../redux/sllices/adminQuestionSlice";

//yup validation schema
const validationSchema = Yup.object().shape({
  quizName: Yup.string()
    .required("Quiz Name is required")
    .trim("space can not be allowed"),
  description: Yup.string()
    .required("Quiz Description is required")
    .trim("space can not be allowed"),
  expireDate: Yup.string().required("Date is required"),
});

//formik initial schema
const initialValueSchema = {
  quizName: "",
  description: "",
  expireDate: "",
};

//Drag and drop Handler logic
const onDragEnd = (result, columns, setColumns) => {
  if (!result.destination) return;
  const { source, destination } = result;

  if (source.droppableId !== destination.droppableId) {
    const sourceColumn = columns[source.droppableId];
    const destColumn = columns[destination.droppableId];
    const sourceItems = [...sourceColumn.items];
    const destItems = [...destColumn.items];
    const [removed] = sourceItems.splice(source.index, 1);
    destItems.splice(destination.index, 0, removed);
    setColumns({
      ...columns,
      [source.droppableId]: {
        ...sourceColumn,
        items: sourceItems,
      },
      [destination.droppableId]: {
        ...destColumn,
        items: destItems,
      },
    });
  } else {
    const column = columns[source.droppableId];
    const copiedItems = [...column.items];
    const [removed] = copiedItems.splice(source.index, 1);
    copiedItems.splice(destination.index, 0, removed);
    setColumns({
      ...columns,
      [source.droppableId]: {
        ...column,
        items: copiedItems,
      },
    });
  }
};

function NewAdminQuiz() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector((state) => state?.root?.adminQuiz?.loading);
  const Questionpageloader = useSelector(
    (state) => state?.root?.adminQuestion?.loading
  );
  const Questionslist = useSelector(
    (state) => state?.root?.adminQuestion?.adminQuestionlistarray
  );

  const [columns, setColumns] = useState({
    quizquestion: {
      name: "Quiz Question",
      items: [],
    },
    questionlist: {
      name: "Questions",
      items: Questionslist,
    },
  });
  const [searchValue, setSearchValue] = useState("");
  const [pageNumber, setpageNumber] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [QuizQuestionlength, setQuizQuestionlength] = useState(0);

  const debouncedValue = useDebouncedValue(searchValue, 800);

  useEffect(() => {
    setQuizQuestionlength(0);
    dispatch(resetArrayOnrefresh());
  }, []);

  //useEffect list API call
  useEffect(() => {
    const pages = searchValue !== "" ? 1 : pageNumber;
    dispatch(getAdminQuestionlistArray(searchValue, pages, rowsPerPage));
  }, [debouncedValue, pageNumber, rowsPerPage]);

  useEffect(() => {
    setColumns((prevColumns) => ({
      ...prevColumns,
      questionlist: {
        ...prevColumns.questionlist,
        items: Questionslist,
      },
    }));
  }, [Questionslist]);

  //formik onsubmit Handler
  const onSubmit = (values, onSubmitProps) => {
    values.questionIds = columns.quizquestion?.items?.map(
      (itemid) => itemid?._id
    );
    dispatch(addAdminquiz(values, navigate));
    onSubmitProps.resetForm();
  };

  const handleScroll = (event) => {
    const container = event.target;
    // Check if user has scrolled to the bottom of the list
    if (
      container.scrollTop + container.clientHeight >= container.scrollHeight &&
      Questionslist.length != QuizQuestionlength
    ) {
      setpageNumber((pre) => pre + 1);
      setQuizQuestionlength(Questionslist.length);
      // fetchNextPage();
    }
  };

  return (
    <div>
      {loading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details new_design">
          <div className="container">
            <Formik
              initialValues={initialValueSchema}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue } = formik;

                return (
                  <Form>
                    <h1 className="crt_quiz">Quiz Management</h1>
                    <div className="form-field">
                      <label>
                        Quiz Name<span>*</span>
                      </label>
                      <Field
                        name={`quizName`}
                        placeholder="Enter a quiz name"
                        type="text"
                        onChange={(e) => {
                          const value = e.target.value;
                          const trimmedValue = value.trimStart();
                          // Update the field value
                          setFieldValue("quizName", trimmedValue);
                        }}
                      />
                      <ErrorMessage name="quizName" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Description<span>*</span>
                      </label>
                      <Field
                        name={`description`}
                        placeholder="Enter a quiz description"
                        type="text"
                        onChange={(e) => {
                          const value = e.target.value;
                          const trimmedValue = value.trimStart();
                          // Update the field value
                          setFieldValue("description", trimmedValue);
                        }}
                      />
                      <ErrorMessage name="description" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Expire Date<span>*</span>
                      </label>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          disablePast
                          value={null}
                          onChange={(newValue) =>
                            setFieldValue(
                              `expireDate`,
                              moment(newValue.$d).valueOf()
                            )
                          }
                        />
                      </LocalizationProvider>
                      <ErrorMessage name="expireDate" component={TextError} />
                    </div>

                    <div style={{ float: "right", width: "40%" }}>
                      <input
                        type="search"
                        id="searchInput"
                        placeholder="Search"
                        value={searchValue}
                        onChange={(e) => {
                          setSearchValue(e.target.value);
                          setTimeout(() => {
                            setpageNumber(1);
                          }, 800);
                        }}
                      />
                    </div>
                    <div className="draggbale_section">
                      <DragDropContext
                        onDragEnd={(result) =>
                          onDragEnd(result, columns, setColumns)
                        }
                      >
                        <div
                          style={{
                            display: "flex",
                            // flexDirection: "column",
                            alignItems: "center",
                          }}
                        >
                          <div>
                            <h2>quizquestion</h2>
                            <div style={{ margin: 8 }}>
                              <Droppable droppableId="quizquestion">
                                {(provided, snapshot) => {
                                  return (
                                    <div
                                      {...provided.droppableProps}
                                      ref={provided.innerRef}
                                      style={{
                                        background: snapshot.isDraggingOver
                                          ? "lightblue"
                                          : "lightgrey",
                                        padding: 4,
                                        width: 250,
                                        minHeight: 500,
                                      }}
                                    >
                                      {columns?.quizquestion?.items.map(
                                        (item, index) => {
                                          return (
                                            <Draggable
                                              key={item._id}
                                              draggableId={item._id}
                                              index={index}
                                            >
                                              {(provided, snapshot) => {
                                                return (
                                                  <div
                                                    ref={provided.innerRef}
                                                    {...provided.draggableProps}
                                                    {...provided.dragHandleProps}
                                                    style={{
                                                      userSelect: "none",
                                                      padding: 16,
                                                      margin: "0 0 8px 0",
                                                      minHeight: "50px",
                                                      backgroundColor:
                                                        snapshot.isDragging
                                                          ? "#263B4A"
                                                          : "#456C86",
                                                      color: "white",
                                                      ...provided.draggableProps
                                                        .style,
                                                    }}
                                                  >
                                                    {item.questionText}
                                                  </div>
                                                );
                                              }}
                                            </Draggable>
                                          );
                                        }
                                      )}
                                      {provided.placeholder}
                                    </div>
                                  );
                                }}
                              </Droppable>
                            </div>
                          </div>
                          <div>
                            <h2>questionlist</h2>
                            <div style={{ margin: 8 }}>
                              <Droppable droppableId="questionlist" id="test">
                                {(provided, snapshot) => {
                                  return (
                                    <div
                                      onScroll={handleScroll}
                                      {...provided.droppableProps}
                                      ref={provided.innerRef}
                                      style={{
                                        background: snapshot.isDraggingOver
                                          ? "lightblue"
                                          : "lightgrey",
                                        padding: 4,
                                        width: 250,
                                        height: "500px",
                                        overflowY: "scroll",
                                        // maxHeight: 500,
                                      }}
                                    >
                                      {columns?.questionlist?.items.map(
                                        (item, index) => {
                                          return (
                                            <Draggable
                                              key={item._id}
                                              draggableId={item._id}
                                              index={index}
                                            >
                                              {(provided, snapshot) => {
                                                return (
                                                  <div
                                                    ref={provided.innerRef}
                                                    {...provided.draggableProps}
                                                    {...provided.dragHandleProps}
                                                    style={{
                                                      userSelect: "none",
                                                      padding: 16,
                                                      margin: "0 0 8px 0",
                                                      minHeight: "50px",
                                                      backgroundColor:
                                                        snapshot.isDragging
                                                          ? "#263B4A"
                                                          : "#456C86",
                                                      color: "white",
                                                      ...provided.draggableProps
                                                        .style,
                                                    }}
                                                  >
                                                    {item.questionText}
                                                  </div>
                                                );
                                              }}
                                            </Draggable>
                                          );
                                        }
                                      )}
                                      {provided.placeholder}
                                    </div>
                                  );
                                }}
                              </Droppable>
                            </div>
                          </div>
                        </div>

                        <div
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            height: "100%",
                          }}
                        >
                          <DragDropContext
                            onDragEnd={(result) =>
                              onDragEnd(result, columns, setColumns)
                            }
                          >
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                              }}
                            >
                              <div>
                                <h2>questionlist</h2>
                                <div>
                                  <input
                                    type="search"
                                    placeholder="Search"
                                    value={searchValue}
                                    onChange={(e) => {
                                      setSearchValue(e.target.value);
                                      setTimeout(() => {
                                        setpageNumber(1);
                                      }, 800);
                                    }}
                                  />
                                </div>
                                <div style={{ margin: 8 }}>
                                  {Questionpageloader && <p>Loading...</p>}

                                  {columns.questionlist.items.length > 0 &&
                                  !Questionpageloader ? (
                                    <Droppable
                                      droppableId="questionlist"
                                      id="test"
                                    >
                                      {(provided, snapshot) => {
                                        return (
                                          <div
                                            onScroll={handleScroll}
                                            {...provided.droppableProps}
                                            ref={provided.innerRef}
                                            style={{
                                              background:
                                                snapshot.isDraggingOver
                                                  ? "lightblue"
                                                  : "lightgrey",
                                              padding: 4,
                                              width: 250,
                                              height: "500px",
                                              overflowY: "scroll",
                                            }}
                                          >
                                            {columns.questionlist.items.map(
                                              (item, index) => {
                                                return (
                                                  <Draggable
                                                    key={index}
                                                    draggableId={item?._id}
                                                    index={index}
                                                  >
                                                    {(provided, snapshot) => {
                                                      return (
                                                        <div
                                                          ref={
                                                            provided.innerRef
                                                          }
                                                          {...provided.draggableProps}
                                                          {...provided.dragHandleProps}
                                                          style={{
                                                            userSelect: "none",
                                                            padding: 16,
                                                            margin: "0 0 8px 0",
                                                            minHeight: "50px",
                                                            backgroundColor:
                                                              snapshot.isDragging
                                                                ? "#263B4A"
                                                                : "#456C86",
                                                            color: "white",
                                                            ...provided
                                                              .draggableProps
                                                              .style,
                                                          }}
                                                        >
                                                          {item.questionText}
                                                          react
                                                        </div>
                                                      );
                                                    }}
                                                  </Draggable>
                                                );
                                              }
                                            )}
                                            {provided.placeholder}
                                          </div>
                                        );
                                      }}
                                    </Droppable>
                                  ) : (
                                    !Questionpageloader && (
                                      <p>No Question found</p>
                                    )
                                  )}
                                </div>
                              </div>
                              <div>
                                <h2>quizquestion</h2>
                                <div style={{ margin: 8 }}>
                                  <Droppable droppableId="quizquestion">
                                    {(provided, snapshot) => {
                                      return (
                                        <div
                                          {...provided.droppableProps}
                                          ref={provided.innerRef}
                                          style={{
                                            background: snapshot.isDraggingOver
                                              ? "lightblue"
                                              : "lightgrey",
                                            padding: 4,
                                            width: 250,
                                            minHeight: 500,
                                          }}
                                        >
                                          {columns?.quizquestion?.items.map(
                                            (item, index) => {
                                              return (
                                                <Draggable
                                                  key={item._id}
                                                  draggableId={item._id}
                                                  index={index}
                                                >
                                                  {(provided, snapshot) => {
                                                    return (
                                                      <div
                                                        ref={provided.innerRef}
                                                        {...provided.draggableProps}
                                                        {...provided.dragHandleProps}
                                                        style={{
                                                          userSelect: "none",
                                                          padding: 16,
                                                          margin: "0 0 8px 0",
                                                          minHeight: "50px",
                                                          backgroundColor:
                                                            snapshot.isDragging
                                                              ? "#263B4A"
                                                              : "#456C86",
                                                          color: "white",
                                                          ...provided
                                                            .draggableProps
                                                            .style,
                                                        }}
                                                      >
                                                        {item.questionText}
                                                      </div>
                                                    );
                                                  }}
                                                </Draggable>
                                              );
                                            }
                                          )}
                                          {provided.placeholder}
                                        </div>
                                      );
                                    }}
                                  </Droppable>
                                </div>
                              </div>
                            </div>
                          </DragDropContext>
                        </div>

                        {/* {Object.entries(columns)?.map(
                          ([columnId, column], index) => {
                            return (
                              <div className="quiz_box" key={columnId}>
                                <h1 className="crt_quiz">{column.name}</h1>
                                <div className="innerbox">
                                  {console.log(columns)}

                                  {index == 1 &&
                                  columns?.questionlist.items.length <= 0 ? (
                                    <h3>Loading...</h3>
                                  ) : (
                                    <Droppable
                                      droppableId={columnId}
                                      key={columnId}
                                    >
                                      {(provided, snapshot) => {
                                        return (
                                          <div
                                            className="drop_boxhght"
                                            {...provided.droppableProps}
                                            ref={provided.innerRef}
                                            style={{
                                              padding: 4,
                                              width: "100%",
                                            }}
                                          >
                                            {console.log(column)}
                                            {column?.items?.map(
                                              (item, index) => {
                                                return (
                                                  <Draggable
                                                    key={item._id}
                                                    draggableId={item._id}
                                                    index={index}
                                                  >
                                                    {(provided, snapshot) => {
                                                      return (
                                                        <div
                                                          className="qust_list"
                                                          ref={
                                                            provided.innerRef
                                                          }
                                                          {...provided.draggableProps}
                                                          {...provided.dragHandleProps}
                                                          style={{
                                                            userSelect: "none",
                                                            backgroundColor:
                                                              snapshot.isDragging
                                                                ? "#f7f9fa"
                                                                : "#f7f9fa",
                                                            ...provided
                                                              .draggableProps
                                                              .style,
                                                          }}
                                                        >
                                                          <p>
                                                            {item?.questionText}
                                                          </p>
                                                        </div>
                                                      );
                                                    }}
                                                  </Draggable>
                                                );
                                              }
                                            )}
                                            {provided.placeholder}
                                          </div>
                                        );
                                      }}
                                    </Droppable>
                                  )}
                                </div>
                              </div>
                            );
                          }
                        )} */}
                      </DragDropContext>
                    </div>

                    <div className="d-flex">
                      <button type="submit" className={`primary-btn `}>
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={() => navigate("/admin/quiz-list")}
                        className={`primary-btn `}
                      >
                        Cancel
                      </button>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
      <div className="clearfix"></div>
    </div>
  );
}

export default NewAdminQuiz;
