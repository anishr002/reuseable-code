// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { useNavigate } from "react-router";
// import {
//   deleteQuiz,
//   getAdminQuizlist,
// } from "../../redux/sllices/adminQuizSlice";
// import moment from "moment";
// import Loader from "../../Layout/Loader";
// import DataTable from "react-data-table-component";
// import DeleteIcon from "@mui/icons-material/Delete";
// import EditIcon from "@mui/icons-material/Edit";
// import { IconButton, Pagination, Tooltip } from "@mui/material";
// import Swal from "sweetalert2";
// import { useDebouncedValue } from "../../hooks/usedebounce";
// import { capitalCase } from "change-case";

// const AdminQuizlist = () => {
//   const [searchValue, setSearchValue] = useState("");
//   const [pageNumber, setpageNumber] = useState(1);

//   //store value Selection
//   const loading = useSelector((state) => state?.root?.adminQuiz?.loading);
//   const Quizlist = useSelector(
//     (state) => state?.root?.adminQuiz?.adminQuizlistdata
//   );
//   const debouncedValue = useDebouncedValue(searchValue, 800);

//   const navigate = useNavigate();
//   const dispatch = useDispatch();

//   //useEffect list API call
//   useEffect(() => {
//     dispatch(getAdminQuizlist(searchValue, pageNumber));
//   }, [debouncedValue, pageNumber]);

//   //Quiz delete model
//   const showAlert = (id) => {
//     Swal.fire({
//       title: "Are you sure?",
//       text: "You won't be able to revert this Quiz",
//       showCancelButton: true,
//       confirmButtonText: "Yes, delete it!",
//       confirmButtonColor: "red",
//     }).then((result) => {
//       if (result.isConfirmed) {
//         dispatch(deleteQuiz(id));
//         if (Quizlist?.quizData?.length == 1) {
//           setpageNumber((pre) => pre - 1);
//         }

//         // setPage(1);
//         // console.log("confirm");
//       }
//     });
//   };

//   //React Data Table Column formate
//   const columns = [
//     {
//       name: "Quiz Name",
//       selector: (row) => row.quizName,
//     },
//     {
//       name: "Quiz Description",
//       selector: (row) => row.description,
//     },
//     {
//       name: "Expire Date",
//       selector: (row) => moment(row.expireDate).format("MM/DD/YYYY"),
//     },
//     {
//       name: "Quiz Time Limit",
//       selector: (row) => moment(row.timeLimitInSec).format("hh:mm:ss A"),
//     },
//     {
//       name: "Active Quiz Status",
//       selector: (row) => (
//         <h6>
//           <span
//             className={row.isActive ? `badge bg-success` : `badge bg-danger`}
//           >
//             {capitalCase(row?.isActive?.toString())}
//           </span>
//         </h6>
//       ),
//       // center: true,
//     },
//     {
//       name: "Action",
//       selector: (row) => {
//         return (
//           <>
//             <Tooltip title="Edit">
//               <IconButton>
//                 <EditIcon
//                   onClick={() => {
//                     navigate("/admin/quiz", {
//                       state: row,
//                     });
//                   }}
//                 />
//               </IconButton>
//             </Tooltip>
//             <Tooltip title="Delete">
//               <IconButton>
//                 <DeleteIcon
//                   onClick={() => {
//                     showAlert(row?._id);
//                   }}
//                 />
//               </IconButton>
//             </Tooltip>
//           </>
//         );
//       },
//     },
//   ];

//   // pagination page
//   const handleChangePage = (event, page) => {
//     setpageNumber(page);
//   };

//   const CustomPagination = () => {
//     return (
//       <Pagination
//         count={Quizlist?.totalPages}
//         variant="outlined"
//         page={pageNumber}
//         color="primary"
//         onChange={handleChangePage}
//         style={{ display: "flex", justifyContent: "flex-end" }}
//       />
//     );
//   };

//   return (
//     <>
//       {loading && <Loader />}

//       {Quizlist?.quizData?.length > 0 && !loading ? (
//         <div>
//           <h1>Admin Quiz List</h1>
//           <div>
//             <input
//               type="text"
//               placeholder="Search Quiz"
//               value={searchValue}
//               onChange={(e) => setSearchValue(e?.target?.value)}
//             />
//           </div>
//           <DataTable
//             columns={columns}
//             data={Quizlist?.quizData}
//             pagination
//             paginationServer={true}
//             highlightOnHover
//             paginationComponent={CustomPagination}
//           />
//         </div>
//       ) : (
//         <h3>No Quiz Found</h3>
//       )}
//     </>
//   );
// };

// export default AdminQuizlist;
