import React, { useEffect, useState } from "react";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import TextError from "../../utilities/TextError";
import { useSelector } from "react-redux";
import moment from "moment";
import Loader from "../../Layout/Loader";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addAdminquiz } from "../../redux/sllices/adminQuizSlice";
import { useDebouncedValue } from "../../hooks/usedebounce";
import caticon from "../../assets/images/category_icon.svg";
import {
  getAdminQuestionlist,
  getAdminQuestionlistArray,
  resetArrayOnrefresh,
} from "../../redux/sllices/adminQuestionSlice";
import { handleKeyDown } from "../../utilities/handleKeyDown";
import ClearIcon from "@mui/icons-material/Clear";
import { getCategorylistforDropdown } from "../../redux/sllices/adminCategorySlice";

//yup validation schema
const validationSchema = Yup.object().shape({
  quizName: Yup.string()
    .required("Quiz Name is required")
    .trim("space can not be allowed")
    .min(3, "Quiz Name must be at least 3 characters")
    .max(50, "Quiz Name can be maximum 50 characters"),
  description: Yup.string()
    .required("Quiz Description is required")
    .trim("space can not be allowed"),
  expireDate: Yup.number()
    .required("Date is required")
    .test(
      "future-date",
      "Please select a future date",
      (date) => console.log(date) || moment(date).isSameOrAfter(moment(), "day")
    ),
});

//formik initial schema
const initialValueSchema = {
  quizName: "",
  description: "",
  expireDate: "",
};

function NewAdminQuiz() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector((state) => state?.root?.adminQuiz?.loading);
  const categoryloading = useSelector(
    (state) => state?.root?.adminCategory?.loading
  );
  const Questionslist = useSelector(
    (state) => state?.root?.adminQuestion?.adminQuestionlistarray
  );
  const Categorylist = useSelector(
    (state) => state?.root?.adminCategory?.adminCategorylistdata
  );
  // console.log(Categorylist?.categoryData, "Categorylist", Categorylist);

  const [columns, setColumns] = useState({
    quizquestion: {
      name: "Quiz Question",
      items: [],
    },
    questionlist: {
      name: "Questions",
      items: [],
    },
  });

  const [searchValue, setSearchValue] = useState("");
  const [selectedOption, setSelectedOption] = useState("");
  const [pageNumber, setpageNumber] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [questionEmpltyflag, setquestionEmptyflag] = useState(false);

  const debouncedValue = useDebouncedValue(searchValue, 800);

  //Category Dropdown list API call
  useEffect(() => {
    dispatch(getCategorylistforDropdown());
  }, []);

  //useEffect list API call
  useEffect(() => {
    const QuizQuestionIdarray = columns?.quizquestion?.items?.map(
      (item) => item?._id
    );
    // console.log(QuizQuestionIdarray, "QuizQuestionIdarray");

    const pages = searchValue !== "" ? 1 : pageNumber;
    dispatch(
      getAdminQuestionlistArray(
        searchValue,
        selectedOption,
        pages,
        rowsPerPage,
        QuizQuestionIdarray
      )
    );
  }, [debouncedValue, pageNumber, rowsPerPage, selectedOption]);

  useEffect(() => {
    // const filteredArray = Questionslist.filter(
    //   (item1) =>
    //     !columns?.quizquestion?.items.some((item2) => item2._id === item1._id)
    // );
    // console.log(filteredArray, "filteredArray", Questionslist);

    setColumns((prevColumns) => ({
      ...prevColumns,
      questionlist: {
        ...prevColumns.questionlist,
        items: Questionslist,
      },
    }));
  }, [Questionslist]);

  //Drag and drop Handler logic
  const onDragEnd = (result, columns, setColumns) => {
    if (!result.destination) return;
    const { source, destination } = result;

    if (source.droppableId !== destination.droppableId) {
      const sourceColumn = columns[source.droppableId];
      const destColumn = columns[destination.droppableId];
      const sourceItems = [...sourceColumn.items];
      const destItems = [...destColumn.items];
      const [removed] = sourceItems.splice(source.index, 1);
      destItems.splice(destination.index, 0, removed);

      // if (columns?.questionlist?.items?.length <= 0) {
      //   setSearchValue("");
      //   setSelectedOption("");
      // }
      if (source?.droppableId == "quizquestion") {
        setSearchValue("");
        setSelectedOption("");
      }

      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          items: sourceItems,
        },
        [destination.droppableId]: {
          ...destColumn,
          items: destItems,
        },
      });
    } else {
      const column = columns[source.droppableId];
      const copiedItems = [...column.items];
      const [removed] = copiedItems.splice(source.index, 1);
      copiedItems.splice(destination.index, 0, removed);

      setColumns({
        ...columns,
        [source.droppableId]: {
          ...column,
          items: copiedItems,
        },
      });
    }
  };

  //formik onsubmit Handler
  const onSubmit = (values, onSubmitProps) => {
    if (columns.quizquestion.items.length <= 0) {
      return;
    } else {
      values.questionIds = columns.quizquestion?.items?.map(
        (itemid) => itemid?._id
      );
      dispatch(addAdminquiz(values, navigate));
      setColumns({
        quizquestion: {
          name: "Quiz Question",
          items: [],
        },
        questionlist: {
          name: "Questions",
          items: Questionslist,
        },
      });

      onSubmitProps.resetForm();
    }
  };

  const handleClearSearch = () => {
    setSearchValue("");
  };
  return (
    <div>
      {loading || categoryloading ? (
        <Loader />
      ) : (
        <div className="quiz-form-details new_design">
          <div className="container">
            <Formik
              initialValues={initialValueSchema}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => {
                const { values, setFieldValue, errors, touched } = formik;

                return (
                  <Form>
                    <h1 className="crt_quiz">Add Quiz</h1>

                    <div className="form-field">
                      <label>
                        Quiz Name<span>*</span>
                      </label>
                      <Field
                        name={`quizName`}
                        placeholder="Enter a quiz name"
                        type="text"
                        onChange={(e) => {
                          const value = e.target.value;
                          const trimmedValue = value.trimStart();
                          // Update the field value
                          setFieldValue("quizName", trimmedValue);
                        }}
                      />
                      <ErrorMessage name="quizName" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Description<span>*</span>
                      </label>
                      <Field
                        name={`description`}
                        placeholder="Enter a quiz description"
                        type="text"
                        onChange={(e) => {
                          const value = e.target.value;
                          const trimmedValue = value.trimStart();
                          // Update the field value
                          setFieldValue("description", trimmedValue);
                        }}
                      />
                      <ErrorMessage name="description" component={TextError} />
                    </div>
                    <div className="form-field">
                      <label>
                        Quiz Expire Date<span>*</span>
                      </label>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          disablePast
                          value={null}
                          onChange={(newValue) =>
                            setFieldValue(
                              `expireDate`,
                              moment(newValue?.$d).valueOf()
                            )
                          }
                        />
                      </LocalizationProvider>
                      {errors.expireDate &&
                      errors.expireDate ===
                        "expireDate must be a `number` type, but the final value was: `NaN` (cast from the value `NaN`)." ? (
                        <p className="error"></p>
                      ) : errors.expireDate &&
                        (touched.expireDate || values.expireDate) ? (
                        <p className="error">{errors.expireDate}</p>
                      ) : (
                        ""
                      )}
                      {/* <ErrorMessage name="expireDate" component={TextError} /> */}
                    </div>

                    <div className="draggbale_section">
                      <div className="category-sidebox">
                        <div className="que-list-search-block ">
                          <input
                            type="text"
                            id="searchInput"
                            placeholder="Search"
                            value={searchValue}
                            onKeyDown={handleKeyDown}
                            onChange={(e) => {
                              setSearchValue(e.target.value);
                              setTimeout(() => {
                                setpageNumber(1);
                              }, 800);
                            }}
                          />
                          {searchValue && (
                            <ClearIcon
                              onClick={handleClearSearch}
                              fontSize="small"
                              style={{ cursor: "pointer" }}
                            />
                          )}
                        </div>
                        <div className="que-list-search-block">
                          <img src={caticon} alt="" />
                          <select
                            value={selectedOption}
                            onChange={(event) => {
                              setSelectedOption(event.target.value);
                            }}
                          >
                            <option value="">
                              {Categorylist?.categoryData?.length > 0
                                ? "Category"
                                : "No category found"}
                            </option>
                            {Categorylist?.categoryData?.length > 0 &&
                              Categorylist?.categoryData?.map((data, index) => {
                                return (
                                  <option value={data?._id} key={index}>
                                    {data?.name}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                      </div>

                      <DragDropContext
                        onDragEnd={(result) => {
                          onDragEnd(result, columns, setColumns);
                        }}
                      >
                        {Object.entries(columns)?.map(
                          ([columnId, column], index) => {
                            return (
                              <div className="quiz_box" key={columnId}>
                                <h1 className="crt_quiz">{column.name}</h1>
                                <div className="innerbox">
                                  <Droppable
                                    droppableId={columnId}
                                    key={columnId}
                                  >
                                    {(provided, snapshot) => {
                                      return (
                                        <div
                                          className="drop_boxhght"
                                          {...provided.droppableProps}
                                          ref={provided.innerRef}
                                          style={{
                                            padding: 4,
                                            width: "100%",
                                          }}
                                        >
                                          {index == 1 &&
                                            columns?.questionlist.items
                                              .length <= 0 && (
                                              <div className="no-data-found">
                                                <h3>No data Found</h3>
                                              </div>
                                            )}

                                          {column?.items?.map((item, index) => {
                                            return (
                                              <Draggable
                                                key={item._id}
                                                draggableId={item._id}
                                                index={index}
                                              >
                                                {(provided, snapshot) => {
                                                  return (
                                                    <div
                                                      className="qust_list"
                                                      ref={provided.innerRef}
                                                      {...provided.draggableProps}
                                                      {...provided.dragHandleProps}
                                                      style={{
                                                        userSelect: "none",
                                                        backgroundColor:
                                                          snapshot.isDragging
                                                            ? "#f7f9fa"
                                                            : "#f7f9fa",
                                                        ...provided
                                                          .draggableProps.style,
                                                      }}
                                                    >
                                                      <p>
                                                        {item?.questionText}
                                                      </p>
                                                      <h6>
                                                        {
                                                          item?.categoryData
                                                            ?.name
                                                        }
                                                      </h6>
                                                    </div>
                                                  );
                                                }}
                                              </Draggable>
                                            );
                                          })}
                                          {provided.placeholder}
                                        </div>
                                      );
                                    }}
                                  </Droppable>
                                </div>
                              </div>
                            );
                          }
                        )}
                      </DragDropContext>
                    </div>
                    {questionEmpltyflag &&
                      columns.quizquestion.items.length <= 0 && (
                        <div className="error">Quiz Questions is required</div>
                      )}
                    <div className="clearfix"></div>
                    <div className="save-cancel-btns">
                      <button
                        type="submit"
                        onClick={() => {
                          if (columns.quizquestion.items.length <= 0) {
                            setquestionEmptyflag(true);
                          }
                        }}
                        className={`primary-btn `}
                      >
                        Submit
                      </button>
                      <button
                        type="button"
                        onClick={() => navigate("/admin/quiz-list")}
                        className={`primary-btn `}
                      >
                        Cancel
                      </button>
                    </div>
                    <div className="clearfix"></div>
                  </Form>
                );
              }}
            </Formik>
            <div className="clearfix"></div>
          </div>
        </div>
      )}
      <div className="clearfix"></div>
    </div>
  );
}

export default NewAdminQuiz;
