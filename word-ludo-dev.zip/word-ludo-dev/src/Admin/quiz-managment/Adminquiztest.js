// import React from "react";
// import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
// import * as Yup from "yup";
// import { DatePicker } from "@mui/x-date-pickers/DatePicker";
// import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
// import { TimePicker } from "@mui/x-date-pickers/TimePicker";
// import moment from "moment";
// import { useDispatch } from "react-redux";
// import { addAdminquiz, editQuiz } from "../../redux/sllices/adminQuizSlice";
// import { useLocation, useNavigate } from "react-router";
// import dayjs from "dayjs";
// import TextError from "../../utilities/TextError";

// const AdminQuiz = () => {
//   const dispatch = useDispatch();
//   const navigate = useNavigate();
//   const { state } = useLocation();
//   console.log(state, "state");

//   //formik edit mode schema
//   const editmodeinitialValues = {
//     quizName: state?.quizName,
//     description: state?.description,
//     expireDate: state?.expireDate,
//     timeLimitInSec: state?.timeLimitInSec,
//     questionsArray: state?.questionsData,
//   };

//   //formik initial schema
//   const initialValueSchema = {
//     quizName: "",
//     description: "",
//     expireDate: "",
//     timeLimitInSec: "",
//     questionsArray: [
//       {
//         questionText: "",
//         questionType: "",
//         options: [
//           { option1: "" },
//           { option2: "" },
//           { option3: "" },
//           { option4: "" },
//         ],
//         rightAnswer: null,
//       },
//     ],
//   };

//   const validationSchema = Yup.object().shape({
//     quizName: Yup.string().required("Quizname is required"),
//     description: Yup.string().required("Quizdescription is required"),
//     expireDate: Yup.string().required("Date is required"),
//     timeLimitInSec: Yup.string().required("Time is required"),
//     questionsArray: Yup.array().of(
//       Yup.object().shape({
//         questionText: Yup.string().required("Question is required"),
//         questionType: Yup.string().required("Selection is required"),
//         rightAnswer: Yup.string().required("Correct answer is required"),
//       })
//     ),
//   });
//   const onSubmit = (values, onSubmitProps) => {
//     console.log("Form data", values);
//     state
//       ? dispatch(editQuiz(state?._id, values))
//       : dispatch(addAdminquiz(values));
//     navigate("/admin/quiz-list");
//     onSubmitProps.resetForm();
//   };

//   return (
//     <Formik
//       initialValues={state ? editmodeinitialValues : initialValueSchema}
//       validationSchema={validationSchema}
//       onSubmit={onSubmit}
//     >
//       {(formik) => {
//         const { values, setFieldValue } = formik;
//         return (
//           <Form>
//             <h1>{state ? "Edit Quiz" : "Create Quiz"}</h1>

//             <div>
//               <label>Quiz Name</label>
//               <Field name="quizName" type="text" />
//               <ErrorMessage name="quizName" />
//             </div>
//             <div>
//               <label>Quiz Description</label>
//               <Field name="description" type="text" />
//               <ErrorMessage name="description" />
//             </div>
//             <div>
//               <label>Quiz Expire Date</label>
//               <LocalizationProvider dateAdapter={AdapterDayjs}>
//                 <DatePicker
//                   // minDate={currentDate}
//                   disablePast
//                   value={dayjs(formik?.values?.expireDate)}
//                   onChange={(newValue) =>
//                     setFieldValue(`expireDate`, moment(newValue.$d).valueOf())
//                   }
//                 />
//               </LocalizationProvider>
//               <ErrorMessage name="expireDate" />
//             </div>
//             <div>
//               <label>Quiz Time Limit</label>
//               <LocalizationProvider dateAdapter={AdapterDayjs}>
//                 <TimePicker
//                   value={dayjs(formik?.values?.timeLimitInSec)}
//                   // disablePast
//                   onChange={(newValue) =>
//                     setFieldValue(
//                       `timeLimitInSec`,
//                       moment(newValue.$d).valueOf()
//                     )
//                   }
//                 />
//               </LocalizationProvider>
//               <ErrorMessage name="timeLimitInSec" />
//             </div>
//             <div>
//               <label>Questions </label>
//               <FieldArray name={`questionsArray`}>
//                 {({ push, remove }) => (
//                   <div>
//                     <div className="example_box">
//                       {formik?.values?.questionsArray?.map(
//                         (questionsdata, questionsindex) => (
//                           <div
//                             className="example_box_inner"
//                             key={questionsindex}
//                           >
//                             <div>
//                               <label>Question {questionsindex + 1}</label>
//                               <Field
//                                 name={`questionsArray[${questionsindex}].questionText`}
//                                 type="text"
//                               />
//                               <ErrorMessage
//                                 name={`questionsArray[${questionsindex}].questionText`}
//                               />
//                             </div>
//                             <div>
//                               <Field
//                                 as="select"
//                                 name={`questionsArray[${questionsindex}].questionType`}
//                                 // defaultValue={defdata.wordclass}
//                               >
//                                 <option value="">Select option</option>
//                                 <option value="multiplechoice">
//                                   Multiple Choice
//                                 </option>
//                                 <option value="sortanswer">Short answer</option>
//                               </Field>
//                               <ErrorMessage
//                                 name={`questionsArray[${questionsindex}].questionType`}
//                               />
//                             </div>

//                             {/* start adding add options and answerbox */}
//                             {formik?.values?.questionsArray[questionsindex]
//                               ?.questionType === "multiplechoice" && (
//                               <div>
//                                 <div className="option1">
//                                   <label>Option 1</label>
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].rightAnswer`}
//                                     type="radio"
//                                     value={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[0].option1
//                                     }
//                                     checked={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[0].option1 ==
//                                       formik?.values?.questionsArray[
//                                         questionsindex
//                                       ]?.rightAnswer
//                                     }
//                                   />
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].options[0].option1`}
//                                     type="text"
//                                   />
//                                   <ErrorMessage
//                                     name={`questionsArray[${questionsindex}].options[0].option1`}
//                                   />
//                                 </div>
//                                 <div className="option2">
//                                   <label>Option 2</label>
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].rightAnswer`}
//                                     type="radio"
//                                     value={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[1].option2
//                                     }
//                                     checked={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[1].option2 ==
//                                       formik?.values?.questionsArray[
//                                         questionsindex
//                                       ]?.rightAnswer
//                                     }
//                                   />
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].options[1].option2`}
//                                     type="text"
//                                   />
//                                 </div>
//                                 <div className="option3">
//                                   <label>Option 3</label>
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].rightAnswer`}
//                                     type="radio"
//                                     value={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[2].option3
//                                     }
//                                     checked={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[2].option3 ==
//                                       formik?.values?.questionsArray[
//                                         questionsindex
//                                       ]?.rightAnswer
//                                     }
//                                   />
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].options[2].option3`}
//                                     type="text"
//                                   />
//                                 </div>
//                                 <div className="option4">
//                                   <label>Option 4</label>
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].rightAnswer`}
//                                     type="radio"
//                                     value={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[3].option4
//                                     }
//                                     checked={
//                                       formik.values.questionsArray[
//                                         questionsindex
//                                       ].options[3].option4 ==
//                                       formik?.values?.questionsArray[
//                                         questionsindex
//                                       ]?.rightAnswer
//                                     }
//                                   />
//                                   <Field
//                                     name={`questionsArray[${questionsindex}].options[3].option4`}
//                                     type="text"
//                                   />
//                                 </div>
//                               </div>
//                             )}

//                             {formik?.values?.questionsArray[questionsindex]
//                               ?.questionType === "sortanswer" && (
//                               <div>
//                                 <label>Answer Box</label>
//                                 <Field
//                                   name={`questionsArray[${questionsindex}].rightAnswer`}
//                                   type="text"
//                                 />
//                               </div>
//                             )}

//                             {questionsindex + 1 ===
//                               values?.questionsArray?.length && (
//                               <button
//                                 className="add_btn"
//                                 type="button"
//                                 disabled={
//                                   !values.questionsArray[questionsindex]
//                                     .questionText ||
//                                   values.questionsArray[questionsindex]
//                                     .questionType === "" ||
//                                   (values.questionsArray[questionsindex]
//                                     .questionType == "multiplechoice" &&
//                                     values.questionsArray[
//                                       questionsindex
//                                     ].options.some(
//                                       (option) =>
//                                         Object.values(option)[0] === ""
//                                     )) ||
//                                   values.questionsArray[questionsindex]
//                                     .rightAnswer == null ||
//                                   values.questionsArray[questionsindex]
//                                     .rightAnswer == ""
//                                 }
//                                 onClick={() =>
//                                   push({
//                                     questionText: "",
//                                     expireDate: "",
//                                     timeLimitInSec: "",
//                                     questionType: "",
//                                     options: [
//                                       { option1: "" },
//                                       { option2: "" },
//                                       { option3: "" },
//                                       { option4: "" },
//                                     ],
//                                     rightAnswer: null,
//                                   })
//                                 }
//                               >
//                                 Add Question
//                               </button>
//                             )}
//                             <button
//                               className="remv_btn"
//                               type="button"
//                               disabled={values?.questionsArray?.length <= 1}
//                               onClick={() => remove(questionsindex)}
//                             >
//                               Remove Question
//                             </button>
//                           </div>
//                         )
//                       )}
//                     </div>
//                   </div>
//                   <div className="form-field">
//                     <label>Quiz Description</label>
//                     <Field name="description" type="text" />
//                     <ErrorMessage name="description" />
//                   </div>
//                   <div className="form-field">
//                     <label>Quiz Expire Date</label>
//                     <LocalizationProvider dateAdapter={AdapterDayjs}>
//                       <DatePicker
//                         // minDate={currentDate}
//                         disablePast
//                         value={dayjs(formik?.values?.expireDate)}
//                         onChange={(newValue) =>
//                           setFieldValue(
//                             `expireDate`,
//                             moment(newValue.$d).valueOf()
//                           )
//                         }
//                       />
//                     </LocalizationProvider>
//                     <ErrorMessage name="expireDate" />
//                   </div>
//                   <div className="form-field">
//                     <label>Quiz Time Limit</label>
//                     <LocalizationProvider dateAdapter={AdapterDayjs}>
//                       <TimePicker
//                         value={dayjs(formik?.values?.timeLimitInSec)}
//                         // disablePast
//                         onChange={(newValue) =>
//                           setFieldValue(
//                             `timeLimitInSec`,
//                             moment(newValue.$d).valueOf()
//                           )
//                         }
//                       />
//                     </LocalizationProvider>
//                     <ErrorMessage name="timeLimitInSec" />
//                   </div>
//                   <div className="form-field">
//                     <label className="d-block border-bottom pb-2 mt-4 mb-3">
//                       Questions{" "}
//                     </label>
//                     <FieldArray name={`questionsArray`}>
//                       {({ push, remove }) => (
//                         <div>
//                           <div className="example_box">
//                             {formik?.values?.questionsArray?.map(
//                               (questionsdata, questionsindex) => (
//                                 <div
//                                   className="example_box_inner"
//                                   key={questionsindex}
//                                 >
//                                   <div className="form-field">
//                                     <label>Question {questionsindex + 1}</label>
//                                     <Field
//                                       name={`questionsArray[${questionsindex}].questionText`}
//                                       type="text"
//                                     />
//                                     <ErrorMessage
//                                       name={`questionsArray[${questionsindex}].questionText`}
//                                     />
//                                   </div>
//                                   <div className="form-field">
//                                     <Field
//                                       as="select"
//                                       name={`questionsArray[${questionsindex}].questionType`}
//                                       // defaultValue={defdata.wordclass}
//                                     >
//                                       <option value="">Select option</option>
//                                       <option value="multiplechoice">
//                                         Multiple Choice
//                                       </option>
//                                       <option value="sortanswer">
//                                         Short answer
//                                       </option>
//                                     </Field>
//                                     <ErrorMessage
//                                       name={`questionsArray[${questionsindex}].questionType`}
//                                     />
//                                   </div>

//             <button
//               type="submit"
//               //  disabled={!(formik.dirty && formik.isValid)}
//             >
//               Submit
//             </button>
//             {state && (
//               <button
//                 type="button"
//                 onClick={() => navigate("/admin/quiz-list")}
//               >
//                 Cancel
//               </button>
//             )}
//           </Form>
//         );
//       }}
//     </Formik>
//   );
// };

// export default AdminQuiz;
