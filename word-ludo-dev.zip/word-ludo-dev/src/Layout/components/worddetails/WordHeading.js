import React, { useState, useEffect } from "react";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import BookmarkIcon from "@mui/icons-material/Bookmark";
import VolumeUpRoundedIcon from "@mui/icons-material/VolumeUpRounded";
import { NavLink, useLocation } from "react-router-dom";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import CreatableSelect from "react-select/creatable";
import GoogleLogin from "../../components/GoogleLogin";
import { useDispatch, useSelector } from "react-redux";
import { getAllGroup } from "../../../redux/sllices/saveWordAndGroupSlice";
import { saveWord } from "../../../redux/sllices/wordOfTheDaySlice";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};
// const mediaquery = "@media (min-width: 767px)"
const customStyles = {
  control: (base) => ({
    ...base,
    "@media (min-width: 767px)": {
      maxHeight: "80px",
    },
  }),
};

const WordHeading = ({
  word,
  audio,
  saveFlag,
  pronunciation,
  definition,
  wordclass,
  id,
}) => {
  const auth = useSelector((state) => state.root.auth.islogin);
  const dispatch = useDispatch();
  const [bookmark, setBookmark] = useState(true);
  const location = useLocation();
  const [beforeSaveWord, setBeforeSaveWord] = useState(false);
  const [saveGroup, setSaveGroup] = useState(false);
  const [selectListOfGroup, setSelectListOfGroup] = useState([]);
  const [group, setGroup] = useState("");
  const groupList = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupList
  );
  const wordDetail = useSelector(
    (state) => state?.root?.wordOfTheDay?.wordDetail
  );

  const handleAudio = () => {
    new Audio(audio).play();
  };
  const handleModel = () => {
    const token = JSON.parse(localStorage.getItem("token"));
    if (token) {
      // if (!saveFlag) {
      setSaveGroup(true);
      dispatch(getAllGroup(true));
      // }
    } else {
      setBeforeSaveWord(true);
    }
  };
  const handleSaveWordModel = () => {
    setBeforeSaveWord(false);
  };
  const handleSaveGroupModel = () => {
    setSaveGroup(false);
  };
  const handleChangeGroup = (name) => {
    if (name) {
      setGroup(name);
    }
  };
  const handleSaveWord = () => {
    if (group?.id) {
      dispatch(saveWord({ groupId: group.id, wordId: id }));
      setGroup("");
      setSaveGroup(false);
    } else {
      dispatch(saveWord({ groupName: group.value, wordId: id }));
      setGroup("");
      setSaveGroup(false);
    }
  };
  useEffect(() => {
    if (groupList) {
      setSelectListOfGroup(
        groupList.map((e) => ({
          label: e?.isPublic ? e.groupName + "  (Public)" : e.groupName,
          value: e.groupName,
          id: e._id,
        }))
      );
    }
  }, [groupList]);
  useEffect(() => {
    if (auth) {
      setBeforeSaveWord(false);
    }
  }, [auth]);

  const selectListOfGroupWithDisabled = selectListOfGroup.map((option) => {
    const isDisabled = wordDetail?.wordGroupDetails?.some(
      (group) => group?.wordGroupId?._id === option.id
    );

    return { ...option, isDisabled };
  });

  return (
    <>
      <Modal
        open={beforeSaveWord}
        onClose={handleSaveWordModel}
        aria-labelledby="child-modal-title"
        aria-describedby="child-modal-description"
      >
        <Box sx={{ ...style, width: 330 }} className="login_popup">
          <h2 id="child-modal-title">Login Now</h2>
          <p id="child-modal-description">
            If you want access this feature then please login with Google
          </p>
          <div className="google_btn">
            <GoogleLogin />
          </div>
          <div className="no_thanks_btn">
            <button onClick={handleSaveWordModel}>No, thanks</button>
          </div>
          <div className="clearfix"></div>
        </Box>
      </Modal>
      <Modal
        open={saveGroup}
        onClose={handleSaveGroupModel}
        aria-labelledby="child-modal-title"
        aria-describedby="child-modal-description"
      >
        <Box sx={{ ...style, width: 330 }} className="my_word_popup">
          <h2 id="child-modal-title">My Word Group </h2>
          <div className="select_box">
            <CreatableSelect
              isClearable
              onChange={(e) => handleChangeGroup(e)}
              options={selectListOfGroupWithDisabled}
              styles={customStyles}
              isValidNewOption={(inputValue) => {
                if (inputValue.trim().length !== 0) {
                  return true;
                }
              }}

              // menuIsOpen={true}
            />
          </div>
          <div className="savbtn_grp">
            <button onClick={() => handleSaveWord()}>Save</button>
            {/* <button onClick={handleSaveGroupModel}>Cancel</button> */}
          </div>
        </Box>
      </Modal>
      <div className="word_data_box">
        <div
          className={`line_one ${
            location?.pathname != "/" && "after_login_save"
          }`}
        >
          {location?.pathname === "/" && <h2> Word of the Day</h2>}
          <p style={{ cursor: "pointer" }} onClick={() => handleModel()}>
            <span onClick={() => setBookmark(!bookmark)}>
              {saveFlag ? <BookmarkIcon /> : <BookmarkBorderIcon />}
            </span>
            Save Word
          </p>
        </div>
        <div className="line_two">
          <h3>{word ? word : "Crick"}</h3>
          {location?.pathname === "/" && <p>{wordclass}</p>}
        </div>
        <div className="line_three">
          <p>
            <span>
              <VolumeUpRoundedIcon onClick={() => handleAudio()} />
            </span>{" "}
            \ {pronunciation ? pronunciation : "No data"} \
          </p>
        </div>
        <div className="line_four">
          <h2> {definition && <>Definition of {word} </>}</h2>
          <p>{definition}</p>
        </div>
        <div className="line_five">
          {location?.pathname === "/" && (
            <NavLink to="/word-details">
              Learn more about this word{" "}
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M3.33325 8H12.6666M12.6666 8L7.99991 3.33325M12.6666 8L7.99991 12.6666"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </NavLink>
          )}
        </div>
      </div>
    </>
  );
};

export default WordHeading;
