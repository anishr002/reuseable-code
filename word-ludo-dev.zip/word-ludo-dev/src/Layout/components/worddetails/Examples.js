import React from 'react';

const Examples = ({ examples }) => {
  const examp = examples.filter(e=>e)
  return (
    <>
      <div className="data_box examples">
        <h4>Examples</h4>
        <ul>
          {examp.length > 0
            ? examp.map((o, i) => {
                return (
                  <>
                    {/* {o === '' && ( */}
                      <li key={i}>
                        <p>{o}</p>
                      </li>
                    {/* )} */}
                  </>
                );
              })
            : 'No Data Found'}
        </ul>
      </div>
    </>
  );
};

export default Examples;
