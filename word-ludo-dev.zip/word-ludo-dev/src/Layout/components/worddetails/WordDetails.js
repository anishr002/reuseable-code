import * as React from "react";
import { useEffect, useState, useRef, createRef } from "react";
import WordHeading from "./WordHeading";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import Defination from "./Defination";
import Antonyms from "./Antonyms";
import Examples from "./Examples";
import Synonyms from "./Synonyms";
import Loader from "../../Loader";
import { useDispatch } from "react-redux";
import {
  getWordDetail,
  getWordSynonymsAntonymsDetails,
} from "../../../redux/sllices/wordOfTheDaySlice";
import { getAllwordclass } from "../../../redux/sllices/wordSlice";
import SearchInput from "../SearchInput";

const WordDetails = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTitle, setActiveTitle] = useState("");
  const allWordClass = useSelector(
    (state) => state?.root?.words?.wordClassArray
  );
  const wordClassRef = useRef(allWordClass.map(() => createRef()));
  const wordDetail = useSelector(
    (state) => state?.root?.wordOfTheDay?.wordDetail
  );
  const isLoading = useSelector((state) => state?.root?.wordOfTheDay?.loading);
  useEffect(() => {
    // Set the initial active title to the first wordClass in the array
    if (wordDetail?.word?.wlLexicalEntries?.length > 0) {
      setActiveTitle(wordDetail.word.wlLexicalEntries[0].wordClass);
    }
  }, [wordDetail]);
  useEffect(() => {
    dispatch(getAllwordclass());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const handleNavigationref = (value) => {
    const wordclassPresent = wordClassRef.current.filter((e) => e.current);
    const wordclassActive = wordclassPresent.filter(
      (f) => f.current?.id === value
    );
    if (wordclassActive.length > 0) {
      window.scrollTo({
        top: wordclassActive[0].current.offsetTop - 100,
        behavior: "smooth",
      });
    }
    setActiveTitle(value);
  };
  const checkId = (str) => {
    return /^[a-zA-ZáéíóúÁÉÍÓÚ-]+$/.test(str);
  };
  useEffect(() => {
    if (!checkId(id)) {
      dispatch(getWordDetail(id));
    } else {
      dispatch(getWordSynonymsAntonymsDetails(id, navigate));
    }
  }, [dispatch, id]);

  // useEffect(() => {
  //   setfirstRender(false);
  // }, []);

  const gobackHandler = () => {
    navigate(-1);
    // const backId = window.location.pathname.split('/')[2]
    // console.log(id,backId)
  };

  return (
    <>
      {isLoading ? (
        <Loader />
      ) : (
        <div className="container">
          {/* <button type="button" onClick={gobackHandler}>
            back
          </button> */}
          <div className="d-flex">
            <div
              onClick={gobackHandler}
              // style={{ marginRight: "15px" }}
              className="back-btn-link me-3"
            >
              <svg
                width="48"
                height="48"
                viewBox="0 0 48 48"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="48" height="48" rx="24" fill="#00509D" />
                <path
                  d="M31 24H17M17 24L24 30.9999M17 24L24 16.9999"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </div>
            <div className="clearfix"></div>

            <SearchInput />
          </div>

          <WordHeading
            id={wordDetail?._id}
            saveFlag={wordDetail?.isSave}
            word={wordDetail?.word?.word}
            audio={wordDetail?.word?.audioURL}
            pronunciation={wordDetail?.word?.pronunciation}
            definition={
              wordDetail?.word?.wlLexicalEntries[0]?.definitions[0]
                ?.definitionText
            }
            wordclass={wordDetail?.word?.wlLexicalEntries?.map((welexidata) => {
              return welexidata?.wordClass;
            })}
          />
          <div className="clearfix"></div>
          <ul className="listing_box">
            {wordDetail?.word?.wlLexicalEntries?.map((welexidata) => {
              return (
                <li
                  className={
                    activeTitle === welexidata?.wordClass ? "active" : ""
                  }
                  onClick={() => handleNavigationref(welexidata?.wordClass)}
                >
                  {welexidata?.wordClass}
                </li>
              );
            })}
          </ul>
          {wordDetail?.word?.wlLexicalEntries?.map((e, i) => (
            <div
              ref={wordClassRef.current[i]}
              id={e?.wordClass}
              className="detail_box"
            >
              <div>
                <h4>{`WordClass (${e?.wordClass})`}</h4>
              </div>
              <Defination definition={e?.definitions} />
              <Synonyms synonyms={e?.synonym} />
              <Antonyms antonyms={e?.antonym} />
              <Examples examples={e?.example} />
            </div>
          ))}

          <div className="clearfix"></div>
        </div>
      )}
    </>
  );
};

export default WordDetails;
