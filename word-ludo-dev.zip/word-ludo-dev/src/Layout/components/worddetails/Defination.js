import React from "react";

const Defination = ({ definition }) => {
  const defi = definition.filter(e=>e.definitionText)
  return (
    <div className="data_box">
      <h4>Definition</h4>
      <ui>
        {defi.length > 0
          ? defi?.map((e, i) => {
              return (
                <>
                  <li key={i}>{e?.definitionText}</li>
                </>
              );
            })
          : "No Data Found"}
      </ui>
    </div>
  );
};

export default Defination;
