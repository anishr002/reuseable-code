import React from 'react';
import { useNavigate } from 'react-router-dom';

const Synonyms = ({ synonyms }) => {
  const navigate = useNavigate();

  return (
    <>
      <div className="data_box synonyms">
        <h4>Synonyms</h4>

        {synonyms.length > 0
          ? synonyms.map((o, i) => {
              return (
                <>
                  {o?.split(' ').length > 1 ? (
                    <>
                      {o}
                      {synonyms.length !== i + 1 ? ', ' : null}
                    </>
                  ) : (
                    <>
                      <div
                        key={i}
                        className="Synonym-para"
                        onClick={() => navigate(`/word-details/${o}`)}
                      >
                        {o}
                        {synonyms.length !== i + 1 ? ', ' : null}
                      </div>
                      {/* {synonyms.length != i + 1 && <span>,</span>} */}
                    </>
                  )}
                </>
              );
            })
          : 'No Data Found'}
      </div>
    </>
  );
};

export default Synonyms;
