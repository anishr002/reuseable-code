import React from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { toggleLoading } from '../../../redux/sllices/wordOfTheDaySlice';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import Loader from '../../Loader';
import axios from 'axios';
import { toast } from 'react-toastify';
import { ToastContent } from '../ToastContent';

const Antonyms = ({ antonyms }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  return (
    <>
      <div className="data_box">
        <h4>Antonyms</h4>
        {antonyms.length > 0
          ? antonyms.map((o, i) => {
              return (
                <>
                  {o?.split(' ').length > 1 ? (
                    <>
                      {o}
                      {antonyms?.length != i + 1 ? ', ' : null}
                    </>
                  ) : (
                    <>
                      <div
                        key={i}
                        className="Synonym-para"
                        onClick={() => navigate(`/word-details/${o}`)}
                      >
                        {o}
                        {antonyms?.length != i + 1 ? ', ' : null}
                      </div>
                      {/* {antonyms.length != i + 1 && <span>,</span>} */}
                    </>
                  )}
                </>
              );
            })
          : 'No Data Found'}
      </div>
    </>
  );
};

export default Antonyms;
