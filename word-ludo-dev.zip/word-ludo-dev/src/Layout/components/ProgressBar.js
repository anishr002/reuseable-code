import * as React from "react";
// import { useTheme } from '@mui/material/styles';
// import Button from '@mui/material/Button';
// import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
// import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
const ProgressBar = ({ progress, Count }) => {
  // const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);

  // const handleNext = () => {
  //     setActiveStep((prevActiveStep) => prevActiveStep + 1);
  // };

  // const handleBack = () => {
  //     setActiveStep((prevActiveStep) => prevActiveStep - 1);
  // };

  return (
    <>
      <div className="top_question_count">
        <p>Question {Count}</p>
      </div>
      <div className="progress_line">
        <span style={{ width: `${progress}%` }}></span>
      </div>
    </>
  );
};

export default ProgressBar;
