// // import { Card } from "@mui/material";
// // import CloseIcon from "@mui/icons-material/Close";
// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { useLocation, useNavigate } from "react-router-dom";
// import { deleteSaveWord } from "../../../redux/sllices/saveWordAndGroupSlice";
// import Loader from "../../Loader";
// import { Empty } from "antd";
// import {
//   getPublicAllWords,
//   resetData,
// } from "../../../redux/sllices/allwordSlice";
// import axios from "axios";
// import InfiniteScroll from "react-infinite-scroll-component";

// const AllFilterWords = () => {
//   const dispatch = useDispatch();
//   const AllDataValue = useSelector((state) => state?.root?.Allwords?.data);

//   const totalWords = useSelector((state) => state?.root?.Allwords?.totalWords);
//   const loading = useSelector((state) => state?.root?.Allwords?.loading);
//   const location = useLocation();
//   const [pageNumber, setPageNumber] = useState(1);
//   const [pageLimit, setPageLimit] = useState(100);
//   const [hasMore, sethasMore] = useState(true);

//   const navigate = useNavigate();
//   const alphabet = [
//     "A",
//     "B",
//     "C",
//     "D",
//     "E",
//     "F",
//     "G",
//     "H",
//     "I",
//     "J",
//     "K",
//     "L",
//     "M",
//     "N",
//     "O",
//     "P",
//     "Q",
//     "R",
//     "S",
//     "T",
//     "U",
//     "V",
//     "W",
//     "X",
//     "Y",
//     "Z",
//   ];

//   const [activeindex, setActiveindex] = useState(0);

//   console.log(AllDataValue?.wordList, "20");

//   // console.log(GroupDetails, "16");
//   const [wordLetter, setWordLetter] = useState([]);
//   const [wordsList, setWordList] = useState(AllDataValue?.wordList);
//   // const [activeindex, setActiveindex] = useState(0);

//   const fetchData = async () => {
//     console.log(wordsList.length <= totalWords, "67");
//     sethasMore(true);
//     if (wordsList.length <= totalWords) {
//       console.log("70");
//       dispatch(getPublicAllWords(pageNumber + 1, pageLimit));
//       setPageNumber((prevPage) => prevPage + 1);
//     } else {
//       sethasMore(false);
//     }
//   };

//   useEffect(() => {
//     dispatch(resetData());
//   }, [location.pathname]);

//   window.addEventListener("beforeunload", () => {
//     dispatch(resetData());
//   });

//   useEffect(() => {
//     dispatch(getPublicAllWords(pageNumber, pageLimit));
//   }, []);

//   useEffect(() => {
//     if (alphabet?.length > 0) {
//       setWordLetter([
//         "All",
//         ...alphabet
//           .map((item) => item)
//           .filter((value, index, self) => self.indexOf(value) === index),
//       ]);
//     } else if (alphabet?.length === 0) {
//       setWordLetter([]);
//     }
//     setWordList(AllDataValue?.wordList);
//   }, [AllDataValue?.wordList]);

//   const handleFilterWord = async (letter) => {
//     try {
//       if (letter === "All") {
//         setWordList(AllDataValue?.wordList);
//       } else {
//         const response = await axios.get(
//           `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${letter}`
//         );
//         console.log(response?.data?.data, "71");
//         setWordList(response?.data?.data?.wordList);
//       }
//     } catch (error) {
//       console.error("Error filtering words:", error);
//     }
//   };
//   return (
//     <>
//       {loading ? (
//         <Loader />
//       ) : (
//         <div className="inner_box">
//           {wordsList && wordsList.length > 0 ? (
//             <InfiniteScroll
//               dataLength={wordsList?.length}
//               next={fetchData}
//               hasMore={hasMore}
//               loader={<Loader />}
//               pullDownToRefreshThreshold={50}
//             >
//               <div className="word_list">
//                 {wordLetter?.map((o, i) => {
//                   return (
//                     <div key={i} className="list_line">
//                       <button
//                         className={activeindex == i && "active"}
//                         onClick={() => {
//                           handleFilterWord(o);
//                           setActiveindex(i);
//                         }}
//                       >
//                         {o}
//                       </button>
//                     </div>
//                   );
//                 })}
//               </div>
//               {/* <h2>My Saved Words</h2> */}
//               <ul className="word_list_inner">
//                 {wordsList?.length > 0 ? (
//                   wordsList?.map((o) => {
//                     return (
//                       <li key={o._id}>
//                         <p onClick={() => navigate(`/word-details/${o?._id}`)}>
//                           {o?.word}{" "}
//                         </p>
//                       </li>
//                     );
//                   })
//                 ) : (
//                   <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
//                 )}
//               </ul>
//             </InfiniteScroll>
//           ) : (
//             <p>No Word Found</p>
//           )}
//         </div>
//       )}
//     </>
//   );
// };

// export default AllFilterWords;

// import { Card } from "@mui/material";
// import CloseIcon from "@mui/icons-material/Close";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteSaveWord } from "../../../redux/sllices/saveWordAndGroupSlice";
import Loader from "../../Loader";
import { Empty } from "antd";
import { getPublicAllWords } from "../../../redux/sllices/allwordSlice";
import axios from "axios";
import { cleanDigitSectionValue } from "@mui/x-date-pickers/internals/hooks/useField/useField.utils";

const AllFilterWords = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const alphabet = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
  ];

  const [activeindex, setActiveindex] = useState(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageLimit, setPageLimit] = useState(100);
  const [isloading, setloading] = useState(true);
  const [isloadingData, setloadingData] = useState(false);

  const [searchKey, setsearchKey] = useState("");

  const AllDataValue = useSelector((state) => state?.root?.Allwords?.data);
  const loading = useSelector((state) => state?.root?.Allwords?.loading);
  const totalWords = useSelector((state) => state?.root?.Allwords?.totalWords);

  // console.log(GroupDetails, "16");
  const [wordLetter, setWordLetter] = useState([]);
  const [wordsList, setWordList] = useState([AllDataValue?.wordList]);
  const [totalPublicWords, setTotalPublicWords] = useState(totalWords);

  // const [activeindex, setActiveindex] = useState(0);
  console.log(totalWords, totalPublicWords, "20");

  const handleInfiniteScroll = async () => {
    console.log(wordsList, totalPublicWords, "242");
    let totalPage = Math.ceil(totalPublicWords / 100);
    console.log(totalPublicWords, totalPage, pageNumber, "totalPage");
    // if (totalPage >= pageNumber) {
    try {
      if (
        totalPublicWords > 100 &&
        window.innerHeight + document.documentElement.scrollTop + 1 >=
          document.documentElement.scrollHeight
      ) {
        setloading(true);
        setPageNumber((prev) => prev + 1);
      }
    } catch (error) {}
    // }
  };
  console.log(totalPublicWords, "totalPublicWords200");
  useEffect(() => {
    setWordList(AllDataValue?.wordList);
    console.log(wordsList);
  }, [AllDataValue]);
  useEffect(() => {
    console.log(searchKey, "searchKey");
    const allsearch = searchKey === "All" ? "" : searchKey;
    dispatch(getPublicAllWords(pageNumber, pageLimit, searchKey));
    setWordList((prev) => [...prev, ...wordsList]);
    setloading(false);
  }, [pageNumber, pageLimit, searchKey]);

  useEffect(() => {
    window.addEventListener("scroll", handleInfiniteScroll);
    return () => window.removeEventListener("scroll", handleInfiniteScroll);
  }, []);

  useEffect(() => {
    if (alphabet?.length > 0) {
      setWordLetter([
        "All",
        ...alphabet
          .map((item) => item)
          .filter((value, index, self) => self.indexOf(value) === index),
      ]);
    } else if (alphabet?.length === 0) {
      setWordLetter([]);
    }
    setWordList(AllDataValue?.wordList);
  }, [AllDataValue?.wordList]);

  // const handleFilterWord = async (letter) => {
  //   console.log(letter);
  //   const newPageNumber = 1;
  //   setsearchKey(letter);
  //   const allsearch = letter === "All" ? "" : letter;
  //   setWordList([]);
  //   setloading(true);
  //   try {
  //     setPageNumber(newPageNumber); // Set pageNumber to 1

  //     if (letter === "All") {
  //       setWordList(AllDataValue?.wordList);
  //     } else {
  //       const response = await axios.get(
  //         `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${allsearch}&pageNumber=${newPageNumber}&pageLimit=${pageLimit}`
  //       );

  //       setWordList(response?.data?.data?.wordList);
  //       // setPageNumber(1);
  //     }
  //   } catch (error) {
  //     console.error("Error filtering words:", error);
  //   }
  // };

  const handleFilterWord = async (letter) => {
    setsearchKey(letter);
    const allsearch = letter === "All" ? "" : letter;
    console.log(letter, allsearch, "318");
    setWordList([]);
    setloadingData(true);

    try {
      setPageNumber(1); // Reset pageNumber to 1

      // if (letter === "All") {
      //   const response = await axios.get(
      //     `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${allsearch}&pageNumber=1&pageLimit=${pageLimit}`
      //   );
      //   setWordList(response?.data?.data?.wordList);
      //   setTotalPublicWords(response?.data?.data?.totalWords);
      // } else {
      //   const response = await axios.get(
      //     `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${allsearch}&pageNumber=1&pageLimit=${pageLimit}`
      //   );
      //   setWordList(response?.data?.data?.wordList);
      //   setTotalPublicWords(response?.data?.data?.totalWords);
      // }
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${allsearch}&pageNumber=1&pageLimit=${pageLimit}`
      );
      setWordList(response?.data?.data?.wordList);
      setTotalPublicWords(response?.data?.data?.totalWords);
      setloading(false);
    } catch (error) {
      console.error("Error filtering words:", error);
    } finally {
      setloadingData(false);
    }
  };
  return (
    <>
      {isloadingData ? (
        <Loader />
      ) : (
        <div className="inner_box">
          <div className="word_list">
            {wordLetter?.map((o, i) => {
              return (
                <div key={i} className="list_line">
                  <button
                    className={activeindex == i && "active"}
                    onClick={() => {
                      handleFilterWord(o);
                      setActiveindex(i);
                    }}
                  >
                    {o}
                  </button>
                </div>
              );
            })}
          </div>
          {/* {/ <h2>My Saved Words</h2> /} */}

          <ul className="word_list_inner">
            {wordsList && wordsList?.length > 0 ? (
              wordsList?.map((o) => {
                return (
                  <li key={o?._id}>
                    <p onClick={() => navigate(`/word-details/${o?._id}`)}>
                      {o?.word}{" "}
                    </p>
                  </li>
                );
              })
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </ul>
        </div>
      )}
      {isloading && <Loader />}
    </>
  );
};

export default AllFilterWords;
