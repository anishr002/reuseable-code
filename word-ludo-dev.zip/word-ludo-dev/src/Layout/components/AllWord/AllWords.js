import React from "react";
import AllWordSearch from "./AllWordSearch";
import AllFilterWords from "./AllFilterWords";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import {
  getPublicAllWords,
  resetData,
} from "../../../redux/sllices/allwordSlice";

const AllWords = () => {
  const dispatch = useDispatch();
  const AllDataValue = useSelector((state) => state?.root?.Allwords?.data);

  useEffect(() => {
    dispatch(resetData());
    dispatch(getPublicAllWords(1, 100, ""));
  }, []);

  return (
    <>
      <div>
        <div className="my_word_box pt-0">
          <div className="container">
            <h1>Words</h1>
            <AllWordSearch />
          </div>
          <div className="saveword_group_box">
            <div className="container">
              {AllDataValue.length != 0 && <AllFilterWords />}
            </div>
          </div>
        </div>
      </div>
      <div className="clearfix"></div>
    </>
  );
};

export default AllWords;
