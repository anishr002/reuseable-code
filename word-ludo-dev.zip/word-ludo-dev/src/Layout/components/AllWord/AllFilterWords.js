import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteSaveWord } from "../../../redux/sllices/saveWordAndGroupSlice";
import Loader from "../../Loader";
import { Empty } from "antd";
import {
  getPublicAllWords,
  resetData,
} from "../../../redux/sllices/allwordSlice";
import axios from "axios";
import { cleanDigitSectionValue } from "@mui/x-date-pickers/internals/hooks/useField/useField.utils";
import { useLocation } from "react-router-dom/dist";

const AllFilterWords = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const alphabet = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
  ];

  const [activeindex, setActiveindex] = useState(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageLimit, setPageLimit] = useState(100);
  const [isloading, setloading] = useState(true);
  const [isloadingData, setloadingData] = useState(false);

  const [searchKey, setsearchKey] = useState("");

  const fullState = useSelector((state) => state);
  const AllDataValue = useSelector((state) => state?.root?.Allwords?.data);
  const loading = useSelector((state) => state?.root?.Allwords?.loading);
  const totalWords = useSelector((state) => state?.root?.Allwords?.totalWords);

  const [wordLetter, setWordLetter] = useState([]);
  const [wordsList, setWordList] = useState([AllDataValue?.wordList]);
  const [totalPublicWords, setTotalPublicWords] = useState(totalWords);
  // const [isFirstLoad, setIsFirstLoad] = useState(false);

  useEffect(() => {
    if (pageNumber !== 1) {
      const allsearch = searchKey === "All" ? "" : searchKey;
      dispatch(getPublicAllWords(pageNumber, pageLimit, allsearch));
      setWordList((prev) => [...prev, ...wordsList]);
    }
    setloading(false);
  }, [pageNumber, pageLimit, totalPublicWords]);

  const handleFilterWord = async (letter) => {
    setsearchKey(letter);
    const allsearch = letter === "All" ? "" : letter;
    setWordList([]);
    setloadingData(true);

    try {
      setPageNumber(1); // Reset pageNumber to 1
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${allsearch}&pageNumber=1&pageLimit=${pageLimit}`
      );
      setWordList(response?.data?.data?.wordList);
      setTotalPublicWords(response?.data?.data?.totalWords);
      setloadingData(false);
    } catch (error) {
      // console.error("Error filtering words:", error);
    } finally {
      setloadingData(false);
    }
  };
  const handleInfiniteScroll = async () => {
    let totalPage = Math.ceil(totalPublicWords / 100);

    try {
      if (
        totalPublicWords > 100 &&
        pageNumber <= Number(totalPage) - 1 &&
        window.innerHeight + document.documentElement.scrollTop + 1 >
          document.documentElement.scrollHeight
      ) {
        setloading(true);
        setPageNumber((prev) => prev + 1);
      }
    } catch (error) {}
  };
  useEffect(() => {
    setloadingData(false);
    window.addEventListener("scroll", handleInfiniteScroll);
    return () => window.removeEventListener("scroll", handleInfiniteScroll);
  }, [totalPublicWords, wordsList]);

  useEffect(() => {
    if (alphabet?.length > 0) {
      setWordLetter([
        "All",
        ...alphabet
          .map((item) => item)
          .filter((value, index, self) => self.indexOf(value) === index),
      ]);
    } else if (alphabet?.length === 0) {
      setWordLetter([]);
    }
    setWordList(AllDataValue?.wordList);
  }, [AllDataValue?.wordList]);

  useEffect(() => {}, []);

  return (
    <>
      {isloadingData ? (
        <Loader />
      ) : (
        <div className="inner_box">
          <div className="word_list">
            {wordLetter?.map((o, i) => {
              return (
                <div key={i} className="list_line">
                  <button
                    className={activeindex == i && "active"}
                    onClick={() => {
                      handleFilterWord(o);
                      setActiveindex(i);
                    }}
                  >
                    {o}
                  </button>
                </div>
              );
            })}
          </div>
          {/* {/ <h2>My Saved Words</h2> /} */}

          <ul className="word_list_inner">
            {wordsList && wordsList?.length > 0
              ? wordsList?.map((o) => {
                  return (
                    <li
                      key={o?._id}
                      onClick={() => navigate(`/word-details/${o?._id}`)}
                    >
                      <p>{o?.word} </p>
                    </li>
                  );
                })
              : ""}
            {/* {wordsList?.length < 0 && (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )} */}
            {totalPublicWords === 0 && (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </ul>
        </div>
      )}
      {isloading && <Loader />}
      <div className="clearfix"></div>
    </>
  );
};

export default AllFilterWords;
