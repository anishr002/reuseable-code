import { Skeleton, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import logoImg from "../../../src/assets/images/logo.svg";

const withSplashScreen = (WrappedComponent) => {
  return (props) => {
    const [isLoading, setIsLoading] = useState(true);
    useEffect(() => {
      setTimeout(() => {
        setIsLoading(false);
      }, 1500);
    }, []);

    if (isLoading !== false)
      return (
        <div className="splash_logo">
          <img className="logo_img" src={logoImg} alt="" />
        </div>
      );

    return <WrappedComponent {...props} />;
  };
};

export default withSplashScreen;
