import * as React from "react";
import { useState } from "react";
import { Button } from "@mui/material";
import { useDispatch } from "react-redux";
import { resetData } from "../../../redux/sllices/quizSlice";
import EssayGeenerator from "./EssayGeenerator";
import EssayGrade from "./EssayGrade";

const Essay = () => {
  const [value, setValue] = useState("essayGenerate");
  const url = window.location.href.split("/")[3];
  const dispatch = useDispatch();
  React.useEffect(() => {
    if (url === "essay") {
      setValue("essayGenerate");
    } else if (url === "essay-grade") {
      setValue("essayGrade");
    }
  }, [url]);

  return (
    <>
      <div className="quiz_main_page">
        <div className="container">
          <div className="top_button ">
            <Button
              className={value === "essayGenerate" ? "active" : ""}
              onClick={() => setValue("essayGenerate")}
            >
              Essay Generator
            </Button>

            <Button
              className={value === "essayGrade" ? "active" : ""}
              onClick={() => setValue("essayGrade")}
            >
              Grade an Essay
            </Button>
          </div>
          <div className="quiz_list">
            {value === "essayGenerate" ? <EssayGeenerator /> : <EssayGrade />}
          </div>
          <div className="clearfix"></div>
        </div>
      </div>
      <div className="clearfix"></div>
    </>
  );
};

export default Essay;
