import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Delete } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import {
  GradeinEssay,
  getgradeOption,
  resetEssay,
} from "../../../redux/sllices/essayGeneratorSlice";

const EssayGrade = () => {
  const GradeEssayResponse = useSelector(
    (state) => state?.root?.essay?.genereategradeData
  );

  const OptionData = useSelector(
    (state) => state?.root?.essay?.generateGradeOptionData
  );

  // console.log(OptionData, "OptionData");

  const validationSchema = yup.object().shape({
    essayImage: yup.mixed().required("Image is required"),
  });

  const gradingValidationSchema = yup.object().shape({
    gradingOptions: yup
      .array()
      .of(yup.string())
      .min(1, "Select at least one option"),
  });

  const [showModal, setShowModal] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [imageResponse, setImageResponse] = useState(GradeEssayResponse);

  const openModal = () => {
    setShowModal(true);
  };

  // console.log(GradeEssayResponse, "23414");

  const closeModal = () => {
    setShowModal(false);
    clearErrors();
  };

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
      if (!isMobile && showModal) {
        setShowModal(false);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [showModal]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      essayImage: null,
    },
  });

  const {
    register: registerGrading,
    handleSubmit: handleSubmitGrading,
    formState: { errors: gradingErrors },
  } = useForm({
    resolver: yupResolver(gradingValidationSchema),
    defaultValues: {
      gradingOptions: [],
    },
  });

  const [image, setImage] = useState(null);
  const [imageName, setImageName] = useState("Choose image");
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getgradeOption());
    dispatch(resetEssay());
  }, [dispatch]);

  function convertImageToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result);
      };
      reader.onerror = (error) => {
        reject(error);
      };
      reader.readAsDataURL(file);
    });
  }

  const onSubmit = (data) => {
    const newdata = { image: data.essayImage };
    dispatch(GradeinEssay(newdata));
  };

  const onSubmitGrading = (data) => {
    console.log("Grading Data: ", data);
    // Handle grading submission
  };

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const base64String = await convertImageToBase64(file);
      setImage(base64String);
      setValue("essayImage", base64String);
      clearErrors("essayImage");
      setImageName(file.name);
    }
  };

  const handleRemoveImage = () => {
    setImage(null);
    setImageName("Choose image");
    setValue("essayImage", null);
    setError("essayImage", {
      type: "manual",
      message: "Image is required",
    });
  };

  return (
    <div className="container mt-2">
      <div className="row">
        <div className="col-12 col-md-4 mb-3">
          <div className="p-3 border">
            <h5>Upload Essay Image</h5>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="form-group">
                {/* <label htmlFor="essayImage">Upload Essay Image</label> */}
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    value={imageName}
                    readOnly
                  />
                  <label className="input-group-text" htmlFor="essayImage">
                    Browse
                  </label>
                  <input
                    type="file"
                    id="essayImage"
                    accept=".svg, .jpg, .jpeg, .png"
                    {...register("essayImage")}
                    onChange={handleImageChange}
                    className="form-control d-none"
                  />
                </div>
                {errors.essayImage && (
                  <p className="text-danger">{errors.essayImage.message}</p>
                )}
              </div>
              {image && (
                <div className="d-flex justify-content-between mt-1">
                  <img
                    src={image}
                    alt="Uploaded Essay"
                    className="img-thumbnail"
                    style={{ width: "50.2px", height: "39.93px" }}
                  />
                  <button
                    type="button"
                    className="btn btn-outline-danger btn-sm"
                    onClick={handleRemoveImage}
                    style={{ zIndex: 1, height: "39px" }}
                  >
                    <Delete />
                  </button>
                </div>
              )}
              <div className="new_grade_form_group d-flex justify-content-end">
                <button className="submit_btn m-2" type="submit">
                  Submit
                </button>
              </div>
            </form>
          </div>
          <div className="p-3 border mt-4">
            <h5>Grading Controls</h5>
            <form onSubmit={handleSubmitGrading(onSubmitGrading)}>
              <div className="form-group">
                {OptionData &&
                  OptionData.length > 0 &&
                  OptionData?.map((option) => {
                    return (
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="option1"
                          {...registerGrading("gradingOptions")}
                          value={option?.value}
                        />
                        <label className="form-check-label" htmlFor="option1">
                          {option && option?.label}
                        </label>
                      </div>
                    );
                  })}
              </div>
              {gradingErrors.gradingOptions && (
                <p className="text-danger">
                  {gradingErrors.gradingOptions.message}
                </p>
              )}
              {/* {imageResponse.length > 0 && ( */}
              <div className="new_grade_form_group d-flex justify-content-end">
                <button className="submit_btn m-2" type="submit">
                  Grade Essay
                </button>
              </div>
              {/* )} */}
            </form>
          </div>
        </div>
        <div className="col-12 col-md-4 mb-3">
          <div className="p-3 border">
            <h5>Image to Text Conversion</h5>
            {/* <label htmlFor="essayImage">Image to Text Conversion</label> */}
            <textarea
              className="form-control"
              // style={{ border: "none" }}
              placeholder="write here.."
              rows={
                Object.keys(errors).length === 0 && image === null ? "17" : "19"
              }
              // value={imageResponse.length === 0 ? "No Data" : imageResponse}
              value={imageResponse}
              onChange={(e) => setImageResponse(e.target.value)}
              // readOnly
            />
          </div>
        </div>
        <div className="col-12 col-md-4 mb-3">
          <div className="p-3 border">
            <h5>Graded Summary</h5>
            <div className="form-group">
              <select className="form-select mb-2">
                <option>Content and Development</option>
              </select>
              <select className="form-select mb-2">
                <option>Content and Development</option>
              </select>
              <select className="form-select mb-2">
                <option>Content and Development - Grade</option>
              </select>
              <textarea
                className="form-control"
                // rows="8"
                rows={
                  Object.keys(errors).length === 0 && image === null
                    ? "11"
                    : "13"
                }
                value="Overall grade"
                readOnly
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EssayGrade;
