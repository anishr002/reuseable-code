import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Delete } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import {
  GradeinEssay,
  resetEssay,
} from "../../../redux/sllices/essayGeneratorSlice";
import { Modal } from "antd";
import { useSelector } from "react-redux";

const EssayGrade = () => {
  const GradeEssayResponse = useSelector(
    (state) => state?.root?.essay?.genereategradeData
  );
  const validationSchema = yup.object().shape({
    essayImage: yup
      .mixed()
      // .test("fileSize", "File size is too large", (value) => {
      //   return value && value[0].size <= 5242880; // 5MB
      // })
      // .test(
      //   "fileType",
      //   "Unsupported file type",
      //   (value) =>
      //     value &&
      //     ["image/jpeg", "image/png", "image/svg+xml"].includes(value[0].type)
      // )
      .required("Image is required"),
  });

  const [showModal, setShowModal] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    clearErrors();
  };

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768); // Adjust the breakpoint as needed
      if (!isMobile && showModal) {
        setShowModal(false); // Close modal if not mobile view
      }
    };

    handleResize(); // Call the function to set initial state
    window.addEventListener("resize", handleResize); // Listen for resize events
    return () => window.removeEventListener("resize", handleResize); // Cleanup
  }, [showModal]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
    clearErrors,
    getValues,
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      essayImage: null,
    },
  });

  const [image, setImage] = useState(null);
  const [imageName, setImageName] = useState("Please select an image");
  const [response, setResponse] = useState("");
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(resetEssay());
  }, []);

  function convertImageToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result);
      };
      reader.onerror = (error) => {
        reject(error);
      };
      reader.readAsDataURL(file);
    });
  }

  const onSubmit = (data) => {
    const newdata = { image: data.essayImage };
    dispatch(GradeinEssay(newdata));
  };

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const base64String = await convertImageToBase64(file);
      setImage(base64String);
      setValue("essayImage", base64String);
      clearErrors("essayImage");
      setImageName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImage(null);
    setImageName("Please select an image");
    setValue("essayImage", null);
    setError("essayImage", {
      type: "manual",
      message: "Image is required",
    });
  };

  return (
    <>
      <div className="container mt-2">
        {isMobile ? (
          <div className="row">
            <div className="create-btn-div text-end">
              <button
                className="CreateEssay"
                variant="contained"
                onClick={openModal}
              >
                Create Grade In Essay
              </button>
            </div>
            <Modal open={showModal} onCancel={closeModal} footer={null}>
              <div className="container mt-2">
                <form onSubmit={handleSubmit(onSubmit)} className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="essayImage p-1">Upload Essay Image</label>
                      <div className="input-group p-1">
                        <input
                          type="text"
                          className="form-control"
                          value={imageName}
                          readOnly
                        />
                        <label
                          className="input-group-text"
                          htmlFor="essayImage"
                        >
                          Browse
                        </label>
                        <input
                          type="file"
                          id="essayImage"
                          accept=".svg, .jpg, .jpeg, .png"
                          {...register("essayImage")}
                          onChange={handleImageChange}
                          className="form-control d-none"
                        />
                      </div>
                      {errors.essayImage && (
                        <p className="text-danger">
                          {errors.essayImage.message}
                        </p>
                      )}
                    </div>
                    {image && (
                      <div className="mt-3 position-relative">
                        <div className="d-flex justify-content-end">
                          <button
                            type="button"
                            className="btn btn-outline-danger btn-sm"
                            onClick={handleRemoveImage}
                            style={{ zIndex: 1 }}
                          >
                            <Delete />
                          </button>
                        </div>
                        <div className="mt-1">
                          <img
                            src={image}
                            alt="Uploaded Essay"
                            className="img-thumbnail"
                            style={{ width: "614.2px", height: "342.93px" }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="col-md-12">
                    <div className="form_group  d-flex justify-content-end">
                      <button className="submit_btn m-2" type="submit">
                        Submit
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </Modal>
            <div className="col-md-6">
              <div className="form-group">
                <label htmlFor="response">Response</label>
                <textarea
                  id="response"
                  className="form-control"
                  // rows="6"
                  rows={image === null ? "6" : "18"}
                  value={
                    GradeEssayResponse.length === 0
                      ? // <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                        "No Data"
                      : GradeEssayResponse
                  }
                  readOnly
                />
              </div>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label htmlFor="essayImage p-1">Upload Essay Image</label>
                <div className="input-group p-1">
                  <input
                    type="text"
                    className="form-control"
                    value={imageName}
                    readOnly
                  />
                  <label className="input-group-text" htmlFor="essayImage">
                    Browse
                  </label>
                  <input
                    type="file"
                    id="essayImage"
                    accept=".svg, .jpg, .jpeg, .png"
                    {...register("essayImage")}
                    onChange={handleImageChange}
                    className="form-control d-none"
                  />
                </div>
                {errors.essayImage && (
                  <p className="text-danger">{errors.essayImage.message}</p>
                )}
              </div>
              {image && (
                <div className="mt-3 position-relative">
                  <div className="d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-outline-danger btn-sm"
                      onClick={handleRemoveImage}
                      style={{ zIndex: 1 }}
                    >
                      <Delete />
                    </button>
                  </div>
                  <div className="mt-1">
                    <img
                      src={image}
                      alt="Uploaded Essay"
                      className="img-thumbnail"
                      style={{ width: "614.2px", height: "342.93px" }}
                    />
                  </div>
                </div>
              )}
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label htmlFor="response">Response</label>
                <textarea
                  id="response"
                  className="form-control"
                  // rows="6"
                  rows={image === null ? "6" : "18"}
                  value={
                    GradeEssayResponse.length === 0
                      ? // <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                        "No Data"
                      : GradeEssayResponse
                  }
                  readOnly
                />
              </div>
            </div>
            <div className="col-md-12  ">
              <div className="form_group ">
                <button className="submit_btn m-2" type="submit">
                  Submit
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </>
  );
};

export default EssayGrade;
