import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { handleKeyDown } from "../../../utilities/handleKeyDown";
import "bootstrap/dist/css/bootstrap.min.css";
import Slider from "@mui/material/Slider";
import Typography from "@mui/material/Typography";
import { Box, TextField } from "@mui/material";
import { useDispatch } from "react-redux";
import {
  addEssayGenerator,
  getEssayGenratorJson,
  resetEssay,
} from "../../../redux/sllices/essayGeneratorSlice";
import { useSelector } from "react-redux";
import { Button, Empty, Modal } from "antd";
import Loader from "../../Loader";

// const jsonData = [
//   {
//     Attribute: {
//       Name: "Age",
//       Type: "Slider",
//       MinValue: "8",
//       MaxValue: "40",
//       required: true,
//     },
//   },
//   {
//     Attribute: {
//       Name: "WordLimit",
//       Type: "Slider",
//       MinValue: "50",
//       MaxValue: "200",
//       required: true,
//     },
//   },
//   {
//     Attribute: {
//       Name: "Thematic",
//       Type: "CheckBoxCollection",
//       required: true,
//     },
//     Values: ["Holiday", "Race", "Weekend", "FamilyTrip"],
//   },
//   {
//     Attribute: {
//       Name: "Person",
//       Type: "RadioBoxCollection",
//       required: true,
//     },
//     Values: ["FirstPerson", "SecondPerson"],
//   },
//   {
//     Attribute: {
//       Name: "Voice",
//       Type: "RadioBoxCollection",
//       required: true,
//     },
//     Values: ["Active", "Passive"],
//   },
// ];

const EssayGenerator = () => {
  const jsonData =
    useSelector((state) => state?.root?.essay?.essayGeneratordata) || [];
  const IsLoading = useSelector((state) => state?.root?.essay?.loading);

  // console.log(jsonData11, IsLoading, "jsonData11");
  const [showModal, setShowModal] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    clearErrors();
  };

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768); // Adjust the breakpoint as needed
      if (!isMobile && showModal) {
        setShowModal(false); // Close modal if not mobile view
      }
    };

    handleResize(); // Call the function to set initial state
    window.addEventListener("resize", handleResize); // Listen for resize events
    return () => window.removeEventListener("resize", handleResize); // Cleanup
  }, [showModal]); // Ensure the effect runs when showModal changes
  const GerateEssayResponse = useSelector(
    (state) => state?.root?.essay?.addEssaydata
  );

  const validationSchema = Yup.object().shape({
    essaytopic: Yup.string().required("Essay Topic is required*."),
    ...Object.assign(
      {},
      ...jsonData?.map((item) => {
        if (item.Attribute.required) {
          switch (item.Attribute.Type) {
            case "Slider":
              return {
                [item.Attribute.Name]: Yup.number()
                  .min(parseInt(item.Attribute.MinValue))
                  .max(parseInt(item.Attribute.MaxValue))
                  .required(`${item.Attribute.Name} is required*.`),
              };
            case "CheckBoxCollection":
              return {
                [item.Attribute.Name]: Yup.array()
                  .min(1, `${item.Attribute.Name} is required*.`)
                  .required(`${item.Attribute.Name} is required*.`),
              };
            case "RadioBoxCollection":
              return {
                [item.Attribute.Name]: Yup.string()
                  .oneOf(item.Values, `${item.Attribute.Name} is required*.`)
                  .required(`${item.Attribute.Name} is required*.`),
              };
            default:
              return {};
          }
        } else {
          return {};
        }
      })
    ),
  });

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getEssayGenratorJson());
  }, []);

  useEffect(() => {
    dispatch(resetEssay());
  }, []);

  const {
    register,
    handleSubmit,
    control,
    clearErrors,
    watch,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onSubmit = (data) => {
    const transformedData = {
      "prompt-parms": [
        ...jsonData
          ?.map((item) => {
            switch (item.Attribute.Type) {
              case "Slider":
                return {
                  attribute: item.Attribute.Name,
                  values: [data[item.Attribute.Name]],
                };
              case "CheckBoxCollection":
                const thematicValues = data[item.Attribute.Name] || [];
                return {
                  attribute: item.Attribute.Name,
                  values: thematicValues,
                };
              case "RadioBoxCollection":
                return {
                  attribute: item.Attribute.Name,
                  values: [data[item.Attribute.Name]],
                };
              default:
                return null;
            }
          })
          .filter((item) => item !== null), // Filter out any null values
        {
          attribute: "essayTopic",
          values: [data.essaytopic.toLowerCase()],
        },
      ],
    };

    dispatch(addEssayGenerator(transformedData, reset, setShowModal));
  };

  const renderField = (attribute, values) => {
    switch (attribute.Type) {
      case "Slider":
        return (
          <div className="form-field" key={attribute.Name}>
            <label>
              {attribute.Name}
              <span>*</span>
            </label>
            <Controller
              name={attribute.Name}
              control={control}
              defaultValue={parseInt(attribute.MinValue)}
              render={({ field }) => (
                <CustomSlider
                  {...field}
                  attribute={attribute}
                  value={field.value}
                />
              )}
            />
            {errors[attribute.Name] && (
              <p className="text-danger">{errors[attribute.Name].message}</p>
            )}
          </div>
        );
      case "CheckBoxCollection":
        return (
          <div className="form-field" key={attribute.Name}>
            <label>
              {attribute.Name}
              <span>*</span>
            </label>
            <div className="d-flex flex-wrap p-1">
              {values.map((value) => (
                <div className="form-check w-50" key={value}>
                  <input
                    type="checkbox"
                    value={value}
                    {...register(attribute.Name)}
                    className="form-check-input"
                  />
                  <label className="form-check-label">{value}</label>
                </div>
              ))}
            </div>
            {errors[attribute.Name] && (
              <p className="text-danger">
                {errors[attribute.Name].message ===
                  "Thematic must be a `array` type, but the final value was: `false`." &&
                  "Please choose an any one  option"}
              </p>
            )}
          </div>
        );

      case "RadioBoxCollection":
        return (
          <div className="form-field" key={attribute.Name}>
            <label className="p-1">
              {attribute.Name}
              <span>*</span>
            </label>
            {values.map((value) => (
              <div className="form-check" key={value}>
                <input
                  type="radio"
                  value={value}
                  {...register(attribute.Name)}
                  className="form-check-input"
                />
                <label className="form-check-label">{value}</label>
              </div>
            ))}
            {errors[attribute.Name] && (
              <p className="text-danger">{errors[attribute.Name].message}</p>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  const CustomSlider = ({ attribute, value, ...rest }) => {
    const handleChange = (_, newValue) => {
      rest.onChange(newValue);
    };

    return (
      <Box sx={{ display: "flex", flexDirection: "column", alignItems: "end" }}>
        <Slider
          value={value}
          onChange={handleChange}
          min={parseInt(attribute.MinValue)}
          max={parseInt(attribute.MaxValue)}
          step={1}
          valueLabelDisplay="auto"
        />
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <Typography variant="body2">{attribute.MinValue}</Typography>
          <Typography variant="body2">{attribute.MaxValue}</Typography>
        </Box>
        <TextField
          id="outlined-basic"
          value={value}
          size="small"
          sx={{ width: 70, textAlign: "center" }}
          disabled
        />
      </Box>
    );
  };

  return (
    <>
      {IsLoading ? (
        <Loader />
      ) : (
        <div className="container mt-2">
          {isMobile ? (
            <div className="row">
              <div className="create-btn-div text-end">
                <button
                  className="CreateEssay"
                  variant="contained"
                  onClick={openModal}
                >
                  Create Essay
                </button>
              </div>
              <Modal open={showModal} onCancel={closeModal} footer={null}>
                <div className="container mt-2">
                  <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="row">
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="p-1">
                            Essay Topic
                            <span>*</span>
                          </label>
                          <input
                            name="essaytopic"
                            {...register("essaytopic")}
                            placeholder="Enter an essay topic"
                            onKeyDown={handleKeyDown}
                            type="text"
                            className="form-control"
                          />
                          {errors.essaytopic && (
                            <p className="text-danger">
                              {errors.essaytopic.message}
                            </p>
                          )}
                        </div>

                        {jsonData &&
                          jsonData.length > 0 &&
                          jsonData?.map((item) => (
                            <div className="mb-3" key={item.Attribute.Name}>
                              <div className="card">
                                <div className="card-body">
                                  {renderField(item.Attribute, item.Values)}
                                </div>
                              </div>
                            </div>
                          ))}

                        <div className="form_group text-end ">
                          <button className="submit_btn" type="submit">
                            Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </Modal>
              <div className="col-md-6">
                <div className="mb-3">
                  <label>Response:</label>
                  <textarea
                    className="form-control"
                    rows={Object.keys(errors).length === 0 ? "30" : "36"}
                    value={
                      GerateEssayResponse.length === 0
                        ? // <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                          "No Data"
                        : GerateEssayResponse
                    }
                    readOnly
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="row">
              <div className="col-md-6">
                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="mb-3">
                    <label>
                      Essay Topic
                      <span>*</span>
                    </label>
                    <input
                      name="essaytopic"
                      {...register("essaytopic")}
                      placeholder="Enter an essay topic"
                      onKeyDown={handleKeyDown}
                      type="text"
                      className="form-control"
                    />
                    {errors.essaytopic && (
                      <p className="text-danger">{errors.essaytopic.message}</p>
                    )}
                  </div>

                  {jsonData &&
                    jsonData.length > 0 &&
                    jsonData?.map((item) => (
                      <div className="mb-3" key={item.Attribute.Name}>
                        <div className="card">
                          <div className="card-body">
                            {renderField(item.Attribute, item.Values)}
                          </div>
                        </div>
                      </div>
                    ))}

                  <div className="form_group text-end ">
                    <button className="submit_btn" type="submit">
                      Submit
                    </button>
                  </div>
                </form>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label>Response:</label>
                  <textarea
                    className="form-control"
                    rows={Object.keys(errors).length === 0 ? "31" : "37"}
                    value={
                      GerateEssayResponse.length === 0
                        ? // <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                          "No Data"
                        : GerateEssayResponse
                    }
                    readOnly
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default EssayGenerator;
