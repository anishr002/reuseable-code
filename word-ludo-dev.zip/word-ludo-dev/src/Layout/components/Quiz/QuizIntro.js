import React, { useEffect, useState } from "react";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { Link, NavLink, useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import Loader from "../../Loader";
import { useDispatch } from "react-redux";
import { getsingleUserQuizDetails } from "../../../redux/sllices/quizSlice";

const QuizIntro = () => {
  const [randNumber, setrandNumber] = useState(Math.floor(Math.random() * 101));
  const { id } = useParams();
  const dispatch = useDispatch();
  const data = useSelector((state) => state?.root?.quiz?.singleuserQuiz);
  const { loading } = useSelector((state) => state?.root?.quiz);
  const navigate = useNavigate();

  useEffect(() => {
    dispatch(getsingleUserQuizDetails(id));
  }, [id]);

  const StartQuiz = () => {
    localStorage.setItem("num", randNumber);
    navigate("/quiz-questions");
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="quiz_detail">
          <div className="container">
            <NavLink to="/new-quiz" className="back-btn-link">
              <svg
                width="48"
                height="48"
                viewBox="0 0 48 48"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="48" height="48" rx="24" fill="#00509D" />
                <path
                  d="M31 24.0001H17M17 24.0001L24 31M17 24.0001L24 17"
                  stroke="white"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </NavLink>

            <div className="clearfix"></div>
            <h1>{data[0]?.quizName}</h1>
            <p>{data[0]?.description}</p>
            <div className="text_cnt">
              <h6>Let's Play !</h6>
              <button className="btn" onClick={StartQuiz}>
                Start Quiz
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="clearfix"></div>
    </>
  );
};

export default QuizIntro;
