import React, { useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
// import OtherHousesOutlinedIcon from "@mui/icons-material/OtherHousesOutlined";
// import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import { useDispatch, useSelector } from "react-redux";
import {
  getResult,
  getsingleUserQuizDetails,
  resetData,
} from "../../../redux/sllices/quizSlice";
import Loader from "../../Loader";
import trophy from "../../../../src/assets/images/trophy_img.svg";

const QuizResult = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const data = useSelector((state) => state?.root?.quiz?.resultdata);
  const { loading } = useSelector((state) => state?.root?.quiz);
  const attemptquizId = useSelector(
    (state) => state?.root?.quiz?.addquizAnswer?._id
  );
  const quizId = useSelector(
    (state) => state?.root?.quiz?.addquizAnswer?.quizId
  );

  // useEffect(() => {
  //   dispatch(getResult(attemptquizId));
  // }, [dispatch, attemptquizId]);

  useEffect(() => {
    if (attemptquizId) {
      dispatch(getResult(attemptquizId));
    }
  }, [dispatch, attemptquizId]);

  useEffect(() => {
    dispatch(getResult(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  window.addEventListener("beforeunload", () => {
    dispatch(getResult(null));
    dispatch(resetData());
  });

  const resultPercentage =
    (data[0]?.rightQuestions / data[0]?.totalQuestions) * 100;

  const SingleUserQuiz = () => {
    dispatch(getsingleUserQuizDetails(quizId));
    navigate("/quiz-intro");
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          {" "}
          <div className="container text-center">
            <div className="result_box">
              <img className="trophy_img" src={trophy} alt="" />

              <h2>
                {" "}
                {resultPercentage <= 50
                  ? "Well Done"
                  : resultPercentage > 50 && resultPercentage <= 80
                  ? "Great Work"
                  : "You are a star"}
              </h2>
              <p>Your score for this page is</p>
              {data &&
                data.length > 0 &&
                data?.map((result, i) => {
                  return (
                    <h3>
                      {result?.rightQuestions}/{result?.totalQuestions}
                    </h3>
                  );
                })}

              <button
                className="play_btn"
                onClick={() => navigate(`/quiz-intro/${quizId}`)}
              >
                Play Again
                <svg
                  width="25"
                  height="24"
                  viewBox="0 0 25 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12.5 22C18.0228 22 22.5 17.5228 22.5 12C22.5 6.47715 18.0228 2 12.5 2C6.97715 2 2.5 6.47715 2.5 12C2.5 17.5228 6.97715 22 12.5 22Z"
                    stroke="#00509D"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M10.5 8L16.5 12L10.5 16V8Z"
                    stroke="#00509D"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
              </button>
              <NavLink className="my_quz_btn" to="/my-quiz">
                My Quiz
              </NavLink>
            </div>
            <div className="back_home_btn">
              <NavLink to="/home">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z"
                    stroke="white"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
                Back to Home
              </NavLink>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default QuizResult;
