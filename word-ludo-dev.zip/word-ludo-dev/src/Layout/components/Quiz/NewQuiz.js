import React, { useRef, useState } from "react";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  getUserQuiz,
  getsingleUserQuizDetails,
  resetData,
} from "../../../redux/sllices/quizSlice";
import { useEffect } from "react";
import moment from "moment/moment";
import InfiniteScroll from "react-infinite-scroll-component";
import Loader from "../../Loader";

const NewQuiz = () => {
  const data = useSelector((state) => state?.root?.quiz?.data);
  const totalQuiz = useSelector((state) => state?.root?.quiz?.totalQuiz);
  const { loading } = useSelector((state) => state?.root?.quiz);
  // let page = 1;
  const [pageLimit, setpageLimit] = useState(10);
  const [page, setPage] = useState(1);
  const [hasMore, sethasMore] = useState(true);
  const location = useLocation();
  const fetchData = async () => {
    sethasMore(true);
    if (data.length < totalQuiz) {
      dispatch(getUserQuiz(page + 1, pageLimit));
      setPage((prevPage) => prevPage + 1);
    } else {
      sethasMore(false);
    }
  };

  useEffect(() => {
    dispatch(resetData());
  }, [location.pathname]);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  window.addEventListener("beforeunload", () => {
    dispatch(resetData());
  });

  useEffect(() => {
    dispatch(getUserQuiz(page, pageLimit));
  }, []);

  const SingleUserQuiz = (o) => {
    dispatch(getsingleUserQuizDetails(o?._id));
    navigate("/quiz-intro");
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div>
          {data && data?.length > 0 ? (
            <InfiniteScroll
              dataLength={data?.length}
              next={fetchData}
              hasMore={hasMore}
              loader={<Loader />}
            >
              {data?.map((o, i) => {
                return (
                  <div
                    key={i}
                    className="quiz_box"
                    onClick={() => navigate(`/quiz-intro/${o?._id}`)}
                  >
                    <div>
                      <h2>{o?.quizName}</h2>
                      <p>
                        Expire on : {moment(o?.expireDate).format("DD/MM/YYYY")}
                      </p>
                    </div>
                    <span>
                      <svg
                        width="40"
                        height="40"
                        viewBox="0 0 40 40"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M19.9999 36.6666C29.2047 36.6666 36.6666 29.2047 36.6666 19.9999C36.6666 10.7952 29.2047 3.33325 19.9999 3.33325C10.7952 3.33325 3.33325 10.7952 3.33325 19.9999C3.33325 29.2047 10.7952 36.6666 19.9999 36.6666Z"
                          stroke="#00509D"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                        <path
                          d="M16.6666 13.3333L26.6666 19.9999L16.6666 26.6666V13.3333Z"
                          stroke="#00509D"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </span>
                  </div>
                );
              })}
            </InfiniteScroll>
          ) : (
            <p>No Quiz Found</p>
          )}
        </div>
      )}
    </>
  );
};

export default NewQuiz;
