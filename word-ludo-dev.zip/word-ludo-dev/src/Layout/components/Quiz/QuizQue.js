import React from "react";
import ProgressBar from "../ProgressBar";
import Question from "./Question";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const QuizQue = () => {
  const data = useSelector(
    (state) => state?.root?.quiz?.singleuserQuiz[0]?.questionsData
  );
  const navigate = useNavigate();
  const gobackHandler = () => {
    navigate(-1);
    // const backId = window.location.pathname.split('/')[2]
    // console.log(id,backId)
  };
  return (
    <div className="container">
      <span className="back-btn-link">
        <svg
          width="48"
          height="48"
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            width="48"
            height="48"
            rx="24"
            fill="#00509D"
            style={{ cursor: "pointer" }}
            onClick={gobackHandler}
          />
          <path
            d="M31 24.0001H17M17 24.0001L24 31M17 24.0001L24 17"
            stroke="white"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </span>
      <Question data={data} />
    </div>
  );
};

export default QuizQue;
