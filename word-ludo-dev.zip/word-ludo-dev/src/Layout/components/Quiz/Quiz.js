import * as React from "react";
import { useState } from "react";
import NewQuiz from "./NewQuiz";
import MyQuiz from "./MyQuiz";
import { Button } from "@mui/material";
import { useDispatch } from "react-redux";
import { resetData } from "../../../redux/sllices/quizSlice";

const Quiz = () => {
  const [value, setValue] = useState("newQuiz");
  const url = window.location.href.split("/")[3];
  const dispatch = useDispatch();
  React.useEffect(() => {
    if (url === "new-quiz") {
      setValue("newQuiz");
    } else if (url === "my-quiz") {
      setValue("myQuiz");
    }
  }, [url]);

  return (
    <>
      <div className="quiz_main_page">
        <div className="container">
          <div className="top_button ">
            <Button
              className={value === "newQuiz" ? "active" : ""}
              onClick={() => setValue("newQuiz")}
            >
              New Quiz
            </Button>

            <Button
              className={value === "myQuiz" ? "active" : ""}
              onClick={() => setValue("myQuiz")}
            >
              My Quiz
            </Button>
          </div>
          <div className="quiz_list">
            {value === "newQuiz" ? <NewQuiz /> : <MyQuiz />}
          </div>
          <div className="clearfix"></div>
        </div>
      </div>
      <div className="clearfix"></div>
    </>
  );
};

export default Quiz;
