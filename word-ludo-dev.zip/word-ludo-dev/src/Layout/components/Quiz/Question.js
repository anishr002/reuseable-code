import React from "react";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import { useState } from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addUserAnswer, getResult } from "../../../redux/sllices/quizSlice";
import { useNavigate } from "react-router-dom";
// import { LinearProgress } from '@mui/material';
import ProgressBar from "../ProgressBar";
import { ToastContent } from "../ToastContent";
import { toast } from "react-toastify";
import Loader from "../../Loader";

const Question = ({ data }) => {
  const dispatch = useDispatch();

  const quizId = useSelector(
    (state) => state?.root?.quiz?.singleuserQuiz[0]._id
  );
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const TotalQuestion = data.length;

  const { loading } = useSelector((state) => state?.root?.quiz);
  const [answerByUser, setanswerByUser] = useState("");
  const [questionId, setquestionId] = useState();
  const navigate = useNavigate();
  const questionid = data[currentQuestion]?._id;
  const quizPlayCount = localStorage.getItem("num");
  const [questionsData, setquestionsData] = useState([]);

  // useEffect(() => {
  //   localStorage.setItem("answer", JSON.stringify(questionsData));
  // }, [questionsData]);

  useEffect(() => {
    setquestionId(questionid);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data[currentQuestion]?._id]);

  const handleChange = (event) => {
    let inputData = event.target.value.replace(/\n/g, "");
    setanswerByUser(inputData);
    // return allMovieData;
  };
  const isQuestionLast = currentQuestion === data.length - 1;
  const handleNextClick = () => {
    const isSkipped = false;
    const isCompleted = true;
    const isQuestionLast = currentQuestion === data.length - 1;

    setquestionsData((prev) => [
      ...prev,
      {
        answerByUser,
        questionId,
        isSkipped,
        isCompleted,
      },
    ]);

    setCurrentQuestion(currentQuestion + 1);
    setanswerByUser("");
    if (currentQuestion === data.length - 1) {
      // toast.success(<ToastContent message="Quiz submitted successfully" />, {
      //   position: "top-right",
      //   autoClose: 2000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "light",
      // });
      navigate("/quiz-result");
    }
  };

  const handleSkipClick = () => {
    const isSkipped = true;
    const isCompleted = false;
    const answerByUser = isSkipped ? "" : answerByUser;
    const isQuestionLast = currentQuestion === data.length - 1;
    setquestionsData((prev) => [
      ...prev,
      {
        answerByUser,
        questionId,
        isSkipped,
        isCompleted,
      },
    ]);

    setCurrentQuestion(currentQuestion + 1);
    setanswerByUser("");

    if (isQuestionLast) {
      const isSkipped = true;
      const isCompleted = false;
      const answerByUser = isSkipped ? "" : answerByUser;

      setquestionsData((prev) => [
        ...questionsData,
        {
          answerByUser,
          questionId,
          isSkipped,
          isCompleted,
        },
      ]);
    }

    let questionDummyData = [
      ...questionsData,
      {
        answerByUser,
        questionId,
        isSkipped,
        isCompleted,
      },
    ];

    if (isQuestionLast) {
      dispatch(addUserAnswer(questionDummyData, quizId));

      navigate("/quiz-result");
    }
  };
  useEffect(() => {
    dispatch(addUserAnswer(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = () => {
    if (isQuestionLast) {
      const isSkipped = false;
      const isCompleted = true;
      setquestionsData((prev) => [
        ...questionsData,
        {
          answerByUser,
          questionId,
          isSkipped,
          isCompleted,
        },
      ]);
    }
    const isSkipped = false;
    const isCompleted = true;
    let questionDummyData = [
      ...questionsData,
      {
        answerByUser,
        questionId,
        isSkipped,
        isCompleted,
      },
    ];
    dispatch(addUserAnswer(questionDummyData, quizId));

    navigate("/quiz-result");
  };

  const progress = Math.round((currentQuestion / TotalQuestion) * 100);
  const Count = currentQuestion + 1 + "/" + TotalQuestion;
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="container">
          <ProgressBar progress={progress} Count={Count} />
          <FormControl className="question_box">
            <h4 className="qust_title" id="demo-controlled-radio-buttons-group">
              {data[currentQuestion]?.questionText}
            </h4>
            {data[currentQuestion]?.questionType === "multiplechoice" ? (
              <RadioGroup
                className="radio_box"
                aria-labelledby="demo-radio-buttons-group-label"
                value={answerByUser}
                onChange={handleChange}
                name="answerByUser"
              >
                <FormControlLabel
                  value={data[currentQuestion]?.options[0]}
                  control={<Radio />}
                  label={data[currentQuestion]?.options[0]}
                />

                <FormControlLabel
                  value={data[currentQuestion]?.options[1]}
                  control={<Radio />}
                  label={data[currentQuestion]?.options[1]}
                />
                <FormControlLabel
                  value={data[currentQuestion]?.options[2]}
                  control={<Radio />}
                  label={data[currentQuestion]?.options[2]}
                />
                <FormControlLabel
                  value={data[currentQuestion]?.options[3]}
                  control={<Radio />}
                  label={data[currentQuestion]?.options[3]}
                />
                <FormControlLabel
                  value={data[currentQuestion]?.options[4]}
                  control={<Radio />}
                  label={data[currentQuestion]?.options[4]}
                />
              </RadioGroup>
            ) : (
              // <input className="ans_txt" type="text" onChange={handleChange} />
              <textarea
                className="ans_txt"
                value={answerByUser}
                cols="30"
                rows="10"
                onChange={handleChange}
              ></textarea>
            )}
          </FormControl>

          <div className="next_skip_btn">
            {isQuestionLast ? (
              <button
                className="next_btn"
                disabled={!answerByUser}
                onClick={handleSubmit}
              >
                Submit{" "}
              </button>
            ) : (
              <button
                disabled={!answerByUser}
                onClick={handleNextClick}
                className="next_btn"
              >
                Next
              </button>
            )}
            <button className="skip_btn" onClick={handleSkipClick}>
              Skip
            </button>
          </div>
          <div className="clearfix"></div>
        </div>
      )}
    </>
  );
};

export default Question;
