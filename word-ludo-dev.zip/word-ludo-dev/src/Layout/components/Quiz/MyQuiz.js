import React, { useEffect, useState } from "react";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import check_img from "../../../../src/assets/images/chekbox.svg";
import clox_img from "../../../../src/assets/images/close.svg";
import {
  getMyQuiz,
  getsingleUserQuizDetails,
  resetData,
} from "../../../redux/sllices/quizSlice";
import Loader from "../../Loader";
import InfiniteScroll from "react-infinite-scroll-component";

const MyQuiz = () => {
  const myData = useSelector((state) => state?.root?.quiz?.myquizdata);
  const totalQuiz = useSelector((state) => state?.root?.quiz?.totalQuiz);
  const { loading } = useSelector((state) => state?.root?.quiz);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [pageLimit, setpageLimit] = useState(10);
  const [page, setPage] = useState(1);
  const [hasMore, sethasMore] = useState(true);

  const fetchData = async () => {
    sethasMore(true);
    console.log(myData.length < totalQuiz, totalQuiz, myData.length, "2777");
    if (myData.length < totalQuiz) {
      dispatch(getMyQuiz(page + 1, pageLimit));
      setPage((prevPage) => prevPage + 1);
    } else {
      sethasMore(false);
    }
  };

  window.addEventListener("beforeunload", () => {
    dispatch(resetData());
  });
  useEffect(() => {
    dispatch(getMyQuiz(page, pageLimit));
  }, []);
  const SingleUserQuiz = (o) => {
    dispatch(getsingleUserQuizDetails(o.quizData._id));
    navigate("/quiz-intro");
  };

  const styles = {
    wordBreak: "break-word",
  };
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div>
          {myData && myData?.length > 0 ? (
            <InfiniteScroll
              dataLength={myData?.length}
              next={fetchData}
              hasMore={hasMore}
              loader={<Loader />}
            >
              {myData?.map((o, i) => {
                return (
                  <div
                    key={i}
                    className="my_quiz_box"
                    onClick={() => navigate(`/quiz-intro/${o?.quizData._id}`)}
                  >
                    <div className="d-flex align-items-center">
                      <h1>
                        {o.rightQuestions} <span>/ {o.totalQuestions}</span>
                      </h1>
                      <div className="ps-3 pe-2">
                        <h2 style={styles}>{o?.quizData?.quizName}</h2>
                        <p className="attem_txt">
                          Question Attempt: {o.attemptedQuestions}
                        </p>
                        <p className="right_wrong_txt">
                          <span>
                            <img src={check_img} alt="" /> {o.rightQuestions}
                          </span>
                          <span>
                            <img src={clox_img} alt="" />{" "}
                            {o.totalQuestions - o.rightQuestions}
                          </span>
                        </p>
                      </div>
                    </div>
                    <div>
                      <span>
                        <svg
                          width="40"
                          height="40"
                          viewBox="0 0 40 40"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M19.9999 36.6666C29.2047 36.6666 36.6666 29.2047 36.6666 19.9999C36.6666 10.7952 29.2047 3.33325 19.9999 3.33325C10.7952 3.33325 3.33325 10.7952 3.33325 19.9999C3.33325 29.2047 10.7952 36.6666 19.9999 36.6666Z"
                            stroke="#00509D"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          />
                          <path
                            d="M16.6666 13.3333L26.6666 19.9999L16.6666 26.6666V13.3333Z"
                            stroke="#00509D"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          />
                        </svg>
                      </span>
                    </div>
                  </div>
                );
              })}
            </InfiniteScroll>
          ) : (
            <p>No Quiz Found</p>
          )}
        </div>
      )}
    </>
  );
};

export default MyQuiz;
