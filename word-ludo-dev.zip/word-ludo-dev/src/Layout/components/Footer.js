import React from "react";
const privacyPolicyUrl = `${process.env.REACT_APP_AUDIO_URL}/media/staticFiles/Privacy%20Policy.pdf`;

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <div>
      <div className="container">
        <div className="footer-content">
          {/* Privacy Policy Link */}
          <div className="footer-links">
            <a
              href={privacyPolicyUrl}
              className="privacy-policy-link"
              target="_blank"
              rel="noopener noreferrer"
            >
              Privacy Policy
            </a>
          </div>

          {/* All Rights Reserved Text */}
          <div className="footer-rights">
            <p>© {currentYear} Word Ludo, All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
