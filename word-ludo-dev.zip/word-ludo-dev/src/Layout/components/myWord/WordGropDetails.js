import React, { useEffect, useState } from "react";
import SearchInput from "../SearchInput";
import Loader from "../../Loader";
import Swal from "sweetalert2";
import { Empty } from "antd";
import {
  deleteSaveGroup,
  deleteSaveWord,
  getAllGroup,
  getGroupDetail,
  getWordgroupdetails,
} from "../../../redux/sllices/saveWordAndGroupSlice";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const WordGropDetails = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const groupList = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupList
  );
  const loading = useSelector(
    (state) => state?.root?.saveWordAndGroup?.loading
  );
  const wordList = useSelector(
    (state) => state?.root?.saveWordAndGroup?.saveWordList
  );
  const wordgroupWord = useSelector(
    (state) => state?.root?.saveWordAndGroup?.wordGroupdetails
  );
  const [activeindex, setActiveindex] = useState(0);

  // console.log(wordgroupWord, "wordgroupWord");
  useEffect(() => {
    dispatch(getAllGroup(false));
    // dispatch(getSaveWord(""));
  }, [dispatch]);

  //Delete Word Group API
  const showAlert = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this Word Group",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      confirmButtonColor: "red",
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(deleteSaveGroup(id));
      }
    });
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="my_word_box pt-0">
            <div className="container">
              <h1>My Words</h1>
              <SearchInput />
            </div>
          </div>

          <div className="clearfix"></div>
          <div className="saveword_group_box">
            <div className="container">
              <div className="inner_box">
                <h2>Word Group</h2>
                <div className="word_list">
                  {groupList.length > 0 ? (
                    groupList?.map((o, i) => {
                      return (
                        <div key={o._id} className="list_line1">
                          <p
                            onClick={() =>
                              //   navigate(`/my-group?groupid=${o._id}`)
                              dispatch(getWordgroupdetails(o?._id))
                            }
                          >
                            {o.groupName}{" "}
                          </p>
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 16 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            onClick={() => showAlert(o._id)}
                            className="c-pointer"
                          >
                            <path
                              d="M12 4L4 12M4 4L12 12"
                              stroke="#090A0A"
                              stroke-width="1.5"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>{" "}
                        </div>
                      );
                    })
                  ) : (
                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="clearfix"></div>

          <div className="saveword_group_box">
            <div className="container">
              <div className="inner_box">
                <div className="word_list">
                  <div className="list_line">
                    <button
                    // className={activeindex == i && "active"}
                    // onClick={() => {
                    //   handleFilterWord(o);
                    //   setActiveindex(i);
                    // }}
                    >
                      All
                    </button>
                  </div>
                  {wordgroupWord?.wordData?.map((o, i) => {
                    return (
                      <div key={i} className="list_line">
                        <button
                        // className={activeindex == i && "active"}
                        // onClick={() => {
                        //   handleFilterWord(o);
                        //   setActiveindex(i);
                        // }}
                        >
                          {o?.wordCapital}
                        </button>
                      </div>
                    );
                  })}
                </div>

                <h2>My Saved Words</h2>
                <div className="word_list">
                  {wordgroupWord?.wordData?.length > 0 ? (
                    wordgroupWord?.wordData?.map((o) => {
                      return (
                        <div key={o._id} className="list_line1">
                          <p
                            onClick={() => navigate(`/word-details/${o?._id}`)}
                          >
                            {o?.word}{" "}
                          </p>
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 16 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            onClick={() => dispatch(deleteSaveWord(o._id, ""))}
                            className="c-pointer"
                          >
                            <path
                              d="M12 4L4 12M4 4L12 12"
                              stroke="#090A0A"
                              stroke-width="1.5"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>{" "}
                        </div>
                      );
                    })
                  ) : (
                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="clearfix"></div>
        </>
      )}
    </>
  );
};

export default WordGropDetails;
