import React, { useEffect, useState } from "react";
import WordGroups from "./WordGroups";
import SavedWords from "./SavedWords";
import SearchInput from "../SearchInput";
import { useDispatch, useSelector } from "react-redux";
import {
  getAllGroup,
  getSaveWord,
  resetGroupdetails,
} from "../../../redux/sllices/saveWordAndGroupSlice";
import Loader from "../../Loader";
import { useLocation } from "react-router-dom";

const MyWord = () => {
  const dispatch = useDispatch();
  const groupList = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupList
  );
  const location = useLocation();

  const GroupDetails = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupDetail
  );
  // console.log(groupList, "17");
  const [isactive, setisActive] = useState([]);
  const [activeindex, setActiveindex] = useState(0);

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (groupList) {
      setisActive(groupList.map((e) => ({ ...e, active: false })));
    }
  }, [groupList]);
  const handleIsActive = (id) => {
    setisActive(
      isactive.map((e) =>
        e._id === id ? { ...e, active: true } : { ...e, active: false }
      )
    );
  };

  const loading = useSelector(
    (state) => state?.root?.saveWordAndGroup?.loading
  );
  const wordList = useSelector(
    (state) => state?.root?.saveWordAndGroup?.saveWordList
  );

  useEffect(() => {
    dispatch(resetGroupdetails());
  }, [location.pathname]);
  useEffect(() => {
    setIsLoading(true);
    dispatch(getAllGroup(false))
      .then(() => {
        setIsLoading(false);
      })
      .catch((error) => {
        setIsLoading(false);
      });
  }, [dispatch]);
  // console.log(GroupDetails, "46");
  return (
    <>
      {isLoading ? (
        <Loader />
      ) : (
        <>
          <div className="my_word_box pt-0">
            <div className="container">
              <h1>My Words</h1>
              <SearchInput />
            </div>
          </div>

          <div className="clearfix"></div>

          <div className="saveword_group_box">
            <div className="container">
              <WordGroups
                groupList={isactive}
                handleActive={handleIsActive}
                setActiveindex2={setActiveindex}
              />
            </div>
          </div>
          <div className="clearfix"></div>
          {GroupDetails?.wordData?.length >= 0 && (
            <div className="saveword_group_box">
              <div className="container">
                <SavedWords
                  GroupDetails={GroupDetails}
                  wordList={wordList}
                  activeindex={activeindex}
                  setActiveindex={setActiveindex}
                />
              </div>
            </div>
          )}

          <div className="clearfix"></div>
        </>
      )}
    </>
  );
};

export default MyWord;
