import React, { useEffect } from 'react';
import GroupWord from './GroupWord';
import SearchInput from '../SearchInput';
import { useDispatch, useSelector } from 'react-redux';
import { getGroupDetail } from '../../../redux/sllices/saveWordAndGroupSlice';
import { NavLink } from 'react-router-dom';
import Loader from '../../Loader';

const MyGroup = () => {
  const dispatch = useDispatch();
  const loading = useSelector(
    (state) => state?.root?.saveWordAndGroup?.loading
  );
  const groupId = window.location.search.split('id=')[1];

  const groupWord = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupDetail
  );
  useEffect(() => {
      dispatch(getGroupDetail(groupId, ''));
    
  }, [dispatch, groupId]);

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div>
          <div className="my_word_box pt-0">
            <div className="container">
              <div className="d-flex align-items-center mb-3">
                <NavLink to="/my-words" className="back-btn-link m-0">
                  <svg
                    width="48"
                    height="48"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="48" height="48" rx="24" fill="#00509D" />
                    <path
                      d="M31 24.0001H17M17 24.0001L24 31M17 24.0001L24 17"
                      stroke="white"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </NavLink>
                <h1 id="heading" className='m-0 p-0'>My Words</h1>
              </div>
              <SearchInput />
            </div>
          </div>

          <div className="saveword_group_box">
            <div className="container">
              <GroupWord wordList={groupWord} />
            </div>
          </div>
          <div className="clearfix"></div>
        </div>
      )}
    </>
  );
};

export default MyGroup;
