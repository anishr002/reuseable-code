// import { Card } from "@mui/material";
// import CloseIcon from "@mui/icons-material/Close";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteSaveWord } from "../../../redux/sllices/saveWordAndGroupSlice";
import Loader from "../../Loader";
import { Empty } from "antd";

const SavedWords = ({ wordList, setActiveindex, activeindex }) => {
  const userRole = localStorage.getItem("role");
  const token = localStorage.getItem("token");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const GroupDetails = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupDetail
  );
  const groupList = useSelector(
    (state) => state?.root?.saveWordAndGroup?.groupList
  );
  // console.log(GroupDetails, "16");
  const [wordLetter, setWordLetter] = useState([]);
  const [wordsList, setWordList] = useState(GroupDetails?.wordData);
  // const [activeindex, setActiveindex] = useState(0);
  const loading = useSelector(
    (state) => state?.root?.saveWordAndGroup?.loading
  );
  useEffect(() => {
    if (GroupDetails?.wordData?.length > 0) {
      setWordLetter([
        "All",
        ...GroupDetails?.wordData
          .map((item) => item.wordCapital)
          .filter((value, index, self) => self.indexOf(value) === index),
      ]);
    } else if (GroupDetails?.wordData?.length === 0) {
      setWordLetter([]);
    }
    setWordList(GroupDetails?.wordData);
  }, [GroupDetails?.wordData]);
  const handleFilterWord = (letter) => {
    if (letter === "All") {
      setWordList(GroupDetails?.wordData);
    } else {
      setWordList(
        GroupDetails?.wordData?.filter((e) => e.wordCapital === letter)
      );
    }
  };

  return (
    <>
      {/* {loading ? (
        <Loader />
      ) : ( */}
      <div className="inner_box">
        <div className="word_list">
          {wordLetter?.map((o, i) => {
            return (
              <div key={i} className="list_line">
                <button
                  className={activeindex == i && "active"}
                  onClick={() => {
                    handleFilterWord(o);
                    setActiveindex(i);
                  }}
                >
                  {o}
                </button>
              </div>
            );
          })}
        </div>
        <h2>My Saved Words</h2>

        <div className="word_list">
          {wordsList?.length > 0 ? (
            wordsList?.map((o) => {
              return (
                <div key={o._id} className="list_line1">
                  <p onClick={() => navigate(`/word-details/${o?._id}`)}>
                    {o?.word}{" "}
                  </p>
                  {userRole === "admin" && token && (
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 16 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      onClick={() =>
                        dispatch(
                          deleteSaveWord(
                            o?.saveWordId,
                            GroupDetails?.WordGroupData?._id,
                            setActiveindex
                          )
                        )
                      }
                      className="c-pointer"
                    >
                      <path
                        d="M12 4L4 12M4 4L12 12"
                        stroke="#090A0A"
                        stroke-width="1.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  )}
                  {userRole === "user" &&
                    token &&
                    !GroupDetails?.WordGroupData?.isPublic && (
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        onClick={() =>
                          dispatch(
                            deleteSaveWord(
                              o?.saveWordId,
                              GroupDetails?.WordGroupData?._id,
                              setActiveindex
                            )
                          )
                        }
                        className="c-pointer"
                      >
                        <path
                          d="M12 4L4 12M4 4L12 12"
                          stroke="#090A0A"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    )}
                </div>
              );
            })
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
      </div>
      {/* {/ )} /} */}
    </>
  );
};

export default SavedWords;
