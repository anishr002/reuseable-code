import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { deleteSaveWord } from '../../../redux/sllices/saveWordAndGroupSlice';
import Loader from '../../Loader';
import { Empty } from 'antd';

const GroupWord = ({ wordList }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector(
    (state) => state?.root?.saveWordAndGroup?.loading
  );
  const [arr, setArr] = useState([]);
  const [wordsList, setWordList] = useState(wordList?.wordData);
  const [activeindex, setActiveindex] = useState(0);
  const handleFilterWord = (e) => {
    if (e === 'All') {
      setWordList(wordList?.wordData);
    } else {
      setWordList(wordList?.wordData.filter((f) => f.wordCapital === e));
    }
  };
  const handleWord = (id) => {
    navigate(`/word-details/${id}`);
  };
  useEffect(() => {
    if (wordList?.wordData?.length > 0) {
      setArr([
        'All',
        ...wordList?.wordData
          .map((e) => e.wordCapital)
          .filter((value, index, self) => self.indexOf(value) === index),
      ]);
      setWordList(wordList?.wordData);
    }
  }, [wordList]);
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="inner_box">
          <h2>Words Save for {wordList?.WordGroupData?.groupName}</h2>
          <div className="word_list mb-4">
            {arr?.map((o, i) => {
              return (
                <div key={i} className="list_line">
                  <button
                    className={activeindex == i && 'active'}
                    onClick={() => {
                      handleFilterWord(o);
                      setActiveindex(i);
                    }}
                  >
                    {o}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="word_list">
            {wordsList?.length > 0 ? (
              wordsList?.map((o) => {
                return (
                  <div key={o._id} className="list_line1">
                    <p onClick={() => handleWord(o._id)}>{o.word} </p>
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 16 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      onClick={() =>
                        dispatch(
                          deleteSaveWord(
                            o.saveWordId,
                            wordList?.WordGroupData?._id
                          )
                        )
                      }
                    >
                      <path
                        d="M12 4L4 12M4 4L12 12"
                        stroke="#090A0A"
                        stroke-width="1.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>{' '}
                  </div>
                );
              })
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default GroupWord;
