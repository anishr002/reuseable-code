import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { editProfile, getProfile } from "../../redux/sllices/profileSlice";
import { useNavigate } from "react-router";
import { Logout, logoutdata } from "../../redux/sllices/authSlice";
import Loader from "../Loader";
import { googleLogout } from "@react-oauth/google";

const Profile = () => {
  const navigate = useNavigate();
  // eslint-disable-next-line no-unused-vars
  const [image, setImage] = useState(null);
  const dispatch = useDispatch();
  const data = useSelector((state) => state?.root?.profile?.data);
  const user = useSelector((state) => state?.root?.auth?.data);
  const isAdmin = user?.role?.name;

  const loading = useSelector((state) => state?.root?.profile?.loading);
  useEffect(() => {
    dispatch(getProfile());
  }, [dispatch]);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const fileReader = new FileReader();
    fileReader.addEventListener("load", () => {
      setImage(fileReader.result);
    });
    fileReader.readAsDataURL(file);
  };

  const EditAble = () => {
    navigate("/admin/edit-profile");
  };
  const logoutHandler = () => {
    googleLogout();
    dispatch(Logout(navigate));
  };
  return (
    <>
      {/* {loading ? (
        <Loader />
      ) : ( */}
      <div className="container">
        <div className="my_profile">
          <>
            <h1>My Profile</h1>
            <div className="wrapper profile_pic">
              <div className="btnimg">
                <img src={data?.profilePictureURL} alt="" />
              </div>
              {/* <input type="file" onChange={handleImageChange} /> */}
            </div>
            <div className="title_box">
              <h2>{data?.firstName}</h2>
              <h3>{data?.email}</h3>
            </div>
            <div className="logout_btn">
              {/* {isAdmin === "admin" && ( */}
              <button onClick={EditAble} style={{ marginRight: "5px" }}>
                {" "}
                Edit{" "}
              </button>
              {/* )} */}
              <button onClick={logoutHandler}>Logout</button>
            </div>
          </>
        </div>
        <div className="clearfix"></div>
      </div>
      {/* )} */}
    </>
  );
};

export default Profile;
