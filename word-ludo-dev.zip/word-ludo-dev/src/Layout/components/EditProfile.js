import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { editProfile } from "../../redux/sllices/profileSlice";
import { useNavigate } from "react-router";
import Loader from "../Loader";
import { handleKeyDown } from "../../utilities/handleKeyDown";

const EditProfile = () => {
  const navigate = useNavigate();
  const loading = useSelector((state) => state?.root?.profile?.loading);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm({
    mode: "onChange",
  });
  const data = useSelector((state) => state?.root?.profile?.data);
  const dispatch = useDispatch();

  const HandleSubmit = (data) => {
    dispatch(editProfile(data, navigate));
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="container">
          <div className="my_profile">
            <>
              <form onSubmit={handleSubmit(HandleSubmit)}>
                {" "}
                <h1>Edit My Profile</h1>
                <div className="wrapper profile_pic">
                  <div className="btnimg">
                    <img src={data?.profilePictureURL} alt="" />
                  </div>
                  {/* <input type="file" onChange={handleImageChange} /> */}
                </div>
                <div className="title_box">
                  <div className="innerbox">
                    <input
                      type="text"
                      name="firstName"
                      defaultValue={data?.firstName}
                      onKeyDown={handleKeyDown}
                      {...register("firstName", {
                        required: "Please Enter Name",
                        maxLength: {
                          value: 50,
                          message: "The Name should not exceed 50 characters",
                        },
                      })}
                    />

                    <p style={{ color: "red" }}>
                      {errors?.firstName && errors?.firstName?.message}
                    </p>
                  </div>
                  <div className="innerbox">
                    <input
                      type="text"
                      name="email"
                      disabled
                      style={{ cursor: "not-allowed" }}
                      defaultValue={data?.email}
                    />
                  </div>
                </div>
                <div className="logout_btn">
                  <button type="submit" style={{ marginRight: "5px" }}>
                    Update
                  </button>
                  <button onClick={() => navigate("/profile")}>Cancel</button>
                </div>
              </form>
            </>
          </div>
          <div className="clearfix"></div>
        </div>
      )}
    </>
  );
};

export default EditProfile;
