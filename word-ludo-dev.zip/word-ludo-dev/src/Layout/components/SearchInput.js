import React, { useEffect, useMemo, useState } from "react";
// import SearchIcon from "@mui/icons-material/Search";
// import MicNoneIcon from "@mui/icons-material/MicNone";
// import { useDebouncedValue } from "../../hooks/usedebounce";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import { useDispatch, useSelector } from "react-redux";
import { getWord } from "../../redux/sllices/wordOfTheDaySlice";
// import { redirect } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const SearchInput = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    transcript,
    // listening,
    // resetTranscript,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition();

  const [searchValue, setSearchValue] = useState("");
  // const search = useDebouncedValue(searchValue, 900);
  const searchData = useSelector(
    (state) => state?.root?.wordOfTheDay?.wordData
  );
  useMemo(() => {
    if (transcript?.length > 0) {
      setSearchValue(transcript);
      // SpeechRecognition.stopListening()
    }
  }, [transcript]);

  useEffect(() => {
    // if(searchData.length>0){
    //     return redirect('/word-details')
    // }
  }, [searchData]);

  const startRecording = () => {
    if (!browserSupportsSpeechRecognition) {
      alert(`Browser doesn't support speech recognition.`);
    }
    SpeechRecognition.startListening();
  };

  useEffect(() => {
    if (searchValue !== "") {
      dispatch(getWord(searchValue));
    }
  }, [dispatch, searchValue]);
  return (
    <div className="searchbox" onClick={() => navigate("/searchword")}>
      <div className="searchicon">
        <svg
          width="16"
          height="16"
          viewBox="0 0 16 16"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M14 14L11.1 11.1M12.6667 7.33333C12.6667 10.2789 10.2789 12.6667 7.33333 12.6667C4.38781 12.6667 2 10.2789 2 7.33333C2 4.38781 4.38781 2 7.33333 2C10.2789 2 12.6667 4.38781 12.6667 7.33333Z"
            stroke="#090A0A"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </div>
      <input
        disabled
        type="text"
        onChange={(e) => setSearchValue(e.target.value)}
        value={searchValue}
        placeholder="Search Word"
      />
      <div className="record_icon" disabled onClick={() => startRecording()}>
        <svg
          width="16"
          height="16"
          viewBox="0 0 16 16"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M12.6666 6.66663V7.99996C12.6666 9.23764 12.1749 10.4246 11.2998 11.2998C10.4246 12.175 9.2376 12.6666 7.99992 12.6666M7.99992 12.6666C6.76224 12.6666 5.57526 12.175 4.70009 11.2998C3.82492 10.4246 3.33325 9.23764 3.33325 7.99996V6.66663M7.99992 12.6666V15.3333M5.33325 15.3333H10.6666M7.99992 0.666626C7.46949 0.666626 6.96078 0.87734 6.5857 1.25241C6.21063 1.62749 5.99992 2.13619 5.99992 2.66663V7.99996C5.99992 8.53039 6.21063 9.0391 6.5857 9.41417C6.96078 9.78924 7.46949 9.99996 7.99992 9.99996C8.53035 9.99996 9.03906 9.78924 9.41413 9.41417C9.78921 9.0391 9.99992 8.53039 9.99992 7.99996V2.66663C9.99992 2.13619 9.78921 1.62749 9.41413 1.25241C9.03906 0.87734 8.53035 0.666626 7.99992 0.666626Z"
            stroke="#090A0A"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </div>
    </div>
  );
};

export default SearchInput;
