import React, { useEffect } from "react";
import jwt_decode from "jwt-decode";
import { GoogleLogin } from "@react-oauth/google";
import { useDispatch } from "react-redux";
import { login } from "../../redux/sllices/authSlice";
import { useSelector } from "react-redux";
import { getProfile } from "../../redux/sllices/profileSlice";
import { useNavigate } from "react-router-dom";
import { cleanDigitSectionValue } from "@mui/x-date-pickers/internals/hooks/useField/useField.utils";

const GLogin = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isLogin = JSON.parse(localStorage.getItem("token"));
  const dataaa = useSelector((state) => state?.root?.apk?.data);

  const data = useSelector((state) => state?.root?.profile?.data);
  const GloginData = dataaa?.profilePictureURL === undefined ? data : dataaa;
  useEffect(() => {
    dispatch(getProfile());
  }, [dispatch]);

  return (
    <>
      {isLogin ? (
        <div>
          <div className="google-after-sign-in">
            <GoogleLogin
              onSuccess={(credentialResponse) => {
                let decoded = jwt_decode(credentialResponse?.credential);
                console.log(dataaa, "38");
                dispatch(
                  login(decoded, credentialResponse?.credential, navigate)
                );
              }}
              onError={() => {
                // console.log("Login Failed");
              }}
              // useOneTap
            />

            <button type="button" className="custom_after_signin">
              <img src={GloginData?.profilePictureURL} alt="" />
              <div className="get-details">
                <span className="signin-name">
                  Sign in as {GloginData?.firstName}
                </span>
                <span>{GloginData?.email}</span>
              </div>
              <svg
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                class="LgbsSe-Bz112c"
              >
                <g>
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  ></path>
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  ></path>
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  ></path>
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  ></path>
                  <path fill="none" d="M0 0h48v48H0z"></path>
                </g>
              </svg>
            </button>
          </div>
        </div>
      ) : (
        <div className="custom-google-btn">
          <button>
            <div className="google_btn">
              <GoogleLogin
                onSuccess={(credentialResponse) => {
                  let decoded = jwt_decode(credentialResponse?.credential);

                  dispatch(
                    login(decoded, credentialResponse?.credential, navigate)
                  );
                }}
                onError={() => {
                  // console.log("Login Failed");
                }}
                // useOneTap
              />
            </div>
            <div className="custm_btn">
              <svg
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                class="LgbsSe-Bz112c"
              >
                <g>
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  ></path>
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  ></path>
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  ></path>
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  ></path>
                  <path fill="none" d="M0 0h48v48H0z"></path>
                </g>
              </svg>
              <span>Sign in with google</span>
            </div>
          </button>
        </div>
      )}
    </>
  );
};

export default GLogin;
