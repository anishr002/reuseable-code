import React, { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar";
import bannerImg from "../../src/assets/images/home_bg.svg";
import logoImg from "../../src/assets/images/logo.svg";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import Footer from "./components/Footer";

const Applayout = () => {
  const location = useLocation();
  const { loading } = useSelector((state) => state?.root?.auth);
  const isLogin = JSON.parse(localStorage.getItem("token"));

  const newurl = isLogin ? "/home" : "/";
  const userRole = localStorage.getItem("role");
  const profilepicdata = useSelector((state) => state?.root?.profile?.data);

  const [isDivVisible, setDivVisible] = useState(false);
  const toggleDivVisibility = () => {
    if (window.innerWidth <= 766) {
      setDivVisible(!isDivVisible);
    }
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 766) {
        setDivVisible(true);
      } else {
        setDivVisible(false);
      }
    };

    window.addEventListener("resize", handleResize);
    handleResize();

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div
      className={`top_bg ${
        location.pathname === "/" && loading ? "splash_screen" : ""
      }`}
      style={{ backgroundImage: `url(${bannerImg})` }}
    >
      <div id="sticky-area-venue" className="top_header sticky-md-top">
        <div className="container">
          <div className="desktop_header">
            <Link to={newurl}>
              <img className="logo_img" src={logoImg} alt="" />
            </Link>
            <div className="mobile_menu">
              {!isDivVisible && (
                <div className="menu_bar">
                  <Navbar toggleDivVisibility={toggleDivVisibility} />
                </div>
              )}
              <button className="burgermenu" onClick={toggleDivVisibility}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="1em"
                  viewBox="0 0 448 512"
                >
                  <path d="M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" />
                </svg>
              </button>
            </div>
            <div className="profile_box">
              {isLogin && (
                <NavLink
                  to="/profile"
                  className="profileimg"
                  // onClick={toggleDivVisibility}
                >
                  {userRole === "admin" && (
                    <div className="hedaer-pro-link" title="Profile">
                      <img
                        src={profilepicdata?.profilePictureURL}
                        alt="profile"
                      />
                    </div>
                  )}
                  {userRole === "user" && (
                    <div>
                      <svg
                        width="25"
                        height="24"
                        viewBox="0 0 25 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M20.25 21V19C20.25 17.9391 19.8286 16.9217 19.0784 16.1716C18.3283 15.4214 17.3109 15 16.25 15H8.25C7.18913 15 6.17172 15.4214 5.42157 16.1716C4.67143 16.9217 4.25 17.9391 4.25 19V21"
                          stroke="#979C9E"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                        <path
                          d="M12.25 11C14.4591 11 16.25 9.20914 16.25 7C16.25 4.79086 14.4591 3 12.25 3C10.0409 3 8.25 4.79086 8.25 7C8.25 9.20914 10.0409 11 12.25 11Z"
                          stroke="#979C9E"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <span>Profile</span>
                    </div>
                  )}
                </NavLink>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="clearfix"></div>
      <div class="main-content">
        <Outlet />
      </div>
      <div class="footer">
        <Footer />
      </div>
    </div>
  );
};

export default Applayout;
