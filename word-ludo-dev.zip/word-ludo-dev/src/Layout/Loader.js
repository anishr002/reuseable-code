import * as React from "react";
// import CircularProgress from "@mui/material/CircularProgress";
// import Box from "@mui/material/Box";
import loader from "../assets/images/loding.gif";

export default function Loader() {
  return (
    <div className="loader_box">
        <img src={loader} alt="loader" />
    </div>
  );
}
