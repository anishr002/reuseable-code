import React from "react";
import WordDay from "./components/WordDay";
import SearchInput from "./components/SearchInput";
import GLogin from "./components/GoogleLogin";
// import CircularProgress from "@mui/material/CircularProgress";
// import Box from "@mui/material/Box";
import { useSelector } from "react-redux";
import logoImg from "../../src/assets/images/logo.svg";
import withSplashScreen from "./components/BackDropLoaders";
import Loader from "./Loader";
import { GoogleLogin } from "@react-oauth/google";
import { useLocation } from "react-router-dom";

const HomePage = () => {
  // const { data } = useSelector((state) => state?.root?.auth);
  const { loading } = useSelector((state) => state?.root?.auth);
  const location = useLocation();

  // const isAdmin = data?.role?.name;

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="container">
          <SearchInput />
          <WordDay />
          <div className="gbtn_box text-center">
            <GLogin />
          </div>
          <div className="clearfix"></div>
        </div>
      )}
    </>
  );
};

export default withSplashScreen(HomePage);
