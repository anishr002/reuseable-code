import { combineReducers } from "@reduxjs/toolkit";
import authSlice from "./sllices/authSlice";
import profileSlice from "./sllices/profileSlice";
import wordOfTheDaySlice from "./sllices/wordOfTheDaySlice";
import userQuizSlice from "./sllices/quizSlice";
import storage from "redux-persist/lib/storage";
import { persistReducer } from "redux-persist";
import saveWordAndGroupSlice from "./sllices/saveWordAndGroupSlice";
import wordSlice from "./sllices/wordSlice";
import adminQuizSlice from "./sllices/adminQuizSlice";
import adminQuestionSlice from "./sllices/adminQuestionSlice";
import adminCategorySlice from "./sllices/adminCategorySlice";
import adminPublicWordgroupSlice from "./sllices/adminPublicWordgroupSlice";
import allwordSlice from "./sllices/allwordSlice";
import apkLoginSlice from "./sllices/apkLoginSlice";
import essayGeneratorSlice from "./sllices/essayGeneratorSlice";

// Reducers

const persistConfig = {
  key: "root",
  storage,
};

const appReducer = combineReducers({
  auth: authSlice,
  profile: profileSlice,
  wordOfTheDay: wordOfTheDaySlice,
  saveWordAndGroup: saveWordAndGroupSlice,
  words: wordSlice,
  quiz: userQuizSlice,
  adminQuiz: adminQuizSlice,
  adminQuestion: adminQuestionSlice,
  adminCategory: adminCategorySlice,
  adminpublicwordgroup: adminPublicWordgroupSlice,
  Allwords: allwordSlice,
  apk: apkLoginSlice,
  essay: essayGeneratorSlice,
});
const rootReducer = (state, action) => {
  if (action.type === "login/logoutdata") {
    state = undefined;
  }
  return appReducer(state, action);
};
export const persistedReducer = persistReducer(persistConfig, rootReducer);
export default rootReducer;
