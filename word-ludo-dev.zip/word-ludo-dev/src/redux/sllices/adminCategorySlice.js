import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  adminCategorylistdata: {},
  addCategorydata: {},
  loading: false,
  singleCategorydata: {},
};

// Get Admin Category list Data
export const getAdminCategorylist =
  (searchValue, page, rowsPerPage) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${
          process.env.REACT_APP_API_URL
        }/category/get-all?pageNumber=${page}&pageLimit=${rowsPerPage}&search=${searchValue}&isList=${true}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(adminCategoryDatalist(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

// Get Admin Category list Data
export const getCategorylistforDropdown = () => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/category/get-all`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(adminCategoryDatalist(response?.data?.data));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//admin add Category
export const addAdminCategory =
  (categorydata, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/category `,
        categorydata,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addAdminCategorydetails(response?.data?.data));
        // dispatch(toggleLoading(false));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/category-list");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//Get Single category Details
export const getSingleCategoryDetail = (id, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/category/get-single/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(singleCategoryDetails(response?.data?.data));

      // navigate(`/admin/edit-word/${response?.data?.data?._id}`);

      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      navigate("/admin/category-list");
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//admin delete category
export const deleteCategory =
  (id, searchValue, pageNumber, rowsPerPage, lastone, setpageNumber) =>
  async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/category/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(toggleLoading(false));
        if (lastone && pageNumber > 1) {
          setpageNumber((pre) => pre - 1);
        }
        dispatch(
          getAdminCategorylist(
            searchValue,
            lastone && pageNumber > 1 ? pageNumber - 1 : pageNumber,
            rowsPerPage
          )
        );
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//admin Edit category
export const editCategory =
  (id, categorydata, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));

    try {
      dispatch(toggleLoading(true));
      const response = await axios.patch(
        `${process.env.REACT_APP_API_URL}/category/${id}`,
        categorydata,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addAdminCategorydetails(response?.data?.data));
        // dispatch(toggleLoading(false));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/category-list");
        //   navigate("/admin/quiz-list");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

const adminCategorySlice = createSlice({
  name: "adminCategory",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    adminCategoryDatalist: (state, action) => {
      state.adminCategorylistdata = action.payload;
    },
    addAdminCategorydetails: (state, action) => {
      state.addCategorydata = action.payload;
    },
    singleCategoryDetails: (state, action) => {
      state.singleCategorydata = action.payload;
    },
  },
});

export const {
  toggleLoading,
  adminCategoryDatalist,
  addAdminCategorydetails,
  singleCategoryDetails,
} = adminCategorySlice.actions;

export default adminCategorySlice.reducer;
