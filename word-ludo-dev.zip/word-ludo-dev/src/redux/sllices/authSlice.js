import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";
import { useNavigate } from "react-router-dom";
import { resetEssay } from "./essayGeneratorSlice";

const initialState = {
  data: {},
  logoutDataObj: {},
  loading: false,
  islogin: false,
};
// GOOGLE LOGIN
export const login = (obj, token, navigate) => async (dispatch) => {
  try {
    dispatch(toggleLoading(true));
    const data = {
      email: obj?.email,
      firstName: obj?.given_name,
      lastName: obj?.family_name,
      profilePictureURL: obj?.picture,
    };
    const response = await axios.post(
      `${process.env.REACT_APP_API_URL}/users/login`,
      data
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(loginData(response.data.data));
      dispatch(toggleLogin(true));
      localStorage.setItem(
        "token",
        JSON.stringify(response?.data?.data?.token)
      );
      localStorage.setItem("role", response?.data?.data?.role?.name);
      dispatch(toggleLoading(false));
      navigate("/home");
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

export const Logout = (navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));

    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/users/logout`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      console.log(response.data.message, "response");

      dispatch(logoutdata());

      window.postMessage("Logout successfully.", "*");
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      navigate("/logout");

      dispatch(toggleLogin(false));
      dispatch(toggleLoading(false));
      dispatch(resetEssay());

      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

const authSlice = createSlice({
  name: "login",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    loginData: (state, action) => {
      state.data = action.payload;
      state.islogin = true;
    },
    logoutdata: (state, action) => {
      state.data = {};
    },
    toggleLogin: (state, action) => {
      state.islogin = action.payload;
    },
  },
});

export const { toggleLoading, loginData, logoutdata, toggleLogin } =
  authSlice.actions;

export default authSlice.reducer;
