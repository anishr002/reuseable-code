import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  data: [],
  myquizdata: [],
  singleuserQuiz: {},
  addquizAnswer: [],
  resultdata: [],
  loading: false,
  totalQuiz: 0,
};

// Get user quiz
export const getUserQuiz = (pageNumber, pageLimit) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));

  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/quiz/get-all-users-quiz?pageNumber=${pageNumber}&pageLimit=${pageLimit}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(userQuizData(response.data.data));
      dispatch(setTotalQuiz(response.data?.data[0]?.totalQuiz));

      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//Get My Quiz
export const getMyQuiz = (pageNumber, pageLimit) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/userQuiz/my-quiz?pageNumber=${pageNumber}&pageLimit=${pageLimit} `,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(myQuizData(response.data.data));
      dispatch(setTotalQuiz(response.data?.data[0]?.totalQuiz));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//Get single user Quiz details
export const getsingleUserQuizDetails = (id) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/quiz/getOneQuiz/${id}`,

      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(getsingleUserQuizdata(response?.data?.data));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//Play UserQuiz
export const addUserAnswer = (questionsData, quizId) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  if (questionsData === null) {
    dispatch(addUserquizAnswer([]));
  } else {
    const data = {
      questionsData,
      quizId,
    };
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/userQuiz/attempt`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addUserquizAnswer(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  }
};

//quiz result
export const getResult = (id) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  if (id === null) {
    dispatch(getresultData([]));
  } else {
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/userQuiz/result/${id} `,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(getresultData(response?.data?.data));
        dispatch(toggleLoading(false));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  }
};

const userQuizSlice = createSlice({
  name: "quiz",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    userQuizData: (state, action) => {
      if (state.data.length === 0) {
        state.data = action.payload[0]?.quizData;
      } else {
        state.data = state.data.concat(action.payload[0]?.quizData);
      }
    },
    setTotalQuiz: (state, action) => {
      state.totalQuiz = action.payload;
    },
    resetData: (state, action) => {
      state.data = [];
      state.myquizdata = [];
    },
    myQuizData: (state, action) => {
      if (state.myquizdata.length === 0) {
        state.myquizdata = action.payload[0]?.quizData;
      } else {
        state.myquizdata = state.myquizdata.concat(action.payload[0]?.quizData);
      }
    },
    addUserquizAnswer: (state, action) => {
      state.addquizAnswer = action.payload;
    },
    getsingleUserQuizdata: (state, action) => {
      state.singleuserQuiz = action.payload;
    },
    getresultData: (state, action) => {
      state.resultdata = action.payload;
    },
  },
});

export const {
  toggleLoading,
  userQuizData,
  myQuizData,
  setTotalQuiz,
  resetData,
  getsingleUserQuizdata,
  addUserquizAnswer,
  getresultData,
} = userQuizSlice.actions;

export default userQuizSlice.reducer;
