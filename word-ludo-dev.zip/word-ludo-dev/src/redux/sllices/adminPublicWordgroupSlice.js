import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  PublicWorgroupTablelist: {},
  PublicWordGroupdata: {},
  loading: false,
  singlePublicWorgroupdata: {},
  // searchWorddata: [],
};

//admin add public word group
export const addAdminPublicWordgroup =
  (publicWdata, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));

      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/public-word-group/create `,
        publicWdata,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addPublicWordgroupData(response?.data?.data));
        // dispatch(toggleLoading(false));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/public-wordgroup-list");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

// //admin add public word group
// export const getSearchWordlist =
//   (wordIdArray, searchWord) => async (dispatch) => {
//     const token = JSON.parse(localStorage.getItem("token"));
//     const url = `${process.env.REACT_APP_API_URL}/public-word-group/search?word=${searchWord}`;

//     try {
//       dispatch(toggleLoading(true));
//       const response = await axios.post(
//         url,
//         { wordIdArray: wordIdArray },
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       if (response.status === 200 && response?.data?.status === 1) {
//         dispatch(addPublicWordgroupData(response?.data?.data));
//         dispatch(toggleLoading(false));
//       }
//     } catch (err) {
//       if (err?.response?.status === 400 || err?.response?.status === 500) {
//         dispatch(toggleLoading(false));
//         toast.error(<ToastContent message={err?.response?.data?.message} />, {
//           position: "top-right",
//           autoClose: 5000,
//           hideProgressBar: false,
//           closeOnClick: true,
//           pauseOnHover: true,
//           draggable: true,
//           progress: undefined,
//           theme: "light",
//         });
//       }
//       dispatch(toggleLoading(false));
//     }
//   };

// Get Admin PublicWordgroup list Data
export const getAdminPublicWordgrouplist =
  (searchValue, page, rowsPerPage) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));

    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/public-word-group/fetch-all?pageNumber=${page}&pageLimit=${rowsPerPage}&search=${searchValue}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(adminPublicWordgroupDatalist(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//admin delete PublicWordgroup
export const deletePublicWordgroup =
  (id, searchValue, pageNumber, rowsPerPage, lastone) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/public-word-group/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(toggleLoading(false));
        dispatch(
          getAdminPublicWordgrouplist(
            searchValue,
            lastone ? pageNumber - 1 : pageNumber,
            rowsPerPage
          )
        );
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//admin single PublicWordgroup
export const getSinglePublicWordGroup = (id, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));

  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/public-word-group/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(singlePublicWordgroupData(response?.data?.data));
      dispatch(toggleLoading(false));
      // toast.success(<ToastContent message={response?.data?.message} />, {
      //   position: "top-right",
      //   autoClose: 2000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "light",
      // });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      navigate("/admin/public-wordgroup-list");
    }
    dispatch(toggleLoading(false));
  }
};

//admin Edit PublicWordgroup
export const editPublicWordgroup =
  (id, editdata, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));

    try {
      dispatch(toggleLoading(true));
      const response = await axios.patch(
        `${process.env.REACT_APP_API_URL}/public-word-group/update/${id}`,
        editdata,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(singlePublicWordgroupData(response?.data?.data));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/public-wordgroup-list");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/public-wordgroup-list");
      }
      dispatch(toggleLoading(false));
    }
  };

const adminPublicWordgroupSlice = createSlice({
  name: "adminCategory",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    addPublicWordgroupData: (state, action) => {
      state.PublicWordGroupdata = action.payload;
    },
    adminPublicWordgroupDatalist: (state, action) => {
      state.PublicWorgroupTablelist = action.payload;
    },
    singlePublicWordgroupData: (state, action) => {
      state.singlePublicWorgroupdata = action.payload;
    },
    // adminSearchwordList: (state, action) => {
    //   console.log(action?.payload, "p");
    //   state.searchWorddata = action.payload;
    // },
  },
});

export const {
  toggleLoading,
  addPublicWordgroupData,
  adminPublicWordgroupDatalist,
  singlePublicWordgroupData,
  // adminSearchwordList,
} = adminPublicWordgroupSlice.actions;

export default adminPublicWordgroupSlice.reducer;
