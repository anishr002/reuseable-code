import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  data: [],
  loading: false,
  addWordData: {},
  editwordData: {},
  wordClassArray: [],
  singlewordData: {},
};

//Get single word details
export const getSingleWordDetail =
  (id, seteditwordData, navigate) => async (dispatch) => {
    if (id === null) {
      dispatch(getOneWordDetails([]));
    } else {
      const token = JSON.parse(localStorage.getItem("token"));
      try {
        dispatch(toggleLoading(true));
        const response = await axios.get(
          `${process.env.REACT_APP_API_URL}/admin/words/get-single/${id}`,
          token
            ? {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            : {}
        );
        if (response.status === 200 && response?.data?.status === 1) {
          dispatch(getOneWordDetails(response?.data?.data));
          seteditwordData(response?.data?.data);
          // navigate(`/admin/edit-word/${response?.data?.data?._id}`);

          dispatch(toggleLoading(false));
        }
      } catch (err) {
        if (err?.response?.status === 400 || err?.response?.status === 500) {
          dispatch(toggleLoading(false));
          navigate("/admin/word-listing");
          toast.error(<ToastContent message={err?.response?.data?.message} />, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
        }
        dispatch(toggleLoading(false));
      }
    }
  };

// Get All word Data
export const getAllWords = (searchValue, page, limit) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  const urlWithPage = `${process.env.REACT_APP_API_URL}/admin/words/getAllWords?search=${searchValue}&skip=${page}&limit=${limit}`;
  const urlWithoutPage = `${process.env.REACT_APP_API_URL}/admin/words/getAllWords`;
  const mainUrl = limit ? urlWithPage : urlWithoutPage;
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(mainUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(getAllData(response?.data?.data));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//get All word class data
export const getAllwordclass = () => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));

  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/admin/words/word-class`,
      token && {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(getWordclassArraydata(response?.data?.data));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//Add wordDetails
export const addWordDetails =
  (word, setFormShow, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/admin/words/addWord/${word}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addWord(response?.data?.data));
        dispatch(toggleLoading(false));
        setFormShow(true);
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/word-listing");
      }
      dispatch(toggleLoading(false));
    }
  };

//delete Words
export const deleteWords =
  (id, searchValue, pageNumber, rowsPerPage, lastone) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    // const searchvalue = "";
    // const page = 1;
    // const limit = 10;
    try {
      dispatch(toggleLoading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/admin/words/deleteWord/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(toggleLoading(false));
        dispatch(
          getAllWords(
            searchValue,
            lastone ? pageNumber - 1 : pageNumber,
            rowsPerPage
          )
        );
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//edit Words
export const editwords = (id, data, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.patch(
      `${process.env.REACT_APP_API_URL}/admin/words/editWord/${id}`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(addWord(response?.data?.data));
      // dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      navigate("/admin/word-listing");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//add word when get google search url
export const AddwordonGoogleurl =
  (searchValueword, data, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/admin/words/addWord/${searchValueword}`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addWord(response?.data?.data));
        dispatch(toggleLoading(false));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/word-listing");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//get Edit WordDetails
export const getEditwordDetails = (id) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/admin/words/editWordObj/${id}`,

      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(geteditesworddata(response?.data?.data?.word));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//Add word by Admin
export const AddwordbyAdmin = (id, data, addWord) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.patch(
      `${process.env.REACT_APP_API_URL}/admin/words/editWord/${id}?addWord=${addWord}`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

const wordSlice = createSlice({
  name: "word",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    getAllData: (state, action) => {
      state.data = action.payload;
    },
    addWord: (state, action) => {
      state.addWordData = action.payload;
    },
    editword: (state, action) => {
      state.addWordData = action.payload;
    },
    getWordclassArraydata: (state, action) => {
      state.wordClassArray = action.payload;
    },
    getOneWordDetails: (state, action) => {
      state.singlewordData = action.payload;
    },
    geteditesworddata: (state, action) => {
      state.editwordData = action.payload;
    },
    resetData: (state, action) => {
      state.addWordData = {};
    },
    resetsingleData: (state, action) => {
      state.singlewordData = {};
    },
  },
});

export const {
  toggleLoading,
  getAllData,
  addWord,
  editword,
  getOneWordDetails,
  geteditesworddata,
  getWordclassArraydata,
  resetData,
  resetsingleData,
} = wordSlice.actions;

export default wordSlice.reducer;
