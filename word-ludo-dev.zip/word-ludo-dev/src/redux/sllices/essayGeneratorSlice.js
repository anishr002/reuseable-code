import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  essayGeneratordata: [],
  addEssaydata: [],
  genereategradeData: [],
  generateGradeOptionData: [],
  loading: false,
  addLoading: false,
};

// Get Essay Generator  Data
export const getEssayGenratorJson = () => async (dispatch) => {
  //   const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(`http://172.16.1.129:3005/Frontend/Json`);
    dispatch(EssayGenerator(response?.data));
    dispatch(toggleLoading(false));
  } catch (err) {
    dispatch(toggleLoading(false));
    toast.error(<ToastContent message={err?.response?.data?.message} />, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  }
};

//add Essay Generator
export const addEssayGenerator =
  (data, reset, setShowModal) => async (dispatch) => {
    // const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(AddEssayLoading(true));
      const response = await axios.post(
        `http://172.16.1.129:3005/essay/create`,
        data
      );
      dispatch(addEssayGeneratorData(response?.data?.data));
      dispatch(AddEssayLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      setShowModal(false);
      // reset();
    } catch (err) {
      console.log(err, "err");
      dispatch(toggleLoading(false));
      dispatch(AddEssayLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.error} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  };

//add Essay Generator
export const GradeinEssay = (data) => async (dispatch) => {
  // const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.post(
      `http://172.16.1.129:3005/ocr/Detection`,
      data
    );
    dispatch(generateGradeEssay(response?.data?.data));
    dispatch(toggleLoading(false));
    toast.success(<ToastContent message={response?.data?.message} />, {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
    // setShowModal(false);
    // reset();
  } catch (err) {
    dispatch(toggleLoading(false));
    toast.error(<ToastContent message={err?.response?.data?.error} />, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  }
};

export const getgradeOption = () => async (dispatch) => {
  //   const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(`http://172.16.1.129:3005/grade/Option`);
    dispatch(generateGradeOption(response?.data?.data));
    dispatch(toggleLoading(false));
  } catch (err) {
    dispatch(toggleLoading(false));
    toast.error(<ToastContent message={err?.response?.data?.message} />, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  }
};

const essayGeneratorSlice = createSlice({
  name: "essay",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    AddEssayLoading: (state, action) => {
      state.addLoading = action.payload;
    },
    EssayGenerator: (state, action) => {
      state.essayGeneratordata = action.payload;
    },
    addEssayGeneratorData: (state, action) => {
      state.addEssaydata = action.payload;
    },
    generateGradeEssay: (state, action) => {
      state.genereategradeData = action.payload;
    },
    generateGradeOption: (state, action) => {
      state.generateGradeOptionData = action.payload;
    },
    resetEssay: (state, action) => {
      state.addEssaydata = [];
      state.essayGeneratordata = [];
      state.genereategradeData = [];
    },
  },
});

export const {
  toggleLoading,
  EssayGenerator,
  addEssayGeneratorData,
  AddEssayLoading,
  resetEssay,
  generateGradeEssay,
  generateGradeOption,
  //   singleCategoryDetails,
} = essayGeneratorSlice.actions;

export default essayGeneratorSlice.reducer;
