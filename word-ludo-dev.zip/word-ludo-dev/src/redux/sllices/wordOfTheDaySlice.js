import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  data: {},
  loading: false,
  wordData: [],
  wordDetail: {},
  synonymsAntonymsData: [],
  savedData: {},
  searchWorddata: [],
};

//get wordofTheDay
export const getWordOfTheDay = () => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/admin/words/word-of-day`,
      {
        headers: {
          Authorization: token && `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(wordOfTheDayData(response?.data?.data));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//Get Word-Details for synonyms and Antonyms
export const getWordSynonymsAntonymsDetails =
  (o, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/admin/words/get-word-details/${o}`,
        {
          headers: {
            Authorization: token && `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(wordDetail(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        navigate(-1);
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//Get SearchDetails by Add button

export const getAddSearchDetails = (o, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/admin/words/get-word-details/${o}`,
      {
        headers: {
          Authorization: token && `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(synonymsantonymsDetail(response?.data?.data));
      dispatch(toggleLoading(false));

      navigate(`/word-details?id=${response?.data?.data?._id}`);
      // navigate("/")
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//get Word
export const getWord = (searchValue, setResponseflag) => async (dispatch) => {
  const url = `${process.env.REACT_APP_API_URL}/admin/words/search?word=${searchValue}`;
  if (searchValue === null) {
    dispatch(searchWordData([]));
  } else {
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(url);
      if (response.status === 200 && response?.data?.status === 1) {
        setResponseflag(true);

        dispatch(searchWordData(response?.data?.data));
        dispatch(wordDetail(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  }
};

//admin add public word group
export const getSearchWordlist =
  (wordIdArray, searchWord) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    const url = `${process.env.REACT_APP_API_URL}/public-word-group/search?word=${searchWord}`;

    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        url,
        { wordIdArray: wordIdArray },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(adminSearchwordList(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

// //admin add public word group
// export const getSearchWordlist =
//   (wordIdArray, searchWord) => async (dispatch) => {
//     const token = JSON.parse(localStorage.getItem("token"));
//     const url = `${process.env.REACT_APP_API_URL}/public-word-group/search?word=${searchWord}`;

//     try {
//       dispatch(toggleLoading(true));
//       const response = await axios.post(
//         url,
//         { wordIdArray: wordIdArray },
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       if (response.status === 200 && response?.data?.status === 1) {
//         dispatch(addPublicWordgroupData(response?.data?.data));
//         dispatch(toggleLoading(false));
//       }
//     } catch (err) {
//       if (err?.response?.status === 400 || err?.response?.status === 500) {
//         dispatch(toggleLoading(false));
//         toast.error(<ToastContent message={err?.response?.data?.message} />, {
//           position: "top-right",
//           autoClose: 5000,
//           hideProgressBar: false,
//           closeOnClick: true,
//           pauseOnHover: true,
//           draggable: true,
//           progress: undefined,
//           theme: "light",
//         });
//       }
//       dispatch(toggleLoading(false));
//     }
//   };

// get worddetails
export const getWordDetail = (id, navigate) => async (dispatch) => {
  if (id === null) {
    dispatch(wordDetail([]));
  } else {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/admin/words/get-single/${id}`,
        token
          ? {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          : {}
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(wordDetail(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));

        // navigate("/*");
        // toast.error(<ToastContent message={err?.response?.data?.message} />, {
        //   position: "top-right",
        //   autoClose: 5000,
        //   hideProgressBar: false,
        //   closeOnClick: true,
        //   pauseOnHover: true,
        //   draggable: true,
        //   progress: undefined,
        //   theme: "light",
        // });
      }
      dispatch(toggleLoading(false));
    }
  }
};

//save word
export const saveWord = (payload) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_URL}/word-group/create`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(getWordDetail(payload.wordId));
      dispatch(getWordOfTheDay());
      dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

const wordOfTheDaySlice = createSlice({
  name: "wordOfTheDay",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    wordOfTheDayData: (state, action) => {
      state.data = action.payload;
    },
    searchWordData: (state, action) => {
      state.wordData = action.payload;
    },
    wordDetail: (state, action) => {
      state.wordDetail = action.payload;
    },
    synonymsantonymsDetail: (state, action) => {
      state.wordDetail = action.payload;
    },
    resetData: (state, action) => {
      state.wordData = [];
    },
    adminSearchwordList: (state, action) => {
      // console.log(action?.payload, "p");
      state.searchWorddata = action.payload;
    },
  },
});

export const {
  toggleLoading,
  wordOfTheDayData,
  searchWordData,
  wordDetail,
  synonymsantonymsDetail,
  resetData,
  adminSearchwordList,
} = wordOfTheDaySlice.actions;

export default wordOfTheDaySlice.reducer;
