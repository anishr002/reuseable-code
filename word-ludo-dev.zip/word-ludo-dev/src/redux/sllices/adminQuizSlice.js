import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  adminQuizlistdata: {},
  loading: false,
  addquizdata: {},
  singleQuizData: {},
};

// Get Admin Quiz list Data
export const getAdminQuizlist =
  (searchValue, page, rowsPerPage) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/quiz/get-all-admin-quiz?pageNumber=${page}&pageLimit=${rowsPerPage}&search=${searchValue}`,

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(adminQuizDatalist(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//Add Admin Quiz
export const addAdminquiz = (quizformdata, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.post(
      `${process.env.REACT_APP_API_URL}/quiz/create `,
      quizformdata,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(addAdminquizdetails(response?.data?.data));
      // dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      navigate("/admin/quiz-list");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//delete Quiz
export const deleteQuiz =
  (id, searchValue, pageNumber, rowsPerPage, lastone) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/quiz/delete/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(toggleLoading(false));
        dispatch(
          getAdminQuizlist(
            searchValue,
            lastone ? pageNumber - 1 : pageNumber,
            rowsPerPage
          )
        );
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//Single quiz Data
export const getSingleQuizDetail =
  (id, seteditquizData, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/quiz/${id}`,
        token
          ? {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          : {}
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(singleQuizDetails(response?.data?.data));
        seteditquizData(response?.data?.data);
        // navigate(`/admin/edit-word/${response?.data?.data?._id}`);

        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        navigate("/admin/quiz-list");
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//edit Quiz
export const editQuiz = (id, data, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));

  try {
    dispatch(toggleLoading(true));
    const response = await axios.patch(
      `${process.env.REACT_APP_API_URL}/quiz/edit/${id}`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(addAdminquizdetails(response?.data?.data));
      // dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      navigate("/admin/quiz-list");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

const adminQuizSlice = createSlice({
  name: "adminQuiz",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    adminQuizDatalist: (state, action) => {
      state.adminQuizlistdata = action.payload;
    },
    addAdminquizdetails: (state, action) => {
      state.addquizdata = action.payload;
    },
    deleteAdminQuiz: (state, action) => {
      state.adminQuizlistdata = action.payload;
    },
    singleQuizDetails: (state, action) => {
      state.singleQuizData = action.payload;
    },
    resetsingleQuizdata: (state, action) => {
      state.singleQuizData = {};
    },
  },
});

export const {
  toggleLoading,
  addAdminquizdetails,
  adminQuizDatalist,
  singleQuizDetails,
  resetsingleQuizdata,
  editAdminQuiz,
} = adminQuizSlice.actions;

export default adminQuizSlice.reducer;
