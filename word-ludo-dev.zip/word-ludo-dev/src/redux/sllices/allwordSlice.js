import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  data: [],
  loading: false,
  totalWords: 0,
};

// Get All Words Data
export const getPublicAllWords =
  (pageNumber, pageLimit, letter) => async (dispatch) => {
    //   const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/admin/words/word-list?search=${letter}&pageNumber=${pageNumber}&pageLimit=${pageLimit}`
      );
      if (response.status === 200 && response?.data?.status === 1) {
        // console.log(response?.data.data, "22");
        dispatch(allPublicData(response?.data?.data));
        dispatch(setTotalWords(response?.data.data.totalWords));

        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

// //edit Profile
// export const editProfile = (data, navigate) => async (dispatch) => {
//   const token = JSON.parse(localStorage.getItem("token"));
//   try {
//     dispatch(toggleLoading(true));
//     const response = await axios.patch(
//       `${process.env.REACT_APP_API_URL}/users/editAdminProfile`,
//       data,
//       {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       }
//     );
//     if (response.status === 200 && response?.data?.status === 1) {
//       dispatch(profileData(response?.data?.data));
//       dispatch(toggleLoading(false));
//       toast.success(<ToastContent message={response?.data?.message} />, {
//         position: "top-right",
//         autoClose: 2000,
//         hideProgressBar: false,
//         closeOnClick: true,
//         pauseOnHover: true,
//         draggable: true,
//         progress: undefined,
//         theme: "light",
//       });
//       navigate("/profile");
//     }
//   } catch (err) {
//     if (err?.response?.status === 400 || err?.response?.status === 500) {
//       dispatch(toggleLoading(false));
//       toast.error(<ToastContent message={err?.response?.data?.message} />, {
//         position: "top-right",
//         autoClose: 5000,
//         hideProgressBar: false,
//         closeOnClick: true,
//         pauseOnHover: true,
//         draggable: true,
//         progress: undefined,
//         theme: "light",
//       });
//     }
//     dispatch(toggleLoading(false));
//   }
// };

const allwordSlice = createSlice({
  name: "AllWord",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    allPublicData: (state, action) => {
      state.data = action.payload;
    },
    setTotalWords: (state, action) => {
      state.totalWords = action.payload;
    },
    resetData: (state, action) => {
      state.data = [];
      state.totalWords = 0;
    },
  },
});

export const { toggleLoading, allPublicData, setTotalWords, resetData } =
  allwordSlice.actions;

export default allwordSlice.reducer;
