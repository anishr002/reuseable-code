import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  data: {},
  loading: false,
};

// Get Profile Data
export const getapk = (data) => async (dispatch) => {
  dispatch(apkData(data));
};

const apkLoginSlice = createSlice({
  name: "apk",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    apkData: (state, action) => {
      state.data = action.payload;
    },
  },
});

export const { toggleLoading, apkData } = apkLoginSlice.actions;

export default apkLoginSlice.reducer;
