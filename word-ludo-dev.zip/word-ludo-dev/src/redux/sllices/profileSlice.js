import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  data: {},
  loading: false,
};

// Get Profile Data
export const getProfile = () => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/users/getUserProfile`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(profileData(response?.data?.data));
      dispatch(toggleLoading(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//edit Profile
export const editProfile = (data, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));
  try {
    dispatch(toggleLoading(true));
    const response = await axios.patch(
      `${process.env.REACT_APP_API_URL}/users/editAdminProfile`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(profileData(response?.data?.data));
      dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      navigate("/profile");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

const profileSlice = createSlice({
  name: "profile",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    profileData: (state, action) => {
      state.data = action.payload;
    },
  },
});

export const { toggleLoading, profileData } = profileSlice.actions;

export default profileSlice.reducer;
