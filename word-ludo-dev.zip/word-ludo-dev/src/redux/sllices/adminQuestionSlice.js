import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  adminQuestionlistdata: [],
  addQuestiondata: {},
  loading: false,
  adminQuestionlistarray: [],
  singleQuestiondata: {},
};

// Get Admin Question list Data
export const getAdminQuestionlist =
  (searchValue, page, rowsPerPage, selectedOption, QuestionIdarray) =>
  async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/questions/getAllQuestions?pageNumber=${page}&pageLimit=${rowsPerPage}&search=${searchValue}&categoryId=${selectedOption}`,
        { questionsIdArray: [] },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(adminQuestionDatalist(response?.data?.data));
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//admin add questions
export const addAdminQuestion =
  (quizformdata, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/questions/create `,
        quizformdata,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(addAdminquestiondetails(response?.data?.data));
        // dispatch(toggleLoading(false));
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        navigate("/admin/question-list");
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//Get Single question Details
export const getSingleQuestionDetail =
  (id, seteditquestionData, navigate) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/questions/getSingleQuestion/${id}`,
        token
          ? {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          : {}
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(singleQuestionDetails(response?.data?.data));
        seteditquestionData(response?.data?.data);
        // navigate(`/admin/edit-word/${response?.data?.data?._id}`);

        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        navigate("/admin/question-list");
        // navigate("/*");
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//admin delete questions
export const deleteQuestion =
  (id, searchValue, pageNumber, rowsPerPage, lastone, selectedOption) =>
  async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/questions/delete/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(toggleLoading(false));
        dispatch(
          getAdminQuestionlist(
            searchValue,
            lastone && pageNumber > 1 ? pageNumber - 1 : pageNumber,
            rowsPerPage,
            selectedOption,
            []
          )
        );
        toast.success(<ToastContent message={response?.data?.message} />, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//admin Edit questions
export const editQuestion = (id, data, navigate) => async (dispatch) => {
  const token = JSON.parse(localStorage.getItem("token"));

  try {
    dispatch(toggleLoading(true));
    const response = await axios.patch(
      `${process.env.REACT_APP_API_URL}/questions/editQuestion/${id}`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(addAdminquestiondetails(response?.data?.data));
      // dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      navigate("/admin/question-list");
      //   navigate("/admin/quiz-list");
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

//get Questionlist Array
export const getAdminQuestionlistArray =
  (searchValue, categoryID, page, rowsPerPage, QuizQuestionIdarray) =>
  async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    // const questionsIdArray =
    //   QuizQuestionIdarray?.length > 0 ? QuizQuestionIdarray : [];
    try {
      dispatch(toggleLoading(true));
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/questions/getAllQuestions/?search=${searchValue}&categoryId=${categoryID}`,
        {
          questionsIdArray:
            QuizQuestionIdarray?.length > 0 ? QuizQuestionIdarray : [],
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(
          addQustionlistArray({
            data: response?.data?.data?.result,
            searchValue,
          })
        );
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

//get Questionlist Array in edit mode with id
export const getAdminQuestionlistArrayineditmode =
  (searchValue, quizId, category) => async (dispatch) => {
    const token = JSON.parse(localStorage.getItem("token"));
    try {
      dispatch(toggleLoading(true));
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/questions/getAllQuestions/?quizId=${quizId}&search=${searchValue}&categoryId=${category}`,

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200 && response?.data?.status === 1) {
        dispatch(
          addQustionlistArray({
            data: response?.data?.data?.result,
            searchValue,
          })
        );
        dispatch(toggleLoading(false));
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(toggleLoading(false));
        toast.error(<ToastContent message={err?.response?.data?.message} />, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
      dispatch(toggleLoading(false));
    }
  };

const adminQuestionSlice = createSlice({
  name: "adminQuestion",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    adminQuestionDatalist: (state, action) => {
      state.adminQuestionlistdata = action.payload;
    },
    addAdminquestiondetails: (state, action) => {
      state.addQuestiondata = action.payload;
    },
    singleQuestionDetails: (state, action) => {
      state.singleQuestiondata = action.payload;
    },
    addQustionlistArray: (state, action) => {
      // const { data, searchValue } = action.payload;
      // if (searchValue != "") {
      //   state.adminQuestionlistarray = data;
      // } else {
      //   state.adminQuestionlistarray =
      //     state.adminQuestionlistarray.concat(data);
      // }
      // state.adminQuestionlistarray = state.adminQuestionlistarray.concat(
      //   action.payload

      state.adminQuestionlistarray = action.payload.data;
    },
    resetArrayOnrefresh: (state, action) => {
      state.adminQuestionlistarray = [];
    },
  },
});

export const {
  toggleLoading,
  adminQuestionDatalist,
  addAdminquestiondetails,
  addQustionlistArray,
  resetArrayOnrefresh,
  singleQuestionDetails,
} = adminQuestionSlice.actions;

export default adminQuestionSlice.reducer;
