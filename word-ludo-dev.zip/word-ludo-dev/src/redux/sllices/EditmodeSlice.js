import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContent } from "../../Layout/components/ToastContent";

const initialState = {
  wordEditdata: {},
  loading: false,
};

// GOOGLE LOGIN
export const login = (obj, token) => async (dispatch) => {
  try {
    dispatch(toggleLoading(true));
    const data = {
      email: obj?.email,
      firstName: obj?.given_name,
      lastName: obj?.family_name,
      profilePictureURL: obj?.picture,
    };
    const response = await axios.post(
      `${process.env.REACT_APP_API_URL}/users/login`,
      data
    );
    if (response.status === 200 && response?.data?.status === 1) {
      dispatch(editWordDetails(response.data.data));
      dispatch(toggleLoading(false));
      toast.success(<ToastContent message={response?.data?.message} />, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(toggleLoading(false));
      toast.error(<ToastContent message={err?.response?.data?.message} />, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
    dispatch(toggleLoading(false));
  }
};

const authSlice = createSlice({
  name: "login",
  initialState,
  reducers: {
    toggleLoading: (state, action) => {
      state.loading = action.payload;
    },
    editWordDetails: (state, action) => {
      state.wordEditdata = action.payload;
    },
  },
});

export const { toggleLoading, loginData, logoutdata, toggleLogin } =
  authSlice.actions;

export default authSlice.reducer;
