import { configureStore } from "@reduxjs/toolkit";
import { persistedReducer } from "./rootReducer";

export default configureStore({
  reducer: {
    root: persistedReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      immutableCheck: false,
      serializableCheck: false,
    }),
});
