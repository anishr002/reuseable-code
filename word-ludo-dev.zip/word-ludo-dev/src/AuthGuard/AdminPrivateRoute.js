import React from "react";
import { useSelector } from "react-redux";
import { Navigate, Outlet } from "react-router-dom";

const AdminPrivateRoute = () => {
  const { data } = useSelector((state) => state?.root?.auth);
  const token = JSON.parse(localStorage.getItem("token"));
  const isAdmin = data?.role?.name === "admin";
  // const auth = true;
  const auth = token && isAdmin;

  return <>{auth ? <Outlet /> : <Navigate to="/" replace />}</>;
};

export default AdminPrivateRoute;
