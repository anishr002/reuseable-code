import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useSelector } from "react-redux";

const UserPrivateRoute = () => {
  const { data } = useSelector((state) => state?.root?.auth);
  const isUser = data?.role?.name === "user";
  const token = JSON.parse(localStorage.getItem("token"));
  // const auth = true
  const auth = token;
  return <>{auth ? <Outlet /> : <Navigate to="/" replace />}</>;
};

export default UserPrivateRoute;
