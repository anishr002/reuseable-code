import React, { lazy, Suspense, useEffect, useState } from "react";
import {
  redirect,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from "react-router-dom";
import Loader from "../Layout/Loader";
import AdminNewQuizTable from "../Admin/quiz-managment/AdminNewQuizTable";
import NewAddWord from "../Admin/word-managment/NewAddWord";
import NewEditWord from "../Admin/word-managment/NewEditWord";
// import QuestionTable from "../Admin/question-managment/QuestionTable";
import AddQuestion from "../Admin/question-managment/AddQuestion";
import NewAdminQuiz from "../Admin/quiz-managment/NewAdminQuiz";
import NewAdminEditQuiz from "../Admin/quiz-managment/NewAdminEditQuiz";
import EditQuestion from "../Admin/question-managment/EditQuestion";
import AddCategory from "../Admin/category-management/AddCategory";
import EditCategory from "../Admin/category-management/EditCategory";
import CategoryTable from "../Admin/category-management/CategoryTable";
// import WordGropDetails from "../Layout/components/myWord/WordGropDetails";
import PublicWordGroupTable from "../Admin/publicwordgrop-management/PublicWordGroupTable";
import AddPublicWordGroup from "../Admin/publicwordgrop-management/AddPublicWordGroup";
import EditPublicWordGroup from "../Admin/publicwordgrop-management/EditPublicWordGroup";
import NewAddQuestion from "../Admin/question-managment/NewAddQuestion";
import NewEditQuestion from "../Admin/question-managment/NewEditQuestion";
import AllWords from "../Layout/components/AllWord/AllWords";
import CryptoJS from "crypto-js";
import { cleanDigitSectionValue } from "@mui/x-date-pickers/internals/hooks/useField/useField.utils";
import { useDispatch } from "react-redux";
import { apkData, getapk } from "../redux/sllices/apkLoginSlice";

const Applayout = lazy(() => import("../Layout/Applayout"));
const HomePage = lazy(() => import("../Layout/HomePage"));
const UserPrivateRoute = lazy(() => import("../AuthGuard/UserPrivateRoute"));
const Page404 = lazy(() => import("../Errors/Page404"));
const AdminPrivateRoute = lazy(() => import("../AuthGuard/AdminPrivateRoute"));
// const AdminQuiz = lazy(() => import("../Admin/quiz-managment/AdminQuiz"));
const WordDetails = lazy(() =>
  import("../Layout/components/worddetails/WordDetails")
);
const MyWord = lazy(() => import("../Layout/components/myWord/MyWord"));
const SearchResult = lazy(() => import("../Layout/components/SearchResult"));

const QuizQue = lazy(() => import("../Layout/components/Quiz/QuizQue"));
const Quiz = lazy(() => import("../Layout/components/Quiz/Quiz"));
const Essay = lazy(() => import("../Layout/components/EssayGenerator/Essay"));

const QuizResult = lazy(() => import("../Layout/components/Quiz/QuizResult"));
const QuizIntroduction = lazy(() =>
  import("../Layout/components/Quiz/QuizIntro")
);
const Profile = lazy(() => import("../Layout/components/Profile"));
const EditProfile = lazy(() => import("../Layout/components/EditProfile"));
const MyGroup = lazy(() => import("../Layout/components/myWord/MyGroup"));

const Admindashboard = lazy(() => import("../Admin/Admindashboard"));
// const AddWord = lazy(() => import("../Admin/word-managment/AddWord"));
const GetAllWords = lazy(() => import("../Admin/word-managment/WordListing"));
const GetAllQuestions = lazy(() =>
  import("../Admin/question-managment/QuestionTable")
);

const Router = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  useEffect(() => {
    // const searchParams = new URLSearchParams(location.search);
    // // console.log("searchParams", searchParams);
    // const queryData = {};

    // for (let param of searchParams.entries()) {
    //   const [key, value] = param;
    //   queryData[key] = value;
    // }
    // console.log(queryData.data);
    // if (queryData.data !== undefined) {

    const encStr = location.search.substring(6);
    const originalKey = "my32lengthsupersecretnooneknows1";
    const originaliv = "1234rtyuhgfdcvbh";

    const key = CryptoJS.enc.Utf8.parse(originalKey);
    const iv = CryptoJS.enc.Utf8.parse(originaliv);

    try {
      const decryptedText = CryptoJS.AES.decrypt(encStr, key, {
        iv: iv,
      }).toString(CryptoJS.enc.Utf8);
      // let editedStr = decryptedText.
      const userobj = JSON?.parse(decryptedText);
      dispatch(getapk(userobj));
      localStorage.setItem("token", JSON.stringify(userobj?.token));
      localStorage.setItem("role", userobj?.role?.name);
      localStorage.setItem("email", userobj?.email);
      localStorage.setItem("firstname", userobj?.firstName);
      localStorage.setItem("lastname", userobj?.lastName);

      navigate("/home");
    } catch (error) {
      console.log(error);
    }
  }, [location]);

  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/" element={<Applayout />}>
          <Route index element={<HomePage />} />
          <Route path="/home" element={<HomePage />} />

          <Route path="/word-details" element={<WordDetails />} />
          <Route path="/word-details/:id" element={<WordDetails />} />
          <Route path="/searchword" element={<SearchResult />} />
          <Route path="/my-words" element={<MyWord />} />
          <Route path="/all-words" element={<AllWords />} />

          {/* {/ Application Routes with Authentication /} */}
          <Route element={<UserPrivateRoute />}>
            <Route path="/profile" element={<Profile />} />
            <Route path="/admin/edit-profile" element={<EditProfile />} />
            <Route path="/my-group" element={<MyGroup />} />
            <Route path="/new-quiz" element={<Quiz />} />
            <Route path="/essay" element={<Essay />} />
            <Route path="/essay-grade" element={<Essay />} />
            <Route path="/quiz-result" element={<QuizResult />} />
            <Route path="/my-quiz" element={<Quiz />} />
            <Route path="/quiz-questions" element={<QuizQue />} />
            <Route path="/quiz-intro/:id" element={<QuizIntroduction />} />
          </Route>

          {/* {/ Admin Routes with Authentication /} */}
          <Route element={<AdminPrivateRoute />}>
            <Route path="/admin/add-word" element={<NewAddWord />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/admin/edit-profile" element={<EditProfile />} />
            <Route path="/admin/edit-word/:id" element={<NewEditWord />} />
            <Route path="/admin/word-listing" element={<GetAllWords />} />
            <Route path="/admin/dashboard" element={<Admindashboard />} />
            <Route path="/admin/quiz" element={<NewAdminQuiz />} />
            <Route path="/admin/edit-quiz/:id" element={<NewAdminEditQuiz />} />
            <Route path="/admin/quiz-list" element={<AdminNewQuizTable />} />
            <Route path="/admin/question-list" element={<GetAllQuestions />} />
            <Route path="/admin/add-question" element={<NewAddQuestion />} />
            <Route
              path="/admin/edit-question/:id"
              element={<NewEditQuestion />}
            />
            <Route path="/admin/category-list" element={<CategoryTable />} />
            <Route path="/admin/add-category" element={<AddCategory />} />
            <Route path="/admin/edit-category/:id" element={<EditCategory />} />
            <Route
              path="/admin/public-wordgroup-list"
              element={<PublicWordGroupTable />}
            />
            <Route
              path="/admin/add-public-wordgroup"
              element={<AddPublicWordGroup />}
            />
            <Route
              path="/admin/edit-public-wordgroup/:id"
              element={<EditPublicWordGroup />}
            />
          </Route>

          {/* {/ Error Routes /} */}
          <Route path="*" element={<Page404 />} />
        </Route>
      </Routes>
    </Suspense>
  );
};

export default Router;
