import React from "react";
import { Link } from "react-router-dom";

const Page404 = () => {
  const isLogin = JSON.parse(localStorage.getItem("token"));

  return (
    <div id="notfound">
      <div className="notfound">
        <div className="notfound-404">
          <h1>404</h1>
        </div>
        <h2>Oops, The Page you are looking for can't be found!</h2>
        <Link to={isLogin ? "/home" : "/"}>
          <span className="arrow"></span>
          Return To Homepage
        </Link>
      </div>
    </div>
  );
};

export default Page404;
