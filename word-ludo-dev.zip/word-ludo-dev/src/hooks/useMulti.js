import Autocomplete from "@material-ui/lab/Autocomplete";
import TextField from "@material-ui/core/TextField";
import { Stack } from "@mui/system";
import { Chip } from "@mui/material";

const useMulti = ({ field, form, label, options }) => {
  console.log(options,'options')
  const handleChange = (event, newValue) => {
    form.setFieldValue(field.name, newValue);
  };
  return (
    <Stack spacing={3} sx={{ width: 500 }}>
      <Autocomplete
        multiple
        id={field.name}
        onChange={handleChange}
        options={options?.map((option) => option)}
        // defaultValue={options}
        value={field.value}
        freeSolo
        renderTags={(value, getTagProps) =>
          value?.map((option, index) => (
            <Chip
              variant="outlined"
              label={option}
              {...getTagProps({ index })}
            />
          ))
        }
        renderInput={(params) => (
          <TextField
            {...params}
            // label={label}
            placeholder="Add Word"
          />
        )}
      />
    </Stack>
  );
};

export default useMulti;
