import { Suspense } from "react";
import PrivateRoute from "./PrivateRoute";
import PublicRoute from "./PublicRoute";
import { Navigate, useRoutes } from "react-router-dom";
import PageNotFound from "../components/PageNotFound";
import PapPaTopaypal from "../modules/payments/PaypalTopaypal/PapPaTopaypal";
import ReturnUrl from "../modules/payments/PaypalTopaypal/ReturnPage";
import HomePage from "../modules/payments/commonComponents/Home";
import PayPalCheckout from "../modules/payments/advanceCheckout/PayPalCheckout";
import SucccessPage from "../modules/payments/advanceCheckout/SucccessPage";
import PayPalButton from "../modules/payments/Fastlane-by-PayPal/FastlanePayPal";
import PaypalSave from "../modules/payments/savemethods/PayPalSave";
import CardForm from "../modules/payments/UserCardSave/CardForm";
import StoredCards from "../modules/payments/UserCardSave/userCardSaveMethods";
import CartPage from "../modules/products/Cart";
import UserCardHome from "../modules/payments/UserCardSave/UserCardHome";
import Commisions from "../modules/payments/commisions/Commisions";
import CommisionAdmin from "../modules/payments/commisions/commision-admin";
import AdminOrders from "../modules/payments/commisions/admin-list-order";
import Signup from "../modules/auth/signup";
import Login from "../modules/auth/Login";
import PaymentOrders from "../modules/payments/paymentOrders/paymentOrders";
import AdminPayments from "../modules/payments/admin-payments/AdminPayments";
import Designer from "../modules/payments/designer-payment/Designer";
// import PayPalSaveMethod from "../modules/payments/savemethods/PayPalSave";

const Router = () => {
  // Define public routes
  const publicRoutes = [
    {
      path: "/", // Redirect root to dashboard if token present
      element: <Navigate to="/login" />,
    },
    {
      path: "/signup",
      element: (
        <Suspense>
          <PublicRoute>
            <Signup />
          </PublicRoute>
        </Suspense>
      ),
    },
    {
      path: "/login",
      element: (
        <Suspense>
          <PublicRoute>
            <Login />
          </PublicRoute>
        </Suspense>
      ),
    },
  ];

  // Define private routes
  const privateRoutes = [
    {
      path: "/paypal-methods",
      element: (
        <Suspense fallback="loading">
          <PrivateRoute>
            <HomePage />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/home",
      element: (
        <Suspense>
          <PrivateRoute>
            <CartPage />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/paypal-to-paypal",
      element: (
        <Suspense>
          <PrivateRoute>
            <PapPaTopaypal />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/plan-paypal",
      element: (
        <Suspense>
          <PrivateRoute>
            <PaypalSave />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/advance-checkout",
      element: (
        <Suspense>
          <PrivateRoute>
            <PayPalCheckout />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/returnUrl",
      element: (
        <Suspense>
          <PrivateRoute>
            <ReturnUrl />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/successPage",
      element: (
        <Suspense>
          <PrivateRoute>
            <SucccessPage />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/fastlane-by-paypal",
      element: (
        <Suspense>
          <PrivateRoute>
            <PayPalButton />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/save",
      element: (
        <Suspense>
          <PrivateRoute>
            <PaypalSave />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/card-form",
      element: (
        <Suspense>
          <PrivateRoute>
            <CardForm />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/cardisplay",
      element: (
        <Suspense>
          <PrivateRoute>
            <StoredCards />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/user-card",
      element: (
        <Suspense>
          <PrivateRoute>
            <UserCardHome />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/commisions",
      element: (
        <Suspense>
          <PrivateRoute>
            <Commisions />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/admin-commisions",
      element: (
        <Suspense>
          <PrivateRoute>
            <CommisionAdmin />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/admin-home",
      element: (
        <Suspense>
          <PrivateRoute>
            <AdminPayments />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/admin-orders",
      element: (
        <Suspense>
          <PrivateRoute>
            <AdminOrders />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/payemnt-orders",
      element: (
        <Suspense>
          <PrivateRoute>
            <PaymentOrders />
          </PrivateRoute>
        </Suspense>
      ),
    },
    {
      path: "/home-designer",
      element: (
        <Suspense>
          <PrivateRoute>
            <Designer />
          </PrivateRoute>
        </Suspense>
      ),
    },
    // Add more private routes as needed
  ];

  // Merge public and private routes
  const routes = useRoutes([
    ...publicRoutes,
    ...privateRoutes,
    {
      path: "*",
      element: (
        <Suspense>
          <PageNotFound />
        </Suspense>
      ),
    },
  ]);

  return routes;
};

export default Router;
