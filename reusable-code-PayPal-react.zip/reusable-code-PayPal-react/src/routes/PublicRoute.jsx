import React from "react";
import { Navigate } from "react-router-dom";
import { Suspense } from "react";

const PublicRoute = ({ children }) => {
  //get access token
  const accessToken = localStorage.getItem("token");

  if (accessToken) {
    return <Navigate to="/home" />;
  }

  return <Suspense fallback="loding">{children}</Suspense>;
};

export default PublicRoute;
