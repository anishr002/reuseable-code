import { createAsyncThunk } from "@reduxjs/toolkit";
import AxiosDefaultSetting from "../AxiosDefault";

//get create order service data
export const CreateOrder = createAsyncThunk(
  "paypal/paypaltopaypal",
  async (purchaseUnits, { rejectWithValue }) => {
    try {
      const response = await AxiosDefaultSetting({
        method: "POST",
        url: `/payment/createpayment`,
        data: { purchaseUnits },
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

//capture order when redirect to return page
export const capturePAyment = createAsyncThunk(
  "paypal/capaturepayment",
  async (data, { rejectWithValue }) => {
    try {
      const response = await AxiosDefaultSetting({
        method: "GET",
        url: `/payment/capture/${data}`,
        //data: data,
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);
