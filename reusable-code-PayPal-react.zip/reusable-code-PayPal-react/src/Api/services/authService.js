import AxiosDefaultSetting from "../AxiosDefault";

//fetch data service
const fetchData = async () => {
  try {
    // Example GET request
    const response = await AxiosDefaultSetting({
      method: "GET",
      url: "/users",
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
};

export { fetchData };
