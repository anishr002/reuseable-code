import { createAsyncThunk } from "@reduxjs/toolkit";
import AxiosDefaultSetting from "../AxiosDefault";

// Fetch PayPal Client Token
export const fetchClientToken = createAsyncThunk(
  "paypal/fetchClientToken",
  async (_, { rejectWithValue }) => {
    try {
      const response = await AxiosDefaultSetting({
        method: "GET",
        url: "/advance/generate-client-token",
      });
      return response.data.clientToken;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data?.message || "Error fetching client token"
      );
    }
  }
);

// Create Order
export const advanceCreateOrder = createAsyncThunk(
  "paypal/createOrder",
  async (_, { rejectWithValue }) => {
    try {
      const response = await AxiosDefaultSetting({
        method: "POST",
        url: "/advance/create-order",
      });
      if (response?.data?.id) {
        return response.data.id;
      }
    } catch (error) {
      return rejectWithValue(
        error?.response?.data?.message || "Error creating order"
      );
    }
  }
);

// Capture Order
export const advanceCaptureOrder = createAsyncThunk(
  "paypal/captureOrder",
  async (orderID, { rejectWithValue }) => {
    try {
      const response = await AxiosDefaultSetting({
        method: "POST",
        url: "/advance/capture-order",
        data: { orderID },
      });
      return response.data.capture;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data?.message || "Error capturing payment"
      );
    }
  }
);

export const cancelSubscription = createAsyncThunk(
  "paypal/cancelSubscription",
  async ({ captureId, amount }, { rejectWithValue }) => {
    try {
      const response = await AxiosDefaultSetting({
        method: "POST",
        url: "/advance/cancel",
        data: { captureId, amount },
      });

      if (response.data.success) {
        return response.data.message;
      } else {
        return rejectWithValue(
          response.data.message || "Failed to cancel subscription"
        );
      }
    } catch (error) {
      return rejectWithValue(
        error?.response?.data?.message ||
          "An error occurred while canceling the subscription."
      );
    }
  }
);
