import React from "react";

function PageNotFound() {
  return <div>not found</div>;
}

export default PageNotFound;
