import { createSlice } from "@reduxjs/toolkit";
import {
  advanceCaptureOrder,
  advanceCreateOrder,
  cancelSubscription,
  fetchClientToken,
} from "../../Api/services/AdvancePaymentService";

const initialState = {
  clientToken: null,
  orderId: null,
  captureOrder: null,
  loading: false,
  error: null,
  isRefunded: false,
};

const advancePaypalSlice = createSlice({
  name: "advancePaypal",
  initialState,
  reducers: {
    resetAdvancePaypal: (state) => {
      state.clientToken = null;
      state.orderId = null;
      state.captureOrder = null;
      state.error = null;
      state.loading = false;
      state.isRefunded = false; // Reset the refund status on reset
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchClientToken.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchClientToken.fulfilled, (state, action) => {
        state.clientToken = action.payload;
        state.loading = false;
      })
      .addCase(fetchClientToken.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      .addCase(advanceCreateOrder.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(advanceCreateOrder.fulfilled, (state, action) => {
        state.orderId = action.payload;
        state.loading = false;
      })
      .addCase(advanceCreateOrder.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      .addCase(advanceCaptureOrder.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(advanceCaptureOrder.fulfilled, (state, action) => {
        state.captureOrder = action.payload;
        state.loading = false;
      })
      .addCase(advanceCaptureOrder.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      .addCase(cancelSubscription.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.isRefunded = false; // Reset refund status while loading
      })
      .addCase(cancelSubscription.fulfilled, (state) => {
        state.loading = false;
        state.isRefunded = true; // Set refund status to true on success
      })
      .addCase(cancelSubscription.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
        state.isRefunded = false; // Ensure it's false on failure
      });
  },
});

export const { resetAdvancePaypal } = advancePaypalSlice.actions;

export default advancePaypalSlice.reducer;
