// src/components/HomePage.js
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const HomePage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { purchaseUnits } = location.state || {};

  const handleLogout = () => {
    // Implement your logout functionality here
    console.log("User logged out");
    // Optionally redirect to login or home page after logout
    navigate("/login");
    localStorage.clear();
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-green-400 to-blue-500 p-8">
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
        <h1 className="text-4xl font-bold text-gray-800 mb-6">
          Payment Methods
        </h1>
        <p className="text-gray-600 mb-4">
          Choose your preferred payment method below:
        </p>

        <div className="space-y-4 mb-6">
          <button
            onClick={() =>
              navigate("/paypal-to-paypal", { state: { purchaseUnits } })
            }
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            PayPal to PayPal Account
          </button>
          <button
            onClick={() =>
              navigate("/fastlane-by-paypal", { state: { purchaseUnits } })
            }
            className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            Fastlane By PayPal
          </button>
          <button
            onClick={() =>
              navigate("/advance-checkout", { state: { purchaseUnits } })
            }
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            Advanced Checkout and Refund Method
          </button>
          {/* <button
            onClick={() => navigate("/cart", { state: { purchaseUnits } })}
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            Complete Checkout and Refund Flow
          </button> */}
          <button
            onClick={() => navigate("/user-card", { state: { purchaseUnits } })}
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            Make Payment with Store Card
          </button>
          <button
            onClick={() =>
              navigate("/commisions", { state: { purchaseUnits } })
            }
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            Make Payment with Admin Commissions
          </button>
          <button
            onClick={() =>
              navigate("/admin-commisions", { state: { purchaseUnits } })
            }
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            Admin Approved Payments
          </button>
        </div>

        <button
          onClick={handleLogout}
          className="w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default HomePage;
