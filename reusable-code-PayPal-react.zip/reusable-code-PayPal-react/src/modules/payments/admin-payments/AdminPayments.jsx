import React from "react";
import { useNavigate } from "react-router-dom";

function AdminPayments() {
  const navigate = useNavigate();
  const handleLogout = () => {
    // Implement your logout functionality here
    console.log("User logged out");
    // Optionally redirect to login or home page after logout
    navigate("/login");
    localStorage.clear();
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white shadow-md rounded-lg p-8 space-y-4 w-full max-w-md">
        <h2 className="text-2xl font-semibold text-center text-gray-800 mb-6">
          Admin Payment Management
        </h2>

        <button
          onClick={() => navigate("/admin-orders")}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300 ease-in-out"
        >
          Check Commissions & Make Payment to Designer
        </button>

        <button
          onClick={() => navigate("/payemnt-orders")}
          className="w-full bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition duration-300 ease-in-out"
        >
          Advance Checkout Order List
        </button>
        <button
          onClick={handleLogout}
          className="w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
        >
          Logout
        </button>
      </div>
    </div>
  );
}

export default AdminPayments;
