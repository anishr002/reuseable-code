import React from "react";

function DisplayListproduct() {
  return <div>display product</div>;
}

export default DisplayListproduct;
