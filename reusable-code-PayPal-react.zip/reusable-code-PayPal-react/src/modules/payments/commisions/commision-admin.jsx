import React, { useState, useEffect } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import { FaSpinner } from "react-icons/fa";
import { useLocation } from "react-router-dom";

const CommisionAdmin = () => {
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedCard, setSelectedCard] = useState("");
  const [amount, setAmount] = useState("");
  const [designerData, setDesignerData] = useState([]);
  const [selectedDesigner, setSelectedDesigner] = useState("");
  const location = useLocation();
  const { purchaseUnits } = location.state || {};

  useEffect(() => {
    // Fetch cards
    const fetchCards = async () => {
      try {
        const response = await axios.get(
          "http://localhost:3001/api/v1/cardMethod/list-cards"
        );
        setCards(response?.data);
      } catch (error) {
        console.error("Error fetching cards:", error);
      }
    };

    // Fetch designer data
    const fetchDesigners = async () => {
      try {
        const response = await axios.get(
          "http://localhost:3001/api/v1/commisions/list-designer"
        );
        setDesignerData(response?.data?.data?.result);
      } catch (error) {
        console.error("Error fetching designers:", error);
      }
    };

    fetchCards();
    fetchDesigners();
  }, []);

  const handlePayment = async () => {
    if (!selectedDesigner) {
      toast.error("Please select a designer");
      return;
    }
    if (!selectedCard) {
      toast.error("Please select a card");
      return;
    }
    if (!purchaseUnits[0]?.amount?.value) {
      toast.error("Please add amounts");
      return;
    }

    try {
      setLoading(true);
      const response = await axios.post(
        "http://localhost:3001/api/v1/commisions/send-money",
        {
          cardId: selectedCard,
          purchaseUnits,
          designerId: selectedDesigner,
        }
      );
      if (response.data.success) {
        setLoading(false);
        toast.success("Payment successful!");
      } else {
        setLoading(false);
        toast.error("Payment failed");
      }
    } catch (error) {
      setLoading(false);
      console.error("Error making payment:", error);
      toast.error("Error making payment");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-lg">
        <h2 className="text-2xl font-bold mb-6 text-center">
          Select a Stored Card and Designer
        </h2>

        {/* Select Card Section */}
        <div className="space-y-4 mb-4">
          {cards &&
            cards?.data?.map((card) => (
              <div
                key={card._id}
                className={`flex items-center p-4 border rounded-lg cursor-pointer hover:bg-blue-50 transition-colors ${
                  selectedCard === card._id
                    ? "border-blue-500"
                    : "border-gray-300"
                }`}
                onClick={() => setSelectedCard(card._id)}
              >
                <input
                  type="radio"
                  name="card"
                  value={card._id}
                  checked={selectedCard === card._id}
                  onChange={() => setSelectedCard(card._id)}
                  className="mr-4"
                />
                <div>
                  <p className="text-lg font-semibold">{`${card.brand.toUpperCase()} ****${
                    card.last4
                  }`}</p>
                  <p className="text-sm text-gray-500">{`Expires ${card.expiryMonth}/${card.expiryYear}`}</p>
                </div>
              </div>
            ))}
        </div>

        {/* Select Designer Dropdown */}
        <div className="mb-4">
          <label
            htmlFor="designer"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Select Designer
          </label>
          <select
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={selectedDesigner}
            onChange={(e) => setSelectedDesigner(e.target.value)}
          >
            <option value="">-- Select Designer --</option>
            {designerData?.map((designer) => (
              <option key={designer._id} value={designer._id}>
                {designer.name}
              </option>
            ))}
          </select>
        </div>

        {/* Input Amount */}
        <input
          type="text"
          placeholder="Enter Amount"
          value={
            purchaseUnits && purchaseUnits?.length > 0
              ? purchaseUnits[0]?.amount?.value
              : 100.0
          }
          // onChange={(e) => setAmount(e.target.value)}
          disabled
          className="w-full p-3 mb-4 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        {/* Make Payment Button */}
        <button
          disabled={loading}
          onClick={handlePayment}
          className="w-full p-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300"
        >
          {loading ? (
            <FaSpinner className="animate-spin mr-2" />
          ) : (
            "Make Payment"
          )}
        </button>
      </div>
    </div>
  );
};

export default CommisionAdmin;
