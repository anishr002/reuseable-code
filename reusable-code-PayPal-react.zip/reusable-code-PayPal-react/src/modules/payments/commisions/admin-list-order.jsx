import React, { useState, useEffect } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const AdminOrders = () => {
  const [transactions, setTransactions] = useState([]);
  const [status, setStatus] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const capturedTransaction = transactions?.find(
    (item) => item.status === "captured"
  );
  const navigate = useNavigate();

  const limit = 5;

  // Fetch transactions from API
  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        "http://localhost:3001/api/v1/commisions/list-transactions",
        {
          params: {
            status,
            page,
            limit,
            startDate,
            endDate,
          },
        }
      );
      setTransactions(response.data.data.transactions);
      setTotalPages(response.data.data.totalPages);
    } catch (error) {
      console.error(
        "Error fetching transactions:",
        error.response?.data || error.message
      );
    }
    setLoading(false);
  };

  //paynow api calls
  const handelclicktopaynow = async (id) => {
    try {
      const response = await axios.post(
        "http://localhost:3001/api/v1/commisions/single-payout",
        {
          transactionId: id,
        }
      );
      if (response.data.success) {
        toast.success("Payment successful!");
        fetchTransactions();
      } else {
        toast.error("Payment failed");
      }
    } catch (error) {
      console.error("Error making payment:", error);
      toast.error(error?.response?.data?.message);
    }
  };

  //pay all users
  const handelpayall = async (id) => {
    try {
      const response = await axios.post(
        "http://localhost:3001/api/v1/commisions/multiple-payout"
      );
      if (response.data.success) {
        toast.success("Payment successful!");
        fetchTransactions();
      } else {
        toast.error("Payment failed");
      }
    } catch (error) {
      console.error("Error making payment:", error);
      toast.error(error?.response?.data?.message);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [status, page, startDate, endDate]);
  console.log(status, "status");
  return (
    <div className="container mx-auto p-6">
      <button
        onClick={() => navigate(-1)}
        className="bg-gray-200 text-gray-700 hover:bg-gray-300 hover:text-gray-900 py-2 px-4 rounded-lg shadow-md transition duration-300 ease-in-out"
      >
        Back
      </button>

      <h1 className="text-2xl font-semibold mb-4">Transactions</h1>

      {/* Filters */}
      <div className="mb-4 flex flex-col sm:flex-row gap-4">
        {/* Status Filter */}
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="border p-2 rounded w-full sm:w-1/4"
        >
          <option value="">All Statuses</option>
          <option value="captured">Captured</option>
          <option value="pending_payout">Pending Payout</option>
          <option value="payout_done">Payout Done</option>
        </select>

        {/* Date Filters */}
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className="border p-2 rounded w-full sm:w-1/4"
        />
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className="border p-2 rounded w-full sm:w-1/4"
        />
        {capturedTransaction && (
          <button
            className="bg-red-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-red-600 transition-all duration-300 ease-in-out transform hover:scale-105 active:scale-100 active:bg-red-700"
            onClick={handelpayall}
          >
            Pay All
          </button>
        )}
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-3 text-left">Transaction ID</th>
              <th className="p-3 text-left">Status</th>
              <th className="p-3 text-left">Total-Amount</th>
              <th className="p-3 text-left">Admin-commission</th>
              <th className="p-3 text-left">Payout-for-user</th>
              <th className="p-3 text-left">Date</th>
              <th className="p-3 text-left">PayNow</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="4" className="text-center p-4">
                  Loading...
                </td>
              </tr>
            ) : transactions.length === 0 ? (
              <tr>
                <td colSpan="4" className="text-center p-4">
                  No transactions found
                </td>
              </tr>
            ) : (
              transactions.map((transaction) => (
                <tr key={transaction._id} className="border-t">
                  <td className="p-3">{transaction._id}</td>
                  <td className="p-3 capitalize">{transaction.status}</td>
                  <td className="p-3">${transaction.amount}</td>
                  <td className="p-3">${transaction.commission}</td>
                  <td className="p-3">${transaction.remainingAmount}</td>
                  <td className="p-3">
                    {new Date(transaction.createdAt).toLocaleDateString()}
                  </td>
                  <td className="p-3">
                    {transaction.status === "payout_done" ? (
                      <p className="bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-semibold">
                        Paid
                      </p>
                    ) : (
                      <button
                        className="bg-red-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-red-600 transition-all duration-300 ease-in-out transform hover:scale-105 active:scale-100 active:bg-red-700"
                        onClick={() => handelclicktopaynow(transaction._id)}
                      >
                        Pay Now
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex justify-center">
        <button
          className={`px-4 py-2 mx-1 border rounded ${
            page === 1 ? "bg-gray-300" : "bg-blue-500 text-white"
          }`}
          onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
          disabled={page === 1}
        >
          Previous
        </button>
        <button
          className={`px-4 py-2 mx-1 border rounded ${
            page === totalPages ? "bg-gray-300" : "bg-blue-500 text-white"
          }`}
          onClick={() =>
            setPage((prev) => (prev < totalPages ? prev + 1 : prev))
          }
          disabled={page === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default AdminOrders;
