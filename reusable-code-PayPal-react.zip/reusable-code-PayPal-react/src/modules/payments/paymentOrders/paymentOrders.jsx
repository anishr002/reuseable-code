import React, { useState, useEffect } from "react";
import axios from "axios";
import useDebounce from "../../../components/useDebounce";
import { useNavigate } from "react-router-dom";

const PaymentOrders = () => {
  const [transactions, setTransactions] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 500); // Debounce for 500ms
  const navigate = useNavigate();
  const limit = 5;
  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `http://localhost:3001/api/v1/advance/list-capture-orders?page=${page}&limit=${limit}&search=${debouncedSearch}`
      );
      setTransactions(response.data.orders);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.error(
        "Error fetching transactions:",
        error.response?.data || error.message
      );
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchTransactions();
  }, [page, debouncedSearch]);

  return (
    <div className="container mx-auto p-6">
      <button
        onClick={() => navigate(-1)}
        className="bg-gray-200 text-gray-700 hover:bg-gray-300 hover:text-gray-900 py-2 px-4 rounded-lg shadow-md transition duration-300 ease-in-out"
      >
        Back
      </button>
      <div className="mb-4 flex justify-between items-center">
        <h1 className="text-2xl font-semibold">All Orders Payment</h1>
        {/* Search input */}
        <input
          type="text"
          placeholder="Search by Order ID or Payer Name or Email"
          className="p-2 w-96 border rounded"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-3 text-left">Order ID</th>
              <th className="p-3 text-left">Payer ID</th>
              <th className="p-3 text-left">Payer Name</th>
              <th className="p-3 text-left">Payer Email</th>
              <th className="p-3 text-left">Purchase Products</th>
              <th className="p-3 text-left">Total Amount</th>
              <th className="p-3 text-left">Capture ID</th>
              <th className="p-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="7" className="text-center p-4">
                  Loading...
                </td>
              </tr>
            ) : transactions.length === 0 ? (
              <tr>
                <td colSpan="7" className="text-center p-4">
                  No transactions found
                </td>
              </tr>
            ) : (
              transactions?.map((transaction) => (
                <tr key={transaction?._id} className="border-t">
                  <td className="p-3">{transaction?.orderID}</td>
                  <td className="p-3 capitalize">
                    {transaction?.payer?.payerID}
                  </td>
                  <td className="p-3">
                    {`${transaction?.payer?.name?.givenName || ""} ${
                      transaction?.payer?.name?.surname || ""
                    }`}
                  </td>
                  <td className="p-3">{transaction?.payer?.email}</td>
                  <td className="p-3">
                    {transaction?.purchaseUnits[0]?.item?.map((product) => (
                      <div key={product?._id} className="mb-2 border-b pb-2">
                        <p>
                          <strong>Product Name:</strong> {product?.name}
                        </p>
                        <p>
                          <strong>Quantity:</strong> {product?.quantity}
                        </p>
                        <p>
                          <strong>Price:</strong>{" "}
                          {`$${product?.units_amount?.value} ${product?.units_amount?.currency_code}`}
                        </p>
                      </div>
                    ))}
                  </td>
                  <td className="p-3">
                    {`$${transaction?.purchaseUnits[0]?.payments[0]?.amount?.value} ${transaction?.purchaseUnits[0]?.payments[0]?.amount?.currencyCode}`}
                  </td>
                  <td className="p-3">
                    {transaction?.purchaseUnits[0]?.payments[0]?.captureID}
                  </td>

                  <td className="p-3">{transaction?.status}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex justify-center">
        <button
          className={`px-4 py-2 mx-1 border rounded ${
            page === 1 ? "bg-gray-300" : "bg-blue-500 text-white"
          }`}
          onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
          disabled={page === 1}
        >
          Previous
        </button>
        <button
          className={`px-4 py-2 mx-1 border rounded ${
            page === totalPages ? "bg-gray-300" : "bg-blue-500 text-white"
          }`}
          onClick={() =>
            setPage((prev) => (prev < totalPages ? prev + 1 : prev))
          }
          disabled={page === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default PaymentOrders;
