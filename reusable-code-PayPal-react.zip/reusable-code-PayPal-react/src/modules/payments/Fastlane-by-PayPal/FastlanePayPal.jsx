import React, { useState } from "react";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import toast from "react-hot-toast";
import CancelSubscription from "../advanceCheckout/CancelSubscription";
import { useLocation } from "react-router-dom";

const PayPalButton = () => {
  const [captureData, setCaptureData] = useState({});
  const location = useLocation();
  const { purchaseUnits } = location.state || {};

  console.log(captureData, "captureData");
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-green-400 to-blue-500">
      <PayPalScriptProvider
        options={{
          "client-id":
            "AS7L_i-AZe_D_TdUzLVMJ_vowsz_mZhzodSYCpDpw2o4ZrJAswPCQcp_7EHjSrUy8u5h2J2daZ2__vXd",
        }}
      >
        <PayPalButtons
          createOrder={(data, actions) => {
            return actions.order.create({
              purchase_units: purchaseUnits,
            });
          }}
          onApprove={(data, actions) => {
            return actions?.order?.capture().then((details) => {
              const captureId = details;
              setCaptureData(captureId);
              toast.success(`Transaction completed.`);
            });
          }}
          onError={(err) => {
            console.error("Transaction error: ", err);
            toast.error("Transaction failed");
          }}
        />
      </PayPalScriptProvider>

      {/* Display captured transaction IDs */}
      {Object.keys(captureData).length > 0 && (
        <div className="mt-4">
          <CancelSubscription OrdercaptureId={captureData} />
        </div>
      )}
    </div>
  );
};

export default PayPalButton;
