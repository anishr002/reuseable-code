import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-hot-toast";
import { cancelSubscription } from "../../../Api/services/AdvancePaymentService";

const CancelSubscription = ({ OrdercaptureId }) => {
  const dispatch = useDispatch();
  const { loading, error, isRefunded } = useSelector(
    (state) => state.advancePaypal
  );

  const [captureId, setCaptureId] = useState(
    OrdercaptureId?.purchase_units[0]?.payments?.captures[0]?.id
  );
  const [amount, setAmount] = useState(
    OrdercaptureId?.purchase_units[0]?.payments?.captures[0]?.amount?.value
  );

  const handleCancelSubscription = async () => {
    if (!captureId) {
      toast.error("Please enter a valid capture ID");
      return;
    }

    dispatch(
      cancelSubscription({ captureId, amount: parseFloat(amount) || undefined })
    )
      .unwrap()
      .then(() => {
        toast.success(
          "Subscription canceled and refund processed successfully"
        );
      })
      .catch((err) => {
        toast.error(err || "Failed to cancel subscription");
      });
  };

  return (
    <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full text-center">
      <h2>Cancel Subscription</h2>

      {isRefunded ? (
        <div className="text-green-500 font-semibold">
          Your payment has been refunded successfully.
        </div>
      ) : (
        <>
          <div>
            <label htmlFor="captureId">PayPal Capture ID:</label>
            <input
              type="text"
              id="captureId"
              value={captureId}
              onChange={(e) => setCaptureId(e.target.value)}
              placeholder="Enter the PayPal Capture ID"
              disabled
            />
          </div>

          <div>
            <label htmlFor="amount">Refund Amount :</label>
            <input
              type="number"
              id="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter the amount to refund"
              disabled
            />
          </div>

          <button
            onClick={handleCancelSubscription}
            disabled={loading}
            className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition duration-300"
          >
            {loading ? "Processing..." : "Cancel Subscription"}
          </button>

          {error && <div className="text-red-500 mt-2">{error}</div>}
        </>
      )}
    </div>
  );
};

export default CancelSubscription;
