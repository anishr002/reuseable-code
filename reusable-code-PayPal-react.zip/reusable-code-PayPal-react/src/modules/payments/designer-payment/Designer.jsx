import React, { useState, useEffect } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import { Oval } from "react-loader-spinner"; // For spinner loading effect

const Designer = () => {
  const [transactions, setTransactions] = useState([]);
  const [status, setStatus] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const limit = 5; // Number of items per page

  // Fetch transactions from API
  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        "http://localhost:3001/api/v1/commisions/list-trn-designer",
        {
          params: {
            status,
            page,
            limit,
            startDate,
            endDate,
            designerId: localStorage.getItem("userId"),
          },
        }
      );
      setTransactions(response.data.data.transactions);
      setTotalPages(response.data.data.totalPages);
    } catch (error) {
      console.error(
        "Error fetching transactions:",
        error.response?.data || error.message
      );
      toast.error("Error fetching transactions. Please try again.");
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchTransactions();
  }, [status, page, startDate, endDate]);

  console.log(localStorage.getItem("userID"), "userId");

  const handleLogout = () => {
    // Implement your logout functionality here
    console.log("User logged out");
    // Optionally redirect to login or home page after logout
    navigate("/login");
    localStorage.clear();
  };

  return (
    <div className="container mx-auto p-6">
      <button
        onClick={handleLogout}
        className=" bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md transition duration-300 ease-in-out"
      >
        Logout
      </button>

      <h1 className="text-2xl font-semibold mb-4">Transactions</h1>

      {/* Filters */}
      <div className="mb-4 flex flex-col sm:flex-row gap-4">
        {/* Status Filter */}
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="border p-2 rounded w-full sm:w-1/4 hover:bg-gray-50 transition duration-200 ease-in-out"
        >
          <option value="">All Statuses</option>
          <option value="captured">Captured</option>
          <option value="payout_done">Payout Done</option>
        </select>

        {/* Date Filters */}
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className="border p-2 rounded w-full sm:w-1/4 hover:bg-gray-50 transition duration-200 ease-in-out"
        />
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className="border p-2 rounded w-full sm:w-1/4 hover:bg-gray-50 transition duration-200 ease-in-out"
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-3 text-left">Transaction ID</th>
              <th className="p-3 text-left">Status</th>
              <th className="p-3 text-left">Total Amount</th>
              <th className="p-3 text-left">Date</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="4" className="text-center p-4">
                  <Oval
                    height={40}
                    width={40}
                    color="#4fa94d"
                    ariaLabel="loading"
                    secondaryColor="#4fa94d"
                    strokeWidth={4}
                    strokeWidthSecondary={2}
                  />
                </td>
              </tr>
            ) : transactions.length === 0 ? (
              <tr>
                <td colSpan="4" className="text-center p-4">
                  No transactions found
                </td>
              </tr>
            ) : (
              transactions.map((transaction) => (
                <tr
                  key={transaction._id}
                  className="border-t hover:bg-gray-50 transition duration-200"
                >
                  <td className="p-3">{transaction._id}</td>
                  <td className="p-3">
                    {transaction.status === "payout_done" ? (
                      <p className="bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-semibold">
                        Paid
                      </p>
                    ) : (
                      <p className="bg-red-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-red-600 transition-all duration-300 ease-in-out transform hover:scale-105 active:scale-100 active:bg-red-700">
                        Not done
                      </p>
                    )}
                  </td>
                  <td className="p-3">${transaction.remainingAmount}</td>
                  <td className="p-3">
                    {new Date(transaction.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex justify-center">
        <button
          className={`px-4 py-2 mx-1 border rounded ${
            page === 1 ? "bg-gray-300" : "bg-blue-500 text-white"
          } hover:bg-blue-600 transition duration-200`}
          onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
          disabled={page === 1}
        >
          Previous
        </button>
        <button
          className={`px-4 py-2 mx-1 border rounded ${
            page === totalPages ? "bg-gray-300" : "bg-blue-500 text-white"
          } hover:bg-blue-600 transition duration-200`}
          onClick={() =>
            setPage((prev) => (prev < totalPages ? prev + 1 : prev))
          }
          disabled={page === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default Designer;
