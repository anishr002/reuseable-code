import React from "react";

function Sidebar() {
  return <div>sidebar</div>;
}

export default Sidebar;
