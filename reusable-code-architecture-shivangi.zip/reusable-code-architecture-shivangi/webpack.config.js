const { merge } = require('webpack-merge');
const common = require('./webpack.common');
const Dotenv = require('dotenv-webpack');
require('dotenv').config();

module.exports = (_, argv) => merge(common, {
    mode: 'development',
    entry: './src/index.tsx',
    output: {
        publicPath: process.env.REACT_APP_BASE_URL,
    },
    resolve: {
        extensions: [".tsx", ".ts", ".json", ".js"],
    },
    devServer: {
        port: process.env.PORT,
        historyApiFallback: true,
    },
    plugins: [
        // new HtmlWebpackPlugin({
        //     template: "public/index.html",
        // }),
        new Dotenv()
    ]
});
