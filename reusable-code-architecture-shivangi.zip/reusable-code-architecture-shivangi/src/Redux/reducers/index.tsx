import { ActionType, InitialStateType } from '../../types/index.type';
import { DECREMENT, INCREMENT, RESET } from '../actions';

const initialState: InitialStateType = {
  counterNumber: 0,
};

export const counterReducer = (
  state = initialState,
  action: ActionType = { type: '' },
) => {
  switch (action.type) {
    case INCREMENT:
      return {
        ...state,
        counterNumber: state.counterNumber + 1,
      };
    case DECREMENT:
      return {
        ...state,
        counterNumber: state.counterNumber - 1,
      };
    case RESET:
      return {
        ...state,
        counterNumber: 0,
      };
    default:
      return state;
  }
};
