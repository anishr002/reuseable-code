import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { InitialStateType } from '../../types/index.type';

const initialState: InitialStateType = {
  counterNumber: 0,
};

const counterSlice = createSlice({
  name: 'Counter',
  initialState: initialState,
  reducers: {
    increment: (state, action: PayloadAction<number>) => ({
      ...state,
      counterNumber: state.counterNumber + action.payload,
    }),
    decrement: (state, action: PayloadAction<number>) => ({
      ...state,
      counterNumber: state.counterNumber - action.payload,
    }),
    reset: (state) => ({
      ...state,
      counterNumber: 0,
    }),
  },
});

export const { increment, decrement, reset } = counterSlice.actions;

export default counterSlice.reducer;
