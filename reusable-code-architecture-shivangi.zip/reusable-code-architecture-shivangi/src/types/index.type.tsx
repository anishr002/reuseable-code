export interface ActionType {
  type: string;
}

export interface InitialStateType {
  counterNumber: number;
}

export interface StateType {
  counterNumber: number;
}
