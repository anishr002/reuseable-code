import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { DECREMENT, INCREMENT, RESET } from "../Redux/actions";
import { RootState } from '../Redux/rootReducer';
import { decrement, increment, reset } from '../Redux/Slices/counter.slice';

const Counter: React.FC = () => {
  const dispatch = useDispatch();
  const { counterNumber } = useSelector((state: RootState) => state.counter);

  return (
    <div className="container">
      <h1>Counter APP</h1>
      <div className="counter">
        <button
          type="button"
          className="increment"
          onClick={() => {
            dispatch(increment(1));
          }}
        >
          increment
        </button>
        <div className="counter-value">{counterNumber}</div>
        <button
          type="button"
          className="decrement"
          onClick={() => {
            dispatch(decrement(1));
          }}
        >
          decrement
        </button>
      </div>
      <button
        type="button"
        className="reset"
        onClick={() => {
          dispatch(reset());
        }}
      >
        reset
      </button>
    </div>
  );
};

export default Counter;
