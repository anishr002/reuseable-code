import React from 'react';
import { Provider } from 'react-redux';
import ReactDOM from 'react-dom/client';
import './assets/styles/counter.scss';
import App from './App';
import store from './Redux/store';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement,
);

root.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>,
);
