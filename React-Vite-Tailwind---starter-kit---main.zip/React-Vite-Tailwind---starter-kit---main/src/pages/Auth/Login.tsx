import React from "react";
const Login = () => {
  return (
    <>
      <h1>Login Page</h1>
      <h2></h2>
    </>
  );
};

export default Login;
