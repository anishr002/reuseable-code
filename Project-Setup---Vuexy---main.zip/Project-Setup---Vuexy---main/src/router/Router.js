// ** Router imports
import { Navigate, useRoutes } from "react-router-dom";

// ** GetRoutes
import { getRoutes } from "./routes";

// ** Hooks Imports
import { useLayout } from "@hooks/useLayout";
import { lazy } from "react";


// const SecondPage = lazy(() => import("../views/SecondPage"));
const Login = lazy(() => import("../views/Login"));
const Register = lazy(() => import("../views/Register"));
const ForgotPassword = lazy(() => import("../views/ForgotPassword"));
const Error = lazy(() => import("../views/Error"));

// ** Default Route
const DefaultRoute = "/home";

const Router = () => {
  // ** Hooks
  const { layout } = useLayout();

  const allRoutes = getRoutes(layout);

  const routes = useRoutes([
    {
      path: "/",
      index: true,
      element: <Navigate replace to={DefaultRoute} />,
    },
    // {
    //   path: "/second-page",
    //   element: <SecondPage />,
    // },
    {
      path: "/login",
      element: <Login />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "/register",
      element: <Register />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "/forgot-password",
      element: <ForgotPassword />,
      meta: {
        layout: "blank",
      },
    },
    {
      path: "/error",
      element: <Error />,
      meta: {
        layout: "blank",
      },
    },
    ...allRoutes]);

  return routes;
};

export default Router;
