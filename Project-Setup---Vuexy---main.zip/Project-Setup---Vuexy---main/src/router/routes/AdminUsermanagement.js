// ** React Imports
import { lazy } from 'react'
import { Navigate } from 'react-router';

const Home = lazy(() => import("../../views/Home"));
// const AdminProfileDetails = lazy(() => import("../../views/AdminProfile/AdminProfileDetails"));
// const AdminProfileEditForm = lazy(() => import("../../views/AdminProfile/AdminProfileEditForm"));


// ** Default Route
const DefaultRoute = "/login";

const AdminUserRoutes = [
    {
        path: "/home",
        element: <Home />,
    },

    // {
    //     path: "/profiledetails",
    //     element: <AdminProfileDetails />,
    //     id: ["Admin", "Super Admin", "RFS"]


    // },
    // {
    //     path: "/editprofile/:id",
    //     element: <AdminProfileEditForm />,
    //     id: ["Admin", "Super Admin", "RFS"]

    // },
]

export default AdminUserRoutes
