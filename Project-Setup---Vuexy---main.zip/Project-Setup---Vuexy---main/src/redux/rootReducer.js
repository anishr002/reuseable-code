import layoutSlice from '../redux/layout'
import navlayoutSlice from '../redux/navbar'
import { combineReducers } from "@reduxjs/toolkit";
import authSlice from '../redux/slices/auth/authSlice'

const combinedReducer = combineReducers({
    signin: authSlice,
    navbar: navlayoutSlice,
    layout: layoutSlice,
});

const rootReducer = (state, action) => {
    if (
        action.type === "signin/logoutUser" ||
        action.type === "signin/logoutUserAdmin"
    ) {
        state = undefined;
    }
    return combinedReducer(state, action);
};

export default rootReducer;
