import { Briefcase, Home, Users, DollarSign, HelpCircle } from "react-feather"

export default [
  {
    id: "Dashboard",
    title: "Dashboard",
    icon: <Home size={20} />,
    navLink: "/dashboard",
  },
  {
    id: "staffManagement",
    title: "Staff Management",
    icon: <Briefcase size={20} />,
    navLink: "/staff-management",
  },
  {
    id: "users",
    title: "Users",
    icon: <Users size={20} />,
    navLink: "/users",
  },
  {
    id: "payment",
    title: "Payment",
    icon: <DollarSign size={20} />,
    navLink: "/payment",
  },
  {
    id: "SupportTicket",
    title: "Support ticket",
    icon: <HelpCircle size={20} />,
    navLink: "/support-ticket",
  },
]
