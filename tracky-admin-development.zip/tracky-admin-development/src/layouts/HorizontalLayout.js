// ** React Imports
import { Outlet } from "react-router-dom"

// ** Core Layout Import
// !Do not remove the Layout import
import Layout from "@layouts/HorizontalLayout"

// ** Menu Items Array
import navigation from "@src/navigation/horizontal"
import { Briefcase, Home, Users, DollarSign, HelpCircle } from "react-feather"
import { useSelector } from "react-redux"

const HorizontalLayout = (props) => {
  // const [menuData, setMenuData] = useState([])
  const user = useSelector((state) => state?.auth?.user)
  let horizontal = [
    {
      id: "Dashboard",
      title: "Dashboard",
      icon: <Home size={20} />,
      navLink: "/dashboard",
    },
  ]

  if (user.isStaffManagement) {
    let StaffManagementMenu = {
      id: "staffManagement",
      title: "Staff Management",
      icon: <Briefcase size={20} />,
      navLink: "/staff-management",
    }

    horizontal.push(StaffManagementMenu)
  }
  if (user.isUsers) {
    let users = {
      id: "users",
      title: "Users",
      icon: <Users size={20} />,
      navLink: "/users",
    }
    horizontal.push(users)
  }
  if (user.isPayment) {
    let payment = {
      id: "payment",
      title: "Payment",
      icon: <DollarSign size={20} />,
      navLink: "/payment",
    }
    horizontal.push(payment)
  }
  if (user.isSupportTicket) {
    let supportTicket = {
      id: "SupportTicket",
      title: "Support ticket",
      icon: <HelpCircle size={20} />,
      navLink: "/support-ticket",
    }
    horizontal.push(supportTicket)
  }

  // ** For ServerSide navigation
  // useEffect(() => {
  //   axios.get(URL).then(response => setMenuData(response.data))
  // }, [])

  return (
    <Layout menuData={horizontal} {...props}>
      <Outlet />
    </Layout>
  )
}

export default HorizontalLayout
