import { toast } from "react-toastify"

var Toaster = toast

export { Toaster }
