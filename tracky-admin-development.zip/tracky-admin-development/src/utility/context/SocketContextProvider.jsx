import { createContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
export const SocketContext = createContext();

export const SocketContextProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isSocketConnected, setIsConnected] = useState(null);

const ENDPOINT = import.meta.env.VITE_APP_API_ADMIN_IO;


  useEffect(() => {
    setSocket(io(ENDPOINT));
  }, []);

  useEffect(() => {
    if (socket !== null && socket !== undefined) {
      function onConnect() {
        setIsConnected(true);
      }

      function onDisconnect() {
        setIsConnected(false);
      }

      socket?.on('connect', onConnect);
      socket?.on('disconnect', onDisconnect);

      return () => {
        socket?.off('connect', onConnect);
        socket?.off('disconnect', onDisconnect);
      };
    }
  }, [socket]);

  return (
    <>
      <SocketContext.Provider value={{ socket, isSocketConnected }}>
        {children}
      </SocketContext.Provider>
    </>
  );
};
