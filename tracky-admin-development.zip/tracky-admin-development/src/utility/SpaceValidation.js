// Check if the space key is pressed and it's the first character
export const handleKeyDown = (event) => {
  if (event.key === " " && event.target.selectionStart === 0) {
    event.preventDefault()
  }
}
