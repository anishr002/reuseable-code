// ** React Imports
import { Fragment, useEffect, useState,useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import "./NotificationDropdown.css"

// ** Custom Components
import Avatar from '@components/avatar';

// ** Third Party Components
import classnames from 'classnames';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Bell, X, Check, AlertTriangle } from 'react-feather';

// ** Reactstrap Imports
import {
  Button,
  Badge,
  Input,
  DropdownMenu,
  DropdownItem,
  DropdownToggle,
  UncontrolledDropdown,
  Spinner
} from 'reactstrap';

// ** Avatar Imports

import { getAllNotificationList, markAllasRead, markSingleRead, AllNotificationDataFun } from '../../../../redux/Slices/notificationSlice';
import { SocketContext } from '../../../../utility/context/SocketContextProvider';

const NotificationDropdown = () => {
  const dispatch = useDispatch();
  const accessToken = useSelector((state) => state?.auth?.accessToken);
  const notiData = useSelector(
    (state) => state?.notification?.AllNotificationData?.notificationList
  );
  const unreadnotiData = useSelector(
    (state) => state?.notification?.AllNotificationData?.un_read_count
  );

  const allNotiObj = useSelector(
    (state) => state?.notification?.AllNotificationData
  );

  const notilistLoading = useSelector(
    (state) => state?.notification?.getAllNotiListLoader
  );


  const PofileData = useSelector((state) => state?.profile?.profileData);


  const totalCountnotiData = useSelector(
    (state) => state?.notification?.AllNotificationData?.totalCount
  );

  const [notilistlimt, setNotilistLimit] = useState(5);
  const { socket, isSocketConnected } = useContext(SocketContext);

  useEffect(() => {

    socket?.emit('ROOM', { id: PofileData?._id });

    socket?.on('NOTIFICATION', (response) => {
      // payload.un_read_count
      dispatch(AllNotificationDataFun({
        ...allNotiObj,
        un_read_count: response.un_read_count
      }));
      catchEvent();
      socket?.emit('CONFIRMATION', { event: 'NOTIFICATION' });
    });

    return () => {
      socket?.off('NOTIFICATION');
    };
  }, [socket]);

  const allNotiListPayload = {
    limit: notilistlimt,
  };

  useEffect(() => {
    let eventReceived = false;
    dispatch(getAllNotificationList(accessToken, allNotiListPayload, eventReceived));
  }, [notilistlimt]);

  const MarkAllNotificationAsRead = () =>{
    const markAllPayload = {
      notification_id: 'all',
    }
    dispatch(markAllasRead(accessToken,markAllPayload, allNotiListPayload));
  }

  const MarkSingleNotificationAsRead = (noti) =>{
    if(noti?.is_read == false){
    const markSinglePayload = {
      notification_id: noti?._id
    }
    dispatch(markSingleRead(accessToken,markSinglePayload, allNotiListPayload));
  }
  }

  const ShowMoreNotiData = () =>{
    setNotilistLimit((prevCount)=>prevCount + 5)
  }

  const fetchData = (e) =>{
    e.preventDefault();
    let eventReceived = false;
    dispatch(getAllNotificationList(accessToken, allNotiListPayload,eventReceived));
  }


  const catchEvent = () =>{
    let eventReceived = true;
    dispatch(getAllNotificationList(accessToken, allNotiListPayload,eventReceived));
  }

  // ** Notification Array


  // ** Function to render Notifications
  /*eslint-disable */
  const renderNotificationItems = () => {
    return (
      <PerfectScrollbar
        component='li'
        className='media-list scrollable-container'
        options={{
          wheelPropagation: false,
        }}>
        {/* {notificationsArray.map((item, index) => { */}
        {notilistLoading ?
          (
            <>
            <div className="d-flex justify-content-center align-items-center loader-container my-5">
              <Spinner />
            </div>
            </>
          ) :
        (<>
        {notiData &&
          notiData.length !== 0 &&
          notiData.map((item, index) => {
            return (
              <>
              {/* <div className={`${item?.is_read == false ? "bg-info" : "" }d-flex list-item d-flex align-items-start`}> */}
              <div className={classnames('d-flex list-item d-flex align-items-start mb-1', {
                    'NotiUnread': !item?.is_read
                  })} key={index} onClick={()=>{MarkSingleNotificationAsRead(item)}}>
                  <div className=''>
                  {item?.message}
                  </div>
              </div>
              </>
            );
          })}
          {totalCountnotiData !== null && totalCountnotiData !== undefined  && totalCountnotiData == 0 ?
            (
              <>
              <div className='d-flex list-item d-flex align-items-start mb-1'>
                <div>
                No any Notification
                </div>
              </div>
              </>
            ) : (
              <>
              </>
            )
          }
          </>
          )}

      </PerfectScrollbar>
    );
  };
  /*eslint-enable */

  return (
    <UncontrolledDropdown
      tag='li'
      className='dropdown-notification nav-item me-25'
      // onClick={fetchData}
      >
      <DropdownToggle
        tag='a'
        className='nav-link'
        href='/'
        onClick={(e) => fetchData(e)}>
        {/* <div onClick={()=>{fetchData}}> */}
        <Bell size={21} />
        <Badge pill color='danger' className='badge-up'>
          {unreadnotiData !== null && unreadnotiData !== undefined
            ? unreadnotiData
            : ''}
        </Badge>
        {/* </div> */}
      </DropdownToggle>
      <DropdownMenu end tag='ul' className='dropdown-menu-media mt-0'>
        <li className='dropdown-menu-header'>
          <DropdownItem className='d-flex' tag='div' header>
            <h4 className='notification-title mb-0 me-auto'>Notifications</h4>
            <Badge tag="div" color="light-primary" pill className='cursor-pointer' onClick={MarkAllNotificationAsRead}>

            {unreadnotiData && unreadnotiData !== undefined && unreadnotiData !== null && unreadnotiData >0 ? "Read all notifications" : ""}
            </Badge>
          </DropdownItem>
        </li>
        {renderNotificationItems()}
        { totalCountnotiData && totalCountnotiData !== undefined && totalCountnotiData !== null && totalCountnotiData > notiData?.length  ?
          (
            <>
            <li className='dropdown-menu-footer'>
          <Button color='primary' block onClick={ShowMoreNotiData}>
            Show more
          </Button>
        </li>
            </>

        )
          :
        (<></>)
        }
      </DropdownMenu>
    </UncontrolledDropdown>
  );
};

export default NotificationDropdown;
