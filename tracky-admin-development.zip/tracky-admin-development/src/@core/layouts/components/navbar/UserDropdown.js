// ** React Imports
import { Link } from "react-router-dom"

// ** Custom Components
import Avatar from "@components/avatar"

// ** Third Party Components
import {
  User,
  Mail,
  CheckSquare,
  MessageSquare,
  Settings,
  CreditCard,
  HelpCircle,
  Power,
} from "react-feather"

// ** Reactstrap Imports
import {
  UncontrolledDropdown,
  DropdownMenu,
  DropdownToggle,
  DropdownItem,
} from "reactstrap"

// ** Default Avatar Image
import defaultAvatar from "@src/assets/images/portrait/small/avatar-s-11.jpg"
import alex_img from "../../../../../src/assets/images/logo/alex_img.svg"

import { resetAuth } from "../../../../redux/Slices/authSlice"
import { resetUser } from "../../../../redux/Slices/userSlice"
import { resetStaff } from "../../../../redux/Slices/StaffSlice"
import { restProfile } from "../../../../redux/Slices/profileSlice"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { GetProfile } from "../../../../redux/Slices/profileSlice"
import { resetNotification } from "../../../../redux/Slices/notificationSlice"
import { resetPayment } from "../../../../redux/Slices/PaymentSlice"


const UserDropdown = () => {
  const dispatch = useDispatch()
  // const UserObj = useSelector((state) => state?.auth?.user);
  const UserObj = useSelector((state) => state?.profile?.profileData)
  const accessToken = useSelector((state) => state?.auth?.accessToken)

  // function mergeStrings(string1, string2) {
  //   const result = string1 + " " + string2

  //   if (result.length > 18) {
  //     return result.substring(0, 15) + "..."
  //   }

  //   return result
  // }

  // function capitalizeFirstLetter(str) {
  //   return str.charAt(0).toUpperCase() + str.slice(1)
  // }

  // let nameToShow = mergeStrings(
  //   capitalizeFirstLetter(UserObj?.first_name),
  //   capitalizeFirstLetter(UserObj?.last_name)
  // )
  useEffect(() => {
    dispatch(GetProfile(accessToken))
  }, [])

  return (
    <UncontrolledDropdown tag="li" className="dropdown-user nav-item">
      <DropdownToggle
        href="/"
        tag="a"
        className="nav-link dropdown-user-link"
        onClick={(e) => e.preventDefault()}
      >
        <div className="user-nav d-sm-flex d-none">
          <span className="user-name fw-bold">
            {/* {nameToShow != undefined && nameToShow != null && nameToShow} */}

            {UserObj?.first_name &&
              UserObj?.last_name &&
              UserObj?.last_name !== undefined &&
              UserObj?.first_name !== undefined && (
                <>
                  {UserObj?.first_name.charAt(0).toUpperCase() +
                    UserObj?.first_name.slice(1)}{" "}
                  {UserObj?.last_name.charAt(0).toUpperCase() +
                    UserObj?.last_name.slice(1)}
                </>
              )}
          </span>
          {/* <span className="user-status">Admin</span> */}
        </div>
        <Avatar img={alex_img} imgHeight="40" imgWidth="40" />
      </DropdownToggle>
      <DropdownMenu end>
        <DropdownItem
          tag={Link}
          to="/profile"
          // onClick={(e) => e.preventDefault()}
        >
          <User size={14} className="me-75" />
          <span className="align-middle">Profile</span>
        </DropdownItem>
        {/* <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <Mail size={14} className="me-75" />
          <span className="align-middle">Inbox</span>
        </DropdownItem> */}
        {/* <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <CheckSquare size={14} className="me-75" />
          <span className="align-middle">Tasks</span>
        </DropdownItem> */}
        {/* <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <MessageSquare size={14} className="me-75" />
          <span className="align-middle">Chats</span>
        </DropdownItem> */}
        {/* <DropdownItem divider />
        <DropdownItem
          tag={Link}
          to="/pages/"
          onClick={(e) => e.preventDefault()}
        >
          <Settings size={14} className="me-75" />
          <span className="align-middle">Settings</span>
        </DropdownItem> */}
        {/* <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <CreditCard size={14} className="me-75" />
          <span className="align-middle">Pricing</span>
        </DropdownItem>
        <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <HelpCircle size={14} className="me-75" />
          <span className="align-middle">FAQ</span>
        </DropdownItem> */}
        <DropdownItem
          tag={Link}
          to="/login"
          onClick={() => {
            dispatch(resetAuth())
            dispatch(resetUser())
            dispatch(resetStaff())
            dispatch(restProfile())
            dispatch(resetNotification())
            dispatch(resetPayment())
          }}
        >
          <Power size={14} className="me-75" />
          <span className="align-middle">Logout</span>
        </DropdownItem>
      </DropdownMenu>
    </UncontrolledDropdown>
  )
}

export default UserDropdown
