// ** React Imports
import { Navigate } from "react-router-dom"
import { useContext, Suspense } from "react"

// ** Context Imports
import { AbilityContext } from "@src/utility/context/Can"
import { useSelector } from "react-redux"

// ** Spinner Import
import Spinner from "../spinner/Loading-spinner"

const PrivateRoute = ({ children, route }) => {
  // ** Hooks & Vars
  // const ability = useContext(AbilityContext)
  const accessToken = useSelector((state) => state?.auth?.accessToken)
  const user = accessToken
  // const user = JSON.parse(localStorage.getItem("userData"));
  const permissionObj = useSelector((state) => state?.auth?.user)

  if (route) {
    let action = null
    let resource = null
    let restrictedRoute = false

    if (route.meta) {
      action = route.meta.action
      resource = route.meta.resource
      restrictedRoute = route.meta.restricted
    }
    if (!user) {
      return <Navigate to="/login" />
    }
    if (user && restrictedRoute) {
      return <Navigate to="/" />
    }
    // if (user && restrictedRoute && user.role === "client") {
    //   return <Navigate to="/access-control" />
    // }
    // if (user && !ability.can(action || "read", resource)) {
    //   return <Navigate to="/misc/not-authorized" replace />
    // }
    if (
      (route.path == "/staff-management" || route.path == "/staff") &&
      !permissionObj.isStaffManagement
    ) {
      return <Navigate to="/auth/not-auth" />
    }

    if (
      (route.path == "/users/:id" || route.path == "/users") &&
      !permissionObj.isUsers
    ) {
      return <Navigate to="/auth/not-auth" />
    }
    if (route.path == "/payment" && !permissionObj.isPayment) {
      return <Navigate to="/auth/not-auth" />
    }
    if (route.path == "/support-ticket" && !permissionObj.isSupportTicket) {
      return <Navigate to="/auth/not-auth" />
    }

    // if (
    //   (route.path == "/login" ||
    //     route.path == "/reset-password" ||
    //     route.path == "/forgot-password") &&
    //   accessToken
    // ) {
    //   return <Navigate to="/dashboard" />
    // }
  }

  return (
    <Suspense fallback={<Spinner className="content-loader" />}>
      {children}
    </Suspense>
  )
}

export default PrivateRoute
