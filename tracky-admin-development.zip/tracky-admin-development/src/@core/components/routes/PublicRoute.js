// ** React Imports
import { Suspense } from "react"
import { Navigate } from "react-router-dom"

// ** Utils
import { getUserData, getHomeRouteForLoggedInUser } from "@utils"
import { useSelector } from "react-redux"

const PublicRoute = ({ children, route }) => {
  if (route) {
    // const user = getUserData();
    const accessToken = useSelector((state) => state?.auth?.accessToken)
    const user = accessToken

    const getHomeRoute = () => {
      // const user = getUserData()
      if (accessToken) {
        return "/dashboard"
      } else {
        return "/login"
      }
    }

    const restrictedRoute = route.meta && route.meta.restricted

    if (user && restrictedRoute) {
      return <Navigate to={getHomeRoute()} />
    }

    if (
      (route.path == "/login" ||
        route.path == "/reset-password" ||
        route.path == "/forgot-password") &&
      accessToken
    ) {
      return <Navigate to="/dashboard" />
    }
  }

  return <Suspense fallback={null}>{children}</Suspense>
}

export default PublicRoute
