// counterSlice.js
import { createSlice } from "@reduxjs/toolkit"
import axios from "axios"
import { Toaster } from "../../utility/Global"
import { resetAuth } from "../Slices/authSlice"
import { resetUser } from "../Slices/userSlice"
import { restProfile } from "../Slices/profileSlice"
import { resetNotification } from "../Slices/notificationSlice"
import { resetPayment } from "../Slices/PaymentSlice"


const initialState = {
  saveStaffLoader: false,
  getStaffLoader: false,
  updateSingleStaffLoader: false,
  StaffData: {},
  getSingleStaffLoader: false,
  getSingleStaffData: {},
  delSingleStaffLoader: false,
  changeStatusLoader: false,
}

const apiUrl = import.meta.env.VITE_APP_API_ADMIN_URL

// Login API
export const saveStaff = (accessToken, data, navigate) => async (dispatch) => {
  try {
    dispatch(saveStaffLoaderFun(true))
    const response = await axios.post(`${apiUrl}Staff/create`, data, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response?.data?.success == true) {
      dispatch(saveStaffLoaderFun(false))
      Toaster.success(response?.data?.message)
      navigate("/staff-management")
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(saveStaffLoaderFun(false))
      Toaster.error(err?.response?.data?.message)
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(saveStaffLoaderFun(false))
  }
}

export const getStaff = (accessToken, apiPayload) => async (dispatch) => {
  try {
    dispatch(getStaffLoaderFun(true))
    const response = await axios.post(`${apiUrl}Staff/list`, apiPayload, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response?.data?.success == true) {
      dispatch(getStaffLoaderFun(false))
      dispatch(StaffDataFun(response?.data?.data))
      // Toaster.success(response?.data?.message)
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(getStaffLoaderFun(false))
      Toaster.error(err?.response?.data?.message)
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(getStaffLoaderFun(false))
  }
}

export const getSingleStaff = (accessToken, id) => async (dispatch) => {
  try {
    dispatch(getSingleStaffLoaderFun(true))
    const response = await axios.get(`${apiUrl}Staff/fetch/${id}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response?.data?.success == true) {
      dispatch(getSingleStaffLoaderFun(false))
      dispatch(getSingleStaffDataFun(response?.data?.data))
      // Toaster.success(response?.data?.message)
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(getSingleStaffLoaderFun(false))
      Toaster.error(err?.response?.data?.message)
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(getSingleStaffLoaderFun(false))
  }
}

export const updateSingleStaff =
  (accessToken, data, id, navigate) => async (dispatch) => {
    try {
      dispatch(getSingleStaffLoaderFun(true))

      const response = await axios.put(`${apiUrl}Staff/update/${id}`, data, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      })

      if (response?.data?.success == true) {
        dispatch(getSingleStaffLoaderFun(false))
        dispatch(getSingleStaffDataFun(response?.data?.data))
        Toaster.success(response?.data?.message)
        navigate("/staff-management")
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(getSingleStaffLoaderFun(false))
        Toaster.error(err?.response?.data?.message)
      }

      if (err?.response?.status === 401) {
        dispatch(resetAuth())
        dispatch(resetUser())
        dispatch(resetStaff())
        dispatch(restProfile())
        dispatch(resetNotification())
        dispatch(resetPayment())
      }

      dispatch(getSingleStaffLoaderFun(false))
    }
  }

export const delSingleStaff = (accessToken, id, Dataa) => async (dispatch) => {
  try {
    dispatch(delSingleStaffLoaderFun(true))

    const response = await axios.delete(`${apiUrl}Staff/delete/${id}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response?.data?.success == true) {
      dispatch(delSingleStaffLoaderFun(false))
      Toaster.success(response?.data?.message)
      dispatch(getStaff(accessToken, Dataa))
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(delSingleStaffLoaderFun(false))
      Toaster.error(err?.response?.data?.message)
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(delSingleStaffLoaderFun(false))
  }
}

export const ChangeStaffStatus =
  (id, data, accessToken, Dataa) => async (dispatch) => {
    try {
      dispatch(changeStatusLoaderFun(true))

      const response = await axios.put(
        `${apiUrl}Staff/update-status/${id}`,
        data,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )

      if (response.data.success == true) {
        dispatch(changeStatusLoaderFun(false))
        dispatch(getStaff(accessToken, Dataa))
        Toaster.success(response.data.message)
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(changeStatusLoaderFun(false))
        Toaster.error(err.response.data.message)
      }
      if (err?.response?.status === 401) {
        dispatch(resetAuth())
        dispatch(resetUser())
        dispatch(resetStaff())
        dispatch(restProfile())
        dispatch(resetNotification())
        dispatch(resetPayment())
      }
      dispatch(changeStatusLoaderFun(false))
    }
  }

const StaffSlice = createSlice({
  name: "StaffSlice",
  initialState,
  reducers: {
    saveStaffLoaderFun: (state, action) => {
      state.saveStaffLoader = action.payload
    },
    getStaffLoaderFun: (state, action) => {
      state.getStaffLoader = action.payload
    },
    StaffDataFun: (state, action) => {
      state.StaffData = action.payload
    },
    getSingleStaffLoaderFun: (state, action) => {
      state.getSingleStaffLoader = action.payload
    },
    getSingleStaffDataFun: (state, action) => {
      state.getSingleStaffData = action.payload
    },
    delSingleStaffLoaderFun: (state, action) => {
      state.delSingleStaffLoader = action.payload
    },
    updateSingleStaffLoaderFun: (state, action) => {
      state.updateSingleStaffLoader = action.payload
    },
    changeStatusLoaderFun: (state, action) => {
      state.changeStatusLoader = action.payload
    },

    resetStaff: (state, action) => {
      state.saveStaffLoader = false
      state.getStaffLoader = false
      state.StaffData = {}
      state.getSingleStaffLoader = false
      state.getSingleStaffData = {}
      state.delSingleStaffLoader = false
      state.updateSingleStaffLoader = false
      state.changeStatusLoader = false
    },
  },
})

export const {
  saveStaffLoaderFun,
  getStaffLoaderFun,
  StaffDataFun,
  getSingleStaffLoaderFun,
  getSingleStaffDataFun,
  delSingleStaffLoaderFun,
  resetStaff,
  updateSingleStaffLoaderFun,
  changeStatusLoaderFun,
} = StaffSlice.actions
export default StaffSlice.reducer
