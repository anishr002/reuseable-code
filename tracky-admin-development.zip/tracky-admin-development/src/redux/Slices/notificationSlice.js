import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { Toaster } from "../../utility/Global";
import { resetAuth } from "../../redux/Slices/authSlice"
import { resetUser } from "../../redux/Slices/userSlice"
import { resetStaff } from "../../redux/Slices/StaffSlice"
import { restProfile } from "../../redux/Slices/profileSlice"
import { resetPayment } from "../../redux/Slices/PaymentSlice"

const initialState = {
  getAllNotiListLoader: false,
  AllNotificationData: {},
  marksinglereadload: false,
  markallreadload : false
};

const apiUrl = import.meta.env.VITE_APP_API_ADMIN_URL;

export const getAllNotificationList = (accessToken, apiPayload,eventReceived) => async (dispatch) => {
  try {
    if(eventReceived != true){
    dispatch(getAllNotiListLoaderFun(true));
    }

    const response = await axios.post(`${apiUrl}admin/notification/list`, apiPayload, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });


    if (response?.data?.success == true) {
      if(eventReceived != true){
      dispatch(getAllNotiListLoaderFun(false));
    }
      dispatch(AllNotificationDataFun(response?.data?.data));
      // Toaster.success(response?.data?.data?.message)
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      if(eventReceived != true){
      dispatch(getAllNotiListLoaderFun(false));
      }
      Toaster.error(err?.response?.data?.data?.message);
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }
    if(eventReceived != true){
    dispatch(getAllNotiListLoaderFun(false));
    }
  }
};


export const markAllasRead = (token,data,notiPayload ) => async (dispatch) => {
  try {
        dispatch(markallreadloadFun(true));
        dispatch(getAllNotiListLoaderFun(true));
    const response = await axios.post(
      `${apiUrl}admin/notification/read`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response?.data?.success == true) {

      dispatch(markallreadloadFun(false));
      dispatch(getAllNotiListLoaderFun(false));
      dispatch(getAllNotificationList(token,notiPayload ));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(markallreadloadFun(false));
      dispatch(getAllNotiListLoaderFun(false));
    }
    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }
    dispatch(markallreadloadFun(false));
    dispatch(getAllNotiListLoaderFun(false));
  }
  dispatch(markallreadloadFun(false));
  dispatch(getAllNotiListLoaderFun(false));
};

export const markSingleRead = (token,data,notiPayload ) => async (dispatch) => {
  try {
        dispatch(marksinglereadloadFun(true));
        dispatch(getAllNotiListLoaderFun(true));
    const response = await axios.post(
      `${apiUrl}admin/notification/read`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response?.data?.success == true) {

      dispatch(marksinglereadloadFun(false));
      dispatch(getAllNotiListLoaderFun(false));
      dispatch(getAllNotificationList(token,notiPayload ));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(marksinglereadloadFun(false));
      dispatch(getAllNotiListLoaderFun(false));
    }
    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())

    }
    dispatch(marksinglereadloadFun(false));
    dispatch(getAllNotiListLoaderFun(false));
  }
  dispatch(marksinglereadloadFun(false));
  dispatch(getAllNotiListLoaderFun(false));
};

const notificationSlice = createSlice({
  name: "notificationSlice",
  initialState,
  reducers: {
    getAllNotiListLoaderFun: (state, action) => {
      state.getAllNotiListLoader = action.payload;
    },
    marksinglereadloadFun: (state, action) => {
      state.marksinglereadload = action.payload;
    },
    markallreadloadFun: (state, action) => {
      state.markallreadload = action.payload;
    },
    AllNotificationDataFun: (state, action) => {
      state.AllNotificationData = action.payload;
    },
    resetNotification: (state, action) => {
      state.getAllNotiListLoader = false;
      state.marksinglereadload = false;
      state.markallreadload = false;
      state.AllNotificationData = {};
    },
  },
});

export const { getAllNotiListLoaderFun, AllNotificationDataFun,marksinglereadloadFun,markallreadloadFun,  resetNotification } =
  notificationSlice.actions;
export default notificationSlice.reducer;
