// counterSlice.js
import { createSlice } from "@reduxjs/toolkit"
import axios from "axios"
import { Toaster } from "../../utility/Global"

const initialState = {
  sendForgotPWemailLoading: false,
  resetPassLoadFlag: false,
  resendEmailLoadFlag: false,
}

const apiUrl = import.meta.env.VITE_APP_API_BASE_URL

// Login API
export const sendForgotPWemail = (data, navigate) => async (dispatch) => {
  try {
    dispatch(sendForgotPWemailLoadingFlag(true))
    const response = await axios.post(`${apiUrl}forgetPassword`, data)

    if (response.data.success == true) {
      dispatch(sendForgotPWemailLoadingFlag(false))
      navigate(`/verifyemail?id=${data.email}`)
      Toaster.success(response?.data?.message)

      // toast.success(<ToastContent message={response.data.message} />, {
      //   position: "top-right",
      //   autoClose: 3000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "light",
      // });
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(sendForgotPWemailLoadingFlag(false))
      Toaster.error(err?.response?.data?.message)

      // toast.error(<ToastContent message={err?.response?.data?.message} />, {
      //   position: "top-right",
      //   autoClose: 3000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "light",
      // });
    }
    dispatch(sendForgotPWemailLoadingFlag(false))
  }
}

export const resetPass = (data, navigate) => async (dispatch) => {
  try {
    dispatch(resetPassLoadFlagFun(true))
    const response = await axios.post(`${apiUrl}resetPassword`, data)

    if (response.data.success == true) {
      dispatch(resetPassLoadFlagFun(false))
      Toaster.success(response?.data?.message)
      navigate(`/login`)
    }

  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(resetPassLoadFlagFun(false))
    }
    dispatch(resetPassLoadFlagFun(false))
  }
}

export const resendEmail = (data) => async (dispatch) => {
  try {
    dispatch(resendEmailLoadFlagFun(true))
    const response = await axios.post(`${apiUrl}resendEmail`, data)

    if (response.data.success == true) {
      dispatch(resendEmailLoadFlagFun(false))
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(resendEmailLoadFlagFun(false))
    }
    dispatch(resendEmailLoadFlagFun(false))
  }
}

const PasswordSlice = createSlice({
  name: "PasswordSlice",
  initialState,
  reducers: {
    sendForgotPWemailLoadingFlag: (state, action) => {
      state.sendForgotPWemailLoading = action.payload
    },
    resetPassLoadFlagFun: (state, action) => {
      state.resetPassLoadFlag = action.payload
    },
    resendEmailLoadFlagFun: (state, action) => {
      state.resendEmailLoadFlag = action.payload
    },
  },
})

export const {
  sendForgotPWemailLoadingFlag,
  resetPassLoadFlagFun,
  resendEmailLoadFlagFun,
} = PasswordSlice.actions
export default PasswordSlice.reducer
