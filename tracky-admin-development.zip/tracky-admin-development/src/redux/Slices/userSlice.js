// counterSlice.js
import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { Toaster } from "../../utility/Global";
import { resetAuth } from "../../redux/Slices/authSlice"
import { resetStaff } from "../../redux/Slices/StaffSlice"
import { restProfile } from "../../redux/Slices/profileSlice"
import { resetNotification } from "../../redux/Slices/notificationSlice"
import { resetPayment } from "../../redux/Slices/PaymentSlice"

const initialState = {
  userloader: false,
  userData: [],
  getSingleuserData: [],
};

const apiUrl = import.meta.env.VITE_APP_API_ADMIN_URL;

// Get AllUser API
export const GetAllUsers = (data, accessToken) => async (dispatch) => {
  try {
    dispatch(userloadingFun(true));
    const response = await axios.post(`${apiUrl}user/list`, data, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (response.data.success == true) {
      dispatch(userloadingFun(false));

      dispatch(GetUsers(response.data.data));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(userloadingFun(false));

      // toast.error(<ToastContent message={err?.response?.data?.message} />, {
      //   position: "top-right",
      //   autoClose: 3000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "light",
      // });
    }
    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(userloadingFun(false));
  }
};

//Get single User Api
export const GetSingleUsers = (id, accessToken) => async (dispatch) => {
  try {
    dispatch(userloadingFun(true));
    const response = await axios.get(`${apiUrl}user/view/${id}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (response.data.success == true) {
      dispatch(userloadingFun(false));

      dispatch(getSingleUser(response.data.data));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(userloadingFun(false));

      // toast.error(<ToastContent message={err?.response?.data?.message} />, {
      //   position: "top-right",
      //   autoClose: 3000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      //   theme: "light",
      // });
    }
    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }
    dispatch(userloadingFun(false));
  }
};

//Delete User
export const DeleteUser = (id, accessToken, Dataa) => async (dispatch) => {
  try {
    dispatch(userloadingFun(true));
    const response = await axios.delete(`${apiUrl}user/delete/${id}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (response.data.success == true) {
      dispatch(userloadingFun(false));
      dispatch(GetAllUsers(Dataa, accessToken));
      Toaster.success(response.data.message);
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(userloadingFun(false));
      Toaster.error(err.response.data.message);
    }
    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }
    dispatch(userloadingFun(false));
  }
};

//Change user status
export const ChangeStatus =
  (id, data, accessToken, Dataa) => async (dispatch) => {
    try {
      dispatch(userloadingFun(true));
      const response = await axios.put(`${apiUrl}user/status/${id}`, data, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (response.data.success == true) {
        dispatch(userloadingFun(false));
        dispatch(GetAllUsers(Dataa, accessToken));
        Toaster.success(response.data.message);
      }
    } catch (err) {
      if (err?.response?.status === 400 || err?.response?.status === 500) {
        dispatch(userloadingFun(false));
        Toaster.error(err.response.data.message);
      }
      if (err?.response?.status === 401) {
        dispatch(resetAuth())
        dispatch(resetUser())
        dispatch(resetStaff())
        dispatch(restProfile())
        dispatch(resetNotification())
        dispatch(resetPayment())
      }
      dispatch(userloadingFun(false));
    }
  };

const userSlice = createSlice({
  name: "userSlice",
  initialState,
  reducers: {
    userloadingFun: (state, action) => {
      state.userloader = action.payload;
    },
    GetUsers: (state, action) => {
      state.userData = action.payload;
    },
    getSingleUser: (state, action) => {
      state.getSingleuserData = action.payload;
    },
    resetUser: (state) => {
      state.userloader = false;
      state.userData = [];
      state.getSingleuserData = [];
    },
  },
});

export const { userloadingFun, GetUsers, getSingleUser, resetUser } =
  userSlice.actions;
export default userSlice.reducer;
