// counterSlice.js
import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { Toaster } from "../../utility/Global";

const initialState = {
  postLoginloading: false,
  accessToken: null,
  user: {},
};

const apiUrl = import.meta.env.VITE_APP_API_BASE_URL;

// Login API
export const login = (data, navigate) => async (dispatch) => {
  try {
    dispatch(postLoginloadingFun(true));
    const response = await axios.post(`${apiUrl}login`, data);

    if (response.data.success == true) {

      dispatch(accessTokenFun(response.data.data.token));
      dispatch(userFun(response.data.data.user));

      dispatch(postLoginloadingFun(false));
      navigate("/dashboard");
      // Toaster.success()
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(postLoginloadingFun(false));
      Toaster.error(err.response.data.message);
    }
    dispatch(postLoginloadingFun(false));
  }
};

const authSlice = createSlice({
  name: "counter",
  initialState,
  reducers: {
    postLoginloadingFun: (state, action) => {
      state.postLoginloading = action.payload;
    },
    accessTokenFun: (state, action) => {
      state.accessToken = action.payload;
    },
    userFun: (state, action) => {
      state.user = action.payload;
    },
    resetAuth: (state, action) => {
      state.postLoginloading = false;
      state.accessToken = null;
      state.user = {};
    },
  },
});

export const { postLoginloadingFun, accessTokenFun, userFun, resetAuth } =
  authSlice.actions;
export default authSlice.reducer;
