import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { Toaster } from "../../utility/Global";

import { resetAuth } from "../../redux/Slices/authSlice"
import { resetUser } from "../../redux/Slices/userSlice"
import { resetStaff } from "../../redux/Slices/StaffSlice"
import { restProfile } from "../../redux/Slices/profileSlice"
import { resetNotification } from "../../redux/Slices/notificationSlice"

const initialState = {
  getPaymentLoader: false,
  PaymentData: {},
};

const apiUrl = import.meta.env.VITE_APP_API_ADMIN_URL;

export const getPayment = (accessToken, apiPayload) => async (dispatch) => {
  try {
    dispatch(getPaymentLoaderFun(true));

    const response = await axios.post(`${apiUrl}payment/history`, apiPayload, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });


    if (response?.data?.success == true) {
      dispatch(getPaymentLoaderFun(false));
      dispatch(PaymentDataFun(response?.data?.data));
      // Toaster.success(response?.data?.data?.message)
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(getPaymentLoaderFun(false));
      Toaster.error(err?.response?.data?.data?.message);
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(getPaymentLoaderFun(false));
  }
};

const PaymentSlice = createSlice({
  name: "PaymentSlice",
  initialState,
  reducers: {
    getPaymentLoaderFun: (state, action) => {
      state.getPaymentLoader = action.payload;
    },
    PaymentDataFun: (state, action) => {
      state.PaymentData = action.payload;
    },
    resetPayment: (state, action) => {
      state.getPaymentLoader = false;
      state.PaymentData = {};
    },
  },
});

export const { getPaymentLoaderFun, PaymentDataFun, resetPayment } =
  PaymentSlice.actions;
export default PaymentSlice.reducer;
