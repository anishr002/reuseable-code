// counterSlice.js
import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { Toaster } from "../../utility/Global";
import { resetAuth } from "../../redux/Slices/authSlice"
import { resetUser } from "../../redux/Slices/userSlice"
import { resetStaff } from "../../redux/Slices/StaffSlice"
import { resetNotification } from "../../redux/Slices/notificationSlice"
import { resetPayment } from "../../redux/Slices/PaymentSlice"


const initialState = {
  isLoading: false,
  editLoading: false,
  profileData: {},
  isEditing: false,
};

const apiUrl = import.meta.env.VITE_APP_API_ADMIN_URL;

// Get profile API
export const GetProfile = (accessToken) => async (dispatch) => {
  try {
    dispatch(loadingFun(true));
    const response = await axios.get(`${apiUrl}admin/fetch`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (response?.data?.success == true) {
      dispatch(GetProfileData(response?.data?.data));

      dispatch(loadingFun(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(loadingFun(false));
      Toaster.error(err?.response?.data?.message);
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(loadingFun(false));
  }
};

// Update profile API
export const UpdateProfile = (data, accessToken) => async (dispatch) => {
  try {
    dispatch(UpdateloadingFun(true));
    const response = await axios.put(`${apiUrl}admin/edit`, data, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (response?.data?.success == true) {
      dispatch(GetProfile(accessToken));
      Toaster.success(response?.data?.message);

      dispatch(UpdateloadingFun(false));
    }
  } catch (err) {
    if (err?.response?.status === 400 || err?.response?.status === 500) {
      dispatch(UpdateloadingFun(false));
      Toaster.error(err?.response?.data?.message);
    }

    if (err?.response?.status === 401) {
      dispatch(resetAuth())
      dispatch(resetUser())
      dispatch(resetStaff())
      dispatch(restProfile())
      dispatch(resetNotification())
      dispatch(resetPayment())
    }

    dispatch(UpdateloadingFun(false));
  }
};

const profileSlice = createSlice({
  name: "profile",
  initialState,
  reducers: {
    loadingFun: (state, action) => {
      state.isLoading = action.payload;
    },
    UpdateloadingFun: (state, action) => {
      state.editLoading = action.payload;
    },
    GetProfileData: (state, action) => {
      state.profileData = action.payload;
      state.isEditing = false;
    },
    startEditing: (state) => {
      state.isEditing = true; // Set the isEditing flag when starting the edit
    },
    restProfile: (state) => {
      state.isLoading = false;
      state.profileData = [];
      state.editLoading = false;
      state.isEditing = false;
    },
  },
});

export const {
  loadingFun,
  restProfile,
  GetProfileData,
  UpdateloadingFun,
  startEditing,
} = profileSlice.actions;
export default profileSlice.reducer;
