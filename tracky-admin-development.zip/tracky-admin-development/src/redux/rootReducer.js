// rootReducer.js
import { combineReducers } from "redux"
import layout from "./layout"
import navbar from "./navbar"
import PasswordSlice from "./Slices/PasswordSlice"
import authSlice from "./Slices/authSlice"
import userSlice from "./Slices/userSlice"
import StaffSlice from "./Slices/StaffSlice"
import profileSlice from "./Slices/profileSlice"
import PaymentSlice from "./Slices/PaymentSlice"
import notificationSlice from "./Slices/notificationSlice"

const rootReducer = combineReducers({
  // Add your other reducers here
  navbar,
  layout,
  auth: authSlice,
  pass: PasswordSlice,
  user: userSlice,
  staff: StaffSlice,
  payment: PaymentSlice,
  profile: profileSlice,
  notification : notificationSlice
})

export default rootReducer
