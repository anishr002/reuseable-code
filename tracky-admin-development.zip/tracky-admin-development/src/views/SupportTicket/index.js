import React from "react"
import { Helmet } from "react-helmet"
import BreadCrumbs from "../../@core/components/breadcrumbs"
import { Card, CardHeader, CardTitle } from "reactstrap"

function SupportTicket() {
  return (
    <>
      <Helmet>
        <title>Tracky | Support Ticket</title>
        <meta name="description" content="Tracky | Support Ticket" />
      </Helmet>
      <BreadCrumbs title="User Management" data={[{ title: "User list" }]} />
      <Card className="mt-2">
        <CardHeader className="flex-md-row flex-column align-md-items-center align-items-start border-bottom">
          <CardTitle tag="h4">Support Ticket</CardTitle>
        </CardHeader>
      </Card>
    </>
  )
}

export default SupportTicket
