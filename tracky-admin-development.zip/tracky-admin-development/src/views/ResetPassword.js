// ** React Imports
import { Link, useNavigate } from "react-router-dom"
import { useEffect } from "react"
import * as Yup from "yup"
import { yupResolver } from "@hookform/resolvers/yup"
import { useForm, Controller } from "react-hook-form"
import { resetPass } from "../redux/Slices/PasswordSlice"
import { useDispatch, useSelector } from "react-redux"
import { Helmet } from "react-helmet"

// ** Custom Hooks
import { useSkin } from "@hooks/useSkin"

// ** Icons Imports
import { ChevronLeft } from "react-feather"
import TrackyLogo from "@src/assets/images/logo/TrackyLogo.svg"

// ** Custom Components
import InputPassword from "@components/input-password-toggle"

// ** Reactstrap Imports
import { Row, Col, CardTitle, CardText, Form, Label, Button } from "reactstrap"

// ** Illustrations Imports
import illustrationsLight from "@src/assets/images/pages/reset-password-v2.svg"
// import illustrationsDark from "@src/assets/images/pages/reset-password-v2-dark.svg"

// ** Styles
import "@styles/react/pages/page-authentication.scss"
import { Spinner } from "reactstrap"

const ResetPassword = () => {
  // ** Hooks
  const { skin } = useSkin()
  const urlParams = new URLSearchParams(window.location.search)
  const verifyid = urlParams.get("token")
  const isLoading = useSelector((state) => state?.pass?.resetPassLoadFlag)

  const validationSchema = Yup.object().shape({
    password1: Yup.string()
      .required("Password is required")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
        "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
      )
      .max(15, "maximum 15 characters allowed"),
    password: Yup.string()
      .required("Confirm password is required")
      .oneOf([Yup.ref("password1"), null], "passwords must match")
      .max(15, "maximum 15 characters allowed"),
  })

  const dispatch = useDispatch()
  const navigate = useNavigate()
  const {
    handleSubmit,
    control,
    setError,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  })

  const onSubmit = (data) => {
    // You can handle the form submission logic here
    // console.log(data, "formdataa")
    const formData = { password: data.password, token: verifyid }

    dispatch(resetPass(formData, navigate))
  }

  useEffect(() => {
    if (verifyid == null) {
      navigate("/login")
    }
  }, [])

  // const source = skin === "dark" ? illustrationsDark : illustrationsLight

  return (
    <>
      <Helmet>
        <title>Tracky | Reset Password</title>
        <meta name="description" content="Tracky | Reset Password" />
      </Helmet>

      <div className="auth-wrapper auth-cover">
        <Row className="auth-inner m-0">
          <Link
            className="brand-logo"
            to="/"
            onClick={(e) => e.preventDefault()}
          >
            <img src={TrackyLogo} />
          </Link>
          <Col
            className="d-none d-lg-flex align-items-center p-5"
            lg="8"
            sm="12"
          >
            <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
              <img
                className="img-fluid"
                src={illustrationsLight}
                alt="Login Cover"
              />
            </div>
          </Col>
          <Col
            className="d-flex align-items-center auth-bg px-2 p-lg-5"
            lg="4"
            sm="12"
          >
            <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
              <CardTitle tag="h2" className="fw-bold mb-1">
                Reset Password 🔒
              </CardTitle>
              <CardText className="mb-2">
                Your new password must be different from previously used
                passwords
              </CardText>
              <Form
                className="auth-reset-password-form mt-2"
                onSubmit={handleSubmit(onSubmit)}
              >
                <div className="mb-1">
                  <Label className="form-label" for="new-password">
                    New Password
                  </Label>
                  <Controller
                    name="password1"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <>
                        <InputPassword
                          className="input-group-merge"
                          id="login-password"
                          {...field}
                        />
                        {errors.password1 && (
                          <span className="text-danger">
                            {errors.password1.message}
                          </span>
                        )}
                      </>
                    )}
                  />
                </div>
                <div className="mb-1">
                  <Label className="form-label" for="confirm-password">
                    Confirm Password
                  </Label>
                  <Controller
                    name="password"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <>
                        <InputPassword
                          className="input-group-merge"
                          id="login-password"
                          {...field}
                        />
                        {errors.password && (
                          <span className="text-danger">
                            {errors.password.message}
                          </span>
                        )}
                      </>
                    )}
                  />
                </div>
                {isLoading ? (
                  <Button className="me-1" color="primary" disabled block>
                    <Spinner color="white" size="sm" />
                    <span>Loading...</span>
                  </Button>
                ) : (
                  <Button color="primary" block>
                    Set New Password
                  </Button>
                )}
              </Form>
              <p className="text-center mt-2">
                <Link to="/login">
                  <ChevronLeft className="rotate-rtl me-25" size={14} />
                  <span className="align-middle">Back to login</span>
                </Link>
              </p>
            </Col>
          </Col>
        </Row>
      </div>
    </>
  )
}

export default ResetPassword
