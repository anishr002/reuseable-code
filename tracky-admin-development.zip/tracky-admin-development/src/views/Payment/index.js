import { Helmet } from "react-helmet"
import { useNavigate } from "react-router-dom"
import Breadcrumbs from "@components/breadcrumbs"
import ReactPaginate from "react-paginate"
import DataTable from "react-data-table-component"
import { Fragment, useState, forwardRef, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { getStaff } from "../../redux/Slices/StaffSlice"
import { getPayment } from "../../redux/Slices/PaymentSlice"
import moment from "moment"
// import "react-date-range/dist/styles.css" // main css file
// import "react-date-range/dist/theme/default.css" // theme css file
// import { DateRangePicker } from "react-date-range"

import { useDebouncedValue } from "../../hooks/useDebouncedValue"
import Swal from "sweetalert2"
import { Link } from "react-router-dom"
import { Badge } from "reactstrap"
import { Trash, Eye, Edit } from "react-feather"
import { DateRangePicker } from "rsuite"
import "rsuite/dist/rsuite-no-reset.min.css"
import { startOfDay, endOfDay, addDays, subDays } from "date-fns"

import {
  ChevronDown,
  Share,
  Printer,
  FileText,
  File,
  Grid,
  Copy,
  Plus,
} from "react-feather"

import {
  Row,
  Col,
  Card,
  Input,
  Label,
  Button,
  CardTitle,
  CardHeader,
  DropdownMenu,
  DropdownItem,
  DropdownToggle,
  UncontrolledButtonDropdown,
  Spinner,
} from "reactstrap"
import Select from "react-select"
import { selectThemeColors } from "@utils"

function Payment() {
  const navigate = useNavigate()
  const [modal, setModal] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [searchValue, setSearchValue] = useState("")
  const [sortField, setSortField] = useState("")
  const [sortOrder, setSortOrder] = useState("desc")
  const [sort, setsort] = useState(true)

  const [itemPerPage, setItemPerPage] = useState(10)
  const [startDate, setStartDate] = useState(null)
  const [endDate, setEndDate] = useState(null)

  const colourOptions = [
    { value: 10, label: "10" },
    { value: 20, label: "20" },
    { value: 30, label: "30" },
    { value: 50, label: "50" },
  ]

  const [paymentSort, setPaymentSort] = useState([
    {
      startDate: new Date(),
      endDate: addDays(new Date(), 7),
      key: "selection",
    },
  ])

  const dispatch = useDispatch()
  const accessToken = useSelector((state) => state?.auth?.accessToken)

  // const UserdataObj = useSelector((state) => state?.staff?.StaffData)
  // const data = UserdataObj.staffList
  // const IsLoading = useSelector((state) => state?.staff?.getStaffLoader)

  const paymentDataObj = useSelector((state) => state?.payment?.PaymentData)
  const data = paymentDataObj.payments
  const IsLoading = useSelector((state) => state?.payment?.getPaymentLoader)

  // console.log(data, "staffData")
  // console.log(IsLoading, "IsLoading")
  const search = useDebouncedValue(searchValue, 1000)

  useEffect(() => {
    const apiPayload = {
      page: currentPage,
      itemsPerPage: itemPerPage,
      sortField,
      sortOrder,
      search,
      startDate: startDate,
      endDate: endDate,
    }

    // dispatch(getStaff(accessToken, apiPayload))
    dispatch(getPayment(accessToken, apiPayload))
  }, [
    currentPage,
    sortField,
    sortOrder,
    search,
    searchValue,
    itemPerPage,
    startDate,
    endDate,
  ])

  const handlePagination = (page) => {
    setCurrentPage(page.selected + 1)
  }

  const handleFilter = (event) => {
    setTimeout(() => {
      setCurrentPage(1)
    }, 800)
    setSearchValue(event.target.value)
  }

  const handleSort = (column, sortDirection) => {
    setsort(!sort)
    setSortOrder(sortDirection)
    setSortField(column?.sortField)
  }

  const showAlert = (_id) => {
    // alert("I'm an alert")

    return Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert User!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-outline-danger ml-1",
      },
      buttonsStyling: false,
    }).then(function (result) {
      if (result.isConfirmed) {
        // store.dispatch(DeleteQuestion(_id));
      }
    })
  }

  // convertDateFormat = (inputDate) => {
  //   const dateObject = new Date(inputDate)
  //   const day = String(dateObject.getDate()).padStart(2, "0")
  //   const month = String(dateObject.getMonth() + 1).padStart(2, "0") // Months are zero-based
  //   const year = dateObject.getFullYear()

  //   return `${day}-${month}-${year}`
  // }

  const Ranges = [
    {
      label: "last7Days",
      value: [startOfDay(subDays(new Date(), 6)), endOfDay(new Date())],
    },
    {
      label: "Last 10 Days",
      value: [startOfDay(subDays(new Date(), 9)), endOfDay(new Date())],
    },
    {
      label: "Last 15 Days",
      value: [startOfDay(subDays(new Date(), 14)), endOfDay(new Date())],
    },
  ]

  const columns = [
    // {
    //   name: "Name",
    //   minWidth: "250px",
    //   sortable: true,
    //   sortField: "first_name",
    //   selector: "full_name",
    //   cell: (row) => row?.full_name,
    // },
    {
      name: "Email",
      sortable: true,
      minWidth: "250px",
      sortField: "email",
      cell: (row) => <>{row?.user_id !== null ? row?.user_id?.email : "N/A"}</>,
    },

    // {
    //   name: "Active / Deactive",
    //   sortable: true,
    //   minWidth: "150px",
    //   selector: "key",
    //   sortField: "key",
    //   cell: (row) => (
    //     <span>
    //       {row.active === true ? (
    //         <Badge color="light-success">
    //           <div>
    //             <span>Active</span>
    //           </div>
    //         </Badge>
    //       ) : (
    //         <Badge color="light-warning">
    //           <div>
    //             <span>Deactive</span>
    //           </div>
    //         </Badge>
    //       )}
    //     </span>
    //   ),
    // },
    {
      name: "Interval",
      sortable: true,
      minWidth: "350px",
      sortField: "interval",
      selector: (row) => <>{row.interval == "year" ? "Yearly" : "Monthly"}</>,
    },

    {
      name: "Plan",
      sortable: true,
      minWidth: "250px",
      sortField: "price",
      cell: (row) => (
        <>{row?.plan !== null ? `$ ${row?.plan?.price}` : "N/A"}</>
      ),
    },
    {
      name: "Date",
      sortable: true,
      minWidth: "250px",
      sortField: "createdAt",
      cell: (row) => (
        <>
          {row?.plan !== null
            ? ` ${moment.utc(row?.createdAt).local().format("YYYY-MM-DD")}`
            : "N/A"}
        </>
      ),
    },
    // {
    //   name: "Actions",
    //   allowOverflow: true,
    //   cell: (row) => {
    //     return (
    //       <div className="d-flex">
    //         <div style={{ marginRight: "5px" }}>
    //           <Link to={`/staff?id=${row?._id}`}>
    //             <Edit color="#0000FF" size={15} className="mr-1" />
    //           </Link>
    //         </div>
    //         <div className="cursor-pointer">
    //           <span onClick={() => showAlert(row?._id)}>
    //             <Trash color="#ea5556" size={15} />
    //           </span>
    //         </div>
    //       </div>
    //     )
    //   },
    // },
  ]

  // ** Custom Pagination
  const CustomPagination = () => {
    const count = 10
    return (
      <>
                <div className="d-flex flex-sm-row-reverse flex-column flex-sm-row pb-sm-0 pb-2">
          <ReactPaginate
            previousLabel={""}
            nextLabel={""}
            breakLabel="..."
            pageCount={paymentDataObj?.page_count}
            marginPagesDisplayed={2}
            pageRangeDisplayed={2}
            activeClassName="active"
            forcePage={currentPage !== 0 ? currentPage - 1 : 0}
            onPageChange={(page) => handlePagination(page)}
            pageClassName="page-item"
            breakClassName="page-item"
            nextLinkClassName="page-link"
            pageLinkClassName="page-link"
            breakLinkClassName="page-link"
            previousLinkClassName="page-link"
            nextClassName="page-item next-item"
            previousClassName="page-item prev-item"
            containerClassName={
              "pagination react-paginate separated-pagination pagination-sm justify-sm-content-end justify-content-center pe-1 mt-1"
            }
          />
          <div className="d-flex align-items-center justify-content-center me-1">
          <div >
            <Label className="form-label">Rows Per Page</Label>
          </div>
          <div style={{marginLeft:"8px"}}>
            <Select
              theme={selectThemeColors}
              className="basic-single page-select"
              classNamePrefix="select"
              value={colourOptions.find(
                (option) => option.value === itemPerPage
              )}
              options={colourOptions}
              isClearable={false}
              searchable={false}
              styles={{
                option: (styles) => {
                  return { ...styles, zIndex: 11 }
                },
              }}
              onChange={(val) => {
                setItemPerPage(val.value)
              }}
              onKeyDown={(e) => {
                e.preventDefault()
              }}
            />
            </div>
          </div>


        </div>
      </>
    )
  }

  return (
    <>
      <Helmet>
        <title>Tracky | Payment</title>
        <meta name="description" content="Tracky | Payment" />
      </Helmet>
      <Breadcrumbs title="Payment" data={[{ title: "Staff list" }]} />
      <Card className="mt-1">
        <Row className="justify-content-end mx-0 mb-1">
          {/* <Col
            className="d-flex align-items-center justify-content-end mt-1"
            md="6"
            sm="12"
          > */}
          <Col
            className="d-flex align-items-center justify-content-end mt-1"
            md="9"
            sm="9"
          >
            <div className="d-flex align-items-center justify-content-center me-1">
              <DateRangePicker
                placeholder="Select Date Range"
                onChange={(value) => {
                  if (value == null) {
                    setStartDate(null)
                    setEndDate(null)
                  } else if (value !== null) {
                    setStartDate(moment(value[0]).format("YYYY-MM-DD"))
                    setEndDate(moment(value[1]).format("YYYY-MM-DD"))
                  }
                }}
                ranges={Ranges}
                size="lg"
                showOneCalendar
              />
            </div>
          </Col>
          <Col
            className="d-flex align-items-center justify-content-end mt-1"
            md="3"
            sm="3"
          >
            <Label className="me-1" for="search-input">
              Search
            </Label>
            <Input
              className="dataTable-filter mb-50"
              style={{ height: "40px" }}
              type="text"
              bsSize="sm"
              id="search-input"
              value={searchValue}
              // onChange={handleFilter}
              onChange={(e) => handleFilter(e)} // Pass the event object to handleFilter
            />
          </Col>
          {/* </Col> */}
        </Row>
        <div className="react-dataTable react-dataTable-selectable-rows">
          {IsLoading ? (
            <div className="d-flex justify-content-center align-items-center loader-container my-5">
              <Spinner />
            </div>
          ) : (
            <DataTable
              noHeader
              pagination
              paginationServer
              // selectableRows
              columns={columns}
              paginationPerPage={itemPerPage}
              defaultSortAsc={sort}
              defaultSortFieldId={sortField}
              onSort={handleSort}
              className="react-dataTable"
              sortIcon={<ChevronDown size={10} />}
              paginationComponent={CustomPagination}
              sortServer
              // paginationDefaultPage={currentPage + 1}
              // selectableRowsComponent={BootstrapCheckbox}
              data={data}
            />
          )}
        </div>
        {/* <p>{}</p> */}
      </Card>
    </>
  )
}

export default Payment
