import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  CardText,
  CardLink,
} from "reactstrap";
import { Helmet } from "react-helmet";
import Breadcrumbs from "@components/breadcrumbs";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Tracky | Dashboard</title>
        <meta name="description" content="Tracky | Dashboard" />
      </Helmet>
      <Breadcrumbs title="Tracky Admin Panel" data={[{ title: "Dashboard" }]} />
      <div className="mt-2">
        <Card>
          <CardHeader>
            <CardTitle>Welcome to Tracky Admin Panel</CardTitle>
          </CardHeader>
          <CardBody>
            {/* <CardText>All the best for your new project.</CardText>
          <CardText>
            Please make sure to read our{" "}
            <CardLink
              href="https://pixinvent.com/demo/vuexy-react-admin-dashboard-template/documentation/"
              target="_blank"
            >
              Template Documentation
            </CardLink>{" "}
            to understand where to go from here and how to use our template.
          </CardText> */}
          </CardBody>
        </Card>
      </div>
    </>
  );
};

export default Home;
