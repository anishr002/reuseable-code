// ** React Imports
import { Link } from "react-router-dom"

// ** Custom Hooks
import { useSkin } from "@hooks/useSkin"

// ** Icons Imports
import { ChevronLeft } from "react-feather"

// ** Reactstrap Imports
import {
  Row,
  Col,
  CardTitle,
  CardText,
  Form,
  Label,
  Input,
  Button,
} from "reactstrap"

// ** Illustrations Imports
import illustrationsLight from "@src/assets/images/pages/loginPageSideImage.svg"

// import illustrationsLight from "@src/assets/images/pages/forgot-password-v2.svg"
import illustrationsDark from "@src/assets/images/pages/forgot-password-v2-dark.svg"
import TrackyLogo from "@src/assets/images/logo/TrackyLogo.svg"
import { Helmet } from "react-helmet"
import * as Yup from "yup"
import { yupResolver } from "@hookform/resolvers/yup"
import { useForm, Controller } from "react-hook-form"
import { ErrorMessage } from "@hookform/error-message"
import { handleKeyDown } from "../utility/SpaceValidation.js"
import { sendForgotPWemail, resendEmail } from "../redux/Slices/PasswordSlice"
import { useNavigate } from "react-router-dom"
import { Spinner } from "reactstrap"
import { useDispatch, useSelector } from "react-redux"

// ** Styles
import "@styles/react/pages/page-authentication.scss"

const ForgotPassword = () => {
  // ** Hooks
  const { skin } = useSkin()
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const isLoading = useSelector(
    (state) => state?.pass?.sendForgotPWemailLoading
  )

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .required("Please enter email address")
      .matches(
        /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
        "Please enter valid email address"
      ),
  })

  const {
    register,
    handleSubmit,
    formState: { errors },
    control,
    setValue,
    setError,
    clearErrors,
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "onChange",
  })

  const saveForgotPassword = (data) => {
    dispatch(sendForgotPWemail(data, navigate))
  }

  // const source = skin === "dark" ? illustrationsDark : illustrationsLight

  const source = illustrationsLight

  return (
    <>
      <Helmet>
        <title>Tracky | Forgot Password</title>
        <meta name="description" content="Tracky | Forgot Password" />
      </Helmet>
      <div className="auth-wrapper auth-cover">
        <Row className="auth-inner m-0">
          <Link
            className="brand-logo"
            to="/"
            onClick={(e) => e.preventDefault()}
          >
            <img src={TrackyLogo} />
          </Link>
          <Col
            className="d-none d-lg-flex align-items-center p-5"
            lg="8"
            sm="12"
          >
            <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
              <img className="img-fluid" src={source} alt="Login Cover" />
            </div>
          </Col>
          <Col
            className="d-flex align-items-center auth-bg px-2 p-lg-5"
            lg="4"
            sm="12"
          >
            <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
              <CardTitle tag="h2" className="fw-bold mb-1">
                Forgot Password? 🔒
              </CardTitle>
              <CardText className="mb-2">
                Enter your email and we'll send you instructions to reset your
                password
              </CardText>
              {/* <Form
                className="auth-forgot-password-form mt-2"
                onSubmit={(e) => e.preventDefault()}
              > */}
              <form
                onSubmit={handleSubmit(saveForgotPassword)}
                className="auth-forgot-password-form mt-2"
              >
                <div className="mb-1">
                  <Label className="form-label" for="login-email">
                    Email
                  </Label>

                  <Controller
                    name="email"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <>
                        <Input
                          type="text"
                          id="login-email"
                          placeholder="john@example.com"
                          autoComplete="off"
                          onKeyPress={handleKeyDown}
                          name="email"
                          autoFocus
                          {...field}
                        />
                        {errors.email && (
                          <span className="text-danger">
                            {errors.email.message}
                          </span>
                        )}
                      </>
                    )}
                  />

                  {/* <ErrorMessage
                    errors={errors}
                    name="email"
                    render={({ message }) => (
                      <span className="text-danger">{message}</span>
                    )}
                  /> */}
                </div>

                {isLoading ? (
                  <Button className="me-1" color="primary" disabled block>
                    <Spinner color="white" size="sm" />
                    <span>Loading...</span>
                  </Button>
                ) : (
                  <Button color="primary" block type="submit">
                    Send reset link
                  </Button>
                )}
                {/* </Form> */}
              </form>
              <p className="text-center mt-2">
                <Link to="/login">
                  <ChevronLeft className="rotate-rtl me-25" size={14} />
                  <span className="align-middle">Back to login</span>
                </Link>
              </p>
            </Col>
          </Col>
        </Row>
      </div>
    </>
  )
}

export default ForgotPassword
