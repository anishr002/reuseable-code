import React from "react";
import { Helmet } from "react-helmet";
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Row,
  Col,
  Input,
  Form,
  Button,
  Label,
  FormFeedback,
  Spinner,
} from "reactstrap";
import InputPasswordToggle from "@components/input-password-toggle";
import { useForm, Controller } from "react-hook-form";
import Breadcrumbs from "@components/breadcrumbs";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../../../src/utility/SpaceValidation";
// import { DevTool } from "@hookform/devtools"
import { useDispatch, useSelector } from "react-redux";
import {
  saveStaff,
  getSingleStaff,
  updateSingleStaff,
} from "../../redux/Slices/StaffSlice";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import { ArrowLeft } from "react-feather";
import {
  GetProfile,
  UpdateProfile,
  startEditing,
} from "../../redux/Slices/profileSlice";

function ProfileView() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const accessToken = useSelector((state) => state?.auth?.accessToken);
  const PofileData = useSelector((state) => state?.profile?.profileData);
  const isLoading = useSelector((state) => state?.profile?.editLoading);
  const isPageLoading = useSelector((state) => state?.profile?.isLoading);
  const isEditing = useSelector((state) => state?.profile?.isEditing);


  useEffect(() => {
    dispatch(GetProfile(accessToken));
  }, []);

  useEffect(() => {
    setValue("first_name", PofileData?.first_name);
    setValue("last_name", PofileData?.last_name);
    setValue("email", PofileData?.email);

    // return () => {
    //   reset();
    // };
  }, [PofileData]);

  const validationSchema = Yup.object().shape({
    first_name: Yup.string()
      .required("First name is required")
      .max(30, "Maximum 30 characters allowed"),
    last_name: Yup.string()
      .required("Last name is required")
      .max(30, "Maximum 30 characters allowed"),
    email: Yup.string()
      .required("E-mail is required")
      .matches(
        /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
        "Please enter a valid email address"
      ),
    password: Yup.string().test(
      "password",
      "Password is required",
      function (value) {
        const { confirmPassword } = this.parent;
        // If confirmPassword is provided, require a password
        if (confirmPassword && confirmPassword.length > 0) {
          return !!value;
        }
        // Otherwise, password is optional
        return true;
      }
    ),
    confirmPassword: Yup.string().when("password", {
      is: (password) => password && password.length > 0,
      then: Yup.string()
        .required("Confirm password is required")
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .max(15, "Maximum 15 characters allowed"),
    }),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });

  const onSubmit = async (data) => {

    const { confirmPassword, ...newdata } = data;
    dispatch(startEditing());
    dispatch(UpdateProfile(newdata, accessToken));
    reset();
  };

  const resetForm = () => {
    reset();
    setValue("first_name", PofileData?.first_name);
    setValue("last_name", PofileData?.last_name);
    setValue("email", PofileData?.email);
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Profile</title>
        <meta name="description" content="Tracky | Profile" />
      </Helmet>
      <div className="d-flex align-items-center">
        <ArrowLeft
          onClick={() => navigate("/")}
          className="cursor-pointer me-1"
        />
        <Breadcrumbs
          title="Profile Details"
          data={[
            { title: "Staff list", link: "/staff-management" },
            { title: "Staff" },
          ]}
        />
      </div>

      <Col sm="12" className="mt-2">
        <Card>
          {/* <CardHeader>
            <CardTitle tag="h4">Add Staff</CardTitle>
          </CardHeader> */}
          {(isPageLoading || isLoading) && !isEditing ? (
            <div className="d-flex justify-content-center align-items-center loader-container my-5">
              <Spinner />
            </div>
          ) : (
            <CardBody>
              <Form onSubmit={handleSubmit(onSubmit)}>
                <Row>
                  <Col md="6" sm="12" className="mb-1">
                    <Label className="form-label" for="first_name">
                      First Name
                    </Label>
                    <Controller
                      id="firstName"
                      name="first_name"
                      defaultValue={PofileData?.first_name}
                      control={control}
                      render={({ field }) => (
                        <Input
                          {...field}
                          type="text"
                          placeholder="First Name"
                          autoComplete="off"
                          onKeyPress={handleKeyDown}
                          invalid={errors.first_name && true}
                        />
                      )}
                    />
                    {errors.first_name && (
                      <FormFeedback>{errors.first_name.message}</FormFeedback>
                    )}
                  </Col>

                  <Col md="6" sm="12" className="mb-1">
                    <Label className="form-label" for="last_name">
                      Last Name
                    </Label>
                    <Controller
                      id="lastName"
                      name="last_name"
                      defaultValue={PofileData?.last_name}
                      control={control}
                      render={({ field }) => (
                        <Input
                          {...field}
                          type="text"
                          placeholder="Last Name"
                          autoComplete="off"
                          onKeyPress={handleKeyDown}
                          invalid={errors.last_name && true}
                        />
                      )}
                    />
                    {errors.last_name && (
                      <FormFeedback>{errors.last_name.message}</FormFeedback>
                    )}
                  </Col>
                  <Col md="6" sm="12" className="mb-1">
                    <Label className="form-label" for="email">
                      Email
                    </Label>
                    <Controller
                      id="email"
                      name="email"
                      // value={PofileData?.email}
                      control={control}
                      render={({ field }) => (
                        <Input
                          {...field}
                          type="text"
                          placeholder="Email"
                          autoComplete="off"
                          onKeyPress={handleKeyDown}
                          invalid={errors.email && true}
                          disabled
                        />
                      )}
                    />
                    {errors.email && (
                      <FormFeedback>{errors.email.message}</FormFeedback>
                    )}
                  </Col>

                  <Col md="6" sm="12" className="mb-1">
                    <Label className="form-label" for="EmailMulti">
                      Password
                    </Label>
                    <Controller
                      name="password"
                      control={control}
                      defaultValue=""
                      render={({ field }) => (
                        <>
                          <InputPasswordToggle
                            className="input-group-merge"
                            onKeyPress={handleKeyDown}
                            id="login-password"
                            {...field}
                            invalid={errors.password && true}
                          />
                        </>
                      )}
                    />
                    {errors.password && (
                      <FormFeedback>{errors.password.message}</FormFeedback>
                    )}
                  </Col>

                  <Col md="6" sm="12" className="mb-1">
                    <Label className="form-label" for="confirmPassword">
                      Confirm Password
                    </Label>
                    <Controller
                      name="confirmPassword"
                      control={control}
                      defaultValue=""
                      render={({ field }) => (
                        <>
                          <InputPasswordToggle
                            className="input-group-merge"
                            id="confirmpassword"
                            onKeyPress={handleKeyDown}
                            {...field}
                            invalid={errors.confirmPassword && true}
                          />
                        </>
                      )}
                    />
                    {errors.confirmPassword && (
                      <FormFeedback>
                        {errors.confirmPassword.message}
                      </FormFeedback>
                    )}
                  </Col>

                  <Col sm="12">
                    <div className="d-flex">
                      {isLoading ? (
                        <Button className="me-1" color="primary" disabled>
                          <Spinner color="white" size="sm" />
                          <span>Loading...</span>
                        </Button>
                      ) : (
                        <Button className="me-1" color="primary" type="submit">
                          Save
                        </Button>
                      )}

                      <Button
                        outline
                        color="secondary"
                        type="button"
                        onClick={resetForm}
                      >
                        Reset
                      </Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </CardBody>
          )}
        </Card>
      </Col>
    </>
  );
}

export default ProfileView;
