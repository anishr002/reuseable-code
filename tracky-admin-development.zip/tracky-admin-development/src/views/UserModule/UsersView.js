import React, { useEffect } from "react";
import { Col, Row, Spinner } from "reactstrap";
import UserInfoCard from "./UserInfoCard";
import UserCounts from "./UserCounts";
import Breadcrumbs from "@components/breadcrumbs";
import { useNavigate, useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { GetSingleUsers } from "../../redux/Slices/userSlice";
import { ArrowLeft } from "react-feather";

const UsersView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const singleUserData = useSelector((state) => state?.user?.getSingleuserData);
  const IsLoading = useSelector((state) => state?.user?.userloader);
  const accessToken = useSelector((state) => state?.auth?.accessToken);

  useEffect(() => {
    dispatch(GetSingleUsers(id, accessToken));
  }, [id]);
  return (
    <div className="app-user-view">
      <div className="row">
        <div className="d-flex align-items-center">
          <ArrowLeft
            onClick={() => navigate("/users")}
            className="cursor-pointer me-1"
          />
          <Breadcrumbs title="User Details" data={[{ title: "" }]} />
        </div>
      </div>
      {IsLoading ? (
        <div className="d-flex justify-content-center align-items-center loader-container my-5">
          <Spinner />
        </div>
      ) : (
        <Row className="mt-2">
          <Col xl="4" lg="5" xs={{ order: 1 }} md={{ order: 0, size: 5 }}>
            <UserInfoCard singleUserData={singleUserData} />
          </Col>
          <Col xl="8" lg="7" xs={{ order: 0 }} md={{ order: 1, size: 7 }}>
            <UserCounts singleUserData={singleUserData} />
          </Col>
        </Row>
      )}
    </div>
  );
};

export default UsersView;
