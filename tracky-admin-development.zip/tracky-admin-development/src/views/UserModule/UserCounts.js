import React from "react";
import {
  Activity,
  BarChart,
  Briefcase,
  Check,
  MessageCircle,
  PhoneCall,
  TrendingDown,
  User,
  UserCheck,
  UserPlus,
  UserX,
} from "react-feather";
import StatsHorizontal from "@components/widgets/stats/StatsHorizontal";

import { Badge, Col, Row } from "reactstrap";

const UserCounts = ({ singleUserData }) => {
  return (
    <div>
      <div className="app-user-list">
        <Row>
          <Col lg="6" sm="6">
            <StatsHorizontal
              color="primary"
              statTitle="Average deal size"
              icon={<BarChart size={20} />}
              renderStats={
                <h3 className="fw-bolder mb-75">
                  {singleUserData?.sumData?.average_deal_size
                    ? singleUserData?.sumData?.average_deal_size
                    : 0}
                </h3>
              }
            />
          </Col>
          {singleUserData?.profileData?.role?.key === "closer" && (
            <Col lg="6" sm="6">
              <StatsHorizontal
                color="warning"
                statTitle="Total calls"
                icon={<PhoneCall size={20} />}
                renderStats={
                  <h3 className="fw-bolder mb-75">
                    {singleUserData?.sumData?.total_calls
                      ? singleUserData?.sumData?.total_calls
                      : 0}
                  </h3>
                }
              />
            </Col>
          )}
          {singleUserData?.profileData?.role?.key === "setter" && (
            <Col lg="6" sm="6">
              <StatsHorizontal
                color="warning"
                statTitle="Total chats"
                icon={<MessageCircle size={20} />}
                renderStats={
                  <h3 className="fw-bolder mb-75">
                    {singleUserData?.sumData?.total_chat
                      ? singleUserData?.sumData?.total_chat
                      : 0}
                  </h3>
                }
              />
            </Col>
          )}

          <Col lg="6" sm="6">
            <StatsHorizontal
              color="success"
              statTitle="Total clients"
              icon={<UserCheck size={20} />}
              renderStats={
                <h3 className="fw-bolder mb-75">
                  {singleUserData?.sumData?.total_client
                    ? singleUserData?.sumData?.total_client
                    : 0}
                </h3>
              }
            />
          </Col>
          <Col lg="6" sm="6">
            <StatsHorizontal
              color="danger"
              statTitle="Total lost"
              icon={<TrendingDown size={20} />}
              renderStats={
                <h3 className="fw-bolder mb-75">
                  {singleUserData?.sumData?.total_lost
                    ? singleUserData?.sumData?.total_lost
                    : 0}
                </h3>
              }
            />
          </Col>
        </Row>
        {/* <Table /> */}
      </div>
    </div>
  );
};

export default UserCounts;
