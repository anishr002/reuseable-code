// ** Third Party Components
import {
  Trash,
  Eye,
  MoreVertical,
  FileText,
  XCircle,
  CheckCircle,
} from "react-feather";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";

// ** Reactstrap Imports
import {
  Badge,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  UncontrolledDropdown,
  UncontrolledTooltip,
} from "reactstrap";
import { store } from "../../redux/store";

import { ChangeStatus, DeleteUser } from "../../redux/Slices/userSlice";

export let data;

// // ** Get initial Data
// axios.get("/api/datatables/initial-data").then((response) => {
//   data = response.data;
// });

// ** Expandable table component
const ExpandableTable = ({ data }) => {
  return (
    <div className="expandable-content p-2">
      <p>
        <span className="fw-bold">City:</span> {data.city}
      </p>
      <p>
        <span className="fw-bold">Experience:</span> {data.experience}
      </p>
      <p className="m-0">
        <span className="fw-bold">Post:</span> {data.post}
      </p>
    </div>
  );
};
// const MySwal = withReactContent(Swal);

const showAlert = (_id) => {
  // alert("I'm an alert")

  return Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert User!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, delete it!",
    customClass: {
      confirmButton: "btn btn-primary",
      cancelButton: "btn btn-outline-danger ml-1",
    },
    buttonsStyling: false,
  }).then(function (result) {
    if (result.isConfirmed) {
      // store.dispatch(DeleteUser(_id));
    }
  });
};

const statusHandler = (row) => {
  // alert("I'm an alert")
  const User_id = row?._id;
  const payload = {
    status:
      row?.status === "Active"
        ? "Deactive"
        : row?.status === "Deactive"
        ? "Active"
        : "Active",
  };

  return Swal.fire({
    title: "Are you sure?",
    text: `You want to change status!`,
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, change it!",
    customClass: {
      confirmButton: "btn btn-primary",
      cancelButton: "btn btn-outline-danger ml-1",
    },
    buttonsStyling: false,
  }).then(function (result) {
    if (result.isConfirmed) {
      store.dispatch(ChangeStatus(User_id, payload, accessToken));
    }
  });
};

// ** Table Common Column
export const columns = [
  {
    name: "Name",
    minWidth: "250px",
    sortable: true,
    sortField: "first_name",
    selector: "first_name",
    cell: (row) =>
      row?.user_name?.charAt(0).toUpperCase() +
      row?.user_name?.slice(1).toLowerCase(),
  },
  {
    name: "Email",
    sortable: true,
    minWidth: "250px",
    selector: "email",
    sortField: "email",

    cell: (row) => row?.email,
  },
  {
    name: "Country",
    sortable: true,
    minWidth: "150px",
    selector: "country",
    sortField: "country",
    cell: (row) => {
      return row?.country ? row?.country : "N/A";
    },
  },

  {
    name: "Role",
    sortable: true,
    minWidth: "150px",
    selector: "key",
    sortField: "key",

    cell: (row) => (
      <span>
        {row?.role_Data?.key === "closer" ? (
          <Badge color="light-success">
            <div>
              <span>Closer</span>
            </div>
          </Badge>
        ) : (
          <Badge color="light-warning">
            <div>
              <span>Setter</span>
            </div>
          </Badge>
        )}
      </span>
    ),
  },

  {
    name: "Status",
    minWidth: "150px",
    sortable: true,
    sortField: "status",
    cell: (row) => (
      <span>
        {row?.status === "Active" ? (
          <Badge color="light-success">
            <div>
              <span>Active</span>
            </div>
          </Badge>
        ) : row?.status === "Deactive" ? (
          <Badge color="light-warning">
            <div>
              <span>Deactive</span>
            </div>
          </Badge>
        ) : (
          "N/A"
        )}
      </span>
    ),
  },
  {
    name: "Actions",
    allowOverflow: true,
    cell: (row) => {
      return (
        <div className="d-flex">
          <div style={{ marginRight: "10px" }} className="cursor-pointer">
            {row?.status === "Active" ? (
              <span onClick={() => statusHandler(row)}>
                <XCircle
                  color="#FF0000"
                  size={15}
                  className="mr-1"
                  id={`statusTooltip${row?._id}`}
                />
                <UncontrolledTooltip
                  placement="top"
                  target={`statusTooltip${row?._id}`}
                >
                  Deactive
                </UncontrolledTooltip>
              </span>
            ) : row?.status === "Deactive" ? (
              <span onClick={() => statusHandler(row)}>
                <CheckCircle
                  color="#008000"
                  size={15}
                  className="mr-1"
                  id={`deactivestatusTooltip${row?._id}`}
                />
                <UncontrolledTooltip
                  placement="top"
                  target={`deactivestatusTooltip${row?._id}`}
                >
                  Active
                </UncontrolledTooltip>
              </span>
            ) : (
              <span onClick={() => statusHandler(row)}>
                <CheckCircle
                  color="#008000"
                  size={15}
                  className="mr-1"
                  id={`deactivestatusTooltip${row?._id}`}
                />
                <UncontrolledTooltip
                  placement="top"
                  target={`deactivestatusTooltip${row?._id}`}
                >
                  Active
                </UncontrolledTooltip>
              </span>
            )}
          </div>
          <div style={{ marginRight: "10px" }}>
            <Link to={`/users/${row?._id}`}>
              <Eye
                color="#0000FF"
                size={15}
                className="mr-1"
                id={`viewTooltip${row?._id}`}
              />
              <UncontrolledTooltip
                placement="top"
                target={`viewTooltip${row?._id}`}
              >
                View
              </UncontrolledTooltip>
            </Link>
          </div>
          <div className="cursor-pointer">
            <span onClick={() => showAlert(row?._id)}>
              <Trash
                color="#ea5556"
                size={15}
                id={`deleteTooltip${row?._id}`}
              />
              <UncontrolledTooltip
                placement="top"
                target={`deleteTooltip${row?._id}`}
              >
                Delete
              </UncontrolledTooltip>
            </span>
          </div>
        </div>
      );
    },
  },
];

export default ExpandableTable;
