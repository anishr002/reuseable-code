// ** React Imports
import { useState, Fragment } from "react";

// ** Reactstrap Imports
import {
  Row,
  Col,
  Card,
  Form,
  CardBody,
  Button,
  Badge,
  Modal,
  Input,
  Label,
  ModalBody,
  ModalHeader,
} from "reactstrap";
import defaultAvatar from "@src/assets/images/portrait/small/avatar-s-11.jpg";
import alex_img from "../../../src/assets/images/logo/alex_img.svg";

// ** Third Party Components
import Swal from "sweetalert2";
import Select from "react-select";
import { Check, Briefcase, X } from "react-feather";
import { useForm, Controller } from "react-hook-form";
import withReactContent from "sweetalert2-react-content";

// ** Custom Components
import Avatar from "@components/avatar";

// ** Utils
import { selectThemeColors } from "@utils";

// ** Styles
import "@styles/react/libs/react-select/_react-select.scss";

const roleColors = {
  editor: "light-info",
  admin: "light-danger",
  author: "light-warning",
  maintainer: "light-success",
  subscriber: "light-primary",
};

const statusColors = {
  active: "light-success",
  pending: "light-warning",
  inactive: "light-secondary",
};

const statusOptions = [
  { value: "active", label: "Active" },
  { value: "inactive", label: "Inactive" },
  { value: "suspended", label: "Suspended" },
];

const countryOptions = [
  { value: "uk", label: "UK" },
  { value: "usa", label: "USA" },
  { value: "france", label: "France" },
  { value: "russia", label: "Russia" },
  { value: "canada", label: "Canada" },
];

const languageOptions = [
  { value: "english", label: "English" },
  { value: "spanish", label: "Spanish" },
  { value: "french", label: "French" },
  { value: "german", label: "German" },
  { value: "dutch", label: "Dutch" },
];

const MySwal = withReactContent(Swal);

const UserInfoCard = ({ selectedUser, singleUserData }) => {
  // ** State
  const [show, setShow] = useState(false);

  // ** Hook
  const {
    reset,
    control,
    setError,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      username: selectedUser?.username,
      lastName: selectedUser?.fullName?.split(" ")[1],
      firstName: selectedUser?.fullName?.split(" ")[0],
    },
  });

  // ** render user img
  const renderUserImg = () => {
    const imageUrl = singleUserData?.profileData?.profile_image
      ? `${import.meta.env.VITE_APP_API_ADMIN_IO}/${
          singleUserData?.profileData?.profile_image
        }`
      : alex_img;

    return (
      <img
        height="110"
        width="110"
        alt="user-avatar"
        src={imageUrl}
        onError={({ currentTarget }) => {
          currentTarget.onerror = null; // prevents looping
          currentTarget.src = alex_img;
        }}
        className="img-fluid rounded mt-3 mb-2"
      />
    );
  };

  return (
    <Fragment>
      <Card>
        <CardBody>
          <div className="user-avatar-section">
            <div className="d-flex align-items-center flex-column">
              {renderUserImg()}
              <div className="d-flex flex-column align-items-center text-center">
                <div className="user-info">
                  <h4>
                    {selectedUser !== null
                      ? selectedUser?.fullName
                      : "Eleanor Aguilar"}
                  </h4>
                  {selectedUser !== null ? (
                    <Badge
                      color={roleColors[selectedUser?.role]}
                      className="text-capitalize"
                    >
                      {selectedUser?.role}
                    </Badge>
                  ) : null}
                </div>
              </div>
            </div>
          </div>

          <h4 className="fw-bolder border-bottom pb-50 mb-1">Details</h4>
          <div className="info-container">
            <ul className="list-unstyled">
              <li className="mb-75">
                <span className="fw-bolder me-25">Username:</span>
                <span>
                  {singleUserData?.profileData?.user_name
                    ? singleUserData?.profileData?.user_name
                    : singleUserData?.profileData?.first_name +
                      " " +
                      singleUserData?.profileData?.last_name}
                </span>
              </li>
              <li className="mb-75">
                <span className="fw-bolder me-25">Email:</span>
                <span>
                  {singleUserData?.profileData?.email
                    ? singleUserData?.profileData?.email
                    : "N/A"}
                </span>
              </li>
              <li className="mb-75">
                <span className="fw-bolder me-25">Status:</span>
                {singleUserData?.profileData?.status === "Active" ? (
                  <Badge className="text-capitalize" color="light-success">
                    Active
                  </Badge>
                ) : singleUserData?.profileData?.status === "Deactive" ? (
                  <Badge className="text-capitalize" color="light-warning">
                    Deactive
                  </Badge>
                ) : (
                  "N/A"
                )}
              </li>
              <li className="mb-75">
                <span className="fw-bolder me-25">Role:</span>
                <span className="text-capitalize">
                  {singleUserData?.profileData?.role?.key === "closer" ? (
                    <Badge className="text-capitalize" color="light-success">
                      Closer
                    </Badge>
                  ) : singleUserData?.profileData?.role?.key === "setter" ? (
                    <Badge className="text-capitalize" color="light-warning">
                      Setter
                    </Badge>
                  ) : (
                    "N/A"
                  )}
                </span>
              </li>
              <li className="mb-75">
                <span className="fw-bolder me-25">Bio:</span>
                <span>
                  {singleUserData?.profileData?.bio
                    ? singleUserData?.profileData?.bio
                    : "N/A"}
                </span>
              </li>
              <li className="mb-75">
                <span className="fw-bolder me-25">Subscription:</span>
                <span>
                  {singleUserData?.profileData?.plan_purchased_type &&
                  singleUserData?.profileData?.plan_purchased_type !== null
                    ? singleUserData?.profileData?.plan_purchased_type
                    : "N/A"}
                </span>
              </li>

              <li className="mb-75">
                <span className="fw-bolder me-25">Country:</span>
                <span>
                  {singleUserData?.profileData?.country
                    ? singleUserData?.profileData?.country
                    : "N/A"}
                </span>
              </li>
            </ul>
          </div>
        </CardBody>
      </Card>
    </Fragment>
  );
};

export default UserInfoCard;
