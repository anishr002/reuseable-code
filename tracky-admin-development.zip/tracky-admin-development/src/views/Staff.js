import React, { useState } from "react";
import { Helmet } from "react-helmet";
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Row,
  Col,
  Input,
  Form,
  Button,
  Label,
  FormFeedback,
} from "reactstrap";
import InputPasswordToggle from "@components/input-password-toggle";
import { useForm, Controller } from "react-hook-form";
import Breadcrumbs from "@components/breadcrumbs";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { ErrorMessage } from "@hookform/error-message";
import { handleKeyDown } from "../utility/SpaceValidation.js";
// import { DevTool } from "@hookform/devtools"
import { useDispatch, useSelector } from "react-redux";
import {
  saveStaff,
  getSingleStaff,
  updateSingleStaff,
} from "../redux/Slices/StaffSlice";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import { ArrowLeft } from "react-feather";

function Staff() {
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get("id");
  const getSingleStaffData = useSelector(
    (state) => state?.staff?.getSingleStaffData
  );
  const [formTitle, setFormTitle] = useState("Add");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const accessToken = useSelector((state) => state?.auth?.accessToken);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get("id");
    if (token != null || token != undefined) {
      dispatch(getSingleStaff(accessToken, token));
    }
  }, []);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get("id");
    if (token != null || token != undefined) {
      setValue("first_name", getSingleStaffData.first_name);
      setValue("last_name", getSingleStaffData.last_name);
      setValue("email", getSingleStaffData.email);
      if (getSingleStaffData.isStaffManagement) {
        setValue("isStaffManagement", true);
      }
      if (getSingleStaffData.isUsers) {
        setValue("isUsers", true);
      }
      if (getSingleStaffData.isPayment) {
        setValue("isPayment", true);
      }
      if (getSingleStaffData.isSupportTicket) {
        setValue("isSupportTicket", true);
      }
      setFormTitle("Edit");
    }
    return () => {
      reset();
    };
  }, [getSingleStaffData, token]);

  const validationSchema = Yup.object()
    .shape({
      first_name: Yup.string()
        .required("First name is required")
        .max(30, "Maximum 30 characters allowed"),
      last_name: Yup.string()
        .required("Last name is required")
        .max(30, "Maximum 30 characters allowed"),
      email: Yup.string()
        .required("E-mail is required")
        .matches(
          /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
          "Please enter valid email address"
        ),
      password: Yup.string()
        .required("Password is required")
        .matches(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
          "Must contain 8 characters,at least one uppercase,lowercase, number and special case character"
        )
        .max(15, "Maximum 15 characters allowed"),
      confirmPassword: Yup.string()
        .required("Confirm password is required")
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .max(15, "Maximum 15 characters allowed"),

      isStaffManagement: Yup.boolean(),
      isUsers: Yup.boolean(),
      isPayment: Yup.boolean(),
      isSupportTicket: Yup.boolean(),
    })
    .test("at-least-one", "Select at least one checkbox", function (values) {
      const { isStaffManagement, isUsers, isPayment, isSupportTicket } = values;
      if (isStaffManagement || isUsers || isPayment || isSupportTicket) {
        return true;
      } else if (
        !isStaffManagement &&
        !isUsers &&
        !isPayment &&
        !isSupportTicket
      ) {
        return this.createError({
          path: "isUsers", // Choose any one checkbox to associate the error with
          message: "Please give at least one permission",
        });
      }

      return true;
    });

  const EditvalidationSchema = Yup.object()
    .shape({
      first_name: Yup.string()
        .required("First name is required")
        .max(30, "Maximum 30 characters allowed"),
      last_name: Yup.string()
        .required("Last name is required")
        .max(30, "Maximum 30 characters allowed"),
      email: Yup.string()
        .required("E-mail is required")
        .matches(
          /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
          "Please enter valid email address"
        ),
      password: Yup.string().test(
        "password",
        "Password is required",
        function (value) {
          const { confirmPassword } = this.parent;
          // If confirmPassword is provided, require a password
          if (confirmPassword && confirmPassword.length > 0) {
            return !!value;
          }
          // Otherwise, password is optional
          return true;
        }
      ),
      confirmPassword: Yup.string().when("password", {
        is: (password) => password && password.length > 0,
        then: Yup.string()
          .required("Confirm password is required")
          .oneOf([Yup.ref("password"), null], "Passwords must match")
          .max(15, "Maximum 15 characters allowed"),
      }),
      isStaffManagement: Yup.boolean(),
      isUsers: Yup.boolean(),
      isPayment: Yup.boolean(),
      isSupportTicket: Yup.boolean(),
    })
    .test("at-least-one", "Select at least one checkbox", function (values) {
      const { isStaffManagement, isUsers, isPayment, isSupportTicket } = values;
      if (isStaffManagement || isUsers || isPayment || isSupportTicket) {
        return true;
      } else if (
        !isStaffManagement &&
        !isUsers &&
        !isPayment &&
        !isSupportTicket
      ) {
        return this.createError({
          path: "isUsers", // Choose any one checkbox to associate the error with
          message: "Please give at least one permission",
        });
      }

      return true;
    });

  const NewValidationSchema = token ? EditvalidationSchema : validationSchema;

  const {
    control,
    register,
    handleSubmit,
    getFieldState,
    trigger,
    formState: { isDirty, dirtyFields, touchedFields, isValid, errors },
    reset,
    setValue,
    setError,
    clearErrors,
    watch,
  } = useForm({
    resolver: yupResolver(NewValidationSchema),
  });

  let modules = [
    { name: "Staff Management", value: "staffmanagement" },
    { name: "Users", value: "users" },
    { name: "Payment", value: "payment" },
    { name: "Support ticket", value: "supportmanagement" },
  ];

  const onSubmit = async (data) => {

    const { confirmPassword, ...newdata } = data;

    if (token != null || token != undefined) {
      dispatch(updateSingleStaff(accessToken, newdata, token, navigate));
    } else {
      dispatch(saveStaff(accessToken, newdata, navigate));
    }
  };

  const resetForm = () => {
    reset();
  };

  return (
    <>
      <Helmet>
        <title>Tracky | Staff</title>
        <meta name="description" content="Tracky | Staff" />
      </Helmet>
      <div className="d-flex align-items-center">
        <ArrowLeft
          onClick={() => navigate("/staff-management")}
          className="cursor-pointer me-1"
        />
        <Breadcrumbs
          title="Staff Management"
          data={[
            { title: "Staff list", link: "/staff-management" },
            { title: "Staff" },
          ]}
        />
      </div>

      <Col sm="12" className="mt-2">
        <Card>
          <CardHeader>
            <CardTitle tag="h4">{`${formTitle}`} Staff</CardTitle>
          </CardHeader>

          <CardBody>
            <Form onSubmit={handleSubmit(onSubmit)}>
              <Row>
                <Col md="6" sm="12" className="mb-1">
                  <Label className="form-label" for="first_name">
                    First Name
                  </Label>
                  <Controller
                    id="firstName"
                    name="first_name"
                    defaultValue=""
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        type="text"
                        placeholder="First Name"
                        autoComplete="off"
                        onKeyPress={handleKeyDown}
                        invalid={errors.first_name && true}
                      />
                    )}
                  />
                  {errors.first_name && (
                    <FormFeedback>{errors.first_name.message}</FormFeedback>
                  )}
                </Col>

                <Col md="6" sm="12" className="mb-1">
                  <Label className="form-label" for="last_name">
                    Last Name
                  </Label>
                  <Controller
                    id="lastName"
                    name="last_name"
                    defaultValue=""
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        type="text"
                        placeholder="Last Name"
                        autoComplete="off"
                        onKeyPress={handleKeyDown}
                        invalid={errors.last_name && true}
                      />
                    )}
                  />
                  {errors.last_name && (
                    <FormFeedback>{errors.last_name.message}</FormFeedback>
                  )}
                </Col>
                <Col md="6" sm="12" className="mb-1">
                  <Label className="form-label" for="email">
                    Email
                  </Label>
                  <Controller
                    id="email"
                    name="email"
                    defaultValue=""
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        type="text"
                        placeholder="Email"
                        autoComplete="off"
                        onKeyPress={handleKeyDown}
                        invalid={errors.email && true}
                      />
                    )}
                  />
                  {errors.email && (
                    <FormFeedback>{errors.email.message}</FormFeedback>
                  )}
                </Col>

                <Col md="6" sm="12" className="mb-1">
                  <Label className="form-label" for="EmailMulti">
                    Password
                  </Label>
                  <Controller
                    name="password"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <>
                        <InputPasswordToggle
                          className="input-group-merge"
                          onKeyPress={handleKeyDown}
                          id="login-password"
                          {...field}
                          invalid={errors.password && true}
                        />
                      </>
                    )}
                  />
                  {errors.password && (
                    <FormFeedback>{errors.password.message}</FormFeedback>
                  )}
                </Col>

                <Col md="6" sm="12" className="mb-1">
                  <Label className="form-label" for="confirmPassword">
                    Confirm Password
                  </Label>
                  <Controller
                    name="confirmPassword"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <>
                        <InputPasswordToggle
                          className="input-group-merge"
                          id="confirmpassword"
                          onKeyPress={handleKeyDown}
                          {...field}
                          invalid={errors.confirmPassword && true}
                        />
                      </>
                    )}
                  />
                  {errors.confirmPassword && (
                    <FormFeedback>
                      {errors.confirmPassword.message}
                    </FormFeedback>
                  )}
                </Col>

                <Col md="6" sm="12" className="mb-1">
                  <Label className="form-label" for="confirmpassword">
                    Permission
                  </Label>
                  <div className="mt-1">
                    {/* {modules.map((item, index) => {
                      return (
                        <div
                          className="form-check form-check-inline"
                          key={index}
                        >
                          <Input
                            type="checkbox"
                            id="basic-cb-checked"
                            value={item.value}
                            name="permission"
                            key={index}
                            {...register("permission")}
                            // ref={register}
                            defaultChecked={false}
                          />
                          <Label
                            for="basic-cb-checked"
                            className="form-check-label"
                          >
                            {item.name}
                          </Label>
                        </div>
                      )
                    })} */}

                    <div className="form-check form-check-inline">
                      <Controller
                        control={control}
                        name="isUsers"
                        defaultValue={false}
                        render={({ field }) => (
                          <Input
                            type="checkbox"
                            id="basic-cb-checked"
                            {...field}
                            checked={field.value}
                          />
                        )}
                      />
                      <Label
                        for="basic-cb-checked"
                        className="form-check-label"
                      >
                        {`Users`}
                      </Label>
                    </div>
                    <div className="form-check form-check-inline">
                      <Controller
                        control={control}
                        name="isStaffManagement"
                        defaultValue={false}
                        render={({ field }) => (
                          <Input
                            type="checkbox"
                            id="basic-cb-checked"
                            value={`staffManagement`}
                            {...field}
                            checked={field.value}
                          />
                        )}
                      />
                      <Label
                        for="basic-cb-checked"
                        className="form-check-label"
                      >
                        {`Staff Management`}
                      </Label>
                    </div>
                    <div className="form-check form-check-inline">
                      <Controller
                        control={control}
                        name="isPayment"
                        defaultValue={false}
                        render={({ field }) => (
                          <Input
                            type="checkbox"
                            id="basic-cb-checked"
                            {...field}
                            checked={field.value}
                          />
                        )}
                      />
                      <Label
                        for="basic-cb-checked"
                        className="form-check-label"
                      >
                        {`Payment`}
                      </Label>
                    </div>
                    <div className="form-check form-check-inline">
                      <Controller
                        control={control}
                        name="isSupportTicket"
                        defaultValue={false}
                        render={({ field }) => (
                          <Input
                            type="checkbox"
                            id="basic-cb-checked"
                            {...field}
                            checked={field.value}
                          />
                        )}
                      />
                      <Label
                        for="basic-cb-checked"
                        className="form-check-label"
                      >
                        {`Support ticket`}
                      </Label>
                    </div>
                    {errors.isUsers && (
                      <p className="text-danger">{errors.isUsers.message}</p>
                    )}
                  </div>
                </Col>

                <Col sm="12">
                  <div className="d-flex">
                    <Button className="me-1" color="primary" type="submit">
                      Submit
                    </Button>
                    <Button
                      outline
                      color="secondary"
                      type="button"
                      onClick={resetForm}
                    >
                      Reset
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>

            {/* <DevTool control={control} /> */}
          </CardBody>
        </Card>
      </Col>
    </>
  );
}

export default Staff;
