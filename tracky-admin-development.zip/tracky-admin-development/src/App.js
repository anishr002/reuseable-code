import React, { Suspense } from "react"
import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import {SocketContextProvider} from "./utility/context/SocketContextProvider.jsx"

// ** Router Import
import Router from "./router/Router"

const App = () => {
  return (
    <SocketContextProvider>

    <Suspense fallback={null}>
      <Router />
      <ToastContainer limit={1} />
    </Suspense>
    </SocketContextProvider>

  )
}

export default App
