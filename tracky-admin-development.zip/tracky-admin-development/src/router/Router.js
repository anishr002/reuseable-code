// ** Router imports
import { lazy } from "react"
import { useRoutes, Navigate } from "react-router-dom"

// ** GetRoutes
import { getRoutes } from "./routes"

// ** Hooks Imports
import { useLayout } from "@hooks/useLayout"
import { useSelector } from "react-redux"
const Login = lazy(() => import("../views/Login"))
const NotAuthorized = lazy(() => import("../views/misc/NotAuthorized"))
import BlankLayout from "@layouts/BlankLayout"
const Error = lazy(() => import("../views/misc/Error"))

const Router = () => {
  // ** Hooks
  const { layout } = useLayout()

  const allRoutes = getRoutes(layout)
  const accessToken = useSelector((state) => state?.auth?.accessToken)

  const getHomeRoute = () => {
    // const user = getUserData()
    if (accessToken) {
      return "/dashboard"
    } else {
      return "/login"
    }
  }

  const routes = useRoutes([
    {
      path: "/",
      index: true,
      element: <Navigate replace to={getHomeRoute()} />,
    },
    // {
    //   path: "/login",
    //   element: <BlankLayout />,
    //   children: [{ path: "/login", element: <Login /> }],
    // },
    {
      path: "/auth/not-auth",
      element: <BlankLayout />,
      children: [{ path: "/auth/not-auth", element: <NotAuthorized /> }],
    },
    {
      path: "*",
      element: <BlankLayout />,
      children: [{ path: "*", element: <Error /> }],
    },
    ...allRoutes,
  ])

  return routes
}

export default Router
