### Added firebase credential ###
- In .env

### Install Node Modules ###
- npm install

### Start Project ###
- npm start