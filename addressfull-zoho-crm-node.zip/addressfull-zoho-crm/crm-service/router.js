const rootRouter = require("express").Router();

const hubspotRouter = require("./routes/hubspotRoute");
const zohoRouter = require("./routes/zohoRoute");

rootRouter.use("/api/v1/hubspot", hubspotRouter);
rootRouter.use("/api/v1/zoho", zohoRouter);

module.exports = rootRouter;
