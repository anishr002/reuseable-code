require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { errorHandler, notFound } = require('./middleware/errorHandler');
const logger = require('./logger');
const rootRouter = require('./router');

const app = express();
app.disable('x-powered-by');
app.use(express.json());
app.use(cors());

app.use(rootRouter);

app.use(notFound);
app.use(errorHandler);

module.exports = app.listen(process.env.PORT, process.env.HOST, () => {
  logger.info(
    `Your server is running on : ${process.env.PROTOCOL}://${process.env.HOST}:${process.env.PORT}`
  );
});
