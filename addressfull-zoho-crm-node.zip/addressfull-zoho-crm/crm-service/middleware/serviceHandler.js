const asyncHandler = require('./asyncHandler');
const logger = require('../logger');

// Common error handling function
const handleServiceError = (error) => ({
  error: error.message,
  errorInfo: error?.body?.message || null,
});

// Higher-order function to wrap the service functions
const withErrorHandling = (serviceFunction) =>
  asyncHandler(async (...args) => {
    try {
      return await serviceFunction(...args);
    } catch (error) {
      logger.error(`Error cached by serviceHandler of CRM: ${error.message}`);
      return handleServiceError(error);
    }
  });

// Error handling function for Zoho service - throws errors instead of returning them
const withZohoErrorHandling = (serviceFunction) =>
  asyncHandler(async (...args) => {
    try {
      return await serviceFunction(...args);
    } catch (error) {
      logger.error(
        `Error in Zoho service: ${error.message}`,
        error.response?.data || error
      );
      // Re-throw the error so it can be properly handled by the controller
      throw error;
    }
  });

module.exports = withErrorHandling;
module.exports.withZohoErrorHandling = withZohoErrorHandling;
