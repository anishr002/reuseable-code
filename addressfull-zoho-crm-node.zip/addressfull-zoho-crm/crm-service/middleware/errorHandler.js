const responseMessages = require("../config/constants/reponseMessages");

exports.errorHandler = (err, _req, res, _next) => {
  const statusCode = res.statusCode !== 200 ? res.statusCode : 500;
  return res.status(statusCode).json({
    status: statusCode,
    message:
      process.env.NODE_ENV === "development"
        ? err.message
        : "Something went wrong!",
    stack: process.env.NODE_ENV === "development" ? err.stack : null,
  });
};

exports.notFound = (_req, res) =>
  res.status(404).json({
    status: 404,
    message: responseMessages.ROUTE_NOT_FOUND,
  });
