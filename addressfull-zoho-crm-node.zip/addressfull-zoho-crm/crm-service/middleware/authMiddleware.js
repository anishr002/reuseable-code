const responseMessages = require('../config/constants/reponseMessages');

exports.protect = (req, res, next) => {
  let token;
  const authHeader =
    req.headers && (req.header('authorization') || req.header('token'));
  if (authHeader?.trim().startsWith('Bearer')) {
    token = authHeader.replace('Bearer', '').trim();
  }
  // console.log(`token from Users service: ${token}`)
  // console.log(`token from env: ${process.env.API_KEY_AUTHENTICATION}`)
  // console.log(`Comparison: ${token && token == process.env.API_KEY_AUTHENTICATION}`)
  if (token && token === process.env.API_KEY_AUTHENTICATION) return next();
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
};
