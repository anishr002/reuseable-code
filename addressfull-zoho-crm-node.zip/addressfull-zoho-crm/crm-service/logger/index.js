const buildDevLogger = require('./logger');

const logger = buildDevLogger();

module.exports = logger;
