const { deepFreezeObject } = require('../../utils/common');

module.exports = deepFreezeObject({
  // --- Validation Errors Users
  INVALID_EMAIL_PASSWORD: 'Invalid email or password',
  INVALID_MOBILE: 'Invalid Country Code or Mobile Number.',
  USER_NOT_EXIST: "Account doesn't exist",
  ACCOUNT_EXIST: 'Account already exists',
  ACCOUNT_CREATION_FAIL: 'There was an issue in creating your account',

  // --- General Error Messages
  SOMETHING_WENT_WRONG: 'Something is wrong',
  UNAUTHORIZED_ACCESS: 'Unauthorized access',
  ROUTE_NOT_FOUND: 'Route not found',
  INVALID_ID: 'Invalid or missing ID',
});
