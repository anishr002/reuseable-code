const router = require('express').Router();
const {
  createContact,
  getContactById,
  getContacts,
  updateContact,
  updateContactBatch,
  deleteContact,
  verifyToken,
  verifyCRMConnection,
} = require('../controllers/hubspotController');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);
router.get('/verifyCRMHealth', verifyCRMConnection);
router.post('/verifyToken', verifyToken);
router.post('/create', createContact);
router.post('/update/:id', updateContact);
router.post('/updateBatch', updateContactBatch);
router.post('/delete/:id', deleteContact);
router.post('/get/:id', getContactById);
router.post('/', getContacts);

module.exports = router;
