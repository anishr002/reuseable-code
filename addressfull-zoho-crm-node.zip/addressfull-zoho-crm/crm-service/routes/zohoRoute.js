const router = require('express').Router();
const {
  createContact,
  getContactById,
  getContacts,
  updateContact,
  updateContactBatch,
  deleteContact,
  verifyToken,
  verifyCRMConnection,
  getAccessToken,
  getTokenFromCode,
  exchangeCodeForTokens,
  verifyAndRefreshToken,
} = require('../controllers/zohoController');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

// CRM Health and Token verification
router.get('/verifyCRMHealth', verifyCRMConnection);
router.post('/verifyToken', verifyToken);

// Token management APIs (based on your screenshot)
router.post('/getAccessToken', getAccessToken);
router.post('/getTokenFromCode', getTokenFromCode);
router.post('/exchangeCodeForTokens', exchangeCodeForTokens);
router.post('/verifyAndRefreshToken', verifyAndRefreshToken);

// Contact management APIs
router.post('/create', createContact);
router.post('/update/:id', updateContact);
router.post('/updateBatch', updateContactBatch);
router.post('/delete/:id', deleteContact);
router.post('/get/:id', getContactById);
router.post('/', getContacts);

module.exports = router;
