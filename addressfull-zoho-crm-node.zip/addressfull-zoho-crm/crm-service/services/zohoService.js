const axios = require('axios');
const withErrorHandling = require('../middleware/serviceHandler');
const { withZohoErrorHandling } = require('../middleware/serviceHandler');
const logger = require('../logger');

const ZOHO_API_BASE_URL =
  process.env.ZOHO_API_BASE_URL || 'https://www.zohoapis.in/crm/v2';
const ZOHO_OAUTH_URL =
  process.env.ZOHO_OAUTH_URL || 'https://accounts.zoho.in/oauth/v2/token';

// Helper function to create axios instance with auth token
const createZohoClient = (authToken) =>
  axios.create({
    baseURL: ZOHO_API_BASE_URL,
    headers: {
      Authorization: `Zoho-oauthtoken ${authToken}`,
      'Content-Type': 'application/json',
    },
  });

// Helper function to format phone number for Zoho
const formatPhoneNumber = (phone) => {
  if (!phone) return undefined;
  // Convert to string and replace | with space or hyphen, remove any other non-digit characters except +
  const cleaned = String(phone)
    .replace(/\|/g, ' ')
    .replace(/[^\d+ ]/g, '');
  return cleaned || undefined;
};

// Helper function to extract Twitter handle from URL
const formatTwitter = (twitter) => {
  if (!twitter) return undefined;
  // If it's a URL, extract the handle
  if (twitter.includes('twitter.com/') || twitter.includes('x.com/')) {
    const parts = twitter.split('/');
    return parts[parts.length - 1] || undefined;
  }
  // If it's already a handle, return as is
  return twitter;
};

// Map AddressFull fields to Zoho CRM fields
const createPropertiesObject = (payload) => {
  const properties = {
    First_Name: payload?.firstName,
    Last_Name: payload?.lastName,

    Mobile: formatPhoneNumber(payload?.mobileNumber1),
    Mobile_Number_2: formatPhoneNumber(payload?.mobileNumber2),
    Mobile_Number_3: formatPhoneNumber(payload?.mobileNumber3),
    Mobile_Number_4: formatPhoneNumber(payload?.mobileNumber4),
    Mobile_Number_5: formatPhoneNumber(payload?.mobileNumber5),

    // Additional contact details
    Email: payload?.email1,
    Email_2: payload?.email2,
    Email_3: payload?.email3,
    Email_4: payload?.email4,
    Email_5: payload?.email5,

    Address_1: payload?.address1,
    Address_2: payload?.address2,
    Address_3: payload?.address3,
    Address_4: payload?.address4,
    Address_5: payload?.address5,

    LinkedIn: payload?.linkedin,
    Twitter: formatTwitter(payload?.twitter),
  };

  // Remove undefined values
  Object.keys(properties).forEach(
    (key) => properties[key] === undefined && delete properties[key]
  );

  return properties;
};

// Verify Zoho connection by making a test API call
exports.verifyConnection = withErrorHandling(async (payload) => {
  const { auth_token } = payload;
  try {
    const zohoClient = createZohoClient(auth_token);
    // Test the connection by fetching user info
    const response = await zohoClient.get('/users?type=CurrentUser');

    if (
      response.data &&
      response.data.users &&
      response.data.users.length > 0
    ) {
      return true;
    }
    return false;
  } catch (error) {
    // Log error internally but don't expose details
    return false;
  }
});

// Verify Zoho CRM health
exports.verifyCRMHealth = withErrorHandling(async () => {
  try {
    // Simple health check - just verify the API endpoint is reachable
    const response = await axios.get(`${ZOHO_API_BASE_URL}/settings/modules`);
    return response.status === 200 || response.status === 401; // 401 means API is up but auth needed
  } catch (error) {
    return false;
  }
});

// Get all fields for Contacts module
const getContactFields = async (authToken) => {
  const zohoClient = createZohoClient(authToken);
  const response = await zohoClient.get('/settings/fields?module=Contacts');
  return response.data.fields || [];
};

// Create custom field in Zoho CRM
function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

// Function to create custom fields in chunks
async function createCustomFieldsInChunks(authToken, fields) {
  logger.info(`Creating custom fields in chunks...`, fields);
  const zohoClient = createZohoClient(authToken);
  const chunkedFields = chunkArray(fields, 5);
  const results = [];

  // eslint-disable-next-line no-restricted-syntax
  for (const group of chunkedFields) {
    // eslint-disable-next-line no-await-in-loop
    const response = await zohoClient.post(`/settings/fields?module=Contacts`, {
      fields: group,
    });
    results.push(response.data);
  }

  return results;
}

// Ensure all required custom fields exist
const ensureCustomFieldsExist = async (authToken) => {
  try {
    const existingFields = await getContactFields(authToken);
    const existingFieldNames = existingFields.map((field) => field.api_name);

    logger.info(
      `Existing custom fields in Zoho: ${JSON.stringify(existingFieldNames)}`
    );

    const requiredFields = [
      {
        api_name: 'Mobile_Number_2',
        field_label: 'Mobile Number 2',
        data_type: 'phone',
      },
      {
        api_name: 'Mobile_Number_3',
        field_label: 'Mobile Number 3',
        data_type: 'phone',
      },
      {
        api_name: 'Mobile_Number_4',
        field_label: 'Mobile Number 4',
        data_type: 'phone',
      },
      {
        api_name: 'Mobile_Number_5',
        field_label: 'Mobile Number 5',
        data_type: 'phone',
      },
      {
        api_name: 'Email_2',
        field_label: 'Email 2',
        data_type: 'text',
      },
      {
        api_name: 'Email_3',
        field_label: 'Email 3',
        data_type: 'email',
      },
      {
        api_name: 'Email_4',
        field_label: 'Email 4',
        data_type: 'email',
      },
      {
        api_name: 'Email_5',
        field_label: 'Email 5',
        data_type: 'email',
      },
      {
        api_name: 'Address_1',
        field_label: 'Address 1',
        data_type: 'textarea',
        length: 32000,
      },
      {
        api_name: 'Address_2',
        field_label: 'Address 2',
        data_type: 'textarea',
        length: 32000,
      },
      {
        api_name: 'Address_3',
        field_label: 'Address 3',
        data_type: 'textarea',
        length: 32000,
      },
      {
        api_name: 'Address_4',
        field_label: 'Address 4',
        data_type: 'textarea',
        length: 32000,
      },
      {
        api_name: 'Address_5',
        field_label: 'Address 5',
        data_type: 'textarea',
        length: 32000,
      },
      {
        api_name: 'LinkedIn',
        field_label: 'LinkedIn',
        data_type: 'website',
      },
    ];

    // Filter only fields not already existing
    const fieldsToCreate = requiredFields.filter(
      (field) => !existingFieldNames.includes(field.api_name)
    );

    if (fieldsToCreate.length > 0) {
      logger.info(
        `Creating ${fieldsToCreate.length} new custom fields in Zoho...`
      );
      const results = await createCustomFieldsInChunks(
        authToken,
        fieldsToCreate
      );
      logger.info('Zoho field creation results:', JSON.stringify(results));
    } else {
      logger.info('All required fields already exist.');
    }

    return true;
  } catch (error) {
    return false;
  }
};

// Create a new contact in Zoho CRM
exports.createContact = withZohoErrorHandling(async (payload) => {
  logger.info(
    `Creating Zoho contact with data: ${JSON.stringify({
      firstName: payload?.firstName,
      lastName: payload?.lastName,
      email: payload?.email1,
    })}`
  );

  // Ensure custom fields exist before creating contact
  await ensureCustomFieldsExist(payload.auth_token);
  const zohoClient = createZohoClient(payload.auth_token);
  const properties = createPropertiesObject(payload);

  logger.info(
    `Zoho contact properties prepared: ${Object.keys(properties).length} fields`
  );

  const requestBody = {
    data: [properties],
    trigger: ['approval', 'workflow', 'blueprint'],
  };

  const response = await zohoClient.post('/Contacts', requestBody);

  if (response.data && response.data.data && response.data.data.length > 0) {
    const contactId =
      response.data.data[0].details?.id || response.data.data[0].id;
    logger.info(
      `Zoho contact created successfully with ID: ${contactId}, Status: ${response.data.data[0].code}`
    );
    return response.data.data[0];
  }

  logger.error(
    `Failed to create Zoho contact - Invalid response: ${JSON.stringify(
      response.data
    )}`
  );
  throw new Error('Failed to create contact');
});

// Update an existing contact in Zoho CRM
exports.updateContact = withZohoErrorHandling(async (payload, contactId) => {
  logger.info(
    `Updating Zoho contact ID: ${contactId} with data: ${JSON.stringify({
      firstName: payload?.firstName,
      lastName: payload?.lastName,
      email: payload?.email1,
    })}`
  );

  // Ensure custom fields exist before updating contact
  await ensureCustomFieldsExist(payload.auth_token);
  const zohoClient = createZohoClient(payload.auth_token);
  const properties = createPropertiesObject(payload);

  logger.info(
    `Zoho contact update properties prepared: ${Object.keys(properties).length} fields`
  );

  const requestBody = {
    data: [properties],
    trigger: ['approval', 'workflow', 'blueprint'],
  };

  const response = await zohoClient.put(`/Contacts/${contactId}`, requestBody);

  if (response.data && response.data.data && response.data.data.length > 0) {
    logger.info(
      `Zoho contact updated successfully - ID: ${contactId}, Status: ${response.data.data[0].code}`
    );
    return response.data.data[0];
  }

  logger.error(
    `Failed to update Zoho contact ${contactId} - Invalid response: ${JSON.stringify(
      response.data
    )}`
  );
  throw new Error('Failed to update contact');
});

// Update multiple contacts in batch
exports.updateContactsInBatch = withErrorHandling(async (payload) => {
  const zohoClient = createZohoClient(payload.auth_token);
  const contactsToUpdate = payload.contacts;

  const dataArray = contactsToUpdate.map((contactData) => ({
    id: contactData?.id,
    ...createPropertiesObject(contactData.payload),
  }));

  const requestBody = {
    data: dataArray,
    trigger: ['approval', 'workflow', 'blueprint'],
  };

  const response = await zohoClient.put('/Contacts', requestBody);

  return response.data;
});

// Delete (archive) a contact in Zoho CRM
exports.deleteContact = withErrorHandling(async (payload, contactId) => {
  const { auth_token, restore_flag } = payload;
  const zohoClient = createZohoClient(auth_token);

  if (restore_flag) {
    // Restore contact from recycle bin
    const response = await zohoClient.post('/Contacts/actions/restore', {
      ids: [contactId],
    });
    return response.data;
  }

  // Move to recycle bin (soft delete)
  const response = await zohoClient.delete(`/Contacts?ids=${contactId}`);

  if (response.data && response.data.data && response.data.data.length > 0) {
    return response.data.data[0];
  }

  return response.data;
});

// Get a contact by ID
exports.getContactById = withErrorHandling(async (payload, contactId) => {
  const zohoClient = createZohoClient(payload.auth_token);

  const response = await zohoClient.get(`/Contacts/${contactId}`);

  if (response.data && response.data.data && response.data.data.length > 0) {
    return response.data.data[0];
  }

  throw new Error('Contact not found');
});

// Get all contacts with pagination
exports.getContacts = withErrorHandling(async (payload) => {
  const zohoClient = createZohoClient(payload.auth_token);

  const limit = payload.limit || 200; // Zoho default max is 200
  const page = payload.page || 1;

  const params = {
    per_page: limit,
    page,
  };

  const response = await zohoClient.get('/Contacts', { params });

  return response.data;
});

// Get access token using refresh token
exports.getAccessToken = withErrorHandling(async (payload) => {
  const { client_id, client_secret, refresh_token } = payload;

  const params = new URLSearchParams();
  params.append('grant_type', 'refresh_token');
  params.append('client_id', client_id);
  params.append('client_secret', client_secret);
  params.append('refresh_token', refresh_token);

  const response = await axios.post(ZOHO_OAUTH_URL, params, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  });

  return response.data;
});

// Get access token using authorization code (Based on your API screenshot)
exports.getTokenFromCode = withErrorHandling(async (payload) => {
  const { client_id, client_secret, code, redirect_uri } = payload;

  const requestData = {
    grant_type: 'authorization_code',
    client_id,
    client_secret,
    redirect_uri,
    code,
  };

  const response = await axios.post(ZOHO_OAUTH_URL, requestData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  });

  return response.data;
});

// Exchange authorization code for tokens (API from your screenshot)
exports.exchangeCodeForTokens = withErrorHandling(async (payload) => {
  const { grant_type, client_id, client_secret, redirect_uri, code } = payload;

  const requestData = {
    grant_type: grant_type || 'authorization_code',
    client_id,
    client_secret,
    redirect_uri,
    code,
  };

  const response = await axios.post(ZOHO_OAUTH_URL, requestData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  });

  // Response should contain access_token, refresh_token, api_domain, token_type, expires_in, scope
  return response.data;
});

// Verify access token and refresh if expired
exports.verifyAndRefreshToken = withZohoErrorHandling(
  async (refreshToken, accessToken, clientId, clientSecret) => {
    logger.info(
      `Verifying Zoho access token for client: ${clientId?.substring(0, 10)}...`
    );

    try {
      // Try to verify the access token by making a simple API call
      const zohoClient = createZohoClient(accessToken);
      await zohoClient.get('/users?type=CurrentUser');

      // If the call succeeds, the access token is still valid
      logger.info(
        `Zoho access token is still valid for client: ${clientId?.substring(0, 10)}...`
      );
      return {
        accessToken,
        isRefreshed: false,
      };
    } catch (error) {
      // If the token is invalid or expired (401/403 error), refresh it

      if (
        error.response &&
        (error.response.status === 401 || error.response.status === 403)
      ) {
        logger.info(
          `Zoho access token expired (status ${error.response.status}), refreshing token for client: ${clientId?.substring(0, 10)}...`
        );

        const params = new URLSearchParams();
        params.append('grant_type', 'refresh_token');
        params.append('client_id', clientId);
        params.append('client_secret', clientSecret);
        params.append('refresh_token', refreshToken);

        const response = await axios.post(ZOHO_OAUTH_URL, params, {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        });

        logger.info(
          `Zoho access token successfully refreshed for client: ${clientId?.substring(0, 10)}... (expires in ${response.data.expires_in}s)`
        );

        // Return the new access token
        return {
          accessToken: response.data.access_token,
          isRefreshed: true,
          expiresIn: response.data.expires_in,
          apiDomain: response.data.api_domain,
        };
      }

      // If it's a different error, throw it
      logger.error(
        `Error verifying Zoho token (status ${error.response?.status}): ${error.message}`
      );
      throw error;
    }
  }
);
