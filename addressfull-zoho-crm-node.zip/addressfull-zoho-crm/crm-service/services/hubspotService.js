const hubspot = require('@hubspot/api-client');
const withErrorHandling = require('../middleware/serviceHandler');
const hubspotProperties = require('../config/constants/hubspotProperties');

const createProperty = withErrorHandling(
  async (hubspotClient, propertyName, propertyData) => {
    // Create the new property for contacts
    const updatedPropertyData = propertyData;
    updatedPropertyData.name = propertyName;
    const createdProperty = await hubspotClient.crm.properties.coreApi.create(
      'contacts',
      propertyData
    );
    return createdProperty;
  }
);

const getPropertyInfo = withErrorHandling(
  async (hubspotClient, propertyName) => {
    const allProperties =
      await hubspotClient.crm.properties.coreApi.getAll('contacts');
    return allProperties.results.find(
      (propertyData) => propertyData.name === propertyName
    );
  }
);

const createAllProperies = withErrorHandling(async (hubspotClient) => {
  const desiredProperties = hubspotProperties.PROPERTIES;

  await Promise.all(
    Object.keys(desiredProperties).map(async (propertyName) => {
      const propertyConfig = desiredProperties[propertyName];
      const propertyInfo = await getPropertyInfo(hubspotClient, propertyName);
      if (propertyInfo === undefined) {
        await createProperty(hubspotClient, propertyName, {
          ...propertyConfig,
        });
      }
    })
  );
});

exports.verifyConnection = withErrorHandling(async (payload) => {
  const { auth_token } = payload;
  try {
    const hubspotClient = new hubspot.Client({
      accessToken: auth_token,
      // numberOfApiCallRetries: 3,
    });
    // Get information using the provided token
    const response = await hubspotClient.crm.owners.ownersApi.getPage();
    // If successful, the token is valid
    if (response.results.length > 0) {
      await createAllProperies(hubspotClient);
      return true;
    }
    return false;
  } catch (error) {
    return false;
  }
});

exports.verifyCRMHealth = withErrorHandling(async () => {
  const hubspotClient = new hubspot.Client();
  return hubspotClient.crm.contacts.basicApi.getPage({ limit: 1 });
});

const hubspotClientFactory = (authToken) =>
  new hubspot.Client({ accessToken: authToken });

const createPropertiesObject = (payload, isUpdate = false) => {
  const properties = {
    firstname: payload?.firstName,
    lastname: payload?.lastName,
    addressfull_email_1: payload?.email1,
    addressfull_email_2: payload?.email2,
    addressfull_email_3: payload?.email3,
    addressfull_email_4: payload?.email4,
    addressfull_email_5: payload?.email5,
    addressfull_contact_number_1: payload?.contactNumber1,
    addressfull_contact_number_2: payload?.contactNumber2,
    addressfull_contact_number_3: payload?.contactNumber3,
    addressfull_contact_number_4: payload?.contactNumber4,
    addressfull_contact_number_5: payload?.contactNumber5,
    addressfull_address_1: payload?.address1,
    addressfull_address_2: payload?.address2,
    addressfull_address_3: payload?.address3,
    addressfull_address_4: payload?.address4,
    addressfull_address_5: payload?.address5,
    addressfull_linkedin_profile: payload?.linkedInLink,
    addressfull_twitter_profile: payload?.twitterLink,
  };

  if (isUpdate) {
    delete properties?.createdate;
  }

  return properties;
};

exports.createContact = withErrorHandling(async (payload) => {
  const hubspotClient = hubspotClientFactory(payload.auth_token);
  const properties = createPropertiesObject(payload);

  const SimplePublicObjectInputForCreate = { associations: [], properties };

  return hubspotClient.crm.contacts.basicApi.create(
    SimplePublicObjectInputForCreate
  );
});

exports.updateContact = withErrorHandling(async (payload, contactId) => {
  const hubspotClient = hubspotClientFactory(payload.auth_token);
  const properties = createPropertiesObject(payload, true);

  const SimplePublicObjectInput = { properties };

  return hubspotClient.crm.contacts.basicApi.update(
    contactId,
    SimplePublicObjectInput
  );
});

exports.updateContactsInBatch = withErrorHandling(async (payload) => {
  const hubspotClient = hubspotClientFactory(payload.auth_token);
  const contactsToUpdate = payload.contacts;

  const BatchInputSimplePublicObjectBatchInput = contactsToUpdate.map(
    (contactData) => {
      const propertiesObject = {
        id: contactData?.id,
        properties: createPropertiesObject(contactData.payload),
      };

      return propertiesObject;
    }
  );

  return hubspotClient.crm.contacts.batchApi.update({
    inputs: BatchInputSimplePublicObjectBatchInput,
  });
});

exports.deleteContact = withErrorHandling(async (payload, contactId) => {
  const { auth_token, restore_flag } = payload;
  const hubspotClient = new hubspot.Client({
    accessToken: auth_token,
  });
  if (restore_flag) {
    const contactData = await this.getContactById(
      {
        auth_token,
      },
      contactId
    );
    if (!contactData?.error && Object.keys(contactData?.properties).length) {
      // Create a new record and return the response
      return this.createContact({
        auth_token,
        properties: contactData?.properties,
      });
    }
    return false;
  }
  return hubspotClient.crm.contacts.basicApi.archive(contactId);
});

exports.getContactById = withErrorHandling(async (payload, contactId) => {
  const hubspotClient = new hubspot.Client({
    accessToken: payload.auth_token,
  });
  const properties = Object.keys(hubspotProperties.PROPERTIES);
  const propertiesWithHistory = null;
  const associations = null;
  const archived = true;

  return hubspotClient.crm.contacts.basicApi.getById(
    contactId,
    properties,
    propertiesWithHistory,
    associations,
    archived
  );
});

exports.getContacts = withErrorHandling(async (payload) => {
  const hubspotClient = new hubspot.Client({
    accessToken: payload.auth_token,
  });

  const limit = payload.limit || 10;
  const after = payload.after || undefined;
  const properties = Object.keys(hubspotProperties.PROPERTIES);
  const propertiesWithHistory = null;
  const associations = null;
  const archived = true;

  return hubspotClient.crm.contacts.basicApi.getPage(
    limit,
    after,
    properties,
    propertiesWithHistory,
    associations,
    archived
  );
});
