const asyncHandler = require('../middleware/asyncHandler');
const {
  createContact,
  updateContactsInBatch,
  getContactById,
  getContacts,
  updateContact,
  deleteContact,
  verifyConnection,
  verifyCRMHealth,
  getAccessToken,
  getTokenFromCode,
  exchangeCodeForTokens,
  verifyAndRefreshToken,
} = require('../services/zohoService');
const responseMessages = require('../config/constants/reponseMessages');

exports.verifyToken = asyncHandler(async (req, res) => {
  const isValidToken = await verifyConnection(req.body);
  return res.status(200).json({
    status: 200,
    data: isValidToken,
  });
});

exports.verifyCRMConnection = asyncHandler(async (_req, res) => {
  const isCRMUp = await verifyCRMHealth();
  return res.status(200).json({
    status: 200,
    data: isCRMUp,
  });
});

exports.createContact = asyncHandler(async (req, res) => {
  try {
    const newContact = await createContact(req.body);
    return res.status(200).json({
      status: 200,
      data: newContact,
    });
  } catch (error) {
    const statusCode = error.response?.status || 500;
    const errorMessage =
      error.response?.data?.message ||
      error.message ||
      'Failed to create contact';

    return res
      .status(statusCode >= 400 && statusCode < 600 ? statusCode : 500)
      .json({
        status: statusCode >= 400 && statusCode < 600 ? statusCode : 500,
        data: errorMessage,
        errorInfo: error.response?.data || null,
      });
  }
});

exports.getContactById = asyncHandler(async (req, res) => {
  const contact = await getContactById(req.body, req.params.id);
  if (!contact)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: contact,
  });
});

exports.getContacts = asyncHandler(async (req, res) => {
  const contacts = await getContacts(req.body);
  if (!contacts)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: contacts,
  });
});

exports.updateContact = asyncHandler(async (req, res) => {
  try {
    const updatedContact = await updateContact(req.body, req.params.id);
    return res.status(200).json({
      status: 200,
      data: updatedContact,
    });
  } catch (error) {
    const statusCode = error.response?.status || 500;
    const errorMessage =
      error.response?.data?.message ||
      error.message ||
      'Failed to update contact';

    return res
      .status(statusCode >= 400 && statusCode < 600 ? statusCode : 500)
      .json({
        status: statusCode >= 400 && statusCode < 600 ? statusCode : 500,
        data: errorMessage,
        errorInfo: error.response?.data || null,
      });
  }
});

exports.updateContactBatch = asyncHandler(async (req, res) => {
  const updatedContact = await updateContactsInBatch(req.body);
  if (!updatedContact)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: updatedContact,
  });
});

exports.deleteContact = asyncHandler(async (req, res) => {
  const deletedContact = await deleteContact(req.body, req.params.id);
  if (deletedContact?.error || deletedContact === false)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: deletedContact,
  });
});

// Get access token from refresh token
exports.getAccessToken = asyncHandler(async (req, res) => {
  const tokenData = await getAccessToken(req.body);
  if (tokenData?.error)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      errorInfo: tokenData?.errorInfo,
    });
  return res.status(200).json({
    status: 200,
    data: tokenData,
  });
});

// Get access token from authorization code
exports.getTokenFromCode = asyncHandler(async (req, res) => {
  const tokenData = await getTokenFromCode(req.body);
  if (tokenData?.error)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      errorInfo: tokenData?.errorInfo,
    });
  return res.status(200).json({
    status: 200,
    data: tokenData,
  });
});

// Exchange authorization code for tokens (based on your API screenshot)
exports.exchangeCodeForTokens = asyncHandler(async (req, res) => {
  const tokenData = await exchangeCodeForTokens(req.body);
  if (tokenData?.error)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      errorInfo: tokenData?.errorInfo,
    });
  return res.status(200).json({
    status: 200,
    data: tokenData,
  });
});

// Verify access token and refresh if expired
exports.verifyAndRefreshToken = asyncHandler(async (req, res) => {
  const { refresh_token, access_token, client_id, client_secret } = req.body;

  try {
    const tokenData = await verifyAndRefreshToken(
      refresh_token,
      access_token,
      client_id,
      client_secret
    );

    return res.status(200).json({
      status: 200,
      data: tokenData,
    });
  } catch (error) {
    // Handle specific error cases
    const statusCode = error.response?.status || 500;
    const errorMessage =
      error.response?.data?.message ||
      error.message ||
      'Failed to verify/refresh token';

    return res
      .status(statusCode >= 400 && statusCode < 600 ? statusCode : 500)
      .json({
        status: statusCode >= 400 && statusCode < 600 ? statusCode : 500,
        data: errorMessage,
        errorInfo: error.response?.data || null,
      });
  }
});
