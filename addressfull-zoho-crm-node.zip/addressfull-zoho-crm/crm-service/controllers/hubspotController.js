const asyncHandler = require('../middleware/asyncHandler');
const {
  createContact,
  updateContactsInBatch,
  getContactById,
  getContacts,
  updateContact,
  deleteContact,
  verifyConnection,
  verifyCRMHealth,
} = require('../services/hubspotService');
const responseMessages = require('../config/constants/reponseMessages');

exports.verifyToken = asyncHandler(async (req, res) => {
  const isValidToken = await verifyConnection(req.body);
  return res.status(200).json({
    status: 200,
    data: isValidToken,
  });
});

exports.verifyCRMConnection = asyncHandler(async (_req, res) => {
  const isCRMUp = await verifyCRMHealth();
  return res.status(200).json({
    status: 200,
    data: isCRMUp,
  });
});

exports.createContact = asyncHandler(async (req, res) => {
  const newContact = await createContact(req.body);
  if (newContact?.error)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      errorInfo: newContact?.errorInfo,
    });
  return res.status(200).json({
    status: 200,
    data: newContact,
  });
});

exports.getContactById = asyncHandler(async (req, res) => {
  const contact = await getContactById(req.body, req.params.id);
  if (!contact)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: contact,
  });
});

exports.getContacts = asyncHandler(async (req, res) => {
  const contacts = await getContacts(req.body);
  if (!contacts)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: contacts,
  });
});

exports.updateContact = asyncHandler(async (req, res) => {
  const updatedContact = await updateContact(req.body, req.params.id);
  if (updatedContact?.error)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      errorInfo: updatedContact?.errorInfo,
    });
  return res.status(200).json({
    status: 200,
    data: updatedContact,
  });
});

exports.updateContactBatch = asyncHandler(async (req, res) => {
  const updatedContact = await updateContactsInBatch(req.body);
  if (!updatedContact)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  return res.status(200).json({
    status: 200,
    data: updatedContact,
  });
});

exports.deleteContact = asyncHandler(async (req, res) => {
  const deletedContact = await deleteContact(req.body, req.params.id);
  if (deletedContact?.error || deletedContact === false)
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      message: deletedContact?.error,
      errorInfo: deletedContact?.errorInfo,
    });
  return res.status(200).json({
    status: 200,
    data: deletedContact,
  });
});
