const mongoose = require('mongoose'); // Erase if already required
const userTypes = require('../config/constants/notificationUserTypes');
const requestTypes = require('../config/constants/requestTypes');
const requestStatus = require('../config/constants/requestStatus');

// Declare the Schema of the Mongo model
const notificationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  userType: {
    type: String,
    enum: [...Object.values(userTypes), null],
    default: null,
  },
  requestType: {
    type: String,
    enum: [...Object.values(requestTypes), null],
    default: null,
  },
  requesterId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    default: null,
  },
  requestStatus: {
    type: String,
    enum: [...Object.values(requestStatus), null],
    default: null,
  },
  requestedLabels: {
    type: [String],
    default: undefined,
  },
  message: {
    type: String,
    required: true,
  },
  isRead: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Export the model
module.exports = mongoose.model('Notification', notificationSchema);
