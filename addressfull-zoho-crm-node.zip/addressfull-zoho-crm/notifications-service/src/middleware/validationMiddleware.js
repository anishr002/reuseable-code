const validateRequestData = (schema) => async (req, res, next) => {
  const dataToValidate = { ...req.body, ...req.query };

  const validationSchema = typeof schema === 'function' && (await schema(req));

  const { error } =
    typeof schema === 'function'
      ? validationSchema.validate(dataToValidate)
      : schema.validate(dataToValidate);
  if (error) {
    // Generate error message
    let errorMessage = '';
    if (Array.isArray(error.details)) {
      const errorparts = error.details[0].message.split(`"`);
      errorMessage = errorparts.join(``);
    } else {
      errorMessage = error.toString().replace('Error: ', '');
    }
    return res.status(400).json({
      status: 400,
      message: errorMessage,
    });
  }
  return next();
};

module.exports = validateRequestData;
