const asyncHandler = require('./asyncHandler');

// Common error handling function
const handleServiceError = (error) => ({
  error: error.message,
});

// Higher-order function to wrap the service functions
const withErrorHandling = (serviceFunction) =>
  asyncHandler(async (...args) => {
    try {
      return await serviceFunction(...args);
    } catch (error) {
      console.error(
        `Notification: Error cached by serviceHandler: ${error.message}`
      );
      return handleServiceError(error);
    }
  });

module.exports = withErrorHandling;
