const { isValidObjectId } = require('mongoose');

/**
 * Checks if the req.params.id is a valid Mongoose ObjectId.
 */
function checkObjectId(req, res, next) {
  if (!isValidObjectId(req.params.id)) {
    return res.status(400).json({
      status: 400,
      message: 'Invalid Object Id',
    });
  }
  return next();
}

module.exports = checkObjectId;
