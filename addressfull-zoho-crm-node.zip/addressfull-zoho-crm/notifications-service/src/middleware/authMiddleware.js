const asyncHandler = require('./asyncHandler');
const { decodeJWTSign } = require('../helpers/jwtHelper');
const responseMessages = require('../config/constants/responseMessages');
const { findUserById } = require('../services/userService');
const { decodeUser } = require('../services/commonService');

exports.protect = asyncHandler(async (req, res, next) => {
  // Check if notification_type is ORGANIZATION_REGISTRATION
  const skipTokenValidation =
    req.body.notification_type === 'ORGANIZATION_REGISTRATION';
  if (!skipTokenValidation) {
    const userDecoded = await decodeJWTSign(req);

    if (userDecoded.error) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.UNAUTHORIZED_ACCESS,
      });
    }

    const decodedUserData = await decodeUser(userDecoded);
    const user =
      decodedUserData?._id && (await findUserById(decodedUserData._id));
    if (!user) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.UNAUTHORIZED_ACCESS,
      });
    }
    req.user = user;
  }
  return next();
});
