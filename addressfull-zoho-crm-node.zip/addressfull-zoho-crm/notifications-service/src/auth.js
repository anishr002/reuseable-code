// Configure Auth here
const jwt = require('jsonwebtoken');

module.exports = async (token) => {
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.SECRET_KEY);
      return {
        success: true,
        decoded,
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
      };
    }
  }
  return {
    success: false,
    error: 'Unauthorized access',
  };
};
