const { error } = require('dotenv').config({
  path: require('path').resolve(__dirname, `../.env`),
});

if (error) {
  console.error(error);
  process.exit(-1);
}

if (process.env.LOGS === 'false') {
  console.log = function () {};
}

const http = require('http');
const swagger = require('swagger-ui-express');
const app = require('./app');
const socket = require('./socket');

const server = http.createServer(app);
const io = socket(server);
const swaggerDoc = require('./swagger');
const rootRouter = require('./router')(io);

app.use(rootRouter);

/* Swagger Doc */
app.use('/api-docs', swagger.serve, swagger.setup(swaggerDoc));

server.listen(parseInt(process.env.PORT, 10) || 3010, () => {
  console.info(
    `Your server is running on : ${process.env.PROTOCOL}://${process.env.HOST}:${process.env.PORT}`
  );
});
