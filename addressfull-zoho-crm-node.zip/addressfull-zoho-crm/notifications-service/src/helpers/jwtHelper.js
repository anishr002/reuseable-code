const jwt = require('jsonwebtoken');
const responseMessages = require('../config/constants/responseMessages');

exports.decodeJWTSign = async (req) => {
  let token;
  if (req?.token && req.token !== '') {
    token = req.token;
  }
  const authHeader =
    req.headers && (req.header('authorization') || req.header('token'));
  if (authHeader?.trim().startsWith('Bearer')) {
    token = authHeader.replace('Bearer', '').trim();
  }
  if (token) {
    try {
      return jwt.verify(token, process.env.SECRET_KEY);
    } catch (error) {
      console.log('Decode Error', error.message);
      return {
        message: error.message,
      };
    }
  }
  return {
    message: responseMessages.UNAUTHORIZED_ACCESS,
  };
};
