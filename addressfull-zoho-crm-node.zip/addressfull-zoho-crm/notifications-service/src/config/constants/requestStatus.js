const { deepFreezeObject } = require('../../utils/common');

module.exports = deepFreezeObject({
  ACCEPT: 'ACCEPT',
  REJECT: 'REJECT',
  SHARE: 'SHARE',
  UNSHARE: 'REVOKE',
  SENT: 'SENT',
  NONE: 'NONE',
});
