const { deepFreezeObject } = require("../../utils/common");

module.exports = deepFreezeObject({
  FRONT_END_USER: "front-end-user",
  ORGANIZATION_ADMIN: "organization-admin",
  SUPER_ADMIN: "super-admin",
  SUB_ADMIN: "sub-admin",
});
