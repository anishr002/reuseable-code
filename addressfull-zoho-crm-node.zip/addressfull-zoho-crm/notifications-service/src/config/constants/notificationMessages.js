const notesTypes = [
  [
    'NEW_ADMIN_CREATION',
    'Administrator {creator} has successfully created a new admin user, {newUser}, in the system',
  ],
  [
    'ORGANIZATION_REGISTRATION',
    'A new organisation, with email {organizationEmail}, has been successfully registered',
  ],
  [
    'ORGANIZATION_PROFILE_UPDATE',
    '{organizationName} has successfully updated its profile',
  ],
  [
    'ORGANIZATION_DOCUMENT_UPLOAD',
    '{organizationName} has successfully uploaded a document',
  ],
  [
    'ORGANIZATION_SETTING_UPDATE',
    '{organizationName} has successfully updated its setting',
  ],
  ['USER_SHARED_DATA', '{mobileNumber} has granted access to {labelName}'],
  ['USER_UNSHARED_DATA', '{mobileNumber} has removed access to {labelName}'],
  [
    'USER_APPROVE_REQUEST_TO_ORGANIZATION',
    '{mobileNumber} has approved your request',
  ],
  [
    'USER_REJECT_REQUEST_TO_ORGANIZATION',
    '{mobileNumber} has rejected your request',
  ],
  ['USER_CONNECT_TO_ORGANIZATION', '{userName} has connected with you'],
  [
    'USER_DELETE_DATA_REQUEST',
    '{mobileNumber} has requested that all data is removed',
  ],
  [
    'USER_BLOCK_TO_ORGANIZATION',
    '{mobileNumber} has blocked you. Please remove all this user’s data from your platform',
  ],
  [
    'USER_UNBLOCK_TO_ORGANIZATION',
    '{mobileNumber} has unblocked you. You can now send a request to the user for data sharing',
  ],
  [
    'USER_UNTRUSTED_TO_ORGANIZATION',
    'The user registered with the phone number {mobileNumber} has requested that all data is removed from your platform',
  ],
];

const getMessageByType = (type, args) => {
  const messageType = notesTypes.find((entry) => entry[0] === type);
  if (messageType) {
    let message = messageType[1];
    // Replace dynamic placeholders with actual values
    for (const key in args) {
      if (args.hasOwnProperty(key)) {
        const placeholder = `{${key}}`;
        message = message.replace(new RegExp(placeholder, 'g'), args[key]);
      }
    }
    return message;
  } else {
    return 'Message Type not found';
  }
};

module.exports = getMessageByType;
