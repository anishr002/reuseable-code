const { deepFreezeObject } = require("../../utils/common");

module.exports = deepFreezeObject({
  REQUEST: "REQUEST",
  CONSENT: "CONSENT",
});
