const { deepFreezeObject } = require("../../utils/common");

module.exports = deepFreezeObject({
  SUPER_USER: "SUPER-USER",
  OTHER_USER: "OTHER-USER",
});
