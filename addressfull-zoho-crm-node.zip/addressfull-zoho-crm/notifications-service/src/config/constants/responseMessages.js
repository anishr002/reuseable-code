const { deepFreezeObject } = require('../../utils/common');

module.exports = deepFreezeObject({
  SOMETHING_WENT_WRONG: 'Something is wrong',
  UNAUTHORIZED_ACCESS: 'Unauthorized access',
  ROUTE_NOT_FOUND: 'Route not found',
  INVALID_ID: 'Invalid or missing ID',
  NOTIFICATION_SUCCESS: 'Notification sent successfully',
  NOTIFICATION_NOT_FOUND: 'Notification not found or unable to read',
  NOTIFICATION_REQUEST_READ: 'Request read successfully',
  NOTIFICATION_READ_SUCCESS: 'All notifications read',
  NOTIFICATION_REMOVE_SUCCESS: 'Notification removed successfully',
  NOTIFICATION_READ_FAIL: 'Unable to read notification',
});
