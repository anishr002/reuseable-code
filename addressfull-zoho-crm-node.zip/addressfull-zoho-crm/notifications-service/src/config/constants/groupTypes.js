module.exports = ["SUPER-ADMIN", "ORGANIZATION-ADMIN"];
