const mongoose = require("mongoose");

const dbConnect = async () => {
  await mongoose
    .connect(process.env.MONGODB_URI)
    .then((conn) => {
      console.info(`Database is running on ${conn.connection.host}`);
    })
    .catch((err) => {
      console.error(`Error in connecting DB: ${err}`);
    });
};

module.exports = dbConnect;
