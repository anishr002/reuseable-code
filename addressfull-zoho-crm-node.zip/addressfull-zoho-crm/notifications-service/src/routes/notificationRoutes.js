const { Router } = require('express');
const { protect } = require('../middleware/authMiddleware');
const checkObjectId = require('../middleware/verifyObjectId');
const validateRequest = require('../middleware/validationMiddleware');
const {
  pushNotificationSchema,
  getNotificationSchema,
  pushFirebaseNotificationSchema,
  readNotificationSchema,
  readAllNotificationSchema,
  notifyUserSchema,
} = require('../validations/notificationSchema');
const {
  SendNotification,
  GetNotification,
  SendFirebaseNotification,
  ReadNotification,
  ReadAllNotification,
  getNotificationById,
  getNotificationCount,
  NotifyUser,
  getReqSentCount,
  removeNotification,
  processNotification,
} = require('../controllers/notificationController');

module.exports = function (io) {
  const router = Router({ mergeParams: true });

  router
    .route('/list')
    .get(protect, validateRequest(getNotificationSchema), (req, res) =>
      GetNotification(req, res)
    );

  router
    .route('/req-count')
    .post(protect, (req, res) => getReqSentCount(req, res));

  router
    .route('/remove-notification')
    .post(protect, (req, res) => removeNotification(req, res));

  router
    .route('/send')
    .post(protect, validateRequest(pushNotificationSchema), (req, res) =>
      SendNotification(req, res, io)
    );

  router
    .route('/send-request')
    .post(
      protect,
      validateRequest(pushFirebaseNotificationSchema),
      (req, res) => SendFirebaseNotification(req, res)
    );

  router
    .route('/notify-user')
    .post(validateRequest(notifyUserSchema), (req, res) =>
      NotifyUser(req, res)
    );

  router
    .route('/read')
    .post(protect, validateRequest(readNotificationSchema), (req, res) =>
      ReadNotification(req, res)
    );

  router
    .route('/read-all')
    .post(protect, validateRequest(readAllNotificationSchema), (req, res) =>
      ReadAllNotification(req, res)
    );

  router
    .route('/:id')
    .get(protect, checkObjectId, (req, res) => getNotificationById(req, res));

  router.route('/notification-count').post(protect, getNotificationCount);

  router
    .route('/process-notification')
    .post(protect, (req, res) => processNotification(req, res));

  return router;
};
