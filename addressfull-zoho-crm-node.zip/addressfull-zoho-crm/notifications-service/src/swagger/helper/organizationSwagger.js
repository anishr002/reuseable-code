const pkg = require('../../../package.json');

const getTrustedOrganizations = {
  tags: ['Organizations'],
  description: 'Listing of Top Trusted Organizations',
  summary: 'Listing of Top Trusted Organizations',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/search',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'id',
      in: 'query',
      description: 'Enter Organization Id',
      type: 'string',
    },
    {
      name: 'is_trusted',
      in: 'query',
      description:
        'Default value is true. Pass false if searching with all the orgabizations and pass nothing if searching with trusted organizations',
      type: 'boolean',
      example: true,
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                description: 'HTTP status code',
              },
              data: {
                type: 'array',
                description: 'Array of Objects',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const organizationRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/organizations/top-trusted`]: {
    get: getTrustedOrganizations,
  },
};

module.exports = organizationRoutes;
