// import all common express paths here
const organizationRoutes = require("./helper/organizationSwagger");

const swaggerDoc = {
  openapi: "3.0.0",
  host: "",
  info: {
    title: "Notification microservice",
    version: "0.0.1",
    description: "Swagger API Documentation for notification microservice",
  },
  servers: [
    {
      url: "http://localhost:3101",
      description: "local server",
    },
    // {
    //   url: 'http://172.16.2.200:3005',
    //   description: 'local ip',
    // },
  ],
  tags: [
    {
      name: "Organizations",
      description: "Organizations API Routes",
    },
  ],

  paths: {
    ...organizationRoutes,
  },

  components: {
    schemaProps: {
      RolePermissions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            module: {
              type: "string",
              description: "Module name",
            },
            permission: {
              type: "string",
              description: "Permission type",
            },
          },
        },
        description: "Permissions",
        example: [
          {
            module: "roles",
            permission: "read",
          },
          {
            module: "admins",
            permission: "read",
          },
        ],
      },
      FirstName: {
        type: "string",
        description: "First Name",
        example: "Grant",
      },
      LastName: {
        type: "string",
        description: "Last Name",
        example: "Morte",
      },
      Email: {
        type: "string",
        description: "Email",
        example: "jon.p@yopmail.com",
      },
      RecordStatus: {
        type: "boolean",
        description: "Record is active or not",
        example: false,
      },
      UniqueId: {
        type: "string",
        description: "Unique Id",
        example: "654371af939d72ca10b19867",
      },
      createdAtDate: {
        type: "string",
        description: "Created Date",
        example: "2023-11-02T09:53:51.650Z",
      },
      updatedAtDate: {
        type: "string",
        description: "Updated Date",
        example: "2023-11-03T08:05:13.267Z",
      },
    },
    responses: {
      CommonResponse: {
        type: "object",
        properties: {
          status: {
            type: "number",
            description: "Status Code",
          },
          message: {
            type: "string",
            description: "Success or Error Message",
          },
        },
      },
      paginationResponse: {
        type: "object",
        properties: {
          total_count: {
            type: "number",
            description: "Total number of records",
            example: 5,
          },
          total_pages: {
            type: "number",
            description: "Total number of pages",
            example: 3,
          },
          current_page: {
            type: "number",
            description: "Current page",
            example: 2,
          },
        },
      },
      settingsResponse: {
        type: "object",
        properties: {
          status: {
            type: "number",
            example: 200,
          },
          data: {
            type: "object",
            properties: {
              to_email: {
                type: "array",
                items: {
                  type: "string",
                  example: "test@gmail.com",
                },
              },
              organization_types: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: {
                      type: "string",
                      example: "education",
                    },
                    title: {
                      type: "string",
                      example: "Education",
                    },
                    status: {
                      type: "boolean",
                      example: true,
                    },
                  },
                },
              },
            },
          },
        },
      },
      emailTemplatesResponse: {
        type: "object",
        properties: {
          mail_type: {
            type: "string",
            description: "Type of the email template",
            example: "send-otp",
          },
          from_name: {
            type: "string",
            description: "From Name",
            example: "AddressFull",
          },
          from_email: {
            type: "string",
            description: "From Email",
            example: "addressfull@gmail.com",
          },
          subject: {
            type: "string",
            description: "Subject",
            example: "OTP Verification",
          },
          body: {
            type: "string",
            description: "Subject",
            example: "<html><head></head></html",
          },
        },
      },
    },
    parameters: {
      token: {
        name: "token",
        description:
          "An authorization header, Please add Bearer keyword before token",
        in: "header",
        type: "string",
        required: true,
        examples: {
          super_admin: {
            value:
              "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Impvbi5wQHlvcG1haWwuY29tIiwiaWF0IjoxNzAzMjI3OTk2LCJleHAiOjE3MDMzMTQzOTZ9.1kExE4i3qKCC_4musgri2l8MB9P4rd1Kn_MiDgNpDFY",
          },
          sub_admin: {
            value:
              "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZzFfc3RmMUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwMzY3MDE3MiwiZXhwIjoxNzAzNzU2NTcyfQ.Sz-E7n7_C3_-t_V0q7nkHYU7of05kJ4h_bsV8S0emaw",
          },
          organization_admin: {
            value:
              "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjFAeW9wbWFpbC5jb20iLCJpYXQiOjE3MDM3NTYwNTAsImV4cCI6MTcwMzg0MjQ1MH0.wHdlr_HpysqVnD7VBPZjgGPTQK9tlGh2FZpysJtbODQ",
          },
          android_user: {
            value:
              "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjY1IiwibW9iaWxlTnVtYmVyIjoiMTEyMjMzNDQ1NSIsImlhdCI6MTcwMzgzMTQxMSwiZXhwIjoxNzAzOTE3ODExfQ.T4ohY3yvmYX8iPdwkTF9BKjxXi-1Pyt8xYhVLzY9m_0",
          },
          ios_user: {
            value:
              "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjY2IiwibW9iaWxlTnVtYmVyIjoiMTEyMjMzNDQ1NTY2IiwiaWF0IjoxNzAzNDg3MDUyLCJleHAiOjE3MDM1NzM0NTJ9.tzfjbftAPNChqJq2TTgQ109olGZGK91mzd4529gufFE",
          },
        },
      },
      page: {
        name: "page",
        in: "query",
        description: "Enter the page number",
        type: "Number",
      },
      pageSize: {
        name: "page_size",
        in: "query",
        description: "Enter the page size",
        type: "Number",
      },
      search: {
        name: "search",
        in: "query",
        description: "Enter search string",
        type: "string",
      },
    },
  },
};

module.exports = swaggerDoc;
