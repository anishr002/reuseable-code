const { log, error } = console;

const validateConnection = require("./services/validateConnection");

module.exports = (server) => {
  const io = require("socket.io")(server, {
    cors: {
      origin: "*",
      methods: ["OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE"],
      allowedHeaders: "*",
    },
    pingTimeout: parseInt(process.env.PING_TIMEOUT, 10) || 5000,
    pingInterval: parseInt(process.env.PING_INTERVAL, 10) || 10000,
  });

  io.use(validateConnection);

  const onConnection = async (socket) => {
    try {
      log(`\n${socket.id}:: has joined.`);

      // Handle room joining
      socket.on("joinRoom", (roomId) => {
        socket.join(roomId);
      });

      // Handle incoming messages
      // socket.on("message", (roomId, message) => {
      //   io.to(roomId).emit("message", message);
      // });

      // socket.on("send_message", (data) => {
      //   socket.broadcast.emit("receive_message", data);
      // });

      // socket.on("DeleteAppointment", (payload) => {
      //   if (payload) {
      //     log(
      //       "\nSocket.io receive delete appointment request from connect!!",
      //       payload
      //     );
      //     io.emit(
      //       "DeleteStatusAppointment",
      //       "Appointment deleted from connect!!"
      //     );
      //   } else {
      //     error("\nDeleteAppointment: no payload available!");
      //   }
      // });

      socket.once("disconnect", async () => {
        log(`\n${socket.id}:: has disconnected.`);
        socket.disconnect(true);
      });
    } catch (err) {
      error("\n", err, { query: socket.handshake.query });
      socket.emit("error");
    }
  };
  io.on("connection", onConnection);

  return io;
};
