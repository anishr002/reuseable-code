// Recursive function to deeply freeze an object
exports.deepFreezeObject = (object) => {
  if (
    object === null ||
    typeof object !== "object" ||
    Object.isFrozen(object)
  ) {
    return object;
  }
  // Freeze the object
  Object.freeze(object);
  // Freeze all props recursively
  Object.keys(object).forEach((key) => this.deepFreezeObject(object[key]));
  return object;
};
