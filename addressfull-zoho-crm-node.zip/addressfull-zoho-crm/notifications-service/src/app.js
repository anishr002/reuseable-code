const express = require('express');
const cors = require('cors');
const dbConnect = require('./config/dbConnection');

const app = express();
app.disable('x-powered-by');

app.use(
  cors({
    origin: '*',
    methods: ['OPTIONS', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: '*',
  })
);
app.use(express.json());
dbConnect();

module.exports = app;
