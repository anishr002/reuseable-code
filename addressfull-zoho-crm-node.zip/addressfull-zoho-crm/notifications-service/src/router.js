const express = require("express");
const rootRouter = express.Router();
const notificationRouter = require("./routes/notificationRoutes");

module.exports = function (io) {
  rootRouter.use("/api/v1/notification", notificationRouter(io));
  return rootRouter;
};
