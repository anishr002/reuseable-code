module.exports = {
  type: 'service_account',
  project_id: 'addressfull-9e3ec',
  private_key_id: '48199a59c8fee818811acd2ba0bdef80ff03b973',
  private_key: process.env.FIREBASE_KEY,
  client_email:
    'firebase-adminsdk-tisvp@addressfull-9e3ec.iam.gserviceaccount.com',
  client_id: '117792102985685241127',
  auth_uri: 'https://accounts.google.com/o/oauth2/auth',
  token_uri: 'https://oauth2.googleapis.com/token',
  auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
  client_x509_cert_url:
    'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-tisvp%40addressfull-9e3ec.iam.gserviceaccount.com',
  universe_domain: 'googleapis.com',
};
