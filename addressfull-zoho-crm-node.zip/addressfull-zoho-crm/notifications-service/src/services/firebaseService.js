const admin = require('firebase-admin');
const serviceAccount = require('../firebase/serviceAccountKey');
const withErrorHandling = require('../middleware/serviceHandler');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

exports.pushFirebaseNotification = withErrorHandling(
  async (deviceToken, payload) => {
    const { title, body, extra_data: extraData } = payload;
    const message = {
      data: {
        body,
        title,
        content_available: 'true',
        extraData: JSON.stringify(extraData || {}),
      },
      apns: {
        payload: {
          aps: {
            alert: {
              title,
              body,
            },
            contentAvailable: true,
          },
        },
      },
      token: deviceToken,
    };
    console.log('notification message', message);
    return admin.messaging().send(message);
  }
);
