const { findUserByEmail, findUserByMobile } = require('./userService');

exports.decodeUser = async (decodedData) => {
  if (
    decodedData.email ||
    (decodedData.countryCode && decodedData.mobileNumber)
  ) {
    const decodedUser = decodedData.email
      ? await findUserByEmail(decodedData.email)
      : await findUserByMobile({
          countryCode: decodedData.countryCode,
          mobileNumber: decodedData.mobileNumber,
        });

    return decodedUser;
  }
  return null;
};

exports.throwError = (statusCode, message) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  throw error;
};
