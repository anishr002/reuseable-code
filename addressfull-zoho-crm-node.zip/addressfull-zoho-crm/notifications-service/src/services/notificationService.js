const moment = require('moment-timezone');
const mongoose = require('mongoose');
const Notification = require('../models/notificationModel');
const withErrorHandling = require('../middleware/serviceHandler');
const userRoles = require('../config/constants/userRoles');
const userTypes = require('../config/constants/notificationUserTypes');

exports.getAllNotification = withErrorHandling(
  async ({ where, selectString, skip, limit }) => {
    const whereCondition = where || {};
    // console.log("whereCondition", whereCondition)

    // Count total number of documents
    const totalCount = await Notification.countDocuments(whereCondition);
    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = Notification.find(whereCondition).select(selectString);

    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }

    query.sort({ createdAt: -1 });

    const notificationList = await query.exec();
    // console.log("notificationList", notificationList);

    return {
      notificationList: notificationList || [],
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.countReqSent = withErrorHandling(async (payload) => {
  const { where } = payload;
  const whereCondition = where || {};
  // Count total number of documents
  const totalCount = await Notification.countDocuments(whereCondition);
  return {
    totalCount,
  };
});

exports.removeRequest = withErrorHandling(async (userId, organizationId) => {
  const query = { userId };

  if (organizationId !== undefined) {
    query.organizationId = organizationId;
  }

  const result = await Notification.deleteMany(query);
  return result;
});

exports.saveNotification = withErrorHandling(async (payload) => {
  const {
    userId,
    userType,
    message,
    requestType = null,
    requesterId = null,
    organizationId = null,
    requestStatus = null,
  } = payload;

  const notification = new Notification({
    userId,
    userType,
    requestType,
    requesterId,
    organizationId,
    requestStatus,
    message,
  });
  return notification.save();
});

exports.saveRequest = withErrorHandling(async (payload) => {
  const {
    userId,
    userType,
    requestType,
    requesterId,
    organizationId,
    requestStatus,
    requestedLabels,
    message,
  } = payload;

  const notification = new Notification({
    userId,
    userType,
    requestType,
    requesterId,
    organizationId,
    requestStatus,
    requestedLabels,
    message,
  });
  return notification.save();
});

exports.calculateDateToFilterNotification = ({ reqPeriod }) => {
  let todayStart;
  let todayEnd;
  let createdAtObject;
  if (reqPeriod !== undefined) {
    if (reqPeriod === '0') {
      todayStart = moment().startOf('day').toDate();
      todayEnd = moment().endOf('day').toDate();
      createdAtObject = {
        $gte: todayStart,
        $lt: todayEnd,
      };
    } else if (reqPeriod === '1') {
      todayStart = moment().startOf('day').toDate();
      createdAtObject = {
        $lt: todayStart,
      };
    }
    return {
      createdAt: createdAtObject,
    };
  }
  return null;
};

exports.updateNotification = withErrorHandling(async (notificationId) => {
  if (notificationId) {
    const notification = await Notification.findById(notificationId);
    if (notification) {
      notification.isRead = true;
      return notification.save();
    }
  }
  return null;
});

exports.readAllNotification = withErrorHandling(
  async (userId, isSuperAdmin) => {
    try {
      const where = isSuperAdmin
        ? { userId: null, userType: userTypes.SUPER_USER }
        : { userId, userType: userTypes.OTHER_USER };

      const result = await Notification.updateMany(where, {
        $set: { isRead: true },
      });
      return result;
    } catch (error) {
      return null;
    }
  }
);

exports.findNotificationById = withErrorHandling(
  async (requestId, selectString) => {
    if (requestId) {
      return Notification.findById(requestId).select(selectString);
    }
    return null;
  }
);

// Helper function to build the match stage based on user data and payload
const buildMatchStage = (userData, payload) => {
  const { userType, organizationId, isAdminMember } = userData;
  const { requestType, requestStatus, orgId } = payload;

  const matchStage = {};

  if (userType === userRoles.ORGANIZATION_ADMIN || organizationId) {
    matchStage.organizationId = new mongoose.Types.ObjectId(orgId);
  } else if (userType === userRoles.SUPER_ADMIN || isAdminMember === true) {
    // No additional match criteria for SUPER_ADMIN or admin members
  }

  if (requestType) {
    matchStage.requestType = requestType;
  }

  if (requestStatus) {
    matchStage.requestStatus = Array.isArray(requestStatus)
      ? { $in: requestStatus }
      : requestStatus;
  }

  return matchStage;
};

// Helper function to build the lookup stages based on user type
const buildLookupStages = (isOrganization) => {
  if (isOrganization) {
    return [
      {
        $lookup: {
          from: 'users',
          localField: 'requesterId',
          foreignField: '_id',
          as: 'mobileUserData',
        },
      },
      { $unwind: '$mobileUserData' },
    ];
  } else {
    return [
      {
        $lookup: {
          from: 'organizations',
          localField: 'userId',
          foreignField: 'userId',
          as: 'organizationData',
        },
      },
      { $unwind: '$organizationData' },
      {
        $lookup: {
          from: 'users',
          localField: 'userId',
          foreignField: '_id',
          as: 'userData',
        },
      },
      { $unwind: '$userData' },
    ];
  }
};

// Helper function to build the group stage
const buildGroupStage = (groupByCol) => {
  return {
    $group: {
      _id: `$${groupByCol}`,
      userId: { $first: '$organizationData.userId' },
      organizationName: { $first: '$organizationData.name' },
      organizationLogo: { $first: '$userData.profileImage' },
      countryCode: { $first: '$mobileUserData.countryCode' },
      mobileNumber: { $first: '$mobileUserData.mobileNumber' },
      count: { $sum: 1 },
      isDeleted: {
        $first: {
          $cond: [
            { $eq: [{ $type: '$mobileUserData.isDeleted' }, 'missing'] },
            '$userData.isDeleted',
            '$mobileUserData.isDeleted',
          ],
        },
      },
    },
  };
};

exports.calculateNotificationCount = withErrorHandling(
  async (userData, payload) => {
    const { sortBy, orderBy, skip, limit, countType } = payload;
    const sortValue = orderBy === 'asc' ? 1 : -1;
    const sortFields = { [sortBy || 'count']: sortValue };

    if (countType === 'COUNT') {
      delete payload.countType;
      return Notification.countDocuments(payload);
    }

    const matchStage = buildMatchStage(userData, payload);
    let groupByCol;
    let isOrganization = false;

    if (
      userData.userType === userRoles.ORGANIZATION_ADMIN ||
      userData.organizationId
    ) {
      isOrganization = true;
      groupByCol = 'requesterId';
    } else if (
      userData.userType === userRoles.SUPER_ADMIN ||
      userData.isAdminMember
    ) {
      groupByCol = 'organizationId';
    }
    // Remove null values from the pipelineStages array
    const pipelineStages = [
      { $match: matchStage },
      ...buildLookupStages(isOrganization),
      groupByCol ? buildGroupStage(groupByCol) : null,
      { $match: { isDeleted: false } },
      { $sort: sortFields },
    ].filter(Boolean);

    // Calculate total count
    const totalCount = await Notification.aggregate(pipelineStages);
    const totalSumCount = totalCount.reduce((sum, item) => sum + item.count, 0);
    const totalPages = Math.ceil(totalCount.length / limit);

    // Add pagination stages
    const paginatedPipelineStages = [
      ...pipelineStages,
      { $skip: skip },
      { $limit: limit },
    ];

    // Get paginated data
    const data = await Notification.aggregate(paginatedPipelineStages);

    return {
      data,
      pageInfo: {
        totalCount: totalCount.length,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
      totalSumCount,
    };
  }
);

exports.processBulkRequest = withErrorHandling(async (notifications) => {
  try {
    await Promise.all(
      notifications.map(async (notification) => {
        const { _id, requestedLabels, message } = notification;

        if (requestedLabels.length === 0) {
          // Delete the notification document if requestedLabels is empty
          await Notification.deleteOne({ _id });
        } else {
          // Update the notification document based on _id
          await Notification.findOneAndUpdate(
            { _id },
            { $set: { requestedLabels, message } },
            { new: true }
          );
        }
      })
    );

    return true;
  } catch (error) {
    return false;
  }
});
