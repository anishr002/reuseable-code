module.exports = async (socket, next) => {
  const _token = socket?.handshake?.auth?.token;

  if (_token) {
    const res = await require('../auth')(_token);
    console.log('\n', JSON.stringify(res));
    if (res.success) {
      socket.decoded = res.decoded;
      next();
    } else {
      return next(new Error(res?.error?.name || res?.message || res?.error));
    }
  } else {
    console.log('\n***No token found!***');
    next(new Error('NoTokenFound'));
  }
};
