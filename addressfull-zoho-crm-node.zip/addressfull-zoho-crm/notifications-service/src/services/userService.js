const { isValidObjectId } = require('mongoose');
const User = require('../models/userModel');
const withErrorHandling = require('../middleware/serviceHandler');

exports.findUserById = withErrorHandling(async (userId, selectString) => {
  if (userId && isValidObjectId(userId)) {
    return User.findById(userId).select(selectString);
  }
  return null;
});

exports.findUserByEmail = withErrorHandling(async (email) => {
  if (email) {
    const user = await User.findOne({
      email,
    });
    return user;
  }
  return null;
});

exports.findUserByMobile = withErrorHandling(
  async ({ countryCode, mobileNumber }) => {
    if (countryCode && mobileNumber) {
      return User.findOne({
        countryCode,
        mobileNumber,
      });
    }
    return null;
  }
);
