const { pushFirebaseNotification } = require('../services/firebaseService');
const { findUserById } = require('../services/userService');
const {
  getAllNotification,
  saveNotification,
  saveRequest,
  calculateDateToFilterNotification,
  updateNotification,
  readAllNotification,
  findNotificationById,
  calculateNotificationCount,
  countReqSent,
  removeRequest,
  processBulkRequest,
} = require('../services/notificationService');
const getMessageByType = require('../config/constants/notificationMessages');
const responseMessages = require('../config/constants/responseMessages');
const asyncHandler = require('../middleware/asyncHandler');
const userTypes = require('../config/constants/notificationUserTypes');
const requestTypes = require('../config/constants/requestTypes');
const requestStatus = require('../config/constants/requestStatus');
const { throwError } = require('../services/commonService');

const replaceWords = {
  firstName: 'First name',
  lastName: 'Last name',
  MobileNumber: 'Mobile number',
  mobileNumber1: 'Mobile number 1',
  mobileNumber2: 'Mobile number 2',
  mobileNumber3: 'Mobile number 3',
  mobileNumber4: 'Mobile number 4',
  mobileNumber5: 'Mobile number 5',
  Email: 'Email',
  email1: 'Email 1',
  email2: 'Email 2',
  email3: 'Email 3',
  email4: 'Email 4',
  email5: 'Email 5',
  'email 1': 'Email 1',
  'email 2': 'Email 2',
  'email 3': 'Email 3',
  'email 4': 'Email 4',
  'email 5': 'Email 5',
  Address: 'Address',
  address1: 'Address 1',
  address2: 'Address 2',
  address3: 'Address 3',
  address4: 'Address 4',
  address5: 'Address 5',
  'address 1': 'Address 1',
  'address 2': 'Address 2',
  'address 3': 'Address 3',
  'address 4': 'Address 4',
  'address 5': 'Address 5',
  linkedin: 'LinkedIn',
  twitter: 'Twitter',
};

exports.SendNotification = asyncHandler(async (req, res, io) => {
  try {
    const {
      notification_to: NotificationTo,
      notification_type: NotificationType,
      organization_id: OrganizationId,
      organization_name: OrganizationName,
      organization_email: OrganizationEmail,
      creator_name: CreatorName,
      recipient_name: RecipientName,
      user_name: UserName,
      label_name: LabelName,
      sender_id: senderId,
      organization_parent_id: organizationParentId,
    } = req.body;

    let mobileNumber = 'User';
    if (senderId) {
      const user = await findUserById(senderId);
      mobileNumber = user?.mobileNumber || '';
    }

    const roomId = NotificationTo === 'ORGANIZATION-ADMIN' ? OrganizationId : 1;
    const dynamicValuesMap = new Map([
      [
        'SUPER-ADMIN',
        {
          NEW_ADMIN_CREATION: {
            creator: CreatorName,
            newUser: RecipientName,
          },
          ORGANIZATION_REGISTRATION: { organizationEmail: OrganizationEmail },
          ORGANIZATION_PROFILE_UPDATE: { organizationName: OrganizationName },
          ORGANIZATION_DOCUMENT_UPLOAD: {
            organizationName: OrganizationName,
          },
          ORGANIZATION_SETTING_UPDATE: { organizationName: OrganizationName },
        },
      ],
      [
        'ORGANIZATION-ADMIN',
        {
          USER_SHARED_DATA: { labelName: LabelName, mobileNumber },
          USER_UNSHARED_DATA: { labelName: LabelName, mobileNumber },
          USER_APPROVE_REQUEST_TO_ORGANIZATION: {
            userName: UserName,
            mobileNumber,
          },
          USER_REJECT_REQUEST_TO_ORGANIZATION: {
            userName: UserName,
            mobileNumber,
          },
          USER_CONNECT_TO_ORGANIZATION: { userName: UserName },
          USER_DELETE_DATA_REQUEST: { mobileNumber },
          USER_BLOCK_TO_ORGANIZATION: { mobileNumber },
          USER_UNBLOCK_TO_ORGANIZATION: { mobileNumber },
          USER_UNTRUSTED_TO_ORGANIZATION: { mobileNumber },
        },
      ],
    ]);

    const userId = OrganizationId !== undefined ? OrganizationId : null;
    const userType =
      NotificationTo === 'SUPER-ADMIN'
        ? userTypes.SUPER_USER
        : userTypes.OTHER_USER;

    const dynamicValues =
      dynamicValuesMap.get(NotificationTo)?.[NotificationType] || {};
    const message = getMessageByType(NotificationType, dynamicValues);

    const payload = {
      userId,
      userType,
      message,
      requestType: null,
      requesterId: null,
      organizationId: null,
      requestStatus: null,
    };

    // eslint-disable-next-line default-case
    switch (NotificationType) {
      case 'USER_SHARED_DATA':
      case 'USER_UNSHARED_DATA':
      case 'USER_APPROVE_REQUEST_TO_ORGANIZATION':
      case 'USER_REJECT_REQUEST_TO_ORGANIZATION':
        payload.requestType = requestTypes.CONSENT;
        payload.requesterId = senderId;
        payload.organizationId = organizationParentId;
        break;
      default:
    }

    // eslint-disable-next-line default-case
    switch (NotificationType) {
      case 'USER_SHARED_DATA':
        payload.requestStatus = requestStatus.SHARE;
        break;
      case 'USER_UNSHARED_DATA':
        payload.requestStatus = requestStatus.UNSHARE;
        break;
      case 'USER_APPROVE_REQUEST_TO_ORGANIZATION':
        payload.requestStatus = requestStatus.ACCEPT;
        break;
      case 'USER_REJECT_REQUEST_TO_ORGANIZATION':
        payload.requestStatus = requestStatus.REJECT;
        break;
      default:
    }

    const createdNotification = await saveNotification(payload);
    if (!createdNotification?.error) {
      const page = 1;
      const limit = 5;
      const skip = (page - 1) * limit;
      const { notificationList, pageInfo } = await getAllNotification({
        where: {
          userType,
          userId,
          isRead: false,
        },
        selectString: '-__v',
        skip,
        limit,
      });

      // Loop through notificationList and replace words in each message
      notificationList.forEach((notification) => {
        let notificationMsg = notification.message;
        // eslint-disable-next-line no-restricted-syntax, guard-for-in
        for (const word in replaceWords) {
          const regex = new RegExp(word, 'g');
          notificationMsg = notificationMsg.replace(regex, replaceWords[word]);
        }
        // eslint-disable-next-line no-param-reassign
        notification.message = notificationMsg;
      });

      io.to(roomId).emit('NotificationAlert', {
        message,
        data: {
          notification_list: notificationList,
          page_info: {
            total_count: pageInfo.totalCount,
            total_pages: pageInfo.totalPages,
            current_page: pageInfo.currentPage,
          },
        },
      });

      return res.status(200).json({
        status: 200,
        message: responseMessages.NOTIFICATION_SUCCESS,
        notification: message,
      });
    }
    throwError(400, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.SendFirebaseNotification = asyncHandler(async (req, res) => {
  try {
    const {
      requester_id: requesterId,
      organization_id: organizationId,
      organization_name: organizationName,
      receiver_id: receiverId,
      request_details: requesterDetails,
      extra_data,
    } = req.body;

    // const requestData = requesterDetails.join(', ');
    // const message = `${organizationName} wants to access your ${requestData}`;
    const requestData = requesterDetails
      .map((label) =>
        label.toLowerCase() === 'mobilenumber'
          ? 'mobile number'
          : label.toLowerCase()
      )
      .join(', ');

    const message = `${organizationName} wants to access your ${requestData}`;

    const createdRequest = await saveRequest({
      userId: receiverId,
      userType: 'OTHER-USER',
      requestType: 'REQUEST',
      requesterId,
      organizationId,
      requestStatus: 'SENT',
      requestedLabels: requesterDetails,
      message,
    });

    if (createdRequest?.error) {
      throwError(400, responseMessages.SOMETHING_WENT_WRONG);
    }

    // Push Firebase Notification
    const user = await findUserById(receiverId);
    if (user) {
      const deviceToken = user?.deviceToken || null;
      try {
        await pushFirebaseNotification(deviceToken, {
          title: 'Received request for data',
          body: message,
          extra_data,
        });
      } catch (error) {
        console.error('Error to send firebase notification:', error);
      }
    }

    // Send success without notification dependency
    return res.status(200).json({
      status: 200,
      message: responseMessages.NOTIFICATION_SUCCESS,
      notification: message,
    });
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.GetNotification = asyncHandler(async (req, res) => {
  try {
    const {
      req_type: reqType,
      req_status: reqStatus,
      req_period: reqPeriod,
      is_read: isRead,
      organization_id: organizationId,
    } = req.query;

    const userType =
      req.user?.userType === 'super-admin'
        ? userTypes.SUPER_USER
        : userTypes.OTHER_USER;

    const userId =
      userType === userTypes.SUPER_USER
        ? null
        : req.user?.organizationId || req.user?._id;

    const page = req.query.page ? parseInt(req.query.page, 10) : 1;
    const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
    const skip = (page - 1) * limit;
    const createdDateObject = calculateDateToFilterNotification({ reqPeriod });

    const whereClause = {
      userId,
      userType,
      ...(isRead === '0' ? { isRead: false } : null),
      ...(isRead === '1' ? { isRead: true } : null),
      ...(reqType ? { requestType: reqType } : null),
      ...(reqStatus ? { requestStatus: reqStatus } : null),
      ...(createdDateObject
        ? { createdAt: createdDateObject.createdAt }
        : null),
    };

    if (organizationId !== undefined) {
      whereClause.organizationId = organizationId;
    }

    const { notificationList, pageInfo } = await getAllNotification({
      where: whereClause,
      selectString: '-__v',
      skip,
      limit,
    });

    return res.status(200).json({
      status: 200,
      data: {
        notification_list: notificationList,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  } catch (error) {
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.getReqSentCount = asyncHandler(async (req, res) => {
  const { userId, organizationId = null } = req.body;

  const whereClause = {
    requestType: requestTypes.REQUEST,
    requestStatus: requestStatus.SENT,
    userId,
  };

  if (organizationId !== null) {
    whereClause.requesterId = organizationId;
  }

  const reqSentCount = await countReqSent({ where: whereClause });

  if (!reqSentCount?.error) {
    return res.status(200).json({
      status: 200,
      data: {
        reqCount: reqSentCount,
      },
    });
  }
});

exports.removeNotification = asyncHandler(async (req, res) => {
  try {
    const { userId, organizationId } = req.body;
    const deleteStatus = await removeRequest(userId, organizationId);

    if (deleteStatus) {
      return res.status(200).json({
        status: 200,
        isDeleted: true,
      });
    }
  } catch (error) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.processNotification = asyncHandler(async (req, res) => {
  try {
    const { notificationRequests } = req.body;
    const notificationProcessStatus =
      await processBulkRequest(notificationRequests);

    if (notificationProcessStatus) {
      return res.status(200).json({
        status: 200,
        isUpdated: true,
      });
    }
  } catch (error) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.ReadNotification = asyncHandler(async (req, res) => {
  try {
    const { request_id: requestId } = req.body;

    const readNotification = await updateNotification(requestId);
    if (readNotification) {
      return res.status(200).json({
        status: 200,
        message: responseMessages.NOTIFICATION_REQUEST_READ,
      });
    }
    throwError(400, responseMessages.NOTIFICATION_NOT_FOUND);
  } catch (error) {
    return res.status(error.statusCode || 500).json({
      status: error.statusCode || 500,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.ReadAllNotification = asyncHandler(async (req, res) => {
  try {
    const { client_id: userId } = req.body;

    const user = await findUserById(userId, 'userType');
    if (!user || user?.isDeleted) {
      throwError(404, responseMessages.USER_NOT_FOUND);
    }

    const isSuperAdmin = user.userType === 'super-admin';
    const readStatus = await readAllNotification(userId, isSuperAdmin);

    if (readStatus) {
      return res.status(200).json({
        status: 200,
        message: responseMessages.NOTIFICATION_READ_SUCCESS,
      });
    }

    throwError(400, responseMessages.NOTIFICATION_READ_FAIL);
  } catch (error) {
    return res.status(error.statusCode || 500).json({
      status: error.statusCode || 500,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.getNotificationById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const notification = await findNotificationById(id);
  if (notification && !notification.error) {
    return res.status(200).json({
      status: 200,
      data: notification,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getNotificationCount = asyncHandler(async (req, res) => {
  const payload = req.body;
  const notificationData = await calculateNotificationCount(req.user, payload);
  return res.json({
    status: 200,
    data: notificationData,
  });
});

exports.NotifyUser = asyncHandler(async (req, res) => {
  const { title, body, silent, client_id, extra_data } = req.body;

  const mobileUser = await findUserById(client_id);
  if (!mobileUser || mobileUser?.isDeleted) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.USER_NOT_FOUND,
    });
  }

  const deviceToken = mobileUser?.deviceToken || null;
  try {
    await pushFirebaseNotification(
      deviceToken,
      { title, body, extra_data },
      silent
    );
    return res.status(200).json({
      status: 200,
      data: responseMessages.NOTIFICATION_SUCCESS,
    });
  } catch (error) {
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
      error: {
        message: error.message,
        stack: error.stack,
        errorInfo: error.errorInfo,
      },
    });
  }
});
