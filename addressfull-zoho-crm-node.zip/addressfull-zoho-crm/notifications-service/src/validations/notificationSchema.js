const Joi = require('joi');
const GroupTypes = require('../config/constants/groupTypes');
const {
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  sortByQueryParam,
  requestTypeSchema,
  requestStatusSchema,
  requestPeriodSchema,
  isReadSchema,
  ObjectIdSchema,
  timezoneSchema,
} = require('./commonSchema');

exports.pushNotificationSchema = Joi.object({
  notification_to: Joi.string()
    .valid(...GroupTypes)
    .required(),
  notification_type: Joi.when('notification_to', {
    is: 'SUPER-ADMIN',
    then: Joi.string()
      .valid(
        'NEW_ADMIN_CREATION',
        'ORGANIZATION_REGISTRATION',
        'ORGANIZATION_PROFILE_UPDATE',
        'ORGANIZATION_DOCUMENT_UPLOAD',
        'ORGANIZATION_SETTING_UPDATE'
      )
      .required(),
    otherwise: Joi.string()
      .valid(
        'USER_APPROVE_REQUEST_TO_ORGANIZATION',
        'USER_REJECT_REQUEST_TO_ORGANIZATION',
        'USER_CONNECT_TO_ORGANIZATION',
        'USER_SHARED_DATA',
        'USER_UNSHARED_DATA',
        'USER_DELETE_DATA_REQUEST',
        'USER_BLOCK_TO_ORGANIZATION',
        'USER_UNBLOCK_TO_ORGANIZATION',
        'USER_UNTRUSTED_TO_ORGANIZATION'
      )
      .required(),
  }),
  organization_name: Joi.when('notification_type', {
    is: Joi.string().valid(
      'ORGANIZATION_PROFILE_UPDATE',
      'ORGANIZATION_DOCUMENT_UPLOAD',
      'ORGANIZATION_SETTING_UPDATE'
    ),
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  organization_email: Joi.when('notification_type', {
    is: Joi.string().valid('ORGANIZATION_REGISTRATION'),
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  creator_name: Joi.when('notification_type', {
    is: 'NEW_ADMIN_CREATION',
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  recipient_name: Joi.when('notification_type', {
    is: 'NEW_ADMIN_CREATION',
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  organization_id: Joi.when('notification_to', {
    is: 'ORGANIZATION-ADMIN',
    then: Joi.string()
      .required()
      .regex(/^[0-9a-fA-F]{24}$/), // Assuming it should be a valid mongoose ObjectId
    otherwise: Joi.string().forbidden(),
  }),
  user_name: Joi.when('notification_type', {
    is: Joi.string().valid(
      'USER_APPROVE_REQUEST_TO_ORGANIZATION',
      'USER_REJECT_REQUEST_TO_ORGANIZATION',
      'USER_CONNECT_TO_ORGANIZATION'
    ),
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  label_name: Joi.when('notification_type', {
    is: Joi.string().valid('USER_SHARED_DATA', 'USER_UNSHARED_DATA'),
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  sender_id: Joi.when('notification_type', {
    is: Joi.string().valid(
      'USER_SHARED_DATA',
      'USER_UNSHARED_DATA',
      'USER_APPROVE_REQUEST_TO_ORGANIZATION',
      'USER_REJECT_REQUEST_TO_ORGANIZATION',
      'USER_DELETE_DATA_REQUEST',
      'USER_BLOCK_TO_ORGANIZATION',
      'USER_UNBLOCK_TO_ORGANIZATION',
      'USER_UNTRUSTED_TO_ORGANIZATION'
    ),
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
  organization_parent_id: Joi.when('notification_type', {
    is: Joi.string().valid(
      'USER_SHARED_DATA',
      'USER_UNSHARED_DATA',
      'USER_APPROVE_REQUEST_TO_ORGANIZATION',
      'USER_REJECT_REQUEST_TO_ORGANIZATION',
      'USER_DELETE_DATA_REQUEST',
      'USER_BLOCK_TO_ORGANIZATION',
      'USER_UNBLOCK_TO_ORGANIZATION',
      'USER_UNTRUSTED_TO_ORGANIZATION'
    ),
    then: Joi.string().required(),
    otherwise: Joi.string().forbidden(),
  }),
});

exports.pushFirebaseNotificationSchema = Joi.object({
  requester_id: Joi.required(),
  receiver_id: Joi.required(),
  organization_id: Joi.required(),
  organization_name: Joi.string().required(),
  request_details: Joi.array()
    .items(
      Joi.string().valid(
        'FirstName',
        'LastName',
        'Address',
        'MobileNumber',
        'Email',
        'Twitter',
        'LinkedIn'
      )
    )
    .required(),
  extra_data: Joi.object({
    status: Joi.boolean().required(),
    type: Joi.number().required(),
  }).optional(),
});

exports.getNotificationSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  sort_by: sortByQueryParam(['created_at']),
  req_type: requestTypeSchema,
  req_status: requestStatusSchema,
  req_period: requestPeriodSchema,
  is_read: isReadSchema,
  organization_id: Joi.string().regex(/^[0-9a-fA-F]{24}$/),
  timezone: timezoneSchema,
});

exports.readNotificationSchema = Joi.object({
  request_id: Joi.required(),
});

exports.notifyUserSchema = Joi.object({
  client_id: ObjectIdSchema.required(),
  silent: Joi.string().valid('true', 'false').required(),
  title: Joi.string().required(),
  body: Joi.string().required(),
  extra_data: Joi.object({
    status: Joi.boolean().required(),
    type: Joi.number().required(),
    message: Joi.string(),
  }).optional(),
});

exports.readAllNotificationSchema = Joi.object({
  client_id: ObjectIdSchema.required(),
});
