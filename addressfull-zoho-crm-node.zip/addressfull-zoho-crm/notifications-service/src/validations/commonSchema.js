const Joi = require('joi');
const { isValidObjectId } = require('mongoose');
const requestTypes = require('../config/constants/requestTypes');
const requestStatus = require('../config/constants/requestStatus');

/**
 * Request Body Parameter Schemas
 */

// Defined a custom validation function for Object IDs
const objectIdValidator = (value, helpers) => {
  if (value === '') {
    return null;
  }
  if (isValidObjectId(value)) {
    return value;
  }
  // If it's not a valid Object ID, return an error message
  return helpers.error('any.invalidObjectId');
};

// Extend Joi to add objectId validation type
const objectIdJoi = Joi.extend((joi) => ({
  type: 'objectId',
  base: joi.string().trim(),
  rules: {
    validObjectId: {
      validate(value, helpers) {
        return objectIdValidator(value, helpers);
      },
    },
  },
}));

exports.ObjectIdSchema = objectIdJoi.objectId().validObjectId();

// Custom validation function for timezone
const validateTimezone = (value, helpers) => {
  // Regular expression to match valid timezone strings
  const timezoneRegex =
    /^(?:(?:\(UTC(?:\+|\-)(?:[0-9]|1[0-3])\))|(?:[A-Za-z_\-\/]+(?:\/[A-Za-z_\-\/]+)?))$/;

  if (!timezoneRegex.test(value)) {
    return helpers.error('any.invalid');
  }
  return value;
};

exports.timezoneSchema = Joi.string()
  .custom(validateTimezone, 'Timezone Validation')
  .optional();

/**
 * Request Query Parameter Schemas
 */
exports.pageNumberQuerySchema = Joi.number()
  .integer()
  .min(1)
  .label('Page Number');

exports.pageSizeQuerySchema = Joi.number()
  .integer()
  .min(1)
  .max(100)
  .label('Page Size');

exports.sortByQueryParam = (validFields) =>
  Joi.string()
    .trim()
    .valid(...validFields)
    .allow()
    .label('Sort By Field');

exports.orderByQueryParam = Joi.string()
  .trim()
  .valid('asc', 'desc')
  .allow('')
  .label('Order By Field');

exports.requestTypeSchema = Joi.string()
  .trim()
  .valid(...Object.values(requestTypes));

exports.requestStatusSchema = Joi.string()
  .trim()
  .valid(...Object.values(requestStatus));

exports.requestPeriodSchema = Joi.string().trim().valid('0', '1');

exports.isReadSchema = Joi.string().trim().valid('0', '1');
// 0 - Non-Read
// 1 - Read
