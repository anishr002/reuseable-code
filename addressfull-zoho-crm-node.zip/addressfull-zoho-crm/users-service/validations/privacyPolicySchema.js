const Joi = require('joi');
const {
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  sortByQueryParam,
  orderByQueryParam,
  policyTitleSchema,
  policySubRulesSchema,
  updatePolicySubRulesSchema,
} = require('./commonSchema');

exports.policySchema = Joi.object({
  id: Joi.string(),
  title: policyTitleSchema.required(),
  isActive: Joi.boolean().default(false).required(),
  subRules: Joi.array().items(policySubRulesSchema).required(),
});

exports.getPolicySchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  sort_by: sortByQueryParam(['title', 'active', 'created_at', 'updated_at']),
  order_by: orderByQueryParam,
  active: Joi.string().alphanum().trim(),
});

exports.updatePolicySchema = Joi.object({
  id: Joi.string(),
  title: policyTitleSchema.required(),
  isActive: Joi.boolean().default(false).required(),
  subRules: Joi.array().items(updatePolicySubRulesSchema).required(),
});
