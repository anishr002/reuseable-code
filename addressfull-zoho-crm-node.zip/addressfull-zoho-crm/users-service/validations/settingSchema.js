const Joi = require('joi');
const {
  emailAddressesSchema,
  emailSchema,
  smsService,
  timezoneSchema,
  cronSchema,
  timeExpirationSchema,
  activityFilters,
} = require('./commonSchema');
const mailOptions = require('../config/constants/mailOptions');
const crmTypes = require('../config/constants/crmTypes');

exports.settingsSchema = Joi.object({
  to_email: emailAddressesSchema.label('Email'),
  sms_service: smsService,
  timezone: timezoneSchema,
  cron_execution_time: cronSchema,
  token_expiration_time: timeExpirationSchema,
  activity_filters: activityFilters,
});

exports.getEmailTemplateSchema = Joi.object({
  type: Joi.string()
    .valid(...Object.values(mailOptions.MAIL_TYPES))
    .label('Email Type'),
});

exports.updateEmailTemplateSchema = Joi.object({
  type: Joi.string().valid(...Object.values(mailOptions.MAIL_TYPES)),
  // from_name: Joi.string().trim().required().label('From Name'),
  // from_email: emailSchema.required().label('From Email'),
  // to_email: Joi.array().items(emailSchema).min(1).label('To Email'),
  subject: Joi.string().trim().required().label('Subject'),
  body: Joi.string().trim().required().label('Body'),
});

exports.updateCRMSettingSchema = Joi.object({
  type: Joi.string()
    .valid(...Object.values(crmTypes))
    .required(),

  authToken: Joi.string().trim().when('type', {
    is: crmTypes.HUBSPOT,
    then: Joi.required(),
    otherwise: Joi.forbidden(), // not allowed for zoho
  }),

  // Zoho-specific fields
  zohoClientId: Joi.string().trim().when('type', {
    is: crmTypes.ZOHO,
    then: Joi.required(),
    otherwise: Joi.forbidden(),
  }),

  zohoSecretKey: Joi.string().trim().when('type', {
    is: crmTypes.ZOHO,
    then: Joi.required(),
    otherwise: Joi.forbidden(),
  }),

  authCode: Joi.string().trim().when('type', {
    is: crmTypes.ZOHO,
    then: Joi.required(),
    otherwise: Joi.forbidden(),
  }),
});

