const Joi = require('joi');
const userRoles = require('../config/constants/userRoles');
const {
  emailSchema,
  passwordSchema,
  otpSchema,
  countryCodeSchema,
  mobileNumberSchema,
  // profilePictureSchema,
  profileImageSchema,
  smsTokenSchema,
  firstNameSchema,
  lastNameSchema,
  roleTypeSchema,
  registeredNumberSchema,
  dateOfIncorporationSchema,
  organizationNameSchema,
  organizationTypeSchema,
  organizationAddressSchema,
  organizationDescriptionSchema,
  organizationWebsiteSchema,
  organizationLegalStatusSchema,
  orgEmailAddressesSchema,
  contactNumbersSchema,
  tokenSchema,
  yearSchema,
  linkedInURLSchema,
  twitterURLSchema,
  sharedDataSchema,
  policyIdSchema,
  policySubRuleIdSchema,
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  searchSchema,
} = require('./commonSchema');

exports.userSignupSchema = Joi.object({
  email: emailSchema,
  country_code: countryCodeSchema,
  mobile_number: mobileNumberSchema,
  device_id: Joi.string()
    .trim()
    .when('mobile_number', {
      then: Joi.required(),
      otherwise: Joi.allow(''),
    }),
  device_token: Joi.string()
    .trim()
    .when('mobile_number', {
      then: Joi.required(),
      otherwise: Joi.allow(''),
    }),
  sms_token: smsTokenSchema.allow(''),
})
  .xor('email', 'mobile_number')
  .messages({
    'object.xor': 'Either Email or Mobile Number is allowed',
    'object.missing': 'Email or Mobile Number is required',
  });

exports.userLoginSchema = Joi.object({
  email: emailSchema,
  country_code: countryCodeSchema,
  mobile_number: mobileNumberSchema,
  password: Joi.string()
    .trim()
    .when('email', {
      then: Joi.required(),
      otherwise: Joi.allow(''),
    }),
  role_type: roleTypeSchema.when('email', {
    then: Joi.required(),
    otherwise: Joi.allow(''),
  }),
  device_id: Joi.string()
    .trim()
    .when('mobile_number', {
      then: Joi.required(),
      otherwise: Joi.allow(''),
    }),
  device_token: Joi.string()
    .trim()
    .when('mobile_number', {
      then: Joi.required(),
      otherwise: Joi.allow(''),
    }),
  sms_token: smsTokenSchema.allow(''),
})
  .xor('email', 'mobile_number')
  .messages({
    'object.xor': 'Either Email or Mobile Number is allowed',
    'object.missing': 'Email or Mobile Number is required',
  });

exports.forgotPasswordSchema = Joi.object({
  email: emailSchema.required(),
  role_type: roleTypeSchema.when('email', {
    then: Joi.required(),
    otherwise: Joi.allow(''),
  }),
});

exports.resetPasswordSchema = Joi.object({
  token: tokenSchema,
  email: emailSchema,
  password: passwordSchema.required(),
  confirm_password: Joi.string()
    .valid(Joi.ref('password'))
    .required()
    .messages({
      'any.only': 'Password and Confirm Password must match.',
    })
    .label('Confirm Password'),
});

exports.verifyOTPSchema = Joi.object({
  email: emailSchema,
  country_code: countryCodeSchema,
  mobile_number: mobileNumberSchema,
  otp: otpSchema,
  x_api_key: Joi.string().allow(''),
})
  .xor('email', 'mobile_number')
  .messages({
    'object.xor': 'Either Email or Mobile Number is allowed',
    'object.missing': 'Email or Mobile Number is required',
  });

exports.resendOTPSchema = Joi.object({
  email: emailSchema,
  country_code: countryCodeSchema,
  mobile_number: mobileNumberSchema,
})
  .xor('email', 'mobile_number')
  .messages({
    'object.xor': 'Either Email or Mobile Number is allowed',
    'object.missing': 'Email or Mobile Number is required',
  });

exports.getUserSchema = (req) => {
  const { userType } = req.user;
  let userProfileSchema;
  switch (userType) {
    case userRoles.SUPER_ADMIN:
      userProfileSchema = {
        first_name: firstNameSchema.allow('').required(),
        last_name: lastNameSchema.allow('').required(),
        // profile_picture: profilePictureSchema,
        profile_picture: Joi.any(),
      };
      break;
    case userRoles.ORGANIZATION_ADMIN:
      userProfileSchema = {
        registered_number: registeredNumberSchema.required(),
        date_of_incorporation: dateOfIncorporationSchema.required(),
        name: organizationNameSchema.required(),
        type: organizationTypeSchema.required(),
        office_address: organizationAddressSchema.required(),
        description: organizationDescriptionSchema.required(),
        website: organizationWebsiteSchema.required(),
        legal_status: organizationLegalStatusSchema.required(),
        email_id: orgEmailAddressesSchema.required(),
        contact_number: contactNumbersSchema.required(),
        profile_picture: profileImageSchema,
        linkedin: linkedInURLSchema,
        twitter: twitterURLSchema,
        policy_id: policyIdSchema.required(),
        sub_rule_ids: policySubRuleIdSchema.required(),
      };
      break;
    case userRoles.FRONT_END_USER:
      userProfileSchema = {};
      break;
    default:
      userProfileSchema = {
        first_name: firstNameSchema.allow('').required(),
        last_name: lastNameSchema.allow('').required(),
        profile_picture: profileImageSchema,
        country_code: countryCodeSchema.allow('').required(),
        mobile_number: mobileNumberSchema.allow('').required(),
      };
      break;
  }
  return Joi.object({
    ...userProfileSchema,
  });
};

exports.deleteAccountSchema = Joi.object({
  type: Joi.string().valid('yes', 'no').label('Delete Type'),
});

exports.dashboardSchema = Joi.object({
  year: yearSchema.required(),
});

exports.autoSyncUserDataSchema = Joi.object({
  shared_data: sharedDataSchema,
});

exports.getCronHistorySchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
});
