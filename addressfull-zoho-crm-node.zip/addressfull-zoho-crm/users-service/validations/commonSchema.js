const Joi = require('joi');
const { isValidObjectId } = require('mongoose');
const responseMessages = require('../config/constants/reponseMessages');
const SMSService = require('../config/constants/SMSServices');

/**
 * Request Body Parameter Schemas
 */

// Defined a custom validation function for Object IDs
const objectIdValidator = (value, helpers) => {
  if (value === '') {
    return null;
  }
  if (isValidObjectId(value)) {
    return value;
  }
  // If it's not a valid Object ID, return an error message
  return helpers.error('any.invalidObjectId');
};

// Extend Joi to add objectId validation type
const objectIdJoi = Joi.extend((joi) => ({
  type: 'objectId',
  base: joi.string().trim(),
  rules: {
    validObjectId: {
      validate(value, helpers) {
        return objectIdValidator(value, helpers);
      },
    },
  },
}));

exports.ObjectIdSchema = objectIdJoi.objectId().validObjectId();

exports.ObjectIdWithNullSchema = objectIdJoi
  .objectId()
  .validObjectId()
  .allow('null');

// Define the reusable schema
const nameWithoutSpecialChars = Joi.string()
  .regex(/^[a-zA-Z0-9\s\-\&\'\#]+$/) // Allows letters, numbers, spaces, hyphens, apostrophes, ampersands, and hashtags
  .messages({
    'string.pattern.base':
      '{#label} must only contain valid characters (letters, numbers, spaces, hyphens, apostrophes, ampersands, and hashtags).',
  });

// Extend with required() if needed. Empty string is allowed
const firstNameSchema = Joi.string().trim().label('First Name');
exports.firstNameSchema = firstNameSchema;

const firstNameProfileSchema = Joi.string()
  .trim()
  // eslint-disable-next-line no-control-regex
  .pattern(/^[\u{0000}-\u{1D7FF}a-zA-Z0-9\s\-'\u2018\u2019\p{M}]+$/u)
  .label('First Name');
exports.firstNameProfileSchema = firstNameProfileSchema;

// Extend with required() if needed. Empty string is allowed
const lastNameSchema = Joi.string().trim().label('Last Name');
exports.lastNameSchema = lastNameSchema;

const lastNameProfileSchema = Joi.string()
  .trim()
  // eslint-disable-next-line no-control-regex
  .pattern(/^[\u{0000}-\u{1D7FF}a-zA-Z0-9\s\-'\u2018\u2019\p{M}]+$/u)
  .label('Last Name');
exports.lastNameProfileSchema = lastNameProfileSchema;

const emailSchema = Joi.string().trim().email().lowercase().label('Email');
exports.emailSchema = emailSchema;

const emailProfileSchema = Joi.string()
  .trim()
  .pattern(/^[A-Z0-9a-z._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,64}$/)
  .lowercase()
  .label('Email');
exports.emailProfileSchema = emailProfileSchema;

exports.emailArraySchema = Joi.array()
  .items(emailSchema.allow(''))
  .label('Email')
  .error((errors) => {
    const index = errors[0].path[1]; // Extract the index from the error object
    return new Error(`Invalid email at position ${index + 1}`);
  });

exports.mobileNumberSchema = Joi.string()
  .trim()
  .pattern(/^\d{6,13}$/)
  .message('Mobile number should be between 6 to 13 characters.')
  .label('Mobile Number');

const mobileNumberWithCodeSchema = Joi.string()
  .trim()
  .regex(/^(\d{1,3}\|\d{6,13})$/)
  .message('Mobile number should be between 6 to 13 characters.')
  .label('Mobile Number');
exports.mobileNumberWithCodeSchema = mobileNumberWithCodeSchema;

exports.mobileNumberWithCodeArraySchema = Joi.array()
  .items(
    Joi.string()
      .trim()
      .regex(/^(\d{1,3}\|\d{6,13})$/)
      .allow('')
      .error((errors) => {
        const index = errors[0].path[1]; // Extract the index from the error object
        return new Error(
          `Mobile number should be between 6 to 13 characters at position ${
            index + 1
          }`
        );
      })
  )
  .label('Mobile number');

// exports.roleTypeSchema = Joi.string()
//   .required()
//   .trim()
//   .valid('super-admin, organization-admin')
//   .label('Role Type');

exports.roleTypeSchema = Joi.string()
  // .required()
  .trim()
  .valid('super-admin', 'organization-admin')
  .label('Role Type');

exports.passwordSchema = Joi.string()
  .trim()
  .min(8)
  .max(16)
  .regex(/^(?=.*[a-zA-Z])(?=.*[A-Z])(?=.*[!@#$%^&*])/)
  .message(
    'Password must be between 8 and 16 characters and contain at least one alphabetic character, one uppercase character, and one special character (!@#$%^&*).'
  )
  .label('Password');

// exports.otpSchema = Joi.number()
//   .integer()
//   .greater(0000)
//   .message('Invalid Verification Code')
//   .less(9999)
//   .message('Invalid Verification Code')
//   .required()
//   .label('OTP')
//   .error(new Error('Invalid Verification Code'));

exports.otpSchema = Joi.number()
  .integer()
  .min(0) // Allows 0000 (which is 0) and above
  .max(9999) // Allows up to 9999
  .required()
  .label('OTP')
  .error(new Error('Invalid Verification Code'));

exports.countryCodeSchema = Joi.string()
  .trim()
  .pattern(/^\d{1,3}$/)
  .message('Country code is invalid')
  .when('mobile_number', {
    then: Joi.required(),
    otherwise: Joi.allow(''),
  })
  .label('Country Code');

exports.profilePictureSchema = Joi.object({
  data: Joi.string(),
})
  .allow('')
  .label('Profile Picture');

exports.profileImageSchema = Joi.any().allow('').label('Profile Picture');

exports.organizationDocSchema = Joi.object({
  data: Joi.string(),
})
  .allow('')
  .label('Document');

exports.tokenSchema = Joi.string().trim().label('Token');

exports.smsTokenSchema = Joi.string().trim().label('SMS Token');

exports.organizationDocTypeSchema = Joi.string().label('Document Type');

exports.organizationDocIdSchema = Joi.string()
  .trim()
  .label('Organization Doc Id');

exports.organizationAuthorizeSchema = Joi.string()
  .valid('yes', 'no')
  .label('Authorize Status');

exports.organizationTrustedSchema = Joi.string()
  .valid('yes', 'no')
  .label('Trusted Status');

// Organization Schema
exports.registeredNumberSchema = Joi.string().trim().label('Registered Number');

exports.dateOfIncorporationSchema = Joi.date()
  .max('now')
  .iso()
  .label('Date Of Incorporation [Ex. YYYY-MM-DD]');

// exports.organizationNameSchema = Joi.string().label('Organization Name');
exports.organizationNameSchema = nameWithoutSpecialChars
  .label('Organization Name')
  .messages({
    'string.pattern.base':
      'Organization Name must not contain special characters.',
  });

exports.organizationTypeSchema = Joi.string().label('Organization Type');

exports.organizationAddressSchema = Joi.string().label('Organization Address');

exports.organizationDescriptionSchema = Joi.string().label(
  'Organization Description'
);
exports.organizationWebsiteSchema = Joi.string().label('Organization Website');

const linkedInURLSchema = Joi.string()
  .trim()
  .uri({ scheme: ['http', 'https'] })
  .message(responseMessages.INVALID_SOCIAL_LINKEDIN)
  .regex(/^https?:\/\/(?:www\.)?linkedin\.com\/.*/)
  .message(responseMessages.INVALID_SOCIAL_LINKEDIN);
exports.linkedInURLSchema = linkedInURLSchema;

const twitterURLSchema = Joi.string()
  .trim()
  .uri({ scheme: ['http', 'https'] })
  .message(responseMessages.INVALID_SOCAIL_TWITTER)
  .regex(/^https?:\/\/(?:www\.)?(?:x\.com|twitter\.com)\/.*/)
  .message(responseMessages.INVALID_SOCAIL_TWITTER);
exports.twitterURLSchema = twitterURLSchema;

exports.organizationLegalStatusSchema = Joi.string().label(
  'Organization Legal Status'
);

exports.emailAddressesSchema = Joi.array()
  .items(Joi.string().email())
  .label('Email Addresses');

exports.activityFilters = Joi.array().items(Joi.string());

exports.contactNumbersSchema = Joi.array()
  .items(
    Joi.string().custom((value, helpers) => {
      // Regular expression to validate a contact number with a country code
      const regex = /^\+\d{1,3}\|\d{6,13}$/;

      if (!regex.test(value)) {
        return helpers.message(
          'Invalid contact number format. It should be in the form of "+[country code]|[number]".'
        );
      }
      return value;
    })
  )
  .unique()
  .label('Contact Numbers')
  .error((errors) => {
    const uniqueError = errors.find((error) => error.code === 'array.unique');
    if (uniqueError) {
      uniqueError.message = 'Contact Numbers should not be duplicate.';
    }
    return errors;
  });

/**
 * Request Query Parameter Schemas
 */
exports.pageNumberQuerySchema = Joi.number()
  .integer()
  .min(1)
  .label('Page Number');

exports.pageSizeQuerySchema = Joi.number()
  .integer()
  .min(1)
  .max(100)
  .label('Page Size');

exports.sortByQueryParam = (validFields) =>
  Joi.string()
    .trim()
    .valid(...validFields)
    .allow()
    .label('Sort By Field');

exports.orderByQueryParam = Joi.string()
  .trim()
  .valid('asc', 'desc')
  .allow('')
  .label('Order By Field');

// exports.searchSchema = Joi.string()
//   .trim()
//   .regex(/^[a-zA-Z0-9\-_\. ]+$/)
//   .message(responseMessages.INVALID_SEARCH)
//   .max(50);

exports.searchSchema = Joi.string().max(30).messages({
  'string.max': responseMessages.MAX_SEARCH,
});

exports.searchAllSchema = Joi.string().max(30);

exports.orgEmailAddressesSchema = Joi.array()
  .items(Joi.string().email())
  .unique()
  .label('Email Addresses')
  .error((errors) => {
    const uniqueError = errors.find((error) => error.code === 'array.unique');
    if (uniqueError) {
      uniqueError.message = 'Email addresses should not be duplicate.';
    }
    return errors;
  });

// Custom validation function for timezone
const validateTimezone = (value, helpers) => {
  // Regular expression to match valid timezone strings
  const timezoneRegex =
    /^(?:(?:\(UTC(?:\+|\-)(?:[0-9]|1[0-3])\))|(?:[A-Za-z_\-\/]+(?:\/[A-Za-z_\-\/]+)?))$/;

  if (!timezoneRegex.test(value)) {
    return helpers.error('any.invalid');
  }
  return value;
};
exports.timezoneSchema = Joi.string()
  .custom(validateTimezone, 'Timezone Validation')
  .optional();

exports.yearSchema = Joi.number()
  .integer()
  .min(1900) // Adjust the minimum year as needed
  .max(new Date().getFullYear()) // Set the maximum year to the current year
  .required()
  .label('Year');

exports.smsService = Joi.string()
  .valid(...Object.values(SMSService))
  .label('SMS Service');

exports.sharedDataSchema = Joi.array().items(
  Joi.object({
    type: Joi.string().valid(
      'firstName',
      'lastName',
      'mobileNumber1',
      'mobileNumber2',
      'mobileNumber3',
      'mobileNumber4',
      'mobileNumber5',
      'email1',
      'email2',
      'email3',
      'email4',
      'email5',
      'address1',
      'address2',
      'address3',
      'address4',
      'address5',
      'linkedin',
      'twitter'
    ),
    value: Joi.string()
      .when('type', {
        is: 'firstName',
        then: firstNameProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'lastName',
        then: lastNameProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber1',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber2',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber3',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber4',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber5',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email1',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email2',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email3',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email4',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email5',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'address1',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address2',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address3',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address4',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address5',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'linkedin',
        then: linkedInURLSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'twitter',
        then: twitterURLSchema,
        otherwise: Joi.allow(''),
      }),
    old_value: Joi.string()
      .when('type', {
        is: 'firstName',
        then: firstNameProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'lastName',
        then: lastNameProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber1',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber2',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber3',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber4',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'mobileNumber5',
        then: mobileNumberWithCodeSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email1',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email2',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email3',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email4',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'email5',
        then: emailProfileSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'address1',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address2',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address3',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address4',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'address5',
        then: Joi.string().trim().allow('').label('Address'),
      })
      .when('type', {
        is: 'linkedin',
        then: linkedInURLSchema,
        otherwise: Joi.allow(''),
      })
      .when('type', {
        is: 'twitter',
        then: twitterURLSchema,
        otherwise: Joi.allow(''),
      }),
  })
);

exports.policyTitleSchema = Joi.string().label('Policy Title');

exports.policySubRulesSchema = Joi.object({
  name: Joi.string().required(),
  description: Joi.string(),
  isActive: Joi.boolean().default(false).required(),
});

exports.updatePolicySubRulesSchema = Joi.object({
  id: exports.ObjectIdWithNullSchema.required().messages({
    'any.invalidObjectId': responseMessages.INVALID_OBJECT_ID,
  }),
  name: Joi.string().required(),
  description: Joi.string(),
  isActive: Joi.boolean().default(false).required(),
});

exports.policyIdSchema = Joi.string().trim().label('Policy Id');

exports.policySubRuleIdSchema = Joi.array()
  .items(Joi.string().trim())
  .min(1) // Ensure the array has at least 1 item
  .label('Sub Rules');

// Define a schema for the cron expression validation
exports.cronSchema = Joi.string()
  .regex(
    /^(\*|\d+)(\/\d+)?(\-\d+)?(,\d+)*(\s+(\*|\d+)(\/\d+)?(\-\d+)?(,\d+)*){4}$/
  )
  .error(new Error('Invalid cron expression'));

exports.timeExpirationSchema = Joi.string()
  .regex(/^([1-9]|[1-2][0-9]|3[0-1])d$/) // Accepts values from 1d to 31d
  .min(2)
  .max(4)
  .messages({
    'string.pattern.base':
      'Expiration time must be in the format "Nd" where N is a number from 1 to 31. (Ex: 10d)',
    'string.min': 'Expiration time must be at least 1 day (1d).',
    'string.max': 'Expiration time must be at most 31 days (31d).',
  });
