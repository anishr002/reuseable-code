const Joi = require('joi');
const responseMessages = require('../config/constants/reponseMessages');
const {
  emailSchema,
  passwordSchema,
  firstNameSchema,
  lastNameSchema,
  ObjectIdSchema,
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  sortByQueryParam,
  orderByQueryParam,
  searchSchema,
} = require('./commonSchema');

exports.adminSchema = Joi.object({
  first_name: firstNameSchema.allow(''),
  last_name: lastNameSchema.allow(''),
  email: emailSchema.required(),
  // password: passwordSchema.required(),
  status: Joi.boolean().required(),
  role: ObjectIdSchema.required().messages({
    'any.invalidObjectId': responseMessages.ROLE_INVALID,
  }),
});

exports.updateAdminSchema = Joi.object({
  first_name: firstNameSchema.allow(''),
  last_name: lastNameSchema.allow(''),
  status: Joi.boolean().required(),
  role: ObjectIdSchema.required().allow(null).messages({
    'any.invalidObjectId': responseMessages.ROLE_INVALID,
  }),
  id: Joi.string(),
});

exports.getAdminSchema = Joi.object({
  mobile_user: Joi.string().valid('true', 'false'),
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  sort_by: sortByQueryParam([
    'first_name',
    'last_name',
    'email',
    'active',
    'created_at',
    'updated_at',
  ]),
  order_by: orderByQueryParam,
  search: searchSchema,
  role: ObjectIdSchema.messages({
    'any.invalidObjectId': 'Invalid Role',
  }),
});
