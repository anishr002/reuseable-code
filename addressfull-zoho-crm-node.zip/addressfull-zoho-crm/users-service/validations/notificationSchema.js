const Joi = require('joi');

const { ObjectIdSchema } = require('./commonSchema');

exports.sendRequestToUserSchema = Joi.object({
  client_id: ObjectIdSchema.required(),
  request_details: Joi.array()
    .items(
      Joi.string().valid(
        'Address',
        'MobileNumber',
        'Email',
        'Twitter',
        'LinkedIn'
      )
    )
    .required(),
});

exports.updateRequestSchema = Joi.object({
  request_id: ObjectIdSchema.required(),
  organization_id: ObjectIdSchema.required(),
  request_status: Joi.boolean().required().valid(true, false),
});

exports.forceUpdateSchema = Joi.object({
  device_type: Joi.string().valid('Android', 'IOS').required(),
  update_status: Joi.boolean().valid(true, false).optional(),
});
