const Joi = require('joi');
const {
  mobileNumberWithCodeArraySchema,
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  searchSchema,
  registeredNumberSchema,
  dateOfIncorporationSchema,
  organizationNameSchema,
  organizationTypeSchema,
  organizationAddressSchema,
  organizationDescriptionSchema,
  organizationWebsiteSchema,
  organizationLegalStatusSchema,
  orgEmailAddressesSchema,
  contactNumbersSchema,
  profileImageSchema,
  organizationDocSchema,
  organizationDocTypeSchema,
  ObjectIdSchema,
  sortByQueryParam,
  orderByQueryParam,
  organizationDocIdSchema,
  organizationAuthorizeSchema,
  tokenSchema,
  timezoneSchema,
  linkedInURLSchema,
  twitterURLSchema,
  sharedDataSchema,
  policyIdSchema,
  policySubRuleIdSchema,
} = require('./commonSchema');

const responseMessages = require('../config/constants/reponseMessages');

exports.getTopTrustedOrganizationsSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
  id: ObjectIdSchema.messages({
    'any.invalidObjectId': responseMessages.INVALID_QR,
  }),
  lat: Joi.number().min(-90).max(90).optional(),
  lon: Joi.number().min(-180).max(180).optional(),
  miles: Joi.number().positive().optional(),
  timezone: timezoneSchema,
  // is_trusted: Joi.boolean(),
});

exports.getBlockedOrganizationListSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
  sort_by: sortByQueryParam(['organization_name, created_at', 'updated_at']),
  order_by: orderByQueryParam,
  timezone: timezoneSchema,
});

exports.getOrganizationsSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
  sort_by: sortByQueryParam([
    'name',
    'registered_number',
    'date_of_incorporation',
    'created_at',
    'updated_at',
  ]),
  order_by: orderByQueryParam,
});

exports.createOrganizationSchema = Joi.object({
  // is_trusted: organizationTrustedSchema.required(),
  registered_number: registeredNumberSchema.required(),
  date_of_incorporation: dateOfIncorporationSchema.required(),
  name: organizationNameSchema.required(),
  type: organizationTypeSchema.required(),
  office_address: organizationAddressSchema.required(),
  description: organizationDescriptionSchema.required(),
  website: organizationWebsiteSchema.required(),
  legal_status: organizationLegalStatusSchema.required(),
  email_id: orgEmailAddressesSchema.required(),
  contact_number: contactNumbersSchema.required(),
  profile_picture: profileImageSchema,
  linkedin: linkedInURLSchema,
  twitter: twitterURLSchema,
  policy_id: policyIdSchema.required(),
  sub_rule_ids: policySubRuleIdSchema.required(),
});

exports.updateOrganizationSchema = Joi.object({
  id: tokenSchema,
  is_authorized: organizationAuthorizeSchema.required(),
  // is_trusted: organizationTrustedSchema.required(),
  registered_number: registeredNumberSchema.required(),
  date_of_incorporation: dateOfIncorporationSchema.required(),
  name: organizationNameSchema.required(),
  type: organizationTypeSchema.required(),
  office_address: organizationAddressSchema.required(),
  description: organizationDescriptionSchema.required(),
  website: organizationWebsiteSchema.required(),
  legal_status: organizationLegalStatusSchema.required(),
  email_id: orgEmailAddressesSchema,
  contact_number: contactNumbersSchema.required(),
  profile_picture: profileImageSchema,
  linkedin: linkedInURLSchema,
  twitter: twitterURLSchema,
  policy_id: policyIdSchema.required(),
  sub_rule_ids: policySubRuleIdSchema.required(),
});

exports.uploadOrganizationDocSchema = Joi.object({
  id: ObjectIdSchema.required().messages({
    'any.invalidObjectId': responseMessages.INVALID_OBJECT_ID,
  }),
  document: organizationDocSchema,
  document_type: organizationDocTypeSchema.required(),
});

exports.removeOrganizationDocSchema = Joi.object({
  org_id: ObjectIdSchema.required().messages({
    'any.invalidObjectId': responseMessages.INVALID_OBJECT_ID,
  }),
  doc_id: organizationDocIdSchema.required(),
});

exports.makeMyTrustedOrganizationSchema = Joi.object({
  organization_id: ObjectIdSchema.required().messages({
    'any.invalidObjectId': responseMessages.INVALID_OBJECT_ID,
  }),
});

exports.shareDataToOrganizationSchema = Joi.object({
  organization_id: ObjectIdSchema.messages({
    'any.invalidObjectId': responseMessages.INVALID_OBJECT_ID,
  }),
  shared_data: sharedDataSchema,
});

exports.getConnectedUsersSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
  sort_by: sortByQueryParam(['mobile_number', 'country_code', 'updated_at']),
  order_by: orderByQueryParam,
});

exports.getUserConsentSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
  sort_by: sortByQueryParam(['organizationName', 'count']),
  order_by: orderByQueryParam,
});

exports.sendDataReqBulkSchema = Joi.object({
  singleItem: Joi.boolean(),
  mobile_numbers: mobileNumberWithCodeArraySchema,
});

exports.blockUnblockOrganizationSchema = Joi.object({
  organization_id: ObjectIdSchema.required(),
  block_status: Joi.boolean().required().valid(true, false),
  reason_for_block: Joi.when('block_status', {
    is: true,
    then: Joi.string().required(),
    otherwise: Joi.forbidden(),
  }),
});

exports.getMessageLogsSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  search: searchSchema,
  sort_by: sortByQueryParam([
    'country_code',
    'mobile_number',
    'status',
    'try_count',
    'fail_count',
    'created_at',
    'updated_at',
  ]),
  order_by: orderByQueryParam,
});
