const Joi = require('joi');
const { getModules } = require('../utils/common');
const permissionTypes = require('../config/constants/permissionType');
const {
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  sortByQueryParam,
  orderByQueryParam,
} = require('./commonSchema');
const responseMessages = require('../config/constants/reponseMessages');

const createPermissionSchema = async (req) => {
  const validSystemModules = await getModules(req.user.userType);
  return Joi.object({
    module: Joi.string()
      .required()
      .valid(...validSystemModules)
      .messages({
        'any.only': responseMessages.ROLES_WRONG_MODULE,
      })
      .label('Module'),
    permission: Joi.string()
      .required()
      .valid(...Object.values(permissionTypes))
      .messages({
        'any.only': responseMessages.ROLES_WRONG_PERMISSION,
      })
      .label('Permission Type'),
  });
};

exports.createRoleSchema = async (req) => {
  const permissionsArrayItems = await createPermissionSchema(req);
  return Joi.object({
    name: Joi.string().required().trim().lowercase().label('Name'),
    status: Joi.boolean().label('Status'),
    permissions: Joi.array().items(permissionsArrayItems),
    id: Joi.string(),
  });
};

exports.getRoleSchema = Joi.object({
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  sort_by: sortByQueryParam(['name', 'active', 'created_at', 'updated_at']),
  order_by: orderByQueryParam,
  active: Joi.string().alphanum().trim(),
});
