const Joi = require('joi');

exports.profilePictureSchema = Joi.object({
  profilePicture: Joi.any()
    .required()
    // .meta({
    //   swaggerType: 'file',
    // })
    .label('Profile Picture'),
});
