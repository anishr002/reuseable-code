const Joi = require('joi');
const {
  pageNumberQuerySchema,
  pageSizeQuerySchema,
  ObjectIdSchema,
  timezoneSchema,
  organizationNameSchema,
  searchAllSchema,
} = require('./commonSchema');

const transactionBaseSchema = {
  page: pageNumberQuerySchema,
  page_size: pageSizeQuerySchema,
  log_type: Joi.string().valid('request', 'consent').optional(),
  permission_status: Joi.string()
    .valid('sent', 'approve', 'reject', 'share', 'revoke', 'policy')
    .optional(),
  start_date: Joi.date().iso().optional(),
  end_date: Joi.date().iso().optional(),
  bookmark: Joi.string().allow('').optional(),
  sort_order: Joi.string().valid('asc', 'desc').optional(),
};

exports.getTransactionSchema = Joi.object({
  ...transactionBaseSchema,
  organization_name: organizationNameSchema,
  search: searchAllSchema,
  mobile_number: Joi.string()
    .pattern(/^(?:\+\d{1,4} ?)?\d{7,13}$/)
    .messages({ 'string.pattern.base': 'Invalid mobile number format' }),
});

exports.getActivitySchema = Joi.object({
  ...transactionBaseSchema,
  organization_name: organizationNameSchema,
  client_id: ObjectIdSchema.allow('').optional(),
  timezone: timezoneSchema,
});
