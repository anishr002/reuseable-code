// import all common express paths here
const userRoutes = require('./helper/userSwagger');
const organizationRoutes = require('./helper/organizationSwagger');
const roleRoutes = require('./helper/roleSwagger');
const adminRoutes = require('./helper/adminSwagger');
const settingRoutes = require('./helper/settingSwagger');
const notificationRoutes = require('./helper/notificationSwagger');
const transactionRoutes = require('./helper/transactionSwagger');
const privacyPolicyRoutes = require('./helper/privacyPolicySwagger');

const swaggerDoc = {
  openapi: '3.0.0',
  host: '',
  info: {
    title: 'Users microserice',
    version: '0.0.1',
    description: 'Swagger API Documentation for user microserice',
  },
  servers: [
    {
      url: `${process.env.PROTOCOL}://${process.env.HOST}:${process.env.PORT}`,
      description: 'Current server',
    },
    {
      url: 'https://api.addressfull.com',
      description: 'Production server',
    },
    {
      url: 'https://api.uat.addressfull.com',
      description: 'Old Development server',
    },
    // {
    //   url: 'http://172.16.2.200:3005',
    //   description: 'local ip',
    // },
    // {
    //   url: 'http://137.184.19.129:3001',
    //   description: 'Staging server',
    // },
    // {
    //   url: 'http://137.184.19.129:3003',
    //   description: 'Demo server',
    // },
  ],
  tags: [
    {
      name: 'Authentication',
      description: 'Authentication API Routes',
    },
    {
      name: 'UserProfile',
      description: 'User Profile API Routes',
    },
    {
      name: 'Users',
      description: 'Users API Routes',
    },
    {
      name: 'Organizations',
      description: 'Organizations API Routes',
    },
    {
      name: 'Roles',
      description: 'Role Management Module API Routes',
    },
    {
      name: 'Admins',
      description: 'Admin Management Module API Routes',
    },
    {
      name: 'Notifications',
      description: 'Notofication Module API Routes',
    },
    {
      name: 'Setting',
      description: 'Settings Module API Routes',
    },
    {
      name: 'PrivacyPolicy',
      description: 'PrivacyPolicy Module API Routes',
    },
  ],

  paths: {
    ...userRoutes,
    ...organizationRoutes,
    ...roleRoutes,
    ...adminRoutes,
    ...settingRoutes,
    ...notificationRoutes,
    ...transactionRoutes,
    ...privacyPolicyRoutes,
  },

  components: {
    schemas: {
      EmailAndRoleSchema: {
        type: 'object',
        properties: {
          email: {
            type: 'string',
            description: 'Enter Email',
            required: true,
            example: 'jon.p@yopmail.com',
          },
          role_type: {
            type: 'string',
            description: 'Enter Role Type',
            required: true,
            example: 'super-admin',
          },
        },
      },
      EmailSchema: {
        type: 'object',
        properties: {
          email: {
            type: 'string',
            description: 'Enter Email',
            required: true,
            example: 'jon.p@yopmail.com',
          },
        },
      },
      PasswordSchema: {
        type: 'object',
        properties: {
          password: {
            type: 'string',
            description: 'Enter Password',
            required: true,
            example: 'Abcd@123',
          },
        },
      },
      RoleModule: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            description: 'Role Name',
            example: 'manager',
            required: true,
          },
          status: {
            type: 'boolean',
            description: 'Role Status',
            example: false,
          },
          permissions: {
            $ref: '#/components/schemaProps/RolePermissions',
          },
        },
      },
      EmailPassword: {
        type: 'object',
        properties: {
          email: {
            type: 'string',
            description: 'Enter Email',
            required: true,
            example: 'jon.p@yopmail.com',
          },
          password: {
            type: 'string',
            description: 'Enter Password',
            required: true,
            example: 'Abcd@123',
          },
          role_type: {
            type: 'string',
            description: 'Enter Role Type',
            required: true,
            example: 'super-admin',
          },
        },
      },
      CountryCodeMobileNumber: {
        type: 'object',
        properties: {
          country_code: {
            type: 'string',
            description: 'Enter Country Code',
            required: true,
          },
          mobile_number: {
            type: 'string',
            description: 'Enter Mobile Number',
            required: true,
          },
        },
      },
      OTPAndEmail: {
        type: 'object',
        properties: {
          email: {
            type: 'string',
            description: 'Enter Email',
            required: true,
            example: 'jon.p@yopmail.com',
          },
          otp: {
            type: 'number',
            description: 'Enter OTP',
            required: true,
            example: 133894,
          },
        },
      },
      OTPAndMobile: {
        allOf: [
          {
            $ref: '#/components/schemas/CountryCodeMobileNumber',
          },
          {
            properties: {
              otp: {
                type: 'number',
                description: 'Enter OTP',
                required: true,
                example: 133894,
              },
            },
          },
        ],
      },
      Email: {
        type: 'object',
        properties: {
          email: {
            type: 'string',
            description: 'Enter Email',
            required: true,
            example: 'jon.p@yopmail.com',
          },
        },
      },
      Mobile: {
        type: 'object',
        properties: {
          country_code: {
            type: 'string',
            description: 'Enter Country Code',
            required: true,
          },
          mobile_number: {
            type: 'string',
            description: 'Enter Mobile Number',
            required: true,
          },
        },
      },
    },
    schemaProps: {
      RolePermissions: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            module: {
              type: 'string',
              description: 'Module name',
            },
            permission: {
              type: 'string',
              description: 'Permission type',
            },
          },
        },
        description: 'Permissions',
        example: [
          {
            module: 'roles',
            permission: 'read',
          },
          {
            module: 'admins',
            permission: 'read',
          },
        ],
      },
      PolicySubRules: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            name: {
              type: 'string',
              description: 'Policy name',
            },
            description: {
              type: 'string',
              description: 'Policy description',
            },
            isActive: {
              type: 'boolean',
              description: 'Policy status',
            },
            _id: {
              type: 'string',
              description: 'Policy Id',
            },
          },
        },
        description: 'SubRules',
        example: [
          {
            name: 'Rule Name',
            description: 'Rule Description',
            isActive: true,
            id: '65e9345fa141d1ebdd0c77b3',
          },
        ],
      },
      FirstName: {
        type: 'string',
        description: 'First Name',
        example: 'Grant',
      },
      LastName: {
        type: 'string',
        description: 'Last Name',
        example: 'Morte',
      },
      Email: {
        type: 'string',
        description: 'Email',
        example: 'jon.p@yopmail.com',
      },
      RecordStatus: {
        type: 'boolean',
        description: 'Record is active or not',
        example: false,
      },
      UniqueId: {
        type: 'string',
        description: 'Unique Id',
        example: '654371af939d72ca10b19867',
      },
      createdAtDate: {
        type: 'string',
        description: 'Created Date',
        example: '2023-11-02T09:53:51.650Z',
      },
      updatedAtDate: {
        type: 'string',
        description: 'Updated Date',
        example: '2023-11-03T08:05:13.267Z',
      },
    },
    responses: {
      CommonResponse: {
        type: 'object',
        properties: {
          status: {
            type: 'number',
            description: 'Status Code',
          },
          message: {
            type: 'string',
            description: 'Success or Error Message',
          },
        },
      },
      paginationResponse: {
        type: 'object',
        properties: {
          total_count: {
            type: 'number',
            description: 'Total number of records',
            example: 5,
          },
          total_pages: {
            type: 'number',
            description: 'Total number of pages',
            example: 3,
          },
          current_page: {
            type: 'number',
            description: 'Current page',
            example: 2,
          },
        },
      },
      settingsResponse: {
        type: 'object',
        properties: {
          status: {
            type: 'number',
            example: 200,
          },
          data: {
            type: 'object',
            properties: {
              to_email: {
                type: 'array',
                items: {
                  type: 'string',
                  example: 'test@gmail.com',
                },
              },
              organization_types: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    name: {
                      type: 'string',
                      example: 'education',
                    },
                    title: {
                      type: 'string',
                      example: 'Education',
                    },
                    status: {
                      type: 'boolean',
                      example: true,
                    },
                  },
                },
              },
              activity_filters: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    title: {
                      type: 'string',
                      example: 'Last 30 days',
                    },
                    start_date: {
                      type: 'string',
                      example: '2024-03-16',
                    },
                    end_date: {
                      type: 'string',
                      example: '2024-04-15',
                    },
                  },
                },
              },
            },
          },
        },
      },
      emailTemplatesResponse: {
        type: 'object',
        properties: {
          mail_type: {
            type: 'string',
            description: 'Type of the email template',
            example: 'send-otp',
          },
          from_name: {
            type: 'string',
            description: 'From Name',
            example: 'AddressFull',
          },
          from_email: {
            type: 'string',
            description: 'From Email',
            example: 'addressfull@gmail.com',
          },
          subject: {
            type: 'string',
            description: 'Subject',
            example: 'OTP Verification',
          },
          body: {
            type: 'string',
            description: 'Subject',
            example: '<html><head></head></html',
          },
        },
      },
    },
    parameters: {
      token: {
        name: 'token',
        description:
          'An authorization header, Please add Bearer keyword before token',
        in: 'header',
        type: 'string',
        required: true,
        examples: {
          super_admin: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Impvbi5wQHlvcG1haWwuY29tIiwiaWF0IjoxNzEwODI2NjMwLCJleHAiOjE3MTA5MTMwMzB9.QmsSYciT0B7e_odqDMiIqxQUKJXNWvH5SNf_2_tG08Y',
          },
          sub_admin: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImdyYW50cy5tQHlvcG1haWwuY29tIiwiaWF0IjoxNzA2MTcxMDQ0LCJleHAiOjE3MTEzNTUwNDR9.qL9BHa_FIF_2GLJltGtGLVzhiLbY4OERqot2GvJ5qYY',
          },
          organization_admin_domentia: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImRlbWVudGlhQHlvcG1haWwuY29tIiwiaWF0IjoxNzExNjkzMzk4LCJleHAiOjE3MTg2MDUzOTh9.svQ8cjVj-IRgeuUWtu2I7Ge2SpCD6jug_isOLxsPbzo',
          },
          organization_admin_janavi: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjFAeW9wbWFpbC5jb20iLCJpYXQiOjE3MDYxNzIwMTksImV4cCI6MTcxMTM1NjAxOX0.RcpLWx7IiISNUqD2S8ybfnFwN-KB-joX6LSH0F_9c-s',
          },
          organization_admin_london: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InNpbHZlcnA3N0B5b3BtYWlsLmNvbSIsImlhdCI6MTcwNjE3MjQ4NSwiZXhwIjoxNzExMzU2NDg1fQ.iE8nG-cmkSBUVWV4tP1_rFB1yq3AiFimKzzwu6q8k8U',
          },
          organization_admin_amazon: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFtYXpvbkB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNjE3MjU4NSwiZXhwIjoxNzExMzU2NTg1fQ.KE9bF8NFqNR9mS_JWR6PjOFEHGduYwKUggH6tBBr3Cw',
          },
          organization_admin_IBM: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImlibTFAeW9wbWFpbC5jb20iLCJpYXQiOjE3MDYxNzI2NjQsImV4cCI6MTcxMTM1NjY2NH0.hjTQfjvrf4ASnOVTnpu3AwV8jb4YbRU2Iq2R9YWmeJI',
          },
          organization_subadmin_janavi: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZzFfc3RmMUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNjE3MjgyNywiZXhwIjoxNzExMzU2ODI3fQ.T7kWDRR2QC3JW1M2xUUUXc2svsFKgtuFBsIxheXTlc8',
          },
          organization_100: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwMEB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MTg0MCwiZXhwIjoxNzEyNTc1ODQwfQ.62k5mj44jKAbNGBaE5Q3071X5Mk83Icpe2yl4fH1B3k',
          },
          organization_101: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwMUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MjIyNiwiZXhwIjoxNzEyNTc2MjI2fQ.XjZU3X8paMTR_C4wPK_G4jEF55Md5zmWvX5WVVaBM0A',
          },
          organization_102: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwMkB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MjUwNywiZXhwIjoxNzEyNTc2NTA3fQ.iRvfj4aiiioTaa1F1FGqa7Ez0e3sXUAmpgUETBEiJp0',
          },
          organization_103: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwM0B5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5Mjc0OSwiZXhwIjoxNzEyNTc2NzQ5fQ.BZIS_YQ241bGNZba8_WnYUNl5xNVYkEEjsTgEGLdfjc',
          },
          organization_104: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwNEB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5Mjk2OSwiZXhwIjoxNzEyNTc2OTY5fQ.eEzJzNdwSTLI-Tok9R82GHUzZHaCAAIparaPVkFi5Pc',
          },
          organization_105: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwNUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MzE4OCwiZXhwIjoxNzEyNTc3MTg4fQ.AoUyjMY-2yCYOoqA-d1UD5sc0y9QmXGqB6Mw3gCHrwQ',
          },
          organization_106: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwNkB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MzM2NiwiZXhwIjoxNzEyNTc3MzY2fQ.RiDIpwn-H1xdxP11cCSVg1BCNsIz9yQGQwP_FM0JMR0',
          },
          organization_107: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwN0B5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MzU1MSwiZXhwIjoxNzEyNTc3NTUxfQ.SNT2rfTr-ZzbVYw61si1HbOdBbg6tcW2tj355f3PnZE',
          },
          organization_108: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwOEB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5Mzc0NiwiZXhwIjoxNzEyNTc3NzQ2fQ.54dkU9PyDRDHK4rUwbsHz7vfEJuz0rxymE8cdKz-nOQ',
          },
          organization_109: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjEwOUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5MzgyNSwiZXhwIjoxNzEyNTc3ODI1fQ.A79wTVvjdfjoleT40Ix-hQekUObe0zgiZPFuTO1x6Gg',
          },
          organization_110: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjExMEB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5Mzk3NCwiZXhwIjoxNzEyNTc3OTc0fQ.uqoNaG71C8uR5dTa3AkJlixXajn-kJtMgBDy2SLmR_0',
          },
          organization_111: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjExMUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5NDQzNiwiZXhwIjoxNzEyNTc4NDM2fQ.bmo52dsta2tSVl_H4bgMEVHDkhCeqOHF8Apmd7mdyio',
          },
          organization_112: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjExMkB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5NDU3OSwiZXhwIjoxNzEyNTc4NTc5fQ.qSRc88Ig0xfu2c7mRKmv6egK2B4o7-mmwMYPfEaeSX0',
          },
          organization_113: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjExM0B5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5NDc0OCwiZXhwIjoxNzEyNTc4NzQ4fQ.vmnQ9mZdkj1HaijFMLfs4O1F19UnCnwvvPtRzswZEUM',
          },
          organization_114: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjExNEB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5NDg4MCwiZXhwIjoxNzEyNTc4ODgwfQ.sUU8alNspe9aMd07SzcRXczw_0QXc5k9dBnqDSOD7rE',
          },
          organization_115: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjExNUB5b3BtYWlsLmNvbSIsImlhdCI6MTcwNzM5NTAyOCwiZXhwIjoxNzEyNTc5MDI4fQ.7ZW2_sZd2-9jgQDrXOz3X_-TMoBHANuc9qoskryzEc4',
          },
          android_user_1122334455: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiMTEyMjMzNDQ1NSIsImlhdCI6MTcwNzQ1ODk2NCwiZXhwIjoxNzEyNjQyOTY0fQ.gqH64T1UqmAY0nkwxIxHGdwModLc2lCECblBNGLrxe8',
          },
          android_user_11122334455: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiMTExMjIzMzQ0NTUiLCJpYXQiOjE3MTAyMzcwNjMsImV4cCI6MTcxNTQyMTA2M30.LsuVI5ExVPJZH_-cr5PJpUw2h8U7bwzUkzcqm6AjE5g',
          },
          mobile_user_9099665918: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiOTA5OTY2NTkxOCIsImlhdCI6MTcxMDMwODczMSwiZXhwIjoxNzEwMzk1MTMxfQ.mldAyHfjqeLrroGJgw56dG3Bf-qe06Cu61Jqa9WXroo',
          },
          test_org_janvi: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im9yZ2FuaXphdGlvbjFAeW9wbWFpbC5jb20iLCJpYXQiOjE3MTAyMDgwNzUsImV4cCI6MTc0MTc0NDA3NX0.iZeeEADlB2i2iyaQpgPsif3Ae9WJJXutPzZd2BvrJMM',
          },
          mobile_user_6353752165: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiNjM1Mzc1MjE2NSIsImlhdCI6MTcxMDkyOTM4NywiZXhwIjoxNzExMDE1Nzg3fQ.YfBitpkLWu15k85KggiZ6EMPoXAUkDZ0Dok8sBSquJg',
          },
          mobile_user_7228883394: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiNzIyODg4MzM5NCIsImlhdCI6MTc2MjQ5NzgwOCwiZXhwIjoxNzYyNTg0MjA4fQ.rxbWT4fwEPfa_yuYipReKYJTu5uZYPggJXqjgOyce9Q',
          },
          mobile_user_8200816619: {
            value:
              'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiODIwMDgxNjYxOSIsImlhdCI6MTcxMjY0NTY5OCwiZXhwIjoxNzEyODE4NDk4fQ.oLZ8gdJUUddWlWzO0CNDuAmtYU9bpE6Vfe6cNW12Qpw',
          },
        },
      },
      passwordResetToken: {
        name: 'token',
        description: 'token',
        in: 'path',
        type: 'string',
        required: true,
      },
      objectId: {
        name: 'id',
        description: 'Id of the record',
        in: 'path',
        type: 'string',
        required: true,
        examples: {
          domentia_uk: {
            value: '6571ac1a2319c241b7907e7a',
          },
          test_janavi: {
            value: '658910cb17e0fc4809b0c5e7',
          },
          university_london: {
            value: '65799a65ca113ff38973b04d',
          },
          amazon: {
            value: '6581634c540049c13687a87d',
          },
          IBM: {
            value: '659d1ebf4e51998cee0aa139',
          },
        },
      },
      objectPolicyId: {
        name: 'id',
        description: 'Id of the record',
        in: 'path',
        type: 'string',
        required: true,
        examples: {
          GDPR: {
            value: '65e92bdf7cc5f07e8c3f0ed1',
          },
        },
      },
      emailType: {
        name: 'type',
        description: 'Type of email',
        in: 'path',
        type: 'string',
        required: true,
        examples: {
          example1: {
            value: 'send-otp',
          },
          example2: {
            value: 'password-reset',
          },
          example3: {
            value: 'new-account',
          },
          example4: {
            value: 'organization-registration',
          },
        },
      },
      page: {
        name: 'page',
        in: 'query',
        description: 'Enter the page number',
        type: 'Number',
      },
      pageSize: {
        name: 'page_size',
        in: 'query',
        description: 'Enter the page size',
        type: 'Number',
      },
      sortBy: {
        name: 'sort_by',
        in: 'query',
        description:
          'Enter field name to sort (name, email, active, created_at, updated_at, etc)',
        type: 'string',
        example: '',
      },
      sortByPolicy: {
        name: 'sort_by',
        in: 'query',
        description:
          'Enter field name to sort (title, created_at, updated_at, etc)',
        type: 'string',
        example: '',
      },
      sortByLogs: {
        name: 'sort_by',
        in: 'query',
        description:
          'Enter field name to sort (mobile_number, country_code, status, try_count, fail_count, created_at, updated_at, etc)',
        type: 'string',
        example: '',
      },
      orderBy: {
        name: 'order_by',
        in: 'query',
        description: 'Enter sort type (asc | desc)',
        type: 'string',
        example: '',
      },
      search: {
        name: 'search',
        in: 'query',
        description: 'Enter search string',
        type: 'string',
      },
      timezone: {
        name: 'timezone',
        in: 'query',
        description: 'Enter the timezone',
        type: 'string',
        example: 'Asia/Kolkata | America/New_York',
      },
      sort_order: {
        name: 'sort_order',
        in: 'query',
        description: 'Enter the sort order',
        type: 'string',
        enum: ['desc', 'asc'],
        example: 'desc',
      },
    },
  },
};

module.exports = swaggerDoc;
