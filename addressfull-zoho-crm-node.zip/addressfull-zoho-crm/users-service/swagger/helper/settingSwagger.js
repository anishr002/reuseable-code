const pkg = require('../../package.json');

const getEmailTemplates = {
  tags: ['Setting'],
  description: 'Get email templates',
  summary: 'Get email templates',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'array',
                items: {
                  $ref: '#/components/responses/emailTemplatesResponse',
                },
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getEmailTemplate = {
  tags: ['Setting'],
  description: 'Get email template',
  summary: 'Get email template',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/emailType',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                $ref: '#/components/responses/emailTemplatesResponse',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const updateEmailTemplate = {
  tags: ['Setting'],
  description: 'Update email template',
  summary: 'Update email template',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/emailType',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            from_name: {
              type: 'string',
              description: 'From Name',
              example: 'AddressFull',
            },
            from_email: {
              type: 'string',
              description: 'From Name',
              example: 'AddressFull@gmail.com',
            },
            subject: {
              type: 'string',
              description: 'Subject',
              example: 'AddressFull OTP Verification',
            },
            body: {
              type: 'string',
              description: 'Mail Body',
            },
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Settings have been successfully updated',
              },
            },
          },
        },
      },
    },
  },
};

const getUserSettings = {
  tags: ['Setting'],
  description: 'Get user settings',
  summary: 'Get user settings',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/settingsResponse',
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const updateUserSettings = {
  tags: ['Setting'],
  description: 'Update user settings',
  summary: 'Update user settings',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            to_email: {
              type: 'array',
              description:
                'Admin mail notifications will be sent to this mails',
              items: {
                type: 'string',
                description: 'Email',
                example: 'test@gmail.com',
              },
            },
            sms_service: {
              type: 'string',
              description: 'SMS Service',
              example: 'twilio',
            },
            timezone: {
              type: 'string',
              description: 'Timezone',
              example: 'Asia/Kolkata',
            },
            cron_execution_time: {
              type: 'string',
              description: 'Cron Execution Time',
              example: '*/3 * * * *',
            },
            token_expiration_time: {
              type: 'string',
              description: 'Token Expiration Time',
              example: '1d',
            },
            activity_filters: {
              type: 'array',
              description: 'Add Activity filter for user filter that data',
              items: {
                type: 'string',
                description: 'Activity Filters',
                example: '661cf8840964ea6e75e0dc60',
              },
            },
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/settingsResponse',
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const addCRM = {
  tags: ['Setting'],
  description: 'Add CRM',
  summary: 'Add CRM',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            type: {
              type: 'string',
              description: 'Type of CRM',
              example: 'hubspot',
            },
            auth_token: {
              type: 'string',
              description: 'Authentication Token',
              example: 'pat-na1-704193a2-fe18-49b1-b420-f8aa81b7b3c8',
              // examples: {
              //   hubspot_janavi: {
              //     value: 'pat-na1-704193a2-fe18-49b1-b420-f8aa81b7b3c8',
              //   },
              //   hubspot_smit: {
              //     value: 'pat-na1-335722e4-4a92-4b6c-a57e-594d514591ac',
              //   },
              // },
            },
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Suceess',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Record has been added successfully.',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Auth token is required',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Type is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getCRMList = {
  tags: ['Setting'],
  description: 'Get CRM List',
  summary: 'Get CRM List',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const settingRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/settings/emailTemplates`]: {
    get: getEmailTemplates,
  },
  [`/api/v${parseInt(pkg.version, 10)}/settings/emailTemplates/{type}`]: {
    get: getEmailTemplate,
    put: updateEmailTemplate,
  },
  [`/api/v${parseInt(pkg.version, 10)}/settings`]: {
    get: getUserSettings,
    post: updateUserSettings,
  },
  [`/api/v${parseInt(pkg.version, 10)}/settings/crm`]: {
    post: addCRM,
    get: getCRMList,
  },
};

module.exports = settingRoutes;
