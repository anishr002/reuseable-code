const pkg = require('../../package.json');

const createPolicy = {
  tags: ['PrivacyPolicy'],
  description: 'Create a new privacy policy',
  summary: 'Create a new policy',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                title: {
                  type: 'string',
                  description: 'Policy Title',
                  example: 'GDPR',
                  required: true,
                },
                isActive: {
                  type: 'boolean',
                  description: 'Policy is active or not.',
                  example: true,
                  required: true,
                },
                subRules: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      name: {
                        type: 'string',
                        description: 'The name of the sub-rule.',
                        example: 'Rule Name',
                        required: true,
                      },
                      description: {
                        type: 'string',
                        description: 'The description of the sub-rule.',
                        example: 'Rule Description',
                      },
                      isActive: {
                        type: 'boolean',
                        description: 'sub-rule is active or not.',
                      },
                    },
                  },
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    201: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 201,
                message: 'Policy is Created',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Policy title is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Policy not found',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Privacy Policy Already Exists',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: 'Policy already exists',
              },
            },
          },
        },
      },
    },
  },
};

const updatePolicy = {
  tags: ['PrivacyPolicy'],
  description: 'Update privacy policy',
  summary: 'Update policy',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectPolicyId',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                title: {
                  type: 'string',
                  description: 'Policy Title',
                  example: 'TEST',
                  required: true,
                },
                isActive: {
                  type: 'boolean',
                  description: 'Policy is active or not.',
                  example: true,
                  required: true,
                },
                subRules: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      id: {
                        type: 'string',
                        description: 'The id of the sub-rule.',
                        example: '65eb1160d78cfbcf79f416f7',
                        required: true,
                      },
                      name: {
                        type: 'string',
                        description: 'The name of the sub-rule.',
                        example: 'Rule Name3',
                        required: true,
                      },
                      description: {
                        type: 'string',
                        description: 'The description of the sub-rule.',
                        example: 'Rule Description',
                      },
                      isActive: {
                        type: 'boolean',
                        description: 'sub-rule is active or not.',
                      },
                    },
                  },
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Policy is Updated',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Policy title is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Policy not found',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Privacy Policy Already Exists',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: 'Policy already exists',
              },
            },
          },
        },
      },
    },
  },
};

const deletePolicy = {
  tags: ['PrivacyPolicy'],
  description: 'For all types of admins: Delete policy',
  summary: 'Delete policy',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectPolicyId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Policy is deleted',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Policy not found',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Conflict',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: "Policy can't be removed.",
              },
            },
          },
        },
      },
    },
  },
};

const getPoliciesList = {
  tags: ['PrivacyPolicy'],
  description: 'Get list of policies',
  summary: 'Get list of policies',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      $ref: '#/components/parameters/sortByPolicy',
    },
    {
      $ref: '#/components/parameters/orderBy',
    },
    {
      name: 'active',
      in: 'query',
      description: 'Record active',
      type: 'string',
      example: 'yes',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  policy_list: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        _id: {
                          $ref: '#/components/schemaProps/UniqueId',
                        },
                        title: {
                          type: 'string',
                          description: 'Policy Name',
                          example: 'GDPR',
                        },
                        sub_rules: {
                          $ref: '#/components/schemaProps/PolicySubRules',
                        },
                        active: {
                          $ref: '#/components/schemaProps/RecordStatus',
                        },
                        created_at: {
                          $ref: '#/components/schemaProps/createdAtDate',
                        },
                        updated_at: {
                          $ref: '#/components/schemaProps/updatedAtDate',
                        },
                      },
                    },
                  },
                  page_info: {
                    $ref: '#/components/responses/paginationResponse',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Size must be greater than or equal to 1',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const privacyPolicyRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/privacy-policies`]: {
    get: getPoliciesList,
    post: createPolicy,
  },
  [`/api/v${parseInt(pkg.version, 10)}/privacy-policies/{id}`]: {
    put: updatePolicy,
    delete: deletePolicy,
  },
};

module.exports = privacyPolicyRoutes;
