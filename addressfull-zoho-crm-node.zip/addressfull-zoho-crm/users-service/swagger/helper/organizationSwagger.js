const pkg = require('../../package.json');

const getTrustedOrganizations = {
  tags: ['Organizations'],
  description: 'Listing of Top Trusted Organizations',
  summary: 'Listing of Top Trusted Organizations',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/search',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'id',
      in: 'query',
      description: 'Enter Organization Id',
      type: 'string',
    },
    {
      name: 'lat',
      in: 'query',
      description: 'Enter latitude',
      type: 'string',
      example: '40.7128',
    },
    {
      name: 'lon',
      in: 'query',
      description: 'Enter Longitude',
      type: 'string',
      example: '-74.0060',
    },
    {
      name: 'miles',
      in: 'query',
      description: 'Enter miles',
      type: 'string',
      example: '5',
    },
    // {
    //   name: 'is_trusted',
    //   in: 'query',
    //   description:
    //     'Default value is true. Pass false if searching with all the orgabizations and pass nothing if searching with trusted organizations',
    //   type: 'boolean',
    //   example: true,
    // },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: {
                  organization_list: [
                    {
                      id: '6571ac1a2319c241b7907e7a',
                      organization_profile_image: `${process.env.PROTOCOL}://172.16.2.200:3005/uploads/profilePictures/orgprofile_1702892675369_213052.jpg`,
                      organization_name: 'Dementia UK',
                      shared_data_count: 8,
                      QR_image:
                        'iVBORw0KGgoAAAANSUhEUgAAAKQAAACkCAYAAAAZtYVBAAAAAklEQVR4AewaftIAAAYbSURBVO3BQY4cSXAAQfdE///LLh7jogIKPcNNSmFmf7DWJQ5rXeSw1kUOa13ksNZFDmtd5LDWRQ5rXeSw1kUOa13ksNZFDmtd5LDWRQ5rXeSw1kUOa13kw5dU/qaKJypTxRsqU8WkMlU8UZkqnqhMFd9Q+ZsqvnFY6yKHtS5yWOsiH35YxU9SeaIyVUwqU8WkMlVMKm+oTBWTylQxVUwqb1Q8qfhJKj/psNZFDmtd5LDWRT78MpU3Kt6oeFIxqUwVk8o3KiaVJypTxZOKSeUbKm9U/KbDWhc5rHWRw1oX+fD/nMobFU9UnlQ8UXmj4v+Sw1oXOax1kcNaF/nwj1OZKv4mlaliUplU1v/usNZFDmtd5LDWRT78sorfVDGpTBVTxTdUpoonFZPKGxWTypOKNypucljrIoe1LnJY6yIffpjK36QyVUwqU8WkMlVMKlPFpDJVTCpTxaQyVUwqU8Wk8obKzQ5rXeSw1kUOa13E/uD/EZU3KiaVqWJSeVIxqTypmFSmiv9LDmtd5LDWRQ5rXeTDl1SmikllqphUpopJZap4ojJVTBXfqJhUpoo3Kv5LKlPFE5Wp4icd1rrIYa2LHNa6yIfLVUwqU8VU8Q2VqWJSeaIyVUwqP0nljYqpYlJ5UjGpTBXfOKx1kcNaFzmsdZEPf5nKGypPVL5RMVVMKlPFNyomlaniDZUnFU9U3lD5TYe1LnJY6yKHtS5if/CDVKaKv0nljYpJ5Y2KSWWqeENlqniiMlX8yw5rXeSw1kUOa13kw2VUnlRMKlPFpDJVPKmYVKaKSWWqmFSeVEwVb1RMKk8qJpWpYlKZKn7TYa2LHNa6yGGti3z4kspUMak8qXhSMak8UfmGyhOVqeJJxROVJxVPVKaKSeVJxaTyhspU8Y3DWhc5rHWRw1oXsT/4gsobFZPKVDGpPKmYVKaKJypTxaQyVUwqU8WkMlU8UXlS8V9SeVLxjcNaFzmsdZHDWhf58KWKJyqTyhOVqeI3VUwqU8WkMlVMKj+pYlJ5o2JSeVLxpOI3Hda6yGGtixzWusiHL6lMFW9UTCqTypOKJypPKt6o+IbKT6qYVCaVqeINlTcqvnFY6yKHtS5yWOsiH75U8Zsq3qiYVKaKSeUnVUwq31CZKn6TypOK33RY6yKHtS5yWOsi9gdfUHmjYlL5RsWkMlX8S1SmiicqU8UTlScVT1SeVHzjsNZFDmtd5LDWRT58qeKJyhsVT1TeUHmjYlJ5UvFE5SepPFGZKqaKSeUbFT/psNZFDmtd5LDWRT78soo3VJ5UTCpTxROVqWJS+YbKk4pJ5TepTBVTxaQyVUwVv+mw1kUOa13ksNZFPvwwlZ9UMalMFZPKk4pJ5Y2KNyr+SxVvVDxReVLxjcNaFzmsdZHDWhf58CWVqeKJylTxROWJyhsqU8WkMlVMKlPFT6qYVKaKN1TeqPgvHda6yGGtixzWusiHL1VMKlPFE5WpYqqYVJ5UTCpTxaQyVfxNFZPKVPFE5Y2KSeUbFT/psNZFDmtd5LDWRT58SWWqmFSmiicqP6niScWk8o2KJypTxd+k8pNUpopvHNa6yGGtixzWuoj9wT9MZaqYVJ5UPFF5o+I3qTypeENlqnii8qTiG4e1LnJY6yKHtS7y4Usqf1PFVDGpTBWTyqTyRsWk8kRlqphUpopJ5RsqU8XNDmtd5LDWRQ5rXeTDD6v4SSrfUJkq3lB5UjGpvFExqTypmFSeVPxLDmtd5LDWRQ5rXeTDL1N5o+INlaniGypTxaQyVfykim+o/MsOa13ksNZFDmtd5MM/rmJSeVLxpGJSeaIyVUwqT1SeVDypeEPlicqTiknlJx3WushhrYsc1rrIh3+cylQxqUwqb1Q8UflNKk8qflLFpPI3Hda6yGGtixzWusiHX1bxmyq+UfFE5UnFpPKTKr6hMlVMKk8qJpWp4icd1rrIYa2LHNa6yIcfpvI3qfyXVJ5UTCpTxaQyqXyj4hsqT1Smim8c1rrIYa2LHNa6iP3BWpc4rHWRw1oXOax1kcNaFzmsdZHDWhc5rHWRw1oXOax1kcNaFzmsdZHDWhc5rHWRw1oXOax1kf8BhBfzaqhgK68AAAAASUVORK5CYII=',
                    },
                    {
                      id: '65799a65ca113ff38973b04d',
                      organization_profile_image: `${process.env.PROTOCOL}://172.16.2.200:3005/uploads/profilePictures/orgprofile_1703768583491_516422.jpg`,
                      organization_name: 'University of London',
                      shared_data_count: 0,
                      QR_image:
                        'iVBORw0KGgoAAAANSUhEUgAAAKQAAACkCAYAAAAZtYVBAAAAAklEQVR4AewaftIAAAYWSURBVO3BQY4cy5LAQDJQ978y5y19lUCiuqX4Gjez/7DWJQ5rXeSw1kUOa13ksNZFDmtd5LDWRQ5rXeSw1kUOa13ksNZFDmtd5LDWRQ5rXeSw1kUOa13kw5dU/qSKJypTxROVNyomlTcqJpWpYlKZKt5Q+ZMqvnFY6yKHtS5yWOsiH35YxU9SeaPiico3VKaKJypPKp5U/KSKn6Tykw5rXeSw1kUOa13kwy9TeaPiDZWp4o2KSWWqeKIyVUwVk8pUMalMFU9Upoo3VN6o+E2HtS5yWOsih7Uu8uEfo/KNikllqpgqJpWp4onKVDGpPKn4lxzWushhrYsc1rrIh39cxROVJxWTylQxVUwqU8Wk8qTi/5PDWhc5rHWRw1oX+fDLKv6kikllqvhNKm9UTCpTxW+quMlhrYsc1rrIYa2LfPhhKv/LKiaVqWJSmSomlScqU8WkMlVMKlPFE5WbHda6yGGtixzWuoj9h/9hKlPFGypTxROVqeINlaliUpkq/j85rHWRw1oXOax1kQ9fUpkqJpWfVDFVTCpPKp6o/EkqT1SeVDxR+UkVv+mw1kUOa13ksNZF7D9cRGWquInKNyomlaliUpkq3lCZKr6hMlX8pMNaFzmsdZHDWhf58MtU3qiYVJ5UvKHypOJPqnhS8UTlScWkMlVMKn/TYa2LHNa6yGGti3z4YSpPKiaVSWWqeKIyVUwqU8UbKk8qnqhMKlPFpDJVTCpTxaTypOJmh7UucljrIoe1LmL/4RepTBWTylQxqXyjYlJ5UvFEZaqYVH5TxaTypGJSmSqeqEwVk8pU8Y3DWhc5rHWRw1oX+fDDVKaKN1SmiknlDZWp4g2Vv6liUpkqJpVJZap4ovJE5Tcd1rrIYa2LHNa6iP2HL6hMFW+ovFHxRGWqmFSeVLyhMlVMKlPFpDJVvKEyVUwqb1RMKk8qftJhrYsc1rrIYa2LfPhhKj+p4onKNyqeqHyjYlKZKiaVqWJSmSqeVEwqU8Wk8jcd1rrIYa2LHNa6yIfLVEwqb1RMKlPFpPKk4onKpPKk4knFpPKGylTxROUmh7UucljrIoe1LvLhSxVPVJ5UTCpTxaQyVUwqb1RMKm9UfENlqnhDZaqYVKaKb6j8psNaFzmsdZHDWhf58CWVJxWTypOKSeUmKk8qJpWp4onKk4pJ5V9yWOsih7UucljrIh++VPGbKp6oPKl4ojJVvFHxN1U8qXiicpPDWhc5rHWRw1oX+fDDVN5QmSomlaliqphUJpUnFZPKk4onKm9UvKHyRsU3KiaV33RY6yKHtS5yWOsiH76kMlVMKlPFE5WpYlKZKv4mlaniico3Kr6hMlW8UTGpTBXfOKx1kcNaFzmsdZEPf5jKGyrfqJhUnlQ8UZkqJpWpYqp4ojJVPFGZKp5UPFF5o+InHda6yGGtixzWusiHP6ziicpUMalMKlPFpPJEZaqYVKaKSWWqmFSmiknlGxVPVN6omFSmikllqvjGYa2LHNa6yGGti3z4ZRXfUJkqJpWfpDJVTCpvVLxRMalMFZPKT1KZKiaVqeInHda6yGGtixzWusiHL1X8pIpvqEwVf5PKk4pJZap4o+INlScqT1Smim8c1rrIYa2LHNa6yIcvqfxJFVPFpPJE5UnFpPKk4o2KN1S+oTJVPKn4mw5rXeSw1kUOa13kww+r+EkqT1Smijcq3qh4ojJVTCpTxZOKSeWNijdUvlHxjcNaFzmsdZHDWhf58MtU3qj4k1R+UsWTiknlicpUMalMKt+oeEPlJx3WushhrYsc1rrIh3+MypOKN1QmlW9UvFExqbxRMam8ofInHda6yGGtixzWusiHf0zFpPJE5UnFN1TeqHij4onKVPFE5UnFbzqsdZHDWhc5rHWRD7+s4jdVTCpTxZOKSWVSmSreqJhUnqhMFU9UvqFyk8NaFzmsdZHDWhf58MNU/iSVqWJSmSreqJhUpopJZap4o+InVUwqU8Wk8kRlqvhJh7UucljrIoe1LmL/Ya1LHNa6yGGtixzWushhrYsc1rrIYa2LHNa6yGGtixzWushhrYsc1rrIYa2LHNa6yGGtixzWusj/AcDh7HRzeMt+AAAAAElFTkSuQmCC',
                    },
                  ],
                  page_info: {
                    total_count: 2,
                    total_pages: 1,
                    current_page: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getMyTrustedOrganizations = {
  tags: ['Organizations'],
  description: 'Listing of My Trusted Organizations',
  summary: 'Listing of My Trusted Organizations',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/search',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'id',
      in: 'query',
      description: 'Enter organization id',
      type: 'string',
    },
    {
      $ref: '#/components/parameters/timezone',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: {
                  request_count: 1,
                  shared_count: 2,
                  organization_list: [
                    {
                      id: '6570510f1ce1df028849fe92',
                      organization_profile_image: `http://localhost:3005/uploads/profilePictures/profile_picture-1701859681576.jpeg`,
                      organization_name: 'HSBC',
                      shared_data_count: 6,
                      shared_email_address: [1, 2],
                      shared_mobile_number: [1, 2],
                      shared_address: [1, 2],
                      shared_social_data: {
                        linkedin: '',
                        twitter: '',
                      },
                      shared_data_timestamp: '31/01/2024, Wednesday',
                      QR_image: null,
                    },
                  ],
                  page_info: {
                    total_count: 1,
                    total_pages: 1,
                    current_page: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getMyBlockedOrganizations = {
  tags: ['Organizations'],
  description: 'Listing of My Blocked Organizations',
  summary: 'Listing of My Blocked Organizations',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/search',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },

    {
      name: 'sort_by',
      in: 'query',
      description: 'Enter field name to sort (updated_at)',
      type: 'string',
      example: '',
    },
    {
      name: 'order_by',
      in: 'query',
      description: 'Enter sort type (asc | desc)',
      type: 'string',
      example: '',
    },
    {
      $ref: '#/components/parameters/timezone',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: {
                  organization_list: [
                    {
                      organization_id: '658910cb17e0fc4809b0c5e7',
                      organization_name: 'Test Janavi Organization',
                      organization_profile: `${process.env.PROTOCOL}://172.16.2.200:3005/doc/65890f8ae409d08326571b3e$profile_picture-1703481546137.jpg`,
                      block_reason: 'Unwanted organization',
                    },
                    {
                      organization_id: '6571ac1a2319c241b7907e7a',
                      organization_name: 'Dementia UK',
                      organization_profile: `${process.env.PROTOCOL}://172.16.2.200:3005/doc/6571ac192319c241b7907e76$dementia.jpg`,
                      block_reason: 'Unwanted organization',
                    },
                  ],
                  page_info: {
                    total_count: 2,
                    total_pages: 1,
                    current_page: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getOrganizationProfile = {
  tags: ['Organizations'],
  description: 'Get Profile of Truted Organization',
  summary: 'Get Profile of Truted Organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
    {
      $ref: '#/components/parameters/timezone',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                description: 'Status Code',
              },
              data: {
                type: 'object',
                properties: {
                  id: {
                    $ref: '#/components/schemaProps/UniqueId',
                  },
                  organization_profile_image: {
                    type: 'string',
                    description: 'Profile image url',
                    example: `${process.env.PROTOCOL}://172.16.2.200:3005/uploads/profilePictures/amazon_logo.png`,
                  },
                  organization_name: {
                    type: 'string',
                    description: 'Organization name',
                    example: 'Amazon private limited',
                  },
                  organization_website: {
                    type: 'string',
                    description: 'Organization website',
                    example: 'www.twitter.com.au',
                  },
                  email_id: {
                    type: 'array',
                    items: {
                      type: 'string',
                      description: 'Email Id',
                      example: 'amazon@gmail.com',
                    },
                  },
                  mobile_number: {
                    type: 'array',
                    items: {
                      type: 'string',
                      description: 'Mobile Number',
                      example: '1234567891',
                    },
                  },
                  address: {
                    type: 'string',
                    description: 'Organization address',
                    example: 'Test Street',
                  },
                  // is_trusted: {
                  //   type: 'boolean',
                  //   description: 'Organization status',
                  //   example: 'true',
                  // },
                  is_trusted: {
                    type: 'boolean',
                    description: 'If the organization is trusted by the user',
                    example: 'true',
                  },
                  shared_email_address: {
                    type: 'array',
                    items: {
                      type: 'number',
                      description: 'index of shared data',
                      example: '1',
                    },
                  },
                  shared_mobile_number: {
                    type: 'array',
                    items: {
                      type: 'number',
                      description: 'index of shared data',
                      example: '1',
                    },
                  },
                  shared_address: {
                    type: 'array',
                    items: {
                      type: 'number',
                      description: 'index of shared data',
                      example: '1',
                    },
                  },
                  shared_social_data: {
                    type: 'object',
                    properties: {
                      linkedin: {
                        type: 'string',
                        example: 'linkedin',
                        description:
                          'When shared: "linkedin" | When nor shared: ""',
                      },
                      twitter: {
                        type: 'string',
                        example: 'twitter',
                        description:
                          'When shared: "twitter" | When nor shared: ""',
                      },
                    },
                  },
                  shared_data_timestamp: {
                    type: 'string',
                    description:
                      'Time stamp of shared data in "DD/MM/YYYY, day"',
                    example: '31/01/2024, Wednesday',
                  },
                  QR_image: {
                    type: 'string',
                    format: 'base64',
                    description: 'Base64 encoded QR image',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Organization not found',
              },
            },
          },
        },
      },
    },
  },
};

const shareDataToOrganization = {
  tags: ['Organizations'],
  description: `Share Data to trusted organizations. <br>
    <br> <b>Domentia UK:</b> 6571ac1a2319c241b7907e7a 
    <br> <b>Test Janavi Organization</b>: 658910cb17e0fc4809b0c5e7 
    <br> <b>Universily of London</b>: 65799a65ca113ff38973b04d 
    <br> <b>Amazon:</b> 6581634c540049c13687a87d 
    <br> <b>IBM:</b> 659d1ebf4e51998cee0aa139 
    <br> <b>Organization 100:</b> 65c4ba0f743b9da9b65ec692 
    <br> <b>Organization 101:</b> 65c4bc57743b9da9b65ec6fb 
    <br> <b>Organization 101:</b> 65c4bc57743b9da9b65ec6fb
    <br> <b>Organization 102:</b> 65c4bda8743b9da9b65ec761
    <br> <b>Organization 103:</b> 65c4be8e743b9da9b65ec7c3
    <br> <b>Organization 104:</b> 65c4bf52743b9da9b65ec81d
    <br> <b>Organization 105:</b> 65c4c042743b9da9b65ec875
    <br> <b>Organization 106:</b> 65c4c11d743b9da9b65ec8d5
    <br> <b>Organization 107:</b> 65c4c19f743b9da9b65ec92f
    <br> <b>Organization 108:</b> 65c4c24e743b9da9b65ec98c
    <br> <b>Organization 109:</b> 65c4c2cb743b9da9b65ec9d6
    <br> <b>Organization 110:</b> 65c4c366743b9da9b65eca2c
    <br> <b>Organization 111:</b> 65c4c40d743b9da9b65ecab4
    <br> <b>Organization 112:</b> 65c4c5c900b1e7eeb4253f13
    <br> <b>Organization 113:</b> 65c4c65600b1e7eeb4253fa1
    <br> <b>Organization 114:</b> 65c4c70000b1e7eeb4254065
    <br> <b>Organization 115:</b> 65c4c79100b1e7eeb42540bb
  `,
  summary: 'Share Data to trusted organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            shared_data: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  type: {
                    type: 'string',
                    description: 'Label of shared data',
                    example: 'email1',
                  },
                  value: {
                    type: 'string',
                    description: 'Value of shared data',
                    example: 'test_email1@gmail.com',
                  },
                  old_value: {
                    type: 'string',
                    description: 'Previous of updated shared data',
                    example: 'test_email_prev1@gmail.com',
                  },
                },
              },
            },
          },
        },
        example: {
          organization_id: '6571ac1a2319c241b7907e7a',
          shared_data: [
            {
              type: 'firstName',
              value: 'James',
              old_value: 'Robert',
            },
            {
              type: 'lastName',
              value: 'Smith',
              old_value: 'Taylor',
            },
            {
              type: 'mobileNumber1',
              value: '65|1111111111',
              old_value: '65|111111110',
            },
            {
              type: 'mobileNumber2',
              value: '65|2222222222',
              old_value: '65|0222222222',
            },
            {
              type: 'mobileNumber3',
              value: '65|3333333333',
              old_value: '65|0333333333',
            },
            {
              type: 'mobileNumber4',
              value: '65|4444444444',
              old_value: '65|0444444444',
            },
            {
              type: 'mobileNumber5',
              value: '65|5555555555',
              old_value: '65|0555555555',
            },
            {
              type: 'email1',
              value: 'test_email1@gmail.com',
              old_value: 'test_email_prev1@gmail.com',
            },
            {
              type: 'email2',
              value: 'test_email2@gmail.com',
              old_value: 'test_email_prev2@gmail.com',
            },
            {
              type: 'email3',
              value: 'test_email3@gmail.com',
              old_value: 'test_email_prev3@gmail.com',
            },
            {
              type: 'email4',
              value: 'test_email4@gmail.com',
              old_value: 'test_email_prev4@gmail.com',
            },
            {
              type: 'email5',
              value: 'test_email5@gmail.com',
              old_value: 'test_email_prev5@gmail.com',
            },
            {
              type: 'address1',
              value: '123 Main Street, London, SW1A 1AA, United Kingdom',
              old_value:
                'Prev: 123 Main Street, London, SW1A 1AA, United Kingdom',
            },
            {
              type: 'address2',
              value: '456 Elm Road, Manchester, M1 2NE, UK',
              old_value: 'Prev: 456 Elm Road, Manchester, M1 2NE, UK',
            },
            {
              type: 'address3',
              value: 'Flat 3B, 789 High Street, Birmingham, B4 5CD',
              old_value: 'Prev: Flat 3B, 789 High Street, Birmingham, B4 5CD',
            },
            {
              type: 'address4',
              value: '101 Park Avenue, Bristol, BS1 6EH, Avon, United Kingdom',
              old_value:
                'Prev: 101 Park Avenue, Bristol, BS1 6EH, Avon, United Kingdom',
            },
            {
              type: 'address5',
              value:
                'XYZ Company Ltd. 555 Industrial Estate, Newcastle upon Tyne, NE1 7RP',
              old_value:
                'Prev: XYZ Company Ltd. 555 Industrial Estate, Newcastle upon Tyne, NE1 7RP',
            },
            {
              type: 'linkedin',
              value: 'https://linkedin.com/jshdbsahbc/profile',
              old_value: 'https://linkedin.com/jshdbsahbc/profile/old',
            },
            {
              type: 'twitter',
              value: 'https://x.com/hsdcshdc/profile',
              old_value: 'https://x.com/hsdcshdc/profile/old',
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
        examples: {
          exmaple_local: {
            value:
              'bqEe+FhnNg+e+LEAt7ROG61OYwFEik0H7fmQ8i3xbFhHb3wXERabbHoLxoN4v0QW2i6AE0/HHb1qvg23DNAOrMu+ig+yyoQCtKCbJ8aec7+acedvdaaGSUr02ICJhpiRFAXj+dDN/wjdnVupYvAGm4FvPBNGsks1/rLD6uSf7sbKjL4nEBtmWwF9FyTHQ22D6Te/t8jklTSZdO0RkgDWmRxAXCGIa2j/SHp1qfbu7GnQC+nSgH0Gjbn/RzYvgM1R5oWPb8pJTUgtYN4DKD4zA39L3S1veOOn9iyejBD0DvFyI1hfglriAAl90Q//yFc1USjRJTwMXlRgGYgGQxG2imXHahnQ5HsYTdakHBGq4jymGy+cBGjl/XI6C0C2pgt9mcKC6TUgYhaqiYvEAMbBDQ4ThvBJvFMpLx3D/1PyeOpgsCA18GC/GxW5LDYwNCmNOpHdrIa/iQAtXbh5WTeVm4QvAh1DoJmsGqa1GfMuOyGy+QjCHRoqLW/sJfd4lTaAIO+ROFdwTtk8oYnp0aKpBgcGvkn8jGDWtdNAzyFtbZvI4pEoU/sZsUH4MRJUnQDeB6MsBYBiwgjucOenf4NJecw0JP/tG0qCasJjX1svEhpelwW4QXpwQWYO3VeqLne+gbzhi2yHeoliF9Kkb17X0+6m/ZcQP+6ZNi05iEkgGrRe0JZjpBOxE7R9UdcQg96WtptWJqw2kOUeseP15onNQzaH41dljHg8vPTzpEBy1txD6CZojLlDghVMUh6zzi80UzB3c21iocgi4OEnlM1l/zx7cwrDP3ioev0jqch0EaKdhn6uU5noIiRl6JerHm+shQp3ZGkV7BMPlb8/HWO8l876dxBmJaiDPg3mzpT7NvCXCXymqEuY+Ku8MSB9xOeU4Wrz8ceK2gGR//hwss5otYz87t/WFM0w+TfIwVxGP2D9LVWp/i13N03XjrS6P2l+RKU+JvE+7BR1jVcqRpGqF/mjagYInb5iGMLsWwSNToWlT22Tr2BMGPMHfRpHpkUYOzixUDNl1y29D0Vftn2lBYr3v0rJYiX/eA/IZN4+k+a3Wr8Q494yB0pqd9ash6PkZO785GZlxRr1wxX7UQpdcG8nIiCL8ESUh5fT3EaUC3Mf1bFaf/6GBgiCVT2z+klZCxYZmGlTTyeS4OrJ91zD84f8CInIKV/wyqTNpSxA5NLjb+NMTe89h+lgDkzMq4jaDk1SqOhx3tEFxc4S/AYrmh/OY1prfHbuQdm/f34fuO6dvOFa9OU1l2GbjSFLTQMc1fmDFDWmudvoBI3D5OZ2htvNTbTfxDGXC4ONHUXKwv64YCcshnFM8kwWUvcP7jMOJjxcHK+gH4/m/ZXH2R3b/TD+eVcuZR2YypE80L7MkPFXOrUknqmT2L6ImseYNfdE5RYAmqHuC1okPsc2vPzQIugU1Ee+NQXwPY3j0WHGzL2ZEZqRuGu9urnRrWlgaC4D5GRuCgMGr9v1neAoPSuW1qvlMsUYd0NhItm8RJrZw4waY3AbB0XDwfPHNO1P/TxSReSh+058YhMMBaXvm9AMEu6zlc/bXZjpMbPu1iCisHsBSEdWEOn+u88lzdABAdeBzW3sEP3npRtt/tt/jh48Bt9ROaGgIZaeN1mRwB8XZI2sB0niSPUDIpfbfv99gKEVOeNJo8E7SMORKO5ic4nVeWTCVKhZuygtrN5U+7xpHFA1QdINun7zMuZVCBiGQW/VdooJRIfQTa9vmycGgx7BHXHMOYOrGdYsy1wHBiasTCyLD7WpOGPmtyFUaXGdVBP8iKqfoTSP0jlUqMJ2zz+Zh8z5ht35NF2TmcS8cmkPPl2ACJVPex9ZXsIkM9X01rcRu/2p3a2hoDY9v4vROCLB41LzBa8T3Pprygp5X4Bf/owRJ5KgIeSrJicVVahDeuksPQ4p1hhttJUJlRXrIJcQZEaybpl2ULljplSQlBpkrtIJ82FSr0qv/xI25TsfKMSVnK/Q/W05n9gR0NYu/Ho26KEi+1svQo6YfH4kp90dnn04hEvGJ/BaRrZf7w4CH4Oody1ytuhfEyRI6rQ5DnZ2ZV3GN3aunh4nndsJe5p8kHfWeOJasiWmK5n1lkkCmgPT29T/Dyq15+ANjWLzJt3OnZHGbQDC2NNx5aFAiDI222zHWJaIdFfoU+9z1P4dbDSY453p0t2ZyAHKdGWkBj9F7aJfJ/u8S5MgNtNjDoUfxDAA/P7YZHcRBxCoH5khMpIg7NwlWzP+O8jGz6f8SAAHQc+qFEW6oU6xQZ4NW6l4GDKqrQA7SY+LtYDa/nSStIXOsGW1ZxuszQQVg6Bv1i30KFOsKw922WNhX3GMelgJu04UoHa1mc/U0GYgOSS2ffFava+AbSVU1S/9wshm2dejrHJzgpWo4fEuc1Fqbo9HKF5g/xSgV32I/2/J1UvOTdqg1tJAWfV84kAT5i0TOaThWl0ES4tX9v4Thjglrlz53XbTm0s/MEF49++qT/BrbTFt|aOXUZKV8PnCnJw/MqY/OJwk3SQ87ZTqV6ZjBj72t4l6SneIxNRreiS/8YbBWFDc+0zqqZy38c/yua5elT/eKy2Jc+h8R0iDYm+rdvA7otCvmyKAvGgqD6iLRIfieDBFwEe0iSW8CUvYsSfunCO/eDoZrs4/rOIJDCbYcMj/J8LxIlgTQRtAMFBHVMpudYkOUeuXFCFrotCetGVoOM6HWhhbWqqYy+3OJ5YI6PejqDdtiI57ti8YRjAk5WmP4i6OCi8m4DKcYDzn8ahM4bCjvR6gB8u3SZ00Q7MlB+QfGCNjzmQ5Q/9ozh+8iuf414FmOeaFy/nDpOhmA9gyUUOsIW9uatSWYa/g0Yu2VT4VpssIcGIikGe5eqp5TiPak0qeuuT/JF7K2l4P84zsGUEJHU9+1auwAV4/E93ubkJAMhP9/sIYnps5zUVCFZ88/06zObJFVyFtNG1XO23q+BhwDLD67xzJvGjwPf27GLPXJB/C7pH50f26HNNI8I0xAIU4MNgU6CGeC5xaj80ZZs5syKoHVghFxIuvZ4tDeKcTrqKkMAoFIp947v2VFwVQbvGfJWfVBOQ+/z91tgQAAVohY2iyFzm4XJW65ASYyTpKeUZIIKY+pbfdF7lDtrjfXubzapUzMRB89A5vWbyANel2fgszlTMAeX6OeNXOISYMRWCs=|Yops08CrfvKTkWnHfULS4CKx4eJ8NbzznxGKR9hvD33U+VS0azgYX61Zd/ZYCXrAluXRzNkYUjfbn2FTX8jiQPtniOEJ4Z3x4+LHBfADE5ZSe4xACWDtCiNb+v7/HFoYvHZSGpPbu81mcyLJsi0APBVcUrnSpRDpPMJkvRZV4kfGo8EFp9MiEx0GGhQstQ1SdQ+arcKW8QBbtrttoapPziCxKH2TAS6T+ZIze8/wdZTBBVjaozjpcOq+rxAT8CCgau8k4Dqcm2hzdM1/wNp5QvE5e32TCXBsOt5deb/DQrkfbrZhutn5GdjHoGN18Nr12SSvhOWpYldnCzxan8WUIFsE/rkQkZkHMQdb9P2xcHZ7iY1v0wR6dim5EFiGWkoLTo4op3/QouD+2mWcdxmDn5lRZ0koXODs4es4lRu13TwEGNhCHc3tm/dZD5iKBmuvppqO6eVeYhBShHBTv9zKWE5qLXzhjmDDtQy8DHtj1FjcUwYXLSmMJybawoj/H5x/iKh9b6tYsbrIzvAHHg0KeNenJLBWmlQ8dExFh0IFkz9j0EiyA7PiRZVmo9OzUlOtfoaZPZPtdVKDOFEva1RCr3ciwgB13gObKhG2ZQnz/c0fVjLclFPcPM4kszwaXPPM1M23bq7WzuGmMruFyj7Oyp//zZ/X1pLx3FEO17V62is=',
          },
          exmaple_dev: {
            value:
              '9D6yLTGjKTOpGhrJZHAcbGDO9gvJTASmCUpNix+MxpQdBDfJ2wfnkILz8/cN0ZJZyMWJrHfy4mf+BbAhHrft6z922+7PLFf3jeUZF070+vuZuPn69/mf+fZoQHQbK3FEjD5Fxbk8cboLVMTExJH02o/sCJswZLlg/LAqhjK9cfrcly6BvfICIJV5G0tLonaow+28DayERDeUXkXfmzEOOPWxEhDbxbb4lSyTDMsbgDRg/Mw7bBprKNP1EIC4BJEiXTahOjI2Uyqlz3InkpUNlgCg9Fbv41YBteYKPJTXVisq3vVmNj8alB/T74KuGynTYgJQaNHvXuwcMPAve2I59kMRNNGvOv5fu4KT/j9iKSpRj26ia8qZyRKmQKflNt3Pk63nEu/6L5lMCgEFMNMWHYq+z6321Jjdq29QS0g+ZZc4A9K5gapRbPp8NKx+wzWujsvIT7aJZ42Oy5rmYqyUJB7m51ErTMhtfdUnneWzae90z2xKb06+dibRW09YECp4mtwhs/skR2Uq3LLKeFhWm0eaQOgJKyG9Tus9MuxNcxFsU9BH9XejqubthLflcZbtL1h0hIL8JpvqxKoVR4z9CX5NQVzqVN94YpSDgS2+oaqyG3clMER9mUeKTuF1fsa+lE9CYTGvaUpIsjcHemjUVpaxfBNUzHrjFzZpijg6DJg5iWLGZaKLQCnW1uGga3AAuj0vayQtT+5/ztf6orRY3qW0289qgx6toJ5s4uRySqYQmUACU80fOUsNsoY980dPmKY8B35wT0yqI48ZBnQWoGsCpWzN7ZzJ1Y6WWcXKeB6hHh8YJtGfv72P4Xmd6WYiKL0n625InkvZSrqiCMxI3x8KHccMUJcsLlpENIe2VsnUlJmldvWRedOXeDUQ4ULt03z8M2CMJvN3T+OhaaNxS1uJxWbQVH3XjqmkXfyozU8g1aprgSGlFd/Tko0C0EgrKxwA6kkToQ9E2vsKQ58IY05nwmHqaIWFo2eEVQxmMVg0oAl3LNpyNJ8y33k1oMhR32E1LYDwNJKiYwyZRiGEKa7R1ze9bBzaCpTPB/1gFU5qaQeRiXSmQm4Rq8uc664x6LF3NG95I3o0U56PiV7gpUx79wIak6R9YiAyQGrAk8cm767j1g02l+H2ylmm8onZ9J+u4VOceRjiBxQaAoNOINjcLoqjPA9gMd9CRKDXTN4DEFwYjBGIzDuROucD+pdQKtDJIzxHcdXOUzVmz7sJyFNlSL7tIueErOrI8qlp5Xm4FUGRePYSgPVL7UrToMzpzpg5ctYLw404ZC/e+TjaAM9uCESMnVYrLbNl/eij5TqyTGEO9Y1EkaiM+FWhN7gryU6s3PnMAHRd4NqJ0Kgz+cEjJ1sKXxz5PsN+3q5j5NysYlDcUkfEDBTJPp0s+Rz555TZybSu7syjXDUuRObf5ECpy1TZQArEmmw5cdBA/U6Rp1j6jUp82rdg9ZMh6jBIE9ZxEU0TQ6+qHVTYc2F6iELYjWN3skSkGfcaAkXR/GIDeYe+t3/O8AqKUrZ8ueVXGpkFuBfIF1spaj4nboVdEyQ18Lg9YL9TP3nl/qKPLqSBUmzioCiUrgoraKGHSsKoa1U9o7m5igsVQOOHADeNLOmCgInd+WIxQL8eRmPllXW6T2bLXP/RZ0cfKdh1xLgMCLoJ+4vpb6OTo6+hpU4COpaZN6+Cr6CX8wozee1i43ItsEU9ZwRohujmhNmAGg6RnNxH6UtipY/HptNwzxK0XEtVitegrWsDInNDzpjwM1xaL8Q0CHfkRRCP5LUGyXOrA1gI+j/Yzc2rQmpkcfmWo8X9yQ50wYIfmchZbqKYKLb5/4cwCVGNfLNnXTsxJUevPQNAhO/681UIVJmTFz2k4ZMY2Jcm88UkrDodscTkRy/XNJchyngyP10EQbSYmyjzvXlgBg4N5a1Zjpm++PBOYLeI1wl3yny8viOrVrwfdo/p9OL/5neXuD6slmc+OCuc+oYO2cnMeKiQQ6uH4o2nmR28IHSxdEUUJqvFqiJe+uz5gBW7X562mbKKesad8fg32sUFQyfCF5T9scrfdscq61RtSkkCFuZbsOFx0adlIKOneAe5CbZFdyR8MfuJ7ooWp5K29/KfYmaI+vK+y+uO/hwuipL8ENASKfGZls7fwoAbB0PLnW6F/8FZF5bbj8iMXkk/GJdZNG1JM2bPl7Q7AhAUCrtfosHWhbgpjYrmeLykUlHVJM+tu5CkIstzMUrW7GhsP2GTlAujbxZmA3cwgtCkyqobOFelfR639A3PWXXIpRsXyuSkueY2slxF99RPhhPs+PdgUZMVo86hde3s5HWQwETqfyIkeH5tNloGOOIJ1zqMwrEhzYFCLaLlnSpMG6nP6IKkMRGUP/TWyegCjtpyA5xDleopS9FfG2A+oH8aYyw05m/p6IM9hT6riMQ68Istttl4iZhd3rMqfI+Ayt9S4DoM8Iy3mFdfGRasxu0oihobBdXw0OTt81JT8ZcT|nB6XNw1JbnZiwMariBXBywn1Ga4gssF+hvoFvuVJq0uyJELU5YYt/El6IzLZvgW2FrXqtbXg4eTUbMIer+p8N4Z3s0yIvphWeP6VJZXNiB8g+JreyP4wXSafvF9dH/yLMVO+SgeQsy8kkjJnU4LzTnToWnQ94JhPKBlrWfoB15tz7JivqFqysVAzqqGtdezh9OXH5igcDvZiucmhqvlXqxW0aSsut3nbEq7C7xb8Lc9XAmRezUK9kJKTQlQpAhkJrOFuEHpZsaq5afCcTTINTri0NB12pjTrcVt7l2eed22p8+OmYhwh7rJ182m4sb59KREsMwWYY9UCUFxinZK1g6BHCiTDA0iDyJjcyZDqCS8wdsE1N9tgV4Yz1Um5z/tDF+jDTQEvb2P8EQSyoH2c9DV83YO/y/JI0Zmg7JWyiTTrbGdp9qAMCPx8ywFHHNkQOtGt4s/qZd+uIb4JPM8kqqTph9Espw19ykgoXJyUW3lEa24eUXj+wJxR0wLl/v2M9m1E80FqHn9q2fm9GDz39tVmxxi0T82hUNZOSNb5BJfcZez1xHd9/nn3JAEAemdlVEFSxpZd3QozuFnBqNrqB+pKjyynXCYzta5NpZsodzRJxAKTyJgrxZW4nugultAkGun6jfqn5eMTdY7VmpnOAA6WJ/2Vb199WPDWBhJRA20=|h5cUOWwf5f1ip0t8mSGi0h6QIQfLyWY4iRfiNy0c2ycqvVYNwbTU2P/6prW3FB3s156yjosloG3Ba+ylP9d3xRRcgJ54v0TGwjiMGneRNI5UzijECNlzpjgbxZQIyT/d9MrHxHHuhfhqF5yA1i6+euK37tSRc7CA8i+I99TsnQ0hmfSXj/8NW4IGSMW6TelkyELYwKMizuf8I6fW7hLtDtAAo239E+KOr6coXkmvpMuZaYuF3IWREjc4pT4/jAtIpJ68DZEkp9axJ7TBy/fzUKCp8Cy5/622q8PwQRnl73EzIlJB3M46Yr1TsovDebSR+d6DtgSb1oC0JeceBW8JzUGHoBl7IJOsuLq7gr7wiorKEym/B/+yebRoxdoWLeqkgTHamQXHfUx1sCXtdYKDlTgM3NOgocWId1JY93nE98XMMahU2ssy99VhrjoggM79h9gsy1s32PWQu8ihEuEPn6X2aBJhvNaBXKX06WaEW10ZgdgLjyqwbr+V0XepZDcqUS8jcIjDUg+KRWy8xK2N1njFS5Xl1so6pcqyooWhvmQdB1SCqilowy6OykQJkhXQPXVuhTb5ugaG526wBFkzCL7rVj4F2MlrLxieZU6Y2drOTUkO2Z+M5QJYEKno8l/c0FXg8jWjHVsy4AVQPrlOZn1f+XEw/R6U8qmpvh9QXlQ=',
          },
          example_production: {
            value:
              'o49EnuxmdLbVYt5DZRuEz+R06VQsJko70m5f7f2ECSOiHmh2uedkXUGxmRioCEUPMfP9CEZvCgSR13ZB+jorAm/MY9tbCdZUbIJPrph4S+QEEcZ6YZA5LuqCztY4GBCx|B9YHgDPkRvf9y4UEHlKrwBrWF6z2HhE02hXFhaIqfahDYLa4c6LvE3Ga6W+HNF6Gf59t7nJymql2QNQ6y3GPgLH+AhgnCXddJeDRjYZJ7w4onKCfHGqkW/hM3Nr5H7y0Sy4q6sQnORvbJuSbCb/oYBWAFygShmUdh0UKb/mjCMN6+72NxUhpDtAOxPsMYv9EX+LTqMvCeQOQwlFq0GujSWzwQOKF+2I0TLL7KGIejfdWhU8K/0CSHqCYE7n/GMb/2HcUlFeiUDTZofitXjKFz+zlPVUSemHUh7SNxwi5PQjKmM4BoU09bHfkh2187gT3T2vbyP86eYUGs4GaOJ5sdm4Yvar+OEmk5INm6QUl8sHUCR93TUu9KvAQvQTo+D5cep1+SOOpPHlc9rQVHWxj+Jg1qs1C2TiCSE/G8Wds8uSm0DwVvV/s2yGzpAySbYV9VOuAzngP7XQhDxsOdR/m8qnYqdka7+Ic2bNOsOFYnbV7cTb2OqR6lWk0Vqxpxd/auczs0Q7GR5uEXA2PTwXZ1QLg7M11IYeToE8qRTxLk6+HYXqnoaSEc7mE69v0Y3oGJXEF1z12TEDxFl5Tw0QshaMOpbUhH4rv+J/ix8rjcg40vzGNkdKZqr6o0t1iicHxpTOX04OFt26urKOTgsVRMv21c4wjKVkdv79IALb07Kc=|l4T7x9Muo7xnJAj7eM5XApcDdfMdLTwObhy9KCtv4AIdxJ/Z7o/+vP3mpnwiIChzjKsgzOYUwjq7wT64IqgG78hC9vhQMH2bsMms7J8feoAjg/+SVKQNelFliy98vR9/IWh0giNG77EIU+KBG7mY95SeGAk+0302s51uocQm7B+si8MccU6mEmr0947VScgzlu+wjawrIYrViRi+27sQT8OjcXV/q5yRjSdqGAnS4YgPNmo7hqoczxmenz5i/oxXsui/6V2WQ9RPok50OOom+11w+0lsF64uXt6Pg5IcN4ye+FHCgn2Pm1bNadYuDxcwnMXSyYkYcxdvLXy9nOPuKAnjBWqggQ86As8d2zsUlaQdO+mSk8xdyihrkv43hvvp21rh60R/0373PxXpQg002aHlT1pfiP+gvseth7CZd+vKX1MdP2e+nNr7/P5hBqT+QonfdHNM88HrqZFpCI7E7VMqOjgiHavQt+CShpMy9zeTTYf+C1QZ3rItFFptcMkiyPDFPUWyZWswIn4KyFehYd1zF73BchN6H9IlirIvCQkMv8LBs5jWQfrzjSw2ZtGZ3M+b59w3A3LTbYWM0Dg6easjWD0rvu7L0HuvbMmIiTC5SfrY2FiFr0woBhHDyMpp2JYEx78lYbbwDQxfluiyGTnFZss2RQIvA5+hCQ9AhMA=',
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Your data has been shared with your organisation',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Organization not found',
              },
            },
          },
        },
      },
    },
  },
};

const makeMyTrustedOrganization = {
  tags: ['Organizations'],
  description: 'Make Organization As My Trusted',
  summary: 'Make Organization As My Trusted',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                organization_id: {
                  type: 'string',
                  description: 'Organization Id',
                  example: '6569d494bb58f8179b78e6c5',
                  required: true,
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message:
                  'organization is added in my trusted list successfully.',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Organization not found',
              },
            },
          },
        },
      },
    },
  },
};

const deleteMyTrustedOrganization = {
  tags: ['Organizations'],
  description: 'Remove Organization From My Trusted',
  summary: 'Remove Organization From My Trusted',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'organization is removed from my trusted successfully',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'organization is not exists in my trusted list.',
              },
            },
          },
        },
      },
    },
  },
};

const deleteAllMyTrustedOrganization = {
  tags: ['Organizations'],
  description: 'Remove all trusted organizations',
  summary: 'Remove all trusted organizations',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message:
                  'All trusted organizations has been removed successfully',
              },
            },
            example2: {
              value: {
                status: 200,
                message:
                  'We are deleting your trusted organizations, We will notify you once your trusted organizations are removed.',
                isCronService: true,
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Something went wrong.',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const addNewOrganization = {
  tags: ['Organizations'],
  description: 'Add New Organization',
  summary: 'Add New Organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'multipart/form-data': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                name: {
                  type: 'string',
                  description: 'Organization Name',
                  example: 'Amazon',
                  required: true,
                },
                registered_number: {
                  type: 'string',
                  description: 'Organization Registered No.',
                  example: 'AMZ123',
                  required: true,
                },
                date_of_incorporation: {
                  type: 'string',
                  description: 'Organization DOI',
                  example: '2021-01-01',
                  required: true,
                },
                type: {
                  type: 'string',
                  description: 'Organization Type',
                  example: 'E-Commerce',
                  required: true,
                },
                office_address: {
                  type: 'string',
                  description: 'Organization Office Address',
                  example: '3325 Sweetwood Drive, Newyork',
                  required: true,
                },
                description: {
                  type: 'string',
                  description: 'Organization Description',
                  example: 'We are amazon',
                  required: true,
                },
                website: {
                  type: 'string',
                  description: 'Organization Website',
                  example: 'https://www.amazon.com/',
                  required: true,
                },
                legal_status: {
                  type: 'string',
                  description: 'Organization legal Status',
                  example: 'Yes',
                  required: true,
                },
                // is_trusted: {
                //   type: 'string',
                //   description: 'Organization trusted status',
                //   enum: ['yes', 'no'],
                //   example: 'no',
                //   required: true,
                // },
                'email_id[0]': {
                  type: 'string',
                  description: 'Organization Email',
                  example: 'amazon@yopmail.com',
                  required: true,
                },
                'contact_number[0]': {
                  type: 'string',
                  description: 'Organization Contact',
                  example: '+91|1234567890',
                  required: true,
                },
                profile_picture: {
                  type: 'string',
                  description: 'Organization Profile Image',
                  format: 'binary',
                },
                linkedin: {
                  type: 'string',
                  example: 'https://linkedin.com/',
                  description: 'Organization Linkedin Link',
                },
                twitter: {
                  type: 'string',
                  example: 'https://twitter.com/',
                  description: 'Organization Twitter Link',
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    201: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 201,
                message: 'organization is created successfully.',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Something went wrong!',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: 'Organisation with the provided name already exists',
              },
            },
            example2: {
              value: {
                status: 409,
                message: 'Organisation with the provided email already exists',
              },
            },
          },
        },
      },
    },
  },
};

const getOrganization = {
  tags: ['Organizations'],
  description: 'Get Organization by id',
  summary: 'Get details of requested organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  _id: {
                    $ref: '#/components/schemaProps/UniqueId',
                  },
                  user_id: {
                    $ref: '#/components/schemaProps/UniqueId',
                  },
                  primary_email: {
                    type: 'string',
                    example: 'amazon@yopmail.com',
                  },
                  is_authorized: {
                    type: 'boolean',
                    example: false,
                  },
                  // is_trusted: {
                  //   type: 'boolean',
                  //   example: false,
                  // },
                  registered_number: {
                    type: 'string',
                    example: 'AMZ123',
                  },
                  date_of_incorporation: {
                    type: 'string',
                    example: '2021-01-01',
                  },
                  name: {
                    type: 'string',
                    example: 'Amazon',
                  },
                  type: {
                    type: 'string',
                    example: 'E-Commerce',
                  },
                  office_address: {
                    type: 'string',
                    example: '3325 Sweetwood Drive, Newyork',
                  },
                  description: {
                    type: 'string',
                    example: 'We are amazon',
                  },
                  website: {
                    type: 'string',
                    example: 'https://www.amazon.com/',
                  },
                  legal_status: {
                    type: 'string',
                    example: 'Yes',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Role not found',
              },
            },
          },
        },
      },
    },
  },
};

const getConnectedUsers = {
  tags: ['Organizations'],
  description:
    'Get all connected users of organization. Search by mobile number.',
  summary: 'Get all connected users of organization.',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      name: 'search',
      in: 'query',
      description: 'Search by mobile number',
      type: 'string',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'sort_by',
      in: 'query',
      description:
        'Enter field name to sort (mobile_number, country_code, updated_at)',
      type: 'string',
      example: '',
    },
    {
      name: 'order_by',
      in: 'query',
      description: 'Enter sort type (asc | desc)',
      type: 'string',
      example: '',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: {
                  user_list: [
                    {
                      id: '658925147717ba57cd629d3a',
                      country_code: '65',
                      mobile_number: '1122334455',
                    },
                  ],
                  page_info: {
                    total_count: 3,
                    total_pages: 1,
                    current_page: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getUserConsentCount = {
  tags: ['Organizations'],
  description: 'Get user consent counts organzaion wise.',
  summary: 'Get user consent counts organzaion wise.',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'search',
      in: 'query',
      description: 'Search by organizationName',
      type: 'string',
    },
    {
      name: 'sort_by',
      in: 'query',
      description: 'Enter field name to sort (organizationName, count)',
      type: 'string',
      example: '',
    },
    {
      name: 'order_by',
      in: 'query',
      description: 'Enter sort type (asc | desc)',
      type: 'string',
      example: '',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: [
                  {
                    organization_name: 'Dementia UK',
                    organization_logo: `http://localhost:3005/uploads/profilePictures/orgprofile_1702892675369_213052.jpg`,
                    country_code: null,
                    mobile_number: null,
                    count: 127,
                  },
                  {
                    organization_name: 'University of London',
                    organization_logo: `http://localhost:3005/uploads/profilePictures/profile_picture-1706856463224.png`,
                    country_code: null,
                    mobile_number: null,
                    count: 89,
                  },
                  {
                    organization_name: 'IBM',
                    organization_logo: `http://localhost:3005/uploads/profilePictures/orgprofile_1706769562529_849995.png`,
                    country_code: null,
                    mobile_number: null,
                    count: 50,
                  },
                  {
                    organization_name: 'Amazon',
                    organization_logo: `http://localhost:3005/uploads/profilePictures/orgprofile_1703236432566_139237.png`,
                    country_code: null,
                    mobile_number: null,
                    count: 32,
                  },
                  {
                    organization_name: 'Test Janavi Organization',
                    organization_logo: `http://localhost:3005/uploads/profilePictures/profile_picture-1703481546137.jpg`,
                    country_code: null,
                    mobile_number: null,
                    count: 30,
                  },
                  {
                    organization_name: 'PIZZA HUT',
                    organization_logo: `http://localhost:3005/uploads/profilePictures/profile_picture-1707127906111.png`,
                    country_code: null,
                    mobile_number: null,
                    count: 2,
                  },
                ],
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const downloadWebpageToPDF = {
  tags: ['Organizations'],
  description: 'Download report',
  summary: 'Download report',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: {
                  link: 'https://api.uat.addressfull.com/doc/659fa1b376abeac14221ed03$reports$organizations_shared_data.pdf',
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const sendDataRequest = {
  tags: ['Organizations'],
  description:
    'Verify if the user exist and send data request to the user accordingly. If user does not exist, send a text message else notification of data request to the user.',
  summary:
    'Verify if the user exist and send data request to the user accordingly.',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            singleItem: {
              type: 'string',
              example: 'true',
              description:
                'This flag is used when the admin is inserting mobile number manually inside the input box.',
            },
            mobile_numbers: {
              type: 'array',
              items: {
                type: 'string',
                example: '91|1122334455',
              },
            },
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message:
                  'Your data requests have been successfully sent to all of the contact numbers contained in the uploaded document',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Something went wrong.',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized access',
              },
            },
          },
        },
      },
    },
  },
};

const blockUnblockOrganization = {
  tags: ['Organizations'],
  description: 'Block/Unblock Organization',
  summary: 'Block/Unblock Organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                organization_id: {
                  type: 'string',
                  description: 'Organization Id',
                  example: '658910cb17e0fc4809b0c5e7',
                  required: true,
                },
                block_status: {
                  type: 'boolean',
                  example: 'true',
                  required: true,
                },
                reason_for_block: {
                  type: 'string',
                  example: 'Unwanted organization',
                  required: true,
                },
              },
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
        examples: {
          exmaple_local: {
            value: '',
          },
          exmaple_dev: {
            value: '',
          },
          example_production: {
            value:
              'h4I3XEeWFjKiCg/ROgJWLTpANBGYkDczWf54Tdpno8w+Pe4T8Tqrtsra/TqaTGnSdlUgGcAKsHcugTw+PZnd0WAxp09LSo3N0d/70uk5eRP76YJu83vIoRcmM62OHNp2|mmK6agM9xLCJ6LPxtfpqJRZ4+s6VBiJIB9YW19SbQFDVaJn+gSwOcAt+WFz219jZLnOpgIB1Z2aI+RaNS6VFUtGPougBKQRY9Lisqc1ooNVMi0ixVNHMDiTatNfXGxfEW1UYbTZw8wnZNYEBTLrUckIO1aJyAdAox/6+2EpIKtX2Wwg8Q9iZXvoGE7EByCCEoZJAMfYQj74+xBrdyszvIv1rtwquN80DsbwL3m4xPRIzCH5+CXJIhuj40L6WjWpdXqptDC0YZ1idC9S2i7hQte7G2PrcGYSXzd1Nyux9JEHWj3NraBa+fGTjyFGpvgqK8UY5tpERnYSYARvWRo8xT7+PfMMeeX28I8ToEvs/gtsLGQl9MG20CU5VFQWi8kw4qnSTTQ7As7EwWijdIh6zn05lRW7ToSYKH+rYd7FMW3043Pn5wL0XhCIeK82cNBX6xPIfgcsz8LFrZq/XTdGBaYclZurwm5te97eu0J8oJULR0wXm9Wy/gmf29TWM6V0yRiV5jSeArOIJh2ZS+GNnuUB2fhgukkFplleDfmfnRyrgLkweE9QCH1C+Et9EYLpGZNh/gyDJ0b7KSBpxGggZ10xpbL6Sammnz1eWI4WkC0rF0XVg5odqLqrz96J9t2YhOG3sj/1gUbmHYpNZ1+XDatoKPnRfKVbPw7Tth54MyLM=|at5sIg0nQLtc/gv4hm3WkXmCTQa6zAqLlYZVkq53h8Va86TxiZ5SY4AxrbIe0s3J++bpsX16SNhwuG7Abl3jDvmAzIXKcfNxzZixZ1TqsS2rngQ+8AEW3bghaZ4sNk8VspdZHbkkf+qRF5xDHWCIQyhnrhTbCiYLZPhtORRBLyVKf5F3c2bQTjZfzb0gNOehQc+xKVnv4YmeNrpISmT4KZVyKyePgRL0QANX8mouFkxjwttUKWixFBiOJO5fojzWdnbByXG5/XnKqvui4lfzXwkD3CIU10DCouSKEx47fwI0Om7Mo4ASXA0woT4vh5JPsMPFw4TL+q20vmxa8+VX/KHJ096CZVWOH0RM7hc6mzBjVh2p5WejEg+pDva5otb09X/vTN0y0gu/p3n3laNajwUvoH16hQSrnfc1EylguJpvtEi4RJ0B8z4WlL8JIpZj/cPvUeX4f0poJQOhJPrYcwlI02Qxgdb5RzAiFXUMlPCy8lzuLvX9ZM69XbKjMpgKy+iOmwzUDdooG6Q7PODi4sszyzPyiHwaSu6uON6ZBP10I5obUtfQ+RV4GA5Pm3fJCrBwIUeGRtM58IXn32V4GA/Eo7zPWjrBjd5nWPag/Ua0yfMEYN+nmtP31RjrKNoTJ+VzKEzNblDViZU/3wYOzDX/vaaYHdCoxtBY5hK6SbI=',
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Organisation has been successfully blocked',
              },
            },
            example2: {
              value: {
                status: 200,
                message: 'Organisation has been successfully unblocked',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Organization not found',
              },
            },
          },
        },
      },
    },
  },
};

const getMessageLogsList = {
  tags: ['Organizations'],
  description: 'Get list of message logs',
  summary: 'Get list of message logs',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'search',
      in: 'query',
      description: 'Search by mobileNumber',
      type: 'string',
    },
    {
      $ref: '#/components/parameters/sortByLogs',
    },
    {
      $ref: '#/components/parameters/orderBy',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  policy_list: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        _id: {
                          $ref: '#/components/schemaProps/UniqueId',
                        },
                        title: {
                          type: 'string',
                          description: 'Policy Name',
                          example: 'GDPR',
                        },
                        sub_rules: {
                          $ref: '#/components/schemaProps/PolicySubRules',
                        },
                        active: {
                          $ref: '#/components/schemaProps/RecordStatus',
                        },
                        created_at: {
                          $ref: '#/components/schemaProps/createdAtDate',
                        },
                        updated_at: {
                          $ref: '#/components/schemaProps/updatedAtDate',
                        },
                      },
                    },
                  },
                  page_info: {
                    $ref: '#/components/responses/paginationResponse',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Size must be greater than or equal to 1',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const organizationRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/organizations/top-trusted`]: {
    get: getTrustedOrganizations,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/trusted/profile/{id}`]: {
    get: getOrganizationProfile,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/my-trusted`]: {
    get: getMyTrustedOrganizations,
    post: makeMyTrustedOrganization,
    delete: deleteAllMyTrustedOrganization,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/my-blocked`]: {
    get: getMyBlockedOrganizations,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/my-trusted/share-data`]: {
    post: shareDataToOrganization,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/my-trusted/{id}`]: {
    delete: deleteMyTrustedOrganization,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations`]: {
    post: addNewOrganization,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/{id}`]: {
    get: getOrganization,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/users`]: {
    get: getConnectedUsers,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/user-consent-count`]: {
    get: getUserConsentCount,
  },
  [`/api/v${parseInt(
    pkg.version,
    10
  )}/organizations/download/shared-data-report`]: {
    get: downloadWebpageToPDF,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/send-data-request`]: {
    post: sendDataRequest,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/block-unblock`]: {
    post: blockUnblockOrganization,
  },
  [`/api/v${parseInt(pkg.version, 10)}/organizations/bulk-sms-logs`]: {
    get: getMessageLogsList,
  },
};

module.exports = organizationRoutes;
