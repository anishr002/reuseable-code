const pkg = require('../../package.json');

// key-exchange
const keyExchange = {
  tags: ['Authentication'],
  description: 'RSA key exchange',
  summary: 'RSA key exchange',
  parameters: [
    {
      name: 's_api_key',
      description: 'API Key',
      in: 'header',
      type: 'string',
    },
    {
      name: 'x_api_key',
      description: 'API Key',
      in: 'header',
      type: 'string',
      examples: {
        example1: {
          value:
            'MIIBCgKCAQEAnCGTUVSxbd8DmhMFwi8FztYjbnwhq+NOMWJuBCyerb0FusmgAPSGqZ05yeoy6zOIF9ULU6QcZ6Ctrjd7Nh0uSVBPOj6Ox5mCB5WkbfJ4Mvraaz5Vi81RzGFRhavO/fBS9cGY3kMHzFm/EdnDsWS/bOByJaU+VRbxpc9uG6yvIj2rpdnyY4UTqudxqN0k3WUECXsxyJ7CeCTL8swN284s30qH7iv7BC8sqzh9xPnMo46O1nQu6TiRe272CWCT8Mt6R0KNnNnKvYce6ciNV/LteAzAB7jyKI+eFyiV9LOMbK/9vj9ctyYEqDpmeflfhefyoBw9VtMn9wDZlJEdedN/AwIDAQAB',
        },
        example2: {
          value:
            '-----BEGIN PUBLIC KEY-----|MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA0HhAbKHVydonnwXETKYkN66f57z25ICF|TVxvHD9Zv7npSoPGGCM+qW7opPE37UudzaDAy+W8/8G6GYvikn53oS9U2kiIvLd5DI10qDDkh9Vi|TF61N9CB6CHRY/ealRdzJLnSyrsjLM/ycW0xQFFurq3ireUkc3V9a3W7EdP9eB7Dw05yGklpf9c3|gImO/OoUo/NW+qt/eJo9RbTxSP4tolU3Yg4j3a9UxUCsh1CpqWKNavHqxX05qAl98I6xnY3dLk4L|gTkoldd4S5BM/DfW3KbW4vT1xjgEVkjNMQ6kXJyESO5nd9HjhmupVi2gqhoAhwMMH1uEG7bmqK/A|bf+K1Pa1BQy35KSCPYyB/EJ9YtkjnyBtv4MFeXbZ00Cx6P+26dvU+56cfIGOSFi+0YELxcVeOCUY|z5s4Mav+xe5e3L9oL+SvfbcIUv+keVkpBGgL+/+5moEAsVzAtsJGzG+QljJTpau/Y8y6KvzzcKld|CqlaiDX7qrJDfWLFWCFPWfu4SHCLWGAOdL7QwAPPOM+M0sJPDzrt9cCBiADBeSXMvi9uqRl8R3Oy|aJ22OSpAonnLPf8utRQt6vt3JuwhrQpObWD/As1LaHXiwWohzccDQop28jkxrfJnB1exlmU+fsT2|HAWLQK5YtXuKMZlhL+28sknjyNP0bdPBp21sN43hmRsCAwEAAQ==|-----END PUBLIC KEY-----',
        },
        new_ios_key: {
          value:
            'MIICCgKCAgEAvV9ciO9FNuv96iV7I3fRtHijAq2XSdVND8kDLk14C4YcT3podaZxpExOhm/XJCzKG8zytTcXwsE8L6+v8JhVdwEmy3v9mnucJeMiFZmUQQN3zwkmZYzvw8Ci5XF/A5Xc5LP2TaTrfSMN4nNvFmXepfyNh6YQJDvTs2E3xXa9JiAq9YlKKvKgoCFofQZ2iw3vxIWWeP1xWpsdia4opCprmbykvpKQbAqjll+bRrmeVbPOsqs8edjSkaJRjcU36swcZpkGedBVSfUgxcRRsymBcm9L37ot78mdRg335e7PIgAtVvThaSlqpqv9rV2cc6GNFR7Qouai3yx8CvuIBvA9k088m/VpdHpCbN0aOWNjOT/ceXK1ld7OeWw5IrCSTuzAy0zIxwaSdDPHxsbD1zQVrsxQ/1j2g6NIwextjnpsd7DWhLEH89FtUHowkH/81W4AxZiZhSbOgmi4OSFnv2epQ1lz0T9lziE6rxAbd9ZN9pkdIFK1E7KgzYbqrQHO2jkZZUK4R1H1uQwTo/HssO0iJC7YHHtPoALLXnOSql/XLKRp2LLAWu9FNCClImzTdql/eBKh70tQX8AJfUnz9rDAglh9Sqd5mLhBf7wQzajnILoiAZI4Oqxw2oUiBG7S1geWXl8m+z+BtvvY3m7tpV3mRJel49OOxVFJ8SNCFNCFH4UCAwEAAQ==',
        },
        new_android_key: {
          value:
            '-----BEGIN PUBLIC KEY-----|MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxqd8eqNLZaf2hqGyMM9r9lh6tZjqESb2|5fsKZrZejA25bi5vgXVuAL98ieaiVzhwfAHhGBfIo9vHW0BLE0a9DofA5F/YkEJxHKmyONzWDoue|it4NBknXZsWBsZk+qCuHWJDiJb/Z4B2pNMHE/aIWN8dOhmYKG+0M0BDabcxVTbxmw9vL0nxCoZ1l|g71Tew0CxRx1mW0JR4MSBiCwYcHjQ3faoWYfBYWSVMItuPiZgktU0nhfDPgtXCxBD/07rPDiqtmW|StwkW+jFDe5dGYmFsH6h9uoqjTHSs/lcaRG06gxvaZUMMKk+lz4aFvZkuOaucJ/7vtux6ecluXZR|3/Ue3rZJTHDX4qMqREUk8ToYXPcaz2TC3SKxjZ/Luh8I9WixrT7sA+iY4kj36KvRjjqJC/t0KFQj|klW5HGyd5OpxzLP8x7yXGmXARjJWbj31Q2zp7iIuWQb15OSTGiazw3nWtjSaNI3O3CIw1/SH4I0a|w3Ph5vV3noLBfOvRu6tN8ItoayIj98/MGwVh4ZWSg/Jma9UDaHorW8xvLqeD8A3M2E1xgdgUtr8p|RSS7kxA2TlUEghiQewHMHzulGeJNuhhEpJ2IAx8Ce7YYeB+SuT3MqcjHQr+AKX7uTyizW9zpguxG|k12nrpfBtiyLD4XFkDicBwpOtaqzlvwycdm2RhZPIl8CAwEAAQ==|-----END PUBLIC KEY-----',
        },
      },
      // example:
      //   'MIIBCgKCAQEAnCGTUVSxbd8DmhMFwi8FztYjbnwhq+NOMWJuBCyerb0FusmgAPSGqZ05yeoy6zOIF9ULU6QcZ6Ctrjd7Nh0uSVBPOj6Ox5mCB5WkbfJ4Mvraaz5Vi81RzGFRhavO/fBS9cGY3kMHzFm/EdnDsWS/bOByJaU+VRbxpc9uG6yvIj2rpdnyY4UTqudxqN0k3WUECXsxyJ7CeCTL8swN284s30qH7iv7BC8sqzh9xPnMo46O1nQu6TiRe272CWCT8Mt6R0KNnNnKvYce6ciNV/LteAzAB7jyKI+eFyiV9LOMbK/9vj9ctyYEqDpmeflfhefyoBw9VtMn9wDZlJEdedN/AwIDAQAB',
      // example:
      //   '-----BEGIN PUBLIC KEY-----|MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA0HhAbKHVydonnwXETKYkN66f57z25ICF|TVxvHD9Zv7npSoPGGCM+qW7opPE37UudzaDAy+W8/8G6GYvikn53oS9U2kiIvLd5DI10qDDkh9Vi|TF61N9CB6CHRY/ealRdzJLnSyrsjLM/ycW0xQFFurq3ireUkc3V9a3W7EdP9eB7Dw05yGklpf9c3|gImO/OoUo/NW+qt/eJo9RbTxSP4tolU3Yg4j3a9UxUCsh1CpqWKNavHqxX05qAl98I6xnY3dLk4L|gTkoldd4S5BM/DfW3KbW4vT1xjgEVkjNMQ6kXJyESO5nd9HjhmupVi2gqhoAhwMMH1uEG7bmqK/A|bf+K1Pa1BQy35KSCPYyB/EJ9YtkjnyBtv4MFeXbZ00Cx6P+26dvU+56cfIGOSFi+0YELxcVeOCUY|z5s4Mav+xe5e3L9oL+SvfbcIUv+keVkpBGgL+/+5moEAsVzAtsJGzG+QljJTpau/Y8y6KvzzcKld|CqlaiDX7qrJDfWLFWCFPWfu4SHCLWGAOdL7QwAPPOM+M0sJPDzrt9cCBiADBeSXMvi9uqRl8R3Oy|aJ22OSpAonnLPf8utRQt6vt3JuwhrQpObWD/As1LaHXiwWohzccDQop28jkxrfJnB1exlmU+fsT2|HAWLQK5YtXuKMZlhL+28sknjyNP0bdPBp21sN43hmRsCAwEAAQ==|-----END PUBLIC KEY-----',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                description: 'Status Code',
                example: 200,
              },
              encrypted_key: {
                type: 'string',
                description: 'Key Data 1',
              },
              encrypted_iv: {
                type: 'string',
                description: 'Key Data 2',
              },
              encrypted_public_key: {
                type: 'string',
                description: 'Key Data 3',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Validation Failed | Any Type Of Conflict',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Something is wrong',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid or mising API keys',
              },
            },
          },
        },
      },
    },
  },
};

// verify otp
const verifyOtp = {
  tags: ['Authentication'],
  description: 'Verify Otp',
  summary: 'Verify Otp',
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              oneOf: [
                { $ref: '#/components/schemas/OTPAndMobile' },
                { $ref: '#/components/schemas/OTPAndEmail' },
              ],
            },
            {
              properties: {
                x_api_key: {
                  type: 'string',
                  description: 'Enter key',
                  example:
                    '-----BEGIN PUBLIC KEY-----|MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA4IEV8VBycF69DGgh7udi|8H+RHCGEBihnLDumL6dPK5IQO/SOiIHckpFdyXoT5an6b6LDKWwRYaiBnVhZ2N55|R/R4td76l5SeLfjdsG1fiLR7O3GgltdJlsaRmWTHxM0F2XRok0OlWkDCHjco+q+S|BAyQVDDSouHxY+Eyv7LlElGPY1XTm6Hipd7U+Q1rXZu/H4o716nRPg6YGbhR0Ul8|KdaKYZteOtFJXDvN5giT+5viAnXO1aNe7gGo8yOOtWZshRoe5OVPz/B5PgWtNGaG|nfxO5+N7mc8TOHOFWlbW8zJ6NmxDFLpw5VqWE0UG8nR0K55Em0p/fbmiW3YYKE69|S6FTPEVU7vkuFgyBr+AZHEenqb0Na7PVrB+vs+fKW1W7oC0ig9OgHqm3v9xstRdm|jobcwegGQ6zRhhX6anqKCHfzGZinRtzjPplwLIZqe9zb25E27oiFV2TocSPyV7gt|Q2Gyns/pIsWiJqQ7EeqqUNE2BO2ecMvKFDSPKL1iwTqa6hnkoN7crnUudMvyr8fw|gQDBBKRDISn0EKTlYsPf55OCmEVB8RH74cK+jdAFStAkolms66lR509ZYAIh0lsI|OSq0ccWeG4UOLpnZyvnq+o4Geyx/480Q5OvTK5M/DDgrOwcf//4II+TZ/UJHFfdh|/df8gZtqBt+XpLMVPxh6ax8CAwEAAQ==|-----END PUBLIC KEY-----',
                },
              },
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                description: 'Status Code',
                example: 200,
              },
              data: {
                type: 'object',
                description: 'Response data',
                properties: {
                  token: {
                    type: 'string',
                    description: 'Token',
                    example:
                      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NTNhNTMwMTY0ZjRhZTcwZGZmMTFlNGUiLCJ1c2VyVHlwZSI6InN1cGVyLWFkbWluIiwiaWF0IjoxNzAwMDU0MDIyLCJleHAiOjE3MDAwNTQ5MjJ9.C3u1yCn-g0KvpvsTdItzgiLle_KNMLabzv8ZZV2Q_jE',
                  },
                },
              },
              message: {
                type: 'string',
                description: 'Success or Error Message',
                example: 'OTP is verified',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Country Code is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Expired OTP',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'OTP is either expired or incorrect',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: "Account doesn't exist",
              },
            },
          },
        },
      },
    },
  },
};

// signup
const signup = {
  tags: ['Authentication'],
  description: 'Signup of front-end-user and organization-user',
  summary: 'Signup of a new user',
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          oneOf: [
            // { $ref: '#/components/schemas/CountryCodeMobileNumber' },
            {
              allOf: [
                { $ref: '#/components/schemas/CountryCodeMobileNumber' },
                {
                  type: 'object',
                  properties: {
                    device_id: {
                      type: 'string',
                      description: 'Enter Device Id',
                      example: '1234',
                    },
                  },
                },
                {
                  type: 'object',
                  properties: {
                    device_token: {
                      type: 'string',
                      description: 'Enter Device Token',
                      example: 'KBSassasdasd',
                    },
                  },
                },
                {
                  type: 'object',
                  properties: {
                    sms_token: {
                      type: 'string',
                      description: 'Enter SMS Token',
                      example: 'KBSassasdasd',
                    },
                  },
                },
              ],
            },
            { $ref: '#/components/schemas/EmailSchema' },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    400: {
      description: 'Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Email or Mobile Number is required',
              },
            },
          },
        },
      },
    },
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message:
                  'OTP is successfully sent to the provided mobile number or email',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Conflict',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: 'Account already exists',
              },
            },
          },
        },
      },
    },
  },
};

// login
const login = {
  tags: ['Authentication'],
  description: 'User Login',
  summary: 'User Login',
  requestBody: {
    // required: true,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          oneOf: [
            { $ref: '#/components/schemas/EmailPassword' },
            {
              allOf: [
                { $ref: '#/components/schemas/CountryCodeMobileNumber' },
                {
                  type: 'object',
                  properties: {
                    device_id: {
                      type: 'string',
                      description: 'Enter Device Id',
                      example: '1234',
                    },
                  },
                },
                {
                  type: 'object',
                  properties: {
                    device_token: {
                      type: 'string',
                      description: 'Enter Device Token',
                      example: 'KBSassasdasd',
                    },
                  },
                },
                {
                  type: 'object',
                  properties: {
                    sms_token: {
                      type: 'string',
                      description: 'Enter SMS Token',
                      example: 'KBSassasdasd',
                    },
                  },
                },
              ],
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message:
                  'OTP is successfully sent to the provided mobile number or email',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Email or Mobile Number is required',
              },
            },
          },
        },
      },
    },
  },
};

// forgot password
const forgotPassword = {
  tags: ['Authentication'],
  description: 'Forgot Password',
  summary: 'Forgot Password',
  requestBody: {
    content: {
      'application/json': {
        schema: {
          $ref: '#/components/schemas/EmailAndRoleSchema',
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Sucess',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message:
                  'Password reset link is successfullty sent to the provided email',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Email is required',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: "Account doesn't exist",
              },
            },
          },
        },
      },
    },
  },
};

// reset password
const resetPassword = {
  tags: ['Authentication'],
  description: 'Reset Password',
  summary: 'Reset Password',
  parameters: [
    {
      $ref: '#/components/parameters/passwordResetToken',
    },
  ],
  requestBody: {
    // required: true,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            { $ref: '#/components/schemas/PasswordSchema' },
            {
              type: 'object',
              properties: {
                confirm_password: {
                  type: 'string',
                  description: 'Enter Confirm Password',
                  required: true,
                  example: '12345678A@',
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Password is updated successfully',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Password is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

// resend otp
const resendOTP = {
  tags: ['Authentication'],
  description: 'Resend OTP',
  summary: 'Resend OTP',
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          oneOf: [
            { $ref: '#/components/schemas/Email' },
            { $ref: '#/components/schemas/Mobile' },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message:
                  'OTP is successfully sent to the provided email/mobile number',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Email or Mobile Number is required',
              },
            },
          },
        },
      },
    },
  },
};

const updateProfile = {
  tags: ['UserProfile'],
  description: 'Update user profile',
  summary: 'Update user profile',
  consumes: ['multipart/form-data'],
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          oneOf: [
            {
              type: 'object',
              properties: {
                first_name: {
                  $ref: '#/components/schemaProps/FirstName',
                },
                last_name: {
                  $ref: '#/components/schemaProps/LastName',
                },
                profile_picture: {
                  type: 'string',
                  format: 'binary',
                  example:
                    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAOwAAADsAEnxA+tAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAF6pJREFUeJztnXt8VNW1x3/rnJnJnDwn78mD8JK3Aj6gCtoi1rZgW23vhQ/4wE+rhUt5ShFEbY1agQDlEQjUttpWELTUW3tVbK/lClYR2wIqFCQJAiEkk0lCJpnMTGbOnLPvHwEMzCPzOGfOGeT7+eTzgfNYe83Z6+yz99prr024Apg5c6bR5fKOZQy3M2KjiDAYDCUA0gCYAUgAOgC0AjgBwmEG+QPBZNr94osvOrXUXWtIawXiYfr0GSOJ8CMQpgPIjUGECOCvBDzv83ne3rlzp6SwironKQ3g/vvvHyWDfxaMfRtK/QaGaoA9uX371j8CYIrITAKSygBmzpyZ6nR5nyOwuQAMapTBQH+X/fjBq6/+/oQa8vVG0hjA9OkPjiAOfwDY8AQU5wJjs7dv37o1AWVpSlIYwPQHHphIMv0JQGYiy2VgK3a8vPUJ9PgkzJw50+h0dt1ERGOIWCkjlgWZmohYE8B9PGhQ/w/Ly8vlROoZD7o3gPvumzGJMfwJhBRtNGCV21/eumDatB/04TjpJyDcj/AdTjsIr8l+fsUrr/z2TKK0jBVdG8D06TNuIQ5/A5CqsSr/C+A2AEIU93QRsN7n8zy1c+dOn0p6xY1uDeCBBx4okGQ6BKBYa13i5AMmi/+xY8eOJq0VCQantQIhIEmmrUj+ygeA8UTG96ZMeShHa0WCoUsDuPfeB+8F8A2t9VAMwmCjSfzTlClTTFqrcjm6M4ApU6YIILZaaz1U4Ksmk3mh1kpcju4MwGASHgZQpLUeasBAy2bMmBGLy1o19GYARGC6e0sUxOL3Y67WSvREVwZw770P3gbQAK31UBUO39dahZ7oxgCqVjaNK8i54Y9a66E6DCPLl7xxj9ZqXECVCZVo2LzidDbjUsoBNrfTfUY3BqkmRmPWf2+uaNzml/CT+Y8XNWupi2YPnDFGVSubZjAu5TiA+X7Jw3l8mj6LhOHztxMDPcDz3PGqVbYF5eVMs3rQpODnVzaUbV5lew/Efg8gHwA83mYw9uWYhhcl1/l/sWwwrM8XbHuqfnG2jxa6JNwANq2yfdtP3EGAbu15vMvbmmhVNIMFxJvQbfDzhzavbLwr0bokrA9QXs4M+YLtSTD8FEEMzy93JUoVvZLLiN6oqrBtzPe0Pjq1fERCJpAS0gJsWdtSki80vQfQU6HKlGVtJ8wyBSNG98nWVAd0T87NbxZy391Y0ZyQeRDVDWDj8oahkujfB+CWcNcxaBdDkWk2YMnXh2Le1wZhbD9dOOrGcZD2ba44O0TtglQ1gKoVjWM4nnuPgDI1y4mHDLMRS+4chhJLKjgi/Gj8AIzpqwsj6CuD37dpdVPYFydeVDOATRW2O8DRbpzv5euRPtmp+NmkESixfBFvYuA4zL5tIO4ZWaqhZt0QkEMye2fzysZJapWhigFsWtk4lYC3AWSoIV8JxvbLxZOTRiAvPTDSjIhw96gSPDxuAMxGXgPtLiFNJnp986rGKWoIV9wANlXY7iCilwAYlZatBKkmHg9+pT/+69aBMPHhf/74gfl46q5r0S83LUHaBYcAE2P0ctUq+7eUlq2oAVStaBxDwOuAVgGc4RlVYsGz3x6JCYMLQBRZNJw1w4wnvzUC943pB0Hb1sAIJr+mdJ9AMQP45Sr7IHD0JoB0pWQqRd+cNDwycQgWThyCnLTog3J4jvD1oYVYfvdIjB+QB57TLJQylWT2PxuXNwxVSqAiv2TL2pYSSfTvi6e3X9/8Lk43vq2EOhfpk52Ke0aV4vpSS8RvfCTYnV1443ADPjzZAkmO3n3dt2gSSvNvj0eFUwY/P27WE/mN8QgBFDCA8nJmKBCa9jBgfDxylDIAE89hVGk2JgzKxzBrpqIVfzkdHhHvn2jG3lo77E5vxPcpYAAAsN9gKfzqrFkkxiMkbldwgWBfHm/lx0umYMR1RVm4tsSC0SWWhPXcMwUjJl9bjEkjinCy1YWDZ9rwcX0bzjo8iSj+ZqmtqRzAE/EIiev12LyycRIjeiteOUDkLYDZwKM0W0Bpdir6WAQMzM9AWXaqqm96tLR7fKht7kSNvRN7aprg9V/q5VSoBQAAWWY0ed5jhX+NVUDMLUBlRX0pA70EFReXpKcY8ODN/ZGRYkSGmUdGihHpKQZdVXYwsgQTbizLwY1lOThw5hy8nZF/HqKE44ht3bK25frZi/LOxiQglpsYY8SD3w4gL5b7I8Vs5HFTWQ6GFGagOCsVGWaj7itfA/Jl0b+VMRbTg4mpBaha3fQQgW6L5V6lYIzhUH0bOjz+oOevKchAqSWapXyhqXd4UGsPnkkmUzDg+tJsrQ3z9i2rbDMA/D7aG6M2gN+sPZPjFbE82vuUZvdxO17+56mQ5408h1XfGwWLEN9iHIfHh2d2HYEohZ6tvHdMX9w51BpXOfHCQL/YtLz+zbmPl0YVWRP1J8AnGiug0gSPgSMIRv7in9kQujfv8ISPHxAlGS5v/Cl/XF5/2MoHgHZP6JGY2cBf8psM6jmRcok3PhPtTVFpU7WicQw42g8FPYiZJgcGZn6GvJRTEIyXPmieI+RmBH+DXT4/Xv/kbNCHT2AYZs3ChMEFiui4p9qOo7aOoOeyBCPuGVWCNFPwxrTV6QtwFrlFHq3evqhtHwqnaFFEx/PIjMO4uY9aP4r0hogNgDFGm1fb/wnGboxNt0CGWA5jsOUIKEROpnAGkCwEM4ALMBCOO65FteM6JYvcP2epNeL5gojf5C0VtslKVv6w7E8wxHI4ZOVHg73DjTVv/Qvb3j+KGDyzESMzYNv7R7HmrX/B3uGOWx6BYajlMIZZPlVAu4vcXLWqKeKV1ZF3AomWxaROEHJSmjEo699KicML7x7GnmPd2VgGWbPxlWvUWVv6zxON2Pr+UQCA6Jew7O6vKCJ3kOUIbJ5itHkVGlUz9hS6s5r0SkQtwJYVtolKunuvsRxVShQAwOH2Bv230vSU3aZwOUq+EADGbVrZ8NVILozIACQ+Pn9zT3iSUGCOexLriqNAsIEj5RKVEriI6qxXA9hS0TiWGCbGr1I3gsEFjpSNAOZ6DK3UnKvvKbqXYKIYZEsQDPH3Ky5C+MbGioabei23twtk0MPKaNQNU2HqYNzgYhARMswmjCxTLwZ1ZFk+MswmEBHGDS5RrRyl4EAP9XZN2Nr4bflJs1sQGgEoNljlOQmT++wERdAKRDMMtDlcyBBMSEtRNxSxs0tEZ5cPVktkcYLhhoE9kRmHt+umQGKKTmW3e41i0aJFfULOT4dtAVxm4R4oWPkAIMk8mrsKlRQJALBa0lSvfABINxsjrvxoaPZYla58AMhKEQ1h1xuGNQAiPKCsPt1UO0aoITapqW1X55kwUNg6DGkAW1bbCqBSqrZz3gKcaB+mhuikpLZ9OFq96vRdCJi8/rmmkE1uSAOQZfafUHH18NG20ahxhE/8fSXkCwj3ExgI1e0jcKxtlJoqGIw8+27Ik6Hvo8lqaHMBBsIxx2g0eMpwTeYxFAiNMHK6TakbB4EWIMom2N3FqO0YinZfAhKIEm4H8Otgp4IaQGVlTQo8+JqqSp2n3ZuDA83dTkYD54OJ/8IICAzThr+jyHyBFjAQ3qn/ziVDX59kgl9O+ATXHYwxIqKABxnUAMiVfgu4xC/w8MuBD8flE5BuUtBBkkCcvjS4RF0sjyyoqrANBxDgbw7aB+A40jTMuycOb0L3iFCUdq9+FklxHAX15obqBKq6Jj0aWtyKuiESSotb84wjF2Eh3PmhDKBXH3KiaOjUbXqBXmlwKhORpBBjgx0M6ANULm/MB6C8qy5Gmtx58MlGmLjoV0AxgwkoHABwMXoIZRFo+hzkj3504pVMsLt1tUVAceXyxvzLE1MGGIDByI1iaobVRIkkczjpKMGQnFNR38uGTwCy45y0yS0DfRpRbMUlnHSUQNIu/2NQeB7XAni357EADZksD06YRhFSc65vbDeaFeiBC7F1QmvaYtRZRYi4QZcfCzAAAtcvIdpEgc2VB5sr+nAp8sW/SJO80Q9Bm1y5aHLpItHUJTCw/pcfC2wBgH4J0SZKPm6KIWNahz3+gmOQccCWiL0tY4ChdwMgMF1u1FTvtKKuPcpgz+ZT8RccpYxT7SVo6NRV778HFPAAA1sAimkX7oSwr2E0RCmKQGZnC9Aax96NLWe6ZUSIKBvwYYOqEztxwgLqNrCbyqCrsUtPOn2p+Ht9dEsTuNr9IDH6PMQkdoE7sT+qez6ovx4unzILUlUiAgPQYZKnnnzuKMWx1ih2lenqBI7sBvkjD+Mmvxc4srv73gg52jIQtW26TYh6gYC6DWYAul+Lta9+NE62Rz6+pw476MAbgCOCcHRHI+jAG6AoOn91HUXY3zAy4us1JCB93yVBoeXljMsXmpQLTlcRnpNxR9/9KMuMco1BdjFYfn8wixUwnU8R63ODHDZQ80mgrSEqcXUdRdh9+mZIsr6cPqFo9hTy5eVfROQmrQEAAEcybi09iME5pzUp/7Nz/bGvfjRknXn8wvHjJYVcz7iASzQ/bxnBU27oEJlxeO/MTdhbdxP8cuKyeEoyhw/PjsL7Z25IqsoHIF4eFBJsTOULcVy31LT1RYsnG+NLD8Kapu7WM42defig/gY4vLoI9IiWgJ5wMPMNngxH57R1ZeLN2gk4cc4aU/bO3pBkhhNtVrx14mvJWvlAkLoNdAQxJPXuTS2eDLQ6fehw++Hzx78G0SfKaHeLaHX60OpO2oq/QIBXK6CpJ2KtKqb+SxhdooQuUQJHhBQjwWjgYeSp18WjkswgSgyiX4LXzyDraGo8XogCX+4g33q6otZuy4zB42Pw+LpbAyICzwEc0Rd2zrqvk+QrYy1CSBhslx8KNACiU2FXMyQ5jDH4JSBYvP6VjgycvPxYkIAQnEqINldJOMQiMACeseOJUUclVOy+JHubQRyrvvxYgAFIzP9JYtRRB6cvF5Z0IwQTDyWShXAECCYelnQjnKJuZ8ojQvZLRy4/FmAA51ONRucQ1xEMBBPPIUMwIC8zBTnpRmSYDUgxcjDwHMKl9CUCDDyHFCOHDLMBOelG5GWmIEMwwMRzqmQ3SSBngqWRDe7xIxwAgy4jg6LFwHMw8ICAL1zFMmPne/7d/+cIAJ0fGVyhMMb+Eex4UEc2MfaBuupoC0cEjiMY+O4/jqMruvIBgAj/F+x4UANgjE9KA5BlHyTuc9XkS9xx+KVk3eWcvRvsaFADyO9q/geSaE6AMQm21o9w4LMK+OQ61coRZRsOfLYS9fY9kFnSTJoCQOOcpcXHgp0IagBTy0f4EKLJ0BOMMbQ4PsXB6jU4cfY1+Pzq26xfcuO0bRcOHq+ArfUjMKbdrucRQ9gd6lTIaV8C7WJgd6ujUfw4nDU4ZdsFlyemrXLixutrx4mzr6Gx9X30KbgTeRb9hoQRYyFf5pAGIPvF18AbNpLOYgQ7PfU43bALDlet1qoAANxdTThetw0NrX3RzzoJmWlRBKwmAAb4DDx7I9T5kOEs58eMf1FFqxjw+JpxvG4bPq3dqJvK74nTdRqHT/wS/z75a7i7AuZcNIPA3py1uDjk4oawkT+M6CVioTNMJQLR70JDy140NP8dMtN/uKLDWYNDznXIs1yHvta7YDZpmySCwG0Ndz6sARS6W95oFnJbEWRBgdpIsheNLR+i3r4bkqxeCnh16O6cnms/huL88SjNvx08n/gFIww4JwkdYXfjDBvROLV8hI+I/UFZtcIj9xjSnbbtSsLK/wKZiai378GB4+eHjnJc2/xGDQHb588fFPYB9hr8KYP9hkCzlVMrFAwtjsM4bduFLt859YtLIKLfg9O2XWhs/QB9Cr6OwpwxIFI9mpiBuBd6u6hXLeYuKT4IMFU7gw5nDT6u2YDjdduuuMrviU/sHjp+XL0WLY5PVY0+IuCtOUsKPu7tuojCvxnHPUMy+1b8al2K012HU4270OFSz32rR9xeO47XbUNGahn6WicjK135oaNEtDKS6yJqh+Y+WvghgL1xadQDj7d7SHf4RNWXrvJ74nTX4cjnF4aOCs7AM/xt3pLCiOZzIv4QMdBzsWvUjcxEnLbtwiEVm8BmD4OcqXySMzmzEM0eddy+DmcNDlVvwImzr0FSYLJJZiziuorYAOYuLXwHwL6YNEK3B+/gZ6tRb98DpuJ4vsMnwzN0IrqG3QHJUgzE09kiDpKlGF3D7oBn6ER0+NQMCmOwtX6EQ9Vr0empj0fQ3nnLivZEenFUS8AYyfOIcf8AENVCvJb2T1FT90pCZ9CkjAJIGQUg0QtDWx349kZwnedAYvjEUcwoQE7PgZRVDH92HzBjwIpqVfGKDhyu3YxBZdOQlxX1/IJfYrQgmhuiMoC5S4oPVlXYtgCYG+k95zr+jeq6Haq+9eFgxhSIBYMgFnRnSCOfB5y3E5B8FxNAMt4EGEyQzelgRu0zfMjMj+q67aAyQm5WFNvKMmyc/1hhVDGdUS8ClQTjE7xH/D7Qe8hYp+csjp/eplnlB4OZBEgm7Su5NxiTUV23AyOvyUWaEFF0ns0A09PRlhP1B3L+/NwOYrS0t+tkJqKmbkdS+O/1yoWWQGYReBAJC2c9ltMebRkx9ZBmLy14GQx/C3fN2ea9cHsVyNP3JcfttaPB/l4vV7G/zFlifTUW+TEZABExUaL7AQRdR+iX3Djb3JvSV4mUsy17IfpDdl6bQPwPYpUd8xhp4ROFTbLM7gUQ0Mbbzx1QZDx7lW78UhdaHAeDnZIZcN+cJQUxByDENSMxb1nRHhbE6WAPruxV4sDe9q+AY4zw1Nyl1pDxfpEQ95RUS5f16Z79AdHvUtateRUAgKurAaLf1fPQuwX9ClfEKzduAygvJ5njcR+AWgBwuk9f2WvsNYIxBqf7QjY0Vm3g5alTp8a/37wik9KzH7XaZQ7fANDoudrzVw2PtxkAGjgZ3wwX5xcNikUlzHvUelJm+KbP13G196cSPrHdB+Lumr2s6JRSMhUNS5n3mPWwxNzPEiUuZ9+XBSIOor/z6UiCPKJB8bikdRsXLi/KuflpLtaNmq4SAEc88nNufG5D1aLlistWWiAArKmcVW7NGbuA40xXe4NxQmRkeTk3/mR95bwn1ZCvWmTimg2zKguyrp9uMAhJsHhOn/CciRVm3/DD9ZVz16pVhqqhqWs3zXk1O33g3SZjZmLjoa8AjIYsf17mdd9bu3HO79QsR/XY5A1VS94syrn12gyhLKkzkCaSdKGkrTB76Mh1VQv+rHZZCUl1vWLttOqiUoM1O2vYX66ELKRqQUSwZA76qK09xbpq/Zyg6/mVJmFZwcvLy/0AJi2cs25Zq/PYzyWpK6nyrKsNRyaWZxnx8/WbHvlZQstNZGEAsL7qkRXZaSPGZqSWKeLJuhJIM1vbslKH3JLoygc02hegcsuCAwDyF8xZu6bNWbPQL7m+lJ4jjkwsJ2v4tsqqRQ9CozyUmjbDG6oWLbZah5dlZQw4QFd4lq7LSRNKTmZnD7i2smrRDGiYhFTznUFWrZrXAOCmeXPW/bDLY1vn8jbGtltzkiCkFHZkmIsXrN/8yO+01gXQgQFcYGPVIy8C+O38H69+3Ok5u9TrO5f0uzP0xJyS485M7b9q/aYFz0BHaYd1YwDnYZWbH30OwPK5s1bO7xJbf+r2NiV1gt40c1G7OSX/2Y2bF6+Fjir+AnozgAuwTc8/tgHAhsXzfzXN7bM/0dF5coTMxKToKBAZWHpqSa3ZkP/zDZvnv6S1PuHQqwFcZE3lzFcAvPLQQ+U5qSkpj3u8jvs83iar3vLzEXFIE4pbBFP+To8o/ez5Xy1OimGu7g3gAi+8UH4OwGIAixfN2TSYkbTE7Wu90+Vu6CMznyYtA0dGli6U1JnNue+IMr+6qmpuQD5+vZM0BtCTtd0P+mEAmDBhguG66+6+h/z+aT7JeTNHghVRLl6NFI4zS5lp/WwmPmM/8cYdnxx5/c979ryQVDljLycpvqnRUrXuzWGp6fwMc5pxbFqaYUBmpjk3LV0wp6QYeaORJ4OBJ0EQkJLSnQPT6/XB4/HA75eYKErM6xUlV6enq6Ojq9Xl8n/udYsfOT3+l+bN+85nGv80xfl/O4t1K6HGxQIAAAAASUVORK5CYII=',
                },
              },
            },
            {
              $ref: '#/components/schemas/CountryCodeMobileNumber',
            },
          ],
        },
      },
      'multipart/form-data': {
        schema: {
          type: 'object',
          allOf: [
            {
              $ref: '#/components/schemas/CountryCodeMobileNumber',
            },
            {
              type: 'object',
              properties: {
                first_name: {
                  $ref: '#/components/schemaProps/FirstName',
                },
                last_name: {
                  $ref: '#/components/schemaProps/LastName',
                },
                profile_picture: {
                  type: 'string',
                  format: 'binary',
                },
              },
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getProfile = {
  tags: ['UserProfile'],
  description: 'Get user profile',
  summary: 'Get user profile',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getSecurityQuestions = {
  tags: ['Users'],
  description: 'Get Security Question List',
  summary: 'Get Security Question List',
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    question: {
                      type: 'string',
                      example: 'What city were you born in?',
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  },
};

const dashboard = {
  tags: ['Users'],
  description: 'Dashboard Data',
  summary: 'Dashboard Data',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      name: 'year',
      in: 'query',
      description: 'Enter Year',
      type: 'string',
      value: 2024,
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
              },
            },
          },
        },
      },
    },
  },
};

const deleteAccount = {
  tags: ['Users'],
  description: 'Delete user acoount',
  summary: 'Delete user acoount',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      name: 'type',
      description: 'Deletion Type',
      in: 'path',
      type: 'string',
      required: true,
      example: 'yes | no',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Your account has been successfully deleted',
              },
            },
            example2: {
              value: {
                status: 200,
                message:
                  'We are in the process of deleting your account. Please allow up to 24 hours for it to be processed.',
                isCronService: true,
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Something went wrong.',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const autoSyncUserData = {
  tags: ['Users'],
  description: 'Auto-sync user data with the trusted organization',
  summary: 'Auto-sync user data with the trusted organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            shared_data: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  type: {
                    type: 'string',
                    description: 'Label of shared data',
                    example: 'email1',
                  },
                  value: {
                    type: 'string',
                    description: 'Value of shared data',
                    example: 'test_email1@gmail.com',
                  },
                  old_value: {
                    type: 'string',
                    description: 'Previous of updated shared data',
                    example: 'test_email_prev1@gmail.com',
                  },
                },
              },
            },
          },
        },
        example: {
          shared_data: [
            {
              type: 'firstName',
              value: 'James',
              old_value: 'Robert',
            },
            {
              type: 'lastName',
              value: 'Smith',
              old_value: 'Taylor',
            },
            {
              type: 'mobileNumber1',
              value: '65|1111111111',
              old_value: '65|111111110',
            },
            {
              type: 'mobileNumber2',
              value: '65|2222222222',
              old_value: '65|0222222222',
            },
            {
              type: 'mobileNumber3',
              value: '65|3333333333',
              old_value: '65|0333333333',
            },
            {
              type: 'mobileNumber4',
              value: '65|4444444444',
              old_value: '65|0444444444',
            },
            {
              type: 'mobileNumber5',
              value: '65|5555555555',
              old_value: '65|0555555555',
            },
            {
              type: 'email1',
              value: 'test_email1@gmail.com',
              old_value: 'test_email_prev1@gmail.com',
            },
            {
              type: 'email2',
              value: 'test_email2@gmail.com',
              old_value: 'test_email_prev2@gmail.com',
            },
            {
              type: 'email3',
              value: 'test_email3@gmail.com',
              old_value: 'test_email_prev3@gmail.com',
            },
            {
              type: 'email4',
              value: 'test_email4@gmail.com',
              old_value: 'test_email_prev4@gmail.com',
            },
            {
              type: 'email5',
              value: 'test_email5@gmail.com',
              old_value: 'test_email_prev5@gmail.com',
            },
            {
              type: 'address1',
              value: '123 Main Street, London, SW1A 1AA, United Kingdom',
              old_value:
                'Prev: 123 Main Street, London, SW1A 1AA, United Kingdom',
            },
            {
              type: 'address2',
              value: '456 Elm Road, Manchester, M1 2NE, UK',
              old_value: 'Prev: 456 Elm Road, Manchester, M1 2NE, UK',
            },
            {
              type: 'address3',
              value: 'Flat 3B, 789 High Street, Birmingham, B4 5CD',
              old_value: 'Prev: Flat 3B, 789 High Street, Birmingham, B4 5CD',
            },
            {
              type: 'address4',
              value: '101 Park Avenue, Bristol, BS1 6EH, Avon, United Kingdom',
              old_value:
                'Prev: 101 Park Avenue, Bristol, BS1 6EH, Avon, United Kingdom',
            },
            {
              type: 'address5',
              value:
                'XYZ Company Ltd. 555 Industrial Estate, Newcastle upon Tyne, NE1 7RP',
              old_value:
                'Prev: XYZ Company Ltd. 555 Industrial Estate, Newcastle upon Tyne, NE1 7RP',
            },
            {
              type: 'linkedin',
              value: 'https://linkedin.com/jshdbsahbc/profile',
              old_value: 'https://linkedin.com/jshdbsahbc/profile/old',
            },
            {
              type: 'twitter',
              value: 'https://x.com/hsdcshdc/profile',
              old_value: 'https://x.com/hsdcshdc/profile/old',
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
        examples: {
          exmaple1: {
            value:
              'ACrhx541hVow2H20Wz+BdGHcQoRIi/gaYg630UKWZNo2GcGcFb5zuUgZJBzqBeb0IfWZXu9ZH1DhlIOxLJA6t9TorOuVWNg0kv11d8beAdhImpecdNysIQtk1La47ZP/DeKbgEkMSpjhZJ/PJu26mFEJ8rpY1UUMST+GfEytxRwQ/wlJYbXAOQCQDgmd8vJ2T5QhT94RnfHphFcvWbU9fpO6N0ewHE4JJbM8QW1ubaUMabT5UWN60QIeMLFN5I7WeLYAs2BHAB6zTfVfl8Yseedf1/AX2ZH65dghuPRLeFGwrEyJqaO9xcXNpOpjvNW61GF03p1XzI19FQo3GI9zegn/bPnBLLLBf4HaWcyekE8RqVt23Govp4RZgYNQdJlov004cFuOYvicNv7S7AQFvhBKK3ru6pbg8lwqmcEHfD/mO81V0ATuN39SRVwkByT/3V4e5C4a46TOs5iv1uDtNNr+blLINqhZ7JpjCNOqNRfNlsE2igkBpRBZwEjCi76I/sfJFB2cnvZR+L7snOmBKRIvaB+zwk6ULyLVwVuYOa5H3Ep25UdCmo2V+UEO3uMX+ecydaCGH0I0JcbN1ZGaW6GJX4NJ282JHwsrxKSUyvsN05kNikLA3KU8KxAt7vrqgIQyv/ZydMsoL/oQTE7rT89yEKXvLNSBFh2ogeMED/PY+9kJmUn84DLZD0E4GAGw6KOhf3J5RGSlBjmFVC8rzQrgLuvHy3qRFvy3DKpF1avmEKLKc39+rwBZictvLAUc4SKnGcnwMuhps5/7YMp7nZmmuTPfoysHCIJzEvec6Z6AP6vcIR8RCH/KDSlLtrXu1SY0DZ/eRQSwTKM+YEKC3ZrgKwFm3CiVMW5dagkMUJf5XyQNysq9QRfDueVGNdFbkaN/rUb3IuWEMkrFRALc8vWotI0uZ1j/QCMJMoE4NvEdvw6qkIPzGQm+Y4Ci/3qHNWzpJvq4zkmSwvqzA4scRilxID/WKF52DqYmNHndBCo3PEwlMHVCJS/7YXRowM/SV6DqgJuyuojuj9QC9IWzO02123wpnPWD1ytAbckYVL24GAjf43bZuly90PbflKxUSQ9deAGuiVkBpk/iYPOW+3XEWfoCqoW/kTjPivCXJFiV2EAnM0dcw6VLsQ4JCJ4L0DW6SJoVlDcKw0OfPR0VUKlP8+xUkxVabNFqAUInPlskL24i0V8mFYOHLxJNDApVQCCuSTqGTZwtjkFLqcIxmUT4A5jxSU2vfoVY92081I/g8h8nVECMq1Ve64mvEgwP13NNBTdPgsBlrUHjqOZEPepjgGsZwpiW5995dvJvULxA4TB3rUKwUrqAfws1h6R3fmgZQBKht+rwUxgh5anHtkgbQS8YTTjbzEUPR/rxY+c=|dOOUX6YS3c3gfBftBOsunjCqlkyeCFFMh23amlLodopfbc8tJROXINuWVN8LwZNPjHtk5kamv8UfGk5BZVm5sR7+widQeHQ5wjheUnLWzhWBEkSiZUmOqXJfrpqJSTK5wzEHt5VJGfpweYMsdLQAIaE+1ytnP06rat1AL45CGVgvTPgaN47KoZy9L/9Ush+vi1qU/r6vhvqgWBv1dVV2VESNM9fyQc0VqeC2C97ft0Lw7Af+1yB4lJM7idhFl7IZciNmP1FCCBDbDp4+wN/5ho5kt9D/IDq4kgB5BiyAqAbllsq8K1FvJOLDKI2mSrvXaAJMso0MsEwSEUoPLONTZGX8dkxfTOqpzxDYT8mSw2bhWhQYsQMAUjqbFQ7DxD5IapM1fSYQDdpdz5PUvAgINLKBnSFkp8cKJPSdrp+8iMklRoW8XNhLnxMXElYnl+yfTlvG5wPyxe/V5sbdNU5EsPp42YwHANzMSadPAYvFlH0WLnZHs8DGiUtn+YRNXn3NtOH0F2FnCXHvDRLgIMuMjIlFPlljNuDA6vgElKhcm/GZ5iYCyf53yiemHy5h3NmJN1FvyJuBXkqmGg6mNoDNMpVHRFMR1P65jEyVc9tmL7LJlCbOg2znJDFK6eu+nDL2MuXucMzuYwfuO7CA1DCIsAOasIwVDa7ZuB3+vRow6zw=|KcLfHV3+OIjIGjoJj8XT3CdKn0xuMB/PgyYvHs8t96GMUbSD3kUMLisTCFr8jwL7WDjWKC+zbUhmX85HhHrD1a08dhVXnEhqysNIbFbWAS0/aZalurEl4/PjXsUXHj1G6hb8RA5f8Z6PstCclcIIKVgBgT4/AaxGn4pa5ooR/wh0sBAWhdwvhy2HzK5SBHrQJ8HATlMma2DKkpxa9318zgE0KhnOal/5XcOxYCofbzgQD9M2hJgEfInez+OPSPh+Xl4jgk+Zv3AmrfEksZ7nfKHS3ZaIjHS1z8NsMhmJyvpNGJ/8XUTYPFSzHP/QHiA9S2wv8yvpoCPwTf8X1w+kwVBjyvT0HRkyCAMkrx7yPzqL9onUVLUwmHq0iM1hbY6YmJGiZJqilmWzHvJg1KU0QA0iovgevoVBAjzumqPLacFSVN0ScTgAyWsjGdKTQlg4E3/MwSOEKpIuehOTUQNq3ZACHfTsCCnSOKMpI2Ei3Q7ZwGSdRfhclycfQQLKfdgRZwL3d1LOQbIHfNZDX6kD8WJC11kKlT6QOhl7mBLGeA0ktnXbt5L1FKTAvs/AgI0jvYuHEPZfhPFP/tp2HTNcYv9GxfPQSO17TLwkHQCpWDL++3CHlMehpjgCahjDCQkq4R6tpX241KR0FU5jzWRd0b6caxz8vL1o7mFnUfZVg5o=',
          },
          example_dev1: {
            value:
              'dho783Fr+rYy5yOriy7kGBi15vX3O27d+Bi9kgRoV41IBrxa8ptcaJpJcnb3XWNTBy85pe52j5r+d2lBQxwerFLEPubcnNAzfngL4LNDWriNr6ZNAExpeRhs3Gm/lfGID33ng21hk2NxbzqwfDMlkXIxG4dB4THSVM40+M19KIxwB6RLCbmudGUDPW7znDsNqpdk4PIyxl8tRPGV40a/EoFY8GkBZjPy7eB99xdsfSB0qgimaAMg0HQeJ4sfIirF5SZeSMDdiGyOQSLEzDK8X3KakGelX/pWjYKidpeXL+7fflGOb2fjEeohTy+8+z5ScdbMo50fgrC5FB9XDs9UvdUUrtkjv6ULXdW6h8r1v0BsMMvsQlha5bt3ES5K8Ogq2sxsuBhuN2vKuz82s27UZYXzjpcu4u2pWI1Qp8sN23rIueAmiNNjzrCvwMG1CcOjEjlGtNp7aiFcUsdJipFYH8SBtYiB1JsH4r/x5gpHebptOM8QUR43M8ryudW0YUD/61J4R9kZKjWKTcE9yuav3Fd8PxT+6XwHafXXPS9qAtifZXeGcFheO4amZKl30Mdbo08T7YmVjq1K5lWrW3DfcdZVbJqz6HM89EsdmeICBJPKHGASB3c3sLaQqCpCuIrkJiNUAmqIWAulMkl1CdeB12gFIwnbhAOREWD9IbUfdFF2MtGX0T+xoNci+bZJpopIxG0Un6qcfyzkGbDraFQCneWKE3nT13CvNi9Yg9319f7fWp6R4tTbqTkhDO1vJY+oBLqLP5xI6f9PgNHdPCjKCbY9U43gCuHsRzRy22XsjBXlkFwrvCFgzgyx84+8k1L1LIkhm0VvyXWpeaAPCkdE+zkEyYYO4ksT4bgPY8wfSm1Pzob5bjlwPxuban1meCDYfL/tlUqpbSUFsxelY32z7D1GDlvbNWPuPDUQHwXqAyz3s3BLK5VO2FLxgKYokSht5cEum22pYeCSp8SJqM28IsS9bTqVsMscNPtmyHqsnlZmQHyCGkdxoTUnL3SdKmHYfBJOYEyMDR+bpUELiXI2iznkWKiu0wwazfBioRaRpnVlGOi1wHH2TpCFz6rfvt7JyvyBJL1KbcDjTsh+DxXMLYUATuhP1b5VgK6M82cAyC7KXPqhWqYIKlX0vB4LWjBVOOiPRfC99gNI7Z8aR8gKSA2kt/8HfaBoBxvuWL0kIWFkSI9WCsTXVD+5X/Nq0hkJnXr6OZbUPpOg0gM3KZClzGpxoSgaS0JKf+uzG38obKZio9YBb5u9GhYOZA8v/nMhvGPXDZ8M2r8juVVre/piUKIJiC3/cyLWE99jnSxpZc4N4ATf2mMNXybvCyt27AJ1nM400cpP3n33GfD0la4Hgyey0PxdizpCYW6OA1O3mJM=|S1xlNJjWOUqeKMcVyjbvpJRxn723Xb2aYFm//LKTGSWgJSdoNL7TfzR9C6yJmJklPMNr0AGErg+aio1Dqg+RnhDCJN5i5drvEN7uGWj8kFoLro8TsT9ZkzA2Jy4N1GU7Wv5HcGPXhCevokFxtQvqbPQfV7B3QfOO7ptjzRRKWwR9b7c5RLbZcPC5SLeOZ/MB9Ko4cQdL004dSO61YqqwpTmY3e5+seXlFydy1Ir/Ncv/J77+oO3Qx1C7jVlaFZ4Gg8P6GchVauCtQSPCI1FIYCzJEA4dSVyrHOrK+a4XCKp1b6uJxvTgHPkgeT4bWiddaj/kzBk8TzlE+YBmoJMx0XeAKgb+/6UIHpfMZLZy7vNPe87FIeOZpoWON/d9sn1QkKnFGJZNWjjOQPSKWnys2GFv5a/4NrW0jZSMAcjbKAyIPSIluv0PoK7juAJUNJOXGNvxoqZm/tbrLbq2/u0b14Thc9pYC5P7NyU78V7XNMhcOGBS5bcQ1lOYQX/zoFZBpiJOwf5cfb1GTDTOtfd/XtxpR8cyPoPh6rCsMW2w+ejZRwKzFlmffdbUKjlefYZHA0tyqUqTBK/3vyOLNhtwWj1eldoNdKbjTjEFk5nv2sgaA4pOqA9gbARnQ/bYUtUZsmYpfnilK3mEnpSJGquBD7+85Nu6atgbXslHVk9yIYk=|KOzvhRpVIOxWejdfXjwqYR4/cE1dOXHWBixukYWwZT/IABULemQSsSB1b8H+LL9SNuz8ENsF9Rn5eQY3FHWxdkXe1qOkLou2tRCCFYPZ/Unhocnrga0+ptfAvNALXTEHp6MyGlEompRo/L5jVklsRWBAXHiGQqoSVqon1cAwB/bLuu3UFiEfaj3PnXo5ESShPlYuRoOqzh75jI89SmZ4gtSkgwmoZyeqg0IDq86Nn5zSpRXslmYTGZsBEcv5HDmnXgA0/im/TZER7GbWphddXAhSkRQ3bAqHsdz1lYJiqQSbIBL70mOU2v/eLtWYjxbMv9LWXj8KceAms1Pu95E/9GwklRA1DOJwMY+13arulz/si8ctvBVF9JC7booCTam4wLjwix8UkFKlhOr4x+o7dgzL+8HEiaF1BGsCllKVU9cSHJfs3Ap1O+8cZ/FQ/FMc73/FWjb23TOPEh1IF4aUOrzMcAhSvqE4KybdVqXaIf41Xt0jPpg+ER4vvI4rv5IZG1KdkKkGKq3yWHjx1h4cPcBjj1UpXooU4jMhsB1L0gHRveU2SzVtI233Ya8I2x8vvlfoC6kfSgNs6QwstNKyTCvEVrX6eL1ewcxyADVeinw1bEEPpym4UV/ehE8Binxwkf9PfesRfWOWxa+f7FiamQXtEBSll5N9hvvcS+vZ/w8=',
          },
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Profile has been updated successfully',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getRefreshToken = {
  tags: ['UserProfile'],
  description: 'Get Refresh Token',
  summary: 'Get Refresh Token',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example_mobile: {
              value: {
                status: 200,
                message: 'Token was successfully regenerated',
                data: {
                  token:
                    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb3VudHJ5Q29kZSI6IjkxIiwibW9iaWxlTnVtYmVyIjoiNzIyODg4MzM5NCIsImlhdCI6MTcxMjgzMjU2NiwiZXhwIjoxNzEyOTE4OTY2fQ.W0OYzUFub0QuOTRxAwvB0RKctLIZKCkOnm1ifzARQ2w',
                },
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

// Cron Hosting List for Super Admin
const cronHistoryList = {
  tags: ['UserProfile'],
  description: 'Listing of Cron History',
  summary: 'Listing of Cron History',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/search',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                data: {
                  cron_history_list: [
                    {
                      _id: '66210d48bd77aaf073469924',
                      userId: {
                        _id: '6620b9f774dc34b67d8b79a3',
                        organizationId: null,
                        countryCod: '91',
                        mobileNumber: '9157073370',
                        deviceId: 'C7EDE275-1EA2-489F-83F5-FEF1E3E96046',
                        clientPublicKey:
                          'MIICCgKCAgEAk6PzCalNNf+wydCQUHSiTnIRl3E0dEDkFaFByNSwul51FK+66wX71bflawq6PuR212VkdmPNMEbpheygEP+gJ2G+D7R7OKOiea8yUQzaPa4TmDAdaJc+jUiDYI5jNm2C1Bdbs+fYNLp413MDGDxTiZUEFA+x4v1Py7h38AlIavDcWuH3bA/xgtZFriKRMHQlOg+EMs4mUHutYdWNUJz/Pk7ER/oaxGEwp9+1/vxNbzgoHgtXR6Nt3tDSvlh9iHqkuQFth2WTaiYymsCsCisd6zMylR11WJykhPgyx1U6fYC7/aEC8i315jzNxzZvCarKK8lfATKKSd88Nmma+2bYzLCRHUd02nuUBlhouZcMJgaWai/jJ1R2Vg18bUsXxGZ1RMC6/EThxvoGIUdOZdfquMJX6oGC3BnkdsUP/i1V2Cun4vOw4E8uTsjT7m8U+OZIikj1gJS/lBYDVhfwaN6Zp1C4fr1X+NNOWo6EdVhWbmzdI1s6sUJgxEoPW1NTl7aZTRxTWAWxwOu1tNFb9EslQPLIZJW3vKXVS1zXW2NABtoS//AD1uNTbJPVY1bObtnNOZP4amk61PE8jmt0R/x70sX4cfzQQ71403ti+GuFBKnMbPyEnH1lJSBj7hH7rGoJST7mxVn0OhXN8ZQAU+q3ZBynhqCQeIWbf/ZESHk3ZXkCAwEAAQ==',
                        linkedin: null,
                        twitter: null,
                        role: null,
                        userType: 'front-end-user',
                        hubspotIds: {
                          '6581634c540049c13687a87d': 13531718953,
                          '66178a8d714bec8eed596372': 13534189844,
                          '6571ac1a2319c241b7907e7a': 13548400449,
                        },
                        sharedData: {
                          '6581634c540049c13687a87d': [
                            'firstName',
                            'lastName',
                            'mobileNumber1',
                            'email1',
                            'address1',
                          ],
                          '66178a8d714bec8eed596372': [
                            'firstName',
                            'lastName',
                            'mobileNumber1',
                            'email1',
                          ],
                        },
                        sharedDataTimestamp: {
                          '6581634c540049c13687a87d': '2024-04-18T12:08:40Z',
                          '66178a8d714bec8eed596372': '2024-04-18T12:08:40Z',
                        },
                        isAdminMember: null,
                        isAuthorized: false,
                        isEmailVerified: false,
                        isActive: true,
                        isPasswordReset: false,
                        isDeleted: false,
                        isDeletedByAdmin: false,
                        deletedAt: null,
                        createdAt: '2024-04-18T06:13:11.340Z',
                        updatedAt: '2024-04-18T12:08:40.378Z',
                        __v: 9,
                        otp: 7680,
                        otpExpiration: '2024-04-18T12:07:49.992Z',
                        blockChainToken:
                          'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijk0NWVhMDU5LWNjYjQtNGQ1ZS04MTJmLTk1ZDkxMjY3N2RmNyIsIm1vYmlsZU51bWJlciI6IjkxNTcwNzMzNzAiLCJvcmdhbml6YXRpb25OYW1lIjpudWxsLCJpYXQiOjE3MTM0MjMxODcsImV4cCI6MTcxNjAxNTE4N30.pD8OHLHuKHhBKjGTg-2kO5uttUOqYMoGy7Bil2oxDF8',
                        trustedOrganizations: [
                          '6581634c540049c13687a87d',
                          '66178a8d714bec8eed596372',
                        ],
                        deviceToken:
                          'cDmIuqDuqkRBkKqKjGvTGq:APA91bFWA72FHjHnk84u9DrNqmUyrcumESDeafsC-QfQNfr1e6L4t6NlBuoOuDOrGFKHD_pZLO7O9k9cSJ_ESWy5iXE5PAZKPntaunsobPApQrEL7tHZ5w4GfsE7cm89xgVBzNQYxxgx',
                      },
                      status: true,
                      type: 2,
                      isRunning: false,
                      isHubSpotSync: true,
                      hubSpotSyncUpdate: {
                        '66178a8d714bec8eed596372': true,
                        '6581634c540049c13687a87d': true,
                        '6571ac1a2319c241b7907e7a': true,
                      },
                      rollBackHubspotIds: {},
                      rollBackHubspotStatus: false,
                      rollBackHubspotDBStatus: false,
                      isBlockChainSync: true,
                      blockChainTransId: [
                        'e279f615-0c5c-5e0f-2c47-21d85f547505',
                        'b2389393-6464-5551-f7ca-5a2d6525688c',
                        '916da152-f131-ae65-707a-e690193980e2',
                        'bb495921-e760-0b0e-d2cb-c43dc4a72aae',
                        '625b1139-cf41-7e1f-718b-79b44179b804',
                        '2cc59b7f-d60e-8578-e199-fbbf3155be0e',
                        'e092fe96-e658-b32d-8b3a-ad8bb644648a',
                        'f0161bc9-79ca-645e-e473-1e7636635343',
                        'ef2c0d7b-a074-827e-b761-d468ecd8de9d',
                        '266febb4-1f57-2bd1-0c2b-c4d69a89ad43',
                      ],
                      rollBackBlockchainStatus: false,
                      sharedDataBackup: {
                        '6581634c540049c13687a87d': [
                          'firstName',
                          'lastName',
                          'mobileNumber1',
                          'mobileNumber2',
                          'mobileNumber3',
                          'email1',
                          'email2',
                          'address1',
                          'address2',
                          'address3',
                          'linkedin',
                        ],
                        '66178a8d714bec8eed596372': [
                          'firstName',
                          'lastName',
                          'mobileNumber1',
                          'mobileNumber2',
                          'mobileNumber3',
                          'email1',
                          'email2',
                          'address2',
                          'address3',
                          'linkedin',
                          'twitter',
                        ],
                      },
                      rollBackFinalStatus: false,
                      env: 'local_jatin',
                      priority: 0,
                      logs: [
                        '{"message":"Start processing the cron job.","data":{"jobData":{"_id":"66210cb9bd77aaf0734698a4","userId":"6620b9f774dc34b67d8b79a3","type":2,"isRunning":false,"isHubSpotSync":false,"hubSpotSyncUpdate":{},"rollBackHubspotIds":{},"rollBackHubspotStatus":false,"rollBackHubspotDBStatus":false,"isBlockChainSync":false,"blockChainTransId":[],"rollBackBlockchainStatus":false,"sharedDataBackup":{},"rollBackFinalStatus":false,"env":"local_jatin","priority":0,"logs":[],"createdAt":"2024-04-18T12:06:17.748Z","updatedAt":"2024-04-18T12:06:17.748Z","__v":0}},"timestamp":"2024-04-18T12:07:00.493Z"}',
                        '{"message":"Processing the cron job for the user +919157073370","data":{"userData":{"_id":"6620b9f774dc34b67d8b79a3","organizationId":null,"countryCode":"91","mobileNumber":"9157073370","deviceId":"C7EDE275-1EA2-489F-83F5-FEF1E3E96046","clientPublicKey":"MIICCgKCAgEAk6PzCalNNf+wydCQUHSiTnIRl3E0dEDkFaFByNSwul51FK+66wX71bflawq6PuR212VkdmPNMEbpheygEP+gJ2G+D7R7OKOiea8yUQzaPa4TmDAdaJc+jUiDYI5jNm2C1Bdbs+fYNLp413MDGDxTiZUEFA+x4v1Py7h38AlIavDcWuH3bA/xgtZFriKRMHQlOg+EMs4mUHutYdWNUJz/Pk7ER/oaxGEwp9+1/vxNbzgoHgtXR6Nt3tDSvlh9iHqkuQFth2WTaiYymsCsCisd6zMylR11WJykhPgyx1U6fYC7/aEC8i315jzNxzZvCarKK8lfATKKSd88Nmma+2bYzLCRHUd02nuUBlhouZcMJgaWai/jJ1R2Vg18bUsXxGZ1RMC6/EThxvoGIUdOZdfquMJX6oGC3BnkdsUP/i1V2Cun4vOw4E8uTsjT7m8U+OZIikj1gJS/lBYDVhfwaN6Zp1C4fr1X+NNOWo6EdVhWbmzdI1s6sUJgxEoPW1NTl7aZTRxTWAWxwOu1tNFb9EslQPLIZJW3vKXVS1zXW2NABtoS//AD1uNTbJPVY1bObtnNOZP4amk61PE8jmt0R/x70sX4cfzQQ71403ti+GuFBKnMbPyEnH1lJSBj7hH7rGoJST7mxVn0OhXN8ZQAU+q3ZBynhqCQeIWbf/ZESHk3ZXkCAwEAAQ==","linkedin":null,"twitter":null,"role":null,"userType":"front-end-user","hubspotIds":{"6581634c540049c13687a87d":13531718953,"66178a8d714bec8eed596372":13534189844,"6571ac1a2319c241b7907e7a":13548400449},"sharedData":{"6581634c540049c13687a87d":["firstName","lastName","mobileNumber1","mobileNumber2","mobileNumber3","email1","email2","address1","address2","address3","linkedin"],"66178a8d714bec8eed596372":["firstName","lastName","mobileNumber1","mobileNumber2","mobileNumber3","email1","email2","address2","address3","linkedin","twitter"],"6571ac1a2319c241b7907e7a":["firstName","lastName","mobileNumber1","mobileNumber2","email1","email2","address1","address3","linkedin","twitter"]},"sharedDataTimestamp":{"6581634c540049c13687a87d":"2024-04-18T07:50:56Z","66178a8d714bec8eed596372":"2024-04-18T07:52:04Z","6571ac1a2319c241b7907e7a":"2024-04-18T10:32:57Z"},"isAdminMember":null,"isAuthorized":false,"isEmailVerified":false,"isActive":true,"isPasswordReset":false,"isDeleted":false,"isDeletedByAdmin":false,"deletedAt":null,"createdAt":"2024-04-18T06:13:11.340Z","updatedAt":"2024-04-18T12:05:53.528Z","__v":8,"otp":7680,"otpExpiration":"2024-04-18T12:07:49.992Z","blockChainToken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijk0NWVhMDU5LWNjYjQtNGQ1ZS04MTJmLTk1ZDkxMjY3N2RmNyIsIm1vYmlsZU51bWJlciI6IjkxNTcwNzMzNzAiLCJvcmdhbml6YXRpb25OYW1lIjpudWxsLCJpYXQiOjE3MTM0MjMxODcsImV4cCI6MTcxNjAxNTE4N30.pD8OHLHuKHhBKjGTg-2kO5uttUOqYMoGy7Bil2oxDF8","trustedOrganizations":["6581634c540049c13687a87d","66178a8d714bec8eed596372","6571ac1a2319c241b7907e7a"],"deviceToken":"cDmIuqDuqkRBkKqKjGvTGq:APA91bFWA72FHjHnk84u9DrNqmUyrcumESDeafsC-QfQNfr1e6L4t6NlBuoOuDOrGFKHD_pZLO7O9k9cSJ_ESWy5iXE5PAZKPntaunsobPApQrEL7tHZ5w4GfsE7cm89xgVBzNQYxxgx"}},"timestamp":"2024-04-18T12:07:00.559Z"}',
                        '{"message":"Took backup of users\'s shared data labels with the trusted organizations","data":{"userSharedData":{"6581634c540049c13687a87d":["firstName","lastName","mobileNumber1","mobileNumber2","mobileNumber3","email1","email2","address1","address2","address3","linkedin"],"66178a8d714bec8eed596372":["firstName","lastName","mobileNumber1","mobileNumber2","mobileNumber3","email1","email2","address2","address3","linkedin","twitter"],"6571ac1a2319c241b7907e7a":["firstName","lastName","mobileNumber1","mobileNumber2","email1","email2","address1","address3","linkedin","twitter"]}},"timestamp":"2024-04-18T12:07:00.750Z"}',
                        '{"message":"Found 3 Trusted Organizations.","data":{"count":3},"timestamp":"2024-04-18T12:07:00.750Z"}',
                        '{"message":"Processing auto sync of user\'s profile with one of trusted organizations.","data":{"organizationId":"66178a8d714bec8eed596372"},"timestamp":"2024-04-18T12:07:00.854Z"}',
                        '{"message":"Processing auto sync of user\'s profile with one of trusted organizations.","data":{"organizationId":"6581634c540049c13687a87d"},"timestamp":"2024-04-18T12:07:00.860Z"}',
                        '{"message":"Processing auto sync of user\'s profile with one of trusted organizations.","data":{"organizationId":"6571ac1a2319c241b7907e7a"},"timestamp":"2024-04-18T12:07:00.876Z"}',
                        '{"message":"Start processing of HubSpot data.","data":{"requestBody":{"auth_token":"pat-na1-704193a2-fe18-49b1-b420-f8aa81b7b3c8","firstName":"test","lastName":"test","email1":"test@gmail.com","email2":"","contactNumber1":"91|9157073370","contactNumber2":"","contactNumber3":"","address2":"","address3":"","linkedInLink":"","twitterLink":""},"organizationId":"66178a8c714bec8eed59636e"},"timestamp":"2024-04-18T12:07:00.973Z"}',
                        '{"message":"Updating exisiting HubSpot record.","data":{"hubspotId":13534189844,"organizationId":"66178a8d714bec8eed596372"},"timestamp":"2024-04-18T12:07:00.973Z"}',
                        '{"message":"Processing auto sync of user\'s profile with one of trusted organizations has been performed successfully.","data":{"organizationId":"66178a8d714bec8eed596372"},"timestamp":"2024-04-18T12:07:01.875Z"}',
                        '{"message":"Blockchain transactions have been created successfully.","timestamp":"2024-04-18T12:08:40.164Z"}',
                        '{"message":"User data is updated successfully in the database.","timestamp":"2024-04-18T12:08:40.448Z"}',
                      ],
                      createdAt: '2024-04-18T12:08:40.841Z',
                      updatedAt: '2024-04-18T12:08:40.841Z',
                      __v: 0,
                    },
                  ],
                  pageInfo: {
                    totalCount: 1,
                    totalPages: 1,
                    currentPage: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Number must be a number',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const usersRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/users/key-exchange`]: {
    post: keyExchange,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/signup`]: {
    post: signup,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/verify-otp`]: {
    post: verifyOtp,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/login`]: {
    post: login,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/forgot-password`]: {
    post: forgotPassword,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/reset-password/{token}`]: {
    post: resetPassword,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/resend-otp`]: {
    post: resendOTP,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/profile`]: {
    post: updateProfile,
    get: getProfile,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/refresh-token`]: {
    get: getRefreshToken,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/securityQuestions`]: {
    get: getSecurityQuestions,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/dashboard`]: {
    get: dashboard,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/delete-account/{type}`]: {
    delete: deleteAccount,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/auto-sync`]: {
    post: autoSyncUserData,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/cron-history-list`]: {
    get: cronHistoryList,
  },
};

module.exports = usersRoutes;
