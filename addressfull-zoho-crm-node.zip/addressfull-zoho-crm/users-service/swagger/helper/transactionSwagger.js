const pkg = require('../../package.json');

const getTransactionList = {
  tags: ['Transactions'],
  description: 'Get transactions',
  summary: 'Get transactions list',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'organization_name',
      in: 'query',
      description: 'Organization Name',
      type: 'string',
    },
    {
      name: 'log_type',
      in: 'query',
      description: 'Log Type',
      type: 'string',
    },
    {
      name: 'permission_status',
      in: 'query',
      description: 'Permission Status',
      type: 'string',
    },
    {
      name: 'start_date',
      in: 'query',
      description: 'Start Date',
      type: 'string',
    },
    {
      name: 'end_date',
      in: 'query',
      description: 'End Date',
      type: 'string',
    },
    {
      name: 'bookmark',
      in: 'query',
      description: 'Bookmark',
      type: 'string',
    },
    {
      $ref: '#/components/parameters/sort_order',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example_mobile: {
              value: {
                status: 200,
                data: {
                  results: [
                    {
                      Key: '1f2c8bb4-22c7-8dc1-1b9d-5b7e4a9409ae',
                      Record: {
                        acl: ['27b35fe0-f748-409b-a7e2-d967632d3c23'],
                        ccName: 'adfcc',
                        channelName: 'adfchannel',
                        consentRequestor: 'IBM',
                        countryCode: '91',
                        createdAt: '2024-01-10T14:13:58.378Z',
                        email: '',
                        id: '1f2c8bb4-22c7-8dc1-1b9d-5b7e4a9409ae',
                        isIndividualLog: 'true',
                        logType: 'consent',
                        messages: 'accepted request of LinkedIn for IBM',
                        mobileNumber: '70987654321',
                        permissionStatus: 'approve',
                        updatedData: 'LinkedIn',
                        userId: '27b35fe0-f748-409b-a7e2-d967632d3c23',
                        userInFront: '',
                        version: '1',
                      },
                    },
                    {
                      Key: 'c57a1152-aeed-86ab-bdfa-023d16edc030',
                      Record: {
                        acl: ['27b35fe0-f748-409b-a7e2-d967632d3c23'],
                        ccName: 'adfcc',
                        channelName: 'adfchannel',
                        consentRequestor: 'IBM',
                        countryCode: '91',
                        createdAt: '2024-01-10T14:13:58.376Z',
                        email: '',
                        id: 'c57a1152-aeed-86ab-bdfa-023d16edc030',
                        isIndividualLog: 'true',
                        logType: 'consent',
                        messages: 'accepted request of Twitter for IBM',
                        mobileNumber: '70987654321',
                        permissionStatus: 'approve',
                        updatedData: 'Twitter',
                        userId: '27b35fe0-f748-409b-a7e2-d967632d3c23',
                        userInFront: '',
                        version: '1',
                      },
                    },
                  ],
                  fetchedRecordsCount: 0,
                  bookmark:
                    'g2wAAAACaAJkAA5zdGFydGtleV9kb2NpZG0AAAAkZWFlMzBhYjctOTlkMy02YTQxLWRmOGYtZDliNGVkN2RkYjhiaAJkAAhzdGFydGtleWwAAAABbQAAABgyMDI0LTAxLTEwVDEzOjU0OjMxLjY3NVpqag',
                },
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getActivityList = {
  tags: ['Transactions'],
  description: 'Get activities',
  summary: 'Get activity list',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'organization_name',
      in: 'query',
      description: 'Organization Name',
      type: 'string',
      value: 'IBM',
    },
    {
      name: 'log_type',
      in: 'query',
      description: 'Log Type',
      type: 'string',
    },
    {
      name: 'permission_status',
      in: 'query',
      description: 'Permission Status',
      type: 'string',
    },
    {
      name: 'start_date',
      in: 'query',
      description: 'Start Date',
      type: 'string',
    },
    {
      name: 'end_date',
      in: 'query',
      description: 'End Date',
      type: 'string',
    },
    {
      name: 'client_id',
      in: 'query',
      description: 'ClientId',
      type: 'string',
      value: '658c01f093afc807e450ec58',
    },
    {
      name: 'bookmark',
      in: 'query',
      description: 'Bookmark',
      type: 'string',
    },
    {
      $ref: '#/components/parameters/sort_order',
    },
    {
      $ref: '#/components/parameters/timezone',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example_mobile: {
              value: {
                status: 200,
                data: {
                  results: [
                    {
                      id: 'b3deedfa-f252-49d5-7460-6c19e5f1893c',
                      organization_name: 'University of London',
                      organization_logo: `${process.env.PROTOCOL}://172.16.0.230:3005/uploads/profilePictures/orgprofile_1703768583491_516422.jpg`,
                      message:
                        'Received request for Email by University of London',
                      log_type: 'request',
                      permission_status: 'sent',
                      country_code: '91',
                      email: '',
                      mobile_number: '70987654321',
                      created_date: '11-1-2024, 6:29 pm',
                    },
                    {
                      id: '9e653f75-eca8-b8ea-2187-50ebc4dec989',
                      organization_name: 'IBM',
                      organization_logo: `${process.env.PROTOCOL}://172.16.0.230:3005/uploads/profilePictures/orgprofile_1704796534914_14106.jpg`,
                      message: 'Removed email2 with IBM',
                      log_type: 'consent',
                      permission_status: 'revoke',
                      country_code: '91',
                      email: '',
                      mobile_number: '70987654321',
                      created_date: '11-1-2024, 6:6 pm',
                    },
                  ],
                  fetchedRecordsCount: 2,
                  bookmark:
                    'g2wAAAACaAJkAA5zdGFydGtleV9kb2NpZG0AAAAkZWFlMzBhYjctOTlkMy02YTQxLWRmOGYtZDliNGVkN2RkYjhiaAJkAAhzdGFydGtleWwAAAABbQAAABgyMDI0LTAxLTEwVDEzOjU0OjMxLjY3NVpqag',
                },
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getFilterList = {
  tags: ['Transactions'],
  description: 'Get activity filters',
  summary: 'Get activity filter list',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example_mobile: {
              value: {
                status: 200,
                data: [
                  {
                    title: 'Last 30 days',
                    start_date: '2024-03-09',
                    end_date: '2024-04-09',
                  },
                  {
                    title: 'Last 3 months',
                    start_date: '2024-01-09',
                    end_date: '2024-04-09',
                  },
                  {
                    title: '2023',
                    start_date: '2023-01-01',
                    end_date: '2023-12-31',
                  },
                  {
                    title: '2022',
                    start_date: '2022-01-01',
                    end_date: '2022-12-31',
                  },
                ],
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const transactionRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/transactions`]: {
    get: getTransactionList,
  },
  [`/api/v${parseInt(pkg.version, 10)}/transactions/activity-list`]: {
    get: getActivityList,
  },
  [`/api/v${parseInt(pkg.version, 10)}/transactions/activity-filters`]: {
    get: getFilterList,
  },
};

module.exports = transactionRoutes;
