const pkg = require('../../package.json');

const createRole = {
  tags: ['Roles'],
  description: 'For all types of admins: Create a new role',
  summary: 'Create a new role',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          $ref: '#/components/schemas/RoleModule',
        },
      },
    },
  },
  responses: {
    201: {
      description: 'Role is Created',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 201,
                message: 'Role is created',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Name is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Role Already Exists',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: 'Role with the provided name already exists',
              },
            },
          },
        },
      },
    },
  },
};

const getRolesList = {
  tags: ['Roles'],
  description: 'For all types of admins: Get list of roles',
  summary: 'Get list of roles',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      $ref: '#/components/parameters/sortBy',
    },
    {
      $ref: '#/components/parameters/orderBy',
    },
    {
      name: 'active',
      in: 'query',
      description: 'Record active',
      type: 'string',
      example: 'yes',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  role_list: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        id: {
                          $ref: '#/components/schemaProps/UniqueId',
                        },
                        name: {
                          type: 'string',
                          description: 'Role Name',
                          example: 'manager',
                        },
                        permissions: {
                          $ref: '#/components/schemaProps/RolePermissions',
                        },
                        active: {
                          $ref: '#/components/schemaProps/RecordStatus',
                        },
                        created_at: {
                          $ref: '#/components/schemaProps/createdAtDate',
                        },
                        updated_at: {
                          $ref: '#/components/schemaProps/updatedAtDate',
                        },
                      },
                    },
                  },
                  page_info: {
                    $ref: '#/components/responses/paginationResponse',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Size must be greater than or equal to 1',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const getRole = {
  tags: ['Roles'],
  description: 'For all types of admins: Get role by id',
  summary: 'Get details of requested role',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  _id: {
                    $ref: '#/components/schemaProps/UniqueId',
                  },
                  name: {
                    type: 'string',
                    description: 'Role Name',
                    example: 'manager',
                  },
                  permissions: {
                    $ref: '#/components/schemaProps/RolePermissions',
                  },
                  active: {
                    $ref: '#/components/schemaProps/RecordStatus',
                  },
                  created_at: {
                    $ref: '#/components/schemaProps/createdAtDate',
                  },
                  updated_at: {
                    $ref: '#/components/schemaProps/updatedAtDate',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Role not found',
              },
            },
          },
        },
      },
    },
  },
};

const updateRole = {
  tags: ['Roles'],
  description: 'For all types of admins: Update role',
  summary: 'Update role',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          $ref: '#/components/schemas/RoleModule',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Role is updated',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalide module name is provided',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalide permission type is provided',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Role not found',
              },
            },
          },
        },
      },
    },
  },
};

const deleteRole = {
  tags: ['Roles'],
  description: 'For all types of admins: Delete role',
  summary: 'Delete role',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Role is deleted',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalide permission type is provided',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Role not found',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Conflict',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: "Role can't be removed. User with this role exists",
              },
            },
          },
        },
      },
    },
  },
};

const getModules = {
  tags: ['Roles'],
  description: 'Get modules list',
  summary: 'Get modules list to set permissions while creating/updating a role',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: {
                  type: 'string',
                  description: 'Module Name',
                  example: 'roles',
                },
                title: {
                  type: 'string',
                  description: 'Module Title',
                  example: 'Role Management',
                },
              },
            },
          },
        },
      },
    },
  },
};

const roleRoutes = {
  [`/api/v${parseInt(pkg.version)}/roles`]: {
    post: createRole,
    get: getRolesList,
  },
  [`/api/v${parseInt(pkg.version)}/roles/{id}`]: {
    get: getRole,
    put: updateRole,
    delete: deleteRole,
  },
  [`/api/v${parseInt(pkg.version)}/modules`]: {
    get: getModules,
  },
};

module.exports = roleRoutes;
