const pkg = require('../../package.json');

const createAdmin = {
  tags: ['Admins'],
  description: 'For all types of admins: Create a new admin',
  summary: 'Create a new admin',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                first_name: {
                  type: 'string',
                  description: 'First Name',
                  example: 'Grant',
                  required: true,
                },
                last_name: {
                  type: 'string',
                  description: 'Last Name',
                  example: 'Morte',
                  required: true,
                },
                role: {
                  type: 'string',
                  description: 'Role Id',
                  example: '654371af939d72ca10b19867',
                  required: true,
                },
              },
            },
            { $ref: '#/components/schemas/EmailSchema' },
            { $ref: '#/components/schemas/PasswordSchema' },
            {
              type: 'object',
              properties: {
                status: {
                  $ref: '#/components/schemaProps/RecordStatus',
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    201: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 201,
                message: 'Admin is Created',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Email is required',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Role not found',
              },
            },
          },
        },
      },
    },
    409: {
      description: 'Account already exists',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 409,
                message: 'Account already exists',
              },
            },
          },
        },
      },
    },
  },
};

const getAdmin = {
  tags: ['Admins'],
  description: 'Get a requested admin',
  summary: 'Get a requested admin',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  id: {
                    $ref: '#/components/schemaProps/UniqueId',
                  },
                  first_name: {
                    $ref: '#/components/schemaProps/FirstName',
                  },
                  last_name: {
                    $ref: '#/components/schemaProps/LastName',
                  },
                  email: {
                    $ref: '#/components/schemaProps/Email',
                  },
                  role: {
                    type: 'string',
                    description: 'Role Id',
                    example: '654371af939d72ca10b19867',
                  },
                  active: {
                    $ref: '#/components/schemaProps/RecordStatus',
                  },
                  created_at: {
                    $ref: '#/components/schemaProps/createdAtDate',
                  },
                  updated_at: {
                    $ref: '#/components/schemaProps/updatedAtDate',
                  },
                },
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Admin not found',
              },
            },
          },
        },
      },
    },
  },
};

const getAdminList = {
  tags: ['Admins'],
  description: 'Get admin list',
  summary: 'Get admin list',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      type: 'string',
      in: 'query',
      name: 'mobile_user',
      description: 'Filter by user type',
      example: 'true',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      $ref: '#/components/parameters/sortBy',
    },
    {
      $ref: '#/components/parameters/orderBy',
    },
    {
      $ref: '#/components/parameters/search',
    },
    {
      type: 'string',
      in: 'query',
      name: 'role',
      description: 'Filter by role',
      example: '6554fe389ae9ed04fe032749',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {
                type: 'number',
                example: 200,
              },
              data: {
                type: 'object',
                properties: {
                  admin_list: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        id: {
                          $ref: '#/components/schemaProps/UniqueId',
                        },
                        first_name: {
                          $ref: '#/components/schemaProps/FirstName',
                        },
                        last_name: {
                          $ref: '#/components/schemaProps/LastName',
                        },
                        email: {
                          $ref: '#/components/schemaProps/Email',
                        },
                        role: {
                          type: 'object',
                          description:
                            'role can be null as well as can be an object as shown',
                          properties: {
                            id: {
                              $ref: '#/components/schemaProps/UniqueId',
                            },
                            name: {
                              type: 'string',
                              description: 'Name of Role',
                              example: 'Manager',
                            },
                          },
                        },
                        active: {
                          $ref: '#/components/schemaProps/RecordStatus',
                        },
                        created_at: {
                          $ref: '#/components/schemaProps/createdAtDate',
                        },
                        updated_at: {
                          $ref: '#/components/schemaProps/updatedAtDate',
                        },
                      },
                    },
                  },
                  page_info: {
                    $ref: '#/components/responses/paginationResponse',
                  },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Page Size must be greater than or equal to 1',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Invalid Search String',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const updateAdmin = {
  tags: ['Admins'],
  description: 'Update Admin',
  summary: 'Update Admin',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                first_name: {
                  type: 'string',
                  description: 'First Name',
                  example: 'Grant',
                  required: true,
                },
                last_name: {
                  type: 'string',
                  description: 'Last Name',
                  example: 'Morte',
                  required: true,
                },
                role: {
                  type: 'string',
                  description: 'Role Id',
                  example: '654371af939d72ca10b19867',
                  required: true,
                },
              },
            },
            {
              type: 'object',
              properties: {
                status: {
                  $ref: '#/components/schemaProps/RecordStatus',
                },
              },
            },
          ],
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Role is updated',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad Request',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Status is required',
              },
            },
            example2: {
              value: {
                status: 400,
                message: 'Role is invalid',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'Role not found',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const DeleteAdmin = {
  tags: ['Admins'],
  description: 'Delete Admin',
  summary: 'Delete Admin',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    400: {
      description: 'Bad Request',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const adminRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/users/`]: {
    post: createAdmin,
    get: getAdminList,
  },
  [`/api/v${parseInt(pkg.version, 10)}/users/{id}`]: {
    get: getAdmin,
    put: updateAdmin,
    delete: DeleteAdmin,
  },
};

module.exports = adminRoutes;
