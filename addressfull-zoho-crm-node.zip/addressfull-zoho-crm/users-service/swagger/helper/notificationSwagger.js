const pkg = require('../../package.json');

const getNotificationList = {
  tags: ['Notifications'],
  description: 'Get all type of notifications',
  summary: 'Get request list | Get notification list',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/page',
    },
    {
      $ref: '#/components/parameters/pageSize',
    },
    {
      name: 'req_type',
      in: 'query',
      description: 'Request Type',
      type: 'string',
    },
    {
      name: 'req_status',
      in: 'query',
      description: 'Request Status',
      type: 'string',
    },
    {
      name: 'req_period',
      in: 'query',
      description: 'Request Period [0, 1]',
      type: 'string',
    },
    {
      name: 'is_read',
      in: 'query',
      description: 'Is Read [0, 1]',
      type: 'string',
    },
    {
      $ref: '#/components/parameters/timezone',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example_mobile: {
              value: {
                status: 200,
                data: {
                  notification_list: [
                    {
                      request_id: '659401ce8d79bed2fecd6d49',
                      organization_id: '65799894ca113ff38973aef9',
                      organization_name: null,
                      organization_profile_image: null,
                      request_date: '03-01-2024, 06:00 PM',
                      message: 'Organization requested for Address',
                    },
                    {
                      request_id: '659401b18d79bed2fecd6d45',
                      organization_id: '65799894ca113ff38973aef9',
                      organization_name: null,
                      organization_profile_image: null,
                      request_date: '02-01-2024, 05:59 PM',
                      message:
                        'Organization requested for Address, MobileNumber, Email, Twitter, LinkedIn',
                    },
                  ],
                  page_info: {
                    total_count: 2,
                    total_pages: 1,
                    current_page: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const sendRequestToUser = {
  tags: ['Notifications'],
  description: 'Send Request to User',
  summary: 'Send Request to User For Access Data',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                client_id: {
                  type: 'string',
                  example: '6571ac1a2319c241b7907e7a',
                  required: true,
                },
                request_details: {
                  type: 'array',
                  example: [
                    'Address',
                    'MobileNumber',
                    'Email',
                    'Twitter',
                    'LinkedIn',
                  ],
                },
              },
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Your request has been sent to user.',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'User not found',
              },
            },
          },
        },
      },
    },
  },
};

const updateRequest = {
  tags: ['Notifications'],
  description: 'Update Request',
  summary: 'Approve or Reject Received Request Sent By Organization',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                request_id: {
                  type: 'string',
                  example: '6571ac1a2319c241b7907e7a',
                  required: true,
                },
                organization_id: {
                  type: 'string',
                  example: '6571ac1a2319c241b7907e7a',
                  required: true,
                },
                request_status: {
                  type: 'boolean',
                  example: 'true',
                  required: true,
                },
              },
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Request updated successfully.',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
    404: {
      description: 'Not Found',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 404,
                message: 'User not found',
              },
            },
          },
        },
      },
    },
  },
};

const readAllNotification = {
  tags: ['Notifications'],
  description: 'Read All Notification',
  summary: 'Read All Notification',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'All notifications read',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const readNotification = {
  tags: ['Notifications'],
  description: 'Read Notification',
  summary: 'Read Notification',
  parameters: [
    {
      $ref: '#/components/parameters/token',
    },
    {
      $ref: '#/components/parameters/objectId',
    },
  ],
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
          },
          examples: {
            example1: {
              value: {
                status: 200,
                message: 'Request read successfully',
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
    401: {
      description: 'Unauthorized Access',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 401,
                message: 'Unauthorized Access',
              },
            },
          },
        },
      },
    },
  },
};

const forceUpdate = {
  tags: ['Notifications'],
  description: 'Update Request',
  summary: 'Provide force update notification on device',
  requestBody: {
    content: {
      'application/json': {
        schema: {
          type: 'object',
          allOf: [
            {
              type: 'object',
              properties: {
                device_type: {
                  type: 'string',
                  example: 'Android',
                  required: true,
                },
                update_status: {
                  type: 'boolean',
                  example: 'true',
                  required: true,
                },
              },
            },
          ],
        },
      },
      'application/base64': {
        schema: {
          type: 'string',
        },
      },
    },
  },
  responses: {
    200: {
      description: 'Success',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: { type: 'integer', example: 200 },
              message: {
                type: 'string',
                example: 'Force update successfully added for Android/IOS',
              },
              data: {
                type: 'object',
                properties: {
                  device_type: { type: 'string', example: 'Android' },
                  force_update: { type: 'boolean', example: true },
                },
              },
            },
          },
        },
      },
    },
    400: {
      description: 'Bad request | Validation Failed',
      content: {
        'application/json': {
          schema: {
            $ref: '#/components/responses/CommonResponse',
          },
          examples: {
            example1: {
              value: {
                status: 400,
                message: 'Invalid or Missing Id',
              },
            },
          },
        },
      },
    },
  },
};

const notificationRoutes = {
  [`/api/v${parseInt(pkg.version, 10)}/notifications`]: {
    get: getNotificationList,
  },
  [`/api/v${parseInt(pkg.version, 10)}/notifications/send-request`]: {
    post: sendRequestToUser,
  },
  [`/api/v${parseInt(pkg.version, 10)}/notifications/update-request`]: {
    post: updateRequest,
  },
  [`/api/v${parseInt(pkg.version, 10)}/notifications/read-all`]: {
    get: readAllNotification,
  },
  [`/api/v${parseInt(pkg.version, 10)}/notifications/read/{id}`]: {
    put: readNotification,
  },
  [`/api/v${parseInt(pkg.version, 10)}/notifications/force-update`]: {
    post: forceUpdate,
  },
};

module.exports = notificationRoutes;
