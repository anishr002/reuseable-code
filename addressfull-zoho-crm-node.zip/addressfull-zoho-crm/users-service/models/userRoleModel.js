const mongoose = require('mongoose'); // Erase if already required
const permissionTypes = require('../config/constants/permissionType');
const { getModules } = require('../utils/common');
const User = require('./userModel');
const responseMessages = require('../config/constants/reponseMessages');
const userRoles = require('../config/constants/userRoles');

const permissionsSchema = new mongoose.Schema({
  module: {
    type: String,
    // enum: Object.values(validModules),
  },
  permission: {
    type: String,
    enum: [...Object.values(permissionTypes)],
    default: null,
  },
});

// Declare the Schema of the Mongo model
const userRoleSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    permissions: {
      type: [permissionsSchema],
    },
    // DO::update default
    isActive: {
      type: Boolean,
      defualt: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // Reference to the User who created the role.
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Defined compound index
userRoleSchema.index({ name: 1, createdBy: 1 }, { unique: true });

// Validate system modules
userRoleSchema.pre('save', async function (next) {
  const user = await User.findById(this.createdBy);

  // Get user type
  let createdByUserType;
  if (user.userType) {
    createdByUserType = user.userType;
  } else if (user?.isAdminMember === true) {
    createdByUserType = userRoles.SUPER_ADMIN;
  } else {
    createdByUserType = userRoles.ORGANIZATION_ADMIN;
  }

  const systemModules = await getModules(createdByUserType);
  if (this.permissions && Array.isArray(this.permissions)) {
    this.permissions.forEach((permission) => {
      if (!systemModules.includes(permission.module)) {
        return next(new Error(responseMessages.ROLES_WRONG_MODULE));
      }
    });
  }
  next();
});

// Export the model
module.exports = mongoose.model('Role', userRoleSchema, 'userRoles');
