const mongoose = require('mongoose');
const SMSServices = require('../config/constants/SMSServices');
const { type } = require('os');

// Declare the Schema of the Mongo model
const generalSettingSchema = new mongoose.Schema(
  {
    settings: {
      toEmail: [
        {
          type: String,
        },
      ],
      smsService: {
        type: String,
        enum: Object.values(SMSServices),
        default: SMSServices.TWILIO,
      },
      timezone: {
        type: String,
      },
      cron_execution_time: {
        type: String,
      },
      token_expiration_time: {
        type: String,
      },
      activity_filters: {
        type: [String],
        default: undefined,
      },
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      unique: true,
      sparse: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model('GeneralSetting', generalSettingSchema);
