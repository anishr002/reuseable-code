const mongoose = require('mongoose');

const subRulesSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  description: {
    type: String,
  },
  isActive: {
    type: Boolean,
    defualt: false,
  },
});

// Declare the Schema of the Mongo model
const privacyPolicySchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    subRules: {
      type: [subRulesSchema],
    },
    isActive: {
      type: Boolean,
      defualt: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // Reference to the User who created the policy.
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model(
  'PrivacyPolicy',
  privacyPolicySchema,
  'privacyPolicies'
);
