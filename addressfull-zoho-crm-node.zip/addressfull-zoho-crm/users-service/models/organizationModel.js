const mongoose = require('mongoose');
const logger = require('../logger');

// Declare the Schema of the Mongo model
const organizationSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // Reference to the User
      required: true,
    },
    registeredNumber: {
      type: String,
      unique: true,
      sparse: true,
    },
    name: {
      type: String,
    },
    QRImage: {
      type: Buffer,
    },
    type: {
      type: String,
    },
    dateOfIncorporation: {
      type: Date,
    },
    address: {
      type: String,
    },
    description: {
      type: String,
    },
    website: {
      type: String,
    },
    legalStatus: {
      type: String,
    },
    emails: {
      type: [String],
    },
    contactNumbers: {
      type: [String],
    },
    logoImage: {
      type: String,
    },
    location: {
      type: {
        type: String,
        enum: ['Point'], // Only allow 'Point' as the type
      },
      coordinates: {
        type: [Number], // Longitude (East-West), Latitude (North-South)
      },
    },
    isTrusted: {
      type: Boolean,
      default: false,
    },
    trustedUsers: {
      type: [String],
      default: undefined,
    },
    blockedUsers: {
      type: [String],
      default: undefined,
    },
    policyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PrivacyPolicy', // Reference to the PrivacyPolicy
      default: null,
    },
    policySubRules: {
      type: [String],
      default: null,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
    documents: [
      {
        type: {
          type: String,
        },
        url: {
          type: String,
        },
      },
    ],
  },
  {
    timestamps: true,
  }
);

organizationSchema.index({
  // Index on the name field for text search
  name: 'text',
});

organizationSchema.index({
  // Index on the location field for geospatial queries
  location: '2dsphere',
});

const Organization = mongoose.model('Organization', organizationSchema);

// Ensure indexes are created
Organization.createIndexes()
  .then(() => {
    logger.info(`Organization: Indexes created successfully.`);
  })
  .catch((err) => {
    logger.error(`Organization: Error in creating indexes: ${err.message}`);
  });

// Export the model
module.exports = Organization;
