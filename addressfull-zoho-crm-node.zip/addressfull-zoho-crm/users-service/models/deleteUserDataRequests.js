const mongoose = require('mongoose');

const deleteUserDataReqSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    type: {
      type: Number,
      // 0: delete all organizations
      // 1: delete user account & delete all organizations
      // 2: Auto sync of user data
      enum: [0, 1, 2],
      required: true,
    },
    isRunning: {
      type: Boolean,
      default: false,
    },
    isHubSpotSync: {
      type: Boolean,
      default: false,
    },
    hubSpotSyncUpdate: {
      type: Map,
      of: mongoose.Schema.Types.Mixed, // Allow values of any type
      default: {},
    },
    rollBackHubspotIds: {
      type: Map,
      of: Number,
      default: {},
    },
    rollBackHubspotStatus: {
      type: Boolean,
      default: false,
    },
    rollBackHubspotDBStatus: {
      type: Boolean,
      default: false,
    },
    isBlockChainSync: {
      type: Boolean,
      default: false,
    },
    blockChainTransId: {
      type: [String],
      default: null,
    },
    rollBackBlockchainStatus: {
      type: Boolean,
      default: false,
    },
    sharedDataBackup: {
      type: Map,
      of: [String],
      default: {},
    },
    rollBackFinalStatus: {
      type: Boolean,
      default: false,
    },
    env: {
      type: String,
    },
    priority: {
      type: Number,
      enum: [0, 1],
      // 0 is for highest priority
      default: 0,
    },
    logs: {
      type: [String],
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model(
  'DeleteUserData',
  deleteUserDataReqSchema,
  'deleteUserData'
);
