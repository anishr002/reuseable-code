const mongoose = require('mongoose'); // Erase if already required
const bcrypt = require('bcrypt');
const util = require('util');
const userRoles = require('../config/constants/userRoles');

// ** If the user will fails to receive OTP then they can request for resend OTP after 1 Minute.
// ** User can consecutively request for new OTP for maximum 5 times. (Then when?)
// ** Temporary account lockouts after 5 consecutive failed login attempts. (The app will be putting in place security mechanisms to stop brute-force attacks)
// ** Automatically logs out users of their accounts after 1 week of ideal activity.

// Declare the Schema of the Mongo model
const userSchema = new mongoose.Schema(
  {
    /* Organization reference if the user is of any organization */
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Organization',
      default: null,
    },
    /* firstName and lastName is for `Admin Management` */
    firstName: {
      type: String,
    },
    lastName: {
      type: String,
    },
    email: {
      type: String,
      // unique: true,
      // sparse: true,
      //   validate: {
      //     validator(value) {
      //       // Custom validation logic
      //       return /^\S+@\S+\.\S+$/.test(value);
      //     },
      //     message: 'Invalid email format',
      //   },
    },
    /* Save country code if needed */
    countryCode: {
      type: String,
    },
    mobileNumber: {
      type: String,
      index: true,
      // unique: true,
      // sparse: true,
    },
    deviceId: {
      type: String,
      // unique: true,
      // sparse: true,
    },
    deviceToken: {
      type: String,
    },
    SMSToken: {
      type: String,
    },
    clientPublicKey: {
      type: String,
      // unique: true,
      // sparse: true,
    },
    profileImage: {
      type: String,
    },
    linkedin: {
      type: String,
      default: null,
    },
    twitter: {
      type: String,
      default: null,
    },
    role: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
      ref: 'Role',
    },
    userType: {
      type: String,
      enum: [...Object.values(userRoles), null],
      default: null,
    },
    password: {
      type: String,
    },
    resetPasswordToken: {
      type: String,
    },
    blockChainToken: {
      type: String,
    },
    newRegistrationToken: {
      type: String,
    },
    hubspotIds: {
      type: Map, // Using Map to store key-value pairs
      of: Number, // Assuming HubSpot IDs are numbers
      default: {},
    },
    zohoIds: {
      type: Map, // Using Map to store key-value pairs
      of: String, // Zoho CRM IDs are typically strings
      default: {},
    },
    otp: {
      type: Number,
    },
    otpExpiration: {
      type: Date,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    trustedOrganizations: {
      type: [String],
      default: undefined,
    },
    /* To store the blocked organizations for user */
    blockedOrganizations: {
      type: [String],
      default: undefined,
    },
    /* To store the shared data lables shared by user to the organizations */
    sharedData: {
      type: Map,
      of: [String],
      default: {},
    },
    /* Timestamp of shared data */
    sharedDataTimestamp: {
      type: Map,
      of: String,
      default: {},
    },
    /* isAdminMember flag is created to track futher sub-admins are created by super-admin or organization-admin */
    isAdminMember: {
      type: Boolean,
      default: null,
    },
    /* For organization, If 100% profile details are added and authorized by super-admin then only the organization
    can access other modules */
    isAuthorized: {
      type: Boolean,
      default: false,
    },
    /* To track if the email is verified or not */
    isEmailVerified: {
      type: Boolean,
      default: false,
    },
    /* If the status is active, then only user can login and access the system whether it is a front-end or admin. */
    isActive: {
      type: Boolean,
      default: false,
    },
    /* If the status is active, then only user can login and access the system whether it is a sub-admin. */
    isPasswordReset: {
      type: Boolean,
      default: false,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
    isDeletedByAdmin: {
      type: Boolean,
      default: false,
    },
    isRegistered: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// Define compound index for countryCode and mobileNumber
userSchema.index(
  { countryCode: 1, mobileNumber: 1 },
  { unique: true, sparse: true }
);

// Compound index on email and isDeleted fields
userSchema.index(
  { email: 1, isDeleted: 1 },
  { unique: true, sparse: true, partialFilterExpression: { isDeleted: false } }
);

/* To encypt the password before it gets saved to the database */
userSchema.pre('save', async function (next) {
  try {
    // Only hash the password if it's new or has been modified
    if (!this.isModified('password')) {
      return next();
    }

    // Hash the password with the salt
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(this.password, salt);
    this.password = hashedPassword;
    return next();
  } catch (error) {
    return next(error);
  }
});

userSchema.methods.comparePassword = function (enteredPassword) {
  return util.promisify(bcrypt.compare)(enteredPassword, this.password);
};

/* Middleware to encrypt data */
// userSchema.pre('save', async function (next) {
//   try {
//     // Iterate through all fields in the document
//     for (const key in this._doc) {
//       if (key !== '_id' && key !== '__v') {
//         // Check if the field is a string and not the password field
//         if (typeof this[key] === 'string' && key !== 'password') {
//           // Encrypt or modify the field here
//           // For example, you can use bcrypt to hash it
//           const salt = await bcrypt.genSalt(10);
//           this[key] = await bcrypt.hash(this[key], salt);
//         }
//       }
//     }

//     next();
//   } catch (error) {
//     return next(error);
//   }
// });

/* Middleware to decrypt data */
// userSchema.pre('find', async function(next) {
//     try {
//         const documents = await this.model.find(this.getFilter());
//         documents.forEach(async (document) => {
//           for (const key in document._doc) {
//             if (key !== '_id' && key !== '__v' && typeof document[key] === 'string') {
//               // Check if the field is a string and not the password field
//               if (key !== 'password') {
//                 // Decrypt the field here (e.g., using bcrypt compare)
//                 const isMatch = await bcrypt.compare(document[key], this[key]);
//                 if (isMatch) {
//                   document[key] = this[key];
//                 }
//               }
//             }
//           }
//         });
//         next();
//     } catch(error) {
//         return next(error);
//     }
// });

userSchema.virtual('fullName').get(function () {
  return `${this.firstName} ${this.lastName}`;
});

// Export the model
module.exports = mongoose.model('User', userSchema);
