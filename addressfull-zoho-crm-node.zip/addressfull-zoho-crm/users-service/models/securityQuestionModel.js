const mongoose = require('mongoose');

// Declare the Schema of the Mongo model
const securityQuestionSchema = new mongoose.Schema({
  question: {
    type: String,
    required: true,
    unique: true,
  },
  isActive: {
    type: Boolean,
    required: true,
    default: true,
  },
});

// Export the model
module.exports = mongoose.model(
  'SecurityQuestion',
  securityQuestionSchema,
  'securityQuestions'
);
