const mongoose = require('mongoose');

// Declare the Schema of the Mongo model
const crmSettingSchema = new mongoose.Schema(
  {
    // Type of the CRM (e.g., 'zoho', 'salesforce', etc.)
    type: {
      type: String,
      required: true,
    },

    // Generic CRM Config
    config: {
      authToken: {
        type: String,
      },
    },

    // Organization reference
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      unique: true,
    },

    // --- Zoho CRM specific fields ---
    zohoClientId: {
      type: String,
    },
    zohoSecretKey: {
      type: String,
    },
    zohoRefreshToken: {
      type: String,
    },
    zohoAccessToken: {
      type: String,
    },
    zohoAccessTokenExpiresAt: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model('CRMSetting', crmSettingSchema);
