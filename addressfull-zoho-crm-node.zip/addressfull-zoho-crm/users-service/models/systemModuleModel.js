const mongoose = require('mongoose');
const systemModules = require('../config/constants/systemModules');

const validUserTypes = ['super-admin', 'organization-admin', null];
const validModules = Object.values(systemModules);

// System Modules Model
const systemModuleSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      enum: Object.values(validModules),
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    userType: {
      type: String,
      enum: [...Object.values(validUserTypes), null],
      default: null,
    },
    status: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model(
  'systemModule',
  systemModuleSchema,
  'systemModules'
);
