const mongoose = require('mongoose');
const mailOptions = require('../config/constants/mailOptions');

const validUserTypes = ['super-admin', 'organization-admin', null];
const validMailTypes = [...Object.values(mailOptions.MAIL_TYPES)];

// Schema of the Mongo model
const mailTypeSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    mailType: {
      type: String,
      enum: validMailTypes,
      required: true,
    },
    userType: {
      type: String,
      required: true,
      default: null,
      enum: [...Object.values(validUserTypes)],
    },
    fromName: {
      type: String,
      required: true,
    },
    fromEmail: {
      type: String,
      required: true,
    },
    subject: {
      type: String,
      required: true,
    },
    body: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    status: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model('MailType', mailTypeSchema, 'mailTypes');
