const mongoose = require('mongoose');

const deviceUpdateSchema = mongoose.Schema(
  {
    device_type: {
      type: String,
      required: true,
    },
    update_status: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model(
  'DeviceUpdates',
  deviceUpdateSchema,
  'deviceUpdates'
);
