const mongoose = require('mongoose');
const mailOptions = require('../config/constants/mailOptions');

const validMailTypes = [...Object.values(mailOptions.MAIL_TYPES)];

// Schema of the Mongo model
const mailSchema = new mongoose.Schema(
  {
    mailType: {
      type: String,
      enum: validMailTypes,
      required: true,
    },
    // fromName: {
    //   type: String,
    //   required: true,
    // },
    // fromEmail: {
    //   type: String,
    //   required: true,
    // },
    // toEmail: {
    //   type: [String],
    // },
    subject: {
      type: String,
      required: true,
    },
    body: {
      type: String,
      required: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // Reference to User model
    },
    status: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model('Mail', mailSchema);
