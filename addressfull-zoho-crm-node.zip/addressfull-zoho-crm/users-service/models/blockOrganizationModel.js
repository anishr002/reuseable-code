const mongoose = require('mongoose');

// Declare the Schema of the Mongo model
const blockOrganizationSchema = new mongoose.Schema(
  {
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Organization',
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    reasonForBlock: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model(
  'BlockOrganization',
  blockOrganizationSchema,
  'blockOrganizations'
);
