const mongoose = require('mongoose');

// Declare the Schema of the Mongo model
const organizationTypeSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
      unique: true,
    },
    isActive: {
      type: Boolean,
      required: true,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model(
  'OrganizationType',
  organizationTypeSchema,
  'organizationTypes'
);
