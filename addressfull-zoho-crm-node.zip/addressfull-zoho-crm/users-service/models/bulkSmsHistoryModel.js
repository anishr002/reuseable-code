const mongoose = require('mongoose');

// Declare the Schema of the Mongo model
const bulkSmsHistorySchema = new mongoose.Schema(
  {
    countryCode: {
      type: String,
      required: true,
    },
    mobileNumber: {
      type: String,
      required: true,
    },
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Organization',
      required: true,
    },
    status: {
      type: String,
      default: 'Pending',
    },
    tryCount: {
      type: Number,
      default: 0,
    },
    failCount: {
      type: Number,
      default: 0,
    },
    attemptLogs: {
      type: [String],
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

// Export the model
module.exports = mongoose.model(
  'bulkSmsHistory',
  bulkSmsHistorySchema,
  'bulkSmsHistory'
);
