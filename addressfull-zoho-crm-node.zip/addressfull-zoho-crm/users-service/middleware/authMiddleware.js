const asyncHandler = require('./asyncHandler');
const { decodeJWTSign } = require('../helpers/jwtHelper');
const responseMessages = require('../config/constants/reponseMessages');
const { findUserById } = require('../services/userService');
const userRoles = require('../config/constants/userRoles');
const Role = require('../models/userRoleModel');
const { getModules } = require('../utils/common');
const { decodeUser } = require('../services/commonService');
const { blockChainHealthStatus } = require('../services/blockChainService');
const { revokedTokens } = require('./tokenCleanupMiddleware');
const logger = require('../logger');

exports.protect = asyncHandler(async (req, res, next) => {
  logger.info(`protect: ${req.url} - ${req.params}`);
  const userDecoded = await decodeJWTSign(req);

  if (userDecoded.error) {
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }
  const decodedUserData = await decodeUser(userDecoded);
  const user =
    decodedUserData?._id && (await findUserById(decodedUserData._id));

  // Check if the token is revoked
  if (revokedTokens.has(userDecoded.token)) {
    req.user = user;
    req.user.token = userDecoded?.token;
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }

  if (!user) {
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }

  if (user && !user.isActive) {
    if (user.isDeleted && user.isDeletedByAdmin) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.ADMIN_DELETED_ACCOUNT,
      });
    }
    req.user = user;
    req.user.token = userDecoded?.token;

    return res.status(401).json({
      status: 401,
      message: responseMessages.ACCOUNT_DISABLE,
    });
  }
  req.user = user;
  req.user.token = userDecoded?.token;
  return next();
});

exports.isSuperAdmin = asyncHandler(async (req, res, next) => {
  const { user } = req;
  if (user && user.userType === userRoles.SUPER_ADMIN) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

exports.isAdmin = asyncHandler(async (req, res, next) => {
  const { user } = req;
  if (
    user &&
    ((user.userType === userRoles.SUPER_ADMIN && user.isActive) ||
      (user.userType === null && user.isActive) ||
      (user.userType === userRoles.ORGANIZATION_ADMIN &&
        user.isActive &&
        user.isAuthorized))
  ) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

exports.isOrganizationAdmin = asyncHandler(async (req, res, next) => {
  const { user } = req;
  if (
    (user &&
      user.userType === null &&
      user.isActive &&
      user.isAdminMember === false) ||
    (user.userType === userRoles.ORGANIZATION_ADMIN &&
      user.isActive &&
      user.isAuthorized)
  ) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

exports.isAdminAndOrganization = asyncHandler(async (req, res, next) => {
  const { user } = req;
  if (
    user &&
    ((user.userType === userRoles.SUPER_ADMIN && user.isActive) ||
      (user.userType === null && user.isActive && !user.isDeleted) ||
      (user.userType === userRoles.ORGANIZATION_ADMIN && !user.isDeleted))
  ) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

exports.isMobileUser = asyncHandler(async (req, res, next) => {
  const { user } = req;
  if (
    user &&
    user.userType === userRoles.FRONT_END_USER &&
    user.isActive &&
    user.isDeleted === false
  ) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

exports.validateModuleAccess = (moduleName, permissionType) =>
  asyncHandler(async (req, res, next) => {
    logger.info('Auth: validateModuleAccess');
    const { user } = req;
    if (user) {
      const systemRolesforUser = await getModules(user.userType);
      if (user.userType && systemRolesforUser.includes(moduleName)) {
        return next();
      }
      if (user.role) {
        const roleData = await Role.findById(user.role);
        if (
          roleData &&
          roleData.permissions &&
          Array.isArray(roleData.permissions)
        ) {
          let hasAccess = false;
          roleData.permissions.forEach((element) => {
            if (
              element.module === moduleName &&
              element.permission.includes(permissionType)
            ) {
              hasAccess = true;
            }
          });
          if (hasAccess) {
            return next();
          }
        }
      }
    }
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  });

exports.blockchainHealthCheck = asyncHandler(async (_req, res, next) => {
  const blockchainStatus = await blockChainHealthStatus();
  if (blockchainStatus) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.SERVER_DOWN_ERROR,
  });
});

exports.serverHealthCheck = asyncHandler(async (_req, res, next) => {
  const blockchainStatus = await blockChainHealthStatus();
  const crmStatus = true;

  if (blockchainStatus && crmStatus) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.SERVER_DOWN_ERROR,
  });
});
