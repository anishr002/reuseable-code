const asyncHandler = require('./asyncHandler');
const logger = require('../logger');
const mailConstants = require('../config/constants/mailOptions');

// Common error handling function
const handleServiceError = (error) => ({
  error: error.message,
});

// Higher-order function to wrap the service functions
const withErrorHandling = (serviceFunction) =>
  asyncHandler(async (...args) => {
    try {
      return await serviceFunction(...args);
    } catch (error) {
      // eslint-disable-next-line global-require
      const { sendErrorLogs } = require('../helpers/emailServices');
      logger.error(
        `Error Catched by Service Handler: ${error.message} | ${error.stack}`
      );
      // Send mail to the developer or support team to fix errors coming from the application
      await sendErrorLogs({
        error,
        mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
      });
      return handleServiceError(error);
    }
  });

module.exports = withErrorHandling;
