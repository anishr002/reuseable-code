const { Router } = require('express');

const router = Router();

// Maintain a map of revoked tokens with their expiration timestamps
const revokedTokens = new Map();

// Function to periodically clean up expired tokens
function cleanUpExpiredTokens() {
  // eslint-disable-next-line no-restricted-syntax
  for (const [token, expiration] of revokedTokens.entries()) {
    if (expiration < Date.now()) {
      revokedTokens.delete(token);
    }
  }
}

// Schedule token cleanup every hour (adjust as needed)
// setInterval(cleanUpExpiredTokens, 3600000); // 1 hour in milliseconds
setInterval(cleanUpExpiredTokens, 1000); // 1 hour in milliseconds

// Middleware for cleaning up expired tokens
router.use((_req, _res, next) => {
  cleanUpExpiredTokens();
  next();
});

module.exports = { revokedTokens, router };
