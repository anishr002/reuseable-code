const multer = require('multer');
const {
  setMulterStorage,
  // setOrgMulterStorage,
  // validateProfilePicture,
  validateDocument,
  // decodeBase64File,
  // getPathToUpload,
  getFileNameToUpload,
  getFileTypeBase64File,
} = require('../utils/upload');
const responseMessages = require('../config/constants/reponseMessages');
const logger = require('../logger');

// S3 related imports
const AWSconfig = require('../config/AWSConfig');
const { createFolder, uploadImage } = require('../helpers/S3BucketHelper');

const regexImage = /^data:image\/(jpg|jpeg|png);base64,/;
const regexDoc = /^data:image\/(doc|docx|xlsx|pdf|jpg|jpeg|png);base64,/;

exports.getImageType = (base64String, contentType = 'image') => {
  const regex = contentType === 'image' ? regexImage : regexDoc;
  if (!regex.test(base64String)) {
    return null;
  }
  const [, imageType] = base64String.match(regex) || [];

  return imageType || null;
};

exports.checkFileSizeAndType = (
  base64String,
  fileSize = 2,
  fileType = 'image'
) => {
  const fileStatus = {
    status: false,
    error: '',
  };

  // Check file type
  const mimeType = exports.getImageType(base64String, fileType);
  if (!mimeType) {
    fileStatus.error =
      fileType === 'image'
        ? responseMessages.PROFILE_FILETYPE
        : responseMessages.DOCUMENT_FILETYPE;
    return fileStatus;
  }

  // Decode base64 string to buffer
  const buffer = Buffer.from(base64String, 'base64');

  // Check file size
  const fileSizeInMb = buffer.length / (1024 * 1024); // Convert bytes to MB
  if (fileSizeInMb > fileSize) {
    fileStatus.error = `${fileType} size should be less than ${fileSize} MB.`;
    return fileStatus;
  }

  fileStatus.status = true;
  return fileStatus;
};

// Profile Picture Upload
// const uploadProfilePicture = multer({
//   storage: setMulterStorage(),
//   limits: {
//     fileSize: 2 * 1024 * 1024, // 2 MB limit
//   },
//   fileFilter(req, file, cb) {
//     validateProfilePicture(req, file, cb);
//   },
// });

// Organization Picture Upload
// const orgUploadProfilePicture = multer({
//   storage: setOrgMulterStorage(),
//   limits: {
//     fileSize: 2 * 1024 * 1024, // 2 MB limit
//   },
//   fileFilter(req, file, cb) {
//     validateProfilePicture(req, file, cb);
//   },
// });

// Document Upload
const uploadDocument = multer({
  storage: setMulterStorage(),
  limits: {
    fileSize: 2 * 1024 * 1024, // 5 MB limit
  },
  fileFilter(req, file, cb) {
    validateDocument(req, file, cb);
  },
});

exports.profilePictureUpload = async (req, res, next) => {
  /* Custom middleware to upload images */
  const { bucketName } = AWSconfig;
  const { profile_picture } = req.body;

  try {
    if (profile_picture) {
      const fileValidation = exports.checkFileSizeAndType(profile_picture);
      if (!fileValidation.status) {
        return res.status(400).json({
          status: 400,
          message: fileValidation.error,
        });
      }

      const [fileType, fileExtension] = getFileTypeBase64File(profile_picture);

      const fileName = getFileNameToUpload(req.url);
      const fileNameToUpload = fileName
        ? `${fileName}.${fileExtension}`
        : `profile-${Date.now()}${fileExtension}`;

      // Upload Image in S3 Bucket
      const createFolderResult = await createFolder(bucketName, req.user._id);
      if (!createFolderResult.status) {
        throw new Error(responseMessages.PROFILE_PIC_UPLOAD_ERROR);
      }

      const uploadImageResult = await uploadImage(
        bucketName,
        req.user._id,
        fileNameToUpload,
        profile_picture
      );

      if (uploadImageResult.status) {
        logger.info(
          'Image uploaded successfully in S3',
          uploadImageResult.data
        );
      } else {
        throw new Error(responseMessages.PROFILE_PIC_UPLOAD_ERROR);
      }

      req.file = {
        filename: fileNameToUpload,
        mimetype: `${fileType}/${fileExtension}`,
      };
    }

    logger.info('After: req file', req.file);
    return next();
  } catch (error) {
    logger.error('Error in profilePictureUpload:', error);
    req.fileUploadError = error.message;
    return next();
  }
};

exports.orgPictureUpload = (req, res, next) => {
  const { profile_picture } = req.body;

  if (profile_picture) {
    const fileValidation = exports.checkFileSizeAndType(profile_picture);
    if (!fileValidation.status) {
      return res.status(400).json({
        status: 400,
        message: fileValidation.error,
      });
    }
  }
  return next();
  // orgUploadProfilePicture.single('profile_picture')(req, res, (err) => {
  //   // Handle Multer errors
  //   if (err && err instanceof multer.MulterError) {
  //     logger.error(`Error in upload middleware: ${err}`);
  //     if (err.code === 'LIMIT_FILE_SIZE') {
  //       return res.status(400).json({
  //         status: 400,
  //         message: responseMessages.PROFILE_PIC_SIZE,
  //       });
  //     }
  //     return res.status(400).json({
  //       status: 400,
  //       message: responseMessages.PROFILE_PIC_UPLOAD_ERROR,
  //     });
  //   }
  //   // No errors, continue to the next middleware or route
  //   return next();
  // });
};

exports.documentUpload = (req, res, next) => {
  uploadDocument.single('document')(req, res, (err) => {
    // Handle Multer errors
    if (err && err instanceof multer.MulterError) {
      logger.error(`Error in upload middleware: ${err}`);
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          status: 400,
          // message: responseMessages.PROFILE_PIC_SIZE,
          message: 'File size should not be more than 10mb',
        });
      }
      return res.status(400).json({
        status: 400,
        // message: responseMessages.PROFILE_PIC_UPLOAD_ERROR,
        message: 'Document upload error',
      });
    }
    // No errors, continue to the next middleware or route
    return next();
  });
};
