const asyncHandler = require('./asyncHandler');
const responseMessages = require('../config/constants/reponseMessages');
const Role = require('../models/userRoleModel');
const User = require('../models/userModel');
const logger = require('../logger');
const userRoles = require('../config/constants/userRoles');

exports.isRoleCreator = asyncHandler(async (req, res, next) => {
  const loggedInUserId = req.user._id;
  const role = await Role.findById(req.params.id);
  if (!role) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ROLES_NOT_FOUND,
    });
  }
  if (role.createdBy.toString() === loggedInUserId.toString()) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

exports.isAdminCreator = asyncHandler(async (req, res, next) => {
  logger.info('Auth: isAdminCreator');
  const loggedInUserId = req.user._id;
  const admin = await User.findById(req.params.id);
  if (!admin) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ADMIN_NOT_FOUND,
    });
  }

  if (admin.userType === userRoles.FRONT_END_USER) {
    req.mobile_user = admin;
    return next();
  }

  if (
    admin.createdBy &&
    typeof admin.createdBy === 'object' &&
    admin.createdBy.toString() === loggedInUserId.toString()
  ) {
    return next();
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});
