const responseMessages = require('../config/constants/reponseMessages');
const mailConstants = require('../config/constants/mailOptions');
const { sendErrorLogs } = require('../helpers/emailServices');
const logger = require('../logger');

exports.errorHandler = async (err, _req, res, _next) => {
  const statusCode = res.statusCode !== 200 ? res.statusCode : 500;
  logger.error(`Error Catched by Error Handler: ${err.message} | ${err.stack}`);
  // Send mail to the developer or support team to fix errors coming from the application
  await sendErrorLogs({
    error: err,
    mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
  });
  return res.status(statusCode).json({
    status: statusCode,
    message:
      process.env.NODE_ENV === 'development'
        ? err.message
        : 'Something went wrong!',
    stack: process.env.NODE_ENV === 'development' ? err.stack : null,
  });
};

exports.notFound = (_req, res) =>
  res.status(404).json({
    status: 404,
    message: responseMessages.ROUTE_NOT_FOUND,
  });
