const { isValidObjectId } = require('mongoose');
const responseMessages = require('../config/constants/reponseMessages');

/**
 * Checks if the req.params.id is a valid Mongoose ObjectId.
 */
function checkObjectId(req, res, next) {
  if (!isValidObjectId(req.params.id)) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.INVALID_ID,
    });
  }
  return next();
}

module.exports = checkObjectId;
