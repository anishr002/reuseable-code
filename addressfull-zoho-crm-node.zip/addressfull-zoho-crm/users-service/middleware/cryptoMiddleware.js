const asyncHandler = require('./asyncHandler');
const {
  generateSymmetricKey,
  encryptWithSymmetricKey,
  encryptSymmetricKeyWithRSA,
  decryptWithRSA,
  decryptWithSymmetricKey,
} = require('../helpers/cryptoHelper');
const userRoles = require('../config/constants/userRoles');
const { decodeJWTSign } = require('../helpers/jwtHelper');
const { decodeUser } = require('../services/commonService');
const logger = require('../logger');
const responseMessages = require('../config/constants/reponseMessages');

exports.decrypt = asyncHandler((req, res, next) => {
  const payload = req.body;
  const contentType = req.headers['content-type'];
  logger.info(`contentType: ${contentType}`);
  if (contentType === 'application/base64' && !Object.keys(payload).length) {
    try {
      let data = '';
      logger.info(`Doing Decryption`);
      req.on('data', (chunk) => {
        data += chunk.toString();
      });
      req.on('end', () => {
        req.parsedData = data.split('|'); // Parsing the data
        let keyType = 'pem';
        if (req.parsedData[3] && req.parsedData[3] === '10$') {
          keyType = 'der';
        } else if (req.parsedData[3] && req.parsedData[3] === '20$') {
          keyType = 'admin';
        }
        logger.info(`keyType while decrypt: ${keyType}`);
        if (req.parsedData.length >= 3) {
          let decryptedSymmetricKey = decryptWithRSA(
            req.parsedData[1],
            keyType
          );
          let descryptedIV = decryptWithRSA(req.parsedData[2], keyType);
          if (keyType === 'admin') {
            decryptedSymmetricKey = decryptedSymmetricKey.replace(
              /[^\x20-\x7E\n\r\t]/g,
              ''
            );
            descryptedIV = descryptedIV.replace(/[^\x20-\x7E\n\r\t]/g, '');
          }
          logger.info(`decryptedSymmetricKey: ${decryptedSymmetricKey}`);
          logger.info(`descryptedIV: ${descryptedIV}`);
          if (!decryptedSymmetricKey || !descryptedIV) {
            return res.status(400).json({
              status: 400,
              message: responseMessages.SOMETHING_WENT_WRONG,
            });
          }
          const bodyData = decryptWithSymmetricKey(
            req.parsedData[0],
            Buffer.from(decryptedSymmetricKey, 'base64'),
            Buffer.from(descryptedIV, 'base64')
          );
          logger.info(`BASE64 DATA: ${JSON.stringify(bodyData)}`);
          req.body = bodyData;
          req.body.encryptedPayload = data;
          return next();
        }
      });
    } catch (error) {
      logger.error(`decrypt-payload-error: ${error}`);
      return false;
    }
  } else {
    logger.info(`JSON PAYLOAD WITHOUT ENCRYPRION: ${JSON.stringify(req.body)}`);
    return next();
  }
});

exports.encrypt = asyncHandler(async (req, res, next) => {
  // Fetch client's public key from the DB to encrypt the response based on userType and keyType
  const tokenDecoded = await decodeJWTSign(req);
  const userDecoded = await decodeUser(tokenDecoded);
  if (
    (req.url === '/key-exchange' && req.headers?.s_api_key) ||
    (req.url === '/verify-otp' && req.body?.x_api_key) ||
    userDecoded?.userType === userRoles.FRONT_END_USER ||
    (userDecoded?.clientPublicKey !== undefined &&
      userDecoded?.clientPublicKey !== '')
  ) {
    res.json = function (data) {
      if (data) {
        /** Encrypt to a single string */
        const dataToEncrypt = data;
        const mobilePublicKey =
          dataToEncrypt?.publicKey ||
          req?.user?.clientPublicKey ||
          req.body?.x_api_key;
        logger.info(`clientkey: ${mobilePublicKey}`);
        delete dataToEncrypt.publicKey;
        const jsonString = JSON.stringify(data);
        logger.info(`jsonString: ${jsonString}`);
        const symmetricKey = generateSymmetricKey();
        logger.info(`symmetricKey: ${symmetricKey.toString('base64')}`);
        const iv = generateSymmetricKey(16);
        logger.info(`iv: ${iv.toString('base64')}`);
        const encryptedKey = encryptSymmetricKeyWithRSA(
          symmetricKey,
          mobilePublicKey
        );
        // logger.info(`encryptedKey: ${encryptedKey}`);
        const encryptedKeyIv = encryptSymmetricKeyWithRSA(iv, mobilePublicKey);
        // logger.info(`encryptedKeyIv: ${encryptedKeyIv}`);
        const encryptedData = encryptWithSymmetricKey(
          jsonString,
          symmetricKey,
          iv
        );
        if (encryptedData && encryptedKey && encryptedKeyIv) {
          // logger.info(
          //   `Result: ${encryptedData}|${encryptedKey}|${encryptedKeyIv}`
          // );
          return res.send(`${encryptedData}|${encryptedKey}|${encryptedKeyIv}`);
        }
        return res.send(`${encryptedData}`);
      }
      return res.json(data);
    };
  }
  next();
});
