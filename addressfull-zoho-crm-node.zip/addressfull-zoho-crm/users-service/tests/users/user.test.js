require('dotenv').config();
const chai = require('chai');
const chaiHttp = require('chai-http');
const should = require('chai').should();
const jwt = require('jsonwebtoken');
const server = require('../../index');
const supertest = require('supertest');
const sinon = require('sinon');
const logger = require('../../logger/index');
const User = require('../../models/user.model');
chai.use(chaiHttp);

let sandbox;
let request;

describe('Userlist api test cases', () => {
  it('should return all users with a valid JWT token', (done) => {

    const fakeUser = { id: 'f6fde248-7cd7-459a-9cc6-c7489853cd91', username: 'testuser' };
    const fakeToken = jwt.sign(fakeUser, process.env.SECRET_KEY); // Replace 'secretKey' with your JWT secret
    chai
      .request(server)
      .get('/api/v1/users/list')
      .set('Authorization', fakeToken)
      .end((err, res) => {
        res.should.have.status(200);
        res.body.should.be.an('object');
        done();
      });
  });
});

describe("Create user api test cases", () => {

  before(() => {
    sandbox = sinon.createSandbox();
    request = supertest(server);
  });

  after(() => {
    sandbox.restore();
  });

  it("should return 401 status code if Email is already exits in database!", async () => {
    const userData = {
      firstName: "Example",
      lastName: "User",
      email: "example@yopmail.com",
      password: "1234567890",
    };

    const res = await request.post("/api/v1/users/create").send(userData);

    res.should.have.status(401);
    res.body.should.have.property("message").eql("User is already exits.");
    res.body.should.be.a("object");
  });

  it("should return 200 status code and a success message on successfull Adduser", async () => {
    const userData = {
      firstName: "Rahul",
      lastName: "Patel",
      email: "rahul@gmail.com",
      password: "1234567890",
    };

    sandbox.stub(User, "create").resolves(userData);

    const res = await request.post("/api/v1/users/create").send(userData);

    res.should.have.status(200);
    res.body.should.be.a("object");
    res.body.should.have.property("message").eql("User has been created successfully.");
  });
});

describe("Login user api test cases", () => {

  it("should return a 400 status code for Email is incorrect", (done) => {
    const user = { email: "mihir@gmail.com", password: "example@123" };
    chai
      .request(server)
      .post("/api/v1/users/login")
      .send(user)
      .end((err, res) => {
        res.should.have.status(400);
        res.body.should.be.an("object");
        res.body.should.have.property("message").eql("Email is incorrect.");
        done();
      });
  });

  it("should return a 403 status code for a password is incorrect", (done) => {
    const user = { email: "example@yopmail.com", password: "12345617890" };
    chai
      .request(server)
      .post("/api/v1/users/login")
      .send(user)
      .end((err, res) => {
        res.should.have.status(403);
        res.body.should.be.an("object");
        res.body.should.have.property("message").eql("Password is incorrrect.");
        done();
      });
  });

  it("should return a 200 status code on successful login", (done) => {
    const user = { email: "example@yopmail.com", password: "example@123" };
    chai
      .request(server)
      .post("/api/v1/users/login")
      .send(user)
      .end((err, res) => {
        res.should.have.status(200);
        res.body.should.be.an("object");
        res.body.should.have.property("message").eql("Login successful.");
        res.body.should.have.all.keys("message", "email", "token");
        done();
      });
  });
});

describe("User details update api test cases", () => {

  before(() => {
        sandbox = sinon.createSandbox();
        request = supertest(server);
      });

  afterEach(() => {
    sandbox.restore();
  });

  it("should return a 200 status code if user update successfully", async () => {

    const fakeUser = { id: 'f6fde248-7cd7-459a-9cc6-c7489853cd91', username: 'testuser' };
    const fakeToken = jwt.sign(fakeUser, process.env.SECRET_KEY); // Replace 'secretKey' with your JWT secret

    let userData = {
      firstName: "Raju",
      lastName: "Japan",
      email: "raju@gmail.com",
    };
    sandbox.stub(User, "update").resolves(userData);

    const res = await request.put('/api/v1/users/update-user').set('Authorization', fakeToken).send(userData);
    res.should.have.status(200);
    res.body.should.be.an("object");

  });
});

describe("User soft delete api test cases", () => {

  before(() => {
        sandbox = sinon.createSandbox();
        request = supertest(server);
      });

  afterEach(() => {
    sandbox.restore();
  });

  it("should return a 401 status code if user is unauthenticate", async () => {

    const id = "f6fde248-7cd7-459a-9cc6-c7489853cd90";
    const fakeUser = { id: 'f6fde248-7cd7-459a-9cc6-c7489853cd90', username: 'testuser' };
    const fakeToken = jwt.sign(fakeUser, process.env.SECRET_KEY); // Replace 'secretKey' with your JWT secret

    let userData = {
      isDeleted: true
    };
    sandbox.stub(User, "update").resolves(userData);

    const res = await request.delete(`/api/v1/users/delete/${id}`).set('Authorization', fakeToken).send(userData);
    res.should.have.status(401);
    res.body.should.be.an("object");

  });

  it("should return a 200 status code if user update successfully", async () => {

    const id = "f6fde248-7cd7-459a-9cc6-c7489853cd91";
    const fakeUser = { id: 'f6fde248-7cd7-459a-9cc6-c7489853cd91', username: 'testuser' };
    const fakeToken = jwt.sign(fakeUser, process.env.SECRET_KEY); // Replace 'secretKey' with your JWT secret

    let userData = {
      isDeleted: true
    };
    sandbox.stub(User, "update").resolves(userData);

    const res = await request.delete(`/api/v1/users/delete/${id}`).set('Authorization', fakeToken).send(userData);
    res.should.have.status(200);
    res.body.should.be.an("object");
    res.body.should.have.property("message").eql("User deleted successfully.");
  });

});

describe('User details api test cases', () => {

  it('should return a 401 status code if user is unauthnticate', () => {
    const fakeUser = { id: 'f6fde248-7cd7-459a-9cc6-c7489853cd90', username: 'testuser' };
    const fakeToken = jwt.sign(fakeUser, process.env.SECRET_KEY); // Replace 'secretKey' with your JWT secret
    chai
      .request(server)
      .get('/api/v1/users/details')
      .set('Authorization', fakeToken)
      .end((err, res) => {
        res.should.have.status(401);
      });
  });

  it('should return a 200 status code if user details get successfully', () => {
    const fakeUser = { id: 'f6fde248-7cd7-459a-9cc6-c7489853cd91', username: 'testuser' };
    const fakeToken = jwt.sign(fakeUser, process.env.SECRET_KEY); // Replace 'secretKey' with your JWT secret
    chai
      .request(server)
      .get('/api/v1/users/details')
      .set('Authorization', fakeToken)
      .end((err, res) => {
        res.should.have.status(200);
        res.body.should.be.an('object');
        res.body.should.have.property("message").eql("User details get successfully.");
      });
  });

});

describe('Forgot password api test cases', () => {
  before(() => {
    sandbox = sinon.createSandbox();
    request = supertest(server);
  });

  afterEach(() => {
    sandbox.restore();
  });

  // it('should return a 404 status code for user mobile was wrong', (done) => {
  //   const user = { emailOrNumber: '7069563140' };
  //   chai
  //     .request(server)
  //     .post('/api/v1/users/forgot-password')
  //     .send(user)
  //     .end((err, res) => {
  //       res.should.have.status(404);
  //       res.body.should.be.an('object');
  //       res.body.should.have.property('message').eql('User doest not exists.');
  //       done();
  //     });
  // });

  // it('should return a 200 status code for user mobile number get', () => {
  //   const user = { emailOrNumber: '7069563142' };
  //   chai
  //     .request(server)
  //     .post('/api/v1/users/forgot-password')
  //     .send(user)
  //     .end((err, res) => {
  //       res.should.have.status(200);
  //       res.body.should.be.an('object');
  //       res.body.should.have.property('message').eql('Otp send successfully.');
  //     });
  // });

  it('should return a 404 status code for user email was wrong', () => {
    const user = { emailOrNumber: 'example1@yopmail.com' };
    chai
      .request(server)
      .post('/api/v1/users/forgot-password')
      .send(user)
      .end((err, res) => {
        res.should.have.status(404);
        res.body.should.be.an('object');
        res.body.should.have.property('message').eql('User doest not exists.');

      });
  });

  it('should return a 200 status code for user email was correct', () => {
    const user = { emailOrNumber: 'example@yopmail.com' };
    chai
      .request(server)
      .post('/api/v1/users/forgot-password')
      .send(user)
      .end((err, res) => {
        res.should.have.status(200);
        res.body.should.be.an('object');
        res.body.should.have.property('message').eql('Forgot password email send success.');

      });
  });
});

describe('Reset password api test cases', () => {
  before(() => {
    sandbox = sinon.createSandbox();
    request = supertest(server);
  });

  afterEach(() => {
    sandbox.restore();
  });

  it('should return a 400 status code if user doest not exits successfully', async () => {
    let userData = {
      resetPasswordToken:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImY2ZmRlMjQ4LTdjZDctNDU5YS05Y2M2LWM3NDg5ODUzY2Q5MSIsImlhdCI6MTY5Nzc0Mjk4MSwiZXhwIjoxNjk4OTUyNTgxfQ.cBTmyxJJgPHq_67jecAzc1jL2GCJwjGMp90E4LSL7qs',
      newPassword: 'example@123',
    };
    sandbox.stub(User, 'update').resolves(userData);

    const res = await request.post('/api/v1/users/reset-password').send(userData);
    res.should.have.status(400);
    res.body.should.be.an('object');
    res.body.should.have.property('message').eql('User doest not exists.');
  });
  
  it('should return a 200 status code if password has been changed successfully', async () => {
    let userData = {
      resetPasswordToken:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImY2ZmRlMjQ4LTdjZDctNDU5YS05Y2M2LWM3NDg5ODUzY2Q5MSIsImlhdCI6MTY5Nzc0NDI5MSwiZXhwIjoxNjk4OTUzODkxfQ.O5NJy0DwKx6__VuXl630qJWHVX6ecvz8Wvp3WMQR4KM',
      newPassword: 'example@123',
    };
    sandbox.stub(User, 'update').resolves(userData);

    const res = await request.post('/api/v1/users/reset-password').send(userData);
    res.should.have.status(200);
    res.body.should.be.an('object');
    res.body.should.have.property('message').eql('Password has been changed successfully.');
  });
});
