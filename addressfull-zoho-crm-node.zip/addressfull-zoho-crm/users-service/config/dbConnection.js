const mongoose = require('mongoose');
const logger = require('../logger');

const dbConnect = async () => {
  await mongoose
    .connect(process.env.MONGODB_URI)
    .then((conn) => {
      logger.info(`Database is running on ${conn.connection.host}`);
    })
    .catch((err) => {
      logger.error(`Error in connecting DB: ${err}`);
    });
};

module.exports = dbConnect;
