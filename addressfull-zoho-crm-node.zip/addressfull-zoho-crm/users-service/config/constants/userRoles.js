const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  FRONT_END_USER: 'front-end-user',
  ORGANIZATION_ADMIN: 'organization-admin',
  SUPER_ADMIN: 'super-admin',
  SUB_ADMIN: 'sub-admin',
});
