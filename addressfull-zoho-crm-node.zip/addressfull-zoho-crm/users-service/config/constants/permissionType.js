const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  READ: 'read',
  READ_WRITE: 'read-write',
  UNSET: null,
});
