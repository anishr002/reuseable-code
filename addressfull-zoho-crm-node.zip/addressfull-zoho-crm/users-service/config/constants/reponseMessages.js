const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  PASSWORD_RESET_TOKEN_EXPIRED:
    'Link is expired. Please try resetting your password again.',
  PASSWORD_RESET_LINK_SENT:
    'The password reset link has been successfully sent to the provided email',
  ORGANIZATION_REGISTRATION_LINK_SENT:
    'The organisation registration link has been successfully sent to the registered email',
  ORGANIZATION_REGISTRATION_LINK_RESENT:
    'Your email is not verified. The link has been sent to the registered email. Please check your email account and click on the provided link to verify your AddressFull account.',

  // --- OTP Messages and Errors
  OTP_SENT_MAIL:
    'Verification code has been successfully sent to the provided email',
  OTP_SENT_MOBILE:
    'Verification code has been successfully sent to the provided mobile number',
  OTP_NOT_SENT_MOBILE:
    'We were unable to send the verification code to the provided mobile number',
  OTP_VERIFIED: 'Verification code has been verified',
  OTP_INVALID: 'Verification code is expired or incorrect',

  // --- Validation Errors Users
  INVALID_EMAIL_PASSWORD: 'Invalid email or password',
  INVALID_MOBILE: 'Invalid country code or mobile number',
  USER_NOT_AVAILABLE:
    'Account deactivated! Contact support to reactivate your account.',
  USER_NOT_EXIST:
    'Account deactivated! Contact support to reactivate your account.',
  DEVICE_NOT_EXIST: 'Unknown device',
  SIGNUP_FIRST:
    'Unregistered user! You need to create an AddressFull account in order to sign in.',
  ACCOUNT_MULTIPLE_DEVICE:
    'An account already exists on this device or another device',
  ACCOUNT_DELETE_PROCESS_PENDING:
    'Your account will be deleted as per your request. Please allow up to 24 hours for it to be processed.',
  USER_DUPLICATE_MOBILE: 'Provided mobile number already in use',
  ADMIN_PUBLIC_KEY_MISSING: 'Key is missing',
  ACCOUNT_EXIST: 'Account already exists',
  ACCOUNT_CREATION_FAIL: 'There was an issue in creating your account',
  ACCOUNT_NOT_ACTIVE:
    'User already exists! Contact support to reactivate your account',
  ACCOUNT_DELETED: 'Account has been deleted',
  ACCOUNT_DELETION_PENDING:
    'We are in the process of deleting your account. Please allow up to 24 hours for it to be processed.',
  USER_DATA_DELETION_PENDING:
    'We are deleting all of your organisations from your account. We will notify you once they have been successfully removed.',
  NOTIFICATION_READ_SUCCESS: 'All notifications read',

  // --- Validation Errors: Uploads
  PROFILE_PIC_MISSING: 'Profile picture is required',
  PROFILE_PIC_FILETYPE: 'Only images are allowed',
  PROFILE_PIC_UPLOAD_SUCCESS: 'Profile picture has been successfully uploaded',
  PROFILE_PIC_UPLOAD_ERROR: 'Profile picture upload has failed',
  PROFILE_PIC_SIZE: 'Image size should be less than 2 MB',
  PROFILE_PIC_DEL_SUCCESS: 'Profile picture has been successfully removed',
  PROFILE_PIC_NOT_FOUND: 'Profile picture is not set',
  // DOCUMENT_FILETYPE: 'Only doc, docx, xlsx, pdf, jpg, jpeg, png file types are allowed.',
  DOCUMENT_FILETYPE: 'Only mentioned document types are allowed.',
  PROFILE_FILETYPE: 'Only jpg, jpeg, png file types are allowed',

  // Validation Errors: User Profile
  PROFILE_UPDATE_SUCCESS: 'Your profile has been updated successfully.',
  ORG_PROFILE_UPDATE_SUCCESS:
    'Your profile has been updated successfully. We have received your request and will process it soon.',
  // PROFILE_UPDATE_PENDING:
  //   'We have received your request to update your profile. We will notify you once it is has been successfully completed.',
  PROFILE_UPDATE_PENDING:
    'AddressFull is processing your request. We will notify you once your contact details are updated and shared with your organisations.',

  // --- Validation Errors: Organisations
  ORG_NOT_FOUND: 'Organisation not found',
  ORG_WITH_USER_EXISTS:
    'You can’t delete this organisation because there are users associated with it',
  INVALID_QR: 'Invalid QR code',

  // --- Validation Errors: Roles
  ROLES_WRONG_MODULE: 'Invalid module name provided',
  ROLES_WRONG_PERMISSION: 'Invalid permission type provided',
  ROLES_CREATED: 'The record has been successfully added',
  ROLES_UPDATED: 'The record has been successfully updated',
  ROLES_NOT_FOUND: 'Role not found',
  ROLES_USER_EXISTS: "Role can't be removed. A user with this role exists.",
  ROLES_USER_EXISTS_UPDATE:
    "Role can't be deactivated. User with this role exists.",
  ROLES_DELETED: 'The record has been successfully deleted',
  ROLE_INVALID: 'Role is invalid',
  ROLE_NAME_EXISTS: 'Role with the provided name already exists',

  // --- Validation Errors: Organisations
  ORGANIZATION_CREATED: 'The record has been successfully added',
  ORGANIZATION_UPDATED: 'The record has been successfully updated',
  ORGANIZATION_NOT_FOUND: 'Record can’t be found',
  ORGANIZATION_DELETED: 'The record has been successfully deleted',
  ORGANIZATION_DOC_UPLOAD: 'Document has been successfully uploaded',
  ORGANIZATION_DOC_REMOVE: 'Document has been successfully removed',
  ORGANIZATION_DOC_REMOVE_ERR: 'Organisation not found or document not removed',
  ORGANIZATION_NAME_EXISTS:
    'Organisation with the provided name already exists',
  ORGANIZATION_EMAIL_EXISTS:
    'Organisation with the provided email already exists',
  ORGANIZATION_NUMBER_EXISTS:
    'Organisation with the provided registered number already exists',
  MY_TRUSTED_ORGANIZATION_SAVED:
    'Organisation has been successfully added to my organisations',
  MY_TRUSTED_ORGANIZATION_NOT_EXISTS:
    'Organisation does not exist in my organisations',
  MY_TRUSTED_ORGANIZATION_REMOVED:
    'Organisation was successfully removed from my organisations',
  NO_ANY_TRUSTED_ORGANIZATION:
    'You currently do not have any organisations to delete',

  // Request
  REQUEST_ACCESS_NOT_EXISTS: "You don't have permission to update this request",
  REQUEST_SENT: 'Request has been successfully sent',
  REQUEST_FAIL: 'Request was not sent',
  REQUEST_SUCCESS: 'Request was approved',
  REQUEST_REJECT: 'Request was rejected',

  // --- Validation Errors: Admins
  ADMIN_CREATED: 'The record has been successfully added',
  ADMIN_EXISTS: 'Account already exists',
  ADMIN_NOT_FOUND: 'Record can’t be found',
  ADMIN_UPDATED: 'The record has been successfully updated',
  ADMIN_DELETED: 'The record has been successfully deleted',

  // --- Blockchain Error Messages
  USER_NOT_FOUND: 'User not found',
  BLOCKCHAIN_ACCOUNT_EXISTS: 'Blockchain account already exists',
  BLOCKCHAIN_ACCOUNT_NOT_EXISTS: 'Blockchain account not found',
  BLOCKCHAIN_ACCESS_DENIED: "You don't have access to Blockchain",
  BLOCKCHAIN_TRANSACTION_CREATED:
    'Your data has been shared with your organisation',
  BLOCKCHAIN_TRANSACTION_FAILED: 'Unable to share data with organisation',
  BLOCKCHAIN_TRANSACTION_REJECT: 'Blockchain transaction failed',
  BLOCKCHAIN_TRANSACTION_REQUEST_FAILED:
    'Request rejected because Blockchain transaction failed',
  BLOCKCHAIN_TRANSACTION_SUCCESS: 'Transaction was successfully completed',
  ACTIVITY_FILTER_SUCCESS: 'Activity filters were successfully set',
  TOKEN_REFRESH: 'Token was successfully regenerated',
  SERVER_DOWN_ERROR:
    'Apologies, our server is currently down. Please try again later.',

  // --- General Error Messages
  SOMETHING_WENT_WRONG: 'Something is wrong',
  SOMETHING_WENT_WRONG_BLOCKCHAIN: 'Something is wrong with Blockchain',
  UNAUTHORIZED_ERROR: 'Unauthorized access',
  UNAUTHORIZED_ACCESS: 'Your session has expired',
  UNAUTHORIZED_ACCESS_WRONG_URL:
    'Unauthorized access! Please check URL or login credentials.',
  ADMIN_DELETED_ACCOUNT: 'Account deleted by Admin! Contact admin for help.',
  DEVICE_CHANGE_ERROR: 'You are already logged in on another device',
  ACCOUNT_DISABLE: 'Your account has been deactivated on your request',
  ROUTE_NOT_FOUND: 'Route not found',
  INVALID_ID: 'Invalid or missing ID',

  // --- Updation Messages
  PASSWORD_UPDATE_SUCCESS: 'Password was successfully updated',
  OLD_NEW_PASSWORD_SAME: 'New password and old password should not be the same',

  // --- Settings Messages
  EMAIL_TEMPLATE_UPDATED: 'The record has been successfully updated',
  SETTINGS_UPDATED: 'Settings have been successfully updated',

  // --- CRM Integration
  CRM_CONNECTED: 'The record has been successfully updated',
  CRM_NOT_CONNECTED: 'There was an issue connecting to the CRM',
  INVALID_ZOHO_AUTH_CODE:
    'Invalid or expired Zoho authorization code. Please reconnect Zoho CRM.',

  // --- Cron messages
  CRON_REQUEST_IN_PROGRESS:
    'Your previous data update request is currently in progress. Please allow up to 24 hours for it to be processed.',
  CRON_ACCOUNT_DELETION_REQUEST:
    'Account delete request has been successfully submitted! It may take up to 24 hours for it to be processed.',
  CRON_ACCOUNT_DELETED: 'Your account has been successfully deleted',
  CRON_ACCOUNT_DELETED_TITLE: 'Delete account',
  CRON_ACCOUNT_DELETED_FAIL:
    'Account deletion process has failed. Please try again later.',
  CRON_ORGANIZATIONS_DELETED:
    'Your organisations have been successfully deleted',
  CRON_ORGANIZATIONS_DELETED_TITLE: 'Delete organisations',
  CRON_ORGANIZATIONS_DELETED_FAIL:
    'Organisation delete request has failed. Please try again later.',
  CRON_AUTO_SYNC_SUCCESS:
    'Your contact details on AddressFull have been updated and shared with your organisations',
  CRON_AUTO_SYNC:
    'Your contact details on AddressFull have been updated and shared with your organisations',
  CRON_AUTO_SYNC_TITLE: 'Update profile',
  CRON_AUTO_SYNC_FAIL: 'Profile update has failed. Please try again later.',

  CRON_REQUEST_REMINDER:
    'You have REQUEST_COUNT pending requests waiting your action',
  CRON_REQUEST_REMINDER_TITLE: 'Request reminder',
  CRON_REQUEST_REMINDER_FAIL: 'Request reminder process has failed',

  // --- Joi Validation Messages
  PROFILE_UPDATE_NOCHANGE:
    'You have not changed anything, there is nothing to update',
  INVALID_SEARCH: 'Invalid search string',
  MAX_SEARCH: 'Search keywords should not exceed 30 characters',
  INVALID_CREDS: 'Invalid credentials',
  INVALID_OBJECT_ID: 'Invalid ID',
  // Organisation validation messages
  INVALID_SOCIAL_LINKEDIN: 'Invalid LinkedIn profile URL',
  INVALID_SOCAIL_TWITTER: 'Invalid Twitter profile URL',
  SEND_DOWNLOAD_LINK_MESSAGE:
    'XYZ organisation has requested your contact details. Download the AddressFull app to start sharing with them now! \n\nIOS: https://apps.apple.com/in/app/addressfull/id6648764697\n\nAndroid: https://play.google.com/store/apps/details?id=com.addressful',

  // --- PDF validation
  REPORT_NO_ORG:
    'You currently do not have any organisations to generate a report',
  REPORT_FAIL: 'Report generation failed. Please try again later.',
  REPORT_ACCESS_DENIED: 'Resource not found',
  EXCEL_REQ_SENT:
    'Your data requests have been successfully sent to all of the contact numbers contained in the uploaded document',
  EXCEL_REQ_SENT_SUCCESS:
    'Your data requests have been received. We will proceed immediately and provide updates soon. Thank you for your patience.',
  EXCEL_ALL_REQ_FAIL:
    'Your data requests have failed. Please try to upload the document again.',
  EXCEL_FEW_REQ_FAIL: 'Unable to send request due to a technical issue',

  // --- S3 bucket
  RESOURCE_NOT_FOUND: 'Resource not found',

  // Policy Validation
  POLICY_SUB_RULES_ERROR: 'Policy sub rules can’t be empty',
  POLICY_CREATED: 'Policy has been successfully added',
  POLICY_UPDATED: 'Policy has been successfully updated',
  POLICY_DELETED: 'Policy has been successfully removed',
  POLICY_CREATE_ERROR: 'Unable to create policy',
  POLICY_NAME_EXISTS: 'Policy with the provided name already exists',
  POLICY_NOT_FOUND: 'Policy not found',
  POLICY_SYNC_ERROR:
    "Policy can't be removed or edited. Organisation with this policy already exists.",
  POLICY_RULE_ERROR:
    'Some policy rules are being used by this organisation. You can’t update those rules.',

  // Block Organisation
  BLOCK_ORG_EXISTS: 'Organisation has already been blocked',
  UNBLOCK_ORG_NOT_POSSIBLE:
    'You have not blocked this organisation. It can’t be unblocked.',
  BLOCK_ORG_SUCCESS: 'Organisation has been successfully blocked',
  UNBLOCK_ORG_SUCCESS: 'Organisation has been successfully unblocked',
  BLOCK_ORG_ERROR: 'Unable to block organisation',
  UNBLOCK_ORG_ERROR: 'Unable to unblock organisation',
  BLOCK_REQUEST_SEND_ERROR:
    "You can't send a request. The user has blocked you.",
  BLOCK_DATA_SHARE_ERROR:
    'Unblock first! You have blocked this organisation and must first unblock them in order to proceed.',
  QR_CODE_INVALID_COUNTRY:
    'Data sharing with organisations from other countries is not allowed. Please only share QR codes from your country.',
  DATA_REQUEST_INVALID_COUNTRY:
    "You can't send a data request to another country's user",
  BLOCKED_ORG_ERROR:
    "You can't accept or reject this request because you have blocked them",
  CRON_HISTORY_SUCCESS: 'Cron history successfully generated',
  DEVICE_UPDATE_SUCCESS: 'Force update successfully added for [DEVICE_TYPE]',
  DEVICE_GET_SUCCESS:
    'Force update status successfully fetched for [DEVICE_TYPE]',
});
