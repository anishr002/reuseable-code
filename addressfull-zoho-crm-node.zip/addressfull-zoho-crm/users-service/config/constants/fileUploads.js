const { deepFreezeObject } = require('../../utils/objectUtils');

// All File Upload Paths
module.exports = deepFreezeObject({
  DEFAULT_UPLOAD: 'uploads',
  PROFILE_PICTURE: 'uploads/profilePictures',
  DOCUMENT_UPLOAD: 'uploads/orgDocuments',
  KEYPAIR_RELATIVE_PATH: '../keyStore',
  USER_AUTO_SYNC_FOLDER_RELATIVE_PATH: '../cronData',
  S3_REPORTS_FOLDER: 'reports',
});
