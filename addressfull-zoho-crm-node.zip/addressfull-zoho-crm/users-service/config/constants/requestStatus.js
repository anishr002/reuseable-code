const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  ACCEPT: 'ACCEPT',
  REJECT: 'REJECT',
  SHARE: 'SHARE',
  UNSHARE: 'REVOKE',
  SENT: 'SENT',
  NONE: 'NONE',
});
