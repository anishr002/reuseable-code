const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  TWILIO: 'twilio',
  AWS: 'aws',
});
