const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  /** Mail Configs */
  MAIL_FROM: 'developer@addressfull.com',
  MAIL_FROM_NAME: 'AddressFull',
  ERROR_LOGS_MAIL_TO: '',
  CRITICAL_ERROR_LOGS_MAIL_TO: '',

  /** Mail Subjects */
  SUBJECT_ERROR_LOGS: 'AddressFull Error Logs',
  SUBJECT_CRITICAL_ERROR_LOGS: 'AddressFull Critical Error Logs',

  /** Mail Types */
  MAIL_TYPES: {
    OTP_MAIL: 'send-otp',
    PASSWORD_RESET_LINK_MAIL: 'password-reset',
    ACCOUNT_CREATED_MAIL: 'new-account',
    ORGANIZATION_REGISTRATION_MAIL: 'organization-registration',
    ORGANIZATION_REGISTERED_MAIL: 'organization-registered',
    DELETE_USER_DATA_NOTIFICATION: 'delete-user-data-notification',
    BLOCK_USER_DATA_NOTIFICATION: 'block-user-data-notification',
    PROFILE_APPROVAL_PENDING_NOTIFICATION:
      'profile-approval-pending-notification',
    PROFILE_APPROVAL_SUCCESS_NOTIFICATION:
      'profile-approval-success-notification',
    ERROR_LOGS: 'error-logs',
    CRITICAL_ERROR_LOGS: 'critical-error-logs',
  },

  /** Template Text */
  TEMPLATE_VAR_PLACEHOLDER: 'templateVars',
});
