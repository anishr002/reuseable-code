const { deepFreezeObject } = require('../../utils/objectUtils');

// General Configs
module.exports = deepFreezeObject({
  // DEFAULT_JWT_EXPIRATION: '15m',
  DEFAULT_JWT_EXPIRATION: '7d',
  TWILIO_TO_PHONE_NUMBER: '+917228883394',
  DEFAULT_PASSWORD: 'Abcd#&@123',
});
