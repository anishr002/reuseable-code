const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  HUBSPOT: 'hubspot',
  ZOHO: 'zoho',
  // SALESFORCE: 'salesforce',
});
