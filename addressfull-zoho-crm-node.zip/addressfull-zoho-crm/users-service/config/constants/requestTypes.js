const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  REQUEST: 'REQUEST',
  CONSENT: 'CONSENT',
});
