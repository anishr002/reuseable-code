const { deepFreezeObject } = require('../../utils/objectUtils');

module.exports = deepFreezeObject({
  DASHBOARD: 'dashboard',
  ROLE_MODULE: 'roles',
  ADMIN_MODULE: 'admins',
  ORGANIZATION_MODULE: 'organizations',
  USER_MODULE: 'users',
  REQUEST_MODULE: 'requests',
  CRM_SETTING_MODULE: 'crm_settings',
  TRANSACTION_MODULE: 'transactions',
  GENERAL_SETTING_MODULE: 'general_settings',
  PRIVACY_POLICY_SETTINGS: 'privacy_policy_settings',
  SMS_LOGS_MODULE: 'message_logs',
});
