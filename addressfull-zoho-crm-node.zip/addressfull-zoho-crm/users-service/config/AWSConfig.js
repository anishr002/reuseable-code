const AWSConfig = {
  accessKey: process.env.AWS_ACCESS_KEY,
  secretKey: process.env.AWS_SECRET_KEY,
  bucketName: 'addressfull-uat-filesystem',
  region: 'eu-west-2',
};

module.exports = AWSConfig;
