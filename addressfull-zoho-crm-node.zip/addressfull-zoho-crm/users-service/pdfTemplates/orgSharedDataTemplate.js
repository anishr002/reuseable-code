const moment = require('moment');
const { generateProfileImageFromS3 } = require('../services/userService');
const { replacePDFWords } = require('../services/blockChainService');

async function createOrgSharedDataTemplate(
  organizationsData,
  loggedInUserData
) {
  const { sharedData, sharedDataTimestamp } = loggedInUserData;

  const htmlBodyData = await Promise.all(
    organizationsData.map(async (orgData) => {
      const sharedDataContent = replacePDFWords(
        (sharedData.get(orgData._id) || []).join('<br>')
      );
      const numberOfSharedDataItems = sharedDataContent.split('<br>').length;

      const profileImageUrl =
        (await generateProfileImageFromS3(
          orgData.userId._id,
          orgData.userId.profileImage
        )) || '';

      const timestamp = moment(sharedDataTimestamp.get(orgData._id)).format(
        'DD/MM/YYYY, dddd, hh:mm A'
      );

      // Address labels render
      const addresses = [
        'address 1',
        'address 2',
        'address 3',
        'address 4',
        'address 5',
      ];

      // Function to capitalize the first letter of a string
      const capitalizeFirstLetter = (str) =>
        str.charAt(0).toUpperCase() + str.slice(1);

      // Check if any address is included in sharedDataContent
      const hasAddress = addresses.some((address) =>
        sharedDataContent.includes(address)
      );

      // Build the HTML content if any address is included
      let addressHtml = '';
      if (hasAddress) {
        addressHtml += '<div style="display: grid;">';
        addressHtml += '<h6 style="font-weight: bold">Address</h6>';
        addresses.forEach((address) => {
          if (sharedDataContent.includes(address)) {
            const capitalizedAddress = capitalizeFirstLetter(address);
            addressHtml += `<span style="color: #687A82">${capitalizedAddress}</span>`;
          }
        });
        addressHtml += '</div>';
      }

      // Social icon renders
      const hasSocialMedia =
        sharedDataContent.includes('LinkedIn') ||
        sharedDataContent.includes('Twitter');

      // Create the social media icons HTML
      let socialMediaIcons = '';
      if (sharedDataContent.includes('LinkedIn')) {
        socialMediaIcons += `
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 5px; display: inline-block;">
      <path d="M16.5604 0H1.53803C0.717186 0 0 0.590625 0 1.40183V16.4575C0 17.2732 0.717186 18 1.53803 18H16.556C17.3812 18 18 17.2683 18 16.4575V1.40183C18.0048 0.590625 17.3812 0 16.5604 0ZM5.57959 15.0039H3.00093V6.98625H5.57959V15.0039ZM4.37946 5.76723H4.36097C3.53571 5.76723 3.00133 5.1529 3.00133 4.38388C3.00133 3.6008 3.54977 3.00094 4.39352 3.00094C5.23727 3.00094 5.75356 3.59638 5.77204 4.38388C5.77164 5.1529 5.23727 5.76723 4.37946 5.76723ZM15.0039 15.0039H12.4252V10.62C12.4252 9.56973 12.0499 8.85214 11.117 8.85214C10.4042 8.85214 9.98235 9.33429 9.79472 9.80397C9.7244 9.97272 9.70552 10.2025 9.70552 10.4372V15.0039H7.12686V6.98625H9.70552V8.10201C10.0808 7.56763 10.667 6.79862 12.0311 6.79862C13.7238 6.79862 15.0043 7.91438 15.0043 10.3199L15.0039 15.0039Z" fill="black"/>
    </svg>`;
      }

      if (sharedDataContent.includes('Twitter')) {
        socialMediaIcons += `
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 5px; display: inline-block;">
      <path d="M2.57143 0C1.15313 0 0 1.15313 0 2.57143V15.4286C0 16.8469 1.15313 18 2.57143 18H15.4286C16.8469 18 18 16.8469 18 15.4286V2.57143C18 1.15313 16.8469 0 15.4286 0H2.57143ZM14.5085 3.375L10.3379 8.14018L15.2437 14.625H11.4027L8.39732 10.6915L4.95402 14.625H3.04554L7.50536 9.52634L2.80045 3.375H6.73795L9.45804 6.97098L12.6 3.375H14.5085ZM12.9897 13.4839L6.16339 4.4558H5.02634L11.929 13.4839H12.9857H12.9897Z" fill="black"/>
    </svg>`;
      }

      // Construct the final social HTML
      const socialHTML = hasSocialMedia
        ? `
    <h6 style="font-weight: bold; margin: 0;">Social</h6>
    <div style="display: flex">
      ${socialMediaIcons}
    </div>`
        : '';

      return `
        <div class="card p-4 rounded mt-4 text-left">
          <h5>${numberOfSharedDataItems} shared details</h5>
          <div class="d-flex align-items-center" style="padding:0.2cm">
            <img src="${profileImageUrl}" class="img-fluid rounded-circle float-left text-left" style="width: 7%;" alt="Logo" />
            <span class="pl-3" style="font-size: 20px;">${orgData.name}</span>
          </div>
          <hr class="border border-2 opacity-50">
          <div>
            <div style="display: grid;">
              <h6 style="font-weight: bold">Name</h6>
              ${sharedDataContent.includes('first name') ? '<span style="color: #687A82">First Name</span>' : ''}
              ${sharedDataContent.includes('first name') ? '<span style="color: #687A82">Last Name</span>' : ''}
            </div>
            <br />
            <div style="display: grid;">
              <h6 style="font-weight: bold">Mobile number</h6>
              ${sharedDataContent.includes('mobile number 1') ? '<span style="color: #687A82">Mobile number 1</span>' : ''}
              ${sharedDataContent.includes('mobile number 2') ? '<span style="color: #687A82">Mobile number 2</span>' : ''}
              ${sharedDataContent.includes('mobile number 3') ? '<span style="color: #687A82">Mobile number 3</span>' : ''}
              ${sharedDataContent.includes('mobile number 4') ? '<span style="color: #687A82">Mobile number 4</span>' : ''}
              ${sharedDataContent.includes('mobile number 5') ? '<span style="color: #687A82">Mobile number 5</span>' : ''}
            </div>
            <br />
            <div style="display: grid;">
              <h6 style="font-weight: bold">Email</h6>
              ${sharedDataContent.includes('email 1') ? '<span style="color: #687A82">Email 1</span>' : ''}
              ${sharedDataContent.includes('email 2') ? '<span style="color: #687A82">Email 2</span>' : ''}
              ${sharedDataContent.includes('email 3') ? '<span style="color: #687A82">Email 3</span>' : ''}
              ${sharedDataContent.includes('email 4') ? '<span style="color: #687A82">Email 4</span>' : ''}
              ${sharedDataContent.includes('email 5') ? '<span style="color: #687A82">Email 5</span>' : ''}
            </div>
            <br />
            ${hasAddress ? addressHtml : ''}
            <br />
            <div style="display: grid; gap: 10px; align-items: center;">
              ${socialHTML}
            </div>
          <br />
          </div>
          <hr class="border border-2 opacity-50">
          <div>Shared on <strong>${timestamp}</strong></div>
        </div>`;
    })
  );

  const htmlData = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PDF Generation</title>
        <!-- Add any additional CSS or meta tags here -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="misc-inner p-sm-7" style="width: 21cm; min-height: 29.7cm; margin: auto; padding: 0.5cm;">
            <div class="w-100 text-center">
                <div>
                    <div class="justify-content-center">
                        <h3 class="card-text justify-content-center">Shared Data Report</h3>
                    </div>
                    <!-- Start Loop for Shared Data -->
                    ${htmlBodyData.join('')}
                    <!-- End Loop for Shared Data -->
                </div>
            </div>
        </div>
    </body>
    </html>`;
  return htmlData;
}

module.exports = createOrgSharedDataTemplate;
