const AWS = require('aws-sdk');
const fs = require('fs').promises; // Use fs.promises for async file reading
const path = require('path');
const AWSconfig = require('../config/AWSConfig');
const { generateJWTSign } = require('./jwtHelper');
const logger = require('../logger');

AWS.config.update({
  region: AWSconfig.region,
  accessKeyId: AWSconfig.accessKey,
  secretAccessKey: AWSconfig.secretKey,
});

const s3 = new AWS.S3();

// Function to determine the content type based on file extension
const getContentType = (fileName) => {
  const ext = path.extname(fileName).toLowerCase();

  switch (ext) {
    case '.doc':
    case '.docx':
      return 'application/msword';
    case '.xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case '.pdf':
      return 'application/pdf';
    case '.jpg':
    case '.jpeg':
      return 'image/jpeg';
    case '.png':
      return 'image/png';
    case '.svg':
      return 'image/svg+xml';
    default:
      // Default to octet-stream if content type is not recognized
      return 'application/octet-stream';
  }
};

const getBase64FileType = (base64String) => {
  const [, fileType] = base64String.match(
    /^data:([a-zA-Z]+\/[a-zA-Z]+);base64/
  );
  return fileType ? fileType.split('/') : null;
};

exports.createFolder = async (bucketName, folderName) => {
  try {
    const folderParams = {
      Bucket: bucketName,
      Key: `${folderName}/`,
    };

    const data = await s3.putObject(folderParams).promise();
    logger.info('Folder created successfully:', data);

    return {
      data,
      status: true,
    };
  } catch (error) {
    logger.error('Error in createFolder:', error);
    return {
      error: error.message,
      status: false,
    };
  }
};

exports.removeFolder = async (bucketName, folderName) => {
  try {
    const listParams = {
      Bucket: bucketName,
      Prefix: `${folderName}/`,
    };

    const data = await s3.listObjects(listParams).promise();

    const deleteParams = {
      Bucket: bucketName,
      Delete: { Objects: data.Contents.map((item) => ({ Key: item.Key })) },
    };

    if (deleteParams.Delete.Objects.length > 0) {
      await s3.deleteObjects(deleteParams).promise();
      logger.info('Objects deleted successfully');
    }

    return {
      data: deleteParams.Delete.Objects,
      status: true,
    };
  } catch (error) {
    logger.error('Error in removeFolder:', error);
    return {
      error: error.message,
      status: false,
    };
  }
};

exports.uploadImage = async (bucketName, folderName, fileName, base64Image) => {
  try {
    // Determine image type
    const imageInfo = getBase64FileType(base64Image);
    const contentType = imageInfo
      ? `${imageInfo[0]}/${imageInfo[1]}`
      : 'application/octet-stream';

    // Remove the data:image/png;base64 part
    const base64ImageData = base64Image.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64ImageData, 'base64');

    const uploadParams = {
      Bucket: bucketName,
      Key: `${folderName}/${fileName}`,
      Body: buffer,
      ContentEncoding: 'base64',
      ContentType: contentType,
    };

    const data = await s3.upload(uploadParams).promise();
    logger.info(`${fileName} uploaded successfully:`, data.Location);

    return {
      data,
      status: true,
    };
  } catch (error) {
    logger.error('Error in uploadImage:', error);
    return {
      error: error.message,
      status: false,
    };
  }
};

exports.uploadImageFromLocal = async (
  bucketName,
  folderName,
  fileName,
  localFilePath
) => {
  try {
    const contentType = getContentType(fileName);
    // Set the parameters for the S3 upload
    const params = {
      Bucket: bucketName,
      Key: `${folderName}/${fileName}`,
      Body: await fs.readFile(`${localFilePath}`),
      ContentType: contentType,
    };

    // Upload the file to S3
    const data = await s3.upload(params).promise();
    logger.info('Document uploaded successfully. S3 Location:', data.Location);

    return {
      data,
      status: true,
    };
  } catch (error) {
    logger.error('Error in uploadDocument:', error);
    return {
      error: error.message,
      status: false,
    };
  }
};

exports.deleteImage = async (bucketName, folderName, imageName) => {
  try {
    const objectKey = `${folderName}/${imageName}`;

    // Check if the object exists before attempting to delete
    const headParams = {
      Bucket: bucketName,
      Key: objectKey,
    };
    await s3.headObject(headParams).promise();

    const deleteParams = {
      Bucket: bucketName,
      Delete: { Objects: [{ Key: objectKey }] },
    };

    await s3.deleteObjects(deleteParams).promise();
    logger.info('Image deleted successfully');

    return {
      data: deleteParams.Delete.Objects,
      status: true,
    };
  } catch (error) {
    logger.error('Error in deleteImage:', error);
    return {
      error: error.message,
      status: false,
    };
  }
};

exports.getS3ImageUrl = async (
  bucketName,
  folderPath,
  imageName,
  expirationTime = null
) => {
  try {
    const imageKey = folderPath ? `${folderPath}/${imageName}` : imageName;

    const params = {
      Bucket: bucketName,
      Key: imageKey,
    };

    if (expirationTime !== null) {
      params.Expires = expirationTime;
    }

    const imageUrl = await s3.getSignedUrlPromise('getObject', params);
    return imageUrl;
  } catch (error) {
    logger.error('Error fetching S3 image URL:', error);
    return null;
  }
};

exports.uploadFileToS3 = async (payload) => {
  const { fileContent, folderName, fileName, loggedInUserData } = payload;
  try {
    const createFolderResult = await this.createFolder(
      AWSconfig.bucketName,
      folderName
    );
    if (!createFolderResult.status) {
      logger.error(`Error in creating folder inside s3 bucket: ${folderName}`);
      return false;
    }
    const params = {
      Bucket: AWSconfig.bucketName,
      Key: `${folderName}/${fileName}`,
      Body: fileContent,
      ContentType: getContentType(fileName),
    };

    const data = await s3.putObject(params).promise();
    if (data?.ETag) {
      const folderTag = folderName.replace(/\//g, '$');
      const token = generateJWTSign(
        {
          countryCode: loggedInUserData?.countryCode,
          mobileNumber: loggedInUserData?.mobileNumber,
        },
        '600s'
      );
      const fileURL = `${process.env.BASE_URL}/doc/${folderTag}$${fileName}?token=${token}`;
      return fileURL;
    }
    return false;
  } catch (err) {
    logger.error(`Error in creating file to S3 bucket: ${err.message}`);
    return false;
  }
};
