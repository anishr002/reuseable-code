const sendGridMail = require('@sendgrid/mail');
const nodemailer = require('nodemailer');
const { sendAWSEmailWithTemplate } = require('./AWSHelper');
const logger = require('../logger');

sendGridMail.setApiKey(process.env.SEND_GRID_KEY);
const asyncHandler = require('../middleware/asyncHandler');
const mailConstants = require('../config/constants/mailOptions');
const { generateOTP, updateOTP } = require('../services/userService');
const { generateTimeExpiration } = require('../utils/common');
const { filterTemplateByUserData } = require('../services/mailService');
const errorLogTemplate = require('../emailTemplates/errorLogTemplate');

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  service: 'gmail',
  auth: {
    user: process.env.MAIL_USERNAME,
    pass: process.env.MAIL_PASSWORD,
  },
});

const replaceTemplateVar = (templateText, templateVarObject) => {
  // Template variables should come in form of object only
  if (typeof templateVarObject !== 'object') {
    return templateText;
  }
  let modifiedTemplateText = templateText;
  Object.keys(templateVarObject).forEach((templateVar) => {
    // Create template variable placeholder
    const templateVarPlaceholder = `{{${mailConstants.TEMPLATE_VAR_PLACEHOLDER}.${templateVar}}}`;
    // Replace template text with placeholder
    modifiedTemplateText = modifiedTemplateText.replace(
      new RegExp(templateVarPlaceholder, 'g'),
      templateVarObject[templateVar]
    );
  });
  return modifiedTemplateText;
};

const getTemplateData = async (mailOptions) => {
  const mailTemplateData = await filterTemplateByUserData({
    mailType: mailOptions?.type,
    userData: mailOptions?.userData,
  });
  const mailTemplateBody = replaceTemplateVar(
    mailTemplateData.body,
    mailOptions?.templateVars
  );
  mailTemplateData.body = mailTemplateBody;
  return mailTemplateData;
};

exports.sendEmail = async (mailOptions) => {
  try {
    const updatedMailOptions = mailOptions;
    // updatedMailOptions.templateVars.logo = `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`;

    /** Disable all mails */
    if (process.env.DISABLE_MAIL) {
      return true;
    }

    if (
      updatedMailOptions?.type &&
      (updatedMailOptions?.type === mailConstants.MAIL_TYPES.ERROR_LOGS ||
        updatedMailOptions?.type ===
          mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS ||
        updatedMailOptions?.to)
    ) {
      // Get Template Data
      let templateData;
      let mailConfig;
      if (
        updatedMailOptions?.type !== mailConstants.MAIL_TYPES.ERROR_LOGS &&
        updatedMailOptions?.type !==
          mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS
      ) {
        templateData = await getTemplateData(updatedMailOptions);
      }

      if (
        updatedMailOptions?.type !== mailConstants.MAIL_TYPES.ERROR_LOGS &&
        updatedMailOptions?.type !==
          mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS
      ) {
        mailConfig = {
          to: updatedMailOptions.to,
          from: templateData?.fromName
            ? `${templateData?.fromName} <${templateData?.fromEmail}>`
            : `<${templateData?.fromEmail}>`,
          subject: templateData?.subject,
          html: templateData?.body,
        };
      } else {
        const mailToEmails =
          updatedMailOptions?.type === mailConstants.MAIL_TYPES.ERROR_LOGS
            ? mailConstants.ERROR_LOGS_MAIL_TO
            : mailConstants.CRITICAL_ERROR_LOGS_MAIL_TO;
        const subject =
          updatedMailOptions?.type === mailConstants.MAIL_TYPES.ERROR_LOGS
            ? mailConstants.SUBJECT_ERROR_LOGS
            : mailConstants.SUBJECT_CRITICAL_ERROR_LOGS;
        mailConfig = {
          to: mailToEmails,
          from: `${mailConstants?.MAIL_FROM_NAME} <${mailConstants?.MAIL_FROM}>`,
          subject,
          html: errorLogTemplate(updatedMailOptions?.templateVars),
        };
      }

      if (mailConfig?.to) {
        if (process.env.MAIL_ENV === 'production') {
          const response = await sendAWSEmailWithTemplate(mailConfig);
          logger.info(
            `Response from AWS Custom SES: ${JSON.stringify(response)}`
          );
          return !!response?.success;
        }
        const sendGridResponse = await transporter.sendMail(mailConfig);
        logger.info(
          `sendGridResponse Response: ${JSON.stringify(
            sendGridResponse.response
          )}`
        );
        return true;
      }
    }
    return false;
  } catch (err) {
    logger.error(`Error in sending email: ${err}`);
    return false;
  }
};

exports.sendOTPToUser = asyncHandler(async (user) => {
  if (user?.email || (user?.mobileNumber && user?.countryCode)) {
    // Generate OTP
    const otpExpirationTime = 15;
    let otp = generateOTP();
    if (process.env.DISABLE_MAIL) {
      otp = 1234;
    }
    const otpExpiration = generateTimeExpiration(otpExpirationTime);
    logger.info(otp);
    logger.info(otpExpiration);

    // Send mail for OTP verification
    if (otp && otpExpiration) {
      const mailOptions = {
        to: user.email,
        type: mailConstants.MAIL_TYPES.OTP_MAIL,
        userData: user,
        templateVars: {
          otp,
          // logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
        },
      };

      const mailSentResponse = await this.sendEmail(mailOptions);
      if (mailSentResponse) {
        // Save OTP to the database
        const updatedOTP = await updateOTP(user._id, {
          otp,
          otpExpiration,
        });
        if (updatedOTP && !updatedOTP.error) {
          return true;
        }
      }
    }
  }
  return false;
});

exports.sendErrorLogs = asyncHandler(async ({ error, mailType }) => {
  // Send error logs mail
  const type = mailType || mailConstants.ERROR_LOGS;
  if (error) {
    const mailOptions = {
      type,
      templateVars: {
        err_log_message: error?.message,
        err_log_stack: error?.stack,
        err_info: error?.response?.data?.errorInfo ?? error?.errorInfo,
      },
    };
    logger.info(`Error log mailOptions: ${JSON.stringify(mailOptions)}`);
    const mailSentResult = await this.sendEmail(mailOptions);
    logger.info(`Error log mail sent: ${mailSentResult}`);
  }
});
