const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const logger = require('../logger');
const fileUploadPath = require('../config/constants/fileUploads');
const { deepCopy } = require('../utils/common');

exports.generateSymmetricKey = (bytes) => crypto.randomBytes(bytes || 32); // 256 bits (32 bytes) for AES-256

exports.getKeyPairPath = (keyType) => {
  const relativeFolderPath = fileUploadPath.KEYPAIR_RELATIVE_PATH;
  if (keyType === 'private') {
    return path.resolve(__dirname, relativeFolderPath, 'private-key.pem');
  }
  return path.resolve(__dirname, relativeFolderPath, 'public-key.pem');
};

exports.getKeyPairFolderPath = () =>
  path.resolve(__dirname, fileUploadPath.KEYPAIR_RELATIVE_PATH);

exports.createKeyStore = () => {
  try {
    const folderPath = this.getKeyPairFolderPath();
    // Check if the folder already exists
    if (!fs.existsSync(folderPath)) {
      // If it doesn't exist, create it
      fs.mkdirSync(folderPath);
      logger.info(`folder '${folderPath}' created.`);
    } else {
      logger.info(`folder '${folderPath}' already exists.`);
    }
  } catch (error) {
    logger.error(`Error creating keyStore: ${error.message}`);
  }
};

exports.generateKeyPair = () => {
  try {
    const publicKeyPath = this.getKeyPairPath();
    const privateKeyPath = this.getKeyPairPath('private');

    this.createKeyStore();
    if (!fs.existsSync(publicKeyPath) || !fs.existsSync(privateKeyPath)) {
      logger.info(publicKeyPath, privateKeyPath);
      const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
        modulusLength: 4096,
        publicKeyEncoding: {
          type: 'spki',
          format: 'pem',
        },
        privateKeyEncoding: {
          type: 'pkcs8',
          format: 'pem',
        },
      });

      // Save the private key to a .pem file
      fs.writeFileSync(privateKeyPath, privateKey);
      fs.chmodSync(privateKeyPath, 0o600); // read and write only for the owner
      // Save the public key to a .pem file
      fs.writeFileSync(publicKeyPath, publicKey);
      fs.chmodSync(publicKeyPath, 0o600); // read and write only for the owner
    } else {
      logger.info('Keys are already created!');
    }
    return true;
  } catch (error) {
    logger.error(`Error generating key pair: ${error.message}`);
    return false;
  }
};

exports.readPublicKey = () => {
  const publicKeyPath = this.getKeyPairPath();
  return fs.readFileSync(publicKeyPath, 'utf8');
};

exports.readPrivateKey = () => {
  const privateKeyPath = this.getKeyPairPath('private');
  return fs.readFileSync(privateKeyPath, 'utf8');
};

// Encrypt data with a dynamically generated symmetric key
exports.encryptWithSymmetricKey = (data, symmetricKey, iv) => {
  try {
    const cipher = crypto.createCipheriv(
      'aes-256-cbc',
      Buffer.from(symmetricKey, 'hex'),
      Buffer.from(iv, 'hex')
    );
    const encryptedBuffer = Buffer.concat([
      cipher.update(data, 'utf-8'),
      cipher.final(),
    ]);
    return encryptedBuffer.toString('base64');
  } catch (error) {
    logger.error(`encrypt SymmetricKey-error: ${error}`);
    return undefined;
  }
};

exports.decryptWithSymmetricKey = (data, symmetricKey, iv) => {
  try {
    const decipher = crypto.createDecipheriv(
      'aes-256-cbc',
      Buffer.from(symmetricKey, 'hex'),
      Buffer.from(iv, 'hex')
    );
    const decryptedBuffer = Buffer.concat([
      decipher.update(Buffer.from(data, 'base64')),
      decipher.final(),
    ]);
    const jsonString = decryptedBuffer.toString('utf-8');
    const jsonObject = JSON.parse(jsonString);
    // console.log('Decrypted jsonObject', jsonObject);
    return jsonObject;
  } catch (error) {
    logger.error(`decryptWithSymmetricKey-error: ${error}`);
    return false;
  }
};

// Encrypt the symmetric key with an RSA public key
exports.encryptSymmetricKeyWithRSA = (symmetricKey, publicKey) => {
  try {
    // Check if the key is of pem or der
    const keyType = this.verifyKeyType(publicKey);
    logger.info(`keyType: ${keyType}`);
    let publicKeyObject;

    // Sanitize the key according to the format
    const sanitizePublicKey =
      keyType === 'pem'
        ? publicKey.replace(/\|/g, '\n')
        : Buffer.from(publicKey, 'base64');

    if (keyType === 'der') {
      // Create a public key object if the key is of der format
      publicKeyObject = crypto.createPublicKey({
        key: sanitizePublicKey,
        format: 'der',
        type: 'pkcs1',
      });
    }
    // logger.info(`sanitizePublicKey: ${sanitizePublicKey}`);
    // Encryption with the mobile public key
    const encryptedSymmetricKey = crypto.publicEncrypt(
      {
        key: keyType === 'pem' ? sanitizePublicKey : publicKeyObject,
        padding: crypto.constants.RSA_PKCS1_PADDING,
      },
      Buffer.from(symmetricKey.toString('base64'))
    );
    return encryptedSymmetricKey.toString('base64');
  } catch (error) {
    logger.error(`encryptPublicKey-error: ${error}`);
    return undefined;
  }
};

exports.decryptWithRSA = (encryptedData, keyType) => {
  try {
    const dataToDecrypt = encryptedData;
    const serverPrivateKey = this.readPrivateKey();
    // Create a private key object from PEM string
    const privateKeyObject = crypto.createPrivateKey({
      key: serverPrivateKey,
      format: 'pem',
      type: 'pkcs1',
    });
    if (dataToDecrypt && dataToDecrypt !== '') {
      const bufferValue = Buffer.from(dataToDecrypt, 'base64');
      let decryptedValue;
      if (keyType === 'admin') {
        decryptedValue = crypto.privateDecrypt(
          {
            key: privateKeyObject,
            padding: crypto.constants.RSA_NO_PADDING,
          },
          bufferValue
        );
      } else {
        decryptedValue = crypto.privateDecrypt(
          {
            key: privateKeyObject,
            padding: crypto.constants.RSA_PKCS1_PADDING,
          },
          bufferValue
        );
      }
      if (keyType === 'der') {
        return decryptedValue.toString('base64');
      }
      return decryptedValue.toString();
    }
    return undefined;
  } catch (error) {
    logger.error(`Error in decryptData: ${error}`);
    return undefined;
  }
};

exports.verifyKeyType = (key) => {
  if (key && key !== '' && key !== undefined) {
    return key.startsWith('-----BEGIN PUBLIC KEY-----') &&
      key.endsWith('-----END PUBLIC KEY-----')
      ? 'pem'
      : 'der';
  }
  return null;
};

exports.encryptServerPublicKey = (symmetricKey, iv) => {
  let serverPublicKey = this.readPublicKey();
  serverPublicKey = serverPublicKey.replace(/\n/g, '|');
  const encrypted = this.encryptWithSymmetricKey(
    serverPublicKey,
    symmetricKey,
    iv
  );
  return encrypted.toString('base64');
};

// To decrypt single value
exports.decryptData = (encryptedValue) => {
  try {
    if (encryptedValue && encryptedValue !== '') {
      const serverPrivateKey = this.readPrivateKey();
      const bufferValue = Buffer.from(encryptedValue, 'base64');
      const decryptedValue = crypto.privateDecrypt(
        serverPrivateKey,
        bufferValue
      );
      return decryptedValue.toString();
    }
    return undefined;
  } catch (error) {
    logger.error(`Error in decryptData: ${error}`);
    return undefined;
  }
};

// To encrypt single value
exports.encryptData = (clientPublicKey, data) => {
  try {
    if (
      clientPublicKey &&
      clientPublicKey !== '' &&
      data &&
      data !== '' &&
      typeof data === 'string'
    ) {
      const encryptedData = crypto.publicEncrypt(clientPublicKey, data);
      return encryptedData.toString('base64');
    }
    return undefined;
  } catch (error) {
    logger.error(`Error in encryptData: ${error}`);
    return undefined;
  }
};

exports.decryptReqPayload = (data) => {
  const parsedData = data.split('|'); // Parsing the data
  let keyType = 'pem';
  if (parsedData[3] && parsedData[3] === '10$') {
    keyType = 'der';
  } else if (parsedData[3] && parsedData[3] === '20$') {
    keyType = 'admin';
  }
  logger.info(`decryptReqPayload: keyType while decrypt: ${keyType}`);
  if (parsedData.length >= 3) {
    let decryptedSymmetricKey = this.decryptWithRSA(parsedData[1], keyType);
    let descryptedIV = this.decryptWithRSA(parsedData[2], keyType);
    if (keyType === 'admin') {
      decryptedSymmetricKey = decryptedSymmetricKey.replace(
        /[^\x20-\x7E\n\r\t]/g,
        ''
      );
      descryptedIV = descryptedIV.replace(/[^\x20-\x7E\n\r\t]/g, '');
    }
    logger.info(
      `decryptReqPayload: decryptedSymmetricKey: ${decryptedSymmetricKey}`
    );
    logger.info(`decryptReqPayload: descryptedIV: ${descryptedIV}`);
    if (!decryptedSymmetricKey || !descryptedIV) {
      return false;
    }
    const DecryptedData = this.decryptWithSymmetricKey(
      parsedData[0],
      Buffer.from(decryptedSymmetricKey, 'base64'),
      Buffer.from(descryptedIV, 'base64')
    );
    logger.info(`decryptReqPayload DATA: ${JSON.stringify(DecryptedData)}`);
    return DecryptedData;
  }
  return false;
};

// To decrypt objects
exports.decryptObjectFields = (encryptedObject) => {
  try {
    const decryptedObject = deepCopy(encryptedObject);
    Object.keys(decryptedObject).forEach((key) => {
      if (
        typeof decryptedObject[key] === 'object' &&
        !Array.isArray(decryptedObject[key])
      ) {
        decryptedObject[key] = this.decryptObjectFields(decryptedObject[key]);
      } else {
        decryptedObject[key] = this.decryptData(decryptedObject[key]);
      }
    });
    return decryptedObject;
  } catch (error) {
    logger.error(`Error in decryptObjectFields: ${error}`);
    return false;
  }
};

// To encrypt objects
exports.encryptObjectFields = (dataObject, symmetricKey, iv) => {
  try {
    const encryptedObject = deepCopy(dataObject); // Assuming deepCopy creates a deep clone
    if (Array.isArray(encryptedObject)) {
      // If it's an array, encrypt each element
      encryptedObject.forEach((item, index) => {
        if (typeof item === 'object' && !Array.isArray(item)) {
          // If element is an object, recursively encrypt it
          encryptedObject[index] = this.encryptObjectFields(
            item,
            symmetricKey,
            iv
          );
        } else {
          // Encrypt individual array element
          encryptedObject[index] = this.encryptWithSymmetricKey(
            item.toString(),
            symmetricKey,
            iv
          );
        }
      });
    } else if (
      typeof encryptedObject === 'object'
      // && encryptedObject !== null
    ) {
      // If it's an object, iterate through its properties
      Object.keys(encryptedObject).forEach((key) => {
        if (
          typeof encryptedObject[key] === 'object' &&
          !Array.isArray(encryptedObject[key])
        ) {
          // If property value is an object, recursively encrypt it
          encryptedObject[key] = this.encryptObjectFields(
            encryptedObject[key],
            symmetricKey,
            iv
          );
        } else {
          // Encrypt individual property value
          encryptedObject[key] = this.encryptWithSymmetricKey(
            encryptedObject[key].toString(),
            symmetricKey,
            iv
          );
        }
      });
    }

    // else {
    //   // Encrypt non-object and non-array values
    //   encryptedObject = this.encryptWithSymmetricKey(
    //     encryptedObject,
    //     symmetricKey,
    //     iv
    //   );
    // }

    return encryptedObject;
  } catch (error) {
    logger.error(`Error in encryptObjectFields: ${error}`);
    return false;
  }
};

const isValidBase64 = (str) => {
  // Regular expression to check base64 format
  const base64Regex = /^[a-zA-Z0-9+/=]+$/;
  return base64Regex.test(str);
};

// Helper function to create buffers from base64 encoded strings
const base64ToBuffer = (base64String) => Buffer.from(base64String, 'base64');

// Encrypt data with blockchain key
exports.encryptWithBlockchainKey = (data, symmetricKey, iv) => {
  try {
    const cipher = crypto.createCipheriv(
      'aes-256-cbc',
      base64ToBuffer(symmetricKey),
      base64ToBuffer(iv)
    );
    const encryptedBuffer = Buffer.concat([
      cipher.update(data, 'utf8'),
      cipher.final(),
    ]);
    return encryptedBuffer.toString('base64');
  } catch (error) {
    logger.error(`Encryption error: ${error.message}`);
    return undefined;
  }
};

// Decrypt data with blockchain key
exports.decryptWithBlockchainKey = (encryptedData, symmetricKey, iv) => {
  try {
    if (!isValidBase64(encryptedData)) {
      return encryptedData;
    }

    const decipher = crypto.createDecipheriv(
      'aes-256-cbc',
      base64ToBuffer(symmetricKey),
      base64ToBuffer(iv)
    );
    const decryptedBuffer = Buffer.concat([
      decipher.update(base64ToBuffer(encryptedData)),
      decipher.final(),
    ]);
    const jsonString = decryptedBuffer.toString('utf-8');
    const jsonObject = JSON.parse(jsonString);
    return jsonObject;
  } catch (error) {
    logger.error(`Decryption error: ${error.message}`);
    return false;
  }
};
