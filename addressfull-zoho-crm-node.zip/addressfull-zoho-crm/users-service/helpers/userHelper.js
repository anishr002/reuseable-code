const userRoles = require('../config/constants/userRoles');

exports.getCreatedByUserType = (user) => {
  let createdByUserType;
  if (user.userType) {
    createdByUserType = user.userType;
  } else if (user?.isAdminMember === true) {
    createdByUserType = userRoles.SUPER_ADMIN;
  } else {
    createdByUserType = userRoles.ORGANIZATION_ADMIN;
  }
  return createdByUserType;
};

exports.getOrgIdLoggedInUser = (userData) => {
  if (userData?.userType === userRoles.SUPER_ADMIN) {
    return null;
  } else if (userData?.userType === userRoles.ORGANIZATION_ADMIN) {
    return userData._id;
  } else {
    return userData?.organizationId;
  }
};
