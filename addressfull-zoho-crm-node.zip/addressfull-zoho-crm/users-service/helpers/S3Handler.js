const AWS = require('aws-sdk');
const jwt = require('jsonwebtoken');
const AWSconfig = require('../config/AWSConfig');
const { decodeUser } = require('../services/commonService');
const logger = require('../logger');
const responseMessages = require('../config/constants/reponseMessages');
const fsConstants = require('../config/constants/fileUploads');

AWS.config.update({
  region: AWSconfig.region,
  accessKeyId: AWSconfig.accessKey,
  secretAccessKey: AWSconfig.secretKey,
});

const s3 = new AWS.S3();

exports.convertS3Image = async (req, res) => {
  const { pathToImage } = req.params;
  const { token } = req.query;

  const key = pathToImage.replace(/\$/g, '/');
  if (key.includes(`/${fsConstants.S3_REPORTS_FOLDER}`) && !token) {
    return res.status(400).send(responseMessages.REPORT_ACCESS_DENIED);
  }
  if (token) {
    try {
      const jwtVerified = jwt.verify(token, process.env.SECRET_KEY);
      const decodedUser = await decodeUser(jwtVerified);
      if (!decodedUser?.isActive || decodedUser?.isDeleted) {
        return res.status(400).send(responseMessages.REPORT_ACCESS_DENIED);
      }
    } catch (error) {
      logger.error(
        `Token verification issue while accessing AWS docs: ${error.message}`
      );
      return res.status(400).send(responseMessages.REPORT_ACCESS_DENIED);
    }
  }

  const params = {
    Bucket: AWSconfig.bucketName,
    Key: key,
  };

  s3.getObject(params, (err, data) => {
    if (err) {
      logger.error(
        `Error in fetching resource URL from the S3: ${err?.message}`
      );
      return res.status(400).send(responseMessages.RESOURCE_NOT_FOUND);
    }
    // Set appropriate headers to indicate image type
    res.setHeader('Content-Type', data.ContentType);
    // Send the image data as the response
    res.send(data.Body);
  });
};
