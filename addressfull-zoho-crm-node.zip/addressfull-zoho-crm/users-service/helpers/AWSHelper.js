const AWS = require('aws-sdk');
const util = require('util');
const AWSconfig = require('../config/AWSConfig');
const logger = require('../logger');

AWS.config.update({
  region: AWSconfig.region,
  accessKeyId: AWSconfig.accessKey,
  secretAccessKey: AWSconfig.secretKey,
});

exports.sendAWSSMS = async (payload) => {
  const { messageText, countryCode, mobileNumber } = payload;
  const response = { success: false, error: false, data: null };
  try {
    const params = {
      Message: messageText,
      PhoneNumber: `+${countryCode}${mobileNumber}`,
    };
    logger.info(`AWS Params: ${JSON.stringify(params)}`);
    /** Create new SNS object */
    const sns = new AWS.SNS({ apiVersion: '2010-03-31' });
    const publishAsync = util.promisify(sns.publish).bind(sns);
    /** Publish the message */
    const serviceResponse = await publishAsync(params);
    logger.info(
      `Response from AWS SNS Service: ${JSON.stringify(serviceResponse)}`
    );
    response.success = true;
    response.data = serviceResponse;
    return response;
  } catch (err) {
    logger.error(`Error in sending OTP via AWS: ${err.message}`);
    response.error = err;
    return response;
  }
};

exports.sendAWSEmailWithTemplate = async (payload) => {
  const { to, from, subject, html } = payload;
  const response = { success: false, error: null, data: null };
  const ses = new AWS.SES({
    region: AWSconfig.region,
  });
  const params = {
    Destination: {
      ToAddresses: [to],
    },
    Message: {
      Body: {
        Html: {
          Charset: 'UTF-8',
          Data: html,
        },
      },
      Subject: {
        Charset: 'UTF-8',
        Data: subject,
      },
    },
    Source: from,
  };
  logger.info(`AWS SES service params: ${JSON.stringify(params)}`);
  try {
    const AWSResponse = await ses.sendEmail(params).promise();
    logger.isInfoEnabled(
      `AWSResponse while sending an email: ${JSON.stringify(AWSResponse)}`
    );
    response.success = true;
    response.data = AWSResponse;
    return response;
  } catch (err) {
    logger.error(`Error in sending AWS email: ${err}`);
    response.error = err;
    return response;
  }
};
