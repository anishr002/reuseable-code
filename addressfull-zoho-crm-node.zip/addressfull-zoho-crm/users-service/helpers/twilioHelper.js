const { generateOTP, updateOTP } = require('../services/userService');
const { getSettingsByUser } = require('../services/generalSettingService');
const { generateTimeExpiration } = require('../utils/common');
const SMSServices = require('../config/constants/SMSServices');
const { sendAWSSMS } = require('./AWSHelper');
const logger = require('../logger');

exports.twilioClient = require('twilio')(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

exports.sendOTPMobile = async (user, payload) => {
  const SMSToken = payload?.SMSToken || user?.SMSToken;
  if (process.env.NODE_ENV === 'development') {
    /** In the development mode, OTP will not be send to the user in real. */
    const otp = '1234';
    const otpExpiration = generateTimeExpiration(2); // otp expire in 60 minutes
    const otpUpdatedData = await updateOTP(user._id, {
      otp,
      otpExpiration,
    });
    return !!(otpUpdatedData && !otpUpdatedData?.error);
  }
  if (process.env.NODE_ENV === 'production') {
    const { countryCode, mobileNumber } = user;
    const finalNumber = countryCode + mobileNumber;
    const excludedNumbers = ['919898989898', '918989898989'];

    if (excludedNumbers.includes(finalNumber)) {
      /** In the development mode, OTP will not be send to the user in real. */
      const otp = '1234';
      const otpExpiration = generateTimeExpiration(2); // otp expire in 60 minutes
      const otpUpdatedData = await updateOTP(user._id, {
        otp,
        otpExpiration,
      });
      return !!(otpUpdatedData && !otpUpdatedData?.error);
    }
    const otp = generateOTP();
    const otpExpiration = generateTimeExpiration(2); // otp expire in 2 minutes
    try {
      const isMessageSent = await this.sendTextMessage({
        SMSToken,
        countryCode: user.countryCode,
        mobileNumber: user.mobileNumber,
        messageBody: `Your AddressFull Verification Code is: ${otp}`,
      });
      if (isMessageSent) {
        /** Update OTP in the database */
        const otpUpdatedData = await updateOTP(user._id, {
          otp,
          otpExpiration,
        });
        return !!(otpUpdatedData && !otpUpdatedData?.error);
      }
    } catch (error) {
      console.log('error.message.....', error.message);
      logger.error(
        `Error in sending OTP to the user: ${JSON.stringify(error)}`
      );
      return false;
    }
  }
  return false;
};

exports.sendTextMessage = async (payload) => {
  try {
    const { SMSToken, countryCode, mobileNumber, messageBody } = payload;
    logger.info(`Payload to send the message: ${JSON.stringify(payload)}`);
    if (
      process.env.NODE_ENV === 'production' &&
      countryCode &&
      mobileNumber &&
      messageBody
    ) {
      /** Fetch twilio balance */
      const twilioBalanceData = await this.twilioClient.balance.fetch();
      const twilioBalance = twilioBalanceData?.balance;
      logger.info(`Twillio Balance: ${twilioBalance}`);
      /** Fetch SMS service setting */
      const SMSSetting = await getSettingsByUser(null);
      let SMSService = SMSSetting?.settings?.smsService || SMSServices.TWILIO;
      if (twilioBalance <= 0.2) {
        logger.info(`Twilio doesn't have enough balance to send SMS.`);
        SMSService = SMSServices.AWS;
      }
      logger.info(`SMSService: ${SMSService}`);
      let isMessageSent;
      /** Send SMS based on the SMS service setting */
      if (SMSService === SMSServices.TWILIO) {
        logger.info(
          `Sending twilio message to: +${countryCode}${mobileNumber}`
        );
        const response = await this.twilioClient.messages.create({
          body: `${messageBody}.${SMSToken || ''}`,
          to: `+${countryCode}${mobileNumber}`,
          from: process.env.TWILIO_PHONE_NUMBER,
        });
        logger.info(
          `Response from Twillio message service: ${JSON.stringify(response)}`
        );
        if (response.errorMessage === null) isMessageSent = true;
      } else if (SMSService === SMSServices.AWS) {
        const response = await sendAWSSMS({
          messageText: `${messageBody}.${SMSToken || ''}`,
          countryCode,
          mobileNumber,
        });
        logger.info(
          `Response from AWS message service: ${JSON.stringify(response)}`
        );
        if (response?.success) isMessageSent = true;
      }
      return isMessageSent;
    }
  } catch (error) {
    console.log('errorMessageSend..', error.message);
    return error.message;
  }
  return false;
};
