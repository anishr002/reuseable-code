const QRCode = require('qrcode');

exports.createQRCode = async (payload) => {
  const { organizationId } = payload;
  if (!organizationId) {
    return '';
  }
  const url = `${process.env.QR_SCANNER_LINK}/${organizationId}`;
  const qrCode = await QRCode.toDataURL(url);
  return qrCode;
};
