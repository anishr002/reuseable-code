const jwt = require('jsonwebtoken');
const responseMessages = require('../config/constants/reponseMessages');
const generalConfig = require('../config/constants/generalConfig');

// const DEFAULT_JWT_EXPIRATION = '15m';

exports.generateJWTSign = (payload, expirationTime) => {
  const secretKey = process.env.SECRET_KEY;
  const expiresIn = expirationTime || generalConfig.DEFAULT_JWT_EXPIRATION;
  const token = jwt.sign(payload, secretKey, {
    expiresIn,
  });

  return token;
};

exports.decodeJWTSign = async (req) => {
  let token;
  if (req?.token) {
    token = req.token;
  }
  const authHeader =
    req.headers && (req.header('authorization') || req.header('token'));
  if (authHeader?.trim().startsWith('Bearer')) {
    token = authHeader.replace('Bearer', '').trim();
  }

  if (token) {
    try {
      const jwtVerified = jwt.verify(token, process.env.SECRET_KEY);
      return {
        ...jwtVerified,
        token,
      };
    } catch (error) {
      return {
        message: error.message,
      };
    }
  }
  return {
    message: responseMessages.UNAUTHORIZED_ACCESS,
  };
};
