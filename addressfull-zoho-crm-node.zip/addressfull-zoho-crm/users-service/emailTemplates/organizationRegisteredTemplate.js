function orgRegistrationTemplate(_templateVars) {
  const logoUrl = `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`;

  const htmlData = `
            <html>
              <head>
                <style>
                  /* Styles for the professional email template */
                  body {
                    font-family: 'Arial', 'Helvetica', sans-serif;
                    background-color: #f5f5f5;
                    margin: 0;
                    padding: 0;
                  }
                  .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #ffffff;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                  }
                  .header {
                    background-color: #3498db;
                    color: white;
                    text-align: center;
                    padding: 20px;
                    border-radius: 10px 10px 0 0;
                  }
                  .logo {
                    text-align: center;
                    margin-top: 15px;
                    margin-bottom: 15px;
                  }
                  .logo img {
                    max-width: 100%;
                    height: 100px;
                  }
                  .content {
                    padding: 30px;
                    color: #333;
                  }
                  .button {
                    background-color: #3498db;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    text-decoration: none;
                    border-radius: 5px;
                    cursor: pointer;
                    display: inline-block;
                    margin-top: 20px;
                  }
                  .footer {
                    margin-top: 20px;
                    padding-top: 20px;
                    border-top: 1px solid #ddd;
                    text-align: center;
                    color: #777;
                  }
                </style>
              </head>
              <body>
                <div class="container">
                  <div class="header">
                    <h1>New Organization Registration</h1>
                  </div>
                  <div class="logo">
                    <img
                      src="${logoUrl}"
                      alt="Company Logo"
                    />
                  </div>
                  <div class="content">
                    <p>We're thrilled to inform you that a new organization has joined our platform!</p>
                    <p>The organization registered using the email address <b>{{templateVars.email}}</b>.</p>
                    <p> If you have any questions or need further details about this new registration, please visit the admin panel.</p>
                    <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Admin Panel</a>
                  </div>
                  <div class="footer">
                    <p>Best regards,<br />AddressFull Team</p>
                  </div>
                </div>
              </body>
            </html>`;
  return htmlData;
}

module.exports = orgRegistrationTemplate;
