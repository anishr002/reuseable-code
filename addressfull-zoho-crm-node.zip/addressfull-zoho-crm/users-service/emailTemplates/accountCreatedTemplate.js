function accountCreatedTemplate(templateVars) {
  const htmlData = `
  <html>
  <head>
    <style>
      /* Styles for the email template */
      body {
        font-family: "Arial", "Helvetica", sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }
      .header {
        background-color: #3498db;
        color: white;
        text-align: center;
        padding: 10px;
        border-radius: 10px 10px 0 0;
      }
      .logo {
        text-align: center;
        margin-top: 15px;
        margin-bottom: 15px;
      }
      .logo img {
        max-width: 100%;
        height: 100px;
      }
      .content {
        padding: 20px;
        color: #333;
      }
      a.button {
        display: inline-block;
        padding: 10px 20px;
        margin-top: 20px;
        text-decoration: none;
        color: #ffffff;
        background-color: #3498db;
        border-radius: 5px;
      }
      .footer {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #ddd;
        text-align: center;
        color: #777;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>Password Reset</h1>
      </div>
      <div class="logo">
        <img
          src="${templateVars.logo}"
          alt="Company Logo"
        />
      </div>
      <div class="content">
        <p>Welcome to AddressFull</p>
        <p>
          We are excited to have you on board. Your account has been
          successfully created, and here are your login details:
        </p>
        <p><strong>Email:</strong> ${templateVars.email}</p>
        <p><strong>Temporary Password:</strong> ${templateVars.password}</p>
        <p>
          Please use the provided credentials to log in to the Admin Portal.
          Upon your first login, you will be prompted to change your password
          for security purposes.
        </p>
        <div class="button-container">
          <a style="color: #ffffff;" href="${templateVars.link}" class="button">Log In Now</a>
        </div>
        <div class="footer">
          <p>Best regards,<br />AddressFull Team</p>
        </div>
      </div>
    </div>
  </body>
</html>`;
  return htmlData;
}

module.exports = accountCreatedTemplate;
