function sendErrorLogTemplate(templateVars) {
  const htmlData = `
    <html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 10px 20px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
         }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Error Log</h1>
        </div>
        <div class="logo">
          <img
            src="${templateVars.logo}"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p style="font-size: 24px; font-weight: bold; color: #007BFF;">Error Log:</p>
          <p><b>${templateVars?.err_log_message}</b></p>
          <p>${templateVars?.err_log_stack}</p>
          <p>${templateVars?.err_info}</p>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`;
  return htmlData;
}

module.exports = sendErrorLogTemplate;
