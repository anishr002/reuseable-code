const { MongoClient } = require('mongodb');

async function copyDatabase() {
  // Use environment variables for username and password
  const mongodbUser = process.env.MONGODB_USER;
  const mongodbPassword = process.env.MONGODB_PASSWORD;

  const productionURI =
    'mongodb://3.10.233.71:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.1.4';
  const developmentURI = `mongodb+srv://${mongodbUser}:${mongodbPassword}@cluster1.k24slxq.mongodb.net`;

  // Connect to production database
  const productionClient = new MongoClient(productionURI);
  await productionClient.connect();
  const productionDB = productionClient.db('test');

  // Connect to development database
  const developmentClient = new MongoClient(developmentURI);
  await developmentClient.connect();
  const developmentDB = developmentClient.db('addressFull');

  // Get list of collections in production database
  const collections = await productionDB.listCollections().toArray();

  // Define array to store promises for concurrent import operations
  const importPromises = [];

  // Iterate through each collection and clone it concurrently
  // eslint-disable-next-line no-restricted-syntax
  for (const collectionInfo of collections) {
    const collectionName = collectionInfo.name;
    const collection = productionDB.collection(collectionName);

    // Push the promise for importing the collection into the importPromises array
    importPromises.push(
      (async () => {
        console.time(`Importing ${collectionName}`);

        // Drop collection if it already exists in development database
        try {
          await developmentDB.dropCollection(collectionName);
        } catch (error) {
          console.log(`Error dropping collection ${collectionName}:`, error);
        }

        // Fetch documents and insert into development database
        const documents = await collection.find().toArray();
        if (documents.length > 0) {
          await developmentDB.collection(collectionName).insertMany(documents);
        } else {
          console.log(`No documents found in ${collectionName}`);
        }

        console.timeEnd(`Importing ${collectionName}`);
      })()
    );
  }

  // Wait for all import operations to complete
  await Promise.all(importPromises);

  // Close connections
  await productionClient.close();
  await developmentClient.close();

  console.timeEnd('Database copy');
  console.log('Database copy completed.');
}

copyDatabase().catch(console.log);
