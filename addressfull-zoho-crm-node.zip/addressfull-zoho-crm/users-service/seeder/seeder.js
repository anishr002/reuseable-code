require('dotenv').config();
const dbConnect = require('../config/dbConnection');
const systemModule = require('../models/systemModuleModel');
const SecurityQuestion = require('../models/securityQuestionModel');
const MailType = require('../models/mailTypeModel');
const User = require('../models/userModel');
const Organization = require('../models/organizationModel');
const userData = require('./data/users');
const OrganizationType = require('../models/organizationTypeModel');
const organizationData = require('./data/organizations');
const logger = require('../logger');
const moduleData = require('./data/modules');
const securityQuestionData = require('./data/securityQuestions');
const mailTypeData = require('./data/mailTypes');
const organizationTypeData = require('./data/organizationTypes');

dbConnect();

const importData = async () => {
  try {
    /** Delete everything */
    // await systemModule.deleteMany();
    // await SecurityQuestion.deleteMany();
    await MailType.deleteMany();
    // await OrganizationType.deleteMany();

    /** Insert all modules data */
    // await systemModule.insertMany(moduleData);
    // await SecurityQuestion.insertMany(securityQuestionData);
    await MailType.insertMany(mailTypeData);
    // await OrganizationType.insertMany(organizationTypeData);

    /** START:: Insert into users and organizations collection */
    // const totalRecords = userData.length + organizationData.length;
    // let totalDeletedRecords = 0;
    // const userIdToRemove = [];
    // const organizationIdToRemove = [];
    // logger.info(`Total users and organizations: ${totalRecords}`);

    // userData.forEach((adminUser) => {
    //   userIdToRemove.push(adminUser?._id);
    // });
    // organizationData.forEach((organizationUser) => {
    //   organizationIdToRemove.push(organizationUser?._id);
    // });
    // logger.info(`Users to remove: ${JSON.stringify(userIdToRemove)}`);
    // logger.info(
    //   `Organizations to remove: ${JSON.stringify(organizationIdToRemove)}`
    // );

    // const userIdDeleted = await User.deleteMany({
    //   _id: { $in: userIdToRemove },
    // });
    // const organizationIdDeleted = await Organization.deleteMany({
    //   _id: { $in: organizationIdToRemove },
    // });
    // totalDeletedRecords =
    //   userIdDeleted.deletedCount + organizationIdDeleted.deletedCount;
    // logger.info(`Users deleted: ${JSON.stringify(userIdDeleted)}`);
    // logger.info(
    //   `Organizations deleted: ${JSON.stringify(organizationIdDeleted)}`
    // );
    // logger.info(`Total record deleted: ${totalDeletedRecords}`);

    // // if (totalDeletedRecords === totalRecords) {
    // logger.info(`Inserting into users and organizations collections.`);
    // const insertedUser = await User.insertMany(userData);
    // const insertedOrganization =
    //   await Organization.insertMany(organizationData);
    // logger.info(`Users Inserted: ${JSON.stringify(insertedUser)}`);
    // logger.info(
    //   `Organizations Inserted: ${JSON.stringify(insertedOrganization)}`
    // );
    // // }
    /** END:: Insert into users and organizations collection */

    logger.info(`Data is imported`);
    process.exit();
  } catch (error) {
    logger.error(`Error in seeding data: ${error}`);
    process.exit(1);
  }
};

importData();
