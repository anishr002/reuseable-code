require('dotenv').config();
const dbConnect = require('../config/dbConnection');
const MailType = require('../models/mailTypeModel');
const Mail = require('../models/mailModel');

const logger = require('../logger');

dbConnect();

const replaceMailTemplates = async () => {
  try {
    // Update MailType collection
    const mailTemplates = await MailType.find({
      body: { $regex: 'src="{{templateVars.logo}}"' },
    }); // Fetch only matching documents

    // eslint-disable-next-line no-restricted-syntax
    for (const mail of mailTemplates) {
      mail.body = mail.body.replace(
        /src="{{templateVars.logo}}"/g,
        'src="https://api.addressfull.com/uploads/profilePictures/Logo1.png" style="width: 200px;height: 100px;"'
      );
      // eslint-disable-next-line no-await-in-loop
      await mail.save(); // Save the updated document
    }

    // Update Mail collection
    const mails = await Mail.find({
      body: { $regex: 'src="{{templateVars.logo}}"' },
    }); // Fetch only matching documents

    // eslint-disable-next-line no-restricted-syntax
    for (const mail of mails) {
      mail.body = mail.body.replace(
        /src="{{templateVars.logo}}"/g,
        'src="https://api.addressfull.com/uploads/profilePictures/Logo1.png" style="width: 200px;height: 100px;"'
      );
      // eslint-disable-next-line no-await-in-loop
      await mail.save(); // Save the updated document
    }

    logger.info(`Data has been updated successfully.`);
    process.exit();
  } catch (error) {
    logger.error(`Error updating mail templates: ${error}`);
    process.exit(1);
  }
};

replaceMailTemplates();
