const { MongoClient } = require('mongodb');

const mongodbUser = process.env.MONGODB_LIVE_USER;
const mongodbPassword = process.env.MONGODB_LIVE_PASSWORD;

const uri = `mongodb://${mongodbUser}:${mongodbPassword}@192.168.40.199?retryWrites=true&w=majority`; // Replace with your MongoDB URI
const client = new MongoClient(uri);

async function checkConnection() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
  } finally {
    await client.close();
  }
}

checkConnection();
