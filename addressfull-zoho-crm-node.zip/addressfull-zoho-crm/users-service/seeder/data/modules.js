module.exports = [
  // Super Admin Modules
  {
    name: 'dashboard',
    title: 'Dashboard',
    userType: 'super-admin',
    description: 'Dashboard',
  },
  {
    name: 'roles',
    title: 'Role Management',
    userType: 'super-admin',
    description: 'Role Management',
  },
  {
    name: 'admins',
    title: 'Admin Management',
    userType: 'super-admin',
    description: 'Admin Management',
  },
  {
    name: 'organizations',
    title: 'Organization Management',
    userType: 'super-admin',
    description: 'Organization Management',
  },
  {
    name: 'requests',
    title: 'Requests',
    userType: 'super-admin',
    description: 'Approval requests coming from the organizations',
  },
  {
    name: 'transactions',
    title: 'Transaction',
    userType: 'super-admin',
    description: 'Transaction Module',
  },
  {
    name: 'general_settings',
    title: 'General Settings',
    userType: 'super-admin',
    description: 'General settings',
  },
  {
    name: 'privacy_policy_settings',
    title: 'Privacy Policy',
    userType: 'super-admin',
    description: 'Privacy Policy',
  },
  // Organization Admin Modules
  {
    name: 'roles',
    title: 'Role Management',
    userType: 'organization-admin',
    description: 'Role Management',
  },
  {
    name: 'admins',
    title: 'Admin Management',
    userType: 'organization-admin',
    description: 'Admin Management',
  },
  {
    name: 'dashboard',
    title: 'Dashboard',
    userType: 'organization-admin',
    description: 'Dashboard',
  },
  {
    name: 'users',
    title: 'Connected Users',
    userType: 'organization-admin',
    description:
      'Admin will be able to see the connected users with the organization',
  },
  {
    name: 'general_settings',
    title: 'General Settings',
    userType: 'organization-admin',
    description: 'General settings',
  },
  {
    name: 'crm_settings',
    title: 'CRM Settings',
    userType: 'organization-admin',
    description: 'CRM settings',
  },
  {
    name: 'transactions',
    title: 'Transaction',
    userType: 'organization-admin',
    description: 'Transaction Module',
  },
];
