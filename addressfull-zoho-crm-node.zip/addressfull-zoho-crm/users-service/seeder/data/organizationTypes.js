module.exports = [
  {
    title: 'Education',
    name: 'education',
    isActive: true,
  },
  {
    title: 'Information Technology (IT) Sector',
    name: 'it',
    isActive: true,
  },
  {
    title: 'Healthcare',
    name: 'healthcare',
    isActive: true,
  },
  {
    title: 'Finance',
    name: 'finance',
    isActive: true,
  },
  {
    title: 'Retail',
    name: 'retail',
    isActive: true,
  },
  {
    title: 'Manufacturing',
    name: 'manufacturing',
    isActive: true,
  },
  {
    title: 'Nonprofit and Social Organizations',
    name: 'nonprofit_social',
    isActive: true,
  },
  {
    title: 'Telecommunications',
    name: 'telecommunications',
    isActive: true,
  },
  {
    title: 'Agriculture',
    name: 'agriculture',
    isActive: true,
  },
  {
    title: 'Media and Entertainment',
    name: 'media_entertainment',
    isActive: true,
  },
];
