module.exports = [
  {
    question: 'What city were you born in?',
  },
  {
    question: 'What is the name of your first pet?',
  },
  {
    question: 'What is your favorite book or movie?',
  },
  {
    question: 'Who was your childhood best friend?',
  },
  {
    question: 'What is the name of the hospital where you were born?',
  },
  {
    question: 'What is your favorite food?',
  },
  {
    question: 'What street did you grow up on?',
  },
  {
    question: 'In what city did you meet your spouse/partner?',
  },
  {
    question: 'What is the name of your favorite fictional character?',
  },
  {
    question: 'What is your favorite vacation destination?',
  },
  {
    question: 'What was your dream job as a child?',
  },
];
