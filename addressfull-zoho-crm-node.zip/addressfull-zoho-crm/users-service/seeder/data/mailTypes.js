module.exports = [
  {
    title: 'Send Verification Code',
    mailType: 'send-otp',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Verification Code',
    body: `<html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 10px 20px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
         }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Verification Code</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>Thank you for using our services. To complete your verification, please enter the following verification code:</p>
          <p style="font-size: 24px; font-weight: bold; color: #007BFF;">Your Verification Code: <span style="color: #333;">{{templateVars.otp}}</span></p>
          <p>This verification code is valid for a short period of time, so please use it promptly.</p>
          <p>If you did not request this verification, please ignore this email.</p>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`,
    description: 'This email will be used to send OTP to the users',
  },
  {
    title: 'Send Verification Code',
    mailType: 'send-otp',
    userType: 'organization-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Verification Code',
    body: `<html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 10px 20px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
         }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Verification Code</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>Thank you for using our services. To complete your verification, please enter the following verification code:</p>
          <p style="font-size: 24px; font-weight: bold; color: #007BFF;">Your Verification Code: <span style="color: #333;">{{templateVars.otp}}</span></p>
          <p>This verification code is valid for a short period of time, so please use it promptly.</p>
          <p>If you did not request this verification, please ignore this email.</p>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`,
    description: 'This email will be used to send OTP to the users',
  },
  {
    title: 'Reset Password',
    mailType: 'password-reset',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Password Reset',
    body: `<html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 10px 20px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
        }
        a.button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            text-decoration: none;
            color: #ffffff;
            background-color: #3498db;
            border-radius: 5px;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
         }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Password Reset</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>We received a request to reset your password. To reset your password, please click on the link below:</p>
          <div class="button-container">
              <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Reset Password Link</a>
           </div>
          <p>If you did not request a password reset, you can ignore this email. Your password will remain unchanged.</p>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`,
    description: 'This email will be used to reset the password',
  },
  {
    title: 'Reset Password',
    mailType: 'password-reset',
    userType: 'organization-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Password Reset',
    body: `<html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 10px 20px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
        }
        a.button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            text-decoration: none;
            color: #ffffff;
            background-color: #3498db;
            border-radius: 5px;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
         }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Password Reset</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>We received a request to reset your password. To reset your password, please click on the link below:</p>
          <div class="button-container">
              <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Reset Password Link</a>
           </div>
          <p>If you did not request a password reset, you can ignore this email. Your password will remain unchanged.</p>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`,
    description: 'This email will be used to reset the password',
  },
  {
    title: 'Admin Created',
    mailType: 'new-account',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Welcome to the AddressFull Admin Portal',
    body: `<html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: "Arial", "Helvetica", sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        a.button {
          display: inline-block;
          padding: 10px 20px;
          margin-top: 20px;
          text-decoration: none;
          color: #ffffff;
          background-color: #3498db;
          border-radius: 5px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Password Reset</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>Welcome to AddressFull</p>
          <p>
            We are excited to have you on board. Your account has been
            successfully created, and here are your login details:
          </p>
          <p><strong>Email:</strong> {{templateVars.email}}</p>
          <p><strong>Temporary Password:</strong> {{templateVars.password}}</p>
          <p>
            Please use the provided credentials to log in to the Admin Portal.
            Upon your first login, you will be prompted to change your password
            for security purposes.
          </p>
          <div class="button-container">
            <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Log In Now</a>
          </div>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new admin user will be created',
  },
  {
    title: 'Admin Created',
    mailType: 'new-account',
    userType: 'organization-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Welcome to the AddressFull Admin Portal',
    body: `<html>
    <head>
      <style>
        /* Styles for the email template */
        body {
          font-family: "Arial", "Helvetica", sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 10px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 20px;
          color: #333;
        }
        a.button {
          display: inline-block;
          padding: 10px 20px;
          margin-top: 20px;
          text-decoration: none;
          color: #ffffff;
          background-color: #3498db;
          border-radius: 5px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Password Reset</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>Welcome to AddressFull</p>
          <p>
            We are excited to have you on board. Your account has been
            successfully created, and here are your login details:
          </p>
          <p><strong>Email:</strong> {{templateVars.email}}</p>
          <p><strong>Temporary Password:</strong> {{templateVars.password}}</p>
          <p>
            Please use the provided credentials to log in to the Admin Portal.
            Upon your first login, you will be prompted to change your password
            for security purposes.
          </p>
          <div class="button-container">
            <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Log In Now</a>
          </div>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new admin user will be created',
  },
  {
    title: 'Organization Registration',
    mailType: 'organization-registration',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'AddressFull Registration',
    body: `<html>
    <head>
      <style>
        /* Styles for the professional email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 20px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 30px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
          display: inline-block;
          margin-top: 20px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>New Organization Registration</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>We are delighted to extend a warm welcome to you at AddressFull</p>
          <p>To complete your account setup and gain access to our system, kindly click on the button below:</p>
          <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Set Up Your Account</a>
          <p>If you did not initiate this registration or have any concerns, please disregard this email.</p>
        </div>
        <div class="footer">
          <p>Best regards,<br />AddressFull Team</p>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new organization is registered',
  },
  {
    title: 'Organization Registration Notification',
    mailType: 'organization-registered',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'New Organization Registration',
    body: `<html>
      <head>
        <style>
          /* Styles for the professional email template */
          body {
            font-family: 'Arial', 'Helvetica', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          }
          .header {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 20px;
            border-radius: 10px 10px 0 0;
          }
          .logo {
            text-align: center;
            margin-top: 15px;
            margin-bottom: 15px;
          }
          .logo img {
            max-width: 100%;
            height: 100px;
          }
          .content {
            padding: 30px;
            color: #333;
          }
          .button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
            margin-top: 20px;
          }
          .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>New Organization Registration</h1>
          </div>
          <div class="logo">
            <img
              src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
              alt="Company Logo"
            />
          </div>
          <div class="content">
            <p>We're thrilled to inform you that a new organization has joined our platform!</p>
            <p>The organization registered using the email address <b>{{templateVars.email}}</b>.</p>
            <p> If you have any questions or need further details about this new registration, please visit the admin panel.</p>
            <a style="color: #ffffff;" href="{{templateVars.link}}" class="button">Admin Panel</a>
          </div>
          <div class="footer">
            <p>Best regards,<br />AddressFull Team</p>
          </div>
        </div>
      </body></html>`,
    description:
      'This email will be sent to the super-admin when a new organization is registered',
  },
  {
    title: 'Data Access Revocation Request',
    mailType: 'delete-user-data-notification',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Data Access Revocation Request',
    body: `<html>
    <head>
      <style>
        /* Styles for the professional email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 20px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 30px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
          display: inline-block;
          margin-top: 20px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>User Data Deletion Request</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>The user registered with the phone number +{{templateVars.countryCode}}{{templateVars.mobileNumber}} has requested that all data is removed from your platform</p>
          <p>Kindly proceed with the necessary actions to remove their data from our CRM system</p>
        </div>
        <div class="footer">
          <p>Best regards,<br />AddressFull Team</p>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new organization is registered',
  },
  {
    title: 'Data Access Revocation Request',
    mailType: 'delete-user-data-notification',
    userType: 'organization-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Data Access Revocation Request',
    body: `<html>
    <head>
      <style>
        /* Styles for the professional email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 20px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 30px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
          display: inline-block;
          margin-top: 20px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>User Data Deletion Request</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>The user registered with the phone number +{{templateVars.countryCode}}{{templateVars.mobileNumber}} has requested that all data is removed from your platform</p>
          <p>Kindly proceed with the necessary actions to remove their data from our CRM system</p>
        </div>
        <div class="footer">
          <p>Best regards,<br />AddressFull Team</p>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new organization is registered',
  },
  {
    title: 'Data Access Revocation Request (For Block)',
    mailType: 'block-user-data-notification',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Data Access Revocation Request',
    body: `<html>
    <head>
      <style>
        /* Styles for the professional email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 20px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 30px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
          display: inline-block;
          margin-top: 20px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Request to remove user data</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>The user registered with the phone number +{{templateVars.countryCode}}{{templateVars.mobileNumber}} has requested to revoke all data access from our platform.</p>
          <p>Kindly proceed with the necessary actions to remove their data from our CRM system.</p>
        </div>
        <div class="footer">
          <p>Best regards,<br />AddressFull Team</p>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new organization is registered',
  },
  {
    title: 'Data Access Revocation Request (For Block)',
    mailType: 'block-user-data-notification',
    userType: 'organization-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Data Access Revocation Request',
    body: `<html>
    <head>
      <style>
        /* Styles for the professional email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #3498db;
          color: white;
          text-align: center;
          padding: 20px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 30px;
          color: #333;
        }
        .button {
          background-color: #3498db;
          color: white;
          border: none;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
          display: inline-block;
          margin-top: 20px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Request to remove user data</h1>
        </div>
        <div class="logo">
          <img
            src="https://api.addressfull.com/uploads/profilePictures/Logo1.png"
            alt="Company Logo"
          />
        </div>
        <div class="content">
          <p>The user registered with the phone number +{{templateVars.countryCode}}{{templateVars.mobileNumber}} has requested to revoke all data access from our platform.</p>
          <p>Kindly proceed with the necessary actions to remove their data from our CRM system.</p>
        </div>
        <div class="footer">
          <p>Best regards,<br />AddressFull Team</p>
        </div>
      </div>
    </body>
  </html>`,
    description:
      'This email will be used when a new organization is registered',
  },
  {
    title: 'Profile Approval Pending Notification',
    mailType: 'profile-approval-pending-notification',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Profile Approval Pending Notification',
    body: `<html><head>
      <style>
        /* Styles for the professional email template */
        body {
          font-family: 'Arial', 'Helvetica', sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #00B000;
          color: white;
          text-align: center;
          padding: 20px;
          border-radius: 10px 10px 0 0;
        }
        .logo {
          text-align: center;
          margin-top: 15px;
          margin-bottom: 15px;
        }
        .logo img {
          max-width: 100%;
          height: 100px;
        }
        .content {
          padding: 30px;
          color: #333;
        }
        .button {
          background-color: #00B000;
          color: white;
          border: none;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          cursor: pointer;
          display: inline-block;
          margin-top: 20px;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #777;
        }
      </style>
    </head>
    <body spellcheck="false" style="min-height: 101px;" contenteditable="true">
      <div class="container">
        <div class="header">
          <h1>Your Profile is Complete – Awaiting Super Admin Approval</h1>
        </div>
        <div class="logo">
          <img src="https://api.addressfull.com/uploads/profilePictures/Logo1.png" alt="Company Logo">
        </div>
        <div class="content">
          <p>Dear {{templateVars.organizationName}},<br><br>Thank you for completing your profile! Your account is now pending approval from the Super Admin.<br><br>Once approved, you'll gain access to the modules that will help you collect and manage your organisation's data effectively.<br><br>We appreciate your patience during this process. You will receive a confirmation email once your account is approved.<br><br>If you have any questions, feel free to reach out to our support team.<br></p>
        </div>
        <div class="footer">
          <p>Best regards,<br>AddressFull</p>
        </div>
      </div>
  </body></html>`,
    description:
      'This email will be used when a new organization complete their profile',
  },
  {
    title: 'Profile Approval Success Notification',
    mailType: 'profile-approval-success-notification',
    userType: 'super-admin',
    fromName: 'AddressFull',
    fromEmail: 'developer@addressfull.com',
    subject: 'Profile Approval Success Notification',
    body: `<html><head>
<style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
  }
  .container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, .1);
  }
  .header {
    background-color: #00b000;
    color: #fff;
    text-align: center;
    padding: 20px;
    border-radius: 10px 10px 0 0;
  }
  .logo {
    text-align: center;
    margin-top: 15px;
    margin-bottom: 15px;
  }
  .logo img {
    max-width: 100%;
    height: 100px;
  }
  .content {
    padding: 30px;
    color: #333;
  }
  .button {
    background-color: #00b000;
    color: #fff;
    border: none;
    padding: 12px 24px;
    text-decoration: none;
    border-radius: 5px;
    cursor: pointer;
    display: inline-block;
    margin-top: 20px;
  }
  .footer {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
    text-align: center;
    color: #777;
  }
</style></head>
<body style="min-height: 101px;">
  <div class="container">
    <div class="header">
      <h1>Your Organisation Profile Has Been Approved</h1>
    </div>
    <div class="logo">
      <img alt="Company Logo" src="https://api.addressfull.com/uploads/profilePictures/Logo1.png">
    </div>
    <div class="content">
      <p>Dear {{templateVars.organizationName}},</p>
      <p>We are pleased to inform you that your organisation profile has been approved by the Super Admin. You now have full access to the modules and can begin collecting and managing data for your users.</p>
      <p>Log in to your account to get started: 
        <a class="button" href="{{templateVars.link}}" style="color: #fff;">Admin Panel</a>
      </p>
      <p>If you need assistance, our support team is here to help.</p>
      <p>Welcome aboard!</p>
    </div>
    <div class="footer">
      <p>Best regards,</p>
      <p>AddressFull</p>
    </div>
  </div>
</body></html>`,
    description:
      'This email will be used when a new organization approve by superAdmin',
  },
];
