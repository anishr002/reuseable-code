const asyncHandler = require('../middleware/asyncHandler');
const {
  configureCRM,
  updateCRMSetting,
  getCRMList,
} = require('../services/crmSettingService');
const responseMessages = require('../config/constants/reponseMessages');
// const activityFilter = require('../models/activityFilterModel');

exports.addCRM = async (req, res) => {
  const { type, auth_token, zohoClientId, zohoSecretKey, authCode } = req.body;
  const configuredCRM = await configureCRM({
    type,
    auth_token,
    zohoClientId,
    zohoSecretKey,
    authCode,
  });
  // Check for Zoho OAuth-specific errors
  if (configuredCRM?.data?.error === 'invalid_code' || configuredCRM?.error) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.INVALID_ZOHO_AUTH_CODE,
    });
  }
  if (configuredCRM?.data) {
    // Update CRM Setting
    const crmSettingUpdated = await updateCRMSetting(
      req.body,
      req.user,
      configuredCRM.data
    );
    if (!crmSettingUpdated?.error) {
      return res.status(200).json({
        status: 200,
        data: responseMessages.CRM_CONNECTED,
      });
    }
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.CRM_NOT_CONNECTED,
  });
};

exports.getCRMIntegrations = asyncHandler(async (req, res) => {
  const crmList = await getCRMList(req.user);
  const responseData = crmList.length
    ? crmList.map((crm) => ({
        id: crm._id,
        auth_token: crm.config.authToken,
        type: crm.type,
        zohoClientId: crm.zohoClientId,
        zohoSecretKey: crm.zohoSecretKey,
        zohoRefreshToken: crm.zohoRefreshToken,
        zohoAccessToken: crm.zohoAccessToken,
        zohoAccessTokenExpiresAt: crm.zohoAccessTokenExpiresAt,
      }))
    : [];
  if (!crmList.error) {
    return res.json({
      status: 200,
      data: responseData,
    });
  }
  return res.status(400).json({
    status: 400,
    data: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// exports.addActivity = asyncHandler(async (req, res) => {
//   try {
//     const reqBody = req.body;
//     const responseData = await activityFilter.create(reqBody);

//     return res.json({
//       status: 200,
//       data: responseData,
//     });
//   } catch (error) {
//     return res.status(400).json({
//       status: 400,
//       data: responseMessages.SOMETHING_WENT_WRONG,
//     });
//   }
// });
