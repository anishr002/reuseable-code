const asyncHandler = require('../middleware/asyncHandler');
const { uploadFileToS3 } = require('../helpers/S3BucketHelper');
const { createPDFByHTML } = require('../services/documentService');
const { getMyTrusted } = require('../services/organizationService');
const createOrgSharedDataTemplate = require('../pdfTemplates/orgSharedDataTemplate');
const responseMessages = require('../config/constants/reponseMessages');
const fsConstants = require('../config/constants/fileUploads');

exports.generateOrgSharedDataPDF = asyncHandler(async (req, res) => {
  const loggedInUserData = req.user;
  const trustedOrganizationIds = loggedInUserData?.trustedOrganizations || [];
  let organizationList = [];
  if (!trustedOrganizationIds.length) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.REPORT_NO_ORG,
    });
  }
  ({ organizationList } = await getMyTrusted({
    where: {
      ...(trustedOrganizationIds.length > 0
        ? {
            _id: {
              $in: trustedOrganizationIds,
            },
          }
        : null),
    },
    selectString: '-__v',
    skip: 0,
    limit: 1000,
  }));
  const pdfContent = await createOrgSharedDataTemplate(
    organizationList,
    loggedInUserData
  );
  const pdfCreated = await createPDFByHTML({
    htmlContent: pdfContent,
  });
  if (!pdfCreated?.error && pdfCreated) {
    // Create a pdf file inside bucket
    const fileCreatedLink = await uploadFileToS3({
      folderName: `${loggedInUserData._id}/${fsConstants.S3_REPORTS_FOLDER}`,
      fileName: 'organizations_shared_data.pdf',
      fileContent: pdfCreated,
      loggedInUserData,
    });
    if (fileCreatedLink) {
      return res.status(200).json({
        status: 200,
        data: {
          link: fileCreatedLink,
        },
      });
    }
  }
  return res.status(400).json({
    status: 400,
    data: responseMessages.REPORT_FAIL,
  });
});
