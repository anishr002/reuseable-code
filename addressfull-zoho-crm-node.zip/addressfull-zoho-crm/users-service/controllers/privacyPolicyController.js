const asyncHandler = require('../middleware/asyncHandler');
const responseMessages = require('../config/constants/reponseMessages');
const {
  create,
  update,
  findPolicyByName,
  findPolicyById,
  deleteOne,
  getPolicyList,
  formatPolicyResponse,
} = require('../services/privacyPolicyService');
const {
  isPolicySync,
  isPolicyAndRuleSync,
} = require('../services/organizationService');
const { throwError } = require('../services/commonService');

// Create Policy
exports.createPolicy = asyncHandler(async (req, res) => {
  try {
    const { title, subRules, isActive } = req.body;

    // Check if Policy with same name exists
    const policyNameExists = await findPolicyByName({
      policyName: title,
    });
    if (policyNameExists && Object.keys(policyNameExists).length) {
      throwError(409, responseMessages.POLICY_NAME_EXISTS);
    }

    const createPolicy = await create({
      title,
      subRules,
      isActive,
      createdBy: req.user._id,
    });

    if (!createPolicy?.error) {
      throwError(201, responseMessages.POLICY_CREATED);
    }

    throwError(400, responseMessages.POLICY_CREATE_ERROR);
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

// Update Policy
exports.updatePolicy = asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    const { title, isActive, subRules } = req.body;

    // Verify if the policy exists
    const policy = await findPolicyById(id, '_id title subRules');
    if (!policy) {
      throwError(404, responseMessages.POLICY_NOT_FOUND);
    }

    const updatedPolicy = await update(id, {
      title,
      subRules,
      isActive,
    });

    if (updatedPolicy?.policyNameExists) {
      throwError(409, responseMessages.POLICY_NAME_EXISTS);
    }

    if (updatedPolicy && !updatedPolicy.error) {
      throwError(200, responseMessages.POLICY_UPDATED);
    }

    throwError(400, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

// Delete Policy
exports.deletePolicy = asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;

    // Verify if the policy sync
    const syncStatus = await isPolicySync(id);
    if (syncStatus) {
      throwError(400, responseMessages.POLICY_SYNC_ERROR);
    }

    const deletedPolicy = await deleteOne(id);
    if (deletedPolicy && !deletedPolicy.error && deletedPolicy.deletedCount) {
      throwError(200, responseMessages.POLICY_DELETED);
    }

    throwError(400, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.getPolicies = asyncHandler(async (req, res) => {
  try {
    const { sort_by: sortBy, order_by: orderBy, active = 'yes' } = req.query;
    const page = req.query.page ? parseInt(req.query.page, 10) : 1;
    const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
    const skip = (page - 1) * limit;
    const { policyList, pageInfo } = await getPolicyList({
      where: {
        ...(active === 'yes' ? { isActive: true } : { isActive: false }),
      },
      selectString: '-createdBy -__v',
      skip,
      limit,
      sortBy,
      orderBy,
    });

    const responseData = policyList?.length
      ? await Promise.all(
          policyList.map(
            async (listItem) =>
              formatPolicyResponse(listItem, isPolicyAndRuleSync)
          )
        )
      : [];
    if (policyList && !policyList.error) {
      return res.status(200).json({
        status: 200,
        data: {
          policy_list: responseData,
          page_info: {
            total_count: pageInfo.totalCount,
            total_pages: pageInfo.totalPages,
            current_page: pageInfo.currentPage,
          },
        },
      });
    }
    throwError(400, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});
