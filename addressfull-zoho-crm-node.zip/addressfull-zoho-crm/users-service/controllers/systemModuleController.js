const asyncHandler = require('../middleware/asyncHandler');
const { findModulesByUser } = require('../services/systemModuleService');
const { findRoleById } = require('../services/roleService');
const userRoles = require('../config/constants/userRoles');

exports.getModules = asyncHandler(async (req, res) => {
  // Return modules based on userType and permissions.
  let modules = [];
  if (req.user.userType) {
    modules = await findModulesByUser(req.user.userType, '-_id name title');
  } else if (req.user.role) {
    let createdByUserType;
    if (req.user.userType) {
      createdByUserType = req.user.userType;
    } else if (req.user?.isAdminMember === true) {
      createdByUserType = userRoles.SUPER_ADMIN;
    } else {
      createdByUserType = userRoles.ORGANIZATION_ADMIN;
    }
    const moduleList = await findModulesByUser(createdByUserType);
    const user = await findRoleById(req.user.role);
    modules = user.permissions.map((permission) => {
      // Get module title
      const moduleTitle = moduleList
        .filter((module) => module.name === permission.module)
        .map((moduleData) => moduleData.title);
      return {
        module: permission.module,
        title: moduleTitle[0] || null,
        permission: permission.permission,
      };
    });
  }
  return res.json({
    status: 200,
    data: modules,
  });
});
