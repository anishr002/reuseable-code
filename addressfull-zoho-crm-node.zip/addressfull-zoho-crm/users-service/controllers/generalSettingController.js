const asyncHandler = require('../middleware/asyncHandler');
const {
  updateUserSettings,
  getSettingsByUser,
  formatSettingsResponse,
} = require('../services/generalSettingService');
const responseMessages = require('../config/constants/reponseMessages');
const userRoles = require('../config/constants/userRoles');

exports.updateSettings = asyncHandler(async (req, res) => {
  const {
    to_email: toEmail,
    sms_service: smsService,
    timezone,
    cron_execution_time,
    token_expiration_time,
    activity_filters,
  } = req.body;
  const updatedSettings = await updateUserSettings({
    settings: {
      ...(toEmail !== undefined && { toEmail }),
      ...(smsService !== undefined && { smsService }),
      ...(timezone !== undefined && { timezone }),
      ...(cron_execution_time !== undefined && { cron_execution_time }),
      ...(token_expiration_time !== undefined && { token_expiration_time }),
      ...(activity_filters !== undefined && { activity_filters }),
    },
    userId: req.user.userType === userRoles.SUPER_ADMIN ? null : req.user._id,
  });
  if (!updatedSettings.error) {
    // format response
    const responseData = await formatSettingsResponse(updatedSettings);
    return res.json({
      status: 200,
      data: responseData,
      message: responseMessages.SETTINGS_UPDATED,
    });
  }
  return res.status(400).json({
    status: 400,
    data: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getSettings = asyncHandler(async (req, res) => {
  const getSettings = await getSettingsByUser(
    req.user.userType === userRoles.SUPER_ADMIN ? null : req.user._id
  );
  // format response
  const responseData = await formatSettingsResponse(getSettings);
  return res.json({
    status: 200,
    data: responseData,
  });
});
