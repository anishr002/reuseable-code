const moment = require('moment-timezone');
const logger = require('../logger');
const asyncHandler = require('../middleware/asyncHandler');
const { throwError } = require('../services/commonService');
const {
  getNotifications,
  sendNotification,
  readNotification,
  notificationById,
  processNotification,
} = require('../services/notificationService');
const {
  makeBlockchainApiCallWithRetry,
  replaceWordsInMessage,
} = require('../services/blockChainService');
const { getSettingsByUser } = require('../services/generalSettingService');
const { generatePrivacyPolicy } = require('../services/privacyPolicyService');
const {
  saveOrUpdateDeviceUpdate,
  findDevice,
} = require('../services/deviceUpdateService');
const {
  findUserById,
  updateBlockChainToken,
  // generateProfilePictureURL,
  generateProfileImageFromS3,
} = require('../services/userService');
const {
  getOrganizationByUserId,
  getOrganizationById,
  getOrganizationsByNameOrId,
} = require('../services/organizationService');
const {
  getBlockOrganization,
} = require('../services/blockOrganizationService');
const userRoles = require('../config/constants/userRoles');
const responseMessages = require('../config/constants/reponseMessages');
const { generateJWTSign } = require('../helpers/jwtHelper');

exports.getNotificationList = asyncHandler(async (req, res) => {
  const authToken =
    req.headers && (req.header('authorization') || req.header('token'));
  const response = await getNotifications({
    token: authToken,
    userData: req.user,
    queryParams: req.query,
  });
  const { timezone } = req.query;
  response.notification_list = response.notification_list
    ? await Promise.all(
        response.notification_list.map(
          async ({ _id, organizationId, createdAt, message }) => {
            const [org] = await getOrganizationsByNameOrId(
              [organizationId],
              '_id name'
            );
            const orgName = org?.name || null;
            const orgProfile = org?.userId?.profileImage || null;
            let requestedDate = moment(createdAt);
            if (timezone) {
              requestedDate = requestedDate.tz(timezone);
            }
            requestedDate = requestedDate.format('DD-MM-YYYY, hh:mm A');

            return {
              request_id: _id,
              organization_id: organizationId,
              organization_name: orgName,
              // organization_profile_image: generateProfilePictureURL(orgProfile),
              organization_profile_image: await generateProfileImageFromS3(
                org?.userId?._id,
                orgProfile
              ),
              request_date: requestedDate,
              default_request_date: createdAt,
              message: await replaceWordsInMessage(
                message,
                req.user.userType,
                'None',
                true,
                true
              ),
            };
          }
        )
      )
    : [];
  if (!response?.error) {
    if (response?.status) {
      return res.status(response?.status).json(response);
    }
    return res.status(200).json({
      status: 200,
      data: response,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

const filterNotifications = async (notificationList, labelsToRemove) => {
  const modifiedNotifications = [];
  notificationList.forEach((notification) => {
    const modifiedNotification = { ...notification };

    modifiedNotification.requestedLabels =
      modifiedNotification.requestedLabels.filter(
        (label) => !labelsToRemove.includes(label)
      );

    labelsToRemove.forEach((label) => {
      const labelRegex = new RegExp(`,? ${label}`, 'g');
      modifiedNotification.message = modifiedNotification.message.replace(
        labelRegex,
        ''
      );
    });

    modifiedNotification.message = modifiedNotification.message.replace(
      /your\s*(, )?/,
      'your '
    );
    modifiedNotifications.push(modifiedNotification);
  });
  return modifiedNotifications;
};

const getNotificationsWithParams = (
  token,
  mobileUser,
  organizationId,
  reqPeriod,
  timezone
) =>
  getNotifications({
    token: `Bearer ${token}`,
    userData: mobileUser,
    queryParams: {
      page: 1,
      page_size: 10,
      is_read: 0,
      req_period: reqPeriod,
      organization_id: organizationId,
      timezone,
    },
  });

const makeTransactions = async (organization, requestDetails, mobileUser) => {
  const { _id: userId, countryCode, mobileNumber } = mobileUser;
  const policy = await generatePrivacyPolicy(organization);

  const requestDetailsString = requestDetails.join(', ');

  const transactions = [
    {
      log_type: 'request',
      permission_status: 'sent',
      consent_requestor: organization?.name || 'Organization',
      version: 1,
      updated_parameter: [requestDetailsString],
      user_in_front: '',
      // messages: requestDetails.map(
      //   (label) =>
      //     `${organization?.name} organization has requested your ${label} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`
      // ),
      messages: [
        `${organization?.name} wants to access your ${requestDetailsString} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`,
      ],
    },
  ];
  // console.log('transactions....', transactions);

  // Make blockchain API call
  const startTime = new Date();
  logger.info(`Blockchain executed at: ${startTime}`);
  logger.info(`Started Blockchain API Call`);
  const sharedData = await makeBlockchainApiCallWithRetry(
    transactions,
    mobileUser?.blockChainToken || null,
    {
      countryCode,
      mobileNumber,
      userId,
      updateBlockChainToken,
    }
  );
  logger.info(`Finished Blockchain API Call`);
  const elapsedTime = new Date() - startTime;
  logger.info(`Blockchain took ${elapsedTime} milliseconds`);

  return sharedData;
};

const processNotificationsAndSend = async ({
  previousNotifications,
  requestDetails,
  mobileUser,
  organization,
  authToken,
  userId,
  clientId,
  diffStatus = true,
}) => {
  if (previousNotifications?.notification_list.length) {
    const modifiedNotifications = await filterNotifications(
      previousNotifications.notification_list,
      requestDetails
    );
    await processNotification(mobileUser, {
      notificationRequests: modifiedNotifications,
    });
  }

  if (diffStatus) {
    await sendNotification(
      {
        requester_id: userId,
        receiver_id: clientId,
        organization_id: organization?._id,
        organization_name: organization?.name,
        request_details: requestDetails,
        extra_data: { status: true, type: 11 },
      },
      authToken,
      'REQUEST'
    );
  }
};

exports.sendRequestToUser = asyncHandler(async (req, res) => {
  try {
    const { client_id: clientId, request_details: requestDetails } = req.body;
    const { userType, _id: userId, organizationId } = req.user;
    const authToken = `Bearer ${req.user.token}`;

    // Fetch mobile user
    const mobileUser = await findUserById(clientId);
    if (!mobileUser || mobileUser.userType !== userRoles.FRONT_END_USER) {
      throwError(404, responseMessages.USER_NOT_FOUND);
    }

    // Fetch organization
    const currentUserId =
      userType === userRoles.ORGANIZATION_ADMIN ? userId : organizationId;
    const organization = await getOrganizationByUserId(currentUserId);
    if (!organization) {
      throwError(404, responseMessages.ORG_NOT_FOUND);
    }

    // Restrict another country to send request
    const contactCountryCode = (organization.contactNumbers?.[0] || '')
      .split('|')[0]
      ?.replace('+', '');
    const loggedInCountryCode = (mobileUser.countryCode || '').replace('+', '');
    if (contactCountryCode !== loggedInCountryCode) {
      throwError(404, responseMessages.DATA_REQUEST_INVALID_COUNTRY);
    }

    // Check if organization is blocked
    const isBlocked = await getBlockOrganization(organization._id, clientId);
    if (isBlocked) {
      throwError(400, responseMessages.BLOCK_REQUEST_SEND_ERROR);
    }

    // Generate token for mobile user
    const token = generateJWTSign({
      countryCode: mobileUser.countryCode,
      mobileNumber: mobileUser.mobileNumber,
    });
    mobileUser.token = token;

    // Fetch organization
    const timezone =
      (await getSettingsByUser(organization.userId))?.settings?.timezone ||
      'UTC';

    // Fetch recent and previous notifications
    const [userRecentNotification, userPreviousNotification] =
      await Promise.all([
        getNotificationsWithParams(
          token,
          mobileUser,
          organization._id,
          0,
          timezone
        ),
        getNotificationsWithParams(
          token,
          mobileUser,
          organization._id,
          1,
          timezone
        ),
      ]);

    // If no recent notifications, send request to user directly
    if (userRecentNotification?.notification_list.length === 0) {
      const sharedData = await makeTransactions(
        organization,
        requestDetails,
        mobileUser
      );

      if (sharedData?.status) {
        await processNotificationsAndSend({
          previousNotifications: userPreviousNotification,
          requestDetails,
          mobileUser,
          organization,
          authToken,
          userId,
          clientId,
        });

        return res
          .status(200)
          .json({ status: 200, message: responseMessages.REQUEST_SENT });
      }
    }

    if (userRecentNotification?.notification_list.length > 0) {
      // Filter recent request
      let diffStatus = true;
      let diffValues = requestDetails;
      userRecentNotification?.notification_list.forEach((notification) => {
        const currentLabels = notification.requestedLabels;
        diffValues = diffValues.filter((item) => !currentLabels.includes(item));
      });
      diffStatus = diffValues.length !== 0;

      if (diffValues.length === 0) {
        await processNotificationsAndSend({
          previousNotifications: userPreviousNotification,
          requestDetails,
          mobileUser,
          organization,
          authToken,
          userId,
          clientId,
          diffStatus,
        });

        return res
          .status(200)
          .json({ status: 200, message: responseMessages.REQUEST_SENT });
      }

      if (diffValues.length > 0) {
        const sharedData = await makeTransactions(
          organization,
          diffValues,
          mobileUser
        );

        if (sharedData?.status) {
          await processNotificationsAndSend({
            previousNotifications: userPreviousNotification,
            requestDetails: diffValues,
            mobileUser,
            organization,
            authToken,
            userId,
            clientId,
          });

          return res
            .status(200)
            .json({ status: 200, message: responseMessages.REQUEST_SENT });
        }
      }
    }
    throwError(400, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.updateRequest = asyncHandler(async (req, res) => {
  const authToken = req.headers?.authorization || req.headers?.token;
  const {
    request_id: requestId,
    organization_id: organizationId,
    request_status: requestStatus,
  } = req.body;

  const org = await getOrganizationById(organizationId);
  if (!org || org.error) {
    return res
      .status(404)
      .json({ status: 404, message: responseMessages.ORG_NOT_FOUND });
  }

  const isBlocked = await getBlockOrganization(org._id, req.user._id);
  if (isBlocked) {
    return res.status(200).json({
      status: 400,
      message: responseMessages.BLOCKED_ORG_ERROR,
    });
  }

  const request = await notificationById(requestId, authToken);
  if (!request) {
    return res
      .status(400)
      .json({ status: 400, message: responseMessages.SOMETHING_WENT_WRONG });
  }

  const requestDetails = request?.data?.data?.requestedLabels || [];
  const mobileUser = await findUserById(req.user?._id);
  if (
    !mobileUser ||
    mobileUser.isDeleted ||
    mobileUser.userType !== userRoles.FRONT_END_USER
  ) {
    return res
      .status(404)
      .json({ status: 404, message: responseMessages.USER_NOT_FOUND });
  }

  const {
    _id: userId,
    countryCode,
    mobileNumber,
    blockChainToken = null,
  } = mobileUser;

  const labelText = requestStatus ? 'Accepted' : 'Rejected';
  const permissionStatus = requestStatus ? 'approve' : 'reject';

  const requestDetailsString = requestDetails.join(', ');

  const transactions = [
    {
      log_type: 'consent',
      permission_status: permissionStatus,
      consent_requestor: org.name || 'Organization',
      version: 1,
      updated_parameter: [requestDetailsString],
      user_in_front: '',
      // messages: requestDetails?.map(
      //   (label) =>
      //     `${labelText} request of ${label} for ${org.name || 'Organization'}`
      // ),
      messages: [
        `${labelText} the request for ${requestDetailsString} for ${org.name || 'Organization'}`,
      ],
    },
  ];
  // console.log('transactions..', transactions);

  try {
    const startTime = new Date();
    logger.info(`Blockchain executed at: ${startTime}`);
    logger.info('Started Blockchain API Call');
    const sharedData = await makeBlockchainApiCallWithRetry(
      transactions,
      blockChainToken,
      { countryCode, mobileNumber, userId, updateBlockChainToken }
    );
    logger.info('Finished Blockchain API Call');
    const endTime = new Date();
    const elapsedTime = endTime - startTime;
    logger.info(`Blockchain took ${elapsedTime} milliseconds`);

    if (!sharedData?.status) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.BLOCKCHAIN_TRANSACTION_REQUEST_FAILED,
      });
    }

    const rededNotification = await readNotification(requestId, authToken);
    if (rededNotification) {
      await sendNotification(
        {
          notification_to: 'ORGANIZATION-ADMIN',
          notification_type: requestStatus
            ? 'USER_APPROVE_REQUEST_TO_ORGANIZATION'
            : 'USER_REJECT_REQUEST_TO_ORGANIZATION',
          organization_id: org.userId,
          organization_parent_id: org._id,
          user_name: 'User',
          sender_id: userId,
        },
        authToken
      );

      return res.status(200).json({
        status: 200,
        message: requestStatus
          ? responseMessages.REQUEST_SUCCESS
          : responseMessages.REQUEST_REJECT,
      });
    }
  } catch (error) {
    logger.error('Error processing the request:', error);
  }

  return res
    .status(400)
    .json({ status: 400, message: responseMessages.SOMETHING_WENT_WRONG });
});

exports.forceUpdate = asyncHandler(async (req, res) => {
  try {
    const { device_type: deviceType, update_status: updateStatus } = req.body;

    let responseData = { device_type: deviceType, force_update: false };
    let message = responseMessages.DEVICE_UPDATE_SUCCESS.replace(
      '[DEVICE_TYPE]',
      deviceType
    );

    if (updateStatus !== undefined) {
      const savedDeviceUpdate = await saveOrUpdateDeviceUpdate({
        deviceType,
        updateStatus,
      });
      responseData = {
        device_type: savedDeviceUpdate.device_type,
        force_update: savedDeviceUpdate.update_status,
      };
    } else {
      message = responseMessages.DEVICE_GET_SUCCESS.replace(
        '[DEVICE_TYPE]',
        deviceType
      );
      const device = await findDevice(deviceType);
      if (device) {
        responseData = {
          device_type: device.device_type,
          force_update: device.update_status,
        };
      }
    }

    return res.status(200).json({
      status: 200,
      message,
      data: responseData,
    });
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      status: error.statusCode || 400,
      message: error.message || 'Something went wrong',
    });
  }
});

exports.readNotification = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { token } = req.user;
  const isReadNotification = await readNotification(id, `Bearer ${token}`);

  if (isReadNotification?.status && isReadNotification?.message) {
    return res.status(isReadNotification?.status).json(isReadNotification);
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.readAllNotification = asyncHandler(async (req, res) => {
  const { token, _id: userId } = req.user;
  const response = await readNotification(userId, `Bearer ${token}`, true);
  console.log('response......', response);
  if (response?.status && response?.message) {
    return res.status(response?.status).json(response);
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});
