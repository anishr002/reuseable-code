const jwt = require('jsonwebtoken');
const asyncHandler = require('../middleware/asyncHandler');
const responseMessages = require('../config/constants/reponseMessages');
const {
  getSecurityQuestionsList,
} = require('../services/securityQuestionService');
const { getSettingsByUser } = require('../services/generalSettingService');
const { throwError } = require('../services/commonService');
const { generateJWTSign } = require('../helpers/jwtHelper');
const { revokedTokens } = require('../middleware/tokenCleanupMiddleware');
const generalConfig = require('../config/constants/generalConfig');

exports.getSecurityQuestions = asyncHandler(async (_req, res) => {
  const securityQuestionsList = await getSecurityQuestionsList({
    where: {
      isActive: true,
    },
    selectString: 'question -_id',
  });
  if (securityQuestionsList && !securityQuestionsList.error) {
    return res.status(200).json({
      status: 200,
      data: securityQuestionsList,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.verifyTokenExpiration = asyncHandler(async (req, res) => {
  const { token } = req.params;

  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }

  const secretKey = process.env.SECRET_KEY;

  jwt.verify(token, secretKey, (err) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(400).json({ message: 'Token expired' });
      }
      return res.status(400).json({ message: 'Invalid token' });
    }
    return res.status(200).json({ message: 'Token is valid' });
  });
});

exports.refreshToken = asyncHandler(async (req, res) => {
  try {
    const { token } = req.user;

    // Decode the token
    const decodedToken = jwt.decode(token);

    // Collect payload from token
    const payload = {
      countryCode: decodedToken?.countryCode,
      mobileNumber: decodedToken?.mobileNumber,
    };

    // Fetch expiration time from db
    const generalSetting = await getSettingsByUser(null, 'settings');
    const expirationTime =
      generalSetting?.settings?.token_expiration_time ||
      generalConfig.DEFAULT_JWT_EXPIRATION;

    const newToken = generateJWTSign(payload, expirationTime);

    if (newToken) {
      // Add the old token to the revoked tokens map with expiration time
      revokedTokens.set(token, decodedToken.exp * 1000);

      return res.status(200).json({
        status: 200,
        message: responseMessages.TOKEN_REFRESH,
        data: {
          token: newToken,
        },
      });
    }

    throwError(400, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});
