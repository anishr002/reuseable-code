const asyncHandler = require('../middleware/asyncHandler');
const responseMessages = require('../config/constants/reponseMessages');
const { getCreatedByUserType } = require('../helpers/userHelper');
const userRoles = require('../config/constants/userRoles');
const {
  getAuthorizedOrgCount,
  getConnectedUsersCount,
  getOrganizationByUserId,
} = require('../services/organizationService');
const {
  countMobileUsers,
  countOrgAdminStaffMembers,
  // generateProfilePictureURL,
  generateProfileImageFromS3,
  findUserById,
} = require('../services/userService');
const {
  fetchAndTransformTransactions,
  fetchStatisticsData,
  replaceWordsInTransactions,
} = require('../services/blockChainService');
const {
  calculateNotificationCount,
} = require('../services/notificationService');
const { calculateCRMIntegrations } = require('../services/crmSettingService');
const requestStatus = require('../config/constants/requestStatus');

const handleSuperAdmin = async (crmTypesCount) => {
  const orgCount = await getAuthorizedOrgCount();
  const usersCount = await countMobileUsers();
  return {
    total_counts_data: {
      total_organization: orgCount || 0,
      total_user: usersCount || 0,
      total_crm_integrated: crmTypesCount || 0,
    },
  };
};

const handleOrganizationAdmin = async (userData) => {
  let crmTypesCount = 0;
  const CRMIntegrationsCount = await calculateCRMIntegrations(userData);
  if (!CRMIntegrationsCount?.error) {
    crmTypesCount = CRMIntegrationsCount;
  }

  const usersCount = await getConnectedUsersCount(userData);
  const adminStaffCount = await countOrgAdminStaffMembers(userData);
  const organizationUser = await findUserById(userData._id);
  const finalOrgId = organizationUser?.organizationId || userData._id;
  const organization = await getOrganizationByUserId(finalOrgId, 'name');
  const organization_name = organization.name;

  return {
    total_counts_data: {
      total_staff: adminStaffCount || 0,
      total_user: usersCount || 0,
      total_crm_integrated: crmTypesCount || 0,
    },
    organization_name,
  };
};

const getTransactionData = async (organization_name) => {
  const params = {
    page_size: 5,
    log_type: 'consent',
    permission_status: 'share, revoke',
    organization_name,
  };

  const transactions = await fetchAndTransformTransactions(params);
  return transactions;
};

const formatNotificationData = async (response) => {
  return Array.isArray(response.data)
    ? Promise.all(
        response.data.map(async (consent) => ({
          organization_name: consent?.organizationName || null,
          organization_logo: await generateProfileImageFromS3(
            consent.userId,
            consent.organizationLogo
          ),
          country_code: consent?.countryCode || null,
          mobile_number: consent?.mobileNumber || null,
          count: consent?.count || 0,
        }))
      )
    : [];
};

exports.dashboardData = asyncHandler(async (req, res) => {
  const userData = req.user;
  const { year } = req.query;

  const userType = getCreatedByUserType(userData);
  const CRMIntegrationsCount = await calculateCRMIntegrations(userData);
  const crmTypesCount = CRMIntegrationsCount?.error ? 0 : CRMIntegrationsCount;

  let calculatedDashboardData = {};

  if (userType === userRoles.SUPER_ADMIN) {
    calculatedDashboardData = await handleSuperAdmin(crmTypesCount);
  } else if (userType === userRoles.ORGANIZATION_ADMIN) {
    calculatedDashboardData = await handleOrganizationAdmin(userData);
  }

  const transactions = await getTransactionData(
    calculatedDashboardData.organization_name
  );

  if (userType === userRoles.ORGANIZATION_ADMIN) {
    transactions.forEach((trans) => {
      trans.message = trans.message.map((msg) => msg.replace(/ with .*/, ''));
    });
  }

  const replacedTrans =
    transactions.length > 0
      ? await replaceWordsInTransactions(transactions, userType)
      : [];

  calculatedDashboardData.daily_activity = replacedTrans;
  calculatedDashboardData.monthly_transaction_count = await fetchStatisticsData(
    {
      year,
      organizationName: calculatedDashboardData.organization_name,
      isIndividualLog: false,
    }
  );

  const notificationData = await calculateNotificationCount(userData, {
    reqType: 'CONSENT',
    reqStatus: [
      requestStatus.ACCEPT,
      requestStatus.REJECT,
      requestStatus.SHARE,
      requestStatus.UNSHARE,
    ],
    skip: 0,
    limit: 5,
  });

  if (!notificationData?.error) {
    const response = notificationData?.data?.data;
    calculatedDashboardData.user_consent_count =
      await formatNotificationData(response);
  }

  return res.json({
    status: 200,
    data: calculatedDashboardData,
  });
});
