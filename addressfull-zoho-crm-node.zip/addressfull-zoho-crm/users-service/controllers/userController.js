const { Types } = require('mongoose');
const asyncHandler = require('../middleware/asyncHandler');
const {
  createUser,
  findUserByEmail,
  findUserByDevice,
  updatePasswordResetToken,
  updatePassword,
  findUserByMobile,
  updateUserProfile,
  updateProfilePicture,
  generateProfilePictureURL,
  generateProfileImageFromS3,
  deleteProfilePicture,
  storePublicKey,
  formatResponseDocument,
  updateAdmin,
  findUserById,
  updateSocialInfo,
  getAdminList,
  deleteAdmin,
  updateNewRegistrationToken,
  getUserRole,
  getUserRoleName,
  getPermissionsList,
  generateOrgDocURL,
  signupFrontendUser,
  updateDeviceToken,
  deleteUserData,
  activateUserAccount,
  registerUserAccount,
  findUser,
  isOrgAdmin,
  deleteS3File,
  removeBlockedOrganization,
} = require('../services/userService');
const { getAllCronHistory } = require('../services/cronHistoryService');
const {
  findOrganizationById,
  updateOrganizationProfile,
  removeBlockedUsers,
  isDuplicateRegisteredNumber,
  getOrganizationByUserId,
} = require('../services/organizationService');
const {
  deleteBlockAllOrganization,
  getBlockOrganizationOfUser,
} = require('../services/blockOrganizationService');
const {
  sendNotification,
  removeAllNotification,
} = require('../services/notificationService');
const { makeBlockchainRequest } = require('../services/blockChainService');
const { findOneRole } = require('../services/roleService');
const {
  addNewJobToQueue,
  getDeleteJobByUserId,
} = require('../services/deleteUserDataService');
const { getSettingsByUser } = require('../services/generalSettingService');
const { sendOTPMobile } = require('../helpers/twilioHelper');
const userRoles = require('../config/constants/userRoles');
const { sendOTPToUser } = require('../helpers/emailServices');
const responseMessages = require('../config/constants/reponseMessages');
const { generateJWTSign, decodeJWTSign } = require('../helpers/jwtHelper');
const mailConstants = require('../config/constants/mailOptions');
const reponseMessages = require('../config/constants/reponseMessages');
const { sendEmail } = require('../helpers/emailServices');
const { generateKeyPair, readPublicKey } = require('../helpers/cryptoHelper');
const logger = require('../logger');
const { decodeUser, formatDate } = require('../services/commonService');
const { createFolder, writeFile } = require('../utils/upload');
const { generateRandomPassword } = require('../utils/common');
const {
  demoMobileNumbers,
  demoEmails,
} = require('../config/constants/dummyUsers');

// Key-exchange
exports.keyExchange = asyncHandler(async (req, res) => {
  const { x_api_key: mobilePublicKey, s_api_key: deviceId } = req.headers;

  if (!mobilePublicKey || !deviceId) {
    return res.status(400).json({
      status: 400,
      message: 'Invalid or missing API keys',
    });
  }

  try {
    if (generateKeyPair()) {
      // Store client's public key with device ID
      const serverPublicKey = readPublicKey().replace(/\n/g, '|');
      const isKeyStored = await storePublicKey({
        deviceId,
        clientPublicKey: mobilePublicKey,
      });

      if (isKeyStored && !isKeyStored.error) {
        return res.status(200).json({
          status: 200,
          data: {
            encrypted_public_key: serverPublicKey, // Encrypted Public Key
          },
          publicKey: mobilePublicKey,
        });
      }
    }
  } catch (error) {
    console.error('Error during key exchange:', error);
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Signup
exports.signup = asyncHandler(async (req, res) => {
  const {
    country_code: countryCode,
    mobile_number: mobileNumber,
    email,
    device_id: deviceId,
    device_token: deviceToken,
    sms_token: SMSToken,
  } = req.body;

  // Helper function to send a response
  const sendResponse = (status, message) =>
    res.status(status).json({ status, message });

  // Process mobile number signup
  if (countryCode && mobileNumber) {
    const formattedMobile = `${countryCode} ${mobileNumber}`;
    const isExistsDevice = await findUserByDevice({ deviceId });

    let existingPublicKey;
    isExistsDevice.forEach((device) => {
      if (device?.clientPublicKey) {
        existingPublicKey = device.clientPublicKey;
      }
    });

    if (isExistsDevice.length === 0 || !existingPublicKey) {
      return sendResponse(404, responseMessages.DEVICE_NOT_EXIST);
    }

    const isExistsUser = await findUserByMobile({ countryCode, mobileNumber });
    if (isExistsUser && isExistsUser?.isRegistered) {
      const isDeleteProcessPending = await getDeleteJobByUserId({
        userId: isExistsUser._id,
      });
      if (isDeleteProcessPending) {
        return sendResponse(
          401,
          responseMessages.ACCOUNT_DELETE_PROCESS_PENDING
        );
      }

      if (!isExistsUser.isActive && !isExistsUser.isDeleted) {
        return sendResponse(400, responseMessages.ACCOUNT_NOT_ACTIVE);
      }

      if (isExistsUser.isActive) {
        return sendResponse(404, responseMessages.ACCOUNT_MULTIPLE_DEVICE);
      }
    }

    let savedUser;
    const userActivationData = {
      deviceToken,
      SMSToken,
      countryCode,
      mobileNumber,
    };

    if (!isExistsUser?.isActive) {
      if (isExistsUser?.deviceId === deviceId && isExistsUser?.isDeleted) {
        savedUser = await activateUserAccount(userActivationData);
      } else if (
        isExistsUser?.deviceId !== deviceId &&
        isExistsUser?.isDeleted
      ) {
        savedUser = await activateUserAccount({
          ...userActivationData,
          deviceId,
          clientPublicKey: existingPublicKey,
          deleteOtherEntries: true,
        });
      } else {
        savedUser = await signupFrontendUser({
          ...userActivationData,
          deviceId,
          clientPublicKey: existingPublicKey,
          isActive: true,
        });
      }

      if (savedUser?.error || savedUser === false) {
        return sendResponse(400, responseMessages.ACCOUNT_CREATION_FAIL);
      }

      const isSentOTP = demoMobileNumbers.includes(formattedMobile)
        ? true
        : await sendOTPMobile(savedUser, { SMSToken });

      // if (isSentOTP) {
      //   return sendResponse(200, responseMessages.OTP_SENT_MOBILE);
      // }
      if (isSentOTP) {
        try {
          const payload = JSON.stringify({
            country_code: countryCode,
            mobile_number: mobileNumber,
            device_id: deviceId,
          });
          await makeBlockchainRequest(
            '/v1/user/register',
            'POST',
            {},
            {},
            payload
          );
          return sendResponse(200, responseMessages.OTP_SENT_MOBILE);
        } catch (error) {
          if (error.response?.status === 409) {
            return sendResponse(200, responseMessages.OTP_SENT_MOBILE);
          }
          return sendResponse(
            400,
            responseMessages.SOMETHING_WENT_WRONG_BLOCKCHAIN
          );
        }
      }
      return sendResponse(400, responseMessages.OTP_NOT_SENT_MOBILE);
    }

    if (isExistsUser?.isActive && !isExistsUser?.isRegistered) {
      savedUser = await activateUserAccount({
        ...userActivationData,
        deviceId,
        clientPublicKey: existingPublicKey,
        deleteOtherEntries: true,
      });

      if (savedUser?.error || savedUser === false) {
        return sendResponse(400, responseMessages.ACCOUNT_CREATION_FAIL);
      }

      const isSentOTP = demoMobileNumbers.includes(formattedMobile)
        ? true
        : await sendOTPMobile(savedUser, { SMSToken });
      if (isSentOTP) {
        try {
          const payload = JSON.stringify({
            country_code: countryCode,
            mobile_number: mobileNumber,
            device_id: deviceId,
          });
          await makeBlockchainRequest(
            '/v1/user/register',
            'POST',
            {},
            {},
            payload
          );
          return sendResponse(200, responseMessages.OTP_SENT_MOBILE);
        } catch (error) {
          if (error.response?.status === 409) {
            return sendResponse(200, responseMessages.OTP_SENT_MOBILE);
          }
          return sendResponse(
            400,
            responseMessages.SOMETHING_WENT_WRONG_BLOCKCHAIN
          );
        }
      }
      return sendResponse(400, responseMessages.OTP_NOT_SENT_MOBILE);
    }
  }

  // Process email signup
  if (email) {
    let user = await findUserByEmail(email);
    if (user?.isActive && user?.isEmailVerified) {
      return sendResponse(409, responseMessages.ACCOUNT_EXIST);
    }

    if (!user) {
      user = await createUser({
        email,
        userType: userRoles.ORGANIZATION_ADMIN,
      });
      if (user?.error) {
        return sendResponse(500, responseMessages.ACCOUNT_CREATION_FAIL);
      }
    }

    const token = generateJWTSign(
      { email: user.email, purpose: 'organization-registration' },
      '1d'
    );
    const newRegistrationLink = `${process.env.ORG_FRONT_URL}/set-password?token=${token}`;
    const mailOptions = {
      to: email,
      type: mailConstants.MAIL_TYPES.ORGANIZATION_REGISTRATION_MAIL,
      userData: user,
      templateVars: {
        link: newRegistrationLink,
        logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
      },
    };

    const mailSent = demoEmails.includes(email)
      ? true
      : await sendEmail(mailOptions);
    if (mailSent) {
      await updateNewRegistrationToken(user._id, { token });
      return sendResponse(
        200,
        user
          ? responseMessages.ORGANIZATION_REGISTRATION_LINK_RESENT
          : responseMessages.ORGANIZATION_REGISTRATION_LINK_SENT
      );
    }
  }

  return sendResponse(400, responseMessages.SOMETHING_WENT_WRONG);
});

// Login
exports.login = asyncHandler(async (req, res) => {
  const {
    email,
    password,
    country_code: countryCode,
    mobile_number: mobileNumber,
    role_type: roleType,
    device_token: deviceToken,
    sms_token: SMSToken,
    device_id: deviceId,
  } = req.body;
  // Super Admin
  if (email && email !== '') {
    // Verify if user exists
    const user = await findUserByEmail(email);
    if (
      !user?.email ||
      user?.isDeleted ||
      (!user.isActive && user.userType !== userRoles.ORGANIZATION_ADMIN)
    ) {
      return res.status(404).json({
        status: 404,
        message: user?.isDeletedByAdmin
          ? responseMessages.ADMIN_DELETED_ACCOUNT
          : responseMessages.USER_NOT_EXIST,
      });
    }

    if (
      user?.userType === userRoles.ORGANIZATION_ADMIN &&
      (!user?.isActive || !user?.isEmailVerified)
    ) {
      // Generate new registration token
      const token = generateJWTSign(
        {
          email: user.email,
          purpose: 'organization-registration',
        },
        '1d'
      );
      // Generate new registration link
      const newRegistrationLink = `${process.env.ORG_FRONT_URL}/set-password?token=${token}`;
      logger.info(`New Organization token: ${token}`);
      // Send new registration link to the provided email
      const mailOptions = {
        to: email,
        type: mailConstants.MAIL_TYPES.ORGANIZATION_REGISTRATION_MAIL,
        userData: user,
        templateVars: {
          link: newRegistrationLink,
          logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
        },
      };
      const mailSent = demoEmails.includes(email)
        ? true
        : await sendEmail(mailOptions);
      if (mailSent) {
        // Save new registration link to the database
        await updateNewRegistrationToken(user._id, {
          token,
        });
        return res.status(200).json({
          status: 200,
          data: {
            isEmailVerified: false,
          },
          message: responseMessages.ORGANIZATION_REGISTRATION_LINK_RESENT,
        });
      }
    }

    // Get User Role
    const userRole = await getUserRoleName(user);
    if (
      user?.userType !== userRoles.FRONT_END_USER &&
      user?.userType !== roleType &&
      !(
        (roleType === userRoles.SUPER_ADMIN &&
          userRole === userRoles.SUB_ADMIN) ||
        (roleType === userRoles.ORGANIZATION_ADMIN && (await isOrgAdmin(user)))
      )
    ) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.UNAUTHORIZED_ACCESS_WRONG_URL,
      });
    }

    if (roleType === userRoles.SUPER_ADMIN && (await isOrgAdmin(user))) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.UNAUTHORIZED_ACCESS_WRONG_URL,
      });
    }

    // Verify if password is correct
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.INVALID_EMAIL_PASSWORD,
      });
    }
    let isSentOTP;
    const { isPasswordReset } = user;
    if (isPasswordReset) {
      isSentOTP = await sendOTPToUser(user);
    }
    if ((isSentOTP && !isSentOTP?.error) || !isPasswordReset) {
      const data =
        userRole === userRoles.SUB_ADMIN
          ? { is_password_reset: !!isPasswordReset }
          : {};
      return res.status(200).json({
        status: 200,
        message: isPasswordReset ? responseMessages.OTP_SENT_MAIL : '',
        data,
      });
    }
  } else {
    const formattedMobile = `${countryCode} ${mobileNumber}`;
    const user = await findUserByMobile({ countryCode, mobileNumber });
    if (!user) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.SIGNUP_FIRST,
      });
    }

    // Verify delete process pending
    const isDeleteProcessPending = await getDeleteJobByUserId({
      userId: user._id,
    });
    if (isDeleteProcessPending) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.ACCOUNT_DELETE_PROCESS_PENDING,
      });
    }

    if (!user?.isRegistered || (!user?.isActive && user?.isDeleted)) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.SIGNUP_FIRST,
      });
    }

    // Verify if user exists
    if (!user?.isActive && !user?.isDeleted) {
      return res.status(401).json({
        status: 401,
        message: responseMessages.USER_NOT_AVAILABLE,
      });
    }

    // Compare device-id and update the user's public-key and device-id
    if (user?.deviceId !== deviceId) {
      // Remove the existing entry with new device id and update the existing user account with new device id, device token and public key
      const isExistsDevice = await findUser({
        deviceId,
        countryCode: { $exists: false },
        mobileNumber: { $exists: false },
      });
      if (
        Array.isArray(isExistsDevice) &&
        isExistsDevice.length === 1 &&
        isExistsDevice[0]?.clientPublicKey
      ) {
        const updatedUser = await activateUserAccount({
          deviceId,
          SMSToken,
          countryCode,
          mobileNumber,
          clientPublicKey: isExistsDevice[0]?.clientPublicKey,
          deleteOtherEntries: true,
        });
        if (updatedUser?.error || updatedUser === false) {
          return res.status(400).json({
            status: 400,
            message: responseMessages.SOMETHING_WENT_WRONG,
          });
        }
      } else {
        return res.status(400).json({
          status: 400,
          message: responseMessages.DEVICE_NOT_EXIST,
        });
      }
    }
    // Send OTP to Mobile Number
    const isSentOTP = demoMobileNumbers.includes(formattedMobile)
      ? true
      : await sendOTPMobile(user, {
          SMSToken,
        });
    if (!isSentOTP) {
      return res.status(400).json({
        status: 400,
        message: reponseMessages.OTP_NOT_SENT_MOBILE,
      });
    }

    // Save device token to the database
    await updateDeviceToken(user._id, {
      token: deviceToken,
      SMSToken,
    });

    return res.status(200).json({
      status: 200,
      message: `${responseMessages.OTP_SENT_MOBILE}`,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Forgot Password
exports.forgotPassword = asyncHandler(async (req, res) => {
  const { email, role_type: roleType } = req.body;

  // Verify if user exists
  const user = await findUserByEmail(email);

  if (!user) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.USER_NOT_EXIST,
    });
  }

  // Get User Role
  const userRole = await getUserRoleName(user);
  if (
    user?.userType !== userRoles.FRONT_END_USER &&
    user?.userType !== roleType
  ) {
    if (
      !(roleType === userRoles.SUPER_ADMIN && userRole === userRoles.SUB_ADMIN)
    ) {
      return res.status(404).json({
        status: 404,
        message: responseMessages.UNAUTHORIZED_ACCESS_WRONG_URL,
      });
    }
  }

  const linkType =
    userRole === userRoles.SUPER_ADMIN || userRole === userRoles.SUB_ADMIN
      ? 'administrator'
      : 'organization';

  const urlType =
    linkType === 'administrator'
      ? process.env.ADMIN_FRONT_URL
      : process.env.ORG_FRONT_URL;

  if (!user?.isActive) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.USER_NOT_EXIST,
    });
  }

  // Generate password reset token
  const token = generateJWTSign(
    {
      email: user.email,
      purpose: 'reset-password',
    },
    '1d'
  );
  logger.info(`Password Reset token: ${token}`);
  const passwordResetLink = `${urlType}/change-password?token=${token}`;
  // Send password reset link to the provided email
  const mailOptions = {
    to: email,
    type: mailConstants.MAIL_TYPES.PASSWORD_RESET_LINK_MAIL,
    userData: user,
    templateVars: {
      link: passwordResetLink,
      logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
    },
  };
  const mailSent = await sendEmail(mailOptions);

  if (mailSent) {
    // Save password reset token to the database
    await updatePasswordResetToken(user._id, {
      token,
    });
    return res.status(200).json({
      status: 200,
      message: responseMessages.PASSWORD_RESET_LINK_SENT,
    });
  }

  return res.status(500).json({
    status: 500,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Reset Password
exports.resetPassword = asyncHandler(async (req, res) => {
  const { password } = req.body;
  const { token } = req.params;

  // Verify if token exists and not expired
  const decoded = await decodeJWTSign({ token });
  if (decoded.error) {
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }
  // Verify if the password reset token is the recently generated token
  const decodedUser = await decodeUser(decoded);
  if (decodedUser?.isPasswordReset) {
    const userToken = decodedUser?.resetPasswordToken || null;
    if (userToken !== token) {
      return res.status(404).json({
        status: 404,
        message: responseMessages.PASSWORD_RESET_TOKEN_EXPIRED,
      });
    }
  }
  // New password should not be the same as the old password
  if (decodedUser?.password) {
    const isNewPasswordSame = await decodedUser.comparePassword(password);
    if (isNewPasswordSame) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.OLD_NEW_PASSWORD_SAME,
      });
    }
  }

  // Update the password
  if (decodedUser?._id && (await updatePassword(decodedUser?._id, password))) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.PASSWORD_UPDATE_SUCCESS,
    });
  }
  return res.status(401).json({
    status: 401,
    message: responseMessages.PASSWORD_RESET_TOKEN_EXPIRED,
  });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (email && email !== '') {
    const user = await findUserByEmail(email);
    if (user._id && (await updatePassword(user._id, password))) {
      return res.status(200).json({
        status: 200,
        message: responseMessages.PASSWORD_UPDATE_SUCCESS,
      });
    }
  }

  return res.status(401).json({
    status: 401,
    message: responseMessages.UNAUTHORIZED_ACCESS,
  });
});

// Verify OTP (No need of userType as it is just OTP verification)
exports.verifyOTP = asyncHandler(async (req, res) => {
  const {
    email,
    otp,
    mobile_number: mobileNumber,
    country_code: countryCode,
    x_api_key: adminPublicKey,
  } = req.body;

  if (email && !adminPublicKey) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ADMIN_PUBLIC_KEY_MISSING,
    });
  }

  const user = email
    ? await findUserByEmail(email)
    : await findUserByMobile({ countryCode, mobileNumber });

  if (!user?.isActive) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.USER_NOT_EXIST,
    });
  }

  const statusCode = user.userType === userRoles.FRONT_END_USER ? 401 : 400;

  const isDemoNumber = demoMobileNumbers.includes(
    `${countryCode} ${mobileNumber}`
  );

  if (!isDemoNumber && (!user.otp || !user.otpExpiration)) {
    return res.status(statusCode).json({
      status: statusCode,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }

  const isDemoEmail = demoEmails.includes(email);

  if (
    isDemoNumber ||
    isDemoEmail ||
    (user.otpExpiration > new Date() && user.otp === parseInt(otp, 10))
  ) {
    const generalSetting = await getSettingsByUser(null, 'settings');
    const expirationTime =
      user.userType === userRoles.FRONT_END_USER
        ? generalSetting?.settings?.token_expiration_time || '1d'
        : '1d';

    const payload =
      user.userType === userRoles.FRONT_END_USER
        ? {
            countryCode: user.countryCode,
            mobileNumber: user.mobileNumber,
          }
        : {
            email: user.email,
          };

    const token = generateJWTSign(payload, expirationTime);
    const role = await getUserRoleName(user);
    const permissions = await getPermissionsList(user, role);

    if (adminPublicKey) {
      if (generateKeyPair()) {
        const serverPublicKey = readPublicKey().replace(/\n/g, '|');
        const isKeyStored = await storePublicKey({
          userType: 'admin',
          email,
          clientPublicKey: adminPublicKey,
        });

        if (isKeyStored && !isKeyStored.error) {
          return res.status(200).json({
            status: 200,
            data: {
              token,
              ...(user.userType !== userRoles.FRONT_END_USER
                ? { userType: user.userType, role, permissions }
                : null),
              encrypted_public_key: serverPublicKey,
            },
            publicKey: adminPublicKey,
          });
        }
      }
    }

    // Register user account
    if (user.userType === userRoles.FRONT_END_USER && !user?.isRegistered) {
      await registerUserAccount(user._id);
    }

    return res.status(200).json({
      status: 200,
      data: {
        token,
        ...(user.userType !== userRoles.FRONT_END_USER
          ? { userType: user.userType, role, permissions }
          : null),
      },
    });
  }

  return res.status(statusCode).json({
    status: statusCode,
    message: responseMessages.OTP_INVALID,
  });
});

// Resend OTP (Need of userType as need to send OTP differently)
exports.resendOTP = asyncHandler(async (req, res) => {
  const {
    email,
    mobile_number: mobileNumber,
    country_code: countryCode,
  } = req.body;

  let user;
  if (email) {
    // Verify if user exists by email
    user = await findUserByEmail(email);
  } else if (mobileNumber && countryCode) {
    // Verify if user exists by mobile number and country code
    user = await findUserByMobile({ countryCode, mobileNumber });
  }

  if (!user?.isActive) {
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }

  const isSentOTP = email
    ? await sendOTPToUser(user) // Send OTP to email
    : await sendOTPMobile(user); // Send OTP to mobile

  if (isSentOTP) {
    return res.status(200).json({
      status: 200,
      message: email
        ? responseMessages.OTP_SENT_MAIL
        : responseMessages.OTP_SENT_MOBILE,
    });
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Delete Profile Picture
exports.deleteProfilePicture = asyncHandler(async (req, res) => {
  if (req.user.profileImage) {
    const isDeleted = await deleteProfilePicture(req);
    if (isDeleted) {
      return res.status(200).json({
        status: 200,
        message: responseMessages.PROFILE_PIC_DEL_SUCCESS,
      });
    }
    return res.status(500).json({
      status: 500,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.PROFILE_PIC_NOT_FOUND,
  });
});

// Upload Profile Picture
exports.uploadProfilePicture = asyncHandler(async (req, res) => {
  if (!req.fileUploaded) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.PROFILE_PIC_MISSING,
    });
  }
  if (req.fileUploadError) {
    return res.status(400).json({
      status: 400,
      message: req.fileUploadError,
    });
  }
  if (req.file) {
    // Remove old profile image first
    const isDeleted = await deleteProfilePicture(req);
    if (isDeleted) {
      // Save Profile Picture into database only for admins
      if (req.user.userType !== userRoles.FRONT_END_USER) {
        const profileUpdated = await updateProfilePicture(
          req.user._id,
          req.file.filename
        );
        if (profileUpdated) {
          return res.status(200).json({
            status: 200,
            data: {
              profilePicture: generateProfilePictureURL(req.file.filename),
              // profilePicture: await generateProfileImageFromS3(
              //   req.user._id,
              //   req.file.filename
              // ),
            },
            message: responseMessages.PROFILE_PIC_UPLOAD_SUCCESS,
          });
        }
      }
    } else {
      // Remove new uploaded image from the uploads and do not update in the database
      return res.status(400).json({
        status: 400,
        message: responseMessages.PROFILE_PIC_UPLOAD_ERROR,
      });
    }
  }
  return res.status(500).json({
    status: 500,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Get Profile Picture URL
exports.getProfilePicture = asyncHandler(async (req, res) => {
  if (req.user && req.user.userType !== userRoles.FRONT_END_USER) {
    const profileImageURL = generateProfilePictureURL(req.user.profileImage);
    // const profileImageURL = await generateProfileImageFromS3(
    //   req.user._id,
    //   req.user.profileImage
    // );
    return res.json({
      status: 200,
      data: {
        profilePicture: profileImageURL,
      },
    });
  }
  return res.status(500).json({
    status: 500,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

const formatGetProfileResponse = async (user) => {
  let organizationData = {};
  let subOrganizationName = '';
  let parentOrgCountry = '';
  const userRole = await getUserRole(user);
  const roleName = await getUserRoleName(user);
  const permissions = await getPermissionsList(user, roleName);
  const userId = user.userType !== userRoles.SUPER_ADMIN ? user._id : null;
  const userSetting = await getSettingsByUser(userId, 'settings');
  const userTimezone = userSetting?.settings?.timezone || '';

  if (user?.organizationId) {
    const subOrganization = (
      await findOrganizationById(user.organizationId, 'name contactNumbers')
    )?.[0];

    if (subOrganization) {
      subOrganizationName = subOrganization.name ?? '';
      parentOrgCountry = subOrganization?.contactNumbers
        ? subOrganization?.contactNumbers[0]
        : '';
    }
  }

  if (user.userType === userRoles.ORGANIZATION_ADMIN) {
    const organization = await findOrganizationById(user.id);
    const userData = await findUserById(user.id);
    if (organization && organization.length > 0) {
      const org = organization[0];

      const emails = [org.userId?.email, ...org.emails];
      const documents = org.documents
        ? await Promise.all(
            org.documents.map(async (item) => ({
              id: item._id,
              type: item.type,
              url: generateOrgDocURL(user._id, item.url),
            }))
          )
        : [];
      organizationData = {
        _id: org._id || null,
        is_authorized: userData?.isAuthorized || false,
        // is_trusted: org?.isTrusted || false,
        user_id: user.id || null,
        primary_email: org.userId?.email || null,
        registered_number: org.registeredNumber || null,
        date_of_incorporation: org.dateOfIncorporation
          ? formatDate(org.dateOfIncorporation)
          : null,
        name: org.name || null,
        type: org.type || null,
        office_address: org.address || null,
        description: org.description || null,
        website: org.website || null,
        legal_status: org.legalStatus || null,
        email_id: emails.length > 0 ? emails : null,
        contact_number: org.contactNumbers || null,
        // profile_picture:
        //   generateProfilePictureURL(userData.profileImage) || null,
        profile_picture: await generateProfileImageFromS3(
          user._id,
          userData.profileImage
        ),
        documents,
        QR_image: org.QRImage || null,
        linkedin: user?.linkedin || null,
        twitter: user?.twitter || null,
        timezone: userTimezone,
        role: userRole,
        policy_id: org?.policyId || null,
        sub_rule_ids: org?.policySubRules || [],
        permissions,
      };
    }
  }

  let responseData;
  switch (user.userType) {
    case 'super-admin':
      responseData = {
        first_name: user?.firstName || null,
        last_name: user?.lastName || null,
        email: user.email,
        // profile_image: generateProfilePictureURL(user?.profileImage),
        profile_picture: await generateProfileImageFromS3(
          user._id,
          user.profileImage
        ),
        status: user?.isActive || null,
        timezone: userTimezone,
        role: userRole,
        permissions,
      };
      break;
    case 'organization-admin':
      responseData = organizationData;
      break;
    default:
      responseData = {
        org_name: subOrganizationName,
        org_country: parentOrgCountry,
        first_name: user?.firstName || null,
        last_name: user?.lastName || null,
        email: user.email,
        countryCode: user?.countryCode || null,
        mobileNumber: user?.mobileNumber || null,
        // profile_image: generateProfilePictureURL(user?.profileImage),
        profile_picture: await generateProfileImageFromS3(
          user._id,
          user.profileImage
        ),
        status: user?.isActive || null,
        timezone: userTimezone,
        role: userRole,
        permissions,
      };
      break;
  }
  return responseData;
};

// Get Profile
exports.getProfile = asyncHandler(async (req, res) => {
  if (req.user && req.user.userType === userRoles.FRONT_END_USER) {
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }
  const responseData = await formatGetProfileResponse(req.user);
  return res.json({
    // return res.jsonWithEncryption({
    status: 200,
    data: responseData,
  });
});

// Update Profile
exports.updateProfile = asyncHandler(async (req, res) => {
  const authToken =
    req.headers && (req.header('authorization') || req.header('token'));
  const { profile_picture: profilePicture } = req.body;

  if (req.user && req.user.userType === userRoles.FRONT_END_USER) {
    return res.status(401).json({
      status: 401,
      message: responseMessages.UNAUTHORIZED_ACCESS,
    });
  }
  // File upload validation error
  if (req.fileUploadError) {
    return res.status(400).json({
      status: 400,
      message: req.fileUploadError,
    });
  }
  // Remove Profile picture
  if (profilePicture === '' || profilePicture === null) {
    await deleteProfilePicture(req);
  }
  // Upload profile picture
  if (req.file) {
    // Remove old profile image first
    const isDeleted = await deleteProfilePicture(req);
    // this condition will change is future
    if (isDeleted || !isDeleted) {
      // Save Profile Picture into database only for admins
      if (req.user.userType !== userRoles.FRONT_END_USER) {
        await updateProfilePicture(req.user._id, req.file.filename);
      }
    } else {
      // Remove new uploaded image from the uploads
      // const filePathToDelete = path.join(
      //   fileUploads.PROFILE_PICTURE,
      //   req.file.filename
      // );
      // await deleteFile(filePathToDelete);
      await deleteS3File(req.user, req.file.filename);
    }
  }

  // Update profile
  let profileUpdated;

  if (req.user && req.user.userType === userRoles.ORGANIZATION_ADMIN) {
    if (req.body.registered_number) {
      const existingOrg = await getOrganizationByUserId(req.user._id);
      if (!existingOrg?.registeredNumber) {
        if (await isDuplicateRegisteredNumber(req.body.registered_number)) {
          return res.status(400).json({
            status: 400,
            message: `Another organization with same registered number "${req.body.registered_number}" already exists. Try another.`,
          });
        }
      }
    }

    profileUpdated = await updateOrganizationProfile(
      req.user._id,
      req.body,
      findUserById,
      findUser,
      updateSocialInfo
    );

    if (!profileUpdated?.error) {
      // Send Notification to Super-admin
      await sendNotification(
        {
          notification_to: 'SUPER-ADMIN',
          notification_type: 'ORGANIZATION_PROFILE_UPDATE',
          organization_name: profileUpdated.name,
        },
        authToken
      );
    }

    profileUpdated = req.user;
  } else {
    const { country_code: countryCode, mobile_number: mobileNumber } = req.body;
    if (countryCode && mobileNumber) {
      const isExistsUser = await findUserByMobile({
        countryCode,
        mobileNumber,
      });

      if (isExistsUser) {
        if (isExistsUser._id.toString() !== req.user._id.toString()) {
          return res.status(404).json({
            status: 404,
            message: responseMessages.USER_DUPLICATE_MOBILE,
          });
        }
      }
    }

    profileUpdated = await updateUserProfile(req.user._id, req.body);
  }

  if (!profileUpdated?.error) {
    const responseData = await formatGetProfileResponse(profileUpdated);
    const message =
      req.user.userType === userRoles.ORGANIZATION_ADMIN
        ? responseMessages.ORG_PROFILE_UPDATE_SUCCESS
        : responseMessages.PROFILE_UPDATE_SUCCESS;

    return res.status(200).json({
      status: 200,
      message,
      data: responseData,
    });
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// List admins
exports.getAdmins = asyncHandler(async (req, res) => {
  const {
    sort_by: sortBy,
    order_by: orderBy,
    search,
    role,
    mobile_user: isMobileUser,
  } = req.query;
  const userType = isMobileUser ? userRoles.FRONT_END_USER : null;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;

  const skip = (page - 1) * limit;

  let parsedCountryCode = null;
  let parsedMobileNumber = null;

  // Check if the search input matches the pattern "+<countryCode> <mobileNumber>"
  if (search && /^\+\d+\s+\d+$/.test(search)) {
    const [code, number] = search.split(/\s+/); // Split by space
    parsedCountryCode = code.replace('+', ''); // Remove "+" from the country code
    parsedMobileNumber = number;
  }

  const { adminList, pageInfo } = await getAdminList({
    where: {
      ...(!isMobileUser ? { createdBy: req.user._id } : {}),
      ...(isMobileUser
        ? {
            countryCode: { $exists: true, $ne: '' },
            mobileNumber: { $exists: true, $ne: '' },
          }
        : {}),
      userType,
      isDeleted: false,
      // eslint-disable-next-line no-nested-ternary
      ...(search && search !== ''
        ? parsedCountryCode && parsedMobileNumber
          ? {
              countryCode: parsedCountryCode,
              mobileNumber: parsedMobileNumber,
            }
          : {
              $or: [
                { firstName: { $regex: search, $options: 'i' } },
                { lastName: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } },
                { countryCode: { $regex: search, $options: 'i' } },
                { mobileNumber: { $regex: search, $options: 'i' } },
              ],
            }
        : null),
      ...(role && role !== '' ? { role: new Types.ObjectId(role) } : null),
    },
    selectString: '-createdBy -__v',
    skip,
    limit,
    sortBy,
    orderBy,
  });

  const responseData = adminList?.length
    ? adminList.map((listItem) => formatResponseDocument(listItem))
    : [];
  if (adminList && !adminList.error) {
    return res.status(200).json({
      status: 200,
      data: {
        admin_list: responseData,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Create admin
exports.createAdmin = asyncHandler(async (req, res) => {
  const authToken =
    req.headers && (req.header('authorization') || req.header('token'));
  const {
    first_name: firstName,
    last_name: lastName,
    email,
    status,
    role,
  } = req.body;
  const user = await findUserByEmail(email);
  const roleExists = await findOneRole({
    roleId: role,
    userId: req.user._id,
  });
  // Verify if the role exists
  if (!roleExists) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ROLES_NOT_FOUND,
    });
  }
  // Verify if the account with the provided email already exists
  if (user?.email) {
    return res.status(409).json({
      status: 409,
      message: responseMessages.ADMIN_EXISTS,
    });
  }
  const newPassword = generateRandomPassword();
  // Get user type of loggedIn user
  let adminUserType = null;
  if (req.user.userType && req.user.userType === userRoles.SUPER_ADMIN) {
    adminUserType = true;
  } else if (req.user.userType === userRoles.ORGANIZATION_ADMIN) {
    adminUserType = false;
  } else {
    adminUserType = req.user?.isAdminMember;
  }
  // Get organization of loggedIn user
  let organizationId;
  if (req.user.userType && req.user.userType === userRoles.SUPER_ADMIN) {
    organizationId = null;
  } else if (req.user.userType === userRoles.ORGANIZATION_ADMIN) {
    organizationId = req.user._id;
  } else {
    organizationId = req.user?.organizationId;
  }
  // Create a new admin
  const createdUser = await createUser({
    organizationId,
    firstName,
    lastName,
    email,
    password: newPassword,
    isActive: status,
    role,
    createdBy: req.user._id,
    // isAdminMember flag is created to track sub-admin is created by which type of admin user
    isAdminMember: adminUserType,
  });
  if (createdUser && !createdUser.error) {
    let loginLink = `${process.env.ADMIN_FRONT_URL}/login`;

    if (req.user.userType === userRoles.ORGANIZATION_ADMIN) {
      loginLink = `${process.env.ORG_FRONT_URL}/login`;
    }
    // Send mail with creds to the newly created admin
    const mailOptions = {
      to: email,
      type: mailConstants.MAIL_TYPES.ACCOUNT_CREATED_MAIL,
      userData: req?.user,
      templateVars: {
        email,
        password: newPassword,
        link: loginLink,
        logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
      },
    };

    const mailSent = await sendEmail(mailOptions);
    logger.info(`Admin is created and mail is sent: ${mailSent}`);

    // Send Notification to Super-admin
    await sendNotification(
      {
        notification_to: 'SUPER-ADMIN',
        notification_type: 'NEW_ADMIN_CREATION',
        creator_name: req?.user?.firstName || null,
        recipient_name: createdUser.firstName,
      },
      authToken
    );

    return res.status(201).json({
      status: 201,
      message: responseMessages.ADMIN_CREATED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// get admin
exports.getAdmin = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const adminUser = await findUserById(id);
  if (adminUser?.isDeleted) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ADMIN_NOT_FOUND,
    });
  }
  if (adminUser && !adminUser.error) {
    return res.status(200).json({
      status: 200,
      data: formatResponseDocument(adminUser),
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Update admin
exports.updateAdmin = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (req.mobile_user === undefined) {
    const roleExists = await findOneRole({
      roleId: req.body.role,
      userId: req.user._id,
    });
    // Verify if the role exists
    if (!roleExists) {
      return res.status(404).json({
        status: 404,
        message: responseMessages.ROLES_NOT_FOUND,
      });
    }
  }

  const updatedAdmin = await updateAdmin(id, req.body);
  if (!updatedAdmin?.error) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.ADMIN_UPDATED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Delete admin
exports.deleteAdmin = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const softDeleted = await deleteAdmin(id);
  if (softDeleted && !softDeleted.error) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.ADMIN_DELETED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

// Delete Account
exports.deleteAccount = asyncHandler(async (req, res) => {
  const userId = req.user._id;
  const { user: userData } = req;
  const { type } = req.params;

  const deletedAccount = await deleteUserData(userData, {
    deletionType: type,
  });

  if (!deletedAccount?.error) {
    if (deletedAccount === 'done') {
      // Remove all notification requests of user
      await removeAllNotification(userData, { userId });

      // List of all blocked orgs
      const blockedOrgs = await getBlockOrganizationOfUser(
        userId,
        '_id organizationId userId'
      );

      // Remove trusted organizations and users
      if (blockedOrgs.length > 0) {
        await Promise.all(
          blockedOrgs.map(async (blockedOrg) => {
            await Promise.all([
              removeBlockedOrganization(
                blockedOrg.organizationId.toString(),
                blockedOrg.userId.toString()
              ),
              removeBlockedUsers(
                blockedOrg.organizationId.toString(),
                blockedOrg.userId.toString()
              ),
            ]);
          })
        );
      }

      // Remove all blocked orgs of the user
      await deleteBlockAllOrganization(userId);

      return res.status(200).json({
        status: 200,
        message: responseMessages.CRON_ACCOUNT_DELETION_REQUEST,
      });
    }
    if (deletedAccount === 'pending') {
      return res.status(200).json({
        status: 200,
        message: responseMessages.CRON_ACCOUNT_DELETION_REQUEST,
        isCronService: true,
      });
    }
  }

  // If deletion failed or an error occurred
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.autoSyncUserData = asyncHandler(async (req, res) => {
  const { user: loggedInUserData } = req;
  const { shared_data: dataToUpdate, encryptedPayload } = req.body;
  console.log('dataToUpdate', dataToUpdate);

  /** Read the payload and only update the data which is sent in the payload.
   * Update only if the data is shared with the organization otherwise skip it.
   */
  if (dataToUpdate?.length === 0) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.PROFILE_UPDATE_SUCCESS,
    });
  }
  const trustedOrganizations =
    loggedInUserData?.trustedOrganizations &&
    Array.isArray(loggedInUserData.trustedOrganizations)
      ? loggedInUserData.trustedOrganizations
      : [];
  if (trustedOrganizations.length === 0) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.PROFILE_UPDATE_SUCCESS,
    });
  }

  /** Create a folder and file to store the auto-sync data */
  const folderCreated = await createFolder('/auto-sync');
  if (!folderCreated) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }

  /** Create a file and write user-data */
  const fileWritten = await writeFile(
    '/auto-sync',
    `${loggedInUserData?._id}.txt`,
    encryptedPayload,
    false
  );
  if (!fileWritten) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
  /** Create a new job to perform */
  const queueAdded = await addNewJobToQueue({
    userId: loggedInUserData?._id,
    type: 2,
  });
  if (queueAdded.error || queueAdded === false) {
    if (queueAdded === false) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.CRON_REQUEST_IN_PROGRESS,
      });
    }
    if (queueAdded.error === false) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.SOMETHING_WENT_WRONG,
      });
    }
  }
  logger.info(`New Job Added - ${queueAdded && JSON.stringify(queueAdded)}`);

  return res.status(200).json({
    status: 200,
    message: responseMessages.PROFILE_UPDATE_PENDING,
    isCronService: true,
  });
});

exports.cronHistoryList = asyncHandler(async (req, res) => {
  const { search } = req.query;

  const query = {};

  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;

  if (search && search !== '') {
    query.$or = [
      {
        'user_data.mobileNumber': {
          $regex: search,
          $options: 'i',
        },
      },
    ];
  }

  const eventPipeline = [
    {
      $lookup: {
        from: 'users',
        localField: 'userId',
        foreignField: '_id',
        as: 'user_data',
        pipeline: [
          {
            $project: {
              _id: 1,
              countryCode: 1,
              mobileNumber: 1,
              hubspotIds: 1,
              sharedData: 1,
              sharedDataTimestamp: 1,
              // You can include additional fields here if needed
            },
          },
        ],
      },
    },
    {
      $unwind: {
        path: '$user_data',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $match: query,
    },
    {
      $project: {
        mobileNumber: '$user_data.mobileNumber',
        countryCode: '$user_data.countryCode',
        hubspotIds: '$user_data.hubspotIds',
        sharedData: '$user_data.sharedDatae',
        sharedDataTimestamp: '$user_data.sharedDataTimestampe',
        _id: 1,
        userId: 1,
        status: 1,
        type: 1,
        isRunning: 1,
        isHubSpotSync: 1,
        hubSpotSyncUpdate: 1,
        rollBackHubspotIds: 1,
        rollBackHubspotStatus: 1,
        rollBackHubspotDBStatus: 1,
        isBlockChainSync: 1,
        blockChainTransId: 1,
        rollBackBlockchainStatus: 1,
        sharedDataBackup: 1,
        rollBackFinalStatus: 1,
        env: 1,
        priority: 1,
        logs: 1,
      },
    },
  ];

  const [cronHistory] = await Promise.all([
    getAllCronHistory(eventPipeline, skip, limit),
  ]);
  // console.log('cronHistory.......', cronHistory);
  // console.log('pageInfo......', cronHistory.pageInfo);

  const responseData = {
    data: cronHistory.data,
    pageInfo: cronHistory.pageInfo,
  };

  return res.status(200).json({
    status: 200,
    message: responseMessages.CRON_HISTORY_SUCCESS,
    data: responseData,
  });
});
