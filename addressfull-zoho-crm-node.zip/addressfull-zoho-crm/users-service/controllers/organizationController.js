const path = require('path');
const moment = require('moment-timezone');
const { mongoose } = require('mongoose');
const asyncHandler = require('../middleware/asyncHandler');
const fileUploadPaths = require('../config/constants/fileUploads');
const {
  getFileNameToUpload,
  getFileTypeBase64File,
} = require('../utils/upload');
const {
  getAllTrusted,
  getMyTrusted,
  getAllOrganization,
  saveDocument,
  removeDocument,
  removeDocumentPicture,
  removeS3Document,
  saveTrustedUsers,
  removeTrustedUsers,
  getAllConnectedUsers,
  getOrganizationByUserId,
  getOrganizationById,
  saveBlockedUsers,
  removeBlockedUsers,
} = require('../services/organizationService');
const {
  saveBlockedOrganizations,
  removeBlockedOrganization,
  removeTrustedOrganization,
  clearSharedData,
  findUserById,
  findUser,
} = require('../services/userService');
const {
  sendNotification,
  calculateReqSentCount,
  removeAllNotification,
} = require('../services/notificationService');
const {
  insertMultipleSmsRecords,
  getMessageLogs,
} = require('../services/bulkSmsHistoryService');
const {
  createBlockOrganization,
  getBlockOrganization,
  deleteBlockOrganization,
  getMyBlockedOrganizationList,
} = require('../services/blockOrganizationService');
const { generatePrivacyPolicy } = require('../services/privacyPolicyService');
const {
  generateProfileImageFromS3,
  generateOrgDocURL,
  createUser,
  findUserByEmail,
  findUserByMobile,
  removeProfilePicture,
  updateProfilePicture,
  updateNewRegistrationToken,
  deactivateUser,
  updateSocialInfo,
  saveTrustedOrganizations,
  updateBlockChainToken,
  updateUserConsent,
  deleteUserData,
} = require('../services/userService');
const {
  makeBlockchainApiCallWithRetry,
  makeLabels,
  revokedData,
} = require('../services/blockChainService');
const { deleteCRMRecord } = require('../services/crmSettingService');
const {
  formatDate,
  formatTimestamp,
  throwError,
  clearUserSharedData,
} = require('../services/commonService');
const responseMessages = require('../config/constants/reponseMessages');
const {
  create,
  update,
  deleteOne,
  findValidOrganization,
  findOrganizationByName,
  formatSharedData,
  findOrganizationById,
} = require('../services/organizationService');
const { updateCRMRecord } = require('../services/crmSettingService');
const { createHubspotAPIPayload } = require('../services/cronServices');
const userRoles = require('../config/constants/userRoles');
const { deleteFile, isFileExists } = require('../utils/upload');
const fileUploads = require('../config/constants/fileUploads');
const generalConfig = require('../config/constants/generalConfig');
const { generateJWTSign } = require('../helpers/jwtHelper');
const mailConstants = require('../config/constants/mailOptions');
const { sendEmail } = require('../helpers/emailServices');
const logger = require('../logger');
const {
  calculateNotificationCount,
} = require('../services/notificationService');
const requestStatus = require('../config/constants/requestStatus');

const AWSconfig = require('../config/AWSConfig');
const {
  createFolder,
  uploadImage,
  uploadImageFromLocal,
} = require('../helpers/S3BucketHelper');
const { sendTextMessage } = require('../helpers/twilioHelper');

exports.getTopTrustedOrganizationList = asyncHandler(async (req, res) => {
  const { search, id, lat: latitude, lon: longitude, miles } = req.query;
  const { user: loggedInUserData } = req;
  const { countryCode } = loggedInUserData;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;
  const loggedInuserData = await findUserById(req.user._id);

  const { organizationList, pageInfo } = await getAllTrusted({
    userId: req.user?._id,
    id,
    search,
    // is_trusted,
    countryCode,
    skip,
    limit,
    ...(latitude && longitude && miles
      ? {
          location: {
            type: 'Point',
            coordinates: [latitude, longitude],
          },
          miles,
        }
      : null),
  });

  const responseData = organizationList?.length
    ? await Promise.all(
        organizationList.map(async (organization) => {
          const sharedData = loggedInuserData.sharedData.get(organization?._id);

          let sharedDataCount = 0;
          if (Array.isArray(sharedData) && sharedData.length > 0) {
            sharedDataCount = sharedData.length;
          }

          return {
            id: organization?._id || null,
            // organization_profile_image:
            //   generateProfilePictureURL(organization.user?.profileImage) || null,
            organization_profile_image: await generateProfileImageFromS3(
              organization.user._id,
              organization.user.profileImage
            ),
            organization_name: organization.name || null,
            shared_data_count: sharedDataCount,
            privacy_policy: await generatePrivacyPolicy(organization),
            // QR_image: organization.QRImage || null,
          };
        })
      )
    : [];
  if (organizationList && !organizationList.error) {
    return res.status(200).json({
      status: 200,
      data: {
        organization_list: responseData,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  }
  return res.status(400).json({
    status: 400,
    data: responseMessages.SOMETHING_WENT_WRONG,
  });
});

async function getMyTrustedOrgs({
  search,
  trustedOrganizationIds,
  skip,
  limit,
}) {
  const filter = {
    ...(search && search !== ''
      ? { name: { $regex: new RegExp(search, 'i') } }
      : null),
    ...(trustedOrganizationIds.length > 0
      ? { _id: { $in: trustedOrganizationIds } }
      : null),
  };

  const options = {
    where: filter,
    selectString: '-__v',
    skip,
    limit,
  };

  return getMyTrusted(options);
}

exports.getMyTrustedOrganizationList = asyncHandler(async (req, res) => {
  try {
    let trustedOrganizationIds = req.user?.trustedOrganizations || [];
    const sharedCount = req.user?.sharedData.size || 0;
    let organizationList = [];
    let pageInfo = {
      totalCount: 0,
      totalPages: 0,
      currentPage: 1,
    };

    const { search, id, timezone } = req.query;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.page_size, 10) || 10;
    const skip = (page - 1) * limit;
    const loggedInuserData = await findUserById(req.user._id);

    // Calculate Request Count
    const notificationData = await calculateNotificationCount(req.user, {
      userId: req.user._id,
      countType: 'COUNT',
      requestType: 'REQUEST',
      requestStatus: [requestStatus.SENT],
      isRead: false,
    });

    const requestCount = notificationData?.data?.data || 0;

    if (id !== undefined) {
      trustedOrganizationIds = trustedOrganizationIds.includes(id) ? [id] : [];
    }

    if (trustedOrganizationIds.length > 0) {
      ({ organizationList, pageInfo } = await getMyTrustedOrgs({
        search,
        trustedOrganizationIds,
        skip,
        limit,
      }));
    }

    const responseData = await Promise.all(
      organizationList.map(async (organization) => {
        const { sharedData: sharedUserData, sharedDataTimestamp } =
          loggedInuserData;
        const sharedData = sharedUserData.get(organization?._id);
        const sharedDataTimeFormatted = formatTimestamp(
          sharedDataTimestamp.get(organization?._id),
          timezone
        );
        const sharedDataCount = Array.isArray(sharedData)
          ? sharedData.length
          : 0;

        return {
          id: organization.userId._id || null,
          organizationId: organization._id || null,
          organization_profile_image: await generateProfileImageFromS3(
            organization.userId._id,
            organization.userId.profileImage
          ),
          organization_name: organization.name || null,
          shared_data_count: sharedDataCount,
          ...formatSharedData(sharedData),
          shared_data_timestamp: sharedDataTimeFormatted,
          shared_actual_timestamp:
            sharedDataTimestamp.get(organization?._id) || null,
          privacy_policy: await generatePrivacyPolicy(organization),
        };
      })
    );

    responseData.sort(
      (a, b) =>
        new Date(b.shared_actual_timestamp) -
        new Date(a.shared_actual_timestamp)
    );

    return res.status(200).json({
      status: 200,
      data: {
        request_count: requestCount,
        shared_count: sharedCount,
        organization_list: responseData,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  } catch (err) {
    return res.status(400).json({
      status: 400,
      data: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.getMyBlockedOrganizationList = asyncHandler(async (req, res) => {
  const { user: loggedInUserData } = req;
  const { search, sort_by: sortBy, order_by: orderBy, timezone } = req.query;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;
  const { blockedOrganizationList, pageInfo } =
    await getMyBlockedOrganizationList({
      loggedInUserData,
      skip,
      limit,
      search,
      sortBy,
      orderBy,
    });
  const responseData = blockedOrganizationList?.length
    ? await Promise.all(
        blockedOrganizationList.map(async (organization) => {
          let blockTimeFormatted = moment(organization.createdAt);
          if (timezone) {
            blockTimeFormatted = blockTimeFormatted.tz(timezone);
          }
          blockTimeFormatted = blockTimeFormatted.format('DD-MM-YYYY, hh:mm A');

          const data = {
            organizationId: organization.organizationId || null,
            organization_name: organization?.organization?.name || '',
            organization_profile_image: await generateProfileImageFromS3(
              organization.organization_user._id,
              organization.organization_user.profileImage
            ),
            ...(loggedInUserData?.userType !== userRoles.FRONT_END_USER
              ? {
                  countryCode: organization.user.countryCode,
                  mobileNumber: organization.user.mobileNumber,
                }
              : null),
            block_reason: organization?.reasonForBlock || '',
            blocked_date_time: blockTimeFormatted || null,
          };
          return data;
        })
      )
    : [];

  if (blockedOrganizationList && !blockedOrganizationList.error) {
    return res.status(200).json({
      status: 200,
      data: {
        organization_list: responseData,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  }
  return res.status(400).json({
    status: 400,
    data: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getOrganizationList = asyncHandler(async (req, res) => {
  const { sort_by: sortBy, order_by: orderBy, search } = req.query;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;

  const { organizationList, pageInfo } = await getAllOrganization({
    where: {
      isDeleted: false,
      ...(search && search !== ''
        ? {
            // Search with regex and text index over name field
            name: {
              $regex: new RegExp(search, 'i'),
            },
          }
        : null),
    },
    selectString: '-__v',
    skip,
    limit,
    sortBy,
    orderBy,
  });
  const responseData = organizationList?.length
    ? await Promise.all(
        organizationList.map(async (organization) => {
          const user = await findUserById(organization.userId);
          const primaryEmail = user?.email || null;

          return {
            id: organization._id,
            created_by: organization.userId,
            // organization_profile_image:
            //   generateProfilePictureURL(organization.logoImage) || null,
            organization_profile_image: await generateProfileImageFromS3(
              user._id,
              user.profileImage
            ),
            organization_name: organization.name || null,
            is_authorized: user?.isAuthorized || false,
            // is_trusted: organization?.isTrusted || false,
            registered_number: organization.registeredNumber || null,
            date_of_incorporation: organization.dateOfIncorporation
              ? formatDate(organization.dateOfIncorporation)
              : null,
            name: organization.name || null,
            type: organization.type || null,
            office_address: organization.address || null,
            description: organization.description || null,
            website: organization.website || null,
            legal_status: organization.legalStatus || null,
            emails: [...organization.emails],
            contact_number: organization.contactNumbers || null,
            // profile_picture:
            //   generateProfilePictureURL(organization.logoImage) || null,
            profile_picture: await generateProfileImageFromS3(
              user._id,
              user.profileImage
            ),
            primary_email: primaryEmail,
            created_at: organization.createdAt,
            updated_at: organization.updatedAt,
            QR_image: organization.QRImage || null,
          };
        })
      )
    : [];

  // To resolve the promises and get the final result
  const resolvedData = await Promise.all(responseData);

  if (organizationList && !organizationList.error) {
    return res.status(200).json({
      status: 200,
      data: {
        organization_list: resolvedData,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  }
  return res.status(400).json({
    status: 200,
    data: responseMessages.SOMETHING_WENT_WRONG,
  });
});

const getOrganization = async (id) => {
  const organization = await findValidOrganization({ orgId: id });
  if (organization.length === 0) {
    throw new Error(responseMessages.ORG_NOT_FOUND);
  }
  return organization[0];
};

const getOrgPolicy = async (id) =>
  getOrganizationById(id, '_id policyId policySubRules contactNumbers');

const checkIfBlocked = async (orgId, userId) =>
  getBlockOrganization(orgId, userId);

const validateCountryCode = (contactCountryCode, loggedInCountryCode) => {
  const formattedContactCountryCode = contactCountryCode.replace('+', '');
  return formattedContactCountryCode === loggedInCountryCode;
};

const formatSharedDataTime = (sharedDataTimestamp, orgId, timezone) => {
  let sharedDataTime = moment(sharedDataTimestamp.get(orgId));
  if (timezone) {
    sharedDataTime = sharedDataTime.tz(timezone);
  }
  return sharedDataTime.format('DD/MM/YYYY, dddd, hh:mm A');
};

const generateResponseData = async (
  organization,
  orgPolicy,
  loggedInUserData,
  sharedUserData,
  sharedDataTimestamp,
  timezone
) => {
  const emails = [organization.user?.email, ...organization.emails];
  const privacy_policy = await generatePrivacyPolicy(orgPolicy);
  const sharedData = sharedUserData.get(organization._id) || [];
  const sharedDataCount = Array.isArray(sharedData) ? sharedData.length : 0;
  const sharedDataToOrganizations = formatSharedData(sharedData);
  const sharedDataTimeFormatted = formatSharedDataTime(
    sharedDataTimestamp,
    organization._id,
    timezone
  );

  return {
    id: organization.userId?._id,
    organizationId: organization._id,
    organization_profile_image: await generateProfileImageFromS3(
      organization.user._id,
      organization.user.profileImage
    ),
    organization_name: organization.name,
    organization_website: organization.website || null,
    email_id: emails || null,
    mobile_number: organization.contactNumbers || null,
    address: organization.address,
    is_trusted:
      Array.isArray(loggedInUserData.trustedOrganizations) &&
      loggedInUserData.trustedOrganizations.includes(organization._id),
    shared_data_count: sharedDataCount,
    ...sharedDataToOrganizations,
    shared_data_timestamp: sharedDataTimeFormatted,
    privacy_policy,
  };
};

exports.getOrganizationProfile = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { timezone } = req.query;
  const userId = req.user._id;

  try {
    const organization = await getOrganization(id);
    const orgPolicy = await getOrgPolicy(id);

    if (orgPolicy && (await checkIfBlocked(orgPolicy._id, userId))) {
      return res.status(404).json({
        status: 404,
        message: responseMessages.BLOCK_DATA_SHARE_ERROR,
      });
    }

    const loggedInUserData = await findUserById(userId);
    console.log('loggedInUserData');
    console.log(loggedInUserData);
    const contactCountryCode = (orgPolicy.contactNumbers?.[0] || '').split(
      '|'
    )[0];
    const loggedInCountryCode = loggedInUserData.countryCode.replace('+', '');

    if (!validateCountryCode(contactCountryCode, loggedInCountryCode)) {
      return res.status(404).json({
        status: 404,
        message: responseMessages.QR_CODE_INVALID_COUNTRY,
      });
    }

    const responseData = await generateResponseData(
      organization,
      orgPolicy,
      loggedInUserData,
      loggedInUserData.sharedData,
      loggedInUserData.sharedDataTimestamp,
      timezone
    );

    return res.json({ status: 200, data: responseData });
  } catch (error) {
    console.log(error);
    return res.status(404).json({ status: 404, message: error.message });
  }
});

const checkIfOrganizationNameExists = async (name) => {
  const organization = await findOrganizationByName(name);
  return organization && Object.keys(organization).length;
};

const checkIfOrganizationEmailExists = async (email) => {
  const user = await findUserByEmail(email);
  return user && Object.keys(user).length;
};

const createOrganizationUser = async (email, userId, linkedin, twitter) =>
  createUser({
    email,
    password: generalConfig.DEFAULT_PASSWORD,
    userType: userRoles.ORGANIZATION_ADMIN,
    createdBy: userId,
    isActive: true,
    linkedin: linkedin ?? null,
    twitter: twitter ?? null,
  });

const handleProfilePictureUpload = async (userId, profilePicture) => {
  if (!profilePicture) return null;

  const createFolderResult = await createFolder(AWSconfig.bucketName, userId);
  if (!createFolderResult.status) throw new Error('Failed to create folder');

  const [, fileExtension] = getFileTypeBase64File(profilePicture);
  const fileName = getFileNameToUpload('org-profile');
  const fileNameToUpload =
    (fileName || `org-profile_${Date.now()}`) + fileExtension;

  const uploadImageResult = await uploadImage(
    AWSconfig.bucketName,
    userId,
    fileNameToUpload,
    profilePicture
  );
  if (!uploadImageResult.status) throw new Error('Failed to upload image');

  await updateProfilePicture(userId, fileNameToUpload);
  return fileNameToUpload;
};

const createOrganizationProfile = async (data) =>
  create({
    registeredNumber: data.registeredNumber,
    dateOfIncorporation: data.dateOfIncorporation,
    name: data.name,
    type: data.type,
    address: data.address,
    description: data.description,
    website: data.website,
    legalStatus: data.legalStatus,
    emails: data.emails,
    contactNumbers: data.contactNumbers,
    userId: data.userId,
    policyId: data.policyId,
    policySubRules: data.policySubRules,
  });

const sendRegistrationEmail = async (email, organization) => {
  const token = generateJWTSign(
    { email, purpose: 'organization-registration' },
    '1d'
  );

  const registrationLink = `${process.env.ORG_FRONT_URL}/set-password?token=${token}&isAddedByAdmin=true`;

  const mailOptions = {
    to: email,
    type: mailConstants.MAIL_TYPES.ORGANIZATION_REGISTRATION_MAIL,
    userData: organization,
    templateVars: {
      link: registrationLink,
      logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
    },
  };

  const mailSent = await sendEmail(mailOptions);
  if (!mailSent) throw new Error('Failed to send registration email');

  await updateNewRegistrationToken(organization._id, { token });
};

exports.createOrganization = asyncHandler(async (req, res) => {
  try {
    const {
      registered_number: registeredNumber,
      date_of_incorporation: dateOfIncorporation,
      name,
      type,
      office_address: address,
      description,
      website,
      legal_status: legalStatus,
      email_id: emails,
      contact_number: contactNumbers,
      linkedin,
      twitter,
      profile_picture: profilePicture,
      policy_id: policyId,
      sub_rule_ids: policySubRules,
    } = req.body;

    // Validate file upload
    if (req.fileUploadError) {
      return res.status(400).json({
        status: 400,
        message: req.fileUploadError,
      });
    }

    // Check for existing organization by name
    const organizationExistsByName = await checkIfOrganizationNameExists(name);
    if (organizationExistsByName) {
      return res.status(409).json({
        status: 409,
        message: responseMessages.ORGANIZATION_NAME_EXISTS,
      });
    }

    // Check for existing organization by email
    const organizationExistsByEmail = await checkIfOrganizationEmailExists(
      emails[0]
    );
    if (organizationExistsByEmail) {
      return res.status(409).json({
        status: 409,
        message: responseMessages.ORGANIZATION_EMAIL_EXISTS,
      });
    }

    // Create user for the organization
    const createdUser = await createOrganizationUser(
      emails[0],
      req.user._id,
      linkedin,
      twitter
    );
    if (!createdUser || createdUser.error) {
      throw new Error('Error creating organization user');
    }

    // Handle profile picture upload
    const profilePictureFilename = await handleProfilePictureUpload(
      createdUser._id,
      profilePicture
    );

    // Create the organization
    const createdOrganization = await createOrganizationProfile({
      registeredNumber,
      dateOfIncorporation,
      name,
      type,
      address,
      description,
      website,
      legalStatus,
      emails: emails.slice(1),
      contactNumbers,
      userId: createdUser._id,
      policyId,
      policySubRules,
      profilePictureFilename,
    });

    if (createdOrganization?.error) {
      throw new Error(responseMessages.SOMETHING_WENT_WRONG);
    }

    // Send registration email and respond
    await sendRegistrationEmail(createdUser.email, createdOrganization);

    return res.status(201).json({
      status: 201,
      message: responseMessages.ORGANIZATION_CREATED,
    });
  } catch (error) {
    logger.error(`Error creating organization: ${error}`);
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.updateOrganization = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const {
    registered_number: registeredNumber,
    date_of_incorporation: dateOfIncorporation,
    name,
    type,
    office_address: address,
    description,
    website,
    legal_status: legalStatus,
    email_id: emails,
    contact_number: contactNumbers,
    profile_picture: profilePicture,
    is_authorized: authorizedStatus,
    // is_trusted: trustedStatus,
    linkedin,
    twitter,
    policy_id: policyId,
    sub_rule_ids: policySubRules,
  } = req.body;

  // File upload validation error
  if (req.fileUploadError) {
    return res.status(400).json({
      status: 400,
      message: req.fileUploadError,
    });
  }

  const superUser = await findUser({
    userType: userRoles.SUPER_ADMIN,
    isActive: true,
    isDeleted: false,
  });
  const organization = await findValidOrganization({ orgId: id });
  const sentMail = organization.length === 0 && authorizedStatus && superUser;

  const emailsValues = emails !== undefined ? emails : [];

  const updatedOrganization = await update(
    id,
    {
      registeredNumber,
      dateOfIncorporation,
      name,
      type,
      address,
      description,
      website,
      legalStatus,
      emails: emailsValues,
      contactNumbers,
      authorizedStatus,
      // trustedStatus,
      policyId,
      policySubRules,
    },
    findUserById
  );

  if (updatedOrganization === null) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ORGANIZATION_NOT_FOUND,
    });
  }

  if (updatedOrganization && !updatedOrganization.error) {
    const { userId } = updatedOrganization;

    // Update Social Info
    await updateSocialInfo(userId, {
      linkedin: linkedin !== undefined ? linkedin : null,
      twitter: twitter !== undefined ? twitter : null,
    });

    // Remove Profile picture
    if (profilePicture === '') {
      await removeProfilePicture(userId);
    }
    // Upload profile picture
    if (profilePicture) {
      // Remove old profile image first
      const isDeleted = await removeProfilePicture(userId);
      if (isDeleted) {
        // Upload organization user profile image in s3
        const createFolderResult = await createFolder(
          AWSconfig.bucketName,
          userId
        );

        if (createFolderResult.status) {
          const [, fileExtension] = getFileTypeBase64File(profilePicture);
          const fileName = getFileNameToUpload('org-profile');

          const fileNameToUpload = `${
            fileName || `org-profile_${Date.now()}`
          }${fileExtension}`;

          const uploadImageResult = await uploadImage(
            AWSconfig.bucketName,
            userId,
            fileNameToUpload,
            profilePicture
          );

          if (uploadImageResult.status) {
            req.file = {
              filename: fileNameToUpload,
            };
          }
        }

        // Save Profile Picture into database only for admins
        await updateProfilePicture(userId, req.file.filename);
      } else {
        // Remove new uploaded image from the uploads
        const filePathToDelete = path.join(
          fileUploads.PROFILE_PICTURE,
          req.file.filename
        );
        await deleteFile(filePathToDelete);
      }
    }

    if (sentMail) {
      console.log('Email sent to', emails[0]);
      // Send mail to the organization
      const mailOptionsOrganisation = {
        to: emails[0],
        type: mailConstants.MAIL_TYPES.PROFILE_APPROVAL_SUCCESS_NOTIFICATION,
        userData: superUser,
        templateVars: {
          link: `${process.env.ORG_FRONT_URL}/login`,
          organizationName: updatedOrganization.name,
        },
      };
      await sendEmail(mailOptionsOrganisation);
    }

    return res.status(200).json({
      status: 200,
      message: responseMessages.ORGANIZATION_UPDATED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.deleteOrganization = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const org = await getOrganizationById(id, 'trustedUsers');
  if (!org || org.error) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ORG_NOT_FOUND,
    });
  }

  if (org?.trustedUsers?.length > 0) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.ORG_WITH_USER_EXISTS,
    });
  }

  const deleteOrganization = await deleteOne(
    id,
    removeProfilePicture,
    deactivateUser,
    true
  );

  if (deleteOrganization.modifiedCount > 0) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.ORGANIZATION_DELETED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

const fetchUserAndEmails = async (userId) => {
  const user = await findUserById(userId);
  const primaryEmail = user?.email || null;
  return {
    user,
    primaryEmail,
    emails: [primaryEmail].concat(user?.emails || []),
  };
};

const fetchDocuments = async (documents, userId) => {
  if (!documents) return [];

  return Promise.all(
    documents.map(async (item) => ({
      id: item._id,
      type: item.type,
      url: generateOrgDocURL(userId, item.url),
    }))
  );
};

const fetchProfilePicture = async (user) => {
  if (!user.profileImage) return null;
  return generateProfileImageFromS3(user._id, user.profileImage);
};

const formatResponseData = (
  org,
  user,
  profilePicture,
  documents,
  primaryEmail,
  emails
) => ({
  _id: org._id || null,
  user_id: org.userId || null,
  primary_email: primaryEmail,
  is_authorized: user?.isAuthorized || false,
  registered_number: org.registeredNumber || null,
  date_of_incorporation: org.dateOfIncorporation
    ? formatDate(org.dateOfIncorporation)
    : null,
  name: org.name || null,
  type: org.type || null,
  office_address: org.address || null,
  description: org.description || null,
  website: org.website || null,
  legal_status: org.legalStatus || null,
  email_id: emails.length > 0 ? emails : null,
  contact_number: org.contactNumbers || null,
  profile_picture: profilePicture,
  documents,
  QR_image: org.QRImage || null,
  linkedin: user?.linkedin || null,
  twitter: user?.twitter || null,
  policy_id: org?.policyId || null,
  sub_rule_ids: org?.policySubRules || [],
});

const handleNotFound = (res) =>
  res.status(404).json({
    status: 404,
    message: responseMessages.ORG_NOT_FOUND,
  });

exports.fetchOrganizationById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const org = await getOrganizationById(id);

  if (org?.error) {
    return handleNotFound(res);
  }

  const { user, primaryEmail, emails } = await fetchUserAndEmails(org.userId);
  const documents = await fetchDocuments(org.documents, org.userId);
  const profilePicture = await fetchProfilePicture(user);

  const responseData = formatResponseData(
    org,
    user,
    profilePicture,
    documents,
    primaryEmail,
    emails
  );

  return res.json({
    status: 200,
    data: responseData,
  });
});

exports.organizationDocumentUpload = asyncHandler(async (req, res) => {
  try {
    const authToken =
      req.headers && (req.header('authorization') || req.header('token'));
    const { document_type: docType, id: orgId } = req.body;

    // File upload validation error
    if (req.fileUploadError) {
      throw new Error(req.fileUploadError);
    }

    const org = await getOrganizationById(orgId);
    if (req.file) {
      // Prepare to save document
      const documentData = {
        type: docType,
        url: req.file.filename,
      };

      // Forward uploaded Image to S3 Bucket from local
      const createFolderResult = await createFolder(
        AWSconfig.bucketName,
        `${org.userId}/documents`
      );

      if (!createFolderResult.status) {
        throw new Error(responseMessages.PROFILE_PIC_UPLOAD_ERROR);
      }

      const uploadImageResult = await uploadImageFromLocal(
        AWSconfig.bucketName,
        `${org.userId}/documents`,
        req.file.filename,
        `${fileUploadPaths.DOCUMENT_UPLOAD}/${req.file.filename}`
      );

      if (!uploadImageResult.status) {
        throw new Error(responseMessages.PROFILE_PIC_UPLOAD_ERROR);
      }

      // Save Profile Picture into database only for admins
      const document = await saveDocument(
        orgId,
        documentData,
        fileUploads.DOCUMENT_UPLOAD,
        isFileExists,
        deleteFile
      );

      if (document) {
        // Remove document from local after upload to s3
        const filteredDocs = document.documents.find(
          (doc) => doc.type === docType
        );

        if (filteredDocs) {
          await removeDocumentPicture(
            orgId,
            filteredDocs._id,
            fileUploads.DOCUMENT_UPLOAD,
            isFileExists,
            deleteFile
          );
        }

        if (req.user && req.user.userType === userRoles.ORGANIZATION_ADMIN) {
          const organizationName = org && !org?.error ? org.name : 'None';

          // Send Notification to Super-admin
          await sendNotification(
            {
              notification_to: 'SUPER-ADMIN',
              notification_type: 'ORGANIZATION_DOCUMENT_UPLOAD',
              organization_name: organizationName,
            },
            authToken
          );
        }

        return res.status(200).json({
          status: 200,
          message: responseMessages.ORGANIZATION_DOC_UPLOAD,
        });
      }
    }
  } catch (error) {
    return res.status(400).json({
      status: 400,
      message: error.message,
    });
  }
});

exports.organizationDocumentRemove = asyncHandler(async (req, res) => {
  const { org_id: orgId, doc_id: docId } = req.body;
  const org = await getOrganizationById(orgId, 'userId');
  // await removeDocumentPicture(
  //   orgId,
  //   docId,
  //   fileUploads.DOCUMENT_UPLOAD,
  //   isFileExists,
  //   deleteFile
  // );
  await removeS3Document(orgId, docId, org.userId);

  const updatedOrganization = await removeDocument(orgId, docId);
  if (updatedOrganization) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.ORGANIZATION_DOC_REMOVE,
    });
  }
  return res.status(404).json({
    status: 404,
    message: responseMessages.ORGANIZATION_DOC_REMOVE_ERR,
  });
});

exports.makeMyTrustedOrganization = asyncHandler(async (req, res) => {
  const { organization_id: organizationId } = req.body;
  const org = await getOrganizationById(organizationId);

  if (org && !org?.error) {
    const resultOrganization = await saveTrustedOrganizations(
      organizationId,
      req.user._id
    );
    const resultUser = await saveTrustedUsers(organizationId, req.user._id);

    if (resultOrganization && resultUser) {
      return res.status(200).json({
        status: 200,
        message: responseMessages.MY_TRUSTED_ORGANIZATION_SAVED,
      });
    }
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
  return res.status(404).json({
    status: 404,
    message: responseMessages.ORG_NOT_FOUND,
  });
});

exports.removeMyTrustedOrganization = asyncHandler(async (req, res) => {
  // const authToken =
  //   req.headers && (req.header('authorization') || req.header('token'));
  const { id: organizationId } = req.params;
  // Remove access of shared data from the CRM
  const revokeAccess = await deleteCRMRecord(req.user, { organizationId });
  logger.info(`CRM Data is removed: ${JSON.stringify(revokeAccess)}`);
  if (revokeAccess) {
    /** Make blockchain API request */
    let transactionStatus = false;
    const org = await getOrganizationById(organizationId, '_id userId name');
    const userData = await findUserById(req.user._id);
    const { countryCode, mobileNumber, blockChainToken } = userData;

    const sharedData = userData?.sharedData?.get(organizationId) || [];
    const requestDetailsString = sharedData.join(', ');

    if (sharedData.length > 0) {
      const transactionBunch = [
        {
          log_type: 'consent',
          permission_status: 'revoke',
          consent_requestor: org.name,
          version: 1,
          updated_parameter: [requestDetailsString],
          user_in_front: '',
          // messages: sharedData.map(
          //   (sharedLabel) => `Removed ${sharedLabel} with ${org.name}`
          // ),
          messages: [`Removed ${requestDetailsString} with ${org.name}`],
        },
      ];
      // console.log('transactionBunch...', transactionBunch);

      /** Make Blockchain API request */
      const startTime = new Date();
      logger.info(`Blockchain executed at: ${new Date()}`);
      logger.info(`Started Blockchain API Call`);
      const blockchainResult = await makeBlockchainApiCallWithRetry(
        transactionBunch,
        blockChainToken,
        {
          countryCode,
          mobileNumber,
          userId: req.user._id,
          updateBlockChainToken,
        }
      );
      logger.info(`Finished Blockchain API Call`);
      const endTime = new Date();
      const elapsedTime = endTime - startTime;
      logger.info(`Blockchain took ${elapsedTime} milliseconds`);
      transactionStatus = blockchainResult?.status;
      logger.info(
        `Blockchain transaction finished | Result: ${transactionStatus}`
      );
    } else {
      transactionStatus = true;
    }

    if (!transactionStatus) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.SOMETHING_WENT_WRONG_BLOCKCHAIN,
      });
    }

    /** Remove user's trusted organizations, shared-data, remove user from organization's connected users list */
    const userSharedDataCleared = await clearUserSharedData(userData, {
      organizationIds: [organizationId],
      deleteUser: false,
    });
    logger.info(
      `Cleared user data for trusted organization: ${organizationId} | Result: ${userSharedDataCleared}`
    );

    if (userSharedDataCleared) {
      await removeTrustedUsers(organizationId, req.user._id);
      // Notify Organization for untrusted by user
      // await sendNotification(
      //   {
      //     notification_to: 'ORGANIZATION-ADMIN',
      //     notification_type: 'USER_UNTRUSTED_TO_ORGANIZATION',
      //     organization_id: org.userId,
      //     organization_parent_id: org._id,
      //     sender_id: req.user._id,
      //   },
      //   authToken
      // );

      return res.status(200).json({
        status: 200,
        message: responseMessages.MY_TRUSTED_ORGANIZATION_REMOVED,
      });
    }
  }

  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getConnectedUsers = asyncHandler(async (req, res) => {
  const { search, sort_by: sortBy, order_by: orderBy } = req.query;
  const loggedInUser = req.user;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;
  const loggedInOrganizationId =
    loggedInUser.userType === userRoles.ORGANIZATION_ADMIN
      ? req.user?._id
      : req.user?.organizationId;
  const connectedUsers = await getAllConnectedUsers({
    // organizationId:
    //   req.user.userType === userRoles.ORGANIZATION_ADMIN
    //     ? req.user?._id
    //     : req.user?.organizationId,
    search,
    skip,
    limit,
    sortBy,
    orderBy,
  });
  if (!connectedUsers?.error) {
    const responseData = connectedUsers?.userList.length
      ? await Promise.all(
          connectedUsers?.userList.map(async (user) => {
            let isConnected = false;
            let isRequestSent = false;
            isConnected = user?.trustedOrganizations?.includes(
              loggedInOrganizationId.toString()
            );
            isRequestSent = await calculateReqSentCount(req.user, {
              userId: user?._id,
              organizationId: loggedInOrganizationId,
            });
            return {
              id: user?._id || null,
              country_code: user?.countryCode || null,
              mobile_number: user?.mobileNumber || null,
              isUserConnected: !!isConnected,
              isRequestSent: !!isRequestSent?.reqCount?.totalCount,
            };
          })
        )
      : [];
    return res.status(200).json({
      status: 200,
      data: {
        user_list: responseData,
        page_info: connectedUsers?.pageInfo,
      },
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getUserConsentCount = asyncHandler(async (req, res) => {
  const { search, sort_by: sortBy, order_by: orderBy } = req.query;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;

  const notificationData = await calculateNotificationCount(req.user, {
    reqType: 'CONSENT',
    reqStatus: [
      requestStatus.ACCEPT,
      requestStatus.REJECT,
      requestStatus.SHARE,
      requestStatus.UNSHARE,
    ],
    search,
    sortByField: sortBy,
    orderBy,
    skip,
    limit,
  });

  if (!notificationData?.error) {
    const response = notificationData?.data?.data;

    const formattedResponse = Array.isArray(response.data)
      ? await Promise.all(
          response.data.map(async (consent) => ({
            organization_name: consent?.organizationName || null,
            // organization_logo: generateProfilePictureURL(
            //   consent?.organizationLogo
            // ),
            organization_profile_image: await generateProfileImageFromS3(
              consent.userId,
              consent.organizationLogo
            ),
            country_code: consent?.countryCode || null,
            mobile_number: consent?.mobileNumber || null,
            count: consent?.count || 0,
          }))
        )
      : [];

    return res.json({
      status: 200,
      data: formattedResponse,
      pageInfo: response.pageInfo,
      totalSumCount: response.totalSumCount,
    });
  }
  return res.status(500).json({
    status: 500,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

const buildTransactionsArray = async (payloads) => {
  const transactions = [];
  const { orgName, orgId, labels, sharedData, removedData } = payloads;

  if (labels.length > 0) {
    let requestDetailsString = labels.join(', ');
    const addedData = `Shared ${requestDetailsString} with ${orgName}`;

    const organization = await getOrganizationById(orgId);
    const policy = await generatePrivacyPolicy(organization);

    transactions.push({
      log_type: 'consent',
      permission_status: 'share',
      consent_requestor: orgName,
      version: 1,
      updated_parameter: [requestDetailsString],
      user_in_front: '',
      messages: [addedData],
    });

    if (policy?.rule !== '') {
      transactions.push({
        log_type: 'consent',
        permission_status: 'policy',
        consent_requestor: orgName,
        version: 1,
        updated_parameter: [policy.rule],
        user_in_front: '',
        messages: [
          `Your data has been shared with ${orgName} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`,
        ],
      });
    }

    const sharedDataOrg = sharedData?.get(orgId);

    if (sharedDataOrg) {
      // removedData = removedLabels(sharedDataOrg, labels);
      if (removedData && Array.isArray(removedData) && removedData.length) {
        requestDetailsString = removedData.join(', ');

        transactions.push({
          log_type: 'consent',
          permission_status: 'revoke',
          consent_requestor: orgName,
          version: 1,
          updated_parameter: [requestDetailsString],
          user_in_front: '',
          // messages: removedData.map(
          //   (removedLabel) => `Removed ${removedLabel} with ${orgName}`
          // ),
          messages: [`Removed ${requestDetailsString} with ${orgName}`],
        });
      }
    }
    return { transactions, removedData };
  }

  const sharedDataOrg = sharedData?.get(orgId);
  if (sharedDataOrg) {
    // removedData = removedLabels(sharedDataOrg, labels);
    if (removedData && Array.isArray(removedData) && removedData.length) {
      const requestDetailsString = removedData.join(', ');

      transactions.push({
        log_type: 'consent',
        permission_status: 'revoke',
        consent_requestor: orgName,
        version: 1,
        updated_parameter: [requestDetailsString],
        user_in_front: '',
        // messages: removedData.map(
        //   (removedLabel) => `Removed ${removedLabel} with ${orgName}`
        // ),
        messages: [`Removed ${requestDetailsString} with ${orgName}`],
      });
    }
  }
  return { transactions, removedData };
};

exports.shareDataToOrganization = asyncHandler(async (req, res) => {
  try {
    const authToken = `Bearer ${req.user.token}`;
    const { userType, countryCode, mobileNumber, _id: userId } = req.user;
    const { organization_id, shared_data } = req.body;

    if (userType !== userRoles.FRONT_END_USER) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.BLOCKCHAIN_ACCESS_DENIED,
      });
    }

    const [resultObject, org] = await Promise.all([
      createHubspotAPIPayload({
        jobData: { userId },
        organizationId: organization_id,
        dataToUpdate: shared_data,
        dataFormatType: 'share-data',
      }),
      getOrganizationById(organization_id, '_id userId name'),
    ]);

    if (!org || org.error) {
      return res
        .status(404)
        .json({ status: 404, message: responseMessages.ORG_NOT_FOUND });
    }

    const {
      organization_id: organizationId,
      firstName,
      lastName,
      mobile_numbers: mobileNumbers,
      emails,
      address,
      social,
    } = resultObject.resultObject;

    const [updatedCRMRecord, userAccess] = await Promise.all([
      updateCRMRecord(req.user, resultObject.resultObject),
      findUserByMobile({ countryCode, mobileNumber }),
    ]);

    if (!updatedCRMRecord) {
      return res
        .status(400)
        .json({ status: 400, message: responseMessages.SOMETHING_WENT_WRONG });
    }
    logger.info(`CRM Data is updated: ${JSON.stringify(updatedCRMRecord)}`);

    if (!userAccess) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.BLOCKCHAIN_ACCESS_DENIED,
      });
    }

    const previousData = userAccess.sharedData.get(org._id) || [];
    const removedData = await revokedData(previousData, shared_data);

    const blockChainToken = userAccess.blockChainToken || null;
    const labelsPayload = {
      mobileNumbers,
      emails,
      address,
      social,
      firstName,
      lastName,
    };
    const labels = await makeLabels(labelsPayload);
    const result = await buildTransactionsArray({
      orgName: org.name,
      orgId: org._id,
      labels,
      sharedData: userAccess.sharedData,
      removedData,
    });

    if (result.transactions) {
      const startTime = Date.now();
      logger.info(`Started Blockchain API Call at: ${new Date()}`);
      const blockchainResult = await makeBlockchainApiCallWithRetry(
        result.transactions,
        blockChainToken,
        { countryCode, mobileNumber, userId, updateBlockChainToken }
      );

      // const blockchainResult = { status: true }; // Mocked for testing without blockchain call
      logger.info(
        `Finished Blockchain API Call in ${Date.now() - startTime} milliseconds`
      );

      if (blockchainResult?.status) {
        const finalData = [...new Set([...previousData, ...labels])];
        const filteredData = finalData.filter(
          (item) => !removedData.includes(item)
        );

        const [updatedLabels, resultOrganization, resultUser] =
          await Promise.all([
            updateUserConsent(req.user, {
              labels: filteredData,
              organizationId,
            }),
            saveTrustedOrganizations(organizationId, req.user._id),
            saveTrustedUsers(organizationId, req.user._id),
          ]);

        if (!updatedLabels || updatedLabels.error) {
          return res.status(400).json({
            status: 400,
            message: responseMessages.SOMETHING_WENT_WRONG,
          });
        }

        if (resultOrganization && resultUser && updatedLabels) {
          await sendNotification(
            {
              notification_to: 'ORGANIZATION-ADMIN',
              notification_type: 'USER_SHARED_DATA',
              organization_id: org.userId,
              organization_parent_id: org._id,
              sender_id: userId,
              label_name: labels.join(', '),
            },
            authToken
          );

          if (result.removedData.length > 0) {
            await sendNotification(
              {
                notification_to: 'ORGANIZATION-ADMIN',
                notification_type: 'USER_UNSHARED_DATA',
                organization_id: org.userId,
                organization_parent_id: org._id,
                sender_id: userId,
                label_name: result.removedData.join(', '),
              },
              authToken
            );
          }

          return res.status(200).json({
            status: 200,
            message: responseMessages.BLOCKCHAIN_TRANSACTION_CREATED,
          });
        }
      } else {
        return res.status(400).json({
          status: 400,
          message: responseMessages.BLOCKCHAIN_TRANSACTION_FAILED,
        });
      }
    }

    return res
      .status(500)
      .json({ status: 500, message: responseMessages.SOMETHING_WENT_WRONG });
  } catch (error) {
    logger.error(`Error in shareDataToOrganization: ${error.message}`);
    return res.status(error.statusCode || 500).json({
      status: error.statusCode || 500,
      message: error.message || responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.deleteAllMyTrustedOrganization = asyncHandler(async (req, res) => {
  const { user: userData } = req;
  const deletedUserData = await deleteUserData(userData, {
    deletionType: 'yes',
    removeOnlyDataFlag: true,
  });
  if (!deletedUserData?.error && deletedUserData === 'no_trusted') {
    return res.status(400).json({
      status: 400,
      message: responseMessages.NO_ANY_TRUSTED_ORGANIZATION,
    });
  }
  if (!deletedUserData?.error && deletedUserData === 'pending') {
    return res.status(200).json({
      status: 200,
      message: responseMessages.USER_DATA_DELETION_PENDING,
      isCronService: true,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.handleDataReqBulk = asyncHandler(async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const user = await findUserById(req.user._id);
    const organization = await getOrganizationByUserId(
      user.organizationId ?? user._id,
      '_id userId name policyId policySubRules contactNumbers'
    );

    if (!organization || organization.error) {
      throwError(404, responseMessages.ORG_NOT_FOUND);
    }

    const { mobile_numbers: mobileNumbers, singleItem } = req.body;
    if (singleItem === 'true' && mobileNumbers.length > 0) {
      let openReqPopup = false;
      const [countryCodeSingle, mobileNumberSingle] =
        mobileNumbers[0].split('|');
      const mobileUser = await findUserByMobile({
        countryCode: countryCodeSingle,
        mobileNumber: mobileNumberSingle,
      });

      if (mobileUser) {
        // Restrict another country to send request
        const contactCountryCode = (organization.contactNumbers?.[0] || '')
          .split('|')[0]
          ?.replace('+', '');
        const loggedInCountryCode = (mobileUser.countryCode || '').replace(
          '+',
          ''
        );
        if (contactCountryCode !== loggedInCountryCode) {
          throwError(404, responseMessages.DATA_REQUEST_INVALID_COUNTRY);
        }

        const isBlocked = await getBlockOrganization(
          organization._id,
          mobileUser._id
        );
        if (isBlocked) {
          throwError(400, responseMessages.BLOCK_REQUEST_SEND_ERROR);
        }
        openReqPopup = true;
      }

      // Send app download link to new user
      if (!mobileUser) {
        const sentMessage = await sendTextMessage({
          countryCode: countryCodeSingle,
          mobileNumber: mobileNumberSingle,
          messageBody: responseMessages.SEND_DOWNLOAD_LINK_MESSAGE.replace(
            'XYZ',
            organization.name
          ),
          SMSToken: user?.SMSToken,
        });

        if (!sentMessage) {
          throwError(400, responseMessages.EXCEL_FEW_REQ_FAIL);
        }
      }

      return res.status(200).json({
        status: 200,
        message: responseMessages.REQUEST_SENT,
        openReqPopup,
        userId: mobileUser?._id || null,
      });
    }

    if (singleItem === 'false' && mobileNumbers.length > 0) {
      const organizationId = organization._id;
      const smsRecords = mobileNumbers.map((number) => {
        const [countryCode, mobileNumber] = number.split('|');
        return {
          countryCode,
          mobileNumber,
          organizationId,
        };
      });

      const bulkRecordResult = await insertMultipleSmsRecords(
        session,
        smsRecords
      );

      if (bulkRecordResult) {
        await session.commitTransaction();
        session.endSession();

        return res.status(200).json({
          status: 200,
          message: responseMessages.EXCEL_REQ_SENT_SUCCESS,
        });
      }
      throwError(400, responseMessages.EXCEL_ALL_REQ_FAIL);
    }
    throwError(500, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    if (session.inTransaction()) {
      await session.abortTransaction();
    }
    session.endSession();

    const statusCode = error.statusCode || 500;
    const message = error.message || responseMessages.SOMETHING_WENT_WRONG;
    return res.status(statusCode).json({ status: statusCode, message });
  }
});

const executeBlockchainTransaction = async (
  logType,
  permissionStatus,
  consentRequestor,
  updatedParameter,
  message,
  blockChainToken,
  userDetails
) => {
  const startTime = new Date();
  logger.info(`Blockchain executed at: ${startTime}`);
  logger.info(`Started Blockchain API Call`);
  const blockchainResult = await makeBlockchainApiCallWithRetry(
    [
      {
        log_type: logType,
        permission_status: permissionStatus,
        consent_requestor: consentRequestor,
        version: 1,
        updated_parameter: updatedParameter,
        user_in_front: '',
        messages: [message],
      },
    ],
    blockChainToken,
    userDetails
  );
  logger.info(`Finished Blockchain API Call`);
  const endTime = new Date();
  const elapsedTime = endTime - startTime;
  logger.info(`Blockchain took ${elapsedTime} milliseconds`);
  logger.info(
    `Blockchain transaction finished | Result: ${blockchainResult.status}`
  );

  return blockchainResult;
};

exports.blockUnblockOrganization = asyncHandler(async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const authToken =
      req.headers && (req.header('authorization') || req.header('token'));
    const { countryCode, mobileNumber, _id: userId } = req.user;
    const {
      organization_id: organizationId,
      block_status: blockStatus,
      reason_for_block: reasonForBlock,
    } = req.body;

    const org = await getOrganizationById(organizationId);
    if (!org || org.error) {
      throwError(404, responseMessages.ORG_NOT_FOUND);
    }

    // Get user access
    const userAccess = await findUserByMobile({ countryCode, mobileNumber });
    const blockChainToken = userAccess?.blockChainToken || null;
    if (!userAccess) {
      throwError(400, responseMessages.BLOCKCHAIN_ACCESS_DENIED);
    }

    const isOrgBlocked = await getBlockOrganization(organizationId, userId);
    if (blockStatus) {
      if (isOrgBlocked) {
        throwError(400, responseMessages.BLOCK_ORG_EXISTS);
      }

      /** Store Blockchain transaction for block */
      const blockchainResult = await executeBlockchainTransaction(
        'consent',
        'block',
        org.name,
        ['Blocked'],
        `You have blocked ${org.name} organisation`,
        blockChainToken,
        { countryCode, mobileNumber, userId, updateBlockChainToken }
      );

      if (blockchainResult?.status) {
        const blockOrganization = await createBlockOrganization(
          {
            userId,
            organizationId,
            reasonForBlock,
          },
          session
        );

        if (!blockOrganization?.error) {
          const savedOrgStatus = await saveBlockedOrganizations(
            organizationId,
            userId
          );
          const savedUserStatus = await saveBlockedUsers(
            organizationId,
            userId
          );
          const removedTrustedOrgStatus = await removeTrustedOrganization(
            organizationId,
            userId,
            'session'
          );
          const removedTrustedUserStatus = await removeTrustedUsers(
            organizationId,
            userId,
            'session'
          );

          if (
            savedOrgStatus &&
            savedUserStatus &&
            removedTrustedOrgStatus &&
            removedTrustedUserStatus
          ) {
            // clear user shared data
            await clearSharedData(userId, organizationId);

            await session.commitTransaction();
            session.endSession();

            // remove notification request of user
            await removeAllNotification(req.user, {
              userId,
              organizationId,
            });

            // Notify Organization for block by user
            await sendNotification(
              {
                notification_to: 'ORGANIZATION-ADMIN',
                notification_type: 'USER_BLOCK_TO_ORGANIZATION',
                organization_id: org.userId,
                organization_parent_id: org._id,
                sender_id: userId,
              },
              authToken
            );

            // Send mail to the organization admin to remove the data
            const orgUserData = await findUserById(org.userId);
            const mailOptions = {
              to: orgUserData?.email,
              type: mailConstants.MAIL_TYPES.BLOCK_USER_DATA_NOTIFICATION,
              userData: userAccess,
              templateVars: {
                countryCode: userAccess?.countryCode,
                mobileNumber: userAccess?.mobileNumber,
                logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
              },
            };
            const mailSent = await sendEmail(mailOptions);
            logger.info(
              `data deletion request mail has been sent to the organization admin ${orgUserData?.email}: ${mailSent}`
            );

            throwError(200, responseMessages.BLOCK_ORG_SUCCESS);
          }
        }
      }
    } else {
      if (!isOrgBlocked) {
        throwError(400, responseMessages.UNBLOCK_ORG_NOT_POSSIBLE);
      }

      /** Store Blockchain transaction for unblock */
      const blockchainResult = await executeBlockchainTransaction(
        'consent',
        'unblock',
        org.name,
        ['Unblocked'],
        `You have unblocked ${org.name} organisation`,
        blockChainToken,
        { countryCode, mobileNumber, userId, updateBlockChainToken }
      );

      if (blockchainResult?.status) {
        const unblockOrganization = await deleteBlockOrganization(
          organizationId,
          userId,
          session
        );
        if (unblockOrganization) {
          const removedOrgStatus = await removeBlockedOrganization(
            organizationId,
            userId,
            'session'
          );
          const removedUserStatus = await removeBlockedUsers(
            organizationId,
            userId,
            'session'
          );

          if (removedOrgStatus && removedUserStatus) {
            await session.commitTransaction();
            session.endSession();

            // Notify Organization for unblock by user
            await sendNotification(
              {
                notification_to: 'ORGANIZATION-ADMIN',
                notification_type: 'USER_UNBLOCK_TO_ORGANIZATION',
                organization_id: org.userId,
                organization_parent_id: org._id,
                sender_id: userId,
              },
              authToken
            );
            throwError(200, responseMessages.UNBLOCK_ORG_SUCCESS);
          }
        }
      }
    }

    throwError(500, responseMessages.SOMETHING_WENT_WRONG);
  } catch (error) {
    if (session.inTransaction()) {
      await session.abortTransaction();
    }
    session.endSession();

    const statusCode = error.statusCode || 500;
    const message = error.message || responseMessages.SOMETHING_WENT_WRONG;
    return res.status(statusCode).json({ status: statusCode, message });
  }
});

exports.getMessageLogs = asyncHandler(async (req, res) => {
  const { search, sort_by: sortBy, order_by: orderBy } = req.query;
  const loggedInUser = req.user;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;
  const skip = (page - 1) * limit;

  const currentUserId =
    loggedInUser.userType === userRoles.ORGANIZATION_ADMIN
      ? req.user?._id
      : req.user?.organizationId;

  const organization = await getOrganizationByUserId(currentUserId);
  if (!organization) {
    return res.status(404).json({
      status: 404,
      message: responseMessages.ORG_NOT_FOUND,
    });
  }

  const messageLogs = await getMessageLogs({
    organizationId: organization._id,
    search,
    skip,
    limit,
    sortBy,
    orderBy,
  });

  if (!messageLogs?.error) {
    const responseData = messageLogs?.logsList.length
      ? await Promise.all(
          messageLogs?.logsList.map(async (log) => ({
            id: log?._id || null,
            country_code: log?.countryCode || null,
            mobile_number: log?.mobileNumber || null,
            organization_id: log?.organizationId || null,
            status: log?.status || null,
            try_count: log?.tryCount || null,
            fail_count: log?.failCount || null,
            attempt_logs: log?.attemptLogs || null,
            created_at: log?.createdAt || null,
            updated_at: log?.updatedAt || null,
          }))
        )
      : [];
    return res.status(200).json({
      status: 200,
      data: {
        message_list: responseData,
        page_info: messageLogs?.pageInfo,
      },
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});
