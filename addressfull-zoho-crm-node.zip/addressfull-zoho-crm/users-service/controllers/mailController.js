const asyncHandler = require('../middleware/asyncHandler');
const {
  findDefaultTemplatesByUserType,
  findTemplatesByUser,
  updateTemplate,
  formatEmailResponse,
  findSuperAdminMailTemplates,
  filterTemplateByUserData,
} = require('../services/mailService');
const userRoles = require('../config/constants/userRoles');
const responseMessages = require('../config/constants/reponseMessages');
const { getCreatedByUserType } = require('../helpers/userHelper');

exports.getMailTemplates = asyncHandler(async (req, res) => {
  // Return mail templates based on userType and permissions.
  const { user: loggedInUserData } = req;
  const createdByUserType = getCreatedByUserType(loggedInUserData);

  const defaultTemplateList =
    await findDefaultTemplatesByUserType(createdByUserType);
  const superAdminTemplateList = await findSuperAdminMailTemplates();
  const userTemplateList = await findTemplatesByUser(loggedInUserData._id);
  const parentTemplateList = await findTemplatesByUser(
    loggedInUserData?.createdBy
  );
  const responseData = defaultTemplateList.map((defaultTemplate) => {
    let template = userTemplateList.find(
      (userTemplate) => defaultTemplate.mailType === userTemplate.mailType
    );
    if (!template)
      template = parentTemplateList.find(
        (parentTemplate) => defaultTemplate.mailType === parentTemplate.mailType
      );
    if (!template)
      template = superAdminTemplateList.find(
        (superAdminTemplate) =>
          defaultTemplate.mailType === superAdminTemplate.mailType
      );
    return template || defaultTemplate;
  });
  const formatResponseData = await Promise.all(
    responseData.map(async (responseRecord) =>
      formatEmailResponse(responseRecord, loggedInUserData)
    )
  );
  return res.json({
    status: 200,
    data: formatResponseData,
  });
});

exports.getMailTemplate = asyncHandler(async (req, res) => {
  const { type: mailType } = req.params;
  const mailTemplate = await filterTemplateByUserData({
    mailType,
    userData: req.user,
  });
  const responseData = await formatEmailResponse(mailTemplate, req.user);
  return res.json({
    status: 200,
    data: responseData,
  });
});

exports.updateMailTemplate = asyncHandler(async (req, res) => {
  const { type: mailType } = req.params;
  const {
    // from_name: fromName,
    // from_email: fromEmail,
    // to_email: toEmail = [],
    subject,
    body,
  } = req.body;
  const updatedTemplate = await updateTemplate({
    mailType,
    userId: req.user.userType === userRoles.SUPER_ADMIN ? null : req.user._id,
    // fromName,
    // fromEmail,
    // toEmail,
    subject,
    body,
  });
  if (!updatedTemplate.error) {
    return res.json({
      status: 200,
      data: responseMessages.SETTINGS_UPDATED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});
