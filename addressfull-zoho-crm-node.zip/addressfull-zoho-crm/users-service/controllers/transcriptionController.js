const moment = require('moment-timezone');
const asyncHandler = require('../middleware/asyncHandler');
const {
  convertToUTCDate,
  convertDateFormat,
} = require('../services/commonService');
const {
  makeBlockchainRequest,
  generateBlockChainToken,
  getBlockchainRequestParams,
  replaceWordsInTransactions,
  replaceWordsInMessage,
  removeOrganizationName,
  encryptOrDecryptTransactions,
} = require('../services/blockChainService');
const {
  findUserById,
  findUserByMobile,
  // generateProfilePictureURL,
  generateProfileImageFromS3,
  findSharedLabel,
  updateBlockChainToken,
} = require('../services/userService');
const {
  getOrganizationsByNameOrId,
  getProfileImageByName,
  findOrganizationByName,
} = require('../services/organizationService');
const { getSettingsByUser } = require('../services/generalSettingService');
const responseMessages = require('../config/constants/reponseMessages');
const userRoles = require('../config/constants/userRoles');
const ActivityFilter = require('../models/activityFilterModel');
const GeneralSetting = require('../models/generalSettingModel');

exports.getTransactionList = asyncHandler(async (req, res) => {
  const { userType, _id: userId } = req.user;
  const params = getBlockchainRequestParams(req.query);

  const startDate = params?.startDate;
  const endDate = params?.endDate;

  if (startDate && endDate) {
    const userSetting = await getSettingsByUser(
      userType !== userRoles.SUPER_ADMIN ? userId : null,
      'settings'
    );
    const userTimezone = userSetting?.settings?.timezone || 'UTC';

    ['startDate', 'endDate'].forEach((dateProp) => {
      params[dateProp] = convertToUTCDate(params[dateProp], userTimezone);
    });

    params.startDate = convertDateFormat(params.startDate);
    params.endDate = convertDateFormat(params.endDate);

    const convertedStartDate = convertDateFormat(params.startDate);
    const convertedEndDate = convertDateFormat(params.endDate);

    const ISOStartDate = new Date(convertedStartDate).toISOString();
    const ISOEndDate = new Date(convertedEndDate).toISOString();

    params.startDate = ISOStartDate;
    params.endDate = ISOEndDate;
  }

  try {
    const transactions = await makeBlockchainRequest(
      '/v1/adf/getAllRecordsForAdmin',
      'GET',
      params,
      {
        'x-admin-token': process.env.BLOCKCHAIN_ADMIN_TOKEN,
      },
      {}
    );

    const transactionBunch = transactions?.data?.data;

    if (transactionBunch.results && transactionBunch.results.length > 0) {
      //  Start: Decrypt transactions
      const decryptedTransactions = await encryptOrDecryptTransactions(
        transactionBunch.results
      );
      transactionBunch.results =
        decryptedTransactions.status && decryptedTransactions.result;
      // End: Decrypt transactions

      if (userType !== userRoles.SUPER_ADMIN) {
        transactionBunch?.results.forEach((trans) => {
          trans.Record.messages = trans.Record.messages.map((msg) =>
            removeOrganizationName(msg)
          );
        });
      }
      await replaceWordsInTransactions(
        transactionBunch.results,
        req.user.userType,
        true,
        true
      );
    }

    return res.status(200).json({
      status: 200,
      data: transactionBunch || {},
      message: responseMessages.BLOCKCHAIN_TRANSACTION_SUCCESS,
    });
  } catch (error) {
    return res.status(500).json({
      status: 500,
      message: responseMessages.SOMETHING_WENT_WRONG_BLOCKCHAIN,
    });
  }
});

exports.getActivityList = asyncHandler(async (req, res) => {
  try {
    const {
      client_id: clientId,
      organization_name: orgName,
      timezone,
    } = req.query;
    const { countryCode, mobileNumber } = req.user;

    const userAccess = clientId
      ? await findUserById(clientId)
      : await findUserByMobile({ countryCode, mobileNumber });

    let sharedLabels = [];
    if (orgName) {
      const organization = await findOrganizationByName(orgName, '_id name');
      if (organization) {
        const sharedData = userAccess?.sharedData?.get(organization._id) || [];
        if (sharedData.length > 0) {
          sharedLabels = await findSharedLabel(sharedData);
        } else {
          sharedLabels = sharedData;
        }
      }
    }

    const clientType = userAccess?.userType || null;
    if (!userAccess || clientType !== userRoles.FRONT_END_USER) {
      return res.status(400).json({
        status: 400,
        message: responseMessages.BLOCKCHAIN_ACCESS_DENIED,
      });
    }

    let blockChainToken = userAccess?.blockChainToken || null;
    if (blockChainToken === null) {
      // Generate and update blockchain token
      blockChainToken = await generateBlockChainToken(
        userAccess?.countryCode,
        userAccess?.mobileNumber
      );

      if (blockChainToken) {
        updateBlockChainToken(userAccess?.userId, blockChainToken);
      } else if (blockChainToken === false) {
        return res.status(400).json({
          status: 400,
          message: responseMessages.BLOCKCHAIN_ACCOUNT_NOT_EXISTS,
        });
      }
    }

    const params = getBlockchainRequestParams(req.query);
    if (params?.startDate && params?.endDate) {
      const isSuperAdmin = req.user.userType === userRoles.SUPER_ADMIN;
      const userId = isSuperAdmin ? null : req.user._id;
      const userSetting = await getSettingsByUser(userId, 'settings');
      const userTimezone = userSetting?.settings?.timezone || 'UTC';

      ['startDate', 'endDate'].forEach((dateProp) => {
        params[dateProp] = convertToUTCDate(params[dateProp], userTimezone);
      });

      params.startDate = convertDateFormat(params.startDate);
      params.endDate = convertDateFormat(params.endDate);

      const convertedStartDate = convertDateFormat(params.startDate);
      const convertedEndDate = convertDateFormat(params.endDate);

      const ISOStartDate = `${convertedStartDate}T00:00:00.000Z`;
      const ISOEndDate = `${convertedEndDate}T00:00:00.000Z`;

      params.startDate = ISOStartDate;
      params.endDate = ISOEndDate;

      // Show records prior to delete account
      if (
        req.user.userType === userRoles.FRONT_END_USER &&
        params.startDate !== params?.endDate
      ) {
        if (
          userAccess.deletedAt !== undefined &&
          userAccess.deletedAt !== null
        ) {
          const updatedDeletedAt = new Date(userAccess.deletedAt);
          const updatedEndDate = new Date(params.endDate)
            .toISOString()
            .split('T')[0];
          const finalEndDate = new Date(`${updatedEndDate}T23:59:59.999Z`);

          // Check if updatedDeletedAt is greater than updatedEndDate
          if (updatedDeletedAt > finalEndDate) {
            params.startDate = '2024-03-10T00:00:00.000Z';
            params.endDate = '2024-03-10T00:00:00.000Z';
          } else {
            params.startDate = updatedDeletedAt.toISOString();
            params.endDate = `${updatedEndDate}T23:59:59.999Z`;
          }
        }
      }
    }

    if (
      req.user.userType === userRoles.FRONT_END_USER &&
      userAccess.deletedAt !== undefined &&
      userAccess.deletedAt !== null &&
      params.startDate === params?.endDate
    ) {
      const newStartDate = new Date(params.startDate)
        .toISOString()
        .split('T')[0];
      const newEndDate = new Date(params.endDate).toISOString().split('T')[0];
      const newDeletedAt = new Date(userAccess.deletedAt)
        .toISOString()
        .split('T')[0];

      if (newStartDate === newDeletedAt) {
        params.startDate = new Date(userAccess.deletedAt).toISOString();
        params.endDate = `${newEndDate}T23:59:59.999Z`;
      }
    }

    const transactions = await makeBlockchainRequest(
      '/v1/adf/getDetailsByFilters',
      'GET',
      params,
      {},
      {},
      blockChainToken
    );

    let transformedTransactions = {
      labels: [],
      results: [],
      fetchedRecordsCount: 0,
      bookmark: null,
    };

    const transactionBunch = transactions?.data?.data;

    if (transactionBunch.results && transactionBunch.results.length > 0) {
      //  Start: Decrypt transactions
      const decryptedTransactions = await encryptOrDecryptTransactions(
        transactionBunch.results
      );
      transactionBunch.results =
        decryptedTransactions.status && decryptedTransactions.result;
      // End: Decrypt transactions

      let consentRequestorNames = transactionBunch?.results.map(
        (transaction) => transaction.Record.consentRequestor
      );
      consentRequestorNames = [...new Set(consentRequestorNames)];
      const organizations = await getOrganizationsByNameOrId(
        consentRequestorNames,
        '_id name',
        'name'
      );

      const transformedResults = await Promise.all(
        transactionBunch?.results.map(async (result) => {
          const record = result.Record;
          const orgProfile = getProfileImageByName(
            organizations,
            record.consentRequestor
          );

          const replaceText = req.user.userType !== userRoles.FRONT_END_USER;
          const updatedMessage = await replaceWordsInMessage(
            // record.messages.map((messages) => messages),
            record.messages,
            req.user.userType,
            'None',
            replaceText
          );
          let createdTimeFormatted = moment(record.createdAt);
          if (timezone) {
            createdTimeFormatted = createdTimeFormatted.tz(timezone);
          }
          const createdTimeReal = createdTimeFormatted;
          createdTimeFormatted = createdTimeFormatted.format(
            'DD-MM-YYYY, hh:mm A'
          );
          return {
            id: record.id,
            organization_name: record.consentRequestor,
            // organization_logo: generateProfilePictureURL(orgProfile),
            organization_logo: await generateProfileImageFromS3(
              userAccess._id,
              orgProfile
            ),
            message: updatedMessage[0],
            log_type: record.logType,
            permission_status: record.permissionStatus,
            country_code: record.countryCode,
            email: record.email,
            mobile_number: record.mobileNumber,
            created_date: createdTimeFormatted || null,
            default_created_date: createdTimeReal || null,
          };
        })
      );

      transformedTransactions = {
        labels: sharedLabels,
        results: transformedResults,
        fetchedRecordsCount: transactionBunch.fetchedRecordsCount,
        bookmark: transactionBunch.bookmark,
      };
    }

    return res.status(200).json({
      status: 200,
      data: transformedTransactions,
      message: responseMessages.BLOCKCHAIN_TRANSACTION_SUCCESS,
    });
  } catch (error) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});

exports.getActivityFilters = asyncHandler(async (req, res) => {
  try {
    const gnSettings = await GeneralSetting.find();

    const filteredSettings = gnSettings.filter(
      (item) => item.settings?.activity_filters
    );

    const response = [];

    // eslint-disable-next-line no-restricted-syntax
    for (const iterator of filteredSettings) {
      const activitySettings = iterator.settings.activity_filters;

      const query = { _id: { $in: activitySettings } };

      const checkInDatabase = await ActivityFilter.find(query);

      // eslint-disable-next-line no-restricted-syntax
      for (const filter of checkInDatabase) {
        if (filter.title === 'Last 30 days') {
          const endDate = moment().subtract(1, 'days');
          const startDate = moment(endDate).subtract(30, 'days');

          response.push({
            title: filter.title,
            start_date: startDate.format('YYYY-MM-DD'),
            end_date: endDate.format('YYYY-MM-DD'),
          });
        } else if (filter.title === 'Last 3 months') {
          const endDate = moment().subtract(1, 'days');
          const startDate = moment(endDate).subtract(3, 'months');

          response.push({
            title: filter.title,
            start_date: startDate.format('YYYY-MM-DD'),
            end_date: endDate.format('YYYY-MM-DD'),
          });
        } else if (filter.title === 'Year') {
          const currentYear = moment().format('YYYY');
          const startYear = moment(req.user.createdAt).format('YYYY');
          const years = Array.from(
            { length: currentYear - startYear + 1 },
            (_, i) => startYear - 0 + i
          );

          years.forEach((year) => {
            const startDate = moment(`${year}-01-01`);
            const endDate =
              year === currentYear ? moment() : moment(`${year}-12-31`);

            response.push({
              title: year.toString(),
              start_date: startDate.format('YYYY-MM-DD'),
              end_date: endDate.format('YYYY-MM-DD'),
            });
          });
        }
      }
    }

    return res.status(200).json({
      status: 200,
      message: responseMessages.ACTIVITY_FILTER_SUCCESS,
      data: response,
    });
  } catch (error) {
    return res.status(400).json({
      status: 400,
      message: responseMessages.SOMETHING_WENT_WRONG,
    });
  }
});
