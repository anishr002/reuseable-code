const asyncHandler = require('../middleware/asyncHandler');
const responseMessages = require('../config/constants/reponseMessages');
const {
  create,
  getRoleList,
  findRoleById,
  update,
  deleteOne,
  findRoleByName,
  formatResponseDocument,
} = require('../services/roleService');

exports.createRole = asyncHandler(async (req, res) => {
  const { name, status, permissions } = req.body;
  const createdBy = req.user._id;
  // Check if Role with same name exists
  const roleNameExists = await findRoleByName({
    roleName: name,
    createdBy: req.user._id,
  });
  if (roleNameExists && Object.keys(roleNameExists).length) {
    return res.status(409).json({
      status: 409,
      message: responseMessages.ROLE_NAME_EXISTS,
    });
  }
  // Create a new role
  const createdRole = await create({
    name,
    status,
    permissions,
    createdBy,
  });
  if (!createdRole?.error) {
    return res.status(201).json({
      status: 201,
      message: responseMessages.ROLES_CREATED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getRoles = asyncHandler(async (req, res) => {
  const { sort_by: sortBy, order_by: orderBy, active } = req.query;
  const page = req.query.page ? parseInt(req.query.page, 10) : 1;
  const limit = req.query.page_size ? parseInt(req.query.page_size, 10) : 10;

  const skip = (page - 1) * limit;
  const { rolesList, pageInfo } = await getRoleList({
    where: {
      ...(active !== undefined && active === 'yes' ? { isActive: true } : null),
      createdBy: req.user._id,
    },
    selectString: '-createdBy -__v',
    skip,
    limit,
    sortBy,
    orderBy,
  });
  const responseData = rolesList?.length
    ? rolesList.map((listItem) => formatResponseDocument(listItem))
    : [];
  if (rolesList && !rolesList.error) {
    return res.status(200).json({
      status: 200,
      data: {
        role_list: responseData,
        page_info: {
          total_count: pageInfo.totalCount,
          total_pages: pageInfo.totalPages,
          current_page: pageInfo.currentPage,
        },
      },
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.getRoleById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const role = await findRoleById(id, '-createdBy -__v -_id');
  if (role && !role.error) {
    return res.status(200).json({
      status: 200,
      data: formatResponseDocument(role),
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.updateRole = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, status, permissions } = req.body;
  const updatedRole = await update(id, {
    name,
    status,
    permissions,
    userId: req.user._id,
  });
  if (updatedRole?.roleNameExists) {
    return res.status(409).json({
      status: 409,
      message: responseMessages.ROLE_NAME_EXISTS,
    });
  }
  if (updatedRole?.userExists) {
    return res.status(409).json({
      status: 409,
      message: responseMessages.ROLES_USER_EXISTS_UPDATE,
    });
  }
  if (updatedRole && !updatedRole.error) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.ROLES_UPDATED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});

exports.deleteRole = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const deletedRole = await deleteOne(id, req.user._id);
  if (deletedRole?.userExists) {
    return res.status(409).json({
      status: 409,
      message: responseMessages.ROLES_USER_EXISTS,
    });
  }
  if (deletedRole && !deletedRole.error && deletedRole.deletedCount) {
    return res.status(200).json({
      status: 200,
      message: responseMessages.ROLES_DELETED,
    });
  }
  return res.status(400).json({
    status: 400,
    message: responseMessages.SOMETHING_WENT_WRONG,
  });
});
