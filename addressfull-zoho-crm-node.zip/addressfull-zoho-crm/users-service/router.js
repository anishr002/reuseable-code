const express = require('express');

const rootRouter = express.Router();
const pkg = require('./package.json');
const userRouter = require('./routes/userRoutes');
const uploadRouter = require('./routes/uploadRoutes');
const roleRouter = require('./routes/roleRoutes');
const organizationRouter = require('./routes/organizationRoutes');
const moduleRoutes = require('./routes/systemModuleRoutes');
const emailRoutes = require('./routes/mailRoutes');
const generalSettingRoutes = require('./routes/generalSettingsRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const transactionRoutes = require('./routes/transactionRoutes');
const privacyPolicyRoutes = require('./routes/privacyPolicyRoutes');
const { encrypt, decrypt } = require('./middleware/cryptoMiddleware');

// rootRouter.use(
//   `/api/v${parseInt(pkg.version, 10)}/users`,
//   decrypt,
//   encrypt,
//   userRouter
// );

rootRouter.use(`/api/v${parseInt(pkg.version, 10)}/users`, userRouter);
rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/uploads`,
  decrypt,
  encrypt,
  uploadRouter
);
rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/roles`,
  decrypt,
  encrypt,
  roleRouter
);
rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/organizations`,
  decrypt,
  encrypt,
  organizationRouter
);
rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/modules`,
  decrypt,
  encrypt,
  moduleRoutes
);
rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/settings/emailTemplates`,
  emailRoutes
);
rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/settings`,
  generalSettingRoutes
);

rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/notifications`,
  decrypt,
  encrypt,
  notificationRoutes
);

rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/transactions`,
  decrypt,
  encrypt,
  transactionRoutes
);

rootRouter.use(
  `/api/v${parseInt(pkg.version, 10)}/privacy-policies`,
  decrypt,
  encrypt,
  privacyPolicyRoutes
);

module.exports = rootRouter;
