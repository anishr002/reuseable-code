const express = require('express');
const {
  keyExchange,
  signup,
  login,
  forgotPassword,
  resetPassword,
  changePassword,
  verifyOTP,
  resendOTP,
  getProfile,
  updateProfile,
  createAdmin,
  getAdmins,
  updateAdmin,
  deleteAdmin,
  getAdmin,
  deleteAccount,
  autoSyncUserData,
  cronHistoryList,
} = require('../controllers/userController');
const {
  getSecurityQuestions,
  verifyTokenExpiration,
  refreshToken,
} = require('../controllers/securityQuestionController');
const { dashboardData } = require('../controllers/dashboardController');
const validateRequest = require('../middleware/validationMiddleware');
const {
  userSignupSchema,
  userLoginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  verifyOTPSchema,
  resendOTPSchema,
  getUserSchema,
  deleteAccountSchema,
  dashboardSchema,
  autoSyncUserDataSchema,
  getCronHistorySchema,
} = require('../validations/userSchema');
const {
  adminSchema,
  getAdminSchema,
  updateAdminSchema,
} = require('../validations/adminSchema');
const {
  protect,
  validateModuleAccess,
  isMobileUser,
  blockchainHealthCheck,
  isSuperAdmin,
} = require('../middleware/authMiddleware');
const { profilePictureUpload } = require('../middleware/fileUploadMiddleware');
const verifyObjectId = require('../middleware/verifyObjectId');
const permissionTypes = require('../config/constants/permissionType');
const { isAdminCreator } = require('../middleware/validateResourceAccess');
const systemModules = require('../config/constants/systemModules');
const { encrypt, decrypt } = require('../middleware/cryptoMiddleware');

const router = express.Router();

// User Authentication Routes

router
  .route('/cron-history-list')
  .get(
    protect,
    decrypt,
    encrypt,
    isSuperAdmin,
    validateRequest(getCronHistorySchema),
    cronHistoryList
  );

router.route('/key-exchange').post(decrypt, encrypt, keyExchange);
router
  .route('/signup')
  .post(decrypt, encrypt, validateRequest(userSignupSchema), signup);
router
  .route('/login')
  .post(decrypt, encrypt, validateRequest(userLoginSchema), login);
router
  .route('/forgot-password')
  .post(validateRequest(forgotPasswordSchema), forgotPassword);
router
  .route('/reset-password/:token')
  .post(validateRequest(resetPasswordSchema), resetPassword);
router
  .route('/change-password')
  .post(validateRequest(resetPasswordSchema), changePassword);

router
  .route('/verify-otp')
  .post(decrypt, encrypt, validateRequest(verifyOTPSchema), verifyOTP);
router
  .route('/resend-otp')
  .post(decrypt, encrypt, validateRequest(resendOTPSchema), resendOTP);

// Security Questions
router.route('/securityQuestions').get(getSecurityQuestions);

router.route('/verifyTokenExpiration/:token').get(verifyTokenExpiration);

router.route('/refresh-token').get(decrypt, encrypt, protect, refreshToken);

// Dashboard Route
router
  .route('/dashboard')
  .get(
    decrypt,
    encrypt,
    protect,
    blockchainHealthCheck,
    validateModuleAccess(systemModules.DASHBOARD, permissionTypes.READ),
    validateRequest(dashboardSchema),
    dashboardData
  );

// User Profile Routes
router
  .route('/profile')
  .get(decrypt, encrypt, protect, getProfile)
  .post(
    decrypt,
    encrypt,
    protect,
    profilePictureUpload,
    validateRequest(getUserSchema),
    updateProfile
  );

// Admin Management Routes
router
  .route('/')
  .post(
    decrypt,
    encrypt,
    protect,
    validateModuleAccess(
      systemModules.ADMIN_MODULE,
      permissionTypes.READ_WRITE
    ),
    validateRequest(adminSchema),
    createAdmin
  )
  .get(
    decrypt,
    encrypt,
    protect,
    validateModuleAccess(systemModules.ADMIN_MODULE, permissionTypes.READ),
    validateRequest(getAdminSchema),
    getAdmins
  );

router
  .route('/:id')
  .get(
    decrypt,
    encrypt,
    protect,
    validateModuleAccess(systemModules.ADMIN_MODULE, permissionTypes.READ),
    verifyObjectId,
    isAdminCreator,
    getAdmin
  )
  .put(
    decrypt,
    encrypt,
    protect,
    validateModuleAccess(
      systemModules.ADMIN_MODULE,
      permissionTypes.READ_WRITE
    ),
    verifyObjectId,
    isAdminCreator,
    validateRequest(updateAdminSchema),
    updateAdmin
  )
  .delete(
    decrypt,
    encrypt,
    protect,
    validateModuleAccess(
      systemModules.ADMIN_MODULE,
      permissionTypes.READ_WRITE
    ),
    verifyObjectId,
    isAdminCreator,
    deleteAdmin
  );

// Delete Account
router
  .route('/delete-account/:type')
  .delete(
    decrypt,
    encrypt,
    protect,
    isMobileUser,
    validateRequest(deleteAccountSchema),
    deleteAccount
  );

// Auto-sync User Data
router
  .route('/auto-sync')
  .post(
    decrypt,
    encrypt,
    protect,
    isMobileUser,
    validateRequest(autoSyncUserDataSchema),
    autoSyncUserData
  );

module.exports = router;
