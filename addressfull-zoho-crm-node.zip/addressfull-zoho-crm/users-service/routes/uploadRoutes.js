const express = require('express');
const {
  uploadProfilePicture,
  getProfilePicture,
  deleteProfilePicture,
} = require('../controllers/userController');
const { profilePictureUpload } = require('../middleware/fileUploadMiddleware');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

// profile-picture upload
router
  .route('/profile-picture')
  .post(protect, profilePictureUpload, uploadProfilePicture)
  .get(protect, getProfilePicture)
  .delete(protect, deleteProfilePicture);

module.exports = router;
