const app = require('express');
const validateRequest = require('../middleware/validationMiddleware');
const {
  getTransactionList,
  getActivityList,
  getActivityFilters,
} = require('../controllers/transcriptionController');
const {
  protect,
  blockchainHealthCheck,
  isAdmin,
  validateModuleAccess,
} = require('../middleware/authMiddleware');
const systemModules = require('../config/constants/systemModules');
const permissionTypes = require('../config/constants/permissionType');
const {
  getTransactionSchema,
  getActivitySchema,
} = require('../validations/transactionSchema');

const router = app.Router();

router
  .route('/')
  .get(
    protect,
    blockchainHealthCheck,
    isAdmin,
    validateModuleAccess(
      systemModules.TRANSACTION_MODULE,
      permissionTypes.READ
    ),
    validateRequest(getTransactionSchema),
    getTransactionList
  );

router
  .route('/activity-list')
  .get(
    protect,
    blockchainHealthCheck,
    validateRequest(getActivitySchema),
    getActivityList
  );

router.route('/activity-filters').get(protect, getActivityFilters);

module.exports = router;
