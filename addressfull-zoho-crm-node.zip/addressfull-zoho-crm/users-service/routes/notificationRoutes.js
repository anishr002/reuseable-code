const app = require('express');
const validateRequest = require('../middleware/validationMiddleware');
const {
  getNotificationList,
  sendRequestToUser,
  updateRequest,
  readNotification,
  readAllNotification,
  forceUpdate,
} = require('../controllers/notificationController');
const {
  protect,
  isOrganizationAdmin,
  blockchainHealthCheck,
} = require('../middleware/authMiddleware');
const {
  sendRequestToUserSchema,
  updateRequestSchema,
  forceUpdateSchema,
} = require('../validations/notificationSchema');

const router = app.Router();

router.route('/').get(protect, getNotificationList);

/* Requests Module Routes */
router
  .route('/send-request')
  .post(
    protect,
    blockchainHealthCheck,
    isOrganizationAdmin,
    validateRequest(sendRequestToUserSchema),
    sendRequestToUser
  );

router
  .route('/update-request')
  .post(
    protect,
    blockchainHealthCheck,
    validateRequest(updateRequestSchema),
    updateRequest
  );

router
  .route('/force-update')
  .post(validateRequest(forceUpdateSchema), forceUpdate);

router.route('/read-all').get(protect, readAllNotification);

router.route('/read/:id').put(protect, readNotification);

module.exports = router;
