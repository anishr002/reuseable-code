const app = require('express');
const {
  getSettings,
  updateSettings,
} = require('../controllers/generalSettingController');
const {
  addCRM,
  getCRMIntegrations,
  addActivity,
} = require('../controllers/crmSettingController');
const {
  protect,
  isAdmin,
  isOrganizationAdmin,
  validateModuleAccess,
  isAdminAndOrganization,
} = require('../middleware/authMiddleware');
const validateRequest = require('../middleware/validationMiddleware');
const {
  settingsSchema,
  updateCRMSettingSchema,
} = require('../validations/settingSchema');
const systemModules = require('../config/constants/systemModules');
const permissionTypes = require('../config/constants/permissionType');

const router = app.Router();

router
  .route('/')
  .post(protect, isAdmin, validateRequest(settingsSchema), updateSettings)
  .get(protect, isAdminAndOrganization, getSettings);

router
  .route('/crm')
  .post(
    protect,
    isOrganizationAdmin,
    validateModuleAccess(
      systemModules.CRM_SETTING_MODULE,
      permissionTypes.READ_WRITE
    ),
    validateRequest(updateCRMSettingSchema),
    addCRM
  );

router
  .route('/crm')
  .get(
    protect,
    isOrganizationAdmin,
    validateModuleAccess(
      systemModules.CRM_SETTING_MODULE,
      permissionTypes.READ
    ),
    getCRMIntegrations
  );

// router.post('/add/activity', addActivity);
module.exports = router;
