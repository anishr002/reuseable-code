const app = require('express');
const { getModules } = require('../controllers/systemModuleController');
const { protect, isAdmin } = require('../middleware/authMiddleware');

const router = app.Router();

router.route('/').get(protect, isAdmin, getModules);

module.exports = router;
