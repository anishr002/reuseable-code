const app = require('express');
const validateRequest = require('../middleware/validationMiddleware');
const verifyObjectId = require('../middleware/verifyObjectId');
const {
  protect,
  isAdminAndOrganization,
  isSuperAdmin,
} = require('../middleware/authMiddleware');
const {
  policySchema,
  updatePolicySchema,
  getPolicySchema,
} = require('../validations/privacyPolicySchema');
const {
  createPolicy,
  updatePolicy,
  deletePolicy,
  getPolicies,
} = require('../controllers/privacyPolicyController');

const router = app.Router();

router
  .route('/')
  .get(
    protect,
    isAdminAndOrganization,
    validateRequest(getPolicySchema),
    getPolicies
  )
  .post(
    protect,
    isAdminAndOrganization,
    validateRequest(policySchema),
    createPolicy
  );

router
  .route('/:id')
  .put(
    protect,
    verifyObjectId,
    isAdminAndOrganization,
    validateRequest(updatePolicySchema),
    updatePolicy
  )
  .delete(protect, verifyObjectId, isAdminAndOrganization, deletePolicy);

module.exports = router;
