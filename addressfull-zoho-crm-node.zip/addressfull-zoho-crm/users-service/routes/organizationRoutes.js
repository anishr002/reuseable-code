const app = require('express');
const {
  getTopTrustedOrganizationList,
  getMyTrustedOrganizationList,
  createOrganization,
  updateOrganization,
  deleteOrganization,
  fetchOrganizationById,
  getOrganizationList,
  organizationDocumentUpload,
  organizationDocumentRemove,
  makeMyTrustedOrganization,
  removeMyTrustedOrganization,
  getOrganizationProfile,
  getConnectedUsers,
  shareDataToOrganization,
  deleteAllMyTrustedOrganization,
  getUserConsentCount,
  handleDataReqBulk,
  blockUnblockOrganization,
  getMyBlockedOrganizationList,
  getMessageLogs,
} = require('../controllers/organizationController');
const {
  generateOrgSharedDataPDF,
} = require('../controllers/documentController');
const verifyObjectId = require('../middleware/verifyObjectId');
const {
  protect,
  isOrganizationAdmin,
  validateModuleAccess,
  isMobileUser,
  serverHealthCheck,
  blockchainHealthCheck,
} = require('../middleware/authMiddleware');
const {
  orgPictureUpload,
  documentUpload,
} = require('../middleware/fileUploadMiddleware');
const validateRequest = require('../middleware/validationMiddleware');
const {
  getTopTrustedOrganizationsSchema,
  createOrganizationSchema,
  updateOrganizationSchema,
  uploadOrganizationDocSchema,
  getOrganizationsSchema,
  removeOrganizationDocSchema,
  makeMyTrustedOrganizationSchema,
  shareDataToOrganizationSchema,
  getConnectedUsersSchema,
  getUserConsentSchema,
  sendDataReqBulkSchema,
  blockUnblockOrganizationSchema,
  getBlockedOrganizationListSchema,
  getMessageLogsSchema,
} = require('../validations/organizationSchema');
const systemModules = require('../config/constants/systemModules');
const permissionTypes = require('../config/constants/permissionType');

const router = app.Router();

router
  .route('/top-trusted')
  .get(
    protect,
    validateRequest(getTopTrustedOrganizationsSchema),
    getTopTrustedOrganizationList
  );

router
  .route('/my-trusted')
  .get(
    protect,
    validateRequest(getTopTrustedOrganizationsSchema),
    getMyTrustedOrganizationList
  )
  .post(
    protect,
    validateRequest(makeMyTrustedOrganizationSchema),
    makeMyTrustedOrganization
  )
  .delete(protect, isMobileUser, deleteAllMyTrustedOrganization);

router
  .route('/my-trusted/share-data')
  .post(
    protect,
    isMobileUser,
    serverHealthCheck,
    validateRequest(shareDataToOrganizationSchema),
    shareDataToOrganization
  );

router
  .route('/my-trusted/:id')
  .delete(
    protect,
    verifyObjectId,
    serverHealthCheck,
    removeMyTrustedOrganization
  );

router
  .route('/trusted/profile/:id')
  .get(protect, verifyObjectId, getOrganizationProfile);

router
  .route('/')
  .get(protect, validateRequest(getOrganizationsSchema), getOrganizationList)
  .post(
    protect,
    orgPictureUpload,
    validateRequest(createOrganizationSchema),
    createOrganization
  );

router
  .route('/users')
  .get(
    protect,
    isOrganizationAdmin,
    validateModuleAccess(systemModules.USER_MODULE, permissionTypes.READ),
    validateRequest(getConnectedUsersSchema),
    getConnectedUsers
  );

router
  .route('/user-consent-count')
  .get(protect, validateRequest(getUserConsentSchema), getUserConsentCount);

router
  .route('/bulk-sms-logs')
  .get(
    protect,
    isOrganizationAdmin,
    validateModuleAccess(systemModules.SMS_LOGS_MODULE, permissionTypes.READ),
    validateRequest(getMessageLogsSchema),
    getMessageLogs
  );

router
  .route('/document')
  .post(
    protect,
    documentUpload,
    validateRequest(uploadOrganizationDocSchema),
    organizationDocumentUpload
  );

router
  .route('/document/remove')
  .post(
    protect,
    validateRequest(removeOrganizationDocSchema),
    organizationDocumentRemove
  );

router
  .route('/download/shared-data-report')
  .get(protect, generateOrgSharedDataPDF);

router
  .route('/send-data-request')
  .post(
    protect,
    blockchainHealthCheck,
    isOrganizationAdmin,
    validateRequest(sendDataReqBulkSchema),
    handleDataReqBulk
  );

router
  .route('/block-unblock')
  .post(
    protect,
    isMobileUser,
    blockchainHealthCheck,
    validateRequest(blockUnblockOrganizationSchema),
    blockUnblockOrganization
  );

router
  .route('/my-blocked')
  .get(
    protect,
    validateRequest(getBlockedOrganizationListSchema),
    getMyBlockedOrganizationList
  );

router
  .route('/:id')
  .get(protect, fetchOrganizationById)
  .put(
    protect,
    orgPictureUpload,
    validateRequest(updateOrganizationSchema),
    updateOrganization
  )
  .delete(protect, verifyObjectId, deleteOrganization);

module.exports = router;
