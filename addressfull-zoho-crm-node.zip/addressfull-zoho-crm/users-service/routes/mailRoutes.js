const app = require('express');
const {
  getMailTemplates,
  updateMailTemplate,
  getMailTemplate,
} = require('../controllers/mailController');
const {
  protect,
  isAdmin,
  validateModuleAccess,
} = require('../middleware/authMiddleware');
const validateRequest = require('../middleware/validationMiddleware');
const {
  getEmailTemplateSchema,
  updateEmailTemplateSchema,
} = require('../validations/settingSchema');
const permissionTypes = require('../config/constants/permissionType');
const systemModules = require('../config/constants/systemModules');

const router = app.Router();

router
  .route('/')
  .get(
    protect,
    isAdmin,
    validateModuleAccess(
      systemModules.GENERAL_SETTING_MODULE,
      permissionTypes.READ
    ),
    getMailTemplates
  );
router
  .route('/:type')
  .get(
    protect,
    isAdmin,
    validateModuleAccess(
      systemModules.GENERAL_SETTING_MODULE,
      permissionTypes.READ
    ),
    validateRequest(getEmailTemplateSchema),
    getMailTemplate
  )
  .put(
    protect,
    isAdmin,
    validateModuleAccess(
      systemModules.GENERAL_SETTING_MODULE,
      permissionTypes.READ_WRITE
    ),
    validateRequest(updateEmailTemplateSchema),
    updateMailTemplate
  );

module.exports = router;
