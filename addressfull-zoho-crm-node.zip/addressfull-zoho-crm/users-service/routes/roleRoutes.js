const app = require('express');
const {
  createRole,
  getRoles,
  getRoleById,
  updateRole,
  deleteRole,
} = require('../controllers/roleController');
const { isRoleCreator } = require('../middleware/validateResourceAccess');
const {
  createRoleSchema,
  getRoleSchema,
} = require('../validations/roleSchema');
const {
  protect,
  validateModuleAccess,
  isAdmin,
} = require('../middleware/authMiddleware');
const validateRequest = require('../middleware/validationMiddleware');
const verifyObjectId = require('../middleware/verifyObjectId');
const permissionTypes = require('../config/constants/permissionType');
const systemModules = require('../config/constants/systemModules');

const router = app.Router();

router
  .route('/')
  .post(
    protect,
    validateModuleAccess(systemModules.ROLE_MODULE, permissionTypes.READ_WRITE),
    validateRequest(createRoleSchema),
    createRole
  )
  .get(protect, isAdmin, validateRequest(getRoleSchema), getRoles);

router
  .route('/:id')
  .get(
    protect,
    validateModuleAccess(systemModules.ROLE_MODULE, permissionTypes.READ),
    verifyObjectId,
    isRoleCreator,
    getRoleById
  )
  .put(
    protect,
    validateModuleAccess(systemModules.ROLE_MODULE, permissionTypes.READ_WRITE),
    verifyObjectId,
    isRoleCreator,
    validateRequest(createRoleSchema),
    updateRole
  )
  .delete(
    protect,
    validateModuleAccess(systemModules.ROLE_MODULE, permissionTypes.READ_WRITE),
    verifyObjectId,
    isRoleCreator,
    deleteRole
  );

module.exports = router;
