require('dotenv').config();

const express = require('express');
const compression = require('compression');
const swagger = require('swagger-ui-express');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');
const cron = require('node-cron');
const swaggerDoc = require('./swagger');
const logger = require('./logger');

if (process.env.LOGS === 'false') {
  console.log = function () {};
  console.error = function () {};
  console.info = function () {};
  logger.info = function () {};
  logger.error = function () {};
}

const dbConnect = require('./config/dbConnection');
const rootRouter = require('./router');
const { errorHandler, notFound } = require('./middleware/errorHandler');
const { router: tokenCleanup } = require('./middleware/tokenCleanupMiddleware');
const { sendErrorLogs } = require('./helpers/emailServices');
const { convertS3Image } = require('./helpers/S3Handler');
const mailConstants = require('./config/constants/mailOptions');
const {
  deleteUserDataCron,
  handleCronJobFailures,
  handleCronJobReminder,
  handleBulkSms,
} = require('./services/cronServices');
const GeneralSetting = require('./models/generalSettingModel');

const app = express();
dbConnect();
app.disable('x-powered-by');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Morgan logger middleware
app.use(morgan(':method :url :status - :response-time ms'));

/* Captured and handled errors that occur at the global level and aren't handled anywhere else in the code. */
process.on('uncaughtException', async (error) => {
  logger.error(`Uncaught Exception thrown : ${JSON.stringify(error)}`);
  // Send mail to the developer or support team to fix errors coming from the application
  await sendErrorLogs({
    error,
    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
  });
});

process.on('unhandledRejection', async (error) => {
  logger.error(`Error from application : ${JSON.stringify(error)}`);
  // Send mail to the developer or support team to fix errors coming from the application
  await sendErrorLogs({
    error,
    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
  });
});

/* Implemented CORS */
// const allowedOrigins = ['http://localhost:3000', 'http://137.184.19.129:3002'];
// app.use(
//   cors({
//     origin: allowedOrigins,
//   })
// );
app.use(cors());

// Cron job to perform all expensive data operations
let isDeleteCronRunning = false;

const runDeleteUserDataCron = () =>
  new Promise((resolve, reject) => {
    if (isDeleteCronRunning) {
      reject(new Error('Previous job is still running'));
    } else {
      isDeleteCronRunning = true;
      const startTime = new Date();
      logger.info(`Cron job started at: ${startTime}`);

      deleteUserDataCron()
        .then(() => {
          const endTime = new Date();
          const elapsedTime = endTime - startTime;
          logger.info(`Cron job completed in ${elapsedTime} milliseconds`);
          isDeleteCronRunning = false;
          resolve();
        })
        .catch((error) => {
          logger.error('Error occurred during job execution:', error);
          isDeleteCronRunning = false;
          reject(new Error(error));
        });
    }
  });

cron.schedule('*/1 * * * *', async () => {
  try {
    await runDeleteUserDataCron();
  } catch (error) {
    logger.error('Failed to execute cron job:', error);
  }
});

// Cron job to handle data operations failures
let isJobFailureRunning = false;

const runHandleCronJobFailures = () =>
  new Promise((resolve, reject) => {
    if (isJobFailureRunning) {
      reject(new Error('Previous job is still running'));
    } else {
      isJobFailureRunning = true;
      const startTime = new Date();
      logger.info(`Cron job started at: ${startTime}`);

      handleCronJobFailures()
        .then(() => {
          const endTime = new Date();
          const elapsedTime = endTime - startTime;
          logger.info(`Cron job completed in ${elapsedTime} milliseconds`);
          isJobFailureRunning = false;
          resolve();
        })
        .catch((error) => {
          logger.error('Error occurred during job execution:', error);
          isJobFailureRunning = false;
          reject(new Error(error));
        });
    }
  });

cron.schedule('*/1 * * * *', async () => {
  try {
    await runHandleCronJobFailures();
  } catch (error) {
    logger.error('Failed to execute cron job:', error);
  }
});

// Cron job for request reminder to mobile user
const defaultCronTime = '0 0 * * *';
let currentCronJob;

// Function to fetch cron expression from settings
async function getCronExpression() {
  try {
    const generalSetting = await GeneralSetting.findOne({
      userId: null,
    });
    return generalSetting?.settings?.cron_execution_time || defaultCronTime;
  } catch (error) {
    logger.error('Error fetching cron expression:', error);
    // Default to everyday if there's an error
    return defaultCronTime;
  }
}

// Function to set up reminder cron job
async function setupReminderCronJob() {
  try {
    const cronExpression = await getCronExpression();

    // If there's an existing cron job, stop it
    if (currentCronJob) {
      currentCronJob.stop();
    }
    // Set up the new cron job
    currentCronJob = cron.schedule(cronExpression, async () => {
      const startTime = new Date();
      logger.info(`History:: Reminder cron job executed at: ${new Date()}`);
      handleCronJobReminder();
      const endTime = new Date();
      const elapsedTime = endTime - startTime;
      logger.info(
        `History:: Reminder cron job took ${elapsedTime} milliseconds`
      );
    });
  } catch (error) {
    logger.error('Error setting up reminder cron job:', error);
  }
}

// Listen for changes in cron expression
GeneralSetting.watch().on('change', async (change) => {
  if (change.operationType === 'update') {
    // Check if the cron_execution_time field was updated
    const updatedFields = Object.keys(change.updateDescription.updatedFields);
    if (updatedFields.includes('settings.cron_execution_time')) {
      logger.info('Cron execution time update detected');
      await setupReminderCronJob();
    }
  }
});

// Initial reminder cron setup
setupReminderCronJob();

// Cron to proceed bulk sms
cron.schedule('*/1 * * * *', async () => {
  const startTime = new Date();
  logger.info(`History:: Bulk sms cron job executed at: ${new Date()}`);
  handleBulkSms();
  const endTime = new Date();
  const elapsedTime = endTime - startTime;
  logger.info(`History:: Bulk sms cron job took ${elapsedTime} milliseconds`);
});

// Apply token cleanup middleware to all routes
app.use(tokenCleanup);

/* Application routes */
app.use(rootRouter);

/* Static Paths (Remember to set it differenty in production) */
app.use(
  '/uploads/profilePictures',
  express.static(path.join(__dirname, '/uploads/profilePictures'))
);
app.use(
  '/uploads/orgDocuments',
  express.static(path.join(__dirname, '/uploads/orgDocuments'))
);

/* Swagger Doc */
app.use('/api-docs', swagger.serve, swagger.setup(swaggerDoc));

// S3 image url convert route
app.get('/doc/:pathToImage', convertS3Image);

/* Error handling middlewares */
app.use(notFound);
app.use(errorHandler);
app.use(compression());

module.exports = app.listen(process.env.PORT, process.env.HOST, () => {
  logger.info(
    `Your server is running on : ${process.env.PROTOCOL}://${process.env.HOST}:${process.env.PORT}`
  );
});
