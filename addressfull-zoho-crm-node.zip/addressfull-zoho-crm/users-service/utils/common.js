const moment = require('moment');
const crypto = require('crypto');

let getAllModules;

exports.setGetAllModules = (getAllFn) => {
  getAllModules = getAllFn;
};

exports.deepCopy = (obj, map = new Map()) => {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (map.has(obj)) {
    // If object is already copied, return the existing copy
    return map.get(obj);
  }

  if (Array.isArray(obj)) {
    const copy = obj.map((item) => this.deepCopy(item, map));
    map.set(obj, copy); // Store copied array in the map
    return copy;
  }

  const copy = {};
  map.set(obj, copy); // Store copied object in the map
  Object.keys(obj).forEach((key) => {
    if (Object.hasOwn(obj, key)) {
      copy[key] = this.deepCopy(obj[key], map);
    }
  });

  return copy;
};

exports.generateTimeExpiration = (minutes) => {
  if (minutes) {
    const otpExpiration = new Date();
    otpExpiration.setMinutes(otpExpiration.getMinutes() + minutes);
    return otpExpiration;
  }
  return null;
};

exports.generateRandomNumber = (digits) => {
  // const min = 1;
  // const max = 10 ** digits;
  // return Math.floor(Math.random() * (max - min)) + min;
  const min = 10 ** (digits - 1);
  const max = 10 ** digits;
  return crypto.randomInt(min, max);
};

exports.filterObjectKeys = (obj, keysToKeep) => {
  const filteredObject = {};
  Object.keys(obj).forEach((key) => {
    if (keysToKeep.includes(key)) {
      filteredObject[key] = obj[key];
    }
  });
  return filteredObject;
};

exports.getModules = async (userType) => {
  if (!userType) {
    return [];
  }
  // Get modules from the database
  const modules = await getAllModules();
  const systemModules = modules
    .filter((module) => module.userType === userType)
    .map((module) => module.name);
  return systemModules;
};

exports.generateRandomPassword = (length = 12) => {
  const charset =
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-+=<>?';
  let password = '';

  for (let i = 0; i < length; i++) {
    // const randomIndex = Math.floor(Math.random() * charset.length);
    const randomIndex = crypto.randomInt(0, charset.length);
    password += charset[randomIndex];
  }

  return password;
};

// Function to add a new log entry to the cronLogs array
exports.addCronLog = (cronLogs, payload) => {
  const { message, data, error } = payload;
  // Push a new log entry to the cronLogs array
  if (Array.isArray(cronLogs)) {
    cronLogs.push({
      message,
      data,
      error,
      timestamp: moment().utc(),
    });
  }
  // Return the updated cronLogs array
  return cronLogs;
};
