const path = require('path');
const multer = require('multer');
const fs = require('fs');
const responseMessages = require('../config/constants/reponseMessages');
const fileUploadPaths = require('../config/constants/fileUploads');
const logger = require('../logger');
const { generateRandomNumber } = require('./common');

/* Function to decode base64 string to file content */
exports.decodeBase64File = (base64String, filename) => {
  const base64Data = base64String.replace(/^data:image\/\w+;base64,/, '');
  const buffer = Buffer.from(base64Data, 'base64');
  fs.writeFileSync(filename, buffer);
  return filename; // Return the filename or content
};

exports.getFileTypeBase64File = (base64String) => {
  const parsedBase64String = base64String.split(',');
  const parsedBase64StringProps = parsedBase64String[0].split(';');
  const parsedFileProps = parsedBase64StringProps[0].split(':');
  const parsedFileTypeProps = parsedFileProps[1].split('/');
  return parsedFileTypeProps;
};

exports.decodeBase64File = (base64String, filePath) => {
  const base64Data = base64String.replace(/^data:image\/\w+;base64,/, '');
  const buffer = Buffer.from(base64Data, 'base64');
  // const filePath = path.join(__dirname, 'uploads', filename); // Adjust the file path as needed
  fs.writeFileSync(filePath, buffer);
  return filePath;
};

// Define all paths for file uploads
exports.getPathToUpload = (endpoint) => {
  let fileUploadPath;
  switch (endpoint) {
    case '/profile':
      fileUploadPath = fileUploadPaths.PROFILE_PICTURE;
      break;
    case '/document':
      fileUploadPath = fileUploadPaths.DOCUMENT_UPLOAD;
      break;
    case '/auto-sync':
      fileUploadPath = fileUploadPaths.USER_AUTO_SYNC_FOLDER_RELATIVE_PATH;
      break;
    default:
      fileUploadPath = fileUploadPaths.DEFAULT_UPLOAD;
  }
  return fileUploadPath;
};

// Define file name conventions for each and every upload
exports.getFileNameToUpload = (endpoint) => {
  let fileName;
  switch (endpoint) {
    case '/profile':
      fileName = `profile_${Date.now()}_${generateRandomNumber(6)}`;
      break;
    case '/org-profile':
      fileName = `org-profile_${Date.now()}_${generateRandomNumber(6)}`;
      break;
    case '/profile-picture':
      fileName = `profile_${Date.now()}_${generateRandomNumber(6)}`;
      break;
    case '/document':
      fileName = `document_${Date.now()}_${generateRandomNumber(6)}`;
      break;
    default:
      fileName = null;
  }
  return fileName;
};

// Set path inside multer storage
exports.setMulterStorage = () => {
  const storage = multer.diskStorage({
    destination(req, _file, cb) {
      const pathToUpload = exports.getPathToUpload(req.url);
      cb(null, pathToUpload);
    },
    filename(req, file, cb) {
      const fileExtention = path.extname(file.originalname);
      const fileName = exports.getFileNameToUpload(req.url);
      const fileNameToUpload = fileName
        ? fileName + fileExtention
        : `${file.fieldname}-${Date.now()}${fileExtention}`;
      cb(null, fileNameToUpload);
    },
  });
  return storage;
};

// Set path inside multer storage
exports.setOrgMulterStorage = () => {
  const storage = multer.diskStorage({
    destination(_req, _file, cb) {
      const pathToUpload = fileUploadPaths.PROFILE_PICTURE;
      cb(null, pathToUpload);
    },
    filename(_req, file, cb) {
      const fileExtention = path.extname(file.originalname);
      const fileName = `orgprofile_${Date.now()}_${generateRandomNumber(6)}`;
      const fileNameToUpload = fileName
        ? fileName + fileExtention
        : `${file.fieldname}-${Date.now()}${fileExtention}`;
      cb(null, fileNameToUpload);
    },
  });
  return storage;
};

// Profile Picture validation
exports.validateProfilePicture = (req, file, cb) => {
  // fileUploaded flag is to check if file is uploaded or not
  req.fileUploaded = true;
  // File type validation
  const filetypes = /jpg|jpeg|png|svg/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = filetypes.test(file.mimetype);
  if (extname && mimetype) {
    return cb(null, true);
  }
  // Setting fileUploadError inside req to track the errors
  req.fileUploadError = responseMessages.PROFILE_PIC_FILETYPE;
  return cb(null, false);
};

exports.validateDocument = (req, file, cb) => {
  req.fileUploaded = true;

  const filetypes = /doc|docx|xlsx|pdf|jpg|jpeg|png/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

  // Allowed mimeTypes
  const allowedMimetypes = [
    'application/msword', // .doc
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
    'application/pdf', // .pdf
    'image/jpeg', // .jpg, .jpeg
    'image/png', // .png
  ];

  const mimetype = allowedMimetypes.includes(file.mimetype);
  if (extname && mimetype) {
    return cb(null, true);
  }

  req.fileUploadError = responseMessages.DOCUMENT_FILETYPE;
  return cb(null, false);
};

// Delete file
exports.deleteFile = async (filePath) => {
  if (!filePath) return false;
  try {
    await fs.promises.unlink(filePath);
    return true;
  } catch (err) {
    logger.error(`Error while deleting file: ${err}`);
    return false;
  }
};

// Check if file exists
exports.isFileExists = (filePath) => {
  if (!filePath) return false;
  try {
    const isExists = fs.existsSync(filePath, fs.constants.F_OK);
    return isExists;
  } catch (err) {
    logger.error(`Error while checking file exist: ${err}`);
    return false;
  }
};

exports.createFolder = async (endpoint) => {
  try {
    const folderPath = path.join(__dirname, exports.getPathToUpload(endpoint));
    // Check if the folder already exists
    if (!fs.existsSync(folderPath)) {
      // If it doesn't exist, create it
      fs.mkdirSync(folderPath);
      logger.info(`Folder created successfully at: ${folderPath}`);
      return true;
    }
    logger.info(`Folder already exists at: ${folderPath}`);
    return true;
  } catch (error) {
    logger.error(`Error creating cronData folder`);
    return false;
  }
};

exports.writeFile = async (endpoint, fileName, contentToWrite, reWriteFlag) => {
  const filePath = path.join(
    __dirname,
    exports.getPathToUpload(endpoint),
    fileName
  );
  try {
    if (reWriteFlag !== false || !fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, contentToWrite);
    }
    return true;
    // fs.chmodSync(privateKeyPath, 0o600); // read and write only for the owner
  } catch (error) {
    logger.error(`Error Writing cronData into file: ${filePath} - ${error}`);
    return false;
  }
};

exports.readFile = async (endpoint, fileName) => {
  const filePath = path.join(
    __dirname,
    exports.getPathToUpload(endpoint),
    fileName
  );
  try {
    const fileContent = await fs.promises.readFile(filePath, {
      encoding: 'utf-8',
    });
    return fileContent;
  } catch (error) {
    logger.error(`Error in reading auto-sync user data: ${error}`);
    return false;
  }
};
