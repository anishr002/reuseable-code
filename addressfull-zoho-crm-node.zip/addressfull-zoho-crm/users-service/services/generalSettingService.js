const GeneralSetting = require('../models/generalSettingModel');
const OrganizationType = require('../models/organizationTypeModel');
const withErrorHandling = require('../middleware/serviceHandler');
const ActivityFilter = require('../models/activityFilterModel');

exports.getOrganizationTypes = withErrorHandling(
  async (_userId, selectString) => {
    const organizationTypes = await OrganizationType.find()
      .select(selectString)
      .sort({ title: 1 });
    return organizationTypes;
  }
);

exports.getSettingsByUser = withErrorHandling(async (userId, selectString) => {
  const userSettings = await GeneralSetting.findOne({
    userId,
  }).select(selectString);
  return userSettings;
});

exports.updateUserSettings = withErrorHandling(
  async (payload, selectString) => {
    const { settings, userId } = payload;
    const {
      toEmail,
      smsService,
      timezone,
      cron_execution_time,
      token_expiration_time,
      activity_filters,
    } = settings;
    const isExistsSetting = await GeneralSetting.findOne({
      userId,
    }).select(selectString);
    if (!isExistsSetting) {
      // Create new template
      const settingRecord = new GeneralSetting({
        settings,
        userId,
      });
      return settingRecord.save();
    }
    if (toEmail !== undefined) isExistsSetting.settings.toEmail = toEmail;
    if (smsService !== undefined)
      isExistsSetting.settings.smsService = smsService;
    if (timezone !== undefined) isExistsSetting.settings.timezone = timezone;
    if (cron_execution_time !== undefined)
      isExistsSetting.settings.cron_execution_time = cron_execution_time;
    if (token_expiration_time !== undefined)
      isExistsSetting.settings.token_expiration_time = token_expiration_time;
    if (activity_filters !== undefined)
      isExistsSetting.settings.activity_filters = activity_filters;

    return isExistsSetting.save();
  }
);

// exports.formatSettingsResponse = async (payload) => {

//   const organizationTypes = await this.getOrganizationTypes();
//   return {
//     to_email: payload?.settings?.toEmail,
//     sms_service: payload?.settings?.smsService,
//     timezone: payload?.settings?.timezone,
//     cron_execution_time: payload?.settings?.cron_execution_time,
//     token_expiration_time: payload?.settings?.token_expiration_time,
//     organization_types: organizationTypes.map((orgType) => ({
//       name: orgType.name,
//       title: orgType.title,
//       active: orgType.isActive,
//     })),
//     activity_filters: activityData.map((data) => ({
//       id: data._id,
//       title: data.title,
//       descriptions: data.descriptions,
//     })),
//   };
// };

exports.formatSettingsResponse = async (payload) => {
  const selectedOptions = payload?.settings?.activity_filters || [];
  const activityData = await ActivityFilter.find();
  const organizationTypes = await this.getOrganizationTypes();

  const formattedActivityFilters = activityData.map((data) => {
    const isSelected = selectedOptions.includes(data._id);
    return {
      id: data._id,
      title: data.title,
      descriptions: data.descriptions,
      selected: isSelected,
    };
  });

  return {
    to_email: payload?.settings?.toEmail,
    sms_service: payload?.settings?.smsService,
    timezone: payload?.settings?.timezone,
    cron_execution_time: payload?.settings?.cron_execution_time,
    token_expiration_time: payload?.settings?.token_expiration_time,
    organization_types: organizationTypes.map((orgType) => ({
      name: orgType.name,
      title: orgType.title,
      active: orgType.isActive,
    })),
    activity_filters: formattedActivityFilters,
  };
};
