const path = require('path');
const withErrorHandling = require('../middleware/serviceHandler');
const DeleteUserData = require('../models/deleteUserDataRequests');
const CronHistory = require('../models/cronHistoryModel');
const { deleteFile, getPathToUpload } = require('../utils/upload');
const logger = require('../logger');

exports.addNewJobToQueue = withErrorHandling(async (payload) => {
  const { userId, type } = payload;
  const isExistsRecord = DeleteUserData.findOne({
    userId,
  });
  const isExistsHistory = CronHistory.findOne({
    userId,
    status: false,
    rollBackFinalStatus: false,
  });
  const [existingRecord, existingHistory] = await Promise.all([
    isExistsRecord,
    isExistsHistory,
  ]);
  if (!existingRecord && !existingHistory) {
    const jobData = new DeleteUserData({
      userId,
      type,
      ...(process.env.CRON_ENV && { env: process.env.CRON_ENV }),
    });
    return jobData.save();
  }
  return false;
});

exports.getOneJob = withErrorHandling(async (jobId, retryFailure) => {
  // const modelName = retryFailure ? CronHistory : DeleteUserData;
  // logger.info(`modelName...........${modelName}`);
  // const jobData = await modelName.findById(jobId);
  // logger.info(`Get One Job...........${JSON.stringify(jobData)}`);
  // return jobData;
  let jobData;
  logger.info(`retryFailure...........${retryFailure}`);
  if (retryFailure) {
    logger.info(`Fetching from CronHistory`);
    jobData = await CronHistory.findById(jobId);
  } else {
    logger.info(`Fetching from DeleteUserData`);
    jobData = await DeleteUserData.findById(jobId);
  }
  return jobData;
});

exports.getJobsList = withErrorHandling(async () =>
  DeleteUserData.find({
    ...(process.env.CRON_ENV ? { env: process.env.CRON_ENV } : null),
    isRunning: false,
  }).sort({
    priority: 0,
  })
);

exports.removeJobFromQueue = withErrorHandling(async (payload) => {
  logger.info(`payload of removeJobFromQueue: ${JSON.stringify(payload)}`);
  const { userId, type, cronStatus } = payload;
  const jobToBeRemoved = await DeleteUserData.findOne({
    userId,
    type,
  });
  const { rollBackFinalStatus } = jobToBeRemoved;
  if (type === 2 && (cronStatus === true || rollBackFinalStatus === true)) {
    // Delete file with user-data
    const filePath = path.join(
      __dirname,
      getPathToUpload('/auto-sync'),
      `${userId}.txt`
    );
    await deleteFile(filePath);
  }
  const removedJob = await DeleteUserData.deleteOne({
    userId,
    type,
  });
  return !!(!removedJob?.error && removedJob?.deletedCount);
});

exports.updateJob = withErrorHandling(async (payload) => {
  const {
    jobId,
    userId,
    type,
    isRunning,
    isHubSpotSync,
    rollBackHubspotStatus,
    rollBackHubspotDBStatus,
    isBlockChainSync,
    blockChainTransId,
    rollBackBlockchainStatus,
    sharedDataBackup,
    rollBackFinalStatus,
    session,
    retryFailure,
    priority,
    logs,
  } = payload;

  const isExistsRecord = retryFailure
    ? await CronHistory.findById(jobId)
    : await DeleteUserData.findOne({ userId, type });

  if (!isExistsRecord) {
    return false;
  }

  const fieldsToUpdate = {
    isRunning,
    isHubSpotSync,
    rollBackHubspotStatus,
    rollBackHubspotDBStatus,
    isBlockChainSync,
    blockChainTransId,
    rollBackBlockchainStatus,
    sharedDataBackup,
    rollBackFinalStatus,
    priority,
  };

  // eslint-disable-next-line no-restricted-syntax
  for (const [key, value] of Object.entries(fieldsToUpdate)) {
    if (value !== undefined) {
      isExistsRecord[key] = value;
    }
  }

  if (logs !== undefined) {
    isExistsRecord.logs.push(...logs.map(JSON.stringify));
  }

  return isExistsRecord.save({ session });
});

exports.updateHubSpotSyncStatus = withErrorHandling(async (payload) => {
  const { jobId, userId, type, organizationId, status, retryFailure } = payload;
  let isExistsRecord;
  if (retryFailure) {
    isExistsRecord = await CronHistory.findById(jobId);
  } else {
    isExistsRecord = await DeleteUserData.findOne({
      userId,
      type,
    });
  }
  if (!isExistsRecord) {
    return false;
  }
  isExistsRecord.hubSpotSyncUpdate.set(organizationId, status);
  return isExistsRecord.save();
});

exports.updateBlockchainSyncStatus = withErrorHandling(
  async ({ cronId: _id, isBlockChainSync, blockChainTransId }) => {
    const updatedRecord = await DeleteUserData.findOneAndUpdate(
      { _id },
      { $set: { isBlockChainSync, blockChainTransId } },
      { new: true }
    );
    if (!updatedRecord) {
      return false;
    }
    return updatedRecord;
  }
);

// Update new created records hubspot id (Rollback)
exports.updateHubSpotRollbackId = withErrorHandling(async (payload) => {
  const { jobId, userId, type, organizationId, hubspotId, retryFailure } =
    payload;
  let isExistsRecord;
  if (retryFailure) {
    isExistsRecord = await CronHistory.findById(jobId);
  } else {
    isExistsRecord = await DeleteUserData.findOne({
      userId,
      type,
    });
  }
  if (!isExistsRecord) {
    return false;
  }
  isExistsRecord.rollBackHubspotIds.set(organizationId, hubspotId);
  return isExistsRecord.save();
});

exports.getDeleteJobByUserId = withErrorHandling(
  async ({ userId, selectString }) => {
    if (userId) {
      return DeleteUserData.findOne({
        userId,
      }).select(selectString);
    }
    return null;
  }
);
