const SecurityQuestion = require('../models/securityQuestionModel');
const withErrorHandling = require('../middleware/serviceHandler');

exports.getSecurityQuestionsList = withErrorHandling(
  async ({ where, selectString }) => {
    const whereCondition = where || {};

    // Query the documents
    const query = SecurityQuestion.find(whereCondition).select(selectString);
    return query.exec();
  }
);
