const withErrorHandling = require('../middleware/serviceHandler');
const CronHistory = require('../models/cronHistoryModel');

exports.addJobToHistory = withErrorHandling(async (payload, cronStatus) => {
  const {
    userId,
    type,
    isHubSpotSync,
    hubSpotSyncUpdate,
    rollBackHubspotIds,
    rollBackHubspotStatus,
    rollBackHubspotDBStatus,
    isBlockChainSync,
    blockChainTransId,
    priority,
    rollBackBlockchainStatus,
    sharedDataBackup,
    rollBackFinalStatus,
    env,
    logs,
  } = payload;
  const jobData = new CronHistory({
    userId,
    type,
    isRunning: false,
    isHubSpotSync,
    hubSpotSyncUpdate,
    isBlockChainSync,
    rollBackHubspotIds,
    rollBackHubspotStatus,
    rollBackHubspotDBStatus,
    blockChainTransId,
    priority,
    rollBackBlockchainStatus,
    sharedDataBackup,
    rollBackFinalStatus,
    env,
    logs,
    ...(cronStatus !== undefined ? { status: cronStatus } : false),
  });
  return jobData.save();
});

exports.getJobHistoryList = withErrorHandling(async (payload) => {
  const { failedJobs } = payload;
  return CronHistory.find({
    ...(process.env.CRON_ENV ? { env: process.env.CRON_ENV } : null),
    ...(failedJobs
      ? {
          status: false,
          rollBackFinalStatus: false,
        }
      : null),
  }).sort({
    priority: 1,
  });
});

exports.getJobHistoryStream = withErrorHandling(async (payload) => {
  const { failedJobs } = payload;
  return CronHistory.find({
    ...(process.env.CRON_ENV ? { env: process.env.CRON_ENV } : null),
    ...(failedJobs
      ? {
          status: false,
          rollBackFinalStatus: false,
          isRunning: false,
        }
      : null),
  })
    .sort({
      priority: 1,
    })
    .cursor();
});

exports.deleteJobsFromHistory = withErrorHandling(async (createdDate) =>
  CronHistory.deleteMany({
    createdAt: {
      $lt: createdDate,
    },
  })
);

exports.getAllCronHistory = withErrorHandling(
  async (eventPipeline, skip, limit) => {
    // Count total number of documents
    const totalCount = await CronHistory.aggregate(eventPipeline);

    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount.length / limit);

    // Event Pipeline the documents
    const data = await CronHistory.aggregate(eventPipeline)
      .skip(skip)
      .limit(limit);

    // Handle pagination
    // if (skip && typeof skip === 'number') {
    //   data.skip(skip);
    // }
    // if (limit && typeof limit === 'number') {
    //   data.limit(limit);
    // }
    // Execute the query
    // const cronHistory = await data.exec();

    return {
      data,
      pageInfo: {
        totalCount: totalCount.length,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);
