const axios = require('axios');
const moment = require('moment-timezone');
const mailConstants = require('../config/constants/mailOptions');
const { sendErrorLogs } = require('../helpers/emailServices');
const userRoles = require('../config/constants/userRoles');
const {
  encryptWithBlockchainKey,
  decryptWithBlockchainKey,
} = require('../helpers/cryptoHelper');

exports.processEncryptionField = async (
  field,
  blockchainKey,
  blockchainIV,
  isEncryption
) => {
  const processFunc = isEncryption
    ? encryptWithBlockchainKey
    : decryptWithBlockchainKey;
  const fieldString = isEncryption ? JSON.stringify(field) : field;
  return processFunc(fieldString, blockchainKey, blockchainIV);
};

exports.encryptOrDecryptTransactions = async (
  transactions,
  encryptionStatus = false
) => {
  const blockchainKey = process.env.BLOCKCHAIN_ENCRYPTION_KEY;
  const blockchainIV = process.env.BLOCKCHAIN_ENCRYPTION_IV;

  try {
    const processedTransactions = await Promise.all(
      transactions.map(async (transaction) => {
        if (encryptionStatus) {
          // Processing when encryptionStatus is true
          const updatedParameter = await this.processEncryptionField(
            transaction.updated_parameter,
            blockchainKey,
            blockchainIV,
            encryptionStatus
          );
          const messages = await this.processEncryptionField(
            transaction.messages,
            blockchainKey,
            blockchainIV,
            encryptionStatus
          );
          return {
            ...transaction,
            updated_parameter: updatedParameter,
            messages,
          };
        }

        // Processing when encryptionStatus is false
        const updatedData = await this.processEncryptionField(
          transaction.Record.updatedData,
          blockchainKey,
          blockchainIV,
          encryptionStatus
        );
        const messages = await this.processEncryptionField(
          transaction.Record.messages,
          blockchainKey,
          blockchainIV,
          encryptionStatus
        );
        return {
          Key: transaction.Key,
          Record: {
            ...transaction.Record,
            updatedData,
            messages,
          },
        };
      })
    );

    return {
      status: true,
      result: processedTransactions,
    };
  } catch (error) {
    return {
      status: false,
      result: [],
    };
  }
};

exports.generateBlockChainToken = async (countryCode, mobileNumber) => {
  if (process.env.PROTOCOL === 'http') {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  }
  try {
    const response = await axios.post(
      `${process.env.BLOCKCHAIN_API_URL}/v1/auth/login`,
      {
        mobile_number: mobileNumber,
        country_code: countryCode,
      },
      {
        headers: {
          accept: '*/*',
          'X-API-KEY': `${process.env.BLOCKCHAIN_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    if (response?.status >= 200 && response?.status < 300) {
      return response.data?.access_token || null;
    }
    return null;
  } catch (error) {
    console.error('API Error:', error.message);
    if (error.response && error.response.status === 404) {
      return false;
    }
    return null;
  } finally {
    if (process.env.PROTOCOL === 'http') {
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
    }
  }
};

exports.makeLabels = async (data) => {
  const labels = [];
  const addLabels = (items, prefix) => {
    items.forEach((item, index) => {
      if (item !== '') {
        labels.push(`${prefix}${index + 1}`);
      }
    });
  };

  if (data.firstName !== '' && data.firstName !== undefined) {
    labels.push('firstName');
  }

  if (data.lastName !== '' && data.lastName !== undefined) {
    labels.push('lastName');
  }

  // Add mobile numbers to labels
  addLabels(data.mobileNumbers, 'mobileNumber');

  // Add emails to labels
  addLabels(data.emails, 'email');

  // Add addresses to labels
  addLabels(data.address, 'address');

  // Add social media links to labels
  if (data.social.linkedin !== '' && data.social.linkedin !== undefined) {
    labels.push('linkedin');
  }
  if (data.social.twitter !== '' && data.social.twitter !== undefined) {
    labels.push('twitter');
  }

  return labels;
};

exports.revokedData = async (sharedData, dataToShare) =>
  dataToShare
    .filter(
      ({ type, value, old_value }) =>
        sharedData.includes(type) && value === '' && old_value !== ''
    )
    .map(({ type }) => type);

exports.removedLabels = (previousData, newData) =>
  previousData.filter((item) => !newData.includes(item));

exports.replacePDFWords = (message) => {
  const replaceWords = {
    MobileNumber: 'mobile number',
    mobileNumber1: 'mobile number 1',
    mobileNumber2: 'mobile number 2',
    mobileNumber3: 'mobile number 3',
    mobileNumber4: 'mobile number 4',
    mobileNumber5: 'mobile number 5',
    Email: 'email',
    email1: 'email 1',
    email2: 'email 2',
    email3: 'email 3',
    email4: 'email 4',
    email5: 'email 5',
    Address: 'address',
    address1: 'address 1',
    address2: 'address 2',
    address3: 'address 3',
    address4: 'address 4',
    address5: 'address 5',
    linkedin: 'LinkedIn',
    twitter: 'Twitter',
    firstName: 'first name',
    lastName: 'last name',
  };
  // eslint-disable-next-line no-restricted-syntax
  for (const [word, replacement] of Object.entries(replaceWords)) {
    const regex = new RegExp(`\\b${word}\\b`, 'g');

    if (Array.isArray(message)) {
      message = message.map((words) => words.replace(regex, replacement));
    } else {
      message = message.replace(regex, replacement);
    }
  }
  return message;
};

exports.removeExactWord = (str, wordToRemove) => {
  // Escape special characters in the word to remove for use in the regular expression
  const escapedWord = wordToRemove.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Create a regular expression to match the word as a whole word
  const regex = new RegExp(`\\b${escapedWord}\\b`, 'gi');
  // Replace the word with an empty string and clean up extra spaces
  return str
    .replace(regex, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
};

exports.replaceExactWord = (text, oldWord, newWord) => {
  const escapedOldWord = oldWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedOldWord}\\b`, 'g');
  return text.replace(regex, newWord);
};

exports.removeOrganizationName = (message) => {
  const regex = /with[^]*?under/i;
  return message.replace(regex, 'under').trim();
};

exports.truncateMessage = (searchString, msg) => {
  const index = msg.indexOf(searchString);
  return index !== -1
    ? msg.slice(0, index + searchString.length - searchString.length)
    : msg;
};

exports.replaceWordsInMessage = (
  message,
  userType,
  consentRequestor,
  replaceText = false,
  isNotification = false
) => {
  const baseReplaceWords = {
    MobileNumber: 'mobile number',
    mobileNumber1: 'mobile number 1',
    mobileNumber2: 'mobile number 2',
    mobileNumber3: 'mobile number 3',
    mobileNumber4: 'mobile number 4',
    mobileNumber5: 'mobile number 5',
    Email: 'email',
    email1: 'email 1',
    email2: 'email 2',
    email3: 'email 3',
    email4: 'email 4',
    email5: 'email 5',
    'email 1': 'email 1',
    'email 2': 'email 2',
    'email 3': 'email 3',
    'email 4': 'email 4',
    'email 5': 'email 5',
    Address: 'address',
    address1: 'address 1',
    address2: 'address 2',
    address3: 'address 3',
    address4: 'address 4',
    address5: 'address 5',
    'address 1': 'address 1',
    'address 2': 'address 2',
    'address 3': 'address 3',
    'address 4': 'address 4',
    'address 5': 'address 5',
    linkedin: 'LinkedIn',
    twitter: 'Twitter',
    firstName: 'first name',
    lastName: 'last name',
  };

  let replaceWords = isNotification
    ? Object.fromEntries(
        Object.entries(baseReplaceWords).map(([key, value]) => [
          key,
          value.charAt(0).toUpperCase() + value.slice(1),
        ])
      )
    : { ...baseReplaceWords };

  // Add user-specific replace words
  if (replaceText) {
    const userSpecificReplaceWords = {
      'You have deleted your account': 'This user has deleted account',
      'You have blocked':
        userType === userRoles.SUPER_ADMIN
          ? 'This user has blocked'
          : 'This user has blocked you',
      'You have unblocked':
        userType === userRoles.SUPER_ADMIN
          ? 'This user has unblocked'
          : 'This user has unblocked you',
      'Your data has been shared': 'This user has shared data',
      'Accepted the request': 'This user had accepted the request',
      'Rejected the request': 'This user had rejected the request',
      Revoke: 'This user had removed',
      Revoked: 'This user had removed',
      Removed: 'This user had removed',
      Shared: 'This user has shared',
      Unshared: 'This user has removed',
    };
    replaceWords = { ...replaceWords, ...userSpecificReplaceWords };
  }

  // eslint-disable-next-line no-restricted-syntax
  for (const [word, replacement] of Object.entries(replaceWords)) {
    const regex = new RegExp(`\\b${word}\\b`, 'g');
    if (Array.isArray(message)) {
      message = message.map((words) => words.replace(regex, replacement));
    } else {
      message = message.replace(regex, replacement);
    }
  }

  if (userType !== userRoles.SUPER_ADMIN) {
    const transformMessage = (msg) => {
      let transformedMsg = this.truncateMessage(
        `with ${consentRequestor}`,
        msg
      );
      transformedMsg = this.replaceExactWord(
        transformedMsg,
        `you ${consentRequestor} organisation`,
        'you'
      );
      transformedMsg = this.replaceExactWord(
        transformedMsg,
        `for ${consentRequestor}`,
        ''
      );
      transformedMsg = this.replaceExactWord(
        transformedMsg,
        `${consentRequestor} wants to access your`,
        'You requested access for'
      );
      return transformedMsg;
    };

    message = Array.isArray(message)
      ? message.map(transformMessage)
      : transformMessage(message);
  }

  return message;
};

exports.replaceWordsInTransactions = async (
  transactions,
  userType,
  isBlockChain,
  replaceText = false
) => {
  transactions.forEach((transaction) => {
    const targetMessage = isBlockChain
      ? transaction.Record?.messages
      : transaction.message;

    const consentRequestor = transaction?.Record?.consentRequestor || 'None';

    if (targetMessage) {
      if (isBlockChain) {
        // eslint-disable-next-line no-param-reassign
        transaction.Record.messages = this.replaceWordsInMessage(
          // targetMessage.map((data) => data),
          targetMessage,
          userType,
          consentRequestor,
          replaceText
        );
      } else {
        // eslint-disable-next-line no-param-reassign
        transaction.message = this.replaceWordsInMessage(
          // targetMessage.map((data) => data),
          targetMessage,
          userType,
          consentRequestor,
          replaceText
        );
      }
    }
  });

  return transactions;
};

exports.makeBlockchainRequest = async (
  endpoint,
  method = 'GET',
  params = {},
  headers = {},
  data = {},
  accessToken = null
) => {
  if (process.env.PROTOCOL === 'http') {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  }
  try {
    const axiosConfig = {
      method,
      url: `${process.env.BLOCKCHAIN_API_URL}${endpoint}`,
      params,
      data,
      headers: {
        accept: '*/*',
        'X-API-KEY': process.env.BLOCKCHAIN_API_KEY,
        'Content-Type': 'application/json',
        ...headers,
      },
    };

    // Add Authorization header if accessToken is provided
    if (accessToken) {
      axiosConfig.headers.Authorization = `Bearer ${accessToken}`;
    }

    const response = await axios(axiosConfig);
    return response;
  } catch (error) {
    console.error('Error making API request:', error.message);
    throw error;
  } finally {
    if (process.env.PROTOCOL === 'http') {
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
    }
  }
};

exports.getBlockchainRequestParams = (query) => {
  const {
    page_size = 10,
    organization_name,
    log_type,
    permission_status,
    start_date,
    end_date,
    bookmark,
    search,
    mobile_number,
    sort_order = 'desc',
  } = query;

  let countryCode;
  let extractedMobileNumber;

  if (mobile_number) {
    const parts = mobile_number.split(' ');

    if (parts.length === 2 && parts[0].startsWith('+')) {
      // If there is a space and the first part starts with '+', treat it as a country code
      countryCode = parts[0].substring(1); // Remove '+'
      // eslint-disable-next-line prefer-destructuring
      extractedMobileNumber = parts[1];
    } else if (!mobile_number.startsWith('+')) {
      // If there's no '+' at the start, consider the whole input as a mobile number
      extractedMobileNumber = mobile_number;
    } else {
      // If the input starts with '+', but no space, consider it as a full mobile number
      extractedMobileNumber = mobile_number;
    }
  }

  return {
    page_size,
    isIndividualLog: false,
    ...(organization_name !== undefined && {
      consent_requestor: organization_name,
    }),
    ...(log_type !== undefined && { log_type }),
    ...(permission_status !== undefined && { permission_status }),
    ...(start_date !== undefined && { startDate: start_date }),
    ...(end_date !== undefined && { endDate: end_date }),
    ...(bookmark !== undefined && { bookmark }),
    ...(sort_order !== undefined && { sortOrder: sort_order }),
    ...(search !== undefined && { message_search: search }),
    ...(extractedMobileNumber !== undefined && {
      mobile_number: extractedMobileNumber,
    }),
    ...(countryCode !== undefined && { countryCode }), // Country code without '+'
  };
};

exports.fetchAndTransformTransactions = async (payload) => {
  let transformedTransactions = [];
  const params = this.getBlockchainRequestParams(payload);
  const transactions = await this.makeBlockchainRequest(
    '/v1/adf/getAllRecordsForAdmin',
    'GET',
    params,
    {
      'x-admin-token': process.env.BLOCKCHAIN_ADMIN_TOKEN,
    },
    {}
  );

  const transactionBunch = transactions?.data?.data;

  if (transactionBunch.results && transactionBunch.results.length > 0) {
    //  Start: Decrypt transactions
    const decryptedTransactions = await this.encryptOrDecryptTransactions(
      transactionBunch.results
    );
    transactionBunch.results =
      decryptedTransactions.status && decryptedTransactions.result;
    // End: Decrypt transactions

    const transformedResults = await Promise.all(
      transactionBunch?.results.map(async (result) => {
        const record = result.Record;
        return {
          id: record.id,
          organization_name: record.consentRequestor,
          message: record.messages,
          log_type: record.logType,
          permission_status: record.permissionStatus,
          country_code: record.countryCode,
          mobile_number: record.mobileNumber,
          created_date: moment(record.createdAt).format('DD-MM-YYYY, hh:mm A'),
        };
      })
    );

    transformedTransactions = transformedResults;
  }

  return transformedTransactions;
};

exports.getMonthlyStatisticsCount = (monthArray) => {
  const result = {
    January: 0,
    February: 0,
    March: 0,
    April: 0,
    May: 0,
    June: 0,
    July: 0,
    August: 0,
    September: 0,
    October: 0,
    November: 0,
    December: 0,
  };

  return monthArray.reduce((acc, item) => {
    const month = item.month.trim();
    const count = parseInt(item.count, 10);

    if (acc.hasOwnProperty(month)) {
      acc[month] += count;
    }

    return acc;
  }, result);
};

exports.fetchStatisticsData = async (params) => {
  const defaultMonthList = {
    January: 0,
    February: 0,
    March: 0,
    April: 0,
    May: 0,
    June: 0,
    July: 0,
    August: 0,
    September: 0,
    October: 0,
    November: 0,
    December: 0,
  };

  try {
    const statistics = await this.makeBlockchainRequest(
      '/v1/statistics/chart',
      'GET',
      params,
      { 'x-admin-token': process.env.BLOCKCHAIN_ADMIN_TOKEN },
      {}
    );

    const statisticsData = this.getMonthlyStatisticsCount(
      statistics?.data?.data || []
    );

    return statisticsData;
  } catch (error) {
    return defaultMonthList;
  }
};

exports.generateAndUpdateBlockChainToken = async (
  countryCode,
  mobileNumber,
  userId,
  updateBlockChainToken
) => {
  try {
    const blockChainToken = await this.generateBlockChainToken(
      countryCode,
      mobileNumber
    );

    if (blockChainToken) {
      return (await updateBlockChainToken(userId, blockChainToken))
        ? blockChainToken
        : null;
    }

    return null;
  } catch (error) {
    return null;
  }
};

exports.makeBlockchainApiCallWithRetry = async (
  transactionBunch,
  blockChainToken,
  payload,
  maxRetryAttempts = 2,
  currentAttempt = 1
) => {
  const encryptedTransactions = await this.encryptOrDecryptTransactions(
    transactionBunch,
    true
  );

  if (!encryptedTransactions.status)
    throw new Error('Failed to encrypt transactions.');

  const { countryCode, mobileNumber, userId, updateBlockChainToken } = payload;
  let blockchainResult = [];
  let blockchainStatus = false;
  let blockchainError = null;

  try {
    const result = await this.makeBlockchainRequest(
      '/v1/adf/createAdfLog',
      'POST',
      {},
      {},
      encryptedTransactions.result,
      blockChainToken
    );

    // Handle success
    blockchainStatus = !result?.data?.isFailed;
    blockchainResult = result?.data?.data || [];
  } catch (error) {
    blockchainError = error?.response?.data?.message || error.message;
    if (error.response && error.response.status === 401) {
      if (currentAttempt <= maxRetryAttempts) {
        const token = await this.generateAndUpdateBlockChainToken(
          countryCode,
          mobileNumber,
          userId,
          updateBlockChainToken
        );

        if (token) {
          // Retry the API call with the new token (recursive call)
          return this.makeBlockchainApiCallWithRetry(
            transactionBunch,
            token,
            payload,
            maxRetryAttempts,
            currentAttempt + 1
          );
        }
      }
    }

    // Handle errors
    blockchainStatus = false;
    await sendErrorLogs({
      error,
      mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
    });
  }

  return {
    result: blockchainResult,
    status: blockchainStatus,
    error: blockchainError,
  };
};

exports.rollbackBlockchainTransaction = async (
  transactionIds,
  userId,
  findUserById,
  updateBlockChainToken,
  maxRetryAttempts = 2,
  currentAttempt = 1
) => {
  let rollbackStatus = false;
  const user = await findUserById(userId);

  try {
    await this.makeBlockchainRequest(
      '/v1/adf/logs',
      'DELETE',
      {},
      {},
      { keys: transactionIds },
      user.blockChainToken
    );

    rollbackStatus = true;
  } catch (error) {
    if (error.response && error.response.status === 401) {
      if (currentAttempt <= maxRetryAttempts) {
        const token = await this.generateAndUpdateBlockChainToken(
          user.countryCode,
          user.mobileNumber,
          user._id,
          updateBlockChainToken
        );

        if (token) {
          return this.rollbackBlockchainTransaction(
            transactionIds,
            userId,
            findUserById,
            updateBlockChainToken,
            maxRetryAttempts,
            currentAttempt + 1
          );
        }
      }
    }

    rollbackStatus = false;
    await sendErrorLogs({
      error,
      mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
    });
  }
  return rollbackStatus;
};

exports.blockChainHealthStatus = async () => {
  let healthStatus = false;
  try {
    const response = await this.makeBlockchainRequest(
      '/v1/health/health',
      'GET'
    );
    healthStatus = response?.data === 1 || 0;
  } catch (error) {
    healthStatus = false;
  }
  return healthStatus;
};
