const moment = require('moment');
const path = require('path');
const { clearUserSharedData, findUserById } = require('./commonService');
const {
  deleteCRMRecord,
  updateCRMRecord,
  restoreCRMRecord,
} = require('./crmSettingService');
const {
  sendFirebaseNotification,
  calculateNotificationCount,
  removeAllNotification,
  getNotificationsData,
  generateAndSendNotification,
} = require('./notificationService');
const {
  getJobsList,
  removeJobFromQueue,
  updateHubSpotSyncStatus,
  updateBlockchainSyncStatus,
  updateJob,
  getOneJob,
} = require('./deleteUserDataService');
const {
  addJobToHistory,
  getJobHistoryStream,
  deleteJobsFromHistory,
} = require('./cronHistoryService');
const { sendTextMessage } = require('../helpers/twilioHelper');
const logger = require('../logger');
const {
  deleteUserAccount,
  updateBlockChainToken,
  updateUserConsentBulk,
  updateSharedData,
  findUser,
  findUserByMobile,
  removeBlockedOrganization,
} = require('./userService');
const {
  findSmsRecords,
  updateBulkSmsHistory,
} = require('./bulkSmsHistoryService');
const {
  makeBlockchainApiCallWithRetry,
  rollbackBlockchainTransaction,
} = require('./blockChainService');
const { getBlockOrganizationOfUser } = require('./blockOrganizationService');
const {
  getOrganizationById,
  removeBlockedUsers,
} = require('./organizationService');
const {
  getBlockOrganization,
  deleteBlockAllOrganization,
} = require('./blockOrganizationService');
const { generatePrivacyPolicy } = require('./privacyPolicyService');
const { getSettingsByUser } = require('./generalSettingService');
const { readFile, deleteFile, getPathToUpload } = require('../utils/upload');
const { addCronLog } = require('../utils/common');
const { decryptReqPayload } = require('../helpers/cryptoHelper');
const responseMessages = require('../config/constants/reponseMessages');
const userRoles = require('../config/constants/userRoles');
const requestStatus = require('../config/constants/requestStatus');
const { generateJWTSign } = require('../helpers/jwtHelper');

const readUserData = async (userId) => {
  const userEncryptedData = await readFile('/auto-sync', `${userId}.txt`);
  if (!userEncryptedData) {
    // DO:: Remove job from the queue and send a silent notification of failure
    logger.info(
      `No user data found inside the file. Jumping to the next cron job`
    );
    return false;
  }
  const decryptedUserData = await decryptReqPayload(userEncryptedData);
  if (!decryptedUserData?.shared_data) {
    // DO:: Remove job from the queue and send a silent notification of failure
    logger.info(
      `There is an error in decrypting user data. Jumping to the next cron job`
    );
    return false;
  }
  return decryptedUserData?.shared_data;
};

exports.createHubspotAPIPayload = async ({
  jobData,
  organizationId,
  dataToUpdate,
  dataFormatType,
}) => {
  const { userId } = jobData;
  const userData = await findUserById(userId);
  const resultObject = {
    organization_id: organizationId,
    mobile_numbers: [],
    emails: [],
    address: [],
    social: {},
  };
  const resultRollbackObject = {
    organization_id: organizationId,
    mobile_numbers: [],
    emails: [],
    address: [],
    social: {},
  };
  const sharedData = userData.sharedData.get(organizationId);
  if (sharedData || dataFormatType === 'share-data') {
    dataToUpdate.forEach(({ type, value, old_value }) => {
      const index = parseInt(type.replace(/[^\d]/g, ''), 10) - 1;
      // If the data is shared with the organization
      if (
        dataFormatType === 'share-data' ||
        (sharedData && sharedData.indexOf(type) !== -1)
      ) {
        if (type === 'firstName') {
          resultObject.firstName = value;
          resultRollbackObject.firstName = old_value;
        } else if (type === 'lastName') {
          resultObject.lastName = value;
          resultRollbackObject.lastName = old_value;
        } else if (type.startsWith('mobileNumber')) {
          resultObject.mobile_numbers[index] = value;
          resultRollbackObject.mobile_numbers[index] = old_value;
        } else if (type.startsWith('email')) {
          resultObject.emails[index] = value;
          resultRollbackObject.emails[index] = old_value;
        } else if (type.startsWith('address')) {
          resultObject.address[index] = value;
          resultRollbackObject.address[index] = old_value;
        } else if (type === 'linkedin') {
          resultObject.social.linkedin = value;
          resultRollbackObject.social.linkedin = old_value;
        } else if (type === 'twitter') {
          resultObject.social.twitter = value;
          resultRollbackObject.social.twitter = old_value;
        }
      }
    });
  }
  return {
    resultObject,
    resultRollbackObject,
  };
};

const removeJobFromQueueInCron = async (jobData, cronStatus) => {
  logger.info(
    `Job data to fetch the jobId and latest job data: ${JSON.stringify(
      jobData
    )}`
  );
  const { userId, type, _id: jobId } = jobData;
  let jobAddedToHistory;
  logger.info(`jobId to remove: ${jobId}`);
  const latestJobData = await getOneJob(jobId);
  if (latestJobData) {
    jobAddedToHistory = await addJobToHistory(latestJobData, cronStatus);
    logger.info(
      `Job added to the history ${JSON.stringify(jobAddedToHistory)}`
    );
    if (!jobAddedToHistory?.error) {
      logger.info(`removeJobFromQueue called from removeJobFromQueueInCron`);
      const jobRemoved = await removeJobFromQueue({
        userId,
        type,
        cronStatus,
      });
      logger.info(`Job Removed from the queue: ${userId} - ${type}`);
      if (jobRemoved?.error) {
        logger.error(
          `Error in removing the job from the queue: ${jobRemoved.error}`
        );
      }
    }
  }
};

const sendFirebaseNotificationInCron = async (jobData, payload) => {
  const { userId, type } = jobData;
  const { notificationStatus, requestCount } = payload;
  let successNotificationMessage;
  let failureNotificationMessage;
  let notificationTitle;
  let finalNotificationMessage;
  if (type === 0) {
    successNotificationMessage = responseMessages.CRON_ORGANIZATIONS_DELETED;
    failureNotificationMessage =
      responseMessages.CRON_ORGANIZATIONS_DELETED_FAIL;
    notificationTitle = responseMessages.CRON_ORGANIZATIONS_DELETED_TITLE;
  } else if (type === 1) {
    successNotificationMessage = responseMessages.CRON_ACCOUNT_DELETED;
    failureNotificationMessage = responseMessages.CRON_ACCOUNT_DELETED_FAIL;
    notificationTitle = responseMessages.CRON_ACCOUNT_DELETED_TITLE;
  } else if (type === 2) {
    finalNotificationMessage = notificationStatus
      ? responseMessages.CRON_AUTO_SYNC_SUCCESS
      : responseMessages.CRON_AUTO_SYNC_FAIL;

    successNotificationMessage = responseMessages.CRON_AUTO_SYNC;
    failureNotificationMessage = responseMessages.CRON_AUTO_SYNC_FAIL;
    notificationTitle = responseMessages.CRON_AUTO_SYNC_TITLE;
  } else if (type === 11) {
    successNotificationMessage = responseMessages.CRON_REQUEST_REMINDER.replace(
      'REQUEST_COUNT',
      requestCount
    );
    failureNotificationMessage = responseMessages.CRON_REQUEST_REMINDER_FAIL;
    notificationTitle = responseMessages.CRON_REQUEST_REMINDER_TITLE;
  }

  const notification = await sendFirebaseNotification({
    client_id: userId,
    silent: 'false',
    title: notificationTitle,
    body:
      notificationStatus === true
        ? successNotificationMessage
        : failureNotificationMessage,
    extra_data: {
      status: notificationStatus,
      type,
      ...(type === 2 ? { message: finalNotificationMessage } : {}),
    },
  });
  return notification;
};

const rollBackCronJob = async (
  jobData,
  rollbackData,
  retryFailure,
  logData
) => {
  const { userId, type: operationType, _id: jobId } = jobData;
  try {
    logger.info(`Doing rollback: ${userId} & operation-type: ${operationType}`);
    logger.info(`retryFailure Flag: ${retryFailure}`);
    logger.info(`jobId (rollBackCronJob): ${jobId}`);
    const latestJobData = await getOneJob(jobId, retryFailure);
    logger.info(`latestJobData: ${JSON.stringify(latestJobData)}`);
    if (!latestJobData) {
      logger.info(`Returning false due to lack of latestJobData`);
      addCronLog(logData, {
        message: `Starting the process of removing blockchain transactions.`,
        data: {
          latestJobData,
        },
      });
      return false;
    }
    // throw new Error('My custom throw');
    // Blockchain transaction rollback
    const {
      isBlockChainSync,
      blockChainTransId,
      sharedDataBackup,
      rollBackBlockchainStatus,
    } = latestJobData;
    if (
      isBlockChainSync &&
      blockChainTransId.length > 0 &&
      rollBackBlockchainStatus === false
    ) {
      addCronLog(logData, {
        message: `Starting the process of removing blockchain transactions.`,
        data: {
          blockChainTransId,
        },
      });
      const rollbackStatus = await rollbackBlockchainTransaction(
        blockChainTransId,
        userId,
        findUserById,
        updateBlockChainToken
      );
      if (rollbackStatus) {
        addCronLog(logData, {
          message: `The process of removing blockchain transactions has been executed successfully.`,
          data: {
            blockChainTransId,
          },
        });
        await updateJob({
          jobId,
          userId,
          type: operationType,
          isBlockChainSync: false,
          blockChainTransId: [],
          rollBackBlockchainStatus: true,
          retryFailure,
        });
      } else {
        addCronLog(logData, {
          message: `The process of removing blockchain transactions has failed`,
        });
        throw new Error('Blockchain rollback process failed!');
      }
    }

    // Restore CRM Records
    const restoreRecords = await restoreCRMRecord(
      latestJobData,
      rollbackData,
      retryFailure,
      logData
    );
    logger.info(`CRM Rollback Final Result ----- ${restoreRecords}`);
    if (!restoreRecords?.error && restoreRecords) {
      // Restore shared data
      const restoreStatus = await updateSharedData(userId, sharedDataBackup);
      // Update a rollback flag to success or failure
      if (restoreStatus) {
        addCronLog(logData, {
          message: `User data has been restored successfully in the database.`,
          data: {
            result: restoreStatus,
          },
        });
        await updateJob({
          jobId,
          userId,
          type: operationType,
          rollBackFinalStatus: true,
          retryFailure,
        });
        return true;
      }
      addCronLog(logData, {
        message: `The process of restoring user data in the database has failed.`,
        data: {
          result: restoreStatus,
        },
        error: restoreStatus,
      });
    }
    addCronLog(logData, {
      message: `Error in the process of CRM data rollback.`,
      data: {
        result: restoreRecords,
      },
      error: restoreRecords,
    });
    return false;
  } catch (error) {
    logger.error(`Error in doing rollback: ${error}`);
    addCronLog(logData, {
      message: `Error in the process of rollback.`,
      error,
    });
    return false;
  }
};

const executeRollBack = async (jobData, rollbackData, logData) => {
  const { userId, type } = jobData;
  logger.info(`Doing rollback: ${userId} - ${type}`);
  addCronLog(logData, {
    message: `Start processing of rollback operation.`,
    data: {
      jobData,
      rollbackData,
    },
  });
  // await updateJob({ userId, type, logs: logData });
  const rollbackResultStatus = await rollBackCronJob(
    jobData,
    rollbackData,
    undefined,
    logData
  );
  logger.info(`Rollback Status: ${rollbackResultStatus}`);
  logger.info(`Removing job called from the executeRollBack()`);
  // const cronLogs = [];
  addCronLog(logData, {
    message: `Removing job data from the job list.`,
    data: {
      jobData,
    },
  });
  if (rollbackResultStatus) {
    addCronLog(logData, {
      message: `Rollback operation has been performed successfully.`,
      data: {
        result: rollbackResultStatus,
      },
    });
    const notification = await sendFirebaseNotificationInCron(jobData, {
      notificationStatus: false,
    });

    if (!notification?.status) {
      addCronLog(logData, {
        message: `Failed to send notification.`,
        data: {
          result: notification.status,
        },
        error: notification?.error,
      });
    }
  }
  await updateJob({ userId, type, logs: logData });
  logger.info(`removeJobFromQueueInCron is called from executeRollBack.`);
  await removeJobFromQueueInCron(jobData, false);
};

const executeCronSuccess = async (jobData, logData) => {
  const { userId, type } = jobData;
  await updateJob({ userId, type, logs: logData });
  logger.info(`Cron Success: ${userId} - ${type}`);
  logger.info(`removeJobFromQueueInCron is called from executeCronSuccess.`);
  await removeJobFromQueueInCron(jobData, true);
  const notification = await sendFirebaseNotificationInCron(jobData, {
    notificationStatus: true,
  });

  if (!notification?.status) {
    addCronLog(logData, {
      message: `Failed to send notification.`,
      data: {
        result: notification.status,
      },
      error: notification?.error,
    });
  }
};

const handleBatchOfCronFailures = async (batchOfRecords) => {
  batchOfRecords.forEach(async (queueItem) => {
    const cronLogs = [];
    const { _id: jobId, userId, type: operationType, priority } = queueItem;
    // Lock the user data to process failure so that it doesn't conflict with the another instance of a cron.
    await updateJob({
      jobId,
      userId,
      type: operationType,
      isRunning: true,
      retryFailure: true,
    });
    addCronLog(cronLogs, {
      message: `Start processing of failed cron job.`,
      data: {
        jobData: queueItem,
      },
    });
    const rollbackData = {};
    if (operationType === 2) {
      const userData = await findUserById(userId);
      const { trustedOrganizations } = userData;
      const dataToUpdate = await readUserData(userId);
      if (dataToUpdate) {
        await Promise.all(
          trustedOrganizations.map(async (trustedOrganizationId) => {
            const { resultRollbackObject } = await this.createHubspotAPIPayload(
              {
                jobData: queueItem,
                organizationId: trustedOrganizationId,
                dataToUpdate,
              }
            );
            rollbackData[trustedOrganizationId] = resultRollbackObject;
          })
        );
      } else {
        logger.error(
          `No user data found while handling failed jobs: ${JSON.stringify(
            queueItem
          )}`
        );
      }
    }
    const rollBackAttempStatus = await rollBackCronJob(
      queueItem,
      rollbackData,
      true,
      cronLogs
    );
    if (rollBackAttempStatus === true) {
      if (operationType === 2) {
        // Delete file with user-data
        const filePath = path.join(
          __dirname,
          getPathToUpload('/auto-sync'),
          `${userId}.txt`
        );
        await deleteFile(filePath);
      }
      addCronLog(cronLogs, {
        message: `The process of executing failed cron job has been performed successfully.`,
        data: {
          result: rollBackAttempStatus,
        },
      });
      // Send rollback success notification to the user
      const notification = await sendFirebaseNotificationInCron(queueItem, {
        notificationStatus: false,
      });

      if (!notification?.status) {
        addCronLog(cronLogs, {
          message: `Failed to send notification.`,
          data: {
            result: notification.status,
          },
          error: notification?.error,
        });
      }
    }
    if (!rollBackAttempStatus) {
      // Update priority of the job
      addCronLog(cronLogs, {
        message: `The process of executing failed cron job has failed ${
          priority + 1
        } times.`,
        data: {
          result: rollBackAttempStatus,
          priority,
          jobId,
        },
      });
      // Unlock the user data so that cron can process it again. Update priority of the job
      await updateJob({
        jobId,
        userId,
        isRunning: false,
        type: operationType,
        priority: priority + 1,
        retryFailure: true,
      });
    }
    logger.info(`rollBackAttempStatus: ${rollBackAttempStatus}`);
    await updateJob({
      jobId,
      userId,
      operationType,
      retryFailure: true,
      logs: cronLogs,
    });
  });
};

exports.deleteUserDataCron = async () => {
  // Read Queue
  const cronLogs = [];
  const QueueList = await getJobsList();

  if (QueueList.length > 0) {
    QueueList.forEach(async (queueItem) => {
      const autoSyncRollbackData = {};
      try {
        const { userId: id, type: operationType, _id: cronId } = queueItem;
        // Lock the user operation so that it doesn't conflict with the another running instance of cron.
        await updateJob({
          userId: id,
          type: operationType,
          isRunning: true,
        });
        addCronLog(cronLogs, {
          message: `Start processing the cron job.`,
          data: {
            jobData: queueItem,
          },
        });
        const userData = await findUserById(id);
        addCronLog(cronLogs, {
          message: `Processing the cron job for the user +${userData?.countryCode}${userData?.mobileNumber}`,
          data: {
            userData,
          },
        });
        const {
          _id: userId,
          trustedOrganizations,
          countryCode,
          mobileNumber,
          blockChainToken,
          sharedData: userSharedData,
        } = userData;

        /* Take backup of shared data */
        await updateJob({
          userId: id,
          type: operationType,
          sharedDataBackup: userSharedData,
        });
        addCronLog(cronLogs, {
          message: `Took backup of users's shared data labels with the trusted organizations`,
          data: {
            userSharedData,
          },
        });

        const trustedOrgCount = trustedOrganizations?.length ?? 0;
        addCronLog(cronLogs, {
          message: `Found ${trustedOrgCount} Trusted Organizations.`,
          data: {
            count: trustedOrgCount,
          },
        });

        const transactions = [];
        const organizationIds = [];
        let transactionStatus = false;

        logger.info(
          `Processing Cron Job: ${queueItem && JSON.stringify(queueItem)}`
        );
        // If trusted organization found, perform the operations
        if (trustedOrgCount) {
          logger.info(
            `Trusted organization found: ${userId} - ${userData?.mobileNumber}`
          );
          if (operationType === 2) {
            const dataToShare = [];
            const dataToUpdate = await readUserData(userId);
            const trustedOrganizationsPromises = trustedOrganizations.map(
              async (trustedOrganizationId) => {
                const sharedData = userData.sharedData.get(
                  trustedOrganizationId
                );
                const { resultObject, resultRollbackObject } =
                  await this.createHubspotAPIPayload({
                    jobData: queueItem,
                    organizationId: trustedOrganizationId,
                    dataToUpdate,
                  });

                const shouldUpdateCRM =
                  resultObject &&
                  (resultObject.firstName ||
                    resultObject.lastName ||
                    resultObject.mobile_numbers.length ||
                    resultObject.emails.length ||
                    resultObject.address.length ||
                    Object.keys(resultObject.social).length);

                if (shouldUpdateCRM) {
                  autoSyncRollbackData[trustedOrganizationId] =
                    resultRollbackObject;
                  addCronLog(cronLogs, {
                    message: `Processing auto sync of user's profile with one of trusted organizations.`,
                    data: {
                      organizationId: trustedOrganizationId,
                    },
                  });
                  const CRMRecordUpdated = await updateCRMRecord(
                    userData,
                    resultObject,
                    undefined,
                    cronLogs
                  );
                  await updateHubSpotSyncStatus({
                    userId: id,
                    type: operationType,
                    organizationId: trustedOrganizationId,
                    status: CRMRecordUpdated,
                  });

                  logger.info(
                    `Auto-sync of user-data with CRM - ${userId} - Result: ${CRMRecordUpdated}`
                  );

                  if (CRMRecordUpdated) {
                    const org = await getOrganizationById(
                      trustedOrganizationId
                    );

                    addCronLog(cronLogs, {
                      message: `Processing auto sync of user's profile with one of trusted organizations has been performed successfully.`,
                      data: {
                        organizationId: trustedOrganizationId,
                      },
                    });

                    const shareLabels = dataToUpdate
                      .filter((item) => item.value !== '')
                      .map((item) => item.type);
                    const revokeLabels = dataToUpdate
                      .filter((item) => item.value === '')
                      .map((item) => item.type);

                    const clonedSharedData = sharedData.filter(
                      (item) => !revokeLabels.includes(item)
                    );

                    if (shareLabels.length > 0) {
                      transactions.push({
                        log_type: 'consent',
                        permission_status: 'share',
                        consent_requestor: org?.name || 'Organization',
                        version: 1,
                        updated_parameter: shareLabels,
                        user_in_front: '',
                        messages: [
                          `Shared ${shareLabels.join(', ')} with ${org?.name || 'Organization'}`,
                        ],
                      });
                    }

                    if (revokeLabels.length > 0) {
                      transactions.push({
                        log_type: 'consent',
                        permission_status: 'revoke',
                        consent_requestor: org?.name || 'Organization',
                        version: 1,
                        updated_parameter: revokeLabels,
                        user_in_front: '',
                        messages: [
                          `Revoked ${revokeLabels.join(', ')} with ${org?.name || 'Organization'}`,
                        ],
                      });
                    }

                    const isSharedTransaction = transactions.some(
                      (item) =>
                        item.consent_requestor === org.name &&
                        item.permission_status === 'share'
                    );
                    if (isSharedTransaction) {
                      const policy = await generatePrivacyPolicy(org);
                      if (policy?.rule !== '') {
                        transactions.push({
                          log_type: 'consent',
                          permission_status: 'policy',
                          consent_requestor: org.name,
                          version: 1,
                          updated_parameter: [policy.rule],
                          user_in_front: '',
                          messages: [
                            `Your data has been shared with ${org.name} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`,
                          ],
                        });
                      }
                    }

                    dataToShare.push({
                      organizationId: org?._id.toString(),
                      updatedSharedData: clonedSharedData,
                    });
                  }
                  return CRMRecordUpdated;
                }
                logger.info(`Nothing to Update in CRM.`);
                return true;
              }
            );

            const dataUpdatedCRM = await Promise.all(
              trustedOrganizationsPromises
            );

            logger.info(
              `Auto-sync of user-data with CRM | Result - ${dataUpdatedCRM} - ${userId}`
            );

            if (dataUpdatedCRM.every((result) => result !== false)) {
              addCronLog(cronLogs, {
                message: `Processing auto sync of user's profile with all trusted organizations has been performed successfully.`,
                data: {
                  result: dataUpdatedCRM,
                },
              });

              await updateJob({
                userId: id,
                type: operationType,
                isHubSpotSync: true,
              });

              const startTime = new Date();
              logger.info(`Blockchain executed at: ${startTime}`);
              logger.info(`Started Blockchain API Call`);
              addCronLog(cronLogs, {
                message: `Starting the process of creating ${transactions.length} blockchain transactions.`,
                data: {
                  transactions,
                },
              });

              const blockchainResult = await makeBlockchainApiCallWithRetry(
                transactions,
                blockChainToken,
                { countryCode, mobileNumber, userId, updateBlockChainToken }
              );

              logger.info(`Finished Blockchain API Call`);
              const endTime = new Date();
              const elapsedTime = endTime - startTime;
              logger.info(`Blockchain took ${elapsedTime} milliseconds`);
              addCronLog(cronLogs, {
                message: `Blockchain took ${elapsedTime} milliseconds`,
              });

              transactionStatus = blockchainResult;
              logger.info(
                `Blockchain transaction finished | Result: ${transactionStatus?.status}`
              );

              if (transactionStatus?.status) {
                addCronLog(cronLogs, {
                  message: `Blockchain transactions have been created successfully.`,
                });

                const blockChainTransId =
                  transactionStatus?.result?.map(
                    (trans) => trans.blockchainLogId
                  ) || [];
                await updateBlockchainSyncStatus({
                  cronId,
                  isBlockChainSync: transactionStatus.status,
                  blockChainTransId,
                });

                const userConsentResult = await updateUserConsentBulk(
                  { _id: userId },
                  dataToShare
                );

                if (userConsentResult) {
                  logger.info(
                    `User shared data update in db | Result: ${transactionStatus}`
                  );
                  addCronLog(cronLogs, {
                    message: `User data is updated successfully in the database.`,
                  });

                  await executeCronSuccess(queueItem, cronLogs);
                  return;
                }

                addCronLog(cronLogs, {
                  message: `Error in updating user data in the database.`,
                  data: {
                    result: userConsentResult,
                  },
                  error: userConsentResult,
                });
              }

              addCronLog(cronLogs, {
                message: `Blockchain transactions creation process has failed.`,
                data: {
                  result: transactionStatus?.status,
                },
                error: transactionStatus?.error,
              });
            }

            throw new Error('Do rollback due to Auto-sync Failure!');
          } else if (operationType === 0 || operationType === 1) {
            const deletedUserData = await Promise.all(
              trustedOrganizations.map(async (trustedOrganizationId) => {
                logger.info(
                  `Removing trusted organization: ${trustedOrganizationId}`
                );
                addCronLog(cronLogs, {
                  message: `Removing one trusted organization from the list of user's trusted organizations`,
                  data: {
                    organizationId: trustedOrganizationId,
                  },
                });
                const deletedRecord = await deleteCRMRecord(userData, {
                  organizationId: trustedOrganizationId,
                  jobData: queueItem,
                  cronLogs,
                });
                logger.info(
                  `Removed CRM data: ${trustedOrganizationId} | Result: ${deletedRecord}`
                );
                if (deletedRecord === true) {
                  addCronLog(cronLogs, {
                    message: `CRM data of one of trusted organizations has been removed successfully.`,
                    data: {
                      organizationId: trustedOrganizationId,
                      result: deletedRecord,
                    },
                  });
                  const org = await getOrganizationById(trustedOrganizationId);
                  if (org && !org?.error) {
                    const sharedData = userData?.sharedData?.get(org._id) || [];
                    const requestDetailsString = sharedData.join(', ');
                    if (sharedData.length > 0) {
                      transactions.push({
                        log_type: 'consent',
                        permission_status: 'revoke',
                        consent_requestor: org.name,
                        version: 1,
                        updated_parameter: sharedData,
                        user_in_front: '',
                        messages: [
                          `Removed ${requestDetailsString} with ${org.name}`,
                        ],
                      });

                      organizationIds.push(trustedOrganizationId);
                    }
                  }
                  return organizationIds.some(
                    (orgId) => orgId === trustedOrganizationId
                  );
                }
                addCronLog(cronLogs, {
                  message: `The process of removing CRM data of one of trusted organizations has failed.`,
                  data: {
                    organizationId: trustedOrganizationId,
                    result: deletedRecord,
                  },
                });
                return false;
              })
            );

            logger.info(
              `Removed All CRM data: Final Result: ${deletedUserData} - ${deletedUserData.length} - ${trustedOrgCount}`
            );

            if (deletedUserData.every((result) => result !== false)) {
              await updateJob({
                userId: id,
                type: operationType,
                isHubSpotSync: true,
              });
              addCronLog(cronLogs, {
                message: `CRM data of all the trusted organizations has been removed successfully.`,
                data: {
                  result: deletedUserData,
                },
              });

              if (operationType === 1) {
                transactions.push({
                  log_type: 'consent',
                  permission_status: 'delete-my-account',
                  consent_requestor: '',
                  version: 1,
                  updated_parameter: ['accountDeletion'],
                  user_in_front: '',
                  messages: ['You have deleted your account'],
                });
              }

              logger.info(
                `Pass all transactions to blockchain : ${transactions && JSON.stringify(transactions)}`
              );
              addCronLog(cronLogs, {
                message: `Creating blockchain transactions.`,
                data: {
                  transactions,
                },
              });

              const startTime = new Date();
              logger.info(`Started Blockchain API Call`);
              const blockchainResult = await makeBlockchainApiCallWithRetry(
                transactions,
                blockChainToken,
                { countryCode, mobileNumber, userId, updateBlockChainToken }
              );
              const endTime = new Date();
              const elapsedTime = endTime - startTime;
              logger.info(`Blockchain took ${elapsedTime} milliseconds`);
              addCronLog(cronLogs, {
                message: `Blockchain API took ${elapsedTime} milliseconds`,
              });

              transactionStatus = blockchainResult;
              logger.info(
                `Blockchain transaction finished | Result: ${transactionStatus?.status}`
              );

              if (transactionStatus?.status) {
                addCronLog(cronLogs, {
                  message: `Blockchain transactions have been created successfully`,
                  data: {
                    result: transactionStatus?.status,
                  },
                });

                const blockChainTransId =
                  transactionStatus?.result?.map(
                    (trans) => trans.blockchainLogId
                  ) || [];
                await updateBlockchainSyncStatus({
                  cronId,
                  isBlockChainSync: transactionStatus.status,
                  blockChainTransId,
                });

                const userSharedDataCleared = await clearUserSharedData(
                  userData,
                  {
                    organizationIds,
                    deleteUser: !!(operationType && operationType === 1),
                  }
                );

                logger.info(
                  `Cleared user data for trusted organization: ${organizationIds} | Result: ${userSharedDataCleared}`
                );

                if (userSharedDataCleared) {
                  logger.info(`User Data is deleted: ${userId}`);
                  addCronLog(cronLogs, {
                    message: `User Data has been removed successfully from the database.`,
                    data: {
                      userId,
                      result: userSharedDataCleared,
                    },
                  });

                  if (operationType === 1) {
                    const token = generateJWTSign({
                      countryCode: userData.countryCode,
                      mobileNumber: userData.mobileNumber,
                    });
                    userData.token = token;
                    await removeAllNotification(userData, { userId });
                    addCronLog(cronLogs, {
                      message: `User's all request has been removed successfully from the database.`,
                    });

                    const blockedOrgs = await getBlockOrganizationOfUser(
                      userId,
                      '_id organizationId userId'
                    );

                    if (blockedOrgs.length > 0) {
                      await Promise.all(
                        blockedOrgs.map(async (blockedOrg) => {
                          await Promise.all([
                            removeBlockedOrganization(
                              blockedOrg.organizationId.toString(),
                              blockedOrg.userId.toString()
                            ),
                            removeBlockedUsers(
                              blockedOrg.organizationId.toString(),
                              blockedOrg.userId.toString()
                            ),
                          ]);
                        })
                      );

                      await deleteBlockAllOrganization(userId);
                      addCronLog(cronLogs, {
                        message: `User's all blocked organization has been removed successfully from the database.`,
                      });
                    }

                    const deletedAccount = await deleteUserAccount(userData);
                    if (deletedAccount?.error) {
                      addCronLog(cronLogs, {
                        message: `User's account has been deleted.`,
                      });
                    }
                  }

                  await executeCronSuccess(queueItem, cronLogs);
                  return;
                }
                addCronLog(cronLogs, {
                  message: `The process of deleting user data from the database has failed.`,
                  data: {
                    result: userSharedDataCleared,
                  },
                });
              }

              addCronLog(cronLogs, {
                message: `Blockchain transactions creation process has failed.`,
                data: {
                  result: transactionStatus?.status,
                },
                error: transactionStatus?.error,
              });
            }

            addCronLog(cronLogs, {
              message: `CRM operation has failed.`,
            });
            throw new Error(`Rollback from operation: ${operationType}`);
          }
        }
        if (!trustedOrgCount) {
          // Delete user count
          if (operationType === 1) {
            // Blockchain transactions of account deletion
            transactions.push({
              log_type: 'consent',
              permission_status: 'delete-my-account',
              consent_requestor: '',
              version: 1,
              updated_parameter: ['accountDeletion'],
              user_in_front: '',
              messages: ['You have deleted your account.'],
            });
            /** Make Blockchain API request */
            const startTime = new Date();
            logger.info(`Blockchain executed at: ${new Date()}`);
            logger.info(`Started Blockchain API Call`);
            addCronLog(cronLogs, {
              message: `Creating blockchain transaction of removing user account.`,
            });
            const blockchainResult = await makeBlockchainApiCallWithRetry(
              transactions,
              blockChainToken,
              { countryCode, mobileNumber, userId, updateBlockChainToken }
            );
            logger.info(`Finished Blockchain API Call`);
            const endTime = new Date();
            const elapsedTime = endTime - startTime;
            logger.info(`Blockchain API took ${elapsedTime} milliseconds`);
            transactionStatus = blockchainResult;
            logger.info(
              `Blockchain transaction finished | Result: ${transactionStatus?.status}`
            );

            if (transactionStatus?.status) {
              /* Store successful transaction Ids */
              addCronLog(cronLogs, {
                message: `Blockchain transaction has been created successfully.`,
              });
              addCronLog(cronLogs, {
                message: `Blockchain API took ${elapsedTime} milliseconds`,
              });
              const blockChainTransId =
                transactionStatus?.result?.map(
                  (trans) => trans.blockchainLogId
                ) || [];
              await updateBlockchainSyncStatus({
                cronId,
                isBlockChainSync: transactionStatus.status,
                blockChainTransId,
              });

              const deletedAccount = await deleteUserAccount(userData);
              if (deletedAccount?.error) {
                logger.info(
                  `Error in removing user account: ${userId} - ${userData?.mobileNumber}`
                );
                addCronLog(cronLogs, {
                  message: `Error in removing user account.`,
                  data: {
                    userId,
                    userMobileNumber: userData?.mobileNumber,
                  },
                  error: deletedAccount?.error,
                });
                // rollback
                cronLogs.push(
                  'Throw New Error: Do rollback due to process failed!'
                );
                throw new Error('Do rollback due to process failed!');
              }
            } else {
              // rollback
              addCronLog(cronLogs, {
                message: `Creation of blockchain transaction of deleting user account has failed.`,
                data: {
                  result: transactionStatus?.status,
                },
                error: transactionStatus?.error,
              });
              addCronLog(cronLogs, {
                message: `Blockchain API took ${elapsedTime} milliseconds`,
              });
              throw new Error('Do rollback due to process failed!');
            }
          }
        }
        logger.info(`Removing job called at the end`);
        await updateJob({ userId, operationType, logs: cronLogs });
        logger.info(
          `removeJobFromQueueInCron is called at the end from deleteUserDataCron.`
        );
        await removeJobFromQueueInCron(queueItem, true);
        // Send success notification to the mobile user based on the operation type
        const notification = await sendFirebaseNotificationInCron(queueItem, {
          notificationStatus: true,
        });

        if (!notification?.status) {
          addCronLog(cronLogs, {
            message: `Failed to send notification.`,
            data: {
              result: notification.status,
            },
            error: notification?.error,
          });
        }
      } catch (error) {
        logger.error(`Error cached in deleteUserDataCron crone: ${error}`);
        // Rollback
        logger.error(
          `Doing rollback from thr catch block of deleteUserDataCron`
        );
        await executeRollBack(queueItem, autoSyncRollbackData, cronLogs);
      }
    });
  }
};

exports.handleCronJobFailures = async () => {
  try {
    // Create a date to remove older records (3 months older)
    const dateOfOlderRecord = moment().utc().subtract(3, 'months').toDate();
    const recordsDeleted = await deleteJobsFromHistory(dateOfOlderRecord);
    logger.info(
      `Cron history records deleted: ${JSON.stringify(recordsDeleted)}`
    );
    // Read Queue
    const QueueStream = await getJobHistoryStream({
      failedJobs: true,
    });
    let batch = [];
    let totalProcessed = 0;
    QueueStream.on('data', (doc) => {
      batch.push(doc);
      if (batch.length >= 10) {
        logger.info(`History:: Processing batch of ${batch.length} records...`);
        // Processing batch of records
        handleBatchOfCronFailures(batch);
        // Increment total processed count
        totalProcessed += batch.length;
        // Clear batch array
        batch = [];
      }
    });

    QueueStream.on('end', () => {
      // Process any remaining records in the last batch
      if (batch.length > 0) {
        logger.info(
          `History:: Processing remaining ${batch.length} records...`
        );
        // Processing remaining records
        handleBatchOfCronFailures(batch);
        // Increment total processed count
        totalProcessed += batch.length;
      }
      logger.info(`History:: Total processed records: ${totalProcessed}`);
    });

    QueueStream.on('error', (error) => {
      // Handle error
      logger.error(`Error in streaming records: ${error}`);
    });
  } catch (error) {
    logger.error(`Error in cronHistory: ${error}`);
  }
};

exports.handleCronJobReminder = async () => {
  try {
    // Find mobile users
    const mobileUsers = await findUser({
      userType: userRoles.FRONT_END_USER,
      isActive: true,
      isDeleted: false,
      countryCode: { $exists: true },
      mobileNumber: { $exists: true },
      deviceToken: { $exists: true },
    });

    logger.info(`Registered mobile users: ${mobileUsers.length}`);

    if (mobileUsers.length > 0) {
      // Batch process mobile users
      const userPromises = mobileUsers.map(async (user) => {
        try {
          // Generate token for user
          const token = generateJWTSign({
            countryCode: user.countryCode,
            mobileNumber: user.mobileNumber,
          });
          // eslint-disable-next-line no-param-reassign
          user.token = token;

          // Calculate request count
          const isRequestSent = await calculateNotificationCount(user, {
            userId: user._id,
            countType: 'COUNT',
            requestType: 'REQUEST',
            requestStatus: [requestStatus.SENT],
            isRead: false,
          });
          const requestCount = isRequestSent?.data?.data || 0;

          if (requestCount > 0) {
            logger.info(
              `Sending reminder to: ${user.countryCode} ${user.mobileNumber} for ${requestCount} pending requests`
            );

            // Send notification
            const notification = await sendFirebaseNotificationInCron(
              { userId: user._id, type: 11 },
              { notificationStatus: true, requestCount }
            );

            logger.info('Reminder status:');
            logger.info(JSON.stringify(notification));
          }
          return isRequestSent;
        } catch (error) {
          logger.error(`Error processing user ${user._id}: ${error}`);
          return null; // Return null for failed users to handle in Promise.all
        }
      });

      await Promise.all(userPromises);
    } else {
      logger.info(`No registered mobile users found.`);
    }
  } catch (error) {
    logger.error(`Error in handleCronJobReminder: ${error}`);
  }
};

exports.handleBulkSms = async () => {
  try {
    const mobileNumbers = await findSmsRecords({
      $or: [{ status: 'Pending' }, { status: 'Failed' }],
      tryCount: { $lt: 3 },
    });

    logger.info(`list of mobile numbers: ${mobileNumbers.length}`);

    if (mobileNumbers.length > 0) {
      await Promise.all(
        mobileNumbers.map(async (contact) => {
          const {
            _id: contactId,
            tryCount,
            failCount,
            organizationId,
            countryCode,
            mobileNumber,
          } = contact;
          try {
            const org = await getOrganizationById(organizationId);

            if (!org || org.error) {
              throw new Error(`Organization not found`);
            }

            const mobileUser = await findUserByMobile({
              countryCode,
              mobileNumber,
            });

            if (!mobileUser) {
              await updateBulkSmsHistory(contactId, {
                attemptLogs: [
                  `+${countryCode} ${mobileNumber} is non-registered user`,
                ],
              });

              // Send Message to Non-registered user
              const sentMessage = await sendTextMessage({
                countryCode,
                mobileNumber,
                messageBody:
                  responseMessages.SEND_DOWNLOAD_LINK_MESSAGE.replace(
                    'XYZ',
                    org.name
                  ),
                SMSToken: mobileUser?.SMSToken,
              });

              if (!sentMessage) {
                throw new Error(
                  `Failed to send text message due to some technical issue`
                );
              }

              if (sentMessage) {
                await updateBulkSmsHistory(contactId, {
                  status: 'Success',
                  tryCount: tryCount + 1,
                  attemptLogs: [
                    `Attempt ${tryCount + 1}: Text message sent successfully`,
                  ],
                });
              }
            }

            if (mobileUser) {
              await updateBulkSmsHistory(contactId, {
                attemptLogs: [
                  `+${countryCode} ${mobileNumber} is Registered user`,
                ],
              });
              const isBlocked = await getBlockOrganization(
                org._id,
                mobileUser._id
              );
              if (isBlocked) {
                throw new Error(
                  `Unable to send the request because the user has blocked you`
                );
              }

              // Send notification to registered user
              const requestDetails = [
                'FirstName',
                'LastName',
                'Address',
                'MobileNumber',
                'Email',
                'Twitter',
                'LinkedIn',
              ];

              const token = generateJWTSign({
                countryCode,
                mobileNumber,
              });
              mobileUser.token = token;
              const authToken = `Bearer ${token}`;

              // Fetch organization
              const timezone =
                (await getSettingsByUser(org.userId))?.settings?.timezone ||
                'UTC';

              // Fetch recent and previous notifications
              const [userRecentNotification, userPreviousNotification] =
                await Promise.all([
                  getNotificationsData(token, mobileUser, org._id, 0, timezone),
                  getNotificationsData(token, mobileUser, org._id, 1, timezone),
                ]);

              // If no recent notifications, send request to user directly
              const { _id: userId } = mobileUser;

              const requestDetailsString = requestDetails.join(', ');

              if (userRecentNotification?.notification_list.length === 0) {
                const policy = await generatePrivacyPolicy(org);
                const transactions = [
                  {
                    log_type: 'request',
                    permission_status: 'sent',
                    consent_requestor: org?.name || 'Organization',
                    version: 1,
                    updated_parameter: [requestDetailsString],
                    user_in_front: '',
                    // messages: requestDetails.map(
                    //   (label) =>
                    //     `${org?.name} organization has requested your ${label} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`
                    // ),
                    messages: [
                      `${org?.name} wants to access your ${requestDetailsString} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`,
                    ],
                  },
                ];

                // Make blockchain API call
                const startTime = new Date();
                logger.info(`Blockchain executed at: ${startTime}`);
                logger.info(`Started Blockchain API Call`);
                const sharedData = await makeBlockchainApiCallWithRetry(
                  transactions,
                  mobileUser?.blockChainToken || null,
                  {
                    countryCode,
                    mobileNumber,
                    userId,
                    updateBlockChainToken,
                  }
                );
                logger.info(`Finished Blockchain API Call`);
                const elapsedTime = new Date() - startTime;
                logger.info(`Blockchain took ${elapsedTime} milliseconds`);
                if (!sharedData?.status) {
                  throw new Error(`Blockchain transaction process failed`);
                }

                if (sharedData?.status) {
                  await generateAndSendNotification({
                    previousNotifications: userPreviousNotification,
                    requestDetails,
                    mobileUser,
                    organization: org,
                    authToken,
                    userId: org.userId,
                    clientId: userId,
                  });
                }
              }

              if (userRecentNotification?.notification_list.length > 0) {
                // Filter recent request
                let diffStatus = true;
                let diffValues = requestDetails;

                const requestDetailsString = diffValues.join(', ');

                userRecentNotification?.notification_list.forEach(
                  (notification) => {
                    const currentLabels = notification.requestedLabels;
                    diffValues = diffValues.filter(
                      (item) => !currentLabels.includes(item)
                    );
                  }
                );
                diffStatus = diffValues.length !== 0;

                if (diffValues.length === 0) {
                  await generateAndSendNotification({
                    previousNotifications: userPreviousNotification,
                    requestDetails,
                    mobileUser,
                    organization: org,
                    authToken,
                    userId: org.userId,
                    clientId: userId,
                    diffStatus,
                  });
                }

                if (diffValues.length > 0) {
                  const policy = await generatePrivacyPolicy(org);
                  const transactions = [
                    {
                      log_type: 'request',
                      permission_status: 'sent',
                      consent_requestor: org?.name || 'Organization',
                      version: 1,
                      updated_parameter: [requestDetailsString],
                      user_in_front: '',
                      // messages: diffValues.map(
                      //   (label) =>
                      //     `${org?.name} organization has requested your ${label} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`
                      // ),
                      messages: [
                        `${org?.name} wants to access your ${requestDetailsString} under ${policy.rule} policy with ${policy.sub_rules[0]} principle`,
                      ],
                    },
                  ];

                  // Make blockchain API call
                  const startTime = new Date();
                  logger.info(`Blockchain executed at: ${startTime}`);
                  logger.info(`Started Blockchain API Call`);
                  const sharedData = await makeBlockchainApiCallWithRetry(
                    transactions,
                    mobileUser?.blockChainToken || null,
                    {
                      countryCode,
                      mobileNumber,
                      userId,
                      updateBlockChainToken,
                    }
                  );
                  logger.info(`Finished Blockchain API Call`);
                  const elapsedTime = new Date() - startTime;
                  logger.info(`Blockchain took ${elapsedTime} milliseconds`);
                  if (!sharedData?.status) {
                    throw new Error(`Blockchain transaction process failed`);
                  }

                  if (sharedData?.status) {
                    await generateAndSendNotification({
                      previousNotifications: userPreviousNotification,
                      requestDetails: diffValues,
                      mobileUser,
                      organization: org,
                      authToken,
                      userId: org.userId,
                      clientId: userId,
                    });
                  }
                }
              }

              // All successful
              await updateBulkSmsHistory(contactId, {
                status: 'Success',
                tryCount: tryCount + 1,
                attemptLogs: [
                  `Attempt ${tryCount + 1}: Notification sent successfully`,
                ],
              });
            }
          } catch (error) {
            logger.error(`Error processing contactId ${contactId}: ${error}`);
            // Update failed attempt
            await updateBulkSmsHistory(contactId, {
              status: 'Failed',
              tryCount: tryCount + 1,
              failCount: failCount + 1,
              attemptLogs: [`Attempt ${tryCount + 1}: ${error.message}`],
            });
          }
        })
      );
    } else {
      logger.info(`No mobile numbers found.`);
    }
  } catch (error) {
    logger.error(`Error in handleBulkSms: ${error}`);
  }
};
