const axios = require('axios');
const CRMSetting = require('../models/crmSettingModel');
const withErrorHandling = require('../middleware/serviceHandler');
const crmTypes = require('../config/constants/crmTypes');
const { getOrganizationById } = require('./organizationService');
const {
  updateHubspotId,
  updateZohoId,
  findUserById,
} = require('./userService');
const {
  updateHubSpotSyncStatus,
  updateHubSpotRollbackId,
  updateJob,
} = require('./deleteUserDataService');
const { updateCRMDataInRollback } = require('./commonService');
const { sendNotification } = require('./notificationService');
const { sendEmail } = require('../helpers/emailServices');
const { getOrgIdLoggedInUser } = require('../helpers/userHelper');
const { generateJWTSign } = require('../helpers/jwtHelper');
const { sendErrorLogs } = require('../helpers/emailServices');
const mailConstants = require('../config/constants/mailOptions');
const { addCronLog } = require('../utils/common');
const logger = require('../logger');

// Helper function to handle Zoho API calls with automatic token refresh on 401
const makeZohoApiCallWithRetry = async (
  apiCall,
  orgUserId,
  organizationId,
  userData,
  logData,
  verifyAndRefreshZohoTokenFn
) => {
  try {
    return await apiCall();
  } catch (error) {
    // If 401 error, refresh token and retry
    if (error.response?.status === 401) {
      logger.info(
        `Received 401 error from Zoho API, refreshing token and retrying...`
      );

      const tokenResult = await verifyAndRefreshZohoTokenFn(orgUserId);

      if (tokenResult?.error) {
        logger.error(
          `Failed to refresh Zoho token after 401 error for organization: ${orgUserId}`
        );
        addCronLog(logData, {
          message: `Failed to refresh Zoho token after 401 error.`,
          data: {
            organizationId: orgUserId,
          },
          error: tokenResult,
        });
        return { error: true, tokenResult };
      }

      // Retry with new token
      try {
        const result = await apiCall(tokenResult.accessToken);
        logger.info(`Successfully completed Zoho API call after token refresh`);
        return result;
      } catch (retryError) {
        logger.error(
          `Error retrying Zoho API call after token refresh: ${retryError.message}`
        );
        addCronLog(logData, {
          message: `Error retrying Zoho API call after token refresh.`,
          data: {
            organizationId,
            userData,
          },
          error: retryError,
        });
        await sendErrorLogs({
          error: retryError,
          mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
        });
        return { error: true, retryError };
      }
    }

    // Not a 401 error, throw it back
    throw error;
  }
};

exports.configureCRM = withErrorHandling(
  async ({ type, auth_token, zohoClientId, zohoSecretKey, authCode }) => {
    if (type === 'hubspot') {
      /** Connection API */
      const response = await axios.post(
        `${process.env.CRM_API_BASE_URL}/api/v1/hubspot/verifyToken`,
        {
          auth_token,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
          },
        }
      );
      return response?.data;
    }
    if (type === 'zoho') {
      /** Zoho CRM Configuration API */
      const response = await axios.post(
        `${process.env.CRM_API_BASE_URL}/api/v1/zoho/exchangeCodeForTokens`,
        {
          grant_type: 'authorization_code',
          client_id: zohoClientId,
          client_secret: zohoSecretKey,
          redirect_uri: process.env.ZOHO_REDIRECT_URI,
          code: authCode,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
          },
        }
      );
      return response?.data;
    }
    return false;
  }
);

exports.updateCRMRecord = withErrorHandling(
  async (userData, payload, rollbackFlag, logData) => {
    const {
      organization_id: organizationId,
      firstName,
      lastName,
      mobile_numbers: mobileNumbers,
      emails,
      address,
      social,
    } = payload;
    // Get the list of configured CRM with the organization
    const orgData = await getOrganizationById(organizationId);
    const CRMList = orgData?.userId
      ? await CRMSetting.find({
          organizationId: orgData?.userId,
        })
      : null;
    logger.info(`CRM list (updateCRMRecord): ${JSON.stringify(CRMList)}`);
    if (CRMList?.length) {
      const responses = await Promise.all(
        CRMList.map(async (CRMData) => {
          // Import user data to the Hubspot CRM
          if (CRMData?.type === crmTypes.HUBSPOT) {
            const requestBody = {
              auth_token: CRMData.config?.authToken,
              ...(firstName !== undefined ? { firstName } : null),
              ...(lastName !== undefined ? { lastName } : null),
              ...(emails[0] !== undefined ? { email1: emails[0] } : null),
              ...(emails[1] !== undefined ? { email2: emails[1] } : null),
              ...(emails[2] !== undefined ? { email3: emails[2] } : null),
              ...(emails[3] !== undefined ? { email4: emails[3] } : null),
              ...(emails[4] !== undefined ? { email5: emails[4] } : null),
              ...(mobileNumbers[0] !== undefined
                ? { contactNumber1: mobileNumbers[0] }
                : null),
              ...(mobileNumbers[1] !== undefined
                ? { contactNumber2: mobileNumbers[1] }
                : null),
              ...(mobileNumbers[2] !== undefined
                ? { contactNumber3: mobileNumbers[2] }
                : null),
              ...(mobileNumbers[3] !== undefined
                ? { contactNumber4: mobileNumbers[3] }
                : null),
              ...(mobileNumbers[4] !== undefined
                ? { contactNumber5: mobileNumbers[4] }
                : null),
              ...(address[0] !== undefined ? { address1: address[0] } : null),
              ...(address[1] !== undefined ? { address2: address[1] } : null),
              ...(address[2] !== undefined ? { address3: address[2] } : null),
              ...(address[3] !== undefined ? { address4: address[3] } : null),
              ...(address[4] !== undefined ? { address5: address[4] } : null),
              ...(social?.linkedin !== undefined
                ? { linkedInLink: social?.linkedin }
                : null),
              ...(social?.twitter !== undefined
                ? { twitterLink: social?.twitter }
                : null),
            };
            addCronLog(logData, {
              message: `Start processing of HubSpot data.`,
              data: {
                requestBody,
                organizationId: orgData?.userId,
              },
            });
            // Verify if data is already imported
            if (requestBody?.auth_token) {
              if (userData.hubspotIds.has(organizationId)) {
                // Update the record and return the result
                const hubspotId = userData.hubspotIds.get(organizationId);
                addCronLog(logData, {
                  message: `Updating exisiting HubSpot record.`,
                  data: {
                    hubspotId,
                    organizationId,
                  },
                });
                try {
                  await axios.post(
                    `${process.env.CRM_API_BASE_URL}/api/v1/hubspot/update/${hubspotId}`,
                    requestBody,
                    {
                      headers: {
                        'Content-Type': 'application/json',
                        authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
                      },
                    }
                  );
                  return true;
                } catch (error) {
                  logger.error(
                    `Error in updating data into Hubspot: ${
                      error.message
                    } | Organization Id: ${organizationId} | User Data: ${JSON.stringify(
                      userData
                    )}`
                  );
                  addCronLog(logData, {
                    message: `Error in the processing of updating existing HubSpot record.`,
                    data: {
                      organizationId,
                      userData,
                    },
                    error,
                  });
                  // Send mail to the developer or support team to fix errors coming from the application
                  await sendErrorLogs({
                    error,
                    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
                  });
                  return false;
                }
              } else if (rollbackFlag === true) {
                return true;
              } else {
                // Create a new record
                addCronLog(logData, {
                  message: `Creating new HubSpot record.`,
                  data: {
                    organizationId,
                  },
                });
                try {
                  const response = await axios.post(
                    `${process.env.CRM_API_BASE_URL}/api/v1/hubspot/create`,
                    requestBody,
                    {
                      headers: {
                        'Content-Type': 'application/json',
                        authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
                      },
                    }
                  );
                  // Save hubspot record id into the database
                  return updateHubspotId(userData._id, {
                    hubspotId: response?.data?.data?.id,
                    organizationId,
                  });
                } catch (error) {
                  logger.error(
                    `Error in creating data into Hubspot: ${
                      error.message
                    } | Organization Id: ${organizationId} | User Data: ${JSON.stringify(
                      userData
                    )}`
                  );
                  addCronLog(logData, {
                    message: `Error in the processing of creating new HubSpot data.`,
                    data: {
                      organizationId,
                      userData,
                    },
                    error,
                  });
                  // Send mail to the developer or support team to fix errors coming from the application
                  await sendErrorLogs({
                    error,
                    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
                  });
                  return false;
                }
              }
            }
          }
          // Import user data to the Zoho CRM
          if (CRMData?.type === crmTypes.ZOHO) {
            let validAccessToken = CRMData.zohoAccessToken;

            // Check if token is expired or about to expire (within 5 minutes)
            const tokenExpiresAt = CRMData.zohoAccessTokenExpiresAt;
            const isTokenExpired =
              !tokenExpiresAt || new Date(tokenExpiresAt) <= new Date();

            if (isTokenExpired) {
              // Verify and refresh Zoho access token if needed
              logger.info(
                `Zoho access token expired or missing for organization: ${orgData?.userId}, refreshing...`
              );
              const tokenResult = await this.verifyAndRefreshZohoToken(
                orgData?.userId
              );

              if (tokenResult?.error) {
                logger.error(
                  `Failed to verify/refresh Zoho token for organization: ${orgData?.userId}`
                );
                addCronLog(logData, {
                  message: `Failed to verify/refresh Zoho access token.`,
                  data: {
                    organizationId: orgData?.userId,
                  },
                  error: tokenResult,
                });
                return false;
              }

              // Use the verified/refreshed access token
              validAccessToken = tokenResult.accessToken;
            }

            const requestBody = {
              auth_token: validAccessToken,
              ...(firstName !== undefined ? { firstName } : null),
              ...(lastName !== undefined ? { lastName } : null),
              ...(emails[0] !== undefined ? { email1: emails[0] } : null),
              ...(emails[1] !== undefined ? { email2: emails[1] } : null),
              ...(emails[2] !== undefined ? { email3: emails[2] } : null),
              ...(emails[3] !== undefined ? { email4: emails[3] } : null),
              ...(emails[4] !== undefined ? { email5: emails[4] } : null),
              ...(mobileNumbers[0] !== undefined
                ? { mobileNumber1: mobileNumbers[0] }
                : null),
              ...(mobileNumbers[1] !== undefined
                ? { mobileNumber2: mobileNumbers[1] }
                : null),
              ...(mobileNumbers[2] !== undefined
                ? { mobileNumber3: mobileNumbers[2] }
                : null),
              ...(mobileNumbers[3] !== undefined
                ? { mobileNumber4: mobileNumbers[3] }
                : null),
              ...(mobileNumbers[4] !== undefined
                ? { mobileNumber5: mobileNumbers[4] }
                : null),
              ...(address[0] !== undefined ? { address1: address[0] } : null),
              ...(address[1] !== undefined ? { address2: address[1] } : null),
              ...(address[2] !== undefined ? { address3: address[2] } : null),
              ...(address[3] !== undefined ? { address4: address[3] } : null),
              ...(address[4] !== undefined ? { address5: address[4] } : null),
              ...(social?.linkedin !== undefined
                ? { linkedin: social?.linkedin }
                : null),
              ...(social?.twitter !== undefined
                ? { twitter: social?.twitter }
                : null),
            };
            addCronLog(logData, {
              message: `Start processing of Zoho data.`,
              data: {
                requestBody,
                organizationId: orgData?.userId,
              },
            });
            // Verify if data is already imported
            if (requestBody?.auth_token) {
              if (userData.zohoIds && userData.zohoIds.has(organizationId)) {
                // Update the record and return the result
                const zohoId = userData.zohoIds.get(organizationId);
                addCronLog(logData, {
                  message: `Updating existing Zoho record.`,
                  data: {
                    zohoId,
                    organizationId,
                  },
                });

                const updateApiCall = async (newToken) => {
                  const tokenToUse = newToken || validAccessToken;
                  await axios.post(
                    `${process.env.CRM_API_BASE_URL}/api/v1/zoho/update/${zohoId}`,
                    { ...requestBody, auth_token: tokenToUse },
                    {
                      headers: {
                        'Content-Type': 'application/json',
                        authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
                      },
                    }
                  );
                  return true;
                };

                try {
                  const result = await makeZohoApiCallWithRetry(
                    updateApiCall,
                    orgData?.userId,
                    organizationId,
                    userData,
                    logData,
                    this.verifyAndRefreshZohoToken.bind(this)
                  );

                  if (result?.error) {
                    return false;
                  }

                  return result;
                } catch (error) {
                  logger.error(
                    `Error in updating data into Zoho: ${error.message} `
                  );
                  addCronLog(logData, {
                    message: `Error in the processing of updating existing Zoho record.`,
                    data: {
                      organizationId,
                      userData,
                    },
                    error,
                  });
                  await sendErrorLogs({
                    error,
                    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
                  });
                  return false;
                }
              } else if (rollbackFlag === true) {
                return true;
              } else {
                // Create a new record
                addCronLog(logData, {
                  message: `Creating new Zoho record.`,
                  data: {
                    organizationId,
                  },
                });

                const createApiCall = async (newToken) => {
                  const tokenToUse = newToken || validAccessToken;
                  const response = await axios.post(
                    `${process.env.CRM_API_BASE_URL}/api/v1/zoho/create`,
                    { ...requestBody, auth_token: tokenToUse },
                    {
                      headers: {
                        'Content-Type': 'application/json',
                        authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
                      },
                    }
                  );

                  // Extract Zoho ID from response - check multiple possible locations
                  const zohoId =
                    response?.data?.data?.details?.id ||
                    response?.data?.data?.id ||
                    null;

                  logger.info(`Zoho contact created with ID: ${zohoId}`);

                  // Save zoho record id into the database
                  return updateZohoId(userData._id, {
                    zohoId,
                    organizationId,
                  });
                };

                try {
                  const result = await makeZohoApiCallWithRetry(
                    createApiCall,
                    orgData?.userId,
                    organizationId,
                    userData,
                    logData,
                    this.verifyAndRefreshZohoToken.bind(this)
                  );

                  if (result?.error) {
                    return false;
                  }

                  return result;
                } catch (error) {
                  logger.error(
                    `Error in creating data into Zoho: ${error.message}}`
                  );
                  addCronLog(logData, {
                    message: `Error in the processing of creating new Zoho data.`,
                    data: {
                      organizationId,
                      userData,
                    },
                    error,
                  });
                  await sendErrorLogs({
                    error,
                    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
                  });
                  return false;
                }
              }
            }
          }
          return false;
        })
      );
      return !!(
        CRMList?.length === responses.length && responses.indexOf(false) === -1
      );
    }
    logger.info(
      `Organization has not configure CRM yet (updateCRMRecord): ${organizationId}`
    );
    return true;
  }
);

exports.deleteCRMRecord = withErrorHandling(
  async (userData, payload, retryFailure, logData) => {
    const { organizationId, jobData, restoreFlag } = payload;
    // Get the list of configured CRM with the organization
    const orgData = await getOrganizationById(organizationId);
    // Send mail to the organization admin to remove the data
    const orgUserData = await findUserById(orgData?.userId);
    const mailOptions = {
      to: orgUserData?.email,
      type: mailConstants.MAIL_TYPES.DELETE_USER_DATA_NOTIFICATION,
      userData,
      templateVars: {
        countryCode: userData?.countryCode,
        mobileNumber: userData?.mobileNumber,
        logo: `${process.env.BASE_URL}/uploads/profilePictures/Logo1.png`,
      },
    };
    const mailSent = await sendEmail(mailOptions);
    logger.info(
      `data deletion request mail has been sent to the organization admin ${orgUserData?.email}: ${mailSent}`
    );
    // DO:: Send notification to the organization admin
    const token = generateJWTSign({
      countryCode: userData.countryCode,
      mobileNumber: userData.mobileNumber,
    });
    const authToken = `Bearer ${token}`;
    await sendNotification(
      {
        notification_to: 'ORGANIZATION-ADMIN',
        notification_type: 'USER_DELETE_DATA_REQUEST',
        organization_id: orgData.userId,
        organization_parent_id: orgData._id,
        sender_id: userData?._id,
      },
      authToken
    );
    if (!mailSent) {
      return false;
    }
    // console.log('mailSent.......', mailSent);
    const CRMList = orgData?.userId
      ? await CRMSetting.find({
          organizationId: orgData?.userId,
        })
      : null;
    logger.info(`CRM list (deleteCRMRecord): ${JSON.stringify(CRMList)}`);
    if (CRMList?.length) {
      const responses = await Promise.all(
        CRMList.map(async (CRMData) => {
          // Import user data to the Hubspot CRM
          if (CRMData?.type === crmTypes.HUBSPOT) {
            const requestBody = {
              auth_token: CRMData.config?.authToken,
              restore_flag: restoreFlag,
            };
            // Verify if data is already imported
            if (requestBody?.auth_token) {
              if (userData.hubspotIds.has(organizationId)) {
                // Delete the record and return the result
                const hubspotId = userData.hubspotIds.get(organizationId);
                addCronLog(logData, {
                  message: `Performing the rollback of CRM data by removing CRM record with id ${hubspotId}`,
                  data: {
                    requestBody,
                  },
                });
                try {
                  // const response = await axios.post(
                  //   `${process.env.CRM_API_BASE_URL}/api/v1/hubspot/delete/${hubspotId}`,
                  //   requestBody,
                  //   {
                  //     headers: {
                  //       'Content-Type': 'application/json',
                  //       authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
                  //     },
                  //   }
                  // );
                  if (restoreFlag === undefined) {
                    // Insert record into cronjob data
                    let isCronJobUpdated = true;
                    if (jobData !== undefined) {
                      const { userId, type: operationType } = jobData;
                      const hubspotCronUpdated = await updateHubSpotSyncStatus({
                        userId,
                        type: operationType,
                        organizationId,
                        status: hubspotId,
                      });
                      logger.info(
                        `Hubspot result is stored to the cron-data: ${
                          hubspotCronUpdated &&
                          JSON.stringify(hubspotCronUpdated)
                        }`
                      );
                      addCronLog(logData, {
                        message: `Hubspot result is stored to the cron data in the database.`,
                        data: {
                          result: hubspotCronUpdated,
                        },
                      });
                      if (
                        hubspotCronUpdated.error ||
                        hubspotCronUpdated === false
                      ) {
                        addCronLog(logData, {
                          message: `Error in storing hubspot record to the database.`,
                          error: hubspotCronUpdated,
                        });
                        isCronJobUpdated = false;
                      }
                    }
                    if (isCronJobUpdated) {
                      // Delete hubspot record id into the database
                      const deletedHubspotData = await updateHubspotId(
                        userData._id,
                        {
                          hubspotId,
                          organizationId,
                          deleteHubspotId: true,
                        }
                      );
                      addCronLog(logData, {
                        message: `Hubspot data is removed from the users's collection.`,
                        data: {
                          result: deletedHubspotData,
                        },
                      });
                      return deletedHubspotData;
                    }
                  } else {
                    // Update hubspotId as new records are created
                    // const newHubspotId = response?.data?.data?.id;
                    const newHubspotId = 0;
                    const { _id: jobId, userId, type: operationType } = jobData;
                    const rollbackIdSaved = await updateHubSpotRollbackId({
                      jobId,
                      userId,
                      type: operationType,
                      organizationId,
                      hubspotId: newHubspotId,
                      retryFailure,
                    });
                    if (!rollbackIdSaved?.error && rollbackIdSaved) {
                      addCronLog(logData, {
                        message: `New Hubspot record is creating while performing the rollback operation.`,
                        data: {
                          newHubspotId,
                        },
                      });
                      logger.info(
                        `New Rollback Id Saved: ${JSON.stringify(
                          rollbackIdSaved
                        )}`
                      );
                      return true;
                    }
                    addCronLog(logData, {
                      message: `Error in storing new Hubspot Id ${newHubspotId} to the database while performing the rollback operation.`,
                      data: {
                        newHubspotId,
                      },
                    });
                    return false;
                  }
                } catch (error) {
                  logger.error(
                    `Error in deleting data from Hubspot: ${
                      error?.response?.data
                        ? JSON.stringify(error?.response?.data)
                        : error?.message
                    } | Organization Id: ${organizationId} | User Data: ${JSON.stringify(
                      userData
                    )}`
                  );
                  addCronLog(logData, {
                    message: `Error in deleting data from the Hubspot CRM.`,
                    data: {
                      organization: organizationId,
                      userData,
                    },
                    error: error?.response?.data,
                  });
                  await sendErrorLogs({
                    error: error?.response?.data,
                    mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
                  });
                  return false;
                }
              }
            }
            return false;
          }
          return false;
        })
      );
      return !!(
        CRMList?.length === responses.length && responses.indexOf(false) === -1
      );
    }
    logger.info(
      `Organization has not configure CRM yet (deleteCRMRecord): ${organizationId}`
    );
    return true;
  }
);

exports.restoreCRMRecord = withErrorHandling(
  async (jobData, rollbackData, retryFailure, logData) => {
    const {
      hubSpotSyncUpdate,
      rollBackHubspotStatus,
      rollBackHubspotDBStatus,
      rollBackHubspotIds,
      _id: jobId,
      userId,
      type: operationType,
    } = jobData;
    logger.info(`HubspotId History: ${hubSpotSyncUpdate.size}`);
    addCronLog(logData, {
      message: `Reading hubspot data to perform rollback`,
      data: {
        hubspotData: hubSpotSyncUpdate,
      },
    });
    if (hubSpotSyncUpdate.size && !rollBackHubspotDBStatus) {
      logger.info(`CRM rollback operation starts: ${JSON.stringify(jobData)}`);
      const userData = await findUserById(userId);
      const hubSpotSyncUpdateArray = Array.from(hubSpotSyncUpdate);
      let restoredCRMData;
      if (!rollBackHubspotStatus) {
        restoredCRMData = await Promise.all(
          hubSpotSyncUpdateArray.map(async ([orgId, hubspotId]) => {
            logger.info(
              `Processing rollback of Hubspot record: OrgId: ${orgId} HubspotId: ${hubspotId}`
            );
            if (
              rollBackHubspotIds.has(orgId) &&
              rollBackHubspotIds.get(orgId)
            ) {
              logger.info(`Returning from restore record map: ${orgId}`);
              return true;
            }
            let recordRestored;
            if (operationType === 2 && hubspotId === true) {
              addCronLog(logData, {
                message: `Performing auto sync of user's profile with the organization`,
                data: {
                  organizationId: orgId,
                },
              });
              recordRestored = await this.updateCRMRecord(
                userData,
                rollbackData[orgId],
                true,
                logData
              );
              const rollbackStatusSaved = await updateHubSpotRollbackId({
                jobId,
                userId,
                type: operationType,
                organizationId: orgId,
                hubspotId: recordRestored,
                retryFailure,
              });
              logger.info(
                `Rollback of Auto-sync: ${JSON.stringify(rollbackStatusSaved)}`
              );
              if (rollbackStatusSaved?.error && !rollbackStatusSaved) {
                addCronLog(logData, {
                  message: `Error in storing job data into the database`,
                  error: rollbackStatusSaved,
                });
                return false;
              }
            } else if (operationType === 0 || operationType === 1) {
              addCronLog(logData, {
                message: `Processing the rollback of Hubspot record with hubspot id ${hubspotId}`,
                data: {
                  organizationId: orgId,
                },
              });
              recordRestored = await this.deleteCRMRecord(
                {
                  hubspotIds: hubSpotSyncUpdate,
                },
                {
                  organizationId: orgId,
                  restoreFlag: true,
                  restoreHubspotId: hubspotId,
                  jobData,
                },
                retryFailure,
                logData
              );
            }
            return recordRestored;
          })
        );
      }
      logger.info(
        `Hubspot Restore Response: ${
          restoredCRMData && JSON.stringify(restoredCRMData)
        }`
      );
      if (
        rollBackHubspotStatus ||
        (hubSpotSyncUpdateArray?.length === restoredCRMData.length &&
          restoredCRMData.indexOf(false) === -1)
      ) {
        addCronLog(logData, {
          message: `Rollback of CRM data has been performed successfully.`,
          data: {
            result: restoredCRMData,
          },
        });
        // Update Hubspot CRM record flag into the database
        if (rollBackHubspotStatus === false) {
          const rollbackHubspotStatusUpdated = await updateJob({
            jobId,
            userId,
            type: operationType,
            rollBackHubspotStatus: true,
            retryFailure,
          });
          logger.info(
            `Rollback Hubspot Flag Updated: ${
              rollbackHubspotStatusUpdated &&
              JSON.stringify(rollbackHubspotStatusUpdated)
            }`
          );
        }
        const updateCRMDataInDB = await updateCRMDataInRollback({
          jobId,
          retryFailure,
        });
        logger.info(`Update CRM data into the database: ${updateCRMDataInDB}`);
        if (!updateCRMDataInDB?.error && updateCRMDataInDB) {
          return updateCRMDataInDB;
        }
        addCronLog(logData, {
          message: `Error in updating CRM records in the database.`,
          data: {
            result: updateCRMDataInDB,
          },
        });
        return false;
      }
      // In case of failure, It will reattempt to perform the operation on cronHistory collection
      return false;
    }
    return true;
  }
);

exports.getCRMList = withErrorHandling(async (userData) => {
  const organizationId = getOrgIdLoggedInUser(userData);
  if (organizationId) {
    return CRMSetting.find({
      organizationId,
    });
  }
  return null;
});

exports.updateCRMSetting = withErrorHandling(
  async (payload, userData, zohoData) => {
    const { type } = payload;
    const organizationId = getOrgIdLoggedInUser(userData);
    if (organizationId) {
      if (type === crmTypes.HUBSPOT) {
        const { auth_token: authToken } = payload;
        const crmConfig = {
          authToken,
        };
        const crmSettingExists = await CRMSetting.findOne({
          type,
          organizationId,
        });
        if (!crmSettingExists) {
          // Create new CRM setting
          const crmSettingObject = new CRMSetting({
            type,
            config: crmConfig,
            organizationId,
          });
          return crmSettingObject.save();
        }
        // Update existing crm config
        crmSettingExists.config = crmConfig;
        return crmSettingExists.save();
      }

      if (type === crmTypes.ZOHO) {
        const { zohoClientId, zohoSecretKey } = payload;
        const crmSettingExists = await CRMSetting.findOne({
          type,
          organizationId,
        });
        if (!crmSettingExists) {
          const expiresInSeconds = zohoData.expires_in || 3600;

          // current time in milliseconds + expires_in (converted to ms)
          const zohoAccessTokenExpiresAt = new Date(
            Date.now() + expiresInSeconds * 1000
          );

          // Create new CRM setting
          const crmSettingObject = new CRMSetting({
            type,
            organizationId,
            zohoClientId,
            zohoSecretKey,
            zohoRefreshToken: zohoData.refresh_token,
            zohoAccessToken: zohoData.access_token,
            zohoAccessTokenExpiresAt,
          });
          return crmSettingObject.save();
        }

        return crmSettingExists.save();
      }
    }
    return {
      error: true,
    };
  }
);

exports.calculateCRMIntegrations = withErrorHandling(async (userData) => {
  const organizationId = await getOrgIdLoggedInUser(userData);
  const CRMIntegrationCount = await CRMSetting.countDocuments({
    ...(organizationId ? { organizationId } : null),
  });
  return CRMIntegrationCount;
});

exports.verifyAndRefreshZohoToken = withErrorHandling(
  async (organizationId) => {
    // Find the Zoho CRM setting for the organization
    const crmSetting = await CRMSetting.findOne({
      type: crmTypes.ZOHO,
      organizationId,
    });

    if (!crmSetting) {
      logger.error(
        `Zoho CRM setting not found for organization: ${organizationId}`
      );
      return {
        error: true,
        message: 'Zoho CRM setting not found',
      };
    }

    const { zohoRefreshToken, zohoAccessToken, zohoClientId, zohoSecretKey } =
      crmSetting;

    if (
      !zohoRefreshToken ||
      !zohoAccessToken ||
      !zohoClientId ||
      !zohoSecretKey
    ) {
      logger.error(
        `Missing Zoho credentials for organization: ${organizationId}`
      );
      return {
        error: true,
        message: 'Missing Zoho credentials',
      };
    }

    try {
      // Call the verifyAndRefreshToken API
      const response = await axios.post(
        `${process.env.CRM_API_BASE_URL}/api/v1/zoho/verifyAndRefreshToken`,
        {
          refresh_token: zohoRefreshToken,
          access_token: zohoAccessToken,
          client_id: zohoClientId,
          client_secret: zohoSecretKey,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${process.env.HUBSPOT_KEY}`,
          },
        }
      );

      const tokenData = response?.data?.data || {};
      const { accessToken, isRefreshed, expiresIn } = tokenData;

      // If token was refreshed, update it in the database
      if (isRefreshed) {
        logger.info(
          `Zoho access token refreshed for organization: ${organizationId}`
        );

        const expiresInSeconds = expiresIn || 3600;
        const zohoAccessTokenExpiresAt = new Date(
          Date.now() + expiresInSeconds * 1000
        );

        crmSetting.zohoAccessToken = accessToken;
        crmSetting.zohoAccessTokenExpiresAt = zohoAccessTokenExpiresAt;
        await crmSetting.save();

        return {
          success: true,
          isRefreshed: true,
          accessToken,
        };
      }

      // Token is still valid
      logger.info(
        `Zoho access token is still valid for organization: ${organizationId}`
      );
      return {
        success: true,
        isRefreshed: false,
        accessToken,
      };
    } catch (error) {
      logger.error(
        `Error verifying/refreshing Zoho token for organization ${organizationId}: ${error.message}`
      );
      await sendErrorLogs({
        error,
        mailType: mailConstants.MAIL_TYPES.CRITICAL_ERROR_LOGS,
      });
      return {
        error: true,
        message: error.message,
      };
    }
  }
);
