const { isValidObjectId } = require('mongoose');
const BlockOrganization = require('../models/blockOrganizationModel');
const withErrorHandling = require('../middleware/serviceHandler');
const { getOrgIdLoggedInUser } = require('../helpers/userHelper');
const userRoles = require('../config/constants/userRoles');

const mapDBFields = (field) => {
  let dbField = '';
  switch (field) {
    case 'organization_name':
      dbField = 'organization.name';
      break;
    case 'created_at':
      dbField = 'createdAt';
      break;
    case 'updated_at':
      dbField = 'updatedAt';
      break;
    default:
      dbField = field;
  }
  return dbField;
};

exports.getMyBlockedOrganizationList = withErrorHandling(async (payload) => {
  const {
    loggedInUserData,
    skip,
    limit,
    search,
    sortBy = 'updated_at',
    orderBy = 'desc',
  } = payload;
  const { userType, _id: userId } = loggedInUserData;

  const pipeline = [];
  const matchStage = {};

  // Match Stage
  if (userType === userRoles.FRONT_END_USER) {
    matchStage.userId = userId;
  } else {
    const organizationId = getOrgIdLoggedInUser(loggedInUserData);
    if (organizationId) {
      matchStage.organizationId = organizationId;
    }
  }
  if (Object.keys(matchStage).length > 0) {
    pipeline.push({ $match: matchStage });
  }

  // Lookup stage to connect with organization
  pipeline.push({
    $lookup: {
      from: 'organizations',
      localField: 'organizationId',
      foreignField: '_id',
      as: 'organization',
    },
  });
  pipeline.push({ $unwind: '$organization' });
  // Lookup stage to match if the organization is authorized (compare userId for isAuthorized)
  pipeline.push({
    $lookup: {
      from: 'users',
      localField: 'organization.userId',
      foreignField: '_id',
      as: 'organization_user',
    },
  });
  pipeline.push({ $unwind: '$organization_user' });
  // Lookup stage to get organization data such as organization name
  pipeline.push({
    $lookup: {
      from: 'users',
      localField: 'userId',
      foreignField: '_id',
      as: 'user',
    },
  });
  pipeline.push({ $unwind: '$user' });

  // Match stage after lookup
  pipeline.push({
    $match: {
      'organization_user.isAuthorized': true,
      'organization_user.isDeleted': false,
    },
  });
  if (userType === userRoles.FRONT_END_USER && search) {
    pipeline.push({
      $match: {
        'organization.name': {
          $regex: new RegExp(search, 'i'),
        },
      },
    });
  } else if (search) {
    pipeline.push({
      $match: {
        $or: [
          {
            'organization.name': {
              $regex: new RegExp(search, 'i'),
            },
          },
          {
            'user.mobileNumber': {
              $regex: new RegExp(search, 'i'),
            },
          },
        ],
      },
    });
  }

  // sortby and orderby stage
  if (sortBy && orderBy) {
    const sortObject = {};
    const sortByField = mapDBFields(sortBy);
    sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
    pipeline.push({
      $sort: sortObject,
    });
  }

  // Calculate total records and total pages
  const totalRecordPipeline = [...pipeline];
  const totalCountStage = { $count: 'totalCount' };
  totalRecordPipeline.push(totalCountStage);
  const organizationListCount =
    await BlockOrganization.aggregate(totalRecordPipeline);
  const totalCount =
    (organizationListCount.length > 0 && organizationListCount[0].totalCount) ||
    0;
  const totalPages = Math.ceil(totalCount / limit) || '1';

  // Pagination stages
  if (skip && typeof skip === 'number') {
    pipeline.push({ $skip: skip });
  }
  if (limit && typeof limit === 'number') {
    pipeline.push({ $limit: limit });
  }

  const blockedOrganizationList = await BlockOrganization.aggregate(pipeline);
  return {
    blockedOrganizationList,
    pageInfo: {
      totalCount,
      totalPages,
      currentPage: Math.ceil((skip + 1) / limit),
    },
  };
});

exports.createBlockOrganization = withErrorHandling(
  async (payload, session) => {
    const { userId, organizationId, reasonForBlock } = payload;
    const organization = new BlockOrganization({
      userId,
      organizationId,
      reasonForBlock,
    });

    // If the session is provided, use it for the transaction
    if (session) {
      await organization.save({ session });
    } else {
      await organization.save();
    }

    return organization;
  }
);

exports.getBlockOrganization = withErrorHandling(
  async (orgId, userId, selectString) => {
    if (isValidObjectId(orgId)) {
      return BlockOrganization.findOne({
        organizationId: orgId,
        userId,
      }).select(selectString);
    }
    return false;
  }
);

exports.deleteBlockOrganization = withErrorHandling(
  async (orgId, userId, session) => {
    const blockedOrganization = await this.getBlockOrganization(orgId, userId);
    if (blockedOrganization) {
      // If the session is provided, use it for the transaction
      if (session) {
        return BlockOrganization.deleteOne(
          { organizationId: orgId, userId },
          { session }
        );
      }
      return BlockOrganization.deleteOne({ organizationId: orgId, userId });
    }
    return null;
  }
);

exports.getBlockOrganizationOfUser = withErrorHandling(
  async (userId, selectString) => {
    if (userId && isValidObjectId(userId)) {
      return BlockOrganization.find({
        userId,
      }).select(selectString);
    }
    return false;
  }
);

exports.deleteBlockAllOrganization = withErrorHandling(async (userId) => {
  if (userId && isValidObjectId(userId)) {
    const result = await BlockOrganization.deleteMany({ userId });
    return result;
  }
  return false;
});
