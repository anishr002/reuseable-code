const path = require('path');
const mongoose = require('mongoose');
const { isValidObjectId } = require('mongoose');
const Organization = require('../models/organizationModel');
const User = require('../models/userModel');
const withErrorHandling = require('../middleware/serviceHandler');
const { createQRCode } = require('../helpers/QRHelper');
const { getUserSettings } = require('./commonService');
const mailConstants = require('../config/constants/mailOptions');
const { sendEmail } = require('../helpers/emailServices');
const userRoles = require('../config/constants/userRoles');

// S3 related imports
const AWSconfig = require('../config/AWSConfig');
const { deleteImage } = require('../helpers/S3BucketHelper');

const mapDBFieldsOrg = (field) => {
  let dbField = '';
  switch (field) {
    case 'name':
      dbField = 'name';
      break;
    case 'registered_number':
      dbField = 'registeredNumber';
      break;
    case 'date_of_incorporation':
      dbField = 'dateOfIncorporation';
      break;
    case 'created_at':
      dbField = 'createdAt';
      break;
    case 'updated_at':
      dbField = 'updatedAt';
      break;
    case 'mobile_number':
      dbField = 'mobileNumber';
      break;
    case 'country_code':
      dbField = 'countryCode';
      break;
    default:
      dbField = field;
  }
  return dbField;
};

exports.getAuthorizedOrgCount = withErrorHandling(async () =>
  User.countDocuments({
    isAuthorized: true,
    isDeleted: false,
  })
);

exports.getConnectedUsersCount = withErrorHandling(async (userData) => {
  if (!userData._id) return false;
  const organizationId =
    userData.userType === userRoles.ORGANIZATION_ADMIN
      ? userData?._id
      : userData?.organizationId;
  if (organizationId) {
    let organizationData = await this.findOrganizationById(organizationId);
    organizationData = organizationData ? organizationData[0] : null;
    if (!organizationData?.trustedUsers?.length) {
      return false;
    }
    return organizationData?.trustedUsers?.length;
  }
});

exports.getMyTrusted = withErrorHandling(
  async ({ where, selectString, skip, limit }) => {
    const whereCondition = where || {};
    // Add condition to filter organizations based on policyId and policySubRules
    whereCondition.policyId = { $ne: null, $exists: true };
    whereCondition.policySubRules = { $ne: null, $exists: true };

    // Count total number of documents
    const totalCount = await Organization.countDocuments(whereCondition);
    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = Organization.find(whereCondition).select(selectString);

    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    query.populate('userId');

    const organizationList = await query.exec();
    return {
      organizationList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.getAllTrusted = withErrorHandling(
  async ({ userId, id, countryCode, search, skip, limit, location, miles }) => {
    /** Aggregation */

    // Country code comparision
    const matchStage = {
      'contactNumbers.0': {
        $regex: `^\\+${countryCode}\\|`,
      },
    };
    matchStage.isDeleted = false;
    const pipeline = [];

    // Location stage
    // if (location?.coordinates?.length) {
    //   pipeline.push({
    //     // $geoNear: {
    //     //   near: location,
    //     //   distanceField: 'distance',
    //     //   maxDistance: miles * 1609.34, // Convert miles to meters
    //     //   spherical: true,
    //     // },
    //     $geoNear: {
    //       near: {
    //         type: 'Point',
    //         coordinates: location.coordinates,
    //       },
    //       maxDistance: miles * 1609.34, // Convert miles to meters
    //       distanceField: 'calculatedDistance',
    //       spherical: true,
    //     },
    //   });
    // }

    if (id && id !== '') {
      matchStage._id = new mongoose.Types.ObjectId(id);
    }
    if (search && search !== '') {
      matchStage.name = { $regex: new RegExp(search, 'i') };
    }
    // matchStage to remove blocked organizations from the list
    if (userId) {
      matchStage.blockedUsers = {
        $nin: [userId.toString()],
      };
    }

    // matchStage to remove blocked organizations from the list
    if (userId) {
      matchStage.trustedUsers = {
        $nin: [userId.toString()],
      };
    }

    // Add a $match stage to exclude organizations with undefined or null policyId or policySubRules
    matchStage.policyId = { $ne: null, $exists: true };
    matchStage.policySubRules = { $ne: null, $exists: true };

    // Add a $sort stage to sort by name in ascending order
    pipeline.push({
      $sort: {
        name: 1, // 1 for ascending order, -1 for descending order
      },
    });

    // if (is_trusted === undefined || is_trusted === true) {
    //   matchStage.isTrusted = true;
    // }

    if (Object.keys(matchStage).length > 0) {
      pipeline.push({ $match: matchStage });
    }

    // Lookup stage to match userId for isAuthorized
    pipeline.push({
      $lookup: {
        from: 'users',
        localField: 'userId',
        foreignField: '_id',
        as: 'user',
      },
    });
    pipeline.push({ $unwind: '$user' });

    // if (is_trusted === false) {
    pipeline.push({
      $match: { 'user.isAuthorized': true },
    });
    // }

    if (location?.coordinates?.length && location?.miles) {
      // Search by location: Get organization IDs within the specified radius
      const organizationsWithinRadius = await Organization.find({
        location: {
          $geoWithin: {
            $centerSphere: [location.coordinates, miles / 3963.2], // Earth radius in miles
          },
        },
      });
      // Extract IDs of organizations within the radius
      const organizationIdsWithinRadius = organizationsWithinRadius.map(
        (org) => org._id
      );
      // Add stage to filter by organization IDs within the radius
      pipeline.push({
        $match: {
          _id: { $in: organizationIdsWithinRadius },
        },
      });
    }

    // Calculate total records and total pages
    const totalRecordPipeline = [...pipeline];
    const totalCountStage = { $count: 'totalCount' };
    totalRecordPipeline.push(totalCountStage);
    const organizationListCount =
      await Organization.aggregate(totalRecordPipeline);
    const totalCount =
      (organizationListCount.length > 0 &&
        organizationListCount[0].totalCount) ||
      0;
    const totalPages = Math.ceil(totalCount / limit);

    // Pagination stages
    if (skip && typeof skip === 'number') {
      pipeline.push({ $skip: skip });
    }
    if (limit && typeof limit === 'number') {
      pipeline.push({ $limit: limit });
    }

    const organizationList = await Organization.aggregate(pipeline);

    return {
      organizationList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.getAllOrganization = withErrorHandling(
  async ({
    where,
    selectString,
    skip,
    limit,
    sortBy = 'updated_at',
    orderBy = 'desc',
  }) => {
    const whereCondition = where || {};

    // Count total number of documents
    const totalCount = await Organization.countDocuments(whereCondition);

    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = Organization.find(whereCondition).select(selectString);

    // Handle sorting
    if (sortBy && orderBy) {
      const sortObject = {};
      const sortByField = mapDBFieldsOrg(sortBy);
      sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
      query.sort(sortObject);
    }

    // Handle pagination
    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    // Execute the query
    const organizationList = await query.exec();

    return {
      organizationList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.findOrganizationById = withErrorHandling(
  async (orgId, selectString) => {
    if (orgId && isValidObjectId(orgId)) {
      return Organization.find({
        userId: orgId,
        isDeleted: false,
      })
        .select(selectString)
        .populate('userId');
    }
    return null;
  }
);

exports.findValidOrganization = withErrorHandling(async ({ orgId }) => {
  if (orgId && isValidObjectId(orgId)) {
    /** Aggregation */
    const matchStage = {};
    matchStage.isDeleted = false;
    matchStage._id = new mongoose.Types.ObjectId(orgId);

    const pipeline = [];
    if (Object.keys(matchStage).length > 0) {
      pipeline.push({ $match: matchStage });
    }

    // Lookup stage to match isAuthorized
    pipeline.unshift({
      $lookup: {
        from: 'users',
        localField: 'userId',
        foreignField: '_id',
        as: 'user',
      },
    });
    pipeline.push({ $unwind: '$user' });

    pipeline.push({
      $match: { $or: [{ 'user.isAuthorized': true }] },
    });
    const organization = await Organization.aggregate(pipeline);
    return organization;
  }
  return null;
});

exports.getOrganizationById = withErrorHandling(async (orgId, selectString) => {
  if (isValidObjectId(orgId)) {
    return Organization.findOne({
      _id: orgId,
      isDeleted: false,
    }).select(selectString);
  }
  return null;
});

exports.getOrganizationByUserId = withErrorHandling(
  async (userId, selectString) => {
    if (userId && isValidObjectId(userId)) {
      const organization = await Organization.findOne({
        userId,
        isDeleted: false,
      }).select(selectString);
      return organization;
    }
    return null;
  }
);

exports.findOrganizationByName = withErrorHandling(
  async (organizationName, selectString) => {
    if (organizationName) {
      return Organization.findOne({
        name: organizationName,
        isDeleted: false,
      }).select(selectString);
    }
    return null;
  }
);

exports.updateOrganizationProfile = withErrorHandling(
  async (
    orgId,
    {
      registered_number,
      date_of_incorporation,
      name,
      type,
      office_address,
      description,
      website,
      legal_status,
      email_id,
      contact_number,
      linkedin,
      twitter,
      policy_id: policyId,
      sub_rule_ids: policySubRules,
    },
    findUserById,
    findUser,
    updateSocialInfo
  ) => {
    if (!orgId) {
      return null;
    }

    // Check if the organization with the given userId exists
    let secondaryEmails = [];
    let orgEmail = null;
    const emailsValues = email_id !== undefined ? email_id : [];
    const userData = await findUserById(orgId);
    const superUser = await findUser({
      userType: userRoles.SUPER_ADMIN,
      isActive: true,
      isDeleted: false,
    });
    if (userData) {
      await updateSocialInfo(orgId, {
        linkedin: linkedin !== undefined ? linkedin : null,
        twitter: twitter !== undefined ? twitter : null,
      });
      await userData.save();
      orgEmail = userData?.email || null;
      secondaryEmails = emailsValues.filter((email) => email !== orgEmail);
    }

    // Check if the same registered_number already exists for another org
    if (registered_number) {
      const existingOrg = await Organization.findOne({
        registeredNumber: registered_number,
      });

      if (existingOrg) {
        throw new Error(
          `Organization with registered number "${registered_number}" already exists`
        );
      }
    }

    const organization = await Organization.findOne({
      userId: orgId,
      isDeleted: false,
    });

    // Create a new organization or update existing organization
    const updatedOrganization = organization
      ? await Organization.findOneAndUpdate(
          { userId: orgId },
          {
            $set: {
              registeredNumber: registered_number,
              dateOfIncorporation: date_of_incorporation,
              name,
              type,
              address: office_address,
              description,
              website,
              legalStatus: legal_status,
              emails: secondaryEmails,
              contactNumbers: contact_number,
              policyId,
              policySubRules,
            },
          },
          { new: true } // Return the updated document
        )
      : await new Organization({
          userId: orgId,
          registeredNumber: registered_number,
          dateOfIncorporation: date_of_incorporation,
          name,
          type,
          address: office_address,
          description,
          website,
          legalStatus: legal_status,
          emails: secondaryEmails,
          contactNumbers: contact_number,
          policyId,
          policySubRules,
        }).save();
    // send email notification to the super-admin
    if (!organization) {
      // Get email to send email notification to the super-admin
      const userSettings = await getUserSettings(null, 'settings');
      // Send mail to the super-admin
      const mailOptionsSuperAdmin = {
        to: userSettings?.settings?.toEmail?.join(', '),
        type: mailConstants.MAIL_TYPES.ORGANIZATION_REGISTERED_MAIL,
        userData: updatedOrganization,
        templateVars: {
          link: `${process.env.FRONT_APP_BASE_URL}/organization-managment/edit/${updatedOrganization._id.toString()}`,
          email: email_id[0],
        },
      };
      await sendEmail(mailOptionsSuperAdmin);

      if (orgEmail && superUser) {
        // Send mail to the organization
        const mailOptionsOrganisation = {
          to: orgEmail,
          type: mailConstants.MAIL_TYPES.PROFILE_APPROVAL_PENDING_NOTIFICATION,
          userData: superUser,
          templateVars: {
            link: `${process.env.ORG_FRONT_URL}/login`,
            organizationName: updatedOrganization.name,
          },
        };
        await sendEmail(mailOptionsOrganisation);
      }
    }
    return updatedOrganization;
  }
);

exports.create = withErrorHandling(async (payload) => {
  const {
    registeredNumber,
    dateOfIncorporation,
    name,
    type,
    address,
    description,
    website,
    legalStatus,
    emails,
    contactNumbers,
    userId,
    // trustedStatus,
    policyId,
    policySubRules,
  } = payload;

  const organization = new Organization({
    registeredNumber,
    dateOfIncorporation,
    name,
    type,
    address,
    description,
    website,
    legalStatus,
    emails,
    contactNumbers,
    userId,
    policyId,
    policySubRules,
    // isTrusted: trustedStatus === 'yes',
  });
  // Create QR code when trusted organization is created
  // if (trustedStatus === 'yes') {
  //   // Create a new QR code
  //   const QRCode = await createQRCode({
  //     organizationId: organization?._id,
  //   });
  //   if (QRCode) {
  //     // Convert base64 QR code image to a Buffer
  //     const buffer = Buffer.from(
  //       QRCode.replace(/^data:image\/png;base64,/, ''),
  //       'base64'
  //     );
  //     organization.QRImage = buffer;
  //   }
  // }
  return organization.save();
});

exports.update = withErrorHandling(async (orgId, payload, findUserById) => {
  const {
    registeredNumber,
    dateOfIncorporation,
    name,
    type,
    address,
    description,
    website,
    legalStatus,
    emails,
    contactNumbers,
    authorizedStatus,
    // trustedStatus,
    policyId,
    policySubRules,
  } = payload;
  const organization = await this.getOrganizationById(orgId);

  if (organization && !organization?.error) {
    // Create QR code when organization is updated to trusted or authorized
    if (authorizedStatus === 'yes' && !organization?.QRImage) {
      // Create a new QR code
      const QRCode = await createQRCode({
        organizationId: organization?._id,
      });
      if (QRCode) {
        // Convert base64 QR code image to a Buffer
        const buffer = Buffer.from(
          QRCode.replace(/^data:image\/png;base64,/, ''),
          'base64'
        );
        organization.QRImage = buffer;
      }
    }
    const userData = await findUserById(organization.userId);
    userData.isAuthorized = authorizedStatus === 'yes';
    await userData.save();
    const orgEmail = userData?.email || null;
    const secondaryEmails = emails.filter((email) => email !== orgEmail);

    organization.registeredNumber = registeredNumber;
    organization.dateOfIncorporation = dateOfIncorporation;
    organization.name = name;
    organization.type = type;
    organization.address = address;
    organization.description = description;
    organization.website = website;
    organization.legalStatus = legalStatus;
    organization.emails = secondaryEmails;
    organization.contactNumbers = contactNumbers;
    organization.policyId = policyId;
    organization.policySubRules = policySubRules;
    // organization.isTrusted = trustedStatus === 'yes';
    return organization.save();
  }
  return organization;
});

exports.deleteOne = withErrorHandling(
  async (orgId, removeProfilePicture, deactivateUser, byAdmin = false) => {
    const orgExists = await this.getOrganizationById(orgId);
    if (orgExists) {
      const orgUserId = orgExists?.userId || null;
      if (orgUserId !== null) {
        await deactivateUser(orgUserId, byAdmin);
        await removeProfilePicture(orgUserId);
      }
      // return Organization.deleteOne({
      //   _id: orgId,
      // });
      return Organization.updateOne(
        { _id: orgId },
        { $set: { isDeleted: true } }
      );
    }
    return null;
  }
);

exports.removeDocumentPicture = withErrorHandling(
  async (orgId, docId, filePath, isFileExists, deleteFile) => {
    const document = await this.findDocumentById(orgId, docId);
    if (document) {
      const documentImg = document?.url;
      const filePathToDelete = path.join(filePath, documentImg);
      const isExists = await isFileExists(filePathToDelete);
      if (isExists) {
        const isDeleted = await deleteFile(filePathToDelete);
        if (!isDeleted) {
          return false;
        }
      }
    }
    return true;
  }
);

exports.removeS3Document = withErrorHandling(
  async (orgId, docId, orgUserId) => {
    const document = await this.findDocumentById(orgId, docId);
    if (document) {
      const documentImg = document?.url;
      // Remove image from s3 bucket
      const deleteDoc = await deleteImage(
        AWSconfig.bucketName,
        `${orgUserId}/documents`,
        documentImg
      );
      if (!deleteDoc.status) {
        return false;
      }
    }
    return true;
  }
);

exports.saveDocument = withErrorHandling(
  async (orgId, documentData, filePath, isFileExists, deleteFile) => {
    if (orgId && isValidObjectId(orgId)) {
      const organization = await Organization.findById(orgId);

      if (organization) {
        // Check if a document with the same type already exists
        const existingDocumentIndex = organization.documents.findIndex(
          (doc) => doc.type === documentData.type
        );

        if (existingDocumentIndex !== -1) {
          // Remove old document
          await this.removeDocumentPicture(
            orgId,
            organization.documents[existingDocumentIndex]._id,
            filePath,
            isFileExists,
            deleteFile
          );
          // If a document with the same type exists, update its URL
          organization.documents[existingDocumentIndex].url = documentData.url;
        } else {
          // If no document with the same type exists, add a new document
          organization.documents.push(documentData);
        }

        // Save the updated organization
        const updatedOrganization = await organization.save();
        return updatedOrganization;
      }
    }

    return null;
  }
);

exports.removeDocument = withErrorHandling(
  async (orgId, documentIdToRemove) => {
    if (
      orgId &&
      isValidObjectId(orgId) &&
      documentIdToRemove &&
      isValidObjectId(documentIdToRemove)
    ) {
      const updatedOrganization = await Organization.findByIdAndUpdate(
        orgId,
        {
          $pull: {
            documents: {
              _id: documentIdToRemove,
            },
          },
        },
        { new: true } // Return the updated document
      );

      return updatedOrganization;
    }
    return null;
  }
);

exports.findDocumentById = withErrorHandling(async (orgId, documentId) => {
  if (
    orgId &&
    isValidObjectId(orgId) &&
    documentId &&
    isValidObjectId(documentId)
  ) {
    const organization = await Organization.findById(orgId);

    if (organization) {
      const foundDocument = organization.documents.find((doc) =>
        doc._id.equals(documentId)
      );
      return foundDocument;
    }
  }

  return null;
});

exports.saveTrustedUsers = withErrorHandling(async (organizationId, userId) => {
  try {
    const organization = await Organization.findById(organizationId);
    if (!organization) {
      // throw new Error('Organization not found');
      return false;
    }
    if (organization && organization.trustedUsers !== undefined) {
      const exists = organization.trustedUsers.includes(userId.toString());
      if (!exists) {
        organization.trustedUsers.push(userId.toString());
        await organization.save();
      }
      return true;
    }
    organization.trustedUsers = userId;
    await organization.save();
    return true;
  } catch (error) {
    return false;
  }
});

exports.saveBlockedUsers = withErrorHandling(async (organizationId, userId) => {
  try {
    const organization = await Organization.findById(organizationId);
    if (!organization) {
      // throw new Error('Organization not found');
      return false;
    }
    if (organization && organization.blockedUsers !== undefined) {
      const exists = organization.blockedUsers.includes(userId.toString());
      if (!exists) {
        organization.blockedUsers.push(userId.toString());
        await organization.save();
      }
      return true;
    }
    organization.blockedUsers = userId;
    await organization.save();
    return true;
  } catch (error) {
    return false;
  }
});

exports.removeTrustedUsers = withErrorHandling(
  async (organizationId, userId, transaction = null) => {
    try {
      const organization = await Organization.findById(organizationId);
      if (!organization) {
        // throw new Error('User not found');
        return false;
      }

      if (
        transaction === 'session' &&
        organization &&
        (organization.trustedUsers === undefined ||
          organization.trustedUsers.length === 0)
      ) {
        return true;
      }

      if (organization && organization.trustedUsers !== undefined) {
        const exists = organization.trustedUsers.includes(userId.toString());
        if (exists) {
          organization.trustedUsers = organization.trustedUsers.filter(
            (usrId) => usrId !== userId.toString()
          );
          // console.log(userId.toString());
          if (organization.trustedUsers.length === 0) {
            organization.trustedUsers = undefined;
          }
          await organization.save();
          return true;
        }

        if (transaction === 'session' && !exists) {
          return true;
        }
      }

      return null;
    } catch (error) {
      return false;
    }
  }
);

exports.removeBlockedUsers = withErrorHandling(
  async (organizationId, userId, transaction = null) => {
    try {
      const organization = await Organization.findById(organizationId);
      if (!organization) {
        // throw new Error('User not found');
        return false;
      }

      if (
        transaction === 'session' &&
        organization &&
        (organization.blockedUsers === undefined ||
          organization.blockedUsers.length === 0)
      ) {
        return true;
      }

      if (organization && organization.blockedUsers !== undefined) {
        const exists = organization.blockedUsers.includes(userId.toString());
        if (exists) {
          organization.blockedUsers = organization.blockedUsers.filter(
            (usrId) => usrId !== userId.toString()
          );
          if (organization.blockedUsers.length === 0) {
            organization.blockedUsers = undefined;
          }
          await organization.save();
          return true;
        }

        if (transaction === 'session' && !exists) {
          return true;
        }
      }

      return null;
    } catch (error) {
      return false;
    }
  }
);

exports.getAllConnectedUsers = withErrorHandling(
  async ({
    // organizationId,
    skip,
    limit,
    search,
    sortBy = 'updated_at',
    orderBy = 'desc',
  }) => {
    // let organizationData = await this.findOrganizationById(organizationId);
    // organizationData = organizationData ? organizationData[0] : null;
    // if (!organizationData || !organizationData?.trustedUsers?.length) {
    //   return {
    //     userList: [],
    //     pageInfo: {
    //       totalCount: 0,
    //       totalPages: 1,
    //       currentPage: 1,
    //     },
    //   };
    // }
    const whereCondition = {
      // _id: { $in: organizationData.trustedUsers },
      userType: userRoles.FRONT_END_USER,
      isDeleted: false,
      isActive: true,
      ...(search && search !== ''
        ? {
            // Search with regex
            mobileNumber: {
              $regex: new RegExp(search, 'i'),
            },
          }
        : null),
    };

    // Count total number of documents
    const totalCount = await User.countDocuments(whereCondition);

    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = User.find(whereCondition);

    // Handle sorting
    if (sortBy && orderBy) {
      const sortObject = {};
      const sortByField = mapDBFieldsOrg(sortBy);
      sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
      query.sort(sortObject);
    }

    // Handle pagination
    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    // Execute the query
    const userList = await query.exec();

    return {
      userList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.formatSharedData = (sharedDataArray) => {
  const output = {
    shared_email_address: [],
    shared_mobile_number: [],
    shared_address: [],
    shared_social_data: {
      linkedin: '',
      twitter: '',
    },
  };
  if (Array.isArray(sharedDataArray) && sharedDataArray.length > 0) {
    sharedDataArray.forEach((sharedDataLabel) => {
      if (sharedDataLabel.startsWith('mobileNumber')) {
        const number = parseInt(
          sharedDataLabel.replace('mobileNumber', ''),
          10
        );
        output.shared_mobile_number.push(number);
      } else if (sharedDataLabel.startsWith('email')) {
        const number = parseInt(sharedDataLabel.replace('email', ''), 10);
        output.shared_email_address.push(number);
      } else if (sharedDataLabel.startsWith('address')) {
        const number = parseInt(sharedDataLabel.replace('address', ''), 10);
        output.shared_address.push(number);
      } else if (sharedDataLabel === 'linkedin') {
        output.shared_social_data.linkedin = sharedDataLabel;
      } else if (sharedDataLabel === 'twitter') {
        output.shared_social_data.twitter = sharedDataLabel;
      }
    });
  }
  return output;
};

exports.getOrganizationsByNameOrId = withErrorHandling(
  async (organizationIdentifiers, selectString, queryType = 'id') => {
    if (organizationIdentifiers.length > 0) {
      const query = {
        isDeleted: false,
        [queryType === 'name' ? 'name' : '_id']: {
          $in: organizationIdentifiers,
        },
      };

      return Organization.find(query).select(selectString).populate({
        path: 'userId',
        select: '_id email profileImage',
      });
    }

    return null;
  }
);

exports.getProfileImageByName = (organizations, organizationName) => {
  const foundOrganization = organizations.find(
    (org) => org.name === organizationName
  );

  if (foundOrganization) {
    return foundOrganization?.userId?.profileImage || null;
  }
  return null;
};

exports.isDuplicateRegisteredNumber = async (registeredNumber) => {
  if (!registeredNumber) return false;

  const existingOrg = await Organization.findOne({
    registeredNumber
  });

  return !!existingOrg;
}


exports.isPolicySync = async (policyId) => {
  try {
    const organizationWithPolicyId = await Organization.findOne({
      policyId,
    });
    return !!organizationWithPolicyId;
  } catch (error) {
    return false;
  }
};

exports.isPolicyAndRuleSync = async (policyId, subRuleId) => {
  try {
    const organizations = await Organization.find({ policyId });
    // eslint-disable-next-line no-restricted-syntax
    for (const organization of organizations) {
      if (organization.policySubRules.includes(subRuleId.toString())) {
        return true;
      }
    }
    return false;
  } catch (error) {
    return false;
  }
};
