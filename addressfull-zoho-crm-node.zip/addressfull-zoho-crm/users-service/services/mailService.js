const Mail = require('../models/mailModel');
const MailType = require('../models/mailTypeModel');
const withErrorHandling = require('../middleware/serviceHandler');
const userRoles = require('../config/constants/userRoles');

exports.findTemplatesByUser = withErrorHandling(
  async (createdBy, selectString) =>
    Mail.find({
      createdBy,
      status: true,
    }).select(selectString)
);

exports.findSuperAdminMailTemplates = withErrorHandling(async (selectString) =>
  Mail.find({
    createdBy: null,
    status: true,
  }).select(selectString)
);

exports.findSuperAdminMailTemplateByType = withErrorHandling(
  async (mailType, selectString) =>
    Mail.findOne({
      createdBy: null,
      mailType,
      status: true,
    }).select(selectString)
);

exports.findDefaultTemplatesByUserType = withErrorHandling(
  async (userType, selectString) =>
    MailType.find({
      userType,
      status: true,
    }).select(selectString)
);

exports.findTemplateByType = withErrorHandling(
  async (payload, selectString) => {
    const { mailType, userId } = payload;
    return Mail.findOne({
      createdBy: userId,
      mailType,
    }).select(selectString);
  }
);

exports.finddefaultTemplateByType = withErrorHandling(
  async (payload, selectString) => {
    const { mailType, userType } = payload;
    return MailType.findOne({
      userType,
      mailType,
    }).select(selectString);
  }
);

exports.updateTemplate = withErrorHandling(async (payload, selectString) => {
  // const { mailType, userId, fromName, fromEmail, toEmail, subject, body } =
  //   payload;
  const { mailType, userId, subject, body } = payload;
  const isExistsMail = await Mail.findOne({
    createdBy: userId,
    mailType,
  }).select(selectString);
  if (!isExistsMail) {
    // Create new template
    const emailTemplate = new Mail({
      mailType,
      createdBy: userId,
      // fromName,
      // fromEmail,
      // toEmail,
      subject,
      body,
    });
    return emailTemplate.save();
  }
  // isExistsMail.fromName = fromName;
  // isExistsMail.fromEmail = fromEmail;
  // isExistsMail.toEmail = toEmail;
  isExistsMail.subject = subject;
  isExistsMail.body = body;
  return isExistsMail.save();
});

exports.filterTemplateByUserData = withErrorHandling(async (payload) => {
  const { mailType, userData } = payload;
  let userTemplateData;
  if (userData?._id) {
    userTemplateData = await this.findTemplateByType({
      mailType,
      userId: userData._id,
    });
  }
  // Find template by createdBy
  if (!userTemplateData) {
    if (userData?.createdBy) {
      userTemplateData = await this.findTemplateByType({
        mailType,
        userId: userData.createdBy,
      });
    }
  }
  // Find template created by super-admin
  if (!userTemplateData) {
    userTemplateData = await this.findSuperAdminMailTemplateByType(mailType);
  }
  // Find default template
  if (!userTemplateData) {
    userTemplateData = await this.finddefaultTemplateByType({
      mailType,
      userType: this.getCreatedByUserType(userData) || userRoles.SUPER_ADMIN,
    });
  }
  // Find default templates of super-admin
  if (!userTemplateData) {
    userTemplateData = await this.finddefaultTemplateByType({
      mailType,
      userType: userRoles.SUPER_ADMIN,
    });
  }
  return userTemplateData;
});

exports.formatEmailResponse = async (payload, userData) => {
  const userType = this.getCreatedByUserType(userData);
  const templateData = await this.finddefaultTemplateByType({
    userType,
    mailType: payload.mailType,
  });
  return {
    mail_title: templateData?.title || null,
    mail_type: payload.mailType || null,
    // from_name: payload.fromName || null,
    // from_email: payload.fromEmail || null,
    // to_email: payload?.toEmail || [],
    subject: payload.subject || null,
    body: payload.body || null,
  };
};

exports.getCreatedByUserType = (user) => {
  let createdByUserType;
  if (user?.userType) {
    createdByUserType = user.userType;
  } else if (user?.isAdminMember === true) {
    createdByUserType = userRoles.SUPER_ADMIN;
  } else {
    createdByUserType = userRoles.ORGANIZATION_ADMIN;
  }
  return createdByUserType;
};
