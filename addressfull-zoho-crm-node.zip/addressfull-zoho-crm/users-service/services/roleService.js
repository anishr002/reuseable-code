const Role = require('../models/userRoleModel');
const User = require('../models/userModel');
const withErrorHandling = require('../middleware/serviceHandler');

const findOneUser = withErrorHandling(async (whereObj, selectString) => {
  const user = await User.findOne(whereObj).select(selectString);
  return user;
});

const mapDBFields = (field) => {
  let dbField = '';
  switch (field) {
    case 'active':
      dbField = 'isActive';
      break;
    case 'created_at':
      dbField = 'createdAt';
      break;
    case 'updated_at':
      dbField = 'updatedAt';
      break;
    default:
      dbField = field;
  }
  return dbField;
};

exports.create = withErrorHandling(async (payload) => {
  const { name, status, permissions, createdBy } = payload;
  const userRole = new Role({
    name,
    isActive: status,
    permissions,
    createdBy,
  });
  return userRole.save();
});

exports.findRoleById = withErrorHandling(async (roleId, selectString) => {
  if (roleId) {
    return Role.findById(roleId).select(selectString);
  }
  return null;
});

exports.findOneRole = withErrorHandling(
  async ({ roleId, userId, selectString }) => {
    if (roleId) {
      return Role.findOne({
        _id: roleId,
        createdBy: userId,
      }).select(selectString);
    }
    return null;
  }
);

exports.findRoleByName = withErrorHandling(
  async ({ roleName, createdBy, selectString }) => {
    if (roleName) {
      return Role.findOne({
        createdBy,
        name: {
          $regex: new RegExp(`^${roleName}$`, 'i'),
        },
      }).select(selectString);
    }
    return null;
  }
);

exports.getRoleList = withErrorHandling(
  async ({
    where,
    selectString,
    skip,
    limit,
    sortBy = 'updated_at',
    orderBy = 'desc',
  }) => {
    const whereCondition = where || {};

    // Count total number of documents
    const totalCount = await Role.countDocuments(whereCondition);
    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = Role.find(whereCondition).select(selectString);

    if (sortBy && orderBy) {
      const sortObject = {};
      const sortByField = mapDBFields(sortBy);
      sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
      query.sort(sortObject);
    }
    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    const rolesList = await query.exec();
    return {
      rolesList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.update = withErrorHandling(async (roleId, payload) => {
  const { name, status, permissions, userId } = payload;
  const role = await this.findRoleById(roleId);
  if (role.isActive === true && status === false) {
    // Verify if user exists with this role
    const usersWithRole = await findOneUser({
      role: roleId,
      isDeleted: false,
      createdBy: userId,
    });
    if (usersWithRole) {
      return {
        userExists: true,
      };
    }
  }
  // Check if Role with same name exists
  const roleNameExists = await this.findRoleByName({
    roleName: name,
    createdBy: userId,
  });
  if (
    roleNameExists &&
    roleNameExists._id.toString() !== roleId &&
    Object.keys(roleNameExists).length
  ) {
    return {
      roleNameExists: true,
    };
  }
  if (role) {
    role.name = name;
    role.isActive = status;
    role.permissions = permissions;
  }
  return role.save();
});

exports.deleteOne = withErrorHandling(async (roleId, createdBy) => {
  const roleExists = await this.findRoleById(roleId);
  if (roleExists) {
    const usersWithRole = await findOneUser({
      role: roleId,
      isDeleted: false,
      createdBy,
    });
    if (usersWithRole) {
      return {
        userExists: true,
      };
    }
    return Role.deleteOne({
      _id: roleId,
    });
  }
  return null;
});

exports.formatResponseDocument = (responseDocument) => ({
  id: responseDocument._id,
  name: responseDocument.name || null,
  permissions: responseDocument.permissions || null,
  active: responseDocument.isActive,
  created_at: responseDocument.createdAt,
  updated_at: responseDocument.updatedAt,
});
