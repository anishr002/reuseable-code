const systemModule = require('../models/systemModuleModel');
const withErrorHandling = require('../middleware/serviceHandler');
const commonUtils = require('../utils/common');

const getAll = withErrorHandling(async () =>
  systemModule.find({ status: true })
);

exports.findModulesByUser = withErrorHandling(async (userType, selectString) =>
  systemModule
    .find({
      userType,
      status: true,
    })
    .select(selectString)
);

// Dependency Injection: Set the getAll function in common.js
commonUtils.setGetAllModules(getAll);

exports.getAll = getAll;
