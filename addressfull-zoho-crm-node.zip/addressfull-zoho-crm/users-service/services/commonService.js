const moment = require('moment-timezone');
const { mongoose, isValidObjectId } = require('mongoose');

const { findUserByEmail, findUserByMobile } = require('./userService');
const GeneralSetting = require('../models/generalSettingModel');
const withErrorHandling = require('../middleware/serviceHandler');
const User = require('../models/userModel');
const Organization = require('../models/organizationModel');
const { updateUserDataInRollback } = require('./userService');
const { updateJob, getOneJob } = require('./deleteUserDataService');
const logger = require('../logger');
const mailConstants = require('../config/constants/mailOptions');
const { sendErrorLogs } = require('../helpers/emailServices');

exports.decodeUser = async (decodedData) => {
  if (
    decodedData.email ||
    (decodedData.countryCode && decodedData.mobileNumber)
  ) {
    const decodedUser = decodedData.email
      ? await findUserByEmail(decodedData.email)
      : await findUserByMobile({
          countryCode: decodedData.countryCode,
          mobileNumber: decodedData.mobileNumber,
        });
    return decodedUser;
  }
  return null;
};

exports.formatDate = (date) => {
  const formattedDate = date.toISOString().split('T')[0];
  return formattedDate;
};

exports.formatTimestamp = (timestamp, timezone) => {
  let formattedTimestamp = moment(timestamp);
  if (timezone) {
    formattedTimestamp = formattedTimestamp.tz(timezone);
  }
  return formattedTimestamp.format('DD/MM/YYYY, dddd, hh:mm A');
};

exports.convertToUTCDate = (originalDate, originalTimezone) => {
  // Assuming the original date has no specific time
  const originalDateTime = moment(originalDate, 'YYYY-MM-DD').format(
    'YYYY-MM-DD'
  );

  // Convert the original date and time to UTC
  const utcDate = moment
    .tz(originalDateTime, originalTimezone)
    .utc()
    .format('YYYY-MM-DD');
  return utcDate;
};

exports.convertDateFormat = (dateString) => {
  if (!dateString) {
    return null;
  }
  const dateArray = dateString.split('-');
  return `${dateArray[2]}-${dateArray[1]}-${dateArray[0]}`;
};

exports.clearUserSharedData = async (userData, payload) => {
  const { deleteUser, organizationIds } = payload;
  const session = await mongoose.startSession();
  const { _id: userId } = userData;

  try {
    await session.withTransaction(async () => {
      const user = await User.findById(userId);
      const { sharedData, sharedDataTimestamp } = user;
      let { trustedOrganizations } = user;

      await Promise.all(
        organizationIds.map(async (organizationId) => {
          // Remove trustedOrganizations & sharedData from user
          sharedData.delete(organizationId);
          sharedDataTimestamp.delete(organizationId);
          trustedOrganizations = trustedOrganizations.filter(
            (trustedOrg) => trustedOrg !== organizationId
          );

          // Remove trustedUser from organization
          const organization = await Organization.findById(organizationId);
          if (organization && organization.trustedUsers !== undefined) {
            const exists = organization.trustedUsers.includes(
              userId.toString()
            );
            if (exists) {
              organization.trustedUsers = organization.trustedUsers.filter(
                (usrId) => usrId !== userId.toString()
              );
              await organization.save({ session });
            }
          }
        })
      );

      user.trustedOrganizations = trustedOrganizations;
      if (deleteUser) {
        user.isActive = false;
        user.isDeleted = true;
      }
      await user.save({ session });
    });

    return true;
  } catch (error) {
    // Transaction failed, handle error
    logger.error(`clearUserSharedData failed ${error}`);
    // Send mail to the developer or support team to fix errors coming from the application
    await sendErrorLogs({
      error,
      mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
    });
    return false;
  } finally {
    // End the session
    session.endSession();
  }
};

exports.updateCRMDataInRollback = async ({ jobId, retryFailure }) => {
  const latestJobData = await getOneJob(jobId, retryFailure);
  const { userId, rollBackHubspotIds, type: operationType } = latestJobData;

  const session = await mongoose.startSession();

  try {
    // Shift all new Hubspot CRM Ids into the users collection
    if (operationType !== 2) {
      const newHubspotIdStored = await updateUserDataInRollback(userId, {
        hubspotIds: rollBackHubspotIds,
        session,
      });
      logger.info(
        `New Hubspot Ids Updated into Userss: ${
          newHubspotIdStored && JSON.stringify(newHubspotIdStored)
        }`
      );
    }

    // Update hubspot rollback DB flag to true in the database
    const rollbackStatusUpdated = await updateJob({
      jobId,
      userId,
      type: operationType,
      rollBackHubspotDBStatus: true,
      session,
      retryFailure,
    });
    logger.info(
      `Final Rollback Huspot DB Status Updated: ${
        rollbackStatusUpdated && JSON.stringify(rollbackStatusUpdated)
      }`
    );
    return true;
  } catch (error) {
    // Transaction failed, handle error
    logger.error(`Failed in updateDataInRollback: ${error}`);
    // Send mail to the developer or support team to fix errors coming from the application
    await sendErrorLogs({
      error,
      mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
    });
    return false;
  } finally {
    // End the session
    session.endSession();
  }
};

exports.getUserSettings = withErrorHandling(async (userId, selectString) => {
  const userSettings = await GeneralSetting.findOne({
    userId,
  }).select(selectString);
  return userSettings;
});

exports.findUserById = withErrorHandling(async (userId, selectString) => {
  if (userId && isValidObjectId(userId)) {
    return User.findById(userId).select(selectString);
  }
  return null;
});

exports.throwError = (statusCode, message) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  throw error;
};
