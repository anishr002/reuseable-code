const puppeteer = require('puppeteer');

const withErrorHandling = require('../middleware/serviceHandler');

exports.downloadWebPage = withErrorHandling(async (payload) => {
  const { webPageURL } = payload;

  // Launch a headless browser
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  // Navigate to a URL or generate HTML content
  await page.goto(webPageURL);
  // await page.goto(webPageURL);

  // Wait for specific content to be loaded (adjust the selector as needed)
  await page.waitForSelector('#ad-1');

  // Generate PDF
  const pdfBuffer = await page.pdf({ format: 'A4' });

  // Close browser
  await browser.close();

  // Write PDF buffer to a file inside the 'pdfs' folder
  // fs.writeFileSync('generated.pdf', pdfBuffer);
  return pdfBuffer;
});

exports.createPDFByHTML = withErrorHandling(async (payload) => {
  const { htmlContent } = payload;
  // Open the browser
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();
  // Set the HTML content
  await page.setContent(htmlContent);
  // Generate PDF
  const pdfBuffer = await page.pdf();
  // Close the browser
  await browser.close();
  return pdfBuffer;
});
