const withErrorHandling = require('../middleware/serviceHandler');
const BulkSmsHistory = require('../models/bulkSmsHistoryModel');
const logger = require('../logger');

exports.insertMultipleSmsRecords = withErrorHandling(
  async (session, records) => {
    try {
      const insertedRecords = await BulkSmsHistory.insertMany(records, {
        session,
      });
      logger.info('Inserted bulk sms records:', insertedRecords);
      return insertedRecords;
    } catch (error) {
      logger.error('Error inserting multiple bulk sms records:', error);
      return false;
    }
  }
);

exports.findSmsRecords = withErrorHandling(async (whereObj, selectString) => {
  const records = await BulkSmsHistory.find(whereObj).select(selectString);
  return records;
});

exports.updateBulkSmsHistory = withErrorHandling(
  async (bulkSmsHistoryId, updateFields) => {
    try {
      const { attemptLogs, ...otherFields } = updateFields;

      const updatedBulkSmsHistory = await BulkSmsHistory.findByIdAndUpdate(
        bulkSmsHistoryId,
        {
          $set: otherFields,
          $push: { attemptLogs: { $each: attemptLogs } },
        },
        { new: true }
      );

      if (!updatedBulkSmsHistory) {
        throw new Error('Bulk SMS history not found');
      }

      return updatedBulkSmsHistory;
    } catch (error) {
      return false;
    }
  }
);

const mapDBFieldsLogs = (field) => {
  let dbField = '';
  switch (field) {
    case 'country_code':
      dbField = 'countryCode';
      break;
    case 'mobile_number':
      dbField = 'mobileNumber';
      break;
    case 'status':
      dbField = 'status';
      break;
    case 'try_count':
      dbField = 'tryCount';
      break;
    case 'fail_count':
      dbField = 'failCount';
      break;
    case 'created_at':
      dbField = 'createdAt';
      break;
    case 'updated_at':
      dbField = 'updatedAt';
      break;
    default:
      dbField = field;
  }
  return dbField;
};

exports.getMessageLogs = withErrorHandling(
  async ({
    organizationId,
    skip,
    limit,
    search,
    sortBy = 'updated_at',
    orderBy = 'desc',
  }) => {
    let whereCondition = { organizationId };

    // Handle search input
    if (search && search !== '') {
      const [countryCodePart, mobileNumber] = search.split(' ');
      const countryCode = countryCodePart?.replace('+', ''); // Remove '+' if it exists

      if (countryCode && mobileNumber) {
        whereCondition = {
          ...whereCondition,
          countryCode,
          mobileNumber: { $regex: new RegExp(mobileNumber, 'i') },
        };
      } else {
        whereCondition = {
          ...whereCondition,
          mobileNumber: { $regex: new RegExp(search, 'i') },
        };
      }
    }

    // Count total number of documents
    const totalCount = await BulkSmsHistory.countDocuments(whereCondition);

    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = BulkSmsHistory.find(whereCondition);

    // Handle sorting
    if (sortBy && orderBy) {
      const sortObject = {};
      const sortByField = mapDBFieldsLogs(sortBy);
      sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
      query.sort(sortObject);
    }

    // Handle pagination
    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    // Execute the query
    const logsList = await query.exec();

    return {
      logsList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);
