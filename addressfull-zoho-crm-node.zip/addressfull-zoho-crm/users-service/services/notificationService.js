const axios = require('axios');
const userRoles = require('../config/constants/userRoles');
const requestTypes = require('../config/constants/requestTypes');
const requestStatus = require('../config/constants/requestStatus');
const withErrorHandling = require('../middleware/serviceHandler');
const { findOrganizationById } = require('./organizationService');
const mailConstants = require('../config/constants/mailOptions');
const { sendErrorLogs } = require('../helpers/emailServices');

exports.sendNotification = async (
  payload,
  token,
  requestType = 'NOTIFICATION'
) => {
  const { NOTIFICATION_BASE_URL } = process.env;
  const API_URL =
    requestType === 'REQUEST'
      ? `${NOTIFICATION_BASE_URL}/api/v1/notification/send-request`
      : `${NOTIFICATION_BASE_URL}/api/v1/notification/send`;

  try {
    const response = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
    });
    // return requestType === 'REQUEST' ? response?.data : response;
    return response;
  } catch (error) {
    // return requestType === 'REQUEST' ? error?.response?.data : null;
    return null;
  }
};

exports.readNotification = async (id, token, readAll = false) => {
  const { NOTIFICATION_BASE_URL } = process.env;

  const API_URL = readAll
    ? `${NOTIFICATION_BASE_URL}/api/v1/notification/read-all`
    : `${NOTIFICATION_BASE_URL}/api/v1/notification/read`;

  const payload = readAll ? { client_id: id } : { request_id: id };

  try {
    const response = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
    });
    return response?.data;
  } catch (error) {
    return error?.response?.data;
  }
};

exports.getNotifications = async ({ token, userData, queryParams }) => {
  try {
    const queryParamsValues = queryParams;
    if (userData.userType === userRoles.FRONT_END_USER) {
      queryParamsValues.req_type = requestTypes.REQUEST;
      queryParamsValues.req_status = requestStatus.SENT;
    }
    // Create an array of query parameter strings in key=value format
    const queryStringArray =
      typeof queryParamsValues === 'object'
        ? Object.keys(queryParamsValues).map(
            (key) =>
              `${encodeURIComponent(key)}=${encodeURIComponent(
                queryParamsValues[key]
              )}`
          )
        : null;

    // Join the array with '&' to create the query string
    const queryString = queryStringArray ? queryStringArray.join('&') : '';
    const API_URL = `${process.env.NOTIFICATION_BASE_URL}/api/v1/notification/list?${queryString}`;

    const response = await axios.get(API_URL, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
    });

    return response?.data?.data;
  } catch (error) {
    return error?.response?.data;
  }
};

exports.notificationById = async (requestId, token) => {
  const { NOTIFICATION_BASE_URL } = process.env;
  const API_URL = `${NOTIFICATION_BASE_URL}/api/v1/notification/${requestId}`;
  try {
    const response = await axios.get(API_URL, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
    });
    return response;
  } catch (error) {
    return null;
  }
};

exports.calculateNotificationCount = withErrorHandling(
  async (userData, payload) => {
    let params;
    const { NOTIFICATION_BASE_URL } = process.env;
    const {
      reqType,
      reqStatus,
      sortByField,
      skip,
      limit,
      countType,
      orderBy,
      search,
    } = payload;
    const API_URL = `${NOTIFICATION_BASE_URL}/api/v1/notification/notification-count`;
    const { token } = userData;

    if (countType === 'COUNT') {
      params = payload;
      params.countType = countType;
    } else {
      let organizationId = null;
      if (userData.userType === userRoles.ORGANIZATION_ADMIN) {
        const organization = await findOrganizationById(userData._id);
        organizationId = organization[0]._id;
      } else if (userData?.organizationId) {
        const organization = await findOrganizationById(
          userData?.organizationId
        );
        organizationId = organization[0]._id;
      }
      params = {
        requestType: reqType,
        requestStatus: reqStatus,
        search,
        sortBy: sortByField,
        orderBy,
        skip,
        limit,
        orgId: organizationId,
      };
    }

    const response = await axios.post(API_URL, params, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    });

    return response;
  }
);

exports.calculateReqSentCount = withErrorHandling(async (userData, payload) => {
  const { NOTIFICATION_BASE_URL } = process.env;
  const { token } = userData;
  const API_URL = `${NOTIFICATION_BASE_URL}/api/v1/notification/req-count`;
  try {
    const response = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    });
    return response?.data?.data;
  } catch (error) {
    return null;
  }
});

exports.removeAllNotification = withErrorHandling(async (userData, payload) => {
  const { NOTIFICATION_BASE_URL } = process.env;
  const { token } = userData;
  const API_URL = `${NOTIFICATION_BASE_URL}/api/v1/notification/remove-notification`;
  try {
    const response = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    });

    return response?.data;
  } catch (error) {
    return false;
  }
});

exports.processNotification = withErrorHandling(async (userData, payload) => {
  const { NOTIFICATION_BASE_URL } = process.env;
  const { token } = userData;
  const API_URL = `${NOTIFICATION_BASE_URL}/api/v1/notification/process-notification`;
  try {
    const response = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    });
    return response?.data;
  } catch (error) {
    return false;
  }
});

exports.sendFirebaseNotification = async (payload) => {
  const { NOTIFICATION_BASE_URL } = process.env;
  const API_URL = `${NOTIFICATION_BASE_URL}/api/v1/notification/notify-user`;

  const response = {
    status: false,
    data: null,
    error: null,
  };

  try {
    const result = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
      },
    });

    response.data = result.data;
    response.status = true;
  } catch (error) {
    const errorMsg = error?.response?.data?.error?.message || error.message;

    await sendErrorLogs({
      error: error?.response?.data?.error || error,
      mailType: mailConstants.MAIL_TYPES.ERROR_LOGS,
    });

    response.error = errorMsg;
  }

  return response;
};

exports.getNotificationsData = async (
  token,
  mobileUser,
  organizationId,
  reqPeriod,
  timezone
) =>
  this.getNotifications({
    token: `Bearer ${token}`,
    userData: mobileUser,
    queryParams: {
      page: 1,
      page_size: 10,
      is_read: 0,
      req_period: reqPeriod,
      organization_id: organizationId,
      timezone,
    },
  });

exports.modifiedNotifications = async (notificationList, labelsToRemove) => {
  const modifiedNotifications = [];
  notificationList.forEach((notification) => {
    const modifiedNotification = { ...notification };

    modifiedNotification.requestedLabels =
      modifiedNotification.requestedLabels.filter(
        (label) => !labelsToRemove.includes(label)
      );

    labelsToRemove.forEach((label) => {
      const labelRegex = new RegExp(`,? ${label}`, 'g');
      modifiedNotification.message = modifiedNotification.message.replace(
        labelRegex,
        ''
      );
    });

    modifiedNotification.message = modifiedNotification.message.replace(
      /your\s*(, )?/,
      'your '
    );
    modifiedNotifications.push(modifiedNotification);
  });
  return modifiedNotifications;
};

exports.generateAndSendNotification = async ({
  previousNotifications,
  requestDetails,
  mobileUser,
  organization,
  authToken,
  userId,
  clientId,
  diffStatus = true,
}) => {
  if (previousNotifications?.notification_list.length) {
    const modifiedNotifications = await this.modifiedNotifications(
      previousNotifications.notification_list,
      requestDetails
    );
    await this.processNotification(mobileUser, {
      notificationRequests: modifiedNotifications,
    });
  }

  if (diffStatus) {
    await this.sendNotification(
      {
        requester_id: userId,
        receiver_id: clientId,
        organization_id: organization?._id,
        organization_name: organization?.name,
        request_details: requestDetails,
        extra_data: { status: true, type: 11 },
      },
      authToken,
      'REQUEST'
    );
  }
};
