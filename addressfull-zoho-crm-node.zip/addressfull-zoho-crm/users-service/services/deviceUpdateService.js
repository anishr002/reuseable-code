const DeviceUpdates = require('../models/deviceUpdateModel');
const withErrorHandling = require('../middleware/serviceHandler');

exports.findDevice = withErrorHandling(async (deviceType) => {
  if (deviceType) {
    return DeviceUpdates.findOne({ device_type: deviceType });
  }
  return null;
});

exports.saveOrUpdateDeviceUpdate = withErrorHandling(async (payload) => {
  const { deviceType, updateStatus } = payload;

  const deviceUpdate = await DeviceUpdates.findOne({ device_type: deviceType });

  if (deviceUpdate) {
    deviceUpdate.update_status = updateStatus;
    return deviceUpdate.save();
  }

  const newDeviceUpdate = new DeviceUpdates({
    device_type: deviceType,
    update_status: updateStatus,
  });
  return newDeviceUpdate.save();
});
