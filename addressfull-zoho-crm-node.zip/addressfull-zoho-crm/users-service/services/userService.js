const mongoose = require('mongoose');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const path = require('path');
const { isValidObjectId } = require('mongoose');
const moment = require('moment');
const User = require('../models/userModel');
const fileUploads = require('../config/constants/fileUploads');
const { deleteFile, isFileExists } = require('../utils/upload');
const uploadFilePaths = require('../config/constants/fileUploads');
const withErrorHandling = require('../middleware/serviceHandler');
const userRoles = require('../config/constants/userRoles');
const { getModules } = require('../utils/common');
const { findRoleById } = require('./roleService');
const { addNewJobToQueue } = require('./deleteUserDataService');
const permissionTypes = require('../config/constants/permissionType');
const logger = require('../logger');

// S3 related imports
const AWSconfig = require('../config/AWSConfig');
const { deleteImage } = require('../helpers/S3BucketHelper');

const { bucketName } = AWSconfig;

const mapDBFields = (field) => {
  let dbField = '';
  switch (field) {
    case 'first_name':
      dbField = 'firstName';
      break;
    case 'last_name':
      dbField = 'lastName';
      break;
    case 'active':
      dbField = 'isActive';
      break;
    case 'created_at':
      dbField = 'createdAt';
      break;
    case 'updated_at':
      dbField = 'updatedAt';
      break;
    default:
      dbField = field;
  }
  return dbField;
};

exports.countMobileUsers = withErrorHandling(async () =>
  User.countDocuments({
    userType: userRoles.FRONT_END_USER,
    isActive: true,
    isDeleted: false,
  })
);

exports.findOneUser = withErrorHandling(async (whereObj, selectString) => {
  const user = await User.findOne(whereObj).select(selectString);
  return user;
});

exports.findUser = withErrorHandling(async (whereObj, selectString) => {
  const user = await User.find(whereObj).select(selectString);
  return user;
});

exports.findOneWithRole = withErrorHandling(async (whereObj, selectString) => {
  const user = await User.findOne(whereObj)
    .select(selectString)
    .populate('role');
  return user;
});

exports.findUserByEmail = withErrorHandling(async (email) => {
  if (email) {
    const user = await User.findOne({
      email,
      isDeleted: false,
    });
    return user;
  }
  return null;
});

exports.findUserByMobile = withErrorHandling(
  async ({ countryCode, mobileNumber }) => {
    if (countryCode && mobileNumber) {
      return User.findOne({
        countryCode,
        mobileNumber,
      });
    }
    return null;
  }
);

exports.findUserByDevice = withErrorHandling(async ({ deviceId }) => {
  if (deviceId) {
    // // Retrieve all users from the database
    // const allUsers = await User.find({});
    // // Map all comparison promises
    // const comparisonPromises = allUsers.map(async (user) => {
    //   const isMatch =
    //     user.deviceId && (await bcrypt.compare(deviceId, user.deviceId));
    //   // console.log('isMatch......', isMatch);
    //   if (isMatch) {
    //     return user;
    //   }
    //   return null;
    // });
    // // Execute all comparison promises concurrently
    // const results = await Promise.all(comparisonPromises);
    // // Find the first non-null result (matching user)
    // const matchingUser = results.find((user) => user !== null);
    // return matchingUser;

    return User.find({
      deviceId,
    });
    // return User.findByDevice(deviceId);
  }
  return null;
});

exports.findUserById = withErrorHandling(async (userId, selectString) => {
  if (userId && isValidObjectId(userId)) {
    return User.findById(userId).select(selectString);
  }
  return null;
});

exports.createUser = withErrorHandling(async (userData) =>
  User.create(userData)
);

exports.signupFrontendUser = withErrorHandling(
  async ({
    deviceId,
    deviceToken,
    SMSToken,
    countryCode,
    mobileNumber,
    clientPublicKey,
    isActive,
  }) => {
    // Find a device which is not registered with mobile number. If there is no unregistered device then create a new device
    const isExistsDevice = await User.findOne({
      deviceId,
      countryCode: { $exists: false },
      mobileNumber: { $exists: false },
    });
    if (!isExistsDevice) {
      // Create a new device
      const newUser = new User({
        deviceId,
        deviceToken,
        clientPublicKey,
        countryCode,
        mobileNumber,
        userType: userRoles.FRONT_END_USER,
        isActive,
      });
      return newUser.save();
    }
    isExistsDevice.deviceToken = deviceToken;
    isExistsDevice.SMSToken = SMSToken;
    isExistsDevice.countryCode = countryCode;
    isExistsDevice.mobileNumber = mobileNumber;
    isExistsDevice.isActive = isActive;
    return isExistsDevice.save();
  }
);

exports.activateUserAccount = withErrorHandling(
  async ({
    deviceToken,
    SMSToken,
    countryCode,
    mobileNumber,
    deviceId,
    clientPublicKey,
    deleteOtherEntries,
  }) => {
    // Remove all key-exchange API entries with new device id
    if (deleteOtherEntries) {
      const removedOtherEntries = await User.deleteMany({
        deviceId,
        countryCode: { $exists: false },
        mobileNumber: { $exists: false },
      });
      if (!removedOtherEntries.deletedCount) {
        return false;
      }
    }
    // Update a device which is registered with mobile number.
    const isExistsDevice = await User.findOne({
      countryCode,
      mobileNumber,
    });
    if (!isExistsDevice) {
      return false;
    }
    if (deviceId !== undefined) {
      isExistsDevice.deviceId = deviceId;
    }
    if (clientPublicKey !== undefined && clientPublicKey !== '') {
      isExistsDevice.clientPublicKey = clientPublicKey;
    }
    isExistsDevice.deviceToken = deviceToken;
    isExistsDevice.SMSToken = SMSToken;
    isExistsDevice.isActive = true;
    isExistsDevice.isDeleted = false;
    return isExistsDevice.save();
  }
);

exports.storePublicKey = withErrorHandling(async (payload) => {
  const { deviceId, clientPublicKey, userType, email } = payload;
  if (userType !== undefined && email !== undefined && userType === 'admin') {
    // Replace public key
    const adminUser = await this.findUserByEmail(email);
    adminUser.clientPublicKey = clientPublicKey;
    return adminUser.save();
  }
  const deviceExists = await User.find({
    deviceId,
  });
  if (deviceExists.length === 0) {
    if (deviceId && clientPublicKey) {
      const user = new User({
        deviceId,
        clientPublicKey,
        userType: userRoles.FRONT_END_USER,
      });
      return user.save();
    }
  } else if (deviceExists.length > 0) {
    let registeredMobileNumbers = 0;
    deviceExists.forEach((device) => {
      if (
        device?.countryCode &&
        device?.mobileNumber &&
        device?.isActive &&
        device?.clientPublicKey
      ) {
        registeredMobileNumbers += 1;
      }
    });
    // If All device instances are registered with mobile numbers then create a new device instance
    if (deviceExists.length === registeredMobileNumbers) {
      const newDevice = new User({
        deviceId,
        clientPublicKey,
        userType: userRoles.FRONT_END_USER,
      });
      await newDevice.save();
    }
    // Replace public key in all device instances
    const keyUpdated = await User.updateMany(
      {
        deviceId,
      },
      {
        $set: { clientPublicKey },
      },
      {
        multi: true,
      }
    );

    return !!keyUpdated.modifiedCount;
  }
});

exports.updateOTP = withErrorHandling(async (userId, payload) => {
  const { otp, otpExpiration } = payload;
  if (userId && otp && otpExpiration) {
    const user = await User.findById(userId);
    if (user) {
      user.otp = otp;
      user.otpExpiration = otpExpiration;
      const updatedOTP = await user.save();
      return updatedOTP;
    }
  }
  return {};
});

exports.updateUserDataInRollback = withErrorHandling(
  async (userId, payload) => {
    const { hubspotIds, session } = payload;
    if (userId) {
      const user = await User.findById(userId);
      if (user) {
        hubspotIds.forEach((hubspotId, orgId) => {
          user.hubspotIds.set(orgId, hubspotId);
        });
        return user.save({ session });
      }
    }
    return false;
  }
);

exports.updatePasswordResetToken = withErrorHandling(
  async (userId, payload) => {
    const { token } = payload;
    if (userId && token) {
      const user = await User.findById(userId);
      if (user) {
        user.resetPasswordToken = token;
        return user.save();
      }
    }
    return null;
  }
);

exports.updateDeviceToken = withErrorHandling(async (userId, payload) => {
  const { token, SMSToken } = payload;
  if (userId && token) {
    const user = await User.findById(userId);
    if (user) {
      user.deviceToken = token;
      user.SMSToken = SMSToken;
      return user.save();
    }
  }
  return null;
});

exports.updateNewRegistrationToken = withErrorHandling(
  async (userId, payload) => {
    const { token } = payload;
    if (userId && token) {
      const user = await User.findById(userId);
      if (user) {
        user.newRegistrationToken = token;
        return user.save();
      }
    }
    return null;
  }
);

exports.updatePassword = withErrorHandling(async (userId, password) => {
  if (userId && password) {
    const user = await User.findById(userId);
    if (user) {
      user.password = password;
      user.isActive = true;
      user.isPasswordReset = true;
      user.isEmailVerified = true;
      return user.save();
    }
  }
  return null;
});

exports.updateHubspotId = withErrorHandling(async (userId, payload) => {
  const { hubspotId, organizationId, deleteHubspotId } = payload;
  if (userId && hubspotId) {
    const user = await User.findById(userId);
    if (user) {
      if (deleteHubspotId) {
        user.hubspotIds.delete(organizationId);
        return user.save();
      }
      // Update map record
      user.hubspotIds.set(organizationId, hubspotId);
      return user.save();
    }
  }
  return null;
});

exports.updateZohoId = withErrorHandling(async (userId, payload) => {
  const { zohoId, organizationId, deleteZohoId } = payload;
  if (userId && zohoId) {
    const user = await User.findById(userId);
    if (user) {
      // Initialize zohoIds Map if it doesn't exist
      if (!user.zohoIds) {
        user.zohoIds = new Map();
      }
      if (deleteZohoId) {
        user.zohoIds.delete(organizationId);
        return user.save();
      }
      // Update map record
      user.zohoIds.set(organizationId, zohoId);
      return user.save();
    }
  }
  return null;
});

exports.updateUserConsentBulk = withErrorHandling(
  async (userData, payloads) => {
    if (userData?._id) {
      const { _id: userId } = userData;

      // Retrieve user outside of the loop
      const user = await User.findById(userId);

      if (user) {
        const updates = []; // Array to collect updates

        // Iterate through payloads
        // eslint-disable-next-line no-restricted-syntax
        for (const payload of payloads) {
          const { organizationId, updatedSharedData: labels } = payload;

          logger.info(`organizationId: ${organizationId}`);
          console.log(labels);

          // Collect updates
          updates.push({ organizationId, labels });
        }

        // Apply collected updates to user
        updates.forEach((update) => {
          const { organizationId, labels } = update;
          user.sharedData.set(organizationId, labels);
          user.sharedDataTimestamp.set(
            organizationId,
            moment.utc().format('YYYY-MM-DDTHH:mm:ss[Z]')
          );
        });

        // Save user after all updates
        await user.save();

        return true; // Return true indicating successful update
      }
    }

    return false; // Return false if user not found or any other failure
  }
);

// exports.updateUserConsent = withErrorHandling(async (userData, payload) => {
//   const { labels, organizationId } = payload;
//   console.log('payload');
//   console.log(payload);
//   const { _id: userId } = userData;
//   console.log('userData');
//   console.log(userData);
//   if (userData?._id) {
//     const user = await User.findById(userId);
//     console.log('user');
//     console.log(user);
//     if (user) {
//       // Update shared data
//       user.sharedData.set(organizationId, labels);
//       user.sharedDataTimestamp.set(
//         organizationId,
//         moment.utc().format('YYYY-MM-DDTHH:mm:ss[Z]')
//       );
//       return user.save();
//     }
//   }
//   return null;
// });

exports.updateUserConsent = withErrorHandling(async (userData, payload) => {
  const { labels, organizationId } = payload;
  const { _id: userId } = userData;
  if (!userId) {
    return null;
  }

  try {
    const update = {
      $set: {
        [`sharedData.${organizationId}`]: labels,
        [`sharedDataTimestamp.${organizationId}`]: moment
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss[Z]'),
      },
    };

    const options = { new: true, upsert: true };
    const user = await User.findOneAndUpdate({ _id: userId }, update, options);

    return user;
  } catch (error) {
    return null;
  }
});

exports.deactivateUser = withErrorHandling(async (userId, byAdmin = false) => {
  if (userId) {
    const user = await User.findById(userId);
    if (user) {
      user.isActive = false;
      user.isDeleted = true;
      if (byAdmin) {
        user.isDeletedByAdmin = true;
      }
      return user.save();
    }
  }
  return null;
});

exports.updateProfilePicture = withErrorHandling(
  async (userId, profilePicture) => {
    if (userId) {
      const user = await User.findById(userId);
      if (user) {
        user.profileImage = profilePicture;
      }
      return user.save();
    }
    return null;
  }
);

exports.updateUserProfile = withErrorHandling(async (userId, payload) => {
  const { first_name, last_name, country_code, mobile_number } = payload;
  if (userId) {
    const user = await User.findById(userId);
    if (user?.userType === userRoles.SUPER_ADMIN || user.userType === null) {
      user.firstName = first_name;
      user.lastName = last_name;
    }
    if (user?.userType === null) {
      if (country_code && mobile_number) {
        user.countryCode = country_code;
        user.mobileNumber = mobile_number;
      }
    }
    return user.save();
  }
  return null;
});

exports.deleteProfilePicture = withErrorHandling(async (req) => {
  const user = await this.findUserById(req.user._id);
  if (!user) {
    return false;
  }
  if (user.profileImage) {
    // const filePathToDelete = path.join(
    //   fileUploads.PROFILE_PICTURE,
    //   user.profileImage
    // );
    // const isExists = isFileExists(filePathToDelete);
    // if (isExists) {
    //   const isDeleted = await deleteFile(filePathToDelete);
    //   if (!isDeleted) {
    //     return false;
    //   }
    // }

    // Remove image from s3 bucket
    const deleteUserProfile = await deleteImage(
      bucketName,
      user._id,
      user.profileImage
    );
    if (!deleteUserProfile.status) {
      return false;
    }

    // Delete Profile Image from the database
    const profileUpdated = await this.updateProfilePicture(req.user._id, '');
    if (profileUpdated) {
      return true;
    }
  }
  return true;
});

// Delete s3 file
exports.deleteS3File = async (user, fileName) => {
  try {
    await deleteImage(bucketName, user._id, fileName);
    return true;
  } catch (err) {
    logger.error(`Error while deleting s3 file: ${err}`);
    return false;
  }
};

exports.removeProfilePicture = withErrorHandling(async (userId) => {
  const user = await this.findUserById(userId);
  if (!user) {
    return false;
  }
  if (user.profileImage) {
    // const filePathToDelete = path.join(
    //   fileUploads.PROFILE_PICTURE,
    //   user.profileImage
    // );
    // const isExists = isFileExists(filePathToDelete);
    // if (isExists) {
    //   const isDeleted = await deleteFile(filePathToDelete);
    //   if (!isDeleted) {
    //     return false;
    //   }
    // }

    // Remove image from s3 bucket
    const deleteUserProfile = await deleteImage(
      bucketName,
      userId,
      user.profileImage
    );
    if (!deleteUserProfile.status) {
      return false;
    }

    // Delete Profile Image from the database
    const profileUpdated = await this.updateProfilePicture(userId, '');
    if (profileUpdated) {
      return true;
    }
  }
  return true;
});

exports.saveTrustedOrganizations = withErrorHandling(
  async (organizationId, userId) => {
    try {
      const user = await User.findById(userId);
      if (!user) {
        // throw new Error('User not found');
        return false;
      }
      if (user && user.trustedOrganizations !== undefined) {
        const exists = user.trustedOrganizations.includes(organizationId);
        if (!exists) {
          user.trustedOrganizations.push(organizationId);
          await user.save();
        }
        return true;
      }
      user.trustedOrganizations = organizationId;
      await user.save();
      return true;
    } catch (error) {
      return false;
    }
  }
);

exports.saveBlockedOrganizations = withErrorHandling(
  async (organizationId, userId) => {
    try {
      const user = await User.findById(userId);
      if (!user) {
        // throw new Error('User not found');
        return false;
      }
      if (user && user.blockedOrganizations !== undefined) {
        const exists = user.blockedOrganizations.includes(organizationId);
        if (!exists) {
          user.blockedOrganizations.push(organizationId);
          await user.save();
        }
        return true;
      }
      user.blockedOrganizations = organizationId;
      await user.save();
      return true;
    } catch (error) {
      return false;
    }
  }
);

exports.removeTrustedOrganization = withErrorHandling(
  async (organizationId, userId, transaction = null) => {
    try {
      const user = await User.findById(userId);
      if (!user) {
        return false;
      }
      if (
        transaction === 'session' &&
        user &&
        (user.trustedOrganizations === undefined ||
          user.trustedOrganizations.length === 0)
      ) {
        return true;
      }
      if (user && user.trustedOrganizations !== undefined) {
        const exists = user.trustedOrganizations.includes(organizationId);
        if (exists) {
          user.trustedOrganizations = user.trustedOrganizations.filter(
            (orgId) => orgId !== organizationId
          );
          if (user.trustedOrganizations.length === 0) {
            user.trustedOrganizations = undefined;
          }

          await user.save();
          return true;
        }
        if (transaction === 'session' && !exists) {
          return true;
        }
      }
      return null;
    } catch (error) {
      return false;
    }
  }
);

exports.removeBlockedOrganization = withErrorHandling(
  async (organizationId, userId, transaction = null) => {
    try {
      const user = await User.findById(userId);
      if (!user) {
        // throw new Error('User not found');
        return false;
      }
      if (
        transaction === 'session' &&
        user &&
        (user.blockedOrganizations === undefined ||
          user.blockedOrganizations.length === 0)
      ) {
        return true;
      }

      if (user && user.blockedOrganizations !== undefined) {
        const exists = user.blockedOrganizations.includes(organizationId);
        if (exists) {
          user.blockedOrganizations = user.blockedOrganizations.filter(
            (orgId) => orgId !== organizationId
          );
          if (user.blockedOrganizations.length === 0) {
            user.blockedOrganizations = undefined;
          }
          await user.save();
          return true;
        }
        if (transaction === 'session' && !exists) {
          return true;
        }
      }
      return null;
    } catch (error) {
      return false;
    }
  }
);

exports.countOrgAdminStaffMembers = withErrorHandling(async (userData) => {
  if (!userData._id) return false;
  const organizationId =
    userData.userType === userRoles.ORGANIZATION_ADMIN
      ? userData?._id
      : userData?.organizationId;
  if (organizationId) {
    return User.countDocuments({
      organizationId,
      isDeleted: false,
    });
  }
  return false;
});

exports.getAdminList = withErrorHandling(
  async ({
    where,
    selectString,
    skip,
    limit,
    sortBy = 'updated_at',
    orderBy = 'desc',
  }) => {
    const whereCondition = where || {};

    // Count total number of documents
    const totalCount = await User.countDocuments(whereCondition);
    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = User.find(whereCondition)
      .select(selectString)
      .populate('role');

    if (sortBy && orderBy) {
      const sortObject = {};
      const sortByField = mapDBFields(sortBy);
      sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
      query.sort(sortObject);
    }
    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    const adminList = await query.exec();
    return {
      adminList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.updateAdmin = withErrorHandling(async (adminId, payload) => {
  const { first_name, last_name, role, status } = payload;
  const admin = await this.findUserById(adminId);
  if (admin) {
    admin.firstName = first_name;
    admin.lastName = last_name;
    admin.role = role;
    admin.isActive = status;
  }
  return admin.save();
});

exports.updateSocialInfo = withErrorHandling(async (userId, payload) => {
  const { linkedin, twitter } = payload;
  const admin = await this.findUserById(userId);
  if (admin) {
    admin.linkedin = linkedin;
    admin.twitter = twitter;
  }
  return admin.save();
});

exports.deleteAdmin = withErrorHandling(async (adminId) => {
  const adminUser = await this.findUserById(adminId);
  if (adminUser) {
    adminUser.isDeleted = true;
    adminUser.isActive = false;
    return adminUser.save();
  }
  return null;
});

exports.formatResponseDocument = (responseDocument) => ({
  id: responseDocument._id,
  first_name: responseDocument.firstName || null,
  last_name: responseDocument.lastName || null,
  email: responseDocument.email || null,
  countryCode: responseDocument.countryCode || null,
  mobileNumber: responseDocument.mobileNumber || null,
  role:
    responseDocument.role?.name !== undefined
      ? {
          id: responseDocument.role._id,
          name: responseDocument.role.name,
        }
      : responseDocument.role,
  active: responseDocument.isActive,
  created_at: responseDocument.createdAt,
  updated_at: responseDocument.updatedAt,
});

exports.generateProfilePictureURL = (profilePictureName) => {
  if (profilePictureName) {
    return `${process.env.BASE_URL}/${uploadFilePaths.PROFILE_PICTURE}/${profilePictureName}`;
  }
  return null;
};

exports.generateProfileImageFromS3 = async (folderName, profilePictureName) => {
  if (profilePictureName) {
    return `${process.env.BASE_URL}/doc/${folderName}$${profilePictureName}`;
  }
  return null;
};

exports.generateOrgDocURL = (folderName, orgDocName) => {
  if (orgDocName) {
    return `${process.env.BASE_URL}/doc/${folderName}$documents$${orgDocName}`;
  }
  return null;
};

exports.generateOTP = () => {
  //  const otp = Math.floor(1000 + Math.random() * 9000);
  const otp = crypto.randomInt(1000, 10000);
  return otp.toString();
};

/* Remove Later */
exports.generateSecretKey = () => {
  const secretKey = crypto.randomBytes(32).toString('hex');
  return secretKey;
};

// Get user role
exports.getUserRole = async (user) => {
  let userRole = null;
  const { userType, role } = user;
  const roleId = role ? role.toString() : null;
  if (
    userType === userRoles.SUPER_ADMIN ||
    userType === userRoles.ORGANIZATION_ADMIN
  ) {
    userRole = userType;
  } else if (userType === null && roleId) {
    const roleObj = await findRoleById(roleId);
    const { name: roleName } = roleObj;
    userRole = roleName;
  }
  return userRole;
};

// Get user role
exports.getUserRoleName = async (user) => {
  let userRole = null;
  const { userType, role } = user;
  const roleId = role ? role.toString() : null;
  if (
    userType === userRoles.SUPER_ADMIN ||
    userType === userRoles.ORGANIZATION_ADMIN
  ) {
    userRole = userType;
  } else if (userType === null && roleId) {
    userRole = userRoles.SUB_ADMIN;
  }
  return userRole;
};

exports.isOrgAdmin = async (user) => {
  const { userType, role, organizationId } = user;
  const roleId = role ? role.toString() : null;
  return !!(userType === null && roleId && organizationId);
};

// Get permissions list
exports.getPermissionsList = async (user, userRole) => {
  let permissionsList = [];
  if (userRole === userRoles.SUPER_ADMIN) {
    const systemModules = await getModules(userRole);
    permissionsList = systemModules.map((module) => ({
      permissions: { read: true, write: true },
      section: module,
    }));
  } else if (userRole === userRoles.ORGANIZATION_ADMIN) {
    const systemModules = await getModules(userRole);
    const permissionFlag = user?.isAuthorized !== false;

    permissionsList = systemModules.map((module) => ({
      permissions: { read: permissionFlag, write: permissionFlag },
      section: module,
    }));
  } else if (userRole) {
    const roleObj = await findRoleById(user.role.toString());
    const { permissions: rolePermissions } = roleObj;
    permissionsList = rolePermissions.map((item) => ({
      permissions: {
        read:
          item.permission === permissionTypes.READ ||
          item.permission === permissionTypes.READ_WRITE,
        write: item.permission === permissionTypes.READ_WRITE,
      },
      section: item.module,
    }));
  }
  return permissionsList;
};

exports.updateBlockChainToken = withErrorHandling(async (userId, token) => {
  if (userId && token) {
    const user = await User.findById(userId);
    if (user) {
      user.blockChainToken = token;
      return user.save();
    }
  }
  return null;
});

exports.updateSharedData = withErrorHandling(async (userId, sharedData) => {
  if (userId) {
    const user = await User.findById(userId);
    if (user) {
      user.sharedData = sharedData;
      return user.save();
    }
  }
  return null;
});

const getTrustedOrgCount = (trustedOrganizations) =>
  trustedOrganizations && Array.isArray(trustedOrganizations)
    ? trustedOrganizations.length
    : 0;

const handleDeletionWithQueue = async (
  userId,
  deletionFlag,
  trustedOrgCount
) => {
  if (trustedOrgCount === 0) {
    const userDeleted = await this.deleteUserAccount({ _id: userId });
    if (!userDeleted?.error) {
      return 'done';
    }
  }

  const queueAdded = await addNewJobToQueue({
    userId,
    type: deletionFlag,
  });
  logger.info(`New Job Added - ${queueAdded && JSON.stringify(queueAdded)}`);
  if (!queueAdded?.error) {
    return 'pending';
  }

  return null;
};

const handleImmediateDeletion = async (userData) => {
  const userDeleted = await this.deleteUserAccount(userData);
  if (!userDeleted?.error) {
    return 'done';
  }

  return null;
};

/**
 * Use: This function is used to delete(soft-delte) user account or user's shared data from the system.
 * Implementation Details: Super admin can not delete their account.
 * Users created by the super-admin can not delete their account.
 * Organization user can delete their account. (We can implement Later)
 * Staff members created by the organization can not delete their account.
 * Mobile user can delete their account. (Implemented)
 * On-deletion of organization:
 * 1. delete all the staff members belongs to the organization along with the organization. (Pending)
 * 2. delete organization from users's trusted organization list.
 * 3. Remove all the connected users's data from the CRM.
 * 4. Add blockchain transaction.
 * On-deletion of mobile users's account:
 * 1. If user wants to delete the data then remove the data from all organization's CRM
 * 2. Remove the user from the connected users's list of the organization
 * 3. If the user don't want to remove the data: Only delete the user's account.
 * 4. Create blockchain transactions
 */
exports.deleteUserData = withErrorHandling(
  async (userData, { deletionType, removeOnlyDataFlag }) => {
    const { userType, _id: userId, trustedOrganizations } = userData;
    const trustedOrgCount = getTrustedOrgCount(trustedOrganizations);
    let deletionFlag = 1;

    if (userType === userRoles.FRONT_END_USER) {
      if (removeOnlyDataFlag) {
        if (trustedOrgCount === 0) {
          return 'no_trusted';
        }
        deletionFlag = 0;
      }

      if (deletionType === 'yes') {
        return handleDeletionWithQueue(userId, deletionFlag, trustedOrgCount);
      }

      if (deletionType === 'no') {
        return handleImmediateDeletion(userData);
      }
    }

    return null;
  }
);

exports.deleteUserAccount = withErrorHandling(async (userData) => {
  const { _id: userId } = userData;
  const user = await User.findById(userId);
  user.isActive = false;
  user.isDeleted = true;
  user.isRegistered = false;
  user.deletedAt = new Date();
  return user.save();
});

exports.registerUserAccount = withErrorHandling(async (userId) => {
  const user = await User.findById(userId);
  user.isRegistered = true;
  return user.save();
});

exports.findSharedLabel = withErrorHandling(async (sharedData) => {
  const regexArray = [
    { keyword: 'mobile', pattern: /mobile/i },
    { keyword: 'email', pattern: /email/i },
    { keyword: 'address', pattern: /address/i },
    { keyword: 'twitter', pattern: /twitter/i },
    { keyword: 'linkedin', pattern: /linkedin/i },
  ];

  const finalData = [];

  /* eslint-disable no-restricted-syntax */
  for (const { keyword, pattern } of regexArray) {
    for (const item of sharedData) {
      if (pattern.test(item)) {
        finalData.push(keyword);
        break;
      }
    }
  }

  return finalData;
});

exports.clearSharedData = withErrorHandling(async (userId, organizationId) => {
  if (userId) {
    const user = await User.findById(userId);
    if (user) {
      const { sharedData, sharedDataTimestamp } = user;
      sharedData.delete(organizationId);
      sharedDataTimestamp.delete(organizationId);
      user.sharedData = sharedData;
      return user.save();
    }
  }
  return null;
});
