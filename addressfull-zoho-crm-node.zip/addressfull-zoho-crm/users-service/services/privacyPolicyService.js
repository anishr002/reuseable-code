const PrivacyPolicy = require('../models/privacyPolicyModel');
const withErrorHandling = require('../middleware/serviceHandler');

const mapDBFields = (field) => {
  let dbField = '';
  switch (field) {
    case 'active':
      dbField = 'isActive';
      break;
    case 'created_at':
      dbField = 'createdAt';
      break;
    case 'updated_at':
      dbField = 'updatedAt';
      break;
    default:
      dbField = field;
  }
  return dbField;
};

exports.create = withErrorHandling(async (payload) => {
  const { title, subRules, isActive, createdBy } = payload;
  const privacyPolicy = new PrivacyPolicy({
    title,
    subRules,
    isActive,
    createdBy,
  });
  return privacyPolicy.save();
});

exports.findPolicyByName = withErrorHandling(
  async ({ policyName, selectString }) => {
    if (policyName) {
      return PrivacyPolicy.findOne({
        title: {
          $regex: new RegExp(`^${policyName}$`, 'i'),
        },
      }).select(selectString);
    }
    return null;
  }
);

exports.findPolicyById = withErrorHandling(async (policyId, selectString) => {
  if (policyId) {
    return PrivacyPolicy.findById(policyId).select(selectString);
  }
  return null;
});

exports.update = withErrorHandling(
  async (policyId, { title, isActive, subRules }) => {
    try {
      const policy = await this.findPolicyById(policyId);
      if (!policy) {
        throw new Error('Policy not found');
      }

      // Check if Policy with same name exists
      if (title) {
        const policyNameExists = await this.findPolicyByName({
          policyName: title,
        });
        if (
          policyNameExists &&
          policyNameExists._id.toString() !== policyId &&
          Object.keys(policyNameExists).length
        ) {
          return {
            policyNameExists: true,
          };
        }
      }

      // Update status
      if (typeof isActive === 'boolean') {
        policy.isActive = isActive;
      }

      // Update title if provided
      if (title) {
        policy.title = title;
      }

      // Store IDs of incoming subRules
      const incomingSubRuleIds = subRules.map((subRule) => subRule.id);

      // Remove subRules not present in the incoming subRules
      policy.subRules = policy.subRules.filter((subRule) =>
        incomingSubRuleIds.includes(subRule.id)
      );

      // Update subRules
      subRules.forEach(async (subRule) => {
        if (!subRule.id || subRule.id === 'null') {
          // If id is null or 'null', create a new subRule
          policy.subRules.push({
            name: subRule.name,
            description: subRule.description,
            isActive: subRule.isActive,
          });
        } else {
          // If id is provided, find and update existing subRule
          const existingSubRuleIndex = policy.subRules.findIndex(
            (rule) => rule.id === subRule.id
          );
          if (existingSubRuleIndex !== -1) {
            policy.subRules[existingSubRuleIndex] = {
              id: subRule.id,
              name: subRule.name,
              description: subRule.description,
              isActive: subRule.isActive,
            };
          }
        }
      });

      return await policy.save();
    } catch (error) {
      return null;
    }
  }
);

exports.deleteOne = withErrorHandling(async (policyId) => {
  const policyExists = await this.findPolicyById(policyId);
  if (policyExists) {
    return PrivacyPolicy.deleteOne({
      _id: policyId,
    });
  }
  return null;
});

exports.getPolicyList = withErrorHandling(
  async ({
    where,
    selectString,
    skip,
    limit,
    sortBy = 'updated_at',
    orderBy = 'desc',
  }) => {
    const whereCondition = where || {};

    // Count total number of documents
    const totalCount = await PrivacyPolicy.countDocuments(whereCondition);
    // Calculate the number of pages
    const totalPages = Math.ceil(totalCount / limit);

    // Query the documents
    const query = PrivacyPolicy.find(whereCondition).select(selectString);

    if (sortBy && orderBy) {
      const sortObject = {};
      const sortByField = mapDBFields(sortBy);
      sortObject[sortByField] = orderBy === 'asc' ? 1 : -1;
      query.sort(sortObject);
    }
    if (skip && typeof skip === 'number') {
      query.skip(skip);
    }
    if (limit && typeof limit === 'number') {
      query.limit(limit);
    }
    const policyList = await query.exec();

    return {
      policyList,
      pageInfo: {
        totalCount,
        totalPages,
        currentPage: Math.ceil((skip + 1) / limit),
      },
    };
  }
);

exports.formatPolicyResponse = async (
  responseDocument,
  isSync,
  isUpdated = false
) => {
  const baseResponse = {
    _id: responseDocument._id,
    title: responseDocument.title || null,
    sub_rules: await Promise.all(
      responseDocument.subRules.map(async (subRule) => ({
        _id: isUpdated ? subRule.id : subRule._id,
        name: subRule.name,
        description: subRule.description,
        isActive: subRule.isActive,
        isSync: await isSync(
          responseDocument._id,
          isUpdated ? subRule.id : subRule._id
        ),
      }))
    ),
    active: responseDocument.isActive,
  };

  return isUpdated
    ? {
        ...baseResponse,
      }
    : {
        ...baseResponse,
        created_at: responseDocument.createdAt,
        updated_at: responseDocument.updatedAt,
      };
};

exports.generatePrivacyPolicy = withErrorHandling(async (orgPolicy) => {
  let privacyPolicy = {
    rule: '',
    sub_rules: [],
  };

  const { policyId } = orgPolicy;
  if (policyId !== undefined) {
    const subRuleIds = orgPolicy.policySubRules.map((id) => id.toString());
    const policy = await this.findPolicyById(policyId);
    if (policy) {
      // Find the policy and sub-rules
      const { title, subRules } = policy;
      const policyRules = subRules
        .filter(({ _id }) => subRuleIds.includes(String(_id)))
        .map(({ name }) => name);

      privacyPolicy = {
        rule: title,
        sub_rules: policyRules,
      };
    }
  }
  return privacyPolicy;
});
