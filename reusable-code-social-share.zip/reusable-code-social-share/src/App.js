import React, { useState, useRef, useEffect } from "react";
import "./App.css";
import Button from 'react-bootstrap/Button';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import social_facebook from "./assets/images/social_facebook.svg";
import social_gmail from "./assets/images/social_gmail.svg";
import social_instagram from "./assets/images/social_instagram.svg";
import social_line from "./assets/images/social_line.svg";
import social_linkedin from "./assets/images/social_linkedin.svg";
import social_messenger from "./assets/images/social_messenger.svg";
import social_telegram from "./assets/images/social_telegram.svg";
import social_tiktok from "./assets/images/social_tik-tok.svg";
import social_twitter from "./assets/images/social_twitter.svg";
import social_whatsapp from "./assets/images/social_whatsapp.svg";
import InputGroupText from "react-bootstrap/esm/InputGroupText";
import { Form, InputGroup } from "react-bootstrap";
import logo from './logo.svg'

function App() {
  const link = 'https://www.tridhyatech.com';
  const [shareText, setshareText] = useState("")
  const [copied, setCopied] = useState(false);


  const isMobile =
    /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent
    );

  const socialMediaList = [
    {
      icon: social_gmail,
      name: "Email",
      link: `mailto:?body=${encodeURIComponent(shareText)}`,
    },
    {
      icon: social_whatsapp,
      name: "WhatsApp",
      link: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`,
    },
    {
      icon: social_line,
      name: "Line",
      link: `https://line.me/R/msg/text/?${encodeURIComponent(shareText)}`,
    },
    {
      icon: social_linkedin,
      name: "LinkedIn(link)",
      link: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
        link
      )}`,
    },
    {
      icon: social_twitter,
      name: "Twitter",
      link: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareText)}`,
    },
    {
      icon: social_instagram,
      name: "Instagram",
      link: `https://www.instagram.com/?url=${encodeURIComponent(shareText)}`,
    },
    {
      icon: social_telegram,
      name: "Telegram",
      link: `https://t.me/share/url?url=${encodeURIComponent(shareText)}`,
    },
    {
      icon: social_facebook,
      name: "Facebook(link)",
      link: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(link)}`,
    },
    {
      icon: social_messenger,
      name: "Messenger",
      link: !isMobile
        ? `https://www.messenger.com/new?text=${encodeURIComponent(shareText)}`
        : `fb-messenger://share/?link=${encodeURIComponent(
          shareText
        )}&app_id=148544941634826`,
    },
  ];


  const handleShare = () => {
    if (navigator.share) {
      // Use the native share API
      // this API properly work only in https not in http
      navigator.share({
        text: shareText,
      })
        .then(() => console.log('Shared successfully'))
        .catch((error) => console.error('Error sharing:', error));
    } else {
      // Fallback for browsers that do not support the native share API
      alert(`Share this text: ${shareText}`);
    }
  };

  //copy function
  const handleCopyLink = async () => {
    try {
      await window?.navigator?.clipboard?.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error("Error copying URL:", error);
    }
  };


  return (
    <div className="mt-10 ">
      <ToastContainer />

      <h2 className="font-bold text-blue-500 text-xl text-center">
        Social share
      </h2>
      <div className="py-5 bg-white px-2 d-flex justify-center ">
        <InputGroup className="mb-3 w-[400px]">
          <Form.Control
            placeholder="Enter text to send in social media"
            aria-label="Recipient's username"
            aria-describedby="basic-addon2"
            onChange={(e) => setshareText(e.target.value)}
            value={shareText}
          />
          <Button variant="outline-primary" onClick={handleCopyLink}>{`${copied ? "Copied!" : "Copy"}`}</Button>
        </InputGroup>
      </div>
      <div className="py-5 bg-white px-2 d-flex justify-evenly">
        {!isMobile ?
          (socialMediaList.map((platform, index) => (
            <div key={index} className="text-center">
              <a
                href={platform.link}
                target="_blank"
                className={`${shareText ? "" : "pointer-events-none"} flex items-center justify-center flex-col gap-2 text-theme_blued font-Poppins_Regular text-[10px]`}
              >
                <img
                  className="md:w-16 md:h-16 w-11 h-11"
                  height={65}
                  width={65}
                  alt=""
                  src={platform?.icon}
                />
                {platform.name}
              </a>
            </div>
          )))
          : (
            <div>
              <Button variant="outline-primary" className={`${shareText ? "" : "pointer-events-none"} `} onClick={handleShare}>Share</Button>
            </div>)
        }
      </div>
    </div>)
}


export default App;
