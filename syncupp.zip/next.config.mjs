import './src/env.mjs';
import { CleanWebpackPlugin } from 'clean-webpack-plugin';
import CssMinimizerPlugin from 'css-minimizer-webpack-plugin';
import TerserPlugin from 'terser-webpack-plugin';
/** @type {import('next').NextConfig} */

const nextConfig = {
  // output: 'export',
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'randomuser.me',
        pathname: '/api/portraits/**',
      },
      {
        protocol: 'https',
        hostname: 'cloudflare-ipfs.com',
        pathname: '/ipfs/**',
      },
      {
        protocol: 'https',
        hostname: 'avatars.githubusercontent.com',
        pathname: '/u/**',
      },
      {
        protocol: 'https',
        hostname: 'picsum.photos',
      },
      {
        protocol: 'https',
        hostname: 'flagcdn.com',
      },
      {
        protocol: 'https',
        hostname: 'utfs.io',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
      },
      {
        protocol: 'https',
        hostname: 's3.amazonaws.com',
        pathname: '/redqteam.com/isomorphic-furyroad/public/**',
      },
      {
        protocol: 'https',
        hostname: 'isomorphic-furyroad.s3.amazonaws.com',
      },
      {
        protocol: 'http',
        hostname: '172.16.1.237',
        port: '3001',
      },
      {
        protocol: 'http',
        hostname: '172.16.0.241',
        port: '3001',
      },
      {
        protocol: 'http',
        hostname: '172.16.1.140',
        port: '3001',
      },
      {

        protocol: 'http',
        hostname: '172.16.0.220',
        port: '3002',
      },

      {
        protocol: 'http',
        hostname: '172.16.0.241',
        port: '3000',
      },
      {
        protocol: 'http',
        hostname: '104.248.10.11',
        port: '5011',
      },
      {
        protocol: 'http',
        hostname: '104.248.10.11',
        port: '5016',
      },
      {
        protocol: 'http',
        hostname: '134.209.154.30',
        port: '5016',
      },
      {
        protocol: 'http',
        hostname: '167.71.164.176',
        port: '5011',
      },
      {
        protocol: 'http',
        hostname: '172.16.0.220',
        port: '3001',
      },
      {
        
        protocol: 'http',
        hostname: '172.16.1.140',
        port: '3001',
      },
      {
        protocol: 'http',
        hostname: '139.59.15.81',
        port: '5011',
      },
      {
        protocol: 'https',
        hostname: '97.74.92.245',
        port: '3002',
      },
      {
        protocol: 'https',
        hostname: 'api.syncupp.com',
      },
      {
        protocol: 'https',
        hostname: 'https://syncupp.onrender.com',
      },
      {
        protocol: 'http',
        hostname: '134.209.154.30',
        port: '5011',
      },
      {
        protocol: 'https',
        hostname: 'syncuppapi.devhostserver.com',
      },
      {
        protocol: 'http',
        hostname: '157.173.110.159',
        port: '5016',
      },
      {
        protocol: 'http',
        hostname: '192.168.1.2',
        port: '3001',
      },
      {
        protocol: 'http',
        hostname: '172.16.0.210',
        port: '3001',
      },
      {
        protocol: 'http',
        hostname: '192.168.4.138',
        port: '3001',
      },
      {
        protocol: 'http',
        hostname: '172.16.1.140',
        port: '3002',
      },
      {
        protocol: 'https',
        hostname: 'staging-syncupp.s3.us-east-1.amazonaws.com'
      }
      // {
      //   protocol: 'http',
      //   hostname: '172.16.1.237',
      //   port: '3001'
      // },
    ],
  },
  // env: {
  //   REACT_APP_API_URL: "http://172.16.0.241:3000/api/v1",
  // },
  reactStrictMode: false,
  async redirects() {
    return [
      {
        source: '/',
        destination: '/signin',
        permanent: false,
      },
      {
        source: '/admin',
        destination: '/admin/signin',
        permanent: false,
      },
      {
        source: '/:workspaceName/reports',
        destination: '/:workspaceName/reports/timesheet-reports',
        permanent: false,
      },
    ];
  },
  swcMinify: true,
  productionBrowserSourceMaps: false,
  webpack(config, { isServer, webpack }) {
    if (!isServer) {
      config.plugins.push(
        new CleanWebpackPlugin({
          // Clean only specific patterns within the `.next` folder
          cleanOnceBeforeBuildPatterns: ['.next/cache/**/*'], // Adjust paths as needed
          dry: false, // Ensures cleaning actually happens
          verbose: true, // Logs which files are being cleaned
        })
      );

      config.optimization.minimizer.push(
        new CssMinimizerPlugin({
          minimizerOptions: {
            preset: [
              'default',
              {
                discardComments: { removeAll: true }, // Remove all comments
              },
            ],
          },
        })
      );

      config.optimization.minimizer = [
        new TerserPlugin({
          terserOptions: {
            compress: {
              drop_console: true, // Remove console logs
            },
            output: {
              comments: false, // Remove comments
            },
          },
        }),
      ];
    }

    return config;
  },
};

export default nextConfig;
