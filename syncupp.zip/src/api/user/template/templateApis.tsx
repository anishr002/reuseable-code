import AxiosWithoutTimeout from '@/services/AxiosWithoutTimeout';

// Get the Templates list
export const gettemplateListAPI = async (group_name: any) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/customTemplate/get-templates-by-group-name?paginate=false&sort_field=createdAt&sort_order=desc&group_name=${group_name}`,
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Get the SingleTemplate By Id
export const gettemplateByIdAPI = async (id: string) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/customTemplate/view-template/${id}`,
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Create the Template
export const createtemplateAPI = async (payload: any) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/customTemplate/create-template`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Edit the Template
export const editTemplateAPI = async (payload: any, id: string) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/customTemplate/update-template/${id}`,
        method: 'PUT',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Delete the Template
export const deletetemplateAPI = async (id: string) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/customTemplate/delete-template/${id}`,
        method: 'DELETE',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Get the get group
export const getTemplateGroupAPI = async (data: any) => {
    const response = await AxiosWithoutTimeout({
        url: '/api/v1/customTemplate/group-names?paginate=false&sort_field=group_name&sort_order=asc',
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};