import AxiosDefault from "@/services/AxiosDefault";

type PostAddEventApiData = {
  title: string;
  agenda: string;
  due_date?: string;
  event_start_time?: string;
  event_end_time?: string;
  recurring_end_date?: string;
  email?: string | string[];
  internal_info?: string;
  agency_id?: string;
  createEventIfEmailExists?: string;
}
  
type PatchEditEventApiData = {
  _id: string;
  title: string;
  agenda: string;
  due_date?: string;
  event_start_time?: string;
  event_end_time?: string;
  recurring_end_date?: string;
  email?: string | string[];
  internal_info?: string;
  agency_id?: string;
  createEventIfEmailExists?: string;
}

type GetEventByIdApiData = {
  eventId: string;
}

type PutCancelEventApiData = {
  eventId: string;
}

type GetAllEventApiData = {
  page?: number;
  items_per_page?: number;
  sort_order?: string;
  sort_field?: string;
  search?: string;
  filter?: any;
  pagination?: boolean;
  agency_id?: string;
  client_id?: string;
  team_id?: string;
  activity_type?: string;
}



// type ApiResponse = {
//   success: boolean;
//   message: string;
//   token: string;
// };

export const PostAddEventApi = async (data: PostAddEventApiData) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: "/api/v1/event/create-event",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};


export const PatchEditEventApi = async (data: PatchEditEventApiData) => {
    const response = await AxiosDefault({
      url: `/api/v1/event/update-event/${data._id}`,
      method: "PUT",
      data: data,
      contentType: "application/json", 
    });
    const responseData = response.data;
    return responseData;
  };

export const GetAllEventApi = async (data: GetAllEventApiData) => {
  const response = await AxiosDefault({
    url: "/api/v1/event/event-list",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

export const GetEventByIdApi = async (data: GetEventByIdApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/event/fetch-event/${data.eventId}`,
    method: "GET",
    // data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};


export const PutCancelEventApi = async (data: PutCancelEventApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/event/delete-event/${data.eventId}`,
    method: "PUT",
    // data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};


