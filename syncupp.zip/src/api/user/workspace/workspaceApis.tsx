import AxiosDefault from '../../../services/AxiosDefault';

interface PostAddWorkspaceApiData {
  workspace_name: string;
}
interface PatchEditWorkspaceApiData {
  workspace_id: string;
  workspace_name: string;
}
interface DeleteWorkspaceApiData {
  workspace_id: string;
}

interface GetWorkspaceDetailApiData {
  workspace_id: string;
}

// GET WORKSPACE LIST API
export const GetWorkspaceListAPI = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/workspace/list',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// CHANGE WORKSPACE
export const ChangeWorkspaceAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/auth/change-workspace',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// WORKSPACE CHECK
export const CheckWorkspaceAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/workspace/workspace-check',
    method: 'POST',
    data,
    contentType: 'application/json',
  });

  const resposneData = response.data;
  return resposneData;
};

//Workspace Creator api for Team agency
export const WorkspaceCreatorAPI = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/workspace/creator',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Add new workspace api
export const postAddWorkspaceApi = async (data: PostAddWorkspaceApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/workspace/create',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get workspace details api
export const getWorkspaceDetailApi = async (
  data: GetWorkspaceDetailApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/workspace/${data?.workspace_id}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Edit workspace api
export const patchEditWorkspaceApi = async (
  data: PatchEditWorkspaceApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/workspace/update/${data?.workspace_id}`,
    method: 'PATCH',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Delete workspace api
export const deleteWorkspaceApi = async (data: DeleteWorkspaceApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/workspace/delete/${data?.workspace_id}`,
    method: 'DELETE',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get all workspace members api
export const getWorkspaceMembersApi = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/workspace/workspace-members',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
