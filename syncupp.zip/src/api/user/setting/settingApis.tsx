import AxiosDefault from '@/services/AxiosDefault';

// GET DEFAULT INVOICE LOGO
export const GetSettingDataAPI = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/setting/get-setting',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
// Get Holiday list
export const GetHolidayDataAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/holiday/list-holiday',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// UPLOAD DEFAULT INVOICE LOGO
export const UploadDefalutInvoiceLogoAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/setting/upload-logo',
    method: 'POST',
    data: data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

// MANAGE CALENDER IDs
export const UpdateCalendarIdAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/activity/update-calendar-event',
    method: 'PUT',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// GET CALENDER IDs
export const GetCalendarIdAPI = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/activity/calendar-ids',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// SET TIME TRACKING
export const SetTimeTrackingAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/setting/timer',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Update Custom Field
export const UpdateCustomFieldAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/setting/custom-fields',
    method: 'PUT',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// ATTENDANCE SETTING API
export const attendanceSettingAPI = async (data: {
  half_day: string;
  full_day: string;
  default_holiday: string[];
  member_can_edit: boolean;
}) => {
  const response = await AxiosDefault({
    url: '/api/v1/setting/attendance',
    method: 'PUT',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// create holiday api
export const createHolidayAPI = async (data: {
  title: string;
  date: string;
  holiday_id?: string | undefined;
}) => {
  const _id = data?.holiday_id;
  !_id && delete data?.holiday_id;
  const url = !_id
    ? '/api/v1/holiday/create-holiday'
    : '/api/v1/holiday/update-holiday';
  const response = await AxiosDefault({
    url,
    method: !_id ? 'POST' : 'PATCH',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// delete holiday
export const DeleteHoliday = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/holiday/delete-holiday',
    method: 'DELETE',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

//updateTaskIdPrefixAPI
export const updateTaskIdPrefixAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/setting/update-task-prefix',
    method: 'PUT',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
