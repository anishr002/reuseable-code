import AxiosDefault from '@/services/AxiosDefault';

export const GetAllTimesheetReportApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/report/time-tracking',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

//download agency list
export const GetTimesheetReportdownloadsApi = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/report/time-tracking-download`,
    method: 'POST',
    data,
    contentType: 'application/json',
    responseType: 'blob', // Important for binary data
  });
  const responseData = response.data;
  return responseData;
};

// Get all Timesheet Task filter Data
export const GetAllTimesheetTaskApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/report/task-list',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
