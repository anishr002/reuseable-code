import AxiosDefault from '@/services/AxiosDefault';
import axios from 'axios';

// GET ATTENDEES LIST
export const GetAttendeesAPI = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/activity/fetch-users',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
// GET ATTENDEES LIST
export const GetInstantMeetingLink = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/activity/hangout',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// CREATE MEETING
export const CreateMeetingAPI = async (data: any) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: "/api/v1/activity/call-meeting",
    method: "POST",
    data: data,
    contentType: "multipart/form-data",
  });
  const responseData = response.data;
  return responseData;
};

export const GetMeetingByIdAPI = async (id: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/call-meeting/${id}`,
    method: "GET",
    // data: data,
    contentType: "application/json",
  });
  const responseData = response.data;
  return responseData;
};

export const CreateGoogleMeetingAPI = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/create-google-meeting`,
    method: "POST",
    data: data,
    contentType: "application/json",
  });
  const responseData = response.data;
  return responseData;
}

// UPDATE MEETING
export const UpdateMeetingAPI = async (data: any, id: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/update/call-meeting/${id}`,
    method: "PATCH",
    data: data,
    contentType: "multipart/form-data",
  });
  const responseData = response.data;
  return responseData;
};


export const GetMeetingApi = async (data: any) => {
  const response = await axios({
    url: 'https://oauth2.googleapis.com/token',
    method: 'POST',
    data: data
  });
  const responseData = response
};

// CREATE MEETING
export const DeleteMeetingAPI = async (data: any) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: "/api/v1/activity/delete-call-meeting",
    method: "POST",
    data: data,
    contentType: "application/json",
  });
  const responseData = response.data;
  return responseData;
};