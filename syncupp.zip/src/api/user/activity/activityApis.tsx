import AxiosDefault from "@/services/AxiosDefault";

type PostAddActivityApiData = {
  title: string;
  agenda: string;
  activity_type: string;
  client_id: string;
  assign_to: string;
  due_date?: string;
  meeting_start_time?: string;
  meeting_end_time?: string;
  internal_info?: string;
  recurring_end_date?: string;
  mark_as_done ?: boolean;
}
  
type PatchEditActivityApiData = {
  _id: string;
  title: string;
  agenda: string;
  activity_type: string;
  client_id: string;
  assign_to: string;
  due_date?: string;
  meeting_start_time?: string;
  meeting_end_time?: string;
  internal_info?: string;
  recurring_end_date?: string;
  mark_as_done ?: boolean;
  activity_id?: string;
}

type GetActivityByIdApiData = {
  activityId: string;
}

type DeleteActivityApiData = {
  activityIdsToDelete: string[];
}

type GetAllActivityApiData = {
  page?: number;
  items_per_page?: number;
  sort_order?: string;
  sort_field?: string;
  search?: string;
  client_id?: string;
  team_id?: string;
  agency_id?: string;
  activity_type?: string;
  filter?: any;
  pagination?: boolean;
}

type DeleteGoogleCalendarConfigAccountApiData = {
  _id: string;
}

type PostGoogleCalendarConfigApiData = {
  code: string;
}


// type ApiResponse = {
//   success: boolean;
//   message: string;
//   token: string;
// };

export const GetAssignedActivityApi = async () => {
  // console.log(data)
  const response = await AxiosDefault({
    url: "/api/v1/activity/assigned_activity",
    method: "GET",
    // data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

export const PostAddActivityApi = async (data: PostAddActivityApiData) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: "/api/v1/activity/call-meeting",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};


export const PatchEditActivityApi = async (data: PatchEditActivityApiData) => {
    const response = await AxiosDefault({
      url: `/api/v1/activity/update/call-meeting/${data._id}`,
      method: "PATCH",
      data: data,
      contentType: "application/json", 
    });
    const responseData = response.data;
    return responseData;
  };

export const GetAllActivityApi = async (data: GetAllActivityApiData) => {
  const response = await AxiosDefault({
    url: "/api/v1/activity/list",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

export const GetActivityByIdApi = async (data: GetActivityByIdApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/call-meeting/${data.activityId}`,
    method: "GET",
    // data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

export const DeleteActivityApi = async (data: DeleteActivityApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/delete-task`,
    method: "DELETE",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

export const MeetingStatusUpdate = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/update-status/${data?._id}`,
    method: "PUT",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
}


// Google calendar config section

// auth google calendar

export const PostGoogleCalendarConfigApi = async (data: PostGoogleCalendarConfigApiData) => {
  const response = await AxiosDefault({
    url: "/api/v1/activity/auth-calendar",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

export const GetVerifyGoogleCalendarConfigApi = async () => {
  const response = await AxiosDefault({
    url: "/api/v1/activity/check-auth-status",
    method: "GET",
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

// get All google calendar activities
export const GetAllGoogleCalendarActivityApi = async (data: any) => {
  const response = await AxiosDefault({
    url: "/api/v1/activity/get-events",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

// get All google calendar congigured accounts
export const GetAllGoogleCalendarConfigAccountsApi = async () => {
  const response = await AxiosDefault({
    url: "/api/v1/activity/calendar-auth-user",
    method: "GET",
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

// delete google calendar congigured account
export const DeleteGoogleCalendarConfigAccountApi = async (data: DeleteGoogleCalendarConfigAccountApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/activity/delete-calendar-account/${data?._id}`,
    method: "DELETE",
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};

// post select configure authenticated user api
export const PostSelectConfigureUserApi = async (data: any) => {
  const response = await AxiosDefault({
    url: "/api/v1/activity/calendar-auth-user",
    method: "POST",
    data: data,
    contentType: "application/json", 
  });
  const responseData = response.data;
  return responseData;
};