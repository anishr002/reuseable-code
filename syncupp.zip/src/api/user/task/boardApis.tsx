import AxiosDefault from '@/services/AxiosDefault';

type PostAddBoardApiData = {
  project_name: string;
  description?: string;
  members?: string[];
  board_image?: any;
};

type PatchEditTaskApiData = {
  _id: string;
  project_name: string;
  description?: string;
  members?: string[];
  board_image?: any;
};

type putBoardPinStatusChangeApiData = {
  is_pinned: boolean;
  board_id: string;
};

type GetAllBoardApiData = {
  skip: number;
  limit: number;
  all: boolean;
};

type GetBoardSectionsByIdApiData = {
  board_id: string;
};

type PostAddSectionApiData = {
  board_id: string;
};

type DeleteSectionByIdApiData = {
  section_id: string;
  force_fully_delete: boolean;
};

type PutEditSectionApiData = {
  board_id: string;
  section_id: string;
  section_name?: string;
  sort_order?: number;
};

type PostBoardMembersRemoveApiData = {
  member_id: string;
  board_id: string;
  action_name: string;
};

type DeleteBoardApiData = {
  board_id: string;
  force_fully_remove: boolean;
};

type ArchiveBoardApiData = {
  board_id: string;
  status: string;
};

type GetBoardByIdApiData = {
  boardId: string;
};

// type ApiResponse = {
//   success: boolean;
//   message: string;
//   token: string;
// };

export const PostAddBoardApi = async (data: PostAddBoardApiData) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: '/api/v1/board/create-board',
    method: 'POST',
    data: data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

// duplicate board api
export const PostDuplicateBoardApi = async (data: any) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: `/api/v1/board/duplicate`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const PatchEditBoardApi = async (data: any) => {
  // Access the _id field
  const id = data?.get('_id');
  const response = await AxiosDefault({
    url: `/api/v1/board/${id}`,
    method: 'PUT',
    data: data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

export const GetAllBoardApi = async (data: GetAllBoardApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/board/get-boards',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const UpdateBoardOrderApi = async (data: GetAllBoardApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/board/order-update',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const PostBoardMembersRemoveApi = async (
  data: PostBoardMembersRemoveApiData
) => {
  const response = await AxiosDefault({
    url: '/api/v1/board/add-remove-user',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Delete board api
export const DeleteBoardApi = async (data: DeleteBoardApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/board/delete-board',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Archive board api
export const ArchiveBoardApi = async (data: ArchiveBoardApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/board/status-update',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetAllAssigneesApi = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/board/fetch-users',
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetBoardByIdApi = async (data: GetBoardByIdApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/board/${data.boardId}`,
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetBoardImagesByIdApi = async (data: any) => {
  console.log(data, 'data');
  const response = await AxiosDefault({
    url: `/api/v1/board/image/board-images`,
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetBoardUsersByIdApi = async (data: any) => {
  console.log(data, 'data');
  const response = await AxiosDefault({
    url: `/api/v1/board/fetch-users`,
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetMembersByBoardIdApi = async (data: GetBoardByIdApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/board/member-list/${data.boardId}`,
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const putBoardPinStatusChangeApi = async (
  data: putBoardPinStatusChangeApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/board/pin-status`,
    method: 'PUT',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Board section apis

export const PostAddBoardSectionApi = async (data: PostAddSectionApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/section/create-section',
    method: 'POST',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const PutEditBoardSectionApi = async (data: PutEditSectionApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/section/update-section/${data?.section_id}`,
    method: 'PUT',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const PutEditBoardSectionOrderApi = async (
  data: PutEditSectionApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/section/update-order`,
    method: 'PUT',
    data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const DeleteBoardSectionByIdApi = async (
  data: DeleteSectionByIdApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/section/${data?.section_id}`,
    method: 'DELETE',
    data: { force_fully_delete: data?.force_fully_delete },
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetBoardSectionsByIdApi = async (
  data: GetBoardSectionsByIdApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/section/get-all/${data?.board_id}`,
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
