import AxiosDefault from '@/services/AxiosDefault';
import AxiosWithoutTimeout from '@/services/AxiosWithoutTimeout';

type PostAddTaskApiData = {
  title: string;
  agenda?: string;
  tags?: string[];
  due_date?: string;
  client_id?: string;
  assign_to?: string;
  mark_as_done?: boolean;
  attachments?: any;
  priority?: string;
  board_id?: string;
  status?: string;
  comment?: string;
};

type PatchEditTaskApiData = {
  _id: string;
  title: string;
  agenda?: string;
  tags?: string[];
  due_date?: string;
  client_id?: string;
  assign_to?: string;
  mark_as_done?: boolean;
  attachments?: any;
  priority?: string;
  board_id?: string;
  status?: string;
  comment?: string;
};

type putTaskStatusChangeApiData = {
  _id: string;
  status: string;
};

type DeleteTaskApiData = {
  taskIdsToDelete: string[];
};

type PostLeaveTaskApiData = {
  task_id: string;
};

type GetAllTaskApiData = {
  page?: number;
  items_per_page?: number;
  sort_order?: string;
  sort_field?: string;
  search?: string;
  board_id?: string;
};

type GetTaskByIdApiData = {
  taskId: string;
};

type PostAddCommentsApiData = {
  task_id: string;
  comment: string;
};

type GetAllCommentsByIdApiData = {
  task_id: string;
};

type TaskTimerStartAndStopPayload = {
  task_id: string;
  event_type: 'timer_start' | 'timer_end';
};

type PostBulkTasksUploadApiData = {
  board_id?: string;
  parent_task_id?: string;
  file?: any;
};

type GetAllParentTasksApiData = {
  board_id?: string;
};
type PostBulkTasksUpdateApiData = {
  task_ids: string[];
  assignees?: string[];
  priority?: string;
  status?: string;
  mark_as_done?: boolean;
  mark_as_delete?: boolean;
};

// type ApiResponse = {
//   success: boolean;
//   message: string;
//   token: string;
// };

export const PostAddTaskApi = async (data: PostAddTaskApiData) => {
  // console.log(data)
  const response = await AxiosWithoutTimeout({
    url: '/api/v1/task/create-task',
    method: 'POST',
    data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

export const PatchEditTaskApi = async (data: any) => {
  // Access the _id field
  const id = data?.get('_id');
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/task/update-task/${id}`,
    method: 'PUT',
    data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

export const GetAllTaskApi = async (data: GetAllTaskApiData) => {
  const response = await AxiosWithoutTimeout({
    url: '/api/v1/task/task-list',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetTaskByIdApi = async (data: GetTaskByIdApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/get-task/${data.taskId}`,
    method: 'GET',
    // data: data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const DeleteTaskApi = async (data: DeleteTaskApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/delete-task`,
    method: 'DELETE',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

//leave task api
export const PostLeaveTaskApi = async (data: PostLeaveTaskApiData) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/leave-task',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const putTaskStatusChangeApi = async (
  data: putTaskStatusChangeApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/update-status/${data._id}`,
    method: 'PUT',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const PostTagsOptionApi = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/tag-list`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// comments section add and get

export const PostAddCommentsApi = async (data: any) => {
  // console.log(data)
  const response = await AxiosWithoutTimeout({
    url: '/api/v1/task/add-comment',
    method: 'POST',
    data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

export const GetAllCommentsByIdApi = async (
  data: GetAllCommentsByIdApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/list-comments/${data.task_id}`,
    method: 'GET',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const TaskTimerStartAndStopApi = async (
  data: TaskTimerStartAndStopPayload
) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/time-tracking',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const GetActiveTaskTimeApi = async () => {
  const response = await AxiosDefault({
    url: '/api/v1/task/active-track',
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const TaskTimeTrackedHistoryApi = async (task_id: string) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/tracked-history/${task_id}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const TrackedBoardsApi = async (data: {
  skip: number;
  limit: number;
  all: boolean;
}) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/tracked-boards',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const TrackedTimeTaskHistoryApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/tracked-boardwise',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const TrackedTimeTaskHistoryDetailsApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/tracked-taskwise',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const UpdateDeleteTrackedTimeApi = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/tracked-history/${data?.timerId}`,
    method: 'PATCH',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const AssignedByListApi = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/task/assignedby/${data?.board_id}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

export const TimeTrackedHistoryDetailsApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/timer-history',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get all parent tasks api
export const getAllParentTasksApi = async (data: GetAllParentTasksApiData) => {
  const response = await AxiosDefault({
    url: `/api/v1/import/tasks-list/${data?.board_id}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Post bulk tasks and sub tasks upload api
export const postBulkTasksUploadApi = async (
  data: PostBulkTasksUploadApiData
) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/import/tasks`,
    method: 'POST',
    data,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
};

// set reminder Task api
export const SetReminderTaskApi = async (data: any) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: `/api/v1/task/set-reminder`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// getTimerLogs
export const getTimerLogsTaskApi = async (data: any) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: `/api/v1/task/timer-log`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// getmyTimerLogs
export const getmyTimerLogsTaskApi = async (data: any) => {
  // console.log(data)
  const response = await AxiosDefault({
    url: `/api/v1/task/timer-user-log`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// TrackedAllTask dropdown api
export const TrackedAllTaskHistoryApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/tracked-boardwise',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// post bulk tasks update api
export const postBulkTasksUpdateApi = async (
  data: PostBulkTasksUpdateApiData
) => {
  const response = await AxiosDefault({
    url: '/api/v1/task/bulk-task-update',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
