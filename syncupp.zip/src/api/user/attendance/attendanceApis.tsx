import AxiosDefault from '@/services/AxiosDefault';

// GET USER ATTENDANCE LIST APIS
export const getAllUserAttendanceApi = async (data: any) => {
    const response = await AxiosDefault({
        url: '/api/v1/attendance/list',
        method: 'POST',
        data,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// PUNCH IN/OUT API
export const logAttendanceApi = async (data: any) => {
    const response = await AxiosDefault({
        url: '/api/v1/attendance/record-punch',
        method: 'POST',
        data,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// GET ACTIVE TRACKED TIME FOR PUCNIN
export const getWorkedDurationApi = async () => {
    const response = await AxiosDefault({
        url: '/api/v1/attendance/active-track',
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

export const getUserDetailsAttendanceApi = async (data: any) => {
    const response = await AxiosDefault({
        url: '/api/v1/attendance/details-list',
        method: 'POST',
        data,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

export const modifyLogApi = async (data: any) => {
    const response = await AxiosDefault({
        url: '/api/v1/attendance/modify-logs',
        method: 'PUT',
        data,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// DELETE LOG
export const deleteTrackedTimeApi = async (data: any) => {
    const response = await AxiosDefault({
        url: '/api/v1/attendance/delete-log',
        method: 'DELETE',
        data,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// REPORT DOWNLOAD
export const reportDownloadApi = async (data: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/attendance/report-download`,
        method: 'POST',
        data,
        contentType: 'application/json',
        responseType: 'blob', // Important for binary data
      });
    const responseData = response.data;
    return responseData;
};

// USER REPORT DOWNLOAD
export const userReportDownloadApi = async (data: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/attendance/user-report-download`,
        method: 'POST',
        data,
        contentType: 'application/json',
        responseType: 'blob', // Important for binary data
      });
    const responseData = response.data;
    return responseData;
};