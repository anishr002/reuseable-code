import AxiosWithoutTimeout from '@/services/AxiosWithoutTimeout';

// Get the Roles list
export const getRolesListAPI = async (payload: any) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/subrole/list`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Create the Sub role
export const createSubRoleAPI = async (payload: any) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/subrole/create`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Edit the sub role
export const editSubRoleAPI = async (payload: any, subRoleId: string) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/subrole/update/${subRoleId}`,
        method: 'PATCH',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Delete the sub role
export const deleteSubRoleAPI = async (subRoleId: string) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/subrole/delete/${subRoleId}`,
        method: 'DELETE',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Get the sub role
export const getSubRoleByIdAPI = async (subRoleId: string) => {
    const response = await AxiosWithoutTimeout({
        url: `/api/v1/subrole/get/${subRoleId}`,
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Get the user permission
export const getPermissionsAPI = async () => {
    const response = await AxiosWithoutTimeout({
        url: '/api/v1/subrole/permissions',
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};