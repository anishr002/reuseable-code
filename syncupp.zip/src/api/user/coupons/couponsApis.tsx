import AxiosDefault from "@/services/AxiosDefault";


type RedeemCoupon = {
    couponId: string;
}

export const GetCouponslistData = async (data: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/coupon/coupon-list?coupon_count=${data?.coupon_count}`,
        method: "GET",
        contentType: "application/json",
    });
    const responseData = response.data;
    return responseData;
};

export const GetMyCouponslistData = async () => {
    const response = await AxiosDefault({
        url: "/api/v1/coupon/list",
        method: "GET",
        contentType: "application/json",
    });
    const responseData = response.data;
    return responseData;
};

//  Redeem Coupon
export const RedeemCouponDataApi = async (data: RedeemCoupon) => {
    const response = await AxiosDefault({
        url: '/api/v1/payment/coupon-payout',
        method: 'POST',
        data: data,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};


