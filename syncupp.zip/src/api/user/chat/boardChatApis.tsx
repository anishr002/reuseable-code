import AxiosDefault from '@/services/AxiosDefault';

// GET chat boards list api
export const getChatBoardsListApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/boards',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get Board Tasks History api
export const getBoardTasksHistoryApi = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/tasks`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get Task comments History api
export const getTaskCommentsHistoryApi = async (data: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/task-comments`,
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
