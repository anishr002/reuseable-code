import { CreateChatGroupPayload } from '@/redux/slices/user/chat/group/groupChatSlice';
import AxiosDefault from '../../../services/AxiosDefault';
import axios from 'axios';
import AxiosWithoutTimeout from '@/services/AxiosWithoutTimeout';

// GET USER LIST APIs
export const GetChatUserApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/users',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get user single user messages
export const GetSingleUserChatApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/history',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Edit message for chat and group api
export const editMessageChatApi = async (data: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/edit-chat',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// API for download document
export const GetDocumentDownloadApi = async (url: any) => {
  const response = await axios({
    url,
    method: 'GET',
    responseType: 'blob',
  });
  const responseData = response.data;
  return responseData;
};

// Group API

// Get Member List
export const GetMemberListApi = async (data?: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/group/users',
    method: 'GET',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get Group List API
export const GroupListingApi = async (payload: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/groups',
    method: 'POST',
    data: payload,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
}

// Create Group API
export const CreateGroupApi = async (payload: CreateChatGroupPayload) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/group/create',
    method: 'POST',
    data: payload,
    contentType: "multipart/form-data",
  });
  const responseData = response.data;
  return responseData;
};

// Update Group API
export const UpdateGroupApi = async (payload: any) => {
  const response = await AxiosDefault({
    url: '/api/v1/chat/group/update',
    method: 'PATCH',
    data: payload,
    contentType: "multipart/form-data",
  });
  const responseData = response.data;
  return responseData;
};

// Get Single Group Message History
export const GetGroupHistoryApi = async (payload: string) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/group/history`,
    method: 'POST',
    data: payload,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Get Group Details By Id
export const GetGroupByIdApi = async (groupId: string) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/group/${groupId}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// Upload Image In Chat
export const UploadImageInUserChatAPI = async (payload: any) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/chat/upload-image`,
    method: 'POST',
    data: payload,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
}

// Upload Image In Group
export const UploadImageInGroupChatAPI = async (payload: any) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/chat/upload-image`,
    method: 'POST',
    data: payload,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
}

// Upload Image In Chat
export const UploadDocumentInUserChatAPI = async (payload: any) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/chat/upload-document`,
    method: 'POST',
    data: payload,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
}

// Upload Image In Group
export const UploadDocumentInGroupChatAPI = async (payload: any) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/chat/upload-document`,
    method: 'POST',
    data: payload,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
}

// Upload Image In Chat
export const UploadAudioInUserChatAPI = async (payload: any) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/chat/upload-audio`,
    method: 'POST',
    data: payload,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
}

// Upload Image In Group
export const UploadAudioInGroupChatAPI = async (payload: any) => {
  const response = await AxiosWithoutTimeout({
    url: `/api/v1/chat/upload-audio`,
    method: 'POST',
    data: payload,
    contentType: 'multipart/form-data',
  });
  const responseData = response.data;
  return responseData;
}

// Recent 5 Chat User or Group
export const RecentUserListAPI= async (payload: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/lastest-history`,
    method: 'POST',
    data: payload,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
}

// Get Shared Flies
export const GetSharedFilesAPI = async (payload: any) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/documents`,
    method: 'POST',
    data: payload,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
}

// Get Meta Data
export const GetMetaDataAPI = async (payload: any) => {
  const response = await AxiosDefault({
    url: `api/v1/chat/meta-data?url=${encodeURIComponent(payload)}`,
    method: 'GET',
    contentType: 'application/json'
  });
  const responseData = response.data;
  return responseData;
}


// Leave the group
export const leaveChatGroupAPI = async (payload: {group_id: string}) => {
  const response = await AxiosDefault({
    url: `/api/v1/chat/group/leave`,
    method: 'POST',
    data: payload,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
}
