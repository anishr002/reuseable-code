import AxiosDefault from '@/services/AxiosDefault';


// Get the history list
export const getHistoryLogAPI = async (payload: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/get-history`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};
