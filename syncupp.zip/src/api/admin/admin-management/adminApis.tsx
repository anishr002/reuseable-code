import AxiosDefault from '@/services/AxiosDefault';

// Get the Admins list
export const getAdminsListAPI = async (payload: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/admin-list`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Create the Admin
export const createAdminAPI = async (payload: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/admin-create`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Edit the Admin
export const editAdminAPI = async (payload: any, subRoleId: string) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/update-admin/${subRoleId}`,
        method: 'PATCH',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Delete the Admin
export const deleteAdminAPI = async (adminId: string) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/admin-delete/${adminId}`,
        method: 'DELETE',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Get the admin by id
export const getAdminByIdAPI = async (adminId: string) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/get-admin/${adminId}`,
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};