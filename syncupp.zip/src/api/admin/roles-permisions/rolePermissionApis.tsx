import AxiosDefault from '@/services/AxiosDefault';

// Get the Roles list
export const getRolesListAPI = async () => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/role-list`,
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Create the Sub role
export const createSubRoleAPI = async (payload: any) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/create-role`,
        method: 'POST',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Edit the sub role
export const editSubRoleAPI = async (payload: any, subRoleId: string) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/update-role/${subRoleId}`,
        method: 'PATCH',
        data: payload,
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Delete the sub role
export const deleteSubRoleAPI = async (subRoleId: string) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/delete-role/${subRoleId}`,
        method: 'DELETE',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};

// Get the sub role
export const getSubRoleByIdAPI = async (subRoleId: string) => {
    const response = await AxiosDefault({
        url: `/api/v1/admin/get-role/${subRoleId}`,
        method: 'GET',
        contentType: 'application/json',
    });
    const responseData = response.data;
    return responseData;
};