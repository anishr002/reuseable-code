import AxiosDefault from '@/services/AxiosDefault';

type PostAddSubscriptionPlanApiData = {
  name: string;
  description: string;
  period: string;
  no_of_users: number;
  currency: string;
  amount: number;
  workspaces_count: number;
};

type PostAddCustomSubscriptionPlanApiData = {
  name: string;
  description: string;
  period: string;
  no_of_users: number;
  currency: string;
  amount: number;
  workspaces_count: number;
  plan_id?: string;
  allowed_users?: string[];
};

type GetAllSubscriptionPlanApiData = {
  page?: number;
  items_per_page?: number;
  sort_order?: string;
  sort_field?: string;
  search?: string;
};

type GetSubscriptionPlanApiData = {
  planId: string;
};

type PatchSubscriptionPlanApiData = {
  planId: string;
  name: string;
  description: string;
  period: string;
  no_of_users: number;
  currency: string;
  amount: number;
  workspaces_count: number;
  active?: boolean;
  status_update?: boolean;
  plan_id?: string;
  allowed_users?: string[];
};

type DeleteSubscriptionPlanApiData = {
  planId: string;
};

type PatchSubscriptionPlanStatusApiData = {
  planId: string;
  active: boolean;
};

type GetAllPlanListApiData = {
  mode: string;
}

type GetAgencyWorkspaceListApiData = {
  agency_id: string;
};

// type ApiResponse = {
//   success: boolean;
//   message: string;
//   token: string;
// };

// add subscription plan api
export const postAddSubscriptionPlanApi = async (
  data: PostAddSubscriptionPlanApiData
) => {
  const response = await AxiosDefault({
    url: '/api/v1/admin/plan-create',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// add subscription plan api
export const postAddCustomSubscriptionPlanApi = async (
  data: PostAddCustomSubscriptionPlanApiData
) => {
  const response = await AxiosDefault({
    url: '/api/v1/admin/custom-plan-create',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// get all subscription plan api
export const getAllSubscriptionPlanApi = async (
  data: GetAllSubscriptionPlanApiData
) => {
  const response = await AxiosDefault({
    url: '/api/v1/admin/plans',
    method: 'POST',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// get subscription plan data api
export const getSubscriptionPlanApi = async (
  data: GetSubscriptionPlanApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/admin/plan/${data?.planId}`,
    method: 'GET',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// update subscription plan api
export const patchSubscriptionPlanApi = async (
  data: PatchSubscriptionPlanApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/admin/update/${data?.planId}`,
    method: 'PATCH',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// delete subscription plan api
export const deleteSubscriptionPlanApi = async (
  data: DeleteSubscriptionPlanApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/admin/delete/${data?.planId}`,
    method: 'DELETE',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// update subscription plan status api
export const patchSubscriptionPlanStatusApi = async (
  data: PatchSubscriptionPlanStatusApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/admin/update/${data?.planId}`,
    method: 'PATCH',
    data,
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// get all standard or custom plan api
export const getAllPlanListApi = async (
  data: GetAllPlanListApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/admin/plans?plan_category=${data?.mode}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};

// get all workspaces of Agency api
export const getAgencyWorkspaceListApi = async (
  data: GetAgencyWorkspaceListApiData
) => {
  const response = await AxiosDefault({
    url: `/api/v1/admin/workspace_members/${data?.agency_id}`,
    method: 'GET',
    contentType: 'application/json',
  });
  const responseData = response.data;
  return responseData;
};
