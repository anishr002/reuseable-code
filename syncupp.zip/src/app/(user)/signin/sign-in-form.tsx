'use client';

import { SocialAuth } from '@/app/shared/(user)/auth-layout/auth-wrapper-two';
import OrSeparation from '@/app/shared/(user)/auth-layout/or-separation';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Password } from '@/components/ui/password';
import Spinner from '@/components/ui/spinner';
import { routes, SignUpStepper } from '@/config/routes';
import socket from '@/io';
import { Paymentloader } from '@/redux/slices/payment/paymentSlice';
import {
  clearStepperData,
  goToStep,
  storeStepperData,
} from '@/redux/slices/user/auth/authSlice';
import {
  setRoleonSingup,
  setSignInData,
  setSignInuserData,
  setTeamMemberRole,
  signInUser,
} from '@/redux/slices/user/auth/signinSlice';
import { setDefaultWorkspace } from '@/redux/slices/user/workspace/workspaceSlice';
import { handleKeyDown } from '@/utils/common-functions';
import { loginSchema, LoginSchema } from '@/utils/validators/login.schema';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { SubmitHandler } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import useMedia from 'react-use/lib/useMedia';
import { toast } from 'react-hot-toast';
import 'src/layouts/helium/style.css';
import ManagePlan from '@/app/(hydrogen)/[workspaceName]/manage-subscription/ManagePlan';
import { useEffect } from 'react';
import Image from 'next/image';
import moment from 'moment';

import main_logo from '@public/assets/images/main_logo.svg';
import FreeTrialModal from '../signup/FreeTrialModal';
import SelectSubscriptionPlanModal from '@/app/(hydrogen)/[workspaceName]/manage-subscription/select-subscription-plan-modal';
import { initiateRazorpay } from '@/services/paymentService';

const initialValues: LoginSchema = {
  email: '',
  password: '',
  rememberMe: false,
};

export default function SignInForm() {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();

  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { loading } = useSelector((state: any) => state?.root?.payment);

  // Will use during payment flow work start
  useEffect(() => {
    dispatch(Paymentloader(false));
  }, [dispatch]);

  const daysUntilTrialEnd = (trialEndDate: any) => {
    const today = moment(); // Get current date
    const endDate = moment(trialEndDate); // Parse trial end date

    const daysRemaining = endDate.diff(today, 'days'); // Calculate the difference in days

    return daysRemaining;
  };

  const checkProfileIsComplete = async (
    token: any,
    user: any,
    workspace: any,
    apiResponse: any
  ) => {
    if (user.first_name == undefined || user.status == 'signup_incomplete') {
      dispatch(goToStep(SignUpStepper.secondSignupPage));
      router.push(routes.signUp);
      return;
    } else if (user.contact_number == undefined) {
      dispatch(goToStep(SignUpStepper.contactNumberPage));
      router.push(routes.signUp);
      return;
    } else if (user.profession_role == undefined) {
      dispatch(goToStep(SignUpStepper.professionPage));
      router.push(routes.signUp);
      return;
    } else if (user.no_of_people == undefined) {
      dispatch(goToStep(SignUpStepper.noOfPeoplePage));
      router.push(routes.signUp);
      return;
    } else if (workspace == undefined) {
      dispatch(goToStep(SignUpStepper.createWorkspacePage));
      router.push(routes.signUp);
      return;
    } else {
      // localStorage.setItem('token', token);
        await dispatch(setSignInData({ token, workspace, apiResponse }));
        await dispatch(setDefaultWorkspace(workspace?.workspace));
        socket.disconnect();
        socket.connect();
        console.log("custom payment.....", user, user?.custom_subscription_plan);
        if(user?.custom_subscription_plan) {
          initiateRazorpay(
            router,
            routes.dashboard(workspace?.workspace?.name),
            token,
            dispatch,
            user?.custom_subscription_plan,
            closeModal
          );
        }
        router.replace(routes.dashboard(workspace?.workspace?.name));
      // }
    }
  };

  const onSubmit: SubmitHandler<LoginSchema> = (data) => {
    // Will use during payment flow work start
    dispatch(Paymentloader(true));
    dispatch(signInUser(data)).then(async (result: any) => {
      if (signInUser.fulfilled.match(result)) {
        if (result && result.payload.success === true) {

          console.log("signInUser response.....", result?.payload?.data);

          const { token, user, workspace } = result?.payload?.data;

          const loginUserDetailsInWorkspace =
            workspace?.workspace?.members?.find(
              (data: any) => data?.user_id == workspace?.workspace?.created_by
            );

          // Profile pending code
          // result?.payload?.data?.user?.profile_pending && localStorage.setItem(
          //   'profile_pending',
          //   result?.payload?.data?.user?.profile_pending
          // );
          if (false &&
            !workspace?.workspace?.trial_end_date &&
            workspace?.role == 'agency' &&
            loginUserDetailsInWorkspace?.status === 'payment_pending'
          ) {
            // comment for payment pending flow
            socket.disconnect();
            socket.connect();

            dispatch(setDefaultWorkspace(workspace?.workspace));
            openModal({
              view: <SelectSubscriptionPlanModal title="Choose Your Plan" />,
              customSize: '900px',
            });

            // initiateRazorpay(
            //   router,
            //   routes.dashboard(workspace?.workspace?.name),
            //   result?.payload?.data?.token,
            //   dispatch
            // );
            return;
          } else if (result?.payload?.data?.user?.profile_pending) {
            // comment for profile pending page
            // localStorage.setItem(
            //   'profile_pending',
            //   result?.payload?.data?.user?.profile_pending
            // );
            // socket.disconnect();
            // socket.connect();
            // router.push(routes.dashboard);
          } else {

            dispatch(clearStepperData());
            dispatch(storeStepperData(user));

            // Check Profile is completed or not if  Workspace is not found || Check if workspace is found and role was agency
            if (!workspace || (workspace && workspace.role == 'agency')) {
              await checkProfileIsComplete(
                token,
                user,
                workspace,
                result?.payload
              );
            } else {
              // If Workspace found and role is no agency

              if (workspace?.workspace == null) {
                // User not assign to workspace
                toast.error(
                  'You have been not assigned to any workspace, Please Sign up'
                );
                dispatch(Paymentloader(false));
                return;
              }
              // localStorage.setItem('token', token);
              // await dispatch(setSignInuserData(result?.payload))
              // await dispatch(setRoleonSingup(workspace.role))
              // await dispatch(setTeamMemberRole(workspace?.sub_role))
              await dispatch(
                setSignInData({
                  token,
                  workspace,
                  apiResponse: result?.payload,
                })
              );
              dispatch(Paymentloader(false));
              dispatch(setDefaultWorkspace(workspace?.workspace));
              socket.disconnect();
              socket.connect();
              if(user?.custom_subscription_plan) {
                console.log("custom payment.....", user, user?.custom_subscription_plan);
                initiateRazorpay(
                  router,
                  routes.dashboard(workspace?.workspace?.name),
                  token,
                  dispatch,
                  user?.custom_subscription_plan,
                  closeModal
                );
              }
              router.replace(routes.dashboard(workspace?.workspace?.name));
            }
          }
        } else {
          dispatch(Paymentloader(false));
        }
      } else {
        dispatch(Paymentloader(false));
      }
    });
    // setReset({ ...initialValues, rememberMe: false });
  };

  return (
    <>
      <div className="signup_bg_image_03   ">
        <div className="mb-4 mt-12 flex h-[50px] flex-col items-center justify-between px-12 lg:mb-0 lg:flex-row">
          {/* logo */}
          <div className="flex  items-center justify-start">
            <Image
              src={main_logo}
              alt={main_logo}
              // className="dark:invert"
              width={100}
              height={50}
            />
          </div>
          <div className="mt-6 flex flex-row items-center justify-end lg:mt-0">
            <Link
              href={routes.signIn}
              className="rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] px-6 py-4 text-[16px] font-semibold text-white"
            >
              Already a user
            </Link>
            <div className="ms-6">
              <Link href={routes.signUp}>Sign Up</Link>
            </div>
          </div>
        </div>

        {/* Simple Login */}
        <div className="mt-14 grid h-auto overflow-auto p-8 px-4 lg:mt-0 lg:h-5/6 lg:p-0">
          <div className="mx-auto w-auto place-self-center rounded-lg border border-[#f7f7f7]  bg-white p-8 shadow-lg lg:w-[720px]">
            <div className="text-center">
              <h1 className="mx-auto mb-8 w-[70%] text-center text-[28px] font-semibold leading-8 text-[#120425] lg:mt-8 lg:text-[40px] lg:leading-10">
                Sign In
              </h1>
              {/* form */}
              <div className="mt-8 px-4 lg:px-16">
                <SocialAuth isSignIn={true} />
                <OrSeparation
                  className="mb-8 text-center dark:before:bg-gray-200 xl:mb-7 dark:[&>span]:bg-[#191919]"
                  title={`OR`}
                />
                <Form<LoginSchema>
                  validationSchema={loginSchema}
                  onSubmit={onSubmit}
                  // resetValues={reset}
                  useFormProps={{
                    mode: 'onTouched',
                    defaultValues: initialValues,
                  }}
                >
                  {({ register, formState: { errors } }) => (
                    <div className="placeholder_color space-y-5">
                      <Input
                        onKeyDown={handleKeyDown}
                        type="email"
                        label="Email"
                        placeholder="Enter your email"
                        size="xl"
                        className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold
                          "
                        {...register('email')}
                        error={errors?.email?.message}
                        autoComplete="off"
                      />
                      <Password
                        onKeyDown={handleKeyDown}
                        label="Password"
                        placeholder="Enter your password"
                        size="xl"
                        className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold
                          "
                        {...register('password')}
                        error={errors?.password?.message}
                        visibilityToggleIcon={(visible: any) =>
                          visible ? (
                            <span className="h-auto w-5 font-semibold text-[#7763E8]">
                              Hide
                            </span>
                          ) : (
                            <span className="h-auto w-5 font-semibold text-[#7763E8]">
                              Show
                            </span>
                          )
                        }
                        autoComplete="off"
                      />
                      <div className="flex items-center justify-between pb-2">
                        <Checkbox
                          {...register('rememberMe')}
                          label="Remember Me"
                          color="info"
                          variant="flat"
                          className="[&>label>span]:font-medium"
                        />
                        <Link
                          href={routes?.forgotPassword}
                          className="h-auto p-0 text-sm font-semibold text-[#53216F] underline transition-colors hover:text-[#8e45b8] hover:no-underline"
                        >
                          Forgot Password?
                        </Link>
                      </div>
                      <Button
                        className="w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-4 text-[16px] font-semibold text-white"
                        type="submit"
                        color="info"
                        size={isMedium ? 'lg' : 'xl'}
                        disabled={signIn.loading || loading}
                      >
                        Sign In
                        {(signIn.loading || loading) && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                    </div>
                  )}
                </Form>
                {/* <Text className="mt-5 text-center text-[15px] leading-loose text-gray-500 lg:text-start xl:mt-7 xl:text-base">
        Don’t have an account?{' '}
        <Link
          href={routes?.signUp}
          className="font-semibold text-gray-700 transition-colors hover:text-[#8e45b8]"
        >
          Create Account
        </Link>
      </Text> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
