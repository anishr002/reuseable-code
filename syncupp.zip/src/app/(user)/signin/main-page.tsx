'use client';
import AuthWrapperTwo from '@/app/shared/(user)/auth-layout/auth-wrapper-two';
import SignInForm from './sign-in-form';
import WithAuthPublic from '@/utils/public-route-user';
import { useSearchParams } from 'next/navigation';
import { useEffect } from 'react';
import { logoutUser } from '@/redux/slices/user/auth/signinSlice';
import { useDispatch } from 'react-redux';


function SignIn() {

  const dispatch = useDispatch()
  const searchParams = useSearchParams();
  const logout = searchParams.get("logout");

  // console.log(logout, 'logout')

  useEffect(() => {
    if (logout) {
      dispatch(logoutUser());
    }
  }, [])

  return (
    // <AuthWrapperTwo title="Sign In" isSignIn isSocialLoginActive={true}>
      <SignInForm />
    // </AuthWrapperTwo>
  );
}

export default WithAuthPublic(SignIn);
