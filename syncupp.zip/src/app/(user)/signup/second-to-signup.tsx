'use client';

import { SocialAuth } from '@/app/shared/(user)/auth-layout/auth-wrapper-two';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Password } from '@/components/ui/password';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { useMedia } from '@/hooks/use-media';
import {
  nextStep,
  previousStep,
  signUpComplete,
  storeStepperData,
} from '@/redux/slices/user/auth/authSlice';
import { handleKeyDown } from '@/utils/common-functions';
import {
  SignupCompleteSchema,
  signupCompleteSchema,
} from '@/utils/validators/signup.schema';
import Image from 'next/image';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { SubmitHandler } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import 'src/layouts/helium/style.css';
import OrSeparation from '../../shared/(user)/auth-layout/or-separation';

import main_logo from '@public/assets/images/main_logo.svg';
import { CiLock } from 'react-icons/ci';
import { GoMail, GoPerson } from "react-icons/go";

export default function SecondToSignupPage(props: any) {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const searchParams = useSearchParams();
  const search = searchParams.get('referral');
  const affiliaterefferalcode = searchParams.get('affiliatereferal');
  const affiliateemail = searchParams.get('email');
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false)

  const { setTitle, setNextBtn, setFormData, formData } = props;

  const { stepperData } = useSelector((state: any) => state?.root?.authSignup);

  const initialValues = {
    first_name: stepperData?.first_name ?? '',
    last_name: stepperData?.last_name ?? '',
    email: stepperData?.email ?? '',
    password: stepperData?.password ?? '',
    confirmPassword: stepperData?.confirmPassword ?? '',
  };

  const onSubmit: SubmitHandler<SignupCompleteSchema> = (data) => {
    // const updatedData = {
    //   ...data,
    //   ...(search && { referral_code: search }),
    //   ...(affiliaterefferalcode && {
    //     affiliate_referral_code: affiliaterefferalcode,
    //   }),
    //   ...(affiliateemail && {
    //     affiliate_email: encodeURIComponent(affiliateemail),
    //   }),
    // };
    // setFormData(updatedData);
    // setNextBtn(true);
    // setTitle('Company Detail');
    setLoading(true);

    dispatch(signUpComplete(data)).then((result: any) => {
      if (signUpComplete.fulfilled.match(result)) {
        if (result.payload.status) {
          dispatch(storeStepperData(data));
          dispatch(nextStep());
        }
      }
      setLoading(false)
    });
  };

  return (
    <>
      <div className="signup_bg_image_03 ">
        {/* right side button */}
        <div className="mt-12 h-[50px] flex flex-col lg:flex-row mb-4 lg:mb-0 items-center justify-between px-12">
          {/* logo */}
          <div className="flex  items-center justify-start">
            <Image
              src={main_logo}
              alt={main_logo}
              // className="dark:invert"
              width={100}
              height={50}
            />
          </div>
          <div className="flex flex-row items-center justify-end mt-6 lg:mt-0">
            <Link href={routes.signIn}>Already a user</Link>
            <div className="ms-6">
              <Link
                href={routes.signUp}
                className="w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-4 px-6 text-[16px] font-semibold text-white"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>

        {/* Simple Login */}
        <div className="grid h-5/6 p-4 lg:p-0 overflow-auto mt-14 lg:mt-0">
          <div className="mx-auto w-auto lg:w-[720px] place-self-center rounded-lg bg-white  p-8  border border-[#f7f7f7] shadow-xl ">
            <div className="text-center">
              <h1 className="mb-4 lg:w-[70%] mx-auto text-center text-[28px] lg:text-[40px] font-semibold text-[#120425] leading-8 lg:leading-10 lg:mt-8">
                Seconds to Sign Up!
              </h1>
              {/* signup with g and f */}
              <div className=''>
                {/* Socical signup component */}
                <SocialAuth isSignIn={false} />
                <OrSeparation
                  className="mb-8 text-center dark:before:bg-gray-200 xl:mb-7 dark:[&>span]:bg-[#191919]"
                  title={`OR`}
                />
              </div>
              {/* form */}
              <div className="mt-12 lg:px-28">

                <Form<SignupCompleteSchema>
                  validationSchema={signupCompleteSchema}
                  onSubmit={onSubmit}
                  useFormProps={{
                    mode: 'all',
                    defaultValues: initialValues,
                  }}
                >
                  {({ register, formState: { errors } }) => (
                    <>
                      <div className="grid grid-cols-1 gap-4 placeholder_color">
                        <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          label="First Name"
                          placeholder="Enter First name"
                          size={'xl'}
                          color="info"
                          className="[&>label>span]:font-semibold [&>label>span]:text-left &>label>span]:text-[16px] border-[#9BA1B9]  placeholder:text-[16px] placeholder:font-semibold  flex justify-center text-[16px] font-semibold  w-full
                          "
                          {...register('first_name')}
                          error={errors?.first_name?.message}
                          prefix={<GoPerson className="w-[30px] h-[30px] mt-[3px]" />}
                          autoComplete='off'
                        // prefix={<Image width={20} height={20} src={'/assets/svgs/syncupp-logo.svg'} alt='' />}
                        />
                        <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          label="Last Name"
                          size={'xl'}
                          placeholder="Enter Last Name"
                          color="info"
                          className="[&>label>span]:font-semibold [&>label>span]:text-left &>label>span]:text-[16px] border-[#9BA1B9]  placeholder:text-[16px] placeholder:font-semibold  flex justify-center text-[16px] font-semibold  w-full
                          "
                          {...register('last_name')}
                          prefix={<GoPerson className="w-[30px] h-[30px] mt-[3px]" />}
                          error={errors?.last_name?.message}
                          autoComplete='off'
                        />
                        <Input
                          onKeyDown={handleKeyDown}
                          type="email"
                          size={'xl'}
                          label="Email"
                          placeholder="Enter your Email"
                          color="info"
                          className="[&>label>span]:font-semibold [&>label>span]:text-left &>label>span]:text-[16px] border-[#9BA1B9]  placeholder:text-[16px] placeholder:font-semibold  flex justify-center text-[16px] font-semibold  w-full
                          "
                          {...register('email')}
                          prefix={<GoMail className="w-[30px] h-[30px] mt-[3px]" />}
                          error={errors?.email?.message}
                          disabled={stepperData?.email ? true : false}
                        />

                        <Password
                          onKeyDown={handleKeyDown}
                          label="Create Password"
                          placeholder="Enter your Password"
                          size={'xl'}
                          color="info"
                          className="[&>label>span]:font-semibold [&>label>span]:text-left &>label>span]:text-[16px] border-[#9BA1B9]  placeholder:text-[16px] placeholder:font-semibold  flex justify-center text-[16px] font-semibold  w-full
                          "
                          {...register('password')}
                          prefix={<CiLock className="w-[30px] h-[30px] mt-[3px]" />}
                          error={errors?.password?.message}
                          visibilityToggleIcon={(visible: any) =>
                            visible ? (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Hide</span>
                            ) : (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Show</span>
                            )
                          }
                          autoComplete='off'
                        />
                        <Password
                          onKeyDown={handleKeyDown}
                          label="Confirm Password"
                          placeholder="Enter your Confirm Password"
                          size={'xl'}
                          color="info"
                          className="[&>label>span]:font-semibold [&>label>span]:text-left &>label>span]:text-[16px] border-[#9BA1B9]  placeholder:text-[16px] placeholder:font-semibold  flex justify-center text-[16px] font-semibold  w-full
                          "
                          {...register('confirmPassword')}
                          prefix={<CiLock className="w-[30px] h-[30px] mt-[3px]" />}
                          visibilityToggleIcon={(visible: any) =>
                            visible ? (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Hide</span>
                            ) : (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Show</span>
                            )
                          }
                          error={errors?.confirmPassword?.message}
                          autoComplete='off'
                        />
                      </div>
                      <div className="mt-6 w-full">
                        <Button
                          className="w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-white mb-4 hover:from-slate-50 hover:to-slate-50 hover:border-1 hover:border-[#8C80D2] hover:text-black"
                          type="submit"
                          disabled={loading}
                        >
                          Next
                          {
                            loading && <Spinner
                              size="sm" tag="div"
                              className="ms-3"
                              color="white"
                            />
                          }
                        </Button>
                        <Button
                          className="w-full rounded-lg border-2 border-[#8C80D2]  bg-whtie text-black hover:bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold  mb-4 hover:text-white"
                          type="button"
                          onClick={() => {
                            dispatch(previousStep());
                          }}
                        >
                          Back
                        </Button>

                      </div>
                    </>
                  )}
                </Form>
              </div>
              <div className='text-[14px] mt-4'>
                By clicking the button above, you agree to our <span className='font-bold underline cursor-pointer hover:text-[#705AEE]'><Link target='_blank' href='https://www.syncupp.com/terms-condition'>Tearms of Service</Link></span>{' '}
                and <span className='font-bold underline cursor-pointer hover:text-[#705AEE]'><Link target='_blank' href="https://www.syncupp.com/privacy-policy">Privacy Policy</Link></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
