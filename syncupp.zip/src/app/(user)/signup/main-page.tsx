'use client';
import SignUpForm from './sign-up-form';
import { useEffect, useState } from 'react';
import CompanyForm from './company-form';
import AuthWrapperTwo from '@/app/shared/(user)/auth-layout/auth-wrapper-two';
import WithAuthPublic from '@/utils/public-route-user';
import { useSearchParams } from 'next/navigation';
import { signUpUserclickcounts } from '@/redux/slices/user/auth/signupSlice';
import { useDispatch, useSelector } from 'react-redux';
import { SignupMarketingPage } from './signup-marketing';
import SecondToSignupPage from './second-to-signup';
import { SignupContactFormPage } from './signup-contact-form';
import { SignupProfessionFormPage } from './signup-profession-form';
import { SignupNoPeopleFormPage } from './signup-no-people-form';
import { SignUpStepper } from '@/config/routes';
import { SignupWorkspaceFormPage } from './signup-workspace-form';

function SignUpPage() {
  const [formData, setFormData] = useState({});
  const [title, setTitle] = useState('Sign Up');
  const [nextBtn, setNextBtn] = useState(false);
  const [fdata, setFdata] = useState({});
  const dispatch = useDispatch();
  const searchParams = useSearchParams();
  const search = searchParams.get('affiliatereferal');

  const { currentStep, stepperData } = useSelector((state: any) => state?.root?.authSignup);
  console.log(currentStep, 'currentSteps');

  console.log(stepperData, 'stepperData');

  useEffect(() => {
    if (search) {
      dispatch(signUpUserclickcounts({ referral_code: search }));
    }
    console.log('called 2 effect')
  }, [search]);

  useEffect(() => {
    // dispatch()
    console.log('called 1 effect')
  }, [])

  return (
    <>
      {/* {nextBtn ? (
        <AuthWrapperTwo title={title} isSocialLoginActive={false}>
          <CompanyForm
            signUpFormData={formData}
            fdata={fdata}
            setFdata={setFdata}
            setNextBtn={setNextBtn}
            setTitle={setTitle}
          />
        </AuthWrapperTwo>
      ) : (
        <AuthWrapperTwo title={title} isSocialLoginActive={true}>
          <SignUpForm
            setFormData={setFormData}
            setNextBtn={setNextBtn}
            setTitle={setTitle}
            formData={formData}
          />
        </AuthWrapperTwo>
      )} */}
      {currentStep == SignUpStepper.marketingPage && <SignupMarketingPage />}
      {currentStep == SignUpStepper.secondSignupPage && <SecondToSignupPage />}
      {currentStep == SignUpStepper.contactNumberPage && <SignupContactFormPage />}
      {currentStep == SignUpStepper.professionPage && <SignupProfessionFormPage />}
      {currentStep == SignUpStepper.noOfPeoplePage && <SignupNoPeopleFormPage />}
      {currentStep == SignUpStepper.createWorkspacePage && <SignupWorkspaceFormPage />}

      {/* <SignupMarketingPage /> */}
      {/* <SecondToSignupPage /> */}
      {/* <SignupContactFormPage /> */}
      {/* <SignupProfessionFormPage /> */}
      {/* <SignupNoPeopleFormPage /> */}
      {/* <SignupWorkspaceFormPage /> */}
    </>
  );
}

export default WithAuthPublic(SignUpPage);
