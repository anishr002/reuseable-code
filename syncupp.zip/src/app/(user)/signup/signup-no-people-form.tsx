import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useDispatch, useSelector } from 'react-redux';
import cn from '@/utils/class-names';
import {
  nextStep,
  previousStep,
  storeStepperData,
} from '@/redux/slices/user/auth/authSlice';

import Image from 'next/image';

import Logo from '@public/assets/images/01_signup_logo.png';
import { GoChevronLeft, GoChevronRight } from "react-icons/go";
import { capitalizeFirstLetter } from '@/utils/common-functions';
import 'src/layouts/helium/style.css';

export const SignupNoPeopleFormPage = () => {
  const noOfPeopleArray = [
    {
      name: 'Just me',
      value: 'Just me',
    },
    {
      name: '2-10',
      value: '2-10',
    },
    {
      name: '11-15',
      value: '11-15',
    },
    {
      name: '16-50',
      value: '16-50',
    },
    {
      name: '51-250',
      value: '51-250',
    },
    {
      name: '251-500',
      value: '251-500',
    },
    {
      name: '501+',
      value: '501+',
    },
    {
      name: "I don't know",
      value: "I don't know",
    },
  ];

  const dispatch = useDispatch();
  const { stepperData } = useSelector((state: any) => state?.root?.authSignup);
  const selectNoOfPeople = (data: { name: string; value: string }) => {
    dispatch(storeStepperData({ no_of_people: data.value }));
    dispatch(nextStep());
  };

  return (
    <>
      <div className="signup_bg_image_02">
        <div className='grid  h-full content-center w-full'>
          <div className="  p-4 lg:p-0  mx-auto overflow-auto lg:overflow-hidden">
            <div className="mx-auto w-auto lg:w-[980px] place-self-center rounded-lg bg-white shadow-lg  ">{/* logo */}
              <div className='grid grid-cols-1 lg:grid-cols-2 gap-8 p-8 place-content-between '>
                <div className='text-center mx-auto lg:place-self-start lg:w-full'>
                  <Image
                    src={Logo} // Local image
                    alt="SyncUp logo"
                    width={108} // Width in pixels
                    height={48} // Height in pixels
                  />
                </div>
                <div className=' place-self-center w-full'>
                  <p className='text-center lg:text-right text-[20px] font-bold'>
                    Welcome, {capitalizeFirstLetter(stepperData?.first_name)} {capitalizeFirstLetter(stepperData?.last_name)}
                  </p>
                </div>
              </div>
              <div className="text-center mt-6 lg:mt-16">
                <h1 className="mb-8 text-[28px] lg:text-[54px] font-bold text-[#120425] lg:leading-[60px] px-16 lg:px-36">
                  How many people will you be working with?
                </h1>
                {/* form */}
                <div className="mt-10 lg:mt-16">
                  <div className='grid grid-cols-2 lg:grid-cols-4 gap-2 lg:gap-4 w-full lg:w-[70%] lg:mx-auto p-2 lg:p-0  lg:mb-20'>
                    {noOfPeopleArray?.map((data, index) => {
                      return (
                        <Button
                          className={
                            `bg-white poppins_font_number rounded-[9px] border-[#9BA1B9] border-2 text-[#000000] text-[16px] font-semibold px-[20px] py-[24px] hover:bg-[#8C80D2] hover:text-[white] hover:border-[#8C80D2] me-4 w-full ${stepperData.no_of_people == data.value ? 'bg-[#8C80D2] text-[white] border-[#8C80D2]' : ''}`}
                          key={index}
                          type="button"
                          onClick={() => selectNoOfPeople(data)}
                        >
                          {data.name}
                        </Button>
                      );
                    })}
                  </div>
                </div>
              </div>
              {/* progress bar */}
              <div className="flex items-center justify-center mt-8  lg:mt-24">
                <div className="w-full">
                  <div className="h-[5px] bg-[#DFE1EC]  overflow-hidden">
                    <div className="h-full bg-[#8C80D2] " style={{ width: '50%' }}></div>
                  </div>
                </div>
              </div>
              {/* back and next button */}
              <div className=" w-full flex justify-center lg:justify-between pt-2 pb-4 px-2 lg:p-8 my-4 lg:my-0">
                <Button
                  className="w-full lg:w-[200px] rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] flex items-center justify-center hover:bg-white hover:border-2 hover:border-[#8C80D2] "
                  type="button"
                  size='xl'
                  onClick={() => dispatch(previousStep())}>
                  <GoChevronLeft className="w-[30px] h-[30px] " />
                  <span className=''> Back</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
