'use client';

import {
  CompanyDetailsSchema,
  companyDetailsSchema,
} from '@/utils/validators/signup.schema';
import { zodResolver } from '@hookform/resolvers/zod';
import { FormProvider, SubmitHandler, useForm } from 'react-hook-form';
import { Button } from 'rizzui';
import CompanyDetailsForm from './company-details';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  signUpUser,
  signUpUserSubscription,
} from '@/redux/slices/user/auth/signupSlice';
import { useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import useMedia from 'react-use/lib/useMedia';
import { initiateRazorpay } from '@/services/paymentService';
import socket from '@/io';
import { setSignInuserData } from '@/redux/slices/user/auth/signinSlice';
import { useModal } from '@/app/shared/modal-views/use-modal';
import ManagePlan from '@/app/(hydrogen)/[workspaceName]/manage-subscription/ManagePlan';
import SelectSubscriptionPlanModal from '@/app/(hydrogen)/[workspaceName]/manage-subscription/select-subscription-plan-modal';

export default function CompanyForm(props: any) {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const { signUpFormData, setNextBtn, setTitle, setFdata, fdata } = props;
  const signUp = useSelector((state: any) => state?.root?.signUp);
  const { subscriptionData } = useSelector((state: any) => state?.root?.signUp);
  const { defaultWorkSpace } =  useSelector((state: any) => state?.root?.workspace)
  
  // console.log(subscriptionData, 'subscriptionData')

  const initialValues = {
    companyName: fdata?.companyName ?? '',
    companyWebsite: fdata?.companyWebsite ?? '',
    peopleCount: fdata?.peopleCount ?? '',
    industry: fdata?.industry ?? '',
  };
  const [loader, setLoader] = useState(false);
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();

  const methods = useForm<CompanyDetailsSchema>({
    resolver: zodResolver(companyDetailsSchema),
    defaultValues: initialValues,
  });

  const onSubmit: SubmitHandler<CompanyDetailsSchema> = (data) => {
    const company_url = data?.companyWebsite?.startsWith('http')
      ? data?.companyWebsite
      : `http://${data?.companyWebsite}`;

    const formData: any = {
      ...data,
      companyWebsite: company_url === 'http://' ? '' : company_url,
    };

    // console.log("company data......", formData)

    dispatch(signUpUser({ ...signUpFormData, ...formData })).then(
      (result: any) => {
        // console.log(result.payload, 'result.payload')
        if (signUpUser.fulfilled.match(result)) {
          console.log(result?.payload?.data, 'payload');
          if (result && result.payload.success === true) {
            // router.replace(routes.signIn);
            localStorage.setItem('profile_pending', 'true');
            localStorage.setItem('token', result?.payload?.data?.token);
            socket.disconnect();
            socket.connect();

            // console.log(result?.payload?.data?.user?.status, '69')

            if (result?.payload?.data?.user?.status === 'payment_pending') {

              openModal({
                view: (
                  <SelectSubscriptionPlanModal title="Choose Your Plan" />
                ),
                customSize: '900px',
              });
              // initiateRazorpay(
              //   router,
              //   routes.viewProfile,
              //   result?.payload?.data?.token,
              //   dispatch
              // );
            } else {
              router.replace(routes.dashboard(defaultWorkSpace?.name));
            }

          }
        }
      }
    );
  };

  const handleClick = () => {
    dispatch(signUpUser({ ...signUpFormData })).then((result: any) => {
      // console.log(result.payload, 'result.payload')
      if (signUpUser.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          // router.replace(routes.signIn);
          localStorage.setItem('profile_pending', 'true');
          localStorage.setItem('token', result?.payload?.data?.token);
          socket.disconnect();
          socket.connect();


          // console.log(result?.payload?.data?.user?.status, '102')

          if (result?.payload?.data?.user?.status === 'payment_pending') {

            openModal({
              view: (
                <SelectSubscriptionPlanModal title="Choose Your Plan" />
              ),
              customSize: '900px',
            });
            // initiateRazorpay(
            //   router,
            //   routes.viewProfile,
            //   result?.payload?.data?.token,
            //   dispatch
            // );
          } else {
            router.replace(routes.dashboard(defaultWorkSpace?.name));
          }

          // dispatch(signUpUserSubscription({})).then((result: any) => {
          // })
        }
        setLoader(false);
      } else {
        setLoader(false);
      }
    });
    setLoader(true);
  };

  const handlePrevClick = () => {
    setNextBtn(false);
    setTitle('Sign Up');
  };

  return (
    <>
      <FormProvider {...methods}>
        <form
          onSubmit={methods.handleSubmit(onSubmit)}
        // className={cn('[&_label.block>span]:font-medium', className)}
        >
          <CompanyDetailsForm fdata={fdata} setFdata={setFdata} />
          <Button
            className="me-3 mt-8 border-2 bg-[#53216F] text-base font-medium hover:bg-[#8e45b8] hover:enabled:bg-[#8e45b8] @xl:w-auto dark:text-white"
            // type="submit"
            color="info"
            rounded="pill"
            size={isMedium ? 'lg' : 'xl'}
            onClick={handlePrevClick}
          >
            Previous
          </Button>
          <Button
            className="me-3 mt-8 border-2 bg-[#53216F] text-base font-medium hover:bg-[#8e45b8] hover:enabled:bg-[#8e45b8] @xl:w-auto dark:text-white"
            // type="submit"
            color="info"
            rounded="pill"
            size={isMedium ? 'lg' : 'xl'}
            onClick={handleClick}
            disabled={loader}
          >
            Skip & Save
            {loader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
          <Button
            className="mt-8 border-2 bg-[#53216F] text-base font-bold hover:bg-[#8e45b8] hover:enabled:bg-[#8e45b8] @xl:w-auto dark:text-white"
            type="submit"
            color="info"
            rounded="pill"
            size={isMedium ? 'lg' : 'xl'}
            disabled={signUp?.loading && !loader}
          >
            Submit
            {signUp?.loading && !loader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </form>
      </FormProvider>
    </>
  );
}
