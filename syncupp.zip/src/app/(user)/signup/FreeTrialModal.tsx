import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon, Title } from '@/components/ui/text';
import { PiXBold } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import { useDispatch, useSelector } from 'react-redux';
import { initiateRazorpayForDefaultPlanSelected } from '@/services/paymentService';
import { useRouter } from 'next/navigation';
import { routes } from '@/config/routes';
import ManagePlan from '@/app/(hydrogen)/[workspaceName]/manage-subscription/ManagePlan';
import SelectSubscriptionPlanModal from '@/app/(hydrogen)/[workspaceName]/manage-subscription/select-subscription-plan-modal';

export default function FreeTrialModal(props: any) {
  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const router = useRouter();
  const { user } = useSelector((state: any) => state?.root?.signIn);
  const token = localStorage.getItem('token');
  
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const onSubmit = () => {
    closeModal();
    try {

      openModal({
        view: <SelectSubscriptionPlanModal title="Choose Your Plan" />,
        customSize: '900px',
      });



      // initiateRazorpayForDefaultPlanSelected(
      //   router,
      //   routes.dashboard(defaultWorkSpace?.name),
      //   token,
      //   dispatch
      // );
    } catch (error) {
      console.log(error, 'Error During Default Plan Selected Flow')
    }

  };

  return (
    <>
      <div className="flex justify-end p-4">
        <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>
      <div className="space-y-4 px-10 pb-10">
        <div className="flex flex-col items-center text-center">
          <p className="text-xl font-bold">Your trial period has ended.</p>
          <p className="text-xl font-bold">Please add your card.</p>
        </div>
        <div className="mt-2 flex flex-col items-center">
          <Button
            onClick={onSubmit}
            className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
            size="DEFAULT"
          >
            Add Card
          </Button>
          {/* <span className="mt-2">Amount Due Today $0</span> */}
        </div>
      </div>
    </>
  );
}
