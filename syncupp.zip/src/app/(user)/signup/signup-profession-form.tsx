'use client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  nextStep,
  previousStep,
  storeStepperData,
} from '@/redux/slices/user/auth/authSlice';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import {
  SignupProfessionSchema,
  signupProfessionSchema,
} from '@/utils/validators/signup.schema';
import { useEffect, useState } from 'react';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

import Image from 'next/image';

import { zodResolver } from '@hookform/resolvers/zod';
import { GoChevronLeft, GoChevronRight } from 'react-icons/go';
import main_logo from '@public/assets/images/main_logo.svg';

export const SignupProfessionFormPage = () => {
  const dispatch = useDispatch();
  const [isOtherSelected, setIsOtherSelected] = useState(false);
  const [initialValue, setInitialValue] = useState({ profession_role: '' });
  const { stepperData } = useSelector((state: any) => state?.root?.authSignup);
  const [selected, setSelected] = useState('');
  const professionRole = [
    {
      name: 'Super Admin',
      value: 'Agency',
    },
    {
      name: 'Freelancer',
      value: 'Freelancer',
    },
    {
      name: 'Other-Specify',
      value: '',
    },
  ];

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignupProfessionSchema>({
    mode: 'all',
    defaultValues: initialValue,
    resolver: zodResolver(signupProfessionSchema),
  });

  useEffect(() => {
    console.log(stepperData?.profession_role, 'stepperData?.profession_role');
    if (stepperData?.profession_role) {
      if (professionRole[0].value == stepperData?.profession_role) {
        setSelected(professionRole[0].value);
      } else if (professionRole[1].value == stepperData?.profession_role) {
        setSelected(professionRole[1].value);
      } else if (stepperData?.profession_role?.length > 0) {
        setSelected(professionRole[2].name);
        setIsOtherSelected(true);
        setInitialValue({
          profession_role: stepperData?.profession_role,
        });
      }
    }
  }, [stepperData?.profession_role]);

  const setProfession = (value: string) => {
    dispatch(storeStepperData({ profession_role: value }));
    dispatch(nextStep());
  };

  const onSubmit: SubmitHandler<SignupProfessionSchema> = (data: any) => {
    dispatch(storeStepperData(data));
    dispatch(nextStep());
  };

  return (
    <>
      <div className="signup_bg_image_02 ">
        <div className="grid  h-full w-full content-center">
          <div className="  overflow-auto p-4  lg:mx-auto lg:overflow-hidden lg:p-0">
            <div className="mx-auto w-auto place-self-center rounded-lg bg-white shadow-lg lg:w-[980px]  ">
              {/* logo */}
              <div className="grid grid-cols-1 place-content-between gap-8 p-8 lg:grid-cols-2 ">
                <div className="mx-auto text-center lg:w-full lg:place-self-start">
                  <Image
                    src={main_logo} // Local image
                    alt="SyncUp logo"
                    width={108} // Width in pixels
                    height={48} // Height in pixels
                  />
                </div>
                <div className=" w-full place-self-center">
                  <p className="text-center text-[20px] font-bold lg:text-right">
                    Welcome, {capitalizeFirstLetter(stepperData?.first_name)}{' '}
                    {capitalizeFirstLetter(stepperData?.last_name)}
                  </p>
                </div>
              </div>
              <div className="mt-6 text-center lg:mt-16 ">
                <h1 className="mb-0 p-4 text-[28px] font-bold text-[#120425] lg:mb-8 lg:p-0 lg:text-[54px] lg:leading-[60px]">
                  What best defines you
                </h1>
                <p className="p-4 text-[18px] font-bold tracking-wide text-[#120425] lg:mb-9 lg:p-0 lg:text-[24px]">
                  and start using Syncupp in seconds!
                </p>
                {/* form */}
                <div className="mt-0 lg:mt-8">
                  <div className="placeholder_color grid grid-cols-1 gap-4 p-8 ">
                    <div className="mx-auto flex w-full flex-col items-center justify-center lg:w-[60%] lg:flex-row">
                      <Button
                        className={`mb-4 me-0 w-full rounded-[9px] border-2 border-[#9BA1B9] bg-white px-[40px] py-[24px] text-[16px] font-semibold text-[#000000] hover:border-[#8C80D2] hover:bg-[#8C80D2] hover:text-[white] lg:mb-0 lg:me-4 lg:w-auto ${
                          professionRole[0].name == selected
                            ? 'border-[#8C80D2] bg-[#8C80D2] text-[white]'
                            : ''
                        }`}
                        type="button"
                        onClick={() => (
                          setIsOtherSelected(false),
                          setProfession(professionRole[0].value)
                        )}
                      >
                        {professionRole[0].name}
                      </Button>
                      <Button
                        className={`mb-4 me-0 w-full rounded-[9px] border-2 border-[#9BA1B9] bg-white px-[40px] py-[24px] text-[16px] font-semibold text-[#000000] hover:border-[#8C80D2] hover:bg-[#8C80D2] hover:text-[white] lg:mb-0 lg:me-4 lg:w-auto ${
                          professionRole[1].name == selected
                            ? 'border-[#8C80D2] bg-[#8C80D2] text-[white]'
                            : ''
                        }`}
                        type="button"
                        onClick={() => (
                          setIsOtherSelected(false),
                          setProfession(professionRole[1].value)
                        )}
                      >
                        {professionRole[1].name}
                      </Button>
                      <Button
                        className={`mb-4 w-full rounded-[9px] border-2 border-[#9BA1B9] bg-white px-[40px] py-[24px] text-[16px] font-semibold text-[#000000] hover:border-[#8C80D2] hover:bg-[#8C80D2] hover:text-[white] lg:mb-0 lg:w-auto  ${
                          professionRole[2].name == selected
                            ? 'border-[#8C80D2] bg-[#8C80D2] text-[white]'
                            : ''
                        }`}
                        type="button"
                        onClick={() => (
                          setIsOtherSelected(true),
                          setSelected(professionRole[2].name)
                        )}
                      >
                        {professionRole[2].name}
                      </Button>
                    </div>
                    {isOtherSelected && (
                      <>
                        <form></form>
                        <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          label=""
                          placeholder=""
                          className="text-left [&>label>span]:font-medium"
                          {...register('profession_role')}
                          error={errors.profession_role?.message}
                        />
                        {/* <Form<SignupProfessionSchema>
                          onSubmit={onSubmit}
                          useFormProps={{
                            mode: 'all',
                            defaultValues: initialValue,
                          }}
                          validationSchema={signupProfessionSchema}
                        >
                          {({ register, formState: { errors } }) => (
                            <>

                              <Input
                                onKeyDown={handleKeyDown}
                                type="text"
                                label=""
                                placeholder=""
                                className="[&>label>span]:font-medium"
                                {...register('profession_role')}
                                error={errors.profession_role?.message}
                              />
                            </>
                          )}
                        </Form> */}
                      </>
                    )}
                  </div>
                </div>
                {/* progress bar */}
                <div className="mt-8 flex items-center  justify-center  lg:mt-16">
                  <div className="w-full">
                    <div className="h-[5px] overflow-hidden  bg-[#DFE1EC]">
                      <div
                        className="h-full bg-[#8C80D2] "
                        style={{ width: '30%' }}
                      ></div>
                    </div>
                  </div>
                </div>
                {/* back and next button */}
                <div className="my-4 flex w-full justify-center px-2 pb-4 pt-2 lg:my-0 lg:justify-between lg:p-8">
                  <Button
                    onClick={() => dispatch(previousStep())}
                    className="flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white lg:w-[200px]"
                    type="button"
                    size="xl"
                  >
                    <GoChevronLeft className="h-[30px] w-[30px] " />
                    <span className=""> Back</span>
                  </Button>
                  {isOtherSelected && (
                    <Button
                      onClick={handleSubmit(onSubmit)}
                      className="flex w-[200px] items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                      type="submit"
                      size="xl"
                    >
                      <span>Next</span>
                      <GoChevronRight className="h-[30px] w-[30px] " />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
