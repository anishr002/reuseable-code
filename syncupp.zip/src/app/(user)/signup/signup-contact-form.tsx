'use client';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { PhoneNumber } from '@/components/ui/phone-input';
import Spinner from '@/components/ui/spinner';
import {
  nextStep,
  phoneNumberIsExist,
  previousStep,
  storeStepperData
} from '@/redux/slices/user/auth/authSlice';
import {
  SignupContactFormSchema,
  signupContactFormSchema,
} from '@/utils/validators/signup.schema';
import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import { Controller, SubmitHandler } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-hot-toast';
import { capitalizeFirstLetter, validatePhoneNumber } from '@/utils/common-functions';
import { GoChevronLeft, GoChevronRight } from 'react-icons/go';
import 'src/layouts/helium/style.css';
import main_logo from '@public/assets/images/main_logo.svg'

export const SignupContactFormPage = () => {
  const dispatch = useDispatch();
  const setValueReference = useRef<any>();
  const [initialValue, setInitialValue] = useState({
    contact_number: '',
  });
  const { stepperData, phoneNumberIsExistLoading } = useSelector(
    (state: any) => state?.root?.authSignup
  );
  const [phoneNumberValid, setPhoneNumberValid] = useState(true);

  useEffect(() => {
    setInitialValue({ contact_number: stepperData?.contact_number });
    setValueReference.current('contact_number', stepperData?.contact_number)
  }, [stepperData?.contact_number]);

  const onSubmit: SubmitHandler<SignupContactFormSchema> = (data: {
    contact_number: string;
  }) => {
    if (!phoneNumberValid) return;

    const payload = {
      email: stepperData?.email,
      contact_number: data?.contact_number,
    };

    dispatch(phoneNumberIsExist(payload)).then((result: any) => {
      if (phoneNumberIsExist.fulfilled.match(result)) {
        if (result.payload.status) {
          if(result?.payload?.data?.unique_contact){
            dispatch(storeStepperData(data));
            dispatch(nextStep());
          } else {
            toast.error('Contact number already exist.');
          }
        }
      }
    });
  };

  return (
    <>
      <div className="signup_bg_image_02 ">
        <div className="grid  h-full w-full content-center  ">
          <div className="overflow-auto p-4  lg:mx-auto lg:overflow-hidden lg:p-0">
            <div className="mx-auto w-auto place-self-center rounded-lg bg-white shadow-lg lg:w-[980px]  ">
              {/* logo */}
              <div className="grid grid-cols-1 place-content-between gap-8 p-8 lg:grid-cols-2 ">
                <div className="mx-auto text-center lg:w-full lg:place-self-start">
                  <Image
                    src={main_logo} // Local image
                    alt="SyncUp logo"
                    width={108} // Width in pixels
                    height={48} // Height in pixels
                  />
                </div>
                <div className=" w-full place-self-center">
                  <p className="text-center text-[20px] font-bold lg:text-right">
                    Welcome, {capitalizeFirstLetter(stepperData?.first_name)}{' '}
                    {capitalizeFirstLetter(stepperData?.last_name)}
                  </p>
                </div>
              </div>
              <div className="mt-6 text-center lg:mt-16 ">
                <h1 className="mx-auto mb-8 w-[70%] px-0 lg:px-20 text-center text-[28px] font-semibold leading-8 text-[#120425] lg:text-[40px] lg:leading-[60px]">
                  Please share your contact number
                </h1>
                {/* form */}
                <div className="mt-10 lg:mt-10 ">
                  <Form<SignupContactFormSchema>
                    validationSchema={signupContactFormSchema}
                    onSubmit={onSubmit}
                    useFormProps={{
                      mode: 'all',
                      defaultValues: initialValue,
                    }}
                  >
                    {({
                      register,
                      control,
                      setError,
                      clearErrors,
                      setValue,
                      formState: { errors, isDirty },
                    }) => (
                    (setValueReference.current = setValue),
                      <>
                        <div className="space-y-5">
                          <div className="p-4 lg:p-0 placeholder_color mb-20 grid grid-cols-1 gap-4 lg:px-28 ">
                            <Controller
                              name="contact_number"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <PhoneNumber
                                  label="Phone Number"
                                  country="us"
                                  size={'xl'}
                                  className="&>label]:text-[16px]
                                w-full
                                 text-left text-[16px] font-semibold [&>label]:text-left [&>label]:text-[16px] [&>label]:font-semibold"
                                  value={initialValue.contact_number}
                                  onChange={onChange}
                                  error={
                                    errors.contact_number?.message
                                  }
                                  // error={
                                  //   !phoneNumberValid
                                  //     ? 'Invalid Phone Number'
                                  //     : errors.contact_number?.message
                                  // }
                                  // isValid={(inputNumber: any, country: any) => {
                                  //   const phoneLength = (
                                  //     country?.format?.match(/\./g) || []
                                  //   ).length;
                                  //   let numberIsValid = validatePhoneNumber(
                                  //     inputNumber,
                                  //     country,
                                  //     isDirty,
                                  //     phoneLength
                                  //   );
                                  //   setPhoneNumberValid(numberIsValid);
                                  //   return numberIsValid;
                                  // }}
                                />
                              )}
                            />
                          </div>
                          {/* progress bar */}
                          <div className="mb-[54px] flex items-center  justify-center">
                            <div className="w-full ">
                              <div className="h-[5px] overflow-hidden  bg-[#DFE1EC]">
                                <div
                                  className="h-full bg-[#8C80D2] "
                                  style={{ width: '10%' }}
                                ></div>
                              </div>
                            </div>
                          </div>
                          <div className="mt-[54px] flex w-full justify-between p-8">
                            <Button
                              className="flex mr-2 lg:mr-0 w-[200px] items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                              type="button"
                              size="xl"
                              onClick={() => {
                                dispatch(previousStep());
                              }}
                            >
                              <GoChevronLeft className="h-[30px] w-[30px] " />
                              <span className=""> Back</span>
                              {/* <Spinner size="sm" tag="div" className="ms-3" color="white" /> */}
                            </Button>
                            <Button
                              className="flex w-[200px] items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                              type="submit"
                              size="xl"
                              disabled={phoneNumberIsExistLoading}
                            >
                              <span> Next</span>
                              <GoChevronRight className="h-[30px] w-[30px] " />
                              {phoneNumberIsExistLoading && (
                                <Spinner
                                  size="sm"
                                  tag="div"
                                  className="ms-3"
                                  color="white"
                                />
                              )}
                            </Button>
                          </div>
                        </div>
                      </>
                    )}
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
