'use client';

import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { SignUpStepper, routes } from '@/config/routes';
import {
  clearStepperData,
  goToStep,
  signUpForMarketing,
  storeStepperData,
} from '@/redux/slices/user/auth/authSlice';
import { handleKeyDown } from '@/utils/common-functions';
import {
  SignupMarketingSchema,
  signupMarketingSchema,
} from '@/utils/validators/signup.schema';
import Link from 'next/link';
import { SubmitHandler } from 'react-hook-form';
import { MdOutlineEmail } from 'react-icons/md';
import { useDispatch, useSelector } from 'react-redux';
import { useSearchParams } from 'next/navigation';

import 'src/layouts/helium/style.css';

import Image from 'next/image';

import main_logo from '@public/assets/images/main_logo.svg';

export const SignupMarketingPage = () => {
  const dispatch = useDispatch();
  const searchParams = useSearchParams();
  const referral = searchParams.get('referral');
  const workspace = searchParams.get('workspace');
  const affiliaterefferalcode = searchParams.get('affiliatereferal');
  const affiliateemail = searchParams.get('email');

  const customPlan = searchParams.get('custom_plan');
  console.log('customPlan.....', customPlan);

  const { signUpForMarketingLoading, stepperData } = useSelector(
    (state: any) => state?.root?.authSignup
  );

  const initialValues = {
    email: stepperData?.email ?? '',
  };

  const onSubmit: SubmitHandler<SignupMarketingSchema> = (data: {
    email: string;
  }) => {
    const payload: any = {
      email: data?.email.toLowerCase(),
      ...(referral && { referral_code: referral }),
      ...(workspace && { workspace: workspace }),
      ...(affiliaterefferalcode && {
        affiliate_referral_code: affiliaterefferalcode,
      }),
      ...(affiliateemail && {
        affiliate_email: encodeURIComponent(affiliateemail),
      }),
      ...(customPlan && {
        custom_plan: customPlan,
      }),
    };

    if (payload.email != stepperData?.email) {
      dispatch(clearStepperData());
    }

    console.log("signup marketing payload.....", payload);

    dispatch(signUpForMarketing(payload)).then((result: any) => {
      if (signUpForMarketing.fulfilled.match(result)) {
        if (result.payload.status) {
          console.log(result?.payload?.data, 'result?.payload?.data');
          // Redirect to particular screen
          const user = result?.payload?.data;
          if (
            user?.first_name == undefined ||
            user.status == 'signup_incomplete'
          ) {
            // 2 screen
            dispatch(storeStepperData(payload));
            dispatch(goToStep(SignUpStepper.secondSignupPage));
          } else if (user?.contact_number == undefined) {
            // 3 screen
            dispatch(
              storeStepperData({
                email: user?.email,
                first_name: user?.first_name,
                last_name: user?.last_name,
              })
            );
            dispatch(goToStep(SignUpStepper.contactNumberPage));
          } else if (user?.profession_role == undefined) {
            // 4 screen
            dispatch(
              storeStepperData({
                email: user?.email,
                first_name: user?.first_name,
                last_name: user?.last_name,
                contact_number: user?.contact_number,
              })
            );
            dispatch(goToStep(SignUpStepper.professionPage));
          } else if (user?.no_of_people == undefined) {
            // 5 screen
            dispatch(
              storeStepperData({
                email: user?.email,
                first_name: user?.first_name,
                last_name: user?.last_name,
                contact_number: user?.contact_number,
                profession_role: user?.profession_role,
              })
            );
            dispatch(goToStep(SignUpStepper.noOfPeoplePage));
          } else {
            // 6 screen
            dispatch(
              storeStepperData({
                email: user?.email,
                first_name: user?.first_name,
                last_name: user?.last_name,
                contact_number: user?.contact_number,
                profession_role: user?.profession_role,
                no_of_people: user?.no_of_people,
              })
            );
            dispatch(goToStep(SignUpStepper.createWorkspacePage));
          }
        }
      }
    });
  };

  return (
    <>
      <div className="signup_bg_image_03 ">
        {/* right side button */}
        {/* right side button */}
        <div className="mb-4 mt-12 flex h-[50px] flex-col items-center justify-between px-12 lg:mb-0 lg:flex-row">
          {/* logo */}
          <div className="flex  items-center justify-start">
            <Image
              src={main_logo}
              alt={main_logo}
              // className="dark:invert"
              width={100}
              height={50}
            />
          </div>
          <div className="mt-6 flex flex-row items-center justify-end lg:mt-0">
            <Link href={routes.signIn}>Already a user</Link>
            <div className="ms-6">
              <Link
                href={routes.signUp}
                className="w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] px-6 py-4 text-[16px] font-semibold text-white"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>
        {/* block sign up */}
        <div className="grid h-5/6 overflow-auto p-4 lg:p-0">
          <div className="mx-auto flex w-auto items-center justify-center place-self-center rounded-lg border border-[#f7f7f7] bg-white p-8  shadow-xl lg:h-[535px] lg:w-[704px] ">
            <div className="w-full text-center">
              <p className="mx-auto mb-[6px] w-[100%] text-center text-[32px] font-bold leading-8 text-[#120425] lg:mb-[20px] lg:text-[45px] lg:leading-10">
                Sign Up for Syncupp
              </p>
              <span className="mb-9 text-[14px] font-bold tracking-wide text-[#120425] lg:text-[26px]">
                & Start Using in Seconds
              </span>
              {/* form */}
              <div className="mt-8 px-4 lg:px-24">
                <Form<SignupMarketingSchema>
                  validationSchema={signupMarketingSchema}
                  onSubmit={onSubmit}
                  useFormProps={{
                    mode: 'all',
                    defaultValues: initialValues,
                  }}
                >
                  {({ register, formState: { errors } }) => (
                    <>
                      <div className="placeholder_color grid grid-cols-1 gap-4">
                        <Input
                          onKeyDown={handleKeyDown}
                          type="email"
                          label=""
                          size="xl"
                          placeholder="Enter Your Email"
                          className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold
                          "
                          {...register('email')}
                          error={errors.email?.message}
                          prefix={
                            <MdOutlineEmail className="mt-[3px] h-[30px] w-[30px]" />
                          }
                        />
                      </div>
                      <div className="mt-6 w-full">
                        <Button
                          className="hover:border-1 mb-4 w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-white hover:border-[#8C80D2] hover:from-slate-50 hover:to-slate-50 hover:text-black"
                          type="submit"
                          disabled={signUpForMarketingLoading}
                        >
                          Next
                          {signUpForMarketingLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                      {/* <p className='w-full text-[12px] lg:text-[14px] font-semibold text-[#120425]'>
                          Get a 7 Day Free Trial. Cancel Anytime!
                      </p> */}
                    </>
                  )}
                </Form>
              </div>
              {/* extra code
            ===================
              <Link href={routes.signIn}>Already a User</Link>
          <Button>Login</Button>
        </div>
        <Form<SignupMarketingSchema>
          validationSchema={signupMarketingSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'all',
            defaultValues: initialValues,
          }}
        >
          {({ register, formState: { errors } }) => (
            <>
              <div>Sign Up for free</div>
              <div>and start using Syncupp in seconds!</div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:gap-5 xl:pb-2">
                <Input
                  onKeyDown={handleKeyDown}
                  type="email"
                  label=""
                  placeholder="Enter Your Email"
                  className="[&>label>span]:font-medium"
                  {...register('email')}
                  error={errors.email?.message}
                  prefix={<MdOutlineEmail />}
                />
              </div>
              <div className="w-full">
                <Button
                  className="float-end border-2 bg-[#53216F] text-base font-medium hover:bg-[#8e45b8] hover:enabled:bg-[#8e45b8] @xl:w-auto dark:text-white"
                  type="submit"
                  color="info"
                  rounded="pill"
                  disabled={signUpForMarketingLoading}
                >
                  Next
                  {signUpForMarketingLoading && (
                    <Spinner size="sm" tag="div" className="ms-3" color="white" />
                  )}
                </Button>
              </div>
            </>
          )}
        </Form>
            ==========================
            
            
            
            
            */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
