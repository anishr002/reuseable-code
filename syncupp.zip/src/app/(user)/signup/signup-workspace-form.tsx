'use client';

import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { SignUpStepper, routes } from '@/config/routes';
import socket from '@/io';
import {
  clearStepperData,
  goToStep,
  previousStep,
  signUpComplete,
  signUpForMarketing,
} from '@/redux/slices/user/auth/authSlice';
import { setDefaultWorkspace } from '@/redux/slices/user/workspace/workspaceSlice';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import {
  SignupWorkspaceSchema,
  signupWorkspaceSchema,
} from '@/utils/validators/signup.schema';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { SubmitHandler } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

import Image from 'next/image';

import Logo from '@public/assets/images/01_signup_logo.png';
import { GoChevronLeft, GoChevronRight } from "react-icons/go";
import { initiateRazorpay } from '@/services/paymentService';
import { useModal } from '@/app/shared/modal-views/use-modal';

export const SignupWorkspaceFormPage = () => {
  const [loader, setLoader] = useState(false)
  const router = useRouter();
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  const { stepperData } = useSelector((state: any) => state?.root?.authSignup);

  const initialValues = {
    workspace_name: stepperData?.workspace_name ?? ''
  }

  const onSubmit: SubmitHandler<SignupWorkspaceSchema> = (data: {
    workspace_name: string;
  }) => {
    const payload = {
      ...stepperData,
      workspace_name: data?.workspace_name.toLowerCase().trim(),
    };
    setLoader(true);
    console.log("stepperData in workspace form...", stepperData);
    dispatch(signUpComplete(payload)).then((result: any) => {
      if (signUpComplete.fulfilled.match(result)) {
        if (
          result.payload.success === true &&
          result?.payload?.data?.user?.status == 'signup_completed'
        ) {

          const { user, workspace, token } = result?.payload?.data;
          // scoket connection
          socket.disconnect();
          socket.connect();
          dispatch(setDefaultWorkspace(workspace?.workspace));
          dispatch(clearStepperData());
          router.replace(routes.dashboard(workspace?.workspace?.name));
          // dispatch(goToStep(SignUpStepper.marketingPage));
          if(user?.custom_subscription_plan) {
            initiateRazorpay(
              router,
              routes.dashboard(workspace?.workspace?.name),
              token,
              dispatch,
              user?.custom_subscription_plan,
              closeModal
            );
          }
        }
      }
      setLoader(false);
    });
  };

  return (
    <>
      <div className="signup_bg_image_02">
        <div className="grid  h-full content-center w-full">
          <div className="  p-4 lg:p-0  lg:mx-auto overflow-auto lg:overflow-hidden">
            <div className="mx-auto w-auto lg:w-[980px] place-self-center rounded-lg bg-white shadow-lg  ">
              {/* logo */}
              <div className="grid grid-cols-1 place-content-between gap-8 p-8 lg:grid-cols-2 ">
                <div className="mx-auto text-center lg:w-full lg:place-self-start">
                  <Image
                    src={Logo} // Local imagek
                    alt="SyncUp logo"
                    width={108} // Width in pixels
                    height={48} // Height in pixels
                  />
                </div>
                <div className=" w-full place-self-center">
                  <p className="text-center text-[20px] font-bold lg:text-right">
                    Welcome, {capitalizeFirstLetter(stepperData?.first_name)} {capitalizeFirstLetter(stepperData?.last_name)}
                  </p>
                </div>
              </div>
              <div className="text-center mt-6 lg:mt-10 ">
                <p className="w-[70%] mx-auto text-center text-[28px] lg:text-[40px] font-bold text-[#120425] leading-8 lg:leading-10">Lastly,</p>
                <p className="w-[70%] mx-auto text-center text-[28px] lg:text-[40px] font-bold text-[#120425] leading-8 lg:leading-10">
                  what would you like to
                </p>
                <p className="mb-8 w-[70%] mx-auto text-center text-[28px] lg:text-[40px] font-bold text-[#120425] leading-8 lg:leading-10">
                  name your Workspace?
                </p>

                {/* form */}
                <div className="mt-10 lg:mt-16">
                  <Form<SignupWorkspaceSchema>
                    validationSchema={signupWorkspaceSchema}
                    onSubmit={onSubmit}
                    useFormProps={{
                      mode: 'all',
                      defaultValues: initialValues,
                    }}
                  >
                    {({ register, formState: { errors } }) => (
                      <>
                        <div className='grid grid-cols-1 gap-2 lg:gap-4 w-full lg:w-[35%] lg:mx-auto p-2 lg:p-0  lg:mb-4 placeholder_color'>
                          <Input
                            onKeyDown={handleKeyDown}
                            type="text"
                            size='lg'
                            label=""
                            placeholder="Enter your Workspace Name"
                            className="[&>label>span]:font-semibold [&>label>span]:text-left &>label>span]:text-[16px] border-[#9BA1B9] placeholder:text-[16px] placeholder:font-semibold  flex justify-center text-[16px] font-semibold  w-full
                          "
                            {...register('workspace_name')}
                            error={errors.workspace_name?.message}
                            autoComplete='off'
                          />
                          {/* button workspace create */}
                          {/* <div>
                            <Button
                              className="bg-white lg:w-[60%] rounded-[9px] border-[#9BA1B9] border-2 text-[#000000] text-[16px] font-semibold px-[20px] py-[24px] hover:bg-[#8C80D2] hover:text-[white] hover:border-[#8C80D2] me-4 w-full"
                              type="submit"
                              size='xl'
                              disabled={loader}
                            >
                              Create Workspace
                              {loader && <Spinner
                                size="sm"
                                tag="div"
                                className="ms-3"
                                color="white"
                              />
                              }
                            </Button>
                          </div> */}
                          <p className='text-[#9BA1B9] text-[14px] font-semibold lg:mt-7'>
                            Try the name of your company or organization.
                          </p>
                        </div>
                        {/* progress bar */}
                        <div className="flex items-center justify-center ">
                          <div className="w-full">
                            <div className="h-[5px] bg-[#DFE1EC]  overflow-hidden">
                              <div className="h-full bg-[#8C80D2] " style={{ width: '70%' }}></div>
                            </div>
                          </div>
                        </div>

                        {/* back and next button */}
                        {/* <div className=" w-full flex justify-center lg:justify-between pt-2 pb-4 px-2 lg:p-8 my-4 lg:my-0">
                          <Button
                            className="w-full lg:w-[200px] rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] flex items-center justify-center hover:bg-white hover:border-2 hover:border-[#8C80D2] "
                            type="button"
                            size='xl'
                            onClick={() => {
                              dispatch(previousStep());
                            }}
                          >
                            <GoChevronLeft className="w-[30px] h-[30px] " />
                            Back
                          </Button>

                        </div> */}
                        <div className=" w-full flex justify-between p-8">
                          <Button
                            className="mr-2 lg:mr-0 w-[200px] rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] flex items-center justify-center hover:bg-white hover:border-2 hover:border-[#8C80D2] "
                            type="button"

                            size='xl'
                            onClick={() => {
                              dispatch(previousStep());
                            }}
                          >
                            <GoChevronLeft className="w-[30px] h-[30px] " />
                            <span className=''> Back</span>
                            {/* <Spinner size="sm" tag="div" className="ms-3" color="white" /> */}
                          </Button>
                          <Button
                            className="w-[200px] lg:w-[300px] rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] flex items-center justify-center hover:bg-white hover:border-2 hover:border-[#8C80D2] hover:text-[#8C80D2]"
                            type="submit"
                            size='xl'
                            disabled={loader}
                          //disabled={phoneNumberIsExistLoading}
                          >

                            <span> Create Workspace</span>
                            <GoChevronRight className="w-[30px] h-[30px] " />
                            {loader && (
                              <Spinner
                                size="sm"
                                tag="div"
                                className="ms-3"
                                color="white"
                              />
                            )}
                          </Button>
                        </div>
                      </>
                    )}
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
