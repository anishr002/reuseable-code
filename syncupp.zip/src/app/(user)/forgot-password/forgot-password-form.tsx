'use client';

import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { Text } from '@/components/ui/text';
import { routes } from '@/config/routes';
import { forgotPasswordUser } from '@/redux/slices/user/auth/forgotPasswordSlice';
import { handleKeyDown } from '@/utils/common-functions';
import {
  forgetPasswordSchema,
  ForgetPasswordSchema,
} from '@/utils/validators/forget-password.schema';
import main_logo from '@public/assets/images/main_logo.svg';
import Image from 'next/image';
import Link from 'next/link';
import { SubmitHandler } from 'react-hook-form';
import { GoMail } from 'react-icons/go';
import { useDispatch, useSelector } from 'react-redux';
import useMedia from 'react-use/lib/useMedia';
import 'src/layouts/helium/style.css';

const initialValues = {
  email: '',
};

export default function ForgetPasswordForm() {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const dispatch = useDispatch();
  const forgotPassword = useSelector(
    (state: any) => state?.root?.forgotPassword
  );

  const onSubmit: SubmitHandler<ForgetPasswordSchema> = (data) => {
    dispatch(forgotPasswordUser(data));
  };

  return (
    <>
      <div className="signup_bg_image_03 ">
        <div className="mb-4 mt-12 flex h-[50px] flex-col items-center justify-between px-12 lg:mb-0 lg:flex-row">
          {/* logo */}
          <div className="flex  items-center justify-start">
            <Image
              src={main_logo}
              alt={main_logo}
              // className="dark:invert"
              width={100}
              height={50}
            />
          </div>
        </div>
        <div className="mt-14 grid h-auto overflow-auto p-8 px-4 lg:mt-0 lg:h-5/6 lg:p-0">
          <div className="mx-auto w-auto place-self-center rounded-lg border border-[#f7f7f7]  bg-white p-8 shadow-lg lg:w-[720px]">
            <div className="text-center">
              <h1 className="mx-auto mb-8 w-[70%] text-center text-[28px] font-semibold leading-8 text-[#120425] lg:mt-8 lg:text-[40px] lg:leading-10">
                Forgot your Password
              </h1>
              {/* <span className="mb-9 text-[24px] font-bold tracking-wide text-[#120425]">
                and start using Syncupp in seconds!
              </span> */}
              {/* form */}
              <div className="mt-12">
                <Form<ForgetPasswordSchema>
                  validationSchema={forgetPasswordSchema}
                  // resetValues={reset}
                  onSubmit={onSubmit}
                  useFormProps={{
                    mode: 'all',
                    defaultValues: initialValues,
                  }}
                >
                  {({ register, formState: { errors } }) => (
                    <div className="placeholder_color grid grid-cols-1 gap-4">
                      <Input
                        onKeyDown={handleKeyDown}
                        type="email"
                        label="Email"
                        placeholder="Enter your email"
                        size="xl"
                        className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold"
                        {...register('email')}
                        error={errors.email?.message as string}
                        prefix={
                          <GoMail className="mt-[3px] h-[30px] w-[30px]" />
                        }
                      />
                      <Button
                        className="hover:border-1 mb-4 w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-white hover:border-[#8C80D2] hover:from-slate-50 hover:to-slate-50 hover:text-black"
                        type="submit"
                        size={isMedium ? 'lg' : 'xl'}
                        disabled={forgotPassword?.loading}
                      >
                        Submit
                        {forgotPassword && forgotPassword?.loading && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                    </div>
                  )}
                </Form>
                <Text className="mt-5 text-center text-[15px] leading-loose text-gray-500 lg:text-start xl:mt-7 xl:text-base">
                  Don’t want to reset?{' '}
                  <Link
                    href={routes.signIn}
                    className="font-semibold text-gray-700 transition-colors hover:text-[#8e45b8]"
                  >
                    Sign In
                  </Link>
                </Text>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
