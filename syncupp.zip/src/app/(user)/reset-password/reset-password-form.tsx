'use client';

import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Password } from '@/components/ui/password';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { resetPasswordUser } from '@/redux/slices/user/auth/resetPasswordSlice';
import { handleKeyDown } from '@/utils/common-functions';
import {
  resetPasswordSchema,
  ResetPasswordSchema,
} from '@/utils/validators/reset-password.schema';
import Image from 'next/image';
import { useRouter, useSearchParams } from 'next/navigation';
import { SubmitHandler } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import useMedia from 'react-use/lib/useMedia';
import 'src/layouts/helium/style.css';
import main_logo from '@public/assets/images/main_logo.svg';

const initialValues: ResetPasswordSchema = {
  password: '',
  confirmPassword: '',
};

export default function ResetPasswordForm() {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const dispatch = useDispatch();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const email = searchParams.get('email');
  const router = useRouter();
  const resetPassword = useSelector((state: any) => state?.root?.resetPassword);

  const onSubmit: SubmitHandler<ResetPasswordSchema> = (data) => {
    dispatch(resetPasswordUser({ ...data, token, email })).then(
      (result: any) => {
        if (resetPasswordUser.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            router.replace(routes.signIn);
          }
        }
      }
    );
    // setReset({ ...initialValues });
  };

  return (
    <>
      <div className="signup_bg_image_03 ">
        <div className="mb-4 mt-12 flex h-[50px] flex-col items-center justify-between px-12 lg:mb-0 lg:flex-row">
          {/* logo */}
          <div className="flex  items-center justify-start">
            <Image
              src={main_logo}
              alt={main_logo}
              // className="dark:invert"
              width={100}
              height={50}
            />
          </div>
        </div>
        <div className="grid h-auto lg:h-5/6 p-8 px-4 lg:p-0 overflow-auto mt-14 lg:mt-0">
        <div className="mx-auto w-auto lg:w-[720px] place-self-center rounded-lg bg-white  p-8 shadow-lg border border-[#f7f7f7]">
          <div className="text-center">
          <h1 className="mb-8 w-[70%] mx-auto text-center text-[28px] lg:text-[40px] font-semibold text-[#120425] leading-8 lg:leading-10 lg:mt-8">
              Reset Password
            </h1>
            <div className="mt-12">
              <Form<ResetPasswordSchema>
                validationSchema={resetPasswordSchema}
                onSubmit={onSubmit}
                // resetValues={reset}
                useFormProps={{
                  mode: 'all',
                  defaultValues: initialValues,
                }}
              >
                {({ register, formState: { errors } }) => (
                  <div className="space-y-5 placeholder_color">
                    <Password
                      onKeyDown={handleKeyDown}
                      label="New Password"
                      placeholder="Enter your password"
                      size={isMedium ? 'lg' : 'xl'}
                      className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold"
                      {...register('password')}
                      error={errors.password?.message}
                      visibilityToggleIcon={(visible: any) =>
                        visible ? (
                          <span className="h-auto w-5 text-[#7763E8] font-semibold" >Hide</span>
                        ) : (
                          <span className="h-auto w-5 text-[#7763E8] font-semibold" >Show</span>
                        )
                      }
                    />
                    <Password
                      onKeyDown={handleKeyDown}
                      label="Confirm New Password"
                      placeholder="Enter your password"
                      size={isMedium ? 'lg' : 'xl'}
                      className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold"
                      {...register('confirmPassword')}
                      error={errors.confirmPassword?.message}
                      visibilityToggleIcon={(visible: any) =>
                        visible ? (
                          <span className="h-auto w-5 text-[#7763E8] font-semibold" >Hide</span>
                        ) : (
                          <span className="h-auto w-5 text-[#7763E8] font-semibold" >Show</span>
                        )
                      }
                    />
                    <Button
                      className="hover:border-1 mb-4 w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-white hover:border-[#8C80D2] hover:from-slate-50 hover:to-slate-50 hover:text-black"
                      type="submit"
                      size={isMedium ? 'lg' : 'xl'}
                      disabled={resetPassword?.loading}
                    >
                      Reset Password
                      {resetPassword?.loading && (
                        <Spinner
                          size="sm"
                          tag="div"
                          className="ms-3"
                          color="white"
                        />
                      )}
                    </Button>
                  </div>
                )}
              </Form>
            </div>
          </div>
        </div>
        </div>
      </div>
    </>
  );
}
