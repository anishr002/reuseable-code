import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { useMedia } from '@/hooks/use-media';
import { workspaceInvitation } from '@/redux/slices/user/auth/authSlice';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { metaObject } from '@/config/site.config';
import 'src/layouts/helium/style.css';

export const metadata = {
  ...metaObject('Workspace Invitation'),
};

export const WorkspaceAccept = () => {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const searchParams = useSearchParams();
  const email = searchParams.get('email');
  const token = searchParams.get('token');
  const workspace = searchParams.get('workspace');
  const workspace_name = searchParams.get('workspace_name');
  const dispatch = useDispatch();
  const router = useRouter();
  const [invitation, setInvitation] = useState('');

  const { workspaceInvitationLoading } = useSelector(
    (state: any) => state?.root?.authSignup
  );

  const submitInvitation = (data: boolean) => {
    const payload = {
      email,
      token,
      workspace,
      accept: data,
    };

    setInvitation(data ? 'accept' : 'reject');

    dispatch(workspaceInvitation(payload)).then((result: any) => {
      if (workspaceInvitation.fulfilled.match(result)) {
        const resposne = result.payload;
        if (resposne?.success == true) {
          router.push(routes.signIn);
        }
      }
    });
  };

  return (
    <>
      <div className="signup_bg_image ">
        <div className="grid h-full">
          <div className="mx-auto w-[750px] place-self-center rounded-lg bg-white p-20 shadow-xl ">
            <div className="text-center">
              <h1 className="mb-8 text-[54px] font-semibold text-[#120425]">
                Workspace invitation
              </h1>
              <span className="mb-9 text-[24px] font-bold tracking-wide text-[#120425]">
                You are invited to the {workspace_name} workspace.
              </span>
              <div className="mt-12">
              <Button
                className="hover:border-1 mb-4 w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-white hover:border-[#8C80D2] hover:from-slate-50 hover:to-slate-50 hover:text-black"
                type="submit"
                size={isMedium ? 'lg' : 'xl'}
                color="info"
                onClick={() => submitInvitation(true)}
                disabled={workspaceInvitationLoading}
              >
                Accept
                {workspaceInvitationLoading && invitation == 'accept' && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
              <Button
                className="bg-whtie mb-4 w-full rounded-lg  border-2 border-[#8C80D2] from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-black  hover:bg-gradient-to-r hover:text-white"
                type="submit"
                size={isMedium ? 'lg' : 'xl'}
                color="info"
                onClick={() => submitInvitation(false)}
                disabled={workspaceInvitationLoading}
              >
                Reject
                {workspaceInvitationLoading && invitation == 'reject' && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  );
};
