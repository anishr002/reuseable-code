'use client';

import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Password } from '@/components/ui/password';
import Spinner from '@/components/ui/spinner';
import { useMedia } from '@/hooks/use-media';
import { setPassword } from '@/redux/slices/user/auth/authSlice';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import {
  SetPasswordSchema,
  setPasswordSchema,
} from '@/utils/validators/set-password-schema';
import { useSearchParams } from 'next/navigation';
import { SubmitHandler } from 'react-hook-form';
import { GoLock, GoMail } from 'react-icons/go';
import { useDispatch, useSelector } from 'react-redux';
import 'src/layouts/helium/style.css';

import { metaObject } from '@/config/site.config';
import main_logo from '@public/assets/images/main_logo.svg';
import Image from 'next/image';

export const metadata = {
  ...metaObject('Set Password'),
};

export default function SetPasswordForm(props: any) {
  const { setRedirect } = props;

  const isMedium = useMedia('(max-width: 1200px)', false);
  const dispatch = useDispatch();
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const { setPasswordLoading } = useSelector(
    (state: any) => state?.root?.authSignup
  );
  const searchParams = useSearchParams();
  const email = searchParams.get('email');
  const token = searchParams.get('token');
  const workspace = searchParams.get('workspace');
  const first_name = searchParams.get('first_name');
  const last_name = searchParams.get('last_name');
  const workspace_name = searchParams.get('workspace_name');

  const initialValues = {
    // firstName: '',
    // lastName: '',
    email: email ?? '',
    password: '',
    confirmPassword: '',
  };

  const onSubmit: SubmitHandler<SetPasswordSchema> = (data) => {
    const apiData = {
      email: email,
      token: token,
      password: data?.password,
      workspace: workspace,
      first_name,
      last_name,
    };

    dispatch(setPassword(apiData)).then((result: any) => {
      if (setPassword.fulfilled.match(result)) {
        if (result && result.payload.success === true) {          
          // Show workspace invitation page
          setRedirect(true);
          // router.replace(routes.signIn);
        }
      }
    });
  };

  return (
    <>
      <div className="signup_bg_image_03 ">
        <div className="mb-4 mt-12 flex h-[50px] flex-col items-center justify-between px-12 lg:mb-0 lg:flex-row">
          {/* logo */}
          <div className="flex  items-center justify-start">
            <Image
              src={main_logo}
              alt={main_logo}
              // className="dark:invert"
              width={100}
              height={50}
            />
          </div>
        </div>

        <div className="mt-14 grid h-5/6 overflow-auto p-4 lg:mt-0 lg:p-0">
          <div className="mx-auto w-auto lg:w-[720px] place-self-center rounded-lg bg-white  p-8  border border-[#f7f7f7] shadow-xl ">
            <div className="text-center">
              <h1 className="mx-auto mb-0 w-[70%] text-center text-[16px] font-bold leading-8 text-[#8C80D2] lg:mt-8 lg:text-[20px] lg:leading-10">
                {capitalizeFirstLetter(workspace_name as string)} invited you to
                their Syncupp.
              </h1>
              <span className="mx-auto mb-0 w-[70%] text-center text-[28px] font-semibold leading-8 text-[#120425] lg:mt-8 lg:text-[38px] lg:leading-10">
                Setup your password to join{' '}
                {capitalizeFirstLetter(workspace_name as string)} on Syncupp.
              </span>

              <div className="mt-6 lg:px-28">
                <Form<SetPasswordSchema>
                  validationSchema={setPasswordSchema}
                  onSubmit={onSubmit}
                  useFormProps={{
                    mode: 'all',
                    defaultValues: initialValues,
                  }}
                >
                  {({ register, formState: { errors } }) => (
                    <>
                      <div className="placeholder_color grid grid-cols-1 gap-4">
                        <Input
                          onKeyDown={handleKeyDown}
                          type="email"
                          size={isMedium ? 'lg' : 'xl'}
                          label="Email ID"
                          placeholder="Enter your email"
                          color="info"
                          className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold
                        "
                          {...register('email')}
                          disabled
                          prefix={
                            <GoMail className="mt-[3px] h-[30px] w-[30px]" />
                          }
                          error={errors.email?.message}
                        />
                        <Password
                          onKeyDown={handleKeyDown}
                          label="Password"
                          placeholder="Enter your password"
                          size={isMedium ? 'lg' : 'xl'}
                          color="info"
                          className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold
                        "
                          {...register('password')}
                          prefix={
                            <GoLock className="mt-[3px] h-[30px] w-[30px]" />
                          }
                          visibilityToggleIcon={(visible: any) =>
                            visible ? (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Hide</span>
                            ) : (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Show</span>
                            )
                          }
                          error={errors.password?.message}
                        />
                        <Password
                          onKeyDown={handleKeyDown}
                          label="Confirm Password"
                          placeholder="Enter your password"
                          size={isMedium ? 'lg' : 'xl'}
                          color="info"
                          className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left  [&>label>span]:font-semibold
                        "
                          {...register('confirmPassword')}
                          prefix={
                            <GoLock className="mt-[3px] h-[30px] w-[30px]" />
                          }
                          visibilityToggleIcon={(visible: any) =>
                            visible ? (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Hide</span>
                            ) : (
                              <span className="h-auto w-5 text-[#7763E8] font-semibold" >Show</span>
                            )
                          }
                          error={errors.confirmPassword?.message}
                        />
                      </div>
                      <div className="mt-6 w-full">
                        <Button
                          className="hover:border-1 mb-4 w-full rounded-lg bg-gradient-to-r from-[#8C80D2] to-[#705AEE] py-7 text-[16px] font-semibold text-white hover:border-[#8C80D2] hover:from-slate-50 hover:to-slate-50 hover:text-black"
                          type="submit"
                          size={isMedium ? 'lg' : 'xl'}
                          color="info"
                          disabled={teamMemberData?.loading}
                        >
                          Create Password
                          {setPasswordLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </>
                  )}
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
