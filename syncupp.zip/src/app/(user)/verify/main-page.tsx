'use client';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { emailCheck, workspaceInvitation } from '@/redux/slices/user/auth/authSlice';
import WithAuthPublic from '@/utils/public-route-user';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { toast } from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux';
import SetPasswordForm from './set-password-form';
import { setDefaultWorkspace } from '@/redux/slices/user/workspace/workspaceSlice';
import { setRoleonSingup, setSignupuserData, setTeamMemberRole, setUserPermission } from '@/redux/slices/user/auth/signinSlice';

function MainPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const searchParams = useSearchParams();
  const email = searchParams.get('email');
  const token = searchParams.get('token');
  const workspace = searchParams.get('workspace');

  const [redirect, setRedirect] = useState(false);
  const {emailCheckLoading} = useSelector((state: any) => state?.root?.authSignup);
  // useEffect(() => {

  // dispatch(postClientRedirect({ email: email })).then((result: any) => {
  //   if (postClientRedirect.fulfilled.match(result)) {
  //     if (result && result?.payload?.success === true) {
  //       // console.log(result?.payload?.data?.password_required)
  //       setRedirect(result?.payload?.data?.password_required)
  //       if (!result?.payload?.data?.password_required) {
  //         dispatch(verifyTeamMember({ email: email, redirect: true,  workspace: workspace, token: token })).then((result: any) => {
  //           if (verifyTeamMember.fulfilled.match(result)) {
  //             if (result && result.payload.success === true) {
  //               router.replace(routes.signIn);
  //             } else if(result && result.payload.code === 422){
  //               router.replace(routes.signIn);
  //             }
  //           }
  //         })
  //       }
  //     }
  //   }
  // })
  // }, [dispatch, email, agencyId, router, token, clientId])

  const acceptWorkspaceInvitaion = (payload: any) => {
    dispatch(workspaceInvitation(payload)).then((result: any) => {
      if (workspaceInvitation.fulfilled.match(result)) {
        const response = result.payload;
        if (response?.success == true) {
          // router.push(routes.signIn)
          const {token, user, workspace} = response?.data;

          localStorage.setItem('token', token);
          dispatch(setDefaultWorkspace(workspace?.workspace));
          dispatch(setRoleonSingup(workspace?.role));
          dispatch(setSignupuserData(response));
          if(workspace?.sub_role){
            dispatch(setUserPermission(workspace?.sub_role?.permissions));
            dispatch(setTeamMemberRole(workspace?.sub_role?.sub_role));
          };

          router.push(routes.dashboard(workspace?.workspace?.name))
        } else {
          // IF verify API Throw error
          router.push(routes.signIn);
        }
      } else {
        router.push(routes.signIn);
      }
    });
  }

  useEffect(() => {
    const payload = {
      email,
      token,
      workspace,
      accept: true,
    };
    if(redirect) {  
      acceptWorkspaceInvitaion(payload)
    }
  }, [redirect])

  useEffect(() => {
    dispatch(emailCheck({ email })).then((result: any) => {
      if (emailCheck.fulfilled.match(result)) {
        if (result?.payload?.success == true) {
          const { is_facebook_signup, is_google_signup, status, password_set } =
            result?.payload?.data;
          if (is_facebook_signup || is_google_signup) {
            // Go To Workspace accept page

            setRedirect(true);
            // const payload = {
            //   email,
            //   token,
            //   workspace,
            //   accept: true,
            // };
            // acceptWorkspaceInvitaion(payload)
          } else {
            if (status == 'signup_incomplete' && !password_set) {
              // Go to Set Password page
              setRedirect(false)
            } else {
              // Go To Workspace accept page
              setRedirect(true);
              // const payload = {
              //   email,
              //   token,
              //   workspace,
              //   accept: true,
              // };
              // acceptWorkspaceInvitaion(payload)
            }
          }
        }
      }
    });
  }, [email]);

  // useEffect(() => { redirect &&
  //     dispatch(verifyTeamMember({email: email, agency_id: agencyId, redirect: redirect, token: token })).then((result: any) => {
  //       if (verifyTeamMember.fulfilled.match(result)) {
  //         if (result && result.payload.success === true ) {
  //           router.replace(routes.signIn);
  //         }
  //       }
  //     })
  //   }, [dispatch, router, agencyId, email, token, redirect]);


  return (
    <>
      {(redirect || emailCheckLoading) ? (
        <div className="col-span-full mt-3 flex items-center justify-center">
          <Spinner size="xl" />
        </div>
      ) : (
        <SetPasswordForm setRedirect={setRedirect} />
      )}

      {/* { redirect ? (
            <AuthWrapperTwo title="Set your password" isSocialLoginActive={false}>
                <SetPasswordForm redirect={!redirect} />
            </AuthWrapperTwo> ) : (
                <div className='flex justify-center items-center col-span-full mt-3'><Spinner size='xl' /></div>
            )
        } */}
    </>
  );
}

export default WithAuthPublic(MainPage);
