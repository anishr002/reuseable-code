'use client';
import AuthWrapperTwo from '@/app/shared/(admin)/auth-layout/auth-wrapper-two';
import SignInForm from './sign-in-form';
import WithAuthPublic from '@/utils/public-route-admin';
import { logoutUserAdmin } from '@/redux/slices/admin/auth/signin/signinSlice';
import { useDispatch } from 'react-redux';
import { useSearchParams } from 'next/navigation';
import { useEffect } from 'react';

function SignIn() {

  const dispatch = useDispatch()
  const searchParams = useSearchParams();
  const logout = searchParams.get("logout");

  console.log(logout, 'logoutAdmin')

  useEffect(() => {
    if (logout) {
      dispatch(logoutUserAdmin({}));
    }
  }, [])
  
  return (
    <AuthWrapperTwo title="Sign In" isSignIn isSocialLoginActive={false}>
      <SignInForm />
    </AuthWrapperTwo>
  );
}

export default WithAuthPublic(SignIn);
