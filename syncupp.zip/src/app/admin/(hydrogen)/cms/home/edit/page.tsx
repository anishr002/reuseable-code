import { metaObject } from '@/config/site.config';
import Homepageform from './homepageform';

export const metadata = {
  ...metaObject('Home'),
};

export default function Page() {
  return (
    <>
      <Homepageform />
    </>
  );
}
