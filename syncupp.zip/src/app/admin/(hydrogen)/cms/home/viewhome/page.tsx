import { metaObject } from '@/config/site.config';
import Viewhome from './Viewhome';

export const metadata = {
  ...metaObject('ViewHome'),
};

export default function Page() {
  return (
    <>
      <Viewhome />
    </>
  );
}
