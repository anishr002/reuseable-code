import { metaObject } from '@/config/site.config';
import ViewFeatures from './ViewFeatures';

export const metadata = {
  ...metaObject('Features'),
};

export default function Page() {
  return (
    <>
      <ViewFeatures />
    </>
  );
}
