import { metaObject } from '@/config/site.config';
import Featureform from './Featureform';

export const metadata = {
  ...metaObject('Features'),
};

export default function Page() {
  return (
    <>
      <Featureform/>
    </>
  );
}
