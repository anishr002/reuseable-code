import { metaObject } from '@/config/site.config';
import Viewtems from './Viewtems';

export const metadata = {
  ...metaObject('T & C'),
};

export default function Page() {
  return (
    <>
      <Viewtems />
    </>
  );
}
