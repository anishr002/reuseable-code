'use client';
import PageHeader from '@/app/shared/page-header';
import {
  GetConatcus,
  GetPrivacy,
  Getshipping,
  cleardata,
} from '@/redux/slices/admin/cms/cmsSlice';
import React, { useEffect } from 'react';
import Spinner from '@/components/ui/spinner';
import { useDispatch, useSelector } from 'react-redux';
import { routes } from '@/config/routes';
import { Button } from 'rizzui';
import Link from 'next/link';

function ViewShipping() {
  const dispatch = useDispatch();
  const termAndCondition = useSelector((state: any) => state?.root?.adminCms);
  useEffect(() => {
    dispatch(Getshipping());
    return () => {
      dispatch(cleardata());
    };
  }, []);

  const htmlDecode = (input: any) => {
    if (!!input) {
      var doc = new DOMParser().parseFromString(input, 'text/html');
      return doc.documentElement.textContent;
    }
    return '';
  };

  if (Object.entries(termAndCondition?.conatcUSdata).length === 0) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <>
        <PageHeader title="Shipping and Delivery" />
        <div
          dangerouslySetInnerHTML={{
            __html: String(
              htmlDecode(
                termAndCondition?.conatcUSdata?.data?.description ?? ''
              )
            ),
          }}
        />
        <Link href={routes.admin.cms}>
          <Button
            variant="outline"
            className="@xl:w-auto dark:hover:border-gray-400"
          >
            Cancel
          </Button>
        </Link>
      </>
    );
  }
}

export default ViewShipping;
