import { metaObject } from '@/config/site.config';
import ViewShipping from './ViewShipping';

export const metadata = {
  ...metaObject('Shipping and Delivery'),
};

export default function Page() {
  return (
    <>
      <ViewShipping />
    </>
  );
}
