'use client';
// import Link from 'next/link';
import PageHeader from '@/app/shared/page-header';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import { useModal } from '@/app/shared/modal-views/use-modal';
import CustomTable from '@/components/common-tables/table';
import { getAllSupportTicket } from '@/redux/slices/support-ticket/support-ticket-slice';
import { GetSupportTicketsColumns } from '@/app/shared/support-ticket/support-tickets-list/columns';

const pageHeader = {
  title: 'Support Tickets',
};

function SupportTicketsTable() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();
  const { loading, data } = useSelector((state: any) => state?.root?.support);

  const [pageSize, setPageSize] = useState<number>(10);


  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    const response = await dispatch(
      getAllSupportTicket({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllSupportTicket({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
        })
      );
      return data?.tickets;
    }
    if (data && data?.tickets && data?.tickets?.length !== 0) {
      return data?.tickets;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    // try {
    //   const res = await dispatch(
    //     deleteClient({ client_ids: id, force_fully_remove: false })
    //   );
    //   if (res.payload.success === true) {
    //     closeModal();

    //     const reponse = await dispatch(
    //       getAllClient({
    //         page: currentPage,
    //         items_per_page: countPerPage,
    //         sort_field: sortConfig?.key,
    //         sort_order: sortConfig?.direction,
    //         search: searchTerm,
    //         pagination: true,
    //       })
    //     );
    //   }
    // } catch (error) {
    //   console.error(error);
    // }
  };

  return (
    <>
      <PageHeader title={pageHeader.title}>
      </PageHeader>
      <CustomTable
        data={data?.tickets}
        total={data?.page_count}
        loading={loading}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={GetSupportTicketsColumns}
        scroll={{ x: 900 }}
      />
    </>
  );
}

export default SupportTicketsTable; 