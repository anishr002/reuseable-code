import { metaObject } from '@/config/site.config';
import SupportTicketsTable from './support-tickets-table';

export const metadata = {
    ...metaObject('Support Tickets'),
};

export default function ViewProfile() {
    return (
        <>
            <SupportTicketsTable />
        </>
    );
}
