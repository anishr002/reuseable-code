'use client';
import PageHeader from '@/app/shared/page-header';
import {  useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { GetColumns } from '@/app/shared/(admin)/history-log/columns';
import CustomTable from '@/components/common-tables/table';
import { getHistoryLogList } from '@/redux/slices/admin/history-log/historyLogSlice';

const pageHeader = {
  title: 'History Log',
};

export default function HistoryLogPage() {
  const dispatch = useDispatch();
  const { getHistoryLogListData, getHistoryLogListLoader } = useSelector(
    (state: any) => state?.root?.historyLog
  );

  const [pageSize, setPageSize] = useState<number>(10);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    await dispatch(
      getHistoryLogList({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
      })
    );
  };

  return (
    <>
      <PageHeader title={pageHeader.title} className="poppins_font_number">
      </PageHeader>
      <CustomTable
        data={getHistoryLogListData?.historyLog || []}
        total={getHistoryLogListData?.page_count}
        loading={getHistoryLogListLoader}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleChangePage={handleChangePage}
        getColumns={GetColumns}
      />
    </>
  );
}
