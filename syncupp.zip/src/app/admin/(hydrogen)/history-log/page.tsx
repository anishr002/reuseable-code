
import { metaObject } from '@/config/site.config';
import HistoryLogPage from './main-page';

export const metadata = {
    ...metaObject('History Log'),
};

export default function HistoryLog() {
    return (
        <>
            <HistoryLogPage />
        </>
    );
}
