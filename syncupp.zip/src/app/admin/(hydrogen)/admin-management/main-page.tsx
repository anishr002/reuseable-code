'use client';
// import Link from 'next/link';
import PageHeader from '@/app/shared/page-header';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
// import toast from 'react-hot-toast';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { GetColumns } from '@/app/shared/(admin)/admin-management/columns';
import CustomTable from '@/components/common-tables/table';
import { PiPlusBold } from 'react-icons/pi';
import Link from 'next/link';
import { routes } from '@/config/routes';
import { Button } from 'rizzui';
import { deleteAdmin, getAdminsList } from '@/redux/slices/admin/admin-management/adminSlice';
import { checkPermission } from '@/app/shared/(admin)/roles-permissions/utils';

const pageHeader = {
  title: 'Admin Management',
};

export default function AdminListingPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal } = useModal();
  const { getAdminsListData, getAdminsListLoader } = useSelector(
    (state: any) => state?.root?.adminUser
  );
  const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
  const roleData = userData?.data?.user?.role;


  const [pageSize, setPageSize] = useState<number>(10);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    await dispatch(
      getAdminsList({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
      })
    );
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
        const res = await dispatch(deleteAdmin(id));
        if (res.payload.success === true) {
          closeModal();
          await dispatch(
            getAdminsList({
              page: currentPage,
              items_per_page: countPerPage,
              sort_field: sortConfig?.key,
              sort_order: sortConfig?.direction,
              search: searchTerm,
            })
          );
        }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <PageHeader title={pageHeader.title} className="poppins_font_number">
      {(roleData?.sub_role === 'super_admin' ? true :
          checkPermission(
            'admin_management',
            'create',
            roleData?.permissions
          )) && (<div className="mt-4 flex items-center gap-3 @lg:mt-0">
          <Link href={routes.admin.adminManagementCreate}>
            <Button className="hover:gray-700 ms-3 @xl:w-auto dark:bg-gray-200 dark:text-white">
              <PiPlusBold className="me-1.5 h-[17px] w-[17px]" />
              Add
            </Button>
          </Link>
        </div>)}
      </PageHeader>
      <CustomTable
        data={getAdminsListData?.admin || []}
        total={getAdminsListData?.page_count}
        loading={getAdminsListLoader}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={GetColumns}
      />
    </>
  );
}
