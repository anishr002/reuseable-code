'use client';
import CreateAdmin from '@/app/shared/(admin)/admin-management/create-admin';
import PageHeader from '@/app/shared/page-header';


const pageHeader = {
  title: 'Create Admin',
};

const MainPage = () => {

  return (
    <>
      <PageHeader title={pageHeader.title}></PageHeader>
      <CreateAdmin />
    </>
  );
};

export default MainPage;
