import { metaObject } from '@/config/site.config';
import AdminListingPage from './main-page';

export const metadata = {
    ...metaObject('Admin Management'),
};

export default function Page() {
    return (
        <>
            <AdminListingPage />
        </>
    );
}
