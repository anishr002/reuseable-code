'use client';

import { ReferralStatisticsColumns } from '@/app/shared/(admin)/referral-statistics/columns';
import { useModal } from '@/app/shared/modal-views/use-modal';
import PageHeader from '@/app/shared/page-header';
import CustomTable from '@/components/common-tables/table';
import {
  clearReferralUsersData,
  exportReferralStatistics,
  getAllReferralUsers,
  setPaginationReferralParams,
} from '@/redux/slices/admin/referral-statistics/referralStatisticsSlice';
import cn from '@/utils/class-names';
import moment from 'moment';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useMedia } from 'react-use';
import { Button } from 'rizzui';

const pageHeader = {
  title: 'Referral Statistics',
};

export default function ReferralStatisticsPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { openModal } = useModal();
  const isSmall = useMedia('(min-width: 640px)', false);
  const isMedium = useMedia('(min-width: 768px)', false);
  const isLarge = useMedia('(min-width: 1024px)', false);
  const isExtraLarge = useMedia('(min-width: 1280px)', false);
  const isTooExtraLarge = useMedia('(min-width: 1536px)', false);

  const {
    userData,
    getAllReferralUsersLoader,
    paginationParams,
    exportReferralStatisticsLoader,
  } = useSelector((state: any) => state?.root?.referralStatistics);

  const [pageSize, setPageSize] = useState(10);

  const firstDayOfMonth = moment().startOf('month').format('DD-MM-YYYY');
  const endDayOfMonth = moment().endOf('month').format('DD-MM-YYYY');

  const [startDate, setStartDate] = useState<any>(firstDayOfMonth);
  const [endDate, setEndDate] = useState<any>(endDayOfMonth);
  const [reset, setReset] = useState('');
  const [referralReset, setReferralReset] = useState(false);

  useEffect(() => {
    // clear user referral data on unmount event
    return () => {
      dispatch(clearReferralUsersData());
      dispatch(
        setPaginationReferralParams({
          page: 1,
          items_per_page: 10,
          sort_field: 'createdAt',
          sort_order: 'desc',
          search: '',
        })
      );
    };
  }, []);

  useEffect(() => {
    // if (!startDate || !endDate) {
    setReset('');
    // }

    !!endDate &&
      dispatch(
        getAllReferralUsers({
          ...paginationParams,
          start_date: moment(startDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
          end_date: moment(endDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
        })
      );

    dispatch(
      setPaginationReferralParams({
        ...paginationParams,
        start_date: moment(startDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
        end_date: moment(endDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
      })
    );
  }, [startDate, endDate]);

  // useMemo to optimize rendering and prevent unnecessary recalculations
  const divCount = useMemo(() => {
    if (isSmall && isMedium) {
      if (isLarge) {
        return isExtraLarge ? (isTooExtraLarge ? 3 : 2) : 2;
      }
      return 1;
    }
    return 0;
  }, [isSmall, isMedium, isLarge, isExtraLarge, isTooExtraLarge]);

  //Pagination Handler
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    dispatch(
      setPaginationReferralParams({
        ...paginationParams,
        start_date: moment(startDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
        end_date: moment(endDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
      })
    );
    const response = await dispatch(
      getAllReferralUsers({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        start_date: moment(startDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
        end_date: moment(endDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllReferralUsers({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          start_date: moment(startDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
          end_date: moment(endDate, 'DD-MM-YYYY').format('MM/DD/YYYY'),
        })
      );
      return data?.user_referral_data;
    }
    return data?.user_referral_data;
  };

  //download referral statistics sheet
  const downloadReferralStatisticsInformation = () => {
    dispatch(exportReferralStatistics()).then(async (result: any) => {
      if (exportReferralStatistics?.fulfilled.match(result)) {
        const blob = await result.payload;

        // Create a URL for the blob data
        const url = window.URL.createObjectURL(
          new Blob([blob], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          })
        );

        // Create a temporary anchor element
        const a = document.createElement('a');
        a.href = url;

        // Set the filename for the downloaded file
        a.download = 'Referral_Statistics_Information.xlsx';

        // Programmatically click the anchor element to trigger the download
        a.click();

        // Clean up by revoking the object URL
        window.URL.revokeObjectURL(url);
      }
      // console.log(result, 'download sheet');
    });
  };

  // Table Filters
  const Filters = () => {
    // handle reset filters
    const handleResetFilters = (e: any) => {
      e.stopPropagation();
      setStartDate(firstDayOfMonth);
      setEndDate(endDayOfMonth);
      setReset('reset');
      setReferralReset(true);
      dispatch(
        getAllReferralUsers({
          page: 1,
          items_per_page: 10,
          sort_field: 'createdAt',
          sort_order: 'desc',
          search: '',
          start_date: moment(firstDayOfMonth, 'DD-MM-YYYY').format(
            'MM/DD/YYYY'
          ),
          end_date: moment(endDayOfMonth, 'DD-MM-YYYY').format('MM/DD/YYYY'),
        })
      );
    };

    return (
      <>
        {/* {divCount
          ? Array?.from({ length: divCount }, (_, index) => <div key={index} />)
          : null} */}
        <Button
          className={cn('text-xs @lg:w-auto sm:text-sm lg:mt-0')}
          onClick={(e) => handleResetFilters(e)}
        >
          Reset
        </Button>
        {/* {isTooExtraLarge && <div/>}
        <Button
          variant="outline"
          className="bg-black text-white"
          onClick={downloadReferralStatisticsInformation}
          disabled={exportReferralStatisticsLoader}
        >
          <PiArrowLineUpBold className="me-1.5 h-[17px] w-[17px]" />
          Export
          {exportReferralStatisticsLoader && (
            <Spinner size="sm" tag="div" className="ms-3 text-white" />
          )}
        </Button> */}
      </>
    );
  };

  const memoizedData = useMemo(
    () => userData?.user_referral_data ?? [],
    [userData?.user_referral_data]
  );
  const memoizedTotal = useMemo(
    () => userData?.page_count ?? 1,
    [userData?.page_count]
  );

  return (
    <>
      <PageHeader title={pageHeader.title} />
      <CustomTable
        data={memoizedData}
        total={memoizedTotal}
        loading={getAllReferralUsersLoader}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleChangePage={handleChangePage}
        getColumns={ReferralStatisticsColumns}
        scroll={{ x: 0 }}
        filtersList={<Filters />}
        setStartDate={setStartDate}
        setEndDate={setEndDate}
        isRangeFilter={true}
        resetValue={reset}
        isaAttendanceDate={true}
        reset={referralReset}
        setReset={setReferralReset}
      />
    </>
  );
}
