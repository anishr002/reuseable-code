import { metaObject } from '@/config/site.config';
import ReferralStatisticsPage from './main-page';

export const metadata = {
  ...metaObject('Referral Statistics'),
};

export default function FaqsPage() {
  return <ReferralStatisticsPage />;
}
