'use client';

import { PopupReferralStatisticsColumns } from '@/app/shared/(admin)/referral-statistics/popup-columns';
import { useModal } from '@/app/shared/modal-views/use-modal';
import CustomTable from '@/components/common-tables/table';
import Spinner from '@/components/ui/spinner';
import {
  clearReferralData,
  exportReferralStatistics,
  getAllReferralDataById,
} from '@/redux/slices/admin/referral-statistics/referralStatisticsSlice';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { PiArrowLineUpBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { useMedia } from 'react-use';
import { ActionIcon, Button, Title } from 'rizzui';

const DummyData = [
  {
    name: 'Payment Information',
    date: '12/12/2023',
    form_of_payment: 'Credit card',
    subscription_plan: 'Platinum',
    transaction_id: 'T1234-5678-9012-3456',
    status: 'Success',
  },
  {
    name: 'Payment Information',
    date: '12/12/2023',
    form_of_payment: 'Credit card',
    subscription_plan: 'Platinum',
    transaction_id: 'T1234-5678-9012-3456',
    status: 'Success',
  },
];

const pageHeader = {
  title: 'Referral Users',
};

export default function ReferralStatisticsSublistPage(props: any) {
  const { referred_by } = props;

  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal } = useModal();
  const isSmall = useMedia('(min-width: 640px)', false);
  const isMedium = useMedia('(min-width: 768px)', false);
  const isLarge = useMedia('(min-width: 1024px)', false);
  const isExtraLarge = useMedia('(min-width: 1280px)', false);
  const isTooExtraLarge = useMedia('(min-width: 1536px)', false);

  const {
    referralData,
    getAllReferralDataByIdLoader,
    exportReferralStatisticsLoader,
    paginationParams,
  } = useSelector((state: any) => state?.root?.referralStatistics);

  const [pageSize, setPageSize] = useState(10);

  console.log('paginationParams....', paginationParams);

  useEffect(() => {
    // clear referral data by user id on unmount event
    return () => {
      dispatch(clearReferralData());
    };
  }, []);

  // useMemo to optimize rendering and prevent unnecessary recalculations
  const divCount = useMemo(() => {
    if (isSmall && isMedium) {
      if (isLarge) {
        return isExtraLarge ? (isTooExtraLarge ? 3 : 2) : 2;
      }
      return 1;
    }
    return 0;
  }, [isSmall, isMedium, isLarge, isExtraLarge, isTooExtraLarge]);

  //Pagination Handler
  const handleChangePage = async (referralPaginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      referralPaginationParams;
    const response = await dispatch(
      getAllReferralDataById({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        start_date: paginationParams?.start_date,
        end_date: paginationParams?.end_date,
        referred_by,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllReferralDataById({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          start_date: paginationParams?.start_date,
          end_date: paginationParams?.end_date,
          referred_by,
        })
      );
      return data?.get_all_users_data;
    }
    return data?.get_all_users_data;
  };

  //download referral statistics of particular user
  const downloadReferralUsersInformation = () => {
    dispatch(exportReferralStatistics()).then(async (result: any) => {
      if (exportReferralStatistics?.fulfilled.match(result)) {
        const blob = await result?.payload;

        // Create a URL for the blob data
        const url = window.URL.createObjectURL(
          new Blob([blob], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          })
        );

        // Create a temporary anchor element
        const a = document.createElement('a');
        a.href = url;

        // Set the filename for the downloaded file
        a.download = 'Referral_Statistics_Information.xlsx';

        // Programmatically click the anchor element to trigger the download
        a.click();

        // Clean up by revoking the object URL
        window.URL.revokeObjectURL(url);
      }
      // console.log(result, 'download sheet');
    });
  };

  // Popup Table Filters
  // const PopupTableFilters = () => {
  //   return (
  //     <>
  //       {divCount
  //         ? Array?.from({ length: divCount }, (_, index) => <div key={index} />)
  //         : null}
  //       <Button
  //         variant="outline"
  //         className="bg-black text-white"
  //         onClick={downloadReferralUsersInformation}
  //         disabled={exportReferralStatisticsLoader}
  //       >
  //         <PiArrowLineUpBold className="me-1.5 h-[17px] w-[17px]" />
  //         Export
  //         {exportReferralStatisticsLoader && (
  //           <Spinner size="sm" tag="div" className="ms-3 text-white" />
  //         )}
  //       </Button>
  //     </>
  //   );
  // };

  const memoizedData = useMemo(
    () => referralData?.get_all_users_data ?? [],
    [referralData?.get_all_users_data]
  );
  const memoizedTotal = useMemo(
    () => referralData?.page_count ?? 1,
    [referralData?.page_count]
  );

  return (
    <div className="p-8">
      <div className="mb-6 flex items-center">
        <Title as="h3" className="w-full text-xl xl:text-2xl">
          {pageHeader.title}
        </Title>
        <div className="ms-auto flex items-center gap-3">
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => closeModal()}
            className="p-0 text-gray-500 hover:!text-gray-900"
          >
            <PiXBold className="h-[18px] w-[18px]" />
          </ActionIcon>
        </div>
      </div>
      <CustomTable
        data={memoizedData}
        total={memoizedTotal}
        loading={getAllReferralDataByIdLoader}
        pageSize={pageSize}
        setPageSize={setPageSize}
        // handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={PopupReferralStatisticsColumns}
        scroll={{ x: 0 }}
        // filtersList={<PopupTableFilters />}
      />
    </div>
  );
}
