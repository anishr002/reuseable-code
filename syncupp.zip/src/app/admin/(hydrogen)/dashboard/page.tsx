'use client';

import Wrapper from '@/app/shared/file/dashboard/WrapperComponets';
import PageHeader from '@/app/shared/page-header';
import WidgetCard from '@/components/cards/widget-card';
import LoginIcon from '@/components/icons/login';
import TaskIcon from '@/components/icons/task';
import TransactionIcon from '@/components/icons/transactions';
import UserPlusIcon from '@/components/icons/user-plus';
import VerifyIcon from '@/components/icons/verify';
import { getAlladminStatic } from '@/redux/slices/user/dashboard/dashboardSlice';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Text } from 'rizzui';
import SimpleBar from 'simplebar-react';

export default function FileDashboardPage() {
  const dispatch = useDispatch();
  const { adminstatics } = useSelector((state: any) => state?.root?.dashbord);

  useEffect(() => {
    dispatch(getAlladminStatic());
  }, [dispatch]);
  const filesStatData = [
    {
      id: 1,
      title: 'Total Customers',
      fill: '#ff5630',
      value: adminstatics?.data?.active_agencies || 0,
      iconComponent: UserPlusIcon,
      roleList: ['admin'],
    },
    {
      id: 2,
      title: 'Total Clients ',
      fill: '#ff5630',
      value: adminstatics?.data?.active_clients || 0,
      iconComponent: UserPlusIcon,
      roleList: ['admin'],
    },
    {
      id: 3,
      title: 'Total Client Members ',
      fill: '#EE0000',
      value: adminstatics?.data?.active_team_client || 0,
      iconComponent: UserPlusIcon,
      roleList: ['admin'],
    },
    {
      id: 4,
      title: 'Total Customer Members',
      fill: '#3872FA',
      value: adminstatics?.data?.active_team_agency || 0,
      iconComponent: UserPlusIcon,
      roleList: ['admin'],
    },
    {
      id: 5,
      title: 'This Month Billing',
      fill: '#00b8d9',
      value: (
        <div className="flex items-center gap-5">
          <span className="poppins_font_number font-lexend text-sm font-semibold text-gray-900 dark:text-gray-700 2xl:text-base">
            $
            {(adminstatics &&
              adminstatics?.data?.this_billing_amount?.length > 0 &&
              Math?.round(
                adminstatics?.data?.this_billing_amount?.find(
                  (billing: any) => billing?._id === 'USD'
                )?.totalAmount ?? 0
              ) / 100) ||
              0}
          </span>
          <span className="poppins_font_number font-lexend text-sm font-semibold text-gray-900 dark:text-gray-700 2xl:text-base">
            ₹
            {(adminstatics &&
              adminstatics?.data?.this_billing_amount?.length > 0 &&
              Math?.round(
                adminstatics?.data?.this_billing_amount?.find(
                  (billing: any) => billing?._id === 'INR'
                )?.totalAmount ?? 0
              ) / 100) ||
              0}
          </span>
        </div>
      ),
      iconComponent: TransactionIcon,
      roleList: ['admin'],
    },
    {
      id: 6,
      title: 'Total Daily Tasks Created',
      fill: '#e9971a',
      value: adminstatics?.data?.new_task || 0,
      iconComponent: TaskIcon,
      roleList: ['admin'],
    },
    {
      id: 7,
      title: 'Total Daily Teammates Added',
      fill: '#ff5630',
      value: adminstatics?.data?.new_agency_team || 0,
      iconComponent: UserPlusIcon,
      roleList: ['admin'],
    },
    {
      id: 8,
      title: 'Total Daily Clients Added',
      fill: '#3872FA',
      value: adminstatics?.data?.new_client || 0,
      iconComponent: UserPlusIcon,
      roleList: ['admin'],
    },
    {
      id: 9,
      title: 'Total Daily Logins',
      fill: '#50AB4D',
      value: adminstatics?.data?.login || 0,
      iconComponent: LoginIcon,
      roleList: ['admin'],
    },
    {
      id: 10,
      title: 'Client / Team Member - Pending Verify',
      fill: '#3872FA',
      value: adminstatics?.data?.pending_clients || 0,
      iconComponent: VerifyIcon,
      roleList: ['admin'],
    },
    {
      id: 11,
      title: 'Team Member - Pending Verify',
      fill: '#ff5630',
      value: adminstatics?.data?.pending_agencyteam || 0,
      iconComponent: VerifyIcon,
      roleList: ['admin'],
    },
  ];

  return (
    <>
      <PageHeader title="Dashboard">
        <div className="mt-4 flex items-center gap-3 @lg:mt-0"></div>
      </PageHeader>
      <WidgetCard
        rounded="lg"
        //className={className}
        title="Statistics "
        headerClassName="@2xl"
      >
        <SimpleBar>
          <div className="2xl grid gap-2 sm:grid-cols-1 md:grid-cols-3">
            {filesStatData?.map((stat: any) => {
              const IconComponent = stat.iconComponent;
              return (
                <Wrapper
                  roleList={stat?.roleList}
                  permission={true}
                  role={'admin'}
                  key={stat?.id}
                >
                  <div className="mt-3 flex items-start 2xl:mt-5">
                    <div className="me-9 flex items-start">
                      <div
                        className="me-3 rounded p-2 text-white"
                        style={{ backgroundColor: `${stat.fill}` }}
                      >
                        <IconComponent className="h-6 w-6" />
                      </div>
                      <div>
                        <Text className="text-gray-500">{stat.title} </Text>
                        <Text className="poppins_font_number font-lexend text-sm font-semibold text-gray-900 dark:text-gray-700 2xl:text-base">
                          {stat.value}
                        </Text>
                      </div>
                    </div>
                  </div>
                </Wrapper>
              );
            })}
          </div>
        </SimpleBar>
      </WidgetCard>
      {/* <FileDashboard /> */}
    </>
  );
}
