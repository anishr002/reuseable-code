'use client';

import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import CustomTable from '@/components/common-tables/table';
import PageHeader from '@/app/shared/page-header';
import DateFiled from '@/components/controlled-table/date-field';
import { Button } from 'rizzui';
import cn from '@/utils/class-names';

import moment from 'moment';
import {
  demoCallsExportHandle,
  getAllDemoCalls,
} from '@/redux/slices/admin/demo-calls/demoCallSlice';
import { DemoCallsColumns } from '@/app/shared/(admin)/demo-calls/columns';
import Spinner from '@/components/ui/spinner';
import { PiArrowLineUpBold } from 'react-icons/pi';

const pageHeader = {
  title: 'Demo Calls',
};

export default function DemoCallsPage() {
  const dispatch = useDispatch();
  const router = useRouter();

  const { loading, demoCallsdata, exportLoading } = useSelector(
    (state: any) => state?.root?.democalls
  );

  const [pageSize, setPageSize] = useState(10);
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);
  const [sortObject, setSortObject] = useState({});

  useEffect(() => {
    dispatch(
      getAllDemoCalls({
        page: 1,
        items_per_page: 10,
        sort_order: 'desc',
        sort_field: 'createdAt',
        search: undefined,
        filter: {
          ...(endRangeDate && endRangeDate != null
            ? {
                start_date:
                  startRangeDate && startRangeDate != null
                    ? moment(startRangeDate).format('DD/MM/YYYY')
                    : null,
                end_date: moment(endRangeDate).format('DD/MM/YYYY'),
              }
            : {}),
        },
      })
    );
  }, [endRangeDate]);

  //Paggination Handler
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    setSortObject({ page, items_per_page, sort_field, sort_order, search });
    const response = await dispatch(
      getAllDemoCalls({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        filter: {
          ...(endRangeDate && endRangeDate != null
            ? {
                start_date:
                  startRangeDate && startRangeDate != null
                    ? moment(startRangeDate).format('DD/MM/YYYY')
                    : null,
                end_date: moment(endRangeDate).format('DD/MM/YYYY'),
              }
            : {}),
        },
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllDemoCalls({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          filter: {
            ...(endRangeDate && endRangeDate != null
              ? {
                  start_date:
                    startRangeDate && startRangeDate != null
                      ? moment(startRangeDate).format('DD/MM/YYYY')
                      : null,
                  end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                }
              : {}),
          },
        })
      );
      return data?.transactions;
    }
    return data?.transactions;
  };

  // Delete Handler
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number
  ) => {
    // try {
    //     const res = await dispatch(deleteAgencyAgreement({ agreementIdsToDelete: id }));
    //     if (res.payload.success === true) {
    //         const reponse = await dispatch(getAllAgencyagreement({ page: currentPage, items_per_page: countPerPage, sort_field: 'createdAt', sort_order: 'desc' }));
    //     }
    // } catch (error) {
    //     console.error(error);
    // }
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    // setsubscriptionplan(null);
  };

  //download sheet
  const DownloaddemoCalls = () => {
    dispatch(
      demoCallsExportHandle({
        ...sortObject,
        filter: {
          ...(endRangeDate && endRangeDate != null
            ? {
                start_date:
                  startRangeDate && startRangeDate != null
                    ? moment(startRangeDate).format('DD/MM/YYYY')
                    : null,
                end_date: moment(endRangeDate).format('DD/MM/YYYY'),
              }
            : {}),
        },
      })
    ).then(async (result: any) => {
      if (demoCallsExportHandle.fulfilled.match(result)) {
        const blob = await result.payload;

        // Create a URL for the blob data
        const url = window.URL.createObjectURL(
          new Blob([blob], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          })
        );

        // Create a temporary anchor element
        const a = document.createElement('a');
        a.href = url;

        // Set the filename for the downloaded file
        a.download = 'Demo_Calls.xlsx';

        // Programmatically click the anchor element to trigger the download
        a.click();

        // Clean up by revoking the object URL
        window.URL.revokeObjectURL(url);
      }
      // console.log(result, 'download sheet');
    });
  };

  // Table Filters
  const DemoCallsFilter = () => {
    return (
      <>
        <DateFiled
          className="w-full"
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Select Date in a Range"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        />
        <Button
          className={cn('text-xs @lg:w-auto sm:text-sm lg:mt-0')}
          onClick={handleResetFilters}
        >
          Reset
        </Button>
        <Button
          variant="outline"
          className="bg-black text-white"
          onClick={DownloaddemoCalls}
          disabled={exportLoading}
        >
          <PiArrowLineUpBold className="me-1.5 h-[17px] w-[17px]" />
          Export
          {exportLoading && (
            <Spinner size="sm" tag="div" className="ms-3 text-white" />
          )}
        </Button>
      </>
    );
  };

  return (
    <>
      {/* <h1>Aggrement</h1> */}
      <PageHeader title={pageHeader.title} />
      <CustomTable
        data={(demoCallsdata && demoCallsdata?.demo_call_data) ?? []}
        total={(demoCallsdata && demoCallsdata?.page_count) ?? 1}
        loading={loading}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={DemoCallsColumns}
        scroll={{ x: 0 }}
        filtersList={<DemoCallsFilter />}
      />
    </>
  );
}
