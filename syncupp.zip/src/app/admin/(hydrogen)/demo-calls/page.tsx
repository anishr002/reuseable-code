import { metaObject } from '@/config/site.config';
import DemoCallsPage from './main-page';

export const metadata = {
  ...metaObject('Demo-Calls'),
};

export default function DemoCalls() {
  return (
    <>
      <DemoCallsPage />
    </>
  );
}
