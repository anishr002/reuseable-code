'use client';

import Spinner from '@/components/ui/spinner';
import { Text, Title } from '@/components/ui/text';
import { routes } from '@/config/routes';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import moment from 'moment';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FaArrowLeft } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

export const FormParts = {
  ShippingInfo: 'ShippingInfo',
  SenderInfo: 'SenderInfo',
  RecipientsInfo: 'RecipientsInfo',
};

export const menuItems = [
  {
    label: 'Activity',
    value: FormParts.ShippingInfo,
  },
  {
    label: 'Agreement',
    value: FormParts.SenderInfo,
  },
  {
    label: 'Invoice',
    value: FormParts.RecipientsInfo,
  },
];
export const menuButtons = [
  {
    label: 'To Do',
    value: FormParts.ShippingInfo,
  },
  {
    label: 'Overdue',
    value: FormParts.SenderInfo,
  },
  {
    label: 'Done',
    value: FormParts.RecipientsInfo,
  },
  {
    label: 'Today',
    value: FormParts.RecipientsInfo,
  },
  {
    label: 'Tomorrow',
    value: FormParts.RecipientsInfo,
  },
  {
    label: 'This Week',
    value: FormParts.RecipientsInfo,
  },
  {
    label: 'Select Period',
    value: FormParts.RecipientsInfo,
  },
];

export function WidgetCard({
  title,
  className,
  children,
  childrenWrapperClass,
}: {
  title?: string;
  className?: string;
  children: React.ReactNode;
  childrenWrapperClass?: string;
}) {
  return (
    <div className={className}>
      <Title
        as="h3"
        className="mb-3.5 text-base font-semibold @5xl:mb-5 4xl:text-lg"
      >
        {title}
      </Title>
      <div
        className={cn(
          'rounded-lg border  border-gray-200 @sm:px-4 @5xl:rounded-xl',
          childrenWrapperClass
        )}
      >
        {children}
      </div>
    </div>
  );
}

export default function AgencyViewProfileForm() {
  const dispatch = useDispatch();
  // const signIn = useSelector((state: any) => state?.root?.signIn);
  // const clientSliceData = useSelector((state: any) => state?.root?.client);
  const agencylistDetails = useSelector(
    (state: any) => state?.root?.adminAgency
  );

  const router = useRouter();

  // useEffect(() => {
  //   dispatch(getAgencyDetails());
  // }, [dispatch]);

  const { data } = agencylistDetails?.agencyDetails ?? {};
  console.log(data, '.....Agency data');
  const initialValues = {
    email: data?.email ?? '',
    first_name: data?.first_name ?? '',
    last_name: data?.last_name ?? '',
    contact_number: data?.contact_number ?? '',
    address: data?.reference_id?.address ?? '',
    city: data?.reference_id?.city?.name ?? '',
    company_name: data?.reference_id?.company_name ?? '',
    company_website: data?.reference_id?.company_website ?? '',
    country: data?.reference_id?.country?.name ?? '',
    industry: data?.reference_id?.industry ?? '',
    no_of_people: data?.reference_id?.no_of_people ?? '',
    pincode: data?.reference_id?.pincode ?? '',
    state: data?.reference_id?.state?.name ?? '',
    role: data?.role ?? '',
  };

  // const { items, total, totalItems } = useCart();
  // const { price: subtotal } = usePrice(
  //   items && {
  //     amount: total,
  //   }
  // );
  // const { price: totalPrice } = usePrice({
  //   amount: total,
  // });
  // const orderNote = useAtomValue(orderNoteAtom);
  // const billingAddress = useAtomValue(billingAddressAtom);
  // const shippingAddress = useAtomValue(shippingAddressAtom);
  if (Object?.keys(agencylistDetails?.agencyDetails ?? {})?.length === 0) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <div className="">
        <div className="flex justify-between border-gray-300 px-6 py-4 font-medium text-gray-700 @5xl:justify-start">
          <div>
            <Title>Customer Details</Title>
          </div>
          <div className="ms-auto">
            <Link href={routes.admin.agencylist}>
              <Button className="bg-none text-xs @lg:w-auto sm:text-sm">
                <FaArrowLeft className="me-1.5 h-[17px] w-[17px]" />
                Back
              </Button>
            </Link>
          </div>
        </div>
        <div className="grid gap-4 p-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
          <WidgetCard
            title="Personal Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[8rem] "
          >
            <div className="mb-[20px] ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-bold text-gray-700">Name :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {capitalizeFirstLetter(data?.agency_detail?.first_name)}{' '}
                  {capitalizeFirstLetter(data?.agency_detail?.last_name)}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Email :</span>
                <Text as="p" className="text-base @7xl:text-lg">
                  {data?.agency_detail?.email}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Contact no :
                </span>
                {data?.agency_detail?.contact_number ? (
                  <Text
                    as="p"
                    className="poppins_font_number text-base font-light @7xl:text-lg"
                  >
                    +{data?.agency_detail?.contact_number}
                  </Text>
                ) : (
                  <Text as="p" className="text-base @7xl:text-lg">
                    -
                  </Text>
                )}
              </span>
            </div>
          </WidgetCard>
          <WidgetCard
            title="Workspace Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[8rem] "
          >
            <div className="w-full ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex w-full items-baseline gap-2">
                <span className="w-[15%] font-semibold text-gray-900">
                  Name :
                </span>
                <span className="flex w-[85%] flex-wrap gap-2">
                  {data &&
                    data?.workspace?.length > 0 &&
                    data?.workspace?.map(
                      (workspace: Record<string, any>, index: number) => {
                        return (
                          <Text
                            key={index}
                            as="p"
                            className="rounded-[12px] border border-gray-400 px-2 py-[2px] text-base capitalize @7xl:text-lg"
                          >
                            {workspace?.name
                              ? capitalizeFirstLetter(workspace?.name)
                              : 'N/A'}
                          </Text>
                        );
                      }
                    )}
                </span>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Trial End Date :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.workspace?.[0]?.trial_end_date
                    ? moment(data?.workspace?.[0]?.trial_end_date).format(
                      'Do MMM, YYYY'
                    )
                    : 'N/A'}
                </Text>
              </span>
            </div>
          </WidgetCard>
        </div>
        <div className="mt-[-51px] grid gap-4 p-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
          <WidgetCard
            title="General Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[11rem] "
          >
            <div className="ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Address :</span>
                <Text as="p" className="text-base @7xl:text-lg">
                  {data?.agency_detail?.address ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">City :</span>
                <Text as="p" className="text-base @7xl:text-lg">
                  {data?.agency_detail?.city?.name ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">State :</span>
                <Text as="p" className="text-base @7xl:text-lg">
                  {data?.agency_detail?.state?.name ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Country :</span>
                <Text as="p" className="text-base @7xl:text-lg">
                  {data?.agency_detail?.country?.name ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Pincode :</span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light @7xl:text-lg"
                >
                  {data?.agency_detail?.pincode ?? 'N/A'}
                </Text>
              </span>
            </div>
          </WidgetCard>
          <WidgetCard
            title="Company Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[11rem] "
          >
            <div className="ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Name :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.agency_detail?.company_name ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="text-wrap font-semibold text-gray-900">
                  Website :
                </span>
                {data?.agency_detail?.company_website &&
                  data?.agency_detail?.company_website !== '' &&
                  data?.agency_detail?.company_website !== null ? (
                  <a
                    href={data?.agency_detail?.company_website}
                    target="_blank"
                    rel=""
                    className="break-all text-base text-blue-600 hover:underline @7xl:text-lg"
                  >
                    {data?.agency_detail?.company_website ?? 'N/A'}
                  </a>
                ) : (
                  <Text as="p" className="text-base @7xl:text-lg">
                    N/A
                  </Text>
                )}
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Industry :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.agency_detail?.profession_role ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Employee :</span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light @7xl:text-lg"
                >
                  {data?.agency_detail?.no_of_people ?? 'N/A'}
                </Text>
              </span>
            </div>
          </WidgetCard>
        </div>
        <div className="mt-[-51px] grid gap-4 p-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
          <WidgetCard
            title="Plan Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[9rem] "
          >
            <div className="ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Plan Name :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.subscription_plan?.subscription?.name
                    ? data?.subscription_plan?.subscription?.name
                    : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Plan Category :
                </span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.subscription_plan?.subscription?.plan_category
                    ? data?.subscription_plan?.subscription?.plan_category
                    : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Plan Type :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.subscription_plan?.subscription?.period
                    ? data?.subscription_plan?.subscription?.period
                    : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Price :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.subscription_plan?.subscription ? (
                    <span className="poppins_font_number flex gap-1 text-base font-light @7xl:text-lg">
                      {data?.subscription_plan?.subscription?.symbol ?? ''}{' '}
                      {(data?.subscription_plan?.subscription?.amount ?? 0) /
                        100}
                    </span>
                  ) : (
                    'N/A'
                  )}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Seats :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.subscription_plan?.subscription?.no_of_users
                    ? data?.subscription_plan?.subscription?.no_of_users
                    : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Workspaces :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.subscription_plan?.subscription?.period !== 'lifetime'
                    ? data?.subscription_plan?.subscription?.workspaces_count
                    : data?.subscription_plan?.subscription?.period ===
                      'lifetime'
                      ? 'Unlimited'
                      : 'N/A'}
                </Text>
              </span>
            </div>
          </WidgetCard>
          <WidgetCard
            title="Billing Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[9rem] "
          >
            <div className="ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Next Billing Date :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.subscription_plan?.next_billing_date
                    ? (Number(data?.subscription_plan?.next_billing_date) ? moment.unix(data?.subscription_plan?.next_billing_date).format(
                      'Do MMM, YYYY'
                    ) : moment(data?.subscription_plan?.next_billing_date).format(
                      'Do MMM, YYYY'
                    ))
                    : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Payment Category :
                </span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {data?.agency_detail?.purchased_plan
                    ? 'Purchased'
                    : data?.agency_detail?.manual_subscription_plan
                      ? 'Manual'
                      : 'N/A'}
                </Text>
              </span>
            </div>
          </WidgetCard>
        </div>
        <div className="mt-[-51px] grid gap-4 p-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
          <WidgetCard
            title="Statistics"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex min-h-[9rem] "
          >
            <div className="ps-[10px] pt-[10px] @5xl:ps-6">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Daily Logins :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.statistics?.total_daily_logins ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Clients Added :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.statistics?.total_clients ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Teammates Added :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.statistics?.total_teams ?? 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Tasks Created :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                >
                  {data?.statistics?.total_tasks ?? 'N/A'}
                </Text>
              </span>
            </div>
          </WidgetCard>
        </div>
      </div>
    );
  }
}
