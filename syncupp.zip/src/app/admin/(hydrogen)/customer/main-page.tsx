'use client';
import { GetColumns } from '@/app/shared/(admin)/agency/columns';
import { useModal } from '@/app/shared/modal-views/use-modal';
import PageHeader from '@/app/shared/page-header';
import CustomTable from '@/components/common-tables/table';
import DateFiled from '@/components/controlled-table/date-field';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import {
  allagencylistdownload,
  deleteAgency,
  getAllAgency,
  setAdminPaginationDetails,
} from '@/redux/slices/admin/agency/agencySlice';
import { removePlanData } from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import cn from '@/utils/class-names';
import moment from 'moment';
import { useEffect, useState } from 'react';
import { PiArrowLineUpBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

const pageHeader = {
  title: 'Customer list',
};

const peopleCountOptions = [
  { name: 'All', value: '' },
  { name: 'Just me', value: 'Just me' },
  { name: '2-10', value: '2-10' },
  { name: '11-15', value: '11-15' },
  { name: '16-50', value: '16-50' },
  { name: '51-250', value: '51-250' },
  { name: '251-500', value: '251-500' },
  { name: '501+', value: '501+' },
  { name: "I don't know", value: "I don't know" },
];

const industryOptions = [
  { name: 'All', value: '' },
  { name: 'Super Admin', value: 'Agency' },
  { name: 'Freelancer', value: 'Freelancer' },
  { name: 'Other', value: 'Other' },
];

//option of payment status
let paymentStatusOptions: Record<string, any>[] = [
  { value: '', name: 'All Status' },
  { value: 'free_trial', name: 'Free Trial' },
  { value: 'payment_pending', name: 'Payment Pending' },
  { value: 'confirmed', name: 'Active' },
  { value: 'agency_inactive', name: 'Inactive' },
  { value: 'subscription_cancelled', name: 'Subscription Cancelled ' },
  // Add more options as needed
];

export default function ClientPage() {
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  const [currentPagee, setCurrentPagee] = useState(1);
  const [selectedpaymnet, setSelectedpayment] = useState<any>('');
  const [exelbuttonloading, setexelbuttonloadding] = useState<any>(false);
  const [selectedpeople, setselectedpeople] = useState<any>(null);
  const [selectedindustry, setselectedindustry] = useState<any>(null);
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);
  const [pageSize, setPageSize] = useState(10);
  const [reset, setReset] = useState(false);

  const { agencylistDetails, loading, paginationParams } = useSelector(
    (state: any) => state?.root?.adminAgency
  );

  console.log('paginationParams in main page.....', paginationParams);

  useEffect(() => {
    // remove plan data on first load if have
    dispatch(removePlanData());
  }, [dispatch]);

  useEffect(() => {
    dispatch(
      getAllAgency({
        page: currentPagee,
        items_per_page: 10,
        sort_order: 'desc',
        sort_field: 'createdAt',
        search: paginationParams?.search ?? '',
        filter: {
          status: selectedpaymnet?.value || '',
          profession_role: selectedindustry?.value || '',
          no_of_people: selectedpeople?.value || '',
          ...(endRangeDate && endRangeDate != null
            ? {
                date: {
                  start_date:
                    startRangeDate && startRangeDate != null
                      ? moment(startRangeDate).format('DD/MM/YYYY')
                      : null,
                  end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                },
              }
            : {}),
        },
      })
    );
    dispatch(
      setAdminPaginationDetails({
        ...paginationParams,
        filter: {
          status: selectedpaymnet?.value || '',
          profession_role: selectedindustry?.value || '',
          no_of_people: selectedpeople?.value || '',
          ...(endRangeDate && endRangeDate != null
            ? {
                date: {
                  start_date:
                    startRangeDate && startRangeDate != null
                      ? moment(startRangeDate).format('DD/MM/YYYY')
                      : null,
                  end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                },
              }
            : {}),
        },
      })
    );
  }, [
    dispatch,
    selectedpaymnet,
    selectedindustry,
    selectedpeople,
    endRangeDate,
  ]);

  useEffect(() => {
    dispatch(
      setAdminPaginationDetails({
        page: 1,
        items_per_page: 10,
        sort_order: 'desc',
        sort_field: 'createdAt',
        search: '',
        filter: {
          status: '',
          profession_role: '',
          no_of_people: '',
          date: {
            start_date: null,
            end_date: null,
          },
        },
      })
    );
  }, []);

  const handleChangePage = async (tablePaginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      tablePaginationParams;

    // console.log("tablePaginationParams in handle change page....", tablePaginationParams, "paginationParams.....####", paginationParams)

    dispatch(
      setAdminPaginationDetails({
        filter: paginationParams?.filter,
        ...tablePaginationParams,
      })
    );

    setCurrentPagee(page);
    const response = await dispatch(
      getAllAgency({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        filter: {
          status: selectedpaymnet?.value || '',
          profession_role: selectedindustry?.value || '',
          no_of_people: selectedpeople?.value || '',
          ...(endRangeDate && endRangeDate != null
            ? {
                date: {
                  start_date:
                    startRangeDate && startRangeDate != null
                      ? moment(startRangeDate).format('DD/MM/YYYY')
                      : null,
                  end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                },
              }
            : {}),
        },
        // status_name: selectedpaymnet?.value || '',
      })
    );
    // console.log("Response....", response);
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllAgency({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          filter: {
            status: selectedpaymnet?.value || '',
            profession_role: selectedindustry?.value || '',
            no_of_people: selectedpeople?.value || '',
            ...(endRangeDate && endRangeDate != null
              ? {
                  date: {
                    start_date:
                      startRangeDate && startRangeDate != null
                        ? moment(startRangeDate).format('DD/MM/YYYY')
                        : null,
                    end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                  },
                }
              : {}),
          },
        })
      );
      return data?.agencyList;
    }
    return data?.agencyList;
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      // console.log("id.....", id, typeof id, Array.isArray(id));

      // let payload: any = [];
      // if (typeof id === 'string') {
      //   // console.log("Hello if", id);
      //   if (agencylistDetails?.data?.agencyList?.length > 0) {
      //     agencylistDetails?.data?.agencyList?.forEach((rowData: any) => {
      //       if (rowData?._id === id) {
      //         // console.log("id matched", rowData)
      //         payload?.push({
      //           agency_id: id,
      //           workspace_id: rowData?.workspace_id,
      //         });
      //       }
      //     });
      //   }
      // } else if (Array.isArray(id)) {
      //   // console.log("Hello else", id);
      //   if (agencylistDetails?.data?.agencyList?.length > 0) {
      //     const filteredList =
      //       agencylistDetails?.data?.agencyList?.filter((rowData: any) => {
      //         return id?.includes(rowData?._id);
      //       }) || [];

      //     filteredList &&
      //       filteredList?.length > 0 &&
      //       filteredList?.forEach((rowData: any) => {
      //         id.forEach((agency) => {
      //           // console.log("id matched", rowData)
      //           if (rowData?._id === agency) {
      //             payload.push({
      //               agency_id: agency,
      //               workspace_id: rowData?.workspace_id,
      //             });
      //           }
      //         });
      //       });
      //   }
      // }

      // console.log("Payload...", payload)
      const res = await dispatch(deleteAgency({ agencies: id, delete: true }));
      if (res.payload.success === true) {
        closeModal();
        const reponse = await dispatch(
          getAllAgency({
            ...paginationParams,
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            search: searchTerm,
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  //on chnage event of payment option
  const selectoption = async (data: any) => {
    setSelectedpayment(data);
    setCurrentPagee(1);
  };

  //download sheet
  const agencylistdownload = () => {
    setexelbuttonloadding(true);
    dispatch(allagencylistdownload({ ...paginationParams }))
      .then(async (result: any) => {
        if (allagencylistdownload.fulfilled.match(result)) {
          const blob = await result.payload;
          setexelbuttonloadding(false);
          // Create a URL for the blob data
          const url = window.URL.createObjectURL(
            new Blob([blob], {
              type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            })
          );

          // Create a temporary anchor element
          const a = document.createElement('a');
          a.href = url;

          // Set the filename for the downloaded file
          a.download = 'SuperAdminDetails.xlsx';

          // Programmatically click the anchor element to trigger the download
          a.click();

          // Clean up by revoking the object URL
          window.URL.revokeObjectURL(url);
        }
        console.log(result, 'download sheet');
      })
      .catch((err: any) => {
        setexelbuttonloadding(false);
      });
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    setselectedpeople(null);
    setSelectedpayment(null);
    setselectedindustry(null);
    setReset(true);
    dispatch(
      setAdminPaginationDetails({
        page: 1,
        items_per_page: 10,
        sort_order: 'desc',
        sort_field: 'createdAt',
        search: paginationParams?.search ?? '',
        filter: {
          status: '',
          profession_role: '',
          no_of_people: '',
          date: {
            start_date: null,
            end_date: null,
          },
        },
      })
    );
  };

  // Table Filters
  const AgencyFilters = () => {
    return (
      <>
        <Select
          options={paymentStatusOptions}
          value={selectedpaymnet}
          placeholder="Select a Status"
          // getOptionValue={(option) => option.value}
          className="w-full"
          onChange={selectoption}
          // color="info"
        />

        <Select
          className="w-full"
          onChange={(e) => {
            setselectedindustry(e);
          }}
          placeholder="Select an Industry"
          options={industryOptions}
          value={selectedindustry?.name}
          // color="info"
        />
        {/* <Select
          className='w-full'
          onChange={(e) => { setselectedpeople(e) }}
          placeholder='Select no of employees'
          options={peopleCountOptions}
          value={selectedpeople?.name}
        // color="info"
        /> */}

        <DateFiled
          className="w-full"
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Joining Date"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        />
        <Button
          className={cn('text-xs @lg:w-auto sm:text-sm lg:mt-0')}
          onClick={handleResetFilters}
        >
          Reset
        </Button>
        <Button
          variant="outline"
          className="bg-black text-white"
          onClick={agencylistdownload}
          disabled={exelbuttonloading}
        >
          <PiArrowLineUpBold className="me-1.5 h-[17px] w-[17px]" />
          Export
          {exelbuttonloading && (
            <Spinner
              size="sm"
              tag="div"
              className="ms-3 text-white"
              color="white"
            />
          )}
        </Button>
      </>
    );
  };

  return (
    <>
      <PageHeader title={pageHeader.title}></PageHeader>
      {/* <AgencyTable
        total={agencylistDetails?.data?.page_count}
        loading={loading}
        page={currentPagee}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        data={agencylistDetails?.data?.agencyList}
        filterlist={<AgencyFilters />}
      // scroll={{ x: 1100 }}
      /> */}
      <CustomTable
        data={agencylistDetails?.data?.agencyList || []}
        total={agencylistDetails?.data?.page_count || 1}
        loading={loading}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={GetColumns}
        scroll={{ x: 2000 }}
        filtersList={<AgencyFilters />}
        reset={reset}
        setReset={setReset}
      />
    </>
  );
}
