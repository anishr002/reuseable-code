'use client';

import { PaymentTransactionColumns } from '@/app/shared/(admin)/payment-transaction/columns';
import PageHeader from '@/app/shared/page-header';
import CustomTable from '@/components/common-tables/table';
import DateFiled from '@/components/controlled-table/date-field';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import {
    exportpaymenttransactions,
    getpaymenttransactions,
} from '@/redux/slices/admin/paymentTransactions/paymentTransactionsSlice';
import {
    getAllPlanList,
    removePlanData,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import cn from '@/utils/class-names';
import moment from 'moment';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { PiArrowLineUpBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

const Statusoptions = [
  { name: 'All', value: '' },
  { name: 'Draft', value: 'draft' },
  { name: 'Sent', value: 'sent' },
  { name: 'Agreed', value: 'agreed' },
];

const pageHeader = {
  title: 'Payment Information',
};

export default function PaymentTransactionlistPage() {
  const dispatch = useDispatch();
  const router = useRouter();

  const { paymentDetails, loading, exportLoading } = useSelector(
    (state: any) => state?.root?.paymentTransaction
  );
  const { planList, planListLoading } = useSelector(
    (state: any) => state?.root?.managePlan
  );
  const { plans } = useSelector((state: any) => state?.root?.subscriptionPlan);
  const [pageSize, setPageSize] = useState(10);
  const [subscriptionplan, setsubscriptionplan] = useState<any>(null);
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);

  useEffect(() => {
    // remove plan data on first load if have
    dispatch(removePlanData());
  }, [dispatch]);

  useEffect(() => {
    dispatch(getAllPlanList({ mode: 'all' }));
    return () => {
      dispatch(removePlanData());
    };
  }, [dispatch]);

  useEffect(() => {
    dispatch(
      getpaymenttransactions({
        page: 1,
        items_per_page: 10,
        sort_order: 'desc',
        sort_field: 'createdAt',
        search: undefined,
        filter: {
          plan_id: subscriptionplan?.value || '',
          ...(endRangeDate && endRangeDate != null
            ? {
                date: {
                  start_date:
                    startRangeDate && startRangeDate != null
                      ? moment(startRangeDate).format('DD/MM/YYYY')
                      : null,
                  end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                },
              }
            : {}),
        },
      })
    );
  }, [subscriptionplan, endRangeDate, dispatch]);

  // Subscription Plan options
  let planOptions: Record<string, any>[] = [];
  if (plans && plans?.length > 0) {
    planOptions = plans?.map((plan: Record<string, any>) => {
      return { name: plan?.name, value: plan?._id, key: plan };
    });

    // Add default selection option
    planOptions.unshift({ name: 'Select a Subscription', value: '', key: {} });
  }

  //Paggination Handler
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    const response = await dispatch(
      getpaymenttransactions({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        filter: {
          plan_id: subscriptionplan?.value || '',
          ...(endRangeDate && endRangeDate != null
            ? {
                date: {
                  start_date:
                    startRangeDate && startRangeDate != null
                      ? moment(startRangeDate).format('DD/MM/YYYY')
                      : null,
                  end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                },
              }
            : {}),
        },
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getpaymenttransactions({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          filter: {
            plan_id: subscriptionplan?.value || '',
            ...(endRangeDate && endRangeDate != null
              ? {
                  date: {
                    start_date:
                      startRangeDate && startRangeDate != null
                        ? moment(startRangeDate).format('DD/MM/YYYY')
                        : null,
                    end_date: moment(endRangeDate).format('DD/MM/YYYY'),
                  },
                }
              : {}),
          },
        })
      );
      return data?.transactions;
    }
    return data?.transactions;
  };

  // Delete Handler
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number
  ) => {
    // try {
    //     const res = await dispatch(deleteAgencyAgreement({ agreementIdsToDelete: id }));
    //     if (res.payload.success === true) {
    //         const reponse = await dispatch(getAllAgencyagreement({ page: currentPage, items_per_page: countPerPage, sort_field: 'createdAt', sort_order: 'desc' }));
    //     }
    // } catch (error) {
    //     console.error(error);
    // }
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    setsubscriptionplan(null);
  };

  //download sheet
  const DownloadpaymentInformation = () => {
    dispatch(exportpaymenttransactions()).then(async (result: any) => {
      if (exportpaymenttransactions.fulfilled.match(result)) {
        const blob = await result.payload;

        // Create a URL for the blob data
        const url = window.URL.createObjectURL(
          new Blob([blob], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          })
        );

        // Create a temporary anchor element
        const a = document.createElement('a');
        a.href = url;

        // Set the filename for the downloaded file
        a.download = 'Payment_Information.xlsx';

        // Programmatically click the anchor element to trigger the download
        a.click();

        // Clean up by revoking the object URL
        window.URL.revokeObjectURL(url);
      }
      // console.log(result, 'download sheet');
    });
  };

  // Table Filters
  const PaymentFilters = () => {
    return (
      <>
        <Select
          className="w-full"
          onChange={(e) => {
            setsubscriptionplan(e);
          }}
          placeholder="Select a Subscription"
          options={planOptions}
          value={subscriptionplan?.name}
          // color="info"
        />

        <DateFiled
          className="w-full"
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Select Date in a Range"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        />
        <Button
          className={cn('text-xs @lg:w-auto sm:text-sm lg:mt-0')}
          onClick={handleResetFilters}
        >
          Reset
        </Button>
        <Button
          variant="outline"
          className="bg-black text-white"
          onClick={DownloadpaymentInformation}
          disabled={exportLoading}
        >
          <PiArrowLineUpBold className="me-1.5 h-[17px] w-[17px]" />
          Export
          {exportLoading && (
            <Spinner size="sm" tag="div" className="ms-3 text-white" />
          )}
        </Button>
      </>
    );
  };

  return (
    <>
      {/* <h1>Aggrement</h1> */}
      <PageHeader title={pageHeader.title} />
      <CustomTable
        data={paymentDetails?.data?.transactions || []}
        total={paymentDetails?.data?.page_count || 1}
        loading={loading}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={PaymentTransactionColumns}
        scroll={{ x: 0 }}
        filtersList={<PaymentFilters />}
      />
    </>
  );
}
