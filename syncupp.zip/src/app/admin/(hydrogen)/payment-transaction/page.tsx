
import { metaObject } from '@/config/site.config';
import PaymentTransactionlistPage from './main-page';

export const metadata = {
    ...metaObject('Payment Information'),
};

export default function FaqsPage() {
    return (
        <>
            <PaymentTransactionlistPage />
        </>
    );
}
