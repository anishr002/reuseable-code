"use client";

import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import { deleteAgencyAgreement, getAllAgencyagreement } from '@/redux/slices/user/agreement/agreementSlice';
import PageHeader from '@/app/shared/page-header';
import { PaymentTransactionColumns } from '@/app/shared/(admin)/payment-transaction/columns';
import { getpaymentSubtransactions } from '@/redux/slices/admin/paymentTransactions/paymentTransactionsSlice';
import CustomTable from './popup-custom-table';
import { PaymentSubTransactionColumns } from '@/app/shared/(admin)/payment-transaction/popup-columns';
import Spinner from '@/components/ui/spinner';
import { ActionIcon } from 'rizzui';
import { PiXBold } from 'react-icons/pi';
import { useModal } from '@/app/shared/modal-views/use-modal';


const DummyData = [{
    name: "Payment Information",
    date: "12/12/2023",
    form_of_payment: "Credit card",
    subscription_plan: "Platinum",
    transaction_id: "T1234-5678-9012-3456",
    status: "Success"
}, {
    name: "Payment Information",
    date: "12/12/2023",
    form_of_payment: "Credit card",
    subscription_plan: "Platinum",
    transaction_id: "T1234-5678-9012-3456",
    status: "Success"
}]

const pageHeader = {
    title: 'Payment Information',
};


export default function PaymentTransactionSublistPage(props: any) {

    const { subscription_id, agency_id } = props

    const dispatch = useDispatch();
    const router = useRouter();
    const { closeModal } = useModal();


    const { paymentsubTransactions, loading } = useSelector((state: any) => state?.root?.paymentTransaction);
    // console.log("paymentsubTransactions", paymentsubTransactions, loading);

    const [pageSize, setPageSize] = useState(10)


    useEffect(() => {
        dispatch(getpaymentSubtransactions({ subscription_id, agency_id }));
    }, [])


    return (
        <>
            {loading ? <div className='p-10 flex items-center justify-center'>
                <Spinner size="xl" tag='div' />
            </div> : <div className='p-10'>
                <PageHeader title={pageHeader.title} >
                    <ActionIcon
                        size="sm"
                        variant="text"
                        onClick={() => closeModal()}
                        className="p-0 text-gray-500 hover:!text-gray-900"
                    >
                        <PiXBold className="h-[18px] w-[18px]" />
                    </ActionIcon>
                </PageHeader>
                <CustomTable
                    data={paymentsubTransactions?.data?.transactions || []}
                    total={paymentsubTransactions?.data?.page_count || 1}
                    loading={loading}
                    pageSize={pageSize}
                    setPageSize={setPageSize}
                    // handleChangePage={handleChangePage}
                    getColumns={PaymentSubTransactionColumns}
                />
            </div>}
        </>
    )

}