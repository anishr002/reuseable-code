"use client";

import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import CustomTable from '@/components/common-tables/table';
import { deleteAgencyAgreement, getAllAgencyagreement } from '@/redux/slices/user/agreement/agreementSlice';
import PageHeader from '@/app/shared/page-header';
import { PaymentTransactionColumns } from '@/app/shared/(admin)/payment-transaction/columns';
import { getpaymenttransactions } from '@/redux/slices/admin/paymentTransactions/paymentTransactionsSlice';
import { PayoutColumns } from '@/app/shared/(admin)/payout-requests/columns';
import Select from '@/components/ui/select';
import { getrequestedpayouts, setPagginationParams } from '@/redux/slices/admin/payoutRequests/payoutRequestsSlice';

const Statusoptions = [
    { name: 'All', value: 'All' },
    { name: 'Paid', value: 'paid' },
    { name: 'Pay request', value: 'unpaid' },
]


const pageHeader = {
    title: `Payout Requests`,
};


export default function PayoutlistPage() {

    const dispatch = useDispatch();
    const router = useRouter();

    const { payoutDetails, loading, paginationParams } = useSelector((state: any) => state?.root?.payout);
    console.log("payoutDetails", payoutDetails, loading);

    const [pageSize, setPageSize] = useState(10)
    const [statusname, setstatusname] = useState<any>('All')

    useEffect(() => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;
        dispatch(getrequestedpayouts({ page, items_per_page, sort_field, sort_order, search, payout_requested: statusname?.value }));
    }, [statusname])

    //Paggination Handler
    const handleChangePage = async (paginationParams: any) => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;
        dispatch(setPagginationParams(paginationParams))
        const response = await dispatch(getrequestedpayouts({ page, items_per_page, sort_field, sort_order, search, payout_requested: statusname?.value }));
        const { data } = response?.payload;
        const maxPage: number = data?.page_count;

        if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            await dispatch(getrequestedpayouts({ page, items_per_page, sort_field, sort_order, search, payout_requested: statusname?.value }));
            return data?.client
        }
        return data?.client
    };


    // Table Filters 
    const PayoutsFilters = () => {
        return (
            <>
                <Select
                    className='w-full'
                    onChange={(e) => {
                        setstatusname(e);
                    }}
                    placeholder='Select a Status'
                    options={Statusoptions}
                    value={statusname?.name}
                    color="info"
                />

            </>
        )
    }


    return (
        <>
            {/* <h1>Aggrement</h1> */}
            <PageHeader title={pageHeader.title} />
            <CustomTable
                data={payoutDetails?.data?.pendingPayout || []}
                total={payoutDetails?.data?.page_count || 1}
                loading={loading}
                pageSize={pageSize}
                setPageSize={setPageSize}
                // handleDeleteById={handleDeleteById}
                filtersList={<PayoutsFilters />}
                handleChangePage={handleChangePage}
                getColumns={PayoutColumns}
                scroll={{ x: 0 }}
            />
        </>
    )

}