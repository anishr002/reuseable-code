
import { metaObject } from '@/config/site.config';
import PayoutlistPage from './main-page';

export const metadata = {
    ...metaObject(`Payout Requests`),
};

export default function FaqsPage() {
    return (
        <>
            <PayoutlistPage />
        </>
    );
}
