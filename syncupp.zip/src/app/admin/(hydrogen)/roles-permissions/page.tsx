import { metaObject } from '@/config/site.config';
import RolePermissionPage from './main-page';

export const metadata = {
    ...metaObject('Roles & Permissions'),
};

export default function Page() {
    return (
        <>
            <RolePermissionPage />
        </>
    );
}
