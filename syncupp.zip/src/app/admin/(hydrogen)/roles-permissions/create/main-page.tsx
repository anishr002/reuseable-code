'use client';

import CreateRole from '@/app/shared/(admin)/roles-permissions/create-role';
import PageHeader from '@/app/shared/page-header';


const pageHeader = {
  title: 'Create Role',
};

const MainPage = () => {

  return (
    <>
      <PageHeader title={pageHeader.title}></PageHeader>
      <CreateRole />
    </>
  );
};

export default MainPage;
