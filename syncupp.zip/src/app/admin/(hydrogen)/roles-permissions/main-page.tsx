'use client';

import PageHeader from '@/app/shared/page-header';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { PiPlusBold } from 'react-icons/pi';
import { useSelector, useDispatch } from 'react-redux';
import RoleCard from '@/app/shared/(admin)/roles-permissions/role-card';
import { useEffect } from 'react';
import Spinner from '@/components/ui/spinner';
import { Empty } from '@/components/ui/empty';
import { routes } from '@/config/routes';
import {
  deleteSubRole,
  getRolesList,
} from '@/redux/slices/admin/roles-permissions/rolePermissionSlice';
import { checkPermission } from '@/app/shared/(admin)/roles-permissions/utils';
// import { checkPermission } from "@/app/shared/(user)/roles-permissions/utils";

const pageHeader = {
  title: 'Roles & Permissions',
};

const RolePermissionPage = () => {
  const dispatch = useDispatch();
  const { getRolesListLoader, getRolesListData } = useSelector(
    (state: any) => state?.root?.adminRole
  );
  const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
  const roleData = userData?.data?.user?.role;

  const canEdit = roleData?.sub_role === 'super_admin' ? true :
    checkPermission(
      'roles_permissions',
      'update',
      roleData?.permissions
    )

    const canDelete = roleData?.sub_role === 'super_admin' ? true :
    checkPermission(
      'roles_permissions',
      'delete',
      roleData?.permissions
    )

  // Component init
  useEffect(() => {
    dispatch(getRolesList());
  }, [dispatch]);

  // Delete role API calling
  const deleteRole = (id: string) => {
    dispatch(deleteSubRole(id)).then((result: any) => {
      if (deleteSubRole.fulfilled.match(result)) {
        if (result.payload.success === true) {
          dispatch(getRolesList());
        }
      }
    });
  };
  
  return (
    <>
      <PageHeader title={pageHeader.title} className="poppins_font_number">
        {(roleData?.sub_role === 'super_admin' ? true :
          checkPermission(
            'roles_permissions',
            'create',
            roleData?.permissions
          )) && (
            <div className="mt-4 flex items-center gap-3 @lg:mt-0">
              <Link href={routes.admin.rolePermissionCreate}>
                <Button className="flex h-10 items-center justify-center gap-2 bg-[#8C80D2] text-sm text-white">
                  <PiPlusBold className="me-1.5 h-[17px] w-[17px]" />
                  Create Role
                </Button>
              </Link>
            </div>
          )}
      </PageHeader>
      {getRolesListLoader && (
        <div className="flex items-center justify-center">
          <Spinner size="xl" tag="div" />
        </div>
      )}
      {!getRolesListLoader && getRolesListData?.length === 0 && (
        <div className="flex items-center justify-center ">
          <div className="flex flex-col items-center justify-center gap-2">
            <Empty />{' '}
            <p className="poppins_font_number mt-3 w-full text-center text-[15px] font-semibold">
              You currently don’t have any role.
            </p>
          </div>
        </div>
      )}
      {!getRolesListLoader && getRolesListData?.length > 0 && (
        <div className="@container">
          <div className="grid grid-cols-1 gap-6 @[36.65rem]:grid-cols-2 @[56rem]:grid-cols-3 @[78.5rem]:grid-cols-4 @[100rem]:grid-cols-5">
            {getRolesListData?.map((permission: any) => (
              <RoleCard
                key={permission?._id}
                roleName={permission?.sub_role}
                data={permission}
                canEdit={canEdit}
                canDelete={canDelete}
                deleteRole={deleteRole}
                roleData={roleData}
              />
            ))}
          </div>
        </div>
      )}
    </>
  );
};

export default RolePermissionPage;
