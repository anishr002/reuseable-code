import { metaObject } from '@/config/site.config';
import SubscriptionPage from './main-page';

export const metadata = {
  ...metaObject('Subscription Plan'),
};

export default function ViewProfile() {
  return <SubscriptionPage />;
}
