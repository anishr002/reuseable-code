'use client';
import { GetSubscriptionPlanColumns } from '@/app/shared/(admin)/subscription-plan/column';
import CustomSubscriptionPlanForm from '@/app/shared/(admin)/subscription-plan/custom-subscription-plan-form';
import SubscriptionPlanForm, {
  currencyOptionsDropdown,
  planTypeOptionsDropdown,
  userCountOptionsDropdown,
} from '@/app/shared/(admin)/subscription-plan/subscription-plan-form';
import ModalButton from '@/app/shared/modal-button';
import PageHeader from '@/app/shared/page-header';
import CustomTable from '@/components/common-tables/table';
import Select from '@/components/ui/select';
import {
  deleteSubscriptionPlan,
  getAllSubscriptionPlan,
  removePlanData,
  removePlanListData,
  setPlansPaginationParams,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import cn from '@/utils/class-names';
import { useEffect, useState } from 'react';
import { PiCaretDownBold, PiPlusBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

export const subscriptionPlanStatusOptionsDropdown: Record<string, any>[] = [
  { name: 'Active', value: 'active' },
  { name: 'Inactive', value: 'inactive' },
];

const pageHeader = {
  title: 'Subscription Plan',
};

function SubscriptionPage() {
  const dispatch = useDispatch();
  const { loading, data, paginationParams } = useSelector(
    (state: any) => state?.root?.subscriptionPlan
  );
  const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
  const roleData = userData?.data?.user?.role;

  const [pageSize, setPageSize] = useState<number>(10);
  const [planType, setPlanType] = useState<string>('');
  const [userCount, setUserCount] = useState<any>('');
  const [currencyType, setCurrencyType] = useState<string>('');
  const [active, setActive] = useState<any>('');
  const [reset, setReset] = useState<boolean>(false);

  useEffect(() => {
    // remove plan data on first load if have
    dispatch(removePlanData());
  }, [dispatch]);

  useEffect(() => {
    if (
      planType !== '' ||
      userCount !== '' ||
      currencyType !== '' ||
      active !== ''
    ) {
      dispatch(removePlanListData());
      dispatch(
        getAllSubscriptionPlan({
          page: 1,
          items_per_page: 10,
          sort_field: 'createdAt',
          sort_order: 'desc',
          search: '',
          filter: {
            plan_type: planType,
            no_of_users: userCount !== '' ? Number(userCount) : '',
            currency: currencyType,
            active: active,
          },
        })
      );
      // setting filter pagination params
      dispatch(
        setPlansPaginationParams({
          ...paginationParams,
          filter: {
            plan_type: planType,
            no_of_users: userCount !== '' ? Number(userCount) : '',
            currency: currencyType,
            active: active,
          },
        })
      );
    } else {
      setReset(false);
    }
  }, [pageSize, planType, userCount, currencyType, active, dispatch]);

  useEffect(() => {
    // clear data on unmount component.
    return () => {
      dispatch(removePlanListData());
      dispatch(setPlansPaginationParams(null));
    };
  }, [dispatch]);

  const handleResetFilters = () => {
    setPlanType('');
    setUserCount('');
    setCurrencyType('');
    setActive('');
    setReset(true);
    dispatch(removePlanListData());
    dispatch(
      getAllSubscriptionPlan({
        page: 1,
        items_per_page: 10,
        sort_order: 'desc',
        sort_field: 'createdAt',
        search: paginationParams?.search ?? '',
        filter: {
          plan_type: '',
          no_of_users: '',
          currency: '',
          active: '',
        },
      })
    );
  };

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    // store plans paginagion params to use further in application
    dispatch(
      setPlansPaginationParams({
        ...paginationParams,
        filter: {
          plan_type: planType,
          no_of_users: userCount !== '' ? Number(userCount) : '',
          currency: currencyType,
          active: active,
        },
      })
    );
    const response = await dispatch(
      getAllSubscriptionPlan({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        filter: {
          plan_type: planType,
          no_of_users: userCount !== '' ? Number(userCount) : '',
          currency: currencyType,
          active: active,
        },
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllSubscriptionPlan({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          filter: {
            plan_type: planType,
            no_of_users: userCount !== '' ? Number(userCount) : '',
            currency: currencyType,
            active: active,
          },
        })
      );
      return data?.subscription_plans;
    }
    if (data?.subscription_plans?.length !== 0) {
      return data?.subscription_plans;  
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      const res = await dispatch(deleteSubscriptionPlan({ planId: id }));
      if (res?.payload?.success === true) {
        const reponse = await dispatch(
          getAllSubscriptionPlan({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            search: searchTerm,
            pagination: true,
            filter: {
              plan_type: planType,
              no_of_users: userCount !== '' ? Number(userCount) : '',
              currency: currencyType,
              active: active,
            },
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Table Filters
  const SubscriptionPlanFilters = () => {
    return (
      <>
        <Select
          // size="sm"
          value={planType}
          onChange={(selectedOption: any) => {
            setPlanType(selectedOption);
          }}
          options={planTypeOptionsDropdown}
          placeholder="Select Plan Type"
          getOptionValue={(option) => option?.value}
          getOptionDisplayValue={(option: any) => option?.name}
          displayValue={(value) => {
            const displayValue = planTypeOptionsDropdown?.find(
              (option: any) => option?.value === value
            );
            return displayValue ? displayValue?.name : '';
          }}
          dropdownClassName="poppins_font_number"
          selectClassName="poppins_font_number"
          suffix={<PiCaretDownBold className="h-3 w-3" />}
        />
        <Select
          // size="sm"
          value={userCount}
          onChange={(selectedOption: any) => {
            setUserCount(selectedOption);
          }}
          options={userCountOptionsDropdown}
          placeholder="Select number of users"
          getOptionValue={(option) => option?.value}
          getOptionDisplayValue={(option: any) => option?.name}
          displayValue={(value) => {
            const displayValue = userCountOptionsDropdown?.find(
              (option: any) => option?.value === value
            );
            return displayValue ? displayValue?.name : '';
          }}
          dropdownClassName="poppins_font_number"
          selectClassName="poppins_font_number"
          suffix={<PiCaretDownBold className="h-3 w-3" />}
        />
        <Select
          // size="sm"
          value={currencyType}
          onChange={(selectedOption: any) => {
            setCurrencyType(selectedOption);
          }}
          options={currencyOptionsDropdown}
          placeholder="Select Currency"
          getOptionValue={(option) => option?.value}
          getOptionDisplayValue={(option: any) => option?.name}
          displayValue={(value) => {
            const displayValue = currencyOptionsDropdown?.find(
              (option: any) => option?.value === value
            );
            return displayValue ? displayValue?.name : '';
          }}
          dropdownClassName="poppins_font_number"
          selectClassName="poppins_font_number"
          suffix={<PiCaretDownBold className="h-3 w-3" />}
        />
        <Select
          // size="sm"
          value={active}
          onChange={(selectedOption: any) => {
            setActive(selectedOption);
          }}
          options={subscriptionPlanStatusOptionsDropdown}
          placeholder="Select Status"
          getOptionValue={(option) => option?.value}
          getOptionDisplayValue={(option: any) => option?.name}
          displayValue={(value) => {
            const displayValue = subscriptionPlanStatusOptionsDropdown?.find(
              (option: any) => option?.value === value
            );
            return displayValue ? displayValue?.name : '';
          }}
          dropdownClassName="poppins_font_number"
          selectClassName="poppins_font_number"
          suffix={<PiCaretDownBold className="h-3 w-3" />}
        />
        <Button
          className={cn('text-xs @lg:w-auto sm:text-sm lg:mt-0')}
          onClick={handleResetFilters}
        >
          Reset
        </Button>
      </>
    );
  };

  return (
    <>
      <PageHeader title={pageHeader.title}>
        {roleData?.sub_role === 'super_admin' && (
          <div className="mt-4 flex items-center gap-3 @lg:mt-0">
            <ModalButton
              label="Standard Plan"
              view={<SubscriptionPlanForm title="New Plan" />}
              customSize="600px"
              className="mt-0 w-full bg-[#53216F] hover:bg-[#8e45b8] @lg:w-auto dark:bg-gray-100 dark:text-white dark:hover:bg-gray-200 dark:active:bg-gray-100"
              icon={<PiPlusBold className="me-1.5 h-[17px] w-[17px]" />}
            />
            <ModalButton
              label="Custom Plan"
              view={<CustomSubscriptionPlanForm title="New Plan" />}
              customSize="600px"
              className="mt-0 w-full bg-[#53216F] hover:bg-[#8e45b8] @lg:w-auto dark:bg-gray-100 dark:text-white dark:hover:bg-gray-200 dark:active:bg-gray-100"
              icon={<PiPlusBold className="me-1.5 h-[17px] w-[17px]" />}
            />
          </div>
        )}
      </PageHeader>
      <CustomTable
        data={data?.subscription_plans ?? []}
        total={data?.page_count ?? 1}
        loading={loading}
        pageSize={pageSize}
        setPageSize={setPageSize}
        handleDeleteById={handleDeleteById}
        handleChangePage={handleChangePage}
        getColumns={GetSubscriptionPlanColumns}
        scroll={{ x: 900 }}
        filtersList={<SubscriptionPlanFilters />}
        reset={reset}
        setReset={setReset}
      />
    </>
  );
}

export default SubscriptionPage;
