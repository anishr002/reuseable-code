import AuthWrapperTwo from '@/app/shared/(admin)/auth-layout/auth-wrapper-two';

import { metaObject } from '@/config/site.config';
import ResetPasswordForm from '../reset-password/reset-password-form';

export const metadata = {
  ...metaObject('Set Password - Admin'),
};


export default function ForgotPassword() {
  return (
    <AuthWrapperTwo title="Set your Password">
      <ResetPasswordForm resetpass={false}/>
    </AuthWrapperTwo>
  );
}
