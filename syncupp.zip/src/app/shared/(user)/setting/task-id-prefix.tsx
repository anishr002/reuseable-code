'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon } from '@/components/ui/text';
import {
  getHolidayData,
  getSettingData,
  updateTaskIdPrefix,
} from '@/redux/slices/user/setting/settingSlice';
import { handleKeyDown } from '@/utils/common-functions';
import { useForm } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';

interface TaskprefixProps {
  title: string;
}

interface TaskPrefixFormData {
  task_prefix?: string;
}

const TaskIdPrefix = ({ title }: TaskprefixProps) => {
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const { settingData, taskIdPrefixLoading } = useSelector(
    (state: any) => state?.root?.setting
  );
  const {
    register,
    formState: { errors },
    handleSubmit,
    reset,
  } = useForm<TaskPrefixFormData>({
    mode: 'onChange',
    defaultValues: {
      task_prefix: settingData?.task?.task_prefix
        ? settingData?.task?.task_prefix
        : '',
    },
  });

  console.log(settingData, 'settingDatasettingData');

  const onSubmit = async (data: TaskPrefixFormData) => {
    const payload = {
      task_prefix: data.task_prefix || '', // Allow empty value
    };

    console.log(payload, 'payloadpayloadpayloadpayload');
    await dispatch(updateTaskIdPrefix(payload)).then((result: any) => {
      if (updateTaskIdPrefix.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getSettingData());
          closeModal();
        }
      }
    });
  };

  return (
    <div className="mb-3 flex flex-col p-4">
      <div className="flex items-center justify-between">
        <div className="text-xl font-bold text-[#120425] xl:text-2xl">
          {title}
        </div>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={closeModal}
          className="text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>

      {/* Form */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="mt-4 flex flex-col items-baseline gap-2 md:flex-row"
      >
        {/* Task id prefix Field */}
        <div className="w-full">
          <Input
            type="text"
            placeholder="Enter task id prefix"
            onKeyDown={handleKeyDown}
            {...register('task_prefix', {
              validate: (value: any) =>
                value === '' ||
                /^[a-zA-Z0-9]{3}$/.test(value) ||
                'Prefix must be exactly 3 alphanumeric characters (e.g., A2b).',
            })}
            className="w-full"
            inputClassName="text-black poppins_font_number"
          />
          <p className="mt-1 min-h-3 text-xs text-red-500">
            {errors?.task_prefix?.message as string}
          </p>
        </div>

        {/* Submit Button */}
        <div className="w-full md:w-auto">
          <Button
            disabled={taskIdPrefixLoading}
            className="mr-1 w-auto rounded-[8px] bg-[#7667CF] p-[12px] font-['Raleway'] text-[14px] font-[400] leading-[19.6px] text-white"
            type="submit"
          >
            Save
            {taskIdPrefixLoading && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default TaskIdPrefix;
