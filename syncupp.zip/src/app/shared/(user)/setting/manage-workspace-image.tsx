'use client'
import { useModal } from '@/app/shared/modal-views/use-modal';
import TrashIcon from '@/components/icons/trash';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  getDefalutInvoiceImage,
  uploadDefalutInvoiceLogo,
} from '@/redux/slices/user/setting/settingSlice';
import { invoiceLogoSchema } from '@/utils/validators/invoice-logo.schema';
import DefaultInvoiceLog from '@public/assets/images/DefaultInvoiceLog.svg';
import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import { toast } from 'react-hot-toast';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';

export const imageFileType = ['jpg', 'jpeg', 'png'];

function ManageWorkspaceImage(props: any) {
  const { title } = props;
  const dispatch = useDispatch();
  const imageInputRef = useRef<HTMLInputElement>(null);
  const { closeModal } = useModal();
  const [filePreview, SetFilePreview] = useState<any>();
  const [selectedFile, SetSelectedFile] = useState<any>(false);
  const {
    uploadDefalutInvoiceLogoLoading,
    getDefalutInvoiceImageLoading,
    invoiceLogoURL,
  } = useSelector((state: any) => state?.root?.setting);

  useEffect(() => {
    dispatch(getDefalutInvoiceImage());
  }, []);

  useEffect(() => {
    SetFilePreview(invoiceLogoURL?.invoice?.logo);
  }, [invoiceLogoURL]);


  const initialValues = {
    invoice_logo: invoiceLogoURL?.invoice?.logo ?? '',
  };


  const removePicture = (setValue: any) => {
    if (selectedFile) {
      SetSelectedFile(false);
      SetFilePreview(invoiceLogoURL?.invoice?.logo);
      setValue('invoice_logo', invoiceLogoURL?.invoice?.logo);
    } else {
      setValue('invoice_logo', '');
      SetFilePreview(undefined);
      SetSelectedFile(undefined);
    }
  };

  const handleImageChange = (event: any, setValue: any) => {
    const file = event.target.files[0];
    const extension = file?.name?.split('.')?.pop()?.toLowerCase();

    
    if (!imageFileType.includes(extension)) {
      toast.error(`${extension} not support in images`);
      return;
    }
    

    if (file) {
      setValue('invoice_logo', file);
      SetFilePreview(URL.createObjectURL(file));
      SetSelectedFile(true);
    }
  };

  const onSubmit = (data: any) => {
    const form: any = new FormData();
    form.append('invoice_logo', data?.invoice_logo);

    dispatch(uploadDefalutInvoiceLogo(form))?.then((result: any) => {
      if (uploadDefalutInvoiceLogo.fulfilled.match(result)) {
        dispatch(getDefalutInvoiceImage());
        closeModal();
      }
    });
  };
  return (
    <>
      <Form
        validationSchema={invoiceLogoSchema}
        onSubmit={onSubmit}
        useFormProps={{
          defaultValues: initialValues,
          mode: 'all',
        }}
        className=" p-10 [&_label]:font-medium"
      >
        {({
          register,
          control,
          formState: { errors, isDirty, isValid },
          setValue,
        }) => (
          <>
            <div className="space-y-5">
              <div className="mb-6 flex items-center justify-between">
                <Title
                  as="h3"
                  className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
                >
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>

              <div className="flex flex-col items-center justify-start lg:flex-row">
                {!filePreview && (
                  <>
                    <div
                      className="h-36 w-36 cursor-pointer rounded-full border-2 border-dashed border-[#9BA1B9] p-12"
                      onClick={() => imageInputRef?.current?.click()}
                    >
                      <Image
                        src={
                          filePreview
                            ? process.env.NEXT_PUBLIC_IMAGE_URL +
                              '/' +
                              filePreview
                            : DefaultInvoiceLog
                        }
                        alt="Description of image"
                        width={40}
                        height={40}
                        className="cursor-pointer rounded-md"
                      />
                    </div>

                    <div className="mt-4 flex flex-col items-center justify-start text-center lg:ms-4 lg:mt-0 lg:items-start lg:text-left">
                      <span className="text-[20px] font-semibold text-[#8C80D2]">
                        Upload  Logo
                      </span>
                    </div>
                  </>
                )}

                {filePreview && (
                  <>
                    <div
                      className="h-36 w-36 cursor-pointer overflow-hidden rounded-full border-2 border-dashed border-[#9BA1B9]"
                      onClick={() => imageInputRef?.current?.click()}
                    >
                      <img
                        src={
                          filePreview
                            ? selectedFile
                              ? filePreview
                              : process.env.NEXT_PUBLIC_IMAGE_URL +
                                '/' +
                                filePreview
                            : process.env.NEXT_PUBLIC_IMAGE_URL +
                              '/' +
                              invoiceLogoURL?.invoice?.logo
                        }
                        alt="Profile Image"
                        className="h-full w-full cursor-pointer rounded-md"
                      />
                    </div>
                    <div className="mt-4 flex items-center justify-start text-center lg:ms-4 lg:mt-0 lg:items-start lg:text-left">
                      <Button
                        className="bg-[#8C80D2] text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                        onClick={() => imageInputRef?.current?.click()}
                        type="button"
                      >
                        Change Picture
                      </Button>
                      <Button
                        type="button"
                        onClick={() => removePicture(setValue)}
                        className="ml-1 bg-[#8C80D2] text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                      >
                        <TrashIcon className="h-4 w-4 cursor-pointer" />
                      </Button>
                    </div>
                  </>
                )}
                <p className="ml-2 text-red-700">
                  {errors?.invoice_logo?.message as string}
                </p>
              </div>

              <input
                {...register('invoice_logo')}
                type="file"
                onChange={(e) => handleImageChange(e, setValue)}
                accept=".jpeg, .jpg, .png"
                style={{ display: 'none' }}
                ref={imageInputRef}
              />
            </div>
            <div className="mt-2 lg:mt-16">
              <Button
                disabled={uploadDefalutInvoiceLogoLoading}
                className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                type="submit"
                size="xl"
              >
                <span>Save Changes</span>
                {uploadDefalutInvoiceLogoLoading && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
            </div>
          </>
        )}
      </Form>
    </>
  );
}

export default ManageWorkspaceImage;
