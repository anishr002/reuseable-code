import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  getSettingData,
  setTimeTracking,
} from '@/redux/slices/user/setting/settingSlice';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { CiViewTimeline } from 'react-icons/ci';
import { FaRegTimesCircle } from 'react-icons/fa';
import { IoIosTimer } from 'react-icons/io';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox } from '@/components/ui/checkbox';

const TimeTrackingSetting = (props: any) => {
  const { title } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();

  const { control, handleSubmit, setValue } = useForm();
  const [selectedTimeTracking, setSelectedTimeTracking] = useState<any>([]);
  const [memberCanEdit, setMemberCanEdit] = useState<any>(false);

  const { settingData, setTimeTrackingLoading, getSettingDataLoading } =
    useSelector((state: any) => state?.root?.setting);

  const timeTrackingOption = [
    // {
    //   label: 'No Time Tracking',
    //   value: '',
    // },
    {
      label: 'Manual',
      value: 'manual',
    },
    {
      label: 'Timer',
      value: 'clocking',
    },
  ];

  // Init API called to get time traking history
  useEffect(() => {
    dispatch(getSettingData());
  }, [dispatch]);

  useEffect(() => {
    if (settingData?.task?.time_tracking?.length > 0) {
      setSelectedTimeTracking(settingData?.task?.time_tracking);
      setMemberCanEdit(settingData?.task?.member_can_edit);
      setValue('time_tracking', settingData?.task?.time_tracking);
    }
  }, [setValue, settingData]);

  const onSubmit = (data: any) => {

    if(selectedTimeTracking?.length === 0) { 
      setMemberCanEdit(false);
    }

    dispatch(setTimeTracking({ time_tracking: selectedTimeTracking, member_can_edit: memberCanEdit })).then((result: any) => {
      if (setTimeTracking.fulfilled.match(result)) {
        if (result?.payload?.success) {
          closeModal();
        }
      }
    });
  };

  const handleCheckboxSelection = (value: any) => {
    if (selectedTimeTracking.includes(value)) {
      const filterSetting = selectedTimeTracking.filter((data: any) => data !== value);
      setSelectedTimeTracking(filterSetting);
    } else {
      setSelectedTimeTracking([...selectedTimeTracking, value]);
    }
  }

  return (
    <>
      <div className="mb-3 flex justify-between p-4">
        <div className="flex items-center justify-center text-xl font-bold text-[#120425] xl:text-2xl">
          {title}
        </div>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="px-10 pb-10 [&_label]:font-medium"
      >
        <div className="space-y-4">
          {getSettingDataLoading && (
            <div className="!grid h-full min-h-[128px] flex-grow place-content-center items-center justify-center">
              <Spinner size="xl" />
            </div>
          )}
          {!getSettingDataLoading && (
            <div className="flex flex-row">
              {timeTrackingOption?.map((data: any) => (
                <div
                  key={data?.value}
                  className="mb-2 w-[100%] p-1 cursor-pointer"
                  onClick={(e) => (
                    handleCheckboxSelection(data?.value)
                  )}
                >
                  <div
                    className={`w-full rounded-3xl border p-5 ${selectedTimeTracking.includes(data?.value)
                      ? 'border-[#8C80D2] bg-[#F7F6FF]'
                      : 'border-[#9BA1B9] bg-[#FFFFFF]'
                      }`}
                  >
                    <div className="flex">
                      <span
                        className={
                          'me-5 flex items-center rounded-[14px] p-1 text-gray-0 dark:text-gray-900'
                        }
                      >
                        {data?.value === '' && (
                          <FaRegTimesCircle className="h-[30px] w-[30px] text-[#9BA1B9]" />
                        )}
                        {data?.value === 'manual' && (
                          <CiViewTimeline className="h-[30px] w-[30px] text-[#9BA1B9]" />
                        )}
                        {data?.value === 'clocking' && (
                          <IoIosTimer className="h-[30px] w-[30px] text-[#9BA1B9]" />
                        )}
                      </span>
                      <div className="w-full">
                        <div className="flex content-center justify-end">
                          <Controller
                            name="time_tracking"
                            control={control}
                            defaultValue=""
                            render={({ field }) => (
                              <Checkbox
                                inputClassName="checkbox-color"
                                {...field}
                                value={data?.value}
                                checked={selectedTimeTracking.includes(data?.value)}
                                onClick={(e) => e.stopPropagation()}
                                className="text-[14px] font-bold text-[#9BA1B9]"
                              />

                              // <input
                              //   className="ms-2"
                              //   type="checkbox"
                              //   {...field}
                              //   value={selectedTimeTracking}
                              //   checked={field.value === data?.value}
                              // />
                            )}
                          />
                        </div>
                        <Title
                          as="h3"
                          className="mb-1 text-sm	font-bold text-[#9BA1B9] md:text-lg"
                        >
                          {data?.label}
                        </Title>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          {
            !getSettingDataLoading && (
              <>
                <div>
                  <span className='font-semibold'>
                    Permission
                  </span>
                </div>
                <div className='flex items-center justify-between'>
                  <span className='font-semibold'>
                    Modify the tracked hour
                  </span>
                  <Checkbox
                    inputClassName="checkbox-color"
                    className="text-[14px] font-bold text-[#9BA1B9]"
                    disabled={selectedTimeTracking?.length === 0}
                    checked={memberCanEdit}
                    onClick={() => setMemberCanEdit(!memberCanEdit)}
                  />
                </div>
              </>
            )
          }
        </div>
        <div className="mt-4">
          <Button
            className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[150px]"
            type="submit"
            size="xl"
          >
            <span>Save</span>
            {setTimeTrackingLoading && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
      </form>
    </>
  );
};

export default TimeTrackingSetting;
