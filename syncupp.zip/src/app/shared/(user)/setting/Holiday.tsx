'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import CustomTable from '@/components/common-tables/table';
import { Button } from '@/components/ui/button';
import { DatePicker } from '@/components/ui/datepicker';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon } from '@/components/ui/text';
import { messages } from '@/config/messages';
import { createHoliday, deleteHoliday, getHolidayData, setEditValue } from '@/redux/slices/user/setting/settingSlice';
import { handleKeyDown } from '@/utils/common-functions';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { GetHolidayColumns } from './columns';

interface HolidayProps {
    title: string;
}

interface HolidayFormData {
    holidayName: string;
    holidayDate: string;
}

const Holiday = ({ title }: HolidayProps) => {
    const { closeModal } = useModal();
    const dispatch = useDispatch();
    const {
        register,
        control,
        formState: { errors },
        handleSubmit,
        setValue,
        reset
    } = useForm<HolidayFormData>({
        mode: 'onChange',
        defaultValues: { holidayName: '', holidayDate: '' },
    });
    const [sortObject, setSortObject] = useState({});
    const [pageSize, setPageSize] = useState<number>(10);
    const { createHolidayLoading, holidayData, getHolidayDataLoading, editId } = useSelector(
        (state: any) => state?.root?.setting
    );

    useEffect(() => {
        if (!!editId) {
            const defaultValues = holidayData?.holidays?.find((holiday: any) => holiday?._id === editId);
            setValue('holidayName', defaultValues?.title || "");
            setValue('holidayDate', defaultValues?.date || "");
        }
    }, [editId, setValue]);
    const onSubmit = async (data: HolidayFormData) => {
        const date = new Date(data.holidayDate);
        const formattedDate = `${String(date.getDate()).padStart(2, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${date.getFullYear()}`;
        const payload = {
            holiday_id: editId,
            title: data?.holidayName,
            date: formattedDate
        };
        await dispatch(createHoliday(payload)).then((result: any) => {
            if (createHoliday.fulfilled.match(result)) {
                if (result && result.payload.success === true) {
                    dispatch(setEditValue(null));
                    reset();
                    dispatch(getHolidayData(sortObject));
                }
            }
        });
    };

    const handleChangePage = async (paginationParams: any) => {
        let { page, items_per_page, sort_field, sort_order, search } =
            paginationParams;
        setSortObject({ page, items_per_page, sort_field, sort_order, search });
        await dispatch(getHolidayData({
            ...paginationParams,
            page,
            items_per_page,
            sort_field,
            sort_order,
            search,
            filter: {},
            pagination: true,
        }));
    };

    const handleDeleteById = async (
        id: string | string[],
        currentPage?: any,
        countPerPage?: number,
        sortConfig?: Record<string, string>,
        searchTerm?: string
    ) => {
        // console.log("delete id in main page....", id)
        try {
            const res = await dispatch(deleteHoliday({ holiday_id: id }));
            if (res.payload.success === true) {
                reset();
                await dispatch(getHolidayData({
                    page: currentPage,
                    items_per_page: countPerPage,
                    sort_field: sortConfig?.key,
                    sort_order: sortConfig?.direction,
                    search: searchTerm,
                    pagination: true,
                    filter: {}
                }));
            }
        } catch (error) {
            console.error(error);
        }
    };
    return (
        <div className="mb-3 flex flex-col p-4">
            <div className="flex justify-between items-center">
                <div className="text-xl font-bold text-[#120425] xl:text-2xl">{title}</div>
                <ActionIcon
                    size="sm"
                    variant="text"
                    onClick={closeModal}
                    className="text-gray-500 hover:!text-gray-900"
                >
                    <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit(onSubmit)} className="mt-4 flex flex-col md:flex-row items-center gap-4">
                {/* Holiday Name Field */}
                <div className="w-full md:w-1/3">
                    <Input
                        type="text"
                        placeholder="Enter Holiday name"
                        onKeyDown={handleKeyDown}
                        {...register('holidayName', {
                            required: messages?.fieldNameRequired,
                            maxLength: {
                                value: 50,
                                message: messages?.fieldNameLength,
                            },
                            setValueAs: (value) => value.trim(),
                        })}
                        className="w-full"
                        inputClassName="text-black poppins_font_number"
                    />
                    <p className="mt-1 min-h-3 text-xs text-red-500">
                        {errors?.holidayName?.message as string}
                    </p>
                </div>

                {/* Holiday Date Field */}
                <div className="w-full md:w-1/3">
                    <Controller
                        name="holidayDate"
                        control={control}
                        rules={{ required: 'Holiday date is required' }}
                        render={({ field: { value, onChange } }) => (
                            <DatePicker
                                selected={value ? new Date(value) : null}
                                placeholderText="Select holiday date"
                                onChange={(date) => onChange(date || '')}
                                selectsStart

                                popperPlacement="bottom-end"
                                className="w-full bg-[#fefefe]"
                                dateFormat="dd-MM-yyyy"
                                inputProps={{
                                    inputClassName: 'font-sans w-full',
                                }}
                            />
                        )}
                    />
                    <p className="mt-1 min-h-3 text-xs text-red-500">
                        {errors?.holidayDate?.message as string}
                    </p>
                </div>

                {/* Submit Button */}
                <div className="w-full md:w-auto">
                    <Button
                        disabled={createHolidayLoading}
                        className="mr-1 w-auto rounded-[8px] bg-[#7667CF] p-[12px] font-['Raleway'] text-[14px] font-[400] leading-[19.6px] text-white"
                        type="submit"
                    >
                        {!!editId ? "Edit" : "Add"} Holiday
                        {createHolidayLoading && (
                            <Spinner size="sm" tag="div" className="ms-3" color="white" />
                        )}
                    </Button>
                    <p className="mt-1 min-h-3 text-xs text-red-500">
                    </p>
                </div>
            </form>

            {/* Table Section */}
            <div className="main_card_block table-pagination flex items-center justify-center sm:justify-between poppins_font_number  xs:mt-6 sm:mt-2 ">
                <div className='overflow-auto max-h-[400px] pb-2 w-full'>
                    <div className="table_border_remove">
                        <CustomTable
                            data={(holidayData?.holidays) || []}
                            total={(holidayData?.page_count) || 1}
                            loading={getHolidayDataLoading}
                            pageSize={pageSize}
                            setPageSize={setPageSize}
                            handleDeleteById={handleDeleteById}
                            handleChangePage={handleChangePage}
                            getColumns={GetHolidayColumns}
                            scroll={{ x: 0 }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Holiday;
