import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { CheckboxGroup } from '@/components/ui/checkbox-group';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  attendanceSetting,
  getSettingData,
} from '@/redux/slices/user/setting/settingSlice';
import { handleKeyDown } from '@/utils/common-functions';
import { useEffect, useState } from 'react';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { z } from 'zod';

const AttendanceConfig = (props: any) => {
  const { title } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const [values, setValues] = useState<string[]>([]);
  const { settingData, attendanceSettingLoading } = useSelector(
    (state: any) => state?.root?.setting
  );
  const [memberCanEdit, setMemberCanEdit] = useState(false);

  console.log(settingData, memberCanEdit, 'settingData');

  useEffect(() => {
    if (settingData?.attendance?.default_holiday?.length > 0) {
      setValues(settingData?.attendance?.default_holiday);
    } else {
      setValues([]);
    }

    if (settingData?.attendance?.member_can_edit) {
      setMemberCanEdit(true);
    } else {
      setMemberCanEdit(false);
    }
  }, [
    settingData?.attendance,
    settingData?.attendance?.default_holiday?.length,
  ]);

  const defaultValues: AttendanceConfigSchema = {
    half_day: !!settingData?.attendance
      ? String(settingData?.attendance?.half_day)
      : '0',
    full_day: !!settingData?.attendance
      ? String(settingData?.attendance?.full_day)
      : '0',
  };

  const attendanceConfigSchema = z
    .object({
      half_day: z
        .string()
        // .transform((value) => Number(value))
        .refine((value) => Number(value) >= 0, {
          message: 'Half day must be at least 0.',
        }),
      full_day: z
        .string()
        // .transform((value) => Number(value))
        .refine((value) => Number(value) >= 0, {
          message: 'Full day must be at least 0.',
        })
        .refine((value) => Number(value) < 24, {
          message: 'Full day must be less than 24.',
        }),
    })
    .refine((data) => Number(data.half_day) < Number(data.full_day), {
      message: 'Half day must be less than full day.',
      path: ['half_day'],
    })
    .refine((data) => Number(data.full_day) > Number(data.half_day), {
      message: 'Full day must be greater than half day.',
      path: ['full_day'],
    });

  type AttendanceConfigSchema = z.infer<typeof attendanceConfigSchema>;

  const onSubmit = async (data: { half_day: string; full_day: string }) => {
    const payload = createPayload({
      ...data,
      default_holiday: values,
      member_can_edit: memberCanEdit,
    });

    console.log(payload, 'payload');

    // return;
    const respone = await dispatch(attendanceSetting(payload));
    if (respone?.payload?.success) {
      dispatch(getSettingData());
      closeModal();
    }
  };

  const createPayload = (data: {
    half_day: string;
    full_day: string;
    default_holiday: string[];
    member_can_edit: boolean;
  }) => {
    return {
      half_day: Number(data?.half_day),
      full_day: Number(data?.full_day),
      default_holiday: data?.default_holiday,
      member_can_edit: data?.member_can_edit
    };
  };

  return (
<div className="space-y-6 p-6 sm:p-10">
  {/* Header */}
  <div className="mb-6 flex items-center justify-between">
    <Title as="h3" className="text-lg text-[#9BA1B9] sm:text-xl xl:text-2xl">
      {title}
    </Title>
    <ActionIcon
      size="sm"
      variant="text"
      onClick={closeModal}
      className="p-0 text-[#9BA1B9] hover:!text-gray-900"
    >
      <PiXBold className="h-5 w-5 sm:h-[18px] sm:w-[18px]" />
    </ActionIcon>
  </div>

  {/* Form */}
  <Form<AttendanceConfigSchema>
    validationSchema={attendanceConfigSchema}
    onSubmit={onSubmit}
    useFormProps={{
      mode: "all",
      defaultValues,
    }}
    className="placeholder_color"
  >
    {({ register, formState: { errors } }) => (
      <div className="space-y-6">
        {/* Half Day Input */}
        <div>
          <Input
            label={"Minimum Hour For Half Day"}
            labelClassName="text-sm font-semibold text-[#9BA1B9]"
            type="number"
            onKeyDown={handleKeyDown}
            color="info"
            placeholder="Enter half day hour"
            {...register("half_day")}
            error={errors.half_day?.message as string}
          />
        </div>

        {/* Full Day Input */}
        <div>
          <Input
            label={"Minimum Hour For Full Day"}
            labelClassName="text-sm font-semibold text-[#9BA1B9]"
            type="number"
            onKeyDown={handleKeyDown}
            color="info"
            placeholder="Enter full day hour"
            {...register("full_day")}
            error={errors.full_day?.message as string}
          />
        </div>

        {/* Default Holiday */}
        <div className="flex flex-col gap-y-2">
          <span className="text-sm font-semibold text-[#9BA1B9]">
            Default Holiday
          </span>
          <CheckboxGroup
            values={values}
            setValues={setValues}
            className="flex flex-wrap gap-2"
          >
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <Checkbox
                key={day}
                inputClassName="checkbox-color"
                label={day}
                value={day.toLowerCase()}
              />
            ))}
          </CheckboxGroup>
        </div>

        {/* Modify Tracked Hours */}
        <div className="flex items-center gap-2">
          <Checkbox
            inputClassName="checkbox-color"
            className="text-sm font-bold text-[#9BA1B9]"
            label="Modify the tracked hours"
            checked={memberCanEdit}
            onClick={() => setMemberCanEdit(!memberCanEdit)}
          />
        </div>

        {/* Save Button */}
        <div className="flex mt-4 lg:mt-8">
          <Button
            className="flex w-full max-w-xs items-center justify-center rounded-full bg-[#8C80D2] px-6 py-3 text-sm font-semibold text-white hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-auto"
            type="submit"
            size="xl"
            disabled={attendanceSettingLoading}
          >
            <span>Save Changes</span>
            {attendanceSettingLoading && (
              <Spinner size="sm" tag="div" className="ml-3" color="white" />
            )}
          </Button>
        </div>
      </div>
    )}
  </Form>
</div>

  );
};

export default AttendanceConfig;
