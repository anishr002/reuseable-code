import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Select from '@/components/ui/select';
import { ActionIcon } from '@/components/ui/text';
import { messages } from '@/config/messages';
import { handleKeyDown } from '@/utils/common-functions';
import { useEffect } from 'react';
import { Controller, useFieldArray, useForm } from 'react-hook-form';
import { PiPlusBold, PiTrash, PiTrashBold, PiXBold } from 'react-icons/pi';
import { useDispatch } from 'react-redux';
import { Switch } from 'rizzui';

interface CustomField {
  fieldName: string;
  fieldType: string;
  options: string[];
  isShow: boolean;
}

interface FormData {
  customFields: CustomField[];
}

const CustomFieldSetting = ({
  title,
  onClose,
  customFields,
  setCustomFields,
}: {
  title: string;
  onClose?: any;
  customFields?: any;
  setCustomFields?: any;
}) => {
  const dispatch = useDispatch();
  // const { settingData, updateCustomFieldLoading, getSettingDataLoading } =
  //   useSelector((state: any) => state?.root?.setting);

  const {
    register,
    formState: { errors },
    control,
    reset,
    watch,
    setValue,
    trigger,
    handleSubmit,
  } = useForm<FormData>({
    mode: 'onChange',
    defaultValues: {
      customFields: customFields ?? [],
    },
  });

  const { fields, replace, append, remove } = useFieldArray<any>({
    name: 'customFields',
    control,
  });

  useEffect(() => {
    // If customFields is defined and is an empty array, append the default field.
    if (customFields && customFields?.length === 0) {
      append({
        fieldName: '',
        fieldType: '',
        options: [],
        isShow: false,
      });
    } else if (customFields) {
      // Otherwise, reset the form with the customFields data.
      reset({
        customFields: customFields ?? [],
      });
    }
  }, [customFields, reset, append]);

  // useEffect(() => {
  //   dispatch(getSettingData());
  // }, [dispatch]);

  const onSubmit = (data: any) => {
    console.log(data, 123);
    setCustomFields(data?.customFields ?? []);
    onClose();
    // dispatch(updateCustomField({ custom_fields: data?.customFields })).then(
    //   (result: any) => {
    //     if (updateCustomField.fulfilled.match(result)) {
    //       if (result?.payload?.success) {
    //         closeModal();
    //       }
    //     }
    //   }
    // );
  };

  const fieldOptionsDropdown: Record<string, any>[] = [
    { name: 'Text', value: 'text' },
    { name: 'Number', value: 'number' },
    { name: 'Textarea', value: 'textarea' },
    { name: 'Date', value: 'date' },
    { name: 'Checkbox', value: 'checkbox' },
    { name: 'DropDown', value: 'dropdown' },
  ];

  return (
    <>
      {/* {getSettingDataLoading && (
        <div className="flex h-full items-center justify-center p-6">
          <Spinner size="xl" />
        </div>
      )} */}

      {/* {!getSettingDataLoading && ( */}

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col justify-between gap-4 p-6"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="text-xl font-bold text-[#120425]">{title}</div>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={onClose}
            className="text-gray-500 hover:!text-gray-900"
          >
            <PiXBold className="h-[18px] w-[18px] text-[#141414]" />
          </ActionIcon>
        </div>

        <div className="h-100 custom-field-modal flex max-h-[450px] flex-col gap-4 overflow-x-hidden [&_label]:font-medium">
          {fields?.map((field: any, index: number) => {
            const currentFieldType = watch(`customFields.${index}.fieldType`);
            const currentFieldOptions = watch(`customFields.${index}.options`);

            return (
              <div
                key={index}
                className="flex flex-col gap-4 rounded-lg bg-[#F9FAFB] p-4"
              >
                <div className="flex gap-4">
                  <div className="w-[84%] flex-row gap-4 sm:flex">
                    <div className=" flex w-full flex-col gap-3">
                      <label className="text-[14px] font-semibold text-[#141414]">
                        Field Title *
                      </label>
                      <div>
                        <Input
                          type="text"
                          onKeyDown={handleKeyDown}
                          {...register(`customFields.${index}.fieldName`, {
                            required: messages.fieldNameRequired,
                            maxLength: {
                              value: 20,
                              message: messages.fieldNameLength,
                            },
                            setValueAs: (value) => value.trim(),
                            validate: (value) => {
                              const normalizedValue = value
                                .trim()
                                .toLowerCase();
                              const isUnique = fields.every(
                                (item: any, i: number) =>
                                  i === index ||
                                  item.fieldName.trim().toLowerCase() !==
                                    normalizedValue
                              );
                              return isUnique || messages.fieldNameUnique;
                            },
                          })}
                          className="w-full rounded-lg bg-[#FFFFFF]"
                          inputClassName="text-black poppins_font_number"
                        />
                        {errors?.customFields?.[index]?.fieldName?.message && (
                          <p className="mt-1 text-sm text-red-500">
                            {errors?.customFields?.[index]?.fieldName?.message}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex w-full flex-col gap-3">
                      <label className="text-[14px] font-semibold text-[#141414]">
                        Select Type *
                      </label>
                      <div>
                        <Controller
                          control={control}
                          rules={{ required: messages.fieldTypeRequired }}
                          name={`customFields.${index}.fieldType`}
                          render={({ field }) => (
                            <Select
                              {...field}
                              options={fieldOptionsDropdown}
                              onChange={(e: any) => {
                                if (e.value === 'dropdown') {
                                  setValue(`customFields.${index}.options`, [
                                    '',
                                  ]);
                                } else {
                                  setValue(`customFields.${index}.options`, []);
                                }
                                field.onChange(e.value);
                              }}
                              value={fieldOptionsDropdown?.find(
                                (option) => option.value === field.value
                              )}
                              placeholder="Select Field"
                              className="!z-[9999] w-full rounded-lg bg-[#FFFFFF] text-black"
                              selectClassName="text-black poppins_font_number h-10"
                              dropdownClassName='!z-[9999]'
                            />
                          )}
                        />
                        {errors?.customFields?.[index]?.fieldType?.message && (
                          <p className="mt-1 text-sm text-red-500">
                            {errors?.customFields?.[index]?.fieldType?.message}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mb-1 flex items-end justify-center gap-3">
                    <Button
                      type="button"
                      className=" flex items-center justify-center rounded-lg bg-[#CB3B281A] p-3 font-semibold text-[#fff]  sm:w-auto"
                      onClick={() => remove(index)}
                    >
                      <PiTrash className="h-5 w-5 text-[#CB3B28]" />
                    </Button>
                  </div>
                </div>

                {currentFieldType === 'dropdown' && (
                  <div className="flex w-full flex-col gap-3">
                    <label className="text-[14px] font-semibold text-[#141414]">
                      Options *
                    </label>
                    {currentFieldOptions?.map(
                      (option: any, optionIndex: any) => (
                        <div key={optionIndex}>
                          <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
                            {/* Input field */}
                            <div className="flex-1">
                              <Input
                                type="text"
                                onKeyDown={handleKeyDown}
                                {...register(
                                  `customFields.${index}.options.${optionIndex}`,
                                  {
                                    required: messages.optionRequired,
                                    maxLength: {
                                      value: 20,
                                      message: messages.optionLength,
                                    },
                                    setValueAs: (value) => value.trim(),
                                  }
                                )}
                                className="w-full"
                                inputClassName="bg-[#FFFFFF] text-black poppins_font_number"
                              />
                            </div>
                            <div className="mt-2 flex justify-start gap-2 sm:mt-0 sm:justify-end">
                              {currentFieldOptions?.length < 10 &&
                                currentFieldOptions?.length - 1 ===
                                  optionIndex && (
                                  <Button
                                    type="button"
                                    className="flex border border-[#5850EC] bg-transparent text-[#5850EC]"
                                    onClick={async () => {
                                      const isValid = await trigger(
                                        `customFields.${index}.options`
                                      );
                                      if (isValid) {
                                        setValue(
                                          `customFields.${index}.options.${
                                            optionIndex + 1
                                          }` as any,
                                          ''
                                        );
                                      }
                                    }}
                                  >
                                    <PiPlusBold className="me-1.5 h-4 w-4" />{' '}
                                    Add
                                  </Button>
                                )}

                              {currentFieldOptions.length > 1 && (
                                <Button
                                  type="button"
                                  className="flex w-full items-center justify-center rounded-lg bg-[#7667CF] px-4 py-2 text-[13px] font-semibold text-[#ffff] sm:w-auto"
                                  onClick={() =>
                                    setValue(
                                      `customFields.${index}.options`,
                                      currentFieldOptions.filter(
                                        (_: any, i: number) => i !== optionIndex
                                      )
                                    )
                                  }
                                >
                                  <PiTrashBold className="me-1 h-[18px] w-[18px]" />{' '}
                                  Remove
                                </Button>
                              )}
                            </div>
                          </div>
                          {errors?.customFields && (
                            <p className="mt-1 w-full text-sm text-red-500 sm:w-auto">
                              {
                                errors?.customFields?.[index]?.options?.[
                                  optionIndex
                                ]?.message
                              }
                            </p>
                          )}
                        </div>
                      )
                    )}
                  </div>
                )}
                <div className="flex w-full justify-start">
                  <Switch
                    label="Show custom field in task"
                    // checked={field.isShow}
                    labelPlacement="left"
                    size="sm"
                    {...register(`customFields.${index}.isShow`)}
                    className="custom-fields-check text-[14px] font-bold text-[#9BA1B9] "
                    labelClassName="text-[#141414] font-medium text-sm"
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between gap-2">
          {fields?.length < 10 && (
            <Button
              onClick={async () => {
                const isValid = await trigger(); // Validate current form fields
                if (isValid) {
                  append({
                    fieldName: '',
                    fieldType: '',
                    options: [],
                    isShow: false,
                  });
                }
              }}
              className="flex border border-[#5850EC] bg-transparent text-[#5850EC]"
            >
              <PiPlusBold className="me-1.5 h-4 w-4" /> Create new field
            </Button>
          )}
          <Button
            className="hover:border-1 flex w-full items-center justify-center rounded-lg bg-[#7667CF] px-4 py-2 text-[13px] font-semibold text-[#ffff] hover:border-[#7667CF] hover:bg-white hover:text-[#7667CF] sm:w-auto"
            type="submit"
            // disabled={updateCustomFieldLoading}
          >
            <span>Save change</span>
            {/* {updateCustomFieldLoading && (
                <Spinner size="sm" tag="div" className="ms-3" color="white" />
              )} */}
          </Button>
        </div>
      </form>

      {/* )} */}
    </>
  );
};

export default CustomFieldSetting;
