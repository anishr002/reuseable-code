'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { setEditValue } from '@/redux/slices/user/setting/settingSlice';
import moment from 'moment';
import { SlOptions } from 'react-icons/sl';
import { useDispatch, useSelector } from "react-redux";
import { ActionIcon, Button, Popover } from 'rizzui';
import DeletePopover from '../../delete-popover';


type Columns = {
    data: any[];
    sortConfig?: any;
    handleSelectAll: any;
    checkedItems: string[];
    onDeleteItem: (
        id: string | string[],
        currentPage?: any,
        countPerPage?: number,
        Islastitem?: boolean,
        sortConfig?: Record<string, string>,
        searchTerm?: string
    ) => void;
    onHeaderCellClick: (value: string) => void;
    onChecked?: (id: string) => void;
    currentPage?: number;
    pageSize?: number;
    searchTerm?: string;
};

export const GetHolidayColumns = ({
    data,
    sortConfig,
    checkedItems,
    onDeleteItem,
    onHeaderCellClick,
    handleSelectAll,
    onChecked,
    currentPage,
    pageSize,
    searchTerm,
}: Columns) => {
    const signIn = useSelector((state: any) => state?.root?.signIn);
    const { paginationParams } = useSelector(
        (state: any) => state?.root?.activity
    );
    let { page, items_per_page, sort_field, sort_order, search, filter } =
        paginationParams;
    const dispatch = useDispatch();
    // console.log("pathname is....", pathname.startsWith('/client/details'))

    return [
        {
            title: (
                <div className="">
                    <HeaderCell
                        // className="text-[#4B5563]"
                        title="Title"
                        sortable
                        ascending={
                            sortConfig?.direction === 'asc' && sortConfig?.key === 'title'
                        }
                    />
                </div>
            ),
            onHeaderCell: () => onHeaderCellClick('title'),
            dataIndex: 'title',
            key: 'title',
            width: 220,
            render: (value: string) => (
                <Text className=" w-72 truncate text-gray-700 font-medium">
                    {value?.charAt(0)?.toUpperCase() + value?.slice(1)}
                </Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Date"
                    // className="text-[#4B5563]"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'date'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('date'),
            dataIndex: 'date',
            key: 'date',
            width: 300,
            render: (value: string) => (
                <Text className=" font-medium text-gray-700">
                    {moment(value).format('DD MMM, YYYY')}
                </Text>
            ),
        },
        {
            // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
            title: <HeaderCell title="Action" align="right" />,
            dataIndex: 'action',
            key: 'action',
            width: 70,
            render: (_: string, row: any) => {
                // function dispatch(arg0: any) {
                //   throw new Error('Function not implemented.');
                // }


                return (
                    <div className="flex items-center justify-end">
                        <Popover
                            placement="top-start"
                            className="demo_test flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
                            content={({ setOpen }) => {
                                return (
                                    <>
                                        <Button
                                            variant="text"
                                            className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                                            onClick={() => {
                                                dispatch(setEditValue(row?._id));
                                            }}
                                        >
                                            Edit Holiday
                                        </Button>
                                        <DeletePopover
                                            title={`Delete Holiday`}
                                            isHolidayDelete={true}
                                            deleteButtonClass="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                                            description={`Are you sure you want to delete?`}
                                            onDelete={() => {
                                                onDeleteItem(
                                                    row._id,
                                                    currentPage,
                                                    pageSize,
                                                    data?.length <= 1 ? true : false,
                                                    sortConfig,
                                                    searchTerm
                                                );
                                                dispatch(setEditValue(null));
                                                setOpen(false);
                                            }}
                                        />
                                    </>
                                );
                            }}
                        >
                            <ActionIcon title="More Options" variant="text">
                                <SlOptions className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
                            </ActionIcon>
                        </Popover>

                    </div>
                );
            },
        },
    ];
};
