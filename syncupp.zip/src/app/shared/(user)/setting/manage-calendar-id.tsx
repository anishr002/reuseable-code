import { useEffect, useState } from 'react';
import { Formik, Form, Field, FieldArray, FieldProps } from 'formik';
import * as Yup from 'yup';
import { ActionIcon, Title } from '@/components/ui/text';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { PiXBold } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { Input } from '@/components/ui/input';
import TrashIcon from '@/components/icons/trash';
import { getCalendarId, updateCalendarId } from '@/redux/slices/user/setting/settingSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox } from 'rizzui';

export const ManageCalendarId = (props: any) => {
    const { title } = props;
    const { closeModal } = useModal();
    const dispatch = useDispatch();
    const [calendarData, setCalendarData] = useState([]);
    const [loader, setLoader] = useState(false);
    const [user, setUser] = useState<any>(null);

    console.log("calendar data...", calendarData)
    // Selector
    const { updateCalendarIdLoading } = useSelector(
        (state: any) => state?.root?.setting
    );

    useEffect(() => {
        setLoader(true);
        dispatch(getCalendarId()).then((result: any) => {
            if (getCalendarId.fulfilled.match(result)) {
                if (result && result.payload.success === true) {
                    result?.payload?.data?.calendar_event && setCalendarData(result?.payload?.data?.calendar_event);
                    result?.payload?.data && setUser(result?.payload?.data);
                    setLoader(false);
                }
                setLoader(false);
            } else {
                setLoader(false);
                closeModal();
            }
        });
    }, []);

    const handleChange = (event: any) => {
        const { value, checked } = event.target;
        let updatedCalendarData: any = calendarData && calendarData?.length > 0 && calendarData?.map((event: any, index: any) => {
            if (value === event?._id) {
                return {
                    ...event,
                    is_marked: checked
                }
            }
            return event;
        }) || [];
        setCalendarData(updatedCalendarData);
    }

    const onSubmit = () => {
        dispatch(updateCalendarId({ _id: user?._id, calender_events: calendarData })).then((result: any) => {
            if (updateCalendarId.fulfilled.match(result)) {
                if (result && result.payload.success === true) {
                    closeModal();
                }
            }
        });
    };

    if (loader) {
        return (
            <div className="flex items-center justify-center p-10">
                <Spinner size="xl" tag="div" />
            </div>
        );
    }
    return (
        <div className="p-8 space-y-5">
            <div className="mb-6 flex items-center justify-between">
                <Title
                    as="h3"
                    className="text-xl font-semibold montserrat_font_title text-black"
                >
                    {title}
                </Title>
                <ActionIcon
                    size="sm"
                    variant="text"
                    onClick={() => closeModal()}
                    className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
                >
                    <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
            </div>
            <div className='flex gap-2 items-center'>
                <div className='font-medium poppins_font_number'>
                    Google user :
                </div>
                <div className='font-medium poppins_font_number'>
                    {user && user?.auth_email}
                </div>
            </div>

            <div>
                {calendarData && calendarData?.length > 0 && calendarData?.map((event: any, index: any) => {
                    return <div key={index} className="flex gap-2 items-center mt-[6px]">
                        <Checkbox
                            value={event?._id}
                            className="mr-4"
                            inputClassName="checkbox-color"
                            checked={event?.is_marked}
                            onChange={handleChange}
                        />
                        <div className='font-medium poppins_font_number'>
                            {event?.summary && (event?.summary?.includes('@') && event?.summary?.includes('.')) ? 'Primary' : event?.summary}
                        </div>
                    </div>
                })
                }
            </div>

            <div className="mt-2 flex w-full lg:justify-end items-center lg:mt-16">
                <Button
                    className="flex w-auto items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                    onClick={onSubmit}
                    disabled={updateCalendarIdLoading}
                >
                    <span>Save Changes</span>
                    {
                        updateCalendarIdLoading &&
                        <Spinner size="sm" tag="div" className="ms-3" color="white" />
                    }
                </Button>
            </div>
        </div>
    );
};