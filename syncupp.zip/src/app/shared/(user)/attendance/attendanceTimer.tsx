import { Button } from '@/components/ui/button';
import { LiaHandPointer } from 'react-icons/lia';

import Spinner from '@/components/ui/spinner';
import {
  getWorkedDuration,
  logAttendance,
  removeWorkedDurationData,
  setUserAccurateLocation,
} from '@/redux/slices/user/attendance/attendanceSlice';
import {
  capitalizeFirstLetter,
  convertSecondsToTimeForManaul,
  formatTime,
} from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { FaAngleDown } from 'react-icons/fa';
import { FiArrowLeft, FiArrowRight } from 'react-icons/fi';
import { LuClock } from 'react-icons/lu';
import { useDispatch, useSelector } from 'react-redux';
import { Popover } from 'rizzui';
import socket from 'src/io';
import { useModal } from '../../modal-views/use-modal';
import useAccurateLocation from '@/hooks/use-accurate-location';
import useReverseGeocoding from '@/hooks/use-reverse-geocoding';
import GoogleMapComponent from './GoogleMap';

const AttendanceTimer = () => {
  const [isAttendanceRunning, setIsAttendanceRunning] = useState(false);
  const [punchInTime, setPunchInTime] = useState(0);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { logAttendanceLoader, workedDurationData, userLocation } = useSelector(
    (state: any) => state?.root?.attendance
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);

  const dispatch = useDispatch();
  const userData = signIn?.userProfile ?? {};

  const { openModal, closeModal } = useModal();
  const [apiResponse, setApiResponse] = useState(false);
  const [punchData, setPunchData] = useState<any>(null);

  // popover management state
  const [isOpen, setIsOpen] = useState(false);

  // swipe end states
  const [sliderPositionEnd, setSliderPositionEnd] = useState(0);
  const sliderRefEnd = useRef<HTMLDivElement>(null);
  const buttonRefEnd = useRef<HTMLButtonElement>(null);
  const sliderPositionEndRef = useRef(sliderPositionEnd);
  const maxPositionEndRef = useRef(0);

  // swipe start states
  const [sliderPositionStart, setSliderPositionStart] = useState(0);
  const sliderRefStart = useRef<HTMLDivElement>(null);
  const buttonRefStart = useRef<HTMLButtonElement>(null);
  const sliderPositionStartRef = useRef(0);
  const maxPositionRefStart = useRef(0);

  useEffect(() => {
    dispatch(removeWorkedDurationData());
    dispatch(getWorkedDuration());
    return () => {
      dispatch(removeWorkedDurationData());
    };
  }, [dispatch]);

  // get user's accurate location
  const { location, error, getAccurateLocation } = useAccurateLocation();
  const {
    location: geoLocation,
    address,
    error: geocodeError,
    getAddress,
  } = useReverseGeocoding();

  useEffect(() => {
    getAccurateLocation();
    dispatch(setUserAccurateLocation({}));
  }, []);

  console.log('Location....', location, 'Location error....', error);
  console.log('address......', address, 'geocodeError....', geocodeError);
  console.log('geoLocation......', geoLocation);
  console.log('userLocation......', userLocation);

  useEffect(() => {
    if (location && location?.latitude && location?.longitude) {
      dispatch(
        setUserAccurateLocation({
          ...userLocation,
          latitude: location?.latitude,
          longitude: location?.longitude,
        })
      );
      getAddress(location?.latitude, location?.longitude);
    }
  }, [location]);

  useEffect(() => {
    if (
      address &&
      geoLocation?.country &&
      geoLocation?.state &&
      geoLocation?.city
    ) {
      dispatch(
        setUserAccurateLocation({
          ...userLocation,
          address,
          country: geoLocation?.country,
          state: geoLocation?.state,
          city: geoLocation?.city,
        })
      );
    }
  }, [address, geoLocation]);

  useEffect(() => {
    socket.on('PUNCH_IN', () => {
      socket.emit('CONFIRMATION', { event: 'PUNCH_IN' });
      dispatch(getWorkedDuration());
    });

    return () => {
      socket.off('PUNCH_IN');
    };
  }, [dispatch, defaultWorkSpace?._id]);

  useEffect(() => {
    socket.on('PUNCH_OUT', (response) => {
      socket.emit('CONFIRMATION', { event: 'PUNCH_OUT' });
      if (response) {
        setPunchData(response);
      }
      dispatch(removeWorkedDurationData());
      setIsAttendanceRunning(false);
    });

    return () => {
      socket.off('PUNCH_OUT');
    };
  }, [dispatch, defaultWorkSpace?._id]);

  useEffect(() => {
    if (
      workedDurationData &&
      workedDurationData !== null &&
      Object?.keys(workedDurationData)?.length > 0
    ) {
      // Using moment to calculate the duration in milliseconds since punch in
      setPunchInTime(
        moment().diff(moment(workedDurationData?.new_log?.punch_in))
      );
      setIsAttendanceRunning(true);
    } else {
      setIsAttendanceRunning(false);
    }
  }, [workedDurationData, defaultWorkSpace?._id]);

  useEffect(() => {
    let timer: any;
    if (isAttendanceRunning) {
      timer = setInterval(() => {
        // Increment time every second (in milliseconds)
        setPunchInTime((prevTime) => prevTime + 1000);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isAttendanceRunning]);

  // Punch In - Punch Out API call function
  const handlePunch = ({
    event_type,
  }: {
    event_type: 'punch_in' | 'punch_out';
  }) => {
    dispatch(
      logAttendance({
        event_type,
        ...(Object?.keys(userLocation)?.length > 0 && userLocation?.address &&
          event_type === 'punch_in' && { location_punch_in: userLocation }),
        ...(Object?.keys(userLocation)?.length > 0 && userLocation?.address &&
          event_type === 'punch_out' && { location_punch_out: userLocation }),
      })
    ).then((result: any) => {
      if (logAttendance.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          if (event_type === 'punch_in') {
            setIsOpen(false); // popover close
            setSliderPositionStart(0);
          }
          if (event_type === 'punch_out') {
            setSliderPositionEnd(0);
            setApiResponse(true);
          }
        } else {
          event_type === 'punch_in' && setSliderPositionStart(0);
          event_type === 'punch_out' && setSliderPositionEnd(0);
        }
      } else {
        event_type === 'punch_in' && setSliderPositionStart(0);
        event_type === 'punch_out' && setSliderPositionEnd(0);
      }
    });
    closeModal();
  };

  // swipe right to start shift events code start

  const handleSliderMoveStart = (clientX: number) => {
    if (!sliderRefStart.current || !buttonRefStart.current) return;
    const sliderRect = sliderRefStart.current.getBoundingClientRect();
    const buttonWidth = buttonRefStart.current.offsetWidth;
    const maxPosition = sliderRect.width - buttonWidth;
    maxPositionRefStart.current = maxPosition - 10;

    // Calculate distance from the left edge
    let newPosition = clientX - sliderRect.left - buttonWidth / 2;
    newPosition = Math.max(0, Math.min(newPosition, maxPosition));
    sliderPositionStartRef.current = newPosition;
    setSliderPositionStart(newPosition);
  };

  const handleMouseDownStart = (e: React.MouseEvent) => {
    e.preventDefault();
    handleSliderMoveStart(e.clientX);

    const handleMouseMove = (e: MouseEvent) => {
      handleSliderMoveStart(e.clientX);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      if (sliderPositionStartRef.current >= maxPositionRefStart.current) {
        handlePunch({ event_type: 'punch_in' });
      } else {
        setSliderPositionStart(0);
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleTouchStartForStart = (e: React.TouchEvent) => {
    e.preventDefault();
    handleSliderMoveStart(e.touches[0].clientX);

    const handleTouchMove = (e: TouchEvent) => {
      handleSliderMoveStart(e.touches[0].clientX);
    };

    const handleTouchEnd = () => {
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
      if (sliderPositionStartRef.current >= maxPositionRefStart.current) {
        handlePunch({ event_type: 'punch_in' });
      } else {
        setSliderPositionStart(0);
      }
    };

    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', handleTouchEnd);
  };

  // swipe right to start shift events code end

  // swipe left to end shift events code start

  const handleSliderMoveEnd = (clientX: number) => {
    if (!sliderRefEnd.current || !buttonRefEnd.current) {
      return;
    }

    const sliderRect = sliderRefEnd.current.getBoundingClientRect();
    const buttonWidth = buttonRefEnd.current.offsetWidth;
    const maxPosition = sliderRect.width - buttonWidth;
    maxPositionEndRef.current = maxPosition - 10;

    let newPosition;
    newPosition = sliderRect.right - clientX - buttonWidth / 2;
    newPosition = Math.max(0, Math.min(newPosition, maxPosition));

    sliderPositionEndRef.current = newPosition;
    setSliderPositionEnd(newPosition);
  };

  const handleMouseDownEnd = (e: React.MouseEvent) => {
    e.preventDefault();
    handleSliderMoveEnd(e.clientX);

    const handleMouseMove = (e: MouseEvent) => {
      handleSliderMoveEnd(e.clientX);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      if (sliderPositionEndRef.current >= maxPositionEndRef.current) {
        handlePunch({ event_type: 'punch_out' });
      } else if (sliderPositionEndRef.current < maxPositionEndRef.current) {
        setSliderPositionEnd(0);
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleTouchStartForEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    handleSliderMoveEnd(e.touches[0].clientX);

    const handleTouchMove = (e: TouchEvent) => {
      handleSliderMoveEnd(e.touches[0].clientX);
    };

    const handleTouchEnd = () => {
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
      if (sliderPositionEndRef.current < maxPositionEndRef.current) {
        setSliderPositionEnd(0);
      } else if (sliderPositionEndRef.current >= maxPositionEndRef.current) {
        handlePunch({ event_type: 'punch_out' });
      }
    };

    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', handleTouchEnd);
  };

  // swipe left to end shift events code end

  // const comformationModal = () => {
  //   openModal({
  //     view: (
  //       <ConfirmationModal
  //         title="Punch Out"
  //         message="Are you sure you want to punch out?"
  //         confirmText="Yes"
  //         onConfirm={() => handlePunch({ event_type: 'punch_out' })}
  //         onClose={closeModal}
  //       />
  //     ),
  //     customSize: '400px',
  //   });
  // };

  return (
    <div className="flex flex-col items-center gap-[10px] rounded-lg bg-[#946FF5] p-[2px] md:h-10 md:flex-row">
      {isAttendanceRunning && (
        <div className="poppins_font_number flex min-h-[35px] w-[145px] items-center justify-between gap-1 overflow-hidden whitespace-nowrap rounded-lg border border-slate-300 bg-[#FFFFFF] px-2 py-1 text-center  shadow-sm">
          <p className="w-full text-xs font-normal text-[#4B5563]">
            Active Shift :{' '}
          </p>
          <p className="w-full text-xs font-semibold text-[#1C64F2]">
            {formatTime(punchInTime)}
          </p>
        </div>
      )}

      <Popover
        className="demo_test !p-0"
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        showArrow={false}
        content={({ open, setOpen }) => (
          <div className="flex w-[275px] flex-col gap-4 p-4">
            <div className="flex flex-col gap-3">
              {/* Header */}
              <div className="flex flex-col gap-1">
                {/* Greetings message with username */}
                <div className="flex flex-row gap-1 text-sm">
                  <p className="text-sm font-semibold text-[#111928]">
                    Good{' '}
                    {(() => {
                      const currentHour = moment().hour();
                      if (
                        (!isAttendanceRunning && !apiResponse) ||
                        isAttendanceRunning
                      ) {
                        if (currentHour >= 5 && currentHour < 12) {
                          return 'morning';
                        } else if (currentHour >= 12 && currentHour < 18) {
                          return 'afternoon';
                        } else {
                          return 'evening';
                        }
                      } else if (!isAttendanceRunning && apiResponse) {
                        return 'bye';
                      }
                    })()}
                    ,
                  </p>
                  <p className="text-sm font-semibold text-[#4B5563]">
                    {capitalizeFirstLetter(userData?.first_name)}
                  </p>
                </div>
                {/* Title */}
                {!isAttendanceRunning && !apiResponse && (
                  <div className="text-start text-[10px] font-normal leading-[14px] text-[#4B5563]">
                    {`Punch in now to track your hours and let your team know you’re here.`}
                  </div>
                )}
                {isAttendanceRunning && (
                  <div className="text-start text-[10px] font-normal leading-[14px] text-[#4B5563]">
                    <span>Active Shift since </span>
                    <span className="poppins_font_number ms-1 text-sm font-bold text-[#009951]">
                      {formatTime(punchInTime)}
                    </span>
                  </div>
                )}
                {!isAttendanceRunning && apiResponse && (
                  <div className="flex flex-col gap-[2px]">
                    <div className="text-start text-[10px] font-normal leading-[14px] text-[#4B5563]">
                      You’ve been punched out for the day.
                    </div>
                    <div className="text-start text-[10px] font-normal leading-[14px] text-[#4B5563]">
                      <span>Total shift time:</span>
                      <span className="poppins_font_number ms-1 text-sm font-bold text-[#B667FE]">
                        {punchData?.new_log?.total_time
                          ? convertSecondsToTimeForManaul(
                              punchData?.new_log?.total_time
                            )
                          : ''}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Map with user's current location */}
              {location && location?.latitude && location?.longitude && (
                <div>
                  <GoogleMapComponent location={location} address={address} />
                </div>
              )}
            </div>
            {!isAttendanceRunning && !apiResponse && (
              <>
                <div className="flex flex-row gap-4">
                  <div className="flex h-[35px] w-[35px] items-center justify-center rounded-[4px] bg-[#F3F4F6] p-[6px]">
                    <LuClock className="h-4 w-4" />
                  </div>

                  <div className="flex flex-col items-start gap-1">
                    <div className="text-[10px] font-medium leading-[14px] text-[#4B5563]">
                      {moment().format('dddd, MMM D')}
                    </div>
                    <div className="poppins_font_number text-xs font-medium text-[#111928]">
                      {moment().format('hh:mm A')}
                    </div>
                  </div>
                </div>
                {/* Start Shift slider */}
                <div
                  ref={sliderRefStart}
                  className="relative h-10 w-full overflow-hidden rounded-lg bg-[#7667CF]"
                >
                  <Button
                    ref={buttonRefStart}
                    className="absolute left-0 top-0 m-1 flex h-8 w-8 cursor-pointer items-center justify-center rounded-[4px] bg-[#FFFFFF] !p-0 text-[#946FF5] transition-transform duration-300 ease-out"
                    style={{
                      transform: `translateX(${Math.min(
                        sliderPositionStart,
                        maxPositionRefStart.current
                      )}px)`,
                    }}
                    onMouseDown={handleMouseDownStart}
                    onTouchStart={handleTouchStartForStart}
                    disabled={logAttendanceLoader}
                  >
                    {logAttendanceLoader ? (
                      <Spinner size="sm" className="text-[#946FF5]" />
                    ) : (
                      <FiArrowRight className="h-4 w-4 text-[#946FF5]" />
                    )}
                  </Button>
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                    <span
                      className="text-xs font-normal text-white"
                      style={{
                        opacity:
                          sliderPositionStart > 0
                            ? 1 -
                              sliderPositionStart / maxPositionRefStart.current
                            : 1,
                      }}
                    >
                      Swipe right to start shift
                    </span>
                  </div>
                </div>
              </>
            )}
            {isAttendanceRunning && (
              <>
                <div className="flex flex-row gap-4">
                  <div className="flex h-[35px] w-[35px] items-center justify-center rounded-[4px] bg-[#EBF5FF] p-[6px]">
                    <LuClock className="h-4 w-4 text-[#1C64F2]" />
                  </div>

                  <div className="flex flex-col items-start gap-1">
                    <div className="text-[10px] font-medium leading-[14px] text-[#4B5563]">
                      Punched-in
                    </div>
                    <div className="poppins_font_number text-xs font-medium text-[#1C64F2]">
                      {workedDurationData?.new_log?.punch_in
                        ? moment(workedDurationData?.new_log?.punch_in).format(
                            'hh:mm A'
                          )
                        : ''}
                    </div>
                  </div>
                </div>
                <div
                  ref={sliderRefEnd}
                  className="relative h-10 w-full overflow-hidden rounded-lg !bg-[#7667CF] bg-opacity-10"
                >
                  <Button
                    ref={buttonRefEnd}
                    className={`absolute right-0 top-0 m-1 flex h-8 w-8 cursor-pointer items-center justify-center rounded-[4px] bg-[#FFFFFF] !p-0 text-[#946FF5] transition-transform duration-300 ease-out`}
                    style={{
                      transform: `translateX(${-Math.min(
                        sliderPositionEnd,
                        maxPositionEndRef.current
                      )}px)`,
                    }}
                    onMouseDown={handleMouseDownEnd}
                    onTouchStart={handleTouchStartForEnd}
                    disabled={logAttendanceLoader}
                  >
                    {logAttendanceLoader ? (
                      <Spinner size="sm" className="text-[#946FF5]" />
                    ) : (
                      <FiArrowLeft className="h-4 w-4 text-[#946FF5]" />
                    )}
                  </Button>
                  <div className="pointer-events-none absolute inset-0 flex items-center ps-3">
                    <span
                      className="text-xs font-normal text-white"
                      style={{
                        opacity:
                          1 - sliderPositionEnd / maxPositionEndRef.current,
                        transition: 'opacity 0.3s ease-out',
                      }}
                    >
                      Swipe left to end shift
                    </span>
                  </div>
                </div>
              </>
            )}
            {!isAttendanceRunning && apiResponse && (
              <>
                <div className="flex flex-row gap-4">
                  <div className="flex h-[35px] w-[35px] items-center justify-center rounded-[4px] bg-[#EBF5FF] p-[6px] text-[#1C64F2]">
                    <LuClock className="h-4 w-4" />
                  </div>
                  <div className="flex flex-col items-start gap-1">
                    <div className="text-[10px] font-medium leading-[14px] text-[#4B5563]">
                      Punched-in
                    </div>
                    <div className="poppins_font_number text-xs font-medium text-[#1C64F2]">
                      {punchData?.new_log?.punch_in
                        ? moment(punchData?.new_log?.punch_in).format('hh:mm A')
                        : ''}
                    </div>
                  </div>
                </div>
                <div className="flex flex-row gap-4">
                  <div className="flex h-[35px] w-[35px] items-center justify-center rounded-[4px] bg-[#FDF2F2] p-[6px] text-[#F05252]">
                    <LuClock className="h-4 w-4" />
                  </div>
                  <div className="flex flex-col items-start gap-1">
                    <div className="text-[10px] font-medium leading-[14px] text-[#4B5563]">
                      Punched-out
                    </div>
                    <div className="poppins_font_number text-xs font-medium text-[#F05252]">
                      {punchData?.new_log?.punch_out
                        ? moment(punchData?.new_log?.punch_out).format(
                            'hh:mm A'
                          )
                        : ''}
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      >
        <Button
          className="flex h-[40px] w-auto items-center justify-center gap-2 whitespace-nowrap rounded-lg bg-[#946FF5] p-3 text-sm font-normal text-white"
          onClick={() => {
            setApiResponse(false);
          }}
        >
          {isAttendanceRunning ? (
            <>
              End Shift
              <FaAngleDown className="h-4 w-4" />
            </>
          ) : (
            <>
              <LiaHandPointer className="h-5 w-5" />
              Mark Attendance
            </>
          )}
        </Button>
      </Popover>
    </div>
  );
};

export default AttendanceTimer;
