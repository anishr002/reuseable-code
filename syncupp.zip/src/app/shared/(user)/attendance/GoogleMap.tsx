'use client';

import { Skeleton } from '@/components/ui/skeleton';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import {
    GoogleMap,
    OverlayView,
    useJsApiLoader
} from '@react-google-maps/api';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Avatar, Tooltip } from 'rizzui';

const GoogleMapComponent = ({
  location,
  address,
}: {
  location: any;
  address: any;
}) => {
  console.log("user's current location....", location);
  console.log("user's current address....", address);
  const { userProfile } = useSelector((state: any) => state?.root?.signIn);
  const [mapCenter, setMapCenter] = useState({
    lat: 31.963158,
    lng: 35.930359,
  });

  useEffect(() => {
    if (location?.latitude && location?.longitude) {
      setMapCenter({
        lat: location.latitude,
        lng: location.longitude,
      });
    }
  }, [location?.latitude, location?.longitude]);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_ADDRESS_KEY ?? '',
    libraries: ['places'],
  });

  console.log('isLoaded.....', isLoaded);

  const mapContainerStyle = {
    width: '243px',
    minWidth: '243px',
    height: '192px',
    borderRadius: '0px',
    backgroundColor: 'white',
  };

  // Render a fallback until the API is loaded
  if (!isLoaded) {
    return <Skeleton className="h-[192px] w-[243px]" />;
  }

  return (
    <GoogleMap
      mapContainerStyle={mapContainerStyle}
      center={mapCenter}
      zoom={16}
      options={{
        disableDefaultUI: false,
        backgroundColor: 'white',
        fullscreenControl: false,
        clickableIcons: true,
        draggable: true,
        scrollwheel: true,
      }}
    >
      {/* <Marker position={mapCenter}>
        {location?.latitude && location?.longitude && (
          <InfoWindow
            position={{
              lat: location?.latitude,
              lng: location?.longitude,
            }}
          >
            <div>{address ?? 'Address not available'}</div>
          </InfoWindow>
        )}
      </Marker> */}
      {location && (
        <OverlayView
          // Position where you want the overlay
          position={{ lat: location?.latitude, lng: location?.longitude }}
          // Determines which "layer" the overlay is drawn on
          mapPaneName={OverlayView.OVERLAY_LAYER}
        >
          <div className="">
            <div className="absolute -left-[16px] -top-[66px] h-10 w-10 rounded-full bg-red-600">
              <Avatar
                src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${userProfile?.profile_image}`}
                name={`${capitalizeFirstLetter(
                  userProfile?.first_name
                )} ${capitalizeFirstLetter(userProfile?.last_name)}`}
                className="!h-10 !w-10 border border-red-600 text-white"
              />
              <div className="absolute -bottom-[28px] left-[14px] -z-10">
                <svg
                  width="28"
                  height="30"
                  viewBox="0 0 28 30"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M11.7896 1.25977L6.5 13.0392L1.21045 1.25977L11.7896 1.25977Z"
                    fill="#DC2626"
                    stroke="#DC2626"
                  />
                </svg>
              </div>
            </div>
            <div className="absolute flex items-center justify-center">
              <span className="absolute inline-flex h-5 w-5 animate-ping rounded-full bg-red-500 opacity-20"></span>
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-600"></span>
            </div>
            {address && location?.latitude && location?.longitude && (
              <Tooltip
                size="sm"
                className='demo_test'
                content={() => address ?? ''}
                placement="top"
                color="invert"
              >
                <div className="absolute -left-[76px] top-7 flex h-[42px] w-[165px] flex-col gap-1 rounded-lg border border-[#16BDCA] bg-[#F3FAF7] px-3 py-1.5">
                  <div className="w-full text-left text-[10px] font-medium text-[#4B5563]">
                    Current Location
                  </div>
                  <div className="w-full truncate text-left text-[10px] font-medium text-[#111928]">
                    {address ?? 'Address not available'}
                  </div>
                </div>
              </Tooltip>
            )}
          </div>
        </OverlayView>
      )}
    </GoogleMap>
  );
};

export default GoogleMapComponent;
