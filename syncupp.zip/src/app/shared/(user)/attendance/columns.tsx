'use client';

import EyeIcon from '@/components/icons/eye';
import { Button } from '@/components/ui/button';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import { routes } from '@/config/routes';
import {
    capitalizeFirstLetter,
    convertSecondsToTime
} from '@/utils/common-functions';
import Link from 'next/link';
import { useSelector } from 'react-redux';

type Columns = {
    data?: any[];
    sortConfig?: any;
    handleSelectAll?: any;
    checkedItems: string[];
    onDeleteItem?: (
        id: string | string[],
        currentPage?: any,
        countPerPage?: number,
        Islastitem?: boolean,
        sortConfig?: Record<string, string>,
        searchTerm?: string
    ) => void;
    onHeaderCellClick: (value: string) => void;
    currentPage?: number;
    pageSize?: number;
    searchTerm?: string;
};

export const GetAttendanceColumns = ({
    sortConfig,
    onHeaderCellClick,
}: Columns) => {
    const { defaultWorkSpace } = useSelector(
        (state: any) => state?.root?.workspace
    );

    return [
        {
            title: (
                <HeaderCell
                    title="Name"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'user_details.full_name'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('user_details.full_name'),
            dataIndex: 'user_details',
            key: 'user_details.full_name',
            width: 200,
            render: (value: Record<string, string>) => (
                <Text className="poppins_font_number font-semibold capitalize text-black">
                    {capitalizeFirstLetter(value?.first_name)}  {capitalizeFirstLetter(value?.last_name)}
                </Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Total time"
                />
            ),
            onHeaderCell: () => onHeaderCellClick('total_time'),
            dataIndex: 'total_time',
            key: 'total_time',
            width: 200,
            render: (value: string) => {
                return (
                    <Text className="poppins_font_number font-semibold text-black">
                        {convertSecondsToTime(value)}
                    </Text>
                );
            },
        },
        {
            // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
            title: <HeaderCell title="Actions"  />,
            dataIndex: 'action',
            key: 'action',
            width: 120,
            render: (_: string, row: any) => (
                <div className="flex items-center gap-3 pe-4">
                    <Tooltip
                        size="sm"
                        content={() => 'View Details'}
                        placement="top"
                        color="invert"
                    >
                        <Link
                            className="rounded-md text-[#E3E1F4]"
                            href={routes?.attendanceDetails(
                                defaultWorkSpace?.name,
                                row?.user_details?._id
                            )}
                        >
                            <Button
                                size="sm"
                                variant="outline"
                                className="bg-[#E3E1F4] text-[#8C80D2]"
                                aria-label={'View Member'}
                            >
                                <EyeIcon className="h-4 w-4" />
                            </Button>
                        </Link>
                    </Tooltip>
                </div>
            ),
        },
    ];
};
