import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { DatePicker } from '@/components/ui/datepicker';
import { FieldError } from '@/components/ui/field-error';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  getUserDetailsAttendance,
  modifyLog,
} from '@/redux/slices/user/attendance/attendanceSlice';
import { getSettingData } from '@/redux/slices/user/setting/settingSlice';
import moment from 'moment';
import { useParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { GrLocation } from 'react-icons/gr';
import { LuClock } from 'react-icons/lu';
import { PiTrashFill, PiXBold } from 'react-icons/pi';
import { RiDeleteBinLine } from 'react-icons/ri';
import { useDispatch, useSelector } from 'react-redux';
import SimpleBar from 'simplebar-react';
import { checkPermission } from '../roles-permissions/utils';
import { Tooltip } from '@/components/ui/tooltip';
import { MdOutlineDone, MdOutlineModeEdit } from 'react-icons/md';
import { RxCross2 } from 'react-icons/rx';

const ManageAttendance = (props: any) => {
  const { title, logDetails = [], date } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const [addNewRecord, setAddNewRecord] = useState(false);
  const [deleteRecord, setDeleteRecord] = useState<any>([]);
  const [error, setError] = useState<boolean | string>(false);
  const [loading, setLoading] = useState<boolean | string>(true);
  const [editPermission, setEditPermission] = useState<boolean | string>(false);

  const [punchData, setPunchData] = useState<any>(logDetails);
  const [selectedDate, setSelectedDate] = useState<any>(new Date(date));

  const [newRecord, setNewRecord] = useState({
    punch_in: '',
    punch_out: '',
  });

  console.log('punchData.....', punchData);

  const { userId } = useParams();
  const { role, permission, user } = useSelector(
    (state: any) => state?.root?.signIn
  );
  const { settingData, getSettingDataLoading } = useSelector(
    (state: any) => state?.root?.setting
  );
  const simpleBarRef = useRef<any>(null);

  const [editedRecord, setEditedRecord] = useState<{
    punch_in: Date | null;
    punch_out: Date | null;
  }>({
    punch_in: null,
    punch_out: null,
  });
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);

  const {
    modifyLogLoader,
    paginationParams,
    detailsPagePaginationParams,
    userLocation,
    userDetailsAttendance,
  } = useSelector((state: any) => state?.root?.attendance);

  const permissionCheck = () => {
    const isPermission =
      ['agency', 'client'].includes(role) ||
      (['team_agency', 'team_client'].includes(role) &&
      checkPermission('attendance', null, 'everyone', permission)
        ? ['team_agency', 'team_client'].includes(role) &&
          checkPermission('attendance', null, 'update', permission)
          ? true
          : settingData?.attendance?.member_can_edit &&
            userId === user?.data?.user?._id
        : settingData?.attendance?.member_can_edit);
    return isPermission;
  };

  useEffect(() => {
    setEditPermission(permissionCheck());
    setLoading(false);
  }, [settingData?.attendance?.member_can_edit, userId]);

  useEffect(() => {
    dispatch(getSettingData());
  }, [dispatch]);

  useEffect(() => {
    if (simpleBarRef.current) {
      const scrollEl = simpleBarRef.current.getScrollElement();
      scrollEl.scrollTo({ top: scrollEl.scrollHeight, behavior: 'smooth' });
    }
  }, [newRecord]);

  const handleNewRecordChange = (field: any, value: any) => {
    setNewRecord({ ...newRecord, [field]: value });
  };

  const handleAddRecord = () => {
    setError(false);
    const { punch_in, punch_out } = newRecord;

    if (!punch_in) {
      setError('Punch In is required.');
      return;
    }

    if (!punch_out) {
      setError('Punch Out is required.');
      return;
    }

    const prevPunchOut =
      punchData.length > 0
        ? new Date(punchData[punchData.length - 1].punch_out)
        : null;

    const _nextPunchIn = punch_out ? new Date(punch_out) : null;

    if (prevPunchOut && new Date(punch_in) <= prevPunchOut) {
      setError('Punch In must be after the last Punch Out.');
      return;
    }

    if (punch_out && new Date(punch_out) <= new Date(punch_in)) {
      setError('Punch Out must be after Punch In.');
      return;
    }
    const newRecordObj = {
      _id: Date.now().toString(),
      punch_in,
      punch_out: punch_out || null,
      total_time: punch_out ? 1000 : null,
      new_record: true,
      punch_in_location:
        Object.keys(userLocation)?.length > 0
          ? `${userLocation?.city}, ${userLocation?.state}, ${userLocation?.country}`
          : 'NA',
      punch_out_location:
        Object.keys(userLocation)?.length > 0
          ? `${userLocation?.city}, ${userLocation?.state}, ${userLocation?.country}`
          : 'NA',
    };

    setPunchData([...punchData, newRecordObj]);
    // Reset form
    setNewRecord({ punch_in: '', punch_out: '' });
    setAddNewRecord(false);
  };

  const handleEdit = (id: string, field: any, newValue: any) => {
    setError(false);
    const updatedData = punchData.map((record: any, index: number) => {
      if (record._id === id) {
        const prevPunchOut =
          index > 0 ? new Date(punchData[index - 1].punch_out) : null;
        const nextPunchIn =
          index < punchData.length - 1
            ? new Date(punchData[index + 1].punch_in)
            : null;
        const currentPunchIn = new Date(record.punch_in);
        const currentPunchOut = record.punch_out
          ? new Date(record.punch_out)
          : null;

        if (field === 'punch_in') {
          const newPunchIn = new Date(newValue);
          if (
            (!prevPunchOut || newPunchIn > prevPunchOut) &&
            (!currentPunchOut || newPunchIn < currentPunchOut)
          ) {
            return { ...record, punch_in: newValue, update_record: true };
          } else {
            setError(
              'Invalid Punch In: Ensure it is after the previous Punch Out and before the current Punch Out.'
            );
          }
        }

        if (field === 'punch_out') {
          const newPunchOut = new Date(newValue);
          if (
            newPunchOut > currentPunchIn &&
            (!nextPunchIn || newPunchOut < nextPunchIn)
          ) {
            return { ...record, punch_out: newValue, update_record: true };
          } else {
            setError(
              'Invalid Punch Out: Ensure it is after the current Punch In and before the next Punch In.'
            );
          }
        }
      }
      return record;
    });
    setPunchData(updatedData);
  };

  const handleDelete = (id: string) => {
    const updatedData = punchData.filter((record: any) => record?._id !== id);
    const deleteData = punchData.filter(
      (record: any) => record?._id === id && !record?.new_record
    );

    setDeleteRecord([...deleteRecord, ...deleteData]);

    setPunchData(updatedData);
  };

  const handleSubmit = async () => {
    const newLogs = punchData?.filter((data: any) => data?.new_record);
    const updatedLog = punchData?.filter((data: any) => data?.update_record);
    const payload = {
      date: selectedDate ? selectedDate : date,
      newLogs,
      updatedLog,
      deleteRecord,
      user_id: userId,
      user_location: userLocation ? userLocation : [],
    };

    console.log(payload, 'payload');

    // return;
    const response = await dispatch(modifyLog(payload));
    console.log(response, 'response');
    if (response?.payload?.success) {
      closeModal();
      const {
        page,
        items_per_page,
        sort_field,
        sort_order,
        start_date,
        end_date,
        search,
      } = detailsPagePaginationParams;
      console.log(paginationParams, 'paginationParams');

      dispatch(
        getUserDetailsAttendance({
          page,
          items_per_page,
          sort_field,
          sort_order,
          // filter: {
          // date: { start_date, end_date },
          // },
          user_id: userId,
          search,
          pagination: true,
        })
      );
    }
  };

  const onDateChange = () => {
    setPunchData([]);
    setAddNewRecord(false);
    setNewRecord({ punch_in: '', punch_out: '' });
  };

  if (getSettingDataLoading || loading) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  const handleUpdatePunchData = () => {
    setError(false);
    let invalid = false;
    const updatedData = punchData.map((record: any, index: number) => {
      if (record._id === editingRecordId) {
        const prevPunchOut =
          index > 0 ? new Date(punchData[index - 1].punch_out) : null;
        const nextPunchIn =
          index < punchData.length - 1
            ? new Date(punchData[index + 1].punch_in)
            : null;
        const currentPunchIn = new Date(editedRecord.punch_in || '');
        const currentPunchOut = editedRecord.punch_out
          ? new Date(editedRecord.punch_out || '')
          : '';

        // Validate Punch In
        if (
          (!prevPunchOut || currentPunchIn > prevPunchOut) &&
          (!currentPunchOut || currentPunchIn < currentPunchOut)
        ) {
          // Validate Punch Out
          if (
            currentPunchOut &&
            currentPunchOut > currentPunchIn &&
            (!nextPunchIn || currentPunchOut < nextPunchIn)
          ) {
            return {
              ...record,
              punch_in: editedRecord.punch_in,
              punch_out: editedRecord.punch_out,
              update_record: true,
            };
          } else {
            setError(
              'Invalid Punch Out: Ensure it is after the current Punch In and before the next Punch In.'
            );
            invalid = true;
            return record;
          }
        }
        if (currentPunchIn >= currentPunchOut) {
          setError(
            'Invalid Punch Out: Ensure it is after the current Punch In .'
          );
          invalid = true;
          return record;
        } else {
          setError(
            'Invalid Punch In: Ensure it is after the previous Punch Out and before the current Punch Out.'
          );
          invalid = true;
          return record;
        }
      }
      return record;
    });
    console.log(updatedData, punchData, 'updatedData');
    setPunchData(updatedData);
    if (!invalid) setEditingRecordId(null); // Exit edit mode
  };

  const handleEditClick = (record: any) => {
    setEditingRecordId(record._id);
    setEditedRecord({
      punch_in: record.punch_in ? new Date(record.punch_in) : null,
      punch_out: record.punch_out ? new Date(record.punch_out) : null,
    });
  };

  const handleDateChange = (field: 'punch_in' | 'punch_out', date: Date) => {
    if (!date) return;
    setEditedRecord((prev: any) => ({
      ...prev,
      [field]: date.toISOString(), // Convert date to ISO format
    }));
  };

  const LocationContent = () =>
    userLocation?.city && userLocation?.state && userLocation?.country ? (
      <div className="flex items-center gap-2 rounded-lg bg-[#F5F5F5] p-2.5 text-[#111928]">
        <GrLocation className="h-4 w-4" />
        <span
          className="w-[110px] !truncate
           text-[10px] font-medium text-[#111928]"
        >
          {`${userLocation?.city}, ${userLocation?.state}, ${userLocation?.country}`}
        </span>
      </div>
    ) : (
      <div className="flex items-center gap-2 rounded-lg bg-[#F5F5F5] p-3 text-[#111928]">
        <GrLocation className="h-4 w-4" />
      </div>
    );

  return (
    <div className="space-y-5 p-6">
      <div className="mb-6 flex items-center justify-between">
        <Title
          as="h3"
          className="text-base font-bold text-[#141414] xl:text-2xl"
        >
          {title}
        </Title>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={closeModal}
          className="p-0 text-[#141414] hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>

      <div className="flex flex-col gap-4">
        {/* Select Date */}
        {/* <DatePicker
          selected={selectedDate}
          inputProps={{
            inputClassName: 'poppins_font_number',
          }}
          isClearable={false}
          popperPlacement="bottom-start"
          onChange={(e) => {
            setSelectedDate(e);
            onDateChange();
          }}
          disabled={true}
        /> */}
        <div className="text-sm font-semibold text-black">
          Date: {moment(selectedDate).format('DD MMM YYYY')}
        </div>
        {/* Punch Records Table */}

        <SimpleBar ref={simpleBarRef} className="max-h-[275px]">
          <div className="flex flex-col gap-4 pe-3">
            {punchData.map((record: any) => (
              <div
                className="flex items-center gap-2.5 rounded-md"
                key={record._id}
              >
                {editingRecordId === record._id ? (
                  // Show date picker when in edit mode
                  <div className="flex w-full items-center gap-2.5">
                    <div className="flex w-full flex-1 flex-col gap-3 rounded-md border-[1px] border-[#F0F0F0] bg-[#F9FAFB] p-3">
                      <div className="text-sm font-semibold text-black">
                        Edit Log
                      </div>
                      <div className="flex flex-1 gap-3">
                        {/* Punched-in */}
                        <div className="flex items-end justify-start gap-1.5 ">
                          <div className="flex w-[100px] flex-col gap-1">
                            <span className="text-[10px] font-medium leading-[140%] text-[#4B5563]">
                              Punched-in
                            </span>
                            <DatePicker
                              selected={
                                editedRecord.punch_in
                                  ? new Date(editedRecord.punch_in)
                                  : null
                              }
                              onChange={(date_in: any) =>
                                handleDateChange('punch_in', date_in)
                              }
                              inputProps={{
                                inputClassName: 'poppins_font_number ps-2',
                                prefixClassName: 'hidden',
                              }}
                              showTimeSelect
                              showTimeSelectOnly
                              isClearable={false}
                              popperPlacement="top-start"
                              dateFormat="h:mm aa"
                            />
                          </div>
                          {record?.location_punch_in?.address ? (
                            <Tooltip
                              size="sm"
                              content={() => (
                                <div className="max-w-[200px] text-[10px]">
                                  {record?.location_punch_in?.address ?? ''}
                                </div>
                              )}
                              placement="top"
                              color="invert"
                              className="demo_test"
                            >
                              <div className="flex items-center gap-2 rounded-lg bg-[#F5F5F5] p-2.5 text-[#111928]">
                                <GrLocation className="h-4 w-4" />
                                <span className=" w-[110px] !truncate text-[10px] font-medium text-[#111928]">
                                  {record?.location_punch_in?.city &&
                                  record?.location_punch_in?.state &&
                                  record?.location_punch_in?.country
                                    ? `${record?.location_punch_in?.city}, ${record?.location_punch_in?.state}, ${record?.location_punch_in?.country}`
                                    : 'NA'}
                                </span>
                              </div>
                            </Tooltip>
                          ) : (
                            <div className="flex items-center gap-2 rounded-lg bg-[#F5F5F5] p-2.5 text-[#111928]">
                              <GrLocation className="h-4 w-4" />
                              <span
                                className={`w-auto !truncate text-[10px] font-medium text-[#111928]`}
                              >
                                {record?.location_punch_in?.city &&
                                record?.location_punch_in?.state &&
                                record?.location_punch_in?.country
                                  ? `${record?.location_punch_in?.city}, ${record?.location_punch_in?.state}, ${record?.location_punch_in?.country}`
                                  : 'NA'}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Punched-out */}
                        <div className="flex items-end gap-1.5">
                          <div className="flex w-[100px] flex-col gap-1">
                            <span className="text-[10px] font-medium leading-[140%] text-[#4B5563]">
                              Punched-out
                            </span>
                            <DatePicker
                              selected={
                                editedRecord.punch_out
                                  ? new Date(editedRecord.punch_out)
                                  : null
                              }
                              onChange={(date_out: any) =>
                                handleDateChange('punch_out', date_out)
                              }
                              inputProps={{
                                inputClassName: 'poppins_font_number ps-2',
                                prefixClassName: 'hidden',
                              }}
                              showTimeSelect
                              showTimeSelectOnly
                              isClearable={false}
                              popperPlacement="top-start"
                              dateFormat="h:mm aa"
                            />
                          </div>
                          {record?.location_punch_out?.address ? (
                            <Tooltip
                              size="sm"
                              content={() => (
                                <div className="max-w-[200px] text-[10px]">
                                  {record?.location_punch_out?.address ?? ''}
                                </div>
                              )}
                              placement="top"
                              color="invert"
                              className="demo_test"
                            >
                              <div className="flex items-center gap-2 rounded-lg bg-[#F5F5F5] p-2.5 text-[#111928]">
                                <GrLocation className="h-4 w-4" />
                                <span className=" w-[110px] !truncate text-[10px] font-medium text-[#111928]">
                                  {record?.location_punch_out?.city &&
                                  record?.location_punch_out?.state &&
                                  record?.location_punch_out?.country
                                    ? `${record?.location_punch_out?.city}, ${record?.location_punch_out?.state}, ${record?.location_punch_out?.country}`
                                    : 'NA'}
                                </span>
                              </div>
                            </Tooltip>
                          ) : (
                            <div className="flex items-center gap-2 rounded-lg bg-[#F5F5F5] p-2.5 text-[#111928]">
                              <GrLocation className="h-4 w-4" />
                              <span
                                className={`w-auto !truncate text-[10px] font-medium text-[#111928]`}
                              >
                                {record?.location_punch_out?.city &&
                                record?.location_punch_out?.state &&
                                record?.location_punch_out?.country
                                  ? `${record?.location_punch_out?.city}, ${record?.location_punch_out?.state}, ${record?.location_punch_out?.country}`
                                  : 'NA'}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => {
                        handleUpdatePunchData();
                      }}
                      size="sm"
                      className="bg-[#31C48D0D] text-[#01A06B] hover:border-[#01A06B]"
                      title="Done"
                    >
                      <MdOutlineDone className="h-4 w-4" />
                    </Button>

                    <Button
                      onClick={() => {
                        setEditingRecordId(null);
                        setError(false);
                      }}
                      size="sm"
                      className="bg-[#FDF2F2] text-[#F05252] hover:border-[#F05252]"
                      title="Cancel"
                    >
                      <RxCross2 className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <div className="flex w-[49%] items-center gap-3 rounded-md border-[1px] border-[#F0F0F0] p-3">
                      <div className=" rounded-md bg-[#EBF5FF] p-2 text-[#1C64F2]">
                        <LuClock className="h-4 w-4" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-medium leading-[140%] text-[#4B5563]">
                          Punched-in
                        </span>
                        <span className="text-xs font-medium text-[#1C64F2] ">
                          {moment(record?.punch_in).format('LT')}
                        </span>
                      </div>
                      <div className="h-7 border-l border-[#D4D4D4]"></div>
                      <div className="flex flex-col">
                        <span className="mb-1 text-[10px] font-medium leading-[140%] text-[#4B5563]">
                          Location
                        </span>
                        <span className="text-[10px] font-medium leading-[100%] text-[##111928]">
                          {record?.punch_out_location
                            ? record?.punch_out_location
                            : record?.location_punch_in?.city &&
                                record?.location_punch_in?.state &&
                                record?.location_punch_in?.country
                              ? `${record?.location_punch_in?.city}, ${record?.location_punch_in?.state}, ${record?.location_punch_in?.country}`
                              : 'NA'}
                        </span>
                      </div>
                    </div>
                    <div className="flex w-[50%] items-center gap-3 rounded-md border-[1px] border-[#F0F0F0] p-3">
                      <div className=" rounded-md bg-[#FDF2F2] p-2 text-[#F05252]">
                        <LuClock className="h-4 w-4" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-medium leading-[140%] text-[#4B5563]">
                          Punched-out
                        </span>
                        <span className="text-xs font-medium text-[#E02424]">
                          {moment(record?.punch_out).format('LT')}
                        </span>
                      </div>
                      <div className="h-7 border-l border-[#D4D4D4]"></div>
                      <div className="flex flex-col">
                        <span className="mb-1 text-[10px] font-medium leading-[140%] text-[#4B5563]">
                          Location
                        </span>
                        <span className="text-[10px] font-medium leading-[100%] text-[##111928]">
                          {record?.punch_out_location
                            ? record?.punch_out_location
                            : record?.location_punch_out?.city &&
                                record?.location_punch_out?.state &&
                                record?.location_punch_out?.country
                              ? `${record?.location_punch_out?.city}, ${record?.location_punch_out?.state}, ${record?.location_punch_out?.country}`
                              : 'NA'}
                        </span>
                      </div>
                    </div>
                    {editPermission && (
                      <>
                        <Button
                          onClick={() => {
                            handleEditClick(record);
                          }}
                          size="sm"
                          variant="outline"
                          className="bg-[#F5F5F5] text-[#4B5563]"
                          aria-label={'View Member'}
                          title="Edit"
                        >
                          <MdOutlineModeEdit className="h-4 w-4" />
                        </Button>
                        <Button
                          onClick={() => handleDelete(record._id)}
                          size="sm"
                          // variant="outline"
                          className="bg-[#FDF2F2] text-[#F05252] hover:border-[#F05252]"
                          aria-label={'View Member'}
                          title="Delete"
                        >
                          <RiDeleteBinLine className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </>
                )}
              </div>
            ))}
            {addNewRecord && (
              <div className="flex items-center gap-2.5">
                <div className="flex w-full flex-col gap-3 rounded-md border-[1px] border-[#F0F0F0] bg-[#F9FAFB] p-3">
                  <div className="text-sm font-semibold text-black">
                    Add new log
                  </div>
                  <div className="flex flex-1 gap-3 ">
                    <div className=" flex items-end justify-start  gap-1.5 ">
                      <div className="flex w-[100px] flex-col gap-1">
                        <span className="text-[10px] font-medium leading-[140%] text-[#4B5563]">
                          Punched-in
                        </span>
                        <DatePicker
                          selected={
                            newRecord.punch_in || !addNewRecord
                              ? new Date(newRecord.punch_in)
                              : selectedDate
                          }
                          inputProps={{
                            inputClassName: 'poppins_font_number ps-2',
                            prefixClassName: 'hidden',
                          }}
                          onChange={(e) => {
                            setError(false);
                            handleNewRecordChange('punch_in', e);
                          }}
                          selectsStart
                          showTimeSelect
                          showTimeSelectOnly
                          isClearable={false}
                          popperPlacement="top-start"
                          dateFormat="h:mm aa"
                        />
                      </div>
                      {Object.keys(userLocation)?.length > 0 ? (
                        <Tooltip
                          size="sm"
                          content={() => (
                            <div className="max-w-[200px] text-[10px]">
                              {userLocation?.address ?? ''}
                            </div>
                          )}
                          placement="top"
                          color="invert"
                          className="demo_test"
                        >
                          <div>
                            <LocationContent />
                          </div>
                        </Tooltip>
                      ) : (
                        <LocationContent />
                      )}
                    </div>
                    <div className=" flex items-end gap-1.5">
                      <div className="flex w-[100px] flex-col gap-1">
                        <span className="text-[10px] font-medium leading-[140%] text-[#4B5563]">
                          Punched-out
                        </span>
                        <DatePicker
                          selected={
                            newRecord.punch_out || !addNewRecord
                              ? new Date(newRecord.punch_out)
                              : selectedDate
                          }
                          inputProps={{
                            inputClassName: 'poppins_font_number ps-2',
                            prefixClassName: 'hidden',
                          }}
                          onChange={(e) => {
                            setError(false);
                            handleNewRecordChange('punch_out', e);
                          }}
                          selectsStart
                          showTimeSelect
                          showTimeSelectOnly
                          isClearable={false}
                          popperPlacement="top-start"
                          dateFormat="h:mm aa"
                        />
                      </div>
                      {Object.keys(userLocation)?.length > 0 ? (
                        <Tooltip
                          size="sm"
                          content={({ setOpen }) => (
                            <div className="max-w-[200px] text-[10px]">
                              {userLocation?.address ?? ''}
                            </div>
                          )}
                          placement="top"
                          color="invert"
                          className="demo_test"
                        >
                          <div>
                            <LocationContent />
                          </div>
                        </Tooltip>
                      ) : (
                        <LocationContent />
                      )}
                    </div>
                  </div>
                </div>
                <Button
                  onClick={handleAddRecord}
                  size="sm"
                  // variant=""
                  className="bg-[#31C48D0D] text-[#01A06B] hover:border-[#01A06B]"
                  aria-label={'Add'}
                >
                  <MdOutlineDone className="h-4 w-4" />
                </Button>
                <Button
                  onClick={() => {
                    setAddNewRecord(!addNewRecord);
                    setNewRecord({ punch_in: '', punch_out: '' });
                    setError(false);
                  }}
                  size="sm"
                  // variant="outline"
                  className="bg-[#FDF2F2] text-[#F05252] hover:border-[#F05252] "
                  aria-label={'View Member'}
                >
                  <RiDeleteBinLine className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </SimpleBar>
      </div>
      {!!error && (
        <FieldError size="DEFAULT" className="!mt-1" error={error as string} />
      )}
      {editPermission && (
        <div className="flex items-center justify-around">
          {editPermission && !addNewRecord && (
            <Button
              onClick={() => {
                setAddNewRecord(!addNewRecord);
                console.log(
                  newRecord.punch_in || addNewRecord,
                  new Date(newRecord.punch_in),
                  selectedDate,
                  1123
                );
                setNewRecord({
                  punch_in:
                    newRecord.punch_in || addNewRecord
                      ? new Date(newRecord.punch_in)
                      : selectedDate,
                  punch_out:
                    newRecord.punch_out || addNewRecord
                      ? new Date(newRecord.punch_out)
                      : selectedDate,
                });
              }}
              size="DEFAULT"
              // variant=""
              className="border-[#6875F5] bg-white px-3 py-2 text-sm font-semibold text-[#6875F5]"
              aria-label={'Add'}
            >
              Add
            </Button>
          )}

          <Button
            type="submit"
            onClick={handleSubmit}
            className="ms-auto flex items-center justify-center rounded-lg bg-[#7667CF] px-4 py-3 text-sm font-semibold text-[#ffffff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
            size="DEFAULT"
            disabled={modifyLogLoader}
          >
            Save Changes
            {modifyLogLoader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
      )}
    </div>
  );
};

export default ManageAttendance;
