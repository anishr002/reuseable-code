'use client';

import CustomModalButton from '@/app/shared/custom-modal-button';
import DeletePopover from '@/app/shared/delete-popover';
import EyeIcon from '@/components/icons/eye';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import {
  convertSecondsToTime,
  formatDateWithDay,
} from '@/utils/common-functions';
import moment from 'moment';
import { useParams } from 'next/navigation';
import { PiMapPin, PiPlusBold } from 'react-icons/pi';
import { useSelector } from 'react-redux';
import { checkPermission } from '../../roles-permissions/utils';
import ManageAttendance from '../manage-attendance';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll?: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string,
    row?: any
  ) => void;
  onHeaderCellClick: (value: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const GetAttendanceDetailsColumns = ({
  data,
  sortConfig,
  currentPage,
  pageSize,
  searchTerm,
  onHeaderCellClick,
  onDeleteItem,
}: Columns) => {
  const { settingData,holidayData } = useSelector((state: any) => state?.root?.setting);
  const { user, role, permission } = useSelector(
    (state: any) => state?.root?.signIn
  );
  const { userId } = useParams();

  const showWorkingStatus = (date: any, totalTime: any) => {
    totalTime = totalTime / 3600;
    const isCustomHoliday = holidayData?.holidays?.some(
      (holiday:any) => moment(holiday.date).isSame(moment(date), 'day')
    );

    if (totalTime === 0) {
      if (
        settingData?.attendance?.default_holiday?.includes(
          moment(date)?.format('ddd')?.toLowerCase() 
        ) || isCustomHoliday
      ) {
        return (
          <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
            <Text className="font-semibold text-[#AC2D2D]">Holiday</Text>
          </div>
        );
      }

      if (moment(date).isSame(moment(), 'day')) {
        return (
          <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
            <Text className="font-semibold text-[#AC2D2D]">No available</Text>
          </div>
        );
      }

      return (
        <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
          <Text className="font-semibold text-[#AC2D2D]">Leave</Text>
        </div>
      );
    } else if (
      totalTime >= Number(settingData?.attendance?.half_day) &&
      totalTime < Number(settingData?.attendance?.full_day)
    ) {
      return (
        <div
          className={`status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFEAC3] px-[20px] py-[8px] text-xs sm:text-sm`}
        >
          <Text className="font-semibold text-[#8C6825]">Half Day</Text>
        </div>
      );
    } else if (totalTime >= Number(settingData?.attendance?.full_day)) {
      return (
        <div className="status_pad flex cursor-not-allowed items-center justify-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
          <Text className="font-semibold text-[#527C31]">Full Day</Text>
        </div>
      );
    } else {
      return (
        <div
          className={`status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#CBE3FB] px-[20px] py-[8px] text-xs sm:text-sm`}
        >
          <Text className="font-semibold text-[#43688D]">Partial day</Text>
        </div>
      );
    }
  };

  return [
    {
      title: (
        <HeaderCell
          title="Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('date'),
      dataIndex: 'date',
      key: 'date',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-semibold capitalize text-black">
          {formatDateWithDay(value)}
        </Text>
      ),
    },
    {
      title: <HeaderCell title="First in"  />,
      dataIndex: 'first_punch_in',
      key: 'first_punch_in',
      width: 200,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-semibold text-black">
            {value ? moment(value).format('HH:mm') : '-'}
          </Text>
        );
      },
    },
    {
      title: <HeaderCell title="Last Out"  />,
      dataIndex: 'last_punch_out',
      key: 'last_punch_out',
      width: 200,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-semibold text-black">
            {value ? moment(value).format('HH:mm') : '-'}
          </Text>
        );
      },
    },
    {
      title: <HeaderCell title="Working Hours"  />,
      dataIndex: 'total_time',
      key: 'total_time',
      width: 150,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-semibold text-black">
            {convertSecondsToTime(value)}
          </Text>
        );
      },
    },
    {
      title: <HeaderCell title="Location"  />,
      dataIndex: 'first_location_punch_in',
      key: 'first_location_punch_in',
      width: 200,
      render: (value: any, row: Record<string, any>) => {
        return (
          <>
            {row?.total_time > 0 && row?.first_location_punch_in ? (
              <Text className="poppins_font_number flex items-center justify-start gap-3 font-semibold text-black">
                <PiMapPin />
                {`${
                  row?.first_location_punch_in?.city &&
                  row?.first_location_punch_in?.city !== ''
                    ? `${row?.first_location_punch_in?.city},`
                    : ''
                }
                ${
                  row?.first_location_punch_in?.state &&
                  row?.first_location_punch_in?.state !== ''
                    ? `${row?.first_location_punch_in?.state},`
                    : ''
                }
                ${
                  row?.first_location_punch_in?.country &&
                  row?.first_location_punch_in?.country !== ''
                    ? `${row?.first_location_punch_in?.country}.`
                    : ''
                }
                `}
              </Text>
            ) : (
              <Text className="poppins_font_number flex items-center justify-start gap-3 font-semibold text-black">
                -
              </Text>
            )}
          </>
        );
      },
    },
    {
      title: <HeaderCell title="Working Status"  />,
      dataIndex: 'total_time',
      key: 'total_time',
      width: 200,
      render: (value: string, row: any) => {
        return (
          <Text className="poppins_font_number font-semibold text-black">
            {showWorkingStatus(row?.date, value)}
          </Text>
        );
      },
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions"  />,
      dataIndex: '',
      key: '',
      width: 120,
      render: (_: string, row: any) => {
        return (
          <div className="flex items-center gap-3 pe-4">
            {row?.total_time > 0 && (
              <CustomModalButton
                className="bg-[#E3E1F4] text-[#8C80D2]"
                icon={<EyeIcon className="h-4 w-4" />}
                view={
                  <ManageAttendance
                    title={'View Attendance Details'}
                    logDetails={row?.logs}
                    date={row?.date}
                    user_id={user?.data?.user?._id}
                  />
                }
                customSize="722px"
                title="View Details"
              />
            )}
            {row?.total_time === 0 &&
              (['agency', 'client'].includes(role) ||
                (['team_agency', 'team_client'].includes(role) &&
                  (checkPermission('attendance', null, 'update', permission) ||
                    (settingData?.attendance?.member_can_edit &&
                      user?.data?.user?._id === userId)))) && (
                <CustomModalButton
                  className="bg-[#E3E1F4] text-[#8C80D2]"
                  icon={<PiPlusBold className="h-4 w-4" />}
                  view={
                    <ManageAttendance
                      title={'Add Log'}
                      logDetails={[]}
                      date={row?.date}
                      user_id={user?.data?.user?._id}
                    />
                  }
                  customSize="600px"
                  title="Add Log"
                />
              )}
            {row?.total_time > 0 &&
              (['agency', 'client'].includes(role) ||
                (['team_agency', 'team_client'].includes(role) &&
                  (checkPermission('attendance', null, 'delete', permission) ||
                    (settingData?.attendance?.member_can_edit &&
                      user?.data?.user?._id === userId)))) && (
                <DeletePopover
                  deleteButtonClass="bg-[#E3E1F4] text-[#8C80D2]"
                  title={`Delete the tracked attendace`}
                  description={`Are you sure you want to remove?`}
                  onDelete={() =>
                    onDeleteItem(
                      row?._id,
                      currentPage,
                      pageSize,
                      data?.length <= 1 ? true : false,
                      sortConfig,
                      searchTerm,
                      row
                    )
                  }
                />
              )}
          </div>
        );
      },
    },
  ];
};
