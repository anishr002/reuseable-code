import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { ActionIcon } from '@/components/ui/text';
import {
  CreateChatGroupPayload,
  createChatGroup,
  emptyMemberList,
  getGroupById,
  getMemberList,
  leaveChatGroup,
  updateChatGroup,
} from '@/redux/slices/user/chat/group/groupChatSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import profile_img_icn from '@public/assets/images/profile_img_icn.png';
import { ErrorMessage, Field, FieldProps, Form, Formik } from 'formik';
import Image from 'next/image';
import React, { Fragment, useEffect, useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { FiTrash2 } from 'react-icons/fi';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect, { components } from 'react-select';
import { Avatar, Textarea } from 'rizzui';
import * as Yup from 'yup';

export default function CreateGroupForm(props: any) {
  const dispatch = useDispatch();
  const { title, groupDetail, canUpdate, isEdit } = props;
  const { closeModal } = useModal();
  const [searchQuery, setSearchQuery] = useState('');
  const [memberListRef, setmemberListRef] = useState([]);
  const [isFormDisabled, setIsFormDisabled] = useState(false);
  const [singleGroupDetailsLoader, setSingleGroupDetailsLoader] =
    useState(false);
  const [previewImage, setpreviewImage] = useState<any>(undefined);

  const imageref = useRef<any>();
  // Group members
  const [selectedMembers, setSelectedMembers] = useState<any>([]);

  // console.log('memberListRef.....', memberListRef);
  // console.log('selectedMembers.....', selectedMembers);

  const validationSchema = Yup.object().shape({
    group_image: Yup.mixed().nullable().notRequired(),
    group_name: Yup.string()
      .required('Group name is required')
      .max(20, 'Maximum 20 characters allowed')
      .trim(),
    description: Yup.string()
      .notRequired()
      .max(800, 'Maximum 800 characters allowed')
      .trim(),
    members: Yup.array().min(1, 'At least one member must be selected'),
  });

  const [initialValues, setInitialValues] = useState<any>({
    group_image: '',
    group_name: '',
    description: '',
    members: [],
  });

  // Selectors
  const {
    leaveChatGroupLoader,
    memberListLoader,
    createGroupLoader,
    updateGroupLoader,
    memberList,
  } = useSelector((state: any) => state?.root?.group);

  const getIdFromArray = (list: any) => {
    return list?.map((data: any) => data?._id);
  };

  useEffect(() => {
    dispatch(emptyMemberList());
    setmemberListRef([]);

    if (!!groupDetail?._id) {
      setSingleGroupDetailsLoader(true);

      // Get Group Data By Id
      dispatch(getGroupById(groupDetail?._id)).then((result: any) => {
        setSingleGroupDetailsLoader(false);
        if (getGroupById.fulfilled.match(result)) {
          if (
            result &&
            result.payload.success === true &&
            result.payload?.data?.length > 0
          ) {
            const groupMembersIds =
              getIdFromArray(result?.payload?.data?.[0]?.members ?? []) ?? [];
            setInitialValues({
              group_image: result.payload?.data[0]?.image_url ?? '',
              group_name: result.payload?.data?.[0]?.group_name ?? '',
              description: result.payload?.data?.[0]?.description ?? '',
              members: groupMembersIds,
            });

            if (
              result.payload?.data[0]?.image_url &&
              result.payload?.data[0]?.image_url !== 'null' &&
              result.payload?.data[0]?.image_url !== null
            ) {
              setpreviewImage(
                process.env.NEXT_PUBLIC_IMAGE_URL +
                  '/uploads/' +
                  result.payload?.data[0]?.image_url
              );
            }

            dispatch(getMemberList()).then((result: any) => {
              if (getMemberList.fulfilled.match(result)) {
                if (result && result?.payload?.success === true) {
                  const allMembers = result.payload?.data ?? [];
                  setmemberListRef(allMembers);

                  const membersOptions =
                    allMembers?.length > 0
                      ? allMembers?.map((member: Record<string, any>) => {
                          const userName = `${capitalizeFirstLetter(
                            member?.first_name
                          )} ${capitalizeFirstLetter(member?.last_name)}`;

                          return {
                            name: userName,
                            label: userName,
                            value: member?.user_id,
                            member,
                          };
                        })
                      : [];

                  // console.log('groupMembersIds......', groupMembersIds);

                  const updatedMembers =
                    membersOptions?.filter(
                      (item: Record<string, any>, index: number) => {
                        return (
                          groupMembersIds &&
                          groupMembersIds?.length > 0 &&
                          groupMembersIds.includes(item?.value)
                        );
                      }
                    ) ?? [];
                  // set selected members to show
                  // console.log('updatedMembers......', updatedMembers);
                  setSelectedMembers(updatedMembers);
                }
              }
            });

            if (!canUpdate) {
              setIsFormDisabled(true);
            }
          }
        }
      });
    } else {
      dispatch(getMemberList()).then((result: any) => {
        if (getMemberList.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setmemberListRef(result?.payload?.data ?? []);
          }
        }
      });
    }
  }, [dispatch, groupDetail?._id]);

  const displayRoleName = (roleName: string) => {
    switch (roleName) {
      case 'agency':
        return <span>(Super Admin)</span>;
      case 'client':
        return <span>(Client)</span>;
      case 'team_agency':
        return <span>(Team)</span>;
      case 'team_client':
        return <span>(Client Team)</span>;
      default:
        return <span>{roleName}</span>;
    }
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    const file = URL.createObjectURL(acceptedFiles[0]);
    // setValue("board_image", acceptedFiles[0])
    imageref.current('group_image', acceptedFiles[0]);
    setpreviewImage(file);
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    // useFsAccessApi: false,
    onDrop: handleDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png'],
    }, // Accept only JPEG and PNG images
    maxSize: 10 * 1024 * 1024, // Maximum file size of 10MB
    multiple: false,
    noClick: false,
  };

  // Submit Group details
  const handleSubmit = (data: CreateChatGroupPayload) => {
    if (!canUpdate) return;

    const formdata = new FormData();

    if (isEdit) {
      formdata.append('group_name', data?.group_name?.trim());
      formdata.append('description', data?.description?.trim() ?? '');
      formdata.append('group_id', groupDetail?._id);
      data?.members.forEach((id: any) => {
        formdata.append('members', id);
      });
      formdata.append('group_image', data?.group_image);

      dispatch(updateChatGroup(formdata)).then((result: any) => {
        if (updateChatGroup.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            dispatch(getGroupById(groupDetail?._id));
            closeModal();
          }
        }
      });
    } else {
      formdata.append('group_name', data?.group_name?.trim());
      formdata.append('description', data?.description?.trim() ?? '');
      data?.members.forEach((id: any) => {
        formdata.append('members', id);
      });

      formdata.append('group_image', data?.group_image);

      dispatch(createChatGroup(formdata)).then((result: any) => {
        if (createChatGroup.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            closeModal();
          }
        }
      });
    }
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps } = useDropzone(dropzoneOptions);

  if (!!groupDetail?._id && singleGroupDetailsLoader) {
    return (
      <div className="flex justify-center p-10">
        <Spinner size="xl" />
      </div>
    );
  }

  // All members options
  const groupMembersOptions = [
    ...(memberListRef?.length > 0
      ? memberListRef?.map((member: Record<string, any>) => {
          const userName = `${capitalizeFirstLetter(
            member?.first_name
          )} ${capitalizeFirstLetter(member?.last_name)}`;

          return {
            name: userName,
            label: userName,
            value: member?.user_id,
            member,
          };
        })
      : []),
  ];

  const customStyles = {
    container: (provided: any) => ({
      ...provided,
      borderColor: 'rgb(209 213 219)',
      borderRadius: '4px',
      height: '36px',
    }),
    control: (provided: any, state: any) => ({
      ...provided,
      borderColor: 'rgb(209 213 219)', // Black border for the control (dropdown)
      borderRadius: '4px',
      boxShadow: state.isFocused ? '0 0 0 0 black' : 'none', // Highlight on focus
      '&:hover': {
        borderColor: 'black', // Black border on hover
      },
      height: '36px',
      // paddingInline: '8px',
    }),
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected
        ? '#8c80d2'
        : state.isFocused
          ? '#f0f0f0'
          : 'white', // Highlighted background on hover
      color: state.isSelected ? 'white' : 'black',
      // marginTop: '6px',
    }),
    menu: (provided: any) => ({
      ...provided,
      borderRadius: '4px',
    }),
    placeholder: (provided: any) => ({
      ...provided,
      color: 'black', // Placeholder text color
    }),
  };

  const CustomValueContainer = ({ children, ...props }: any) => {
    return (
      <components.ValueContainer {...props}>
        {children}
      </components.ValueContainer>
    );
  };

  return (
    <>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize={true}
        onSubmit={handleSubmit}
      >
        {({ errors, isSubmitting, handleChange, values, setFieldValue }) => (
          <Form className="flex flex-col gap-4 border border-black p-8 [&_label]:font-normal">
            <div className="flex items-center justify-between gap-2">
              <p className="overflow-hidden truncate whitespace-nowrap text-[20px] font-semibold leading-[30px] text-[#141414]">
                {title}
              </p>
              <ActionIcon
                size="sm"
                variant="text"
                onClick={closeModal}
                className="flex items-center justify-center p-0 text-[#141414] hover:!text-gray-900"
              >
                <PiXBold className="h-5 w-5" />
              </ActionIcon>
            </div>
            {/* profile image upload */}
            <div className="flex flex-col items-center justify-start gap-6 lg:flex-row">
              {canUpdate && !!previewImage && (
                <>
                  <input {...getInputProps()} />
                  <div {...getRootProps()}>
                    <div
                      className="flex h-[80px] w-[80px] cursor-pointer items-center justify-center rounded-lg border border-[#E5E7EB] bg-transparent object-cover"
                      onClick={() => {
                        imageref.current = setFieldValue;
                      }}
                    >
                      <img
                        src={previewImage} // Path to your image
                        alt="Profile Image"
                        className="h-full w-full cursor-pointer rounded-md object-cover" // Optional Tailwind CSS class
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-start gap-2 ">
                    <div {...getRootProps()}>
                      <Button
                        className="flex h-9 cursor-pointer flex-col items-center justify-center rounded-lg border border-[#E5E7EB]  !bg-white px-4 py-3 text-sm font-medium text-black hover:border-black"
                        onClick={() => {
                          imageref.current = setFieldValue;
                        }}
                      >
                        Change Picture
                      </Button>
                    </div>

                    <Button
                      variant="text"
                      size="sm"
                      onClick={() => {
                        setpreviewImage(null);
                        setFieldValue('group_image', '');
                      }}
                      className="flex items-center justify-center text-gray-500"
                    >
                      <FiTrash2 className="h-5 w-5" />
                    </Button>
                  </div>
                </>
              )}
              {((!isEdit && !previewImage) || (canUpdate && !previewImage)) && (
                <>
                  <input {...getInputProps()} />
                  <div {...getRootProps()}>
                    <div
                      className="flex h-[80px] w-[80px] cursor-pointer items-center justify-center rounded-lg border border-[#E5E7EB] bg-transparent object-cover"
                      onClick={() => {
                        imageref.current = setFieldValue;
                      }}
                    >
                      <Image
                        src={profile_img_icn} // Path to your image
                        alt="Description of image"
                        width={40} // Desired width
                        height={40} // Desired height
                        className="cursor-pointer rounded-md" // Optional Tailwind CSS class
                      />
                    </div>
                  </div>

                  {/* Upload button */}
                  <div {...getRootProps()}>
                    <div
                      onClick={() => {
                        imageref.current = setFieldValue;
                      }}
                      className="flex h-9 cursor-pointer flex-col items-center justify-center rounded-lg border border-[#E5E7EB] px-4 py-3 hover:border-black"
                    >
                      <span className="text-sm font-medium text-black">
                        Upload cover image
                      </span>
                    </div>
                  </div>
                </>
              )}
              {isEdit && !canUpdate && (
                <>
                  <div className="flex h-[80px] w-[80px] cursor-pointer items-center justify-center rounded-lg border border-[#E5E7EB] bg-transparent object-cover">
                    <img
                      src={!!previewImage ? previewImage : profile_img_icn.src} // Path to your image
                      alt="Profile Image"
                      className="h-full w-full rounded-md object-cover" // Optional Tailwind CSS class
                    />
                  </div>
                </>
              )}
            </div>
            <div className="grid grid-cols-1">
              <Field name="group_name" id="group_name">
                {({ field, meta }: FieldProps) => (
                  <Input
                    disabled={isFormDisabled}
                    onKeyDown={handleKeyDown}
                    {...field}
                    label="Group name *"
                    placeholder="Enter group name"
                    labelClassName="font-normal text-sm text-[#141414]"
                    inputClassName="h-[36px]"
                    className="w-full"
                    maxLength={20}
                  />
                )}
              </Field>
              <ErrorMessage
                name="group_name"
                component="div"
                className="mt-0.5 text-xs text-red"
              />
            </div>
            <div className="grid grid-cols-1">
              <Field name="description" id="description">
                {({ field, meta }: FieldProps) => (
                  <Textarea
                    disabled={isFormDisabled}
                    onKeyDown={handleKeyDown}
                    placeholder="Add group description here..."
                    {...field}
                    rows={2}
                    label="Description"
                    textareaClassName="font-normal  text-sm text-[#141414]  bg-[#F9FAFB]"
                    labelClassName="font-normal  text-sm text-[#141414]"
                  />
                )}
              </Field>
              <ErrorMessage
                name="description"
                component="div"
                className="mt-0.5 text-xs text-red"
              />
            </div>
            <div className="w-full flex flex-col gap-1">
              <label className="text-sm font-normal text-[#141414]">
                Add members *
              </label>
              <ReactSelect
                options={groupMembersOptions}
                onChange={(selected: any) => {
                  console.log(selected, '......selected');
                  setSelectedMembers(selected);
                  if (selected && selected?.length > 0) {
                    const selectedOptions =
                      selected?.map((data: any) => data?.value) ?? [];
                    setFieldValue('members', selectedOptions);
                  } else {
                    setFieldValue('members', []);
                  }
                }}
                value={selectedMembers}
                isDisabled={isFormDisabled}
                isMulti
                closeMenuOnSelect={false}
                placeholder="Select members"
                className="poppins_font_number task-assign h-[36px] w-full"
                classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                components={{
                  ValueContainer: CustomValueContainer, // Always show input & placeholder
                  MultiValue: () => null, // Hide the chips for selected options
                }}
                hideSelectedOptions={false}
                styles={customStyles}
                isClearable={false}
              />
              <ErrorMessage
                name="members"
                component="div"
                className="text-xs text-red"
              />
            </div>

            {selectedMembers && selectedMembers?.length > 0 && (
              <SimpleBar
                className={cn(
                  'max-h-[135px] rounded-lg border border-[#E5E7EB]'
                )}
              >
                {selectedMembers?.map((item: any, index: any) => (
                  <Fragment key={index}>
                    <div className="flex items-center justify-between gap-2 border-b border-gray-300 px-2 py-2 text-sm last:border-0 ">
                      {/* Avatar and text container */}
                      <div className="flex w-full items-center justify-start gap-3">
                        <div className="!h-6 !w-6">
                          <Avatar
                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.member?.profile_image}`}
                            name={item?.name ?? ''}
                            className="!h-6 !w-6 bg-[#70C5E0] text-xs font-medium text-white"
                          />
                        </div>

                        <div className="text-xs font-medium capitalize text-[#111928]">
                          {item?.name ?? ''}
                        </div>
                      </div>

                      {/* Clear icon container */}
                      {!isFormDisabled && (
                        <ActionIcon
                          size="sm"
                          variant="text"
                          onClick={() => {
                            const updatedMembers =
                              selectedMembers?.filter(
                                (member: any) => member?.value !== item?.value
                              ) ?? [];
                            const updatedMembersId =
                              updatedMembers?.map(
                                (member: any) => member?.value
                              ) ?? [];
                            setFieldValue('members', updatedMembersId);
                            setSelectedMembers(updatedMembers);
                          }}
                          className="flex items-center justify-center p-0 text-[#141414]"
                        >
                          <PiXBold className="h-4 w-4" />
                        </ActionIcon>
                      )}
                    </div>
                  </Fragment>
                ))}
              </SimpleBar>
            )}

            {/* Footer buttons */}
            <div className={cn('flex items-center justify-end gap-4 pt-2')}>
              <Button
                type="button"
                className="h-[36px] w-auto rounded-[8px] border border-gray-300  text-sm text-[#141414]"
                onClick={closeModal}
                variant="outline"
              >
                Cancel
              </Button>
              {canUpdate && (
                <Button
                  disabled={!isEdit ? createGroupLoader : updateGroupLoader}
                  type="submit"
                  className="flex h-[36px] 
                    w-auto items-center justify-center rounded-[8px] bg-[#7667CF] text-sm text-white"
                >
                  {!isEdit ? 'Create Group' : 'Save changes'}
                  {(!isEdit ? createGroupLoader : updateGroupLoader) && (
                    <Spinner
                      size="sm"
                      tag="div"
                      className="ms-3"
                      color="white"
                    />
                  )}
                </Button>
              )}
            </div>
          </Form>
        )}
      </Formik>
    </>
  );
}
