import { GetDocumentDownloadApi } from '@/api/user/chat/chatApis';
import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { useModal } from '@/app/shared/modal-views/use-modal';
import PencilIcon from '@/components/icons/pencil';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import EmptyBox from '@/components/ui/empty-box';
import Select from '@/components/ui/select';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Text } from '@/components/ui/text';
import {
  emptyFileList,
  getSharedFiles,
  setProfileFilter,
} from '@/redux/slices/user/chat/chatSlice';
import { getGroupById } from '@/redux/slices/user/chat/group/groupChatSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter, getFileType } from '@/utils/common-functions';
import EmptyInfo from '@public/assets/images/chat-icons/Search_empty.png';
import { debounce } from 'lodash';
import moment from 'moment';
import Link from 'next/link';
import { Fragment, useEffect, useRef, useState } from 'react';
import { GoChevronLeft } from 'react-icons/go';
import { LuPhone } from 'react-icons/lu';
import { MdOutlineEmail } from 'react-icons/md';
import { PiCaretDownBold, PiDownloadSimpleBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { checkPermission } from '../../roles-permissions/utils';
import CreateGroupForm from '../group/create-group';
import { LeaveGroupConfirmationModal } from './leave-group-confirmation';

const NEXT_PUBLIC_IMAGE_URL = process.env.NEXT_PUBLIC_IMAGE_URL;

const mediaFilterOptions = [
  { name: 'All media', value: '' },
  { name: 'Images', value: 'images' },
  { name: 'Documents', value: 'documents' },
  { name: 'Audio', value: 'audio' },
];

const menuItems = [
  {
    label: 'Info',
    value: 'info',
  },
  {
    label: 'Media',
    value: 'media',
  },
  {
    label: 'Members',
    value: 'members',
  },
];

export const ProfileViewPage = ({
  chatUser,
  setShowProfileDetails,
}: {
  chatUser: any;
  setShowProfileDetails: any;
}) => {
  // Variable
  const initChatPageination = {
    page: 1,
    items_per_page: 10,
    sort_order: 'asc',
    sort_field: '',
    search: '',
    to_user: '',
    document_type: '',
  };

  const initGroupPageination = {
    page: 1,
    items_per_page: 10,
    sort_order: 'asc',
    sort_field: '',
    search: '',
    group_id: '',
    document_type: '',
  };

  const isGroup = chatUser?.chat_type === 'group' ? true : false;

  // State
  const [pagination, setPagination] = useState(
    isGroup ? initGroupPageination : initChatPageination
  );
  const [selectedTab, setSelectedTab] = useState('info');
  const [loading, setLoading] = useState(false);
  const [scrollLoading, setScrollLoading] = useState(false);
  const fileContainerRef = useRef(null);
  const { openModal } = useModal();
  const [selectedMediaOption, setSelectedMediaOption] = useState<any>('');
  console.log('selectedMediaOption.....', selectedMediaOption);
  // console.log('pagination.....', pagination);
  // Hooks
  const dispatch = useDispatch();

  // Selectors
  const { fileList, page_count } = useSelector(
    (state: any) => state?.root?.chat
  );
  const { singleGroupDetails, leaveChatGroupLoader } = useSelector(
    (state: any) => state?.root?.group
  );
  const signInUserData = useSelector((state: any) => state?.root?.signIn);

  console.log('singleGroupDetails.....', singleGroupDetails);

  // Helper Funcation
  const getAvatarName = (data: any) => {
    let displayName = '';
    if (isGroup) {
      if (data?.group_name) {
        displayName += capitalizeFirstLetter(data?.group_name);
      }
    } else {
      if (data?.first_name) {
        displayName += capitalizeFirstLetter(data?.first_name);
      }
      if (data?.last_name) {
        displayName += ' ' + capitalizeFirstLetter(data?.last_name);
      }
    }
    return displayName;
  };

  const getAvatarImage = (data: any) => {
    let avatarURL;
    if (isGroup) {
      if (
        data?.image_url &&
        data?.image_url !== 'null' &&
        data?.image_url !== null
      ) {
        avatarURL =
          process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.image_url;
      }
    } else {
      if (
        data?.profile_image &&
        data?.profile_image !== 'null' &&
        data?.profile_image !== null
      ) {
        avatarURL =
          process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.profile_image;
      }
    }
    return avatarURL;
  };

  const handleMediaChange = (selectedOption: string) => {
    setSelectedMediaOption(selectedOption);
    dispatch(emptyFileList());
    if (isGroup) {
      setPagination((prevState) => {
        return {
          ...prevState,
          page: 1,
          group_id: chatUser?._id,
          to_user: '',
          document_type: selectedOption,
        };
      });
    } else {
      setPagination((prevState) => {
        return {
          ...prevState,
          page: 1,
          group_id: '',
          to_user: chatUser?._id,
          document_type: selectedOption,
        };
      });
    }
  };

  useEffect(() => {
    // chat user change => remove file list
    dispatch(emptyFileList());
    setPagination(isGroup ? initGroupPageination : initChatPageination);
  }, [chatUser?._id]);

  // media api call main
  useEffect(() => {
    if (!chatUser) {
      return;
    }
    dispatch(setProfileFilter(pagination?.document_type ?? ''));
    setLoading(true);
    if (isGroup) {
      dispatch(
        getSharedFiles({ ...pagination, to_user: '', group_id: chatUser?._id })
      ).then((result: any) => {
        setLoading(false); // api call loader
        setScrollLoading(false); // loadmore api call loader
      });
    } else {
      dispatch(
        getSharedFiles({ ...pagination, group_id: '', to_user: chatUser?._id })
      ).then((result: any) => {
        setLoading(false); // api call loader
        setScrollLoading(false); // loadmore api call loader
      });
    }
  }, [selectedMediaOption, isGroup, dispatch, pagination]);

  // Load more functionality logic for fetching media listing
  const handleScroll = debounce((e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      if (pagination?.page < page_count) {
        setPagination((prevState) => {
          return {
            ...prevState,
            page: prevState?.page + 1,
          };
        });
        setScrollLoading(true);
      }
    }
  }, 200);

  // Image download function
  const downloadFile = async (data: any) => {
    const fileUrl = `${NEXT_PUBLIC_IMAGE_URL}/uploads/${data?.file_url}`;
    const fileName = data?.original_file_name ?? 'Image';

    await GetDocumentDownloadApi(fileUrl).then((data: any) => {
      const href = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = href;
      link.setAttribute('download', fileName?.split('.')?.[0]);
      document.body.appendChild(link);
      link.click();

      document.body.removeChild(link);
      URL.revokeObjectURL(href);
    });
  };

  const manageList = async (data: any) => {
    if (data?.file_url) {
      const fileUrl = NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.file_url;
      const fileName = data?.original_file_name
        ?.replace(/\s+/g, '_')
        ?.split('.')?.[0];
      await GetDocumentDownloadApi(fileUrl).then((data: any) => {
        const href = URL.createObjectURL(data);
        const link = document.createElement('a');
        link.href = href;
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();

        document.body.removeChild(link);
        URL.revokeObjectURL(href);
      });
    }

    // if (data?.file_url) {
    //   downloadFile(data);
    //Image Preview

    // const fileUrl = `${NEXT_PUBLIC_IMAGE_URL}/uploads/${data?.file_url}`;
    // openModal({
    //   view: (
    //     <ImagePreviewModel
    //       fileUrl={fileUrl}
    //       original_file_name={data?.original_file_name}
    //       downloadFile={() => downloadFile(data)}
    //     />
    //   ),
    //   customSize: '100%',
    // });
    // }
  };

  const canUpdate =
    ['agency', 'client'].includes(signInUserData?.role) ||
    (['team_agency', 'team_client'].includes(signInUserData?.role) &&
      checkPermission(
        'chats',
        'group',
        'update',
        signInUserData?.permission
      )) ||
    singleGroupDetails?.[0]?.created_by ===
      signInUserData?.user?.data?.user?._id;

  console.log('canUpdate......', canUpdate);

  // Open Chat Group Details Model
  const openGroupModel = (groupDetail: any) => {
    dispatch(getGroupById(groupDetail?._id)).then((result: any) => {
      if (getGroupById.fulfilled.match(result)) {
        if (
          result &&
          result.payload.success === true &&
          result.payload?.data?.length > 0
        ) {
          openModal({
            view: (
              <CreateGroupForm
                title={canUpdate ? 'Edit Group' : 'Group Details'}
                groupDetail={groupDetail}
                canUpdate={canUpdate}
                isEdit={true}
                signInUserData={signInUserData}
              />
            ),
            customSize: '600px',
          });
        }
      }
    });
  };

  const leaveChatGroupFn = () => {
    openModal({
      view: <LeaveGroupConfirmationModal chatUser={chatUser} />,
      customSize: '600px',
    });
  };

  return (
    <div className="duration-800 flex h-[calc(100dvh-69px)] w-full flex-col justify-between gap-5 bg-[#FCFDFF] p-4 ease-linear lg:w-[30%] lg:border-l lg:border-[#EBEBEB]">
      {/* Group Edit Button */}
      {isGroup && canUpdate && (
        <div className="flex w-full items-center justify-between lg:justify-end">
          {/* Back button in mobile view for group */}
          <div className="block text-left lg:hidden">
            <Button
              onClick={() => setShowProfileDetails(false)}
              className="flex w-full items-center justify-start bg-transparent px-0 text-[14px] font-semibold text-[#8C80D2] lg:w-[200px]  "
              type="button"
              size="sm"
            >
              <GoChevronLeft className="h-[20px] w-[20px] " />
              <span className=""> Back</span>
            </Button>
          </div>
          <ActionIcon
            onClick={() => {
              isGroup && openGroupModel(chatUser);
            }}
            title="Edit Group"
            className="flex h-7 w-7 items-center justify-center rounded-[6.22px] !bg-[#F5F5F5] p-0"
          >
            <PencilIcon className="h-3.5 w-3.5 text-[#383838]" />
          </ActionIcon>
        </div>
      )}
      {!isGroup && (
        <>
          {/* Back button in mobile view for group */}
          <div className="block text-left lg:hidden">
            <Button
              onClick={() => setShowProfileDetails(false)}
              className="flex w-full items-center justify-start bg-transparent px-0 text-[14px] font-semibold text-[#8C80D2] lg:w-[200px]  "
              type="button"
              size="sm"
            >
              <GoChevronLeft className="h-[20px] w-[20px] " />
              <span className=""> Back</span>
            </Button>
          </div>
        </>
      )}
      {/* Chat or Group details */}
      <>
        {/* Profile Image, Name, Contact & Email */}
        <div
          className={cn(
            'flex flex-col items-center gap-4',
            !isGroup && 'lg:mt-12'
          )}
        >
          {/* Profile Image */}
          <div className="!h-16 !w-16">
            <Avatar
              src={getAvatarImage(chatUser)}
              name={getAvatarName(chatUser)}
              className="!h-16 !w-16 border-2 border-[#DDDDDD] text-xl text-white"
            />
          </div>
          {/* Name */}
          <div className="flex flex-col items-center gap-1">
            <Text className="poppins_font_number break-all text-center text-[18px] font-semibold leading-[27px] text-[#222222]">
              {getAvatarName(chatUser)}
            </Text>
            {/* Chat user email */}
            {!isGroup && (
              <div className="w-[200px] break-words text-center text-sm font-normal text-[#222222]">
                {chatUser?.email}
              </div>
            )}
            {/* Chat user email */}
            {isGroup && singleGroupDetails?.[0]?.total_members > 0 && (
              <div className="w-full break-words text-center text-sm font-normal text-[#222222]">
                {singleGroupDetails?.[0]?.total_members ?? ''}{' '}
                {`Member${
                  singleGroupDetails?.[0]?.total_members > 1 ? 's' : ''
                }`}
              </div>
            )}
          </div>
          {/* Contact & Email */}
          {!isGroup && (
            <div className="flex w-full items-center justify-center gap-2">
              {!!chatUser?.contact_number && (
                <Link
                  href={`tel:${chatUser?.contact_number}`}
                  target="_blank"
                  className="flex h-[54px]  flex-col items-center gap-[6px] rounded-lg bg-[#F3F4F6] px-4 py-2"
                >
                  <LuPhone className="h-5 w-5 text-[#6875F5]" />
                  <span className="text-[10px] font-medium leading-3 text-[#4B5563]">
                    Voice call
                  </span>
                </Link>
              )}
              {!!chatUser?.email && (
                <Link
                  href={`mailto:${chatUser?.email}`}
                  target="_blank"
                  className="flex h-[54px] flex-col items-center gap-[6px] rounded-lg bg-[#F3F4F6] px-4 py-2"
                >
                  <MdOutlineEmail className="h-5 w-5 text-[#6875F5]" />
                  <span className="text-[10px] font-medium leading-3 text-[#4B5563]">
                    Send mail
                  </span>
                </Link>
              )}
            </div>
          )}
        </div>

        {/* Info, Media & Members Tabs for group  */}
        {isGroup && (
          <div className="flex h-10 w-full items-center justify-evenly overflow-hidden rounded-lg bg-[#F3F4F6] p-[6px]">
            {menuItems?.map((menu, index) => (
              <button
                key={index}
                className={cn(
                  'h-8 w-full rounded-lg px-3 py-1 text-[14px] font-medium transition duration-300 focus:outline-none',
                  menu?.value === selectedTab
                    ? 'border border-[#D1D5DB] bg-white text-black'
                    : ' bg-transparent text-[#4B5563]'
                )}
                onClick={() => {
                  setSelectedTab(menu?.value);
                }}
              >
                {menu?.label}
              </button>
            ))}
          </div>
        )}

        {/* Media Filter options */}
        {((isGroup && selectedTab === 'media') || !isGroup) && (
          <Select
            onChange={(selectedOption: any) => {
              handleMediaChange(selectedOption);
            }}
            value={selectedMediaOption}
            options={mediaFilterOptions}
            placeholder="All media"
            className="poppins_font_number h-10 w-full"
            selectClassName="text-black"
            optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
            suffix={<PiCaretDownBold className="h-4 w-4" />}
            getOptionValue={(option) => option?.value}
            getOptionDisplayValue={(option: any) => option?.name}
            displayValue={(value) => {
              const displayValue = mediaFilterOptions?.find(
                (option: any) => option?.value === value
              );

              return displayValue?.name ? displayValue?.name : '';
            }}
          />
        )}
        {/* Content show for chat and group*/}
        <div className="w-full flex-1">
          {/* Info section for group */}
          {isGroup && selectedTab === 'info' && (
            <>
              {singleGroupDetails?.[0]?.description ? (
                <div className="text-sm font-medium text-black">
                  {singleGroupDetails?.[0]?.description ?? ''}
                </div>
              ) : (
                <div className="mb-4 mt-[84px] flex items-start justify-center">
                  <EmptyBox
                    imageIcon={EmptyInfo}
                    text="No description was added."
                  />
                </div>
              )}
            </>
          )}

          {/* Media section for chat & group */}
          {((isGroup && selectedTab === 'media') || !isGroup) && (
            <>
              {/* Loader */}
              {loading && !scrollLoading && (
                <div className="mt-[84px] flex items-center justify-center">
                  <Spinner size="xl" />
                </div>
              )}
              {/* Empty screen */}
              {!loading && fileList?.length === 0 && (
                <div className="mt-[84px] flex items-start justify-center">
                  <EmptyBox imageIcon={EmptyInfo} text="No media found" />
                </div>
              )}
              {/* If their is data for media */}
              {fileList?.length > 0 && (
                <SimpleBar
                  ref={fileContainerRef}
                  onScrollCapture={handleScroll}
                  style={{ overflowY: 'auto' }}
                  className="max-h-[228px] pe-2"
                >
                  {fileList?.map((data: any, key: number) => {
                    return (
                      <div
                        key={key}
                        className="flex h-[60px] w-full items-center justify-between gap-2 border-b border-[#DDDDDD] px-2 py-2"
                      >
                        {/* Left side: File icon + filename  & created Date*/}

                        <div className="flex min-w-0 flex-col gap-[6px]">
                          <div
                            className="flex min-w-0 items-center gap-[6px]"
                            title={data?.original_file_name ?? ''}
                          >
                            <CustomFileIcons
                              fileType={getFileType(data?.file_url ?? '')}
                              iconClassName="w-[18px] h-[18px]"
                            />
                            <p className="overflow-hidden truncate text-xs font-semibold text-black">
                              {data?.original_file_name ?? ''}
                            </p>
                          </div>
                          {/* Created date */}
                          <p className="text-[10px] font-medium leading-[12px] text-[#4B5563]">
                            {moment(data?.createdAt ?? '').format(
                              'MMM D, YYYY'
                            )}
                          </p>
                        </div>

                        {/* Right side: Download icon */}
                        <button
                          onClick={() => manageList(data)}
                          className="flex items-center justify-center"
                        >
                          <PiDownloadSimpleBold className="h-5 w-5 text-[#111928]" />
                        </button>
                      </div>
                    );
                  })}
                  {/* Scroll Loader */}
                  {loading && scrollLoading && (
                    <Button
                      variant="text"
                      size="lg"
                      isLoading={true}
                      className="flex w-full items-center justify-center"
                    />
                  )}
                </SimpleBar>
              )}
            </>
          )}

          {/* Members section for group */}
          {isGroup && selectedTab === 'members' && (
            <>
              {singleGroupDetails?.[0]?.members &&
                singleGroupDetails?.[0]?.members?.length > 0 && (
                  <SimpleBar
                    className={cn(
                      'max-h-[287px] rounded-lg border border-[#E5E7EB]'
                    )}
                  >
                    {singleGroupDetails?.[0]?.members?.map(
                      (item: any, index: any) => (
                        <Fragment key={index}>
                          <div className="flex items-center justify-between gap-2 border-b border-gray-300 px-2 py-2 text-sm last:border-0 ">
                            {/* Avatar and text container */}
                            <div className="flex w-full items-center justify-start gap-3">
                              <div className="!h-8 !w-8">
                                <Avatar
                                  src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                                  name={`${capitalizeFirstLetter(
                                    item?.first_name
                                  )} ${capitalizeFirstLetter(item?.last_name)}`}
                                  className="!h-8 !w-8 bg-[#70C5E0] text-xs font-medium text-white"
                                />
                              </div>
                              <div className="flex flex-col gap-1">
                                <div className="text-xs font-medium capitalize text-[#111928]">
                                  {`${capitalizeFirstLetter(
                                    item?.first_name
                                  )} ${capitalizeFirstLetter(item?.last_name)}`}
                                </div>
                                {canUpdate && (
                                  <div className="text-[10px] font-normal leading-[12px] text-[#4B5563]">
                                    Admin
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </Fragment>
                      )
                    )}
                  </SimpleBar>
                )}
            </>
          )}
        </div>

        {/* Exit Group Button */}
        {isGroup && (
          <div className="flex w-full items-center justify-center">
            <Button
              onClick={leaveChatGroupFn}
              title="Exit Group"
              className="group flex h-9 w-full items-center justify-center rounded-lg border border-[#FEE9E7] bg-[#FFFFFF] p-0 px-4 py-3 text-sm text-[#EC221F] transition duration-150 ease-in-out hover:bg-[#EC221F] hover:text-[#FFFFFF]"
            >
              Exit Group
            </Button>
          </div>
        )}
      </>
    </div>
  );
};
