import { getMetaData } from '@/redux/slices/user/chat/chatSlice';
import cn from '@/utils/class-names';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

export default function MetaComponent(props: any) {
  const { URL, selectedUser, signInUserData, message } = props;
  const [state, setState] = useState<any>({});
  const [apiCompleted, setApiCompleted] = useState(false);
  const dispatch = useDispatch();
  const title = state['name:title'] || state['property:og:title'];
  const description =
    state['name:description'] || state['property:og:description'];
  const image = state['property:og:image'] || state['name:twitter:image'];
  const url = state['property:og:url'] || state['name:twitter:url'] || '#';

  const isGroup = selectedUser?.chat_type == 'group' ? true : false;
  const isRtl = isGroup
    ? message?.from_user == signInUserData?.user?.data?.user?._id
    : selectedUser?._id == message?.to_user;

  const messageFromSender =
    message?.from_user == signInUserData?.user?.data?.user?._id;

  const getMetaDataFun = async (al: any) => {
    try {
      const response = await dispatch(getMetaData(al));
      return response;
    } catch (error: any) {
      setApiCompleted(true);
      console.log(error);
    }
  };

  const styles = {
    preview: {
      // border: '1px solid #ddd',
      padding: '16px',
      maxWidth: '400px',
      fontFamily: 'Arial, sans-serif',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      borderRadius: '8px',
    },
    title: {
      fontSize: '1.5em',
      margin: '8px 0',
    },
    description: {
      color: '#555',
      margin: '8px 0',
    },
    link: {
      color: '#007bff',
      textDecoration: 'none',
      fontWeight: 'bold',
    },
  };

  useEffect(() => {
    getMetaDataFun(URL)
      .then((response: any) => {
        if (response?.payload?.data) setState(response?.payload?.data);
      })
      .catch((err) => {
        console.log(err, 'err');
      });
  }, []);
  return (
    <div
      dir={`${isRtl ? 'rtl' : 'ltr'}`}
      className={cn('px-6', message?.nextIsSame ? 'pb-[10px]' : 'pb-5')}
    >
      <div className="flex items-center gap-3 lg:gap-4">
        {/* Recevier Message Code Start */}
        {!messageFromSender && (
          <div className="flex items-end gap-3">
            <div className="flex h-9 w-9 items-center justify-center"></div>
            <div className="flex items-start justify-start">
              <div className="w-[300px] break-words rounded-[20px] bg-white p-[15px] text-left text-sm font-normal text-[#191919]">
                {image && (
                  <div className="">
                    <img src={image} alt="Preview" style={styles.image} />
                  </div>
                )}
                {title && (
                  <p
                    className="poppins_font_number mt-5 w-full truncate break-all text-center text-[18px] text-sm font-medium text-gray-700"
                    dir="ltr"
                  >
                    {title}
                  </p>
                )}
                {description && (
                  <p
                    className="poppins_font_number mt-5 w-full truncate break-all text-center text-[18px] text-sm font-medium text-gray-700"
                    dir="ltr"
                  >
                    {description}
                  </p>
                )}
                {URL && (
                  <div className="mt-2">
                    <a
                      className="text-[16px]"
                      href={URL}
                      style={styles.link}
                      target="_blank"
                    >
                      View More
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Sender Message Code Start */}
        {messageFromSender && (
          <>
            <div className="flex items-end gap-4">
              <div
                dir="ltr"
                className={cn(
                  'relative w-[300px] break-words rounded-b-[20px] rounded-t-[20px] bg-[#D3D7EC] p-[15px] text-left text-sm font-normal text-white'
                )}
              >
                {image && (
                  <div className="">
                    <img src={image} alt="Preview" style={styles.image} />
                  </div>
                )}
                {title && (
                  <p
                    className="mt-5 w-full truncate break-all text-center text-sm font-medium text-black"
                    dir="ltr"
                  >
                    {title}
                  </p>
                )}
                {description && (
                  <p
                    className=" mt-5 flex w-full content-end truncate break-all text-center text-sm font-medium text-black"
                    dir="ltr"
                  >
                    {description}
                  </p>
                )}
                {URL && (
                  <div className="mt-2 sender_message_meta_view_more_link">
                    <a
                      className="flex justify-end text-[16px] text-black"
                      dir="rtl"
                      href={URL}
                      style={styles.link}
                      target="_blank"
                    >
                      View More
                    </a>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
        {/* Sender Message Code End */}
      </div>
    </div>
  );
}
