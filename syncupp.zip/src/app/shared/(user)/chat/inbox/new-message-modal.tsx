'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import { Empty, SearchNotFoundIcon } from '@/components/ui/empty';
import { Input } from '@/components/ui/input';
import { Title } from '@/components/ui/text';
import { getUserList, setNewUser } from '@/redux/slices/user/chat/chatSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import rangeMap from '@/utils/range-map';
import { Fragment, useEffect, useRef, useState } from 'react';
import { PiMagnifyingGlassBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Avatar } from 'rizzui';
import { MessageLoader } from './message-list';

export default function NewMessageModal({
  title,
  setChatUser,
}: {
  title?: string;
  setChatUser?: any;
}) {
  const inputRef = useRef(null);
  const [searchText, setSearchText] = useState('');
  const [menuItemsFiltered, setMenuItemsFiltered] = useState<any>([]);
  const [filteredUsers, setFilteredUsers] = useState<any>([]); // Keep the original filtered list
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const { newUsersChatList, newUsersChatListLoader, userChatList } =
    useSelector((state: any) => state?.root?.chat);

  useEffect(() => {
    dispatch(getUserList({ is_conversation_started: false }));
  }, [dispatch]);

  useEffect(() => {
    if (newUsersChatList?.length > 0) {
      const filtered =
        userChatList?.length > 0
          ? newUsersChatList.filter(
              (newUser: any) =>
                !userChatList.some((user: any) => user._id === newUser._id)
            )
          : newUsersChatList;

      setFilteredUsers(filtered);
      setMenuItemsFiltered(filtered);
    } else {
      setFilteredUsers([]);
      setMenuItemsFiltered([]);
    }
  }, [newUsersChatList, userChatList]);

  useEffect(() => {
    if (searchText.length > 0) {
      const updatedList = filteredUsers.filter((item: any) => {
        const firstName = item?.first_name?.toLowerCase() || '';
        const lastName = item?.last_name?.toLowerCase() || '';
        const fullName = `${firstName} ${lastName}`.trim();
        const search = searchText.toLowerCase();

        return (
          firstName.includes(search) ||
          lastName.includes(search) ||
          fullName.includes(search)
        );
      });

      setMenuItemsFiltered(updatedList);
    } else {
      setMenuItemsFiltered(filteredUsers); // Reset to original filtered list
    }
  }, [searchText, filteredUsers]); // Depend on filteredUsers to ensure it's up-to-date

  useEffect(() => {
    if (inputRef?.current) {
      // @ts-ignore
      inputRef.current.focus();
    }
    return () => {
      inputRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <div className="flex items-center px-5 py-4">
        <Input
          variant="flat"
          value={searchText}
          ref={inputRef}
          onChange={(e) => setSearchText(() => e.target.value)}
          placeholder="Search user"
          className="flex-1"
          prefix={
            <PiMagnifyingGlassBold className="h-[18px] w-[18px] text-gray-600" />
          }
          suffix={
            searchText && (
              <Button
                size="sm"
                variant="text"
                className="h-auto w-auto px-0"
                onClick={(e) => {
                  e.preventDefault();
                  setSearchText(() => '');
                }}
              >
                Clear
              </Button>
            )
          }
        />
        <ActionIcon
          variant="text"
          size="sm"
          className="ms-3 text-gray-500 hover:text-gray-700"
          onClick={closeModal}
        >
          <PiXBold className="h-5 w-5" />
        </ActionIcon>
      </div>

      <>
        {!newUsersChatListLoader && menuItemsFiltered?.length === 0 ? (
          <div className="custom-scrollbar max-h-[60vh] overflow-y-auto border-t border-gray-300 p-2">
            <Empty
              className="scale-75"
              image={<SearchNotFoundIcon />}
              text="No User Found"
              textClassName="text-xl"
            />
          </div>
        ) : (
          <Title as="h6" className="mb-3 px-6 font-semibold text-black">
            Start conversation with
          </Title>
        )}
      </>
      <div className="custom-scrollbar max-h-[60vh] overflow-y-auto border-t border-gray-300 p-2">
        {newUsersChatListLoader && (
          <div>
            {rangeMap(6, (i) => (
              <MessageLoader key={i} />
            ))}
          </div>
        )}
        {!newUsersChatListLoader &&
          menuItemsFiltered?.length > 0 &&
          menuItemsFiltered?.map((item: any, index: any) => {
            return (
              <Fragment key={`${item?.name}-${index}`}>
                <button
                  className="relative my-0.5 flex w-full items-center rounded-lg px-3 py-2 text-sm hover:bg-gray-100 focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg"
                  onClick={() => {
                    dispatch(setNewUser({ ...item, chat_type: 'chat' }));
                    setChatUser({ ...item, chat_type: 'chat' });
                    closeModal();
                  }}
                >
                  <Avatar
                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                    name={`${capitalizeFirstLetter(
                      item?.first_name
                    )} ${capitalizeFirstLetter(item?.last_name)}`}
                    className="border-[1.5px] border-[#DDDDDD] text-[14px] font-medium text-white"
                    size="DEFAULT"
                  />

                  <span className="ms-3 grid gap-0.5">
                    <span className="font-medium capitalize text-gray-900 dark:text-gray-700">
                      {`${capitalizeFirstLetter(
                        item?.first_name
                      )} ${capitalizeFirstLetter(item?.last_name)}`}
                    </span>
                  </span>
                </button>
              </Fragment>
            );
          })}
      </div>
    </>
  );
}
