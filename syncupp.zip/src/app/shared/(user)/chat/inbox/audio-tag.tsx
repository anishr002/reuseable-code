import { useState, useRef, useEffect, useCallback } from "react";
import { FaPlay } from "react-icons/fa";
import { FaPause } from "react-icons/fa6";
import { HiVolumeUp } from "react-icons/hi";
import { IoIosVolumeHigh, IoIosVolumeLow, IoIosVolumeMute } from "react-icons/io";

const AudioTag = ({ audioUrl }: { audioUrl: string }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolume] = useState(1);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [showVolumeSlider, setShowVolumeSlider] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);

    useEffect(() => {
        if (audioRef.current) {
            audioRef.current.addEventListener("loadedmetadata", () => {
                setDuration(audioRef.current!.duration)
                setIsLoading(false)
            })
        }
    }, [])

    const togglePlay = () => {
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause()
            } else {
                audioRef.current.play()
            }
            setIsPlaying(!isPlaying)
        }
    }

    const handleTimeUpdate = () => {
        if (audioRef.current) {
            setCurrentTime(audioRef.current.currentTime)
        }
    }

    const handleError = (e: any) => {
        setError("Error loading audio file")
        setIsLoading(false)
        console.error("Audio error:", e)
    }

    const formatTime = (time: number) => {
        const minutes = Math.floor(time / 60)
        const seconds = Math.floor(time % 60)
        return `${minutes}:${seconds.toString().padStart(2, "0")}`
    }

    const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newVolume = Number.parseFloat(e.target.value)
        setVolume(newVolume)
        if (audioRef.current) {
            audioRef.current.volume = newVolume
        }
    }

    const toggleVolumeSlider = () => {
        setShowVolumeSlider(!showVolumeSlider)
    }

    const VolumeIcon = () => {
        if (volume === 0) return <IoIosVolumeMute className="w-6 h-6" />
        if (volume < 0.5) return <IoIosVolumeLow className="w-6 h-6" />
        return <IoIosVolumeHigh className="w-6 h-6" />
    }

    const generateWaveform = () => {
        const waveCount = 15
        const progress = (currentTime / duration) * waveCount

        return Array.from({ length: waveCount }, (_, index) => (
            <div
                key={index}
                className={`rounded-xl w-1 mx-px transition-all duration-300 ease-in-out ${index < progress ? "bg-[#6C63FF]" : "bg-gray-300"
                    }`}
                style={{
                    height: `${Math.random() * 100}%`,
                    minHeight: "20%",
                }}
            />
        ))
    }

    const handleAudioEnd = () => {
        setIsPlaying(false);
    };

    return (
        <div dir="ltr" className="bg-[#F2F3F5] h-12 p-3 rounded-3xl flex items-center gap-2 sm:gap-4 w-full max-w-md relative">
            <button
                onClick={togglePlay}
                className="w-8 h-8 rounded-full bg-[#6C63FF] text-white flex items-center justify-center hover:bg-[#5B52FF] transition-colors flex-shrink-0"
                disabled={isLoading}
            >
                {isPlaying ? <FaPause className="w-4 h-4" /> : <FaPlay className="w-4 h-4 ml-0.5" />}
            </button>

            <div className="flex-1 h-8 sm:h-10 flex items-center">
                {isLoading ? (
                    <div className="w-full h-4 text-black">Loading...</div>
                ) : (
                    <div className="w-full h-full flex items-center">{generateWaveform()}</div>
                )}
            </div>

            <span className="text-xs sm:text-sm text-gray-600 min-w-[40px] text-right">{formatTime(currentTime)}</span>

            <div className="relative">
                <button
                    onClick={toggleVolumeSlider}
                    className="w-6 h-6 sm:w-6 sm:h-6 text-gray-600 flex-shrink-0 hover:text-[#6C63FF] transition-colors"
                >
                    <VolumeIcon />
                </button>
                {showVolumeSlider && (
                    <div className="absolute bottom-full right-0 mb-2 bg-white p-2 rounded-lg shadow-lg">
                        <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.01"
                            value={volume}
                            onChange={handleVolumeChange}
                            className="w-24 h-1 bg-gray-300 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>
                )}
            </div>

            <audio ref={audioRef} onTimeUpdate={handleTimeUpdate} onError={handleError} onEnded={handleAudioEnd} className="hidden">
                <source src={audioUrl} type="audio/mpeg" />
                Your browser does not support the audio element.
            </audio>
        </div>
    );
};

export default AudioTag;
