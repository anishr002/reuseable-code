import { GetDocumentDownloadApi } from '@/api/user/chat/chatApis';
import DeletePopover from '@/app/shared/delete-popover';
import socket from '@/io';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import EmojiPicker, { EmojiStyle } from 'emoji-picker-react';
import Image from 'next/image';
import { useCallback, useEffect, useMemo } from 'react';
import { MdOutlineEmojiEmotions } from 'react-icons/md';
import { PiXBold } from 'react-icons/pi';
import { SlOptionsVertical } from 'react-icons/sl';
import { useSelector } from 'react-redux';
import { ActionIcon, Button, Popover, Tooltip } from 'rizzui';
import SimpleBar from 'simplebar-react';

export const ImagesPreview = ({
  previewImages,
  setPreviewImages,
  selectedUser,
  selectedIndex,
  setSelectedIndex,
  setIsImagePreview,
  setSelectedImagePreviewIndex,
  setReplyMessage,
  focusChatInput,
}: {
  previewImages?: any;
  setPreviewImages?: any;
  selectedUser?: any;
  selectedIndex?: any;
  setSelectedIndex?: any;
  setIsImagePreview?: any;
  setSelectedImagePreviewIndex?: any;
  setReplyMessage?: any;
  focusChatInput?: any;
}) => {
  console.log('ImagesPreview previewImages......', previewImages);
  const signInUserData = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  // Memoize the selected file
  const selectedFile = useMemo(
    () =>
      previewImages?.images?.length > 0 && selectedIndex > -1
        ? previewImages?.images?.[selectedIndex]
        : null,
    [previewImages, selectedIndex]
  );

  const isGroup = selectedUser?.chat_type === 'group' ? true : false;
  const messageFromSender =
    previewImages?.from_user === signInUserData?.user?.data?.user?._id;
  // Keyboard event handler using functional update
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!previewImages?.images?.length) {
        return;
      }
      setSelectedIndex((prev: any) => {
        if (
          e.key === 'ArrowRight' &&
          prev < previewImages?.images?.length - 1
        ) {
          return prev + 1;
        }
        if (e.key === 'ArrowLeft' && prev > 0) {
          return prev - 1;
        }
        return prev;
      });
    },
    [previewImages]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const handleThumbnailClick = useCallback((index: number) => {
    setSelectedIndex(index);
  }, []);

  // Delete a file and adjust the selected index if necessary
  const handleDeleteFile = useCallback((index: number) => {
    setPreviewImages((prev: any) => {
      const updated = [...prev];
      updated?.splice(index, 1);
      return updated;
    });
    setSelectedIndex((prevIndex: any) =>
      index <= prevIndex ? Math.max(prevIndex - 1, 0) : prevIndex
    );
  }, []);

  // Delete message
  const deleteMessage = (data: any) => {
    if (isGroup) {
      const payload = {
        chat_id: data?._id,
      };
      socket.emit('GROUP_DELETE_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'GROUP_DELETE_MESSAGE' });
    } else {
      const payload = {
        from_user: data?.from_user,
        to_user: data?.to_user,
        chat_id: data?._id,
      };
      socket.emit('DELETE_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'DELETE_MESSAGE' });
    }
  };

  // Download file
  const downloadFile = async (message: any) => {
    let fileUrl = process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/';
    let fileName = '';

    if (message?.message_type === 'document') {
      fileUrl += message?.document_url;
      fileName = message?.original_file_name;
    } else if (message?.message_type === 'image') {
      fileUrl += message?.image_url;
      fileName = message?.original_file_name;
    } else if (message?.message_type === 'audio') {
      fileUrl += message?.audio_url;
      fileName = message?.audio_url;
    }

    await GetDocumentDownloadApi(fileUrl).then((data: any) => {
      const href = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = href;
      link.setAttribute('download', fileName?.split('.')?.[0]);
      document.body.appendChild(link);
      link.click();

      document.body.removeChild(link);
      URL.revokeObjectURL(href);
    });
  };

  // React image
  const reactionMessage = (
    emojiEvent: any,
    message: any,
    setOpen?: any,
    imageIndex?: any
  ) => {
    let chatId = '';
    if (message?.message_type === 'image') {
      chatId = message?.images?.[imageIndex ?? 0]?._id ?? '';
    } else {
      chatId = message?._id ?? '';
    }
    if (isGroup) {
      const payload = {
        chat_id: chatId,
        reaction: emojiEvent?.emoji,
        from_user: signInUserData?.user?.data?.user?._id,
        group_id: selectedUser?._id,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('GROUP_REACTION_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'GROUP_REACTION_MESSAGE' });
    } else {
      const payload = {
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: selectedUser?._id,
        chat_id: chatId,
        reaction: emojiEvent?.emoji,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('REACTION_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'REACTION_MESSAGE' });
    }
    // Image reaction popover closed
    setOpen(false);
  };

  // Remove reaction
  const removeReaction = (message: any, imageIndex?: any) => {
    let chatId = '';
    if (message?.message_type === 'image') {
      chatId = message?.images?.[imageIndex]?._id ?? '';
    } else {
      chatId = message?._id ?? '';
    }
    if (isGroup) {
      if (message?.from_user === signInUserData?.user?.data?.user?._id) {
        return;
      }
      const payload = {
        chat_id: chatId,
        from_user: signInUserData?.user?.data?.user?._id,
        group_id: selectedUser?._id,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('GROUP_REACTION_DELETE', payload);
    } else {
      if (message?.from_user === signInUserData?.user?.data?.user?._id) {
        return;
      }

      const payload = {
        chat_id: chatId,
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: selectedUser?._id,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('REACTION_DELETE', payload);
    }
  };

  // Reaction & Delete message socket events listening
  // Received reaction effect for chat
  useEffect(() => {
    const handleReaction = (response: any) => {
      console.log(response, 'RECEIVED_REACTION');

      if (
        (selectedUser?._id === response?.message?.to_user ||
          selectedUser?._id === response?.message?.from_user) &&
        previewImages?.message_type === 'image'
      ) {
        setPreviewImages((prev: any) => {
          if (!prev?.images) {
            return prev;
          } // Prevent errors if images don't exist

          const imageIndex = prev?.images?.findIndex(
            (img: any) => img?._id === response?.message?._id
          );

          if (imageIndex === -1) {
            return prev;
          } // Exit if image is not found

          // Update image reactions
          const updatedImages = [...(prev?.images ?? [])];
          updatedImages[imageIndex] = {
            ...updatedImages[imageIndex],
            reactions: response?.message?.reactions ?? [],
          };

          return { ...prev, images: updatedImages };
        });
      }
    };

    socket.on('RECEIVED_REACTION', handleReaction);

    return () => {
      socket.off('RECEIVED_REACTION', handleReaction);
    };
  }, [selectedUser?._id, previewImages?.message_type]); // Ensure dependencies are correct

  // Received reaction effect for group
  useEffect(() => {
    const handleReaction = (response: any) => {
      console.log(response, 'GROUP_RECEIVED_REACTION');

      if (
        selectedUser?._id === response?.group_id &&
        previewImages?.message_type === 'image'
      ) {
        setPreviewImages((prev: any) => {
          if (!prev?.images) {
            return prev;
          } // Prevent errors if images don't exist

          const imageIndex = prev?.images?.findIndex(
            (img: any) => img?._id === response?._id
          );

          if (imageIndex === -1) {
            return prev;
          } // Exit if image is not found

          // Update image reactions
          const updatedImages = [...(prev?.images ?? [])];
          updatedImages[imageIndex] = {
            ...updatedImages[imageIndex],
            reactions: response?.reactions ?? [],
          };

          return { ...prev, images: updatedImages };
        });
      }
    };

    socket.on('GROUP_RECEIVED_REACTION', handleReaction);

    return () => {
      socket.off('GROUP_RECEIVED_REACTION', handleReaction);
    };
  }, [selectedUser?._id, defaultWorkSpace?._id]);

  // When Sender Delete Message in one-to-one & group chat
  useEffect(() => {
    const handleMessageDeleted = (response: {
      message: string;
      _id: string;
      message_type: string;
      to_user?: string; // Only for one-to-one chats
      group_id?: string; // Only for group chats
    }) => {
      console.log('MESSGAE_DELETED', response);

      if (response?.message_type !== 'image') {
        return;
      } // Only handle image deletions

      setPreviewImages((prev: any) => {
        if (!prev?.images) {
          return prev;
        } // Prevent errors if images don't exist

        // Filter out the deleted image
        const updatedImages = prev?.images.filter(
          (img: any) => img?._id !== response?._id
        );

        // Update the selected image index if necessary
        const deletedImageIndex = prev?.images?.findIndex(
          (img: any) => img?._id === response?._id
        );

        if (deletedImageIndex > -1) {
          setSelectedIndex((prevIndex: number) =>
            deletedImageIndex <= prevIndex
              ? Math.max(prevIndex - 1, 0)
              : prevIndex
          );
        }

        // If no images remain, close the preview
        if (updatedImages?.length === 0) {
          setPreviewImages(null);
          setIsImagePreview(false);
          setSelectedImagePreviewIndex(0);
          return null;
        }

        return { ...prev, images: updatedImages };
      });
    };

    // Attach event listeners for both individual and group messages
    socket.on('MESSGAE_DELETED', handleMessageDeleted);
    socket.on('GROUP_MESSGAE_DELETED', handleMessageDeleted);

    return () => {
      socket.off('MESSGAE_DELETED', handleMessageDeleted);
      socket.off('GROUP_MESSGAE_DELETED', handleMessageDeleted);
    };
  }, [selectedUser?._id, defaultWorkSpace?._id]); // Only include necessary dependencies

  return (
    <div className="flex h-full w-full flex-col gap-5">
      {/* More Action Header */}
      <div className="flex w-full items-center justify-end">
        <div className="flex items-center justify-center gap-3">
          {!messageFromSender && (
            <Popover
              placement="bottom"
              showArrow={false}
              className="demo_test gap-2 border-0 bg-transparent"
              gap={0}
              content={({ setOpen }) => (
                <EmojiPicker
                  emojiStyle={EmojiStyle.NATIVE}
                  className="bg-white"
                  reactionsDefaultOpen={true}
                  allowExpandReactions={false}
                  onReactionClick={(event) =>
                    reactionMessage(
                      event,
                      previewImages,
                      setOpen,
                      selectedIndex ?? 0
                    )
                  }
                />
              )}
            >
              <ActionIcon
                className="h-7 w-7 p-0"
                title={'Reaction'}
                variant="text"
              >
                <MdOutlineEmojiEmotions
                  size={'lg'}
                  className="h-7 w-7 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]"
                />
              </ActionIcon>
            </Popover>
          )}
          <Popover
            placement="bottom-end"
            className="demo_test p-2"
            gap={4}
            showArrow={false}
            content={({ setOpen }) => (
              <div className="flex flex-col items-center p-0">
                <Button
                  variant="text"
                  className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                  onClick={() => {
                    setReplyMessage({
                      ...previewImages,
                      ...(previewImages?.images?.[selectedIndex ?? 0] ?? {}),
                      _id:
                        previewImages?.images?.[selectedIndex ?? 0]?._id ?? '',
                      message_type: 'image',
                    });
                    focusChatInput();
                    setOpen(false);
                    // empty images preview when close the image preview
                    setPreviewImages(null);
                    setIsImagePreview(false);
                    setSelectedImagePreviewIndex(0);
                  }}
                >
                  Reply
                </Button>
                {messageFromSender && (
                  <DeletePopover
                    title={`Delete the Message`}
                    isMessageDelete={true}
                    className="flex h-auto w-full items-start justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none "
                    description={`Are you sure you want to delete this message?`}
                    onDelete={() => {
                      deleteMessage({
                        ...previewImages,
                        _id:
                          previewImages?.images?.[selectedIndex ?? 0]?._id ??
                          '',
                      });
                    }}
                  />
                )}
                {previewImages?.message_type !== 'message' && (
                  <Button
                    variant="text"
                    className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                    onClick={() => {
                      downloadFile({
                        ...previewImages?.images?.[selectedIndex ?? 0],
                        message_type: 'image',
                      });
                      setOpen(false);
                    }}
                  >
                    Save to Downloads
                  </Button>
                )}
              </div>
            )}
          >
            <ActionIcon
              className="h-7 w-7 p-0"
              title={'More Options'}
              variant="text"
            >
              <SlOptionsVertical
                size={'lg'}
                className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]"
              />
            </ActionIcon>
          </Popover>
          <Button
            type="button"
            title="Close"
            onClick={() => {
              // empty images preview when close the image preview
              setPreviewImages(null);
              setIsImagePreview(false);
              setSelectedImagePreviewIndex(0);
            }}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#686868] !p-0"
          >
            <PiXBold className="h-4 w-4 text-white" />
          </Button>
        </div>
      </div>
      {/* Main preview area */}
      <div className="flex flex-1 items-center justify-center rounded-lg p-2">
        {selectedFile ? (
          <div
            className="relative h-full w-full max-w-lg rounded-sm bg-[#D9D9D9]"
            title={selectedFile?.original_file_name ?? ''}
          >
            <Image
              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${selectedFile?.image_url}`}
              alt="Image Preview"
              layout="fill"
              objectFit="contain"
              className="rounded-lg"
            />
            {/* Reaction */}
            {selectedFile?.reactions?.length > 0 && (
              <div className="absolute -bottom-[10px] right-7 flex h-7 items-center justify-center rounded-full border-[1.5px] border-[#D9D9D9] bg-white p-2 shadow-md">
                {selectedFile?.reactions?.map((data: any) => (
                  <div
                    key={data?._id}
                    className="flex items-center justify-center"
                  >
                    <span className="flex w-fit">
                      <Tooltip
                        placement="top"
                        color="invert"
                        size="sm"
                        content={() => (
                          <div key={data?._id}>
                            {' '}
                            {capitalizeFirstLetter(data?.user?.first_name)}{' '}
                            {capitalizeFirstLetter(data?.user?.last_name)}
                          </div>
                        )}
                      >
                        <ActionIcon
                          className="h-7 w-5 cursor-pointer !p-0"
                          variant="text"
                          onClick={() =>
                            removeReaction(previewImages, selectedIndex ?? 0)
                          }
                        >
                          {data?.emoji}
                        </ActionIcon>
                      </Tooltip>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <p className="text-black">No file selected</p>
        )}
      </div>

      {/* Thumbnail preview list */}
      {previewImages?.images?.length > 0 && (
        <SimpleBar className="pb-4">
          <div className="flex w-max flex-row rounded bg-white ">
            {previewImages?.images?.map((file: any, index: number) => (
              <div
                key={index}
                title={file?.original_file_name ?? ''}
                role="button"
                className="relative flex-shrink-0 cursor-pointer rounded border border-transparent p-1 transition-colors hover:border-gray-300 "
                onClick={() => handleThumbnailClick(index)}
              >
                <div className="relative h-20 w-20">
                  <Image
                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${file?.image_url}`}
                    alt="Thumbnail"
                    layout="fill"
                    objectFit="cover"
                    className="h-20 w-20 rounded"
                  />
                </div>

                {/* Black background shown only for the selected thumbnail */}
                {selectedIndex === index && (
                  <div className="absolute inset-0 flex items-center justify-center rounded bg-black/15"></div>
                )}
              </div>
            ))}
          </div>
        </SimpleBar>
      )}
    </div>
  );
};
