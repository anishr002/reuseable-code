'use client';

import { GetDocumentDownloadApi } from '@/api/user/chat/chatApis';
import DeletePopover from '@/app/shared/delete-popover';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Popover } from '@/components/ui/popover';
import { ActionIcon } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import socket from '@/io';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  copyToClipboard,
  getFileType,
  updateMessageFormatWithMentionUser,
} from '@/utils/common-functions';
import EmojiPicker, { EmojiStyle } from 'emoji-picker-react';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useRef, useState } from 'react';
import { IoIosArrowDown } from 'react-icons/io';
import { MdOutlineEmojiEmotions } from 'react-icons/md';
import { useSelector } from 'react-redux';
import AudioTag from './audio-tag';
import { FileIcons } from './file-icons';

const NEXT_PUBLIC_IMAGE_URL = process.env.NEXT_PUBLIC_IMAGE_URL;

export default function MessageBody({
  message,
  selectedUser,
  signInUserData,
  highlightText,
  searchQuery,
  replyMessage,
  setReplyMessage,
  setRedirectMessage,
  setEditMessage,
  focusChatInput,
  setIsImagePreview,
  setPreviewImages,
  setSelectedImagePreviewIndex,
}: Readonly<{
  message: any;
  selectedUser: any;
  signInUserData: any;
  highlightText: any;
  searchQuery: any;
  replyMessage?: any;
  setReplyMessage?: any;
  setRedirectMessage?: any;
  setEditMessage?: any;
  focusChatInput?: any;
  setIsImagePreview?: any;
  setPreviewImages?: any;
  setSelectedImagePreviewIndex?: any;
}>) {
  const hoverRef = useRef(null);
  const { openModal } = useModal();
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const [isHovered, setIsHovered] = useState(false); // State to manage hover effect
  const { mentioned_users, user_colors } = useSelector(
    (state: any) => state?.root?.group
  );

  const isGroup = selectedUser?.chat_type === 'group' ? true : false;
  const messageFromSender =
    message?.from_user === signInUserData?.user?.data?.user?._id;
  const isRtl = isGroup
    ? message?.from_user === signInUserData?.user?.data?.user?._id
    : selectedUser?._id === message?.to_user;

  const deleteMessage = (data: any) => {
    if (isGroup) {
      const payload = {
        chat_id: data?._id,
      };
      socket.emit('GROUP_DELETE_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'GROUP_DELETE_MESSAGE' });
    } else {
      const payload = {
        from_user: data?.from_user,
        to_user: data?.to_user,
        chat_id: data?._id,
      };
      socket.emit('DELETE_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'DELETE_MESSAGE' });
    }
  };

  const _findAllURLs = (str: any) => {
    // Regular expression to match URLs starting with http or https
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    // Find all matches
    const matches = str.match(urlRegex);

    // Return the array of URLs or an empty array if no URLs are found
    return matches ? matches : [];
  };

  const downloadFile = async (message: any) => {
    let fileUrl = NEXT_PUBLIC_IMAGE_URL + '/uploads/';
    let fileName = '';

    if (message?.message_type === 'document') {
      fileUrl += message?.document_url;
      fileName = message?.original_file_name;
    } else if (message?.message_type === 'image') {
      fileUrl += message?.image_url;
      fileName = message?.original_file_name;
    } else if (message?.message_type === 'audio') {
      fileUrl += message?.audio_url;
      fileName = message?.audio_url;
    }

    await GetDocumentDownloadApi(fileUrl).then((data: any) => {
      const href = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = href;
      link.setAttribute('download', fileName?.split('.')?.[0]);
      document.body.appendChild(link);
      link.click();

      document.body.removeChild(link);
      URL.revokeObjectURL(href);
    });
  };

  const reactionMessage = (emojiEvent: any, message: any, setOpen?: any) => {
    let chatId = '';
    if (message?.message_type === 'image') {
      chatId = message?.images?.[0]?._id ?? '';
    } else {
      chatId = message?._id ?? '';
    }
    if (isGroup) {
      const payload = {
        chat_id: chatId,
        reaction: emojiEvent?.emoji,
        from_user: signInUserData?.user?.data?.user?._id,
        group_id: selectedUser?._id,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('GROUP_REACTION_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'GROUP_REACTION_MESSAGE' });
    } else {
      const payload = {
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: selectedUser?._id,
        chat_id: chatId,
        reaction: emojiEvent?.emoji,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('REACTION_MESSAGE', payload);
      socket.emit('CONFIRMATION', { event: 'REACTION_MESSAGE' });
    }
    // Image reaction popover closed
    setOpen(false);
  };

  const removeReaction = (message: any, imageIndex?: any) => {
    let chatId = '';
    if (message?.message_type === 'image') {
      chatId = message?.images?.[imageIndex]?._id ?? '';
    } else {
      chatId = message?._id ?? '';
    }
    if (isGroup) {
      if (message?.from_user === signInUserData?.user?.data?.user?._id) {
        return;
      }
      const payload = {
        chat_id: chatId,
        from_user: signInUserData?.user?.data?.user?._id,
        group_id: selectedUser?._id,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('GROUP_REACTION_DELETE', payload);
    } else {
      if (message?.from_user === signInUserData?.user?.data?.user?._id) {
        return;
      }

      const payload = {
        chat_id: chatId,
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: selectedUser?._id,
        workspace_id: defaultWorkSpace?._id,
      };
      socket.emit('REACTION_DELETE', payload);
    }
  };

  const getFormatedTime = (
    date: any,
    format: string = 'DD/MM/yyyy hh:mm A'
  ) => {
    if (!date) {
      return '';
    }
    return moment(date).format(format);
  };

  return (
    <div
      dir={`${isRtl ? 'rtl' : 'ltr'}`}
      className={cn('px-6', message?.nextIsSame ? 'pb-[10px]' : 'pb-5')}
    >
      <div className="grid items-center gap-3 lg:gap-4">
        {/* code for html chat */}

        {/* Recevier Message Code Start */}
        {!messageFromSender && (
          <div className="flex items-end gap-3">
            <div className="flex h-9 w-9 items-center justify-center">
              {/* Receiver one to one chat User */}
              {!isGroup && !message?.nextIsSame && (
                <Avatar
                  src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${selectedUser?.profile_image}`}
                  name={`${capitalizeFirstLetter(
                    selectedUser?.first_name
                  )} ${capitalizeFirstLetter(selectedUser?.last_name)}`}
                  className="flex !h-[30px] !w-[30px] items-center justify-center rounded-full bg-blue-500 text-xs text-white"
                />
              )}
              {/* Receiver Group User */}
              {isGroup && !message?.nextIsSame && (
                <Avatar
                  src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.user_detail?.profile_image}`}
                  name={`${capitalizeFirstLetter(
                    message?.user_detail?.first_name
                  )} ${capitalizeFirstLetter(message?.user_detail?.last_name)}`}
                  size="sm"
                  className="flex items-center justify-center rounded-full bg-blue-500 text-xs text-white"
                />
              )}
            </div>
            {/* message box start */}
            <div className="flex items-center justify-start gap-4">
              <div>
                {message?.message_type === 'message' && (
                  <div
                    role="button"
                    className={cn(
                      'relative min-w-[90px] max-w-[550px] cursor-default break-words rounded-t-[20px] rounded-br-[20px] bg-white text-left text-sm font-medium text-[#191919]',
                      message?.nextIsSame && 'rounded-bl-[20px]',
                      message?.reply_message
                        ? 'py-2 pl-2'
                        : 'pb-2 pl-5 pt-[15px]',
                      isHovered
                        ? 'pr-9'
                        : message?.reply_message
                          ? 'pr-2'
                          : 'pr-5'
                    )}
                    onMouseEnter={() => setIsHovered(true)} // Show popover icon on hover
                    onMouseLeave={() => setIsHovered(false)} // Hide popover icon on mouse leave
                  >
                    {/* Message Actions Popover */}
                    {isHovered && (
                      <div className="absolute right-0 top-0">
                        <Popover
                          placement="bottom"
                          className="demo_test p-2"
                          gap={0}
                          showArrow={false}
                          content={({ setOpen }) => (
                            <div className="flex flex-col items-center p-0">
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => {
                                  setReplyMessage({ ...message });
                                  focusChatInput();
                                }}
                              >
                                Reply
                              </Button>
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => {
                                  copyToClipboard(message?.message);
                                  setOpen(false);
                                }}
                              >
                                Copy
                              </Button>
                            </div>
                          )}
                        >
                          <ActionIcon
                            className="!p-0"
                            title={'More Options'}
                            variant="text"
                          >
                            <IoIosArrowDown className="h-4 w-4 text-[#1E1E1E]" />
                          </ActionIcon>
                        </Popover>
                      </div>
                    )}
                    {isGroup && !message?.previousIsSame && (
                      <div
                        className={cn(
                          'text-[16px] font-semibold capitalize',
                          message?.reply_message ? 'mb-2 ml-1' : '-mt-1 mb-1'
                        )}
                        style={{
                          color: user_colors?.[message?.from_user] ?? '#FF5A1F',
                        }}
                      >
                        {/* Group Receiver Name */}
                        {`${capitalizeFirstLetter(
                          message?.user_detail?.first_name
                        )} ${capitalizeFirstLetter(
                          message?.user_detail?.last_name
                        )}`}
                      </div>
                    )}

                    {/* Replied message show */}
                    {message?.reply_message && (
                      <div className="mb-2 flex flex-col items-center justify-start gap-[2px] rounded-[10px] border-l-2 border-[#6875F5] bg-[#F5F5F5] px-3 py-2">
                        <div className="flex w-full items-center justify-start text-sm font-bold text-[#6875F5]">
                          {message?.reply_message?.from_user?._id ===
                            signInUserData?.user?.data?.user?._id && 'You'}
                          {!isGroup &&
                            message?.reply_message?.from_user?._id !==
                              signInUserData?.user?.data?.user?._id &&
                            `${capitalizeFirstLetter(
                              message?.reply_message?.from_user?.first_name
                            )} ${capitalizeFirstLetter(
                              message?.reply_message?.from_user?.last_name
                            )}`}
                          {isGroup &&
                            message?.reply_message?.from_user?._id !==
                              signInUserData?.user?.data?.user?._id &&
                            `${capitalizeFirstLetter(
                              message?.reply_message?.from_user?.first_name
                            )} ${capitalizeFirstLetter(
                              message?.reply_message?.from_user?.last_name
                            )}`}
                        </div>

                        {message?.reply_message?.message_type === 'message' &&
                          message?.reply_message?.message && (
                            <p
                              dir="ltr"
                              className="w-full text-left text-xs font-medium text-black"
                              dangerouslySetInnerHTML={{
                                __html: isGroup
                                  ? updateMessageFormatWithMentionUser(
                                      message?.reply_message?.message,
                                      mentioned_users,
                                      true,
                                      false,
                                      'text-[#6C76FF]'
                                    )
                                  : message?.reply_message?.message,
                              }}
                            ></p>
                          )}

                        {message?.reply_message?.message_type === 'image' && (
                          <div className="flex w-full items-center justify-start gap-2 ">
                            <div className="flex items-center justify-center">
                              <Image
                                src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.reply_message?.image_url}`}
                                alt={message?.reply_message?.image_url}
                                className="rounded-[3px] border border-[#D1D5DB] object-cover"
                                width={60}
                                height={48}
                              />
                            </div>
                            <p className="w-full text-xs font-medium text-black">
                              Image
                            </p>
                          </div>
                        )}
                        {message?.reply_message?.message_type ===
                          'document' && (
                          <div className="flex w-full items-center justify-start gap-2">
                            <div className="flex items-center justify-start">
                              <FileIcons
                                key={message?.reply_message?._id}
                                fileType={getFileType(
                                  message?.reply_message?.document_url
                                )}
                                fileName={
                                  message?.reply_message?.original_file_name
                                }
                                className={cn(
                                  '!flex-row !bg-[#F5F5F5] !py-[6px] !pe-[6px] !ps-0'
                                )}
                              />
                            </div>
                          </div>
                        )}
                        {message?.reply_message?.message_type === 'audio' && (
                          <div className="flex w-full items-center justify-start gap-2">
                            {/* <audio
                              src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.reply_message?.audio_url}`}
                              controls
                            /> */}
                            <AudioTag
                              audioUrl={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.reply_message?.audio_url}`}
                            />
                          </div>
                        )}
                      </div>
                    )}
                    <p
                      dir="ltr"
                      className={cn(
                        message?.reply_message ? 'ml-2' : 'ml-0',
                        'mb-2'
                      )}
                      dangerouslySetInnerHTML={{
                        __html: highlightText(
                          updateMessageFormatWithMentionUser(
                            message?.message,
                            mentioned_users,
                            true,
                            false,
                            'text-[#6C76FF]'
                          ),
                          searchQuery
                        ),
                      }}
                    ></p>
                    <div
                      dir="ltr"
                      className={cn(
                        'poppins_font_number flex w-full items-center justify-start gap-x-2 text-xs font-light text-black',
                        message?.reactions?.length > 0 ? 'mb-[10px]' : 'mb-0'
                      )}
                    >
                      <span
                        className={cn(message?.reply_message ? 'ml-2' : 'ml-0')}
                      >
                        {getFormatedTime(message?.createdAt as Date, 'hh:mm A')}
                      </span>
                      {message?.message_edited && <span>Edited</span>}
                    </div>
                    {/* Reaction */}
                    {message?.reactions?.length > 0 && (
                      <div className="absolute -bottom-[10px] left-5 flex h-7 items-center justify-center rounded-full border border-white bg-[#D9D9D9] p-2 shadow-md">
                        {message?.reactions?.map((data: any) => (
                          <div
                            key={data?._id}
                            className=" flex items-center justify-center"
                          >
                            <span className="flex w-fit">
                              <Tooltip
                                placement="top"
                                color="invert"
                                size="sm"
                                content={() => (
                                  <div key={data?._id}>
                                    {' '}
                                    {capitalizeFirstLetter(
                                      data?.user?.first_name
                                    )}{' '}
                                    {capitalizeFirstLetter(
                                      data?.user?.last_name
                                    )}
                                  </div>
                                )}
                              >
                                <ActionIcon
                                  className="h-7 w-5 cursor-pointer !p-0"
                                  variant="text"
                                  onClick={() => removeReaction(message)}
                                >
                                  {data?.emoji}
                                </ActionIcon>
                              </Tooltip>
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Images */}
                {message?.message_type === 'image' && (
                  <div className="flex items-center gap-4">
                    {message?.images && message?.images?.length > 0 && (
                      <div
                        dir={message?.images?.length > 1 ? 'ltr' : ''}
                        className={cn(
                          'grid items-start justify-start gap-2',
                          !message?.message &&
                            message?.images?.length > 1 &&
                            'rounded-[20px] bg-white p-2',
                          message?.images?.length === 1
                            ? 'grid-cols-1'
                            : 'grid-cols-2'
                        )}
                      >
                        {message?.images?.map((image: any, index: number) => {
                          // Only render up to index 3 (4 images total).
                          if (index > 3) {
                            return null;
                          }
                          const isLastWithOverlay =
                            index === 3 && message?.images?.length > 4;

                          return (
                            <div
                              role="button"
                              key={index}
                              className={cn(
                                'relative',
                                message?.message &&
                                  'min-w-[90px] max-w-[325px] cursor-default break-words rounded-t-[20px] rounded-br-[20px] bg-white pb-[15px] pl-2 pr-2 pt-2 text-left text-sm font-normal text-white sm:max-w-[550px]',
                                isHovered && message?.message && 'pr-9'
                              )}
                              onMouseEnter={() => {
                                // Show popover icon on hover if there is only 1 image
                                if (message?.images?.length === 1) {
                                  setIsHovered(true);
                                }
                              }}
                              onMouseLeave={() => {
                                // Hide popover icon on mouse leave if there is only 1 image
                                if (message?.images?.length === 1) {
                                  setIsHovered(false);
                                }
                              }}
                            >
                              {isHovered && (
                                <div className="absolute right-0 top-0 z-50">
                                  {message?.message_type !== 'message' && (
                                    <Popover
                                      placement="bottom"
                                      className="demo_test p-2"
                                      gap={0}
                                      showArrow={false}
                                      content={({ setOpen }) => (
                                        <div className="flex flex-col items-center p-0">
                                          <Button
                                            variant="text"
                                            className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                            onClick={() => {
                                              setReplyMessage({
                                                ...message,
                                                ...image,
                                                _id: image?._id ?? '',
                                                message_type: 'image',
                                              });
                                              focusChatInput();
                                            }}
                                          >
                                            Reply
                                          </Button>
                                          <Button
                                            variant="text"
                                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                            onClick={() => {
                                              // set Image Preview & files
                                              setIsImagePreview(true);
                                              setPreviewImages(message ?? null);
                                              setSelectedImagePreviewIndex(
                                                index ?? 0
                                              );
                                            }}
                                          >
                                            View
                                          </Button>
                                          {message?.message_type !==
                                            'message' && (
                                            <Button
                                              variant="text"
                                              className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                              onClick={() =>
                                                downloadFile({
                                                  ...image,
                                                  message_type: 'image',
                                                })
                                              }
                                            >
                                              Save to Downloads
                                            </Button>
                                          )}
                                        </div>
                                      )}
                                    >
                                      <ActionIcon
                                        className="!p-0"
                                        title={'More Options'}
                                        variant="text"
                                      >
                                        <IoIosArrowDown
                                          className={cn(
                                            'h-4 w-4 rounded-[1.4px] text-[#1E1E1E]',
                                            message?.message
                                              ? 'bg-transparent'
                                              : 'bg-[#F5F5F5]'
                                          )}
                                        />
                                      </ActionIcon>
                                    </Popover>
                                  )}
                                </div>
                              )}

                              {/* Image itself */}
                              <div className="relative cursor-pointer">
                                <Image
                                  src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${image?.image_url}`}
                                  alt={image?.image_url}
                                  width={150}
                                  height={150}
                                  onClick={() => {
                                    // set Image Preview & files
                                    setIsImagePreview(true);
                                    setPreviewImages(message ?? null);
                                    setSelectedImagePreviewIndex(index ?? 0);
                                  }}
                                  className="h-[150px] w-[150px] rounded-xl border-2 border-[#D1D5DB] object-cover"
                                />
                                {/* If it's the 4th image and there are more than 4 total, show overlay */}
                                {isLastWithOverlay && (
                                  <button
                                    onClick={() => {
                                      // set Image Preview & files
                                      setIsImagePreview(true);
                                      setPreviewImages(message ?? null);
                                      // setSelectedImagePreviewIndex(0);
                                    }}
                                    className="absolute left-0 top-0 z-10 flex h-full w-full cursor-pointer items-center justify-center rounded-xl bg-black/60 text-xl font-bold text-white"
                                  >
                                    +{message?.images?.length - 3}
                                  </button>
                                )}
                              </div>

                              {/* If there's also text with the image */}
                              {message?.message && (
                                <p
                                  dir="ltr"
                                  className={cn(
                                    'ml-0 mr-4 mt-2 !text-black',
                                    image?.reactions?.length > 0
                                      ? 'mb-8'
                                      : 'mb-5'
                                  )}
                                  ref={hoverRef}
                                  dangerouslySetInnerHTML={{
                                    __html: highlightText(
                                      updateMessageFormatWithMentionUser(
                                        message?.message,
                                        mentioned_users,
                                        true,
                                        true,
                                        'text-[#6C76FF]'
                                      ),
                                      searchQuery
                                    ),
                                  }}
                                ></p>
                              )}

                              {/* Time display */}
                              <div
                                dir="ltr"
                                className={cn(
                                  'poppins_font_number absolute left-2 flex items-center justify-center rounded-[5.2px] bg-[#E3E3E3] px-[5.2px] py-[2.6px] text-[13px] font-light text-black',
                                  image?.reactions?.length > 0
                                    ? 'bottom-5'
                                    : 'bottom-2',
                                  message?.message
                                    ? 'bg-transparent'
                                    : 'bg-[#E3E3E3]'
                                )}
                              >
                                {getFormatedTime(
                                  message?.createdAt as Date,
                                  'hh:mm A'
                                )}
                              </div>
                              {/* Reaction */}
                              {image?.reactions?.length > 0 && (
                                <div className="absolute -bottom-[10px] left-5 flex h-7 items-center justify-center rounded-full border border-white bg-[#D9D9D9] p-2 shadow-md">
                                  {image?.reactions?.map((data: any) => (
                                    <div
                                      key={data?._id}
                                      className="flex items-center justify-center"
                                    >
                                      <span className="flex w-fit">
                                        <Tooltip
                                          placement="top"
                                          color="invert"
                                          size="sm"
                                          content={() => (
                                            <div key={data?._id}>
                                              {' '}
                                              {capitalizeFirstLetter(
                                                data?.user?.first_name
                                              )}{' '}
                                              {capitalizeFirstLetter(
                                                data?.user?.last_name
                                              )}
                                            </div>
                                          )}
                                        >
                                          <ActionIcon
                                            className="h-7 w-5 cursor-pointer !p-0"
                                            variant="text"
                                            onClick={() =>
                                              removeReaction(message, index)
                                            }
                                          >
                                            {data?.emoji}
                                          </ActionIcon>
                                        </Tooltip>
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                    {message?.images?.length === 1 && (
                      <Popover
                        placement="top"
                        className="demo_test gap-2 border-0 bg-transparent"
                        gap={0}
                        content={({ setOpen }) => (
                          // <Picker
                          //   emojiStyle={EmojiStyle.NATIVE}
                          //   onReactionClick={(event) =>
                          //     reactionMessage(event, message)
                          //   }
                          //   skinTonesDisabled={true}
                          //   reactionsDefaultOpen={true}
                          //   allowExpandReactions={false}
                          //   className=""
                          // />
                          <EmojiPicker
                            emojiStyle={EmojiStyle.NATIVE}
                            className="bg-white"
                            reactionsDefaultOpen={true}
                            allowExpandReactions={false}
                            onReactionClick={(event) =>
                              reactionMessage(event, message, setOpen)
                            }
                          />
                        )}
                      >
                        <ActionIcon
                          className="h-7 w-7 rounded-full bg-[#D9D9D9] p-0"
                          title={'Reaction'}
                          variant="text"
                        >
                          <MdOutlineEmojiEmotions
                            size={'lg'}
                            className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]"
                          />
                        </ActionIcon>
                      </Popover>
                    )}
                  </div>
                )}

                {/* Document & Audio */}
                {(message?.message_type === 'document' ||
                  message?.message_type === 'audio') && (
                  <button
                    className={cn(
                      'relative min-w-[90px] max-w-[550px] break-words rounded-t-[20px] rounded-br-[20px] bg-white pb-[15px] pl-2 pt-2 text-left text-sm font-normal text-[#191919]',
                      message?.nextIsSame && 'rounded-bl-[20px]',
                      isHovered ? 'pr-9' : 'pr-2'
                    )}
                    onMouseEnter={() => setIsHovered(true)} // Show popover icon on hover
                    onMouseLeave={() => setIsHovered(false)} // Hide popover icon on mouse leave
                  >
                    {isHovered && (
                      <div className="absolute right-0 top-0">
                        {message?.message_type !== 'message' && (
                          <Popover
                            placement="bottom"
                            className="demo_test p-2"
                            gap={0}
                            showArrow={false}
                            content={({ setOpen }) => (
                              <div className="flex flex-col items-center p-0">
                                <Button
                                  variant="text"
                                  className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                  onClick={() => {
                                    setReplyMessage({ ...message });
                                    focusChatInput();
                                  }}
                                >
                                  Reply
                                </Button>
                                {message?.message_type !== 'audio' && (
                                  <Button
                                    variant="text"
                                    className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                    onClick={() => {
                                      if (message?.document_url) {
                                        window.open(
                                          `${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.document_url}`,
                                          '_blank'
                                        );
                                      }
                                    }}
                                  >
                                    View
                                  </Button>
                                )}
                                {message?.message_type !== 'message' && (
                                  <Button
                                    variant="text"
                                    className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                    onClick={() => downloadFile(message)}
                                  >
                                    Save to Downloads
                                  </Button>
                                )}
                              </div>
                            )}
                          >
                            <ActionIcon
                              className="!p-0"
                              title={'More Options'}
                              variant="text"
                            >
                              <IoIosArrowDown className="h-4 w-4 text-[#1E1E1E]" />
                            </ActionIcon>
                          </Popover>
                        )}
                      </div>
                    )}
                    {message?.message_type === 'document' && (
                      <Link
                        target="_blank"
                        href={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.document_url}`}
                      >
                        <FileIcons
                          key={message?._id}
                          fileType={getFileType(message?.document_url)}
                          fileName={message?.original_file_name}
                          className={cn(
                            '!flex-row !bg-[#F5F5F5]',
                            message?.reactions?.length > 0
                              ? message?.message
                                ? 'mb-3'
                                : 'mb-[30px]'
                              : message?.message
                                ? 'mb-2'
                                : 'mb-4'
                          )}
                        />
                      </Link>
                    )}
                    {message?.message_type === 'audio' && (
                      <div
                        className={cn(
                          message?.reactions?.length > 0 ? 'mb-[30px]' : 'mb-4'
                        )}
                      >
                        {/* <audio
                          src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.audio_url}`}
                          controls
                        /> */}
                        <AudioTag
                          audioUrl={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.audio_url}`}
                        />
                      </div>
                    )}
                    {message?.message && (
                      <p
                        dir="ltr"
                        className={cn(
                          'ml-0 mr-4 !text-black',
                          message?.reactions?.length > 0 ? 'mb-7' : 'mb-4'
                        )}
                        ref={hoverRef}
                        dangerouslySetInnerHTML={{
                          __html: highlightText(
                            updateMessageFormatWithMentionUser(
                              message?.message,
                              mentioned_users,
                              true,
                              true,
                              'text-[#6C76FF]'
                            ),
                            searchQuery
                          ),
                        }}
                      ></p>
                    )}
                    <div
                      dir="ltr"
                      className={cn(
                        'poppins_font_number absolute left-5 flex justify-end text-xs font-light text-[#191919]',
                        message?.reactions?.length > 0 ? 'bottom-5' : 'bottom-2'
                      )}
                    >
                      {getFormatedTime(message?.createdAt as Date, 'hh:mm A')}
                    </div>
                    {/* Reaction */}
                    {message?.reactions?.length > 0 && (
                      <div className="absolute -bottom-[10px] left-5 flex h-7 items-center justify-center rounded-full border border-white bg-[#D9D9D9] p-2 shadow-md">
                        {message?.reactions?.map((data: any) => (
                          <div
                            key={data?._id}
                            className=" flex items-center justify-center"
                          >
                            <span className="flex w-fit">
                              <Tooltip
                                placement="top"
                                color="invert"
                                size="sm"
                                content={() => (
                                  <div key={data?._id}>
                                    {' '}
                                    {capitalizeFirstLetter(
                                      data?.user?.first_name
                                    )}{' '}
                                    {capitalizeFirstLetter(
                                      data?.user?.last_name
                                    )}
                                  </div>
                                )}
                              >
                                <ActionIcon
                                  className="h-7 w-5 cursor-pointer !p-0"
                                  variant="text"
                                  onClick={() => removeReaction(message)}
                                >
                                  {data?.emoji}
                                </ActionIcon>
                              </Tooltip>
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </button>
                )}
              </div>
              {/* Reaction Popover */}
              {message?.message_type !== 'image' && (
                <Popover
                  placement="top"
                  className="demo_test gap-2 border-0 bg-transparent"
                  gap={0}
                  content={({ setOpen }) => (
                    // <Picker
                    //   emojiStyle={EmojiStyle.NATIVE}
                    //   onReactionClick={(event) =>
                    //     reactionMessage(event, message)
                    //   }
                    //   skinTonesDisabled={true}
                    //   reactionsDefaultOpen={true}
                    //   allowExpandReactions={false}
                    //   className=""
                    // />
                    <EmojiPicker
                      emojiStyle={EmojiStyle.NATIVE}
                      className="bg-white"
                      reactionsDefaultOpen={true}
                      allowExpandReactions={false}
                      onReactionClick={(event) =>
                        reactionMessage(event, message, setOpen)
                      }
                    />
                  )}
                >
                  <ActionIcon
                    className="h-7 w-7 rounded-full bg-[#D9D9D9] p-0"
                    title={'Reaction'}
                    variant="text"
                  >
                    <MdOutlineEmojiEmotions
                      size={'lg'}
                      className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]"
                    />
                  </ActionIcon>
                </Popover>
              )}
            </div>
          </div>
        )}
        {/* Recevier Message Code End */}

        {/* Sender Message Code Start */}
        {messageFromSender && (
          <div className="flex items-end gap-4 space-x-3">
            <div>
              {/* Message */}
              {message?.message_type === 'message' && (
                <div
                  role="button"
                  className={cn(
                    'relative min-w-[90px] max-w-[550px] cursor-default break-words rounded-t-[20px] rounded-bl-[20px] bg-[#D3D7EC] text-left text-sm font-medium text-white',
                    message?.nextIsSame && 'rounded-br-[20px]',
                    message?.reply_message
                      ? 'py-2 pl-2'
                      : 'pb-2 pl-5 pt-[15px]',
                    isHovered ? 'pr-5' : 'pr-2'
                    // isHovered ? 'pl-9' : 'pl-5'
                  )}
                  onMouseEnter={() => setIsHovered(true)} // Show popover icon on hover
                  onMouseLeave={() => setIsHovered(false)} // Hide popover icon on mouse leave
                >
                  {/*sender message more options */}
                  {isHovered && (
                    <div className="absolute right-0 top-0">
                      <Popover
                        placement="bottom"
                        className="demo_test p-2"
                        gap={0}
                        showArrow={false}
                        content={({ setOpen }) => (
                          <div className="flex flex-col items-center p-0">
                            <Button
                              variant="text"
                              className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                              onClick={() => {
                                setReplyMessage({ ...message });
                                focusChatInput();
                              }}
                            >
                              Reply
                            </Button>
                            <Button
                              variant="text"
                              className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                              onClick={() => {
                                copyToClipboard(message?.message);
                                setOpen(false);
                              }}
                            >
                              Copy
                            </Button>
                            {moment(moment?.now())?.diff(
                              message?.createdAt,
                              'minutes'
                            ) < 30 && (
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => {
                                  setEditMessage({
                                    ...message,
                                    ...(isGroup && {
                                      mentioned_users_list:
                                        mentioned_users ?? [],
                                    }),
                                  });
                                  focusChatInput();
                                }}
                              >
                                Edit
                              </Button>
                            )}
                            <DeletePopover
                              title={`Delete the Message`}
                              isMessageDelete={true}
                              className="flex h-auto w-full items-start justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none "
                              description={`Are you sure you want to delete this message?`}
                              onDelete={() => {
                                deleteMessage(message);
                              }}
                            />
                          </div>
                        )}
                      >
                        <ActionIcon
                          className="!p-0"
                          title={'More Options'}
                          variant="text"
                        >
                          <IoIosArrowDown className="h-4 w-4 text-black" />
                        </ActionIcon>
                      </Popover>
                    </div>
                  )}
                  {/* Replied message show */}
                  {message?.reply_message && (
                    <div
                      role="button"
                      onClick={() => {
                        setRedirectMessage(message?.reply_message);
                      }}
                      className={cn(
                        'mb-2 flex flex-col items-center justify-start gap-[2px] rounded-[10px] border-l-2 border-[#6875F5] bg-[#F5F5F5] px-3 py-2',
                        isHovered ? 'mr-2' : 'mr-0'
                      )}
                    >
                      <div className="flex w-full items-center justify-end text-sm font-bold text-[#6875F5]">
                        {message?.reply_message?.from_user?._id ===
                          signInUserData?.user?.data?.user?._id && 'You'}
                        {!isGroup &&
                          message?.reply_message?.from_user?._id !==
                            signInUserData?.user?.data?.user?._id &&
                          `${capitalizeFirstLetter(
                            message?.reply_message?.from_user?.first_name
                          )} ${capitalizeFirstLetter(
                            message?.reply_message?.from_user?.last_name
                          )}`}
                        {isGroup &&
                          message?.reply_message?.from_user?._id !==
                            signInUserData?.user?.data?.user?._id &&
                          `${capitalizeFirstLetter(
                            message?.reply_message?.from_user?.first_name
                          )} ${capitalizeFirstLetter(
                            message?.reply_message?.from_user?.last_name
                          )}`}
                      </div>

                      {message?.reply_message?.message_type === 'message' &&
                        message?.reply_message?.message && (
                          <p
                            dir="ltr"
                            className="w-full text-left text-xs font-medium text-black"
                            dangerouslySetInnerHTML={{
                              __html: isGroup
                                ? updateMessageFormatWithMentionUser(
                                    message?.reply_message?.message,
                                    mentioned_users,
                                    true,
                                    false,
                                    'text-[#4A40FF]'
                                  )
                                : message?.reply_message?.message,
                            }}
                          ></p>
                        )}
                      {message?.reply_message?.message_type === 'image' && (
                        <div className="flex w-full flex-row-reverse items-center justify-end gap-2 ">
                          <div className="flex items-center justify-center">
                            <Image
                              src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.reply_message?.image_url}`}
                              alt={message?.reply_message?.image_url}
                              className="rounded-[3px] border border-[#D1D5DB] object-cover"
                              width={60}
                              height={48}
                            />
                          </div>
                          <p className="w-full text-xs font-medium text-black">
                            Image
                          </p>
                        </div>
                      )}
                      {message?.reply_message?.message_type === 'document' && (
                        <div className="flex w-full items-center justify-end gap-2">
                          <div className="flex items-center justify-start">
                            <FileIcons
                              key={message?.reply_message?._id}
                              fileType={getFileType(
                                message?.reply_message?.document_url
                              )}
                              fileName={
                                message?.reply_message?.original_file_name
                              }
                              className={cn(
                                ' !bg-[#F5F5F5] !py-[6px] !pe-0 !ps-[6px]'
                              )}
                            />
                          </div>
                        </div>
                      )}
                      {message?.reply_message?.message_type === 'audio' && (
                        <div className="flex w-full items-center justify-end gap-2">
                          {/* <audio
                            src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.reply_message?.audio_url}`}
                            controls
                          /> */}
                          <AudioTag
                            audioUrl={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.reply_message?.audio_url}`}
                          />
                        </div>
                      )}
                    </div>
                  )}
                  <p
                    dir="ltr"
                    className={cn(
                      'mb-2 mr-4 !text-black',
                      message?.reply_message ? 'ml-2' : 'ml-0'
                    )}
                    ref={hoverRef}
                    dangerouslySetInnerHTML={{
                      __html: highlightText(
                        updateMessageFormatWithMentionUser(
                          message?.message,
                          mentioned_users,
                          true,
                          true,
                          'text-[#4A40FF]'
                        ),
                        searchQuery
                      ),
                    }}
                  ></p>
                  <div
                    dir="ltr"
                    className={cn(
                      'poppins_font_number flex w-full items-center justify-end gap-x-2 text-xs font-light text-black',
                      message?.reactions?.length > 0 ? 'mb-[10px]' : 'mb-0'
                    )}
                  >
                    {message?.message_edited && <span>Edited</span>}
                    <span className={cn(isHovered ? '-me-1' : 'me-2')}>
                      {getFormatedTime(message?.createdAt as Date, 'hh:mm A')}
                    </span>
                  </div>
                  {/* Reaction */}
                  {message?.reactions?.length > 0 && (
                    <div className="absolute -bottom-[10px] right-5 flex h-7 items-center justify-center rounded-full border border-[#D9D9D9] bg-white p-2 shadow-md">
                      {message?.reactions?.map((data: any) => (
                        <div
                          key={data?._id}
                          className=" flex items-center justify-center rounded-full"
                        >
                          <span className="flex w-fit">
                            <Tooltip
                              placement="top"
                              color="invert"
                              size="sm"
                              content={() => (
                                <div key={data?._id}>
                                  {' '}
                                  {capitalizeFirstLetter(
                                    data?.user?.first_name
                                  )}{' '}
                                  {capitalizeFirstLetter(data?.user?.last_name)}
                                </div>
                              )}
                            >
                              <ActionIcon
                                className="h-7 w-5 cursor-pointer !p-0"
                                variant="text"
                                onClick={() => removeReaction(message)}
                              >
                                {data?.emoji}
                              </ActionIcon>
                            </Tooltip>
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Images */}
              {message?.message_type === 'image' && (
                <>
                  {message?.images && message?.images?.length > 0 && (
                    <div
                      dir={message?.images?.length > 1 ? 'ltr' : ''}
                      className={cn(
                        'grid items-start justify-start gap-2',
                        !message?.message &&
                          message?.images?.length > 1 &&
                          'rounded-[20px] bg-[#D3D7EC] p-2',
                        message?.images?.length === 1
                          ? 'grid-cols-1'
                          : 'grid-cols-2'
                      )}
                    >
                      {message?.images?.map((image: any, index: number) => {
                        // Only render up to index 3 (4 images total).
                        if (index > 3) {
                          return null;
                        }

                        const isLastWithOverlay =
                          index === 3 && message?.images?.length > 4;

                        return (
                          <div
                            role="button"
                            key={index}
                            className={cn(
                              'relative',
                              message?.message &&
                                'min-w-[90px] max-w-[325px] cursor-default break-words rounded-t-[20px] rounded-bl-[20px] bg-[#D3D7EC] pb-[15px] pl-2 pr-2 pt-2 text-left text-sm font-normal text-white sm:max-w-[550px]',
                              isHovered && message?.message && 'pr-9'
                            )}
                            onMouseEnter={() => {
                              // Show popover icon on hover if there is only 1 image
                              if (message?.images?.length === 1) {
                                setIsHovered(true);
                              }
                            }}
                            onMouseLeave={() => {
                              // Hide popover icon on mouse leave if there is only 1 image
                              if (message?.images?.length === 1) {
                                setIsHovered(false);
                              }
                            }}
                          >
                            {/* Sender message more options */}
                            {isHovered && (
                              <div
                                className={cn('absolute right-0 top-0 z-50')}
                              >
                                <Popover
                                  placement="bottom"
                                  className="demo_test p-2"
                                  gap={0}
                                  showArrow={false}
                                  content={({ setOpen }) => (
                                    <div className="flex flex-col items-center p-0">
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                        onClick={() => {
                                          setReplyMessage({
                                            ...message,
                                            ...image,
                                            _id: image?._id ?? '',
                                            message_type: 'image',
                                          });
                                          focusChatInput();
                                        }}
                                      >
                                        Reply
                                      </Button>
                                      <DeletePopover
                                        title={`Delete the Message`}
                                        isMessageDelete={true}
                                        className="flex h-auto w-full items-start justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none "
                                        description={`Are you sure you want to delete this message?`}
                                        onDelete={() => {
                                          deleteMessage({
                                            ...message,
                                            _id: image?._id ?? '',
                                          });
                                        }}
                                      />
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                        onClick={() => {
                                          // set Image Preview & files
                                          setIsImagePreview(true);
                                          setPreviewImages(message ?? null);
                                          setSelectedImagePreviewIndex(
                                            index ?? 0
                                          );
                                        }}
                                      >
                                        View
                                      </Button>
                                      {message?.message_type !== 'message' && (
                                        <Button
                                          variant="text"
                                          className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                          onClick={() =>
                                            downloadFile({
                                              ...image,
                                              message_type: 'image',
                                            })
                                          }
                                        >
                                          Save to Downloads
                                        </Button>
                                      )}
                                    </div>
                                  )}
                                >
                                  <ActionIcon
                                    className="!p-0"
                                    title={'More Options'}
                                    variant="text"
                                  >
                                    <IoIosArrowDown
                                      className={cn(
                                        'h-4 w-4 rounded-[1.4px] text-[#1E1E1E]',
                                        message?.message
                                          ? 'bg-transparent'
                                          : 'bg-[#F5F5F5]'
                                      )}
                                    />
                                  </ActionIcon>
                                </Popover>
                              </div>
                            )}

                            {/* Image itself */}
                            <div className="relative cursor-pointer">
                              <Image
                                dir="ltr"
                                src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${image?.image_url}`}
                                alt={image?.image_url}
                                className={cn(
                                  'h-[150px] w-[150px] rounded-xl border-2 border-[#D1D5DB] object-cover',
                                  message?.message && 'mr-auto'
                                )}
                                width={150}
                                height={150}
                                onClick={() => {
                                  // set Image Preview & files
                                  setIsImagePreview(true);
                                  setPreviewImages(message ?? null);
                                  setSelectedImagePreviewIndex(index ?? 0);
                                }}
                              />

                              {/* If it's the 4th image and there are more than 4 total, show overlay */}
                              {isLastWithOverlay && (
                                <button
                                  onClick={() => {
                                    // set Image Preview & files
                                    setIsImagePreview(true);
                                    setPreviewImages(message ?? null);
                                    // setSelectedImagePreviewIndex(0);
                                  }}
                                  className="absolute left-0 top-0 z-10 flex h-full w-full cursor-pointer items-center justify-center rounded-xl bg-black/60 text-xl font-bold text-white"
                                >
                                  +{message?.images?.length - 3}
                                </button>
                              )}
                            </div>

                            {/* If there's also text with the image */}
                            {message?.message && (
                              <p
                                dir="ltr"
                                className={cn(
                                  'ml-0 mr-4 mt-2 !text-black',
                                  image?.reactions?.length > 0 ? 'mb-8' : 'mb-5'
                                )}
                                dangerouslySetInnerHTML={{
                                  __html: highlightText(
                                    updateMessageFormatWithMentionUser(
                                      message?.message,
                                      mentioned_users,
                                      true,
                                      true,
                                      'text-[#4A40FF]'
                                    ),
                                    searchQuery
                                  ),
                                }}
                              ></p>
                            )}

                            {/* Time display */}
                            <div
                              dir="ltr"
                              className={cn(
                                'poppins_font_number absolute right-2 flex items-center justify-center rounded-[5.2px] px-[5.2px] py-[2.6px] text-[13px] font-light text-black',
                                image?.reactions?.length > 0
                                  ? 'bottom-5'
                                  : 'bottom-2',
                                message?.message
                                  ? 'bg-transparent'
                                  : 'bg-[#E3E3E3]'
                              )}
                            >
                              {getFormatedTime(
                                message?.createdAt as Date,
                                'hh:mm A'
                              )}
                            </div>

                            {/* Reaction */}
                            {image?.reactions?.length > 0 && (
                              <div className="absolute -bottom-[10px] right-5 flex h-7 items-center justify-center rounded-full border border-[#D9D9D9] bg-white p-2 shadow-md">
                                {image?.reactions?.map((data: any) => (
                                  <div
                                    key={data?._id}
                                    className="flex items-center justify-center rounded-full"
                                  >
                                    <span className="flex w-fit">
                                      <Tooltip
                                        placement="top"
                                        color="invert"
                                        size="sm"
                                        content={() => (
                                          <div key={data?._id}>
                                            {capitalizeFirstLetter(
                                              data?.user?.first_name
                                            )}{' '}
                                            {capitalizeFirstLetter(
                                              data?.user?.last_name
                                            )}
                                          </div>
                                        )}
                                      >
                                        <ActionIcon
                                          className="h-7 w-5 cursor-pointer !p-0"
                                          onClick={() =>
                                            removeReaction(message, index)
                                          }
                                          variant="text"
                                        >
                                          {data?.emoji}
                                        </ActionIcon>
                                      </Tooltip>
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              )}

              {/* Document & Audio */}
              {(message?.message_type === 'document' ||
                message?.message_type === 'audio') && (
                <button
                  className={cn(
                    'relative min-w-[90px] max-w-[325px] break-words rounded-t-[20px] rounded-bl-[20px] bg-[#D3D7EC] pb-[15px] pr-2 pt-2 text-left text-sm font-normal text-white sm:max-w-[550px]',
                    message?.nextIsSame && 'rounded-br-[20px]',
                    isHovered ? 'pl-9' : 'pl-2'
                  )}
                  onMouseEnter={() => setIsHovered(true)} // Show popover icon on hover
                  onMouseLeave={() => setIsHovered(false)} // Hide popover icon on mouse leave
                >
                  {/*sender message more options */}
                  {isHovered && (
                    <div className="absolute left-0 top-0">
                      <Popover
                        placement="bottom"
                        className="demo_test p-2"
                        gap={0}
                        showArrow={false}
                        content={({ setOpen }) => (
                          <div className="flex flex-col items-center p-0">
                            <Button
                              variant="text"
                              className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                              onClick={() => {
                                setReplyMessage({ ...message });
                                focusChatInput();
                              }}
                            >
                              Reply
                            </Button>
                            <DeletePopover
                              title={`Delete the Message`}
                              isMessageDelete={true}
                              className="flex h-auto w-full items-start justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none "
                              description={`Are you sure you want to delete this message?`}
                              onDelete={() => {
                                deleteMessage(message);
                              }}
                            />
                            {message?.message_type !== 'audio' && (
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => {
                                  if (message?.document_url) {
                                    window.open(
                                      `${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.document_url}`,
                                      '_blank'
                                    );
                                  }
                                }}
                              >
                                View
                              </Button>
                            )}
                            {message?.message_type !== 'message' && (
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => downloadFile(message)}
                              >
                                Save to Downloads
                              </Button>
                            )}
                          </div>
                        )}
                      >
                        <ActionIcon
                          className="!p-0"
                          title={'More Options'}
                          variant="text"
                        >
                          <IoIosArrowDown className="h-4 w-4 text-[#1E1E1E]" />
                        </ActionIcon>
                      </Popover>
                    </div>
                  )}
                  {message?.message_type === 'document' && (
                    <Link
                      target="_blank"
                      href={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.document_url}`}
                    >
                      <FileIcons
                        key={message?._id}
                        fileType={getFileType(message?.document_url)}
                        fileName={message?.original_file_name}
                        className={cn(
                          message?.reactions?.length > 0
                            ? message?.message
                              ? 'mb-3'
                              : 'mb-[30px]'
                            : message?.message
                              ? 'mb-2'
                              : 'mb-4'
                        )}
                      />
                    </Link>
                  )}
                  {message?.message_type === 'audio' && (
                    <div
                      className={cn(
                        message?.reactions?.length > 0 ? 'mb-[30px]' : 'mb-4'
                      )}
                    >
                      {/* <audio
                        src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.audio_url}`}
                        controls
                      /> */}
                      <AudioTag
                        audioUrl={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.audio_url}`}
                      />
                    </div>
                  )}
                  {message?.message && (
                    <p
                      dir="ltr"
                      className={cn(
                        'ml-0 mr-4 !text-black',
                        message?.reactions?.length > 0 ? 'mb-7' : 'mb-4'
                      )}
                      ref={hoverRef}
                      dangerouslySetInnerHTML={{
                        __html: highlightText(
                          updateMessageFormatWithMentionUser(
                            message?.message,
                            mentioned_users,
                            true,
                            true,
                            'text-[#4A40FF]'
                          ),
                          searchQuery
                        ),
                      }}
                    ></p>
                  )}
                  <div
                    dir="ltr"
                    className={cn(
                      'poppins_font_number absolute  right-5 flex justify-end text-xs font-light text-black',
                      message?.reactions?.length > 0 ? 'bottom-5' : 'bottom-2'
                    )}
                  >
                    {getFormatedTime(message?.createdAt as Date, 'hh:mm A')}
                  </div>
                  {/* Reaction */}
                  {message?.reactions?.length > 0 && (
                    <div className="absolute -bottom-[10px] right-5 flex h-7 items-center justify-center rounded-full border border-[#D9D9D9] bg-white p-2 shadow-md">
                      {message?.reactions?.map((data: any) => (
                        <div
                          key={data?._id}
                          className=" flex items-center justify-center rounded-full"
                        >
                          <span className="flex w-fit">
                            <Tooltip
                              placement="top"
                              color="invert"
                              size="sm"
                              content={() => (
                                <div key={data?._id}>
                                  {' '}
                                  {capitalizeFirstLetter(
                                    data?.user?.first_name
                                  )}{' '}
                                  {capitalizeFirstLetter(data?.user?.last_name)}
                                </div>
                              )}
                            >
                              <ActionIcon
                                className="h-7 w-5 cursor-pointer !p-0"
                                variant="text"
                                onClick={() => removeReaction(message)}
                              >
                                {data?.emoji}
                              </ActionIcon>
                            </Tooltip>
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </button>
              )}
            </div>
          </div>
        )}
        {/* Sender Message Code End */}
      </div>
    </div>
  );
}
