import React from 'react';
// import { AudioRecorder } from 'react-audio-voice-recorder';
import { ActionIcon, Title } from '@/components/ui/text';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { PiXBold } from 'react-icons/pi';
import cn from '@/utils/class-names';
import { useDispatch } from 'react-redux';
import { uploadAudioInUserChat } from '@/redux/slices/user/chat/chatSlice';

export default function VoiceRecorder(props: any) {
  const { reqPayload } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();

  const addAudioElement = async (blob: Blob) => {
    let payload: any = {
      ...reqPayload,
      audio_blob_data: blob,
    };

    const formData = new FormData();
    for (let i = 0; i < Object.keys(payload).length; i++) {
      formData.append(
        Object.keys(payload)[i],
        Object.values(payload)[i] as any
      );
    }
    dispatch(uploadAudioInUserChat(formData)).then((result: any) => {
      if (uploadAudioInUserChat.fulfilled.match(result)) {
        if (result?.payload?.success == true) {
          closeModal();
        }
      }
    });
  };

  return (
    <div className="p-[20px] [&_label]:font-medium">
      <div className="space-y-5">
        <div className="mb-6 flex items-center justify-between">
          <Title as="h4" className="text-xl font-normal text-[#9BA1B9] xl:text-2xl">
            Voice Message
          </Title>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => closeModal()}
            className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
          >
            <PiXBold className="h-[18px] w-[18px]" />
          </ActionIcon>
        </div>
      </div>
      <div className={cn('flex justify-center')}>
        {/* <AudioRecorder
          onRecordingComplete={addAudioElement}
          audioTrackConstraints={{
            noiseSuppression: true,
            echoCancellation: true,
          }}
          showVisualizer
          downloadOnSavePress={false}
        /> */}
      </div>
      <p className="mt-[14px] flex items-center justify-center text-[14px] font-bold text-[#9BA1B9]">
        Click & Speak
      </p>
    </div>
  );
}
