import { useState, useRef, useEffect } from 'react';
import { FaMicrophone, FaPause, FaStop, FaTrash, FaPlay } from 'react-icons/fa';
import { Button } from 'rizzui';
import { IoPauseCircleOutline } from 'react-icons/io5';
import { FiTrash2 } from 'react-icons/fi';
import { LuSend } from 'react-icons/lu';

interface AudioRecorderProps {
  isRecording: boolean;
  onAudioReady: (audioBlob: Blob) => void;
  onCancel: () => void;
  setIsRecording: any;
}

const AudioRecorder2 = ({
  isRecording,
  setIsRecording,
  onAudioReady,
  onCancel,
}: AudioRecorderProps) => {
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [micPermission, setMicPermission] = useState<
    'granted' | 'denied' | 'prompt'
  >('prompt');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const isDeletedRef = useRef<boolean>(false); //  Tracks if recording was deleted

  useEffect(() => {
    checkMicrophonePermission();
  }, []);

  useEffect(() => {
    if (isRecording) {
      startRecording();
    }
  }, [isRecording]);

  //  Check Microphone Permission
  const checkMicrophonePermission = async () => {
    try {
      const permissionStatus = await navigator.permissions.query({
        name: 'microphone' as PermissionName,
      });
      setMicPermission(permissionStatus.state);

      permissionStatus.onchange = () => {
        setMicPermission(permissionStatus.state);
      };
    } catch (error) {
      console.error('Error checking microphone permission:', error);
    }
  };

  //  Request Microphone Permission
  const requestMicrophonePermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      setMicPermission('granted');
    } catch (error) {
      setMicPermission('denied');
      alert(
        'Microphone access is required to record audio. Please enable it in your browser settings.'
      );
    }
  };

  //  Start Recording
  const startRecording = async () => {
    if (micPermission !== 'granted') {
      await requestMicrophonePermission();

      // 🔥 Fix: Re-check permission explicitly
      const permissionStatus = await navigator.permissions.query({
        name: 'microphone' as PermissionName,
      });

      if (permissionStatus.state !== 'granted') {
        alert('Microphone access is required to record audio.');
        return;
      }
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    audioChunksRef.current = [];
    isDeletedRef.current = false; //  Reset delete state

    mediaRecorder.ondataavailable = (event) => {
      audioChunksRef.current.push(event.data);
    };

    mediaRecorder.onstop = () => {
      if (isDeletedRef.current) return; //  Do NOT fire `onAudioReady` if deleted
      if (audioChunksRef.current.length === 0) return;

      const audioBlob = new Blob(audioChunksRef.current, {
        type: 'audio/webm',
      });
      onAudioReady(audioBlob);
    };

    mediaRecorder.start();
    startTimer();
    setIsRecording(true);
    setIsPaused(false);
  };

  //  Start Timer
  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setRecordingTime((prev) => prev + 1);
    }, 1000);
  };

  //  Stop Timer
  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  //  Pause/Resume Recording
  const togglePause = () => {
    if (!mediaRecorderRef.current) return;
    if (isPaused) {
      mediaRecorderRef.current.resume();
      startTimer();
    } else {
      mediaRecorderRef.current.pause();
      stopTimer();
    }
    setIsPaused(!isPaused);
  };

  //  Stop Recording
  const stopRecording = () => {
    if (!mediaRecorderRef.current) return;
    mediaRecorderRef.current.stop();
    stopTimer();
    setIsRecording(false);
  };

  //  Delete Recording (Cancel Everything, Do NOT Fire onAudioReady)
  const deleteRecording = () => {
    if (mediaRecorderRef.current) {
      isDeletedRef.current = true; //  Mark as deleted
      mediaRecorderRef.current.stop();
    }
    stopTimer();
    setIsRecording(false);
    setIsPaused(false);
    setRecordingTime(0);
    audioChunksRef.current = [];
  };

  //  Format Timer Display (MM:SS)
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="flex w-full items-center gap-2">
      <Button
        variant="text"
        size="sm"
        onClick={deleteRecording}
        className="text-gray-500"
      >
        <FiTrash2 className="h-5 w-5" />
      </Button>
      <div className="flex h-10 w-full items-center justify-between gap-2 rounded-lg bg-gray-100 px-4 py-2">
        <div className="flex items-center justify-start gap-4">
          <span className="inline-block h-4 w-4 rounded-full bg-red"></span>
          <span className="min-w-[40px] text-sm text-gray-600">
            {formatTime(recordingTime)}
          </span>
        </div>
        <div className="flex items-center justify-start">
          <Button
            variant="text"
            size="sm"
            onClick={togglePause}
            className="text-gray-500"
          >
            {isPaused ? (
              <FaPlay className="h-4 w-4 text-[#5865F2]" />
            ) : (
              <IoPauseCircleOutline className="h-5 w-5 text-[#5865F2]" />
            )}
          </Button>
        </div>
      </div>
      <div className="!h-10 !w-10">
        <Button
          type="button"
          onClick={stopRecording}
          className="flex !h-10 !w-10 items-center justify-center rounded-lg bg-[#6875F5] !p-0"
        >
          <LuSend className="h-5 w-5 cursor-pointer text-[#FFFFFF]" />
        </Button>
      </div>
    </div>
  );
};

export default AudioRecorder2;
