"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "rizzui"
import { IoPauseCircleOutline } from "react-icons/io5";
import { FaPlay } from "react-icons/fa";
import { FiTrash2 } from "react-icons/fi";
import { LuSend } from "react-icons/lu";

interface AudioRecorderProps {
  isRecording: boolean,
  onAudioReady: (audioBlob: Blob) => void
  onCancel: () => void
  setIsRecording: any
}

export const AudioRecorder: React.FC<AudioRecorderProps> = ({ isRecording, onAudioReady, onCancel, setIsRecording }) => {
  const [isPaused, setIsPaused] = useState(false)
  const [duration, setDuration] = useState(0)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const animationFrameRef = useRef<number>()
  const audioContextRef = useRef<AudioContext>()
  const analyserRef = useRef<AnalyserNode>()
  const startTimeRef = useRef<number>(0)
  const pausedDurationRef = useRef<number>(0)

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      if (audioContextRef.current) {
        audioContextRef.current.close()
      }
    }
  }, []);

  useEffect(() => {
    return () => {
      resetRecording()
    }
  }, []);

  useEffect(() => {
    if (isRecording) {
      startRecording();
    }
  }, [isRecording]);

  const drawWaveform = (dataArray: Uint8Array) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height
    const bufferLength = dataArray.length
    const barWidth = (width / bufferLength) * 0.5
    let x = 0

    ctx.fillStyle = "#f8f9fa"
    ctx.fillRect(0, 0, width, height)

    ctx.beginPath()
    ctx.moveTo(0, height / 2)

    for (let i = 0; i < bufferLength; i++) {
      const barHeight = (dataArray[i] / 255) * height * 0.5
      ctx.lineTo(x, height / 2 + barHeight)
      x += barWidth
    }

    for (let i = bufferLength - 1; i >= 0; i--) {
      const barHeight = (dataArray[i] / 255) * height * 0.5
      ctx.lineTo(x, height / 2 - barHeight)
      x -= barWidth
    }

    ctx.lineTo(0, height / 2)
    ctx.closePath()
    ctx.fillStyle = "#e2e8f0"
    ctx.fill()
  }

  const visualize = () => {
    if (!analyserRef.current) return

    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount)
    analyserRef.current.getByteTimeDomainData(dataArray)
    drawWaveform(dataArray)

    animationFrameRef.current = requestAnimationFrame(visualize)
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })

      audioContextRef.current = new AudioContext()
      analyserRef.current = audioContextRef.current.createAnalyser()
      const source = audioContextRef.current.createMediaStreamSource(stream)
      source.connect(analyserRef.current)
      analyserRef.current.fftSize = 256

      mediaRecorderRef.current = new MediaRecorder(stream)
      audioChunksRef.current = []

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data)
        }
      }

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" })
        onAudioReady(audioBlob)
      }

      mediaRecorderRef.current.start()
      startTimeRef.current = Date.now()
      setIsRecording(true)
      visualize()
    } catch (err) {
      console.error("Error accessing microphone:", err)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
      setIsPaused(false)
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }

  const togglePause = () => {
    if (!mediaRecorderRef.current) return

    if (isPaused) {
      mediaRecorderRef.current.resume();
      pausedDurationRef.current += Date.now() - startTimeRef.current;
      visualize();
    } else {
      mediaRecorderRef.current.pause()
      startTimeRef.current = Date.now()
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
    setIsPaused(!isPaused)
  }

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRecording && !isPaused) {
      interval = setInterval(() => {
        const currentDuration = Math.floor((Date.now() - startTimeRef.current + pausedDurationRef.current) / 1000)
        setDuration(currentDuration)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isRecording, isPaused])

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const resetRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
    }
    if (audioContextRef.current) {
      audioContextRef.current.close()
    }
    setIsRecording(false)
    setIsPaused(false)
    setDuration(0)
    audioChunksRef.current = []
    startTimeRef.current = 0
    pausedDurationRef.current = 0
  }

  const handleCancel = () => {
    resetRecording();
    onCancel();
  }

  return (
    <div className="flex items-center gap-2 p-2 w-full">
      <Button variant="text" size="sm" onClick={handleCancel} className="text-gray-500">
        <FiTrash2 className="w-5 h-5" />
      </Button>
      <div className="flex w-full py-2 px-4 items-center gap-2 rounded-lg bg-gray-100">
        <span className="w-4 h-4 bg-red rounded-full inline-block"></span>
        <span className="text-sm text-gray-600 min-w-[40px]">{formatDuration(duration)}</span>
        <canvas ref={canvasRef} className="flex-1 h-8 rounded" width={300} height={32} />
        <Button variant="text" size="sm" onClick={togglePause} className="text-gray-500">
          {isPaused ? <FaPlay className="w-5 h-5 text-[#5865F2]" /> : <IoPauseCircleOutline className="w-5 h-5 text-[#5865F2]" />}
        </Button>
      </div>
      <Button
        type="button"
        onClick={stopRecording}
        className="flex h-8 w-8 items-center justify-center !bg-transparent !p-0"
      >
        <LuSend className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
      </Button>
    </div>
  )
}

