'use client';

import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import Spinner from '@/components/ui/spinner';
import {
  getTaskCommentsHistory,
  removeCommentsData,
  setCurrentTaskDetails,
  updateTasksInBoard,
} from '@/redux/slices/user/chat/boards/boardChatSlice';
import {
  SetBoardId,
  getBoardSectionsById,
  getMembersByBoardId,
} from '@/redux/slices/user/task/boardSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter, checkDueDate } from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { IoIosArrowDown, IoIosArrowUp } from 'react-icons/io';
import { useDispatch, useSelector } from 'react-redux';
import SimpleBar from 'simplebar-react';
import ViewTaskFormSideBar from '../../task/task-grid/view-task-form';
import CommentBody from './comment-body';
import TaskComment from './task-comment';

export default function TaskBody({
  task,
  date,
  selectedUser,
  signInUserData,
  highlightText,
  searchQuery,
  setOpenTaskId,
  openTaskId,
}: Readonly<{
  task: any;
  date: any;
  selectedUser: any;
  signInUserData: any;
  highlightText: any;
  searchQuery: any;
  setOpenTaskId: any;
  openTaskId: any;
}>) {
  const [isOpen, setIsOpen] = useState(false);

  const [isAddComment, setIsAddComment] = useState(false);
  const dispatch = useDispatch();
  const {
    commentsHistory,
    taskAssignees,
    taskMentionedUsers,
    getTaskCommentsHistoryLoader,
  } = useSelector((state: any) => state.root.boardChat);
  const cardRef = useRef<any>(null);
  const commentBoxRef = useRef<any>(null);
  const { openDrawer, closeDrawer } = useDrawer();
  const today = moment().startOf('day');
  const inputDate = moment(date, 'YYYY-MM-DD').startOf('day');

  // for scroll to bottom reference
  const commentsEndRef = useRef<any>(null);
  const simpleBarRef = useRef<any>(null);

  useEffect(() => {
    // console.log('use effect calledddddddd');
    if (openTaskId?.task_id === task?._id && openTaskId?.date === date) {
      // console.log('we are in if');
      dispatch(removeCommentsData());
      setIsOpen(true);
    } else {
      // console.log('we are in else');
      setIsOpen(false);
      dispatch(removeCommentsData());
    }
  }, [openTaskId?.task_id, openTaskId?.date]);

  // console.log(
  //   'task....',
  //   task,
  //   'date.....',
  //   date,
  //   'selectedUser....',
  //   selectedUser
  // );
  // console.log(
  //   'getTaskCommentsHistoryLoader...',
  //   getTaskCommentsHistoryLoader,
  //   'commentsHistory......',
  //   commentsHistory
  // );
  // console.log(
  //   'taskAssignees....',
  //   taskAssignees,
  //   'taskMentionedUsers.....',
  //   taskMentionedUsers
  // );

  useEffect(() => {
    if (isOpen && task?._id && date) {
      dispatch(getTaskCommentsHistory({ task_id: task?._id ?? '', date }));
      dispatch(SetBoardId(selectedUser?._id ?? ''));
      dispatch(getBoardSectionsById({ board_id: selectedUser?._id ?? '' }));
      dispatch(getMembersByBoardId({ boardId: selectedUser?._id ?? '' }));
    }
  }, [isOpen, selectedUser?._id]);

  useEffect(() => {
    if (simpleBarRef.current) {
      requestAnimationFrame(() => {
        const scrollElement = simpleBarRef.current.getScrollElement();
        scrollElement.scrollTo({
          top: scrollElement.scrollHeight,
          behavior: 'smooth',
        });
      });
    }
  }, [commentsHistory]);

  useEffect(() => {
    // Add event listener to detect clicks outside the card
    const handleClickOutsideCard = (event: any) => {
      if (cardRef.current && !cardRef.current.contains(event.target)) {
        // setIsOpen(false);
        setIsAddComment(false);
      }
    };

    // Add event listener to detect clicks outside the comment box
    const handleClickOutsideCommentBox = (event: any) => {
      if (
        commentBoxRef.current &&
        !commentBoxRef.current.contains(event.target)
      ) {
        setIsAddComment(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutsideCard);
    document.addEventListener('mousedown', handleClickOutsideCommentBox);
    return () => {
      document.removeEventListener('mousedown', handleClickOutsideCard);
      document.removeEventListener('mousedown', handleClickOutsideCommentBox);
    };
  }, []);

  return (
    <div
      ref={cardRef}
      className={cn(
        'flex flex-col items-center justify-between gap-2 rounded-lg',
        isOpen
          ? 'w-full bg-[#F9FAFB] px-4 py-[15px]'
          : 'h-auto min-w-[300px] bg-white px-4 py-[10px]'
      )}
    >
      {/* Header */}
      <button
        className="flex w-full items-center justify-between gap-2"
        onClick={() => {
          if (isOpen) {
            setOpenTaskId(null);
            dispatch(setCurrentTaskDetails(null));
          } else if (
            openTaskId?.task_id === task?._id &&
            openTaskId?.date !== date
          ) {
            console.log('we are in else if for setting the tasks data');
            setOpenTaskId({ task_id: task?._id, date });
            dispatch(
              setCurrentTaskDetails({
                ...task,
                date,
                user: signInUserData?.user?.data?.user?._id ?? '',
              })
            );
          } else {
            setOpenTaskId({ task_id: task?._id, date });
            dispatch(
              setCurrentTaskDetails({
                ...task,
                date,
                user: signInUserData?.user?.data?.user?._id ?? '',
              })
            );
          }
        }}
      >
        <div
          className={cn(
            'flex items-center justify-start gap-2',
            isOpen ? 'w-[80%]' : 'w-full'
          )}
        >
          <div className="flex h-4 w-4 items-center justify-center bg-[#F3F4F6]">
            {isOpen ? (
              <IoIosArrowUp className="h-3 w-3" />
            ) : (
              <IoIosArrowDown className="h-3 w-3" />
            )}
          </div>
          <div className="text-sm font-semibold text-black">Task:</div>
          <p
            className="text-sm font-semibold"
            style={{ color: task?.task_text_color ?? '#FF5A1F' }}
            dangerouslySetInnerHTML={{
              __html: highlightText(
                capitalizeFirstLetter(task?.title),
                searchQuery
              ),
            }}
          ></p>
        </div>
        {isOpen && task?.due_date && (
          <div className="flex w-[20%] items-center justify-end">
            {checkDueDate(
              moment(task?.due_date)?.toDate(),
              task?.mark_as_done
            ) ?? ''}
          </div>
        )}
      </button>

      {/* Comments listing */}
      {isOpen && (
        <SimpleBar
          className="h-[200px] w-full border-t border-[#E5E7EB] py-[10px]"
          ref={simpleBarRef}
        >
          {getTaskCommentsHistoryLoader && (
            <div className="flex h-[150px] w-full items-center justify-center">
              <Spinner size="xl" />
            </div>
          )}
          {!getTaskCommentsHistoryLoader &&
            commentsHistory?.length > 0 &&
            commentsHistory?.map((comment: any, index: any) => (
              <div
                key={comment?._id}
                ref={
                  index === commentsHistory?.length - 1 ? commentsEndRef : null
                }
              >
                <CommentBody message={comment} selectedUser={selectedUser} />
              </div>
            ))}
        </SimpleBar>
      )}

      {/* Footer */}
      {!isOpen ? (
        <div
          className={cn(
            'flex w-full items-center gap-2',
            task?.un_read_count > 0 ? 'justify-between' : 'justify-end'
          )}
        >
          {task?.un_read_count > 0 && (
            <div className="text-xs font-semibold text-[#E74694]">
              {`${task?.un_read_count} new comment${
                task?.un_read_count > 1 ? 's' : ''
              }`}
              {/* {capitalizeFirstLetter(task?.latestComment?.comment)} */}
            </div>
          )}
          {task?.due_date && (
            <div>
              {checkDueDate(
                moment(task?.due_date)?.toDate(),
                task?.mark_as_done
              ) ?? ''}
            </div>
          )}
        </div>
      ) : (
        <>
          {!isAddComment && (
            <div
              className={cn(
                'flex w-full items-center gap-2',
                !task?.mark_as_done && !task?.mark_as_archived
                  ? 'justify-between'
                  : 'justify-end'
              )}
            >
              {!task?.mark_as_done && !task?.mark_as_archived && (
                <button
                  className="flex h-10 items-center justify-center rounded-lg border border-[#6875F5] bg-transparent p-3 text-sm font-medium text-[#5850EC]"
                  onClick={() => {
                    if (!inputDate?.isSame(today, 'day')) {
                      dispatch(
                        updateTasksInBoard({
                          task,
                          date,
                          board_id: selectedUser?._id,
                          currentBoard: selectedUser,
                          setOpenTaskId,
                          setIsAddComment,
                        })
                      );
                    } else {
                      setIsAddComment(true);
                    }
                  }}
                >
                  Add comment
                </button>
              )}
              <button
                className="flex h-10 items-center justify-center rounded-lg border border-[#E5E7EB] bg-white p-3 text-sm font-medium text-[#111928]"
                onClick={() => {
                  openDrawer({
                    view: (
                      <ViewTaskFormSideBar
                        rowData={task}
                        editMode={true}
                        onClose={closeDrawer}
                        isView={true}
                        isInboxTaskView={true}
                      />
                    ),
                    placement: 'right',
                    customSize: '640px',
                  });
                }}
              >
                View Task
              </button>
            </div>
          )}
        </>
      )}

      {/* Comment Textarea */}
      {isOpen && isAddComment && (
        <div ref={commentBoxRef} className="w-full">
          <TaskComment task={task} selectedUser={selectedUser} />
        </div>
      )}
    </div>
  );
}
