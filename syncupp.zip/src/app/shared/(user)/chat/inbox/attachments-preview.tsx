import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { getFileType } from '@/utils/common-functions';
import Image from 'next/image';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { FaRegTrashAlt } from 'react-icons/fa';
import SimpleBar from 'simplebar-react';

export const AttachmentsPreview = ({
  files,
  setFiles,
}: {
  files?: any;
  setFiles?: any;
}) => {
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  // Memoize the selected file
  const selectedFile = useMemo(
    () =>
      files?.length > 0 && selectedIndex > -1 ? files[selectedIndex] : null,
    [files, selectedIndex]
  );

  // Keyboard event handler using functional update
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!files?.length) {
        return;
      }
      setSelectedIndex((prev) => {
        if (e.key === 'ArrowRight' && prev < files?.length - 1) {
          return prev + 1;
        }
        if (e.key === 'ArrowLeft' && prev > 0) {
          return prev - 1;
        }
        return prev;
      });
    },
    [files]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const handleThumbnailClick = useCallback((index: number) => {
    setSelectedIndex(index);
  }, []);

  // Delete a file and adjust the selected index if necessary
  const handleDeleteFile = useCallback((index: number) => {
    setFiles((prev: any) => {
      const updated = [...prev];
      updated?.splice(index, 1);
      return updated;
    });
    setSelectedIndex((prevIndex) =>
      index <= prevIndex ? Math.max(prevIndex - 1, 0) : prevIndex
    );
  }, []);

  return (
    <div className="flex h-full w-full flex-col gap-5">
      {/* Main preview area */}
      <div className="flex flex-1 items-center justify-center rounded-lg p-2">
        {selectedFile ? (
          selectedFile?.type?.startsWith('image/') ? (
            <div
              className="relative h-full w-full max-w-lg"
              title={selectedFile?.name ?? ''}
            >
              <Image
                src={selectedFile?.preview}
                alt="Attachment Preview"
                layout="fill"
                objectFit="contain"
                className="rounded-lg"
              />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-3">
              <div className="flex size-56 items-center justify-center rounded-lg border border-gray-200 bg-white">
                <CustomFileIcons
                  fileType={getFileType(selectedFile?.name ?? '')}
                  iconClassName="w-[132px] h-[132px]"
                />
              </div>
              <p className="break-all px-[100px] text-base font-medium text-black">
                {selectedFile?.name ?? ''}
              </p>
            </div>
          )
        ) : (
          <p className="text-black">No file selected</p>
        )}
      </div>

      {/* Thumbnail preview list */}
      {files?.length > 0 && (
        <SimpleBar className="pb-4" >
          <div className="flex flex-row bg-white rounded w-max ">
            {files?.map((file: any, index: number) => (
              <div
                key={index}
                title={file?.name ?? ''}
                role="button"
                className="relative flex-shrink-0 cursor-pointer rounded border border-transparent p-1 transition-colors hover:border-gray-300 "
                onClick={() => handleThumbnailClick(index)}
              >
                {file?.type?.startsWith('image/') ? (
                  <div className="relative h-20 w-20">
                    <Image
                      src={file?.preview}
                      alt="Thumbnail"
                      layout="fill"
                      objectFit="cover"
                      className="rounded"
                    />
                  </div>
                ) : (
                  <div className="flex h-20 w-20 items-center justify-center rounded border border-gray-200 bg-white">
                    <CustomFileIcons
                      fileType={getFileType(file?.name ?? '')}
                      iconClassName="w-10 h-10"
                    />
                  </div>
                )}

                {/* Delete icon shown only for the selected thumbnail */}
                {selectedIndex === index && (
                  <button
                    type="button"
                    title="Remove"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteFile(index);
                    }}
                    className="absolute inset-0 flex items-center justify-center rounded bg-black/15"
                  >
                    <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-gray-700">
                      <FaRegTrashAlt className="h-4 w-4 text-white" />
                    </span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </SimpleBar>
      )}
    </div>
  );
};
