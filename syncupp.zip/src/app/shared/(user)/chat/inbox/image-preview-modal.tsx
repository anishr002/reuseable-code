import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon, Text, Title } from '@/components/ui/text';
import { HiOutlineDownload } from 'react-icons/hi';
import { PiXBold } from 'react-icons/pi';

export const ImagePreviewModel = ({
  fileUrl,
  original_file_name,
  downloadFile,
}: Readonly<{
  fileUrl: string;
  original_file_name: string;
  downloadFile?: any;
}>) => {
  const { closeModal } = useModal();

  console.log({ original_file_name }, { fileUrl }, 'data');

  return (
    <div className="bg-black">
      <div className="flex w-full items-center justify-between bg-[#3C3C43] px-12 py-3">
        <Text className="w-full break-all text-xl font-medium text-white">
          {original_file_name}
        </Text>
        <div className="flex items-center justify-center gap-2">
          <ActionIcon
            size="sm"
            variant="text"
            onClick={downloadFile}
            className="p-0 hover:!text-[#E5E7EB]"
          >
            <HiOutlineDownload className="h-5 w-5 text-white" />
          </ActionIcon>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => closeModal()}
            className="p-0 hover:!text-[#E5E7EB]"
          >
            <PiXBold className="h-5 w-5 text-white" />
          </ActionIcon>
        </div>
      </div>
      <div className="flex h-[calc(100dvh-110px)] items-center justify-center px-10 py-10">
        <img
          src={fileUrl}
          alt={original_file_name}
          className="max-h-full max-w-full object-contain"
        />
      </div>
    </div>
  );
};
