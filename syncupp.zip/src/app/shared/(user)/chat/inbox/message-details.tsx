'use client';

import MessageBody from '@/app/shared/(user)/chat/inbox/message-body';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Popover } from '@/components/ui/popover';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { Text } from '@/components/ui/text';
import { documentFileType, imageFileType } from '@/config/constants';
import { useElementSize } from '@/hooks/use-element-size';
import { useMedia } from '@/hooks/use-media';
import socket from '@/io';
import { getBoardTasksHistory } from '@/redux/slices/user/chat/boards/boardChatSlice';
import {
  clearMessage,
  editMessageChat,
  getSingleUserChat,
  setShowSearchFilter,
  uploadAudioInUserChat,
  uploadDocumentInUserChat,
  uploadImageInUserChat,
} from '@/redux/slices/user/chat/chatSlice';
import {
  getGroupById,
  getGroupHistory,
  uploadDocumentInGroup,
  uploadImageInGroupChat,
} from '@/redux/slices/user/chat/group/groupChatSlice';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  documentAccept,
  formatDate,
  getFileSize,
  getFileType,
  groupMessagesByDate,
  handleKeyDown,
  imageAccept,
  requestMicrophone,
  updateMessageFormatWithMentionUser,
} from '@/utils/common-functions';
import { Transition } from '@headlessui/react';
import noConversationSelected from '@public/assets/images/Inbox_conversation_background.png';
import Picker, { EmojiStyle } from 'emoji-picker-react';
import { Field, FieldProps, Form, Formik } from 'formik';
import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import toast from 'react-hot-toast';
import { BsEmojiSmile } from 'react-icons/bs';
import { FiMic, FiMicOff, FiUpload } from 'react-icons/fi';
import { GoChevronLeft, GoFileMedia } from 'react-icons/go';
import {
  IoIosArrowBack,
  IoIosArrowDown,
  IoIosArrowForward,
  IoIosArrowUp,
  IoMdAttach,
} from 'react-icons/io';
import { LuSearch, LuSend } from 'react-icons/lu';
import { MdDone } from 'react-icons/md';
import { PiMagnifyingGlassBold, PiXBold, PiXCircle } from 'react-icons/pi';
import { Mention, MentionsInput } from 'react-mentions';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';
import { checkPermission } from '../../roles-permissions/utils';
import CreateGroupForm from '../group/create-group';
import MetaComponent from './MetaComponent';
import { AttachmentsPreview } from './attachments-preview';
import AudioRecorder2 from './audio-recorder2';
import AudioTag from './audio-tag';
import { FileIcons } from './file-icons';
import { ImagesPreview } from './images-preview';
import { ProfileViewPage } from './profile-view';
import TaskBody from './task-body';
import VoiceRecorder from './voice-recorder';

export default function MessageDetails({
  chatUser,
  className,
  setChatUser,
}: Readonly<{
  chatUser: any;
  className?: string;
  setChatUser: any;
}>) {
  const [ref, { width }] = useElementSize();
  const isMobile = useMedia('(max-width: 1023px)', false);
  const [showProfileDetails, setShowProfileDetails] = useState(false);
  // const messagesEndRef = useRef<any>(null);
  const dispatch = useDispatch();
  const listRef = useRef<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);
  const [skip, setSkip] = useState(1);
  const { openModal } = useModal();
  const isChat = chatUser?.chat_type === 'chat' ? true : false;
  const isGroup = chatUser?.chat_type === 'group' ? true : false;
  const isBoard = chatUser?.chat_type === 'board' ? true : false;
  const validImageSize = 200; // MB
  const validDocumentFileSize = 200; // MB
  const [showProfile, setShowProfile] = useState(false);
  const [previewUrl, setPreviewUrl] = useState({});
  const [mentionUser, setMentionUser] = useState<any>([]);
  const [openTaskId, setOpenTaskId] = useState<any>(null);
  const [replyMessage, setReplyMessage] = useState<any>(null);
  const [redirectMessage, setRedirectMessage] = useState<any>(null);
  const [editMessage, setEditMessage] = useState<any>(null);
  const chatInputRef = useRef<HTMLTextAreaElement | null>(null);
  const [audionButtonDisabled, setAudionButtonDisabled] = useState(false);
  // Attachments upload states
  const [files, setFiles] = useState<any>([]);
  const [fileAccept, setFileAccept] = useState<any>({
    ...imageAccept,
    ...documentAccept,
  });
  const [isDragAttachment, setIsDragAttachment] = useState<boolean>(false);
  const [isAttachmentPreview, setIsAttachmentPreview] =
    useState<boolean>(false);
  // Images preview states
  const [isImagePreview, setIsImagePreview] = useState<boolean>(false);
  const [previewImages, setPreviewImages] = useState<any>(null);
  const [selectedImagePreviewIndex, setSelectedImagePreviewIndex] =
    useState<number>(0);

  console.log('files......', files);
  console.log('previewImages......', previewImages);
  console.log('isAttachmentPreview......', isAttachmentPreview);
  console.log('isImagePreview......', isImagePreview);
  console.log('selectedImagePreviewIndex......', selectedImagePreviewIndex);
  console.log('replyMessage......', replyMessage);
  console.log('redirectMessage......', redirectMessage);
  // const [showSearchFilter, setShowSearchFilter] = useState(false)
  const [payload, setPayload] = useState({
    skip: 0,
    limit: 1000,
    search: '',
  });
  // Form initial value
  const initialValues: { message: string } = {
    message: '',
  };

  const [formValues, setFormValues] = useState(initialValues); // State to manage form values
  const [isReset, setIsReset] = useState(false); // State to manage form values
  const [isRecording, setIsRecording] = useState(false);

  // Chat Form Validation Schema
  const chatFormSchema = Yup.object().shape({
    message: Yup.string(),
  });

  // Login user data
  const signInUserData = useSelector((state: any) => state?.root?.signIn);

  const { documentChatLoader } = useSelector((state: any) => state?.root?.chat);

  // set default selected message when render complete
  const isLoading = useSelector(
    (state: any) => state?.root?.chat?.messageLoading
  );
  const groupMessageLoading = useSelector(
    (state: any) => state?.root?.group?.groupMessageLoader
  );
  const { singleGroupDetails, singleGroupDetailsLoader, mentioned_users } =
    useSelector((state: any) => state?.root?.group);

  // console.log(singleGroupDetails, 'singleGroupDetails');
  // console.log('chatUser in message Details....', chatUser);

  // Message List
  const messages = useSelector(
    (state: any) => state?.root?.chat?.singleUserChat
  );

  // Group Message History
  const groupMessageHistory = useSelector(
    (state: any) => state?.root?.group?.groupMessageHistory
  );

  const chatSlice = useSelector((state: any) => state?.root?.chat);
  const groupSlice = useSelector((state: any) => state?.root?.group);
  const { getBoardTasksHistoryLoader, tasksHistory } = useSelector(
    (state: any) => state.root.boardChat
  );

  // console.log('board tasksHistory......', tasksHistory);

  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  // one to one chat messages group by date
  const groupedMessages = groupMessagesByDate(messages) ?? [];

  // group chat messages group by date
  const groupedMessagesGroupHistory =
    groupMessagesByDate(groupMessageHistory) ?? [];

  // Mention Style Start
  const mentionStyles = {
    control: {
      backgroundColor: '#F9FAFB',
      fontSize: 16,
      fontWeight: 'normal',
      color: '#000000',
    },
    '&multiLine': {
      control: {
        fontFamily: 'Arial, sans-serif',
        overflow: 'hidden',
        maxHeight: '4rem',
        borderRadius: '8px',
      },
      highlighter: {
        padding: 9,
        border: '1px solid transparent',
        overflow: 'hidden',
        maxHeight: '3.9rem',
        borderRadius: '8px',
      },
      input: {
        padding: 6,
        paddingLeft: 16,
        border: '1px solid #E5E5E5',
        height: 'auto',
        maxHeight: '3.9rem',
        overflow: 'auto',
        color: '#000000',
        borderRadius: '8px',
      },
    },
    suggestions: {
      width: '200px',
      list: {
        backgroundColor: 'white',
        border: '1px solid rgba(0,0,0,0.15)',
        color: '#000000',
        fontSize: 14,
        zIndex: 9999, // high z-index so it stays on top of all other layers
      },
      item: {
        padding: '5px 15px',
        borderBottom: '1px solid #ccc',
        zIndex: 9999,
        '&focused': {
          backgroundColor: '#8C80D2',
          color: 'white',
        },
      },
    },
  };
  // Mention Style End

  // Mobile View
  useEffect(() => {
    if (isMobile) {
      setShowProfile(true);
    }
  }, [isMobile]);

  // when board chat selected then showProfile should be set to false.
  useEffect(() => {
    if (isBoard) {
      setShowProfile(false);
    }
  }, [isBoard]);

  // Check Micrphone Permission
  useEffect(() => {
    checkMicrophonePermission();
  }, []);

  // Effect for remove search value when chat user is change
  useEffect(() => {
    onSearchClear();
    setFormValues({ message: '' });
    setIsReset(true);
    // open task should close when board changed from listing
    setOpenTaskId(null);
    // mention user set to [] when user changed
    setMentionUser([]);
    // reply message set to null when user changed
    setReplyMessage(null);
    // edit message set to null when user changed
    setEditMessage(null);
    // recording set to false when user changed
    setIsRecording(false);
    // attachments set to [] when user changed
    // Remove Selected File
    setFiles([]);
    setIsAttachmentPreview(false);
    // preview images set to [] when user changed
    // Remove Selected preview
    setIsImagePreview(false);
    setPreviewImages(null);
    setSelectedImagePreviewIndex(0);
    setIsDragAttachment(false);
    // Set file acceptance configuration (for file extensions)
    setFileAccept({
      ...imageAccept,
      ...documentAccept,
    });
  }, [chatUser?._id]);

  const parseMentions = (text: any, mentionedUsers: any) => {
    if (!mentionedUsers || Object.keys(mentionedUsers)?.length === 0) {
      return { plainText: text, mentions: [] };
    }

    // Regular expression to match mentions: @[user]::[24-char ID]
    const mentionRegex = /@\[(user)::([a-f0-9]{24})\]/g;

    let mentions: any = [];
    let plainText = text.replace(
      mentionRegex,
      (match: any, _: any, userId: any) => {
        const displayName = mentionedUsers?.[userId];
        if (displayName) {
          mentions.push({ id: userId, display: displayName });
          return displayName; // Keeping @ included in displayName
        }
        return match; // If not found, return original mention format
      }
    );

    return { plainText, mentions };
  };

  // reply message set in form input value
  useEffect(() => {
    // console.log('replyMessage......', replyMessage);
    if (replyMessage) {
      setEditMessage(null);
      setIsRecording(false);
      setFormValues({ message: '' });
      setMentionUser([]);
    }
  }, [replyMessage]);

  // console.log('mentionUser.....', mentionUser);
  // Edit message set in form input value
  useEffect(() => {
    // console.log('editMessage......', editMessage);
    if (editMessage?.message) {
      setIsRecording(false);
      setReplyMessage(null);
      if (isGroup) {
        const { plainText, mentions } = parseMentions(
          editMessage?.message ?? '',
          editMessage?.mentioned_users_list
        );
        // console.log('plainText.....', plainText, 'mentions......', mentions);
        setFormValues({ message: plainText ?? '' });
        setMentionUser(mentions ?? []);
      } else {
        setFormValues({ message: editMessage?.message ?? '' });
        setMentionUser([]);
      }
    }
  }, [editMessage]);

  // search Message functionality start
  // Clear search
  const onSearchClear = () => {
    setSearchQuery('');
    setSearchResults([]);
    setCurrentIndex(0);
    dispatch(setShowSearchFilter(false));
  };

  const onSearchChange = (event: any) => {
    const query = event?.target?.value?.trim().toLowerCase();
    setSearchQuery(query);
    setCurrentIndex(0);

    if (!query) {
      setSearchResults([]); // Reset search when query is empty
      return;
    }

    let filteredIndices: any[] = [];

    if (isGroup) {
      filteredIndices = groupedMessagesGroupHistory
        ?.flatMap(
          (group, groupIndex) =>
            group?.messages
              ?.map((message: any, messageIndex: number) => ({
                message,
                index: { groupIndex, messageIndex },
              }))
              ?.filter(
                ({ message }) =>
                  message?.message?.toLowerCase()?.includes(query)
              )
              ?.map(({ index }) => index)
        )
        ?.reverse();
    } else if (isChat) {
      filteredIndices = groupedMessages
        ?.flatMap(
          (group, groupIndex) =>
            group?.messages
              ?.map((message: any, messageIndex: number) => ({
                message,
                index: { groupIndex, messageIndex },
              }))
              ?.filter(
                ({ message }) => message?.message?.toLowerCase().includes(query)
              )
              ?.map(({ index }) => index)
        )
        ?.reverse();
    } else if (isBoard) {
      filteredIndices = tasksHistory
        ?.flatMap(
          (group: any, groupIndex: any) =>
            group?.tasks
              ?.map((task: any, taskIndex: number) => ({
                task,
                index: { groupIndex, messageIndex: taskIndex },
              }))
              ?.filter(
                ({ task }: { task: any }) =>
                  task?.title?.toLowerCase()?.includes(query)
              )
              ?.map(({ index }: { index: any }) => index)
        )
        ?.reverse();
    }

    console.log('filteredIndices....', filteredIndices);
    filteredIndices?.length > 0
      ? setSearchResults(filteredIndices)
      : setSearchResults([]);
  };

  // Scroll to a specific message in a group
  const scrollToIndex = (groupIndex: number, messageIndex: number) => {
    if (!listRef?.current || !listRef.current.contentEl) {
      console.warn('⚠️ listRef or contentEl is not available.');
      return;
    }

    const contentEl = listRef.current.contentEl;

    if (!contentEl.children.length) {
      console.warn('⚠️ No child elements found in contentEl.');
      return;
    }

    // Validate groupIndex
    if (groupIndex < 0 || groupIndex >= contentEl.children.length) {
      console.warn(`⚠️ Invalid groupIndex: ${groupIndex}`);
      return;
    }

    // Get the group container element
    const groupElement = contentEl.children[groupIndex];

    if (!groupElement || !groupElement.children.length) {
      console.warn(
        `⚠️ groupElement or its children not found for index: ${groupIndex}`
      );
      return;
    }

    // Validate messageIndex
    if (messageIndex < 0 || messageIndex >= groupElement.children.length) {
      console.warn(`⚠️ Invalid messageIndex: ${messageIndex}`);
      return;
    }

    // Get the message element inside the group
    const messageElement = groupElement.children[messageIndex];

    if (messageElement) {
      messageElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      console.warn(`⚠️ messageElement not found at index ${messageIndex}`);
    }
  };

  // Next button
  const handleNext = () => {
    if (currentIndex < searchResults?.length - 1) {
      const { groupIndex, messageIndex } = searchResults[currentIndex + 1];
      scrollToIndex(groupIndex, messageIndex);
      setCurrentIndex(currentIndex + 1);
    }
  };

  // Previous button
  const handlePrevious = () => {
    if (currentIndex > 0) {
      const { groupIndex, messageIndex } = searchResults[currentIndex - 1];
      scrollToIndex(groupIndex, messageIndex);
      setCurrentIndex(currentIndex - 1);
    }
  };

  // Search Text highlight
  const highlightText = (text: string, query: any) => {
    if (!query) {
      return text;
    }
    const regex = new RegExp(`(${query})`, 'gi');
    return text?.replace(regex, '<span class="bg-[#FFB53F]">$1</span>');
  };

  // Function to focus the input field
  const focusChatInput = () => {
    if (chatInputRef.current) {
      chatInputRef.current.focus();
    }
  };
  // search Message functionality end

  // reply message redirect functionality start
  // Helper function to find message position from redirectMessageId
  const findMessagePositionInGroups = (
    groups: any,
    redirectMessage: any
  ): { groupIndex: number; messageIndex: number } | null => {
    if (!Array.isArray(groups) || !redirectMessage?._id) {
      return null;
    }

    for (let groupIndex = 0; groupIndex < groups?.length; groupIndex++) {
      const group: any = groups?.[groupIndex];
      const messages = Array.isArray(group?.messages) ? group?.messages : [];

      for (
        let messageIndex = 0;
        messageIndex < messages?.length;
        messageIndex++
      ) {
        const currentMessage = messages?.[messageIndex];
        if (!currentMessage) {
          continue;
        }

        // Handle image-type messages
        if (
          currentMessage?.message_type === 'image' &&
          redirectMessage?.message_type === 'image'
        ) {
          const images = Array.isArray(currentMessage?.images)
            ? currentMessage?.images
            : [];
          const imageIndex = images?.findIndex(
            (img: any) => img?._id === redirectMessage?._id
          );
          if (imageIndex !== -1) {
            return { groupIndex, messageIndex };
          }
        }
        // Handle other message types
        else if (currentMessage?._id === redirectMessage?._id) {
          return { groupIndex, messageIndex };
        }
      }
    }
    return null;
  };

  // Usage in your effect:
  useEffect(() => {
    if (redirectMessage && redirectMessage._id) {
      // Choose which grouped messages to search based on isGroup flag
      const groupsToSearch = isGroup
        ? groupedMessagesGroupHistory
        : groupedMessages;

      const position = findMessagePositionInGroups(
        groupsToSearch,
        redirectMessage
      );

      if (position !== null) {
        scrollToIndex(position?.groupIndex, position?.messageIndex);
      } else {
        console.warn('Redirect message not found in chat history');
      }
      // Clear the redirect message after redirection
      setRedirectMessage(null);
    }
  }, [redirectMessage]);

  // reply message redirect functionality end

  // Check Valid File Size
  const checkValidFileSize = (fileSize: any) => {
    switch (fileSize?.fSExt) {
      case 'GB':
        if (fileSize?.size <= validImageSize / 1024) return true;
        return false;
      case 'MB':
        if (fileSize?.size <= validImageSize) return true;
        return false;
      case 'KB':
        if (fileSize?.size <= validImageSize * 1024) return true;
        return false;
      case 'Bytes':
        if (fileSize?.size <= validImageSize * 1000000) return true;
        return false;
      default:
        return true;
    }
  };

  // Scroll to the bottom of the chat container whenever messages change
  useEffect(() => {
    console.log('Scroll To Bottom.....');
    // messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (listRef?.current) {
      requestAnimationFrame(() => {
        const scrollElement = listRef.current.getScrollElement();
        scrollElement.scrollTo({
          top: scrollElement.scrollHeight,
          behavior: 'smooth',
        });
      });
    }
  }, [messages?.length, groupMessageHistory?.length, tasksHistory]);

  // Effect for get chat history
  useEffect(() => {
    if (isGroup) {
      // get group chat history
      dispatch(
        getGroupHistory({
          group_id: chatUser?._id,
          workspace_id: defaultWorkSpace?._id,
        })
      );
      // get group details
      dispatch(getGroupById(chatUser?._id));
    } else if (isChat && chatUser?._id) {
      // get one-to-one chat history
      dispatch(
        getSingleUserChat({
          to_user: chatUser?._id,
          workspace_id: defaultWorkSpace?._id,
        })
      );
    } else if (isBoard && chatUser?._id) {
      // Get board tasks history api call
      dispatch(
        getBoardTasksHistory({
          ...payload,
          board_id: chatUser?._id,
        })
      );
    }
  }, [chatUser?._id, defaultWorkSpace?._id, dispatch]);

  useEffect(() => {
    setPreviewUrl(chatUser);
  }, [
    chatUser?._id,
    chatUser?.image_url,
    chatUser?.profile_image,
    chatUser?.group_name,
    chatUser,
  ]);

  // Clear chat message
  useEffect(() => {
    socket.on('CHAT_CLEARED', (response: any) => {
      dispatch(clearMessage());
    });
  }, [defaultWorkSpace?._id]);

  // this socket event is used to clear all of the chats between 2 users
  const _clearUserChat = () => {
    const payload = {
      from_user: signInUserData?.user?.data?.user?._id,
      to_user: chatUser?._id,
    };
    socket.emit('CLEAR_CHAT', payload);
    dispatch(clearMessage());
  };

  // Sent Message
  const handleSubmit = (
    value: any,
    { setSubmitting, resetForm }: { setSubmitting: any; resetForm: any }
  ) => {
    if (files?.length === 0 && value.message === '') {
      return;
    }

    const processedMessage = value?.message?.replace(
      /@(\w+\s\w+)/g,
      (match: any, displayName: any) => {
        const mention = singleGroupDetails?.[0]?.members.find(
          (item: any) => item.display === displayName
        );
        return mention ? `@[user::${mention.id}]` : match;
      }
    );

    if (files && files?.length > 0) {
      const documentFromData = new FormData();
      documentFromData.append(
        'from_user',
        signInUserData?.user?.data?.user?._id
      );
      files?.length > 0 &&
        files?.map((file: any) => {
          documentFromData.append('document', file);
        });

      processedMessage &&
        documentFromData.append('message', processedMessage ?? '');

      if (isGroup) {
        documentFromData.append('group_id', chatUser?._id);
        mentionUser?.length > 0 &&
          documentFromData.append(
            'mentioned_users',
            JSON.stringify(
              mentionUser?.length > 0
                ? Array.from(new Set(mentionUser?.map((item: any) => item?.id)))
                : []
            )
          );
      } else {
        documentFromData.append('to_user', chatUser?._id);
        documentFromData.append(
          'user_type',
          signInUserData?.user?.data?.user?.role?.name
        );
      }
      dispatch(uploadDocumentInUserChat(documentFromData)).then(
        (result: any) => {
          if (uploadDocumentInUserChat.fulfilled.match(result)) {
            if (result?.payload?.success === true) {
              resetForm(); // Reset the form after submission
              // Remove Selected File
              setFiles([]);
              setIsAttachmentPreview(false);
              setIsImagePreview(false);
              setPreviewImages(null);
              setSelectedImagePreviewIndex(0);
              setIsDragAttachment(false);
              setFormValues({ message: '' });
              setSubmitting(false);
              setMentionUser([]);
              // Set file acceptance configuration (for file extensions)
              setFileAccept({
                ...imageAccept,
                ...documentAccept,
              });
            }
          }
        }
      );

      // stop further process.
      return;
    }

    if (editMessage && editMessage?._id) {
      const payload = {
        message_id: editMessage?._id ?? '',
        updated_message: processedMessage ?? '',
        ...(isGroup && {
          mentioned_users:
            mentionUser?.length > 0
              ? Array.from(new Set(mentionUser?.map((item: any) => item?.id)))
              : [],
        }),
      };
      dispatch(editMessageChat(payload)).then((result: any) => {
        if (editMessageChat.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            resetForm(); // Reset the form after submission
            setEditMessage(null); // Reset Edit message
            setFormValues({ message: '' });
            setSubmitting(false);
            setMentionUser([]);
          }
        }
      });
      // stop further process.
      return;
    }

    const messagePayload = createPayload({ message: processedMessage });

    if (isGroup) {
      socket.emit('GROUP_SEND_MESSAGE', messagePayload);
      socket.emit('CONFIRMATION', { event: 'GROUP_SEND_MESSAGE' });
    } else {
      socket.emit('SEND_MESSAGE', messagePayload);
      socket.emit('CONFIRMATION', { event: 'SEND_MESSAGE' });
    }
    resetForm(); // Reset the form after submission
    setReplyMessage(null); // Reset reply message
    setFormValues({ message: '' });
    setSubmitting(false);
    setMentionUser([]);
  };

  // Create paylaod
  const createPayload = (value: any) => {
    if (isGroup) {
      return {
        from_user: signInUserData?.user?.data?.user?._id,
        message: value?.message,
        group_id: chatUser?._id,
        workspace_id: defaultWorkSpace?._id,
        mentioned_users:
          mentionUser?.length > 0
            ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
            : [],
        ...(replyMessage?._id && { reply_message: replyMessage?._id ?? '' }),
      };
    } else {
      return {
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: chatUser?._id,
        message: value?.message,
        workspace_id: defaultWorkSpace?._id,
        ...(replyMessage?._id && { reply_message: replyMessage?._id ?? '' }),
      };
    }
  };

  // Remove login user from the mention list
  const removeLoginUser = (mentionUserList: any) => {
    if (mentionUserList?.length === 0) {
      return mentionUserList;
    }
    return mentionUserList?.filter(
      (user: any) => user?._id !== signInUserData?.user?.data?.user?._id
    );
  };

  // keydown event
  const handleKeyDownEvent = (event: any, formik: any) => {
    if (isReset) {
      formik.resetForm();
    }
    setIsReset(false);

    // Check if the suggestions list is open
    const suggestionsOpen = document.querySelector(
      '.react-mentions__suggestions__item--focused'
    );

    // Allow default behavior for arrow keys when suggestions list is open
    if (
      suggestionsOpen &&
      (event.key === 'ArrowUp' || event.key === 'ArrowDown')
    ) {
      return;
    }

    // Check if the space key is pressed and it's the first character
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      formik.handleSubmit();
    }
  };

  // Funaction for handle image upload
  const handleImageChange = (event: any) => {
    // setImageBuffer(null);
    const file = event.target.files[0];
    const extension = file?.name?.split('.')?.pop()?.toLowerCase();

    if (!imageFileType.includes(extension)) {
      toast.error(`${extension} not support in images`);
      return;
    }

    if (file) {
      // Check file size
      const fileSize = getFileSize(file);
      if (checkValidFileSize(fileSize)) {
        // Comment because Now file transfer using API call

        // const buffer = await readFileAsBuffer(file);
        // setImageBuffer(buffer);
        if (isGroup) {
          // Comment because Now file transfer using API call

          // const imagePayload = {
          //   from_user: signInUserData?.user?.data?.user?._id,
          //   group_id: chatUser?._id,
          //   buffer: buffer,
          //   ext: extension,
          // };
          // socket.emit('GROUP_IMAGES', imagePayload);
          // socket.emit('CONFIRMATION', { event: 'GROUP_IMAGES' });

          const imageFromData = new FormData();
          imageFromData.append(
            'from_user',
            signInUserData?.user?.data?.user?._id
          );
          imageFromData.append('group_id', chatUser?._id);
          imageFromData.append('image', file);
          dispatch(uploadImageInGroupChat(imageFromData));
          // messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

          const current = imageInputRef?.current;
          if (current) {
            current.value = '';
            current.type = 'text';
            current.type = 'file';
          }
        } else {
          // const imagePayload = {
          //   from_user: signInUserData?.user?.data?.user?._id,
          //   to_user: chatUser?._id,
          //   buffer: buffer,
          //   user_type: signInUserData?.user?.data?.user?.role?.name,
          //   ext: extension,
          // };
          // socket.emit('IMAGES', imagePayload);
          // socket.emit('CONFIRMATION', { event: 'IMAGES' });

          const imageFromData = new FormData();
          imageFromData.append(
            'from_user',
            signInUserData?.user?.data?.user?._id
          );
          imageFromData.append('to_user', chatUser?._id);
          imageFromData.append('image', file);

          dispatch(uploadImageInUserChat(imageFromData));
          // messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

          const current = imageInputRef?.current;
          if (current) {
            current.value = '';
            current.type = 'text';
            current.type = 'file';
          }
        }
      } else {
        toast.error(`Image is should be less than ${validImageSize}MB`);
        return;
      }
    }
  };

  // Funaction for handle document upload
  const handleDocumentChange = (event: any) => {
    // setDocumentBuffer(null);
    const file = event.target.files[0];
    const extension = file?.name?.split('.')?.pop()?.toLowerCase();
    if (!documentFileType.includes(extension)) {
      toast.error(`${extension} not support in document`);
      return;
    }

    if (file) {
      const fileSize = getFileSize(file);
      if (checkValidFileSize(fileSize)) {
        // Comment because Now file transfer using API call
        // const buffer = await readFileAsBuffer(file);
        // setDocumentBuffer(buffer);

        if (isGroup) {
          // Comment because Now file transfer using API call

          // const documentPayload = {
          //   from_user: signInUserData?.user?.data?.user?._id,
          //   group_id: chatUser?._id,
          //   buffer: buffer,
          //   ext: extension,
          // };

          // socket.emit('GROUP_DOCUMENTS', documentPayload);
          // socket.emit('CONFIRMATION', { event: 'GROUP_DOCUMENTS' });

          const documentFromData = new FormData();
          documentFromData.append(
            'from_user',
            signInUserData?.user?.data?.user?._id
          );
          documentFromData.append('group_id', chatUser?._id);
          documentFromData.append('document', file);
          dispatch(uploadDocumentInGroup(documentFromData));
          // messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

          // Remove Selected File
          const current = documentInputRef?.current;
          if (current) {
            current.value = '';
            current.type = 'text';
            current.type = 'file';
          }
        } else {
          // Comment because Now file transfer using API call

          // const documentPayload = {
          //   from_user: signInUserData?.user?.data?.user?._id,
          //   to_user: chatUser?._id,
          //   buffer: buffer,
          //   user_type: signInUserData?.user?.data?.user?.role?.name,
          //   ext: extension,
          // };

          // socket.emit('DOCUMENTS', documentPayload);
          // socket.emit('CONFIRMATION', { event: 'DOCUMENTS' });

          const documentFromData = new FormData();
          documentFromData.append(
            'from_user',
            signInUserData?.user?.data?.user?._id
          );
          documentFromData.append('to_user', chatUser?._id);
          documentFromData.append(
            'user_type',
            signInUserData?.user?.data?.user?.role?.name
          );
          documentFromData.append('document', file);
          dispatch(uploadDocumentInUserChat(documentFromData));
          // messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

          // Remove Selected File
          const current = documentInputRef?.current;
          if (current) {
            current.value = '';
            current.type = 'text';
            current.type = 'file';
          }
        }
      } else {
        toast.error(
          `Document is should be less than ${validDocumentFileSize}MB`
        );
        return;
      }
    }
  };

  // Scroll up load more message
  const handleScroll = (event: any) => {
    const { scrollTop } = event.target;

    if (scrollTop <= 0 && messages?.length > 0) {
      setSkip(skip + 1);
    }
  };

  const getAvatarName = (data: any) => {
    let displayName = '';
    if (isGroup) {
      if (data?.group_name) {
        displayName += capitalizeFirstLetter(data?.group_name);
      }
    } else if (isChat) {
      if (data?.first_name) {
        displayName += capitalizeFirstLetter(data?.first_name);
      }
      if (data?.last_name) {
        displayName += ' ' + capitalizeFirstLetter(data?.last_name);
      }
    } else if (isBoard) {
      if (data?.project_name) {
        displayName += capitalizeFirstLetter(data?.project_name);
      }
    }
    return displayName;
  };

  const getAvatarImage = (data: any) => {
    let avatarURL;
    if (isGroup) {
      if (
        data?.image_url &&
        data?.image_url !== 'null' &&
        data?.image_url !== null
      ) {
        avatarURL =
          process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.image_url;
      }
    } else if (isChat) {
      if (
        data?.profile_image &&
        data?.profile_image !== 'null' &&
        data?.profile_image !== null
      ) {
        avatarURL =
          process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.profile_image;
      }
    } else if (isBoard) {
      if (
        data?.board_image &&
        data?.board_image !== 'null' &&
        data?.board_image !== null
      ) {
        console.log('Board image set.....');
        avatarURL = process.env.NEXT_PUBLIC_IMAGE_URL + '/' + data?.board_image;
      }
    }
    return avatarURL;
  };

  // Open Chat Group Details Model
  const openGroupModel = (groupDetail: any) => {
    console.log(signInUserData, 'signInUserData');
    dispatch(getGroupById(groupDetail?._id)).then((result: any) => {
      if (getGroupById.fulfilled.match(result)) {
        if (
          result &&
          result.payload.success === true &&
          result.payload?.data?.length > 0
        ) {
          const canUpdate =
            ['agency', 'client'].includes(signInUserData?.role) ||
            (['team_agency', 'team_client'].includes(signInUserData?.role) &&
              checkPermission(
                'chats',
                'group',
                'update',
                signInUserData?.permission
              )) ||
            result.payload?.data?.[0]?.created_by ===
              signInUserData?.user?.data?.user?._id;

          openModal({
            view: (
              <CreateGroupForm
                title={canUpdate ? 'Edit Group' : 'Group Details'}
                groupDetail={groupDetail}
                canUpdate={canUpdate}
                isEdit={true}
                signInUserData={signInUserData}
              />
            ),
            customSize: '600px',
          });
        }
      }
    });
  };

  const openAudioModel = () => {
    let reqPayload;

    if (isGroup) {
      reqPayload = {
        from_user: signInUserData?.user?.data?.user?._id,
        group_id: chatUser?._id,
      };
    } else {
      reqPayload = {
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: chatUser?._id,
        user_type: signInUserData?.user?.data?.user?.role?.name,
      };
    }

    openModal({
      view: <VoiceRecorder reqPayload={reqPayload} />,
    });
  };

  const onEmojiClick = async (emoji: any, formik: any) => {
    setFormValues({ message: formik?.values?.message + emoji?.emoji });
    await formik.setFieldValue(
      'message',
      formik?.values?.message + emoji?.emoji
    );
  };

  function fetchUsers(query: any, callback: any) {
    return callback;
  }

  const findAllURLs = (str: any) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g; // Regular expression to match URLs starting with http or https
    const matches = str.match(urlRegex); // Find all matches

    return matches ? matches : []; // Return the array of URLs or an empty array if no URLs are found
  };

  const checkMicrophonePermission = async () => {
    try {
      const permissionStatus = await navigator.permissions.query({
        name: 'microphone' as PermissionName,
      });
      permissionStatus.onchange = () => {
        if (permissionStatus.state) {
          setAudionButtonDisabled(permissionStatus.state === 'denied');
        }
        return permissionStatus.state;
      };
      setAudionButtonDisabled(permissionStatus.state === 'denied');
      return permissionStatus.state;
    } catch (error) {
      console.error('Error checking microphone permission:', error);
    }
  };

  const onAudioReady = (blob: any) => {
    console.log(blob, 'blob');
    let payload;

    if (isGroup) {
      payload = {
        from_user: signInUserData?.user?.data?.user?._id,
        group_id: chatUser?._id,
        audio_blob_data: blob,
      };
    } else {
      payload = {
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: chatUser?._id,
        user_type: signInUserData?.user?.data?.user?.role?.name,
        audio_blob_data: blob,
      };
    }

    const formData = new FormData();
    for (let i = 0; i < Object.keys(payload).length; i++) {
      formData.append(
        Object.keys(payload)[i],
        Object.values(payload)[i] as any
      );
    }

    dispatch(uploadAudioInUserChat(formData));
  };

  const handleAudioRecording = async () => {
    const hasPermission = await requestMicrophone();

    if (hasPermission) {
      setIsRecording(true);
    } else {
      setAudionButtonDisabled(true);
    }
  };

  // Chats & Groups attachment upload logic start

  // set image or document preview
  useEffect(() => {
    console.log('set files preview useEffect called......');
    if (files?.length > 0) {
      setIsAttachmentPreview(true);
      setPreviewImages(null);
      setIsImagePreview(false);
      setSelectedImagePreviewIndex(0);
    } else {
      setIsAttachmentPreview(false);
      setPreviewImages(null);
      setIsImagePreview(false);
      setSelectedImagePreviewIndex(0);
    }
  }, [files]);

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    console.log('acceptedFiles....', acceptedFiles);

    // Get current files count (using optional chaining in case files is undefined)
    const currentFilesCount = files?.length || 0;
    if (currentFilesCount + acceptedFiles?.length > 10) {
      toast.error('Maximum 10 files allowed');
      return;
    }

    // Calculate total size (in bytes) of current files and new files
    const currentTotalSize =
      files?.reduce((acc: number, file: any) => acc + file?.size, 0) || 0;
    const newFilesTotalSize = acceptedFiles?.reduce(
      (acc: number, file: any) => acc + file?.size,
      0
    );
    const combinedTotalSize = currentTotalSize + newFilesTotalSize;
    const MAX_TOTAL_SIZE_BYTES = 200 * 1024 * 1024; // 200 MB in bytes

    if (combinedTotalSize > MAX_TOTAL_SIZE_BYTES) {
      toast.error('Total file size should not exceed 200 MB');
      return;
    }

    // If both conditions pass, add each accepted file to the state
    acceptedFiles?.forEach((file: any) => {
      if (file?.type?.startsWith('image/')) {
        // Create a preview for image files
        const newFile = Object.assign(file, {
          preview: URL.createObjectURL(file),
        });
        setFiles((prev: any) => [...prev, newFile]);
      } else {
        setFiles((prev: any) => [...prev, file]);
      }
    });

    // reset all the value when file upload
    setEditMessage(null);
    setReplyMessage(null);
    setIsRecording(false);

    // Set file acceptance configuration (for file extensions)
    setFileAccept({
      ...imageAccept,
      ...documentAccept,
    });
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: isDragAttachment
      ? { ...imageAccept, ...documentAccept }
      : fileAccept,
    // maxSize: 200 * 1024 * 1024, // Maximum file size of 200MB
    // maxFiles: 10, // max 10 files
    multiple: true,
    noClick: true,
    disabled: isBoard ?? false,
  };

  // useDropzone hook to handle file selection and drop

  const { getRootProps, getInputProps, open, isDragActive } =
    useDropzone(dropzoneOptions);
  console.log('isDragActive......', isDragActive);

  useEffect(() => {
    setIsDragAttachment(isDragActive);
  }, [isDragActive]);

  // Chats & Groups attachment upload logic end

  // If user is not selected
  if (!chatUser?._id) {
    return (
      <div
        className={cn(
          'chat_background_image min-h-[calc(100vh - 222px)] relative flex h-full items-center justify-center overflow-x-hidden bg-white pt-6 lg:px-4 lg:py-7  xl:px-5 xl:py-5 2xl:pb-7 2xl:pt-6',
          className
        )}
      >
        <div className="flex flex-col items-center gap-[19px]">
          <Image
            src={noConversationSelected}
            alt="No Conversations Selected"
            width={374}
            height={280}
          />
          <Text className="text-[24px] font-bold leading-[22px] text-black">
            Let’s get the conversation rolling! 🚀
          </Text>
          <Text className="text-sm font-medium leading-[21px] text-[#4B5563]">
            Select a chat from your inbox to start messaging and stay connected!
            💬
          </Text>
          {/* <Empty
            text={`No ${!isBoard ? 'Conversations' : 'Board'} Selected`}
            textClassName="mt-4 text-base text-gray-500"
          /> */}
        </div>
      </div>
    );
  }

  return (
    <div className={cn('bg-white ', className)}>
      <div className="flex flex-col items-start justify-start lg:flex-row">
        {!showProfileDetails && (
          <div
            className={`flex h-full w-full flex-col  ${
              showProfile ? 'lg:w-[70%]' : 'lg:w-[100%]'
            }`}
          >
            {/* Header to show profile, name, search and group setting */}
            <header
              className={cn(
                'relative flex h-[121px] flex-col justify-between gap-4 border-b border-[#E5E7EB] lg:h-[64px]'
              )}
            >
              {/* mobile back and profile view butons */}
              <div className="block px-4 py-2 lg:hidden">
                <div className="flex flex-row items-center justify-between">
                  <Button
                    onClick={() => setChatUser(undefined)}
                    className="flex w-auto items-center justify-start bg-transparent px-0 text-[14px] font-semibold text-[#8C80D2] lg:w-[200px]  "
                    type="button"
                    size="sm"
                  >
                    <GoChevronLeft className="h-[20px] w-[20px] " />
                    <span className=""> Back</span>
                  </Button>
                  <Button
                    onClick={() => setShowProfileDetails(true)}
                    className="flex w-auto items-center justify-center rounded-2xl border-2 border-[#8C80D2] bg-transparent px-4 py-2 text-[14px] font-semibold text-[#8C80D2] "
                    type="button"
                    size="sm"
                  >
                    <GoFileMedia className="me-4 h-[20px] w-[20px]" />
                    <span className=""> Documents</span>
                  </Button>
                </div>
              </div>

              {/* Large screen profile menu */}
              <div className="relative px-4 py-2 lg:px-6 lg:py-3">
                <div className="flex w-full flex-row items-center justify-between gap-2">
                  <div
                    role="button"
                    onClick={() => {
                      if (!isBoard) {
                        setShowProfile((prev) => !prev);
                      }
                    }}
                    className={cn(
                      'mb-0 flex w-auto flex-row items-center justify-start gap-4 lg:justify-normal',
                      isBoard && 'cursor-default'
                    )}
                  >
                    <div className="relative">
                      <Avatar
                        name={getAvatarName(chatUser)}
                        src={getAvatarImage(chatUser)}
                        className="text-white"
                      />
                      {/* <div className="lg:translate-x-1/9 lg:-translate-y-1/4.5 absolute right-0 top-0 -translate-y-1/3 translate-x-1/4 transform">
                        {!isGroup && (
                          <Badge
                            renderAsDot
                            className={`ml-3 h-3 w-3 ${
                              chatUser?.is_online
                                ? 'bg-green-600'
                                : 'bg-red-600'
                            }`}
                          />
                        )}
                      </div> */}
                    </div>
                    <div className="flex items-center justify-start gap-2">
                      <Text className="break-all text-[16px] font-semibold text-[#222222]">
                        {isGroup && capitalizeFirstLetter(chatUser?.group_name)}
                        {isChat &&
                          `${capitalizeFirstLetter(
                            chatUser?.first_name
                          )} ${capitalizeFirstLetter(chatUser?.last_name)}`}
                        {isBoard &&
                          capitalizeFirstLetter(chatUser?.project_name)}
                      </Text>
                      {isBoard && chatUser?.members > 0 && (
                        <Text className="break-all border-s border-[#222222] ps-2 text-[16px] font-medium text-[#222222]">
                          {isBoard ? chatUser?.members : ''}{' '}
                          {`Member${chatUser?.members > 1 ? 's' : ''}`}
                        </Text>
                      )}
                    </div>
                  </div>

                  <div className="relative mb-0 flex items-center justify-center lg:justify-end">
                    <div className="">
                      {!chatSlice?.showSearchFilter && (
                        <LuSearch
                          className="h-5 w-5 cursor-pointer text-[#4B5563]"
                          onClick={() => dispatch(setShowSearchFilter(true))}
                        />
                      )}
                    </div>
                  </div>
                  {/* profile edge button for large screens*/}
                  {!isBoard && (
                    <div
                      role="button"
                      className="edge-button absolute -right-4 top-11 z-50 hidden cursor-pointer lg:block"
                      onClick={() => {
                        setShowProfile((prev) => !prev);
                        dispatch(setShowSearchFilter(false));
                      }}
                    >
                      <div className="flex h-8 w-8 items-center justify-center rounded-full border-[1.33px] border-[#D1D5DB] bg-[#E5E7EB] shadow-lg">
                        {!showProfile && (
                          <IoIosArrowBack className="text-xl text-[#111928]" />
                        )}
                        {showProfile && (
                          <IoIosArrowForward className="text-xl text-[#111928]" />
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Search with nevigation */}
              {chatSlice?.showSearchFilter && (
                <div className="absolute -bottom-[51px] left-0 z-40 flex h-[50px] w-full items-center justify-between gap-3 bg-white px-3 py-1">
                  {/* Input for search */}
                  <Input
                    type="search"
                    placeholder="Search here"
                    className="w-full rounded-[6px]"
                    value={searchQuery}
                    onClear={onSearchClear}
                    onChange={onSearchChange}
                    onKeyDown={handleKeyDown}
                    inputClassName="h-10 text-black"
                    clearable={true}
                    prefix={<PiMagnifyingGlassBold className="h-4 w-4" />}
                  />
                  {/* search results navigation */}
                  {searchQuery !== '' && searchResults?.length > 0 && (
                    <div className="item-center flex gap-1">
                      {/* Show Previous button only if there is a previous search result */}
                      {currentIndex > 0 && searchResults?.length > 1 && (
                        <button
                          className="flex h-6 w-6 items-center justify-center rounded-[2px] bg-[#F3F4F6]"
                          onClick={handlePrevious}
                        >
                          <IoIosArrowDown className="h-4 w-4 cursor-pointer text-black" />
                        </button>
                      )}

                      {/* Show Next button only if there are more results to navigate */}
                      {currentIndex < searchResults?.length - 1 && (
                        <button
                          className="flex h-6 w-6 items-center justify-center rounded-sm bg-[#F3F4F6]"
                          onClick={handleNext}
                        >
                          <IoIosArrowUp className="h-4 w-4 cursor-pointer text-black" />
                        </button>
                      )}
                    </div>
                  )}
                  {/* Search Done button */}
                  <button
                    className="flex h-[30px] items-center justify-center rounded bg-[#E0E7FF] px-3 py-[10px] text-sm text-[#3730A3]"
                    onClick={onSearchClear}
                  >
                    Done
                  </button>
                </div>
              )}
            </header>

            {/* Message List */}
            {/* If needed add in below div [&_.simplebar-content]:grid [&_.simplebar-content]:gap-0  */}
            <div
              {...getRootProps()}
              className={cn(
                'chat_background_image relative min-h-[15rem] flex-grow border-b py-[14px] [&_.simplebar-content]:py-5',
                isAttachmentPreview || isImagePreview
                  ? 'border-[#FCFDFF]'
                  : 'border-[#E5E7EB]'
              )}
            >
              {/* Drag & drop overlay */}
              {isDragActive && (
                <div className="absolute inset-0 z-[45] flex flex-col items-center justify-center border-2 border-dashed border-blue-400 bg-blue-100 bg-opacity-80">
                  <p className="text-lg font-semibold text-blue-600">
                    Drop your files here...
                  </p>
                </div>
              )}

              {/* Attachments preview show */}
              <Transition
                show={isAttachmentPreview || isImagePreview}
                enter="transition ease-out duration-300 transform"
                enterFrom="translate-y-full opacity-0"
                enterTo="translate-y-0 opacity-100"
                leave="transition ease-in duration-300 transform"
                leaveFrom="translate-y-0 opacity-100"
                leaveTo="translate-y-full opacity-0"
                className="absolute left-0 top-0 z-40 flex h-full w-full flex-col gap-5 bg-[#DDDDDD] px-6 pt-6"
              >
                {/* Attachments preview when upload images or documents */}
                {isAttachmentPreview && (
                  <>
                    <div className="flex w-full items-center justify-end">
                      <Button
                        type="button"
                        title="Close"
                        onClick={() => {
                          setFileAccept({
                            ...imageAccept,
                            ...documentAccept,
                          });
                          // empty images & files when close the attachment preview
                          setFiles([]);
                        }}
                        className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#686868] !p-0"
                      >
                        <PiXBold className="h-4 w-4 text-white" />
                      </Button>
                    </div>
                    <AttachmentsPreview
                      files={files ?? []}
                      setFiles={setFiles}
                    />
                  </>
                )}
                {/* Images preview when click to view images preview only */}
                {isImagePreview && (
                  <ImagesPreview
                    previewImages={previewImages}
                    setPreviewImages={setPreviewImages}
                    selectedUser={chatUser}
                    selectedIndex={selectedImagePreviewIndex}
                    setSelectedIndex={setSelectedImagePreviewIndex}
                    setIsImagePreview={setIsImagePreview}
                    setSelectedImagePreviewIndex={setSelectedImagePreviewIndex}
                    setReplyMessage={setReplyMessage}
                    focusChatInput={focusChatInput}
                  />
                )}
              </Transition>

              {/* Message History show */}
              <SimpleBar
                ref={listRef}
                onScrollCapture={handleScroll}
                className={cn(
                  '',
                  !isBoard
                    ? 'h-[calc(100dvh-470px)] lg:h-[calc(100vh-245px)]'
                    : 'h-[calc(100dvh-350px)] lg:h-[calc(100vh-160px)]'
                )}
                // className={`${
                //   showProfile
                //     ? 'outer_profile_scroll_with_profile'
                //     : 'inner_chat_scroll'
                // }`}
              >
                {((isLoading && isChat) ||
                  (groupMessageLoading && isGroup) ||
                  (getBoardTasksHistoryLoader && isBoard)) && (
                  <div
                    className={cn(
                      '!grid flex-grow place-content-center items-center justify-center',
                      !isBoard
                        ? 'h-[calc(100dvh-470px)] lg:h-[calc(100vh-245px)]'
                        : 'h-[calc(100dvh-350px)] lg:h-[calc(100vh-160px)]',
                      className
                    )}
                  >
                    <Spinner size="xl" />
                  </div>
                )}

                {/* Single chat user message history  */}
                {!isLoading &&
                  isChat &&
                  messages?.length > 0 &&
                  groupedMessages?.length > 0 &&
                  groupedMessages?.map((group: any) => {
                    return (
                      <div key={group?.date}>
                        {/* Render the date */}
                        <div className="mb-[10px] flex w-full items-center justify-center">
                          <Text className="rounded-md bg-white p-2 text-xs font-bold text-[#707070]">
                            {group?.date}
                          </Text>
                        </div>

                        {/* Render the messages for this date */}
                        {group?.messages?.length > 0 &&
                          group?.messages?.map((message: any) => (
                            <div key={message?._id}>
                              <MessageBody
                                searchQuery={searchQuery}
                                highlightText={highlightText}
                                message={message}
                                selectedUser={chatUser}
                                signInUserData={signInUserData}
                                replyMessage={replyMessage}
                                setReplyMessage={setReplyMessage}
                                setRedirectMessage={setRedirectMessage}
                                setEditMessage={setEditMessage}
                                focusChatInput={focusChatInput}
                                setIsImagePreview={setIsImagePreview}
                                setPreviewImages={setPreviewImages}
                                setSelectedImagePreviewIndex={
                                  setSelectedImagePreviewIndex
                                }
                              />

                              {message?.message_type === 'message' &&
                                findAllURLs(message?.message)?.length > 0 &&
                                findAllURLs(message?.message)?.map(
                                  (url: any, index: number) => (
                                    <MetaComponent
                                      key={`${message?._id}-${index}`}
                                      URL={url}
                                      message={message}
                                      selectedUser={chatUser}
                                      signInUserData={signInUserData}
                                    />
                                  )
                                )}
                            </div>
                          ))}
                      </div>
                    );
                  })}

                {/* Group chat history */}
                {!groupMessageLoading &&
                  isGroup &&
                  groupMessageHistory?.length > 0 &&
                  groupedMessagesGroupHistory?.length > 0 &&
                  groupedMessagesGroupHistory?.map((group: any) => {
                    return (
                      <div key={group?.date}>
                        {/* Render the date */}
                        <div className="mb-[10px] flex w-full items-center justify-center">
                          <Text className="rounded-md bg-white p-2 text-xs font-bold text-[#707070]">
                            {group?.date}
                          </Text>
                        </div>

                        {/* Render the messages for this date */}
                        {group?.messages?.length > 0 &&
                          group?.messages?.map((message: any) => (
                            <div key={message?._id}>
                              <MessageBody
                                searchQuery={searchQuery}
                                highlightText={highlightText}
                                message={message}
                                selectedUser={chatUser}
                                signInUserData={signInUserData}
                                replyMessage={replyMessage}
                                setReplyMessage={setReplyMessage}
                                setRedirectMessage={setRedirectMessage}
                                setEditMessage={setEditMessage}
                                focusChatInput={focusChatInput}
                                setIsImagePreview={setIsImagePreview}
                                setPreviewImages={setPreviewImages}
                                setSelectedImagePreviewIndex={
                                  setSelectedImagePreviewIndex
                                }
                              />

                              {message?.message_type === 'message' &&
                                findAllURLs(message?.message)?.length > 0 &&
                                findAllURLs(message?.message)?.map(
                                  (url: any, index: number) => (
                                    <MetaComponent
                                      key={`${message?._id}-${index}`}
                                      URL={url}
                                      message={message}
                                      selectedUser={chatUser}
                                      signInUserData={signInUserData}
                                    />
                                  )
                                )}
                            </div>
                          ))}
                      </div>
                    );
                  })}

                {/* Board tasks history */}
                {!getBoardTasksHistoryLoader &&
                  isBoard &&
                  tasksHistory?.length > 0 &&
                  tasksHistory
                    ?.slice()
                    ?.reverse()
                    ?.map((group: any) => {
                      return (
                        <div key={group?._id}>
                          {/* Render the date */}
                          <div className="my-5 flex w-full items-center justify-center">
                            <Text className="rounded-md bg-white p-2 text-xs font-bold text-[#707070]">
                              {formatDate(group?._id ?? '')}
                            </Text>
                          </div>

                          {/* Render the tasks for this date */}
                          <div className="w-full">
                            {group?.tasks?.length > 0 &&
                              group?.tasks?.map((task: any) => (
                                <div
                                  key={task?._id}
                                  className="mx-6 mb-[10px] flex items-center justify-start"
                                >
                                  <TaskBody
                                    searchQuery={searchQuery}
                                    highlightText={highlightText}
                                    task={task}
                                    date={group?._id}
                                    selectedUser={chatUser}
                                    signInUserData={signInUserData}
                                    setOpenTaskId={setOpenTaskId}
                                    openTaskId={openTaskId}
                                  />
                                </div>
                              ))}
                          </div>
                        </div>
                      );
                    })}

                {/* Single Chat Image Upload Spinner */}
                {isChat && chatSlice?.imageChatLoader && (
                  <div className="mb-4 mr-10 text-black xl:mr-16" dir="rtl">
                    <Spinner size="sm" /> Image Uploading
                  </div>
                )}

                {/* Single Chat Document Upload Spinner */}
                {isChat && chatSlice?.documentChatLoader && (
                  <div className="mb-4 mr-10 text-black xl:mr-16" dir="rtl">
                    <div>
                      <Spinner size="sm" /> Document Uploading
                    </div>
                  </div>
                )}
                {/* Group Chat Image Upload Spinner */}
                {isGroup && groupSlice?.imageGroupChatLoader && (
                  <div className="mb-4 mr-10 text-black xl:mr-16" dir="rtl">
                    <Spinner size="sm" /> Image Uploading
                  </div>
                )}
                {/* Group Chat Document Upload Spinner */}
                {isGroup && groupSlice?.documentChatLoader && (
                  <div className="mb-4 mr-10 text-black xl:mr-16" dir="rtl">
                    <Spinner size="sm" /> Document Uploading
                  </div>
                )}

                {/* <div ref={messagesEndRef} /> */}

                {((!isGroup && !isLoading && messages?.length === 0) ||
                  (isGroup &&
                    !groupMessageLoading &&
                    groupMessageHistory?.length === 0)) && (
                  <div
                    className={cn(
                      '!grid h-full min-h-[128px] flex-grow place-content-center items-center justify-center',
                      className
                    )}
                  >
                    {/* <Empty
                        text="No conversations"
                        textClassName="mt-4 text-base text-gray-500"
                      /> */}
                  </div>
                )}
              </SimpleBar>

              {/* Attachments upload reference */}
              <input {...getInputProps()} style={{ display: 'none' }} />
            </div>

            {/* Message Input */}
            {!isBoard && (
              <div ref={ref} className="relative">
                {(replyMessage || editMessage) && (
                  <div className="absolute -top-[60px] left-0 min-h-[56px] w-full rounded-[4px] border border-[#D1D5DB] bg-white p-1">
                    <div className="flex h-full w-full items-start justify-between gap-1 border-l-2 border-[#6875F5] bg-[#F5F5F5] px-3 py-2">
                      <div
                        className={cn(
                          'flex flex-col gap-[2px]',
                          replyMessage?.message_type === 'message' ||
                            editMessage?.message_type === 'message'
                            ? 'w-[99%]'
                            : 'w-full'
                        )}
                      >
                        {replyMessage ? (
                          <div className="text-xs font-bold text-[#6875F5]">
                            {replyMessage?.from_user ===
                              signInUserData?.user?.data?.user?._id && 'You'}
                            {isChat &&
                              replyMessage?.from_user !==
                                signInUserData?.user?.data?.user?._id &&
                              `${capitalizeFirstLetter(
                                chatUser?.first_name
                              )} ${capitalizeFirstLetter(chatUser?.last_name)}`}
                            {isGroup &&
                              replyMessage?.from_user !==
                                signInUserData?.user?.data?.user?._id &&
                              `${capitalizeFirstLetter(
                                replyMessage?.user_detail?.first_name
                              )} ${capitalizeFirstLetter(
                                replyMessage?.user_detail?.last_name
                              )}`}
                          </div>
                        ) : (
                          <div className="text-xs font-bold text-[#6875F5]">
                            Editing
                          </div>
                        )}
                        {((replyMessage?.message_type === 'message' &&
                          replyMessage?.message) ||
                          (editMessage?.message_type === 'message' &&
                            editMessage?.message)) && (
                          <div className="flex w-full items-center justify-start">
                            <p
                              className="w-[calc(100%-6px)] truncate text-[10px] font-medium leading-[14px] text-black"
                              dangerouslySetInnerHTML={{
                                __html: isGroup
                                  ? updateMessageFormatWithMentionUser(
                                      replyMessage
                                        ? replyMessage?.message ?? ''
                                        : editMessage?.message ?? '',
                                      mentioned_users,
                                      true,
                                      false,
                                      'text-[#4A40FF]'
                                    )
                                  : replyMessage
                                    ? replyMessage?.message ?? ''
                                    : editMessage?.message ?? '',
                              }}
                            ></p>
                          </div>
                        )}
                        {replyMessage?.message_type === 'image' && (
                          <div className="flex w-full items-center justify-start">
                            <p className="w-[calc(100%-6px)] truncate text-[10px] font-medium leading-[14px] text-black">
                              Image
                            </p>
                          </div>
                        )}
                        {replyMessage?.message_type === 'document' && (
                          <div className="flex w-full items-center justify-start">
                            <p className="w-[calc(100%-6px)] truncate text-[10px] font-medium leading-[14px] text-black">
                              Document
                            </p>
                          </div>
                        )}
                        {replyMessage?.message_type === 'audio' && (
                          <div className="flex w-full items-center justify-start">
                            <p className="w-[calc(100%-6px)] truncate text-[10px] font-medium leading-[14px] text-black">
                              Audio
                            </p>
                          </div>
                        )}
                      </div>
                      <div
                        className={cn(
                          'flex items-start justify-end gap-2',
                          replyMessage?.message_type === 'message' ||
                            editMessage?.message_type === 'message'
                            ? 'w-[1%]'
                            : 'w-full'
                        )}
                      >
                        {replyMessage?.message_type === 'image' && (
                          <div className="flex !h-10 !w-10 items-center justify-center">
                            <Image
                              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${replyMessage?.image_url}`}
                              alt={replyMessage?.image_url}
                              className="rounded-[3px] border border-[#D1D5DB] object-cover"
                              width={40}
                              height={40}
                            />
                          </div>
                        )}
                        {replyMessage?.message_type === 'document' && (
                          <div className="flex h-10 items-center justify-center">
                            <FileIcons
                              key={replyMessage?._id}
                              fileType={getFileType(replyMessage?.document_url)}
                              fileName={replyMessage?.original_file_name}
                              className={cn('!flex-row !bg-[#F5F5F5] !p-[6px]')}
                              fileNameClass="!w-[125px]"
                            />
                          </div>
                        )}
                        {replyMessage?.message_type === 'audio' && (
                          <div className="flex h-10 items-center justify-center">
                            {/* <audio
                              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${replyMessage?.audio_url}`}
                              controls
                            /> */}
                            <AudioTag
                              audioUrl={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${replyMessage?.audio_url}`}
                            />
                          </div>
                        )}
                        {replyMessage && (
                          <button
                            className="h-3 w-3"
                            onClick={() => setReplyMessage(null)}
                          >
                            <PiXBold className="h-3 w-3 text-black hover:text-[#6875F5]" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                <Formik
                  initialValues={formValues}
                  validationSchema={chatFormSchema}
                  onSubmit={handleSubmit}
                  enableReinitialize
                >
                  {(formik) => (
                    <Form>
                      <div
                        className={cn(
                          'flex min-h-[80px] flex-col items-center justify-between px-5 py-[14px] lg:flex-row lg:gap-2',
                          isAttachmentPreview || isImagePreview
                            ? 'bg-[#FCFDFF]'
                            : 'bg-white'
                        )}
                      >
                        {!isImagePreview ? (
                          <>
                            {/* message type */}
                            {/* {
                          isRecording &&
                          <AudioRecorder isRecording={isRecording} setIsRecording={setIsRecording} onAudioReady={onAudioReady} onCancel={() => setIsRecording(false)} />
                        } */}
                            {!isRecording && (
                              <div className="flex w-full items-center justify-start gap-2">
                                {editMessage && (
                                  <div className="!h-10 !w-10">
                                    <button
                                      title="Cancel"
                                      className="flex h-10 w-10 items-center justify-center"
                                      onClick={() => {
                                        setEditMessage(null);
                                        setFormValues({ message: '' });
                                        formik.setFieldValue('message', '');
                                        isGroup && setMentionUser([]);
                                      }}
                                    >
                                      <PiXCircle className="h-8 w-8 text-[#4B5563] hover:text-black" />
                                    </button>
                                  </div>
                                )}
                                {isAttachmentPreview && (
                                  <div className="!h-10 !w-10">
                                    <Button
                                      type="button"
                                      title="Add file"
                                      onClick={() => {
                                        setFileAccept({
                                          ...imageAccept,
                                          ...documentAccept,
                                        });
                                        setTimeout(() => open(), 0);
                                      }}
                                      className="flex !h-10 !w-10 items-center justify-center rounded-lg bg-[#6875F5] !p-0"
                                    >
                                      <FiUpload className="h-5 w-5 cursor-pointer text-white" />
                                    </Button>
                                  </div>
                                )}
                                <Field name="message" className="w-full">
                                  {({ field, form, meta }: FieldProps) => (
                                    <MentionsInput
                                      inputRef={(e: any) =>
                                        (chatInputRef.current = e)
                                      }
                                      allowSpaceInQuery={true}
                                      allowSuggestionsAboveCursor={true}
                                      value={
                                        isReset
                                          ? formValues?.message
                                          : formik.values.message
                                      }
                                      onChange={(
                                        event,
                                        newValue,
                                        newPlainTextValue,
                                        mentions
                                      ) => {
                                        setMentionUser([
                                          ...mentionUser,
                                          ...mentions,
                                        ]);
                                        form.setFieldValue(
                                          'message',
                                          newPlainTextValue
                                        );
                                      }}
                                      onKeyDown={(event) =>
                                        handleKeyDownEvent(event, formik)
                                      }
                                      placeholder="Type a message"
                                      className="mentions absolute z-50 w-full"
                                      style={mentionStyles}
                                    >
                                      <Mention
                                        trigger={isGroup ? '@' : ''}
                                        data={
                                          isGroup
                                            ? removeLoginUser(
                                                singleGroupDetails?.[0]?.members
                                              )
                                            : fetchUsers
                                        }
                                        displayTransform={(id, display) =>
                                          `@${display} `
                                        }
                                      />
                                    </MentionsInput>

                                    // <Textarea
                                    //   rows={2}
                                    //   onKeyDown={(event: any) =>
                                    //     handleKeyDownEvent(event, formik)
                                    //   }
                                    //   {...field}
                                    //   value={
                                    //     isReset
                                    //       ? formValues?.message
                                    //       : formik.values.message
                                    //   }
                                    //   placeholder="Type a message"
                                    //   className="row-start-2 @md:col-span-2 @xl:col-span-3 @xl:row-start-2 @4xl:col-span-4"
                                    //   textareaClassName="h-15 lg:h-10 text-black poppins_font_number"
                                    // />
                                  )}
                                </Field>
                                {/* Send Button */}
                                <div className="!h-10 !w-10">
                                  <Button
                                    type="submit"
                                    title={editMessage ? 'Done' : 'Send'}
                                    className="flex !h-10 !w-10 items-center justify-center rounded-lg !bg-[#6875F5] !p-0"
                                    disabled={
                                      chatSlice?.editMessageChatLoader ||
                                      documentChatLoader
                                    }
                                  >
                                    {chatSlice?.editMessageChatLoader ||
                                    documentChatLoader ? (
                                      <Spinner
                                        size="sm"
                                        className="!text-white"
                                      />
                                    ) : (
                                      <>
                                        {editMessage ? (
                                          <MdDone className="h-5 w-5 cursor-pointer text-white" />
                                        ) : (
                                          <LuSend className="h-5 w-5 cursor-pointer text-white" />
                                        )}
                                      </>
                                    )}
                                  </Button>
                                </div>
                              </div>
                            )}

                            {isRecording && (
                              <AudioRecorder2
                                isRecording={isRecording}
                                setIsRecording={setIsRecording}
                                onAudioReady={onAudioReady}
                                onCancel={() => setIsRecording(false)}
                              />
                            )}

                            {!editMessage &&
                              !isAttachmentPreview &&
                              !isImagePreview && (
                                <div className="mt-4 flex flex-row items-center justify-around gap-2 lg:mt-0">
                                  {/* attachment popup over */}
                                  <div className="flex h-8 w-8 items-center justify-center">
                                    <Popover
                                      placement="bottom"
                                      className="demo_test p-2"
                                      content={({ setOpen }) => (
                                        <div className="flex flex-col items-center p-0">
                                          <div className="w-full">
                                            <Button
                                              variant="text"
                                              className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                              onClick={() => {
                                                setFileAccept(imageAccept);
                                                setTimeout(() => open(), 0);
                                                setOpen(false);
                                              }}
                                            >
                                              Image
                                            </Button>
                                          </div>
                                          <div className="w-full">
                                            <Button
                                              variant="text"
                                              className="flex w-full items-center justify-start p-2 hover:bg-[#EDEAFE] focus:outline-none dark:hover:bg-gray-50"
                                              onClick={() => {
                                                setFileAccept(documentAccept);
                                                setTimeout(() => open(), 0);
                                                setOpen(false);
                                              }}
                                            >
                                              Document
                                            </Button>
                                          </div>
                                        </div>
                                      )}
                                    >
                                      {/* attached icon  */}
                                      <button
                                        className="flex items-center justify-center"
                                        title={'Attachment'}
                                        type="button"
                                      >
                                        <IoMdAttach className="h-6 w-6 rotate-45 cursor-pointer text-[#4B5563] hover:text-black" />
                                      </button>
                                    </Popover>
                                  </div>

                                  {/* Emoji */}
                                  <div className="flex h-8 w-8 items-center justify-center">
                                    <Popover
                                      placement="bottom"
                                      showArrow={false}
                                      className="demo_test gap-2 border-0 bg-transparent"
                                      content={({ setOpen }) => (
                                        <Picker
                                          previewConfig={{
                                            showPreview: false,
                                          }}
                                          height={350}
                                          emojiStyle={EmojiStyle.NATIVE}
                                          skinTonesDisabled={true}
                                          allowExpandReactions={false}
                                          searchDisabled={true}
                                          onEmojiClick={(event) => {
                                            onEmojiClick(event, formik);
                                            // setOpen(false);
                                          }}
                                          className="border-0 bg-transparent p-4"
                                        />
                                      )}
                                    >
                                      <button
                                        className="flex items-center justify-center"
                                        title={'Emoji'}
                                        type="button"
                                      >
                                        <BsEmojiSmile className="h-[22px] w-[22px] cursor-pointer text-[#4B5563] hover:text-black" />
                                      </button>
                                    </Popover>
                                  </div>

                                  {/* Audio */}
                                  <div className="flex h-8 w-8 items-center justify-center">
                                    <button
                                      className="flex items-center justify-center"
                                      // onClick={openAudioModel}
                                      onClick={() => {
                                        handleAudioRecording();
                                        setMentionUser([]);
                                        setFormValues({ message: '' });
                                        formik.setFieldValue('message', '');
                                        setReplyMessage(null);
                                        setEditMessage(null);
                                      }}
                                      title={'Recording'}
                                      disabled={audionButtonDisabled}
                                      type="button"
                                    >
                                      {audionButtonDisabled ? (
                                        <FiMicOff className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-black" />
                                      ) : (
                                        <FiMic className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-black" />
                                      )}
                                    </button>
                                  </div>
                                </div>
                              )}
                          </>
                        ) : (
                          <>
                            <Text className="text-sm font-medium text-black">
                              {`${selectedImagePreviewIndex + 1} - ${
                                previewImages?.images?.length ?? 0
                              } Media`}
                            </Text>
                            <button
                              className="flex h-10 items-center justify-center rounded-lg border border-[#B4C6FC] bg-[#6875F5] p-3 text-sm text-white"
                              onClick={() => {
                                // close image preview when click on done
                                setPreviewImages(null);
                                setIsImagePreview(false);
                                setSelectedImagePreviewIndex(0);
                              }}
                            >
                              Done
                            </button>
                          </>
                        )}
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            )}
          </div>
        )}

        {/* Profile page */}
        {showProfile && !isBoard && (
          <>
            {isMobile && showProfileDetails && (
              <ProfileViewPage
                chatUser={chatUser}
                setShowProfileDetails={setShowProfileDetails}
              />
            )}
            {!isMobile && (
              <ProfileViewPage
                chatUser={chatUser}
                setShowProfileDetails={setShowProfileDetails}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}
