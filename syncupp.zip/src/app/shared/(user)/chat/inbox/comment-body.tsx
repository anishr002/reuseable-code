'use client';

import { GetDocumentDownloadApi } from '@/api/user/chat/chatApis';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  getFileType,
  updateMessageFormatWithMentionUser,
} from '@/utils/common-functions';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useSelector } from 'react-redux';
import { FileIcons } from './file-icons';
import { ImagePreviewModel } from './image-preview-modal';

const NEXT_PUBLIC_IMAGE_URL = process.env.NEXT_PUBLIC_IMAGE_URL;

export default function CommentBody({
  message,
  selectedUser,
}: Readonly<{
  message: any;
  selectedUser: any;
}>) {
  const { openModal } = useModal();
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const signInUserData = useSelector((state: any) => state?.root?.signIn);

  const { taskMentionedUsers } = useSelector(
    (state: any) => state.root.boardChat
  );

  const isBoard = selectedUser?.chat_type === 'boards' ? true : false;
  const messageFromSender =
    message?.user_id?._id === signInUserData?.user?.data?.user?._id;
  const isRtl = message?.user_id?._id === signInUserData?.user?.data?.user?._id;

  // console.log(
  //   'message....',
  //   message,
  //   'messageFromSender....',
  //   messageFromSender,
  //   'isRtl.....',
  //   isRtl
  // );

  const downloadFile = async (file: any) => {
    let fileUrl = NEXT_PUBLIC_IMAGE_URL + '/';
    let fileName = 'document';

    if (file?.preview && file?.name) {
      fileUrl += file?.preview;
      fileName = file?.name;
    }

    await GetDocumentDownloadApi(fileUrl).then((data: any) => {
      const href = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = href;
      link.setAttribute('download', fileName?.split('.')?.[0]);
      document.body.appendChild(link);
      link.click();

      document.body.removeChild(link);
      URL.revokeObjectURL(href);
    });
  };

  const getFormatedTime = (
    date: any,
    format: string = 'DD/MM/yyyy hh:mm A'
  ) => {
    if (!date) {
      return '';
    }
    return moment(date).format(format);
  };

  return (
    <div
      dir={`${isRtl ? 'rtl' : 'ltr'}`}
      className={cn('px-4', message?.nextIsSame ? 'pb-[10px]' : 'pb-5')}
    >
      <div className="grid items-center gap-3 lg:gap-4">
        {/* code for html chat */}

        {/* Recevier Message Code Start */}
        {!messageFromSender && (
          <div className="flex items-end gap-3">
            <div className="flex h-9 w-9 items-center justify-center">
              {/* Comment from Receiver User's profile */}
              {!message?.nextIsSame && (
                <Avatar
                  src={`${NEXT_PUBLIC_IMAGE_URL}/uploads/${message?.user_id?.profile_image}`}
                  name={`${capitalizeFirstLetter(
                    message?.user_id?.first_name
                  )} ${capitalizeFirstLetter(message?.user_id?.last_name)}`}
                  size="sm"
                  className="flex items-center justify-center rounded-full bg-blue-500 text-white"
                />
              )}
            </div>
            {/* message box start */}
            <div className="flex items-center justify-start gap-4">
              <div>
                {message?.comment && (
                  <button
                    className={cn(
                      'relative min-w-[90px] max-w-[550px] break-words rounded-t-[20px] rounded-br-[20px] bg-white py-[15px] pl-5 pr-5 text-left text-sm font-medium text-[#191919] shadow-md',
                      message?.nextIsSame && 'rounded-bl-[20px]'
                    )}
                  >
                    <p
                      dir="ltr"
                      className={cn('mb-4')}
                      dangerouslySetInnerHTML={{
                        __html: updateMessageFormatWithMentionUser(
                          message?.comment,
                          taskMentionedUsers,
                          true,
                          false,
                          'text-[#6C76FF]'
                        ),
                      }}
                    ></p>
                    <div
                      dir="ltr"
                      className={cn(
                        'poppins_font_number absolute bottom-2 left-5 flex justify-end text-xs font-light text-[#191919]'
                      )}
                    >
                      {getFormatedTime(message?.createdAt as Date, 'hh:mm A')}
                    </div>
                  </button>
                )}

                {/* Attachments show */}
                {message?.attachments?.length > 0 &&
                  message?.attachments?.map((file: any) => {
                    return (
                      <div key={file?._id} className="pt-[10px]">
                        {getFileType(file?.name) === 'IMGIcon' ? (
                          <button className="relative">
                            <Image
                              src={`${NEXT_PUBLIC_IMAGE_URL}/${file?.preview}`}
                              alt={file?.name}
                              width={150}
                              height={150}
                              onClick={() =>
                                openModal({
                                  view: (
                                    <ImagePreviewModel
                                      fileUrl={`${NEXT_PUBLIC_IMAGE_URL}/${file?.preview}`}
                                      original_file_name={file?.name}
                                      downloadFile={() => downloadFile(file)}
                                    />
                                  ),
                                  customSize: '100%',
                                })
                              }
                              className="cursor-pointer rounded-xl border-2 border-[#D1D5DB]"
                            />
                            <div
                              dir="ltr"
                              className={cn(
                                'poppins_font_number absolute bottom-2 left-2 flex items-center justify-center rounded-[5.2px] bg-[#E3E3E3] px-[5.2px] py-[2.6px] text-[13px] font-light text-[#1E1E1E]'
                              )}
                            >
                              {getFormatedTime(
                                message?.createdAt as Date,
                                'hh:mm A'
                              )}
                            </div>
                          </button>
                        ) : (
                          <button
                            className={cn(
                              'relative min-w-[90px] max-w-[550px] break-words rounded-t-[20px] rounded-br-[20px] bg-white px-2 pb-[15px] pt-2 text-left text-sm font-normal text-[#191919] shadow-md',
                              message?.nextIsSame && 'rounded-bl-[20px]'
                            )}
                          >
                            <Link
                              target="_blank"
                              href={`${NEXT_PUBLIC_IMAGE_URL}/${file?.preview}`}
                            >
                              <FileIcons
                                key={file?._id}
                                fileType={getFileType(file?.name)}
                                fileName={file?.name}
                                className={cn('mb-4 !flex-row !bg-[#F5F5F5]')}
                              />
                            </Link>
                            <div
                              dir="ltr"
                              className={cn(
                                'poppins_font_number absolute bottom-2 left-5 flex justify-end text-xs font-light text-[#191919]'
                              )}
                            >
                              {getFormatedTime(
                                message?.createdAt as Date,
                                'hh:mm A'
                              )}
                            </div>
                          </button>
                        )}
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        )}
        {/* Recevier Message Code End */}

        {/* Sender Message Code Start */}
        {messageFromSender && (
          <div className="flex items-end gap-4 space-x-3">
            <div>
              {/* Message */}
              {message?.comment && (
                <button
                  className={cn(
                    'relative min-w-[90px] max-w-[550px] break-words rounded-t-[20px] rounded-bl-[20px] bg-[#D3D7EC] py-[15px] pl-5 pr-5 text-left text-sm font-medium text-black shadow-md',
                    message?.nextIsSame && 'rounded-br-[20px]'
                  )}
                >
                  <p
                    dir="ltr"
                    className={cn('mb-4 mr-4 !text-black')}
                    dangerouslySetInnerHTML={{
                      __html: updateMessageFormatWithMentionUser(
                        message?.comment,
                        taskMentionedUsers,
                        true,
                        true,
                        'text-[#4A40FF]'
                      ),
                    }}
                  ></p>
                  <div
                    dir="ltr"
                    className={cn(
                      'poppins_font_number absolute bottom-2 right-5 flex justify-end text-xs font-light text-black'
                    )}
                  >
                    {getFormatedTime(message?.createdAt as Date, 'hh:mm A')}
                  </div>
                </button>
              )}
              {/* Attachments show */}
              {message?.attachments?.length > 0 &&
                message?.attachments?.map((file: any) => {
                  return (
                    <div key={file?._id} className="pt-[10px]">
                      {getFileType(file?.name) === 'IMGIcon' ? (
                        <button className="relative">
                          <Image
                            src={NEXT_PUBLIC_IMAGE_URL + '/' + file?.preview}
                            alt={file?.name}
                            className="rounded-xl border-2 border-[#D1D5DB]"
                            width={150}
                            height={150}
                            onClick={() =>
                              openModal({
                                view: (
                                  <ImagePreviewModel
                                    fileUrl={`${NEXT_PUBLIC_IMAGE_URL}/${file?.preview}`}
                                    original_file_name={file?.name}
                                    downloadFile={() => downloadFile(file)}
                                  />
                                ),
                                customSize: '100%',
                              })
                            }
                          />
                          <div
                            dir="ltr"
                            className={cn(
                              'poppins_font_number absolute bottom-2 right-2 flex items-center justify-center rounded-[5.2px] bg-[#E3E3E3] px-[5.2px] py-[2.6px] text-[13px] font-light text-[#1E1E1E]'
                            )}
                          >
                            {getFormatedTime(
                              message?.createdAt as Date,
                              'hh:mm A'
                            )}
                          </div>
                        </button>
                      ) : (
                        <button
                          className={cn(
                            'relative min-w-[90px] max-w-[550px] break-words rounded-t-[20px] rounded-bl-[20px] bg-[#D3D7EC] px-2 pb-[15px] pt-2 text-left text-sm font-normal text-black shadow-md',
                            message?.nextIsSame && 'rounded-br-[20px]'
                          )}
                        >
                          <Link
                            target="_blank"
                            href={`${NEXT_PUBLIC_IMAGE_URL}/${file?.preview}`}
                          >
                            <FileIcons
                              key={file?._id}
                              fileType={getFileType(file?.name)}
                              fileName={file?.name}
                              className={cn('mb-4')}
                            />
                          </Link>
                          <div
                            dir="ltr"
                            className={cn(
                              'poppins_font_number absolute  bottom-2 right-5 flex justify-end text-xs font-light text-black'
                            )}
                          >
                            {getFormatedTime(
                              message?.createdAt as Date,
                              'hh:mm A'
                            )}
                          </div>
                        </button>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}
        {/* Sender Message Code End */}
      </div>
    </div>
  );
}
