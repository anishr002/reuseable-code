'use client';

import MessageDetails from '@/app/shared/(user)/chat/inbox/message-details';
import cn from '@/utils/class-names';

export default function InboxTabs({ chatUser, className, setChatUser }: Readonly<{ chatUser: any, className?: string, setChatUser: any }>) {
  return <MessageDetails chatUser={chatUser} setChatUser={setChatUser} className={cn(className)} />;
}
