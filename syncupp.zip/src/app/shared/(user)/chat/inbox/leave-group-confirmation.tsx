'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import Spinner from '@/components/ui/spinner';
import { leaveChatGroup } from '@/redux/slices/user/chat/group/groupChatSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

export function LeaveGroupConfirmationModal({ chatUser }: { chatUser: any }) {
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  const { leaveChatGroupLoader } = useSelector(
    (state: any) => state?.root?.group
  );

  const handleYesClick = () => {
    dispatch(leaveChatGroup({ group_id: chatUser?._id ?? '' })).then(
      (result: any) => {
        if (leaveChatGroup.fulfilled.match(result)) {
          if (result && result?.payload?.success === true) {
            closeModal();
          }
        }
      }
    );
  };

  return (
    <div className="flex w-full flex-col items-center justify-center gap-10 rounded-xl bg-white px-8 pb-7 pt-14">
      <p className="text-xl font-bold text-[#141414]">
        Are you sure you want to leave this group?
      </p>
      <div className="flex items-center justify-center gap-4">
        <Button
          variant="outline"
          className="rounded-lg border border-[#D4D4D4] text-sm font-medium text-black"
          onClick={closeModal}
        >
          Cancel
        </Button>
        <Button
          onClick={handleYesClick}
          disabled={leaveChatGroupLoader}
          className="flex items-center justify-center gap-2 rounded-lg bg-[#FA4571] text-sm font-medium text-white"
        >
          <span>Yes, Leave</span>
          {leaveChatGroupLoader && (
            <Spinner size="sm" tag="div" className="text-white" />
          )}
        </Button>
      </div>
    </div>
  );
}
