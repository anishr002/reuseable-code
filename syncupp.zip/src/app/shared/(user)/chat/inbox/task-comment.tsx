'use client';

import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import TrashIcon from '@/components/icons/trash';
import Spinner from '@/components/ui/spinner';
import { messages } from '@/config/messages';
import { postAddComments } from '@/redux/slices/user/task/taskSlice';
import {
  checkValidFileSize,
  getColor,
  getFileSize,
  getFileType,
} from '@/utils/common-functions';
import { useRef, useState } from 'react';
import { IoMdAttach } from 'react-icons/io';
import { LuSend } from 'react-icons/lu';
import { Mention, MentionsInput } from 'react-mentions';
import { useDispatch, useSelector } from 'react-redux';

export default function TaskComment({
  task,
  selectedUser,
}: Readonly<{
  task: any;
  selectedUser: any;
}>) {
  const dispatch = useDispatch();
  const taskData = useSelector((state: any) => state?.root?.task);
  const { boardId, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  const { taskAssignees } = useSelector((state: any) => state.root.boardChat);
  const signIn = useSelector((state: any) => state?.root?.signIn);

  const commentAttachmentRef = useRef<HTMLInputElement>(null);
  const [commentText, setCommentText] = useState('');
  // for handle comment attachement error
  const [commentAttachementInvalid, setCommentAttachementInvalid] =
    useState(false);
  // for multiple selected attachement preview for comment
  const [previewImageForComment, setPreviewImageForComment] =
    useState<any>(null);

  const [mentionUser, setMentionUser] = useState<any>([]);

  console.log('taskAssignees.....', taskAssignees);

  // Mention Style Start
  const mentionStyles = {
    control: {
      // backgroundColor: '#FFFFFF',
      fontSize: 16,
      fontWeight: 'normal',
      color: '#000000',
      borderRadius: '8px',
      outline: 'none', // Removes the focus outline
      '&:focus': {
        border: 'none', // Ensures no border on focus
        outline: 'none', // Prevents the default focus outline
        boxShadow: 'none', // Removes any shadow effect
      },
    },
    '&multiLine': {
      control: {
        fontFamily: 'Arial, sans-serif',
        overflow: 'hidden',
        // maxHeight: '6rem'
        height: '60px',
        width: 'calc(100% - 1px)', // Conditional width
      },
      highlighter: {
        padding: 6,
        border: 'none',
        overflow: 'hidden',
        // maxHeight: '5.9rem',
        // borderRadius: '8px',
        height: '60px',
        width: 'calc(100% - 1px)', // Conditional width
      },
      input: {
        padding: 6,
        border: 'none',
        // maxHeight: '5.9rem',
        margin: '0px',
        color: '#141414',
        borderRadius: '8px',
        borderColor: 'white',
        height: '60px',
        overflow: 'auto',
        // resize: 'none',
        width: 'calc(100% - 1px)', // Conditional width
        placeholderColor: '#141414',
        outline: 'none', // Removes the focus outline
        '&:focus': {
          border: 'none', // Ensures no border on focus
          outline: 'none', // Prevents the default focus outline
          boxShadow: 'none', // Removes any shadow effect
        },
      },
    },
    suggestions: {
      // width: "200px",
      list: {
        // backgroundColor: 'white',
        border: 'none',
        fontSize: 14,
        // position: 'absolute', // Position absolutely to control its placement
        bottom: '100%', // Move the list above the input
        left: 0,
        zIndex: 10, // Ensure it appears above other content
      },
      item: {
        padding: '5px 15px',
        borderBottom: '1px solid #ccc',
        '&focused': {
          backgroundColor: '#8C80D2',
          color: 'white',
        },
      },
    },
  };

  const removeLoginUserFromMentionList = (menetionUserList: any) => {
    if (menetionUserList?.length === 0) {
      return menetionUserList;
    }

    return menetionUserList?.filter(
      (user: any) =>
        user?.id?.toString() !== signIn?.user?.data?.user?._id.toString()
    );
  };

  const formateComment = (message: string, userList: any) => {
    const processedMessage = message?.replace(
      /@(\w+\s\w+)/g,
      (match: any, displayName: any) => {
        const mention = userList?.find(
          (item: any) => item?.display === displayName
        );
        return mention ? `@[user::${mention.id}]` : match;
      }
    );
    return processedMessage;
  };

  // Keydown event for comment with mention user
  const handleKeyDownForComment = (event: any) => {
    // Prevent space as the first character
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }

    // Check for Shift + Enter (allow new line)
    if (event.key === 'Enter' && event.shiftKey) {
      return; // Allow default behavior for a new line
    }

    // Handle Enter key press to submit the comment
    if (event.key === 'Enter') {
      event.preventDefault(); // Prevent new line in the input

      // Call the send comment function
      handleSendComment();
    }
  };

  // check in comment attachement if any invalide file exits or not
  const checkCommentAttachement = (data: any) => {
    setCommentAttachementInvalid(false);

    if (data?.length > 0) {
      const fileSize = Object.values(data)?.map((file: any) =>
        getFileSize(file)
      );
      const inValidFile = fileSize?.filter(
        (fileInfo) => !checkValidFileSize(fileInfo, 200)
      );
      if (inValidFile?.length > 0) {
        setCommentAttachementInvalid(true);
      }
    }
  };

  // handle comment attachement
  const handleAttachmentChange = (event: any) => {
    const newFiles = event?.target?.files;

    checkCommentAttachement(event?.target?.files);

    const previewURLs: any[] = [];
    Object.values(newFiles).forEach((file: any) => {
      Object.assign(file, {
        preview: URL.createObjectURL(file),
      });
      previewURLs.push(file);
    });
    const attachementURL =
      previewImageForComment && previewImageForComment !== null
        ? [...previewImageForComment, ...previewURLs]
        : [...previewURLs];
    setPreviewImageForComment(attachementURL);
  };

  const handleSendComment = () => {
    // comment api logic
    const myForm = new FormData();
    task?._id && myForm.append('task_id', task?._id);

    if (commentText) {
      myForm.append('comment', formateComment(commentText, taskAssignees));
    }
    const mentionedUsers =
      mentionUser?.length > 0
        ? Array.from(new Set(mentionUser?.map((item: any) => item.id)))
        : [];
    myForm.append('mentioned_users', JSON.stringify(mentionedUsers));

    previewImageForComment?.length > 0 &&
      previewImageForComment?.map((file: any) => {
        myForm.append('images', file);
      });

    // console.log(
    //   'commentText....',
    //   commentText,
    //   'previewImageForComment....',
    //   previewImageForComment,
    //   'mentionedUsers....',
    //   mentionedUsers
    // );

    (commentText !== '' || previewImageForComment?.length > 0) &&
      !commentAttachementInvalid &&
      dispatch(postAddComments(myForm)).then((result: any) => {
        if (postAddComments.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setPreviewImageForComment(null);
            setCommentText('');
          }
        }
      });
  };

  return (
    <div className="flex min-h-[100px] w-full flex-col items-center justify-between rounded-lg border border-[#D1D5DB] bg-white text-black">
      {/* Preview Area */}
      {previewImageForComment && previewImageForComment?.length > 0 && (
        <div className="w-full">
          <div className="m-1 flex max-h-24 w-full flex-wrap justify-start gap-4 overflow-auto">
            {previewImageForComment?.map((image: any, index: number) => {
              const fileType = getFileType(image?.name); // Get the file type
              const color = getColor(fileType);
              return (
                <div
                  className="mr-[44px] flex w-[100px] flex-col items-center space-y-2"
                  key={image?._id || index}
                  title={image?.name ?? ''}
                >
                  <div
                    className={`flex items-center gap-2 rounded-lg p-2`}
                    style={{
                      backgroundColor: color?.bgColor,
                      color: color?.textColor,
                    }}
                  >
                    <CustomFileIcons
                      fileType={fileType}
                      iconClassName="!w-5 !h-5"
                    />
                    <p className="w-[80px] truncate text-center font-sans text-[14px]">
                      {image?.name}
                    </p>
                    <TrashIcon
                      className="h-5 w-5 cursor-pointer text-red-500 hover:text-red-700"
                      onClick={() => {
                        const updatedFiles = previewImageForComment.filter(
                          (file: any) => file?.preview !== image?.preview
                        );
                        setPreviewImageForComment(updatedFiles);
                        checkCommentAttachement(updatedFiles);
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Error Message */}
      {commentAttachementInvalid && (
        <div className="w-full">
          <p className="m-1 text-sm text-red-500">
            {messages.taskCommentAttachementMaxFileSize}
          </p>
        </div>
      )}

      {/* Input and Actions */}
      <div className="w-full p-1">
        {/* Hidden File Input */}

        {/* Mentions Input */}
        <div className="flex-grow">
          <MentionsInput
            allowSpaceInQuery
            allowSuggestionsAboveCursor
            placeholder="Enter your comment here..."
            className="mentions task-comment"
            style={mentionStyles}
            disabled={task?.mark_as_done}
            onKeyDown={(event: any) => handleKeyDownForComment(event)}
            maxLength={400}
            onChange={(event, newValue, newPlainTextValue, mentions) => {
              setCommentText(newPlainTextValue);
              setMentionUser([...mentionUser, ...mentions]);
            }}
            value={commentText}
          >
            <Mention
              trigger="@"
              data={removeLoginUserFromMentionList(taskAssignees ?? [])}
              displayTransform={(id, display) => `@${display} `}
            />
          </MentionsInput>
        </div>
      </div>
      <div className="flex w-full items-center justify-between p-1">
        {/* Attachment Button */}
        <input
          type="file"
          onChange={handleAttachmentChange}
          style={{ display: 'none' }}
          multiple
          name="attachments"
          ref={commentAttachmentRef}
          accept=".doc,.docx,.pdf,.txt,.log,.ini,.rtf,.odt,.epub,.xls,.xlsx,.csv,.ods,.ppt,.pptx,.odp,.key,.jpeg,.jpg,.png,.gif,.bmp,.tiff,.svg,.webp,.eps,.mp4,.avi,.mov,.wmv,.mkv,.flv,.mp3,.wav,.aac,.ogg,.flac,.js,.json,.xml,.html,.htm,.css,.yaml,.sql,.md,.py,.java,.c,.cpp,.psd,.ai,.xd,.fig,.sketch,.indd,.sqlite,.db,.zip,.rar,.7z,.tar.gz,.iso,.ics,.apk,.dmg"
        />
        <button
          className="!bg-transparent !p-0"
          title={'Attachment'}
          onClick={() => commentAttachmentRef?.current?.click()}
        >
          <IoMdAttach className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
        </button>
        {/* Send Button */}
        <button
          className="!bg-transparent !p-0"
          disabled={
            taskData?.addCommentsLoader ||
            task?.mark_as_done ||
            (commentText === '' && previewImageForComment?.length === 0)
          }
          onClick={handleSendComment}
        >
          {!taskData?.addCommentsLoader ? (
            <LuSend className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
          ) : (
            <Spinner className="h-5 w-5" size="sm" tag="div" color="white" />
          )}
        </button>
      </div>
    </div>
  );
}
