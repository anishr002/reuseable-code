'use client';

import InboxTabs from '@/app/shared/(user)/chat/inbox/inbox-tabs';
import MessageList from '@/app/shared/(user)/chat/inbox/message-list';
import socket from '@/io';
import {
  deleteTaskInBoard,
  hideUnReadBoardCount,
  removeFromBoard,
  setBoardFirstInList,
  setOnGoingBoardFirst,
  updateCommentInTask,
  updateTaskDetails,
  updateTasksInBoard,
} from '@/redux/slices/user/chat/boards/boardChatSlice';
import {
  deleteMessage,
  deleteReaction,
  getSharedFiles,
  setFileList,
  setFirstInList,
  showUnReadMessage,
  updateFileList,
  updateMessage,
  updateReaction,
  updateSingleMessage,
  userIsOffline,
  userIsOnline,
} from '@/redux/slices/user/chat/chatSlice';
import {
  addNewGroupInList,
  deleteGroupReaction,
  deleteMessageInGroup,
  removeFromGroup,
  setGroupFirstInList,
  showUnReadGroup,
  updateGroupDetails,
  updateGroupMessage,
  updateGroupReaction,
  updateMessageInGroup,
} from '@/redux/slices/user/chat/group/groupChatSlice';
import { showWebNotification } from '@/utils/common-functions';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useMedia } from 'react-use';

const pageHeader = {
  title: 'Chats',
};

export default function ChatInbox() {
  const [chatUser, setChatUser] = useState<any>();
  const [noUserForChat, setnoUserForChat] = useState(false);
  const isMobile = useMedia('(max-width: 1023px)', false);

  const { profileFilter } = useSelector((state: any) => state?.root?.chat);
  const currentChatType = useSelector(
    (state: any) => state?.root?.chat?.currentChatType
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const signInUserData = useSelector((state: any) => state?.root?.signIn);
  const { currentTask } = useSelector((state: any) => state?.root?.boardChat);

  const dispatch = useDispatch();

  const receiveMessageHelper = (response: any) => {
    if (
      chatUser?._id === response?.to_user ||
      chatUser?._id === response?.from_user
    ) {
      dispatch(updateMessage(response));
      dispatch(updateFileList(response));
    }

    console.log(response, 'receiveMessageHelper');
    // Chat not ongoing
    if (
      chatUser?._id !== response?.to_user &&
      chatUser?._id !== response?.from_user
    ) {
      // const payload = {
      //   to_user: response?.to_user,
      //   from_user: response?.from_user,
      // };
      // socket.emit('ONGOING_CHAT', payload);
      socket.emit('NOT_ONGOING_CHAT', {
        ...response,
        workspace_id: defaultWorkSpace?._id,
      });
      console.log('NOT_ONGOING_CHAT');
      showWebNotification('Chat');
      socket.emit('CONFIRMATION', { event: 'NOT_ONGOING_CHAT' });
      // dispatch(showUnReadMessage(response));
    }

    if (chatUser?._id === response?.to_user) {
      // sender side
      dispatch(
        setFirstInList({
          to_user: chatUser?._id,
          createdAt: response?.createdAt,
          message_type: response?.message_type,
          last_message: response?.message,
          sender_info: response?.sender_info ? response?.sender_info : null,
        })
      );
    } else {
      // receiver side
      dispatch(
        setFirstInList({
          to_user: response?.from_user,
          createdAt: response?.createdAt,
          message_type: response?.message_type,
          last_message: response?.message,
          sender_info: response?.sender_info
            ? response?.sender_info
            : response?.user_detail,
        })
      );
    }
  };

  const receiveGroupMessageHelper = (response: any) => {
    if (chatUser?.chat_type === 'group') {
      // If current chat screen and GROUP_RECEIVED_MESSAGE group id is same
      if (chatUser?._id === response?.group_id) {
        dispatch(updateMessageInGroup(response));
        dispatch(updateFileList(response));
      }
    }
    if (currentChatType === 'group') {
      dispatch(
        setGroupFirstInList({
          group_id: response?.group_id,
          createdAt: response?.createdAt,
          message_type: response?.message_type,
          last_message: response?.message,
        })
      );
    }

    if (chatUser?._id !== response?.group_id) {
      // dispatch(showUnReadGroup(response));
      socket.emit('NOT_ONGOING_GROUP_CHAT', {
        ...response,
        workspace_id: defaultWorkSpace?._id,
      });
      console.log('NOT_ONGOING_GROUP_CHAT');
      showWebNotification('Chat');
      socket.emit('CONFIRMATION', { event: 'NOT_ONGOING_GROUP_CHAT' });
    }
  };

  // ----------------------------- One to One Chat Event -------------------------------- //

  // Connect Socket When User Come To Chat Screeen
  useEffect(() => {
    socket.disconnect();
    socket.connect();
    socket.emit('ROOM', {
      id: signInUserData?.user?.data?.user?._id,
      workspace_id: defaultWorkSpace?._id,
    });
    socket.emit('CONFIRMATION', { event: 'ROOM' });
  }, [defaultWorkSpace?._id]);

  // Received message effect
  useEffect(() => {
    socket.on('RECEIVED_MESSAGE', (response: any) => {
      // console.log('RECEIVED_MESSAGE......', response);
      receiveMessageHelper(response);
      socket.emit('CONFIRMATION', { event: 'RECEIVED_MESSAGE' });
    });

    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('RECEIVED_MESSAGE');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Received edit message effect
  useEffect(() => {
    socket.on('MESSAGE_EDITED', (response: any) => {
      // console.log('MESSAGE_EDITED........', response);
      if (response) {
        dispatch(updateSingleMessage(response));
      }
      socket.emit('CONFIRMATION', { event: 'MESSAGE_EDITED' });
    });

    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('MESSAGE_EDITED');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Received images effect
  useEffect(() => {
    socket.on('RECEIVED_IMAGE', (response: any) => {
      console.log('RECEIVED_IMAGE');
      receiveMessageHelper(response);
      socket.emit('CONFIRMATION', { event: 'RECEIVED_IMAGE' });
    });
    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('RECEIVED_IMAGE');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Received document effect
  useEffect(() => {
    socket.on('RECEIVED_DOCUMENT', (response: any) => {
      console.log('RECEIVED_DOCUMENT');
      receiveMessageHelper(response);
      socket.emit('CONFIRMATION', { event: 'RECEIVED_DOCUMENT' });
    });
    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('RECEIVED_DOCUMENT');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // When Sender Delete Message
  useEffect(() => {
    socket.on(
      'MESSGAE_DELETED',
      (response: {
        message: string;
        _id: string;
        message_type: string;
        to_user: string;
      }) => {
        console.log('MESSGAE_DELETED', response);
        dispatch(
          deleteMessage({
            messageId: response._id,
            userId: response?.to_user,
            message_type: response?.message_type,
          })
        );

        const isImage = response?.message_type === 'image';
        const isDocument = response?.message_type === 'document';
        const isAudio = response?.message_type === 'audio';

        const shouldUpdateList =
          (profileFilter === 'images' && isImage) ||
          (profileFilter === 'documents' && isDocument) ||
          (profileFilter === 'audio' && isAudio) ||
          (!profileFilter && (isImage || isDocument || isAudio));

        const initChatPagination = {
          page: 1,
          items_per_page: 10,
          sort_order: 'asc',
          sort_field: '',
          search: '',
          to_user: '',
          document_type: '',
        };
        if (shouldUpdateList) {
          dispatch(
            getSharedFiles({
              ...initChatPagination,
              document_type: profileFilter ?? '',
              to_user: response?.to_user,
            })
          ).then((result: any) => {
            if (getSharedFiles?.fulfilled?.match(result)) {
              if (result && result?.payload?.success === true) {
                dispatch(setFileList(result?.payload?.data?.docs ?? []));
              }
            }
          });
        }
      }
    );

    return () => {
      socket.off('MESSGAE_DELETED');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id, profileFilter]);

  // Received reaction effect
  useEffect(() => {
    socket.on('RECEIVED_REACTION', (response: any) => {
      console.log(response, 'RECEIVED_REACTION');

      if (
        chatUser?._id === response?.message?.to_user ||
        chatUser?._id === response?.message?.from_user
      ) {
        console.log('updateReaction');
        dispatch(updateReaction(response));
      }
      // receiveMessageHelper(response)
    });

    return () => {
      socket.off('RECEIVED_REACTION');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Delete reaction effect
  useEffect(() => {
    socket.on('REACTION_DELETED', (response: any) => {
      if (
        chatUser?._id === response?.message?.to_user ||
        chatUser?._id === response?.message?.from_user
      ) {
        dispatch(deleteReaction(response));
      }
      // receiveMessageHelper(response)
    });

    return () => {
      socket.off('REACTION_DELETED');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Received Audio
  useEffect(() => {
    socket.on('RECEIVED_AUDIO', (response: any) => {
      console.log(response, 'RECEIVED_AUDIO');
      receiveMessageHelper(response);
    });

    return () => {
      socket.off('RECEIVED_AUDIO');
    };
  }, [chatUser, chatUser?._id, defaultWorkSpace?._id]);

  // Unread Message Count Get Event
  useEffect(() => {
    socket.on('USER_SPECIFIC_CHAT_NOTIFICATION', (response: any) => {
      console.log(response, 'USER_SPECIFIC_CHAT_NOTIFICATION');
      socket.emit('CONFIRMATION', { event: 'USER_SPECIFIC_CHAT_NOTIFICATION' });
      dispatch(showUnReadMessage(response));
    });

    return () => {
      socket.off('USER_SPECIFIC_CHAT_NOTIFICATION');
    };
  }, [chatUser, chatUser?._id, defaultWorkSpace?._id]);

  // ----------------------------- Group Event -------------------------------- //
  // User add in new group
  useEffect(() => {
    socket.on('GROUP_CREATED', (response: any) => {
      socket.emit('JOIN_ROOM', {
        ...response,
        workspace_id: defaultWorkSpace?._id,
      });
      socket.emit('CONFIRMATION', { event: 'JOIN_ROOM' });
      if (currentChatType === 'group') {
        dispatch(addNewGroupInList(response));
      }
      socket.emit('CONFIRMATION', { event: 'GROUP_CREATED' });
    });
    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('GROUP_CREATED');
    };
  }, [
    chatUser,
    chatUser?.from_user,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Received group message effect
  useEffect(() => {
    socket.on('GROUP_RECEIVED_MESSAGE', (response: any) => {
      console.log(response, 'GROUP_RECEIVED_MESSAGE');
      receiveGroupMessageHelper(response);
      // Group Chat is ongoing
      socket.emit('CONFIRMATION', { event: 'GROUP_RECEIVED_MESSAGE' });
    });
    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('GROUP_RECEIVED_MESSAGE');
    };
  }, [
    chatUser,
    chatUser?.from_user,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Received Group edit message effect
  useEffect(() => {
    socket.on('GROUP_MESSAGE_EDITED', (response: any) => {
      // console.log('GROUP_MESSAGE_EDITED........', response);
      if (response) {
        dispatch(updateGroupMessage(response));
      }
      socket.emit('CONFIRMATION', { event: 'GROUP_MESSAGE_EDITED' });
    });

    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('GROUP_MESSAGE_EDITED');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Received group images effect
  useEffect(() => {
    socket.on('GROUP_RECEIVED_IMAGE', (response: any) => {
      console.log('GROUP_RECEIVED_IMAGE');
      receiveGroupMessageHelper({
        ...response,
        mentioned_users: response?.mentioned_users_obj,
      });
      socket.emit('CONFIRMATION', { event: 'GROUP_RECEIVED_IMAGE' });
    });
    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('GROUP_RECEIVED_IMAGE');
    };
  }, [
    chatUser,
    chatUser?.from_user,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Received group document effect
  useEffect(() => {
    socket.on('GROUP_RECEIVED_DOCUMENT', (response: any) => {
      console.log('GROUP_RECEIVED_DOCUMENT');
      receiveGroupMessageHelper({
        ...response,
        mentioned_users: response?.mentioned_users_obj,
      });
      socket.emit('CONFIRMATION', { event: 'GROUP_RECEIVED_DOCUMENT' });
    });
    return () => {
      // Remove event listener when component unmounts or when chatUser changes
      socket.off('GROUP_RECEIVED_DOCUMENT');
    };
  }, [
    chatUser,
    chatUser?.from_user,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Group Update
  useEffect(() => {
    socket.on('GROUP_UPDATED', (response: any) => {
      console.log('GROUP_UPDATED', response);
      if (currentChatType === 'group') {
        dispatch(updateGroupDetails({ newGroupDetails: response }));
        // dispatch(updateSingleGroupDetails({newGroupDetails: response}));

        // If user removed form the group and user currect chat screen is same
        if (chatUser?._id === response?._id) {
          setChatUser((prevState: any) => {
            return {
              ...prevState,
              group_name: response?.group_name,
              image_url: response?.image_url,
            };
          });
          // setChatUser({ ...chatUser, group_name: response?.group_name, image_url: response?.image_url });
        }
      }
      socket.emit('CONFIRMATION', { event: 'GROUP_UPDATED' });
      return () => {
        // Remove event listener when component unmounts or when chatUser changes
        socket.off('GROUP_UPDATED');
      };
    });
  }, [
    chatUser,
    chatUser?.from_user,
    dispatch,
    currentChatType,
    chatUser?.image_url,
    defaultWorkSpace?._id,
  ]);

  // Removed from group
  useEffect(() => {
    socket.on('REMOVED_FROM_GROUP', (response: any) => {
      console.log('REMOVED_FROM_GROUP');
      if (currentChatType === 'group') {
        dispatch(removeFromGroup({ groupDetails: response }));

        // If user removed form the group and user currect chat screen is same
        if (chatUser?._id === response?._id) {
          setChatUser(undefined);
        }
      }

      socket.emit('CONFIRMATION', { event: 'REMOVED_FROM_GROUP' });
      return () => {
        socket.off('REMOVED_FROM_GROUP');
      };
    });
  }, [
    chatUser,
    chatUser?.from_user,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // When Sender Delete Message in group
  useEffect(() => {
    socket.on(
      'GROUP_MESSGAE_DELETED',
      (response: {
        message: string;
        _id: string;
        message_type: string;
        group_id: string;
      }) => {
        console.log('GROUP_MESSGAE_DELETED', response);
        console.log('GROUP_MESSGAE_DELETED Chat user', chatUser);
        dispatch(
          deleteMessageInGroup({
            messageId: response?._id,
            groupId: chatUser?._id,
            message_type: response?.message_type,
          })
        );

        const isImage = response?.message_type === 'image';
        const isDocument = response?.message_type === 'document';
        const isAudio = response?.message_type === 'audio';

        const shouldUpdateList =
          (profileFilter === 'images' && isImage) ||
          (profileFilter === 'documents' && isDocument) ||
          (profileFilter === 'audio' && isAudio) ||
          (!profileFilter && (isImage || isDocument || isAudio));

        const initGroupPagination = {
          page: 1,
          items_per_page: 10,
          sort_order: 'asc',
          sort_field: '',
          search: '',
          group_id: '',
          document_type: '',
        };
        if (shouldUpdateList) {
          dispatch(
            getSharedFiles({
              ...initGroupPagination,
              document_type: profileFilter ?? '',
              group_id: response?.group_id,
            })
          ).then((result: any) => {
            if (getSharedFiles?.fulfilled?.match(result)) {
              if (result && result?.payload?.success === true) {
                dispatch(setFileList(result?.payload?.data?.docs ?? []));
              }
            }
          });
        }
      }
    );

    return () => {
      socket.off('GROUP_MESSGAE_DELETED');
    };
  }, [
    chatUser,
    chatUser?._id,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
    profileFilter,
  ]);

  // Received reaction effect
  useEffect(() => {
    socket.on('GROUP_RECEIVED_REACTION', (response: any) => {
      console.log(response, 'GROUP_RECEIVED_REACTION');

      if (chatUser?._id === response?.group_id) {
        dispatch(updateGroupReaction(response));
      }
    });

    return () => {
      socket.off('GROUP_RECEIVED_REACTION');
    };
  }, [
    chatUser,
    chatUser?._id,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Delete reaction from group
  useEffect(() => {
    socket.on('GROUP_REACTION_DELETED', (response: any) => {
      console.log(response, 'GROUP_REACTION_DELETED');

      if (chatUser?._id === response?.group_id) {
        dispatch(deleteGroupReaction(response));
      }
    });

    return () => {
      socket.off('GROUP_REACTION_DELETED');
    };
  }, [
    chatUser,
    chatUser?._id,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Received group audio effect
  useEffect(() => {
    socket.on('GROUP_RECEIVED_AUDIO', (response: any) => {
      console.log('GROUP_RECEIVED_AUDIO');
      receiveGroupMessageHelper({
        ...response,
        mentioned_users: response?.mentioned_users_obj,
      });
      socket.emit('CONFIRMATION', { event: 'GROUP_RECEIVED_AUDIO' });
    });

    return () => {
      socket.off('GROUP_RECEIVED_AUDIO');
    };
  }, [
    chatUser,
    chatUser?._id,
    dispatch,
    currentChatType,
    defaultWorkSpace?._id,
  ]);

  // Group leave effect
  useEffect(() => {
    socket.on('GROUP_LEAVE', (response: any) => {
      if (chatUser?.chat_type === 'group') {
        if (chatUser?._id === response?._id) {
          dispatch(removeFromGroup({ groupDetails: response }));
          setChatUser(undefined);
        }
      }

      socket.emit('CONFIRMATION', { event: 'GROUP_LEAVE' });
    });

    return () => {
      socket.off('GROUP_LEAVE');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // Unread Message Count Get Group Event
  useEffect(() => {
    socket.on('USER_SPECIFIC_GROUP_CHAT_NOTIFICATION', (response: any) => {
      console.log('USER_SPECIFIC_GROUP_CHAT_NOTIFICATION', response);
      dispatch(showUnReadGroup(response));
      socket.emit('CONFIRMATION', {
        event: 'USER_SPECIFIC_GROUP_CHAT_NOTIFICATION',
      });
    });

    return () => {
      socket.off('USER_SPECIFIC_GROUP_CHAT_NOTIFICATION');
    };
  }, [chatUser, chatUser?._id, dispatch, defaultWorkSpace?._id]);

  // ----------------------------- Online / Offline Events Start -------------------------------- //

  // Received user online event
  useEffect(() => {
    socket.on('USER_ONLINE', (response: { user_id: string }) => {
      console.log('USER_ONLINE');
      if (response.user_id === chatUser?._id) {
        setChatUser({ ...chatUser, is_online: true });
        // dispatch(setActiveChatUser({ ...chatUser, is_online: true }));
      }
      dispatch(userIsOnline(response));
    });

    return () => {
      socket.off('USER_ONLINE');
    };
  }, [chatUser, dispatch, defaultWorkSpace?._id]);

  // Received user offine event
  useEffect(() => {
    socket.on('USER_OFFLINE', (response: { user_id: string }) => {
      console.log('USER_OFFLINE');
      if (response.user_id === chatUser?._id) {
        setChatUser({ ...chatUser, is_online: false });
        // dispatch(setActiveChatUser({ ...chatUser, is_online: false }));
      }
      dispatch(userIsOffline(response));
    });

    return () => {
      socket.off('USER_OFFLINE');
    };
  }, [chatUser, dispatch, defaultWorkSpace?._id]);

  // ----------------------------- Online / Offline Events End -------------------------------- //

  // ************** BOARD COMMENT CONVERSATION EVENTS START *******************

  // NOT ONGOING BOARD COMMENT CONVERSATION
  // Board listing notification when comments added to the task
  useEffect(() => {
    socket.on('BOARD_COMMENT_NOTIFICATION', (response: any) => {
      console.log('BOARD_COMMENT_NOTIFICATION........', response);
      // Socket event fire when on going task comment
      if (chatUser?._id === response?.board_details?._id && currentTask) {
        console.log('ON_GOING_TASK_COMMENT event fireddddddd');
        socket.emit('ON_GOING_TASK_COMMENT', {
          task_id: currentTask?._id ?? '',
          date: currentTask?.date ?? '',
          user: {
            _id: currentTask?.user ?? '',
            workspace: defaultWorkSpace?._id ?? '',
          },
        });
      } else {
        console.log('Not on going comment and set board first in the list');
        dispatch(setBoardFirstInList(response));
      }
      socket.emit('CONFIRMATION', {
        event: 'BOARD_COMMENT_NOTIFICATION',
      });
    });

    return () => {
      socket.off('BOARD_COMMENT_NOTIFICATION');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // Tasks & comments realtime update when comments added to the task for Inbox tab component
  useEffect(() => {
    socket.on('TASK_COMMENT_NOTIFICATION', (response: any) => {
      console.log(
        'TASK_COMMENT_NOTIFICATION........',
        response,
        currentTask,
        currentTask?._id === response?.task_id,
        response?.comment && currentTask?._id === response?.task_id
      );
      if (
        response?.comment &&
        chatUser?._id === response?.board_id &&
        currentTask?._id === response?.task_id
      ) {
        console.log('Task comment added in listing');
        dispatch(updateCommentInTask(response?.comment));
      } else {
        dispatch(
          updateTasksInBoard({
            ...response,
            task: response?.task_detail,
            currentBoard: chatUser,
          })
        );
      }
      socket.emit('CONFIRMATION', {
        event: 'TASK_COMMENT_NOTIFICATION',
      });
    });

    return () => {
      socket.off('TASK_COMMENT_NOTIFICATION');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // Tasks & comments realtime update when comments added to the task for Inbox tab component
  useEffect(() => {
    socket.on('SELF_TASK_COMMENT', (response: any) => {
      console.log(
        'SELF_TASK_COMMENT ........',
        response,
        currentTask,
        chatUser
      );
      if (
        response?.comment &&
        chatUser?._id === response?.board_id &&
        currentTask?._id === response?.task_id
      ) {
        console.log('Task comment added to self user in listing');
        dispatch(updateCommentInTask(response?.comment));
        chatUser && dispatch(setOnGoingBoardFirst({ board_id: chatUser?._id }));
      }
      socket.emit('CONFIRMATION', {
        event: 'SELF_TASK_COMMENT',
      });
    });

    return () => {
      socket.off('SELF_TASK_COMMENT');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // ************** BOARD COMMENT CONVERSATION EVENTS END *******************

  // ************** ONGOING BOARD COMMENT CONVERSATION EVENTS START *******************

  // Board listing notification when comments added to the task
  useEffect(() => {
    socket.on('ON_GOING_BOARD_COMMENT_NOTIFICATION', (response: any) => {
      console.log('ON_GOING_BOARD_COMMENT_NOTIFICATION........', response);
      // Socket event fire when on going task comment and make un_read_count to 0
      dispatch(hideUnReadBoardCount(response));
      socket.emit('CONFIRMATION', {
        event: 'ON_GOING_BOARD_COMMENT_NOTIFICATION',
      });
    });

    return () => {
      socket.off('ON_GOING_BOARD_COMMENT_NOTIFICATION');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // Tasks & comments realtime update when comments added to the task for Inbox tab component
  useEffect(() => {
    socket.on('ON_GOING_TASK_COMMENT_NOTIFICATION', (response: any) => {
      console.log(
        'ON_GOING_TASK_COMMENT_NOTIFICATION........',
        response,
        currentTask?._id === response?.task_id,
        response?.comment && currentTask?._id === response?.task_id
      );
      // if (response?.comment && currentTask?._id === response?.task_id) {
      //   dispatch(updateCommentInTask(response?.comment));
      // }
      socket.emit('CONFIRMATION', {
        event: 'ON_GOING_TASK_COMMENT_NOTIFICATION',
      });
    });

    return () => {
      socket.off('ON_GOING_TASK_COMMENT_NOTIFICATION');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // ************** ONGOING BOARD COMMENT CONVERSATION EVENTS END *******************

  // *************************** Board & Task Live Update Start *************************************

  // called when task update
  useEffect(() => {
    socket.on('TASK_UPDATE', (response) => {
      socket.emit('CONFIRMATION', { event: 'TASK_UPDATE' });

      console.log('TASK_UPDATE........', response);

      response?.updated_task &&
        dispatch(
          updateTaskDetails({
            ...response?.updated_task,
            board_id: response?.updated_task?.board_id ?? '',
            task_id: response?.updated_task?._id ?? '',
            mark_as_done: response?.updated_task?.mark_as_done ?? false,
            mark_as_archived: response?.updated_task?.mark_as_archived ?? false,
            currentBoard: chatUser,
          })
        );
    });

    return () => {
      socket.off('TASK_UPDATE');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // called when task status update
  useEffect(() => {
    socket.on('TASK_STATUS_UPDATE', (response) => {
      socket.emit('CONFIRMATION', { event: 'TASK_STATUS_UPDATE' });
      console.log('TASK_STATUS_UPDATE......', response);
      response?.new_section &&
        dispatch(
          updateTaskDetails({
            ...response?.new_section,
            board_id: response?.board_id ?? '',
            task_id: response?.task_id ?? '',
            mark_as_done: response?.new_section?.key === 'completed',
            mark_as_archived: response?.new_section?.key === 'archived',
            currentBoard: chatUser,
          })
        );
    });

    return () => {
      socket.off('TASK_STATUS_UPDATE');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // called when task delete
  useEffect(() => {
    socket.on('TASK_DELETED', (response) => {
      socket.emit('CONFIRMATION', { event: 'TASK_DELETED' });

      console.log('TASK_DELETED........', response);
      dispatch(
        deleteTaskInBoard({
          boardId: response?.board_id ?? '',
          tasksId: response?.task_ids?.[0] ?? '',
          currentBoard: chatUser,
        })
      );
    });

    return () => {
      socket.off('TASK_DELETED');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // called when board member update
  useEffect(() => {
    socket.on('BOARD_MEMBER_UPDATE', (res) => {
      console.log(res, '......BOARD_MEMBER_UPDATE');
      socket.emit('CONFIRMATION', { event: 'BOARD_MEMBER_UPDATE' });
      // if (params.id !== res.board_id) {
      //   return;
      // }
      // dispatch(getMembersByBoardId({ boardId: params?.id })).then(
      //   (result: any) => {
      //     if (getMembersByBoardId.fulfilled.match(result)) {
      //       if (result?.payload?.success) {
      //         const memeberIds = result?.payload?.data?.map(
      //           (res: any) => res?.id
      //         );
      //         memeberIds?.includes(signIn?.user?.data?.user?._id)
      //           ? setSelectedMembers(memeberIds?.length > 0 ? memeberIds : [])
      //           : router.replace(routes?.task(defaultWorkSpace?.name));
      //       }
      //     }
      //   }
      // );
    });

    return () => {
      socket.off('BOARD_MEMBER_UPDATE');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // called when board deleted
  useEffect(() => {
    socket.on('BOARD_DELETED', (response) => {
      console.log('BOARD_DELETED........', response);
      dispatch(removeFromBoard({ ...response, boardId: response?._id ?? '' }));
      // If removed board is active conversation than removed it.
      if (chatUser?._id === response?._id) {
        setChatUser(undefined);
      }
      socket.emit('CONFIRMATION', { event: 'BOARD_DELETED' });
    });

    return () => {
      socket.off('BOARD_DELETED');
    };
  }, [chatUser, chatUser?._id, dispatch, currentTask, defaultWorkSpace?._id]);

  // *************************** Board & Task Live Update End *************************************

  return (
    <div>
      {/* <PageHeader title={pageHeader.title} className="mb-0 lg:mb-0 " /> */}
      <div className="@container">
        <div className="h-[calc(100svh-69px)] items-start @container lg:grid lg:grid-cols-12">
          {/* Mobile Screen Chat */}
          {isMobile && !chatUser && (
            <MessageList
              chatUser={{ ...chatUser }}
              setnoUserForChat={setnoUserForChat}
              setChatUser={setChatUser}
              className="col-span-12 lg:col-span-4 xl:col-span-3"
            />
          )}
          {isMobile && chatUser && (
            <InboxTabs
              chatUser={{ ...chatUser }}
              setChatUser={setChatUser}
              // className=""
              className="lg:col-span-8 xl:col-span-9"
            />
          )}

          {/* Mobile Screen Chat */}
          {!isMobile && (
            <MessageList
              chatUser={{ ...chatUser }}
              setnoUserForChat={setnoUserForChat}
              setChatUser={setChatUser}
              className="col-span-12 border-r border-[#E5E7EB] bg-white lg:col-span-4 xl:col-span-3"
            />
          )}
          {!isMobile && (
            <InboxTabs
              chatUser={{ ...chatUser }}
              setChatUser={setChatUser}
              // className=""
              className="lg:col-span-8 xl:col-span-9"
            />
          )}
        </div>
      </div>
    </div>
  );
}
