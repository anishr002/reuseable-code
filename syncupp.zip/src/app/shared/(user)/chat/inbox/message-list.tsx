'use client';

import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import EmptyBox from '@/components/ui/empty-box';
import { Input } from '@/components/ui/input';
import SimpleBar from '@/components/ui/simplebar';
import { LineGroup, Skeleton } from '@/components/ui/skeleton';
import { supportStatuses } from '@/data/support-inbox';
import { useDebouncedValue } from '@/hooks/use-debounce';
import { useMedia } from '@/hooks/use-media';
import {
  getChatBoardsList,
  removeTasksHistoryData,
  setCurrentTaskDetails,
} from '@/redux/slices/user/chat/boards/boardChatSlice';
import {
  currentChatType,
  getUserList,
  hideUnReadMessage,
  removeMessagesHistoryData,
  setShowSearchFilter,
} from '@/redux/slices/user/chat/chatSlice';
import {
  getGroupList,
  hideUnReadGroup,
  removeGroupMessagesHistoryData,
} from '@/redux/slices/user/chat/group/groupChatSlice';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  handleKeyDown,
  updateMessageFormatWithMentionUser,
} from '@/utils/common-functions';
import { getRelativeTime } from '@/utils/get-relative-time';
import rangeMap from '@/utils/range-map';
import EmptyGroup from '@public/assets/images/chat-icons/Task_empty.png';
import EmptyChat from '@public/assets/images/chat-icons/message_empty.png';
import { debounce } from 'lodash';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { PiMagnifyingGlassBold, PiPlusBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';
import CreateGroupForm from '../group/create-group';
import NewMessageModal from './new-message-modal';

interface MessageItemProps {
  isActive: any;
  setisActive: any;
  index: number;
  setChatUser: any;
  userData?: any;
  groupData?: any;
  boardData?: any;
  className?: string;
  signInUserData: any;
  status: string;
}

export function MessageItem({
  isActive,
  setisActive,
  index,
  className,
  setChatUser,
  userData,
  groupData,
  boardData,
  signInUserData,
  status,
}: MessageItemProps) {
  const isMobile = useMedia('(max-width: 1023px)', false);
  const isChat = status === 'chats';
  const isGroup = status === 'group';
  const isBoard = status === 'boards';
  const dispatch = useDispatch();
  const [previewImage, setPreviewImage] = useState({});
  const { singleGroupDetails, mentioned_users } = useSelector(
    (state: any) => state?.root?.group
  );

  // const url = routes?.support?.messageDetails(messageId);

  // console.log(
  //   'userData......',
  //   userData,
  //   'groupData......',
  //   groupData,
  //   'boardData......',
  //   boardData,
  //   'isActive....',
  //   isActive
  // );

  function handleChange(selectedUser: any, clickIndex: any) {
    // setChatUser(selectedUser);
    setisActive(clickIndex);
    dispatch(setShowSearchFilter(false));
    if (isGroup) {
      setChatUser({ ...selectedUser, chat_type: 'group' });
      dispatch(hideUnReadGroup(selectedUser));
      // dispatch(setActiveCPhatUser({ ...selectedUser, chat_type: 'group' }));
    } else if (isChat) {
      setChatUser({ ...selectedUser, chat_type: 'chat' });
      // dispatch(setActiveChatUser({ ...selectedUser, chat_type: 'chat' }));
      // Add for remove existing notification;
      const ongoingPayload = {
        from_user: signInUserData?.user?.data?.user?._id,
        to_user: selectedUser?._id,
      };
      // socket.emit('ONGOING_CHAT', ongoingPayload);
      dispatch(hideUnReadMessage(selectedUser));
    } else if (isBoard) {
      setChatUser({ ...selectedUser, chat_type: 'board' });
    }
    // router.push(url);
    if (isMobile) {
      // router.push(url);
    }
  }

  useEffect(() => {
    if (isGroup) {
      setPreviewImage(groupData);
    } else if (isChat) {
      setPreviewImage(userData);
    } else if (isBoard) {
      setPreviewImage(boardData);
    }
  }, [groupData, userData, boardData, groupData?.image_url, isGroup]);

  const getAvatarName = (data: any) => {
    let displayName = '';
    if (isGroup) {
      if (data?.group_name) {
        displayName += data?.group_name;
      }
    } else if (isChat) {
      if (data?.first_name) {
        displayName += data?.first_name;
      }
      if (data?.last_name) {
        displayName += ' ' + data?.last_name;
      }
    } else if (isBoard) {
      if (data?.project_name) {
        displayName += data?.project_name;
      }
    }
    return displayName;
  };

  const getAvatarImage = (data: any) => {
    let avatarURL;
    if (isGroup) {
      avatarURL =
        process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.image_url;
    } else if (isChat) {
      avatarURL =
        process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/' + data?.profile_image;
    } else if (isBoard) {
      avatarURL = process.env.NEXT_PUBLIC_IMAGE_URL + '/' + data?.board_image;
    }
    return avatarURL;
  };

  // Show Last Message
  const showLastMessage = (data: any) => {
    if (data?.message_type === 'message') {
      return updateMessageFormatWithMentionUser(
        data?.last_message,
        mentioned_users,
        false
      );
    }
    if (data?.message_type === 'image') {
      return 'Photo';
    }
    if (data?.message_type === 'audio') {
      return 'Audio';
    }
    if (data?.message_type === 'document') {
      return 'Document';
    }
    return '';
  };

  return (
    <div
      onClick={() =>
        handleChange(isGroup ? groupData : isChat ? userData : boardData, index)
      }
      className={cn(
        className,
        'my-1.5 flex w-full cursor-pointer items-center justify-start gap-[10px] rounded-lg border-b  p-2 hover:border-[#E5E7EB]',
        index === isActive
          ? 'border-[#42389D] bg-[#F6F5FF]'
          : 'border-[#E5E7EB] bg-white hover:bg-[#F3F4F6]'
      )}
    >
      {/* Profile Image */}
      <>
        <div className="relative h-10 w-10">
          <Avatar
            src={getAvatarImage(
              isGroup ? groupData : isChat ? userData : boardData
            )}
            name={getAvatarName(
              isGroup ? groupData : isChat ? userData : boardData
            )}
            className="border-[1.5px] border-[#DDDDDD] text-[14px] font-medium text-white"
            size="DEFAULT"
          />
          {/* Unread message count show */}
          {((isChat && userData?.unread > 0) ||
            (isGroup && groupData?.unread > 0) ||
            (isBoard && boardData?.un_read_count > 0)) && (
            <div
              className={cn(
                'poppins_font_number absolute -bottom-[2px] right-[2px] flex items-center justify-center rounded-full bg-[#E74694] text-[10px] font-medium text-white',
                (userData?.unread < 10 ||
                  groupData?.unread < 10 ||
                  boardData?.un_read_count < 10) &&
                  'h-4 w-4',
                (userData?.unread > 9 ||
                  groupData?.unread > 9 ||
                  boardData?.un_read_count > 9) &&
                  'h-[18px] w-[18px]',
                (userData?.unread > 99 ||
                  groupData?.unread > 99 ||
                  boardData?.un_read_count > 99) &&
                  'h-[22px] w-[22px]'
              )}
            >
              {userData?.unread > 99 ? `99+` : userData?.unread}
              {groupData?.unread > 99 ? `99+` : groupData?.unread}
              {boardData?.un_read_count > 99 ? `99+` : boardData?.un_read_count}
            </div>
          )}
        </div>
        {/* User Online Badge */}
        {/* Below code comment - use to show online / offlice badge */}
        {/* <div className="lg:translate-x-1/9 lg:-translate-y-1/4.5 absolute right-0 top-0 -translate-y-1/3 translate-x-1/4 transform">
            {!isGroup && (
              <Badge
                renderAsDot
                className={`ml-3 h-3 w-3 ${userData?.is_online ? 'bg-green-600' : 'bg-red-600'
                  }`}
              />
            )}
          </div> */}
      </>

      {/* Name, Last Message, Date */}
      <div className="flex w-[calc(100%-50px)] flex-col gap-1">
        <div className="flex items-center justify-between">
          <p
            className={cn(
              'max-w-[60%] truncate break-all text-sm text-[#111928]',
              (!isGroup && userData?.unread) || (isGroup && groupData?.unread)
                ? 'font-bold'
                : 'font-semibold'
            )}
          >
            {isGroup && capitalizeFirstLetter(groupData?.group_name)}
            {isChat &&
              `${capitalizeFirstLetter(
                userData?.first_name
              )} ${capitalizeFirstLetter(userData?.last_name)}`}
            {isBoard && capitalizeFirstLetter(boardData?.project_name)}
          </p>
          <p
            className={cn(
              'flex items-center gap-2 text-xs font-medium',
              index === isActive ? 'text-black' : 'text-[#4B5563]'
            )}
          >
            {isChat && getRelativeTime(userData?.last_message_date as Date)}
            {isGroup && getRelativeTime(groupData?.last_message_date as Date)}
          </p>
        </div>
        {/* Last message show */}
        <div
          className={cn(
            'flex items-center justify-start gap-2 text-xs font-medium text-[#4B5563]',
            index === isActive ? 'text-[#8C80D2]' : 'text-[#4B5563]'
          )}
        >
          {!isBoard ? (
            <p
              className="max-w-[90%] truncate break-all"
              dangerouslySetInnerHTML={{
                __html: isGroup
                  ? showLastMessage(groupData)
                  : isChat
                    ? showLastMessage(userData)
                    : '',
              }}
            ></p>
          ) : (
            <p
              className="max-w-[90%] truncate break-all"
              dangerouslySetInnerHTML={{
                __html:
                  boardData?.un_read_count > 0
                    ? `${boardData?.un_read_count} new comment${
                        boardData?.un_read_count > 1 ? 's' : ''
                      }`
                    : '',
              }}
            ></p>
          )}
        </div>
      </div>
    </div>
  );
}

interface InboxListProps {
  chatUser: any;
  setnoUserForChat: any;
  setChatUser: any;
  className?: string;
}

export default function MessageList({
  chatUser,
  setChatUser,
  setnoUserForChat,
  className,
}: Readonly<InboxListProps>) {
  const dispatch = useDispatch();
  const { openModal } = useModal();
  const [isActive, setisActive] = useState<number | any>(null);
  const [status, setStatus] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [payload, setPayload] = useState({
    skip: 0,
    limit: 15,
    search: '',
  });
  const [hasMore, sethasMore] = useState(true);
  const debouncedValue = useDebouncedValue<string>(searchQuery, 1000);
  const searchParams = useSearchParams();
  const router = useRouter();
  const path = usePathname();

  // Get Chat, Group and Boards List Data
  const chatUserSliceData = useSelector((state: any) => state.root.chat);
  const groupSliceData = useSelector((state: any) => state.root.group);
  const { boardList, getChatBoardsListLoader, totalBoardsCount } = useSelector(
    (state: any) => state.root.boardChat
  );

  // Get Chat and Group Loader
  const isLoading = useSelector(
    (state: any) => state?.root?.chat?.userListLoading
  );
  const isGroupListLoading = useSelector(
    (state: any) => state?.root?.group?.groupListLoader
  );

  // Get Login User data
  const signInUserData = useSelector((state: any) => state?.root?.signIn);

  // Get if user redirect form notification
  const redirectFornNotificationSelector = useSelector(
    (state: any) => state?.root?.chat?.redirectFromNotificaion
  );

  // Current Active user and group for chat
  // const activeChatUser = useSelector(
  //   (state: any) => state?.root?.chat?.activeChatUser
  // );

  // console.log('status.....', status, 'isActive....', isActive);
  // console.log('chatUser.....', chatUser);
  // console.log('inbox payload.....', payload);
  // console.log(
  //   'boardList.....',
  //   boardList,
  //   'getChatBoardsListLoader....',
  //   getChatBoardsListLoader,
  //   'totalBoardsCount.....',
  //   totalBoardsCount
  // );
  // console.log('hasMore.....', hasMore);

  useEffect(() => {
    if (chatUser?.chat_type === 'group') {
      // remove group's chat history data
      dispatch(removeGroupMessagesHistoryData());
    } else if (chatUser?.chat_type === 'chat') {
      // remove user's chat history data
      dispatch(removeMessagesHistoryData());
    } else if (chatUser?.chat_type === 'board') {
      // remove Board's Task history data
      dispatch(removeTasksHistoryData());
      // make current task selection null
      dispatch(setCurrentTaskDetails(null));
    }
  }, [chatUser?._id]);

  useEffect(() => {
    handleChatType('chats');
  }, []);

  // Api calls for chat, group & boards listing
  useEffect(() => {
    if (status === '') {
      return;
    }

    // Chat user Listing Api Call
    if (status === 'chats') {
      // If Chat type is Agency, Client or Team
      dispatch(
        getUserList({
          is_conversation_started: true,
          search: debouncedValue ?? '',
        })
      ).then((result: any) => {
        if (getUserList.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            // If user come from notification
            if (
              result?.payload?.data?.length > 0 &&
              redirectFornNotificationSelector?.from_user !== ''
            ) {
              const index = result?.payload?.data?.findIndex(
                (data: any) =>
                  data?._id === redirectFornNotificationSelector?.from_user
              );
              if (index > -1) {
                // select that user
                setChatUser({
                  ...result?.payload?.data?.[index],
                  chat_type: 'chat',
                });
                // dispatch(setActiveChatUser(result?.payload?.data?.[index]));
                // Blank notification redirection
                // dispatch(
                //   redirectFornNotification({
                //     redirectFromNotificaion: { user_type: '', from_user: '' },
                //   })
                // );
              }
            }

            // If User Come Form Mail Notification
            if (
              result?.payload?.data?.length > 0 &&
              searchParams.get('user_id')
            ) {
              const index = result?.payload?.data?.findIndex(
                (data: any) => data?._id === searchParams.get('user_id')
              );
              if (index > -1) {
                setChatUser({
                  ...result?.payload?.data?.[index],
                  chat_type: 'chat',
                });
                // Remove id from queryparams
                router.push(path);
              }
            }

            if (result?.payload?.data?.length === 0) {
              setnoUserForChat(true);
            }
          }
        }
      });
      return;
    }

    // Group user Listing Api Call
    if (status === 'group') {
      // Group API call
      dispatch(getGroupList({ search: debouncedValue ?? '' })).then(
        (result: any) => {
          if (getGroupList.fulfilled.match(result)) {
            // If user come from notification
            if (
              result?.payload?.data?.final_group_array?.length > 0 &&
              redirectFornNotificationSelector?.from_user !== ''
            ) {
              const index = result?.payload?.data?.final_group_array?.findIndex(
                (data: any) =>
                  data?._id === redirectFornNotificationSelector?.from_user
              );
              if (index > -1) {
                // select that group
                setChatUser({
                  ...result?.payload?.data?.[index],
                  chat_type: 'group',
                });
              }
            }

            // If User Come Form Mail Notification
            if (
              result?.payload?.data?.final_group_array?.length > 0 &&
              searchParams.get('group_id')
            ) {
              const index = result?.payload?.data?.final_group_array?.findIndex(
                (data: any) => data?._id === searchParams.get('group_id')
              );
              console.log(index, 'index');
              if (index > -1) {
                setChatUser({
                  ...result?.payload?.data?.[index],
                  chat_type: 'group',
                });
                // Remove id from queryparams
                router.push(path);
                // dispatch(setActiveChatUser(result?.payload?.data?.[index]));
              }
            }
          }
        }
      );
      return;
    }
  }, [dispatch, debouncedValue, status, redirectFornNotificationSelector]);

  // Board listing api call handling
  useEffect(() => {
    if (status === '') {
      return;
    }

    // Boards Listing Api Call
    if (status === 'boards') {
      console.log('payload change api call.....', payload);
      // If Chat type is Boards
      dispatch(getChatBoardsList(payload)).then((result: any) => {
        if (getChatBoardsList.fulfilled.match(result)) {
          if (result && result?.payload?.success === true) {
            if (result?.payload?.data?.length === 0) {
              setnoUserForChat(true);
            }
          }
        }
      });
      return;
    }
  }, [dispatch, status, payload?.skip, payload?.search]);

  const setActiveTab = (userList: any[]) => {
    if (userList?.length === 0) {
      return;
    }

    if (status === 'chats' || status === 'group' || status === 'boards') {
      // Check for selected chat, group or boards current conversation
      const index = userList?.findIndex(
        (data: any) => data?._id === chatUser?._id
      );
      if (index > -1) {
        setisActive(index);
      }
    }
  };

  useEffect(() => {
    if (status === 'chats') {
      setActiveTab(chatUserSliceData?.userChatList);
    } else if (status === 'group') {
      setActiveTab(groupSliceData?.groupList);
    } else if (status === 'boards') {
      setActiveTab(boardList);
    }
  }, [chatUserSliceData?.userChatList, groupSliceData?.groupList, boardList]);

  useEffect(() => {
    if (searchParams.get('group_id')) {
      handleChatType('group');
    }
    if (searchParams.get('user_id')) {
      handleChatType('chats');
    }
  }, []);

  // search logic start
  const onSearchChange = (event: any) => {
    const query = event?.target?.value?.trim();
    setSearchQuery(query);
  };

  useEffect(() => {
    if (status === 'boards') {
      setPayload({
        skip: 0,
        limit: 15,
        search: debouncedValue ?? '',
      });
    }
  }, [debouncedValue, status, dispatch]);

  // Clear search
  const onSearchClear = () => {
    setSearchQuery('');
    if (status === 'boards') {
      setPayload({
        skip: 0,
        limit: 15,
        search: '',
      });
    }
    // setSearchResults([]);
  };

  // search logic end

  // Handle tab change function for chats, group & boards
  const handleChatType = (chatType: string) => {
    setisActive(null);
    setSearchQuery('');
    setStatus(chatType);
    dispatch(currentChatType(chatType));
    setPayload({
      skip: 0,
      limit: 15,
      search: '',
    });
  };

  //Infinite Scroll Handler
  const fetchMoreData = () => {
    // 10px buffer to trigger loading
    if (boardList?.length < totalBoardsCount) {
      sethasMore(true);
      setPayload({
        ...payload,
        skip: boardList?.length, // Increment skip for next batch
      });
    } else {
      sethasMore(false); // No more data to load
    }
  };

  // Load more functionality logic for fetching listing
  const handleScroll = debounce((e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreData();
    }
  }, 300);

  return (
    <div className={cn(className, 'sticky')}>
      {/* Tabs - Chats, Group & Boards */}
      <div className="h-[64px] items-center justify-center border-b border-[#E5E7EB]">
        <div className="flex h-full items-center justify-center gap-4">
          <div className="flex h-[32px] justify-between overflow-hidden rounded-lg bg-[#F3F4F6]">
            <button
              className={cn(
                'h-[32px] w-full rounded-lg px-3 py-1 text-[14px] font-medium transition duration-300 focus:outline-none',
                status === supportStatuses?.chats
                  ? 'border border-[#D1D5DB] bg-white text-black'
                  : ' bg-transparent text-[#4B5563]'
              )}
              onClick={() => handleChatType('chats')}
            >
              Chats
            </button>
            <button
              className={cn(
                'h-[32px] w-full rounded-lg px-3 py-1 text-[14px] font-medium transition duration-300 focus:outline-none',
                status === supportStatuses.group
                  ? 'border border-[#D1D5DB] bg-white text-black'
                  : 'bg-transparent text-[#4B5563]'
              )}
              onClick={() => handleChatType('group')}
            >
              Groups
            </button>
            <button
              className={cn(
                'h-[32px] w-full rounded-lg px-3 py-1 text-[14px] font-medium transition duration-300 focus:outline-none',
                status === supportStatuses.boards
                  ? 'border border-[#D1D5DB] bg-white text-black'
                  : 'bg-transparent text-[#4B5563]'
              )}
              onClick={() => handleChatType('boards')}
            >
              Boards
            </button>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="h-[49px] items-center justify-between border-b border-[#E5E7EB] px-4">
        <div className="flex h-full items-center justify-center">
          <div className="relative flex w-full items-center justify-center">
            <Input
              type="text"
              placeholder={
                status === 'chats'
                  ? 'Search chats'
                  : status === 'boards'
                    ? 'Search boards'
                    : 'Search groups'
              }
              className="search_chat_input w-full rounded-[6px]"
              value={searchQuery}
              onClear={onSearchClear}
              onChange={onSearchChange}
              onKeyDown={handleKeyDown}
              clearable={true}
              variant="text"
              inputClassName="text-[#4B5563] !p-2"
              prefix={
                <PiMagnifyingGlassBold className="h-5 w-5 text-[#4B5563]" />
              }
            />

            {/* New Message Button */}
            {status === 'chats' && (
              <div className="h-6 w-6">
                <button
                  title="New chat"
                  className="flex h-6 w-6 items-center justify-center rounded-full bg-[#7667CF] text-white"
                  onClick={() => {
                    openModal({
                      view: (
                        <NewMessageModal
                          title="New Chat"
                          setChatUser={setChatUser}
                        />
                      ),
                      customSize: '625px',
                    });
                  }}
                >
                  <PiPlusBold className="h-[14px] w-[14px]" />
                </button>
              </div>
            )}

            {/* New Group Button */}
            {status === 'group' &&
              (['team_agency', 'team_client'].includes(signInUserData?.role)
                ? checkPermission(
                    'chats',
                    'group',
                    'create',
                    signInUserData?.permission
                  )
                : ['agency', 'client'].includes(signInUserData?.role)) && (
                <div className="h-6 w-6">
                  <button
                    title="New group"
                    className="flex h-6 w-6 items-center justify-center rounded-full bg-[#7667CF] text-white"
                    onClick={() => {
                      openModal({
                        view: (
                          <CreateGroupForm
                            title="New Group"
                            canUpdate={true}
                            isEdit={false}
                          />
                        ),
                        customSize: '600px',
                      });
                    }}
                  >
                    <PiPlusBold className="h-[14px] w-[14px]" />
                  </button>
                </div>
              )}
          </div>
        </div>
      </div>

      {/* Listing of Chats, Groups & Boards */}
      <SimpleBar
        className="h-[calc(100dvh-356px)] px-4 md:h-[calc(100dvh-296px)] lg:h-[calc(100dvh-185px)]"
        onScrollCapture={handleScroll}
      >
        {((isLoading && status === 'chats') ||
          (isGroupListLoading && status === 'group') ||
          (getChatBoardsListLoader &&
            status === 'boards' &&
            payload?.skip === 0)) && (
          <div className="grid gap-2">
            {rangeMap(10, (i) => (
              <MessageLoader key={i} />
            ))}
          </div>
        )}

        {/* Single Chat User Listing */}
        {!isLoading &&
          status === 'chats' &&
          chatUserSliceData?.userChatList?.length > 0 &&
          chatUserSliceData?.userChatList?.map(
            (userData: any, index: number) => (
              <MessageItem
                isActive={isActive}
                setisActive={setisActive}
                key={userData?._id}
                index={index}
                signInUserData={signInUserData}
                setChatUser={setChatUser}
                userData={userData}
                status={status}
              />
            )
          )}

        {/* Group list */}
        {!isGroupListLoading &&
          status === 'group' &&
          groupSliceData?.groupList?.length > 0 &&
          groupSliceData?.groupList?.map((group: any, index: number) => (
            <MessageItem
              isActive={isActive}
              setisActive={setisActive}
              key={group._id}
              index={index}
              signInUserData={signInUserData}
              setChatUser={setChatUser}
              groupData={group}
              status={status}
            />
          ))}

        {/* Boards list */}
        {(!getChatBoardsListLoader || payload?.skip > 0) &&
          status === 'boards' &&
          boardList?.length > 0 &&
          boardList?.map((board: any, index: number) => (
            <MessageItem
              isActive={isActive}
              setisActive={setisActive}
              key={board?._id}
              index={index}
              signInUserData={signInUserData}
              setChatUser={setChatUser}
              boardData={board}
              status={status}
            />
          ))}

        {/* Load more api call loading show */}
        {getChatBoardsListLoader &&
          status === 'boards' &&
          payload?.skip !== 0 && (
            <Button
              variant="text"
              size="lg"
              isLoading={true}
              className="flex w-full items-center justify-center"
            />
          )}

        {/* If Grop or User list is empty */}
        {((!isLoading &&
          chatUserSliceData?.userChatList?.length === 0 &&
          status === 'chats') ||
          (!isGroupListLoading &&
            groupSliceData?.groupList?.length === 0 &&
            status === 'group') ||
          (!getChatBoardsListLoader &&
            boardList?.length === 0 &&
            status === 'boards')) && (
          <div className="mb-4 mt-[84px] flex min-h-[calc(100dvh-390px)] items-start justify-center md:min-h-[calc(100dvh-330px)] lg:min-h-[calc(100dvh-217px)]">
            <EmptyBox
              imageIcon={status === 'chats' ? EmptyChat : EmptyGroup}
              text={`No ${
                status === 'group'
                  ? 'groups found'
                  : status === 'chats'
                    ? 'conversations found'
                    : 'boards found'
              }`}
            >
              <div className="flex flex-col items-center justify-center gap-2">
                {(status === 'group' || status === 'chats') && (
                  <div className="text-xs font-normal text-black">
                    {status === 'group'
                      ? 'Create new group'
                      : 'Create new chat'}
                  </div>
                )}
                {/* New Message Button */}
                {status === 'chats' && (
                  <button
                    title="New chat"
                    className="flex items-center justify-center gap-1 rounded bg-[#7667CF] px-2 py-1 text-white"
                    onClick={() => {
                      openModal({
                        view: (
                          <NewMessageModal
                            title="New Chat"
                            setChatUser={setChatUser}
                          />
                        ),
                        customSize: '625px',
                      });
                    }}
                  >
                    <PiPlusBold className="size-3 !text-white" />{' '}
                    <span>New chat</span>
                  </button>
                )}
                {/* New Group Button */}
                {status === 'group' &&
                  (['team_agency', 'team_client'].includes(signInUserData?.role)
                    ? checkPermission(
                        'chats',
                        'group',
                        'create',
                        signInUserData?.permission
                      )
                    : ['agency', 'client'].includes(signInUserData?.role)) && (
                    <button
                      title="New group"
                      className="flex items-center justify-center gap-1 rounded bg-[#7667CF] px-2 py-1 text-white"
                      onClick={() => {
                        openModal({
                          view: (
                            <CreateGroupForm
                              title="New Group"
                              canUpdate={true}
                              isEdit={false}
                            />
                          ),
                          customSize: '600px',
                        });
                      }}
                    >
                      <PiPlusBold className="size-3 !text-white" />
                      <span>New group</span>
                    </button>
                  )}
              </div>
            </EmptyBox>
          </div>
        )}
      </SimpleBar>
    </div>
  );
}

// Message Loader
export function MessageLoader() {
  return (
    <div className="grid gap-3 p-2">
      <div className="flex items-center gap-2">
        <Skeleton className="h-6 w-6 rounded" />
        <Skeleton className="h-3 w-32 rounded" />
        <Skeleton className="h-3 w-3 rounded-full" />
        <Skeleton className="ml-auto h-3 w-16 rounded" />
      </div>
      <LineGroup
        columns={6}
        className="grid-cols-6 gap-1.5"
        skeletonClassName="h-2"
      />
    </div>
  );
}
