import AudioIcon from '@/components/icons/AudioIcon';
import PPTIcon from '@/components/icons/PPTIcon';
import ZIPIcon from '@/components/icons/ZIPIcon';
import DocIcon from '@/components/icons/doc-solid';
import ImageIcon from '@/components/icons/image-solid';
import PDFIcon from '@/components/icons/pdf-solid';
import VideoIcon from '@/components/icons/video-solid';
import XMLIcon from '@/components/icons/xml-solid';
import cn from '@/utils/class-names';
import { GoFile } from 'react-icons/go';

export function FileIcons({
  fileType,
  fileName,
  className,
  fileNameClass,
}: {
  fileType: any;
  fileName?: string;
  className?: string;
  fileNameClass?: string;
}) {
  return (
    <div
      className={cn(
        className,
        'relative flex flex-row-reverse items-center justify-center gap-[10px] rounded-lg bg-white p-4 opacity-80'
      )}
    >
      {fileType && (
        <div className="h-5 w-5">
          {fileType === 'PDFIcon' && <PDFIcon className="h-5 w-5" />}
          {fileType === 'DocIcon' && <DocIcon className="h-5 w-5" />}
          {fileType === 'XMLIcon' && <XMLIcon className="h-5 w-5" />}
          {fileType === 'IMGIcon' && <ImageIcon className="h-5 w-5" />}
          {fileType === 'MP4Icon' && <VideoIcon className="h-5 w-5" />}
          {fileType == 'AudioIcon' && <AudioIcon className="h-5 w-5" />}
          {fileType === 'PPTIcon' && <PPTIcon className="h-5 w-5" />}
          {fileType === 'ZIPIcon' && <ZIPIcon className="h-5 w-5" />}
          {fileType === 'text' && <DocIcon className="h-5 w-5" />}
          {fileType === 'unknown' && (
            <GoFile className="h-5 w-5 text-black" />
          )}
        </div>
      )}
      <p
        className={cn(
          'w-full truncate break-all text-left text-sm font-medium text-gray-700',
          fileNameClass
        )}
        dir="ltr"
        title={fileName ?? ''}
      >
        {fileName}
      </p>
    </div>
  );
}
