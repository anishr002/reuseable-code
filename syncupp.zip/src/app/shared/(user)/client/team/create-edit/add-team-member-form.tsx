'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { PhoneNumber } from '@/components/ui/phone-input';
import SelectBox from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import { emailCheck } from '@/redux/slices/user/auth/authSlice';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import { getRolesList } from '@/redux/slices/user/roles-permissions/rolePermissionSlice';
import {
  addClientTeamMember,
  editTeamMember,
  getAllTeamMember,
  getTeamMemberProfile,
} from '@/redux/slices/user/team-member/teamSlice';
import cn from '@/utils/class-names';
import { capitalizeAndJoin, capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import {
  addTeamMemberFormTourStepsContent,
  getStepsByRole,
} from '@/utils/tour-steps/tour-steps';
import {
  TeamMemberSchema,
  teamMemberSchema,
} from '@/utils/validators/add-team-member.schema';
import { useEffect, useState } from 'react';
import { Controller, SubmitHandler } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import { checkPermission } from '../../../roles-permissions/utils';

// const Select = dynamic(() => import('@/components/ui/select'), {
//   ssr: false,
//   loading: () => <SelectLoader />,
// });

const typeOption = [
  { name: 'Team member', value: 'team_member' },
  { name: 'Admin', value: 'admin' },
];

export default function AddTeamMemberForm(props: any) {
  const { title, row, isEdit } = props;
  const [userExist, setUserExist] = useState(false);
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const [save, setSave] = useState(false);
  const [loader, setLoader] = useState(false);
  const [reset, setReset] = useState({});
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const { getRolesListData } = useSelector((state: any) => state?.root?.rolePermission);

  const initialValues: TeamMemberSchema = {
    email: '',
    first_name: '',
    last_name: '',
    contact_number: '',
    role:
      signIn?.role === 'client' || signIn?.role === 'team_client'
        ? 'Team member'
        : '',
  };
  // console.log("Row data....", row)

  console.log(teamMemberData?.addTeamMemberLoader, 'addTeamMemberLoader');
  console.log(teamMemberData?.editTeamMemberLoader, 'editTeamMemberLoader');
  console.log(save, 'save');

  useEffect(() => {
    row && dispatch(getTeamMemberProfile({ _id: row?._id }));
  }, [row, dispatch]);

  // Api call for Tour status get
  useEffect(() => {
    // Tour comment
    dispatch(getAllTourStatus());
    dispatch(getRolesList({ role: 'team_client' }));
  }, []);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [teamMemberFormTourSteps, setTeamMemberFormTourSteps] = useState([]);

  // Handle close tour
  const handleTeamMemberCloseTour = () => {
    dispatch(
      updateTourStatus({ team_member: { view_team_member_tour: true } })
    ).then((result: any) => {
      if (updateTourStatus.fulfilled.match(result)) {
        if (result?.payload?.success) {
          setIsTourOpen(false);
          // Tour comment
          dispatch(getAllTourStatus());
        }
      }
    });
  };

  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.team_member &&
      !tourStatusData?.team_member?.view_team_member_tour
    ) {
      setTeamMemberFormTourSteps([]);
      setIsTourOpen(false);
      const addTeamMemberFormTourStepContent =
        addTeamMemberFormTourStepsContent(handleTeamMemberCloseTour, signIn, checkPermission);

      const updatedTeamMemberFormTourSteps = getStepsByRole(addTeamMemberFormTourStepContent);
      updatedTeamMemberFormTourSteps?.length > 0 && setTeamMemberFormTourSteps(updatedTeamMemberFormTourSteps);
      updatedTeamMemberFormTourSteps?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData, signIn?.permission]);

  let data = teamMemberData?.teamMember ?? {};
  let defaultValuess = {};
  if (Object.keys(data)?.length > 0) {
    defaultValuess = {
      first_name: data?.first_name,
      last_name: data?.last_name,
      email: data?.email,
      contact_number: data?.contact_number,
      role: data?.sub_role?._id ?? ''
    };
  } else {
    defaultValuess = {
      first_name: '',
      last_name: '',
      email: '',
      contact_number: '',
      role: '',
    };
  }

  console.log(defaultValuess, '......defaultValuess');

  const onSubmit: SubmitHandler<TeamMemberSchema> = (dataa) => {
    let formData = {};
    setSave(true);
    if (!isEdit) {
      formData = {
        first_name: dataa?.first_name ?? '',
        last_name: dataa?.last_name ?? '',
        email: dataa?.email?.toLowerCase() ?? '',
        contact_number: dataa?.contact_number ?? '',
        role: dataa?.role
        // agency_id: clientSliceData?.agencyId,
      };
    } else {
      formData = {
        first_name: dataa?.first_name ?? '',
        last_name: dataa?.last_name ?? '',
        email: dataa?.email?.toLowerCase()?.trim() ?? '',
        contact_number: dataa?.contact_number ?? '',
        role: dataa?.role
        // agency_id: clientSliceData?.agencyId,
      };
    }
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(
        ([_, value]) => value !== undefined && value !== ''
      )
    );

    const fullData = { ...filteredFormData };
    console.log(fullData, 'fullData');
    if (!isEdit) {
      dispatch(addClientTeamMember(fullData)).then((result: any) => {
        if (addClientTeamMember.fulfilled.match(result)) {
          setLoader(false);
          setSave(false);
          console.log('result', result);
          if (result && result.payload.success === true) {
            save && closeModal();
            setReset({ ...initialValues });

            if (signIn?.role === 'client' || signIn?.role === 'team_client') {
              dispatch(
                getAllTeamMember({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                })
              );
            } else {
              dispatch(
                getAllTeamMember({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                })
              );
            }
            setSave(false);
          }
        }
      });
    } else {
      dispatch(editTeamMember({ ...fullData, _id: data._id })).then(
        (result: any) => {
          if (editTeamMember.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              save && closeModal();
              setSave(false);
              if (signIn?.role === 'client' || signIn?.role === 'team_client') {
                dispatch(
                  getAllTeamMember({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    agency_id: clientSliceData?.agencyId,
                    pagination: true,
                  })
                );
              } else {
                dispatch(
                  getAllTeamMember({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    pagination: true,
                  })
                );
              }
            }
          }
        }
      );
    }
  };

  const clearFormValue = (setValue: any) => {
    // setValue('first_name', '');
    // setValue('last_name', '');
    // setValue('contact_number', '');
    setUserExist(false);
  };

  // On email change check email is already register or not
  const handleEmailChange = async (e: any, setValue: any, clearErrors: any) => {
    const email = e.target.value;
    try {
      if (!email) {
        clearFormValue(setValue);
        return;
      }

      const response = await dispatch(
        emailCheck({ email: email?.toLowerCase()?.trim() })
      );
      if (response?.payload?.success) {
        const user = response.payload.data;
        if (user.status == 'signup_completed' || !!user?.email) {
          setValue('first_name', user?.first_name);
          setValue('last_name', user?.last_name);
          setValue('contact_number', user?.contact_number);
          setUserExist(true);
          clearErrors();
        } else {
          clearFormValue(setValue);
        }
      } else {
        clearFormValue(setValue);
      }
    } catch (error) {
      console.error('Error validating email:', error);
      // setEmailValidationMessage('Error validating email.');
    }
  };

  const handleSaveClick = () => {
    setSave(true);
  };
  if (!teamMemberData?.teamMember && title === 'Edit Team member') {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <>
        <Tour
          steps={teamMemberFormTourSteps ?? []}
          isOpen={isTourOpen}
          rounded={10}
          closeWithMask={false}
          disableInteraction={true}
          disableKeyboardNavigation={['esc']}
          onRequestClose={handleTeamMemberCloseTour}
          className="poppins_font_number font-semibold text-black tour-close-button"
        />
        <Form<TeamMemberSchema>
          validationSchema={teamMemberSchema}
          onSubmit={onSubmit}
          resetValues={reset}
          useFormProps={{
            mode: 'onSubmit',
            defaultValues: defaultValuess,
          }}
          className="placeholder_color p-10 [&_label]:font-medium"
        >
          {({
            register,
            setValue,
            control,
            formState: { errors, isSubmitSuccessful },
            handleSubmit,
            clearErrors,
          }) => (
            <div className="space-y-5">
              <div className="mb-6 flex items-center justify-between">
                <Title
                  as="h3"
                  className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
                >
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>
              <div
                className={cn(
                  'team-member-form-tour-step-one grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                )}
              >
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    First Name *
                  </label>
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    color="info"
                    placeholder="Enter First Name"
                    // size={'xl'}
                    {...register('first_name')}
                    error={errors.first_name?.message as string}
                    disabled={userExist || isEdit}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Last Name *
                  </label>
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    color="info"
                    placeholder="Enter Last Name"
                    // size={'xl'}
                    {...register('last_name')}
                    error={errors.last_name?.message as string}
                    disabled={userExist || isEdit}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Email Address*
                  </label>

                  <Input
                    type="email"
                    onKeyDown={handleKeyDown}
                    color="info"
                    // size={'xl'}
                    placeholder="Enter Your Email"
                    disabled={isEdit}
                    {...register('email')}
                    error={errors.email?.message as string}
                    onChange={(e) => {
                      handleEmailChange(e, setValue, clearErrors);
                      register('email').onChange(e);
                    }}
                  />
                </div>

                {/* <Input
                  type="text"
                  onKeyDown={handleKeyContactDown}
                  label="Phone"
                  color="info"
                  placeholder="Enter phone number"
                  className="[&>label>span]:font-medium"
                  {...register('contact_number')}
                  error={errors.contact_number?.message as string}
                /> */}
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Phone Number
                  </label>
                  <Controller
                    name="contact_number"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <PhoneNumber
                        country="us"
                        // size={'xl'}
                        className="rounded-xl [&>label>span]:font-medium"
                        value={value}
                        onChange={onChange}
                        error={errors.contact_number?.message as string}
                        disabled={userExist || isEdit}
                      />
                    )}
                  />
                </div>
              </div>
              <div
                className={cn(
                  'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                )}
              >
                <div className="team-member-form-tour-step-two team-member-form-tour-step-three">
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Role *
                  </label>

                  <Controller
                    name="role"
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      <SelectBox
                        // size={'xl'}
                        options={getRolesListData}
                        value={value}
                        onChange={onChange}
                        placeholder="Select Role"
                        color="info"
                        // disabled={
                        //   signIn?.role === 'client' ||
                        //   signIn?.role === 'team_client'
                        // }
                        getOptionValue={(option) => option?._id}
                        getOptionDisplayValue={(option: any) => capitalizeAndJoin(option?.sub_role as string)}
                        displayValue={(value) => {
                          const selectedOption = getRolesListData.find((role: any) => role._id === value);
                          return selectedOption ? capitalizeAndJoin(selectedOption.sub_role) : '';
                        }}
                        error={errors?.role?.message as string}
                        className="rounded-xl capitalize"
                        optionClassName='poppins_font_number'
                        selectClassName="capitalize poppins_font_number"
                      />
                    )}
                  />
                </div>
              </div>
              {/* save changes button */}
              <div className="mt-2 lg:mt-16">
                <Button
                  onClick={handleSaveClick}
                  disabled={
                    (teamMemberData?.addTeamMemberLoader ||
                      teamMemberData?.editTeamMemberLoader) &&
                    save
                  }
                  className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                  type="submit"
                  size="xl"
                >
                  <span>Save Changes</span>
                  {(teamMemberData?.addTeamMemberLoader ||
                    teamMemberData?.editTeamMemberLoader) &&
                    save && (
                      <Spinner
                        size="sm"
                        tag="div"
                        className="ms-3"
                        color="white"
                      />
                    )}
                </Button>
              </div>
            </div>
          )}
        </Form>
      </>
    );
  }
}
