'use client';

import Link from 'next/link';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Checkbox } from '@/components/ui/checkbox';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon, Badge, Button, Popover, Tooltip } from 'rizzui';
import EyeIcon from '@/components/icons/eye';

import moment from 'moment';
import { routes } from '@/config/routes';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { SlOptions } from 'react-icons/sl';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  handlecustomeSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const ClientInvoiceColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  handlecustomeSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const { invoiceDetails, loading } = useSelector(
    (state: any) => state?.root?.clieninvoice
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  function getStatusBadge(status: string) {
    switch (status?.toLowerCase()) {
      case 'overdue':
        return (
          <div
            className={`status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm`}
          >
            <Badge className="bg-[#AC2D2D]" renderAsDot />
            <Text className="font-medium text-[#AC2D2D]">Overdue</Text>
          </div>
        );
      case 'paid':
        return (
          <div className="status_pad flex cursor-not-allowed items-center justify-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
            <Badge className="bg-[#527C31]" renderAsDot />
            <Text className="font-medium text-[#527C31]">Paid</Text>
          </div>
        );
      case 'unpaid':
        return (
          <div
            className={`status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFEAC3] px-[20px] py-[8px] text-xs sm:text-sm`}
          >
            <Badge className="bg-[#8C6825]" renderAsDot />
            <Text className="font-medium text-[#8C6825]">Unpaid</Text>
          </div>
        );
      case 'draft':
        return (
          <div
            className={`status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#CBE3FB] px-[20px] py-[8px] text-xs sm:text-sm`}
          >
            <Badge className="bg-[#43688D]" renderAsDot />
            <Text className="font-medium text-[#43688D]">Draft</Text>
          </div>
        );
      default:
        return (
          <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-gray-200 px-[20px] py-[8px] text-xs sm:text-sm">
            <Badge renderAsDot className="bg-gray-400" />
            <Text className="font-medium text-gray-600">
              {capitalizeFirstLetter(status)}
            </Text>
          </div>
        );
    }
  }

  return [
    // {
    //     title: (
    //         <div className="ps-3.5">
    //             <Checkbox
    //                 title={'Select All'}
    //                 onChange={handlecustomeSelectAll}
    //                 checked={checkedItems.length === data.length}
    //                 className="cursor-pointer"

    //             />
    //         </div>
    //     ),
    //     dataIndex: 'checked',
    //     key: 'checked',
    //     width: 50,
    //     render: (_: any, row: any) => (
    //         < div className="inline-flex ps-3.5" >
    //             {<Checkbox
    //                 className="cursor-pointer"
    //                 checked={checkedItems.includes(row._id)}
    //                 {...(onChecked && { onChange: () => onChecked(row._id) })}
    //             />}
    //         </div >
    //     ),
    // },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Number"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'invoice_number'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('invoice_number'),
      dataIndex: 'invoice_number',
      key: 'invoice_number',
      width: 100,
      render: (value: string) => (
        <Text className=" poppins_font_number mr-1 font-medium capitalize text-black">
          {value && value != '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Amount"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'total'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('total'),
      dataIndex: 'total',
      key: 'total',
      width: 100,
      render: (value: string, row: any) => (
        <Text className="poppins_font_number font-medium text-black">
          {value && value != '' ? row?.currency_symbol + ' ' + value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Invoice Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'invoice_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('invoice_date'),
      dataIndex: 'invoice_date',
      key: 'invoice_date',
      width: 100,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium text-black">
          {value && value != '' ? moment(value).format('DD MMM, YYYY') : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Due Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'due_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('due_date'),
      dataIndex: 'due_date',
      key: 'due_date',
      width: 100,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium text-black">
          {value && value != '' ? moment(value).format('DD MMM, YYYY') : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Status"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (value: string) => (
        <div className="flex items-center justify-center">
          {' '}
          {getStatusBadge(value && value != '' ? value : '-')}
        </div>
      ),
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Action" align="center" />,
      dataIndex: 'action',
      key: 'action',
      width: 50,
      render: (_: string, row: Record<string, string>) => (
        <div className="flex items-center justify-center">
          <Popover
            placement="top-start"
            className="demo_test flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
            content={({ setOpen }) => (
              <div>
                <Link
                  href={routes.clients.invoicedetails(
                    defaultWorkSpace?.name,
                    row?._id
                  )}
                >
                  <Button
                    // type="button"
                    variant="text"
                    className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                    // aria-label={'View Agreement'}
                  >
                    View Invoice
                  </Button>
                </Link>
              </div>
            )}
          >
            <ActionIcon title="More Options" variant="text">
              <SlOptions className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
            </ActionIcon>
          </Popover>
        </div>
      ),
    },
  ];
};
