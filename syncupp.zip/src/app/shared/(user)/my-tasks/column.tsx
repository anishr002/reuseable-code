'use client';

import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { DatePicker } from '@/components/ui/datepicker';
import { Popover } from '@/components/ui/popover';
import Spinner from '@/components/ui/spinner';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { routes } from '@/config/routes';
import { getAllMyTasks } from '@/redux/slices/user/dashboard/dashboardSlice';
import { getMembersByBoardId } from '@/redux/slices/user/task/boardSlice';
import { patchEditTask } from '@/redux/slices/user/task/taskSlice';
import { putTaskKanbanStatusChange } from '@/redux/slices/user/task/taskStatusSlice';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  convertSecondsToTime,
} from '@/utils/common-functions';
import moment from 'moment';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { FiStopCircle } from 'react-icons/fi';
import {
  IoIosCheckmarkCircle,
  IoIosCheckmarkCircleOutline,
} from 'react-icons/io';
import { LuUser2 } from 'react-icons/lu';
import { PiCalendarBlankLight } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Avatar, Button, Checkbox, Input, Tooltip } from 'rizzui';
import { checkPermission } from '../roles-permissions/utils';
import TimerDisplay from '../task/taskTimer';

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E5E7EB]',
    label: (
      <div className="flex items-center  rounded-3xl bg-[#E5E7EB] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="success" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-[#111928]">
          Low
        </Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FFF3B6]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FFF3B6] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="warning" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-[#9A6F00]">
          Medium
        </Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFEFF1]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FFEFF1] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="danger" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-[#C92F54]">
          High
        </Text>
      </div>
    ),
  },
];

type Columns = {
  data: any[];
  sortConfig?: any;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  checkedItems: string[];
  handleBoardTaskSelectAll?: any;
};

function getPriorityStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'low':
      return (
        <div className="status_pad flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-[#E5E7EB] px-[20px] py-[8px] text-xs sm:text-sm">
          <Text className="poppins_font_number font-medium text-[#111928]">
            Low
          </Text>
        </div>
      );
    case 'medium':
      return (
        <div className="status_pad flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-[#FFF3B6] px-[20px] py-[8px] text-xs sm:text-sm">
          <Text className="poppins_font_number font-medium text-[#9A6F00]">
            Medium
          </Text>
        </div>
      );
    case 'high':
      return (
        <div className="status_pad flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-[#FFEFF1] px-[20px] py-[8px] text-xs sm:text-sm">
          <Text className="poppins_font_number font-medium text-[#C92F54]">
            High
          </Text>
        </div>
      );

    default:
      return (
        <div className="status_pad flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-gray-300 px-[20px] py-[8px] text-xs sm:text-sm">
          <Text className="poppins_font_number ms-2 font-medium text-gray-600">
            {status}
          </Text>
        </div>
      );
  }
}

export const GetColumns = ({
  data,
  onHeaderCellClick,
  sortConfig,
  onChecked,
  checkedItems,
  handleBoardTaskSelectAll,
}: Readonly<Columns>) => {
  const dispatch = useDispatch();
  const [endActiveTaskId, setEndActiveTaskId] = useState(null);
  const { getAllMyTasksLoader } = useSelector(
    (state: any) => state?.root?.dashbord
  );
  const { loading: taskLoading } = useSelector(
    (state: any) => state?.root?.task
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [selectedDueDate, setSelectedDueDate] = useState<any>(null);

  const [showSaveButton, setShowSaveButton] = useState<any>(false); // New state for Save button
  const [isOpenPopOver, setIsOpenPopOver] = useState(false); // New state for Save button
  const router = useRouter();

  useEffect(() => {
    setSelectedDueDate(null);
    setShowSaveButton(false);
  }, [isOpenPopOver]);

  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [title, setTitle] = useState<string>('');
  const [error, setError] = useState<string>('');

  let clickTimeout: NodeJS.Timeout | null = null;

  const handleSingleClick = (row: any) => {
    if (clickTimeout) return; // Prevent single-click execution if double-click happens

    clickTimeout = setTimeout(() => {
      router.push(
        `${routes.boardDetails(
          defaultWorkSpace?.name,
          row?.board_id
        )}?task_id=${row?._id}`,
        { scroll: true } // ✅ Ensures scrolling to top
      );
      clickTimeout = null;
    }, 300); // Adjust delay if needed
  };

  const handleDoubleClick = (row: any) => {
    if (clickTimeout) {
      clearTimeout(clickTimeout); // Cancel single-click action
      clickTimeout = null;
    }

    setEditingRowId(row?._id); // Enable edit mode
    setTitle(row?.title || ''); // Pre-fill title
  };
  // Function to handle input change
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = event.target.value.trimStart(); // Prevent leading spaces

    if (newTitle === '') {
      setError('Title cannot be empty.');
    } else if (newTitle.length > 150) {
      setError('Title cannot exceed 150 characters.');
    } else {
      setError(''); // Clear error if valid
    }

    setTitle(newTitle);
  };

  // Function to save the edited title
  const saveTitle = async (taskId: string) => {
    if (error) return; // Prevent saving if there is an error

    if (title.trim()) {
      const formData: any = new FormData();
      formData.append('_id', taskId);
      formData.append('title', title);
      formData.append('action_name', 'date_assignee_update');

      try {
        const result = await dispatch(patchEditTask(formData)).unwrap();

        if (result?.success) {
          await dispatch(getAllMyTasks({ ...paginationParamsClient })).unwrap();
          setEditingRowId(null); // ✅ Now called after API fully resolves
        }
      } catch (error) {
        console.error('Error updating task:', error);
      }
    }
  };

  // Function to cancel editing mode
  const cancelEditing = () => {
    setTitle(''); // Reset title
    setError(''); // Clear error
    setEditingRowId(null); // Exit editing mode
  };
  const { loading } = useSelector((state: any) => state?.root?.taskStatus);
  const { paginationParams } = useSelector((state: any) => state?.root?.client);
  const paginationParamsClient = useSelector(
    (state: any) => state?.root?.client?.paginationParams
  );

  const { activeTimerData } = useSelector(
    (state: any) => state?.root?.timeTracking
  );
  const { openModal, closeModal } = useModal();

  function checkDate(date: Date, status: boolean) {
    const inputDate = moment(date); // Full date and time
    const now = moment(); // Full current date and time

    if (inputDate.isBefore(now) && !status) {
      return (
        <p className="text-sm font-semibold text-[#C92F54]">
          {inputDate.format('MMM D, YYYY h:mm A')}
        </p>
      );
    } else {
      return (
        <p className="text-sm font-semibold text-black">
          {inputDate.format('MMM D, YYYY h:mm A')}
        </p>
      );
    }
  }

  const AssigneeColumn = ({
    teamMembers,
    rowData,
    selectedMembers,
  }: {
    teamMembers: any;
    rowData?: any;
    selectedMembers?: any;
  }) => {
    const handleAddMemberClick = () => {
      if (
        // ['agency', 'client'].includes(signIn?.role)
        ['agency'].includes(signIn?.role) ||
        (['team_agency', 'team_client'].includes(signIn?.role) &&
          checkPermission('projects', 'tasks', 'update', signIn?.permission))
      ) {
        dispatch(getMembersByBoardId({ boardId: rowData?.board_data?._id }));
        openModal({
          view: (
            <div>
              <AddMembers
                onClose={closeModal}
                selectedMembers={selectedMembers}
                setSelectedMembers={setSelectedMembers}
                formPage={false}
                addTaskMember={true}
                taskId={rowData?._id}
                moduleName="my-tasks"
              />
            </div>
          ),
          customSize: '600px',
        });
      }
    };

    // Memoize the rendered output to prevent unnecessary re-renders
    const renderedTeamMembers = useMemo(() => {
      const displayName = (data: any) => {
        let displayName: string =
          data?.first_name?.charAt(0)?.toUpperCase() +
          data?.first_name?.slice(1) +
          ' ' +
          data?.last_name?.charAt(0)?.toUpperCase() +
          data?.last_name?.slice(1);
        return displayName;
      };

      if (teamMembers && teamMembers.length > 0) {
        return (
          <button
            className=" ms-[13px] flex cursor-pointer flex-row items-center justify-start gap-2"
            type="button"
            onClick={() => {
              handleAddMemberClick();
            }}
            disabled={
              rowData?.mark_as_archived ||
              rowData?.mark_as_done ||
              signIn?.role === 'client' ||
              (['team_agency', 'team_client'].includes(signIn?.role)
                ? !checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  )
                : false)
            }
          >
            <div className="flex flex-row items-center justify-start">
              {teamMembers?.slice(0, 3)?.map((team: any, index: number) => (
                <figure
                  key={`${team?._id}-${index}`}
                  className={cn(
                    'relative z-10 ml-[-13px] h-[32px] w-[32px] cursor-pointer rounded-full focus:border-2 focus:border-gray-900'
                  )}
                >
                  <Avatar
                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${team?.profile_image}`}
                    name={displayName(team)}
                    className={cn('bg-[#70C5E0] font-medium text-white')}
                    size="sm"
                  />
                </figure>
              ))}
            </div>
            {teamMembers?.length > 3 && (
              <div className="poppins_font_number flex h-8 w-8 cursor-pointer items-center justify-center gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]">
                +{teamMembers?.length - 3}
              </div>
            )}
          </button>
          // <div>
          //   <div className="mx-4 flex flex-row items-center justify-start lg:mx-0">
          //     {teamMembers &&
          //       teamMembers?.slice(0, 3)?.map((item: any, index: any) => (
          //         <figure
          //           key={item?.id}
          //           className={cn(
          //             'h-[40px] w-[40px] cursor-pointer rounded-full focus:border-2 focus:border-gray-900',
          //             index !== 0 ? 'z-10 ml-[-13px]' : ''
          //           )}
          //         >
          //           <Avatar
          //             size="sm"
          //             src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
          //             name={displayName(item)}
          //             className={cn('bg-[#70C5E0] font-medium text-white')}
          //           />
          //         </figure>
          //       ))}
          //     {teamMembers?.length > 3 && (
          //       <div className="poppins_font_number flex h-8 w-8 cursor-pointer items-center justify-center gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]">
          //         +{teamMembers?.length - 3}
          //       </div>
          //     )}
          //   </div>
          // </div>
        );
      } else {
        return (
          <Button
            variant="text"
            className="flex h-[32px] w-[32px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#9BA1B9] p-1"
            disabled={
              rowData?.mark_as_archived ||
              rowData?.mark_as_done ||
              signIn?.role === 'client' ||
              (['team_agency', 'team_client'].includes(signIn?.role)
                ? !checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  )
                : false)
            }
            onClick={() => {
              handleAddMemberClick();
            }}
          >
            <LuUser2 className="h-[18px] w-[18px] text-[#9BA1B9]" />
          </Button>
        );
      }
    }, [teamMembers]);

    return <div>{renderedTeamMembers}</div>;
  };
  let myTaskColumnArray: any = [
    {
      title: (
        <div className={cn(signIn?.role === 'team_client' && 'ps-3.5')}>
          <HeaderCell
            title="Task Id"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'task_id'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('task_id'),
      dataIndex: 'task_id',
      key: 'task_id',
      width: 400,
      render: (_: any, row: any) => (
        <div className="flex w-full items-center justify-between gap-2">
          <div className="flex w-[85%] items-center justify-between gap-2">
            <div
              className={cn(
                'view-task-tour-step-two flex h-full w-[90%]  justify-start gap-2 break-all p-0 text-start text-[14px] font-semibold normal-case',
                row?.mark_as_done ? 'text-[#9BA1B9]' : 'text-black'
              )}
            >
              {row?.task_id ? row?.task_id : '-'}
            </div>
          </div>
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Task Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'title'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('title'),
      dataIndex: 'title',
      key: 'title',
      width: 500,
      render: (_: any, row: any) => (
        <div className="flex w-full items-center justify-between gap-2">
          <div className="flex w-[85%] items-center justify-between gap-2">
            {editingRowId === row?._id ? (
              // Editing Mode - Show Input Field
              <div>
                <Input
                  type="text"
                  value={title}
                  onChange={handleChange}
                  onKeyDown={(event: any) => {
                    if (event.key === 'Enter') {
                      event.preventDefault();
                      saveTitle(row?._id);
                    } else if (event.key === 'Escape') {
                      cancelEditing();
                    }
                  }}
                  onBlur={cancelEditing}
                  placeholder="Edit task title"
                  className="placeholder_color w-full [&>label>span]:font-medium"
                  autoFocus
                  disabled={taskLoading || getAllMyTasksLoader}
                />
                {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
              </div>
            ) : (
              <button
                className={cn(
                  'view-task-tour-step-two flex h-full w-[90%] cursor-pointer justify-start gap-2 break-all p-0 text-start text-[14px] font-semibold normal-case text-black'
                )}
                onClick={() => handleSingleClick(row)}
                onDoubleClick={() => {
                  if (
                    !row?.mark_as_archived &&
                    !row?.mark_as_done &&
                    signIn?.role !== 'client' &&
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : true) // ✅ Allow double-click only if permission is valid
                  ) {
                    handleDoubleClick(row);
                  }
                }}
                type="button"
              >
                {capitalizeFirstLetter(row?.title)}
              </button>
            )}
            {activeTimerData?.task_detail?._id === row?._id && (
              <Tooltip
                size="sm"
                content={() => (
                  <span className="poppins_font_number">
                    <TimerDisplay />
                  </span>
                )}
                placement="top"
                color="invert"
              >
                <div className="flex items-center justify-center">
                  <FiStopCircle className="h-6 w-6 cursor-pointer text-[#EC221F]" />
                </div>
              </Tooltip>
            )}
          </div>
        </div>
        // <div className="flex items-center justify-start gap-2">
        //   <Link
        //     href={`${routes.boardDetails(
        //       defaultWorkSpace?.name,
        //       row?.board_id
        //     )}?task_id=${row?._id}`}
        //     className="text-[12px] font-semibold text-[#9BA1B9]"
        //   >
        //     <Text className="poppins_font_number text-[14px] font-semibold text-[#120425] hover:text-[#8C80D2]">
        //       {capitalizeFirstLetter(row?.title)}
        //     </Text>
        //   </Link>
        //   {/* {(['agency', 'client'].includes(signIn?.role) ||
        //     (['team_agency', 'team_client'].includes(signIn?.role) &&
        //       checkPermission('dashboard', 'task', 'own', signIn?.permission) &&
        //       activeTimerData?.user_id === signIn?.userProfile?._id)) && ( */}
        //   <div className="flex items-center gap-2">
        //     {(activeTimerData?.task_detail?._id === row?._id ||
        //       row?.time_tracking?.length > 0) && (
        //         <Tooltip
        //           size="sm"
        //           content={() => (
        //             <span className="poppins_font_number">
        //               <TimerDisplay />
        //             </span>
        //           )}
        //           placement="top"
        //           color="invert"
        //         >
        //           <div className="flex h-6 w-6 items-center justify-center">
        //             <FiStopCircle className="h-6 w-6 cursor-pointer text-[#EC221F]" />
        //           </div>
        //         </Tooltip>
        //       )}
        //   </div>
        //   {/* )} */}
        // </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Board"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'board_data.project_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('board_data.project_name'),
      dataIndex: 'board_data',
      key: 'board_data',
      width: 200,
      render: (board_data: Record<string, any>) => (
        <div className="flex items-center gap-1">
          {board_data?.board_image ? (
            <Avatar
              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${board_data?.board_image}`}
              name={capitalizeFirstLetter(board_data?.project_name) ?? ''}
              size="sm"
              className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white"
            />
          ) : (
            <div
              className="flex !h-8 !w-8 items-center justify-center rounded-full border-white"
              style={{ backgroundColor: board_data?.board_color }}
            ></div>
          )}
          <span className="ms-3	grid w-24 gap-0.5">
            <span className="break-all text-sm font-semibold capitalize text-black">
              {capitalizeFirstLetter(board_data?.project_name)}
            </span>
          </span>
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Assignee"
          // sortable
          // ascending={
          //   sortConfig?.direction === 'asc' && sortConfig?.key === 'assign_to'
          // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('assign_to'),
      dataIndex: 'assingnees',
      key: 'assingnees',
      width: 300,
      render: (_: any, row: any) => {
        // console.log("teamMembers..", row);
        return (
          <div>
            <AssigneeColumn
              teamMembers={row?.assingnees}
              rowData={row}
              selectedMembers={
                row?.assingnees && row?.assingnees?.length > 0
                  ? row?.assingnees?.map((member: any) => member?._id)
                  : []
              }
            />
          </div>
        );
      },
    },
    {
      title: <HeaderCell title="Time Tracker" />,
      // onHeaderCell: () => onHeaderCellClick('assign_to'),
      dataIndex: 'total_time',
      key: 'total_time',
      width: 200,
      render: (_: any, row: any) => {
        return (
          <Text className="text-sm font-semibold capitalize text-black">
            {convertSecondsToTime(row?.total_time)}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Due Date"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'due_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('due_date'),
      dataIndex: 'due_date',
      key: 'due_date',
      width: 300,
      render: (_: any, row: any) => {
        const canOpenPopup =
          ['agency'].includes(signIn?.role) ||
          ['team_agency'].includes(signIn?.role);

        return (
          <Text
            className={cn(
              'flex items-center justify-start text-sm font-semibold capitalize'
            )}
          >
            {row?.due_date ? (
              <div>
                <Popover
                  placement="bottom"
                  className="demo_test min-w-[425px] border-none bg-white p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                  content={({ open, setOpen }) => {
                    const originalDueDate = moment.utc(row?.due_date).toDate(); // Store the original due date
                    setIsOpenPopOver(open);
                    const handleDateChange = (date: any) => {
                      setSelectedDueDate(date);
                      setShowSaveButton(
                        moment(date).valueOf() !==
                          moment(originalDueDate).valueOf()
                      );
                      // Enable Save only if the date is different
                    };

                    const handleSaveDate = (setOpen: any) => {
                      if (!selectedDueDate) return;

                      const formData = new FormData();
                      formData.append('_id', row?._id);
                      formData.append('due_date', String(selectedDueDate));
                      formData.append('action_name', 'date_assignee_update');

                      dispatch(patchEditTask(formData)).then((result: any) => {
                        if (
                          patchEditTask.fulfilled.match(result) &&
                          result.payload.success
                        ) {
                          dispatch(getAllMyTasks({ ...paginationParams }));
                          setSelectedDueDate(null);
                          setShowSaveButton(false); // Hide Save button after saving
                          setOpen(false);
                        }
                      });
                    };

                    return (
                      <div>
                        <DatePicker
                          selected={
                            selectedDueDate ||
                            moment.utc(row?.due_date).toDate()
                          } // Use customizedDueDate
                          inputProps={{}}
                          placeholderText="Select due date"
                          onChange={handleDateChange}
                          selectsStart
                          startDate={
                            selectedDueDate ||
                            moment.utc(row?.due_date).toDate()
                          } // Prefill with existing due date
                          startOpen={true}
                          minDate={new Date()}
                          showTimeSelect
                          popperPlacement="bottom-start"
                          dateFormat="MMM d, yyyy h:mm aa"
                          noStyle={true} // ✅ Remove styles only for this picker
                          inline
                        />

                        <div className="mr-[20px] flex justify-end">
                          {' '}
                          {/* Right align */}
                          <Button
                            onClick={() => handleSaveDate(setOpen)}
                            rounded="lg"
                            disabled={!showSaveButton || taskLoading} // Disable Save button if date/time is not changed
                            className={`kanban-task-tour-step-one flex h-10 items-center justify-center gap-2 text-sm text-white ${
                              showSaveButton
                                ? 'bg-[#8C80D2]'
                                : 'cursor-not-allowed bg-[#8C80D2]'
                            }`}
                          >
                            Save
                            {taskLoading && (
                              <Spinner
                                size="sm"
                                tag="div"
                                className="ms-3"
                                color="white"
                              />
                            )}
                          </Button>
                        </div>
                      </div>
                    );
                  }}
                >
                  <button
                    className="cursor-pointer"
                    type="button"
                    disabled={
                      row?.mark_as_archived ||
                      row?.mark_as_done ||
                      signIn?.role === 'client' ||
                      (['team_agency', 'team_client'].includes(signIn?.role)
                        ? !checkPermission(
                            'projects',
                            'tasks',
                            'update',
                            signIn?.permission
                          )
                        : false)
                    }
                  >
                    {checkDate(
                      moment(row?.due_date)?.toDate(),
                      row?.mark_as_done
                    )}
                  </button>
                </Popover>
              </div>
            ) : (
              <Popover
                placement="bottom"
                className="demo_test min-w-[425px] border-none bg-white p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                content={({ open, setOpen }) => {
                  setIsOpenPopOver(open);

                  const handleDateChange = (date: any) => {
                    setSelectedDueDate(date);
                    setShowSaveButton(moment(date).valueOf());
                  };
                  const saveDateChange = (setOpen: any) => {
                    if (
                      !(
                        selectedDueDate?.getHours() === 0 &&
                        selectedDueDate?.getMinutes() === 0 &&
                        selectedDueDate?.getSeconds() === 0
                      )
                    ) {
                      const formData: any = new FormData();
                      formData.append('_id', row?._id);
                      formData.append('due_date', String(selectedDueDate));
                      formData.append('action_name', 'date_assignee_update');

                      dispatch(patchEditTask(formData)).then((result: any) => {
                        if (patchEditTask.fulfilled.match(result)) {
                          if (result && result.payload.success === true) {
                            dispatch(getAllMyTasks({ ...paginationParams }));
                            setSelectedDueDate(null);
                            setShowSaveButton(false);
                            setOpen(false);
                          }
                        }
                      });
                    }
                  };

                  return canOpenPopup ? (
                    <div>
                      <DatePicker
                        selected={selectedDueDate}
                        inputProps={{
                          // label: 'Due Date',
                          color: 'info',
                          // error: errors?.due_date?.message,
                        }}
                        placeholderText="Select due date"
                        onChange={handleDateChange}
                        selectsStart
                        startDate={selectedDueDate}
                        startOpen={true}
                        minDate={new Date()}
                        showTimeSelect
                        popperPlacement="bottom-start"
                        dateFormat="MMMM d, yyyy h:mm aa"
                        inline
                        noStyle={true} // ✅ Remove styles only for this picker
                      />
                      <div className="mr-[20px] flex justify-end">
                        {' '}
                        {/* Right align */}
                        <Button
                          onClick={() => saveDateChange(setOpen)}
                          rounded="lg"
                          disabled={!showSaveButton || taskLoading} // Disable Save button if date/time is not changed
                          className={`kanban-task-tour-step-one flex h-10 items-center justify-center gap-2 text-sm text-white ${
                            showSaveButton
                              ? 'bg-[#8C80D2]'
                              : 'cursor-not-allowed bg-[#8C80D2]'
                          }`}
                        >
                          Save
                          {taskLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </div>
                  ) : null;
                }}
              >
                <Button
                  variant="text"
                  className="flex h-[32px] w-[32px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#9BA1B9] p-1"
                  disabled={
                    row?.mark_as_done ||
                    signIn?.role === 'client' ||
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? !checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : false)
                  }
                >
                  <PiCalendarBlankLight className="h-4 w-4 text-[#4B5563]" />
                </Button>
              </Popover>
            )}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Priority"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'priority'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('priority'),
      dataIndex: 'priority',
      key: 'priority',
      width: 200,
      render: (_: any, row: any) => (
        <div>
          <Popover
            placement="top"
            className="demo_test min-w-[140px] border-none bg-white p-2 shadow-md dark:bg-gray-100"
            content={({ setOpen }) => {
              const handlePriorityChange = (priorityValue: string) => {
                // 🛠️ Update Task in API
                if (priorityValue !== row?.priority) {
                  const formData = new FormData();
                  formData.append('_id', row?._id);
                  formData.append('priority', priorityValue);
                  formData.append('action_name', 'date_assignee_update');

                  dispatch(patchEditTask(formData)).then((result: any) => {
                    if (patchEditTask.fulfilled.match(result)) {
                      if (result && result.payload.success === true) {
                        dispatch(getAllMyTasks({ ...paginationParams }));
                        setOpen(false);
                      }
                    }
                  });
                }
              };

              return (
                <div className="flex flex-col gap-2">
                  {priorityOptions.map((option: any) => (
                    <button
                      key={option.value}
                      type="button"
                      disabled={taskLoading}
                      onClick={() => handlePriorityChange(option.value)}
                      className={`flex h-7 w-[130px] cursor-pointer items-center justify-center rounded-lg border-[1px] px-4 py-1 text-sm font-medium ${option.color} hover:opacity-80`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              );
            }}
          >
            <button
              className="cursor-pointer"
              type="button"
              disabled={
                row?.mark_as_archived ||
                row?.mark_as_done ||
                signIn?.role === 'client' ||
                (['team_agency', 'team_client'].includes(signIn?.role)
                  ? !checkPermission(
                      'projects',
                      'tasks',
                      'update',
                      signIn?.permission
                    )
                  : false)
              }
            >
              <Text className="flex cursor-pointer items-center justify-center">
                {getPriorityStatusBadge(row?.priority)}
              </Text>{' '}
            </button>
          </Popover>
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Status"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'status.section_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status.section_name'),
      dataIndex: 'status',
      key: 'status',
      width: 200,
      render: (status: Record<string, any>) => (
        <div
          className="flex items-center justify-start gap-2 rounded-3xl px-[20px] py-[8px] text-xs sm:text-sm "
          style={{ backgroundColor: status?.color, maxWidth: '200px' }}
        >
          <div
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: status?.test_color }}
          />
          <Tooltip
            className="demo_test"
            size="sm"
            content={() => status?.section_name}
            placement="top"
            color="invert"
          >
            <div
              className="poppins_font_number truncate font-medium"
              style={{ color: status?.test_color }}
            >
              {status?.section_name}
            </div>
          </Tooltip>
        </div>
      ),
    },
  ];

  // Task mark as complete button
  myTaskColumnArray.unshift({
    title: <div className="ps-3.5"></div>,
    dataIndex: 'checked',
    key: 'checked',
    width: 50,
    render: (_: any, row: any) => {
      const handleTaskStatusChangeClick = () => {
        if (!row?.mark_as_done) {
          dispatch(
            putTaskKanbanStatusChange({
              _id: row?._id,
              status: row?.related_sections?._id,
            })
          ).then((result: any) => {
            if (putTaskKanbanStatusChange.fulfilled.match(result)) {
              if (result && result.payload.success === true) {
                dispatch(getAllMyTasks({ ...paginationParams }));
              }
            }
          });
        }
      };

      return (
        <>
          {!row?.mark_as_done ? (
            <>
              {(['agency'].includes(signIn?.role) ||
                row?.assingnees?.some(
                  (user: any) => user?._id === signIn?.user?.data?.user?._id
                ) ||
                (['team_agency'].includes(signIn?.role) &&
                  checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  ))) && (
                <Tooltip
                  className="demo_test"
                  size="sm"
                  content={() => 'Move to completed'}
                  placement="top"
                  color="invert"
                >
                  <Button
                    variant="text"
                    className="inline-flex !bg-transparent !ps-2"
                    onClick={handleTaskStatusChangeClick}
                    disabled={loading}
                  >
                    <IoIosCheckmarkCircleOutline className="h-6 w-6 text-[#8C80D2]" />
                  </Button>
                </Tooltip>
              )}
            </>
          ) : (
            <Button
              variant="text"
              className="view-task-tour-step-one inline-flex !bg-transparent !ps-2"
            >
              <IoIosCheckmarkCircle className="h-6 w-6 text-[#8C80D2]" />
            </Button>
          )}
        </>
      );
    },
  });

  // Task select checkbox column and it's logic
  const filteredData = data?.filter((row) => !row?.mark_as_done) ?? [];
  
  myTaskColumnArray.unshift({
    title: (
      <div className="ps-3.5">
        <Checkbox
          title={'Select All'}
          inputClassName="checkbox-color"
          onChange={handleBoardTaskSelectAll}
          checked={
            checkedItems?.length > 0 &&
            checkedItems?.length === filteredData?.length
          }
          className="cursor-pointer"
        />
      </div>
    ),
    dataIndex: 'checked',
    key: 'checked',
    width: 50,
    render: (_: any, row: any) => (
      <div className="inline-flex ps-3.5">
        {!row?.mark_as_archived && !row?.mark_as_done && (
          <Checkbox
            className="cursor-pointer"
            inputClassName="checkbox-color"
            checked={checkedItems.includes(row?._id)}
            {...(onChecked && { onChange: () => onChecked(row?._id) })}
          />
        )}
      </div>
    ),
  });

  return myTaskColumnArray;
};
