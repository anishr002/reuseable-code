import DeletePopover from '@/app/shared/delete-popover';
import UserCog from '@/components/icons/user-cog';
import { Button } from '@/components/ui/button';
import { routes } from '@/config/routes';
import cn from '@/utils/class-names';
import { capitalizeAndJoin, capitalizeFirstLetter } from '@/utils/common-functions';
import Link from 'next/link';
import { Title } from 'rizzui';

interface RoleCardProps {
    key: string;
    canDelete: boolean;
    canEdit: boolean;
    roleName: string;
    defaultWorkSpace: any;
    data: any,
    className?: string;
    deleteRole: (roleId: string) => void,
}

export default function RoleCard({
    key,
    canEdit,
    canDelete,
    data,
    defaultWorkSpace,
    roleName,
    className,
    deleteRole
}: Readonly<RoleCardProps>) {

    return (
        <div key={key} className={cn('rounded-lg border border-muted p-6 shadow-md bg-white', className)}>
            <header className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                    <Title as="h4" className="poppins_font_number text-center text-base font-semibold sm:text-lg break-all text-[#9BA1B9] capitalize">
                        {roleName && capitalizeAndJoin(roleName)}
                    </Title>
                </div>

                {
                    canDelete &&
                    <div className="flex items-center space-x-2">
                        <DeletePopover
                            deleteButtonClass="bg-[#E3E1F4] text-[#8C80D2]"
                            title={`Delete the role`}
                            description={`Are you sure you want to delete this role?`}
                            onDelete={() => deleteRole(data?._id)}
                        />
                    </div>
                }
            </header>

            {
                <Link href={routes.editRole(defaultWorkSpace?.name, data?._id)}>
                    <Button
                        disabled={!canEdit}
                        className="items-center gap-1 @lg:w-full lg:mt-6 bg-[#8C80D2] text-white hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                    ><UserCog className="h-5 w-5" />
                        Edit Role
                    </Button>
                </Link>
            }
        </div>
    );
}