'use client';

import WidgetCard from '@/components/cards/widget-card';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { createSubRole, editSubRole, getSubRoleById, removeGetSubRoleByIdData } from '@/redux/slices/user/roles-permissions/rolePermissionSlice';
import { capitalizeAndJoin, capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import { CreateRoleInput, createRoleSchema } from '@/utils/validators/create-role.schema';
import { useParams, useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react';
import { PiCheckBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { AGENCYMODULELIST, checkPermission, CLIENTMODULELIST, getCommonModules, getCommonModulesClient, permissions, PERMISSIONSDATA } from './utils';

const CreateRole = () => {
    const { id } = useParams();
    const dispatch = useDispatch();
    const router = useRouter();

    const [modules, setModules] = useState<any>({});

    const { getSubRoleByIdData, getSubRoleByIdLoader, createSubRoleLoader, editSubRoleLoader } = useSelector((state: any) => state?.root?.rolePermission);
    const { defaultWorkSpace } = useSelector(
        (state: any) => state?.root?.workspace
    );
    const { role, permission } = useSelector((state: any) => state?.root?.signIn);

    const initialValues = {
        roleName: getSubRoleByIdData?.sub_role ? getSubRoleByIdData?.sub_role : '',
    };

    useEffect(() => {
        setModules({});

        if (id) {
            dispatch(getSubRoleById(id));
        }

        if (['agency', 'team_agency'].includes(role)) {
            setModules(AGENCYMODULELIST);
        } else if (['client', 'team_client'].includes(role)) {
            setModules(CLIENTMODULELIST);
        };

        return () => {
            setModules({});
            dispatch(removeGetSubRoleByIdData());
        };
    }, [dispatch, id, role]);

    useEffect(() => {
        if (Object.keys(getSubRoleByIdData)?.length > 0) {
            let modulesName = {};
            console.log(role, 'role');
            if (['agency', 'team_agency']?.includes(role)) {
                modulesName = AGENCYMODULELIST;
                setModules(getCommonModules(modulesName, getSubRoleByIdData?.permissions));
            } else if (['client', 'team_clients'].includes(role)) {
                modulesName = CLIENTMODULELIST;
                setModules(getCommonModulesClient(modulesName, getSubRoleByIdData?.permissions));
            };

        }
    }, [getSubRoleByIdData, role]);

    const onSubmit = (data: any) => {
        const roleName = ['agency', 'team_agency'].includes(role) ? 'team_agency' : ['client', 'team_client'].includes(role) ? 'team_client' : '';

        const payload = createPayload(data?.roleName, modules, roleName);

        if (id) {
            dispatch(editSubRole({ ...payload, _id: id })).then((result: any) => {
                if (editSubRole.fulfilled.match(result)) {
                    if (result.payload.success === true) {
                        router.replace(routes.roleAndPermission(defaultWorkSpace?.name));
                    }
                }
            });
        } else {
            dispatch(createSubRole(payload)).then((result: any) => {
                if (createSubRole.fulfilled.match(result)) {
                    if (result.payload.success === true) {
                        router.replace(routes.roleAndPermission(defaultWorkSpace?.name));
                    }
                }
            });
        }
    };

    const createPayload = (roleName: string, permissions: any, role: string) => {
        return {
            role,
            sub_role: roleName,
            permissions: updateIsApplicable(permissions)
        };
    };

    const updateModulePermission = (moduleName: string, submoduleName: string | null, permission: string, value: boolean) => {
        if (!submoduleName) {
            if (modules[moduleName] && permission in modules[moduleName]) {

                if (['everyone', 'own']?.includes(permission)) {
                    const updatedModules = {
                        ...modules,
                        [moduleName]: {
                            ...modules[moduleName],
                            own: permission === 'own' ? value : !value,
                            everyone: permission === 'everyone' ? value : !value
                        }
                    };
                    setModules(updatedModules);
                    return;
                };

                if (['view']?.includes(permission)) {
                    if (value) {
                        const updatedModules = {
                            ...modules,
                            [moduleName]: {
                                ...modules[moduleName],
                                [permission]: value,
                            }
                        };
                        setModules(updatedModules);
                        return;
                    } else {
                        const updatedModules = {
                            ...modules,
                            [moduleName]: {
                                ...modules[moduleName],
                                [permission]: value,
                                ...modules[moduleName].hasOwnProperty('create') && { create: false },
                                ...modules[moduleName].hasOwnProperty('update') && { update: false },
                                ...modules[moduleName].hasOwnProperty('delete') && { delete: false },
                            }
                        };
                        setModules(updatedModules);
                        return;
                    }
                } else if (['create', 'update', 'delete']?.includes(permission)) {
                    let updatedModules = {
                        ...modules,
                        [moduleName]: {
                            ...modules[moduleName],
                            [permission]: value,
                        }
                    };

                    updatedModules = {
                        ...updatedModules,
                        [moduleName]: {
                            ...updatedModules[moduleName],
                            ...updatedModules[moduleName].hasOwnProperty('view') && {
                                view: updatedModules[moduleName].create || updatedModules[moduleName].update || updatedModules[moduleName].delete || false
                            }
                        }
                    };
                    setModules(updatedModules);
                }
            }

        } else if (submoduleName) {
            if (modules?.[moduleName]?.sub_modules && submoduleName in modules?.[moduleName]?.sub_modules) {
                if (permission === 'everyone' || permission === 'own') {
                    const updatedModules = {
                        ...modules,
                        [moduleName]: {
                            ...modules[moduleName],
                            sub_modules: {
                                ...modules[moduleName].sub_modules,
                                [submoduleName]: {
                                    ...modules[moduleName].sub_modules[submoduleName],
                                    everyone: permission === 'everyone' ? value : !value,
                                    own: permission === 'own' ? value : !value,
                                }
                            }
                        }
                    };
                    setModules(updatedModules);
                    return;
                }

                if (['view']?.includes(permission)) {
                    if (value) {
                        const updatedModules = {
                            ...modules,
                            [moduleName]: {
                                ...modules[moduleName],
                                sub_modules: {
                                    ...modules[moduleName].sub_modules,
                                    [submoduleName]: {
                                        ...modules[moduleName].sub_modules[submoduleName],
                                        [permission]: value
                                    }
                                }
                            }
                        };
                        setModules(updatedModules);
                        return;
                    } else {
                        const updatedModules = {
                            ...modules,
                            [moduleName]: {
                                ...modules[moduleName],
                                sub_modules: {
                                    ...modules[moduleName].sub_modules,
                                    [submoduleName]: {
                                        ...modules[moduleName].sub_modules[submoduleName],
                                        [permission]: value,
                                        ...modules[moduleName].sub_modules[submoduleName].hasOwnProperty('create') && { create: false },
                                        ...modules[moduleName].sub_modules[submoduleName].hasOwnProperty('update') && { update: false },
                                        ...modules[moduleName].sub_modules[submoduleName].hasOwnProperty('delete') && { delete: false },
                                    }
                                }
                            }
                        };
                        setModules(updatedModules);
                        return;
                    }
                } else if (['create', 'update', 'delete']?.includes(permission)) {
                    let updatedModules = {
                        ...modules,
                        [moduleName]: {
                            ...modules[moduleName],
                            sub_modules: {
                                ...modules[moduleName].sub_modules,
                                [submoduleName]: {
                                    ...modules[moduleName].sub_modules[submoduleName],
                                    [permission]: value
                                }
                            }
                        }
                    };

                    updatedModules = JSON.parse(JSON.stringify(updatedModules));
                    updatedModules = {
                        ...updatedModules,
                        [moduleName]: {
                            ...updatedModules[moduleName],
                            sub_modules: {
                                ...updatedModules[moduleName].sub_modules,
                                [submoduleName]: {
                                    ...updatedModules[moduleName].sub_modules[submoduleName],
                                    ...(updatedModules[moduleName].sub_modules[submoduleName].hasOwnProperty('view') && {
                                        view: updatedModules[moduleName].sub_modules[submoduleName].create || updatedModules[moduleName].sub_modules[submoduleName].update || updatedModules[moduleName].sub_modules[submoduleName].delete
                                    })
                                }
                            }
                        }
                    };
                    setModules(updatedModules);
                }
            }

        }
    };

    const isChecked = (moduleName: string, subModuleName: string | null, property: string) => {

        if (modules[moduleName]) {
            // Check for the main module's permission
            if (property in modules[moduleName]) {
                return modules[moduleName][property];
            }
            // Check for sub-module permissions
            if (subModuleName && modules?.[moduleName]?.sub_modules?.[subModuleName]) {
                // Check if the property exists within the sub-module
                if (property in modules[moduleName].sub_modules[subModuleName]) {
                    return modules[moduleName].sub_modules[subModuleName][property];
                }
            }
        }
        // Return false if no matching permission is found
        return false;
    };

    const updateIsApplicable = (agencyModuleList: any) => {
        return Object.fromEntries(
            Object.entries(agencyModuleList).map(([moduleKey, moduleData]: any) => {
                if (moduleData.sub_modules) {
                    // Update each submodule's is_applicable if it exists
                    const subModules = Object.fromEntries(
                        Object.entries(moduleData.sub_modules).map(([subModuleKey, subModule]: any) => [
                            subModuleKey,
                            {
                                ...subModule,
                                ...(subModule.hasOwnProperty('is_applicable') && {
                                    is_applicable: checkApplicability(subModule) || false,
                                }),
                            },
                        ])
                    );
                    return [moduleKey, { ...moduleData, sub_modules: subModules }];
                }

                // Update main module's is_applicable if it exists

                return [
                    moduleKey,
                    {
                        ...moduleData,
                        ...(moduleData.hasOwnProperty('is_applicable') && {
                            is_applicable: checkApplicability(moduleData) || false,
                        }),
                    },
                ];
            })
        );
    };

    const checkApplicability = (module: any) => module.create || module.update || module.delete || module.view;


    if (getSubRoleByIdLoader) {
        return (
            <div className="flex items-center justify-center p-10">
                <Spinner size="xl" tag="div" />
            </div>
        );
    }

    return (
        <div className='flex flex-col lg:flex-row gap-7'>
            <div className='w-full'>
                <WidgetCard
                    rounded="lg"
                    className="col-span-full px-4"
                    title=""
                ><Form<CreateRoleInput>
                    onSubmit={onSubmit}
                    validationSchema={createRoleSchema}
                    useFormProps={{
                        defaultValues: initialValues,
                        mode: 'all',
                    }}
                    className="placeholder_color flex flex-grow flex-col gap-6 p-2 @container [&_.rizzui-input-label]:font-medium [&_.rizzui-input-label]:text-gray-900"
                >
                        {({ register, formState: { errors } }) => {

                            return (
                                <>
                                    <div className="flex flex-col gap-4">
                                        <div className="flex justify-between">
                                            <div className="w-1/2 pr-2">
                                                <label htmlFor='roleName' className="text-[14px] font-semibold text-[#9BA1B9]">
                                                    Role Name *
                                                </label>
                                                <Input
                                                    id="roleName"
                                                    placeholder="Enter Role Name"
                                                    type="text"
                                                    color="info"
                                                    onKeyDown={handleKeyDown}
                                                    {...register('roleName')}
                                                    className="rounded-xl [&>label>span]:font-medium"
                                                    inputClassName='poppins_font_number'
                                                    error={errors?.roleName?.message}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="overflow-x-auto relative">
                                        <table className="min-w-full border-collapse">
                                            <thead>
                                                <tr className="bg-gray-100">
                                                    <th className="border p-2 text-left font-bold text-base sm:text-lg break-all text-[#9BA1B9]">Module</th>
                                                    <th className="border p-2 text-left font-bold text-base sm:text-lg break-all text-[#9BA1B9]">Sub Module</th>

                                                    {permissions.map(({ label }: { label: any }) => (
                                                        <th key={label} className="border p-2 text-center w-1/12 font-bold text-base sm:text-lg text-[#9BA1B9]">
                                                            {capitalizeFirstLetter(label)}
                                                        </th>
                                                    ))}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {(() => {
                                                    if (modules && Object.keys(modules)?.length === 0) {
                                                        return (
                                                            <tr>
                                                                <td colSpan={permissions.length + 2} className="p-6 text-center text-gray-500">
                                                                    No data available
                                                                </td>
                                                            </tr>
                                                        );
                                                    }

                                                    return modules && Object.keys(modules)?.map((module: any) => (
                                                        <React.Fragment key={module}>
                                                            {modules?.[module]?.sub_modules && Object.keys(modules?.[module]?.sub_modules).length > 0 ? (
                                                                Object.keys(modules[module]?.sub_modules)?.map((subModuleName, index: number) => (
                                                                    <tr key={subModuleName}>
                                                                        {
                                                                            index === 0 && (
                                                                                <td
                                                                                    rowSpan={Object.keys(modules?.[module]?.sub_modules).length}
                                                                                    className="border p-2 text-left text-base font-semibold sm:text-lg break-all text-[#9BA1B9]"
                                                                                >
                                                                                    {capitalizeAndJoin(module)}
                                                                                </td>
                                                                            )
                                                                        }
                                                                        <td className="border p-2 text-left text-base font-semibold sm:text-lg break-all text-[#9BA1B9]">{capitalizeAndJoin(subModuleName)}</td>
                                                                        {
                                                                            PERMISSIONSDATA.map((permissionValue: string) => (
                                                                                <td key={permissionValue} className="border p-2 text-center">
                                                                                    {modules?.[module]?.sub_modules?.[subModuleName]?.hasOwnProperty(permissionValue) ? (
                                                                                        <Button
                                                                                            variant='outline'
                                                                                            className='w-full border bg-white items-center justify-center'
                                                                                            onClick={() => updateModulePermission(module, subModuleName, permissionValue, !modules[module]?.sub_modules?.[subModuleName]?.[permissionValue])}
                                                                                        >
                                                                                            {isChecked(module, subModuleName, permissionValue) ? <PiCheckBold className="text-[#8C80D2] h-[14px] w-[14px] md:h-4 md:w-4" /> : <span></span>}
                                                                                        </Button>
                                                                                    ) : (
                                                                                        <span>-</span>
                                                                                    )}
                                                                                </td>
                                                                            ))
                                                                        }
                                                                    </tr>
                                                                ))
                                                            ) : (
                                                                <tr key={module}>
                                                                    <td className="border p-2 text-left text-base font-semibold sm:text-lg break-all text-[#9BA1B9]">{capitalizeAndJoin(module)}</td>
                                                                    <td className="border p-2 text-left text-base font-semibold sm:text-lg break-all text-[#9BA1B9]">-</td>
                                                                    {
                                                                        PERMISSIONSDATA.map((permissionValue: any) => (
                                                                            <td key={permissionValue} className="border p-2 text-center">
                                                                                {modules?.[module]?.hasOwnProperty(permissionValue) ? (
                                                                                    <Button
                                                                                        variant='outline'
                                                                                        className='w-full border bg-white items-center justify-center'
                                                                                        onClick={() => updateModulePermission(module, null, permissionValue, !modules[module]?.[permissionValue])}
                                                                                    >
                                                                                        {isChecked(module, null, permissionValue) ? <PiCheckBold className="text-[#8C80D2] h-[14px] w-[14px] md:h-4 md:w-4" /> : <span></span>}
                                                                                    </Button>
                                                                                ) : (
                                                                                    <span>-</span>
                                                                                )}
                                                                            </td>
                                                                        ))
                                                                    }
                                                                </tr>
                                                            )
                                                            }
                                                        </React.Fragment>
                                                    ));
                                                })()}
                                            </tbody>
                                        </table >
                                    </div>

                                    {
                                        (['team_client', 'team_agency'].includes(role) ? (checkPermission('roles_permissions', null, 'create', permission) || checkPermission('roles_permissions', null, 'update', permission)) : ['agency', 'client']?.includes(role)) &&
                                        <div className="flex items-center justify-end gap-4">
                                            <Button
                                                type="submit"
                                                // disabled={createSubRoleLoader || editSubRoleLoader}
                                                className="flex w-full h-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                                            >
                                                Save Changes
                                                {
                                                    (createSubRoleLoader || editSubRoleLoader) &&
                                                    <Spinner
                                                        size="sm"
                                                        tag="div"
                                                        className="ms-3"
                                                        color="white"
                                                    />
                                                }

                                            </Button>
                                        </div>
                                    }
                                </>
                            );
                        }}
                    </Form>
                </WidgetCard>
            </div >
        </div >
    );
};

export default CreateRole;
