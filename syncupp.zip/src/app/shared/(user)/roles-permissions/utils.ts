export const PERMISSIONS = {
  Create: 'create',
  Update: 'update',
  Delete: 'delete',
  View: 'view',
  Own: 'own',
  Everyone: 'everyone',
};

export const PERMISSIONSDATA = [
  'create',
  'update',
  'delete',
  'view',
  'own',
  'everyone',
];

export const AGENCYMODULELIST: any = {
  dashboard: {
    sub_modules: {
      task: {
        own: true,
        everyone: false,
      },
      meetings: {
        own: true,
        everyone: false,
      },
      statistics: {
        own: true,
        everyone: false,
      },
    },
  },
  chats: {
    sub_modules: {
      group: {
        create: false,
        update: false,
      },
    },
  },
  projects: {
    sub_modules: {
      boards: {
        create: false,
        update: false,
        delete: false,
        is_applicable: false,
      },
      tasks: {
        create: false,
        update: false,
        delete: false,
        own: true,
        everyone: false,
        is_applicable: false,
      },
      sections: {
        create: false,
        update: false,
        delete: false,
        is_applicable: false,
      },
    },
  },
  time_tracker: { update: false, delete: false, own: true, everyone: false },
  meetings: {
    own: true,
    everyone: false,
    create: false,
    update: false,
    view: false,
    is_applicable: false,
  },
  invoices: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  agreements: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  teams: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  clients: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  roles_permissions: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  reports: {
    sub_modules: {
      timesheet_reports: {
        own: true,
        everyone: false,
      },
    },
  },
  attendance: { update: false, delete: false, own: true, everyone: false },
};

export const CLIENTMODULELIST: any = {
  chats: {
    sub_modules: {
      group: {
        create: false,
        update: false,
      },
    },
  },
  projects: {
    sub_modules: {
      boards: {
        // create: false,
        update: false,
        // delete: false,
        is_applicable: false,
      },
      tasks: {
        create: false,
        update: false,
        delete: false,
        own: true,
        everyone: false,
        is_applicable: false,
      },
      // sections: {
      // create: false,
      // update: false,
      // delete: false,
      // is_applicable: false,
      // },
    },
  },
  time_tracker: { own: true, everyone: false },
  meetings: {
    own: true,
    everyone: false,
    view: false,
    is_applicable: false,
  },
  teams: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  roles_permissions: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  reports: {
    sub_modules: {
      timesheet_reports: {
        own: true,
        everyone: false,
      },
    },
  },
  attendance: { update: false, delete: false, own: true, everyone: false },
};

export const permissions = Object.values(PERMISSIONS).map((permission) => ({
  label: permission,
  value: permission,
}));

export const getCommonModules = (clientModules: any, apiResponse: any) => {
  return Object.fromEntries(
    Object.entries(apiResponse).filter(([key]) => key in clientModules)
  );
};

export const getApplicableMenuItems = (
  menuItems: any,
  modules: any,
  defaultSidebar: string[]
) => {
  return menuItems
    .filter(
      ({
        moduleName,
        dropdownItems,
      }: {
        moduleName: string;
        dropdownItems?: any[];
      }) => {
        // Check if the moduleName is directly in the defaultSidebar or is applicable
        if (
          defaultSidebar.includes(moduleName) ||
          modules?.[moduleName]?.is_applicable === true
        ) {
          return true;
        }

        // Check if any of the dropdownItems have a moduleName that matches the defaultSidebar or is applicable
        if (dropdownItems) {
          return dropdownItems.some(
            (dropdownItem: { moduleName: string }) =>
              defaultSidebar.includes(dropdownItem.moduleName) ||
              modules?.[dropdownItem.moduleName]?.is_applicable === true
          );
        }

        return false;
      }
    )
    .map(({ dropdownItems, ...rest }: { dropdownItems?: any[] }) => {
      // If dropdownItems exist, filter them to include only the ones that are applicable
      if (dropdownItems) {
        const filteredDropdownItems = dropdownItems.filter(
          (dropdownItem: { moduleName: string }) =>
            defaultSidebar.includes(dropdownItem.moduleName) ||
            modules?.[dropdownItem.moduleName]?.is_applicable === true
        );
        return { ...rest, dropdownItems: filteredDropdownItems };
      }

      return rest;
    });
};

export const checkPermission = (
  moduleName: string,
  submodule: string | null,
  permission: string,
  permissionsList: any
) => {
  // Check if the module exists
  if (!permissionsList?.[moduleName]) {
    return false; // Module not found
  }

  // If submodule exists
  if (
    submodule &&
    permissionsList[moduleName].sub_modules &&
    permissionsList[moduleName].sub_modules[submodule]
  ) {
    const subModuleData = permissionsList[moduleName].sub_modules[submodule];

    // Check if the permission exists in the submodule
    if (subModuleData.hasOwnProperty(permission)) {
      return subModuleData[permission];
    } else {
      return false; // Permission not found in the submodule
    }
  }

  // Check if the permission exists in the module itself (for non-submodule modules)
  if (permissionsList[moduleName].hasOwnProperty(permission)) {
    return permissionsList[moduleName][permission];
  }

  return false; // Permission not found in the module
};

export const getCommonModulesClient = (
  clientModules: any,
  apiResponse: any
) => {
  const filterModules: any = (clientObj: any, apiObj: any) =>
    Object.fromEntries(
      Object.entries(clientObj).flatMap(([key, clientValue]: any) => {
        if (key in apiObj) {
          const apiValue = apiObj[key];
          if (
            typeof clientValue === 'object' &&
            clientValue !== null &&
            typeof apiValue === 'object'
          ) {
            const nestedResult = filterModules(clientValue, apiValue);
            return [[key, nestedResult]];
          }
          return [[key, apiValue]];
        }
        return [];
      })
    );

  return filterModules(clientModules, apiResponse);
};
