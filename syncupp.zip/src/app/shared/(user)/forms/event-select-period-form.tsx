'use client';

import { Form } from '@/components/ui/form';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { usePathname } from 'next/navigation';
import { DatePicker } from '@/components/ui/datepicker';
import moment from 'moment';
import { setPaginationDetails } from '@/redux/slices/user/activity/activitySlice';
import { getAllEvent } from '@/redux/slices/user/events/eventSlice';




export default function EventDatePeriodSelectionForm(props: any) {

    const { setStartDate, setEndDate, setPeriod, reset } = props;

    const dispatch = useDispatch();
    const pathname = usePathname();
    const clientSliceData = useSelector((state: any) => state?.root?.client);
    const signIn = useSelector((state: any) => state?.root?.signIn)
    const { gridView } = useSelector((state: any) => state?.root?.task);
    const { paginationParams } = useSelector((state: any) => state?.root?.activity);


    let initialValue: Record<string, string> = {
        time_selection: ''
    }

    const [startRangeDate, setStartRangeDate] = useState(null);
    const [endRangeDate, setEndRangeDate] = useState(null);

    useEffect(() => {
        setStartRangeDate(null);
        setEndRangeDate(null);
    }, [clientSliceData?.agencyId, reset]);

    const handleRangeChange = (dates: any) => {
        const [start, end] = dates;
        setStartRangeDate(start);
        setEndRangeDate(end);
        setStartDate(moment(start).format('DD-MM-YYYY'))
        !!end && setEndDate(moment(end).format('DD-MM-YYYY'))

        dispatch(setPaginationDetails({ ...paginationParams, page: 1, filter: { date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }}))


        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
            !!end && dispatch(getAllEvent({ page: 1, sort_field: 'createdAt', sort_order: 'desc', filter: { date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }, pagination: true }))
        } else {
            !!end && dispatch(getAllEvent({ page: 1, sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, filter: { date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }, pagination: true }))
        }

        !!end && setPeriod('period')

    };

    const onSubmit = (data: any) => {
    };

    return (
        <>
            <Form
                onSubmit={onSubmit}
                useFormProps={{
                    defaultValues: initialValue,
                    mode: 'all'
                }}
            >
                {({ control, formState: { errors } }) => (
                    <div>
                        <DatePicker
                            selected={startRangeDate}
                            onChange={handleRangeChange}
                            startDate={startRangeDate}
                            endDate={endRangeDate}
                            // isClearable={true}
                            monthsShown={1}
                            placeholderText="Select Date in a Range"
                            className="[&>label>span]:font-medium"
                            selectsRange
                        />
                    </div>
                )}
            </Form>
        </>
    );
}
