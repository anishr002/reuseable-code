'use client';

import { Title, ActionIcon } from '@/components/ui/text';
import { Button } from '@/components/ui/button';
import { SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { Password } from '@/components/ui/password';
import {
  ChangePasswordSchema,
  changePasswordSchema,
} from '@/utils/validators/change-password.schema';
import { useDispatch, useSelector } from 'react-redux';
import { changePasswordUser } from '@/redux/slices/user/auth/changePasswordSlice';
import { handleKeyDown } from '@/utils/common-functions';
import Spinner from '@/components/ui/spinner';
import { useModal } from '@/app/shared/modal-views/use-modal';
import cn from '@/utils/class-names';
import { PiXBold } from 'react-icons/pi';
import { signOutUser } from '@/redux/slices/user/auth/signinSlice';
import socket from '@/io';
import { useRouter } from 'next/navigation';
import { routes } from '@/config/routes';

const initialValues: ChangePasswordSchema = {
  // oldPassword: '',
  newPassword: '',
  confirmedPassword: '',
};

export default function ChangePasswordForm() {
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const changePassword = useSelector(
    (state: any) => state?.root?.changePassword
  );

  const { userProfile, loading } = useSelector(
    (state: any) => state?.root?.signIn
  );
  const router = useRouter();
  const onSubmit: SubmitHandler<ChangePasswordSchema> = (data) => {
    const formData = {
      // currentPassword: data?.oldPassword,
      newPassword: data?.newPassword,
      confirmedPassword: data?.confirmedPassword,
    };
    dispatch(changePasswordUser(formData)).then((result: any) => {
      if (changePasswordUser.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          closeModal();
          dispatch(signOutUser()).then((result: any) => {
            socket.emit('USER_DISCONNECTED', { user_id: userProfile?._id });
            // socket.disconnect();
            if (signOutUser.fulfilled.match(result)) {
              router.replace(`${routes.signIn}?logout=true`);
            }
          });
        }
      }
    });
  };

  return (
    <>
      <Form<ChangePasswordSchema>
        validationSchema={changePasswordSchema}
        onSubmit={onSubmit}
        useFormProps={{
          defaultValues: initialValues,
          mode: 'all',
        }}
        className="placeholder_color p-10 [&_label]:font-medium"
      >
        {({ register, formState: { errors } }) => (
          <div className="space-y-5">
            <div className="mb-6 flex items-center justify-between">
              <Title
                as="h3"
                className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
              >
                Change Password
              </Title>
              <ActionIcon
                size="sm"
                variant="text"
                onClick={() => closeModal()}
                className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
              >
                <PiXBold className="h-[18px] w-[18px]" />
              </ActionIcon>
            </div>
            {/* <Password
              onKeyDown={handleKeyDown}
              label="Current Password"
              labelClassName="text-[14px] font-semibold text-[#9BA1B9]"
              placeholder="Enter your password"
              className="flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425] placeholder:text-[16px]  placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:text-[16px] [&>label>span]:font-semibold"
              {...register('oldPassword')}
              error={errors.oldPassword?.message}
              visibilityToggleIcon={(visible: any) =>
                visible ? (
                  <span className="h-auto w-5 font-semibold text-[#7763E8]">
                    Hide
                  </span>
                ) : (
                  <span className="h-auto w-5 font-semibold text-[#7763E8]">
                    Show
                  </span>
                )
              }
            /> */}
            <Password
              onKeyDown={handleKeyDown}
              label="New Password"
              placeholder="Enter your password"
              labelClassName="text-[14px] font-semibold text-[#9BA1B9]"
              className="flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425] placeholder:text-[16px]  placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:text-[16px] [&>label>span]:font-semibold"
              {...register('newPassword')}
              error={errors.newPassword?.message}
              visibilityToggleIcon={(visible: any) =>
                visible ? (
                  <span className="h-auto w-5 font-semibold text-[#7763E8]">
                    Hide
                  </span>
                ) : (
                  <span className="h-auto w-5 font-semibold text-[#7763E8]">
                    Show
                  </span>
                )
              }
            />
            <Password
              onKeyDown={handleKeyDown}
              label="Confirm New Password"
              placeholder="Enter your password"
              labelClassName="text-[14px] font-semibold text-[#9BA1B9]"
              className="flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425] placeholder:text-[16px]  placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:text-[16px] [&>label>span]:font-semibold"
              {...register('confirmedPassword')}
              error={errors.confirmedPassword?.message}
              visibilityToggleIcon={(visible: any) =>
                visible ? (
                  <span className="h-auto w-5 font-semibold text-[#7763E8]">
                    Hide
                  </span>
                ) : (
                  <span className="h-auto w-5 font-semibold text-[#7763E8]">
                    Show
                  </span>
                )
              }
            />
            <div className="mt-2 lg:mt-16">
              <Button
                disabled={changePassword.loading}
                className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                type="submit"
                size="xl"
              >
                <span>Save Changes</span>
                {changePassword.loading && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
            </div>

            {/* <div className={cn('grid grid-cols-2 gap-4 pt-5')}>
              <Button
                variant="outline"
                className="w-full @xl:w-auto dark:hover:border-gray-400"
                onClick={() => closeModal()}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="hover:gray-700 w-full  @xl:w-auto dark:bg-gray-200 dark:text-white"
                disabled={changePassword.loading}
              >
                Save
                {changePassword.loading && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
            </div> */}
          </div>
        )}
      </Form>
    </>
  );
}
