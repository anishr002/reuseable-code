'use client';

import { Form } from '@/components/ui/form';
import { Controller } from 'react-hook-form';
import { useDispatch, useSelector } from "react-redux";
import Select from '@/components/ui/select';
import { getAllActivity, setActivityName, setPaginationDetails } from '@/redux/slices/user/activity/activitySlice';
import { useEffect, useState } from 'react';


export default function StatusSelectionForm(props: any) {
    const { setStatusType, activityType, startDate, endDate, period, clientId, teamId, clientTeamId, reset } = props;
    const dispatch = useDispatch();
    const activityData = useSelector((state: any) => state?.root?.activity);
    const signIn = useSelector((state: any) => state?.root?.signIn)
    const clientSliceData = useSelector((state: any) => state?.root?.client);
    const { paginationParams } = useSelector((state: any) => state?.root?.activity);
    const [statusOption, setStatusOption] = useState('');


    useEffect(() => {
        reset === 'reset' && setStatusOption('');
    }, [reset]);

    useEffect(() => {
        setStatusOption('');
    }, [clientSliceData?.agencyId]);

    let statusOptionsDropdown: Record<string, any>[] = [
        { name: 'All', value: '' },
        { name: 'Pending', value: 'pending' },
        { name: 'In Progress', value: 'in_progress' },
        { name: 'Overdue', value: 'overdue' },
        { name: 'Completed', value: 'done' },
        { name: 'Cancel', value: 'cancel' },
    ]

    const handleStatusChange = (selectedOption: Record<string, any>) => {
        setStatusType(selectedOption?.value)
        // dispatch(setActivityName(selectedOption?.value));

        dispatch(setPaginationDetails({ ...paginationParams, page: 1, filter: { status: selectedOption?.value, activity_type: activityType, date: period, start_date: startDate, end_date: endDate } }))


        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
            if (activityType === '' && endDate === '' && startDate === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientId, team_id: teamId, client_team_id: clientTeamId, filter: { status: selectedOption?.value }, pagination: true }))
            } else if (endDate === '' && startDate === '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientId, team_id: teamId, client_team_id: clientTeamId, filter: { status: selectedOption?.value, activity_type: activityType }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientId, team_id: teamId, client_team_id: clientTeamId, filter: { status: selectedOption?.value, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientId, team_id: teamId, client_team_id: clientTeamId, filter: { status: selectedOption?.value, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            }
        } else {
            if (activityType === '' && endDate === '' && startDate === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: clientTeamId, filter: { status: selectedOption?.value }, pagination: true }))
            } else if (endDate === '' && startDate === '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: clientTeamId, filter: { status: selectedOption?.value, activity_type: activityType }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: clientTeamId, filter: { status: selectedOption?.value, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: clientTeamId, filter: { status: selectedOption?.value, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            }

        }


    }

    return (
        <>
            <div>
                <Select
                    options={statusOptionsDropdown}
                    onChange={(selectedOption: Record<string, any>) => {
                        setStatusOption(selectedOption?.name);
                        handleStatusChange(selectedOption);
                    }}
                    value={statusOption}
                    placeholder='Select Status'
                    // getOptionValue={(option) => option.value}
                    className="font-medium [&>label>span]:font-medium"
                    dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
                />
            </div>
        </>
    );
}
