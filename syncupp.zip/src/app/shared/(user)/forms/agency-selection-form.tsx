'use client';

import { Form } from '@/components/ui/form';
import {
  getClientAgencies,
  setAgencyId,
  setAgencyName,
} from '@/redux/slices/user/client/clientSlice';
import { getAllTeamMember } from '@/redux/slices/user/team-member/teamSlice';
import dynamic from 'next/dynamic';
import { useEffect } from 'react';
import { Controller } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import Select from '@/components/ui/select';
import SelectLoader from '@/components/loader/select-loader';
import { usePathname } from 'next/navigation';
import { getAllTask } from '@/redux/slices/user/task/taskSlice';
import { getAllActivity } from '@/redux/slices/user/activity/activitySlice';
import { getAllclientinvoice } from '@/redux/slices/user/client/invoice/clientinvoiceSlice';
import { getAllclientagreement } from '@/redux/slices/user/client/agreement/clientAgreementSlice';
import { getAllEvent } from '@/redux/slices/user/events/eventSlice';

export default function AgencySelectionForm() {
  const dispatch = useDispatch();
  const pathname = usePathname();
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { gridView } = useSelector((state: any) => state?.root?.task);
  const { calendarView } = useSelector((state: any) => state?.root?.activity);
  const { boardId } = useSelector((state: any) => state?.root?.board);

  // useEffect(() => { dispatch(getClientAgencies()) }, [dispatch]);
  let initialValue: Record<string, string> = {
    agency_selection: clientSliceData?.agencyName ?? '',
  };

  let agencyOptions: Record<string, any>[] =
    clientSliceData?.agencies && clientSliceData?.agencies?.length > 0
      ? clientSliceData?.agencies?.map((agency: Record<string, string>) => {
          let agency_name =
            agency?.first_name.charAt(0).toUpperCase() +
            agency?.first_name.slice(1) +
            ' ' +
            agency?.last_name.charAt(0).toUpperCase() +
            agency?.last_name.slice(1);
          return {
            name: agency_name,
            value: agency?.reference_id,
            key: agency,
          };
        })
      : [];

  const handleAgencyChange = (selectedOption: Record<string, any>) => {
    dispatch(setAgencyName(selectedOption?.name));
    dispatch(setAgencyId(selectedOption?.value));
    // console.log("pathname...", pathname)
    if (pathname === '/team') {
      dispatch(
        getAllTeamMember({
          sort_field: 'createdAt',
          sort_order: 'desc',
          agency_id: selectedOption?.value,
          pagination: true,
        })
      );
    } else if (pathname?.startsWith('/tasks/board')) {
      !gridView
        ? dispatch(
            getAllTask({
              sort_field: 'createdAt',
              sort_order: 'desc',
              board_id: boardId,
              agency_id: selectedOption?.value,
              pagination: true,
            })
          )
        : null;
    } else if (pathname === '/meetings') {
      !calendarView
        ? dispatch(
            getAllActivity({
              sort_field: 'createdAt',
              sort_order: 'desc',
              agency_id: selectedOption?.value,
              pagination: true,
            })
          )
        : null;
    } else if (pathname === '/events') {
      !calendarView
        ? dispatch(
            getAllEvent({
              sort_field: 'createdAt',
              sort_order: 'desc',
              agency_id: selectedOption?.value,
              pagination: true,
            })
          )
        : null;
    } else if (pathname.startsWith('/team/details')) {
      dispatch(
        getAllActivity({
          sort_field: 'createdAt',
          sort_order: 'desc',
          agency_id: selectedOption?.value,
          client_team_id: clientSliceData?.clientTeamId,
          pagination: true,
        })
      );
    } else if (pathname === '/client/invoice') {
      dispatch(
        getAllclientinvoice({
          sort_field: 'createdAt',
          sort_order: 'desc',
          agency_id: selectedOption?.value,
        })
      );
    } else if (pathname === '/client/agreement') {
      dispatch(
        getAllclientagreement({
          sort_field: 'createdAt',
          sort_order: 'desc',
          agency_id: selectedOption?.value,
        })
      );
    }
  };

  const onSubmit = (data: any) => {};

  if (clientSliceData?.agencies?.length === 0) {
    return <SelectLoader />;
  } else {
    return (
      <>
        <Form
          onSubmit={onSubmit}
          useFormProps={{
            defaultValues: initialValue,
            mode: 'all',
          }}
        >
          {({ control, formState: { errors } }) => (
            <div className="float-right">
              <Controller
                control={control}
                name="agency_selection"
                render={({ field: { onChange, value } }) => (
                  <Select
                    options={agencyOptions}
                    onChange={(selectedOption: Record<string, any>) => {
                      onChange(selectedOption?.name);
                      handleAgencyChange(selectedOption);
                    }}
                    value={value}
                    placeholder="Select Super Admin"
                    // getOptionValue={(option) => option.value}
                    className="font-medium"
                    dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
                  />
                )}
              />
            </div>
          )}
        </Form>
      </>
    );
  }
}
