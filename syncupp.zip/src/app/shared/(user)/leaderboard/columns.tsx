'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { Avatar, Button, Tooltip } from 'rizzui';
import goldTrophyIcon from '@public/assets/images/dashboard-icons/golden_trophy_icn.svg';
import silverTrophyIcon from '@public/assets/images/dashboard-icons/silver_trophy_icn.svg';
import bronzeTrophyIcon from '@public/assets/images/dashboard-icons/bronze_trophy_icn.svg';
import Image from 'next/image';
import cn from '@/utils/class-names';
import Link from 'next/link';
import EyeIcon from '@/components/icons/eye';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

function getTrophySymbols(value: number) {
  switch (value) {
    case 1:
      return goldTrophyIcon;
    case 2:
      return silverTrophyIcon;
    case 3:
      return bronzeTrophyIcon;
  }
}


export const GetLeadeboardColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {

  const displayName = (data: any) => {
    let displayName: string = capitalizeFirstLetter(data?.first_name) + " " + capitalizeFirstLetter(data?.last_name);
    return displayName;
  };

  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
    const signIn = useSelector((state: any) => state?.root?.signIn);
  
  let columns = [
    {
      title: (
        <div className="[&_.rc-table-cell]:!ps-0 [&_.rc-table-cell]:!pe-3">
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('serial_number'),
      dataIndex: 'serial_number',
      key: 'serial_number',
      width: 1,
      render: (value: number) => {
        // return value !== 0 ? (
        //   <Text className="font-semibold text-black flex items-center gap-2 justify-end ps-5">
        //     {(value === 1 || value === 2 || value === 3) && <Image
        //       src={getTrophySymbols(value)}
        //       alt="icon"
        //       width={19}
        //       height={19}
        //     />}
        //   </Text>
        // ) : (
        //   <Text className="font-semibold text-black ps-5"></Text>
        // );
      },
    },
    {
      title: (
        <div className="!ps-5">
          <HeaderCell
            title="Number"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'serial_number'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('serial_number'),
      dataIndex: 'serial_number',
      key: 'serial_number',
      width: 100,
      render: (value: number) => {
        return value !== 0 ? (
          <Text className={cn("font-semibold text-black flex items-center gap-2 justify-start poppins_font_number",
            (value !== 1 && value !== 2 && value !== 3) && 'ps-[26px]'
          )}>
            {(value === 1 || value === 2 || value === 3) && <Image
              src={getTrophySymbols(value)}
              alt="icon"
              width={19}
              height={19}
            />}{value}
          </Text>
        ) : (
          <Text className="font-semibold text-black poppins_font_number">0</Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'user.name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('user.name'),
      dataIndex: 'user',
      key: 'user',
      width: 200,
      render: (user: Record<string, any>) => (
        <div className='flex items-center justify-start gap-2'>
          <Avatar
            src={
              user?.profile_image &&
              `${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${user?.profile_image}`
            }
            name={user && displayName(user)}
            size='sm'
            className=" bg-[#70C5E0] font-semibold text-white"
          />
          <Text className="text-black text-[14px] font-semibold">
            {capitalizeFirstLetter(user?.first_name)} {capitalizeFirstLetter(user?.last_name)}
          </Text>
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Points"
          className='text-[#9BA1B9]'
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'totalPoints'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('totalPoints'),
      dataIndex: 'totalPoints',
      key: 'totalPoints',
      width: 200,
      render: (value: number) => {
        return value !== 0 ? (
          <Text className="font-semibold poppins_font_number text-black">
            {value}
          </Text>
        ) : (
          <Text className="font-semibold poppins_font_number text-black">0</Text>
        );
      },
    },
  ]

  if(['agency'].includes(signIn.role)) {
    columns.push(
      {
      title: (
        <HeaderCell
          title="Action"
          className='text-[#9BA1B9]'
        // sortable
        // ascending={
        //   sortConfig?.direction === 'asc' && sortConfig?.key === 'user.name'
        // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('user.name'),
      // dataIndex: 'user',
      // key: 'user',
      // width: 200,
      // render: (user: Record<string, any>) => (
      dataIndex: 'action',
      key: 'action',
      width: 120,
      render: (_: any, row: any) => (
        <div className='flex items-center justify-start gap-2'>
          <Tooltip
            size="sm"
            content={() => 'View Details'}
            placement="top"
            color="invert"
          >
            <Link
              className="rounded-md	text-[#E3E1F4]"
              href={`${routes.gamification(defaultWorkSpace?.name)}?gamification_id=${row?._id}`}
            >
              <Button
                size="sm"
                variant="outline"
                className="bg-[#E3E1F4] text-[#8C80D2]"
                aria-label={'View Member'}
              >
                <EyeIcon className="h-4 w-4" />
              </Button>
            </Link>
          </Tooltip>
        </div>
        )
    } as any)
  }

  return columns

};
