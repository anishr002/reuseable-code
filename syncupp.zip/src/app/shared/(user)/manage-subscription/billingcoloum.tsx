'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
//import AddClientForm from '../create-edit/add-client-form';
import moment from 'moment';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

function getPaymentModeName(value: string) {
  switch (value?.toLowerCase()) {
    case 'payment':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Payment</Text>
        </div>
      );
    case 'manual':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Manual</Text>
        </div>
      );
    case 'free_trial':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Free Trial</Text>
        </div>
      );
    case 'referral':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Referral</Text>
        </div>
      );
  }
}

export const billingColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => [
  // {
  //   title: (
  //     <HeaderCell
  //       title="No#"
  //       sortable
  //       ascending={
  //         sortConfig?.direction === 'asc' && sortConfig?.key === 'brand'
  //       }
  //     />
  //   ),
  //   onHeaderCell: () => onHeaderCellClick('No'),
  //   dataIndex: 'No',
  //   key: 'No',
  //   width: 100,
  //   render: (_: string, row: any, index: number) => {
  //     // const capitalizedValue = value.charAt(0).toUpperCase() + value.slice(1);
  //     return (
  //       <Text className="font-medium capitalize text-gray-700">
  //         {index + 1}
  //       </Text>
  //     );
  //   },
  // },
  {
    title: (
      <HeaderCell
        title="Payment Mode"
        sortable
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'payment_mode'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('payment_mode'),
    dataIndex: 'payment_mode',
    key: 'payment_mode',
    width: 200,
    render: (value: string) => getPaymentModeName(value),
  },
  {
    title: (
      <HeaderCell
        title="Billing Amount"
        sortable
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'amount'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('amount'),
    dataIndex: 'amount',
    key: 'amount',
    width: 200,
    render: (value: string, row: any) => {
      if (row?.payment_mode === 'payment') {
        return (
          <Text className="poppins_font_number font-medium capitalize text-gray-700">
            {row?.currency === 'INR' ? '₹' : '$'} {parseFloat(value) / 100}
          </Text>
        );
      } else if (row?.payment_mode === 'referral') {
        return (
          <Text className="poppins_font_number font-medium capitalize text-gray-700">
            {value}
          </Text>
        );
      } else if (row?.payment_mode === 'manual') {
        return (
          <Text className="poppins_font_number font-medium capitalize text-gray-700">
            -
          </Text>
        );
      } else if (row?.payment_mode === 'free_trial') {
        return <Text className="font-medium capitalize text-gray-700">-</Text>;
      }
    },
  },
  {
    title: (
      <HeaderCell
        title="Date"
        sortable
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('createdAt'),
    dataIndex: 'createdAt',
    key: 'createdAt',
    width: 200,
    render: (value: string) => (
      <Text className="poppins_font_number font-medium  text-gray-700">
        {moment(value).format('DD MMM, YYYY')}
      </Text>
    ),
  },
  {
    title: (
      <HeaderCell
        title="Seats Counts"
        sortable
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'quantity'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('quantity'),
    dataIndex: 'quantity',
    key: 'quantity',
    width: 200,
    render: (value: string) => {
      return (
        <Text className="poppins_font_number font-medium  capitalize text-gray-700">
          {value || 1}
        </Text>
      );
    },
  },
];
