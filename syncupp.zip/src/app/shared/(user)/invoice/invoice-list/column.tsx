'use client';

import Link from 'next/link';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Checkbox } from '@/components/ui/checkbox';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import DeletePopover from '@/app/shared/delete-popover';
import { ActionIcon, Badge, Button, Popover, Tooltip } from 'rizzui';

import { routes } from '@/config/routes';
import dynamic from 'next/dynamic';
import SelectLoader from '@/components/loader/select-loader';
import { useDispatch, useSelector } from 'react-redux';
import { useState } from 'react';
import { AiOutlineMail } from 'react-icons/ai';
import { FaRegFilePdf } from 'react-icons/fa';
import {
  getAllInvoiceDataTable,
  postDownloadInvoice,
  postSendInvoice,
  updateInvoiceStatus,
} from '@/redux/slices/user/invoice/invoiceSlice';
import { RiDraftLine } from 'react-icons/ri';
import moment from 'moment';
import TrashIcon from '@/components/icons/trash';
import { usePathname, useRouter } from 'next/navigation';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { checkPermission } from '../../roles-permissions/utils';
import { SlOptions } from 'react-icons/sl';
import { createinvoiceapicall } from '@/redux/slices/user/invoice/invoicesformSlice';
const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});
interface InvoiceDetailsProps {
  row: any; // Update with the type of row data
  StatusHandler: (
    status: string,
    id: string,
    setOpen: (value: boolean) => void
  ) => void; // Update with the type of StatusHandler function
}

const statusCountOptions = [
  { name: 'Draft', value: 'draft' },
  { name: 'Overdue', value: 'overdue' },
  { name: 'Unpaid', value: 'unpaid' },
  { name: 'Paid', value: 'paid' },
];

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  handlecustomeSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  row: any;
  setOpen: any;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const InvoiceColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  handlecustomeSelectAll,
  onChecked,
  row,
  setOpen,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const router = useRouter();
  const pathname = usePathname().includes('/client/details/');

  const invoiceSliceData = useSelector((state: any) => state?.root?.invoice);
  const paginationParams = useSelector(
    (state: any) => state?.root?.invoice?.paginationParams
  );
  const clientSliceData = useSelector((state: any) => state?.root?.client)
    ?.clientProfile;
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  const [selectedStatus, setSelectedStatus] = useState<{
    status: string;
    id: string;
  }>({ status: '', id: '' });
  const loading = useSelector((state: any) => state?.root?.invoice);
  const Invoiceformloader = useSelector(
    (state: any) => state?.root?.invoiceform?.loading
  );

  const EmailSend = (id: string, setOpen: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    dispatch(postSendInvoice({ invoice_id: id })).then((result: any) => {
      if (postSendInvoice.fulfilled.match(result)) {
        // console.log('resultt', result)
        if (result && result.payload.success === true) {
          dispatch(
            getAllInvoiceDataTable({
              page,
              items_per_page,
              sort_field,
              sort_order,
              search,
              client_id: pathname ? clientSliceData?._id : null,
            })
          );
          setOpen(false);
        }
      }
    });
  };

  const DownloadInvoice = (id: string, setOpen: any) => {
    dispatch(postDownloadInvoice({ invoice_id: id })).then((result: any) => {
      if (postDownloadInvoice.fulfilled.match(result)) {
        // console.log('resultt', result)
        if (result && result.payload.success === true) {
          setOpen(false);
        }
      }
    });
  };

  const StatusHandler = (status: string, id: string, setOpen: any) => {
    // handlecustomeSelectAll()

    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    // setOpen(false)
    dispatch(updateInvoiceStatus({ status: status, invoice_id: id })).then(
      (result: any) => {
        if (updateInvoiceStatus.fulfilled.match(result)) {
          // console.log('resultt', result)
          if (result && result.payload.success === true) {
            dispatch(
              getAllInvoiceDataTable({
                page,
                items_per_page,
                sort_field,
                sort_order,
                search,
                client_id: pathname ? clientSliceData?._id : null,
              })
            );
          }
        }
      }
    );
  };

  const handleStatusChange = (_funSetOpen: any, status: string, id: string) => {
    // setSelectedStatus({ status: "", id:"" });
    // if (!(status === "paid")){
    // }
    _funSetOpen(false);
    // setSelectedStatus({ status, id });
    StatusHandler(status, id, setOpen);
  };

  function getStatusBadge(status: string) {
    switch (status?.toLowerCase()) {
      case 'overdue':
        return (
          <div
            className={`${
              invoiceSliceData?.loading
                ? 'cursor-not-allowed'
                : 'cursor-pointer'
            } status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm`}
          >
            <Badge className="bg-[#AC2D2D]" renderAsDot />
            <Text className="font-medium text-[#AC2D2D]">Overdue</Text>
          </div>
        );
      case 'paid':
        return (
          <div className="status_pad flex cursor-not-allowed items-center justify-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
            <Badge className="bg-[#527C31]" renderAsDot />
            <Text className="font-medium text-[#527C31]">Paid</Text>
          </div>
        );
      case 'unpaid':
        return (
          <div
            className={`${
              invoiceSliceData?.loading
                ? 'cursor-not-allowed'
                : 'cursor-pointer'
            } status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFEAC3] px-[20px] py-[8px] text-xs sm:text-sm`}
          >
            <Badge className="bg-[#8C6825]" renderAsDot />
            <Text className="font-medium text-[#8C6825]">Unpaid</Text>
          </div>
        );
      case 'draft':
        return (
          <div
            className={`${
              invoiceSliceData?.loading
                ? 'cursor-not-allowed'
                : 'cursor-pointer'
            } status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#CBE3FB] px-[20px] py-[8px] text-xs sm:text-sm`}
          >
            <Badge className="bg-[#43688D]" renderAsDot />
            <Text className="font-medium text-[#43688D]">Draft</Text>
          </div>
        );
      default:
        return (
          <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-gray-200 px-[20px] py-[8px] text-xs sm:text-sm">
            <Badge renderAsDot className="bg-gray-400" />
            <Text className="font-medium text-gray-600">
              {capitalizeFirstLetter(status)}
            </Text>
          </div>
        );
    }
  }

  return [
    {
      title: (
        <div className="ps-3.5">
          {(['team_agency'].includes(signIn?.role)
            ? checkPermission('invoices', null, 'delete', signIn?.permission)
            : ['agency'].includes(signIn?.role)) && (
            <Checkbox
              inputClassName="checkbox-color"
              title={'Select All'}
              onChange={() => {
                handlecustomeSelectAll();
              }}
              checked={checkedItems.length === data.length}
              className="cursor-pointer"
            />
          )}
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 50,
      render: (_: any, row: any) => (
        <div className="inline-flex ps-3.5">
          {(['team_agency'].includes(signIn?.role)
            ? checkPermission('invoices', null, 'delete', signIn?.permission)
            : ['agency'].includes(signIn?.role)) && (
            <Checkbox
              inputClassName="checkbox-color"
              disabled={!(row.status === 'draft')}
              className="cursor-pointer"
              checked={checkedItems.includes(row._id)}
              {...(onChecked && { onChange: () => onChecked(row._id) })}
            />
          )}
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Number"
          // className="text-[#9BA1B9]"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'invoice_number'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('invoice_number'),
      dataIndex: 'invoice_number',
      key: 'invoice_number',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium capitalize text-black">
          {value && value != '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Customer"
          // className="text-[#9BA1B9]"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'client_full_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('client_full_name'),
      dataIndex: 'client_full_name',
      key: 'client_full_name',
      width: 200,
      render: (value: string, row: any) => (
        <Text className="poppins_font_number font-medium capitalize text-black">
          {row?.client_full_name
            ? row?.client_full_name
            : row?.custom_client?.name || '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Amount"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'total'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('total'),
      dataIndex: 'total',
      key: 'total',
      width: 200,
      render: (value: string, row: any) => (
        <Text className="poppins_font_number font-medium text-black">
          {value && value != '' ? row?.currency_symbol + ' ' + value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Invoice Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'invoice_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('invoice_date'),
      dataIndex: 'invoice_date',
      key: 'invoice_date',
      width: 200,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-medium text-black">
            {value && value != '' ? moment(value).format('DD MMM, YYYY') : '-'}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Due date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'due_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('due_date'),
      dataIndex: 'due_date',
      key: 'due_date',
      width: 200,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-medium text-black">
            {value && value != '' ? moment(value).format('DD MMM, YYYY') : '-'}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          // className="text-[#9BA1B9]"
          title="Status"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 150,
      render: (_: any, row: any, control: any) => (
        <div className="flex items-center justify-center">
          {row?.status === 'paid' ||
          (['team_agency'].includes(signIn?.role) &&
            !checkPermission(
              'invoices',
              null,
              'update',
              signIn?.permission
            )) ? (
            <>
              {getStatusBadge(
                selectedStatus?.id === row?._id
                  ? selectedStatus?.status
                  : row?.status
              )}
            </>
          ) : (
            <Popover
              placement="left"
              className="z-50 min-w-[140px] px-0"
              content={({ setOpen }: { setOpen: (value: boolean) => void }) => (
                <div className="text-black">
                  <Button
                    variant="text"
                    className="flex w-full items-center justify-start px-4 py-2.5 focus:outline-none"
                    onClick={() => {
                      handleStatusChange(setOpen, 'draft', row?._id);
                    }}
                    disabled={true}
                  >
                    Draft
                  </Button>
                  <Button
                    variant="text"
                    className="flex w-full items-center justify-start px-4 py-2.5 focus:outline-none"
                    onClick={() =>
                      handleStatusChange(setOpen, 'overdue', row?._id)
                    }
                    disabled={true}
                  >
                    Overdue
                  </Button>
                  <Button
                    variant="text"
                    className="flex w-full items-center justify-start px-4 py-2.5 focus:outline-none"
                    onClick={() =>
                      handleStatusChange(setOpen, 'unpaid', row?._id)
                    }
                    disabled={
                      row?.status === 'unpaid' ||
                      row?.status === 'paid' ||
                      row?.status === 'overdue'
                    }
                  >
                    Unpaid
                  </Button>
                  <Button
                    variant="text"
                    className="flex w-full items-center justify-start px-4 py-2.5 focus:outline-none "
                    onClick={() =>
                      handleStatusChange(setOpen, 'paid', row?._id)
                    }
                    disabled={row?.status === 'paid'}
                  >
                    Paid
                  </Button>
                </div>
              )}
            >
              {getStatusBadge(
                selectedStatus?.id === row?._id
                  ? selectedStatus?.status
                  : row?.status
              )}
            </Popover>
          )}
        </div>
      ),
    },

    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Action" align="center" />,
      dataIndex: 'action',
      key: 'action',
      width: 120,
      render: (_: string, row: Record<string, string>) => (
        <div className="flex items-center justify-center">
          <Popover
            placement="top-start"
            className="demo_test flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
            content={({ setOpen }) => (
              <div>
                <Link
                  href={`${routes.invoiceView(
                    defaultWorkSpace?.name,
                    row._id
                  )}`}
                >
                  <Button
                    variant="text"
                    className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                  >
                    View Invoice
                  </Button>
                </Link>

                <Button
                  disabled={invoiceSliceData?.loading}
                  variant="text"
                  className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                  onClick={() => {
                    DownloadInvoice(row._id, setOpen);
                  }}
                >
                  Download Invoice
                </Button>

                {(['team_agency'].includes(signIn?.role)
                  ? checkPermission(
                      'invoices',
                      null,
                      'view',
                      signIn?.permission
                    )
                  : ['agency'].includes(signIn?.role)) && (
                  <Button
                    variant="text"
                    className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                    onClick={() => {
                      EmailSend(row._id, setOpen);
                    }}
                    disabled={invoiceSliceData?.loading}
                  >
                    Send Invoice
                  </Button>
                )}
                {(['team_agency'].includes(signIn?.role)
                  ? checkPermission(
                      'invoices',
                      null,
                      'create',
                      signIn?.permission
                    )
                  : ['agency'].includes(signIn?.role)) && (
                  <Button
                    variant="text"
                    className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                    onClick={() => {
                      const formdata: any = new FormData();

                      formdata.append('invoiceId', row._id);
                      formdata.append('isDuplicate', true);

                      dispatch(createinvoiceapicall(formdata)).then(
                        (result: any) => {
                          if (createinvoiceapicall.fulfilled.match(result)) {
                            if (result && result.payload.success === true) {
                              let {
                                page,
                                items_per_page,
                                sort_field,
                                sort_order,
                                search,
                              } = paginationParams;
                              dispatch(
                                getAllInvoiceDataTable({
                                  page,
                                  items_per_page,
                                  sort_field,
                                  sort_order,
                                  search,
                                  client_id: pathname
                                    ? clientSliceData?._id
                                    : null,
                                })
                              );
                            }
                          }
                        }
                      );
                    }}
                    disabled={Invoiceformloader}
                  >
                    Duplicate Invoice
                  </Button>
                )}

                {row?.status === 'draft' &&
                  (['team_agency'].includes(signIn?.role)
                    ? checkPermission(
                        'invoices',
                        null,
                        'update',
                        signIn?.permission
                      )
                    : ['agency'].includes(signIn?.role)) && (
                    <Link
                      href={
                        pathname
                          ? `${routes.invoiceEdit(
                              defaultWorkSpace?.name,
                              row._id
                            )}?reference=${clientSliceData?._id}`
                          : routes.invoiceEdit(defaultWorkSpace?.name, row._id)
                      }
                      passHref
                    >
                      <Button
                        variant="text"
                        className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                        disabled={row?.status !== 'draft'}
                      >
                        Edit Invoice
                      </Button>
                    </Link>
                  )}

                {row?.status !== 'draft' &&
                  (['team_agency'].includes(signIn?.role)
                    ? checkPermission(
                        'invoices',
                        null,
                        'update',
                        signIn?.permission
                      )
                    : ['agency'].includes(signIn?.role)) && (
                    <Link
                      href={
                        pathname
                          ? `${routes.invoiceEdit(
                              defaultWorkSpace?.name,
                              row._id
                            )}?reference=${clientSliceData?._id}`
                          : routes.invoiceEdit(defaultWorkSpace?.name, row._id)
                      }
                      passHref
                    >
                      <Button
                        variant="text"
                        className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      >
                        Edit Recurring
                      </Button>
                    </Link>
                  )}

                {row?.status === 'draft' &&
                  (['team_agency'].includes(signIn?.role)
                    ? checkPermission(
                        'invoices',
                        null,
                        'delete',
                        signIn?.permission
                      )
                    : ['agency'].includes(signIn?.role)) && (
                    <DeletePopover
                      title={`Delete the Invoice`}
                      isInvoiceDelete={true}
                      deleteButtonClass="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      description={`Are you sure you want to delete?`}
                      onDelete={() => {
                        onDeleteItem(
                          [row._id],
                          currentPage,
                          pageSize,
                          data?.length <= 1 ? true : false,
                          sortConfig,
                          searchTerm
                        );
                        setOpen(false);
                      }}
                    />
                  )}
              </div>
            )}
          >
            <ActionIcon title="More Options" variant="text">
              <SlOptions className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
            </ActionIcon>
          </Popover>
        </div>
      ),
    },
  ];
};
