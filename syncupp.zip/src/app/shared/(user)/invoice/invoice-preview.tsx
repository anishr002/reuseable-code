import { formatAddress } from '@/utils/common-functions';
import moment from 'moment';
import Image from 'next/image';
import SimpleBar from 'simplebar-react';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';


const InvoicePreview = (props: any) => {
    const { data } = props;

    // Calculate Total Tax
    const calculateTotalTax = (invoiceContent: any) => {
        let total = 0;

        if (
            invoiceContent &&
            Array.isArray(invoiceContent) &&
            invoiceContent.length > 0
        ) {
            for (let index = 0; index < invoiceContent.length; index++) {
                const item: any = invoiceContent[index];
                if (
                    item &&
                    typeof item.qty === 'number' &&
                    typeof item.rate === 'number' &&
                    typeof item.tax === 'number'
                ) {
                    const itemTotal =
                        item.rate * item.qty + ((item.rate * item.qty) / 100) * item.tax;
                    total += parseFloat(itemTotal.toFixed(2));
                }
            }
        }

        return total.toFixed(2);
    }

    // Calculate Discount
    const calculateDiscount = (invoiceContent: any, discount: number) => {
        const total: any = calculateTotalTax(invoiceContent);
        const discountAmount = (total * (discount || 0)) / 100;
        return discountAmount.toFixed(2);
    }

    // Calculate Total After Discount
    const calculateTotalAfterDiscount = (invoiceContent: any, discount: number) => {
        const total: any = calculateTotalTax(invoiceContent);
        const discountAmount = (total * (discount || 0)) / 100;
        return (total - discountAmount).toFixed(2);
    }

    return (
        <>
            <div className="flex items-center justify-between ">
                <div>
                    <p className="pt-5  text-[22px] font-bold leading-[29.26px] text-[#5850EC]">
                        Invoice
                    </p>
                    <p className="mt-1 text-[13px] font-normal leading-[13.3px] text-[#11181C]">
                        No:{' '}
                        {data?.invoice_number && data?.invoice_number != ''
                            ? data?.invoice_number
                            : ''}
                    </p>
                </div>
            </div>
            <div className="mt-2 flex flex-col space-y-1.5">
                <div className="gap flex items-center gap-12">
                    <p className="text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
                        Invoice Date
                    </p>
                    <p className="text-[13px] font-normal leading-[13.6px] text-[#11181C] ">
                        {data?.invoice_date
                            ? moment(data?.invoice_date).format('DD/MM/YYYY')
                            : '-'}
                    </p>
                </div>
                <div className="flex items-center gap-[66px]">
                    <p className="text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
                        Due Date
                    </p>
                    <p className="text-[13px] font-normal leading-[13.6px] text-[#11181C] ">
                        {data?.due_date
                            ? moment(data?.due_date).format('DD/MM/YYYY')
                            : '-'}
                    </p>
                </div>
            </div>

            <div className="mt-5 flex h-auto w-auto items-start justify-between rounded-[12px] bg-[#F3F4F6] p-[22px] ">
                <div className="space-y-2">
                    <p className="font-inter text-[13px] font-bold leading-[13.3px] text-[#687076]">
                        Customer Details
                    </p>
                    <p className="font-inter text-[13px] font-normal leading-[13.3px]  text-[#11181C] ">
                        {data?.to?.client_full_name
                            ? data?.to?.client_full_name
                            : '-'}
                    </p>
                    <p className="font-inter text-[13px] font-normal leading-[13.3px]  text-[#11181C] ">
                        {data?.to?.email ? data?.to?.email : '-'}
                    </p>
                    <p className="font-inter text-[13px] font-normal leading-[13.3px]  text-[#11181C] ">
                        {data?.to?.contact_number ? data?.to?.contact_number : '-'}
                    </p>
                </div>

                {/* Vertical Line with Rotation */}
                <div className="mt-10 h-[1px] w-[62.03px] rotate-90 border border-[#D1D5DB]"></div>

                <div className="space-y-2">
                    <p className="font-inter text-[13px] font-bold leading-[13.3px] text-[#687076]">
                        Billing Address
                    </p>
                    <p className="w-[25vh] whitespace-normal break-words font-inter text-[13px] font-normal leading-[13.3px] text-[#11181C]">
                        {data?.to?.address
                            ? formatAddress(
                                data?.to?.address,
                                data?.to?.city?.name,
                                data?.to?.state?.name,
                                data?.to?.country?.name,
                                data?.to?.pincode
                            )
                            : 'No address available'}
                    </p>
                </div>
            </div>
            {/* Invoice Table */}
            <div className="mt-6 w-auto">
                <SimpleBar className="max-h-[210px] overflow-y-auto">
                    <table className="w-full border-collapse text-left">
                        <thead className="sticky top-0 z-10 bg-[#F0F5FF]">
                            <tr className="h-[32px] border border-[#F1F3F5] font-inter text-[13px] font-bold leading-[13.3px] text-[#687076]">
                                <th className="border border-[#F1F3F5] p-3 first:rounded-tl-[4px] last:rounded-tr-[4px]">
                                    #
                                </th>
                                <th className="border border-[#F1F3F5] p-3">Item Name</th>
                                <th className="border border-[#F1F3F5] p-3">Qty</th>
                                <th className="border border-[#F1F3F5] p-3">
                                    Unit Price
                                </th>
                                <th className="border border-[#F1F3F5] p-3">Tax</th>
                                <th className="border border-[#F1F3F5] p-3 last:rounded-tr-[4px]">
                                    Total
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {data?.invoice_content?.map((item: any, index: any) => (
                                <tr
                                    key={index}
                                    className="border-b border-[#F1F3F5] font-inter text-[13px] font-normal leading-[13.3px] text-[#11181C]"
                                >
                                    <td className="p-3">{index + 1}</td>
                                    <td className="max-w-[150px] overflow-hidden truncate whitespace-nowrap p-3">
                                        {item?.item ? item?.item : '-'}
                                    </td>
                                    <td className="p-3">{item?.qty ? item?.qty : '-'}</td>
                                    <td className="min-w-[80px] whitespace-nowrap p-3">
                                        {item?.rate
                                            ? `${data?.currency_symbol}${item?.rate}`
                                            : `-`}
                                    </td>
                                    <td className="p-3">
                                        {item?.tax
                                            ? `${data?.currency_symbol}${item?.tax}`
                                            : `${data?.currency_symbol}00`}{' '}
                                        <p className="mt-1 font-inter text-[11px] font-normal leading-[13.3px] text-[#7E868C]">
                                            {item?.tax && item?.tax > 0
                                                ? 'Taxable'
                                                : 'Non-Taxable'}
                                        </p>
                                    </td>
                                    <td className="p-3">
                                        {item?.rate && item?.qty
                                            ? `${data?.currency_symbol}${(
                                                item?.rate * item?.qty +
                                                (item?.rate * item?.qty * item?.tax) / 100
                                            ).toFixed(2)}`
                                            : `${data?.currency_symbol}00`}{' '}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </SimpleBar>
            </div>

            {/* Invoice Total */}
            <div className="ml-auto mt-[60px] flex w-fit flex-col space-y-2 px-5 text-right">
                <div className="flex w-full items-center justify-between gap-[112px]">
                    <p className="font-inter text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
                        Subtotal
                    </p>
                    <p className="text-[13px] font-normal leading-[13.6px] text-black">
                        {data?.invoice_content
                            ? `${data?.currency_symbol}${calculateTotalTax(
                                data?.invoice_content
                            )}`
                            : `${data?.currency_symbol}00`}
                    </p>
                </div>
                <div className="flex w-full items-center justify-between gap-[112px]">
                    <p className="font-inter text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
                        Discount
                    </p>
                    <p className="text-[13px] font-normal leading-[13.6px] text-[#11181C]">
                        -
                        {data?.invoice_content && data?.discount > 0
                            ? `${data?.currency_symbol}${calculateDiscount(
                                data?.invoice_content,
                                data?.discount
                            )}`
                            : `${data?.currency_symbol}00`}
                    </p>
                </div>
                <div className="flex w-full items-center justify-between gap-[112px]">
                    <p className="font-inter text-[14px] font-bold leading-[18.62px] text-[#11181C]">
                        Grand Total
                    </p>
                    <p className="font-inter text-[14px] font-bold leading-[18.62px] text-[#5850EC]">
                        {data?.currency_symbol}{' '}
                        {calculateTotalAfterDiscount(
                            data?.invoice_content,
                            data?.discount
                        )}
                    </p>
                </div>
            </div>

            <div className="mt-[70px] font-inter text-[13px] font-normal leading-[15.96px] text-[#687076]">
                {data?.terms_conditions
                    ? data?.terms_conditions
                    : `Please pay within 15 days from the date of invoice, overdue
              interest @ 14% will be charged on delayed payments.`}
            </div>

            <div className="mt-3 w-auto border border-[#F1F3F5]"></div>

            <div className="mt-3 flex items-center gap-3">
                <span className="text-[13px] font-medium leading-[20px] text-[#141414]">
                    Created with
                </span>
                <Image
                    src={syncUppLogo}
                    alt="Syncupp"
                    width={100}
                    height={100}
                    className="h-7 w-[60px]"
                />
            </div></>
    )
}

export default InvoicePreview
