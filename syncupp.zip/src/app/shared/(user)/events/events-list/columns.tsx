'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import CustomModalButton from '@/app/shared/custom-modal-button';
import { Badge, Button, Popover } from 'rizzui';
import moment from 'moment';
import { useSelector } from 'react-redux';
import { usePathname } from 'next/navigation';
import EventForm from '../create-edit-events/event-form';
import CancelPopover from '@/app/shared/cancel-popover';
import DetailsEvents from '../create-edit-events/details-event';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (id: string | string[], currentPage?: any, countPerPage?: number, Islastitem?: boolean, sortConfig?: Record<string, string>, searchTerm?: string) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

function getStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'pending':
      return (
        <div className="flex items-center">
          <Badge color="warning" renderAsDot />
          <Text className="ms-2 font-medium text-orange-dark">Pending</Text>
        </div>
      );
    case 'completed':
      return (
        <div className="flex items-center">
          <Badge color="success" renderAsDot />
          <Text className="ms-2 font-medium text-green-dark">Completed</Text>
        </div>
      );
    case 'overdue':
      return (
        <div className="flex items-center">
          <Badge color="danger" renderAsDot />
          <Text className="ms-2 font-medium text-red-dark">Overdue</Text>
        </div>
      );
    case 'in_progress':
      return (
        <div className="flex items-center">
          <Badge color='secondary' renderAsDot />
          <Text className="ms-2 font-medium text-secondary-dark">In Progress</Text>
        </div>
      );
    case 'cancel':
      return (
        <div className="flex items-center">
          <Badge color="danger" renderAsDot />
          <Text className="ms-2 font-medium text-red-dark">Cancel</Text>
        </div>
      );
    default:
      return (
        <div className="flex items-center">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="ms-2 font-medium text-gray-600">{status}</Text>
        </div>
      );
  }
}


export const GetEventColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm
}: Columns) => {

  const signIn = useSelector((state: any) => state?.root?.signIn)
  const pathname = usePathname();
  // console.log("pathname is....", pathname.startsWith('/client/details'))


  return [
    {
      title: (
        <div className="ps-3.5">
          <HeaderCell
            title="Event Name"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'title'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('title'),
      dataIndex: 'title',
      key: 'title',
      width: 200,
      render: (value: string) => (
        <Text className="ps-3.5 font-medium w-28 text-gray-700 truncate normal-case">{value?.charAt(0)?.toUpperCase() + value?.slice(1)}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Event Location"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'agenda'
          }
        />),
      onHeaderCell: () => onHeaderCellClick('agenda'),
      dataIndex: 'agenda',
      key: 'agenda',
      width: 200,
      render: (value: string) => (
        <Text className="ps-3.5 font-medium w-28 text-gray-700 truncate normal-case">{value?.charAt(0)?.toUpperCase() + value?.slice(1)}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Start Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'due_date'
          }
        />),
      onHeaderCell: () => onHeaderCellClick('due_date'),
      dataIndex: 'due_date',
      key: 'due_date',
      width: 400,
      render: (value: string) => (
        <Text className="font-medium text-gray-700">{moment(value).format("DD MMM, YYYY")}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Start Time"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'event_start_time'
          }
        />),
      onHeaderCell: () => onHeaderCellClick('event_start_time'),
      dataIndex: 'event_start_time',
      key: 'event_start_time',
      width: 400,
      render: (value: string) => (
        <Text className="font-medium text-gray-700">{moment(value).format("hh:mm A")}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="End Time"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'event_end_time'
          }
        />),
      onHeaderCell: () => onHeaderCellClick('event_end_time'),
      dataIndex: 'event_end_time',
      key: 'event_end_time',
      width: 400,
      render: (value: string) => (
        <Text className="font-medium text-gray-700">{moment(value).format("hh:mm A")}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="End Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'recurring_end_date'
          }
        />),
      onHeaderCell: () => onHeaderCellClick('recurring_end_date'),
      dataIndex: 'recurring_end_date',
      key: 'recurring_end_date',
      width: 400,
      render: (value: string) => (
        <>
          {value && value != "" ? <Text className="font-medium text-gray-700">{moment(value).format("DD MMM, YYYY")}</Text> : <Text className="font-medium text-gray-700">-</Text>}
        </>

      ),
    },
    {
      title: (
        <HeaderCell
          title="Email"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
          }
        />),
      onHeaderCell: () => onHeaderCellClick('email'),
      dataIndex: 'email',
      key: 'email',
      width: 400,
      render: (value: string[]) => {
        // console.log("emails...", value)
        return (
          <div>
            {
              value && value?.length > 0 ? value?.map((valuee: string, index: any) => {
                if (index >= 1) {
                  return null; // Skip rendering if not showing all and index is greater than or equal to 2
                }

                return (
                  <div key={index}>
                    <Text className="font-medium text-gray-700">
                      {valuee}
                    </Text>
                    {index === 0 && value.length > 1 &&
                      <Popover
                        placement="top"
                        className="z-[99] min-w-[135px] px-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                        content={({ setOpen }) => (
                          <div className="p-2 text-gray-900">
                            {
                              value?.map((email: string, index: any) => (
                                <Text key={index} className="font-medium text-gray-700">
                                  {email}
                                </Text>
                              ))
                            }
                          </div>
                        )}
                      >
                        <div className="font-medium text-blue-700">More...</div>
                      </Popover>}
                  </div>
                )
              }) : (<Text className="font-medium text-gray-700">-</Text>)
            }
          </div>
        )
      },
    },
    // {
    //   title: (
    //     <HeaderCell
    //       title="Status"
    //       sortable
    //       ascending={
    //         sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
    //       }
    //     />),
    //   onHeaderCell: () => onHeaderCellClick('status'),
    //   dataIndex: 'status',
    //   key: 'status',
    //   width: 200,
    //   render: (value: any) => getStatusBadge(value),
    // },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions" />,
      dataIndex: 'action',
      key: 'action',
      width: 120,
      render: (_: string, row: any) => {
        return (
          <div>
            <div className="flex items-center gap-3 pe-4">
              {/* {(signIn?.role !== 'client' && signIn?.role !== 'team_client' && row?.activity_status?.name !== 'completed' && row?.activity_status?.name !== 'cancel') && */}
              <CustomModalButton
                icon={<PencilIcon className="h-4 w-4" />}
                view={<EventForm row={row} title="Edit Event" />}
                customSize="700px"
                title='Edit Event'
              />
              {/* } */}
              <CustomModalButton
                icon={<EyeIcon className="h-4 w-4" />}
                view={<DetailsEvents data={row} />}
                customSize="700px"
                title='View Event'
              />
              <CancelPopover
                  title={`Cancel the Event`}
                  description={`Are you sure you want to cancel the Event?`}
                  onDelete={() => onDeleteItem(row._id, currentPage, pageSize, data?.length <= 1 ? true : false, sortConfig, searchTerm)}
                />
            </div>
          </div>
        );
      },
    },
  ];
}
