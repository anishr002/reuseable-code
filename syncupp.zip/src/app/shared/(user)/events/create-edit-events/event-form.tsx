'use client';

import { Button } from '@/components/ui/button';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';
import { useModal } from '@/app/shared/modal-views/use-modal';
import cn from '@/utils/class-names';
import { Input } from '@/components/ui/input';
import { useEffect, useState } from 'react';
import { handleKeyDown } from '@/utils/common-functions';
import { DatePicker } from '@/components/ui/datepicker';
import moment from 'moment';
import { ActionIcon, Switch, Text, Textarea, Title } from 'rizzui';
import { GiNotebook } from 'react-icons/gi';
import { getAllActivity } from '@/redux/slices/user/activity/activitySlice';
import { PiTagBold, PiTrashFill, PiXBold } from 'react-icons/pi';
import {
  AddEventFormSchema,
  addEventFormSchema,
} from '@/utils/validators/add-events.schema';
import {
  getAllEvent,
  getEventById,
  patchEditEvent,
  postAddEvent,
} from '@/redux/slices/user/events/eventSlice';
import { MdOutlineAttachEmail } from 'react-icons/md';

export default function EventForm(props: any) {
  const { title, row, startDate, endDate } = props;
  // console.log("row data....", row);

  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const router = useRouter();

  const [loader, setLoader] = useState(false);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { calendarView } = useSelector((state: any) => state?.root?.activity);
  const eventSliceData = useSelector((state: any) => state?.root?.event);

  const [itemText, setItemText] = useState<string>('');
  const [emails, setEmails] = useState<string[]>([]);
  const [isTextAreaVisible, setTextAreaVisible] = useState(false);
  const [recurringStatus, setRecurringStatus] = useState(false);
  const handleAddNoteClick = () => {
    setTextAreaVisible((prevVisible) => !prevVisible);
  };

  // console.log("item text.....", itemText);

  // let data = row;

  const initialValues: AddEventFormSchema = {
    event_name: '',
    event_location: '',
    due_date: new Date(),
    recurring_date: new Date(),
    start_time: new Date(),
    end_time: new Date(),
    emailInput: itemText,
    email: [],
    notes: '',
  };

  useEffect(() => {
    row &&
      dispatch(getEventById({ eventId: row?._id })).then((result: any) => {
        if (getEventById.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
          }
        }
      });
  }, [row, dispatch]);

  let [data] = eventSliceData?.event ?? [{}];

  // const dueee_date = moment(data?.due_date).toDate();
  // console.log(dueee_date, "formateedddd", data?.due_date)

  let defaultValuess = {
    event_name: data?.title,
    event_location: data?.agenda,
    due_date: moment(data?.due_date).toDate(),
    recurring_date: data?.recurring_end_date !== null ? moment(data?.recurring_end_date).toDate() : new Date(),
    start_time: moment(data?.event_start_time).toDate(),
    end_time: moment(data?.event_end_time).toDate(),
    emailInput: itemText,
    email: data?.email,
    notes: data?.internal_info,
  };

  useEffect(() => {
    if (title === 'Edit Event') {
      setEmails(data?.email);
    }
  }, [title, data]);

  useEffect(() => {
    if (title === 'Edit Event' &&  data && data?.recurring_end_date !== null) {
      setRecurringStatus(true);
    }
  }, [title, data?.recurring_end_date]);

  useEffect(() => {
    if (title === 'Edit Event' && data?.internal_info) {
      setTextAreaVisible(true);
    }
  }, [title, data?.internal_info]);

  const handleSwitchChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    // console.log("switch....", event?.target?.checked)
    if (event?.target?.checked) {
      setRecurringStatus(true);
    } else {
      setRecurringStatus(false);
    }
  };

  const onSubmit: SubmitHandler<AddEventFormSchema> = (dataa) => {
    // console.log('Add event form dataa---->', dataa);
    setLoader(true);

    let formData: any;

    if (recurringStatus) {
      formData = {
        title: dataa?.event_name,
        agenda: dataa?.event_location,
        due_date: moment(dataa?.due_date).format('DD-MM-YYYY'),
        event_start_time: moment.utc(dataa?.start_time).format('HH:mm'),
        event_end_time: moment.utc(dataa?.end_time).format('HH:mm'),
        recurring_end_date: moment(dataa?.recurring_date).format('DD-MM-YYYY'),
        email: emails,
        internal_info: dataa?.notes,
      };
    } else {
      formData = {
        title: dataa?.event_name,
        agenda: dataa?.event_location,
        due_date: moment(dataa?.due_date).format('DD-MM-YYYY'),
        event_start_time: moment.utc(dataa?.start_time).format('HH:mm'),
        event_end_time: moment.utc(dataa?.end_time).format('HH:mm'),
        recurring_end_date: null,
        email: emails,
        internal_info: dataa?.notes,
      };
    }

    console.log('Add event form dataa---->', formData);

    // const filteredFormData = Object.fromEntries(
    //   Object.entries(formData).filter(([_, value]) => value !== undefined && value !== '')
    // );

    if (title === 'New Event') {
      if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
        dispatch(postAddEvent(formData)).then((result: any) => {
          if (postAddEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setLoader(false);

              if (result?.payload?.data?.event_exist) {
                openModal({
                  view: (
                    <ConfirmationEventModal
                      data={{ ...formData }}
                      title={title}
                    />
                  ),
                  customSize: '400px',
                });
              } else {
                if (title === 'New Event') {
                  dispatch(
                    getAllEvent({
                      sort_field: 'createdAt',
                      sort_order: 'desc',
                      pagination: true,
                    })
                  );
                }

                if (calendarView) {
                  const firstDayOfMonth = moment()
                    .startOf('month')
                    .format('DD-MM-YYYY');
                  const endDayOfMonth = moment()
                    .endOf('month')
                    .format('DD-MM-YYYY');
                  dispatch(
                    getAllActivity({
                      sort_field: 'createdAt',
                      sort_order: 'desc',
                      filter: {
                        date: 'period',
                        start_date: firstDayOfMonth,
                        end_date: endDayOfMonth,
                      },
                      pagination: false,
                    })
                  );
                }
                closeModal();
              }
            } else {
              setLoader(false);
            }
          }
        });
      } else {
        dispatch(
          postAddEvent({ ...formData, agency_id: clientSliceData?.agencyId })
        ).then((result: any) => {
          if (postAddEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setLoader(false);

              if (result?.payload?.data?.event_exist) {
                openModal({
                  view: (
                    <ConfirmationEventModal
                      data={{
                        ...formData,
                        agency_id: clientSliceData?.agencyId,
                      }}
                      title={title}
                    />
                  ),
                  customSize: '400px',
                });
              } else {
                if (title === 'New Event') {
                  dispatch(
                    getAllEvent({
                      sort_field: 'createdAt',
                      sort_order: 'desc',
                      agency_id: clientSliceData?.agencyId,
                      pagination: true,
                    })
                  );
                }

                if (calendarView) {
                  const firstDayOfMonth = moment()
                    .startOf('month')
                    .format('DD-MM-YYYY');
                  const endDayOfMonth = moment()
                    .endOf('month')
                    .format('DD-MM-YYYY');
                  dispatch(
                    getAllActivity({
                      sort_field: 'createdAt',
                      sort_order: 'desc',
                      filter: {
                        date: 'period',
                        start_date: firstDayOfMonth,
                        end_date: endDayOfMonth,
                      },
                      agency_id: clientSliceData?.agencyId,
                      pagination: false,
                    })
                  );
                }
                closeModal();
              }
            } else {
              setLoader(false);
            }
          }
        });
      }
    } else {
      if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
        dispatch(patchEditEvent({ ...formData, _id: data._id })).then(
          (result: any) => {
            if (patchEditEvent.fulfilled.match(result)) {
              if (result && result.payload.success === true) {
                setLoader(false);
                // console.log("result is....", result?.payload?.data?.event_exist)

                if (result?.payload?.data?.event_exist) {
                  openModal({
                    view: (
                      <ConfirmationEventModal
                        data={{ ...formData, _id: data._id }}
                        title={title}
                      />
                    ),
                    customSize: '400px',
                  });
                } else {
                  if (title === 'Edit Event') {
                    dispatch(
                      getAllEvent({
                        sort_field: 'createdAt',
                        sort_order: 'desc',
                        pagination: true,
                      })
                    );
                  }

                  if (calendarView) {
                    const firstDayOfMonth = moment()
                      .startOf('month')
                      .format('DD-MM-YYYY');
                    const endDayOfMonth = moment()
                      .endOf('month')
                      .format('DD-MM-YYYY');
                    dispatch(
                      getAllActivity({
                        sort_field: 'createdAt',
                        sort_order: 'desc',
                        filter: {
                          date: 'period',
                          start_date: firstDayOfMonth,
                          end_date: endDayOfMonth,
                        },
                        pagination: false,
                      })
                    );
                  }
                  closeModal();
                }
              } else {
                setLoader(false);
              }
            }
          }
        );
      } else {
        dispatch(
          patchEditEvent({
            ...formData,
            _id: data._id,
            agency_id: clientSliceData?.agencyId,
          })
        ).then((result: any) => {
          if (patchEditEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setLoader(false);

              if (result?.payload?.data?.event_exist) {
                openModal({
                  view: (
                    <ConfirmationEventModal
                      data={{
                        ...formData,
                        _id: data._id,
                        agency_id: clientSliceData?.agencyId,
                      }}
                      title={title}
                    />
                  ),
                  customSize: '400px',
                });
              } else {
                if (title === 'Edit Event') {
                  dispatch(
                    getAllEvent({
                      sort_field: 'createdAt',
                      sort_order: 'desc',
                      agency_id: clientSliceData?.agencyId,
                      pagination: true,
                    })
                  );
                }

                if (calendarView) {
                  const firstDayOfMonth = moment()
                    .startOf('month')
                    .format('DD-MM-YYYY');
                  const endDayOfMonth = moment()
                    .endOf('month')
                    .format('DD-MM-YYYY');
                  dispatch(
                    getAllActivity({
                      sort_field: 'createdAt',
                      sort_order: 'desc',
                      filter: {
                        date: 'period',
                        start_date: firstDayOfMonth,
                        end_date: endDayOfMonth,
                      },
                      agency_id: clientSliceData?.agencyId,
                      pagination: false,
                    })
                  );
                }
                closeModal();
              }
            } else {
              setLoader(false);
            }
          }
        });
      }
    }
  };

  if (!eventSliceData?.event && title === 'Edit Event') {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <>
        <Form<AddEventFormSchema>
          validationSchema={addEventFormSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'all',
            defaultValues: defaultValuess,
          }}
          className=" overflow-visible p-10 [&_label]:font-medium"
        >
          {({ register, control, formState: { errors }, setValue }) => (
            <div className="space-y-7">
              <div className="mb-6 flex items-center justify-between">
                <Title as="h3" className="text-xl xl:text-2xl">
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-gray-500 hover:!text-gray-900"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>
              <div className={cn('grid grid-cols-1')}>
                <div className="grid gap-7">
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    label="Event Name *"
                    placeholder="Enter Event name"
                    className="[&>label>span]:font-medium"
                    {...register('event_name')}
                    error={errors?.event_name?.message}
                  />
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    label="Event Location *"
                    placeholder="Enter Event location"
                    className="[&>label>span]:font-medium"
                    {...register('event_location')}
                    error={errors?.event_location?.message}
                  />
                  <div
                    className={cn(
                      'grid grid-cols-1 items-center gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3'
                    )}
                  >
                    <Controller
                      name="due_date"
                      control={control}
                      render={({ field: { value, onChange } }) => {
                        return (
                          <DatePicker
                            placeholderText="Select start date"
                            selected={value}
                            inputProps={{
                              label: 'Start Date *',
                              error: errors?.due_date?.message,
                            }}
                            onChange={onChange}
                            selectsStart
                            startDate={value}
                            minDate={new Date()}
                            // showTimeSelect
                            dateFormat="MMMM dd, yyyy"
                          />
                        );
                      }}
                    />
                    <Controller
                      name="start_time"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <DatePicker
                          placeholderText="Select start time"
                          selected={value}
                          inputProps={{
                            label: 'Start Time *',
                            error: errors?.start_time?.message,
                          }}
                          onChange={onChange}
                          showTimeSelect
                          showTimeSelectOnly
                          dateFormat="hh:mm aa"
                          // onInputError={errors?.due_date?.message as string}
                        />
                      )}
                    />
                    <Controller
                      name="end_time"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <DatePicker
                          placeholderText="Select end time"
                          selected={value}
                          inputProps={{
                            label: 'End Time *',
                            error: errors?.end_time?.message,
                          }}
                          onChange={onChange}
                          showTimeSelect
                          showTimeSelectOnly
                          dateFormat="hh:mm aa"
                        />
                      )}
                    />
                  </div>
                  <div className={cn('flex h-[70px] items-center gap-12')}>
                    <div className="flex w-auto items-end justify-start">
                      <Switch
                        className="[&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                        label="Recurring"
                        labelPlacement="left"
                        variant="active"
                        checked={recurringStatus}
                        onChange={(event) => handleSwitchChange(event)}
                      />
                    </div>

                    {recurringStatus && (
                      <div className="custom_cal-event">
                        <div className="w-full">
                          <Controller
                            name="recurring_date"
                            control={control}
                            render={({ field: { value, onChange } }) => (
                              <DatePicker
                                placeholderText="Select recurring end date"
                                selected={value}
                                inputProps={{
                                  label: 'Recurring End Date',
                                  error: errors?.recurring_date?.message,
                                }}
                                onChange={onChange}
                                selectsStart
                                startDate={value}
                                minDate={new Date()}
                                // showTimeSelect
                                popperPlacement="top-start"
                                dateFormat="MMMM dd, yyyy"
                              />
                            )}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  <div>
                    <ItemCrud
                      name="Email"
                      itemText={itemText}
                      setItemText={setItemText}
                      items={emails}
                      setEmails={setEmails}
                      register={register}
                      setValue={setValue}
                      errors={errors}
                    />
                  </div>
                  <span
                    className="flex cursor-pointer items-center gap-2 font-medium"
                    onClick={handleAddNoteClick}
                  >
                    <GiNotebook className="h-[25px] w-[25px]" />
                    <Text>Add Internal Note</Text>
                  </span>
                  {isTextAreaVisible && (
                    <Textarea
                      placeholder="Add your internal note..."
                      {...register('notes')}
                      error={errors?.notes?.message as string}
                      // textareaClassName="h-20"
                      // className="col-span-2"
                    />
                  )}
                </div>
              </div>
              <div>
                <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
                  <div>
                    <Button
                      variant="outline"
                      className="@xl:w-auto dark:hover:border-gray-400"
                      onClick={() => closeModal()}
                    >
                      Cancel
                    </Button>
                  </div>
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      type="submit"
                      className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
                      disabled={eventSliceData?.loading}
                    >
                      Save
                      {eventSliceData?.loading && (
                        <Spinner
                          size="sm"
                          tag="div"
                          className="ms-3"
                          color="white"
                        />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </Form>
      </>
    );
  }
}

function ItemCrud(props: any): JSX.Element {
  const {
    name,
    itemText,
    setItemText,
    items,
    setEmails,
    register,
    setValue,
    errors,
  } = props;
  // const [itemText, setItemText] = useState<string>('');

  function handleItemAdd(): void {
    if (itemText.trim() !== '') {
      const newItem: string = itemText;

      setEmails([...items, newItem]);
      setValue('email', [...items, newItem]);
      setItemText('');
    }
  }

  function handleItemRemove(text: string): void {
    const updatedItems = items.filter((item: any) => item !== text);
    setEmails(updatedItems);
  }

  return (
    <div>
      <div className="flex">
        <Input
          value={itemText}
          onKeyDown={handleKeyDown}
          label="Attendees"
          placeholder={`Enter an ${name}`}
          // onChange={(e) => setItemText(e.target.value)}
          prefix={<MdOutlineAttachEmail className="h-4 w-4" />}
          className="w-full [&>label>span]:font-medium"
          {...register('emailInput', {
            onChange: (e: any) => setItemText(e.target.value),
          })}
          error={errors?.emailInput?.message}
        />
        <input type="hidden" {...register('email', { value: items })} />
        <Button
          onClick={() => {
            if (!errors?.emailInput) {
              // Check if there's no error in emailInput
              handleItemAdd(); // Submit the form if no error
            }
          }}
          className="ms-4 mt-[26px] shrink-0 text-sm @lg:ms-5 dark:bg-gray-100 dark:text-white dark:active:bg-gray-100"
        >
          Add {name}
        </Button>
      </div>

      {items && items?.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {items?.map((text: any, index: any) => (
            <div
              key={index}
              className="flex items-center rounded-full border border-gray-300 py-1 pe-2.5 ps-3 text-sm font-medium text-gray-700"
            >
              {text}
              <button
                onClick={() => handleItemRemove(text)}
                className="ps-2 text-gray-500 hover:text-gray-900"
              >
                <PiXBold className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function ConfirmationEventModal(props: any) {
  const { data, title } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const eventSliceData = useSelector((state: any) => state?.root?.event);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { calendarView } = useSelector((state: any) => state?.root?.activity);
  const clientSliceData = useSelector((state: any) => state?.root?.client);

  const handleYesClick = () => {
    if (title === 'New Event') {
      if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
        dispatch(
          postAddEvent({ ...data, createEventIfEmailExists: 'yes' })
        ).then((result: any) => {
          if (postAddEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              closeModal();

              if (title === 'New Event') {
                dispatch(
                  getAllEvent({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    pagination: true,
                  })
                );
              }

              if (calendarView) {
                const firstDayOfMonth = moment()
                  .startOf('month')
                  .format('DD-MM-YYYY');
                const endDayOfMonth = moment()
                  .endOf('month')
                  .format('DD-MM-YYYY');
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    filter: {
                      date: 'period',
                      start_date: firstDayOfMonth,
                      end_date: endDayOfMonth,
                    },
                    pagination: false,
                  })
                );
              }
            }
          }
        });
      } else {
        dispatch(
          postAddEvent({ ...data, createEventIfEmailExists: 'yes' })
        ).then((result: any) => {
          if (postAddEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              closeModal();

              if (title === 'New Event') {
                dispatch(
                  getAllEvent({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    agency_id: clientSliceData?.agencyId,
                    pagination: true,
                  })
                );
              }

              if (calendarView) {
                const firstDayOfMonth = moment()
                  .startOf('month')
                  .format('DD-MM-YYYY');
                const endDayOfMonth = moment()
                  .endOf('month')
                  .format('DD-MM-YYYY');
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    filter: {
                      date: 'period',
                      start_date: firstDayOfMonth,
                      end_date: endDayOfMonth,
                    },
                    agency_id: clientSliceData?.agencyId,
                    pagination: false,
                  })
                );
              }
            }
          }
        });
      }
    } else {
      if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
        dispatch(
          patchEditEvent({ ...data, createEventIfEmailExists: 'yes' })
        ).then((result: any) => {
          if (patchEditEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              if (title === 'Edit Event') {
                dispatch(
                  getAllEvent({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    pagination: true,
                  })
                );
              }

              if (calendarView) {
                const firstDayOfMonth = moment()
                  .startOf('month')
                  .format('DD-MM-YYYY');
                const endDayOfMonth = moment()
                  .endOf('month')
                  .format('DD-MM-YYYY');
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    filter: {
                      date: 'period',
                      start_date: firstDayOfMonth,
                      end_date: endDayOfMonth,
                    },
                    pagination: false,
                  })
                );
              }
              closeModal();
            }
          }
        });
      } else {
        dispatch(
          patchEditEvent({ ...data, createEventIfEmailExists: 'yes' })
        ).then((result: any) => {
          if (patchEditEvent.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              closeModal();

              if (title === 'Edit Event') {
                dispatch(
                  getAllEvent({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    agency_id: clientSliceData?.agencyId,
                    pagination: true,
                  })
                );
              }

              if (calendarView) {
                const firstDayOfMonth = moment()
                  .startOf('month')
                  .format('DD-MM-YYYY');
                const endDayOfMonth = moment()
                  .endOf('month')
                  .format('DD-MM-YYYY');
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    filter: {
                      date: 'period',
                      start_date: firstDayOfMonth,
                      end_date: endDayOfMonth,
                    },
                    agency_id: clientSliceData?.agencyId,
                    pagination: false,
                  })
                );
              }
            }
          }
        });
      }
    }
  };

  return (
    <div className="p-6">
      <div className="flex flex-col items-center gap-[6px]">
        <Title
          as="h6"
          className="mb-0.5 flex items-start text-sm text-gray-700 sm:items-center"
        >
          Event is already their on scheduled day.
        </Title>
        <Text className="mb-2 leading-relaxed text-gray-500">
          Are you sure you want to continue?
        </Text>
      </div>
      <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
        <div className="flex items-center justify-end gap-2">
          <Button
            className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
            disabled={eventSliceData?.loading}
            onClick={handleYesClick}
          >
            Yes
            {eventSliceData?.loading && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
        <div>
          <Button
            variant="outline"
            className="@xl:w-auto dark:hover:border-gray-400"
            onClick={() => closeModal()}
          >
            No
          </Button>
        </div>
      </div>
    </div>
  );
}
