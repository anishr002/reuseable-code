"use client";
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import { Title, Text } from '@/components/ui/text';
import { BsPersonFill } from "react-icons/bs";
import { FaPeopleGroup } from "react-icons/fa6";
import { useModal } from '@/app/shared/modal-views/use-modal';
import { MdOutlineCalendarMonth } from 'react-icons/md';
import { FaUserCircle } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { useEffect } from 'react';
import Spinner from '@/components/ui/spinner';
import cn from '@/utils/class-names';
import { usePathname } from 'next/navigation';
import AddActivityFormPage from '../../calender/create-edit-event/create-edit-activity-form';
import SimpleBar from 'simplebar-react';
import { getEventById } from '@/redux/slices/user/events/eventSlice';
import { PiXBold } from 'react-icons/pi';
import EventForm from './event-form';


export default function DetailsEvents(props: any) {
  const { data, isCalendarViewEvent } = props;
  // console.log("data in task card", data)

  const { openModal, closeModal } = useModal();
  const pathname = usePathname();
  const dispatch = useDispatch();
  const { gridView } = useSelector((state: any) => state?.root?.task);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const taskData = useSelector((state: any) => state?.root?.task);
  const { } = useSelector((state: any) => state?.root?.activity);
  const { calendarView, paginationParams, userReferenceId } = useSelector((state: any) => state?.root?.activity);
  let { page, items_per_page, sort_field, sort_order, search, filter } = paginationParams;
  const eventSliceData = useSelector((state: any) => state?.root?.event);

  const firstDayOfMonth = moment().startOf('month').format('DD-MM-YYYY');
  const endDayOfMonth = moment().endOf('month').format('DD-MM-YYYY');

  useEffect(() => {

    data && !isCalendarViewEvent && dispatch(getEventById({ eventId: data?._id })).then((result: any) => {
      if (getEventById.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
        }
      }
    });
    data && isCalendarViewEvent && dispatch(getEventById({ eventId: data?.id })).then((result: any) => {
      if (getEventById.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
        }
      }
    });

  }, [data, dispatch, isCalendarViewEvent]);

  let [dataa] = eventSliceData?.event ?? [{}];

  function handleEditModal() {
    closeModal(),
      openModal({
        view: <EventForm row={dataa} title="Edit Event" />,
        customSize: '700px',
      });
  }


  if (!eventSliceData?.event) {
    return (
      <div className='p-10 flex items-center justify-center'>
        <Spinner size="xl" tag='div' className='ms-3' />
      </div>
    )
  } else {
    return (
      <>
        <div className="p-[1.5rem] h-full w-full overflow-y-auto overflow-x-hidden whitespace-pre-wrap">
          <div className="flex items-center">
            <Title as="h3" className="text-xl xl:text-2xl w-full">
              {dataa?.title?.charAt(0)?.toUpperCase() + dataa?.title?.slice(1)}
            </Title>
            <div className='ms-auto flex items-center gap-3'>
              <ActionIcon
                size="sm"
                variant="text"
                onClick={() => closeModal()}
                className="p-0 text-gray-500 hover:!text-gray-900"
              >
                <PiXBold className="h-[18px] w-[18px]" />
              </ActionIcon>
            </div>
          </div>

          <div className=''>
            {/* <Title as="h4" className="text-lg font-medium xl:text-xl xl:leading-7">
              {event.title}
            </Title>
            {event.description && (
              <Text className="mt-3 xl:leading-6">{event.description}</Text>
            )} */}

            <div className="mt-[6px] flex flex-col gap-[18px] text-gray-600">

              {/* <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:gap-5">
                <div className="flex gap-2">
                  <span className='text-gray-1000 capitalize'>Location: </span>
                  <span className="font-medium text-gray-1000">
                    {dataa?.agenda}
                  </span>
                </div>
              </div> */}
              <div className="flex flex-col gap-1">
                <span className='text-gray-1000 capitalize'>Location: </span>
                {dataa?.agenda ? (
                  <div className='border-2 rounded-md p-1 [&_.simplebar-content:before]:content-none [&_.simplebar-content:after]:content-none'>
                    <SimpleBar className="max-h-[100px] w-full before:p-0">
                      <span className="text-gray-1000">
                        {dataa?.agenda ?? '-'}
                      </span>
                    </SimpleBar>
                  </div>
                ) : (<span className="font-medium text-gray-1000">N/A</span>)
                }
              </div>
              <div className="grid grid-cols-1 gap-1 md:grid-cols-2 xl:gap-5">
                <div className="flex items-center gap-2" title='Start Date & Time'>
                  {/* <TbCalendarDue className="h-5 w-5" /> */}
                  <span className="text-gray-1000 capitalize">Start Date Time:</span>
                  <span className="font-medium text-gray-1000">
                    {moment(new Date(dataa?.due_date)).format('MMMM D, YYYY')} at{' '}
                    {moment(new Date(dataa?.event_start_time)).format('h:mm A')}
                  </span>
                </div>
                <div className="flex items-center gap-2" title='End Date & Time'>
                  {/* <MdDateRange className="h-5 w-5" /> */}
                  <span className="text-gray-1000 capitalize">End Date Time:</span>
                  <span className="font-medium text-gray-1000">
                    {dataa?.recurring_end_date ? moment(new Date(dataa?.recurring_end_date)).format('MMMM D, YYYY') : moment(new Date(dataa?.due_date)).format('MMMM D, YYYY')} at{' '}
                    {moment(new Date(dataa?.event_end_time)).format('h:mm A')}
                  </span>
                </div>
              </div>


              {/* <div className='flex flex-col gap-[18px]'>

                <div className="flex gap-2">
                  <MdOutlineCalendarMonth className="h-5 w-5" />
                  <span>Event Start Date: </span>
                  <span className="font-medium text-gray-1000">
                    {moment(new Date(dataa?.event_start_time)).format('MMMM D, YYYY')}
                  </span>
                </div>
                <div className="flex gap-2">
                  <MdOutlineCalendarMonth className="h-5 w-5" />
                  <span>Event Start Time: </span>
                  <span className="font-medium text-gray-1000">
                    {moment(new Date(dataa?.event_start_time)).format('hh:mm A')}
                  </span>
                </div>
                <div className="flex gap-2">
                  <MdOutlineCalendarMonth className="h-5 w-5" />
                  <span>Event End Time: </span>
                  <span className="font-medium text-gray-1000">
                    {moment(new Date(dataa?.event_end_time)).format('hh:mm A')}
                  </span>
                </div>
                <div className="flex gap-2">
                  <MdOutlineCalendarMonth className="h-5 w-5" />
                  <span>Event End Date: </span>
                  <span className="font-medium text-gray-1000">
                    {dataa && dataa?.recurring_end_date ? moment(new Date(dataa?.recurring_end_date)).format('MMMM D, YYYY') : '-'}
                  </span>
                </div>
              </div> */}
              <div className="flex gap-2">
                <span className=' text-gray-1000 capitalize'>Attendees: </span>
                <div className='block w-full'>
                  {dataa && dataa?.email && dataa?.email?.length > 0 ? dataa?.email?.map((emaill: string, index: any) => {
                    return (
                      <div key={index} className='inline-block mb-1 me-1'>
                        <Button
                          size="sm"
                          tag="span"
                          variant="outline"
                          rounded='pill'
                          className="w-auto font-medium"
                        // style={{ color: valuee?.color, border: `2px solid ${valuee?.color}` }}
                        // color={statusColors()}
                        // data-color={statusColors()}
                        >
                          {emaill}
                        </Button>
                      </div>
                    )
                  }) : 'N/A'}
                </div>
              </div>
              <div className="flex flex-col gap-1 mb-[10px]">
                <span className='text-gray-1000 capitalize'>Internal Note: </span>
                {dataa?.internal_info ? (
                  <div className='border-2 rounded-md p-1 [&_.simplebar-content:before]:content-none [&_.simplebar-content:after]:content-none'>
                    <SimpleBar className="max-h-[100px] w-full before:p-0">
                      <span className="text-gray-1000">
                        {dataa?.internal_info ?? '-'}
                      </span>
                    </SimpleBar>
                  </div>
                ) : (<span className="font-medium text-gray-1000">N/A</span>)
                }
              </div>
            </div>
            <div className='ms-auto text-end'>
              <Button
                className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
                onClick={handleEditModal}
              >
                Edit
              </Button>
            </div>
          </div>
        </div>
      </>
    );
  }
}


