'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { routes } from '@/config/routes';
import {
  clientAgreementchangeStatus,
  getAllclientagreement,
} from '@/redux/slices/user/client/agreement/clientAgreementSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import moment from 'moment';
import Link from 'next/link';
import { SlOptions } from 'react-icons/sl';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon, Badge, Button, Popover } from 'rizzui';
import { ConfirmationModal } from '../../ConfirmationModal';
import { useModal } from '../../modal-views/use-modal';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const AgreementColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const paginationParams = useSelector(
    (state: any) => state?.root?.clienAgreement?.paginationParams
  );
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { openModal, closeModal } = useModal();

  const handleSwitchChangeaccept = (id: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    dispatch(clientAgreementchangeStatus({ id: id, status: 'agreed' })).then(
      (result: any) => {
        if (clientAgreementchangeStatus.fulfilled.match(result)) {
          // console.log('resultt', result)
          if (result && result.payload.success === true) {
            closeModal();
            dispatch(
              getAllclientagreement({
                page,
                items_per_page,
                sort_field,
                sort_order,
                search,
                agency_id: clientSliceData?.agencyId,
              })
            );
          }
        }
      }
    );
  };
  const handleSwitchChangereject = (id: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    dispatch(clientAgreementchangeStatus({ id: id, status: 'reject' })).then(
      (result: any) => {
        if (clientAgreementchangeStatus.fulfilled.match(result)) {
          // console.log('resultt', result)
          if (result && result.payload.success === true) {
            closeModal();
            dispatch(
              getAllclientagreement({
                page,
                items_per_page,
                sort_field,
                sort_order,
                search,
                agency_id: clientSliceData?.agencyId,
              })
            );
          }
        }
      }
    );
  };

  function getStatusBadge(status: string) {
    switch (status?.toLowerCase()) {
      case 'pending':
        return (
          <div className="flex justify-center">
            <div className="status_pad flex w-[150px]  items-center justify-center gap-2 rounded-[14px]  bg-[#FFD4C6]  px-3 py-[6px] text-xs sm:text-sm">
              <Badge className="bg-[#AC2D2D]" renderAsDot />
              <Text className="font-medium text-[#AC2D2D]">Pending</Text>
            </div>
          </div>
        );
      case 'agreed':
        return (
          <div className="flex justify-center">
            <div className="flex  w-[150px] items-center justify-center gap-2 rounded-[14px] bg-[#c7e4b0] px-3 py-[6px] text-xs sm:text-sm">
              <Badge className="bg-[#546d40]" renderAsDot />
              <Text className="font-medium text-[#53723b]">Agreed</Text>
            </div>
          </div>
        );
        case 'reject':
        return (
          <div className="flex justify-center">
            <div className="flex  w-[150px] items-center justify-center gap-2 rounded-[14px] bg-gray-200 px-3 py-[6px] text-xs sm:text-sm">
              <Badge className="bg-gray-400" renderAsDot />
              <Text className="font-medium text-gray-600">Reject</Text>
            </div>
          </div>
        );
      // default:
      //   return (
      //     <div className="flex justify-center">
      //       <div className=" flex w-[150px] items-center justify-center gap-2 rounded-[14px] bg-gray-200 px-3 py-[6px] text-xs sm:text-sm">
      //         <Badge renderAsDot className="bg-gray-400" />
      //         <Text className="font-medium text-gray-600">
      //           {capitalizeFirstLetter(status)}
      //         </Text>
      //       </div>
      //     </div>
      //   );
    }
  }

  return [
    // {
    //     title: (
    //         <div className="ps-3.5">
    //             <Checkbox
    //                 title={'Select All'}
    //                 onChange={handleSelectAll}
    //                 checked={checkedItems.length === data.length}
    //                 className="cursor-pointer"
    //             />
    //         </div>
    //     ),
    //     dataIndex: 'checked',
    //     key: 'checked',
    //     width: 50,
    //     render: (_: any, row: any) => (
    //         <div className="inline-flex ps-3.5">
    //             <Checkbox
    //                 className="cursor-pointer"
    //                 checked={checkedItems.includes(row._id)}
    //                 {...(onChecked && { onChange: () => onChecked(row._id) })}
    //             />
    //         </div>
    //     ),
    // },
    {
      title: (
        <HeaderCell
          className="ms-3"
          title="Title"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'title'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('title'),
      dataIndex: 'title',
      key: 'title',
      width: 230,
      render: (value: string, row: any) => (
        <Text className="poppins_font_number ms-3 font-medium capitalize text-black truncate w-[230px] whitespace-nowrap overflow-hidden text-ellipsis">
          {row?.title
            ? row?.title
            : row?.template_data?.title
              ? row?.template_data?.title
              : row?.agreement_doc
                ? row?.agreement_doc?.file_original_name.split('.')[0]
                : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Description"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'description'
          }
          align="left"
        />
      ),
      onHeaderCell: () => onHeaderCellClick('description'),
      dataIndex: 'description',
      key: 'description',
      width: 250,
      align: 'start',
      render: (value: string, row: any) => (
        <Text className="poppins_font_number font-medium text-black line-clamp-1">

          {row?.description
            ? row?.description
            : row?.template_data?.description
              ? row?.template_data?.description
              : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Status"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
          align="center"
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 150,
      render: (value: string) => (
        <>
          {value && value != ''
            ? value === 'sent'
              ? getStatusBadge('Pending') 
              : value === 'reject' ? getStatusBadge('reject') : getStatusBadge('agreed') 
            : '-'}
        </>
      ),
    },

    {
      title: <HeaderCell title="Action" className="justify-center" />,
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'action',
      key: 'action',
      width: 80,
      render: (value: string, row: Record<string, string>) => (
        <div className="flex items-center justify-center">
          <Popover
            placement="top-start"
            className="demo_test flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
            content={({ setOpen }) => {
              return (
                <>
                  {/* View agreement */}
                  <Link
                    href={`${routes.clients.viewagreement(
                      defaultWorkSpace?.name,
                      row?._id
                    )}`}
                    className="h-auto w-full"
                  >
                    <Button
                      variant="text"
                      className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                    >
                      View
                    </Button>
                  </Link>

                  {!(row?.status === 'agreed' || row?.status === 'reject')  && (
                    <Button
                      variant="text"
                      className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      onClick={() => {
                        setOpen(false);
                        openModal({
                          view: (
                            <ConfirmationModal
                              title="Accept Agreement"
                              message="Are you sure you want to accept?"
                              confirmText="Yes"
                              onConfirm={() => {
                                handleSwitchChangeaccept(row._id);
                              }}
                              onClose={closeModal}
                            />
                          ),
                          customSize: '400px',
                        });
                      }}
                    >
                      Accept
                    </Button>
                  )}
                  {!(row?.status === 'reject' || row?.status === 'agreed') && (
                    <Button
                      variant="text"
                      className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      onClick={() => {
                        setOpen(false);
                        openModal({
                          view: (
                            <ConfirmationModal
                              title="Reject Agreement"
                              message="Are you sure you want to reject?"
                              confirmText="Yes"
                              onConfirm={() => {
                                handleSwitchChangereject(row._id);
                              }}
                              onClose={closeModal}
                            />
                          ),
                          customSize: '400px',
                        });
                      }}
                    >
                      reject
                    </Button>
                  )}
                </>
              );
            }}
          >
            <ActionIcon title="More Options" variant="text">
              <SlOptions className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
            </ActionIcon>
          </Popover>
        </div>
      ),
    },
  ];
};
