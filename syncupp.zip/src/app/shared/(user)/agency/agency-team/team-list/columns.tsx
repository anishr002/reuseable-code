'use client';

import CustomModalButton from '@/app/shared/custom-modal-button';
import DeletePopover from '@/app/shared/delete-popover';
import { useModal } from '@/app/shared/modal-views/use-modal';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import Spinner from '@/components/ui/spinner';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import { routes } from '@/config/routes';
import {
  clientteamStatuschange,
  getAllTeamMember,
  refferalPaymentStatistics,
  setUserReferenceId,
} from '@/redux/slices/user/team-member/teamSlice';
import { initiateRazorpay } from '@/services/clientpaymentService';
import {
  capitalizeAndJoin,
  capitalizeFirstLetter,
} from '@/utils/common-functions';
import moment from 'moment';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { MdOutlineDone } from 'react-icons/md';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import AddTeamMemberForm from '../create-edit/add-team-member-form';
import { checkPermission } from '../../../roles-permissions/utils';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
  handlecustomAgencyTeamSelectAll?: any;
};

function getStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'confirm_pending':
      return (
        <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
          <Badge className="bg-[#AC2D2D]" renderAsDot />
          <Text className="font-semibold text-[#AC2D2D]">Pending</Text>
        </div>
      );
    case 'confirmed':
      return (
        <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
          <Badge className="bg-[#527C31]" renderAsDot />
          <Text className="font-semibold text-[#527C31]">Active</Text>
        </div>
      );
    case 'rejected':
      return (
        <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
          <Badge color="danger" renderAsDot />
          <Text className="font-semibold text-red-dark">Rejected</Text>
        </div>
      );
    case 'payment_pending':
      return (
        <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-[#FBF0DE] px-[20px] py-[8px] text-xs sm:text-sm">
          <Badge color="warning" renderAsDot />
          <Text className="font-semibold text-orange-dark">Payment Pending</Text>
        </div>
      );
    default:
      return (
        <div className="status_pad flex items-center justify-center gap-2 rounded-3xl bg-gray-200 px-[20px] py-[8px] text-xs sm:text-sm">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="font-semibold text-gray-600">
            {capitalizeFirstLetter(status)}
          </Text>
        </div>
      );
  }
}

function getRoleName(role: string) {
  switch (role?.toLowerCase()) {
    case 'team_member':
      return 'Team';
    case 'admin':
      return 'Admin';
    case 'manager':
      return 'Manager';
    default:
      return '-';
  }
}

export const GetclientTeamColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
  handlecustomAgencyTeamSelectAll,
}: Columns) => {
  const token = localStorage.getItem('token');
  const router = useRouter();
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  const [loadingflag, setloadingflag] = useState(false);
  const [showloaderflag, setshowloaderflag] = useState(null);

  const paginationParams = useSelector(
    (state: any) => state?.root?.teamMember?.paginationParams
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  const ClintteamlistAPIcall = async () => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    await dispatch(
      getAllTeamMember({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        pagination: true,
      })
    );
  };

  // Accept and Reject Client Team Memmber
  const StatusHandler = (row: any, freetrailflag: any) => {
    dispatch(
      clientteamStatuschange({
        member_id: row?.user?._id,
        status: freetrailflag,
      })
    ).then((result: any) => {
      if (
        clientteamStatuschange.fulfilled.match(result) &&
        result?.payload?.success
      ) {
        ClintteamlistAPIcall();
      }
    });
  };

  const handlePaymentApi = (row: any) => {
    console.log('row in agency team column...', row);
    dispatch(setUserReferenceId({ data: { _id: row?.user?._id } }));
    setloadingflag(true);
    setshowloaderflag(row?.user?._id);

    dispatch(refferalPaymentStatistics()).then((result: any) => {
      if (refferalPaymentStatistics.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          if (
            result?.payload?.data?.plan?.plan_type === 'limited' &&
            result?.payload?.data?.referral_point >=
              result?.payload?.data?.redeem_required_point
          ) {
            router.push(routes.agency_team_payment(defaultWorkSpace?.name));
          } else {
            initiateRazorpay(
              router,
              routes.agency_team(defaultWorkSpace?.name),
              token,
              row?.user?._id,
              ClintteamlistAPIcall,
              setloadingflag,
              closeModal
            );
          }
        } else {
          setloadingflag(false);
        }
      }
    });
  };

  let updatedData = data ?? [];
  if (signIn?.role === 'team_agency') {
    updatedData =
      data?.filter(
        (row) =>
          row?.status === 'requested' ||
          signIn?.user?.data?.user?._id !== row?._id
          // && row?.sub_role !== 'admin'
      ) ?? []; // Filter out disabled rows
  }

  return [
    {
      title: (
        <div className="ps-3.5">
          {(['agency'].includes(signIn?.role) ||
            (['team_agency', 'team_client'].includes(signIn?.role) &&
              checkPermission(
                'teams',
                null,
                'delete',
                signIn?.permission
              ))) && (
            <Checkbox
              title={'Select All'}
              onChange={handlecustomAgencyTeamSelectAll}
              checked={
                signIn?.role === 'team_agency'
                  ? checkedItems.length === updatedData.length
                  : checkedItems.length === data.length
              }
              inputClassName="checkbox-color"
            />
          )}
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 50,
      render: (_: any, row: any) => (
        <div className="inline-flex ps-3.5">
          {
            // Check if the sign-in role is 'agency'
            signIn?.role === 'agency' ? (
              // Render the Checkbox for 'agency' role
              <Checkbox
                inputClassName="checkbox-color"
                className="aaa cursor-pointer"
                checked={checkedItems.includes(row?.user._id)}
                {...(onChecked && {
                  onChange: () => onChecked(row?.user?._id),
                })}
              />
            ) : ['team_agency', 'team_client'].includes(signIn?.role) &&
              checkPermission('teams', null, 'delete', signIn?.permission) &&
              (row?.status === 'requested' ||
                signIn?.user?.data?.user?._id !== row?._id) ? (
              // Render the Checkbox for 'team_agency' if the conditions are met
              <Checkbox
                inputClassName="checkbox-color"
                className="aaa cursor-pointer"
                checked={checkedItems.includes(row?.user._id)}
                {...(onChecked && {
                  onChange: () => onChecked(row?.user?._id),
                })}
              />
            ) : null
          }
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'user.name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('user.name'),
      dataIndex: 'user',
      key: 'user',
      width: 200,
      render: (value: Record<string, string>) => (
        <Text className="poppins_font_number font-semibold capitalize text-black">
          {value?.name}
        </Text>
      ),
    },
    // {
    //   title: (
    //     <HeaderCell
    //       title="Mobile Number"
    //       sortable
    //       ascending={
    //         sortConfig?.direction === 'asc' &&
    //         sortConfig?.key === 'contact_number'
    //       }
    //     />
    //   ),
    //   onHeaderCell: () => onHeaderCellClick('contact_number'),
    //   dataIndex: 'contact_number',
    //   key: 'contact_number',
    //   width: 200,
    //   render: (value: string) => (
    //     <>
    //       {value && value != '' ? (
    //         <Text className="font-semibold text-gray-700">{value}</Text>
    //       ) : (
    //         <Text className="font-semibold text-gray-700">-</Text>
    //       )}
    //     </>
    //   ),
    // },
    {
      title: (
        <HeaderCell
          title="Email ID"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'user.email'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('user.email'),
      dataIndex: 'user',
      key: 'user',
      width: 200,
      // render: (_: any, row: any) => (
      //   <Text  className="font-semibold	 text-black">{row.email}</Text>
      // ),
      render: (value: Record<string, string>) => (
        <Text className="poppins_font_number font-semibold	text-black">
          {value.email}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Permission"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'sub_role'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('sub_role'),
      dataIndex: 'sub_role',
      key: 'sub_role',
      width: 200,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-semibold capitalize text-black">
            {value && value !== '' ? capitalizeAndJoin(value) : '-'}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Created"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'joining_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('joining_date'),
      dataIndex: 'joining_date',
      key: 'joining_date',
      width: 200,
      render: (value: string) => {
        const date = value ? moment(value).fromNow() : '-';
        return (
          <Text className="poppins_font_number font-semibold text-black">
            {date}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Status"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 200,
      render: (value: string) =>
        getStatusBadge(
          value && value === 'payment_pending' ? 'Payment Pending' : value
        ),
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions"/>,
      dataIndex: 'action',
      key: 'action',
      width: 120,
      render: (_: string, row: any) => (
        <>
          {row?.status === 'payment_pending' && signIn?.role === 'agency' ? (
            <div>
              <Button
                disabled={loadingflag}
                className="w-[50%] rounded-xl bg-[#8C80D2] text-white"
                onClick={() => handlePaymentApi(row)}
              >
                Pay{' '}
                {loadingflag && showloaderflag === row?._id && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-3 pe-4">
              {row?.status == 'requested' && signIn?.role === 'agency' && (
                <>
                  <Tooltip
                    size="sm"
                    content={() => 'Approve'}
                    placement="top"
                    color="invert"
                  >
                    <Button
                      disabled={loadingflag}
                      onClick={() => {
                        /* 
                              Code Comment due to payment flow is pending
                            */
                        // signIn?.user?.data?.user?.status === 'free_trial'
                        //   ? StatusHandler(row, 'accept')
                        //   : handlePaymentApi(row);
                        StatusHandler(row, 'accept');
                      }}
                      size="sm"
                      variant="outline"
                      className="bg-[#E3E1F4] text-[#8C80D2]"
                      aria-label={'Approve Team member'}
                    >
                      <MdOutlineDone className="h-4 w-4" />
                    </Button>
                  </Tooltip>
                  <Tooltip
                    size="sm"
                    content={() => 'Reject'}
                    placement="top"
                    color="invert"
                  >
                    <Button
                      // disabled={loading}
                      onClick={() => {
                        StatusHandler(row, 'reject');
                      }}
                      size="sm"
                      variant="outline"
                      className="bg-[#E3E1F4] text-[#8C80D2]"
                      aria-label={'Reject Team member'}
                    >
                      <PiXBold className="h-4 w-4" />
                    </Button>
                  </Tooltip>
                </>
              )}
              {
                // Check if the sign-in role is 'agency'
                signIn?.role === 'agency' ? (
                  // Render CustomModalButton for 'agency' role
                  <CustomModalButton
                    icon={<PencilIcon className="h-4 w-4" />}
                    view={
                      <AddTeamMemberForm
                        title="Edit Team member"
                        row={row}
                        isEdit={true}
                      />
                    }
                    customSize="625px"
                    className="bg-[#E3E1F4] text-[#8C80D2]"
                    title="Edit Team member"
                  />
                ) : ['team_agency', 'team_client'].includes(signIn?.role) &&
                  checkPermission(
                    'teams',
                    null,
                    'update',
                    signIn?.permission
                  ) &&
                  (row?.status === 'requested' ||
                    signIn?.user?.data?.user?._id !== row?._id) ? (
                  // Render CustomModalButton for 'team_agency' if the conditions are met
                  <CustomModalButton
                    icon={<PencilIcon className="h-4 w-4" />}
                    view={
                      <AddTeamMemberForm
                        title="Edit Team member"
                        row={row}
                        isEdit={true}
                      />
                    }
                    customSize="625px"
                    className="bg-[#E3E1F4] text-[#8C80D2]"
                    title="Edit Team member"
                  />
                ) : null
              }
              <Tooltip
                size="sm"
                content={() => 'View Team member'}
                placement="top"
                color="invert"
              >
                <Link
                  className="rounded-md	text-[#E3E1F4]"
                  href={routes?.agency_teams?.details(
                    defaultWorkSpace?.name,
                    row?.user?._id
                  )}
                >
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-[#E3E1F4] text-[#8C80D2]"
                    aria-label={'View Member'}
                  >
                    <EyeIcon className="h-4 w-4" />
                  </Button>
                </Link>
              </Tooltip>
              {
                // Check if the sign-in role is 'agency'
                signIn?.role === 'agency' ? (
                  // Render DeletePopover for 'agency' role
                  <DeletePopover
                    deleteButtonClass="bg-[#E3E1F4] text-[#8C80D2]"
                    title={`Remove the team member`}
                    description={`Are you sure you want to remove?`}
                    onDelete={() =>
                      onDeleteItem(
                        row?.user?._id,
                        currentPage,
                        pageSize,
                        data?.length <= 1 ? true : false,
                        sortConfig,
                        searchTerm
                      )
                    }
                  />
                ) : checkPermission(
                    'teams',
                    null,
                    'delete',
                    signIn?.permission
                  ) &&
                  (row?.status === 'requested' ||
                    signIn?.user?.data?.user?._id !== row?._id) ? (
                  // Render DeletePopover for 'team_agency' if the conditions are met
                  <DeletePopover
                    deleteButtonClass="bg-[#E3E1F4] text-[#8C80D2]"
                    title={`Delete the Team member`}
                    description={`Are you sure you want to delete?`}
                    onDelete={() =>
                      onDeleteItem(
                        row?.user?._id,
                        currentPage,
                        pageSize,
                        data?.length <= 1 ? true : false,
                        sortConfig,
                        searchTerm
                      )
                    }
                  />
                ) : null
              }
            </div>
          )}
        </>
      ),
    },
  ];
};
