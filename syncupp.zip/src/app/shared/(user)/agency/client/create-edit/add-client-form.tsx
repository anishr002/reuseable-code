'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import SelectLoader from '@/components/loader/select-loader';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { PhoneNumber } from '@/components/ui/phone-input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import { emailCheck } from '@/redux/slices/user/auth/authSlice';
import {
  RemoveRegionalData,
  RemovecityData,
  getAllClient,
  getCities,
  getClientById,
  getCountry,
  getState,
  patchEditClient,
  postAddClient,
} from '@/redux/slices/user/client/clientSlice';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import cn from '@/utils/class-names';
import {
  ClientSchema,
  cliectNoValidationSchema,
  clientSchema,
} from '@/utils/client-schema';
import { handleKeyDown, handleKeyPincode } from '@/utils/common-functions';
import {
  addClientFormTourStepsContent,
  getStepsByRole,
} from '@/utils/tour-steps/tour-steps';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import { checkPermission } from '../../../roles-permissions/utils';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    cursor: 'pointer',
    backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
    color: state.isSelected ? 'black' : 'black',
    padding: '8px',
  }),
};

const editcustomStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    cursor: 'pointer',
    backgroundColor: state.isFocused ? '#d3e5ff' : 'white', // Light blue when hovered
    color: state.isSelected ? 'black' : 'black',
    padding: '8px',
  }),
  control: (provided: any) => ({
    ...provided,
    backgroundColor: '#fafafa', // Set background color to #fafafa
  }),
};

export default function AddClientForm(props: any) {
  const { title, row, fdata, setFdata } = props;
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const router = useRouter();
  const [save, setSave] = useState(false);
  const [loader, setLoader] = useState(false);
  const [reset, setReset] = useState({});
  const [loadingflag, setloadingflag] = useState(false);
  const [userExist, setUserExist] = useState(false);
  const paginationParams = useSelector(
    (state: any) => state?.root?.client?.paginationParams
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const token = localStorage.getItem('token');

  // Api call for Tour status get
  useEffect(() => {
        // Tour comment
        dispatch(getAllTourStatus());
  }, []);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [clientFormTourSteps, setClientFormTourSteps] = useState([]);


  // Handle close tour
  const handleCloseTour = () => {
    dispatch(updateTourStatus({ client: { view_client_tour: true } })).then(
      (result: any) => {
        if (updateTourStatus.fulfilled.match(result)) {
          if (result?.payload?.success) {
            setIsTourOpen(false);
        // Tour comment
        dispatch(getAllTourStatus());
          }
        }
      }
    );
  };

  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.client &&
      !tourStatusData?.client?.view_client_tour
    ) {
      setClientFormTourSteps([]);
      setIsTourOpen(false);
      const addClientFormTourStepContent =
        addClientFormTourStepsContent(handleCloseTour, signIn, checkPermission);
      const clientFormTourStep = getStepsByRole(addClientFormTourStepContent);
      clientFormTourStep?.length > 0 && setClientFormTourSteps(clientFormTourStep);
      clientFormTourStep?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData, signIn?.permission]);


  let initialValues: ClientSchema = {
    // name: "",
    first_name: '',
    last_name: '',
    email: '',
    company_name: '',
    company_website: '',
    address: '',
    city: undefined,
    state: undefined,
    country: undefined,
    pincode: '',
    title: '',
    contact_number: '',
    // titleOption: ""
  };

  const ClintlistAPIcall = async () => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    await dispatch(
      getAllClient({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        pagination: true,
      })
    );
  };

  useEffect(() => {
    dispatch(getCountry());
  }, [dispatch]);

  useEffect(() => {
    row && dispatch(getClientById({ _id: row?._id }));
  }, [row, dispatch]);

  let data = clientSliceData?.client;

  let defaultValuess = {
    first_name: data?.first_name,
    last_name: data?.last_name,
    email: data?.email,
    company_name: data?.company_name,
    company_website: data?.company_website,
    address: data?.address,
    city: data?.city?.name,
    state: data?.state?.name,
    country: data?.country?.name,
    pincode: data?.pincode,
    title: data?.title,
    contact_number: data?.contact_number,
  };

  const [regionalData, setRegionalData] = useState({
    city: null,
    state: null,
    country: null,
  });

  useEffect(() => {
    if (title === 'Edit Client') {
      setRegionalData({
        ...regionalData,
        city: data?.client?.city?._id,
        state: data?.client?.state?._id,
        country: data?.client?.country?._id,
      });
    }
  }, [title, data]);

  let countryOptions: Record<string, string>[] = [];
  let cityOptions: Record<string, string>[] = [];

  clientSliceData?.countries !== '' &&
    clientSliceData?.countries?.map((country: Record<string, string>) => {
      countryOptions.push({
        name: country?.name,
        value: country?.name,
        _id: country?._id,
      });
    });

  const countryHandleChange = (titleOption: string) => {
    console.log('called', titleOption);
    const [countryObj] = clientSliceData?.countries?.filter(
      (country: Record<string, string>) => country?.name === titleOption
    );
    console.log('countryObj', countryObj);
    dispatch(getState({ countryId: countryObj._id }));
    dispatch(RemovecityData());
    cityOptions = [];
    setRegionalData({
      ...regionalData,
      country: countryObj._id,
      state: null,
      city: null,
    });
  };

  let stateOptions: Record<string, string>[] = [];
  clientSliceData?.states !== '' &&
    clientSliceData?.states?.map((state: Record<string, string>) => {
      stateOptions.push({
        name: state?.name,
        value: state?.name,
        _id: state?._id,
      });
    });

  const stateHandleChange = (titleOption: string) => {
    const [stateObj] = clientSliceData?.states?.filter(
      (state: Record<string, string>) => state?.name === titleOption
    );
    dispatch(getCities({ stateId: stateObj._id }));
    console.log('stateObj', stateObj);
    setRegionalData({ ...regionalData, state: stateObj._id });
  };

  clientSliceData?.cities !== ''
    ? clientSliceData?.cities?.map((city: Record<string, string>) => {
        cityOptions.push({
          name: city?.name,
          value: city?.name,
          _id: city?._id,
        });
      })
    : (cityOptions = []);

  const cityHandleChange = (titleOption: string) => {
    const [cityObj] = clientSliceData?.cities?.filter(
      (city: Record<string, string>) => city?.name === titleOption
    );
    console.log(cityObj, 'cityObj');
    setRegionalData({ ...regionalData, city: cityObj._id });
  };

  const onSubmit = (dataa: any) => {
    setloadingflag(true);

    const company_url = dataa?.company_website?.startsWith('http')
      ? dataa?.company_website
      : `http://${dataa?.company_website}`;

    const formData = {
      first_name: dataa?.first_name ?? '',
      last_name: dataa?.last_name ?? '',
      email: dataa?.email?.toLowerCase() ?? '',
      company_name: dataa?.company_name ?? '',
      company_website: company_url === 'http://' ? '' : company_url,
      address: dataa?.address ?? '',
      pincode: dataa?.pincode ?? '',
      title: dataa?.title ?? '',
      contact_number: dataa?.contact_number ?? '',
      gst: dataa?.gst ?? '',
    };
    // console.log("form data...", formData)
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(
        ([_, value]) => value !== undefined && value !== ''
      )
    );
    const filteredRegionalData = Object.fromEntries(
      Object.entries(regionalData).filter(
        ([_, value]) => value !== undefined && value !== ''
      )
    );

    console.log(regionalData, 'regionalData');

    const fullData = { ...filteredRegionalData, ...filteredFormData };

    if (title === 'New Client') {
      dispatch(postAddClient(fullData)).then((result: any) => {
        if (postAddClient.fulfilled.match(result)) {
          setLoader(false);
          setSave(false);
          if (result && result.payload.success === true) {
            const userReferenceId = result?.payload?.data?.reference_id ?? '';

            /* 
            Code commented because of payment flow integration is pending
            */
            // Check the condition for the free trail mode
            // if (signIn?.user?.data?.user?.status === 'free_trial') {
            //   router.push(routes.client(defaultWorkSpace?.name));
            //   closeModal();
            //   setloadingflag(false);
            // } else {
            //   dispatch(refferalPaymentStatistics()).then((result: any) => {
            //     if (refferalPaymentStatistics.fulfilled.match(result)) {
            //       if (result && result.payload.success === true) {
            //         if (result?.payload?.data?.available_sheets > 0) {
            //           // console.log(142, userReferenceId)
            //           dispatch(
            //             refferalPayment({
            //               user_id: userReferenceId,
            //               without_referral: true,
            //             })
            //           ).then((result: any) => {
            //             if (refferalPayment.fulfilled.match(result)) {
            //               if (result && result.payload.success === true) {
            //                 closeModal();
            //                 dispatch(
            //                   getAllClient({
            //                     sort_field: 'createdAt',
            //                     sort_order: 'desc',
            //                     pagination: true,
            //                   })
            //                 );
            //                 setloadingflag(false);
            //               } else {
            //                 setloadingflag(false);
            //               }
            //             }
            //           });
            //         } else if (result?.payload?.data?.redirect_payment_page) {
            //           console.log(146);

            //           router.push(routes?.clients?.payment);
            //         } else if (!result?.payload?.data?.redirect_payment_page) {
            //           console.log(151);

            //           initiateRazorpay(
            //             router,
            //             routes.client(defaultWorkSpace?.name),
            //             token,
            //             userReferenceId,
            //             ClintlistAPIcall,
            //             setloadingflag,
            //             closeModal
            //           );
            //         }
            //       } else {
            //         setloadingflag(false);
            //       }
            //     }
            //   });
            // }

            // save && closeModal();
            // setReset({ ...initialValues })

            closeModal();
            setloadingflag(false);

            dispatch(
              getAllClient({
                sort_field: 'createdAt',
                sort_order: 'desc',
                pagination: true,
              })
            );
            dispatch(RemoveRegionalData());
            setSave(false);
          } else {
            setloadingflag(false);
          }
        }
      });
    } else {
      dispatch(patchEditClient({ ...fullData, clientId: data._id })).then(
        (result: any) => {
          if (patchEditClient.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setloadingflag(false);
              save && closeModal();
              dispatch(
                getAllClient({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                })
              );
              setSave(false);
            } else {
              setloadingflag(false);
            }
          }
        }
      );
    }
  };

  const handleSaveClick = () => {
    setSave(true);
  };

  const clearFormValue = (setValue: any) => {
    // setValue('first_name', null);
    // setValue('last_name', null);
    // setValue('company_name', null);
    // setValue('company_website', null);
    // setValue('address', null);
    // setValue('city', null);
    // setValue('state', null);
    // setValue('country', null);
    // setValue('pincode', null);
    // setValue('title', null);
    // setValue('contact_number', null);
    // setRegionalData({
    //   city: null,
    //   state: null,
    //   country: null,
    // });
    setUserExist(false);
  };

  // On email change check email is already register or not
  const handleEmailChange = async (e: any, setValue: any, clearErrors: any) => {
    const email = e.target.value;
    try {
      if (!email) {
        clearFormValue(setValue);
        return;
      }

      const response = await dispatch(
        emailCheck({ email: email?.toLowerCase()?.trim() })
      );
      if (response?.payload?.success) {
        const user = response.payload.data;

        if (user.status == 'signup_completed' || !!user?.email) {
          clearErrors();
          setValue('first_name', user?.first_name);
          setValue('last_name', user?.last_name);
          setValue('company_name', user?.company_name);
          setValue('company_website', user?.company_website);
          setValue('address', user?.address);
          setValue('city', user?.city?.name);
          setValue('state', user?.state?.name);
          setValue('country', user?.country?.name);
          setValue('pincode', user?.pincode);
          setValue('title', user?.title);
          setValue('contact_number', user?.contact_number);
          setValue('gst', user?.gst);
          setUserExist(true);

          setRegionalData({
            ...regionalData,
            country: user?.country?._id,
            state: user?.state?._id,
            city: user?.city?._id,
          });

          const countryName = countryOptions?.find(
            (data: any) => data?._id == user?.country?._id
          );
          countryHandleChange(countryName?.name as string);
          const stateName = stateOptions?.find(
            (data: any) => data?._id == user?.state?._id
          );
          stateHandleChange(stateName?.name as string);
          const cityName = cityOptions?.find(
            (data: any) => data?._id == user?.city?._id
          );
          cityHandleChange(cityName?.name as string);
        } else {
          clearFormValue(setValue);
        }
      } else {
        clearFormValue(setValue);
      }
    } catch (error) {
      console.error('Error validating email:', error);
      // setEmailValidationMessage('Error validating email.');
    }
  };

  if (!clientSliceData?.client && title === 'Edit Client') {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <Form
        validationSchema={!userExist ? clientSchema : cliectNoValidationSchema}
        onSubmit={onSubmit}
        resetValues={reset}
        useFormProps={{
          mode: 'onSubmit',
          defaultValues: defaultValuess,
        }}
        className="placeholder_color p-10 [&_label]:font-medium"
      >
        {({
          register,
          control,
          setValue,
          getValues,
          formState: { errors, isSubmitSuccessful },
          handleSubmit,
          clearErrors,
        }) => (
          <div className="space-y-5">
            <Tour
              steps={clientFormTourSteps ?? []}
              isOpen={isTourOpen}
              rounded={10}
              closeWithMask={false}
              disableInteraction={true}
              disableKeyboardNavigation={['esc']}
              onRequestClose={handleCloseTour}
              className="poppins_font_number font-semibold text-black tour-close-button"
              scrollDuration={50}
              scrollOffset={5}
            />
            <div className="mb-6 flex items-center justify-between">
              <Title
                as="h3"
                className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
              >
                {title}
              </Title>
              <ActionIcon
                size="sm"
                variant="text"
                onClick={() => closeModal()}
                className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
              >
                <PiXBold className="h-[18px] w-[18px]" />
              </ActionIcon>
            </div>
            <div className="client-form-tour-step-one mt-0">
              <p className="mb-6	text-xl font-bold text-[#120425]	xl:mb-4">
                Account Info
              </p>
              <div
                className={cn(
                  'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                )}
              >
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    First Name *
                  </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    placeholder="Enter First Name"
                    color="info"
                    // size={'xl'}
                    className="rounded-xl	[&>label>span]:font-medium"
                    {...register('first_name')}
                    error={errors?.first_name?.message as string}
                    disabled={userExist}
                  />
                </div>
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Last Name *
                  </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    // size={'xl'}
                    placeholder="Enter Last Name"
                    color="info"
                    className="rounded-xl	[&>label>span]:font-medium"
                    // className="rounded-xl	&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('last_name')}
                    error={errors?.last_name?.message as string}
                    disabled={userExist}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Email ID *
                  </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="email"
                    // size={'xl'}
                    placeholder="Enter Your Email"
                    disabled={title === 'Edit Client'}
                    color="info"
                    className="rounded-xl	[&>label>span]:font-medium"
                    // className="rounded-xl	&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('email')}
                    error={errors?.email?.message as string}
                    onChange={(e) => {
                      handleEmailChange(e, setValue, clearErrors);
                      register('email').onChange(e);
                    }}
                  />
                </div>
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Phone
                  </label>

                  <Controller
                    name="contact_number"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <PhoneNumber
                        // size={'xl'}
                        country="us"
                        className="rounded-xl [&>label>span]:font-medium"
                        value={value}
                        onChange={onChange}
                        disabled={userExist}
                        error={errors.contact_number?.message as string}
                      />
                    )}
                  />
                </div>
              </div>
            </div>
            <div className="client-form-tour-step-two">
              <p className="mb-6	text-xl font-bold text-[#120425]	xl:mb-4">
                Company Info
              </p>
              <div
                className={cn(
                  'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                )}
              >
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Company Name *
                  </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    // size={'xl'}
                    placeholder="Enter Company Name"
                    color="info"
                    className="rounded-xl	[&>label>span]:font-medium"
                    // className="rounded-xl	&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('company_name')}
                    error={errors?.company_name?.message as string}
                    disabled={userExist}
                  />
                </div>
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Company Website
                  </label>

                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    // size={'xl'}
                    placeholder="Enter Website URL"
                    color="info"
                    className="rounded-xl	[&>label>span]:font-medium"
                    // className="rounded-xl	&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('company_website')}
                    error={errors?.company_website?.message as string}
                    disabled={userExist}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    GST Number
                  </label>

                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    placeholder="Enter GST Number"
                    color="info"
                    // size={'xl'}
                    className="rounded-xl	[&>label>span]:font-medium"
                    // className="rounded-xl	&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('gst')}
                    error={errors?.gst?.message as string}
                    disabled={userExist}
                  />
                </div>
              </div>
            </div>

            <div className="client-form-tour-step-three mt-0">
              <p className="mb-6	text-xl font-bold text-[#120425]	xl:mb-4">
                Address
              </p>
              <div className="flex flex-col gap-4">
                <div
                  className={cn(
                    'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                  )}
                >
                  <div>
                    <label className="text-[14px] font-semibold text-[#9BA1B9]">
                      Address *
                    </label>

                    <Input
                      onKeyDown={handleKeyDown}
                      type="text"
                      // size={'xl'}
                      placeholder="Enter Your Address"
                      color="info"
                      className="rounded-xl	[&>label>span]:font-medium"
                      // className="rounded-xl	&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                      {...register('address')}
                      error={errors?.address?.message as string}
                      disabled={userExist}
                    />
                  </div>
                  <div>
                    <label className="text-[14px] font-semibold text-[#9BA1B9]">
                      Country
                    </label>

                    <Controller
                      name="country"
                      control={control}
                      render={({ field: { onChange, value } }) => (
                        <Select
                          // size={'xl'}
                          options={countryOptions}
                          value={value}
                          onChange={(titleOption: string) => {
                            onChange(titleOption);
                            countryHandleChange(titleOption);
                            // if (title === 'Edit Client') {
                            setValue('state', '');
                            setValue('city', '');
                            //   setRegionalData({
                            //     ...regionalData,
                            //     state: '',
                            //     city: '',
                            //   });
                            // }
                          }}
                          color="info"
                          error={errors?.country?.message as string}
                          getOptionValue={(option) => option.name}
                          dropdownClassName="p-1 border w-12 border-gray-100 shadow-lg"
                          // className="rounded-xl	font-medium"
                          className="city_filter_dropdown_customize	rounded-xl [&>label>span]:font-medium"
                          disabled={userExist}
                        />
                      )}
                    />
                  </div>
                </div>
                <div
                  className={cn(
                    'grid grid-cols-1 gap-4 pb-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3'
                  )}
                >
                  <div>
                    <label className="text-[14px] font-semibold text-[#9BA1B9]">
                      State
                    </label>

                    <Controller
                      name="state"
                      control={control}
                      render={({ field: { onChange, value } }) => (
                        <Select
                          // size={'xl'}
                          options={stateOptions}
                          value={value}
                          onChange={(titleOption: string) => {
                            onChange(titleOption);
                            stateHandleChange(titleOption);
                          }}
                          getOptionValue={(option) => option.name}
                          // className="rounded-xl	border-gray-100 p-1 font-medium"
                          className="city_filter_dropdown_customize	rounded-xl font-medium lg:max-w-[162px]"
                          dropdownClassName="p-1 border w-12 border-gray-100 shadow-lg"
                          selectClassName="lg:max-w-[162px]"
                          disabled={stateOptions.length === 0 || userExist}
                          style={
                            !(stateOptions.length === 0)
                              ? editcustomStyles
                              : customStyles
                          }
                        />
                      )}
                    />
                    {errors?.state?.message && (
                      <div className="mt-0.5 text-xs font-medium text-red">
                        {errors?.state?.message as string}
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-[14px] font-semibold text-[#9BA1B9]">
                      City
                    </label>

                    <Controller
                      name="city"
                      control={control}
                      render={({ field: { onChange, value } }) => (
                        <Select
                          // size={'xl'}
                          options={cityOptions}
                          value={value}
                          onChange={(titleOption: string) => {
                            onChange(titleOption);
                            cityHandleChange(titleOption);
                          }}
                          disabled={cityOptions.length === 0 || userExist}
                          color="info"
                          getOptionValue={(option) => option.name}
                          // className="rounded-xl	border-gray-100 p-1 font-medium"
                          className="city_filter_dropdown_customize	rounded-xl font-medium"
                          selectClassName="lg:max-w-[162px]"
                          style={
                            !(cityOptions.length === 0)
                              ? editcustomStyles
                              : customStyles
                          }
                        />
                      )}
                    />
                    {errors?.city?.message && (
                      <div className="mt-0.5 text-xs font-medium text-red">
                        {errors?.city?.message as string}
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-[14px] font-semibold text-[#9BA1B9]">
                      Pin Code
                    </label>
                    <Input
                      // size={'xl'}
                      onKeyDown={handleKeyPincode}
                      type="text"
                      placeholder="Enter Pincode Number"
                      color="info"
                      // className="rounded-xl	[&>label>span]:font-medium"
                      className="placeholder_color rounded-xl	font-medium"
                      {...register('pincode')}
                      error={errors.pincode?.message as string}
                      disabled={userExist}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="mt-2 lg:mt-4">
                <Button
                  disabled={loadingflag}
                  className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                  type="submit"
                  size="xl"
                >
                  <span>Save Changes</span>
                  {loadingflag && (
                    <Spinner
                      size="sm"
                      tag="div"
                      className="ms-3"
                      color="white"
                    />
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}
      </Form>
    );
  }
}
