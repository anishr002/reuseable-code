import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { DatePicker } from '@/components/ui/datepicker';
import { Empty } from '@/components/ui/empty';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  getAllTask,
  taskTimerStartAndStop,
} from '@/redux/slices/user/task/taskSlice';
import {
  allTrackTask,
  removeAllTrackedData,
  removeTimerActiveInTaskData,
  removeTrackedHourDetails,
  taskTimeTrackedHistory,
  timerActiveInTask,
  trackedTimeTaskHistory,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import {
  calculateTotalTimeInSeconds,
  capitalizeFirstLetter,
  convertSecondsToTime,
  convertSecondsToTimeForManaul,
  formatTime,
} from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Controller } from 'react-hook-form';
import { FaRegStopCircle } from 'react-icons/fa';
import { FaCirclePlay } from 'react-icons/fa6';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { z } from 'zod';
import { CgNotes } from 'react-icons/cg';
import ReactSelect from 'react-select';
import { Textarea } from 'rizzui';

const customStyles = {
  control: (provided: any, state: any) => ({
    ...provided,
    borderRadius: '6px', // Ensures rounded corners
    borderColor: '#D4D4D4', // Custom border color
  }),
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#8c80d2' : 'white',
    color: state.isSelected ? 'white' : 'black',
    whiteSpace: 'normal', // Allow text to wrap
    wordBreak: 'break-word', // Break long words if necessary
  }),
};

export default function TimerForm({
  onClose,
  task_id,
  section,
  boardId,
  isTimeTrack,
  taskName,
}: Readonly<{
  onClose: () => void;
  task_id?: string;
  section?: any;
  boardId?: any;
  isTimeTrack?: any;
  taskName?: any;
}>) {
  const signIn = useSelector((state: any) => state?.root?.signIn);

  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [showPrivousDate, setShowPrivousDate] = useState(false);
  const [activeTab, setActiveTab] = useState<string | null>('timer'); // Default to "timer"
  const [page, setPage] = useState(1);
  const [isFetching, setIsFetching] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState(task_id);

  const { trackedAllTaskHistoryData } = useSelector(
    (state: any) => state?.root?.timeTracking
  );

  console.log(trackedAllTaskHistoryData?.tracked_history, 'Demooooooo');

  const checkAssigneExist = (task: any, assign_id: string) => {
    return task?.users?.some((user: any) => user?._id === assign_id);
  };

  // Extract data from Redux
  const taskOptions =
    trackedAllTaskHistoryData?.tracked_history
      ?.filter(
        (task: any) =>
          checkAssigneExist(task, signIn?.user?.data?.user?._id) &&
          task?.is_deleted === false &&
          task?.mark_as_archived === false &&
          task?.mark_as_done === false
      )
      ?.map((task: any) => ({
        name: capitalizeFirstLetter(task?.task?.title),
        value: task?.task?._id, // `_id` added in reducer
        label: task?.task?.title,
      })) || [];

  const pageCount = trackedAllTaskHistoryData?.page_count || 1;

  // create hook form setValue reference
  const setValueReference = useRef<any>();
  const getValuesReference = useRef<any>();

  const dispatch = useDispatch();

  const { trackedHourDetails, timerActiveInTaskData, timerActiveInTaskLoader } =
    useSelector((state: any) => state?.root?.timeTracking);
  const { settingData } = useSelector((state: any) => state?.root?.setting);
  const { taskTimerStartAndStopLoader } = useSelector(
    (state: any) => state?.root?.task
  );

  const defaultValues = {
    start_date: moment().toDate(),
    end_date: moment().toDate(),
    start_time: moment().toDate(),
    end_time: moment().toDate(),
    manual_time: convertSecondsToTimeForManaul(
      calculateTotalTimeInSeconds(moment().toDate(), moment().toDate())
    ),
    notes: '',
  };

  const timeTrackingSchema = z.object({
    start_date: z.date().nullable().optional(),
    end_date: z.date().nullable().optional(),
    start_time: z.date().nullable().optional(),
    end_time: z.date().nullable().optional(),
    notes: z.string().max(150).trim().optional(),
    manual_time: z
      .string()
      .regex(/^((\d+h)?\s*(\d+m)?)$/, { message: 'Invalid Format' })
      .nullable()
      .optional(),
  });

  useEffect(() => {
    let timer: any;
    if (isRunning) {
      timer = setInterval(() => {
        setTime((prevTime) => prevTime + 1000); // Increment time every second
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRunning]);

  // Modal Init API - Called
  useEffect(() => {
    if (selectedTaskId !== undefined && selectedTaskId !== null) {
      dispatch(taskTimeTrackedHistory(selectedTaskId));
      dispatch(timerActiveInTask());
    }

    return () => {
      dispatch(removeTrackedHourDetails());
      dispatch(removeTimerActiveInTaskData());
    };
  }, [selectedTaskId]);

  useEffect(() => {
    dispatch(removeAllTrackedData()); // ✅ Clear old data
  }, []);

  useEffect(() => {
    if (
      timerActiveInTaskData &&
      Object.keys(timerActiveInTaskData)?.length > 0 &&
      selectedTaskId === timerActiveInTaskData?.task_id
    ) {
      setTime(
        calculateTotalTimeInSeconds(
          timerActiveInTaskData?.new_log?.clock_in,
          new Date()
        ) * 1000
      );
      setIsRunning(true);
    }
  }, [timerActiveInTaskData, selectedTaskId]);

  // Start task
  const startTask = async () => {
    dispatch(
      taskTimerStartAndStop({
        task_id: selectedTaskId,
        event_type: 'timer_start',
        mode: 'clocking',
        notes: getValuesReference?.current()?.notes,
      })
    ).then((result: any) => {
      if (taskTimerStartAndStop.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          setIsRunning(true);
          setTime(0);
        }
      }
    });
  };

  // Stop task
  const endTask = async () => {
    dispatch(
      taskTimerStartAndStop({
        task_id: selectedTaskId,
        event_type: 'timer_end',
        mode: 'clocking',
      })
    ).then((result: any) => {
      if (taskTimerStartAndStop.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          setIsRunning(false);
          dispatch(taskTimeTrackedHistory(selectedTaskId));
        }
      }
    });
  };

  // Manual time tracking code --- start

  const manualDateChange = (value: any) => {
    resetDateAndTime();

    const timePattern = /^((\d+h)?\s*(\d+m)?)$/;
    // Test if the input matches the expected pattern
    if (!timePattern.test(value)) {
      return;
    }

    const hoursMatch = value.match(/(\d+)h/);
    const minutesMatch = value.match(/(\d+)m/);

    const hours = hoursMatch ? parseInt(hoursMatch[1], 10) : 0;
    const minutes = minutesMatch ? parseInt(minutesMatch[1], 10) : 0;

    const calculatedData = calculateTime(hours, minutes);

    if (calculatedData?.isPreviousDate) {
      if (calculatedData.isSameDay) {
        setValueReference.current('start_time', calculatedData?.date?.toDate());
      } else {
        setShowPrivousDate(true);
        setValueReference.current('start_time', calculatedData?.date?.toDate());
        setValueReference.current('start_date', calculatedData?.date?.toDate());
      }
    } else {
      setShowPrivousDate(false);
      setValueReference.current('end_time', calculatedData?.date?.toDate());
    }
  };

  const resetDateAndTime = () => {
    setShowPrivousDate(false);
    setValueReference.current('start_time', moment().toDate());
    setValueReference.current('end_time', moment().toDate());
    setValueReference.current('start_date', moment().toDate());
    setValueReference.current('end_date', moment().toDate());
  };

  const calculateTime = (hours: any = 0, minutes: any = 0) => {
    const currentTime = moment();
    const updatedTime = moment(currentTime)
      .add(hours, 'hours')
      .add(minutes, 'minutes');

    const currentDate = moment().startOf('day');
    const updatedDate = moment(currentTime)
      .add(hours, 'hours')
      .add(minutes, 'minutes')
      .startOf('day');

    if (updatedDate.isAfter(currentDate)) {
      const date = moment(currentTime)
        .subtract(hours, 'hours')
        .subtract(minutes, 'minutes');

      const isSameDay = moment(date).isSame(moment(), 'day');
      return isSameDay
        ? { date, isPreviousDate: true, isSameDay: true }
        : { date, isPreviousDate: true, isSameDay: false };
    }
    return { date: updatedTime, isPreviousDate: false };
  };

  const calculateTotalTimeFromDateRage = () => {
    const totalSeconds = calculateTotalTimeInSeconds(
      getValuesReference.current()?.start_time,
      getValuesReference.current()?.end_time
    );
    setValueReference.current(
      'manual_time',
      convertSecondsToTimeForManaul(totalSeconds)
    );
  };

  const onSubmit = (data: any) => {
    const payload = createPayload(data);
    manualSaveTime(payload);
  };

  // Create payload
  const createPayload = (data: any) => {
    return {
      clocking: {
        clock_in: moment(data?.start_time)
          .utc()
          .format(),
        clock_out: moment(data?.end_time)
          .utc()
          .format(),
      },
      mode: 'manual',
      notes: data?.notes,
    };
  };

  const onChangeDate = (date: any) => {
    setValueReference.current('start_time', date);
    setValueReference.current('end_time', date);
  };

  // Submit Data
  const manualSaveTime = (payload: any) => {
    dispatch(
      taskTimerStartAndStop({ task_id: selectedTaskId, ...payload })
    ).then((result: any) => {
      if (taskTimerStartAndStop.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          setIsRunning(false);
          dispatch(taskTimeTrackedHistory(selectedTaskId));
        }
      }
    });
  };

  useEffect(() => {
    const timeTracking = settingData?.task?.time_tracking || [];

    if (timeTracking.includes('clocking') && timeTracking.includes('manual')) {
      setActiveTab((prev) => (prev === 'manual' ? 'manual' : 'timer')); // Default to "timer"
    } else if (timeTracking.includes('clocking')) {
      setActiveTab('timer');
    } else if (timeTracking.includes('manual')) {
      setActiveTab('manual');
    } else {
      setActiveTab(null); // No tab available
    }
  }, [settingData?.task?.time_tracking]);

  useEffect(() => {
    if (isTimeTrack) {
      fetchTasks(1); // ✅ Fetch first page only
    }
  }, [isTimeTrack]);

  const fetchTasks = async (pageNum: number) => {
    if (isFetching || pageNum > pageCount) return; // Stop unnecessary calls

    setIsFetching(true);
    try {
      await dispatch(
        allTrackTask({
          board_id: boardId,
          page: pageNum,
          items_per_page: 10,
          pagination: true,
          search: '',
          sort_field: 'createdAt',
          sort_order: 'desc',
        })
      );
      setPage(pageNum + 1); // ✅ Move to the next page
    } finally {
      setIsFetching(false);
    }
  };

  // Scroll event for loading more data
  const handleMenuScroll = (event: any) => {
    const bottom =
      event.target.scrollHeight - event.target.scrollTop ===
      event.target.clientHeight;
    if (bottom && page <= pageCount) {
      fetchTasks(page);
    }
  };

  const selectedOption = taskOptions.find(
    (option: any) => option.value === selectedTaskId
  );

  return (
    <div className="p-5">
      <div className="space-y-4">
        <div className="mb-4 flex items-center justify-between">
          <span className="montserrat_font_title  text-[20px] font-bold leading-[24px] text-[#141414] ">
            Time Tracker
          </span>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => onClose()}
            className="p-0 text-[#141414] hover:text-[#8C80D2]"
          >
            <PiXBold className=" h-[18px] w-[18px]" />
          </ActionIcon>
        </div>

        {timerActiveInTaskLoader ? (
          <div className="!grid h-full min-h-[128px] flex-grow place-content-center items-center justify-center">
            <Spinner size="xl" />
          </div>
        ) : (
          <>
            {/* Tabs */}
            <div className="flex w-fit gap-[2px] rounded-[8px] bg-[#F9FAFB] p-[6px]">
              {settingData?.task?.time_tracking?.includes('clocking') && (
                <button
                  className={`rounded-md px-4 py-2 text-[14px] text-sm font-medium leading-[19.12px] transition-all ${
                    activeTab === 'timer'
                      ? 'rounded-[8px] border border-[#D1D5DB] bg-[#FFFFFF] text-[#111928]'
                      : 'text-[#4B5563]'
                  }`}
                  onClick={() => setActiveTab('timer')}
                  // disabled={isTimeTrack && !selectedOption}
                >
                  Timer
                </button>
              )}

              {settingData?.task?.time_tracking?.includes('manual') && (
                <button
                  className={`rounded-md px-4 py-2 text-[14px] text-sm font-medium leading-[19.12px] transition-all ${
                    activeTab === 'manual'
                      ? 'rounded-[8px] border border-[#D1D5DB] bg-[#FFFFFF] text-[#111928]'
                      : 'text-[#4B5563]'
                  }`}
                  onClick={() => setActiveTab('manual')}
                  // disabled={isTimeTrack && !selectedOption}
                >
                  Manual Entry
                </button>
              )}
            </div>
            <div className="flex items-center">
              <div className="montserrat_font_title text-[14px] font-medium leading-[19.12px] text-[#1E2026]">
                Total Tracked Hour:{' '}
                <span className="montserrat_font_title text-[16px] font-bold leading-[21.86px] text-[#1E2026]">
                  {convertSecondsToTime(trackedHourDetails?.task_total_time)}
                </span>
              </div>
            </div>
            {section?.key !== 'archived' && section?.key !== 'completed' && (
              <div className="">
                {/* <div className="rounded-md border"> */}
                {/* <div className="flex items-center gap-3 p-4">
                  <Avatar
                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${signIn?.user?.data?.user?.profile_image}`}
                    name={`${capitalizeFirstLetter(
                      signIn?.user?.data?.user?.first_name
                    )} ${capitalizeFirstLetter(
                      signIn?.user?.data?.user?.last_name
                    )}`}
                    className="poppins_font_number bg-[#70C5E0]/[.08] font-bold text-white"
                  />
                  <p className="font-bold text-black">
                    {`${capitalizeFirstLetter(
                      signIn?.user?.data?.user?.first_name
                    )} ${capitalizeFirstLetter(
                      signIn?.user?.data?.user?.last_name
                    )}`}
                  </p>
                </div>
                <hr /> */}

                {/* Timer Form - Start*/}
                <div>
                  <Form
                    validationSchema={timeTrackingSchema}
                    onSubmit={onSubmit}
                    useFormProps={{
                      mode: 'all',
                      defaultValues,
                    }}
                    // className="p-4"
                  >
                    {({
                      register,
                      control,
                      watch,
                      setValue,
                      getValues,
                      clearErrors,
                      setError,
                      formState: { errors },
                    }) => (
                      (setValueReference.current = setValue),
                      (getValuesReference.current = getValues),
                      console.log(errors, 'errors1234'),
                      (
                        <div className="">
                          <div className="flex items-center gap-2">
                            {/* Timer Tracking - Manual */}
                            {settingData?.task?.time_tracking?.includes(
                              'clocking'
                            ) &&
                              activeTab === 'timer' &&
                              !isRunning && (
                                <Input
                                  type="text"
                                  readOnly
                                  placeholder="Time here"
                                  className="w-[87%] rounded-xl [&>label>span]:font-medium"
                                  {...register('manual_time')}
                                  // onBlur={(e) => manualDateChange(e.target.value)}
                                  error={errors?.manual_time?.message as string}
                                  inputClassName="poppins_font_number"
                                  helperClassName="poppins_font_number"
                                  // helperText="Ex: 2h 30m format"
                                  disabled={
                                    taskTimerStartAndStopLoader ||
                                    (isTimeTrack && !selectedOption)
                                  }
                                />
                              )}

                            {/* Timer Tracking - Clocking */}
                            {settingData?.task?.time_tracking?.includes(
                              'clocking'
                            ) &&
                              activeTab === 'timer' &&
                              isRunning && (
                                <>
                                  <Input
                                    readOnly
                                    type="text"
                                    className="w-[88%] rounded-xl [&>label>span]:font-medium"
                                    inputClassName="poppins_font_number"
                                    value={formatTime(time)}
                                  />
                                </>
                              )}
                          </div>

                          {/* Notes field - Only show when time tracking is timer */}
                          {settingData?.task?.time_tracking?.includes(
                            'clocking'
                          ) &&
                            activeTab === 'timer' && (
                              <div className="mt-2 flex items-center gap-2 pb-1">
                                {/* <CgNotes className="h-8 w-8" /> */}
                                {isTimeTrack ? (
                                  <ReactSelect
                                    options={taskOptions}
                                    onChange={(
                                      selectedOption: Record<string, any>
                                    ) => {
                                      setSelectedTaskId(selectedOption.value);
                                      setIsRunning(false);
                                    }}
                                    value={selectedOption || null}
                                    placeholder="Select Task"
                                    className="h-[36px] w-full "
                                    classNamePrefix="custom-multi-select"
                                    styles={customStyles}
                                    isDisabled={
                                      !!selectedOption && !isTimeTrack
                                    }
                                    onMenuScrollToBottom={handleMenuScroll} // ✅ Scroll-based pagination
                                  />
                                ) : (
                                  <Input
                                    type="text"
                                    className="h-[36px] w-full rounded-[8px]  border-[#D4D4D4]  [&>label>span]:font-medium"
                                    // {...register('notes')}
                                    // onBlur={(e) => manualDateChange(e.target.value)}
                                    // error={errors?.notes?.message as string}
                                    inputClassName="poppins_font_number"
                                    helperClassName="poppins_font_number"
                                    defaultValue={capitalizeFirstLetter(
                                      taskName
                                    )}
                                    // helperText="Ex: 2h 30m format"
                                    disabled={!!task_id}
                                  />
                                )}

                                <span className="cursor-pointer">
                                  {!isRunning ? (
                                    <Button
                                      type="button"
                                      className="flex h-[37px] w-auto items-center justify-center rounded-[8px] bg-[#7667CF] py-4 text-[14px] font-normal leading-[16.8px] text-[#fff]  hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                                      size="sm"
                                      onClick={startTask}
                                      disabled={isTimeTrack && !selectedOption}
                                    >
                                      START
                                      {taskTimerStartAndStopLoader && (
                                        <Spinner
                                          size="sm"
                                          tag="div"
                                          className="ms-3"
                                          color="white"
                                        />
                                      )}
                                    </Button>
                                  ) : (
                                    <Button
                                      type="button"
                                      className="flex h-[37px] w-auto items-center justify-center rounded-[8px] bg-[#E9402A] py-4 text-[14px] font-normal leading-[16.8px] text-[#fff]  hover:border-[#E9402A] hover:bg-white hover:text-[#E9402A]"
                                      size="sm"
                                      onClick={endTask}
                                      disabled={isTimeTrack && !selectedOption}
                                    >
                                      STOP
                                      {taskTimerStartAndStopLoader && (
                                        <Spinner
                                          size="sm"
                                          tag="div"
                                          className="ms-3"
                                          color="white"
                                        />
                                      )}
                                    </Button>
                                  )}
                                </span>
                              </div>
                            )}

                          {settingData?.task?.time_tracking?.includes(
                            'clocking'
                          ) &&
                            activeTab === 'timer' && (
                              <div className="mt-3">
                                <span className="text-[14px] font-medium leading-[1.2] text-[#141414]">
                                  Add additional notes (Optional)
                                </span>
                                <Textarea
                                  placeholder="Add notes"
                                  className={`mt-1  w-full rounded-[8px] border-[#D4D4D4] [&>label>span]:font-medium`}
                                  {...register('notes')}
                                  // onBlur={(e) => manualDateChange(e.target.value)}
                                  error={errors?.notes?.message as string}
                                  textareaClassName="poppins_font_number h-[64px] resize-none"
                                  helperClassName="poppins_font_number"
                                  // helperText="Ex: 2h 30m format"
                                  disabled={
                                    taskTimerStartAndStopLoader ||
                                    isRunning ||
                                    (isTimeTrack && !selectedOption)
                                  }
                                />
                              </div>
                            )}

                          {settingData?.task?.time_tracking?.includes(
                            'manual'
                          ) &&
                            activeTab === 'manual' && (
                              <div className="h-auto w-auto gap-[12px] rounded-[6px] bg-[#F9FAFB] p-[12px]">
                                <div className="mb-2 flex flex-row  items-center justify-items-start gap-[12px]">
                                  <div className="">
                                    <Controller
                                      name="start_time"
                                      control={control}
                                      render={({
                                        field: { value, onChange },
                                      }) => (
                                        <DatePicker
                                          className="tracker-date-picker"
                                          placeholderText="Start time"
                                          selected={value}
                                          onChange={(event: any) => {
                                            onChange(event);
                                            calculateTotalTimeFromDateRage();
                                          }}
                                          showTimeSelect
                                          showTimeSelectOnly
                                          dateFormat="hh:mm aa"
                                          inputProps={{
                                            inputClassName:
                                              'poppins_font_number',
                                          }}
                                          disabled={
                                            isRunning ||
                                            (isTimeTrack && !selectedOption)
                                          }
                                        />
                                      )}
                                    />
                                    <p className="mt-1 text-xs text-red">
                                      {errors?.start_time?.message as string}
                                    </p>
                                  </div>
                                  <div className="text-[16px] font-bold leading-[21.86px] text-[#1E2026]">
                                    <span>-</span>
                                  </div>
                                  <div className="">
                                    <Controller
                                      name="end_time"
                                      control={control}
                                      render={({
                                        field: { value, onChange },
                                      }) => (
                                        <DatePicker
                                          className="tracker-date-picker"
                                          placeholderText="End time"
                                          selected={value}
                                          onChange={(event: any) => {
                                            onChange(event);
                                            calculateTotalTimeFromDateRage();
                                          }}
                                          showTimeSelect
                                          showTimeSelectOnly
                                          dateFormat="hh:mm aa"
                                          inputProps={{
                                            inputClassName:
                                              'poppins_font_number',
                                          }}
                                          disabled={
                                            isRunning ||
                                            (isTimeTrack && !selectedOption)
                                          }
                                        />
                                      )}
                                    />
                                    <p className="mt-1 text-xs text-red">
                                      {errors?.manual_time &&
                                        'End time must be after start time'}
                                    </p>
                                  </div>
                                  <div>
                                    <Controller
                                      name="start_date"
                                      control={control}
                                      render={({
                                        field: { value, onChange },
                                      }) => (
                                        <DatePicker
                                          className="tracker-start-date-picker"
                                          placeholderText="Start date"
                                          selected={value}
                                          onChange={(e) => {
                                            onChange(e);
                                            onChangeDate(e);
                                          }}
                                          selectsStart
                                          startDate={value}
                                          maxDate={new Date()}
                                          // showTimeSelect
                                          dateFormat="MMM dd, yyyy"
                                          disabled={
                                            isRunning ||
                                            (isTimeTrack && !selectedOption)
                                          }
                                        />
                                      )}
                                    />
                                    <p className="mt-1 text-xs text-red">
                                      {errors?.start_date?.message as string}
                                    </p>
                                  </div>
                                  {showPrivousDate && (
                                    <div>
                                      <Controller
                                        name="end_date"
                                        control={control}
                                        render={({
                                          field: { value, onChange },
                                        }) => (
                                          <DatePicker
                                            className="meeting-date-picker"
                                            placeholderText="Start date"
                                            selected={value}
                                            onChange={(e) => onChange(e)}
                                            selectsStart
                                            startDate={value}
                                            minDate={new Date()}
                                            // showTimeSelect
                                            dateFormat="MMMM dd, yyyy"
                                            disabled={
                                              isRunning ||
                                              (isTimeTrack && !selectedOption)
                                            }
                                          />
                                        )}
                                      />
                                      <p className="mt-1 text-xs text-red">
                                        {errors?.end_date?.message as string}
                                      </p>
                                    </div>
                                  )}
                                </div>

                                {/* Notes field - Only show when time tracking is manual */}
                                <div className="flex items-center gap-2">
                                  {/* <CgNotes className="h-8 w-8" /> */}
                                  {isTimeTrack ? (
                                    <ReactSelect
                                      options={taskOptions}
                                      onChange={(
                                        selectedOption: Record<string, any>
                                      ) => {
                                        setSelectedTaskId(selectedOption.value);
                                        setIsRunning(false);
                                      }}
                                      value={selectedOption || null}
                                      placeholder="Select Task"
                                      className="h-[36px] w-full "
                                      classNamePrefix="custom-multi-select"
                                      styles={customStyles}
                                      isDisabled={
                                        !!selectedOption && !isTimeTrack
                                      }
                                      onMenuScrollToBottom={handleMenuScroll} // ✅ Scroll-based pagination
                                    />
                                  ) : (
                                    <Input
                                      type="text"
                                      className="h-[36px] w-full rounded-[8px]  border-[#D4D4D4]  [&>label>span]:font-medium"
                                      // {...register('notes')}
                                      // onBlur={(e) => manualDateChange(e.target.value)}
                                      // error={errors?.notes?.message as string}
                                      inputClassName="poppins_font_number"
                                      helperClassName="poppins_font_number"
                                      defaultValue={capitalizeFirstLetter(
                                        taskName
                                      )}
                                      // helperText="Ex: 2h 30m format"
                                      disabled={!!task_id}
                                    />
                                  )}

                                  <Button
                                    type="submit"
                                    className="flex h-[36px] w-auto items-center justify-center rounded-[8px] bg-[#7667CF] py-4 text-[14px] font-normal leading-[16.8px] text-[#fff]  hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                                    size="sm"
                                    disabled={
                                      taskTimerStartAndStopLoader ||
                                      isRunning ||
                                      (isTimeTrack && !selectedOption)
                                    }
                                  >
                                    ADD
                                    {taskTimerStartAndStopLoader && (
                                      <Spinner
                                        size="sm"
                                        tag="div"
                                        className="ms-3"
                                        color="white"
                                      />
                                    )}
                                  </Button>
                                </div>

                                <div className="mt-4">
                                  <span className="text-[14px] font-medium leading-[1.2] text-[#141414]">
                                    Add additional notes (Optional)
                                  </span>
                                  <Textarea
                                    placeholder="Add notes"
                                    className={`mt-1  w-full rounded-[8px] border-[#D4D4D4] [&>label>span]:font-medium`}
                                    {...register('notes')}
                                    // onBlur={(e) => manualDateChange(e.target.value)}
                                    error={errors?.notes?.message as string}
                                    textareaClassName="poppins_font_number h-[64px] bg-white resize-none"
                                    helperClassName="poppins_font_number"
                                    // helperText="Ex: 2h 30m format"
                                    disabled={
                                      taskTimerStartAndStopLoader ||
                                      isRunning ||
                                      (isTimeTrack && !selectedOption)
                                    }
                                  />
                                </div>

                                <div className="flex items-end justify-end"></div>
                              </div>
                            )}
                        </div>
                      )
                    )}
                  </Form>
                </div>
                {/* Timer Form - End*/}
              </div>
            )}

            {/* User List - Start */}
            {false && trackedHourDetails?.tracked_history?.length > 0 && (
              <div className="">
                <div className="flex items-center">
                  <Title
                    as="h3"
                    className="text-[20px] font-semibold text-[#9BA1B9]"
                  >
                    Time Entries
                  </Title>
                </div>
                {trackedHourDetails?.tracked_history?.length === 0 && (
                  <div className="flex items-center justify-center p-5">
                    <Empty
                      text="No Data"
                      textClassName="mt-4 text-base text-gray-500"
                    />
                  </div>
                )}
                {trackedHourDetails?.tracked_history?.length > 0 &&
                  trackedHourDetails?.tracked_history?.map((data: any) => {
                    return (
                      <div
                        className="mt-2 flex items-center justify-between"
                        key={data?.user?._id}
                      >
                        <div className="flex items-center gap-3 pl-4">
                          <Avatar
                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${data?.user?.profile_image}`}
                            name={`${capitalizeFirstLetter(
                              data?.user?.first_name
                            )} ${capitalizeFirstLetter(data?.user?.last_name)}`}
                            className="poppins_font_number bg-[#70C5E0]/[.08] font-bold text-white"
                          />
                          <p className="font-bold text-black">
                            {`${capitalizeFirstLetter(
                              data?.user?.first_name
                            )} ${capitalizeFirstLetter(data?.user?.last_name)}`}
                          </p>
                        </div>
                        <Title
                          as="h5"
                          className="poppins_font_number text-sm font-semibold text-[#9BA1B9]"
                        >
                          {convertSecondsToTime(data?.total_time)}
                        </Title>
                      </div>
                    );
                  })}
              </div>
            )}
            {/* User List - End */}
          </>
        )}
      </div>
    </div>
  );
}
