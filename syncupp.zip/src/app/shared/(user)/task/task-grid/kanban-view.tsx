'use client';

import Select from '@/components/ui/select';
import { useDebouncedValue } from '@/hooks/use-debounce';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { PiCaretDownBold, PiMagnifyingGlassBold } from 'react-icons/pi';
import { useSelector } from 'react-redux';
import ReactSelect from 'react-select';
import { Button, Input } from 'rizzui';
import { taskStatusDropdownOptions } from '../../tasks/tasks-list/task-list';
import KanbanBoard from './kanban-board';

export default function KanbanView({ params }: { params: any }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [taskFilterDropdownOptions, setTaskFilterDropdownOptions] = useState(
    taskStatusDropdownOptions ?? []
  );
  const [taskFilterOptionName, setTaskFilterOptionName] = useState('All tasks');
  const [taskFilterOptionValue, setTaskFilterOptionValue] = useState('');

  const [assigneeFilter, setAssigneeFilter] = useState('');
  const [assignee, setAssignee] = useState<any>({
    name: 'Assigned to',
    value: '',
    label: 'Assigned to',
  });
  const [reset, setReset] = useState(false);
  // console.log("search term....", searchTerm)
  const { gridView } = useSelector((state: any) => state?.root?.task);
  const { members } = useSelector((state: any) => state?.root?.board);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const debouncedValue = useDebouncedValue<string>(searchTerm, 1000);

  // Filters clear when view changed
  useEffect(() => {
    setTaskFilterOptionName('All tasks');
    setTaskFilterOptionValue('');
    setAssigneeFilter('');
    setAssignee({ name: 'Assigned to', value: '', label: 'Assigned to' });
  }, [gridView]);

  useEffect(() => {
    if (
      searchTerm !== '' ||
      assigneeFilter !== '' ||
      taskFilterOptionValue !== ''
    ) {
      setReset(false);
    }
  }, [searchTerm, assigneeFilter, taskFilterOptionValue]);

  const onSearchClear = () => {
    setSearchTerm('');
  };

  const onSearchChange = (event: any) => {
    setSearchTerm(event?.target?.value);
  };

  // Assignee options
  const assigneeOptions = [{ name: 'All', value: '', label: 'All' }];
  members?.length > 0 &&
    members?.map((member: Record<string, any>) => {
      assigneeOptions.push({
        name: `${capitalizeFirstLetter(
          member?.first_name
        )} ${capitalizeFirstLetter(member?.last_name)}`,
        label: `${capitalizeFirstLetter(
          member?.first_name
        )} ${capitalizeFirstLetter(member?.last_name)}`,
        value: member?.id,
      });
    });

  const handleTaskFilterChange = (selectedOption: Record<string, any>) => {
    setTaskFilterOptionValue(selectedOption?.value);
  };

  const handleAssigneeChange = (selectedOption: Record<string, any>) => {
    setAssignee(selectedOption);
    setAssigneeFilter(selectedOption?.value ?? '');
  };

  const handleResetFilters = () => {
    setTaskFilterOptionName('All tasks');
    setTaskFilterOptionValue('');
    setAssigneeFilter('');
    setAssignee({ name: 'Assigned to', value: '', label: 'Assigned to' });
    setSearchTerm('');

    setReset(true);
  };

  const customStyles = {
    container: (provided: any) => ({
      ...provided,
      borderColor: 'rgb(209 213 219)',
      borderRadius: '4px',
    }),
    control: (provided: any, state: any) => ({
      ...provided,
      borderColor: 'rgb(209 213 219)', // Black border for the control (dropdown)
      borderRadius: '4px',
      boxShadow: state.isFocused ? '0 0 0 0 black' : 'none', // Highlight on focus
      '&:hover': {
        borderColor: 'black', // Black border on hover
      },
      height: '40px',
    }),
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected
        ? '#8c80d2'
        : state.isFocused
          ? '#f0f0f0'
          : 'white', // Highlighted background on hover
      color: state.isSelected ? 'white' : 'black',
      '&:hover': {
        backgroundColor: '#f0f0f0',
      },
    }),
    menu: (provided: any) => ({
      ...provided,
      borderRadius: '4px',
    }),
    placeholder: (provided: any) => ({
      ...provided,
      color: 'black', // Placeholder text color
    }),
  };

  useEffect(() => {
    if (
      signIn?.role === 'team_client' ||
      (signIn?.role === 'team_agency' &&
        signIn?.teamMemberRole === 'team_member')
    ) {
      const updatedTaskFilterDropdownOptions =
        taskFilterDropdownOptions?.filter(
          (option: any) => option?.value !== 'my_task'
        ) ?? [];
      setTaskFilterDropdownOptions(updatedTaskFilterDropdownOptions);
    }
  }, [signIn?.role]);

  return (
    <div className="flex flex-col gap-7">
      <div className="flex items-center justify-between">
        {/* Kanban Filters */}
        <div
          className="grid w-full grid-cols-1 items-center gap-4 
            sm:grid-cols-2 
            md:grid-cols-3 
            lg:grid-cols-4 
            xl:grid-cols-5 "
        >
          <Input
            type="search"
            placeholder="Search by anything"
            value={searchTerm}
            onClear={onSearchClear}
            onChange={onSearchChange}
            onKeyDown={handleKeyDown}
            inputClassName="h-10 text-black"
            clearable={true}
            prefix={<PiMagnifyingGlassBold className="h-4 w-4" />}
          />
          <Select
            options={taskFilterDropdownOptions}
            onChange={(selectedOption: Record<string, any>) => {
              setTaskFilterOptionName(selectedOption?.name);
              handleTaskFilterChange(selectedOption);
            }}
            value={taskFilterOptionName}
            placeholder="Select Status"
            // getOptionValue={(option) => option.value}
            className="task-list-tour-step-five w-full"
            selectClassName="text-black h-10"
            suffix={<PiCaretDownBold className="h-4 w-4" />}
            // dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
          />

          <ReactSelect
            options={assigneeOptions}
            onChange={(selectedOption: Record<string, any>) => {
              handleAssigneeChange(selectedOption);
            }}
            value={assignee}
            placeholder="Assigned to"
            className="h-10 w-full"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            styles={customStyles}
          />

          <Button
            className="flex h-10 w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
        {/* <TasksViewMode view="kanban" /> */}
      </div>
      <KanbanBoard
        params={params}
        taskFilterOptionValue={taskFilterOptionValue}
        assigneeFilter={assigneeFilter}
        debouncedValue={debouncedValue}
      />
    </div>
  );
}
