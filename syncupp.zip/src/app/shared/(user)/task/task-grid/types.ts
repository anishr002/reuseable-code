export type Id = string | number ;

export type Column = {
  _id: Id;
  board_id: string;
  section_name: string;
  sort_order: number;
  is_deletable: boolean;
  key?: string;
  color?: string;
  test_color?: string;
  createdAt?: string;
  updatedAt?: string;
  title: string;
};

export type Task = {
  // id: Id;
  // columnId: Id;
  // content?: string;
  // name?: string;
  // date?: string;
  // status?: string;
  // client?: string;
  // assigned_by?: string;
  // assigned_to?: string;

  _id: string;
  status: Record<string, any>;
  column_id?: string | number;
  title?: string;
  due_date?: string;
  due_time?: string;
  agenda?: string;
  createdAt?: string;
  priority?: string;
  assign_to?: any;
  comments_count?: number;
  attachment_count?: number;
  mark_as_done?: boolean;
  mark_as_archived?: boolean;
  client_name?: string;
  assigned_to_name?: string;
  assigned_by_name?: string;
  assigned_by_first_name?: string;
  assigned_by_last_name?: string;
};