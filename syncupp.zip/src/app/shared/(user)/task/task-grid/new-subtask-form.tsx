'use client';

import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Select from '@/components/ui/select';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { Text } from '@/components/ui/text';
import { Textarea } from '@/components/ui/textarea';
import {
  getAllTask,
  getTaskById,
  patchEditTask,
  postAddSubTask,
} from '@/redux/slices/user/task/taskSlice';
import {
  capitalizeFirstLetter,
  checkValidFileSize,
  getFileSize,
} from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { FiUsers } from 'react-icons/fi';
import { IoMdAdd } from 'react-icons/io';
import { RxCross2 } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import { checkPermission } from '../../roles-permissions/utils';
import { DatePicker } from '@/components/ui/datepicker';

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E4F6D6]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="w-[130px] font-medium text-green-dark">Low</Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FBF0DE]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#FBF0DE] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="warning" renderAsDot />
        <Text className="w-[130px] font-medium text-orange-dark">Medium</Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFD4C6]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="w-[130px] font-medium text-red-dark">High</Text>
      </div>
    ),
  },
];
// Define types for props
interface SubTaskFormProps {
  onClose: () => void; // Function that is called when closing the modal
  editMode: boolean; // Flag for edit mode
  rowData?: any;
  subTaskId?: any;
  column?: any;
  createTask?: any;
  updateTask?: any;
  allSubtask?: any;
  setAllSubtask?: any;
  parentStatus?: any;
  parentDueDate?: any;
}

const NewSubTaskForm: React.FC<SubTaskFormProps> = ({
  onClose,
  editMode = false,
  rowData,
  subTaskId = null,
  column,
  updateTask,
  createTask,
  setAllSubtask,
  allSubtask,
  parentStatus,
  parentDueDate,
}) => {
  const dispatch = useDispatch();
  const setValueReference = useRef<any>();
  const taskData = useSelector((state: any) => state?.root?.task);
  const { allTasksLoading, subtaskLoading, oldTasks, oldTasksSections } =
    useSelector((state: any) => state?.root?.task);
  const [titleError, setTitleError] = useState('');
  const [dueDate, setDueDate] = useState<any>(null);
  const [dueDateError, setDueDateError] = useState<string>(''); // New error state

  const { boardId, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { settingData } = useSelector((state: any) => state?.root?.setting);
  const [showAddMemberModal, setshowAddMemberModal] = useState(false);
  const [previewAttechmentImage, setPreviewAttechmentImage] = useState<any>([]);

  const [commentText, setCommentText] = useState('');
  const [mentionUser, setMentionUser] = useState<any>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);
  // for delete confirmation open modal
  const [showDeleteConfirmationPopper, setShowDeleteConfirmationPopper] =
    useState(false);

  //coustomField data
  const [customFieldData, setCustomFieldData] = useState<any>([]);
  const task = taskData?.task?.activity ?? {}; // after get task by id data in edit mode
  const [title, setTitle] = useState(
    editMode && task?.title ? task?.title : ''
  );
  const [priority, setPriority] = useState(
    editMode && task?.priority ? task?.priority : priorityOptions[0]?.value
  );

  const handleTitleChange = (e: any) => {
    const value = e.target.value;
    if (value.length > 150) {
      setTitleError('Title must not exceed 150 characters.');
    } else {
      setTitleError('');
    }
    setTitle(value);
  };
  const handlePriorityChange = (selectedOption: any) =>
    setPriority(selectedOption?.value);
  const { gridView } = useSelector((state: any) => state?.root?.task);

  // for handle comment attachement error
  const [commentAttachementInvalid, setCommentAttachementInvalid] =
    useState(false);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [selectedMembersDetails, setSelectedMembersDetails] = useState([]);

  const initialValues = {
    title: editMode && task?.title ? task?.title : '',
    attachments: [],
    due_date:
      editMode && task?.due_date ? moment(task?.due_date).toDate() : null,
    priority:
      editMode && task?.priority ? task?.priority : priorityOptions[0]?.value,
    status: editMode && task?.status?._id ? task?.status?._id : '',
    description: editMode && task?.agenda ? task?.agenda : '',
  };
  // status dropdown options - dynamic - not included completed and archived
  const statusOptions: Record<string, any>[] =
    sections && sections?.length > 0
      ? sections
          ?.filter(
            (section: Record<string, any>) =>
              section?.key !== 'completed' && section?.key !== 'archived'
          ) // Filter out 'completed' and 'archived' sections
          ?.map((section: Record<string, any>) => {
            return {
              value: section?._id,
              name: capitalizeFirstLetter(section?.section_name),
              label: (
                <div
                  className="flex items-center justify-center gap-2 rounded-3xl px-[20px] py-[8px] text-xs sm:text-sm"
                  style={{ backgroundColor: section?.color }}
                >
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: section?.test_color }}
                  />
                  <div
                    title={section?.section_name} // Tooltip to show full text
                    className="w-[130px] truncate font-medium"
                    style={{ color: section?.test_color }}
                  >
                    {section?.section_name.length > 20
                      ? `${section?.section_name.slice(0, 18)}...`
                      : section?.section_name}
                  </div>
                </div>
              ),
              section: section,
              key: section?.key,
            };
          })
      : [];

  const [selectedStatus, setSelectedStatus] = useState<any>(null);
  const [status, setStatus] = useState(editMode ? task?.status?._id : '');

  useEffect(() => {
    // in create mode we have to select bydefault status option as pendding and priority option as low
    if (!editMode) {
      const defaultOption =
        column &&
        statusOptions.find((option: any) => option.value === column?._id);

      const pendingOption =
        statusOptions.find((option: any) => option?.key === 'pending') ||
        statusOptions[0];

      const initialOption = defaultOption || pendingOption;

      setSelectedStatus(initialOption);
      setStatus(initialOption?.value ?? ''); // Directly set the state
    }
  }, []);

  useEffect(() => {
    const filterCustomFields = board?.custom_fields?.filter(
      (filed: any) => filed?.isShow
    ) ?? [];
    setCustomFieldData(
      editMode
        ? task?.custom_fields?.length === 0
          ? filterCustomFields
          : task?.custom_fields
        : filterCustomFields
    );
  }, [editMode, board?.custom_fields, task?.custom_fields]);

  useEffect(() => {
    const updatedAssigneeObject =
      assignees &&
      assignees?.length > 0 &&
      assignees?.filter((item: Record<string, any>, index: number) => {
        if (
          selectedMembers &&
          selectedMembers.length > 0 &&
          selectedMembers.includes(item?.user_id as never)
        ) {
          return { ...item, _id: item?.user_id };
        }
      });
    setSelectedMembersDetails(updatedAssigneeObject);
  }, [assignees, selectedMembers]);

  const handleDrop = (acceptedFiles: any) => {
    // Generate preview URLs for valid files
    // const previewURLs = acceptedFiles.map((file: any) => URL.createObjectURL(file));
    checkCommentAttachement(acceptedFiles);

    const newFiles = [
      ...acceptedFiles.map((file: any) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      ),
    ];

    const attachementURL =
      previewAttechmentImage && previewAttechmentImage !== null
        ? [...previewAttechmentImage, ...newFiles]
        : [...newFiles];
    setPreviewAttechmentImage(attachementURL);
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.svg', '.avif'],
      'application/pdf': ['.pdf'],
      'application/vnd.ms-excel': ['.xls', '.xlsx', '.csv'],
      'application/vnd.ms-powerpoint': ['.ppt', '.pptx'],
      'application/msword': ['.doc', '.docx'],
      'video/*': [
        '.mp4',
        '.avi',
        '.mov',
        '.wmv',
        '.flv',
        '.mkv',
        '.mpg',
        '.mpeg',
        '.mp2',
        '.3gp',
        '.webm',
      ],
      'application/zip': ['.zip', '.rar'],
      'text/plain': ['.txt'],
    },
    // maxSize: 200 * 1024 * 1024, // Maximum file size of 200MB
    multiple: true,
    noClick: true,
  };
  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps } = useDropzone(dropzoneOptions);

  // check in comment attachement if any invalide file exits or not
  const checkCommentAttachement = (data: any) => {
    setCommentAttachementInvalid(false);

    if (data?.length > 0) {
      const fileSize = Object.values(data)?.map((file: any) =>
        getFileSize(file)
      );
      const inValidFile = fileSize?.filter(
        (fileInfo) => !checkValidFileSize(fileInfo, 200)
      );
      if (inValidFile?.length > 0) {
        setCommentAttachementInvalid(true);
      }
    }
  };

  const onhandleSubmit = (e: any) => {
    e.preventDefault();
    if (commentAttachementInvalid) {
      return;
    }

    let isValid = true; // Track validation status

    // Reset errors before validating
    setDueDateError('');
    setTitleError('');

    if (!title.trim()) {
      setTitleError('Title is required.');
      isValid = false;
    }

    if (title.length > 150) {
      setTitleError('Title must not exceed 150 characters.');
      isValid = false;
    }

    if (parentDueDate) {
      if (new Date(dueDate) > new Date(parentDueDate)) {
        setDueDateError("Due date can't exceed parent due date.");
        isValid = false;
      }
    }

    if (!isValid) return;

    const formData: Record<string, any> = {
      title,
      priority,
      status: parentStatus,
      due_date: dueDate ? moment(dueDate).toDate() : null,
      board_id: board?._id ?? '',
      agenda: '',
      comment: commentText ?? '',
      custom_fields:
        customFieldData?.length > 0 ? JSON.stringify(customFieldData) : [],
    };

    // remove key if its null undefined or ""
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(([_, value]) => {
        return value !== undefined && value !== '';
      })
    );

    const myForm = new FormData();
    // Add data from the 'formData' object to the FormData
    for (const key in filteredFormData) {
      if (Object.prototype.hasOwnProperty.call(filteredFormData, key)) {
        const value = filteredFormData[key];
        myForm.append(key, value);
      }
    }

    // Mentions user data
    const mentionedUsers =
      mentionUser?.length > 0
        ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
        : [];

    myForm.append('mentioned_users', JSON.stringify(mentionedUsers));
    rowData?._id && myForm.append('parent_task', rowData?._id);

    tags?.length > 0 &&
      tags?.map((tag) => {
        myForm.append('tags', tag);
      });

    selectedMembers &&
      selectedMembers?.length > 0 &&
      myForm.append('assign_to', JSON.stringify(selectedMembers));

    if (!editMode) {
      previewAttechmentImage?.length > 0 &&
        previewAttechmentImage?.map((file: any) => {
          myForm.append('attachments', file);
        });
    } else {
      previewAttechmentImage?.length > 0 &&
        previewAttechmentImage?.map((file: any) => {
          if (!file?.preview?.startsWith('blob')) {
            myForm.append('attachments', JSON.stringify(file));
          } else {
            myForm.append('attachments', file);
          }
        });
    }

    if (!editMode) {
      dispatch(postAddSubTask(myForm)).then((result: any) => {
        if (postAddSubTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            if (gridView || rowData?._id) {
              if (gridView && rowData?._id) {
                // dispatch(getTaskById({ taskId: rowData?._id }));
                setAllSubtask((prevSubtasks: any) => [
                  ...prevSubtasks,
                  {
                    ...result?.payload?.data,
                    parent_task: result?.payload?.data?.parent_task?._id, // Correctly adding parent_task inside the object
                  },
                ]);

                updateTask(
                  rowData?._id,
                  'subtask_count',
                  { subtask: rowData },
                  oldTasks,
                  oldTasksSections
                );
                // createTask({
                //   ...result?.payload?.data,
                //   assign_to: selectedMembersDetails,
                //   attachment_count: result?.payload?.data?.attachments?.length,
                //   comments_count: result?.payload?.data?.comment,
                // });
              } else if (gridView && !rowData?._id) {
                updateTask(
                  rowData?._id,
                  'subtask_count',
                  { subtask: rowData },
                  oldTasks,
                  oldTasksSections
                );
                // createTask({
                //   ...result?.payload?.data,
                //   assign_to: selectedMembersDetails,
                //   attachment_count: result?.payload?.data?.attachments?.length,
                //   comments_count: result?.payload?.data?.comment,
                // });
              } else if (!gridView && rowData?._id) {
                // dispatch(getTaskById({ taskId: rowData?._id }));
                setAllSubtask((prevSubtasks: any) => [
                  ...prevSubtasks,
                  {
                    ...result?.payload?.data,
                    parent_task: result?.payload?.data?.parent_task?._id, // Correctly adding parent_task inside the object
                  },
                ]);

                dispatch(
                  getAllTask({
                    page: 1,
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    board_id: boardId,
                    pagination: true,
                  })
                );
              }
            } else {
              dispatch(
                getAllTask({
                  page: 1,
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  board_id: boardId,
                  pagination: true,
                })
              );
            }

            onClose();
          }
        }
      });
    } else {
      myForm.append('_id', subTaskId);
      dispatch(patchEditTask(myForm)).then((result: any) => {
        if (patchEditTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            // onClose();
            // if (!gridView) {
            //   dispatch(
            //     getAllTask({
            //       ...paginationParams,
            //       board_id: boardId,
            //       pagination: true,
            //     })
            //   );
            // } else {
            //   updateTask(
            //     task?._id,
            //     'task_update',
            //     {
            //       oldTaskStatus: task?.status,
            //       updated_task: {
            //         ...result?.payload?.data,
            //         assign_to: updatedAssigneeObject,
            //         attachment_count:
            //           result?.payload?.data?.attachments?.length,
            //         comments_count: result?.payload?.data?.comment,
            //       },
            //     },
            //     oldTasks,
            //     oldTasksSections
            //   );
            // }
          }
        }
      });
    }
  };

  const handleKeyDown = (e: any) => {
    if (e.key === 'Enter') {
      e.preventDefault(); // Prevent default form submission behavior
      onhandleSubmit(e); // Trigger this form's submit handler
    }
  };

  if (allTasksLoading && editMode) {
    return (
      <div className="flex h-[100vh] items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  const handleRemoveMember = (userId: string) => {
    let removedMemberFiltered =
      (selectedMembers &&
        selectedMembers?.length > 0 &&
        selectedMembers?.filter((member: any, index: number) => {
          if (member !== userId) {
            return member;
          }
        })) ||
      [];

    setSelectedMembers(removedMemberFiltered);
  };

  // Clear error when the input loses focus
  const handleInputBlur = () => {
    setError(null); // Clear the error when the input loses focus
  };

  // Add the onChange validation
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const MAX_WORDS = 20;
    const MAX_CHARS = 20; // Limit for a single tag

    const value = e.target.value;
    setInputValue(value);

    const trimmedValue = value.trim();

    // Validation
    const wordCount = trimmedValue.split(/\s+/).filter(Boolean).length;
    if (trimmedValue === '') {
      setError('Tag cannot be empty.');
    } else if (trimmedValue.length > MAX_CHARS) {
      setError(`Each tag can have a maximum of ${MAX_CHARS} characters.`);
    } else if (
      tags.some((tag) => tag?.toLowerCase() === trimmedValue.toLowerCase())
    ) {
      setError('This tag already exists.');
    } else {
      setError(null); // No error if the input is valid
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const trimmedValue = inputValue.trim();

      if (trimmedValue !== '' && !error) {
        setTags((prevTags) => [...prevTags, trimmedValue]);
        setInputValue('');
      }
    }
  };

  const handleRemoveTag = (index: number) => {
    setTags((prevTags) => prevTags.filter((_, i) => i !== index));
  };

  return (
    <div>
      {/* <SimpleBar className="mt-0 max-h-[300px]"> */}

      <div className="flex flex-col gap-4">
        {/* <div className="flex gap-2"> */}
        <div>
          <span className="text-[14px] font-medium">Add subtask Title</span>
          <Textarea
            textareaClassName="text-black poppins_font_number bg-white"
            className="w-full"
            placeholder="Add your subtask title here"
            rows={2}
            value={title}
            onChange={handleTitleChange}
            onKeyDown={handleKeyDown}
            disabled={
              task?.mark_as_done ||
              (['team_client', 'team_agency'].includes(signIn?.role) &&
                !checkPermission(
                  'projects',
                  'tasks',
                  'create',
                  signIn?.permission
                ) &&
                !checkPermission(
                  'projects',
                  'tasks',
                  'update',
                  signIn?.permission
                ))
            }
          />
          {titleError && <p className="mt-1 text-red-500">{titleError}</p>}
        </div>

        {/* <div className={`${editMode ? 'w-3/4' : 'w-full'}`}>
                <Input
                  inputClassName="text-black poppins_font_number bg-white"
                  className="w-full"
                  placeholder="Enter title"
                  value={title}
                  onChange={handleTitleChange}
                  onKeyDown={handleKeyDown}
                  disabled={
                    task?.mark_as_done ||
                    (['team_client', 'team_agency'].includes(signIn?.role) &&
                      !checkPermission(
                        'projects',
                        'tasks',
                        'create',
                        signIn?.permission
                      ) &&
                      !checkPermission(
                        'projects',
                        'tasks',
                        'update',
                        signIn?.permission
                      ))
                  }
                />
                {titleError && (
                  <p className="mt-1 text-red-500">{titleError}</p>
                )}
              </div> */}
        {/* </div> */}

        <div>
          <div
            className=" flex cursor-pointer items-center justify-between rounded-lg border-[1px] bg-[#F9FAFB] p-3 text-black"
            onClick={() => setshowAddMemberModal(true)}
          >
            <div className="flex gap-3">
              <FiUsers className="h-[20px] w-[20px]" />
              <span className="rizzui-input-label block text-[14px] font-semibold text-[#4B5563]">
                Add assignee(s)
              </span>
            </div>
            <IoMdAdd className="h-[16px] w-[16px]" />
          </div>
        </div>

        {selectedMembersDetails?.length > 0 && (
          <SimpleBar
            className={`${
              selectedMembersDetails?.length > 3 ? 'max-h-40' : ''
            } `}
          >
            <div className="rounded-lg border-[1px]">
              {' '}
              {selectedMembersDetails?.map((member: any, index) => (
                <div
                  className={`flex items-center justify-between p-3 text-black ${
                    selectedMembersDetails?.length - 1 !== index &&
                    'border-b-[1px]'
                  }`}
                  key={index}
                >
                  <div className="flex items-center gap-3">
                    <Avatar
                      src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                      name={
                        capitalizeFirstLetter(member?.first_name) +
                        ' ' +
                        capitalizeFirstLetter(member?.last_name)
                      }
                      className="!h-[30px] !w-[30px] text-white"
                    />
                    <span className="rizzui-input-label block text-[14px] font-semibold">
                      {capitalizeFirstLetter(member?.first_name) +
                        ' ' +
                        capitalizeFirstLetter(member?.last_name)}
                    </span>
                  </div>
                  <RxCross2
                    className="h-[20px] w-[20px] cursor-pointer"
                    onClick={() => handleRemoveMember(member?._id)}
                  />
                </div>
              ))}
            </div>
          </SimpleBar>
        )}

        {/* due date */}
        <div className="task_form_date_picker_close_button_hide">
          <span className="text-[14px] font-medium text-[#141414]">
            Select Due Date & Time
          </span>
          <DatePicker
            selected={dueDate}
            onChange={(date: any) => {
              setDueDate(date);

              // Apply validation only if parentDueDate exists
              if (parentDueDate) {
                if (new Date(date) > new Date(parentDueDate)) {
                  setDueDateError("Due date can't exceed parent due date.");
                } else {
                  setDueDateError(''); // Clear error if valid
                }
              } else {
                setDueDateError(''); // Clear error when no parentDueDate restriction
              }
            }}
            inputProps={{
              inputClassName: 'font-sans', // Custom class for the input
            }}
            placeholderText={!task?.mark_as_done ? 'Select due date' : ''}
            selectsStart
            startDate={dueDate}
            minDate={new Date()}
            // disabled={isDisable}
            showTimeSelect
            isClearable={true}
            popperPlacement="bottom-start"
            dateFormat="MMMM d, yyyy h:mm aa"
            className="bg-[#F9FAFB]"
          />
          {dueDateError && (
            <span className=" text-sm text-red-500">{dueDateError}</span>
          )}
        </div>

        <div className={`flex gap-6 ${error ? 'items-start' : 'items-center'}`}>
          <div className="w-full">
            <Select
              variant="text"
              // value={statusOptions?.find(
              //   (option) => option.value === status
              // )}
              value={selectedStatus}
              onChange={(selectedOption: any) => {
                // console.log("selected status...", selectedOption)
                setSelectedStatus(selectedOption);
                setStatus(selectedOption?.value);
              }}
              options={statusOptions}
              placeholder="Select status"
              selectClassName={`!py-0`}
              style={{
                backgroundColor: selectedStatus?.section?.color,
              }}
              className={`rounded-lg border-[1px]`}
            />
          </div>
          <div className="w-full">
            <Select
              variant="text"
              value={priorityOptions?.find(
                (option) => option.value === priority
              )}
              onChange={handlePriorityChange}
              options={priorityOptions}
              placeholder="Select priority"
              className={`rounded-lg border-[1px]`}
              selectClassName={`!py-0 ${priorityOptions?.find(
                (option) => option.value === priority
              )?.color}`}
            />
          </div>

          <div className="w-full">
            <Input
              type="text"
              inputClassName="text-black poppins_font_number"
              className="poppins_font_number flex-1 border-none bg-[#F9FAFB] text-[14px] text-black focus:outline-none"
              placeholder=" # Add Tags"
              value={inputValue}
              onKeyDown={handleAddTag}
              onChange={handleInputChange}
              onBlur={handleInputBlur}
            />
            {error && (
              <span className="mt-1 text-[12px] text-red-500">{error}</span>
            )}
          </div>
        </div>
        {tags?.length > 0 && (
          <div>
            <div className="flex w-full flex-wrap gap-2">
              {tags?.map((tag, index) => (
                <div
                  key={index}
                  className="flex max-w-full items-center gap-2 break-words rounded-md bg-[#E4E7EB] px-3 py-1 text-sm font-medium text-[#4A5568] dark:bg-[#2D3748] dark:text-[#CBD5E0]"
                >
                  <span className="break-all">{tag}</span>
                  <RxCross2
                    className="h-4 w-4 cursor-pointer text-black"
                    onClick={() => handleRemoveTag(index)}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* <div className="flex justify-between gap-4">
              <div>
                <label className="text-[14px] font-medium text-[#9BA1B9]">
                  Assignee
                </label>
                <div
                  className="relative flex cursor-pointer items-center gap-3 py-2 text-sm focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg"
                  onClick={() => setshowAddMemberModal(true)}
                >
                  <div className="mr-1 flex h-[37px] w-[37px] items-center justify-center rounded-full border-[1px] border-dashed border-[#9BA1B9]">
                    <FiPlus className="h-[15px] w-[15px] text-[#9BA1B9] hover:text-[#8C80D2]" />
                  </div>
                  {selectedMembersDetails?.length > 0 ? (
                    <div className="flex items-center">
                      {selectedMembersDetails.map((member: any) => (
                        <figure
                          key={member?.id}
                          className="relative z-10 ml-[-13px] h-[40px] w-[40px] cursor-pointer rounded-full focus:border-2 focus:border-gray-900"
                        >
                          <Avatar
                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                            name={
                              capitalizeFirstLetter(member?.first_name) +
                              ' ' +
                              capitalizeFirstLetter(member?.last_name)
                            }
                            className="bg-[#70C5E0] font-medium text-white"
                          />
                        </figure>
                      ))}
                      {selectedMembersDetails.length > 3 && (
                        <div className="poppins_font_number ml-[-10px] flex h-[40px] w-[40px] items-center justify-center rounded-full text-[14px] font-medium text-[#9BA1B9]">
                          +{selectedMembersDetails.length - 3}
                        </div>
                      )}
                    </div>
                  ) : (
                    <span className="rizzui-input-label block text-[14px] font-semibold text-[#9BA1B9] hover:text-[#8C80D2]">
                      Add member
                    </span>
                  )}
                </div>
              </div>

              <div>
                <span className="text-[14px] font-medium text-[#9BA1B9]">
                  Status
                </span>
                <Select
                  variant="text"
                  // value={statusOptions?.find(
                  //   (option) => option.value === status
                  // )}
                  value={selectedStatus}
                  onChange={(selectedOption: any) => {
                    // console.log("selected status...", selectedOption)
                    setSelectedStatus(selectedOption);
                    setStatus(selectedOption?.value);
                  }}
                  options={statusOptions}
                  placeholder="Select status"
                  selectClassName="m-0 focus:outline-none focus:border-white focus:ring-white !p-0"
                  className="task_select_dropdown w-[200px] py-2"
                />
              </div>

              <div>
                <span className="text-[14px] font-medium text-[#9BA1B9]">
                  Priority
                </span>
                <Select
                  variant="text"
                  value={priorityOptions?.find(
                    (option) => option.value === priority
                  )}
                  onChange={handlePriorityChange}
                  options={priorityOptions}
                  placeholder="Select priority"
                  selectClassName="m-0 focus:outline-none focus:border-white focus:ring-white !p-0"
                  className="task_select_dropdown w-[200px] py-2"
                />
              </div>
            </div>  */}
        <div className="flex justify-end gap-4">
          <Button
            className="h-[42px] cursor-pointer rounded-lg border  border-[#E5E7EB] bg-white text-sm text-[#141414]"
            size="lg"
            type="button"
            onClick={() => onClose()} // Add your cancel handler here
          >
            Cancel
          </Button>

          <Button
            className="h-[42px] cursor-pointer rounded-lg bg-[#8C80D2] text-sm text-white"
            size="lg"
            type="button"
            disabled={subtaskLoading}
            onClick={(e) => onhandleSubmit(e)}
          >
            Create
            {subtaskLoading && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
      </div>

      {(showAddMemberModal || showDeleteConfirmationPopper) && (
        <div>
          <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-hidden rounded-lg bg-white shadow-lg "
              style={{ width: '600px', height: '475px' }}
            >
              {showAddMemberModal && (
                <AddMembers
                  onClose={() => setshowAddMemberModal(false)}
                  selectedMembers={selectedMembers}
                  setSelectedMembers={setSelectedMembers}
                  formPage={true}
                  addTaskMember={true}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewSubTaskForm;
