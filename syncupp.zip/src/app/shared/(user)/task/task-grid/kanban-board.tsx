import EditTaskForm from '@/app/shared/(user)/task/task-grid/edit-task-form';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import SimpleBar from '@/components/ui/simplebar';
import socket from '@/io';
import '@/layouts/helium/style.css';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  getBoardSectionsById,
  putEditBoardSectionOrder,
} from '@/redux/slices/user/task/boardSlice';
import {
  RemoveGetAllTasksData,
  getAllTask,
  setAllTaskData,
  setOldTasks,
  setTasksSectionsData,
} from '@/redux/slices/user/task/taskSlice';
import { putTaskKanbanStatusChange } from '@/redux/slices/user/task/taskStatusSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import {
  getStepsByRole,
  kanbanTaskTourStepsContent,
} from '@/utils/tour-steps/tour-steps';
import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import { SortableContext, arrayMove } from '@dnd-kit/sortable';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import { checkPermission } from '../../roles-permissions/utils';
import ColumnContainer from './column-container';
import TaskCard from './task-card';
import { Column, Id } from './types';

function KanbanBoard({
  params,
  taskFilterOptionValue,
  assigneeFilter,
  debouncedValue,
}: {
  params: { id: string };
  taskFilterOptionValue: string;
  assigneeFilter: string;
  debouncedValue?: string;
}) {
  const dispatch = useDispatch();
  const { openDrawer, closeDrawer } = useDrawer();
  const { openModal, closeModal } = useModal();

  const path = usePathname();
  const searchParams = useSearchParams();
  const router = useRouter();

  // for selecting state from redux store
  const taskData = useSelector((state: any) => state?.root?.task);
  const { gridView, tagList, oldTasks, oldTasksSections, paginationParams } =
    useSelector((state: any) => state?.root?.task);
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { boardId, members, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);

  // for state management of filters
  const [searchTerm, setSearchTerm] = useState('');

  //Infinite Scroll state
  const [getAllTaskLoader, setGetAllTaskLoader] = useState(false);
  const [totalSectionData, setTotalSectionData] = useState([]);

  useEffect(() => {
    dispatch(setTasksSectionsData(totalSectionData));
  }, [totalSectionData]);

  // main api call for fetching tasks and sections
  useEffect(() => {
    // get all board sections
    dispatch(getBoardSectionsById({ board_id: params?.id }));
  }, [
    dispatch,
    signIn?.role,
    debouncedValue,
    taskFilterOptionValue,
    params?.id,
  ]);

  //default columns set
  const [columns, setColumns] = useState<Column[]>(sections || []);
  const columnsId = useMemo(() => columns?.map((col) => col?._id), [columns]);

  // set columns when data will change
  useEffect(() => {
    sections && sections?.length > 0 && setColumns((prev) => [...sections]);
  }, [sections]);

  //default task set
  const [tasks, setTasks] = useState<any[]>([]);
  const [kanbanTaskData, setkanbanTaskData] = useState<any[]>([]);

  useEffect(() => {
    dispatch(setOldTasks(tasks));
  }, [tasks]);

  useEffect(() => {
    dispatch(setAllTaskData(kanbanTaskData));
  }, [kanbanTaskData]);

  useEffect(() => {
    // get all tasks
    setGetAllTaskLoader(true);
    dispatch(
      getAllTask({
        search: debouncedValue,
        pagination: false,
        board_id: params?.id,
        filter: taskFilterOptionValue,
        assignee_id: assigneeFilter,
      })
    ).then((result: any) => {
      if (getAllTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          // console.log("result after first get All task api call...", result)
          result?.payload?.data?.activity &&
            setTasks(result?.payload?.data?.activity);
          setkanbanTaskData(result?.payload?.data);
          setTotalSectionData(result?.payload?.data?.task_counts);
          setGetAllTaskLoader(false);
          dispatch(RemoveGetAllTasksData());
        }
        setGetAllTaskLoader(false);
      }
      setGetAllTaskLoader(false);
    });
  }, [
    dispatch,
    clientSliceData?.agencyId,
    signIn?.role,
    debouncedValue,
    taskFilterOptionValue,
    assigneeFilter,
    params?.id,
  ]);

  // state for setting active column and active task
  const [activeColumn, setActiveColumn] = useState<Column | null>(null);
  const [activeTask, setActiveTask] = useState<any | null>(null);

  // // set tasks when data will change
  // useEffect(() => {
  //   setTasks(taskData?.data?.activity);
  // }, [taskData?.data]);

  // console.log("active task...", activeTask);
  // console.log("active column...", activeColumn);
  // console.log("tasks...", tasks);
  // console.log("columns...", columns);

  // Api call for Tour status get
  useEffect(() => {
    // Tour comment
    dispatch(getAllTourStatus());
  }, []);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [kanbanTaskTourSteps, setKanbanTaskTourSteps] = useState([]);

  // Handle close tour
  const handleCloseTour = () => {
    dispatch(updateTourStatus({ board: { kanban_task_tour: true } })).then(
      (result: any) => {
        if (updateTourStatus.fulfilled.match(result)) {
          if (result?.payload?.success) {
            setIsTourOpen(false);
            // Tour comment
            dispatch(getAllTourStatus());
          }
        }
      }
    );
  };

  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.board &&
      Object?.keys(tourStatusData?.board).includes('kanban_task_tour') &&
      !tourStatusData?.board?.kanban_task_tour
    ) {
      setKanbanTaskTourSteps([]);
      setIsTourOpen(false);
      const kanbanTaskTourStepContent = kanbanTaskTourStepsContent(
        handleCloseTour,
        signIn,
        checkPermission
      );

      const updatedKanbanTaskTourSteps = getStepsByRole(
        kanbanTaskTourStepContent
      );
      updatedKanbanTaskTourSteps?.length > 0 &&
        setKanbanTaskTourSteps(updatedKanbanTaskTourSteps);
      updatedKanbanTaskTourSteps?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData, signIn?.permission]);

  // for dnd context props
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 10,
      },
    })
  );

  // for create new task

  function createTask(task: any) {
    const updateSectionTotalCount: any =
      (totalSectionData &&
        totalSectionData?.map((section: any, index: number) => {
          if (section?._id !== task?.status?._id) {
            return section;
          }
          return { ...section, count: section?.count + 1 };
        })) ||
      [];

    setTotalSectionData(updateSectionTotalCount);

    // setTasks((prevTasks) => [...prevTasks, task]);
    setTasks((prev) => [task, ...prev]);
    // setTasks([...tasks, task]);
  }

  // for update get All Task

  function updateGetAllTasks(task: any[]) {
    // update logic here if task id is already there than filter it out

    // const newTasks = tasks?.filter((task) => {
    //   if (task._id !== id) return task;
    // });

    // setTasks(newTasks);

    setTasks((prevTasks) => [...prevTasks, ...task]);
  }

  //  for update task
  function updateTask(
    id: any,
    action: any,
    data: any,
    oldTaskData: any,
    oldTasksSectionsData: any
  ) {
    if (action === 'subtask_count') {
      const newTasks =
        oldTaskData?.map((task: any) => {
          if (task?._id !== id) return task;
          return {
            ...task,
            sub_task_count: (task?.sub_task_count || 0) + 1, // Increment based on the current value
          };
        }) || [];
      setTasks(newTasks);
    }

    if (action === 'decrease_subtask_count') {
      const newTasks =
        oldTaskData?.map((task: any) => {
          if (task._id !== id) return task;
          return {
            ...task,
            sub_task_count: Math.max((task?.sub_task_count || 0) - 1, 0), // Decrement but ensure it doesn't go below 0
          };
        }) || [];
      setTasks(newTasks);
    }

    if (action === 'status_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return {
              ...task,
              mark_as_done: data?.mark_as_done,
              mark_as_archived: data?.mark_as_archived,
              status: data?.status,
            };
          })) ||
        [];

      setTasks(newTasks);
    } else if (action === 'complete_status_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return {
              ...task,
              mark_as_done: data?.mark_as_done,
              mark_as_archived: data?.mark_as_archived,
              status: data?.after_status,
            };
          })) ||
        [];

      const newSectionTotalCount: any =
        (oldTasksSectionsData &&
          oldTasksSectionsData?.length > 0 &&
          oldTasksSectionsData?.map((section: any, index: number) => {
            if (section?._id !== data?.after_status?._id) {
              if (section?._id === data?.before_status?._id) {
                return { ...section, count: section?.count - 1 };
              }
              return section;
            }
            return { ...section, count: section?.count + 1 };
          })) ||
        [];
      setTotalSectionData(newSectionTotalCount);

      setTasks(newTasks);
    } else if (action === 'assignee_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return { ...task, assign_to: data };
          })) ||
        [];

      setTasks(newTasks);
    } else if (action === 'due_date_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return { ...task, due_date: data };
          })) ||
        [];

      setTasks(newTasks);
    } else if (action === 'title_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return { ...task, title: data };
          })) ||
        [];

      setTasks(newTasks);
    } else if (action === 'priority_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return { ...task, priority: data };
          })) ||
        [];

      setTasks(newTasks);
    } else if (action === 'tags_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return { ...task, tags: data };
          })) ||
        [];

      setTasks(newTasks);
    } else if (action === 'task_update') {
      // have to tasks count if needed

      if (data?.updated_task?.parent_task) {
        return;
      }
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id === id) {
              return {
                ...data?.updated_task,
                sub_task_count: data?.updated_task?.subtask_count,
              }; // Replace the existing task with the new data
            } else if (task?.parent_task?._id === id) {
              return {
                ...task,
                parent_task: data?.updated_task,
                sub_task_count: data?.updated_task?.subtask_count,
              };
            }
            return task;
          })) ||
        [];

      setTasks(newTasks);

      if (data?.updated_task?.status?._id === data?.oldTaskStatus?._id) {
        return;
      } else {
        const newSectionTotalCount: any =
          (oldTasksSectionsData &&
            oldTasksSectionsData?.length > 0 &&
            oldTasksSectionsData?.map((section: any, index: number) => {
              if (section?._id !== data?.updated_task?.status?._id) {
                if (section?._id === data?.oldTaskStatus?._id) {
                  return { ...section, count: section?.count - 1 };
                }
                return section;
              }
              return { ...section, count: section?.count + 1 };
            })) ||
          [];
        setTotalSectionData(newSectionTotalCount);
      }
    } else if (action === 'delete_task') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.filter((task: any) => {
            if (task?._id !== id) return task;
          })) ||
        [];

      setTasks((prev) => [...newTasks]);
      if (oldTaskData?.length !== newTasks?.length) {
        const updateSectionTotalCount: any =
          (oldTasksSectionsData &&
            oldTasksSectionsData?.length > 0 &&
            oldTasksSectionsData?.map((section: any, index: number) => {
              if (section?._id !== data?.section_id) {
                return section;
              }
              return { ...section, count: section?.count - 1 };
            })) ||
          [];

        setTotalSectionData(updateSectionTotalCount);
      }
    } else if (action === 'leave_task') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.filter((task: any) => {
            if (task._id !== id) return task;
          })) ||
        [];
      // const updateSectionTotalCount: any = totalSectionData && totalSectionData?.map((section: any, index: number) => {
      //   if (section?._id !== task?.status?._id) {
      //     return section;
      //   }
      //   return { ...section, count: section?.count + 1 };
      // });
      setTasks(newTasks);
    } else if (action === 'leave_member') {
      const newTasks =
        oldTaskData &&
        oldTaskData?.length > 0 &&
        oldTaskData.map((task: any) => {
          if (task._id !== id) {
            return task;
          } else {
            const updateAssign = task?.assign_to?.filter(
              (member: any) => member?._id !== data?.user_id
            );
            return {
              ...task,
              assign_to: updateAssign,
            };
          }
        });
      setTasks(newTasks);
    } else if (action === 'comment_update') {
      const newTasks =
        (oldTaskData &&
          oldTaskData?.length > 0 &&
          oldTaskData?.map((task: any) => {
            if (task._id !== id) return task;
            return {
              ...task,
              comments: data?.comments?.comments,
              comments_count: data?.comments?.comments?.length,
            };
          })) ||
        [];
      setTasks(newTasks);
    }
  }

  // Redirect with link to view task details logic
  useEffect(() => {
    if (searchParams && searchParams?.get('task_id') && gridView) {
      setTimeout(() => {
        openModal({
          view: (
            <EditTaskForm
              rowData={{ _id: searchParams.get('task_id') }}
              editMode={true}
              updateTask={updateTask}
              onClose={closeModal}
            />
          ),
          customSize: '800px',
        });
        router.replace(path);
      }, 1500);
    }
  }, [searchParams, gridView]);

  // Helper function to check if a task exists
  const taskExists = (tasks: any[], taskId: any) =>
    tasks &&
    tasks.length > 0 &&
    tasks.some((task: any) => task?._id === taskId);

  // Helper function to update a task
  const updateTasks = (
    tasks: any[],
    taskId: any,
    updateCallback: (task: any) => any
  ) =>
    tasks.map((task: any) =>
      task._id !== taskId ? task : updateCallback(task)
    );

  // Helper function to update section count
  const updateSectionCount = (
    sections: any[],
    oldSectionId: any,
    newSectionId: any
  ) =>
    sections.map((section: any) => {
      if (section?._id === oldSectionId) {
        return { ...section, count: section?.count - 1 };
      }
      if (section?._id === newSectionId) {
        return { ...section, count: section?.count + 1 };
      }
      return section;
    });

  /* 
    INFO: For update task using socket
    status_update - use when card status update like card move or mark as done
    date_assignee_update - when assgin or due date add in card
    task_update - when data update from task form
    comment_update - when new comment add in task
  */
  const updateTaskSocket = (
    taskId: any,
    action: any,
    data: any,
    oldTaskData: any,
    oldTasksSectionsData: any
  ) => {
    if (action === 'status_update') {
      if (!taskExists(oldTaskData, taskId)) return;

      const newTasks = updateTasks(oldTaskData, taskId, (task: any) => ({
        ...task,
        mark_as_done: data?.mark_as_done,
        mark_as_archived: data?.mark_as_archived,
        status: data?.new_section,
      }));

      setTasks(newTasks);

      const newSectionTotalCount: any = updateSectionCount(
        oldTasksSectionsData,
        data?.old_section?._id,
        data?.new_section?._id
      );

      setTotalSectionData(newSectionTotalCount);
    } else if (action === 'date_assignee_update') {
      const { updated_task, memberList, due_date } = data;

      if (taskExists(oldTaskData, taskId)) {
        const newTasks = updateTasks(oldTaskData, taskId, (task: any) => ({
          ...task,
          assign_to: memberList,
          due_date: due_date,
          title: updated_task?.title,
          priority: updated_task?.priority,
          tags: updated_task?.tags ? updated_task?.tags : [],
        }));
        setTasks(newTasks);
      } else {
        createTask({
          ...updated_task,
          assign_to: memberList,
          attachment_count: updated_task?.attachments?.length,
          comments_count: updated_task?.comments?.length,
        });
      }
    } else if (action === 'task_update') {
      const task = oldTaskData?.find((task: any) => task?._id === taskId);
      const assignee = data?.updated_task?.assign_to?.map(
        (member: any) => member?._id || member
      );

      if (!task && assignee?.includes(signIn?.user?.data?.user?._id)) {
        return createTask({
          ...data?.updated_task,
          attachment_count: data?.updated_task?.attachments?.length,
          comments_count: data?.updated_task?.comments?.length,
        });
      }

      if (!assignee?.includes(signIn?.user?.data?.user?._id)) {
        const filteredTasks = oldTaskData.filter(
          (task: any) => task._id !== taskId
        );
        setTasks(filteredTasks);

        const updatedSectionTotalCount: any = updateSectionCount(
          oldTasksSectionsData,
          data?.old_section?._id,
          null
        );

        setTotalSectionData(updatedSectionTotalCount);
        return;
      }

      const newTasks = updateTasks(oldTaskData, taskId, () => ({
        ...data?.updated_task,
        sub_task_count: data?.updated_task?.sub_task_count,
      }));

      setTasks(newTasks);

      if (data?.updated_task?.status?._id !== data?.old_section?._id) {
        const newSectionTotalCount: any = updateSectionCount(
          oldTasksSectionsData,
          data?.old_section?._id,
          data?.updated_task?.status?._id
        );

        setTotalSectionData(newSectionTotalCount);
      }
    } else if (action === 'comment_update') {
      const newTasks = updateTasks(oldTaskData, taskId, (task: any) => ({
        ...task,
        comments: data?.comments,
        comments_count: data?.comments?.length,
        attachment_count: data?.attachments?.length,
      }));

      setTasks(newTasks);
    }
  };

  // for delete section column
  function deleteColumn(id: Id) {
    const filteredColumns = columns.filter((col) => col._id !== id);
    setColumns(filteredColumns);

    const newTasks = tasks.filter((t) => t.status._id !== id);
    setTasks(newTasks);
  }

  // for update section column

  function updateColumn(id: Id, title: string) {
    const newColumns = columns.map((col) => {
      if (col._id !== id) return col;
      return { ...col, section_name: title };
    });

    setColumns(newColumns);
  }

  // onDragStart function for handle drag start event

  function onDragStart(event: DragStartEvent) {
    // console.log("event...", event)

    // set active column first when drag start
    if (event.active.data.current?.type === 'Column') {
      setActiveColumn(event.active.data.current.column);
      return;
    }

    // set active task first when drag start
    if (event.active.data.current?.type === 'Task') {
      setActiveTask(event.active.data.current.task);
      return;
    }
  }

  // onDragEnd function for handle drag end event
  function onDragEnd(event: DragEndEvent) {
    setActiveColumn(null);
    // setActiveTask(null);

    const { active, over } = event;

    // console.log("onDragEnd active....", active, "onDragEnd over....", over)

    if (active.data.current?.type === 'Task') {
      // return null when status is same for tasks
      if (
        activeTask?.status?._id === active?.data?.current?.task?.status?._id
      ) {
        setActiveTask(null);
        return;
      }

      // return null if task is not completed and moving into archived

      if (
        activeTask?.status?.key !== 'completed' &&
        active?.data?.current?.task?.status?.key === 'archived'
      ) {
        return;
      } else if (activeTask?._id === active?.id) {
        // api call for status change of task
        dispatch(
          putTaskKanbanStatusChange({
            _id: active?.data?.current?.task?._id,
            status: active?.data?.current?.task?.status?._id,
          })
        ).then((result: any) => {
          if (putTaskKanbanStatusChange.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              // update task function call
              if (active?.data?.current?.task?.status?.key === 'completed') {
                updateTask(
                  active?.data?.current?.task?._id,
                  'status_update',
                  {
                    mark_as_done: true,
                    mark_as_archived: false,
                    status: active?.data?.current?.task?.status,
                  },
                  oldTasks,
                  oldTasksSections
                );
              } else if (
                active?.data?.current?.task?.status?.key === 'archived'
              ) {
                updateTask(
                  active?.data?.current?.task?._id,
                  'status_update',
                  {
                    mark_as_done: true,
                    mark_as_archived: true,
                    status: active?.data?.current?.task?.status,
                  },
                  oldTasks,
                  oldTasksSections
                );
              } else {
                updateTask(
                  active?.data?.current?.task?._id,
                  'status_update',
                  {
                    mark_as_done: false,
                    mark_as_archived: false,
                    status: active?.data?.current?.task?.status,
                  },
                  oldTasks,
                  oldTasksSections
                );
              }

              const newSectionTotalCount: any =
                totalSectionData &&
                totalSectionData?.map((section: any, index: number) => {
                  if (
                    section?._id !== active?.data?.current?.task?.status?._id
                  ) {
                    if (section?._id === activeTask?.status?._id) {
                      return { ...section, count: section?.count - 1 };
                    }
                    return section;
                  }
                  return { ...section, count: section?.count + 1 };
                });
              setTotalSectionData(newSectionTotalCount);
              setActiveTask(null);
            } else {
              updateTask(
                activeTask?._id,
                'status_update',
                {
                  mark_as_done: activeTask?.mark_as_done,
                  mark_as_archived: activeTask?.mark_as_archived,
                  status: activeTask?.status,
                },
                oldTasks,
                oldTasksSections
              );
              setActiveTask(null);
            }
          } else {
            updateTask(
              activeTask?._id,
              'status_update',
              {
                mark_as_done: activeTask?.mark_as_done,
                mark_as_archived: activeTask?.mark_as_archived,
                status: activeTask?.status,
              },
              oldTasks,
              oldTasksSections
            );
            setActiveTask(null);
          }
        });
      }
    }

    // if any column is drop on completed or archived column than it will return back to origin place

    if (
      over &&
      over.data.current?.type === 'Column' &&
      (over.data.current.column.key === 'completed' ||
        over.data.current.column.key === 'archived')
    ) {
      return;
    }

    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const isActiveAColumn = active.data.current?.type === 'Column';
    const isOverAColumn = over.data.current?.type === 'Column';
    const isOverATask = over.data.current?.type === 'Task';
    if (!isActiveAColumn) return;

    // console.log("DRAG END");

    const activeColumnIndex = columns.findIndex((col) => col._id === activeId);
    const overColumnIndex = columns.findIndex((col) => col._id === overId);

    // console.log("activeColumnIndex....", activeColumnIndex, "overColumnIndex....", overColumnIndex)

    if (isActiveAColumn && isOverAColumn && overColumnIndex === -1) {
      // console.log("We are herreeeeeee 451...")
      return;
    }
    if (isActiveAColumn && isOverAColumn && overColumnIndex !== -1) {
      // console.log("over index is not -1")
      // api logic
      const payload = {
        board_id: boardId,
        section_id: active?.data?.current?.column?._id,
        sort_order: overColumnIndex + 1,
      };

      dispatch(putEditBoardSectionOrder(payload)).then((result: any) => {
        if (putEditBoardSectionOrder.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
          }
        }
      });

      setColumns((columns) => {
        return arrayMove(columns, activeColumnIndex, overColumnIndex);
      });
    }

    if (
      isActiveAColumn &&
      isOverATask &&
      over &&
      (over?.data?.current?.task?.status?.key === 'completed' ||
        over?.data?.current?.task?.status?.key === 'archived')
    ) {
      // console.log("We are herreeeeeee 476...")
      return;
    } else if (
      isActiveAColumn &&
      isOverATask &&
      over &&
      over?.data?.current?.task?.status?.key !== 'completed' &&
      over?.data?.current?.task?.status?.key !== 'archived'
    ) {
      // console.log("We are herreeeeeee 479 elseeee if...")

      // api logic
      const payload = {
        board_id: boardId,
        section_id: active?.data?.current?.column?._id,
        sort_order: over?.data?.current?.task?.status?.sort_order,
      };

      dispatch(putEditBoardSectionOrder(payload)).then((result: any) => {
        if (putEditBoardSectionOrder.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
          }
        }
      });

      setColumns((columns) => {
        return arrayMove(
          columns,
          activeColumnIndex,
          over?.data?.current?.task?.status?.sort_order - 1
        );
      });
    }
  }

  //Fires below function when a draggable item is moved over a droppable container, along with the unique identifier of that droppable container.
  function onDragOver(event: any) {
    const { active, over } = event;
    // console.log("onDragOver active....", active, "onDragOver over....", over)

    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const isActiveAColumn = active.data.current?.type === 'Column';
    const isOverAColumn = over.data.current?.type === 'Column';

    // if any column is drop on completed or archived column than it will return back to origin place
    if (
      isActiveAColumn &&
      isOverAColumn &&
      over.data.current?.type === 'Column' &&
      (over.data.current.column.key === 'completed' ||
        over.data.current.column.key === 'archived')
    ) {
      return;
    }

    const isActiveATask = active.data.current?.type === 'Task';
    const isOverATask = over.data.current?.type === 'Task';

    if (!isActiveATask) return;

    // Dropping a Task over another Task
    if (isActiveATask && isOverATask) {
      // return null if task is not completed and moving into archived
      if (
        activeTask?.status?.key !== 'completed' &&
        over?.data?.current?.task?.status?.key === 'archived'
      ) {
        return;
      } else {
        setTasks((tasks) => {
          const activeIndex = tasks.findIndex((t) => t._id === activeId);
          const overIndex = tasks.findIndex((t) => t._id === overId);

          // console.log("active index...", activeIndex, 'over index....', overIndex);

          // Clone the tasks array
          const newTasks = [...tasks];

          // Check if the status needs to be updated
          if (
            newTasks[activeIndex].status?._id !==
            newTasks[overIndex].status?._id
          ) {
            // Clone the task object to update its status immutably
            newTasks[activeIndex] = {
              ...newTasks[activeIndex],
              status: newTasks[overIndex].status, // Directly assigning the status object
            };

            return arrayMove(newTasks, activeIndex, overIndex - 1);
          }

          return arrayMove(newTasks, activeIndex, overIndex);
        });
      }
    }

    // Enter a logic for task add in column when there is no tasks

    // Im dropping a Task over a column  write a logic to not move not completed task into archived
    if (isActiveATask && isOverAColumn) {
      // console.log("DROPPING TASK OVER COLUMN....", "onDragOver active....", active, "onDragOver over....", over, "Active task...", activeTask);

      if (
        activeTask?.status?.key !== 'completed' &&
        over?.data?.current?.column?.key === 'archived'
      ) {
        return;
      } else {
        setTasks((tasks) => {
          // Find the index of the active task
          const activeIndex = tasks.findIndex((t) => t._id === activeId);

          // Assuming the column ID is the status ID, use the overId as the new status ID
          const newStatusId = overId;

          // console.log("Active index drop over column:", activeIndex);

          // Clone the tasks array
          const newTasks = [...tasks];

          // Check if the status needs to be updated
          if (newTasks[activeIndex].status?._id !== newStatusId) {
            // Clone the task object to update its status immutably
            newTasks[activeIndex] = {
              ...newTasks[activeIndex],
              status: over?.data?.current?.column, // Directly assigning the new status object
            };

            // Find the new index for the task based on the new status
            // Assuming you want to move the task to the beginning of the column
            const newIndex = 0;

            return arrayMove(newTasks, activeIndex, newIndex);
          }

          // If the status is the same, move the task within the same column
          // Adjust the index as necessary
          return newTasks;
        });
      }
    }
  }

  // find section data
  const findSectionStatus = (sections: any[], key: string) => {
    return sections && sections.length > 0
      ? sections.filter((option: any) => option?.key === key)
      : [{}];
  };

  const getAssigneeData = (assign_to: any) => {
    return members
      .filter(
        (member: any) =>
          assign_to?.some(
            (assign: any) => member?.id === (assign?._id || assign)
          )
      )
      ?.map((res: any) => {
        return {
          ...res,
          _id: res?.id,
        };
      });
  };

  const [completedStatusData]: any = findSectionStatus(sections, 'completed');
  const [archivedStatusData]: any = findSectionStatus(sections, 'archived');
  // Kanban Socket - Start

  // When new section add in board
  useEffect(() => {
    socket.on('NEW_SECTION', (res) => {
      console.log('NEW_SECTION', res);
      if (params.id === res.board_id) {
        dispatch(getBoardSectionsById({ board_id: params?.id }));
        dispatch(
          getAllTask({
            search: debouncedValue,
            pagination: false,
            board_id: params?.id,
            filter: taskFilterOptionValue,
            assignee_id: assigneeFilter,
          })
        ).then((result: any) => {
          if (getAllTask.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setTotalSectionData(result?.payload?.data?.task_counts);
            }
          }
        });
      }

      socket.emit('CONFIRMATION', { event: 'NEW_SECTION' });
      return () => {
        socket.off('NEW_SECTION');
      };
    });
  }, [params.id]);

  // When section move in board
  useEffect(() => {
    socket.on('SECTION_MOVED', (res) => {
      console.log('SECTION_MOVED', res);
      socket.emit('CONFIRMATION', { event: 'SECTION_MOVED' });
      if (params.id !== res.board_id) {
        return;
      }
      setColumns((columns) => {
        return arrayMove(columns, res?.old_order - 1, res?.new_order - 1);
      });

      return () => {
        socket.off('SECTION_MOVED');
      };
    });
  }, [params.id]);

  // When section update in board
  useEffect(() => {
    socket.on('SECTION_UPDATE', (res) => {
      console.log('SECTION_UPDATE', res);
      socket.emit('CONFIRMATION', { event: 'SECTION_UPDATE' });

      if (params.id !== res.board_id) {
        return;
      }
      updateColumn(res?.section_id, res?.section_name);

      return () => {
        socket.off('SECTION_UPDATE');
      };
    });
  }, [params.id, columns]);

  // When section delete in board
  useEffect(() => {
    socket.on('SECTION_DELETE', (res) => {
      console.log('SECTION_DELETE', res);
      socket.emit('CONFIRMATION', { event: 'SECTION_DELETE' });

      if (params.id !== res.board_id) {
        return;
      }
      deleteColumn(res?.section_id);
    });

    return () => {
      socket.off('SECTION_DELETE');
    };
  }, [params.id, columns]);

  // When new task add in board
  useEffect(() => {
    socket.on('NEW_TASK', (res) => {
      console.log('NEW_TASK', res);
      socket.emit('CONFIRMATION', { event: 'NEW_TASK' });
      if (params.id !== res.board_id) {
        return;
      }

      let updatedAssigneeObject = getAssigneeData(res?.assign_to);
      console.log(
        res?.assign_to?.includes(signIn?.user?.data?.user?._id),
        'data'
      );
      if (res?.assign_to?.includes(signIn?.user?.data?.user?._id)) {
        console.log(!!res?.parent_task, 'data res?.parent_task');
        if (res?.parent_task) {
          console.log(oldTasksSections, oldTasks, 'okbro');
          updateTask(
            res?.parent_task?._id,
            'subtask_count',
            {},
            oldTasks,
            oldTasksSections
          );
        } else {
          createTask({ ...res, assign_to: updatedAssigneeObject });
        }
      }
      // if(paginationParams?.filter === '' || paginationParams?.filter === 'in_completed') { createTask({...res, assign_to: updatedAssigneeObject}) };
      // if(paginationParams?.filter === 'my_task' && res.assign_to?.includes(signIn?.user?.data?.user?._id)) { createTask({...res, assign_to: updatedAssigneeObject}) };
    });

    return () => {
      socket.off('NEW_TASK');
    };
  }, [
    params.id,
    tasks,
    paginationParams,
    oldTasks,
    oldTasksSections,
    members,
    signIn?.user?.data?.user?._id,
  ]);

  // When update status update to mark as done or task move
  useEffect(() => {
    socket.on('TASK_STATUS_UPDATE', (res) => {
      console.log('TASK_STATUS_UPDATE', res);
      socket.emit('CONFIRMATION', { event: 'TASK_STATUS_UPDATE' });

      if (params.id !== res.board_id) {
        return;
      }

      const { new_section, old_section } = res;

      if (new_section?.key === 'completed') {
        updateTaskSocket(
          res?.task_id,
          'status_update',
          {
            mark_as_done: true,
            mark_as_archived: false,
            new_section,
            old_section,
          },
          oldTasks,
          oldTasksSections
        );
      } else if (new_section?.key === 'archived') {
        updateTaskSocket(
          res?.task_id,
          'status_update',
          {
            mark_as_done: true,
            mark_as_archived: true,
            new_section,
            old_section,
          },
          oldTasks,
          oldTasksSections
        );
      } else {
        updateTaskSocket(
          res?.task_id,
          'status_update',
          {
            mark_as_done: false,
            mark_as_archived: false,
            new_section,
            old_section,
          },
          oldTasks,
          oldTasksSections
        );
      }
    });

    return () => {
      socket.off('TASK_STATUS_UPDATE');
    };
  }, [
    params.id,
    oldTasks,
    oldTasksSections,
    completedStatusData,
    archivedStatusData,
  ]);

  // called when task was deleted
  useEffect(() => {
    socket.on('TASK_DELETED', (res) => {
      console.log('TASK_DELETED', res);
      socket.emit('CONFIRMATION', { event: 'TASK_DELETED' });

      if (params.id !== res.board_id) {
        return;
      }

      if (res?.parent_task !== null) {
        updateTask(
          res?.parent_task,
          'decrease_subtask_count',
          {},
          oldTasks,
          oldTasksSections
        );
      } else {
        updateTask(
          res?.task_ids[0],
          'delete_task',
          { section_id: res?.section_id },
          oldTasks,
          oldTasksSections
        );
      }
    });

    return () => {
      socket.off('TASK_DELETED');
    };
  }, [params.id, tasks, oldTasks, oldTasksSections]);

  // called when assignee update or due date update
  useEffect(() => {
    socket.on('ASSIGNEE_UPDATE', (res) => {
      console.log('ASSIGNEE_UPDATE', res);
      socket.emit('CONFIRMATION', { event: 'ASSIGNEE_UPDATE' });

      if (params.id !== res.board_id) {
        return;
      }

      const memberList = res.assignee_details?.map((assign: any) => {
        return {
          ...assign,
          id: assign?._id,
          member_name:
            capitalizeFirstLetter(assign?.first_name) +
            ' ' +
            capitalizeFirstLetter(assign?.last_name),
        };
      });
      updateTaskSocket(
        res?.task_id,
        'date_assignee_update',
        {
          memberList,
          due_date: res?.due_date,
          updated_task: res?.updated_task,
        },
        oldTasks,
        oldTasksSections
      );
    });

    return () => {
      socket.off('ASSIGNEE_UPDATE');
    };
  }, [params.id, oldTasks, oldTasksSections]);

  // called when Board member remove from board => removed board member remove from task automatically.
  useEffect(() => {
    socket.on('BOARD_MEMBER_UPDATE_SELF', (res) => {
      console.log('BOARD_MEMBER_UPDATE_SELF', res);
      socket.emit('CONFIRMATION', { event: 'BOARD_MEMBER_UPDATE_SELF' });

      if (!res?.member_id) {
        return;
      }
      const updatedTaskData =
        oldTasks &&
        oldTasks?.length > 0 &&
        oldTasks?.map((task: any) => {
          return {
            ...task,
            assign_to:
              task?.assign_to?.length > 0
                ? task?.assign_to?.filter(
                    (user: any) => user?._id !== res?.member_id
                  )
                : [],
          };
        });
      setTasks(updatedTaskData);
    });

    return () => {
      socket.off('BOARD_MEMBER_UPDATE_SELF');
    };
  }, [params.id, oldTasks, oldTasksSections]);

  // called when task update
  useEffect(() => {
    socket.on('TASK_UPDATE', (res) => {
      console.log('TASK_UPDATE', res);
      socket.emit('CONFIRMATION', { event: 'TASK_UPDATE' });

      if (
        params.id !== res?.updated_task?.board_id ||
        res?.updated_task?.parent_task
      ) {
        return;
      }

      const updatedAssigneeObject = getAssigneeData(res?.updated_task?.assign_to);

      if (params.id !== res?.updated_task?.board_id) {
        return;
      }

      console.log(res, 'res12345');
      updateTaskSocket(
        res?.updated_task?._id,
        'task_update',
        {
          old_section: res?.old_section,
          updated_task: {
            ...res?.updated_task,
            assign_to: updatedAssigneeObject,
            attachment_count: res?.updated_task?.attachments?.length,
            comments_count: res?.updated_task?.comments?.length,
            sub_task_count: res?.updated_task?.sub_task?.length,
          },
        },
        oldTasks,
        oldTasksSections
      );
    });

    return () => {
      socket.off('TASK_UPDATE');
    };
  }, [params.id, oldTasks, oldTasksSections, members]);

  // called when user leave the task
  useEffect(() => {
    socket.on('TASK_LEAVE', (res) => {
      console.log('TASK_LEAVE', res);
      socket.emit('CONFIRMATION', { event: 'TASK_LEAVE' });

      if (params.id !== res.board_id) {
        return;
      }
      updateTask(
        res?.task_id,
        'leave_member',
        { section_id: res?.section_id, user_id: res?.user_id },
        oldTasks,
        oldTasksSections
      );
    });

    return () => {
      socket.off('TASK_LEAVE');
    };
  }, [params.id, oldTasks, oldTasksSections]);

  // called when new comment add in task
  useEffect(() => {
    socket.on('TASK_COMMENT', (res) => {
      console.log('TASK_COMMENT', res);
      socket.emit('CONFIRMATION', { event: 'TASK_COMMENT' });

      if (params.id !== res.board_id) {
        return;
      }
      updateTaskSocket(
        res?._id,
        'comment_update',
        res,
        oldTasks,
        oldTasksSections
      );
    });

    return () => {
      socket.off('TASK_COMMENT');
    };
  }, [params.id, oldTasks, oldTasksSections]);

  // called when bulk task is update kanban socket event
  useEffect(() => {
    socket.on('BULK_TASK_UPDATE', (res) => {
      console.log(res, 'BULK_TASK_UPDATE');
      socket.emit('CONFIRMATION', { event: 'BULK_TASK_UPDATE' });

      if (params.id !== res?.updated_task?.board_id) {
        return;
      }

      const updatedAssigneeObject = getAssigneeData(
        res?.updated_task?.assign_to
      );

      updateTaskSocket(
        res?.updated_task?._id,
        'task_update',
        {
          old_section: res?.old_section,
          updated_task: {
            ...res?.updated_task,
            assign_to: updatedAssigneeObject,
            attachment_count: res?.updated_task?.attachments?.length,
            comments_count: res?.updated_task?.comments?.length,
            sub_task_count: res?.updated_task?.sub_task?.length,
          },
        },
        oldTasks,
        oldTasksSections
      );
    });

    return () => {
      socket.off('BULK_TASK_UPDATE');
    };
  }, [params?.id, oldTasks, oldTasksSections]);

  // called when bulk task is deleted
  useEffect(() => {
    socket.on('BULK_TASK_DELETED', (res) => {
      socket.emit('CONFIRMATION', { event: 'BULK_TASK_DELETED' });
      updateTask(
        res?.task_ids[0],
        'delete_task',
        { section_id: res?.section_id },
        oldTasks,
        oldTasksSections
      );
    });

    return () => {
      socket.off('BULK_TASK_DELETED');
    };
  }, [params?.id, oldTasks, oldTasksSections]);

  // Kanaban Socket End

  return (
    <div className="grid_task kanaban_wrapper no-scroll">
      {/* The Tour component */}
      {gridView && (
        <Tour
          steps={kanbanTaskTourSteps ?? []}
          isOpen={isTourOpen}
          rounded={10}
          closeWithMask={false}
          disableInteraction={true}
          disableKeyboardNavigation={['esc']}
          onRequestClose={handleCloseTour}
          className="poppins_font_number tour-close-button font-semibold text-black"
          scrollDuration={50}
          scrollOffset={5}
        />
      )}
      {/* <div className="@container border rounded-md border-t-transparent shadow-sm mt-4"> */}
      <SimpleBar className="min-h-[calc(100dvh-258px)]">
        {/* dnd context for provide drag and drop */}
        <DndContext
          sensors={sensors}
          onDragStart={onDragStart}
          onDragEnd={onDragEnd}
          onDragOver={onDragOver}
        >
          {/* provide sortable context for sorting columns by columnId and if  */}
          <div className="">
            <div className="task_table_height flex gap-6 ">
              <SortableContext items={columnsId}>
                {columns &&
                  columns?.length > 0 &&
                  columns?.map((col) => (
                    <ColumnContainer
                      key={col?._id}
                      deleteColumn={deleteColumn}
                      updateColumn={updateColumn}
                      createTask={createTask}
                      updateTask={updateTask}
                      updateGetAllTasks={updateGetAllTasks}
                      activeTask={activeTask}
                      taskFilterOptionValue={taskFilterOptionValue}
                      assigneeFilter={assigneeFilter}
                      totalSectionData={totalSectionData}
                      setTotalSectionData={setTotalSectionData}
                      getAllTaskLoader={getAllTaskLoader}
                      setGetAllTaskLoader={setGetAllTaskLoader}
                      column={col}
                      tasks={tasks?.filter(
                        (task) => task?.status?._id === col?._id
                      )}
                    />
                  ))}
              </SortableContext>
            </div>
          </div>

          {/* The drag overlay is not rendered in a portal by default. Rather, it is rendered in the container where it is rendered. 
            If you would like to render the <DragOverlay> in a different container than where it is rendered, import the createPortal helper from react-dom: */}

          {createPortal(
            <DragOverlay>
              {activeColumn && (
                <ColumnContainer
                  deleteColumn={deleteColumn}
                  updateColumn={updateColumn}
                  createTask={createTask}
                  updateTask={updateTask}
                  updateGetAllTasks={updateGetAllTasks}
                  activeTask={activeTask}
                  taskFilterOptionValue={taskFilterOptionValue}
                  assigneeFilter={assigneeFilter}
                  totalSectionData={totalSectionData}
                  setTotalSectionData={setTotalSectionData}
                  getAllTaskLoader={getAllTaskLoader}
                  setGetAllTaskLoader={setGetAllTaskLoader}
                  column={activeColumn}
                  tasks={tasks?.filter(
                    (task) => task?.status?._id === activeColumn?._id
                  )}
                />
              )}
              {activeTask && (
                <TaskCard
                  updateTask={updateTask}
                  task={activeTask}
                  createTask={createTask}
                />
              )}
            </DragOverlay>,
            document.body
          )}
        </DndContext>
      </SimpleBar>
      {/* </div> */}
    </div>
  );
}

export default KanbanBoard;
