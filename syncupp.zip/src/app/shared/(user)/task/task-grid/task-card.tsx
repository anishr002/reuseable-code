import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import { DatePicker } from '@/components/ui/datepicker';
import { Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import '@/layouts/helium/style.css';
import {
  duplicateAddTask,
  patchEditTask,
} from '@/redux/slices/user/task/taskSlice';
import { putTaskKanbanStatusChange } from '@/redux/slices/user/task/taskStatusSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import { useSortable } from '@dnd-kit/sortable';
import subTaskIcon from '@public/assets/svgs/subtask-icon.svg';
import moment from 'moment';
import Image from 'next/image';
import { useCallback, useEffect, useRef, useState } from 'react';
import { SubmitHandler } from 'react-hook-form';
import { FiStopCircle } from 'react-icons/fi';
import { LuTag, LuUserPlus } from 'react-icons/lu';
import { PiCalendarBlankLight } from 'react-icons/pi';
import { SlOptions } from 'react-icons/sl';
import { useDispatch, useSelector } from 'react-redux';
import { Avatar, Input, Popover } from 'rizzui';
import { checkPermission } from '../../roles-permissions/utils';
import TimerDisplay from '../taskTimer';
import Addtag from './addtag';
import EditTaskForm from './edit-task-form';
import TaskReminder from './task-reminder-model';
import TimerForm from './timer-form';
import ViewTaskFormSideBar from './view-task-form';
import Spinner from '@/components/ui/spinner';

interface Status {
  _id: string;
}

interface Assignee {
  _id: string;
}

interface DuplicateTaskSchema {
  _id: string;
  title: string;
  agenda?: string;
  priority: string;
  board_id: string;
  duplicated_from: string;
  status: Status;
  due_date?: string | null;
  assign_to?: Assignee[];
  attachments?: [];
  custom_fields?: any;
  parent_task?: any;
  tags?: any;
  recurrence_pattern?: any;
  recurrence_end_date?: any;
  recurrence_interval?: any;
  weekly_recurrence_days?: any;
  monthly_recurrence_day_of_month?: any;
}

function getPriorityStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'low':
      return (
        <div className="flex items-center justify-center rounded-2xl bg-[#E4F6D6] px-2 py-1">
          <Text className="font-medium text-green-dark">Low</Text>
        </div>
      );
    case 'medium':
      return (
        <div className="flex items-center justify-center rounded-2xl bg-[#FBF0DE] px-2 py-1">
          <Text className="font-medium text-orange-dark">Medium</Text>
        </div>
      );
    case 'high':
      return (
        <div className="flex items-center justify-center rounded-2xl bg-[#FFD4C6] px-2 py-1">
          <Text className="font-medium text-red-dark">High</Text>
        </div>
      );

    default:
      return (
        <div className="flex items-center justify-center rounded-2xl bg-gray-300 px-2 py-1">
          <Text className="font-medium text-gray-600">{status}</Text>
        </div>
      );
  }
}
interface Props {
  task: any;
  updateTask: (
    id: any,
    action: any,
    data: any,
    oldTasks: any,
    oldTasksSectionsData: any
  ) => void;
  createTask: any;
}

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E4F6D6]',
    label: (
      <div className="flex items-center  rounded-3xl bg-[#E4F6D6] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="success" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-green-dark">
          Low
        </Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FBF0DE]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FBF0DE] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="warning" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-orange-dark">
          Medium
        </Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFD4C6]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FFD4C6] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="danger" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-red-dark">
          High
        </Text>
      </div>
    ),
  },
];

function TaskCard({ task, updateTask, createTask }: Props) {
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const { openDrawer, closeDrawer } = useDrawer();
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [duplicateMembers, setDuplicateMembers] = useState([]);

  const [subTaskStatus, setSubTaskStatus] = useState(task?.priority);
  const [selectedtags, setSelectedTags] = useState<any>([]);
  const [subTaskTags, setSubTaskTags] = useState<any>([]);
  const [selectedDueDate, setSelectedDueDate] = useState<any>(null);
  const [showSaveButton, setShowSaveButton] = useState<any>(false); // New state for Save button
  const [isOpenPopOver, setIsOpenPopOver] = useState(false); // New state for Save button

  useEffect(() => {
    setSelectedDueDate(null);
    setShowSaveButton(false);
  }, [isOpenPopOver]);

  const { activeTimerData } = useSelector(
    (state: any) => state?.root?.timeTracking
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { boardId, sections, assignees } = useSelector(
    (state: any) => state?.root?.board
  );
  const {
    oldTasks,
    oldTasksSections,
    duplicateTaskLoading,
    loading: taskLoading,
  } = useSelector((state: any) => state?.root?.task);
  const { loading } = useSelector((state: any) => state?.root?.taskStatus);
  const { settingData } = useSelector((state: any) => state?.root?.setting);
  const dragCardRef = useRef<HTMLDivElement>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(task?.title || '');
  const [error, setError] = useState(''); // State for error message

  const inputRef = useRef<HTMLInputElement>(null);

  const handleDoubleClick = (e: React.MouseEvent) => {
    handleClick(false, e); // Pass event to handleClick
    setIsEditing(true);
    setTimeout(() => inputRef.current?.focus(), 0); // Auto-focus input
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = event.target.value.trimStart(); // Prevent leading spaces

    if (newTitle === '') {
      setError('Title cannot be empty.');
    } else if (newTitle.length > 150) {
      setError('Title cannot exceed 150 characters.');
    } else {
      setError(''); // Clear error if valid
    }

    setTitle(newTitle);
  };

  const saveTitle = () => {
    if (error) return; // Prevent saving if there is an error

    if (title.trim()) {
      const formData: any = new FormData();
      formData.append('_id', task?._id);
      formData.append('title', title);
      formData.append('action_name', 'date_assignee_update');

      dispatch(patchEditTask(formData)).then((result: any) => {
        if (patchEditTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            updateTask(
              task?._id,
              'title_update',
              title,
              oldTasks,
              oldTasksSections
            );
            setIsEditing(false);
          }
        }
      });
      // updateTask(task?._id, 'title', title, oldTasks, oldTasksSections);
    }
  };
  const cancelEditing = () => {
    setTitle(task?.title || ''); // Restore original title
    setError(''); // Clear error
    setIsEditing(false);
  };
  // find completed section status
  const [completedStatusData]: any = (sections &&
    sections?.length > 0 &&
    sections?.filter((option: any) => {
      if (option?.key === 'completed') {
        return option;
      }
    })) || [{}];

  useEffect(() => {
    const assignToMembers =
      (task?.assign_to &&
        task?.assign_to?.length > 0 &&
        task?.assign_to?.map((member: any) => {
          return member?._id;
        })) ||
      [];
    setDuplicateMembers(assignToMembers);
  }, [task]);

  // find archieved section status
  const [archivedStatusData]: any = (sections &&
    sections?.length > 0 &&
    sections?.filter((option: any) => {
      if (option?.key === 'archived') {
        return option;
      }
    })) || [{}];

  // check date and give style according is today tomorrow or etc.

  function checkDate(date: Date, isCompleted: any) {
    const inputDate = moment(date);
    const now = moment();

    // const inputDay = inputDate?.startOf('day');
    // const today = moment()?.startOf('day');
    // const yesterday = moment()?.subtract(1, 'days').startOf('day');
    // const tomorrow = moment()?.add(1, 'days').startOf('day');

    // if (inputDay?.isSame(today, 'day')) {
    //   return (
    //     <p className="poppins_font_number rounded-2xl bg-[#FFD4C6] px-1 py-1 text-[13px] font-medium text-[#C92F54] ">
    //       {`Today ${moment(date)?.format('hh:mm A')}`}
    //     </p>
    //   );
    // } else if (inputDay?.isSame(yesterday, 'day')) {
    //   return (
    //     <p className="poppins_font_number rounded-2xl bg-[#FFD4C6] px-1 py-1 text-[13px] font-medium text-[#AC2D2D]">
    //       {`Yesterday ${moment(date)?.format('hh:mm A')}`}
    //     </p>
    //   );
    // } else if (inputDay?.isSame(tomorrow, 'day')) {
    //   return (
    //     <p className="poppins_font_number text-[13px] font-medium text-[#111928]">
    //       {`Tomorrow ${moment(date)?.format('hh:mm A')}`}
    //     </p>
    //   );
    // } else if (inputDay?.isBefore(today, 'day')) {
    //   return (
    //     <p className="poppins_font_number rounded-2xl bg-[#FFD4C6] px-1 py-1 text-[13px] font-medium text-[#C92F54]">
    //       {moment(date)?.format('DD MMM YYYY hh:mm A')}
    //     </p>
    //   );
    // } else {
    //   return (
    //     <p className="poppins_font_number text-[13px] font-medium text-[#111928]">
    //       {moment(date)?.format('DD MMM YYYY hh:mm A')}
    //     </p>
    //   );
    // }

    if (!isCompleted && inputDate.isBefore(now)) {
      return (
        <p
          className={cn(
            'rounded-2xl bg-[#FFD4C6] px-2 py-1 text-xs font-medium text-[#AC2D2D]'
          )}
        >
          {moment(date)?.format('MMM D, YYYY h:mm A')}
        </p>
      );
    } else {
      return (
        <p className={cn('text-xs font-medium text-[#111928]')}>
          {moment(date)?.format('MMM D, YYYY h:mm A')}
        </p>
      );
    }
  }

  useEffect(() => {
    setSelectedTags([]);
    setSelectedMembers([]);
    setTitle(task?.title || ''); // Update title when task.title changes

    if (task?.tags?.length > 0) {
      setSelectedTags(task?.tags.map((tag: any) => tag.tag_name)); // ✅ Store only tag_name values
    }
    if (task?.assign_to && task?.assign_to?.length > 0) {
      const memberIds = task?.assign_to?.map((member: any) => member._id) || [];
      setSelectedMembers(memberIds);
    }
  }, [task]);

  const handleAddTag = (isTask: Boolean) => {
    openModal({
      view: (
        <div>
          <Addtag
            onClose={closeModal}
            isAPICall={true}
            selectedtags={selectedtags}
            setSelectedTags={setSelectedTags}
            task={task}
            updateTask={updateTask}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  const customizedDueDate =
    task?.due_date &&
    checkDate(moment(task?.due_date)?.toDate(), task?.mark_as_done);

  const handleClick = useCallback(
    (cardClick: boolean, event: React.MouseEvent) => {
      // console.log("cardClick....", cardClick, "event.....", event);
      event.stopPropagation(); // Prevent the event from bubbling up

      if (cardClick) {
        openDrawer({
          view: (
            <ViewTaskFormSideBar
              rowData={task}
              editMode={true}
              onClose={closeDrawer}
              isView={true}
              createTask={createTask}
              updateTask={updateTask}
              isInboxTaskView={false}
            />
          ),
          placement: 'right',
          customSize: '640px',
        });
      } else if (!cardClick) {
        if (task?.mark_as_archived || signIn?.role === 'team_client') {
          openModal({
            view: (
              <EditTaskForm
                rowData={task}
                editMode={true}
                updateTask={updateTask}
                createTask={createTask}
                onClose={closeModal}
              />
            ),
            customSize: '800px',
          });
        } else {
          return;
        }
      }
    },
    []
  );
  // useSortable hook combines both the useDraggable and useDroppable hooks to connect elements as both draggable sources and drop targets:

  const {
    setNodeRef,
    attributes,
    listeners,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: task?._id,
    data: {
      type: 'Task',
      task,
    },
    disabled:
      ['agency'].includes(signIn?.role) ||
      task?.assign_to?.some(
        (user: any) => user?._id === signIn?.user?.data?.user?._id
      ) ||
      (['team_agency'].includes(signIn?.role) &&
        checkPermission('projects', 'tasks', 'update', signIn?.permission))
        ? false
        : true,
  });

  const style = {
    transition,
    // transform: CSS.Transform.toString(transform),
  };

  if (isDragging) {
    return (
      <div
        ref={setNodeRef}
        style={style}
        className="relative flex h-[180px] min-h-[100px] w-full cursor-grab items-center rounded-3xl border-2 border-gray-400 p-3 text-left"
      />
    );
  }

  const handleAddMemberClick = () => {
    openModal({
      view: (
        <div>
          <AddMembers
            onClose={closeModal}
            selectedMembers={selectedMembers}
            setSelectedMembers={setSelectedMembers}
            formPage={false}
            addTaskMember={true}
            updateTask={updateTask}
            taskId={task?._id}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  const handleTimerClick = (task: any) => {
    openModal({
      view: (
        <div>
          <TimerForm
            onClose={closeModal}
            task_id={task?._id}
            section={task?.status}
            boardId={boardId}
            taskName={task?.title}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  const handleTaskStatusChangeClick = () => {
    if (
      task?.mark_as_archived ||
      (['team_agency', 'team_client'].includes(signIn?.role) &&
        !checkPermission('projects', 'tasks', 'update', signIn?.permission))
    ) {
      return;
    } else {
      dispatch(
        putTaskKanbanStatusChange({
          _id: task?._id,
          status: !task?.mark_as_done
            ? completedStatusData?._id
            : archivedStatusData?._id,
        })
      ).then((result: any) => {
        if (putTaskKanbanStatusChange.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            // update task function call
            // updateTask(task?._id, "status_update", !task?.mark_as_done ? { mark_as_done: true, mark_as_archived: false, status: completedStatusData } : { mark_as_done: true, mark_as_archived: true, status: archivedStatusData })
            updateTask(
              task?._id,
              'complete_status_update',
              !task?.mark_as_done
                ? {
                    mark_as_done: true,
                    mark_as_archived: false,
                    before_status: task?.status,
                    after_status: completedStatusData,
                  }
                : {
                    mark_as_done: true,
                    mark_as_archived: true,
                    before_status: task?.status,
                    after_status: archivedStatusData,
                  },
              oldTasks,
              oldTasksSections
            );
          }
        }
      });
    }
  };

  const displayName = (data: any) => {
    let displayName: string =
      data?.first_name?.charAt(0)?.toUpperCase() +
      data?.first_name?.slice(1) +
      ' ' +
      data?.last_name?.charAt(0)?.toUpperCase() +
      data?.last_name?.slice(1);
    return displayName;
  };

  const checkAssigneExist = (assign_id: string) => {
    const index = task?.assign_to?.findIndex(
      (user: any) => user?._id === assign_id
    );
    return index !== -1 ? true : false;
  };

  // // api call for get clients and team member
  // useEffect(() => {
  //   dispatch(getAllAssignees());
  //   // dispatch(getBoardSectionsById({ board_id: board?._id }));
  //   boardId && dispatch(getMembersByBoardId({ boardId: boardId }));
  // }, []);

  const clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          const team_name =
            capitalizeFirstLetter(team?.first_name) +
            ' ' +
            capitalizeFirstLetter(team?.last_name);
          return { ...team, name: team_name };
        })
      : [];

  const onDuplicateTask: SubmitHandler<DuplicateTaskSchema> = (data) => {
    const formData = new FormData();

    // Append fields to the FormData object
    formData.append('title', data.title);
    if (data?.agenda) {
      formData.append('agenda', data.agenda);
    } else {
      formData.append('agenda', '');
    }
    formData.append('priority', data.priority);
    formData.append('board_id', data.board_id);
    formData.append('status', data.status._id);
    formData.append('duplicated_from', data._id);

    // if (data?.recurrence_pattern && data?.recurrence_pattern !== '') {
    //   formData.append('recurrence_pattern', data?.recurrence_pattern);
    //   formData.append(
    //     'recurrence_end_date',
    //     moment(data?.recurrence_end_date).format('DD-MM-YYYY')
    //   );
    //   formData.append('recurrence_interval', data?.recurrence_interval);

    //   if (data?.recurrence_pattern === 'weekly') {
    //     formData.append('weekly_recurrence_days', data?.weekly_recurrence_days);
    //   }

    //   if (data?.recurrence_pattern === 'monthly') {
    //     formData.append(
    //       'monthly_recurrence_day_of_month',
    //       data?.monthly_recurrence_day_of_month
    //     );
    //   }
    // }
    if (data?.custom_fields) {
      formData.append('custom_fields', JSON.stringify(data?.custom_fields));
    }
    if (data?.parent_task?._id) {
      formData.append('parent_task', data?.parent_task?._id);
    }

    if (data?.tags && data?.tags?.length > 0) {
      data?.tags?.forEach((tag: any) => {
        formData.append('tags', tag?.tag_name);
      });
    }

    // Convert due_date to string format
    if (data.due_date) {
      const dueDate = new Date(data.due_date);
      formData.append('due_date', dueDate.toString());
    } else {
      formData.append('due_date', 'null'); // Send 'null' as a string
    }

    // Extract only the user IDs for assign_to and convert to JSON string
    if (data.assign_to && data.assign_to?.length > 0) {
      const assignToIds = data.assign_to.map((assignee) => assignee._id);
      formData.append('assign_to', JSON.stringify(assignToIds));
    }

    if (data?.attachments && data?.attachments?.length > 0) {
      formData.append('attachments', JSON.stringify(data?.attachments));
    }

    let updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              duplicateMembers &&
              duplicateMembers.length > 0 &&
              duplicateMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];
    console.log(updatedAssigneeObject, 'updatedAssigneeObject1234');
    dispatch(duplicateAddTask(formData)).then((result: any) => {
      if (duplicateAddTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          closeDrawer();
          createTask({
            ...result?.payload?.data,
            assign_to: updatedAssigneeObject,
            attachment_count: result?.payload?.data?.attachments?.length,
            comments_count: result?.payload?.data?.comment,
          });
        }
      }
    });
  };

  return (
    // providing node reference for each task
    <div ref={dragCardRef}>
      <div
        ref={setNodeRef}
        style={style}
        {...attributes}
        {...listeners}
        className={cn(
          'view-kanban-task-tour-step-one task no-scroll relative flex w-full items-center rounded-3xl border-[1px] border-[#D1D5DB] bg-white p-4 text-left transition-all duration-300 ease-in-out hover:z-50 hover:-translate-y-1 hover:shadow-lg cursor-grab',
        )}
        onClick={(e) => handleClick(true, e)}
      >
        {/* <SimpleBar className="max-h-[160px] w-full overflow-y-hidden"> */}
        <div className="no-scroll flex w-full flex-col justify-between gap-4 overflow-y-hidden">
          <div className="flex items-center justify-between gap-4">
            {isEditing ? (
              <div>
                <Input
                  type="text"
                  ref={inputRef}
                  value={title}
                  onChange={handleChange}
                  onKeyDown={(event) => {
                    handleKeyDown(event); // Call the common function

                    // Apply saveTitle() and cancelEditing() only for this input
                    if (event.key === 'Enter') {
                      event.preventDefault();
                      saveTitle();
                    } else if (event.key === 'Escape') {
                      cancelEditing();
                    }
                  }}
                  onBlur={cancelEditing}
                  // maxLength={50}
                  placeholder="Edit task title"
                  className="placeholder_color w-full [&>label>span]:font-medium"
                  disabled={taskLoading}
                />
                {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
              </div>
            ) : (
              <button
                className="poppins_font_number cursor-pointer truncate text-sm font-semibold text-[#120425]"
                onClick={handleDoubleClick}
                type="button"
                disabled={
                  task?.mark_as_done ||
                  signIn?.role === 'client' ||
                  (['team_agency', 'team_client'].includes(signIn?.role)
                    ? !checkPermission(
                        'projects',
                        'tasks',
                        'update',
                        signIn?.permission
                      )
                    : false)
                }
              >
                {task?.title
                  ? task?.title.charAt(0).toUpperCase() + task?.title.slice(1)
                  : ''}
              </button>
            )}

            <Popover
              placement="top-start"
              className="flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
              content={({ setOpen }) => {
                const isTaskCreateAllowed =
                  ['team_agency', 'team_client'].includes(signIn?.role) &&
                  checkPermission(
                    'projects',
                    'tasks',
                    'create',
                    signIn?.permission
                  );

                const isTaskUpdateAllowed =
                  ['team_agency', 'team_client'].includes(signIn?.role) &&
                  checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  );

                return (
                  <>
                    {/* View Task */}
                    <Button
                      variant="text"
                      className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      onClick={(e) => {
                        handleClick(true, e);
                        setOpen(false);
                      }}
                    >
                      View Task
                    </Button>

                    {/* Edit Task */}
                    {(['agency'].includes(signIn?.role) ||
                      isTaskUpdateAllowed) &&
                      !task?.mark_as_done && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={(e) => {
                            handleClick(false, e);
                            openModal({
                              view: (
                                <EditTaskForm
                                  rowData={task}
                                  editMode={true}
                                  onClose={closeModal}
                                  updateTask={updateTask}
                                  createTask={createTask}
                                />
                              ),
                              customSize: '800px',
                            });
                            setOpen(false);
                          }}
                        >
                          Edit Task
                        </Button>
                      )}
                    {/* Reminder due date Task */}
                    {!task?.mark_as_done &&
                      task?.due_date &&
                      new Date(task?.due_date).getTime() >
                        new Date().getTime() &&
                      (['agency'].includes(signIn?.role) ||
                        isTaskCreateAllowed ||
                        isTaskUpdateAllowed) && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={(e) => {
                            if (!taskLoading) {
                              handleClick(false, e);
                              openModal({
                                view: (
                                  <TaskReminder
                                    onClose={closeModal}
                                    rowData={task}
                                    isGridTaskView={true}
                                    updateTask={updateTask}
                                    // AssigneeMembers={task?.assign_to}
                                    AssigneeMembers={
                                      task?.assign_to?.map(
                                        (assignee: Record<string, any>) =>
                                          assignee?._id
                                      ) || []
                                    }
                                  />
                                ),
                                customSize: '490px',
                              });
                            }
                          }}
                          disabled={taskLoading}
                        >
                          Reminder due date Task
                        </Button>
                      )}

                    {/* Duplicate Task */}
                    {!task?.mark_as_done &&
                      (['agency'].includes(signIn?.role) ||
                        isTaskCreateAllowed) && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={(e) => {
                            if (!duplicateTaskLoading) {
                              handleClick(false, e);
                              onDuplicateTask(task);
                              setOpen(false);
                            }
                          }}
                          disabled={duplicateTaskLoading}
                        >
                          Duplicate Task
                        </Button>
                      )}

                    {/* Start Time Tracking */}
                    {settingData?.task?.time_tracking?.length > 0 &&
                      checkAssigneExist(signIn?.user?.data?.user?._id) &&
                      task?.status?.key !== 'archived' &&
                      task?.status?.key !== 'completed' && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={(e) => {
                            handleClick(false, e);
                            handleTimerClick(task);
                            setOpen(false);
                          }}
                        >
                          Start time tracking
                        </Button>
                      )}

                    {/* Mark as completed or Archived */}
                    {(['agency'].includes(signIn?.role) ||
                      isTaskUpdateAllowed) &&
                      !task?.mark_as_archived && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={(e) => {
                            handleClick(false, e);
                            handleTaskStatusChangeClick();
                            setOpen(false);
                          }}
                          disabled={loading}
                        >
                          {task?.mark_as_done
                            ? 'Mark Task as archive'
                            : 'Mark Task as completed'}
                        </Button>
                      )}
                  </>
                );
              }}
            >
              <ActionIcon
                title="More Options"
                variant="text"
                onClick={(e) => e.stopPropagation()}
              >
                <SlOptions className="cursor-pointer text-[#4B5563]" />
              </ActionIcon>
            </Popover>
          </div>
          <div className="flex justify-between gap-1">
            <div className="flex items-center gap-1">
              {task?.assign_to && task?.assign_to?.length > 0 ? (
                <button
                  onClick={(e) => {
                    handleClick(false, e);
                    handleAddMemberClick();
                  }}
                  className="flex cursor-pointer items-center gap-1"
                  type="button"
                  disabled={
                    task?.mark_as_done ||
                    signIn?.role === 'client' ||
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? !checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : false)
                  }
                >
                  <div className="ms-[10px] flex">
                    {task?.assign_to
                      ?.slice(0, 3)
                      ?.map((item: any, index: number) => (
                        <figure
                          key={item?._id}
                          className="relative z-10 -ml-[10px] h-7 w-7 rounded-full"
                        >
                          <Avatar
                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                            name={displayName(item)}
                            className="!h-7 !w-7 bg-[#70C5E0] font-medium text-white"
                          />
                        </figure>
                      ))}
                  </div>
                  {task?.assign_to?.length > 3 && (
                    <div className="poppins_font_number flex h-7 w-7 items-center justify-center gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]">
                      +{task?.assign_to?.length - 3}
                    </div>
                  )}
                </button>
              ) : (
                <div onClick={(e) => handleClick(false, e)}>
                  <Button
                    variant="text"
                    className="flex h-[28px] w-[28px] items-center justify-center rounded-full border-[0.75px] border-dashed border-[#6875F5] p-1"
                    disabled={
                      task?.mark_as_done ||
                      signIn?.role === 'client' ||
                      (['team_agency', 'team_client'].includes(signIn?.role)
                        ? !checkPermission(
                            'projects',
                            'tasks',
                            'update',
                            signIn?.permission
                          )
                        : false)
                    }
                    onClick={() => {
                      handleAddMemberClick();
                    }}
                  >
                    <LuUserPlus className="h-[14px] w-[14px] text-[#6875F5]" />
                  </Button>
                </div>
              )}
            </div>
            <div className="flex cursor-pointer items-center gap-1">
              {task?.tags?.length > 0 ? (
                <button
                  type="button"
                  className="flex items-center gap-1"
                  onClick={(e) => {
                    handleClick(false, e);
                    handleAddTag(true);
                  }}
                  disabled={
                    task?.mark_as_done ||
                    signIn?.role === 'client' ||
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? !checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : false)
                  }
                >
                  {task?.tags?.slice(0, 1)?.map((tag: any, index: number) => (
                    <div
                      key={index}
                      className="max-w-[100px] overflow-hidden truncate whitespace-nowrap rounded bg-[#E5E7EB] p-1 text-[14px] font-medium text-[#4B5563]"
                    >
                      <span>{tag?.tag_name}</span>
                    </div>
                  ))}
                  {task?.tags?.length > 1 && (
                    <div className="poppins_font_number flex items-center justify-center gap-1 rounded bg-[#E5E7EB] p-1 text-[14px] font-medium text-[#757575]">
                      +{task?.tags?.length - 1}
                    </div>
                  )}
                </button>
              ) : (
                <Button
                  variant="text"
                  className="flex h-[28px] w-[28px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
                  onClick={(e) => {
                    handleClick(false, e);
                    handleAddTag(true);
                  }}
                  disabled={
                    task?.mark_as_done ||
                    signIn?.role === 'client' ||
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? !checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : false)
                  }
                >
                  <LuTag className="h-[14px] w-[14px] text-[#6875F5]" />
                </Button>
              )}
            </div>
          </div>
          <div className="flex items-center justify-between gap-1">
            <div className="flex gap-1">
              {task?.sub_task_count > 0 && (
                <Tooltip
                  size="sm"
                  content={() => 'Sub Task'}
                  placement="top"
                  color="invert"
                >
                  <div className=" flex items-center justify-start gap-1 rounded bg-[#F5F5F5] p-1 text-[14px] font-medium text-[#4B5563]">
                    <Image
                      src={subTaskIcon}
                      alt="sub task icon"
                      width={14}
                      height={14}
                    />
                    <span className="poppins_font_number">
                      {task?.sub_task_count ?? 0}
                    </span>
                  </div>
                </Tooltip>
              )}
              <div onClick={(e) => handleClick(false, e)}>
                <Popover
                  placement="top"
                  className="demo_test min-w-[140px] border-none bg-white p-2 shadow-md dark:bg-gray-100"
                  content={({ setOpen }) => {
                    const handlePriorityChange = (priorityValue: string) => {
                      setSubTaskStatus(priorityValue); // Update local state
                      // 🛠️ Update Task in API
                      if (priorityValue !== task?.priority) {
                        const formData = new FormData();
                        formData.append('_id', task?._id);
                        formData.append('priority', priorityValue);
                        formData.append('action_name', 'date_assignee_update');

                        dispatch(patchEditTask(formData)).then(
                          (result: any) => {
                            if (patchEditTask.fulfilled.match(result)) {
                              if (result && result.payload.success === true) {
                                updateTask(
                                  task?._id,
                                  'priority_update',
                                  priorityValue,
                                  oldTasks,
                                  oldTasksSections
                                );
                                setOpen(false);
                              }
                            }
                          }
                        );
                      }
                    };

                    return (
                      <div className="flex flex-col gap-2">
                        {priorityOptions.map((option) => (
                          <button
                            key={option.value}
                            type="button"
                            disabled={taskLoading}
                            onClick={() => handlePriorityChange(option.value)}
                            className={`flex h-7 w-[130px] cursor-pointer items-center justify-center rounded-lg border-[1px] px-4 py-1 text-sm font-medium ${option.color} hover:opacity-80`}
                          >
                            {option.label}
                          </button>
                        ))}
                      </div>
                    );
                  }}
                >
                  <button
                    className="cursor-pointer"
                    type="button"
                    disabled={
                      task?.mark_as_done ||
                      signIn?.role === 'client' ||
                      (['team_agency', 'team_client'].includes(signIn?.role)
                        ? !checkPermission(
                            'projects',
                            'tasks',
                            'update',
                            signIn?.permission
                          )
                        : false)
                    }
                  >
                    {task?.priority && getPriorityStatusBadge(task?.priority)}
                  </button>
                </Popover>
              </div>
            </div>
            <div>
              {task?.due_date ? (
                <div onClick={(e) => handleClick(false, e)}>
                  <Popover
                    placement="bottom"
                    className="demo_test min-w-[425px] border-none bg-white p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                    content={({ open, setOpen }) => {
                      console.log(open, setOpen, 'openopenopenopenopenopen');
                      const originalDueDate = moment
                        .utc(task?.due_date)
                        .toDate(); // Store the original due date
                      setIsOpenPopOver(open);
                      const handleDateChange = (date: any) => {
                        setSelectedDueDate(date);
                        setShowSaveButton(
                          moment(date).valueOf() !==
                            moment(originalDueDate).valueOf()
                        );
                        // Enable Save only if the date is different
                      };

                      const handleSaveDate = (setOpen: any) => {
                        if (!selectedDueDate) return;

                        const formData = new FormData();
                        formData.append('_id', task?._id);
                        formData.append('due_date', String(selectedDueDate));
                        formData.append('action_name', 'date_assignee_update');

                        dispatch(patchEditTask(formData)).then(
                          (result: any) => {
                            if (
                              patchEditTask.fulfilled.match(result) &&
                              result.payload.success
                            ) {
                              updateTask(
                                task?._id,
                                'due_date_update',
                                moment.utc(selectedDueDate),
                                oldTasks,
                                oldTasksSections
                              );
                              setSelectedDueDate(null);
                              setShowSaveButton(false); // Hide Save button after saving
                              setOpen(false);
                            }
                          }
                        );
                      };

                      return (
                        <div>
                          <DatePicker
                            selected={
                              selectedDueDate ||
                              moment.utc(task?.due_date).toDate()
                            } // Use customizedDueDate
                            inputProps={{}}
                            placeholderText="Select due date"
                            onChange={handleDateChange}
                            selectsStart
                            startDate={
                              selectedDueDate ||
                              moment.utc(task?.due_date).toDate()
                            } // Prefill with existing due date
                            startOpen={true}
                            minDate={new Date()}
                            showTimeSelect
                            popperPlacement="bottom-start"
                            dateFormat="MMM d, yyyy h:mm aa"
                            noStyle={true} // ✅ Remove styles only for this picker
                            inline
                          />

                          <div className="mr-[20px] flex justify-end">
                            {' '}
                            {/* Right align */}
                            <Button
                              onClick={() => handleSaveDate(setOpen)}
                              rounded="lg"
                              disabled={!showSaveButton || taskLoading} // Disable Save button if date/time is not changed
                              className={`kanban-task-tour-step-one flex h-10 items-center justify-center gap-2 text-sm text-white ${
                                showSaveButton
                                  ? 'bg-[#8C80D2]'
                                  : 'cursor-not-allowed bg-[#8C80D2]'
                              }`}
                            >
                              Save
                              {taskLoading && (
                                <Spinner
                                  size="sm"
                                  tag="div"
                                  className="ms-3"
                                  color="white"
                                />
                              )}
                            </Button>
                          </div>
                        </div>
                      );
                    }}
                  >
                    <button
                      className="cursor-pointer"
                      type="button"
                      disabled={
                        task?.mark_as_done ||
                        signIn?.role === 'client' ||
                        (['team_agency', 'team_client'].includes(signIn?.role)
                          ? !checkPermission(
                              'projects',
                              'tasks',
                              'update',
                              signIn?.permission
                            )
                          : false)
                      }
                    >
                      {customizedDueDate}
                    </button>
                  </Popover>
                </div>
              ) : (
                <div onClick={(e) => handleClick(false, e)}>
                  <Popover
                    placement="bottom"
                    className=" demo_test min-w-[425px] border-none bg-white p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                    content={({ open, setOpen }) => {
                      setIsOpenPopOver(open);

                      const handleDateChange = (date: any) => {
                        setSelectedDueDate(date);
                        setShowSaveButton(moment(date).valueOf());
                      };
                      const saveDateChange = (setOpen: any) => {
                        if (
                          !(
                            selectedDueDate?.getHours() === 0 &&
                            selectedDueDate?.getMinutes() === 0 &&
                            selectedDueDate?.getSeconds() === 0
                          )
                        ) {
                          const formData: any = new FormData();
                          formData.append('_id', task?._id);
                          formData.append('due_date', String(selectedDueDate));
                          formData.append(
                            'action_name',
                            'date_assignee_update'
                          );

                          dispatch(patchEditTask(formData)).then(
                            (result: any) => {
                              if (patchEditTask.fulfilled.match(result)) {
                                if (result && result.payload.success === true) {
                                  updateTask(
                                    task?._id,
                                    'due_date_update',
                                    moment.utc(selectedDueDate),
                                    oldTasks,
                                    oldTasksSections
                                  );
                                  setSelectedDueDate(null);
                                  setShowSaveButton(false);
                                  setOpen(false);
                                }
                              }
                            }
                          );
                        }
                      };

                      return (
                        <div>
                          <DatePicker
                            selected={selectedDueDate}
                            inputProps={{}}
                            placeholderText="Select due date"
                            onChange={handleDateChange}
                            selectsStart
                            startDate={selectedDueDate}
                            startOpen={true}
                            minDate={new Date()}
                            showTimeSelect
                            popperPlacement="bottom-start"
                            dateFormat="MMM d, yyyy h:mm aa"
                            noStyle={true} // ✅ Remove styles only for this picker
                            inline
                          />
                          <div className="mr-[20px] flex justify-end">
                            {' '}
                            {/* Right align */}
                            <Button
                              onClick={() => saveDateChange(setOpen)}
                              rounded="lg"
                              disabled={!showSaveButton || taskLoading} // Disable Save button if date/time is not changed
                              className={`kanban-task-tour-step-one flex h-10 items-center justify-center gap-2 text-sm text-white ${
                                showSaveButton
                                  ? 'bg-[#8C80D2]'
                                  : 'cursor-not-allowed bg-[#8C80D2]'
                              }`}
                            >
                              Save
                              {taskLoading && (
                                <Spinner
                                  size="sm"
                                  tag="div"
                                  className="ms-3"
                                  color="white"
                                />
                              )}
                            </Button>
                          </div>
                        </div>
                      );
                    }}
                  >
                    <Button
                      variant="text"
                      className="flex h-[28px] w-[28px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
                      disabled={
                        task?.mark_as_done ||
                        signIn?.role === 'client' ||
                        (['team_agency', 'team_client'].includes(signIn?.role)
                          ? !checkPermission(
                              'projects',
                              'tasks',
                              'update',
                              signIn?.permission
                            )
                          : false)
                      }
                    >
                      <PiCalendarBlankLight className="h-[14px] w-[14px] text-[#6875F5]" />
                    </Button>
                  </Popover>
                </div>
              )}
            </div>
          </div>
          {activeTimerData?.task_detail?._id === task?._id && (
            <div className="flex w-[100px] items-center gap-1 rounded-lg bg-[#FEE9E7] px-2 py-1">
              <FiStopCircle className="h-5 w-5 text-[#EC221F]" />
              <span className="poppins_font_number text-sm font-medium text-[#EC221F]">
                <TimerDisplay />
              </span>
            </div>
          )}
          {/* <div className="flex items-center justify-between gap-2">
              <div className="flex w-[70%] flex-wrap items-center justify-start gap-2">
                <div className="ms-[5px] flex">
                </div>
                {task?.due_date ? (
                  <>{customizedDueDate}</>
                ) : (
                  <div onClick={(e) => handleClick(false, e)}>
                    <Popover
                      placement="bottom"
                      className=" demo_test min-w-[425px] border-none bg-transparent p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                      content={({ setOpen }) => {
                        const handleDateChange = (date: any) => {
                          setSelectedDueDate(date);

                          if (
                            !(
                              date.getHours() === 0 &&
                              date.getMinutes() === 0 &&
                              date.getSeconds() === 0
                            )
                          ) {
                            const formData: any = new FormData();
                            formData.append('_id', task?._id);
                            formData.append('due_date', String(date));
                            formData.append(
                              'action_name',
                              'date_assignee_update'
                            );

                            dispatch(patchEditTask(formData)).then(
                              (result: any) => {
                                if (patchEditTask.fulfilled.match(result)) {
                                  if (
                                    result &&
                                    result.payload.success === true
                                  ) {
                                    updateTask(
                                      task?._id,
                                      'due_date_update',
                                      moment.utc(date),
                                      oldTasks,
                                      oldTasksSections
                                    );
                                    setSelectedDueDate(null);
                                    setOpen(false);
                                  }
                                }
                              }
                            );
                          }
                        };
                        return (
                          <DatePicker
                            selected={selectedDueDate}
                            inputProps={{}}
                            placeholderText="Select due date"
                            onChange={handleDateChange}
                            selectsStart
                            startDate={selectedDueDate}
                            startOpen={true}
                            minDate={new Date()}
                            showTimeSelect
                            popperPlacement="bottom-start"
                            dateFormat="MMMM d, yyyy h:mm aa"
                            inline
                          />
                        );
                      }}
                    >
                      <Button
                        variant="text"
                        className="flex h-[32px] w-[32px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#9BA1B9] p-1"
                        disabled={
                          task?.mark_as_done ||
                          (['team_agency', 'team_client', 'client'].includes(
                            signIn?.role
                          )
                            ? !checkPermission(
                                'projects',
                                'tasks',
                                'update',
                                signIn?.permission
                              )
                            : false)
                        }
                      >
                        <PiCalendarBlankLight className="h-[14px] w-[14px] text-[#9BA1B9]" />
                      </Button>
                    </Popover>
                  </div>
                )}
              </div>
              <div className="flex w-[30%] justify-end">
                {activeTimerData?.task_detail?._id === task?._id && (
                  <img
                    src={timerImg?.src}
                    alt=""
                    className="flex h-[35px] w-6 items-center justify-center"
                  />
                )}
                {settingData?.task?.time_tracking?.length > 0 &&
                  checkAssigneExist(signIn?.user?.data?.user?._id) &&
                  task?.status?.key !== 'archived' &&
                  task?.status?.key !== 'completed' && (
                    <div onClick={(e) => handleClick(false, e)}>
                      <ActionIcon
                        variant="text"
                        className="flex items-center justify-center px-0 py-0"
                        onClick={() => {
                          handleTimerClick(task?._id);
                        }}
                      >
                        <IoIosTimer className="h-6 w-6 text-[#8C80D2]" />
                      </ActionIcon>
                    </div>
                  )}
                {!task?.mark_as_archived &&
                (['agency'].includes(signIn?.role) ||
                  // ['agency', 'client'].includes(signIn?.role)
                  (['team_agency', 'team_client'].includes(signIn?.role) &&
                    checkPermission(
                      'projects',
                      'tasks',
                      'update',
                      signIn?.permission
                    ))) ? (
                  <div onClick={(e) => handleClick(false, e)}>
                    <Tooltip
                      size="sm"
                      content={() =>
                        !task?.mark_as_done
                          ? 'Move to completed'
                          : 'Move to archive'
                      }
                      placement="top"
                      color="invert"
                    >
                      <ActionIcon
                        variant="text"
                        className="float-end !bg-white p-0"
                        onClick={handleTaskStatusChangeClick}
                        disabled={loading}
                      >
                        {task?.mark_as_done ? (
                          <IoIosCheckmarkCircle className="h-6 w-6 text-[#8C80D2]" />
                        ) : (
                          <IoIosCheckmarkCircleOutline className="h-6 w-6 text-[#8C80D2]" />
                        )}
                      </ActionIcon>
                    </Tooltip>
                  </div>
                ) : (
                  !['client'].includes(signIn?.role) && (
                    <div>
                      <ActionIcon
                        variant="text"
                        className="float-end inline-flex !bg-white p-0"
                        onClick={handleTaskStatusChangeClick}
                        disabled={loading}
                      >
                        {task?.mark_as_done ? (
                          <IoIosCheckmarkCircle className="h-6 w-6 text-[#8C80D2]" />
                        ) : (
                          <IoIosCheckmarkCircleOutline className="h-6 w-6 text-[#8C80D2]" />
                        )}
                      </ActionIcon>
                    </div>
                  )
                )}
              </div>
            </div> */}
          {/* <div className="flex items-center justify-between gap-2">
              <div className="ms-[8px] flex items-center justify-start gap-2">
                <div className="poppins_font_number flex items-center justify-start gap-2 text-[14px] font-bold text-[#120425]">
                  <BiCommentDetail className="h-[14px] w-[14px] text-[#8C80D2]" />
                  <span className="poppins_font_number">
                    {task?.comments_count ?? 0}{' '}
                  </span>
                </div>
                <div className="poppins_font_number flex items-center justify-start gap-2 text-[14px] font-bold text-[#120425]">
                  <AiOutlineLink className="h-[14px] w-[14px] text-[#8C80D2]" />{' '}
                  {task?.attachment_count ?? 0}
                </div>
                <div className="poppins_font_number flex items-center justify-start gap-2 text-[14px] font-bold text-[#120425]">
                  <Tooltip
                    size="sm"
                    content={() => 'Sub Task'}
                    placement="top"
                    color="invert"
                  >
                    <div>
                      <VscTypeHierarchySub className="h-[14px] w-[14px] cursor-pointer text-[#8C80D2]" />{' '}
                    </div>
                  </Tooltip>

                  {task?.sub_task_count ?? 0}
                </div>
                {!task?.mark_as_done &&
                  // ['agency', 'client'].includes(signIn?.role)
                  (['agency'].includes(signIn?.role) ||
                    (['team_agency', 'team_client'].includes(signIn?.role) &&
                      checkPermission(
                        'projects',
                        'tasks',
                        'create',
                        signIn?.permission
                      ))) && (
                    <Tooltip
                      size="sm"
                      content={() => 'Duplicate Task'}
                      placement="top"
                      color="invert"
                    >
                      <div
                        onClick={(e) => {
                          if (!duplicateTaskLoading) {
                            handleClick(false, e);
                            onDuplicateTask(task);
                          }
                        }}
                        className={`poppins_font_number flex cursor-pointer items-center justify-start gap-2 text-[14px] font-bold text-[#120425] ${
                          duplicateTaskLoading
                            ? 'cursor-not-allowed opacity-50'
                            : ''
                        }`}
                      >
                        <IoDuplicateOutline className="h-[14px] w-[14px] text-[#8C80D2]" />
                      </div>
                    </Tooltip>
                  )}
                {!task?.mark_as_done &&
                  task?.due_date &&
                  // ['agency', 'client'].includes(signIn?.role) ||
                  (['agency'].includes(signIn?.role) ||
                    (['team_agency', 'team_client'].includes(signIn?.role) &&
                      (checkPermission(
                        'projects',
                        'tasks',
                        'create',
                        signIn?.permission
                      ) ||
                        checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )))) &&
                  new Date(task?.due_date).getTime() > new Date().getTime() && (
                    <Tooltip
                      size="sm"
                      content={() => 'Reminder due date Task'}
                      placement="top"
                      color="invert"
                    >
                      <div
                        onClick={(e) => {
                          if (!taskLoading) {
                            handleClick(false, e);
                            openModal({
                              view: (
                                <>
                                  <TaskReminder
                                    onClose={closeModal}
                                    rowData={task}
                                    isGridTaskView={true}
                                    updateTask={updateTask}
                                    // editMode={true}
                                  />
                                </>
                              ),
                              customSize: '410px',
                            });
                          }
                        }}
                        className={`poppins_font_number mr-2 flex cursor-pointer items-center justify-start gap-2 text-[14px] font-bold text-[#120425] ${
                          taskLoading ? 'cursor-not-allowed opacity-50' : ''
                        }`}
                      >
                        {task?.reminder_option &&
                        task?.reminder_option !== 'no_notify' ? (
                          <BiSolidBellRing className="h-[15px] w-[15px] text-[#8C80D2]" />
                        ) : (
                          <LuBellRing className="h-[15px] w-[15px] text-[#8C80D2]" />
                        )}
                      </div>
                    </Tooltip>
                  )}
              </div>
              <div>
                {task?.priority && getPriorityStatusBadge(task?.priority)}
              </div>
            </div> */}
        </div>
        {/* </SimpleBar> */}
      </div>
    </div>
  );
}

export default TaskCard;
