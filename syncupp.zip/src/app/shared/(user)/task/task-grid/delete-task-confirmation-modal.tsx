'use client';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import Spinner from '@/components/ui/spinner';
import {
  deleteTask,
  getAllCommentsById,
  getAllTask,
  getTaskById,
} from '@/redux/slices/user/task/taskSlice';
import { taskTimeTrackedHistory } from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import cn from '@/utils/class-names';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Text, Title } from 'rizzui';

export function ConfirmationTaskDeleteModal(props: any) {
  const {
    taskData,
    onClose,
    updateTask,
    shouldCloseDrawer,
    onDeleteClose,
    setSubTaskData,
    defaulttask,
    setAllSubtask,
  } = props;
  const dispatch = useDispatch();
  const { closeDrawer } = useDrawer();

  const eventSliceData = useSelector((state: any) => state?.root?.event);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { calendarView } = useSelector((state: any) => state?.root?.activity);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const {
    gridView,
    deleteTaskLoader,
    paginationParams,
    oldTasks,
    oldTasksSections,
  } = useSelector((state: any) => state?.root?.task);
  const { boardId, members, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );

  const handleYesClick = () => {
    dispatch(
      deleteTask({
        taskIdsToDelete: [taskData?._id],
        board_id: taskData.board_id,
        section_id: taskData?.status?._id,
        parent_task: taskData?.parent_task,
      })
    ).then((result: any) => {
      if (deleteTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          // Check if shouldCloseDrawer is true
          if (shouldCloseDrawer) {
            onDeleteClose();
            setSubTaskData(null);
            // Use your logic here to fetch task details like in useEffect
            // dispatch(getTaskById({ taskId: taskData?.parent_task })).then(
            //   (result: any) => {
            //     if (getTaskById?.fulfilled?.match(result)) {
            //       if (result && result?.payload?.success === true) {
            //         // You can handle success logic here if needed
            //       } else {
            //         onClose();
            //       }
            //     } else {
            //       onClose();
            //     }
            //   }
            // );
            setAllSubtask((prevSubtasks: any) =>
              prevSubtasks.filter(
                (subtask: any) => subtask._id !== taskData?._id
              )
            );

            dispatch(taskTimeTrackedHistory(taskData?.parent_task));
            dispatch(getAllCommentsById({ task_id: taskData?.parent_task }));
            if (gridView) {
              updateTask(
                defaulttask?._id,
                'decrease_subtask_count',
                { subtask: defaulttask },
                oldTasks,
                oldTasksSections
              );
            }
          } else {
            onClose();
            closeDrawer();
            if (!gridView) {
              dispatch(
                getAllTask({
                  ...paginationParams,
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              updateTask(
                taskData?._id,
                'delete_task',
                { section_id: taskData?.status?._id },
                oldTasks,
                oldTasksSections
              );
            }
          }
        }
      }
    });
  };

  return (
    <div className="p-6">
      <div className="flex flex-col items-center gap-[6px]">
        <Title
          as="h6"
          className="mb-0.5 flex items-start text-sm text-[#8C80D2] sm:items-center"
        >
          {taskData?.parent_task ? 'Delete the sub task.?' : 'Delete the task.'}
        </Title>
        <Text className="mb-2 leading-relaxed text-[#9BA1B9]">
          {taskData?.parent_task
            ? 'Are you sure you want to delete this subtask?'
            : 'Are you sure you want to delete this task?'}{' '}
        </Text>
      </div>
      <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
        <div className="flex items-center justify-end gap-2">
          <Button
            className="bg-[#8C80D2] text-white @xl:w-auto dark:text-white"
            disabled={deleteTaskLoader}
            onClick={handleYesClick}
          >
            Yes
            {deleteTaskLoader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
        <div>
          <Button
            variant="outline"
            className="text-[#9BA1B9] @xl:w-auto dark:hover:border-gray-400"
            onClick={() => {
              // if (shouldCloseDrawer) {
              onDeleteClose();
              // } else {
              //   onClose();
              // }
            }}
          >
            No
          </Button>
        </div>
      </div>
    </div>
  );
}
