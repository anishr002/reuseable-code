import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { RxCross2 } from 'react-icons/rx';
import { ActionIcon } from '@/components/ui/action-icon';
import { PiXBold } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import { getAllTask, patchEditTask } from '@/redux/slices/user/task/taskSlice';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import Spinner from '@/components/ui/spinner';

const Addtag = ({
  onClose,
  isAPICall,
  selectedtags,
  setSelectedTags,
  updateTask,
  task,
  isTable,
  boardId,
  paginationParams,
}: {
  onClose: () => void;
  isAPICall: Boolean;
  selectedtags?: any[];
  setSelectedTags?: any;
  updateTask?: any;
  task?: any;
  isTable?: any;
  boardId?: any;
  paginationParams?: any;
}) => {
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [tags, setTags] = useState<string[]>(selectedtags || []);

  const dispatch = useDispatch();
  const { oldTasks, oldTasksSections, loading } = useSelector(
    (state: any) => state?.root?.task
  );

  const MAX_WORDS = 20;
  const MAX_CHARS = 20; // Limit for a single tag

  // Clear error when the input loses focus
  //   const handleInputBlur = () => {
  //     setError(null); // Clear the error when the input loses focus
  //   };

  // Add the onChange validation
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);

    const trimmedValue = value.trim();

    // Validation
    const wordCount = trimmedValue.split(/\s+/).filter(Boolean).length;
    // if (trimmedValue === '') {
    //   setError('Tag cannot be empty.');
    // } else
    if (trimmedValue.length > MAX_CHARS) {
      setError(`Each tag can have a maximum of ${MAX_CHARS} characters.`);
    } else if (
      tags.some((tag: any) => tag?.toLowerCase() === trimmedValue.toLowerCase())
    ) {
      setError('This tag already exists.');
    } else {
      setError(null); // No error if the input is valid
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const trimmedValue = inputValue.trim();

      if (trimmedValue !== '' && !error) {
        setTags((prevTags: any) => [...prevTags, trimmedValue]);
        setInputValue('');
      }
    }
  };
  const handleRemoveTag = (index: number) => {
    setTags((prevTags: any) =>
      prevTags.filter((_: any, i: any) => i !== index)
    );
  };

  const AddTag = () => {
    if (isAPICall) {
      const formData: any = new FormData();
      formData.append('_id', task?._id);

      if (tags?.length > 0) {
        tags.forEach((tag) => {
          formData.append('tags', tag); // ✅ Append tags if available
        });
      } else {
        formData.append('tags', JSON.stringify([])); // ✅ Send empty array correctly
      }

      formData.append('action_name', 'date_assignee_update');

      dispatch(patchEditTask(formData)).then((result: any) => {
        if (patchEditTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            if (isTable) {
              dispatch(
                getAllTask({
                  ...paginationParams,
                  board_id: boardId,
                  pagination: true,
                })
              );
              onClose();
            } else {
              updateTask(
                task?._id,
                'tags_update',
                tags?.length > 0 &&
                  tags?.map((tag: string) => ({ tag_name: tag })),
                oldTasks,
                oldTasksSections
              );
              onClose();
            }
          }
        }
      });
    } else {
      setSelectedTags(tags);
      onClose();
    }
  };

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-center justify-between">
        <p className="montserrat_font_title text-[23px] font-bold text-[#4B5563]">
          Add Tag
        </p>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={onClose}
          className="p-1 text-[#4B5563] hover:text-[#1A202C]"
        >
          <PiXBold className="h-6 w-6" />
        </ActionIcon>
      </div>

      <div className="w-full">
        <Input
          type="text"
          inputClassName="text-[#141414] poppins_font_number"
          className="poppins_font_number flex-1 border-none bg-[#F9FAFB] text-[14px] text-[#141414] focus:outline-none"
          placeholder="# Add Tags"
          value={inputValue}
          onKeyDown={handleAddTag}
          onChange={handleInputChange}
          //   onBlur={handleInputBlur}
        />
        {error && (
          <span className="mt-1 block text-[12px] text-red-500">{error}</span>
        )}
      </div>

      {tags?.length > 0 && (
        <div className="flex w-full flex-wrap gap-2">
          {tags?.map((tag, index) => (
            <div
              key={index}
              className="flex items-center gap-2 break-words rounded-full bg-[#E4E7EB] px-3 py-1 text-sm font-medium text-[#4A5568] dark:bg-[#2D3748] dark:text-[#CBD5E0]"
            >
              <span className="break-all">{tag}</span>
              <RxCross2
                className="h-4 w-4 cursor-pointer text-[#4A5568] hover:text-[#1A202C]"
                onClick={() => handleRemoveTag(index)}
              />
            </div>
          ))}
        </div>
      )}

      <Button
        type="button"
        className="bg-[#8C80D2] text-sm text-white"
        onClick={() => {
          if (!error) {
            AddTag();
          }
        }}
        disabled={loading}
      >
        Add Tag
        {loading && (
          <Spinner size="sm" tag="div" className="ms-3" color="white" />
        )}
      </Button>
    </div>
  );
};

export default Addtag;
