'use client';

import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { useModal } from '@/app/shared/modal-views/use-modal';
import QuillLoader from '@/components/loader/quill-loader';
import SelectLoader from '@/components/loader/select-loader';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Popover } from '@/components/ui/popover';
import Select from '@/components/ui/select';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { Switch } from '@/components/ui/switch';
import { Text } from '@/components/ui/text';
import { Textarea } from '@/components/ui/textarea';
import { messages } from '@/config/messages';
import TailwindSwitch from '@/hooks/tailwindSwitch';
import {
  getAllMyTasks,
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  getBoardById,
  getBoardSectionsById,
  getMembersByBoardId,
  removeTaskFormData,
} from '@/redux/slices/user/task/boardSlice';
import {
  getAllTask,
  getTaskById,
  postAddTask,
} from '@/redux/slices/user/task/taskSlice';
import {
  capitalizeFirstLetter,
  checkValidFileSize,
  getColor,
  getFileSize,
  getFileType,
  handleKeyDown,
} from '@/utils/common-functions';
import {
  createTaskFormTourStepsContent,
  getStepsByRole,
} from '@/utils/tour-steps/tour-steps';
import moment from 'moment';
import dynamic from 'next/dynamic';
import React, { useEffect, useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Controller } from 'react-hook-form';
import { FiEdit, FiUsers } from 'react-icons/fi';
import { ImAttachment } from 'react-icons/im';
import { IoMdAdd } from 'react-icons/io';
import { PiCaretDownBold } from 'react-icons/pi';
import { RxCross2 } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect, { components } from 'react-select';
import Tour from 'reactour';
import { z } from 'zod';
import { checkPermission } from '../../roles-permissions/utils';
import WeeklyRecurring from './WeeklyRecurring';
import { createPortal } from 'react-dom';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px] w-full" />,
});

const RecurringArray = [
  // {
  //   name: 'Does not repeat',
  //   label: 'Does not repeat',
  //   value: '',
  // },
  {
    name: 'Daily',
    label: 'Daily',
    value: 'daily',
  },
  {
    name: 'Weekly',
    label: 'Weekly',
    value: 'weekly',
  },
  {
    name: 'Monthly',
    label: 'Monthly',
    value: 'monthly',
  },
];
const monthDate = [
  { label: '1', value: '1' },
  { label: '2', value: '2' },
  { label: '3', value: '3' },
  { label: '4', value: '4' },
  { label: '5', value: '5' },
  { label: '6', value: '6' },
  { label: '7', value: '7' },
  { label: '8', value: '8' },
  { label: '9', value: '9' },
  { label: '10', value: '10' },
  { label: '11', value: '11' },
  { label: '12', value: '12' },
  { label: '13', value: '13' },
  { label: '14', value: '14' },
  { label: '15', value: '15' },
  { label: '16', value: '16' },
  { label: '17', value: '17' },
  { label: '18', value: '18' },
  { label: '19', value: '19' },
  { label: '20', value: '20' },
  { label: '21', value: '21' },
  { label: '22', value: '22' },
  { label: '23', value: '23' },
  { label: '24', value: '24' },
  { label: '25', value: '25' },
  { label: '26', value: '26' },
  { label: '27', value: '27' },
  { label: '28', value: '28' },
  { label: '29', value: '29' },
  { label: '30', value: '30' },
  { label: '31', value: '31' },
];

const customData = [
  { value: 'minutes', label: 'Minutes before' },
  { value: 'hours', label: 'Hours before' },
  { value: 'days', label: 'Days before' },
];

const weekdays = [
  { name: 'M', value: 'monday' },
  { name: 'T', value: 'tuesday' },
  { name: 'W', value: 'wednesday' },
  { name: 'T', value: 'thursday' },
  { name: 'F', value: 'friday' },
  { name: 'SA', value: 'saturday' },
  { name: 'S', value: 'sunday' },
];

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E4F6D6]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="w-[130px] font-medium text-green-dark">Low</Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FBF0DE]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#FBF0DE] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="warning" renderAsDot />
        <Text className="w-[130px] font-medium text-orange-dark">Medium</Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFD4C6]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="w-[130px] font-medium text-red-dark">High</Text>
      </div>
    ),
  },
];

// Mention Style Start
const mentionStyles = {
  control: {
    backgroundColor: '#FFFFFF',
    fontSize: '16px',
    fontWeight: 'normal',
    color: '#000000',
    borderRadius: '0.5rem',
  },
  '&multiLine': {
    control: {
      fontFamily: 'Arial, sans-serif',
      overflow: 'hidden',
      height: '106px',
      width: '100%',
    },
    highlighter: {
      padding: '0.5rem',
      border: '1px solid transparent',
      overflow: 'hidden',
      borderRadius: '0.5rem',
      height: '106px',
      width: '100%',
    },
    input: {
      padding: '0.375rem',
      border: '1px solid #d1d5db', // Tailwind: border-gray-300
      color: '#000000',
      borderRadius: '0.5rem',
      height: '106px',
      overflow: 'auto',
      // resize: 'none',
      width: '100%',
    },
  },
  suggestions: {
    list: {
      backgroundColor: '#FFFFFF',
      border: '1px solid rgba(0,0,0,0.15)',
      fontSize: '14px',
      // position: 'absolute',
      left: 0,
      zIndex: 10,
    },
    item: {
      padding: '5px 15px',
      borderBottom: '1px solid #ccc',
      '&focused': {
        backgroundColor: '#8C80D2', // Tailwind: bg-purple-400
        color: '#FFFFFF',
      },
    },
  },
};
// Define types for props
interface AddTaskFormProps {
  onClose: () => void; // Function that is called when closing the modal
  editMode: boolean; // Flag for edit mode
  rowData?: any;
  subTaskId?: any;
  column?: any;
  createTask?: any;
  isAllTasksModule?: boolean; // Flag for All Tasks module
}

const customStyles = {
  control: (provided: any, state: any) => ({
    ...provided,
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    borderRadius: '8px',
    borderColor: state.isFocused ? 'black' : 'rgb(209 213 219)',
    boxShadow: state.isFocused ? 'none' : 'none', // Ensure no box-shadow on focus
    outline: 'none !important',
    padding: '0 8px',
    transition: 'border-color 0.2s ease',
    '&:hover': {
      borderColor: 'black', // Black border on hover
    },
  }),
  input: (provided: any) => ({
    ...provided,
    border: 'none !important',
    boxShadow: 'none !important',
    outline: 'none !important',
    caretColor: 'rgb(209 213 219)', // Ensures visible text cursor
  }),
  valueContainer: (provided: any) => ({
    ...provided,
    display: 'flex',
    alignItems: 'center',
    padding: '0 8px',
    gap: '8px',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  }),
  placeholder: (provided: any) => ({
    ...provided,
    color: 'rgb(209 213 219)',
    fontSize: '14px',
    fontWeight: '500',
    whiteSpace: 'nowrap',
  }),
  singleValue: (provided: any) => ({
    ...provided,
    fontWeight: '600',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  }),
  multiValue: (provided: any) => ({
    ...provided,
    backgroundColor: '#e1e7ff',
    borderRadius: '12px',
    padding: '2px 6px',
    display: 'flex',
    alignItems: 'center',
  }),
  multiValueLabel: (provided: any) => ({
    ...provided,
    fontSize: '12px',
    fontWeight: '500',
    color: '#4a4a4a',
  }),
  multiValueRemove: (provided: any) => ({
    ...provided,
    color: '#8c80d2',
    cursor: 'pointer',
    ':hover': {
      backgroundColor: '#e0e0e0',
      color: '#4a4a4a',
    },
  }),
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isFocused ? '#f3f4f6' : 'white',
    color: state.isSelected ? '#4a4a4a' : '#000',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: state.isSelected ? '600' : '400',
    ':active': {
      backgroundColor: '#e1e7ff',
    },
  }),
  menu: (provided: any) => ({
    ...provided,
    zIndex: 9999,
    borderRadius: '8px',
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
    marginTop: '4px',
  }),
  dropdownIndicator: (provided: any) => ({
    ...provided,
    color: '#8c80d2',
    ':hover': {
      color: '#4a4a4a',
    },
  }),
  indicatorSeparator: () => ({
    display: 'none !important',
  }),
};
const AddTaskForm: React.FC<AddTaskFormProps> = ({
  onClose,
  editMode = false,
  rowData,
  subTaskId = null,
  column,
  createTask,
  isAllTasksModule = false,
}) => {
  const dispatch = useDispatch();
  const setValueReference = useRef<any>();
  const setErrorReference = useRef<any>();
  const setClearErrorReference = useRef<any>();
  const setWatchReference = useRef<any>();
  const [isEachMonth, setIsEachMonth] = useState(false);
  const [isEachWeek, setIsEachWeek] = useState(false);
  const [isEachWeekModal, setIsEachWeekModal] = useState(false);
  const [recurrenceDueDay, setRecurrenceDueDay] = useState<any>({
    label: '1',
    value: '1',
  });
  const [defaultRecurrence, setDefaultRecurrence] = useState<any>({
    label: '1',
    value: '1',
  });

  const taskData = useSelector((state: any) => state?.root?.task);
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const { allTasksLoading } = useSelector((state: any) => state?.root?.task);
  const { paginationParams } = useSelector((state: any) => state?.root?.client);
  const { userProfile } = useSelector((state: any) => state?.root?.signIn);

  const {
    boardId,
    assignees,
    boardDetails,
    boardSections,
    members,
    sections,
    boardSectionsLoader,
    data: boardData,
  } = useSelector((state: any) => state?.root?.board);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  // const { settingData } = useSelector((state: any) => state?.root?.setting);
  const [selectedRecipients, setSelectedRecipients] = useState<any>([]);

  const [showAddMemberModal, setshowAddMemberModal] = useState(false);
  const commentAttachmentRef = useRef<HTMLInputElement>(null);
  const [previewAttechmentImage, setPreviewAttechmentImage] = useState<any>([]);
  const [mentionUser, setMentionUser] = useState<any>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);
  // for selected status option
  const [selectedStatus, setSelectedStatus] = useState<any>(null);
  const [selectedRecurringOption, setSelectedRecurringOption] = useState<any>({
    name: '',
    label: '',
    value: '',
  });
  const [selectedReminder, setSelectedReminder] = useState({
    value: 'no_notify',
    label: "Don't notify",
    name: "Don't notify",
  });
  const [selectedRepetition, setSelectedRepetition] = useState({
    value: 'no_repetition',
    label: 'No repetition',
    name: 'No repetition',
  });

  const reminderOptions = [
    // { value: 'on_due_date', label: 'On due date' },
    { value: 'no_notify', label: "Don't notify" },
    { value: '10_min_before', label: '10 minutes before' },
    { value: '30_min_before', label: '30 minutes before' },
    { value: '1_hour_before', label: '1 hour before' },
    { value: '1_day_before', label: '1 day before' },
    { value: '2_day_before', label: '2 days before' },
    { value: '3_day_before', label: '3 days before' },
    { value: '1_week_before', label: '1 week before' },
    { value: '2_week_before', label: '2 weeks before' },
    { value: 'custom', label: 'Custom' },
  ];

  const RepeatOptions = [
    // { value: 'on_due_date', label: 'On due date' },
    { value: 'no_repetition', label: 'No repetition' },
    {
      value: 'daily',
      label: 'Daily until the task is completed',
    },
    {
      value: 'weekly',
      label: 'Weekly until the task is completed',
    },
  ];

  const [isRecurring, setIsRecurring] = useState(false);
  const [isReminder, setIsReminder] = useState(false);
  const { closeModal } = useModal();
  //coustomField data
  const [customFieldData, setCustomFieldData] = useState<any>([]);
  const task = taskData?.task?.activity ?? {}; // after get task by id data in edit mode
  const { gridView, oldTasks, oldTasksSections, duplicateTaskLoading } =
    useSelector((state: any) => state?.root?.task);

  // for handle comment attachement error
  const [commentAttachementInvalid, setCommentAttachementInvalid] =
    useState(false);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [selectedMembersDetails, setSelectedMembersDetails] = useState([]);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [selectedEndDate, setSelectedEndDate] = useState<any>(null);

  // if not all tasks module tahn call the below apis
  useEffect(() => {
    if (!isAllTasksModule) {
      dispatch(
        getBoardById({
          boardId,
          isAddTaskForm: true,
        })
      );
      dispatch(
        getBoardSectionsById({
          board_id: boardId,
          isAddTaskForm: true,
        })
      );
      dispatch(
        getMembersByBoardId({
          boardId,
          isAddTaskForm: true,
        })
      );
    }
  }, []);

  useEffect(() => {
    // clear board data when add task form unmount
    return () => {
      dispatch(removeTaskFormData());
    };
  }, []);

  const isToday = (date: any) => {
    const today = moment()?.startOf('day');
    return (
      moment(date).isSame(moment(), 'day') ||
      moment(date).isBefore(today, 'day')
    );
  };
  // Get Min Time
  const getMinTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment(selectedDate).isSame(moment(), 'day')
        ? moment().toDate()
        : moment().endOf('day').toDate();
    }
    return undefined;
  };

  // Get Max Time
  const getMaxTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment().endOf('day').toDate();
    }
    return undefined;
  };

  const addTaskFormSchema = z.object({
    title: z
      .string()
      .min(1, { message: messages.titleIsRequired })
      .max(150, { message: messages.taskTitleLength }),
    //   agenda: z.string().optional(),
    // attachments: z.any().optional(),
    attachments: z.any().optional(),
    priority: z
      .string({ required_error: messages.priorityIsRequired })
      .min(1, { message: messages.priorityIsRequired }),
    due_date: z.any().optional(),
    status: z
      .string({ required_error: messages.statusIsRequired })
      .min(1, { message: messages.statusIsRequired }),
    comment_attachments: z.any().optional(),
    description: z.string().optional(),
    recurrence_pattern: z.string().nullable().optional(),
    weekly_recurrence_days:
      selectedRecurringOption?.value === 'weekly'
        ? z.array(z.string()).min(1, 'Select at least one day')
        : z.array(z.string()).optional(),
    recurrence_task_due_date:
      userProfile?.agency_setting?.is_custom_recurring &&
      selectedRecurringOption?.value === 'monthly' &&
      isEachMonth
        ? z
            .array(
              z.object({
                index: z.number().optional(),
                month: z.number().min(1).max(12).optional(), // Ensure valid months (1-12)
                year: z.number().min(1900).optional(), // Ensure a reasonable year
                date: z.date().nullable().optional(), // Ensures default null
              })
            )
            .min(1, {
              message:
                'At least one due date is required for monthly recurrence',
            })
            .optional()
        : z
            .array(
              z.object({
                index: z.number().optional(),
                month: z.number().min(1).max(12).optional(), // Ensure valid months (1-12)
                year: z.number().min(1900).optional(), // Ensure a reasonable year
                date: z.any().nullable().optional(), // Ensures default null
                day: z.number().nullable().optional(),
              })
            )
            .optional(),
    recurrence_default_due_date:
      userProfile?.agency_setting?.is_custom_recurring &&
      selectedRecurringOption?.value == 'monthly' &&
      !isEachMonth
        ? z
            .object({
              label: z.string(),
              value: z.string(),
            })
            .nullable()
        : z
            .object({
              label: z.string().optional(),
              value: z.string().optional(),
            })
            .optional(),
    // recurrence_interval:
    //   selectedRecurringOption?.value !== ''
    //     ? z
    //         .string()
    //         .min(1, { message: 'Minimum 1 number required' })
    //         .max(2, { message: 'Maximum 2 digits allowed' })
    //         .regex(/^[1-9][0-9]?$/, {
    //           message: 'Only positive integers greater than 0 are allowed',
    //         }) // Excludes 0, only positive integers are allowed
    //     : z.string().optional(),
    recurrence_start_at_time:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable() // This allows it to be null
            .refine((val: any) => val !== null, {
              message: messages.recurringStartTimeIsRequried,
            })
        : z.date().nullable().optional(),
    due_date_duration:
      selectedRecurringOption?.value !== '' &&
      (!userProfile?.agency_setting ||
        userProfile?.agency_setting === null ||
        userProfile?.agency_setting?.is_custom_recurring === false)
        ? z
            .string()
            .min(1, { message: 'Due date duration is required' })
            .regex(/^[0-9]\d*$/, {
              message: 'Only positive numbers are allowed (e.g., 0, 1, 2, 3)',
            })
            .transform((val) => Number(val))
            .refine((val) => val <= 100, {
              message: 'Maximum allowed value is 100',
            })
        : z.string().optional(),
    recurrence_start_date:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringStartDateIsRequried,
            })
        : z.date().nullable().optional(),
    recurrence_end_date:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringEndDateIsRequried,
            })
        : z.date().nullable().optional(),
    monthly_recurrence_day_of_month:
      selectedRecurringOption?.value === 'monthly'
        ? z
            .object({
              label: z.string(),
              value: z.string(),
            })
            .nullable()
        : z
            .object({
              label: z.string().optional(),
              value: z.string().optional(),
            })
            .optional(),
    reminder: z.string().optional(),
    repeat: z.string().optional(),
    reminder_user:
      selectedReminder?.value !== 'no_notify' ||
      selectedRepetition?.value !== 'no_repetition'
        ? z
            .array(z.string())
            .min(1, { message: 'At least one reminder user is required' })
        : z.array(z.string()).optional(),
    reminder_date:
      selectedReminder?.value === 'custom'
        ? z
            .union([z.date(), z.null()])
            .refine((date) => date !== null && !isNaN(date.getTime()), {
              message: 'Reminder date is required and must be a valid date',
            })
        : z.date().nullable().optional(),
    board: z
      .string({ required_error: messages.boardIsRequired })
      .min(1, { message: messages.boardIsRequired }),
  });

  type AddTaskFormSchema = z.infer<typeof addTaskFormSchema>;

  // On Change Recurring
  const onChangeRecurring = (option: any, setValue: any) => {
    setSelectedRecurringOption(option);
    if (option?.value !== '') {
      setValue('recurrence_pattern', option?.value);
    } else {
      setValue('recurrence_pattern', '');
    }
  };

  //Board options
  const boardOptions: Record<string, any>[] =
    boardData && boardData?.board_list?.length > 0
      ? boardData?.board_list?.map((board: Record<string, any>) => {
          const boardName = capitalizeFirstLetter(board?.project_name);
          return { name: boardName, value: board?._id, key: board };
        })
      : [];

  // status dropdown options - dynamic - not included completed and archived
  const statusOptions: Record<string, any>[] =
    boardSections && boardSections?.length > 0
      ? boardSections
          ?.filter(
            (section: Record<string, any>) =>
              section?.key !== 'completed' && section?.key !== 'archived'
          ) // Filter out 'completed' and 'archived' sections
          ?.map((section: Record<string, any>) => {
            return {
              value: section?._id,
              name: capitalizeFirstLetter(section?.section_name),
              label: (
                <div
                  className="flex items-center gap-2 rounded-3xl px-[15px] py-[8px] text-xs sm:text-sm"
                  style={{ backgroundColor: section?.color }}
                >
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: section?.test_color }}
                  />
                  <div
                    title={section?.section_name} // Tooltip to show full text
                    className="w-[130px] truncate font-medium"
                    style={{ color: section?.test_color }}
                  >
                    {section?.section_name.length > 20
                      ? `${section?.section_name.slice(0, 18)}...`
                      : section?.section_name}
                  </div>
                </div>
              ),
              section: section,
              key: section?.key,
            };
          })
      : [];

  const allStatusOptions: Record<string, any>[] =
    boardSections && boardSections?.length > 0
      ? boardSections?.map((section: Record<string, any>) => {
          return {
            value: section?._id,
            name: capitalizeFirstLetter(section?.section_name),
            label: (
              <div
                className="flex items-center gap-2 rounded-3xl px-[20px] py-[8px] text-xs sm:text-sm"
                style={{ backgroundColor: section?.color }}
              >
                <div
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: section?.test_color }}
                />
                <div
                  className="font-medium"
                  style={{ color: section?.test_color }}
                >
                  {section?.section_name}
                </div>
              </div>
            ),
            key: section?.key,
          };
        })
      : [];

  // If we create a task from particular section in kanban view than i have to select by default column option

  useEffect(() => {
    // in create mode we have to select bydefault status option as pendding and priority option as low
    if (!editMode) {
      if (column) {
        const defaultSelectedOption: any =
          (statusOptions &&
            statusOptions?.length > 0 &&
            statusOptions?.find(
              (option: any) => option.value === column?._id
            )) ||
          {};

        // setting value in form state
        defaultSelectedOption
          ? setSelectedStatus(defaultSelectedOption)
          : setSelectedStatus(statusOptions?.[0]);
        setValueReference.current(
          'status',
          defaultSelectedOption
            ? defaultSelectedOption?.value
            : statusOptions[0]?.value,
          { shouldValidate: false }
        );
      }
      // else {
      //   const defaultPendingOption: any =
      //     (statusOptions &&
      //       statusOptions?.length > 0 &&
      //       statusOptions?.find((option: any) => option?.key === 'pending')) ||
      //     {};

      //   // setting value in form state
      //   defaultPendingOption && Object?.keys(defaultPendingOption)?.length > 0
      //     ? setSelectedStatus(defaultPendingOption)
      //     : statusOptions &&
      //       statusOptions?.length > 0 &&
      //       setSelectedStatus(statusOptions?.[0] ?? {});
      //   setValueReference.current(
      //     'status',
      //     defaultPendingOption && Object?.keys(defaultPendingOption)?.length > 0
      //       ? defaultPendingOption?.value
      //       : statusOptions?.[0]?.value ?? ''
      //   );
      // }
    }
  }, [column, boardSections]);

  const getMonthlyDates = (startDate: Date, endDate: Date) => {
    if (!startDate || !endDate) return [];

    let currentDate = new Date(
      startDate.getFullYear(),
      startDate.getMonth(),
      1
    );
    const monthlyDates = [];

    while (currentDate <= endDate) {
      monthlyDates.push({
        index: monthlyDates?.length,
        month: currentDate.getMonth() + 1, // 1-based month
        year: currentDate.getFullYear(),
        date: new Date(currentDate),
        isStartMonth:
          currentDate.getMonth() === startDate.getMonth() &&
          currentDate.getFullYear() === startDate.getFullYear(),
        isEndMonth:
          currentDate.getMonth() === endDate.getMonth() &&
          currentDate.getFullYear() === endDate.getFullYear(),
      });

      currentDate.setMonth(currentDate.getMonth() + 1);
    }

    return monthlyDates;
  };
  const [monthlyDates, setMonthlyDates] = useState([]);
  const [weeklyDates, setWeeklyDates] = useState([]);

  useEffect(() => {
    const updatedMonthlyDates: any = getMonthlyDates(
      selectedDate,
      selectedEndDate
    );
    setMonthlyDates(updatedMonthlyDates);
  }, [selectedDate, selectedEndDate]); // Run effect when these values change

  const initialValues = {
    title: editMode && task?.title ? task?.title : '',
    attachments: [],
    board: !isAllTasksModule ? boardId : '',
    due_date:
      editMode && task?.due_date ? moment(task?.due_date).toDate() : null,
    priority:
      editMode && task?.priority ? task?.priority : priorityOptions[0]?.value,
    status: editMode ? task?.status?._id : '',
    description: editMode && task?.agenda ? task?.agenda : '',
    recurrence_pattern: task?.recurrence_pattern
      ? task?.recurrence_pattern
      : '',
    weekly_recurrence_days: task?.weekly_recurrence_days
      ? task?.weekly_recurrence_days
      : [],
    recurrence_start_at_time: null,
    recurrence_end_date: task?.recurrence_end_date
      ? moment(task?.recurrence_end_date).toDate()
      : null,
    recurrence_start_date: task?.recurrence_start_date
      ? moment(task?.recurrence_start_date).toDate()
      : null,

    recurrence_task_due_date:
      monthlyDates?.length > 0
        ? monthlyDates?.map((item: any) => ({
            month: item.month,
            year: item.year,
            day: item?.day,
            date: null, // Default to null initially
          }))
        : [],
    recurrence_default_due_date: task?.recurrence_default_due_date
      ? {
          label: String(task?.recurrence_default_due_date),
          value: String(task?.recurrence_default_due_date),
        }
      : { label: '1', value: '1' },
    // recurrence_interval:
    //   task?.recurrence_interval > -1 ? String(task?.recurrence_interval) : '',
    monthly_recurrence_day_of_month: task?.monthly_recurrence_day_of_month
      ? {
          label: String(task?.monthly_recurrence_day_of_month),
          value: String(task?.monthly_recurrence_day_of_month),
        }
      : { label: '1', value: '1' },
    reminder: task?.reminder ? task?.reminder : 'no_notify',
    repeat: task?.repeat ? task?.repeat : 'no_repetition',
    reminder_user: [],
    reminder_date: null,
    due_date_duration: task?.due_date_duration
      ? String(task?.due_date_duration)
      : '',
    // customValue: task?.customValue > -1 ? String(task?.customValue) : '30',
    // customUnit: task?.customUnit
    //   ? {
    //       label: String(task?.customUnit),
    //       value: String(task?.customUnit),
    //     }
    //   : { value: 'minutes', label: 'Minutes before' },
  };

  useEffect(() => {
    if (monthlyDates?.length > 0) {
      setValueReference.current(
        'recurrence_task_due_date',
        monthlyDates?.map((item: any) => ({
          month: item?.month,
          year: item?.year,
          date: null, // Default to null initially
          day: item?.day,
        }))
      );
    }
  }, [monthlyDates, setValueReference]);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [createTaskFormTourSteps, setCreateTaskFormTourSteps] = useState([]);

  // Handle close tour
  const handleCloseTour = () => {
    dispatch(updateTourStatus({ board: { create_task_tour: true } })).then(
      (result: any) => {
        if (updateTourStatus.fulfilled.match(result)) {
          if (result?.payload?.success) {
            setIsTourOpen(false);
            // Tour comment
            dispatch(getAllTourStatus());
          }
        }
      }
    );
  };

  useEffect(() => {
    if (
      !editMode &&
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.board &&
      !tourStatusData?.board?.create_task_tour
    ) {
      setCreateTaskFormTourSteps([]);
      setIsTourOpen(false);
      const createTaskFormTourStepContent = createTaskFormTourStepsContent(
        handleCloseTour,
        signIn,
        checkPermission
      );
      const updatedCreateTaskFormTourSteps = getStepsByRole(
        createTaskFormTourStepContent
      );
      updatedCreateTaskFormTourSteps?.length > 0 &&
        setCreateTaskFormTourSteps(updatedCreateTaskFormTourSteps);
      updatedCreateTaskFormTourSteps?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData]);

  const handleRemoveMember = (userId: string) => {
    let removedMemberFiltered =
      (selectedMembers &&
        selectedMembers?.length > 0 &&
        selectedMembers?.filter((member: any, index: number) => {
          if (member !== userId) {
            return member;
          }
        })) ||
      [];

    setSelectedMembers(removedMemberFiltered);
  };

  useEffect(() => {
    const filterCustomFields =
      boardDetails?.custom_fields?.filter((filed: any) => filed?.isShow) ?? [];
    setCustomFieldData(
      editMode
        ? task?.custom_fields?.length === 0
          ? filterCustomFields
          : task?.custom_fields
        : filterCustomFields
    );
  }, [editMode, boardDetails?.custom_fields, task?.custom_fields]);

  useEffect(() => {
    const updatedAssigneeObject =
      assignees &&
      assignees?.length > 0 &&
      assignees?.filter((item: Record<string, any>, index: number) => {
        if (
          selectedMembers &&
          selectedMembers.length > 0 &&
          selectedMembers.includes(item?.user_id as never)
        ) {
          return { ...item, _id: item?.user_id };
        }
      });
    setSelectedMembersDetails(updatedAssigneeObject);
  }, [assignees, selectedMembers]);

  const validateCustomReminder = (reminderDate: any) => {
    const dueDate = setWatchReference.current('due_date');
    if (dueDate) {
      const dueMoment = moment(dueDate);
      let reminderTime: moment.Moment | null = null;

      if (reminderDate) {
        reminderTime = moment(reminderDate);
      }
      if (reminderTime && reminderTime.isBefore(moment())) {
        setErrorReference.current('reminder', {
          type: 'manual',
          message: 'Reminder time cannot be in the past',
        });
      } else {
        setClearErrorReference.current('reminder');
      }
    }
  };

  const handleDrop = (acceptedFiles: any) => {
    // Generate preview URLs for valid files
    // const previewURLs = acceptedFiles.map((file: any) => URL.createObjectURL(file));
    checkCommentAttachement(acceptedFiles);

    const newFiles = [
      ...acceptedFiles.map((file: any) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      ),
    ];

    const attachementURL =
      previewAttechmentImage && previewAttechmentImage !== null
        ? [...previewAttechmentImage, ...newFiles]
        : [...newFiles];
    setPreviewAttechmentImage(attachementURL);
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: {
      // 1. Documents
      'application/msword': ['.doc', '.docx'],
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt', '.log', '.ini'], // Combined duplicates for text/plain
      'application/rtf': ['.rtf'],
      'application/vnd.oasis.opendocument.text': ['.odt'],
      'application/epub+zip': ['.epub'],

      // 2. Spreadsheets
      'application/vnd.ms-excel': ['.xls', '.xlsx'],
      'text/csv': ['.csv'], // Use only one key for CSV
      'application/vnd.oasis.opendocument.spreadsheet': ['.ods'],

      // 3. Presentations
      'application/vnd.ms-powerpoint': ['.ppt', '.pptx'],
      'application/vnd.oasis.opendocument.presentation': ['.odp'],
      'application/x-iwork-keynote-sffkey': ['.key'],

      // 4. Images
      'image/*': [
        '.jpeg',
        '.jpg',
        '.png',
        '.gif',
        '.bmp',
        '.tiff',
        '.svg',
        '.webp',
      ],

      // 5. Videos
      'video/*': ['.mp4', '.avi', '.mov', '.wmv', '.mkv', '.flv'],

      // 6. Audio
      'audio/*': ['.mp3', '.wav', '.aac', '.ogg', '.flac'],

      // 7. Code/Programming
      'application/javascript': ['.js'],
      'application/json': ['.json'],
      'application/xml': ['.xml'],
      'text/html': ['.html', '.htm'],
      'text/css': ['.css'],
      'text/yaml': ['.yaml'],
      'application/sql': ['.sql'],
      'text/markdown': ['.md'],
      'text/x-python': ['.py'],
      'text/x-java-source': ['.java'],
      'text/x-c': ['.c', '.cpp'],

      // 8. Design
      'image/vnd.adobe.photoshop': ['.psd'],
      'application/postscript': ['.ai', '.eps'],
      'application/vnd.adobe.xd': ['.xd'],
      'application/figma': ['.fig'],
      'application/sketch': ['.sketch'],
      'application/x-indesign': ['.indd'],

      // 9. Data/Database
      'application/vnd.sqlite3': ['.sqlite'],
      'application/octet-stream': ['.db'],

      // 10. Compressed Files
      'application/zip': ['.zip', '.rar', '.7z', '.tar.gz', '.iso'],

      // 11. Miscellaneous
      'text/calendar': ['.ics'],
      'application/vnd.android.package-archive': ['.apk'],
      'application/x-apple-diskimage': ['.dmg'],
    },
    // maxSize: 200 * 1024 * 1024, // Maximum file size of 200MB
    multiple: true,
    noClick: true,
  };
  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps } = useDropzone(dropzoneOptions);

  // check in comment attachement if any invalide file exits or not
  const checkCommentAttachement = (data: any) => {
    setCommentAttachementInvalid(false);

    if (data?.length > 0) {
      const fileSize = Object.values(data)?.map((file: any) =>
        getFileSize(file)
      );
      const inValidFile = fileSize?.filter(
        (fileInfo) => !checkValidFileSize(fileInfo, 200)
      );
      if (inValidFile?.length > 0) {
        setCommentAttachementInvalid(true);
      }
    }
  };

  const MAX_WORDS = 20;
  const MAX_CHARS = 20; // Limit for a single tag

  // Clear error when the input loses focus
  const handleInputBlur = () => {
    setError(null); // Clear the error when the input loses focus
  };

  // Add the onChange validation
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);

    const trimmedValue = value.trim();

    // Validation
    const wordCount = trimmedValue.split(/\s+/).filter(Boolean).length;
    if (trimmedValue === '') {
      setError('Tag cannot be empty.');
    } else if (trimmedValue.length > MAX_CHARS) {
      setError(`Each tag can have a maximum of ${MAX_CHARS} characters.`);
    } else if (
      tags.some((tag) => tag?.toLowerCase() === trimmedValue.toLowerCase())
    ) {
      setError('This tag already exists.');
    } else {
      setError(null); // No error if the input is valid
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const trimmedValue = inputValue.trim();

      if (trimmedValue !== '' && !error) {
        setTags((prevTags) => [...prevTags, trimmedValue]);
        setInputValue('');
      }
    }
  };

  const handleRemoveTag = (index: number) => {
    setTags((prevTags) => prevTags.filter((_, i) => i !== index));
  };

  const onSubmit = (data: any) => {
    if (commentAttachementInvalid) {
      return;
    }

    const dueDate = setWatchReference.current('due_date');
    const selectedReminderValue = data?.reminder;

    if (selectedReminderValue) {
      const dueMoment = moment(dueDate);
      let reminderTime: moment.Moment | null = null;

      // Determine reminder time based on selected reminder
      if (selectedReminderValue === '10_min_before') {
        reminderTime = dueMoment.subtract(10, 'minutes');
      } else if (selectedReminderValue === '30_min_before') {
        reminderTime = dueMoment.subtract(30, 'minutes');
      } else if (selectedReminderValue === '1_hour_before') {
        reminderTime = dueMoment.subtract(1, 'hour');
      } else if (selectedReminderValue === '1_day_before') {
        reminderTime = dueMoment.subtract(1, 'day');
      } else if (selectedReminderValue === '2_day_before') {
        reminderTime = dueMoment.subtract(2, 'day');
      } else if (selectedReminderValue === '3_day_before') {
        reminderTime = dueMoment.subtract(3, 'day');
      } else if (selectedReminderValue === '1_week_before') {
        reminderTime = dueMoment.subtract(1, 'week');
      } else if (selectedReminderValue === '2_week_before') {
        reminderTime = dueMoment.subtract(2, 'week');
      } else if (selectedReminderValue === 'custom') {
        const reminderDate = data?.reminder_date;
        if (reminderDate) {
          reminderTime = moment(reminderDate);
        }
      }

      // Check if the reminder time is in the past
      if (reminderTime && reminderTime.isBefore(moment())) {
        // Set the error for reminder if the time is in the past
        setErrorReference.current('reminder', {
          type: 'manual',
          message: 'Reminder time cannot be in the past',
        });
        return; // Stop form submission if the error is triggered
      }
    }

    const formData: Record<string, any> = {
      title: data?.title ?? '',
      priority: data?.priority ?? '',
      status: data?.status ?? '',
      due_date: String(data?.due_date),
      board_id: data?.board ?? '',
      agenda: data?.description ?? '',
      comment: '',
      custom_fields:
        customFieldData?.length > 0 ? JSON.stringify(customFieldData) : [],
    };

    const myForm = new FormData();

    if (data.due_date !== null && selectedMembers?.length > 0) {
      formData.reminder_option = data?.reminder ? data?.reminder : null;
      formData.repeat = data?.repeat ? data?.repeat : null;
      // formData.reminder_user = data?.reminder_user?.length
      //   ? JSON.stringify(data.reminder_user)
      //   : '[]'; // Default empty array as a string
      if (Array.isArray(data?.reminder_user)) {
        data?.reminder_user?.forEach((userId: string) => {
          myForm.append('reminder_user', userId);
        });
      }

      if (data?.reminder === 'custom') {
        formData.reminder_date = data?.reminder_date
          ? String(data?.reminder_date)
          : null;
      }
    }
    if (isRecurring) {
      formData.recurrence_pattern = data?.recurrence_pattern
        ? data?.recurrence_pattern
        : null;
      formData.recurrence_start_date = data?.recurrence_start_date
        ? moment(data?.recurrence_start_date).format('DD-MM-YYYY')
        : null;
      formData.recurrence_time = data?.recurrence_start_at_time
        ? moment(data?.recurrence_start_at_time).format('HH:mm')
        : null;

      if (
        !userProfile?.agency_setting ||
        userProfile?.agency_setting === null ||
        userProfile?.agency_setting?.is_custom_recurring === false
      ) {
        formData.due_date_duration = data?.due_date_duration
          ? Number(data?.due_date_duration)
          : '';
      }

      formData.recurrence_end_date = data?.recurrence_end_date
        ? moment(data?.recurrence_end_date).format('DD-MM-YYYY')
        : null;
      // formData.recurrence_interval = data?.recurrence_interval
      //   ? Number(data?.recurrence_interval)
      //   : null;
      // if (data?.recurrence_pattern === 'weekly') {
      //   formData.weekly_recurrence_days = data?.weekly_recurrence_days ?? null;
      // }
      if (
        data?.recurrence_pattern === 'weekly' &&
        Array.isArray(data?.weekly_recurrence_days)
      ) {
        data.weekly_recurrence_days?.forEach((day: string) => {
          myForm.append('weekly_recurrence_days', day);
        });
      }

      if (data?.recurrence_pattern === 'monthly') {
        formData.monthly_recurrence_day_of_month =
          data?.monthly_recurrence_day_of_month
            ? Number(data?.monthly_recurrence_day_of_month.value)
            : null;
      }
      if (
        userProfile?.agency_setting?.is_custom_recurring &&
        data?.recurrence_pattern === 'monthly' &&
        !isEachMonth
      ) {
        formData.recurrence_default_due_date = data?.recurrence_default_due_date
          ? Number(data?.recurrence_default_due_date.value)
          : null;
      }
      if (
        userProfile?.agency_setting?.is_custom_recurring &&
        data?.recurrence_pattern === 'monthly' &&
        isEachMonth
      ) {
        const formattedRecurrenceDates = Array.isArray(
          data?.recurrence_task_due_date
        )
          ? data?.recurrence_task_due_date?.map((item: any) => ({
              month: item?.month,
              year: item?.year,
              date: item?.date ? String(item?.date) : '',
            }))
          : [];

        if (formattedRecurrenceDates?.length > 0) {
          formattedRecurrenceDates.forEach((item: any, index: any) => {
            myForm.append(
              `recurrence_task_due_date[${index}][date]`,
              item?.date ?? null
            );
            myForm.append(
              `recurrence_task_due_date[${index}][year]`,
              item?.year
            );
            myForm.append(
              `recurrence_task_due_date[${index}][month]`,
              item?.month
            );
          });
        }
      }
      if (
        userProfile?.agency_setting?.is_custom_recurring &&
        data?.recurrence_pattern === 'weekly' &&
        isEachWeek
      ) {
        const formattedRecurrenceDates =
          Array.isArray(data?.recurrence_task_due_date) && isEachWeek
            ? data?.recurrence_task_due_date
            : [];

        if (formattedRecurrenceDates?.length > 0) {
          formattedRecurrenceDates.forEach((item: any, index: any) => {
            myForm.append(
              `recurrence_task_due_date[${index}][date]`,
              item?.date ?? ''
            );
            myForm.append(
              `recurrence_task_due_date[${index}][year]`,
              item?.year
            );
            myForm.append(
              `recurrence_task_due_date[${index}][month]`,
              item?.month
            );
            myForm.append(`recurrence_task_due_date[${index}][day]`, item?.day);
          });
        }
      }
    }

    // remove key if its null undefined or ""
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(([_, value]) => {
        return value !== undefined && value !== '';
      })
    );

    // Add data from the 'formData' object to the FormData
    for (const key in filteredFormData) {
      if (Object.prototype.hasOwnProperty.call(filteredFormData, key)) {
        const value = filteredFormData[key];
        myForm.append(key, value);
      }
    }

    // Mentions user data
    const mentionedUsers =
      mentionUser?.length > 0
        ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
        : [];

    myForm.append('mentioned_users', JSON.stringify(mentionedUsers));
    rowData?._id && myForm.append('parent_task', rowData?._id);

    tags?.length > 0 &&
      tags?.map((tag) => {
        myForm.append('tags', tag);
      });

    selectedMembers &&
      selectedMembers?.length > 0 &&
      myForm.append('assign_to', JSON.stringify(selectedMembers));

    if (!editMode) {
      previewAttechmentImage?.length > 0 &&
        previewAttechmentImage?.map((file: any) => {
          myForm.append('attachments', file);
        });
    } else {
      previewAttechmentImage?.length > 0 &&
        previewAttechmentImage?.map((file: any) => {
          if (!file?.preview?.startsWith('blob')) {
            myForm.append('attachments', JSON.stringify(file));
          } else {
            myForm.append('attachments', file);
          }
        });
    }

    if (!editMode) {
      dispatch(postAddTask(myForm)).then((result: any) => {
        if (postAddTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            if (isAllTasksModule) {
              dispatch(
                getAllMyTasks({
                  ...paginationParams,
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                })
              );
              onClose();
              return;
            }
            if (formData?.board_id !== boardId) {
              onClose();
              return;
            }

            if (gridView || rowData?._id) {
              if (gridView && rowData?._id) {
                dispatch(getTaskById({ taskId: rowData?._id }));
                createTask({
                  ...result?.payload?.data,
                  assign_to: selectedMembersDetails,
                  attachment_count: result?.payload?.data?.attachments?.length,
                  comments_count: result?.payload?.data?.comment,
                });
              } else if (gridView && !rowData?._id) {
                createTask({
                  ...result?.payload?.data,
                  assign_to: selectedMembersDetails,
                  attachment_count: result?.payload?.data?.attachments?.length,
                  comments_count: result?.payload?.data?.comment,
                });
              } else if (!gridView && rowData?._id) {
                dispatch(getTaskById({ taskId: rowData?._id }));
                dispatch(
                  getAllTask({
                    page: 1,
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    board_id: boardId,
                    pagination: true,
                  })
                );
              }
            } else {
              dispatch(
                getAllTask({
                  page: 1,
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  board_id: boardId,
                  pagination: true,
                })
              );
            }

            onClose();
          }
        }
      });
    }
  };

  const allOption = {
    label: 'Select all',
    value: '*',
    name: 'Select all',
  };

  const assigneeOptions = [
    // { name: 'All', value: '', label: 'All' },
    ...(selectedMembersDetails && selectedMembersDetails?.length > 0
      ? selectedMembersDetails?.map((assignee: Record<string, any>) => ({
          name: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          label: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          value: assignee?.user_id,
          key: assignee,
        }))
      : []),
  ];

  const optionsWithSelectAll = [allOption, ...assigneeOptions];

  const ValueContainer = ({ children, ...props }: any) => {
    const selectedOptions = props.getValue();
    const hasSelections = selectedOptions.length > 0;

    // Determine the placeholder and truncate it if it’s too long during selected state
    let placeholder = props.selectProps.placeholder || 'Select';

    if (
      hasSelections &&
      placeholder === 'Select assignee' &&
      selectedOptions?.length > 0
    ) {
      // Truncate when displaying selected options count
      placeholder = `Select assignee`;
    } else if (hasSelections && placeholder.length > 15) {
      // Truncate if longer than 15 characters during selected state
      placeholder = `${placeholder.substring(0, 15)}...`;
    }

    return (
      <components.ValueContainer {...props}>
        <div className="flex items-center gap-2 whitespace-nowrap">
          {hasSelections ? (
            <div className="font-medium text-[#4a4a4a]">
              {placeholder}{' '}
              <span className="rounded-full bg-[#8c80d2] px-2 py-1 text-xs font-bold text-white">
                {selectedOptions.length.toString().padStart(2, '0')}
              </span>
            </div>
          ) : (
            <span className="text-[#4a4a4a]">{placeholder}</span>
          )}
          {React.cloneElement(children[1])}
        </div>
      </components.ValueContainer>
    );
  };

  const Option = (props: any) => {
    const { data, isSelected, selectOption, getValue } = props;
    const selectedValues = getValue().map((option: any) => option.value);
    const isAllSelected = selectedValues.length === assigneeOptions.length; // Check if all users are selected

    const handleChange = () => {
      if (data.value === allOption.value) {
        // If "Select All" is clicked, toggle selection
        if (isAllSelected) {
          selectOption([]); // Deselect all
        } else {
          selectOption(assigneeOptions); // Select all
        }
      } else {
        selectOption(data);
      }
    };

    return (
      <components.Option {...props}>
        <div
          className="flex cursor-pointer items-center gap-2"
          onClick={handleChange}
        >
          <Checkbox
            label={data.label}
            checked={
              data.value === allOption.value ? isAllSelected : isSelected
            }
            color="info"
            // variant="flat"
            inputClassName="checkbox-color"
            className=" cursor-pointer [&>label>span]:font-medium"
            labelClassName="text-1.20em md:text-1.20em lg:text-1.20em xl:text-1.20em text-gray-700 dark:text-gray-600 cursor-pointer"
          />
        </div>
      </components.Option>
    );
  };

  const handleKeyDateDown = (e: any) => {
    if (
      !/^[0-9]$/.test(e.key) && // Allow only numbers (0-9)
      e.key !== 'Backspace' && // Allow backspace
      e.key !== 'Delete' && // Allow delete
      e.key !== 'ArrowLeft' && // Allow left arrow
      e.key !== 'ArrowRight' && // Allow right arrow
      e.key !== 'Tab' // Allow tab
    ) {
      e.preventDefault();
    }
  };

  const MultiValue = (props: any) => (
    <components.MultiValue {...props}>
      <div className="flex items-center gap-2">
        {/* <img
            src={props.data.profile}
            alt={props.data.label}
            className="h-6 w-6 rounded-full"
          /> */}
        <span>{props.data.label}</span>
      </div>
    </components.MultiValue>
  );

  useEffect(() => {
    if (
      !defaultRecurrence ||
      Number(defaultRecurrence?.value) < recurrenceDueDay
    ) {
      setValueReference.current('recurrence_default_due_date', {
        label: String(recurrenceDueDay),
        value: String(recurrenceDueDay),
      });
    }
  }, [recurrenceDueDay, defaultRecurrence, setValueReference]);

  if (allTasksLoading && editMode) {
    return (
      <div className="flex h-[100vh] items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <div className="max-h-[670px]">
      <Form<AddTaskFormSchema>
        validationSchema={addTaskFormSchema}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'onSubmit',
          defaultValues: initialValues,
        }}
        className="text-[14px] text-[#9BA1B9] [&_label]:font-medium"
      >
        {({
          register,
          control,
          formState: { errors },
          setValue,
          setError,
          clearErrors,
          getValues,
          watch,
          trigger,
        }) => {
          setValueReference.current = setValue;
          setErrorReference.current = setError;
          setWatchReference.current = watch;
          setClearErrorReference.current = clearErrors;

          return (
            <>
              <Tour
                steps={createTaskFormTourSteps ?? []}
                isOpen={isTourOpen}
                rounded={10}
                closeWithMask={false}
                disableInteraction={true}
                disableKeyboardNavigation={['esc']}
                onRequestClose={handleCloseTour}
                className="poppins_font_number tour-close-button font-semibold text-[#141414]"
              />
              <div className="p-2">
                <SimpleBar className="max-h-[650px]">
                  <div className="flex flex-col gap-5 p-5">
                    <div className="flex flex-col items-center justify-between gap-5 md:flex-row">
                      <div className="flex w-full items-center justify-between gap-5 md:w-auto md:justify-normal">
                        <Text className="text-[20px] font-bold leading-6 text-[#141414]">
                          New Task
                        </Text>
                        <div className=" flex flex-col gap-0.5">
                          <Controller
                            control={control}
                            name="board"
                            render={({ field: { onChange, value } }) => (
                              <Select
                                variant="text"
                                value={value}
                                onChange={(selectedOption: any) => {
                                  if (selectedOption) {
                                    setValue('board', selectedOption ?? '', {
                                      shouldValidate: true,
                                    });
                                    // remove status selection option when board change
                                    setSelectedStatus(null);
                                    setValue('status', '', {
                                      shouldValidate: false,
                                    });
                                    // remove selected members
                                    setSelectedMembers([]);
                                    // api calls for get board details, members and it's sections
                                    dispatch(
                                      getBoardById({
                                        boardId: selectedOption,
                                        isAddTaskForm: true,
                                      })
                                    );
                                    dispatch(
                                      getBoardSectionsById({
                                        board_id: selectedOption,
                                        isAddTaskForm: true,
                                      })
                                    );
                                    dispatch(
                                      getMembersByBoardId({
                                        boardId: selectedOption,
                                        isAddTaskForm: true,
                                      })
                                    );
                                  }
                                }}
                                options={boardOptions}
                                getOptionValue={(option) => option?.value}
                                getOptionDisplayValue={(option: any) =>
                                  option?.name
                                }
                                displayValue={(value) => {
                                  const displayValue = boardOptions?.find(
                                    (option: any) => option?.value === value
                                  );

                                  return displayValue?.name
                                    ? displayValue?.name
                                    : '';
                                }}
                                // error={errors?.board?.message as string}
                                placeholder="Select Board"
                                className="w-[230px] rounded-lg border-[1.5px] border-[#DDDDDD] bg-[#F9FAFB] p-[1px] text-black "
                                selectClassName="truncate max-w-[225px] focus:outline-none focus:ring-0 focus:border-none disabled:!bg-transparent overflow-hidden whitespace-nowrap text-ellipsis"
                                prefix={<Text>Board :</Text>}
                                suffix={<PiCaretDownBold className="h-4 w-4" />}
                              />
                            )}
                          />
                          {errors?.board?.message &&
                            errors?.board?.message !== '' && (
                              <div className="text-xs text-[#EE0000]">
                                {errors?.board?.message}
                              </div>
                            )}
                        </div>
                      </div>
                      <div className=" flex w-full items-center justify-between gap-5 md:w-auto md:justify-normal">
                        <Switch
                          className="create-task-form-tour-step-ten [&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                          variant="active"
                          switchClassName={`${
                            isRecurring ? '!bg-[#362F78]' : '!bg-white'
                          }`}
                          handlerClassName={`${
                            isRecurring ? '!bg-white' : '!bg-[#362F78]'
                          }`}
                          label="Recurring Task"
                          labelClassName="text-[#141414]"
                          labelPlacement="left"
                          onChange={(e) => {
                            const checked = e?.target?.checked;
                            setIsRecurring(checked);
                            if (checked) {
                              setValue('recurrence_pattern', 'daily');
                              setSelectedRecurringOption({
                                name: 'Daily',
                                label: 'Daily',
                                value: 'daily',
                              });
                            } else {
                              setValue('recurrence_pattern', '');
                              setSelectedRecurringOption({
                                name: '',
                                label: '',
                                value: '',
                              });
                            }
                          }}
                          defaultChecked={isRecurring}
                        />
                        <Popover
                          placement="bottom"
                          className="demo_test w-[490px] gap-2"
                          isOpen={isReminder}
                          showArrow={false}
                          content={() => (
                            <div className="flex flex-col items-start gap-5 p-3">
                              <Text className="text-[16px] font-semibold leading-[24px] text-[#141414]">
                                Create reminder
                              </Text>
                              {/* Recipients Field */}
                              <div className="flex flex-col gap-2">
                                {' '}
                                {/* Changed from flex-row to flex-col */}
                                <div className="flex items-center gap-2">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Recipients
                                  </span>
                                  <Controller
                                    control={control}
                                    name="reminder_user"
                                    render={({ field }) => (
                                      <ReactSelect
                                        {...field}
                                        styles={customStyles}
                                        options={optionsWithSelectAll}
                                        isMulti
                                        onChange={(selectedOptions: any) => {
                                          const isAllSelected =
                                            selectedOptions.length ===
                                            assigneeOptions.length + 1; // +1 for "Select All"

                                          if (isAllSelected) {
                                            setValue('reminder_user', []);
                                            setSelectedRecipients([]);
                                            clearErrors('reminder_user');
                                          } else if (
                                            selectedOptions.some(
                                              (option: any) =>
                                                option.value === allOption.value
                                            )
                                          ) {
                                            setValue(
                                              'reminder_user',
                                              assigneeOptions.map(
                                                (option) => option.value
                                              )
                                            );
                                            setSelectedRecipients(
                                              assigneeOptions
                                            );
                                            clearErrors('reminder_user');
                                          } else {
                                            setValue(
                                              'reminder_user',
                                              selectedOptions.map(
                                                (option: any) => option.value
                                              )
                                            );
                                            setSelectedRecipients(
                                              selectedOptions
                                            );
                                            clearErrors('reminder_user');
                                          }
                                        }}
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        components={{
                                          Option,
                                          MultiValue,
                                          ValueContainer,
                                        }}
                                        isClearable={false}
                                        value={selectedRecipients}
                                        className="poppins_font_number react-select-options task-assign w-auto"
                                        classNamePrefix="custom-multi-select"
                                        placeholder="Select assignee"
                                      />
                                    )}
                                  />
                                </div>
                                {/* Ensure the error message is in a block below */}
                                {errors?.reminder_user && (
                                  <p className="text-sm text-red-600">
                                    {errors.reminder_user.message}
                                  </p>
                                )}
                              </div>

                              <div className="flex flex-row space-x-4">
                                <div className="flex flex-col items-start">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Reminder Time
                                  </span>
                                  <Select
                                    options={reminderOptions}
                                    onChange={(event: any) => {
                                      setSelectedReminder(event);
                                      if (event?.value !== '') {
                                        // Set reminder value
                                        setValue('reminder', event?.value);

                                        // If no recipients are selected and the reminder is not "no_notify", set an error
                                        if (
                                          selectedRecipients?.length === 0 &&
                                          event?.value !== 'no_notify'
                                        ) {
                                          setError('reminder_user', {
                                            type: 'manual',
                                            message:
                                              'At least one reminder user is required',
                                          });
                                        } else {
                                          clearErrors('reminder_user');
                                        }

                                        // Check if the reminder is valid based on the due_date
                                        const dueDate = watch('due_date');

                                        if (dueDate) {
                                          // Convert the due date to a moment object for easier manipulation
                                          const dueMoment = moment(dueDate);
                                          let reminderTime: moment.Moment | null =
                                            null;

                                          // Determine reminder time based on selected reminder
                                          if (
                                            event?.value === '10_min_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              10,
                                              'minutes'
                                            );
                                          } else if (
                                            event?.value === '30_min_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              30,
                                              'minutes'
                                            );
                                          } else if (
                                            event?.value === '1_hour_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              1,
                                              'hour'
                                            );
                                          } else if (
                                            event?.value === '1_day_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              1,
                                              'day'
                                            );
                                          } else if (
                                            event?.value === '2_day_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              2,
                                              'day'
                                            );
                                          } else if (
                                            event?.value === '3_day_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              3,
                                              'day'
                                            );
                                          } else if (
                                            event?.value === '1_week_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              1,
                                              'week'
                                            );
                                          } else if (
                                            event?.value === '2_week_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              2,
                                              'week'
                                            );
                                          } else if (
                                            event?.value === 'custom'
                                          ) {
                                            const reminderDate: any =
                                              watch('reminder_date');

                                            if (reminderDate) {
                                              reminderTime =
                                                moment(reminderDate);
                                            }
                                          }

                                          // Validate reminder time
                                          if (
                                            reminderTime &&
                                            reminderTime.isBefore(moment())
                                          ) {
                                            // If the reminder time is in the past, set an error for reminder
                                            setError('reminder', {
                                              type: 'manual',
                                              message:
                                                'Reminder time cannot be in the past',
                                            });
                                          } else {
                                            // Clear the error if valid
                                            clearErrors('reminder');
                                          }
                                        }
                                      } else {
                                        setValue('reminder', '');
                                        clearErrors('reminder');
                                      }
                                    }}
                                    value={selectedReminder}
                                    className="mt-2 w-[200px]"
                                    selectClassName="!text-[#141414] poppins_font_number !bg-white"
                                  />
                                  {errors?.reminder && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {errors.reminder.message}
                                    </p>
                                  )}
                                </div>
                                <div className="flex flex-col items-start">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Repeat
                                  </span>
                                  <Select
                                    options={RepeatOptions}
                                    onChange={(event: any) => {
                                      setSelectedRepetition(event);
                                      if (event?.value !== '') {
                                        // Set reminder value
                                        setValue('repeat', event?.value);
                                        if (
                                          selectedRecipients?.length === 0 &&
                                          event?.value !== 'no_repetition'
                                        ) {
                                          setError('reminder_user', {
                                            type: 'manual',
                                            message:
                                              'At least one reminder user is required',
                                          });
                                        } else {
                                          clearErrors('reminder_user');
                                        }
                                      }
                                    }}
                                    value={selectedRepetition}
                                    className="mt-2 w-[256px]"
                                    selectClassName="!text-[#141414] poppins_font_number !bg-white"
                                  />
                                  {errors?.repeat && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {errors.repeat.message}
                                    </p>
                                  )}
                                </div>
                              </div>
                              {['custom'].includes(selectedReminder?.value) && (
                                <div className="task_form_date_picker_close_button_hide flex flex-col items-start">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Select Reminder Date & Time
                                  </span>
                                  <Controller
                                    name="reminder_date"
                                    control={control}
                                    render={({
                                      field: { value, onChange },
                                    }) => (
                                      <DatePicker
                                        selected={value}
                                        placeholderText={'Select reminder date'}
                                        onChange={onChange}
                                        selectsStart
                                        startDate={value}
                                        minDate={new Date()}
                                        showTimeSelect
                                        isClearable={true}
                                        popperPlacement="bottom-end"
                                        className="mt-2 w-[489px] bg-[#F9FAFB]"
                                        dateFormat={
                                          editMode
                                            ? 'MMM d,yy h:mm'
                                            : 'MMMM d, yyyy h:mm aa'
                                        }
                                        inputProps={{
                                          inputClassName: 'font-sans', // Custom class for the input
                                        }}
                                        showYearDropdown
                                        scrollableYearDropdown
                                        showMonthDropdown
                                        yearDropdownItemNumber={100}
                                      />
                                    )}
                                  />
                                  {errors?.reminder_date && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {errors.reminder_date.message}
                                    </p>
                                  )}
                                </div>
                              )}
                              <div className="flex w-[250px] gap-3">
                                <Button
                                  className="cursor-pointer rounded-lg border border-[#E5E7EB] bg-white text-sm text-[#141414]"
                                  size="DEFAULT"
                                  type="button"
                                  onClick={() => {
                                    setIsReminder(false);
                                    setValue('reminder_date', null);
                                    setValue('reminder', 'no_notify');
                                    setSelectedReminder({
                                      value: 'no_notify',
                                      label: "Don't notify",
                                      name: "Don't notify",
                                    });
                                    setSelectedRepetition({
                                      value: 'no_repetition',
                                      label: 'No repetition',
                                      name: 'No repetition',
                                    });
                                    setValue('repeat', 'no_repetition');
                                    setValue('reminder_user', []);
                                    setSelectedRecipients([]);
                                    clearErrors('reminder');
                                    clearErrors('repeat');
                                    clearErrors('reminder_user');
                                  }}
                                >
                                  Cancel
                                </Button>
                                <Button
                                  className="cursor-pointer rounded-lg bg-[#7667CF] text-[14px] font-normal leading-[19.6px] text-[#FFFFFF]"
                                  size="DEFAULT"
                                  type="button"
                                  onClick={() =>
                                    !errors.reminder &&
                                    !errors.repeat &&
                                    !errors.reminder_user &&
                                    setIsReminder(false)
                                  }
                                >
                                  Save reminder
                                </Button>
                              </div>
                            </div>
                          )}
                        >
                          <Switch
                            className=" create-task-form-tour-step-eleven [&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                            variant="active"
                            switchClassName={`${
                              isReminder ? '!bg-[#362F78]' : '!bg-white'
                            }`}
                            handlerClassName={`${
                              isReminder ? '!bg-white' : '!bg-[#362F78]'
                            }`}
                            label="Task reminder"
                            labelClassName="text-[#141414]"
                            labelPlacement="left"
                            onChange={(e) => setIsReminder(e?.target?.checked)}
                            checked={isReminder}
                            disabled={
                              selectedMembersDetails?.length === 0 ||
                              watch('due_date') === null ||
                              watch('due_date') === undefined
                            }
                          />
                        </Popover>
                      </div>
                    </div>
                    <div className="create-task-form-tour-step-one">
                      <span className="text-[14px] font-medium text-[#141414]">
                        Add Title
                      </span>
                      <Textarea
                        textareaClassName="text-[#141414] poppins_font_number bg-[#F9FAFB]"
                        className="w-full"
                        onKeyDown={handleKeyDown}
                        placeholder="Add your task title here "
                        {...register('title')}
                        rows={2}
                        error={errors?.title?.message}
                      />
                    </div>
                    <div className="create-task-form-tour-step-two">
                      <div
                        className=" flex cursor-pointer items-center justify-between rounded-lg border-[1px] bg-[#F9FAFB] p-3 text-[#141414]"
                        onClick={() => {
                          setshowAddMemberModal(true);
                        }}
                      >
                        <div className="flex gap-3">
                          <FiUsers className="h-[20px] w-[20px]" />
                          <span className="rizzui-input-label block text-[14px] font-semibold text-[#4B5563]">
                            Add assignee(s)
                          </span>
                        </div>
                        <IoMdAdd className="h-[16px] w-[16px]" />
                      </div>
                    </div>
                    {selectedMembersDetails?.length > 0 && (
                      <SimpleBar
                        className={`${
                          selectedMembersDetails?.length > 3 ? 'max-h-40' : ''
                        } `}
                      >
                        <div className="rounded-lg border-[1px]">
                          {' '}
                          {selectedMembersDetails?.map((member: any, index) => (
                            <div
                              className={`flex items-center justify-between p-3 text-[#141414] ${
                                selectedMembersDetails?.length - 1 !== index &&
                                'border-b-[1px]'
                              }`}
                              key={index}
                            >
                              <div className="flex items-center gap-3">
                                <Avatar
                                  src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                  name={
                                    capitalizeFirstLetter(member?.first_name) +
                                    ' ' +
                                    capitalizeFirstLetter(member?.last_name)
                                  }
                                  className="!h-[30px] !w-[30px] text-white"
                                />
                                <span className="rizzui-input-label block text-[14px] font-semibold">
                                  {capitalizeFirstLetter(member?.first_name) +
                                    ' ' +
                                    capitalizeFirstLetter(member?.last_name)}
                                </span>
                              </div>
                              <RxCross2
                                className="h-[20px] w-[20px] cursor-pointer"
                                onClick={() => handleRemoveMember(member?._id)}
                              />
                            </div>
                          ))}
                        </div>
                      </SimpleBar>
                    )}
                    <div
                      className={`flex flex-col gap-6 md:flex-row ${
                        error ? 'items-start' : 'items-center'
                      }`}
                    >
                      <div className="create-task-form-tour-step-four flex w-full flex-col gap-0.5">
                        <Controller
                          control={control}
                          name="status"
                          render={({ field: { onChange, value } }) => (
                            <>
                              {boardSectionsLoader ? (
                                <SelectLoader isNotFirstSkeletonShow={true} />
                              ) : (
                                <Select
                                  variant="text"
                                  value={selectedStatus}
                                  onChange={(selectedOption: any) => {
                                    setSelectedStatus(selectedOption);
                                    setValue('status', selectedOption?.value);
                                    setError('status', { message: '' });
                                  }}
                                  options={statusOptions}
                                  placeholder="Select status"
                                  selectClassName={`!py-0 h-10`}
                                  className={`rounded-lg border-[1px]`}
                                  style={{
                                    backgroundColor:
                                      selectedStatus?.section?.color,
                                  }}
                                  suffix={
                                    <PiCaretDownBold className="h-3 w-3" />
                                  }
                                />
                              )}
                            </>
                          )}
                        />
                        {errors?.status?.message &&
                          errors?.status?.message !== '' && (
                            <div className="text-xs text-[#EE0000]">
                              {errors?.status?.message}
                            </div>
                          )}
                      </div>
                      <div className="create-task-form-tour-step-five flex w-full flex-col gap-0.5">
                        <Controller
                          control={control}
                          name="priority"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              variant="text"
                              onChange={(selectedOption: any) => {
                                onChange(selectedOption?.value);
                              }}
                              value={priorityOptions?.find(
                                (option) => option.value === value
                              )}
                              options={priorityOptions}
                              placeholder="Select priority"
                              className={`rounded-lg border-[1px]`}
                              selectClassName={`!py-0 h-10 ${priorityOptions?.find(
                                (option) => option.value === value
                              )?.color}`}
                              suffix={<PiCaretDownBold className="h-3 w-3" />}
                            />
                          )}
                        />
                        {errors?.priority?.message &&
                          errors?.priority?.message !== '' && (
                            <div className="text-xs text-[#EE0000]">
                              {errors?.priority?.message}
                            </div>
                          )}
                      </div>

                      <div className="create-task-form-tour-step-nine w-full">
                        <Input
                          type="text"
                          inputClassName="text-[#141414] poppins_font_number"
                          className="poppins_font_number flex-1 border-none bg-[#F9FAFB] text-[14px] text-[#141414] focus:outline-none"
                          placeholder=" # Add Tags"
                          value={inputValue}
                          onKeyDown={handleAddTag}
                          onChange={handleInputChange}
                          onBlur={handleInputBlur}
                        />
                        {error && (
                          <span className="mt-1 text-[12px] text-red-500">
                            {error}
                          </span>
                        )}
                      </div>
                    </div>
                    {tags?.length > 0 && (
                      <div className="flex w-full flex-wrap gap-2">
                        {tags?.map((tag, index) => (
                          <div
                            key={index}
                            className="flex max-w-full items-center gap-2 break-words rounded-md bg-[#E4E7EB] px-3 py-1 text-sm font-medium text-[#4A5568] dark:bg-[#2D3748] dark:text-[#CBD5E0]"
                          >
                            <span className="break-all">{tag}</span>
                            <RxCross2
                              className="h-4 w-4 cursor-pointer text-[#141414]"
                              onClick={() => handleRemoveTag(index)}
                            />
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="create-task-form-tour-step-three task_form_date_picker_close_button_hide">
                      <span className="text-[14px] font-medium text-[#141414]">
                        Select Due Date & Time
                      </span>
                      <Controller
                        name="due_date"
                        control={control}
                        render={({ field: { value, onChange } }) => (
                          <DatePicker
                            selected={value}
                            placeholderText={'Select due date'}
                            onChange={onChange}
                            showYearDropdown
                            scrollableYearDropdown
                            showMonthDropdown
                            yearDropdownItemNumber={100}
                            selectsStart
                            startDate={value}
                            minDate={new Date()}
                            showTimeSelect
                            isClearable={true}
                            popperPlacement="bottom-start"
                            className="bg-[#F9FAFB]"
                            dateFormat={
                              editMode
                                ? 'MMM d,yy h:mm'
                                : 'MMMM d, yyyy h:mm aa'
                            }
                            inputProps={{
                              inputClassName: 'font-sans', // Custom class for the input
                            }}
                          />
                        )}
                      />
                    </div>
                    <div>
                      <div className="flex flex-wrap gap-4">
                        <div className="flex items-center" {...getRootProps()}>
                          <input
                            {...getInputProps()}
                            ref={commentAttachmentRef}
                          />
                          <Button
                            size="lg"
                            className="create-task-form-tour-step-seven h-10 items-center gap-2 whitespace-nowrap rounded-lg border border-[#6875F5] bg-transparent p-3 text-[#6875F5] marker:flex"
                            onClick={() =>
                              commentAttachmentRef?.current?.click()
                            }
                          >
                            <ImAttachment className="h-4 w-4 text-[#6875F5]" />
                            <span className="text-sm"> Attachments</span>
                          </Button>
                        </div>
                        {previewAttechmentImage &&
                          previewAttechmentImage != null &&
                          previewAttechmentImage?.length > 0 &&
                          previewAttechmentImage?.map(
                            (image: any, index: number) => {
                              const fileType = getFileType(image?.name);
                              const color = getColor(fileType);
                              return (
                                <div
                                  className={`flex max-h-10 items-center gap-1 rounded-full p-2`}
                                  style={{
                                    backgroundColor: color?.bgColor,
                                    color: color?.textColor,
                                  }}
                                  key={index}
                                >
                                  <CustomFileIcons
                                    iconClassName="!w-5 !h-4"
                                    key={index}
                                    fileType={fileType}
                                  />
                                  <p className="max-w-[200px] truncate !font-sans text-[14px]">
                                    {image?.name}
                                  </p>
                                  {!task?.mark_as_done && (
                                    <RxCross2
                                      className="h-4 w-4 cursor-pointer"
                                      onClick={() => {
                                        // filter out removed file from preview image state
                                        const updatedFiles =
                                          previewAttechmentImage?.length > 0 &&
                                          previewAttechmentImage?.filter(
                                            (file: any) => {
                                              if (
                                                file?.preview !== image?.preview
                                              ) {
                                                return file;
                                              }
                                            }
                                          );
                                        checkCommentAttachement(updatedFiles);
                                        setPreviewAttechmentImage(updatedFiles);
                                        setValue('attachments', updatedFiles, {
                                          shouldValidate: true,
                                        });
                                      }}
                                    />
                                  )}
                                </div>
                              );
                            }
                          )}
                      </div>
                      {commentAttachementInvalid && (
                        <p className="pt-1 text-red">
                          {messages.taskAttachementMaxFileSize}
                        </p>
                      )}
                    </div>
                    <span className="border" />
                    <div className="create-task-form-tour-step-six">
                      <label className="text-[14px] font-semibold text-[#141414]">
                        Description
                      </label>
                      <Controller
                        control={control}
                        name="description"
                        render={({ field: { onChange, value } }) => (
                          <QuillEditor
                            value={value}
                            onChange={onChange}
                            onKeyDown={handleKeyDown}
                            placeholder="Add description"
                            // label="Description"
                            className="quill-editor-font poppins_font_number col-span-full bg-[#F9FAFB] text-[#141414] [&_.ql-editor]:min-h-[100px]"
                          />
                        )}
                      />
                    </div>

                    {customFieldData?.length > 0 && (
                      <>
                        {customFieldData?.map((field: any, index: number) => {
                          const dropdownOption = field?.options?.map(
                            (option: string) => ({
                              value: option,
                              label: capitalizeFirstLetter(option),
                            })
                          );
                          return (
                            <div key={index}>
                              {field?.fieldType !== 'checkbox' && (
                                <label className="mb-1 text-[14px] font-semibold text-[#141414]">
                                  {capitalizeFirstLetter(field?.fieldName)}
                                </label>
                              )}
                              {field?.fieldType === 'dropdown' ? (
                                <Select
                                  options={dropdownOption}
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e.value,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  value={
                                    customFieldData &&
                                    dropdownOption?.find(
                                      (option: any) =>
                                        option.value ===
                                        customFieldData[index]?.value
                                    )
                                  }
                                  placeholder="Select Field"
                                  className="w-full !text-[#141414]"
                                  selectClassName="!text-[#141414] bg-[#F9FAFB] poppins_font_number"
                                  disabled={taskData?.task?.mark_as_done}
                                />
                              ) : field?.fieldType === 'textarea' ? (
                                <Textarea
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e.target.value,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  defaultValue={field?.value}
                                  onKeyDown={handleKeyDown}
                                  className="w-full bg-[#F9FAFB] [&_.rizzui-textarea-field]:!resize-none"
                                  textareaClassName="text-[#141414] poppins_font_number"
                                  disabled={taskData?.task?.mark_as_done}
                                />
                              ) : field?.fieldType === 'checkbox' ? (
                                <Checkbox
                                  inputClassName="checkbox-color"
                                  label={capitalizeFirstLetter(
                                    field?.fieldName
                                  )}
                                  checked={field?.value}
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e?.target?.checked,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  className="text-[14px] font-bold"
                                  labelClassName="ml-2 text-[#141414]"
                                  disabled={taskData?.task?.mark_as_done}
                                />
                              ) : field?.fieldType === 'date' ? (
                                <DatePicker
                                  className="date-picker bg-[#F9FAFB] text-[#141414]"
                                  inputProps={{
                                    inputClassName: 'poppins_font_number',
                                  }}
                                  selected={
                                    field?.value ? new Date(field?.value) : null
                                  }
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  dateFormat="MMMM dd, yyyy"
                                  disabled={taskData?.task?.mark_as_done}
                                  showYearDropdown
                                  scrollableYearDropdown
                                  showMonthDropdown
                                  yearDropdownItemNumber={100}
                                />
                              ) : (
                                <Input
                                  type={field?.fieldType}
                                  defaultValue={field?.value}
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e.target.value,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  onKeyDown={handleKeyDown}
                                  inputClassName="text-[#141414] poppins_font_number bg-[#F9FAFB]"
                                  className="w-full"
                                  disabled={taskData?.task?.mark_as_done}
                                />
                              )}
                            </div>
                          );
                        })}
                      </>
                    )}

                    {isRecurring && (
                      <div className=" flex flex-col  gap-5 rounded-lg border border-gray-300 bg-[#F9FAFB] p-3">
                        <div className="flex w-full items-center gap-3">
                          <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                            Setup Recurring Task
                          </span>
                          <Select
                            options={RecurringArray}
                            onChange={(event) => {
                              onChangeRecurring(event, setValue);
                              setValue('recurrence_task_due_date', []);
                            }}
                            value={selectedRecurringOption}
                            className="w-[6.6rem]"
                            optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                            selectClassName="!text-[#5850EC] border-[#5850EC] poppins_font_number focus:border-[#5850EC] hover:border-[#5850EC] !bg-white"
                          />
                        </div>

                        {/* Repeat every and End date */}
                        {['daily', 'weekly', 'monthly'].includes(
                          selectedRecurringOption?.value
                        ) && (
                          <>
                            <div className="flex flex-col  gap-4 sm:flex-row sm:flex-wrap">
                              <div className="w-[145px]">
                                <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  Starts from
                                </span>
                                <Controller
                                  name="recurrence_start_date"
                                  control={control}
                                  render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                      placeholderText="Select date"
                                      popperPlacement="auto-end"
                                      selected={value}
                                      showYearDropdown
                                      scrollableYearDropdown
                                      showMonthDropdown
                                      yearDropdownItemNumber={100}
                                      inputProps={{
                                        inputClassName: 'bg-white',
                                        error: errors?.recurrence_start_date
                                          ?.message as string,
                                      }}
                                      onChange={(date: any) => {
                                        setValue('recurrence_start_date', date);
                                        setSelectedDate(date);
                                        clearErrors('recurrence_start_date');
                                        // if (watch('recurrence_start_at_time')) {
                                        //   setValue(
                                        //     'recurrence_start_at_time',
                                        //     null
                                        //   );
                                        // }
                                        setIsEachWeek(false);
                                        setIsEachWeekModal(false);
                                        setValue(
                                          'recurrence_task_due_date',
                                          []
                                        );
                                        if (date) {
                                          const maxAllowedEndDate = new Date(
                                            date
                                          );
                                          maxAllowedEndDate.setFullYear(
                                            maxAllowedEndDate.getFullYear() + 1
                                          );

                                          if (
                                            (watch('recurrence_end_date') ??
                                              new Date(0)) > maxAllowedEndDate
                                          ) {
                                            setValue(
                                              'recurrence_end_date',
                                              maxAllowedEndDate
                                            );
                                          }
                                        }
                                      }}
                                      selectsStart
                                      startDate={value}
                                      minDate={new Date()}
                                      maxDate={watch('recurrence_end_date')}
                                      // dateFormat="MMMM dd, yyyy"
                                      className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                    />
                                  )}
                                />
                              </div>

                              <div className="w-[145px]">
                                <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  Ends on
                                </span>
                                <Controller
                                  name="recurrence_end_date"
                                  control={control}
                                  render={({ field: { value, onChange } }) => {
                                    const startDate =
                                      watch('recurrence_start_date') ||
                                      new Date(); // Ensure a valid date
                                    const maxEndDate = new Date(startDate);
                                    maxEndDate.setFullYear(
                                      maxEndDate.getFullYear() + 1
                                    );

                                    return (
                                      <DatePicker
                                        placeholderText="Select date"
                                        selected={value}
                                        showYearDropdown
                                        scrollableYearDropdown
                                        showMonthDropdown
                                        yearDropdownItemNumber={100}
                                        inputProps={{
                                          inputClassName: 'bg-white',
                                          error: errors?.recurrence_end_date
                                            ?.message as string,
                                        }}
                                        // onChange={onChange}
                                        onChange={(date: any) => {
                                          setIsEachWeek(false);
                                          setValue(
                                            'recurrence_task_due_date',
                                            []
                                          );
                                          setIsEachWeekModal(false);
                                          setValue('recurrence_end_date', date);
                                          setSelectedEndDate(date); // Update local state
                                          clearErrors('recurrence_end_date');
                                          setValue('recurrence_end_date', date); // Update form value
                                        }}
                                        selectsStart
                                        startDate={value}
                                        minDate={startDate}
                                        maxDate={maxEndDate}
                                        className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                      />
                                    );
                                  }}
                                />
                              </div>

                              {selectedRecurringOption?.value === 'monthly' && (
                                <div>
                                  <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Select Day
                                  </span>
                                  <div className="mt-2 flex items-center gap-1">
                                    <Controller
                                      name="monthly_recurrence_day_of_month"
                                      control={control}
                                      render={({
                                        field: { onChange, value },
                                      }) => (
                                        <Select
                                          options={monthDate}
                                          onChange={onChange}
                                          value={value}
                                          placeholder="Select date"
                                          className="w-[68px]"
                                          optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                          selectClassName="!text-[#111928] border-[#E5E7EB] font-medium text-sm leading-[19.6px] h-10 border rounded-[10px] font-['Raleway'] focus:border-[#111928] hover:border-[#111928] !bg-white"
                                          // disabled={isDisable}
                                        />
                                      )}
                                    />
                                    <p className="font-['Raleway'] text-[12px] font-normal leading-[14.4px] text-[#111928]">
                                      of every month
                                    </p>
                                  </div>
                                  {errors?.monthly_recurrence_day_of_month && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {
                                        errors?.monthly_recurrence_day_of_month
                                          ?.message as string
                                      }
                                    </p>
                                  )}
                                </div>
                              )}

                              <div className="w-[145px]">
                                <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  At Time
                                </span>
                                <Controller
                                  name="recurrence_start_at_time"
                                  control={control}
                                  render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                      placeholderText="Start time"
                                      popperPlacement="auto-end"
                                      selected={value}
                                      inputProps={{
                                        inputClassName: 'bg-white',
                                        error: errors?.recurrence_start_at_time
                                          ?.message as string,
                                      }}
                                      onChange={(date: any) => {
                                        setValue(
                                          'recurrence_start_at_time',
                                          date
                                        );
                                        clearErrors('recurrence_start_at_time');
                                      }}
                                      selectsStart
                                      startDate={value}
                                      // minTime={getMinTime()}
                                      // maxTime={getMaxTime()}
                                      showTimeSelect
                                      showTimeSelectOnly
                                      dateFormat="hh:mm aa"
                                      className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                    />
                                  )}
                                />
                              </div>
                              {(!userProfile?.agency_setting ||
                                userProfile?.agency_setting === null ||
                                userProfile?.agency_setting
                                  ?.is_custom_recurring === false) && (
                                <div className="w-[145px]">
                                  <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Due Date Duration
                                  </span>
                                  <Input
                                    type="text" // Keep it text to avoid decimal inputs on some browsers
                                    inputClassName="text-black bg-white"
                                    className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                    onKeyDown={handleKeyDateDown} // Restricts non-numeric characters
                                    placeholder="Due in (days)"
                                    {...register('due_date_duration')}
                                    error={errors?.due_date_duration?.message}
                                  />
                                </div>
                              )}
                              {selectedRecurringOption?.value === 'weekly' && (
                                <div className="w-[235px]">
                                  <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Days of the week
                                  </span>
                                  <div className="mt-2 flex gap-1">
                                    {weekdays.map((day) => (
                                      <Controller
                                        key={day.value}
                                        control={control}
                                        name="weekly_recurrence_days"
                                        render={({
                                          field: { value, onChange },
                                        }) => (
                                          <label
                                            className={`flex h-[40px] w-[32px] cursor-pointer items-center justify-center rounded-full border ${
                                              value?.includes(day.value)
                                                ? 'bg-[#EDEBFE] text-[#42389D]'
                                                : 'bg-white text-[#4B5563]'
                                            }`}
                                          >
                                            <input
                                              type="checkbox"
                                              className="hidden"
                                              checked={value?.includes(
                                                day.value
                                              )}
                                              onChange={(e) => {
                                                setIsEachWeek(false);
                                                setValue(
                                                  'recurrence_task_due_date',
                                                  []
                                                );
                                                setIsEachWeekModal(false);
                                                const isChecked =
                                                  e.target.checked;
                                                const newValues = isChecked
                                                  ? [
                                                      ...(value || []),
                                                      day.value,
                                                    ] // Add selected day
                                                  : (value || []).filter(
                                                      (v: any) =>
                                                        v !== day.value
                                                    ); // Remove unselected day
                                                onChange(newValues);
                                              }}
                                            />
                                            {day.name}
                                          </label>
                                        )}
                                      />
                                    ))}
                                  </div>
                                  {errors.weekly_recurrence_days && (
                                    <p className="mt-1 text-sm text-red-600">
                                      {errors.weekly_recurrence_days.message}
                                    </p>
                                  )}
                                </div>
                              )}
                              {userProfile?.agency_setting
                                ?.is_custom_recurring &&
                                selectedRecurringOption?.value ===
                                  'monthly' && (
                                  <div>
                                    <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                      Default due day
                                    </span>
                                    <div className="mt-2 flex items-center gap-1">
                                      <Controller
                                        name="recurrence_default_due_date"
                                        control={control}
                                        render={({
                                          field: { onChange, value },
                                        }) => {
                                          const selectedDay: any =
                                            Number(
                                              watch(
                                                'monthly_recurrence_day_of_month'
                                              )?.value
                                            ) || 1;

                                          setRecurrenceDueDay(selectedDay);
                                          setDefaultRecurrence(
                                            watch('recurrence_default_due_date')
                                          );

                                          return (
                                            <Select
                                              options={monthDate?.filter(
                                                (date) =>
                                                  Number(date.value) >=
                                                  selectedDay
                                              )}
                                              onChange={onChange}
                                              value={value}
                                              placeholder="Select date"
                                              className="w-[68px]"
                                              disabled={isEachMonth}
                                              optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                              selectClassName={`!text-[#111928] border-[#E5E7EB] font-medium text-sm leading-[19.6px] h-10 border rounded-[10px] font-['Raleway'] focus:border-[#111928] hover:border-[#111928] !bg-white ${
                                                isEachMonth
                                                  ? 'opacity-50 cursor-not-allowed'
                                                  : ''
                                              }`}
                                            />
                                          );
                                        }}
                                      />

                                      <p className="font-['Raleway'] text-[12px] font-normal leading-[14.4px] text-[#111928]">
                                        of every month
                                      </p>
                                    </div>
                                    {errors?.recurrence_default_due_date && (
                                      <p className="mt-2 text-sm text-red-600">
                                        {
                                          errors?.recurrence_default_due_date
                                            ?.message as string
                                        }
                                      </p>
                                    )}
                                  </div>
                                )}
                            </div>
                            {userProfile?.agency_setting?.is_custom_recurring &&
                              selectedRecurringOption?.value === 'monthly' && (
                                <div>
                                  <TailwindSwitch
                                    isRecurringType="monthly"
                                    label="Set different Due date & time for each month"
                                    defaultChecked={isEachMonth}
                                    onToggle={setIsEachMonth}
                                    recurrenceStartDate={selectedDate}
                                    recurrenceEndDate={selectedEndDate}
                                  />
                                  {isEachMonth && (
                                    <div className="mt-3 grid w-fit grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-3">
                                      {monthlyDates?.map(
                                        (item: any, index: any) => (
                                          <div key={index} className="mt-2">
                                            <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                              {new Date(
                                                item?.date
                                              ).toLocaleString('en-US', {
                                                month: 'short',
                                                year: 'numeric',
                                              })}
                                            </span>
                                            <Controller
                                              name={`recurrence_task_due_date.${index}.date`}
                                              control={control}
                                              render={({
                                                field: { value, onChange },
                                              }) => {
                                                const endDate = new Date(
                                                  item.year,
                                                  item.month,
                                                  0
                                                ); // Last day of the month
                                                return (
                                                  <DatePicker
                                                    placeholderText="Select Due Date"
                                                    popperPlacement="auto-end"
                                                    showYearDropdown
                                                    scrollableYearDropdown
                                                    showMonthDropdown
                                                    yearDropdownItemNumber={100}
                                                    selected={value || null} // Keep `null` if no date selected
                                                    onChange={(date) => {
                                                      const prevDates =
                                                        watch(
                                                          'recurrence_task_due_date'
                                                        ) ?? [];

                                                      // Ensure all indexes exist with default month/year values
                                                      const updatedDates: any =
                                                        monthlyDates.map(
                                                          (
                                                            item: any,
                                                            i: any
                                                          ) => ({
                                                            month: item.month,
                                                            year: item.year,
                                                            date:
                                                              i === index
                                                                ? date || null
                                                                : prevDates[i]
                                                                    ?.date ||
                                                                  null,
                                                          })
                                                        );

                                                      setValue(
                                                        'recurrence_task_due_date',
                                                        updatedDates
                                                      );
                                                    }}
                                                    selectsStart
                                                    startDate={value}
                                                    showTimeSelect
                                                    minDate={
                                                      item.isStartMonth
                                                        ? new Date(
                                                            item.year,
                                                            item.month - 1,
                                                            watch(
                                                              'recurrence_start_date'
                                                            )?.getDate() || 1
                                                          )
                                                        : new Date(
                                                            item.year,
                                                            item.month - 1,
                                                            1
                                                          )
                                                    }
                                                    maxDate={endDate}
                                                    dateFormat="MMM dd, yyyy h:mm aa"
                                                    className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                                    calendarClassName="w-[420px]"
                                                  />
                                                );
                                              }}
                                            />
                                          </div>
                                        )
                                      )}
                                    </div>
                                  )}
                                </div>
                              )}
                            {signIn?.userProfile?.agency_setting
                              ?.is_custom_recurring &&
                              selectedRecurringOption?.value === 'weekly' && (
                                <div className="mt-5">
                                  <div className="flex gap-2 ">
                                    <TailwindSwitch
                                      isRecurringType="weekly"
                                      label="Set different Due date for each week"
                                      defaultChecked={isEachWeek}
                                      onToggle={setIsEachWeek}
                                      recurrenceStartDate={selectedDate}
                                      recurrenceEndDate={selectedEndDate}
                                      selectedDays={watch(
                                        'weekly_recurrence_days'
                                      )}
                                      editOpen={
                                        getValues()?.recurrence_task_due_date
                                          ?.length === 0
                                      }
                                      setIsEachWeekModal={setIsEachWeekModal}
                                    />
                                    {isEachWeek && (
                                      <span
                                        onClick={() =>
                                          isEachWeek && setIsEachWeekModal(true)
                                        }
                                        className="flex h-6 cursor-pointer items-center justify-center text-black"
                                      >
                                        <FiEdit size={20} />
                                      </span>
                                    )}
                                  </div>

                                  {isEachWeekModal &&
                                    createPortal(
                                      <div>
                                        <div className="fixed inset-0 z-[999] flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                                          <div
                                            className="relative overflow-visible rounded-lg bg-white shadow-lg "
                                            style={{ width: '1000px' }}
                                          >
                                            {isEachWeek && (
                                              <WeeklyRecurring
                                                onClose={() => {
                                                  setIsEachWeek(false);
                                                  setIsEachWeekModal(false);
                                                }}
                                                onModalClose={() =>
                                                  setIsEachWeekModal(false)
                                                }
                                                isEachWeek={isEachWeek}
                                                setIsEachWeek={setIsEachWeek}
                                                selectedDate={selectedDate}
                                                selectedEndDate={
                                                  selectedEndDate
                                                }
                                                selectedDays={watch(
                                                  'weekly_recurrence_days'
                                                )}
                                                defineValue={setValue}
                                                setWeeklyDates={setWeeklyDates}
                                                setAddDateAgain={
                                                  getValues()
                                                    ?.recurrence_task_due_date
                                                }
                                                isEdit={
                                                  (getValues()
                                                    ?.recurrence_task_due_date
                                                    ?.length ?? 0) > 0
                                                }
                                                isEditVal={
                                                  getValues()
                                                    ?.recurrence_task_due_date ??
                                                  []
                                                }
                                                setIsEachWeekModal={
                                                  setIsEachWeekModal
                                                }
                                              />
                                            )}
                                          </div>
                                        </div>
                                      </div>,
                                      document.body
                                    )}
                                </div>
                              )}
                          </>
                        )}
                      </div>
                    )}
                    <div className="flex gap-6">
                      <Button
                        className="w-1/2 cursor-pointer rounded-lg border border-[#E5E7EB] bg-white text-sm text-[#141414]"
                        size="DEFAULT"
                        type="button"
                        onClick={closeModal}
                      >
                        Cancel
                      </Button>
                      <Button
                        className="w-1/2 cursor-pointer rounded-lg bg-[#8C80D2] text-sm text-white"
                        size="DEFAULT"
                        type="submit"
                        disabled={taskData?.loading}
                      >
                        Create Task
                        {taskData?.loading && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                    </div>
                  </div>
                </SimpleBar>
              </div>
            </>
          );
        }}
      </Form>
      {/* </SimpleBar> */}

      {showAddMemberModal && (
        <div>
          <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-hidden rounded-lg bg-white shadow-lg "
              style={{ width: '600px', height: '475px' }}
            >
              {showAddMemberModal && (
                <AddMembers
                  onClose={() => setshowAddMemberModal(false)}
                  selectedMembers={selectedMembers}
                  setSelectedMembers={setSelectedMembers}
                  formPage={true}
                  addTaskMember={true}
                  isAddTaskForm={true}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddTaskForm;
