'use client';

import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { ConfirmationTimerModal } from '@/app/shared/confirmationTimerModal';
import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import TrashIcon from '@/components/icons/trash';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import { Text, Title } from '@/components/ui/text';
import { messages } from '@/config/messages';
import { routes } from '@/config/routes';
import socket from '@/io';
import '@/layouts/helium/style.css';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import { getSettingData } from '@/redux/slices/user/setting/settingSlice';
import {
  getAllAssignees,
  getMembersByBoardId,
} from '@/redux/slices/user/task/boardSlice';
import {
  duplicateAddTask,
  getAllCommentsById,
  getAllTask,
  getmyTimerLogs,
  getTaskById,
  getTimerLogs,
  patchEditTask,
  postAddComments,
  postAddTask,
  postLeaveTask,
  taskTimerStartAndStop,
  updateCommentData,
} from '@/redux/slices/user/task/taskSlice';
import { putTaskKanbanStatusChange } from '@/redux/slices/user/task/taskStatusSlice';
import {
  removeActiveTimerData,
  removeTrackedHourDetails,
  taskTimeTrackedHistory,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import cn from '@/utils/class-names';
import {
  calculateTotalTimeInSeconds,
  capitalizeFirstLetter,
  checkValidFileSize,
  convertSecondsToTime,
  formatTime,
  getColor,
  getFileSize,
  getFileType,
  handleKeyDown,
  updateMessageFormatWithMentionUser,
} from '@/utils/common-functions';
import { getRelativeTime } from '@/utils/get-relative-time';
import {
  createTaskFormTourStepsContent,
  getStepsByRole,
} from '@/utils/tour-steps/tour-steps';
import Calendar from '@public/assets/images/Calendar.png';
import Clock from '@public/assets/images/Clock.png';
import Glyph from '@public/assets/images/Glyph.png';
import morehorizontal from '@public/assets/images/More horizontal (1).png';
import Tagss from '@public/assets/images/Tags.png';
import Users from '@public/assets/images/Users.png';
import backIcon from '@public/assets/images/backIcon.png';
import timelapse from '@public/assets/images/timelapse.png';
import attachmentsIcon from '@public/assets/svgs/Attachment.svg';
import axios from 'axios';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Fragment, useEffect, useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Controller, SubmitHandler } from 'react-hook-form';
import { FaArrowRight, FaRegStopCircle } from 'react-icons/fa';
import { LuUser2 } from 'react-icons/lu';
import {
  PiCalendarBlankLight,
  PiCaretDownBold,
  PiDownloadSimpleBold,
} from 'react-icons/pi';
import { Mention, MentionsInput } from 'react-mentions';
import { useDispatch, useSelector } from 'react-redux';
import {
  ActionIcon,
  Avatar,
  Badge,
  Button,
  Input,
  Popover,
  Radio,
  Switch,
  Tooltip,
} from 'rizzui';
import SimpleBar from 'simplebar-react';
import { z } from 'zod';
import sendbutton from '../../../../../../public/assets/svgs/send-button.svg';
import { checkPermission } from '../../roles-permissions/utils';
import { ConfirmationTaskDeleteModal } from './delete-task-confirmation-modal';
import EditTaskForm from './edit-task-form';
import TimerForm from './timer-form';
import { BiChevronDown, BiChevronUp } from 'react-icons/bi';
import { debounce } from 'lodash';
import { FiStopCircle } from 'react-icons/fi';
import Profile from '@public/dummyprofile.jpg';
import { GoDotFill } from 'react-icons/go';

interface Status {
  _id: string;
}

interface Assignee {
  _id: string;
}

interface DuplicateTaskSchema {
  _id: string;
  title: string;
  agenda?: string;
  priority: string;
  board_id: string;
  duplicated_from: string;
  status: Status;
  due_date?: string | null;
  assign_to?: Assignee[];
  attachments?: [];
  custom_fields?: any;
  parent_task?: any;
  tags?: any;
  recurrence_pattern?: any;
  recurrence_end_date?: any;
  recurrence_interval?: any;
  weekly_recurrence_days?: any;
  monthly_recurrence_day_of_month?: any;
}

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    label: (
      <div className=" rounded-[8px] bg-[#E4F6D6]  text-xs sm:text-sm">
        <div className="flex h-[32px] w-auto items-center justify-center gap-2 px-[20px] py-[8px]">
          <Badge color="success" renderAsDot />
          <Text className="font-medium text-green-dark">Low</Text>
        </div>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    label: (
      <div className=" rounded-[8px] bg-[#FBF0DE]  text-xs sm:text-sm">
        <div className="flex h-[32px] w-auto items-center justify-center gap-2 px-[20px] py-[8px]">
          <Badge color="warning" renderAsDot />
          <Text className="font-medium text-orange-dark">Medium</Text>
        </div>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    label: (
      <div className=" rounded-[8px] bg-[#FBF0DE]  text-xs sm:text-sm">
        <div className="flex h-[32px] w-auto items-center justify-center gap-2 px-[20px] py-[8px]">
          {' '}
          <Badge color="danger" renderAsDot />
          <Text className="font-medium text-red-dark">High</Text>
        </div>
      </div>
    ),
  },
];

const RecurringArray = [
  {
    name: 'Does not repeat',
    label: 'Does not repeat',
    value: '',
  },
  {
    name: 'Daily',
    label: 'Daily',
    value: 'daily',
  },
  {
    name: 'Weekly',
    label: 'Weekly',
    value: 'weekly',
  },
  {
    name: 'Monthly',
    label: 'Monthly',
    value: 'monthly',
  },
];
let monthDate = [
  { label: '1', value: '1' },
  { label: '2', value: '2' },
  { label: '3', value: '3' },
  { label: '4', value: '4' },
  { label: '5', value: '5' },
  { label: '6', value: '6' },
  { label: '7', value: '7' },
  { label: '8', value: '8' },
  { label: '9', value: '9' },
  { label: '10', value: '10' },
  { label: '11', value: '11' },
  { label: '12', value: '12' },
  { label: '13', value: '13' },
  { label: '14', value: '14' },
  { label: '15', value: '15' },
  { label: '16', value: '16' },
  { label: '17', value: '17' },
  { label: '18', value: '18' },
  { label: '19', value: '19' },
  { label: '20', value: '20' },
  { label: '21', value: '21' },
  { label: '22', value: '22' },
  { label: '23', value: '23' },
  { label: '24', value: '24' },
  { label: '25', value: '25' },
  { label: '26', value: '26' },
  { label: '27', value: '27' },
  { label: '28', value: '28' },
  { label: '29', value: '29' },
  { label: '30', value: '30' },
  { label: '31', value: '31' },
];

const weekdays = [
  { name: 'M', value: 'monday' },
  { name: 'T', value: 'tuesday' },
  { name: 'W', value: 'wednesday' },
  { name: 'T', value: 'thursday' },
  { name: 'F', value: 'friday' },
  { name: 'SA', value: 'saturday' },
  { name: 'S', value: 'sunday' },
];

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#8c80d2' : 'white',
    color: state.isSelected ? 'white' : 'black',
    padding: '8px',
  }),
  multiValueLabel: (provided: any, { data }: { data: any }) => ({
    ...provided,
    color: data?.isInvalid ? 'red' : 'black',
  }),
};

const reminderOptions = [
  // { value: 'on_due_date', label: 'On due date' },
  { value: 'no_notify', label: "Don't notify" },
  { value: '10_min_before', label: '10 minutes before' },
  { value: '30_min_before', label: '30 minutes before' },
  { value: '1_hour_before', label: '1 hour before' },
  { value: '1_day_before', label: '1 day before' },
  { value: '2_day_before', label: '2 days before' },
  { value: '3_day_before', label: '3 days before' },
  { value: '1_week_before', label: '1 week before' },
  { value: '2_week_before', label: '2 weeks before' },
  { value: 'custom', label: 'Custom' },
];

const RepeatOptions = [
  // { value: 'on_due_date', label: 'On due date' },
  { value: 'no_repetition', label: 'No repetition' },
  {
    value: 'daily',
    label: 'Daily until the task is completed',
  },
  {
    value: 'weekly',
    label: 'Weekly until the task is completed',
  },
];

const customData = [
  { value: 'minutes', label: 'Minutes before' },
  { value: 'hours', label: 'Hours before' },
  { value: 'days', label: 'Days before' },
];

export default function ViewTaskFormSideBar(props: any) {
  // if we open from table columns in edit or view mode
  const {
    editMode,
    rowData,
    column,
    createTask,
    updateTask,
    setAssigneeFilter,
    setTaskFilterOptionName,
    setTaskFilterOptionValue,
    onClose,
    isView,
    isInboxTaskView,
  } = props;

  // console.log('isInboxTaskView......', isInboxTaskView, !isInboxTaskView);
  // console.log('rowData......', rowData);

  const dispatch = useDispatch();
  const router = useRouter();
  const { openModal, closeModal } = useModal();
  const { openDrawer, closeDrawer } = useDrawer();
  const [isRunning, setIsRunning] = useState(false);
  const [time, setTime] = useState(0);

  const setErrorReference = useRef<any>();
  const setClearErrorReference = useRef<any>();
  const setWatchReference = useRef<any>();
  const [isReminder, setIsReminder] = useState(false);
  const taskData = useSelector((state: any) => state?.root?.task);
  const task = taskData?.task?.activity ?? {}; // after get task by id data in edit mode
  // console.log(task, 'asdfghjkl');

  const [hasMore, sethasMore] = useState(true);
  const [payload, setPayload] = useState({
    page: 1,
    items_per_page: 5,
    task_id: '',
    all_user: false,
  });

  const [totalActivityData, setTotalActivityData] = useState(0);
  const [skeletonLoader, setSkeletonloader] = useState(true);
  const [updatedData, setUpdateddata] = useState<any[]>([]);

  const [singleActivityhasMore, setSingleActivityhasMore] = useState<{
    [key: string]: boolean;
  }>({});
  const [singleActivitypayload, setsingleActivityPayload] = useState<{
    [key: string]: any;
  }>({});
  const [totalsingleActivityData, setTotalsingleActivityData] = useState<{
    [key: string]: number;
  }>({});
  const [singleActivityskeletonLoader, setsingleActivitySkeletonloader] =
    useState<{ [key: string]: boolean }>({});
  const [setsingleActivityData, setsetsingleActivity] = useState<{
    [key: string]: any[];
  }>({});

  const [singleMyloghasMore, setSingleMyloghasMore] = useState<{
    [key: string]: boolean;
  }>({});
  const [singleMylogpayload, setsingleMylogpayload] = useState<{
    [key: string]: any;
  }>({});
  const [totalsingleMylogData, setTotalsingleMylogData] = useState<{
    [key: string]: number;
  }>({});
  const [singleMylogskeletonLoader, setsingleMylogSkeletonloader] = useState<{
    [key: string]: boolean;
  }>({});
  const [singleMylogData, setsingleMylogData] = useState<{
    [key: string]: any[];
  }>({});

  const AllTimerLogsData = useSelector(
    (state: any) => state?.root?.task?.timerLogsdata
  );

  const [sectionData, setSectionData] = useState<{ [key: string]: any }>({});

  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>(
    {}
  );

  const [mylogssectionData, setMylogsSectionData] = useState<{
    [key: string]: any;
  }>({});

  const [myLogsopenSections, setmyLogsopenSections] = useState<{
    [key: string]: boolean;
  }>({});
  const GetsingleTimerLogsData = useSelector(
    (state: any) => state?.root?.task?.mytimerLogsdata
  );

  const signIn = useSelector((state: any) => state?.root?.signIn);
  const [activeTab, setActiveTab] = useState('Comments');
  const { activeTimerData } = useSelector(
    (state: any) => state?.root?.timeTracking
  );

  const {
    gridView,
    paginationParams,
    oldTasks,
    oldTasksSections,
    duplicateTaskLoading,
    loading: taskLoading,
  } = useSelector((state: any) => state?.root?.task);
  const { loading } = useSelector((state: any) => state?.root?.taskStatus);
  const { boardId, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  // console.log(sections, 'sections123');
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { trackedHourDetails } = useSelector(
    (state: any) => state?.root?.timeTracking
  );
  const { settingData } = useSelector((state: any) => state?.root?.setting);

  // create hook form setValue reference
  const setValueReference = useRef<any>();
  const getValueReference = useRef<any>();

  // create image input reference
  const inputRef = useRef<HTMLInputElement>(null);

  // create comment text area setValue reference
  const commentTextAreaReference = useRef<any>();
  const commentAttachmentRef = useRef<HTMLInputElement>(null);

  const [selectedRecurringOption, SetSelectedRecurringOption] = useState<any>({
    name: 'Does not repeat',
    label: 'Does not repeat',
    value: '',
  });
  const [selectedReminder, setSelectedReminder] = useState({
    value: 'no_notify',
    label: "Don't notify",
    name: "Don't notify",
  });
  const [selectedRepetition, setSelectedRepetition] = useState({
    value: 'no_repetition',
    label: 'No repetition',
    name: 'No repetition',
  });

  useEffect(() => {
    if (Object?.keys(activeTimerData).length > 0) {
      console.log(
        calculateTotalTimeInSeconds(
          activeTimerData?.new_log?.clock_in,
          new Date()
        ) * 1000,
        'calculateTotalTimeInSeconds task'
      );

      setTime(
        calculateTotalTimeInSeconds(
          activeTimerData?.new_log?.clock_in,
          new Date()
        ) * 1000
      );
      setIsRunning(true);
    } else {
      setIsRunning(false);
    }
  }, [activeTimerData, defaultWorkSpace?._id]);

  useEffect(() => {
    socket.on('TIMER_SETTING', (response: any) => {
      socket.emit('CONFIRMATION', { event: 'TIMER_SETTING' });
      console.log(response, 'response');
      dispatch(getSettingData());
    });

    return () => {
      socket.off('TIMER_SETTING');
    };
  }, [dispatch, defaultWorkSpace?._id]);

  // called when new comment add in task
  useEffect(() => {
    socket.on('TASK_COMMENT', (res) => {
      console.log('TASK_COMMENT.......', res);
      // dispatch(updateCommentData(res));
      socket.emit('CONFIRMATION', { event: 'TASK_COMMENT' });
    });

    return () => {
      socket.off('TASK_COMMENT');
    };
  }, [dispatch, defaultWorkSpace?._id]);

  // Start Timer
  useEffect(() => {
    let timer: any;
    if (isRunning) {
      timer = setInterval(() => {
        setTime((prevTime: any) => prevTime + 1000); // Increment time every second
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRunning]);

  const handleStopClick = () => {
    openModal({
      view: (
        <ConfirmationTimerModal
          message="Are you sure you want to stop the timer?"
          confirmText="Yes"
          onConfirm={endTask}
          onClose={closeModal}
          isRunning={isRunning}
        />
      ),
      customSize: '400px',
    });
  };

  const endTask = async () => {
    // Close modal after confirming action
    // Original task-stopping logic
    dispatch(
      taskTimerStartAndStop({
        task_id: activeTimerData?.task_id,
        event_type: 'timer_end',
        mode: 'clocking',
      })
    ).then((result: any) => {
      if (taskTimerStartAndStop.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          setIsRunning(false);
          dispatch(removeActiveTimerData());
          closeModal();
        }
      }
    });
  };

  const MAX_FILE_SIZE = 200 * 1024 * 1024; // 200MB in bytes

  const taskFormSchema = z.object({
    title: z
      .string()
      .min(1, { message: messages.titleIsRequired })
      .max(150, { message: messages.taskTitleLength }),
    agenda: z.string().optional(),
    // attachments: z.any().optional(),
    attachments: z
      .any()
      .optional()

      .refine((files) => {
        if (typeof files === 'string') {
          return true;
        } else if (typeof files === 'object') {
          let checkInvalidFile: any[] = [];
          checkInvalidFile =
            files?.length > 0 &&
            files?.filter((file: any) => {
              return file?.size > MAX_FILE_SIZE;
            });

          return checkInvalidFile?.length > 0 ? false : true;
          // return files?.size <= MAX_FILE_SIZE;
        }
      }, messages.taskAttachementMaxFileSize),
    priority: z.string().optional(),
    due_date: z.any().optional(),
    board_id: z.string().optional(),
    status: z.string().min(1, { message: 'Status is required' }),
    assign_to: z.string().optional(),
    comment: z.string().optional(),
    comment_attachments: z.any().optional(),
    mentioned_users: z.any().optional(),
    recurrence_pattern: z.string().nullable().optional(),
    weekly_recurrence_days:
      selectedRecurringOption?.value === 'weekly'
        ? z.array(z.string()).min(1, 'Select at least one day')
        : z.array(z.string()).optional(),
    recurrence_start_at_time:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable() // This allows it to be null
            .refine((val: any) => val !== null, {
              message: messages.recurringStartTimeIsRequried,
            })
        : z.date().nullable().optional(),
    recurrence_start_date:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringStartDateIsRequried,
            })
        : z.date().nullable().optional(),
    // recurrence_interval:
    //   selectedRecurringOption?.value !== ''
    //     ? z
    //         .string()
    //         .min(1, { message: 'Minimum 1 number required' })
    //         .max(2, { message: 'Maximum 2 digits allowed' })
    //         .regex(/^[1-9][0-9]?$/, {
    //           message: 'Only positive integers greater than 0 are allowed',
    //         }) // Excludes 0, only positive integers are allowed
    //     : z.string().optional(),
    recurrence_end_date:
      selectedRecurringOption?.value != ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringEndDateIsRequried,
            })
        : z.date().nullable().optional(),
    monthly_recurrence_day_of_month:
      selectedRecurringOption?.value == 'monthly'
        ? z
            .object({
              label: z.string(),
              value: z.string(),
            })
            .nullable()
        : z
            .object({
              label: z.string().optional(),
              value: z.string().optional(),
            })
            .optional(),
    reminder: z.string().optional(),
    repeat: z.string().optional(),
    reminder_date:
      selectedReminder?.value === 'custom'
        ? z
            .union([z.date(), z.null()])
            .refine((date) => date !== null && !isNaN(date.getTime()), {
              message: 'Reminder date is required and must be a valid date',
            })
        : z.date().nullable().optional(),
  });
  type TaskFormSchema = z.infer<typeof taskFormSchema>;

  // const [files, setFiles] = useState<any>([]);
  const [commentText, setCommentText] = useState('');
  const [showSubtaskFields, setShowSubtaskFields] = useState(false);

  //set subtask state
  const [subTaskData, setSubTaskData] = useState<any>(null);

  // for assignee open modal
  const [showPopper, setShowPopper] = useState(false);

  // for sub task open modal
  const [showSubTaskModal, setShowSubTaskModal] = useState(false);

  //coustomField data
  const [customFieldData, setCustomFieldData] = useState<any>([]);

  // for delete confirmation open modal
  const [showDeleteConfirmationPopper, setShowDeleteConfirmationPopper] =
    useState(false);

  // for delete confirmation open modal
  const [showTaskReminderPopper, setShowTaskReminderPopper] = useState(false);

  // selected assigness - in ["id", "id"]
  const [selectedMembers, setSelectedMembers] = useState([]);

  // for selected status option
  const [selectedStatus, setSelectedStatus] = useState<any>(null);

  // for selected priority option
  const [selectedPriority, setSelectedPriority] = useState<any>(null);

  // for multiple selected attachment preview - [{}, {}]
  const [previewImage, setPreviewImage] = useState<any>(null);

  // for multiple selected attachement preview for comment
  const [previewImageForComment, setPreviewImageForComment] =
    useState<any>(null);

  // for mark complete button
  const [taskDone, setTaskDone] = useState(false);

  // for leave task
  const [canLeaveTask, setCanLeaveTask] = useState(false);

  // My tracked time
  const [myTimeTracked, setMyTimeTracked] = useState(0);

  // create agenda input reference
  const agendaInputRef = useRef<HTMLTextAreaElement>(null);

  // for get agenda value
  const [agendaValue, setAgendaValue] = useState<string>();

  // bulk download
  const [bulkDownload, setBulkDownload] = useState<any[]>([]);
  const [bulkDownloadLoader, setBulkDownloadLoader] = useState(false);
  const [shouldCloseDrawer, setShouldCloseDrawer] = useState(false);
  const [isDisable, setIsDisable] = useState(false);
  // Comment with mentions
  const [mentionUser, setMentionUser] = useState<any>([]);
  const [tags, setTags] = useState<{ tag_name: string; tag_color?: string }[]>(
    []
  );
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  const MAX_WORDS = 20;
  const MAX_CHARS = 20;

  const mention_users = taskData?.task?.mention_users ?? {};
  const [isRecurring, setIsRecurring] = useState(task?.recurring);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [isReminderPopoverOpen, setIsReminderPopoverOpen] = useState(false);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<any>(null);

  const handleTimerClick = (task: any) => {
    setSelectedTask(task);
    setIsPopupOpen(true);
  };

  const closePopup = () => {
    setIsPopupOpen(false);
    setSelectedTask(null);
  };

  // console.log(isRecurring, task, '535353');

  // Mention Style Start
  const mentionStyles = {
    control: {
      // backgroundColor: '#FFFFFF',
      fontSize: 16,
      fontWeight: 'normal',
      color: '#000000',
      borderRadius: '8px',
    },
    '&multiLine': {
      control: {
        fontFamily: 'Arial, sans-serif',
        overflow: 'hidden',
        // maxHeight: '6rem'
        height: '42px',
        // width: editMode && !task?.mark_as_done ? '250px' : '290px', // Conditional width
        width: '400px', // Conditional width
      },
      highlighter: {
        padding: 6,
        border: 'none',
        overflow: 'hidden',
        // maxHeight: '5.9rem',
        // borderRadius: '8px',
        height: '42px',
        width: '400px', // Conditional width
      },
      input: {
        padding: 6,
        border: 'none',
        // maxHeight: '5.9rem',
        margin: '2px',
        color: '#141414',
        borderRadius: '8px',
        height: '70px',
        overflow: 'auto',
        // resize: 'none',
        // width: editMode && !task?.mark_as_done ? '250px' : '290px', // Conditional width
        width: '510px', // Conditional width
        placeholderColor: '#141414',
      },
    },
    suggestions: {
      // width: "200px",
      list: {
        // backgroundColor: 'white',
        border: 'none',
        fontSize: 14,
        // position: 'absolute', // Position absolutely to control its placement
        bottom: '100%', // Move the list above the input
        left: 0,
        zIndex: 10, // Ensure it appears above other content
      },
      item: {
        padding: '5px 15px',
        borderBottom: '1px solid #ccc',
        '&focused': {
          backgroundColor: '#8C80D2',
          color: 'white',
        },
      },
    },
  };

  // for handle comment attachement error
  const [commentAttachementInvalid, setCommentAttachementInvalid] =
    useState(false);

  // Initialize tags from rowData in edit mode
  useEffect(() => {
    if (editMode && task?.tags?.length > 0) {
      setTags(
        task.tags.map((tag: any) => ({
          tag_name: tag.tag_name.trim(),
          tag_color: tag.tag_color,
        }))
      );
    }
  }, [editMode, task]);

  useEffect(() => {
    (!editMode || (editMode && task?.custom_fields?.length === 0)) &&
      dispatch(getSettingData());
  }, [dispatch, editMode, task?.custom_fields]);

  useEffect(() => {
    (!editMode || (editMode && task?.custom_fields?.length === 0)) &&
      dispatch(getSettingData());
  }, [dispatch, editMode, task?.custom_fields]);

  useEffect(() => {
    const filterCustomFields =
      board?.custom_fields?.filter((filed: any) => filed?.isShow) ?? [];
    setCustomFieldData(
      editMode
        ? task?.custom_fields?.length === 0
          ? filterCustomFields
          : task?.custom_fields
        : filterCustomFields
    );
  }, [editMode, board?.custom_fields, task?.custom_fields]);

  useEffect(() => {
    // fetching get task by id and get comments by task id
    if (editMode) {
      setTags([]);
      setPreviewImage(null);
      dispatch(getTaskById({ taskId: rowData?._id })).then((result: any) => {
        if (getTaskById?.fulfilled?.match(result)) {
          if (result && result?.payload?.success === true) {
          } else {
            onClose();
          }
        } else {
          onClose();
        }
      });
      dispatch(taskTimeTrackedHistory(rowData?._id));
      dispatch(getAllCommentsById({ task_id: rowData?._id }));
    } else {
      setMyTimeTracked(0);
      dispatch(removeTrackedHourDetails());
    }
  }, [rowData]);

  useEffect(() => {
    const setRecurrencePattern = RecurringArray?.find(
      (data: any) => data?.value == task?.recurrence_pattern
    );
    if (setRecurrencePattern) {
      SetSelectedRecurringOption(setRecurrencePattern);
    } else {
      SetSelectedRecurringOption({
        name: 'Does not repeat',
        label: 'Does not repeat',
        value: '',
      });
    }
  }, [task]);

  useEffect(() => {
    const setupdateReminder: any = reminderOptions?.find(
      (data: any) => data?.value == task?.reminder_option
    );
    if (setupdateReminder) {
      setSelectedReminder(setupdateReminder);
    } else {
      setSelectedReminder({
        value: 'no_notify',
        label: "Don't notify",
        name: "Don't notify",
      });
    }
    const selectedRepetOption: any = RepeatOptions?.find(
      (data: any) => data?.value === task?.repeat
    );

    if (selectedRepetOption) {
      setSelectedRepetition(selectedRepetOption);
    } else {
      setSelectedRepetition({
        value: 'no_repetition',
        label: 'No repetition',
        name: 'No repetition',
      });
    }
  }, [task]);

  // On Change Recurring
  const onChangeRecurring = (option: any, setValue: any) => {
    SetSelectedRecurringOption(option);
    if (option?.value !== '') {
      setValue('recurrence_pattern', option?.value);
    } else {
      setValue('recurrence_pattern', '');
    }
  };

  //on Change Reminder
  const handleCustomChange = (option: any, setValue: any) => {
    setSelectedReminder(option);
    if (option?.value !== '') {
      setValue('reminder', option?.value);
    } else {
      setValue('reminder', '');
    }
    // if (value.value !== 'custom') {
    //   setCustomValue(30); // Reset custom value
    //   setCustomUnit('minutes'); // Reset unit
    // }
  };

  useEffect(() => {
    if (trackedHourDetails && Object.keys(trackedHourDetails)?.length > 0) {
      trackedHourDetails?.tracked_history?.length > 0 &&
        trackedHourDetails?.tracked_history?.map((data: any) => {
          if (data?.user?._id === signIn?.user?.data?.user?._id) {
            setMyTimeTracked(data?.total_time);
          }
        });
    } else {
      setMyTimeTracked(0);
    }
  }, [signIn?.user?.data?.user?._id, trackedHourDetails]);

  const parseTimeToDate = (timeString: string | null) => {
    if (!timeString) return null;
    const now = new Date(); // Use current date
    const [hours, minutes] = timeString.split(':').map(Number);
    return new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      hours,
      minutes
    );
  };

  const initialValues: TaskFormSchema = {
    title: editMode ? task?.title : '',
    agenda: editMode ? task?.agenda : '',
    attachments: '',
    due_date:
      editMode && task?.due_date ? moment(task?.due_date).toDate() : null,
    priority: editMode ? task?.priority : '',
    board_id: editMode ? board?._id : '',
    status: editMode ? task?.status?._id : '',
    assign_to: '',
    comment: '',
    recurrence_pattern: task?.recurrence_pattern
      ? task?.recurrence_pattern
      : '',
    weekly_recurrence_days: task?.weekly_recurrence_days
      ? task?.weekly_recurrence_days
      : [],
    recurrence_end_date: task?.recurrence_end_date
      ? moment(task?.recurrence_end_date).toDate()
      : null,
    recurrence_start_at_time: task?.recurrence_time
      ? parseTimeToDate(task?.recurrence_time)
      : null,
    recurrence_start_date: task?.recurrence_start_date
      ? moment(task?.recurrence_start_date).toDate()
      : null,
    // recurrence_interval:
    //   task?.recurrence_interval > -1 ? String(task?.recurrence_interval) : '',
    // alert_time_unit: meetingDataById?.alert_time_unit ? meetingDataById?.alert_time_unit : {label: '', value: ''},
    monthly_recurrence_day_of_month: task?.monthly_recurrence_day_of_month
      ? {
          label: String(task?.monthly_recurrence_day_of_month),
          value: String(task?.monthly_recurrence_day_of_month),
        }
      : { label: '1', value: '1' },
    reminder: task?.reminder_option ? task?.reminder_option : 'no_notify',
    repeat: task?.repeat ? task?.repeat : 'no_repetition',
    reminder_date: task?.reminder_date
      ? moment(task?.reminder_date).toDate()
      : null,
  };

  // Auto increase agenda input field
  useEffect(() => {
    if (agendaInputRef.current) {
      agendaInputRef.current.style.height = 'auto';
      agendaInputRef.current.style.overflowY = 'hidden';
      agendaInputRef.current.style.height = `${agendaInputRef.current.scrollHeight}px`;
    }
  }, [agendaValue, task?.agenda]);

  // status dropdown options - dynamic - not included completed and archived
  const statusOptions: Record<string, any>[] =
    sections && sections?.length > 0
      ? sections
          ?.filter(
            (section: Record<string, any>) =>
              section?.key !== 'completed' && section?.key !== 'archived'
          ) // Filter out 'completed' and 'archived' sections
          ?.map((section: Record<string, any>) => {
            return {
              value: section?._id,
              name: capitalizeFirstLetter(section?.section_name),
              label: (
                <div
                  className="rounded-[8px] text-xs sm:text-sm"
                  style={{ backgroundColor: section?.color }}
                >
                  <div className="flex h-[32px] w-auto items-center justify-center gap-2 px-[20px] py-[8px]">
                    <div
                      className="h-2 w-2 rounded-[8px]"
                      style={{ backgroundColor: section?.test_color }}
                    />
                    <div
                      className="font-medium"
                      style={{ color: section?.test_color }}
                    >
                      {section?.section_name}
                    </div>
                  </div>
                </div>
              ),
              key: section?.key,
            };
          })
      : [];

  // All status options

  const allStatusOptions: Record<string, any>[] =
    sections && sections?.length > 0
      ? sections?.map((section: Record<string, any>) => {
          return {
            value: section?._id,
            name: capitalizeFirstLetter(section?.section_name),
            label: (
              <div
                className="flex w-auto items-center justify-center gap-2 rounded-[8px] px-2 py-1.5 text-sm sm:text-sm"
                style={{ backgroundColor: section?.color }}
              >
                <div
                  className="h-2 w-2 rounded-[8px]"
                  style={{ backgroundColor: section?.test_color }}
                />
                <div
                  className="font-medium"
                  style={{ color: section?.test_color }}
                >
                  {section?.section_name}
                </div>
              </div>
            ),
            key: section?.key,
          };
        })
      : [];

  // If we create a task from particular section in kanban view than i have to select by default column option

  useEffect(() => {
    // in edit mode we have to select bydefault status and priority of particular task and mark complete status
    if (editMode) {
      const assignToMembers =
        (task?.assign_to &&
          task?.assign_to?.length > 0 &&
          task?.assign_to?.map((member: any) => {
            return member?._id;
          })) ||
        [];
      setSelectedMembers(assignToMembers);

      assignToMembers &&
        assignToMembers?.length > 0 &&
        setCanLeaveTask(
          assignToMembers?.includes(signIn?.user?.data?.user?._id)
        );

      if (task?.status) {
        const defaultOption =
          allStatusOptions.find(
            (option: any) => option.value === task?.status?._id
          ) || null;
        setSelectedStatus(defaultOption || allStatusOptions[0]);
      }

      if (task?.priority) {
        const defaultOption =
          priorityOptions.find(
            (option: any) => option.value === task?.priority
          ) || {};
        setSelectedPriority(defaultOption || priorityOptions[0]);
      }

      // set mark_as_done value
      task?.mark_as_done && setTaskDone(task?.mark_as_done);

      // set attchments value need to change
      // let updatedAttachmentArray: Record<string, any>[] = task?.attachments && task?.attachments?.length > 0 ? task?.attachments?.map((file: any) => {
      //     return { preview: file }
      // }) : [];

      // task?.attachments && task?.attachments?.length > 0 && setPreviewImage(updatedAttachmentArray)
      task?.attachments &&
        task?.attachments?.length > 0 &&
        setPreviewImage(task?.attachments);
    }
  }, [task]);

  const validateCustomReminder = (customValue: any, customUnit: any) => {
    const dueDate = setWatchReference.current('due_date');
    if (dueDate) {
      const dueMoment = moment(dueDate);
      let reminderTime: moment.Moment | null = null;

      if (customValue && customUnit?.value) {
        reminderTime = dueMoment.subtract(customValue, customUnit.value);
      }

      if (reminderTime && reminderTime.isBefore(moment())) {
        setErrorReference.current('reminder', {
          type: 'manual',
          message: 'Reminder time cannot be in the past',
        });
      } else {
        setClearErrorReference.current('reminder');
      }
    }
  };

  useEffect(() => {
    // in create mode we have to select bydefault status option as pendding and priority option as low
    if (!editMode) {
      if (column) {
        const defaultSelectedOption: any =
          (statusOptions &&
            statusOptions?.length > 0 &&
            statusOptions?.find(
              (option: any) => option.value === column?._id
            )) ||
          {};

        // setting value in form state
        defaultSelectedOption
          ? setSelectedStatus(defaultSelectedOption)
          : setSelectedStatus(statusOptions?.[0]);
        setValueReference.current(
          'status',
          defaultSelectedOption
            ? defaultSelectedOption?.value
            : statusOptions[0]?.value,
          { shouldValidate: true }
        );
      } else {
        const defaultPendingOption: any =
          (statusOptions &&
            statusOptions?.length > 0 &&
            statusOptions?.find((option: any) => option?.key === 'pending')) ||
          {};

        // setting value in form state
        defaultPendingOption && Object?.keys(defaultPendingOption)?.length > 0
          ? setSelectedStatus(defaultPendingOption)
          : statusOptions &&
            statusOptions?.length > 0 &&
            setSelectedStatus(statusOptions?.[0] ?? {});
        setValueReference.current(
          'status',
          defaultPendingOption && Object?.keys(defaultPendingOption)?.length > 0
            ? defaultPendingOption?.value
            : statusOptions?.[0]?.value ?? ''
        );
      }
      setSelectedPriority(priorityOptions[0]);
      setValueReference.current('priority', priorityOptions[0]?.value, {
        shouldValidate: true,
      });
    }
  }, []);

  useEffect(() => {
    setIsDisable(
      task?.mark_as_done ||
        (['team_client', 'team_agency'].includes(signIn?.role) &&
          !(
            editMode &&
            checkPermission('projects', 'tasks', 'update', signIn?.permission)
          ))
    );

    console.log(
      task?.mark_as_done,
      ['team_client', 'team_agency'].includes(signIn?.role) &&
        !(
          editMode &&
          checkPermission('projects', 'tasks', 'update', signIn?.permission)
        ),
      'abcd'
    );
  }, [task?.mark_as_done, signIn, editMode]);

  // api call for get clients and team member
  useEffect(() => {
    dispatch(getAllAssignees());
    // dispatch(getBoardSectionsById({ board_id: board?._id }));
    boardId && dispatch(getMembersByBoardId({ boardId: boardId }));
  }, []);

  const clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          const name = `${
            capitalizeFirstLetter(team?.first_name) +
            +capitalizeFirstLetter(team?.last_name)
          }`;
          return { ...team, name };
        })
      : [];

  // for avtar image display name
  const displayName = (data: any) => {
    return `${
      capitalizeFirstLetter(data?.first_name) +
      ' ' +
      capitalizeFirstLetter(data?.last_name)
    }`;
  };

  // handle remove member

  const handleRemoveMember = (userId: string) => {
    let removedMemberFiltered =
      (selectedMembers &&
        selectedMembers?.length > 0 &&
        selectedMembers?.filter((member: any, index: number) => {
          if (member !== userId) {
            return member;
          }
        })) ||
      [];

    setSelectedMembers([...removedMemberFiltered]);
  };

  // keydown event for comment text area
  const handleKeyDownEvent = (
    event: any,
    setValueReference: any,
    commentTextAreaReference?: any
  ) => {
    setValueReference.current('comment', event.target.value);

    setCommentText(event.target.value);

    // Check if the space key is pressed and it's the first character
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }
    // if (event.key === 'Enter' && !event.shiftKey) {
    //     event.preventDefault();
    // }
  };

  // Keydown event for comment with mention user
  const handleKeyDownForComment = (event: any, setValueReference: any) => {
    // Prevent space as the first character
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }

    // Check for Shift + Enter (allow new line)
    if (event.key === 'Enter' && event.shiftKey) {
      return; // Allow default behavior for a new line
    }

    // Handle Enter key press to submit the comment
    if (event.key === 'Enter') {
      event.preventDefault(); // Prevent new line in the input

      // Format the comment text and mentioned users
      const mentioned_users =
        mentionUser?.length > 0
          ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
          : [];

      setValueReference.current(
        'comment',
        formateComment(commentText, task?.assign_to)
      );
      setValueReference.current(
        'mentioned_users',
        JSON.stringify(mentioned_users)
      );

      // Call the send comment function
      handleSendComment();
    }
  };

  const removeLoginUserFromMentionList = (menetionUserList: any) => {
    if (menetionUserList?.length === 0) {
      return menetionUserList;
    }

    return menetionUserList?.filter(
      (user: any) =>
        user?.id?.toString() !== signIn?.user?.data?.user?._id.toString()
    );
  };

  const fetchUsers = (query: any, callback: any) => {
    return callback;
  };

  const handleSendComment = () => {
    // comment api logic
    const myForm = new FormData();
    rowData?._id && myForm.append('task_id', rowData?._id);
    editMode &&
      task?.parent_task &&
      myForm.append('parent_task', task?.parent_task);

    if (commentText) {
      myForm.append('comment', formateComment(commentText, task?.assign_to));
    }
    const mentionedUsers =
      mentionUser?.length > 0
        ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
        : [];
    myForm.append('mentioned_users', JSON.stringify(mentionedUsers));

    previewImageForComment?.length > 0 &&
      previewImageForComment?.map((file: any) => {
        myForm.append('images', file);
      });

    (commentText !== '' || previewImageForComment?.length > 0) &&
      !commentAttachementInvalid &&
      editMode &&
      dispatch(postAddComments(myForm)).then((result: any) => {
        if (postAddComments.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            // commentTextAreaReference.current.value = '';
            setValueReference.current('comment', '');
            setPreviewImageForComment(null);
            setCommentText('');
            dispatch(getAllCommentsById({ task_id: rowData?._id })).then(
              (result: any) => {
                if (getAllCommentsById.fulfilled.match(result)) {
                  if (result && result.payload.success === true) {
                    if (gridView) {
                      updateTask(
                        rowData?._id,
                        'comment_update',
                        { comments: result?.payload?.data },
                        oldTasks,
                        oldTasksSections
                      );
                    }
                  }
                }
              }
            );
          }
        }
      });
  };

  const formateComment = (message: string, userList: any) => {
    const processedMessage = message.replace(
      /@(\w+\s\w+)/g,
      (match: any, displayName: any) => {
        const mention = userList.find(
          (item: any) => item.display === displayName
        );
        return mention ? `@[user::${mention.id}]` : match;
      }
    );
    return processedMessage;
  };

  // dropzone for attachments logic

  // Function to trigger the click event on the hidden file input
  const handleAddPictureButtonClick = () => {
    const inputElement = inputRef.current;
    if (inputElement) {
      inputElement.click();
    }
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    // Generate preview URLs for valid files
    // const previewURLs = acceptedFiles.map((file: any) => URL.createObjectURL(file));

    const newFiles = [
      ...acceptedFiles.map((file: any) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      ),
    ];

    // Combine previous files with the new files
    const previewURLs =
      previewImage && previewImage !== null
        ? [...previewImage, ...newFiles]
        : [...newFiles];

    // Set the combined list of files
    setValueReference.current('attachments', previewURLs, {
      shouldValidate: true,
    });
    setPreviewImage(previewURLs);

    // console.log("previewURLs....", previewURLs)
    // // const file = URL.createObjectURL(acceptedFiles[0])
    // // setValue("attachments", acceptedFiles[0])
    // setValueReference.current('attachments', previewURLs)

    // setPreviewImage(previewURLs)
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: {
      // 1. Documents
      'application/msword': ['.doc', '.docx'],
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt', '.log', '.ini'], // Combined duplicates for text/plain
      'application/rtf': ['.rtf'],
      'application/vnd.oasis.opendocument.text': ['.odt'],
      'application/epub+zip': ['.epub'],

      // 2. Spreadsheets
      'application/vnd.ms-excel': ['.xls', '.xlsx'],
      'text/csv': ['.csv'], // Use only one key for CSV
      'application/vnd.oasis.opendocument.spreadsheet': ['.ods'],

      // 3. Presentations
      'application/vnd.ms-powerpoint': ['.ppt', '.pptx'],
      'application/vnd.oasis.opendocument.presentation': ['.odp'],
      'application/x-iwork-keynote-sffkey': ['.key'],

      // 4. Images
      'image/*': [
        '.jpeg',
        '.jpg',
        '.png',
        '.gif',
        '.bmp',
        '.tiff',
        '.svg',
        '.webp',
      ],

      // 5. Videos
      'video/*': ['.mp4', '.avi', '.mov', '.wmv', '.mkv', '.flv'],

      // 6. Audio
      'audio/*': ['.mp3', '.wav', '.aac', '.ogg', '.flac'],

      // 7. Code/Programming
      'application/javascript': ['.js'],
      'application/json': ['.json'],
      'application/xml': ['.xml'],
      'text/html': ['.html', '.htm'],
      'text/css': ['.css'],
      'text/yaml': ['.yaml'],
      'application/sql': ['.sql'],
      'text/markdown': ['.md'],
      'text/x-python': ['.py'],
      'text/x-java-source': ['.java'],
      'text/x-c': ['.c', '.cpp'],

      // 8. Design
      'image/vnd.adobe.photoshop': ['.psd'],
      'application/postscript': ['.ai', '.eps'],
      'application/vnd.adobe.xd': ['.xd'],
      'application/figma': ['.fig'],
      'application/sketch': ['.sketch'],
      'application/x-indesign': ['.indd'],

      // 9. Data/Database
      'application/vnd.sqlite3': ['.sqlite'],
      'application/octet-stream': ['.db'],

      // 10. Compressed Files
      'application/zip': ['.zip', '.rar', '.7z', '.tar.gz', '.iso'],

      // 11. Miscellaneous
      'text/calendar': ['.ics'],
      'application/vnd.android.package-archive': ['.apk'],
      'application/x-apple-diskimage': ['.dmg'],
    },
    // maxSize: 200 * 1024 * 1024, // Maximum file size of 200MB
    multiple: true,
    noClick: true,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps } = useDropzone(dropzoneOptions);

  // Mark complete feature

  const handleMarkCompleteClick = () => {
    setTaskDone((prev) => !prev);

    const defaultCompleteOption: any =
      (sections &&
        sections?.length > 0 &&
        sections?.filter((option: any) => {
          if (option?.key === 'completed') {
            return option;
          }
        })) ||
      [];

    editMode &&
      defaultCompleteOption?.length > 0 &&
      dispatch(
        putTaskKanbanStatusChange({
          _id: rowData?._id,
          status: defaultCompleteOption[0]?._id,
        })
      ).then((result: any) => {
        if (putTaskKanbanStatusChange.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            onClose();
            if (!gridView) {
              dispatch(
                getAllTask({
                  ...paginationParams,
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              updateTask(
                rowData?._id,
                'complete_status_update',
                {
                  mark_as_done: true,
                  mark_as_archived: false,
                  before_status: rowData?.status,
                  after_status: defaultCompleteOption[0],
                },
                oldTasks,
                oldTasksSections
              );
            }
          }
        }
      });
  };

  const handleMarkArchive = () => {
    const defaultCompleteOption: any =
      (sections &&
        sections?.length > 0 &&
        sections?.filter((option: any) => {
          if (option?.key === 'archived') {
            return option;
          }
        })) ||
      [];

    editMode &&
      defaultCompleteOption?.length > 0 &&
      dispatch(
        putTaskKanbanStatusChange({
          _id: rowData?._id,
          status: defaultCompleteOption[0]?._id,
        })
      ).then((result: any) => {
        if (putTaskKanbanStatusChange.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            onClose();
            if (!gridView) {
              dispatch(
                getAllTask({
                  ...paginationParams,
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              // updateTask(
              //   rowData?._id,
              //   'status_update',
              //   {
              //     mark_as_done: true,
              //     mark_as_archived: true,
              //     before_status: rowData?.status,
              //     after_status: defaultCompleteOption[0],
              //   },
              //   oldTasks,
              //   oldTasksSections
              // );
            }
          }
        }
      });
  };

  const onSubmit: SubmitHandler<TaskFormSchema> = (data) => {
    if (commentAttachementInvalid) {
      return;
    }

    const dueDate = setWatchReference.current('due_date');
    console.log(dueDate, '56777');
    const selectedReminderValue = data?.reminder;

    if (selectedReminderValue) {
      const dueMoment = moment(dueDate);
      let reminderTime: moment.Moment | null = null;

      // Determine reminder time based on selected reminder
      if (selectedReminderValue === '10_min_before') {
        reminderTime = dueMoment.subtract(10, 'minutes');
      } else if (selectedReminderValue === '1_hour_before') {
        reminderTime = dueMoment.subtract(1, 'hour');
      } else if (selectedReminderValue === 'custom') {
        const reminderDate = data?.reminder_date;
        if (reminderDate) {
          reminderTime = moment(reminderDate);
        }
      }

      // Check if the reminder time is in the past
      if (reminderTime && reminderTime.isBefore(moment())) {
        // Set the error for reminder if the time is in the past
        setErrorReference.current('reminder', {
          type: 'manual',
          message: 'Reminder time cannot be in the past',
        });
        return; // Stop form submission if the error is triggered
      }
    }

    const formData: Record<string, any> = {
      title: data?.title ?? '',
      agenda: data?.agenda ?? '',
      priority: data?.priority ?? '',
      board_id: board?._id ?? '',
      status: data?.status ?? '',
      due_date: String(data?.due_date), // Convert due_date to string
      comment: data?.comment ?? '',
      custom_fields: JSON.stringify(customFieldData),
      // tags: tags,
    };
    const myForm = new FormData();

    if (
      data.due_date !== null
      //  &&
      // new Date(data?.due_date).getTime() > new Date().getTime()
    ) {
      formData.reminder_option = data?.reminder ? data?.reminder : null;
      formData.repeat = data?.repeat ? data?.repeat : null;

      if (data?.reminder === 'custom') {
        formData.reminder_date = data?.reminder_date
          ? String(data?.reminder_date)
          : null;
      }
    }

    if (!task?.parent_task) {
      formData.isRecurring = true;
    }
    // Add recurrence-related fields only if task?.parent_task is not present
    if (!task?.parent_task && data?.recurrence_pattern !== '') {
      formData.recurrence_pattern = data?.recurrence_pattern
        ? data?.recurrence_pattern
        : null;
      formData.recurrence_end_date = data?.recurrence_end_date
        ? moment(data?.recurrence_end_date).format('DD-MM-YYYY')
        : null;
      // formData.recurrence_interval = data?.recurrence_interval
      //   ? Number(data?.recurrence_interval)
      //   : null;

      if (
        data?.recurrence_pattern === 'weekly' &&
        Array.isArray(data?.weekly_recurrence_days)
      ) {
        data.weekly_recurrence_days?.forEach((day: string) => {
          myForm.append('weekly_recurrence_days', day);
        });
      }

      if (data?.recurrence_pattern === 'monthly') {
        formData.monthly_recurrence_day_of_month =
          data?.monthly_recurrence_day_of_month
            ? Number(data?.monthly_recurrence_day_of_month.value)
            : null;
      }
    }
    // remove key if its null undefined or ""
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(([_, value]) => {
        if (_ === 'agenda') {
          return value !== undefined;
        }
        return value !== undefined && value !== '';
      })
    );

    tags.forEach((tag) => {
      myForm.append('tags', tag?.tag_name);
    });
    // Add data from the 'formData' object to the FormData
    for (const key in filteredFormData) {
      if (Object.prototype.hasOwnProperty.call(filteredFormData, key)) {
        const value = filteredFormData[key];
        myForm.append(key, value);
      }
    }

    // Mentions user data
    const mentionedUsers =
      mentionUser?.length > 0
        ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
        : [];

    myForm.append('mentioned_users', JSON.stringify(mentionedUsers));

    editMode &&
      task?.parent_task &&
      myForm.append('parent_task', task?.parent_task);

    // add members id in form data [id, id] format
    selectedMembers &&
      selectedMembers?.length > 0 &&
      myForm.append('assign_to', JSON.stringify(selectedMembers));

    // add attachments files in form data

    if (!editMode) {
      previewImage?.length > 0 &&
        previewImage?.map((file: any) => {
          myForm.append('attachments', file);
        });
    } else {
      previewImage?.length > 0 &&
        previewImage?.map((file: any) => {
          if (!file?.preview?.startsWith('blob')) {
            myForm.append('attachments', JSON.stringify(file));
          } else {
            myForm.append('attachments', file);
          }
        });
    }

    // add id of task in form data in edit mode
    if (editMode) {
      myForm.append('_id', task?._id);
    }

    // create a object of selected assignees to update in card of kanban

    const updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];

    if (!editMode) {
      dispatch(postAddTask(myForm)).then((result: any) => {
        if (postAddTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            onClose();
            if (!gridView) {
              setTaskFilterOptionValue('');
              setTaskFilterOptionName('All tasks');
              setAssigneeFilter('');
              dispatch(
                getAllTask({
                  page: 1,
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              createTask({
                ...result?.payload?.data,
                assign_to: updatedAssigneeObject,
                attachment_count: result?.payload?.data?.attachments?.length,
                comments_count: result?.payload?.data?.comment,
              });
            }
          }
        }
      });
    } else {
      dispatch(patchEditTask(myForm)).then((result: any) => {
        if (patchEditTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            onClose();
            if (!gridView) {
              dispatch(
                getAllTask({
                  ...paginationParams,
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              console.log(result, 'result234');
              updateTask(
                task?._id,
                'task_update',
                {
                  oldTaskStatus: task?.status,
                  updated_task: {
                    ...result?.payload?.data,
                    assign_to: updatedAssigneeObject,
                    attachment_count:
                      result?.payload?.data?.attachments?.length,
                    comments_count: result?.payload?.data?.comment,
                    subtask_count: task?.sub_tasks?.length,
                    reminder_option: result?.payload?.data?.reminder_option,
                    custom_reminder_value:
                      result?.payload?.data?.custom_reminder_value,
                    custom_reminder_unit:
                      result?.payload?.data?.custom_reminder_unit,
                  },
                },
                oldTasks,
                oldTasksSections
              );
            }
          }
        }
      });
    }
  };

  //subtask duplicate
  const onSubTaskDuplicateTask: SubmitHandler<DuplicateTaskSchema> = (data) => {
    const formData = new FormData();

    // Append fields to the FormData object
    formData.append('title', data.title);
    if (data?.agenda) {
      formData.append('agenda', data.agenda);
    } else {
      formData.append('agenda', '');
    }
    formData.append('priority', data.priority);
    formData.append('board_id', data.board_id);
    formData.append('status', data.status._id);
    formData.append('duplicated_from', data._id);
    formData.append('custom_fields', JSON.stringify(data?.custom_fields));

    if (editMode && data?.parent_task) {
      formData.append('parent_task', data?.parent_task);
    }

    if (data?.tags && data?.tags?.length > 0) {
      data?.tags?.forEach((tag: any) => {
        formData.append('tags', tag?.tag_name);
      });
    }

    // Convert due_date to string format
    if (data.due_date) {
      const dueDate = new Date(data.due_date);
      formData.append('due_date', dueDate.toString());
    } else {
      formData.append('due_date', 'null'); // Send 'null' as a string
    }

    // Extract only the user IDs for assign_to and convert to JSON string
    if (data.assign_to && data.assign_to?.length > 0) {
      const assignToIds = data.assign_to.map((assignee: any) => assignee._id);
      formData.append('assign_to', JSON.stringify(assignToIds));
    }

    if (data?.attachments && data?.attachments?.length > 0) {
      formData.append('attachments', JSON.stringify(data?.attachments));
    }

    let updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];

    dispatch(duplicateAddTask(formData)).then((result: any) => {
      if (duplicateAddTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getTaskById({ taskId: data?.parent_task })).then(
            (result: any) => {
              if (getTaskById?.fulfilled?.match(result)) {
                if (result && result?.payload?.success === true) {
                } else {
                  onClose();
                }
              } else {
                onClose();
              }
            }
          );
          if (!gridView) {
            dispatch(
              getAllTask({
                page: 1,
                sort_field: 'createdAt',
                sort_order: 'desc',
                board_id: boardId,
                pagination: true,
              })
            );
          } else {
            updateTask(
              rowData?._id,
              'subtask_count',
              { subtask: rowData },
              oldTasks,
              oldTasksSections
            );
          }
          dispatch(taskTimeTrackedHistory(data?.parent_task));
          dispatch(getAllCommentsById({ task_id: data?.parent_task }));
        }
      }
    });
  };

  const onDuplicateTask = (data: any, setOpen: any) => {
    const formData = new FormData();

    // Append fields to the FormData object
    formData.append('title', data.title);
    if (data?.agenda) {
      formData.append('agenda', data.agenda);
    } else {
      formData.append('agenda', '');
    }
    formData.append('priority', data.priority);
    formData.append('board_id', data.board_id);
    formData.append('status', data.status._id);
    formData.append('duplicated_from', data._id);
    formData.append('custom_fields', JSON.stringify(data?.custom_fields));
    // if (data?.recurrence_pattern && data?.recurrence_pattern !== '') {
    //   formData.append('recurrence_pattern', data?.recurrence_pattern);
    //   formData.append(
    //     'recurrence_end_date',
    //     moment(data?.recurrence_end_date).format('DD-MM-YYYY')
    //   );
    //   // formData.append('recurrence_interval', data?.recurrence_interval);

    //   if (
    //     data?.recurrence_pattern === 'weekly' &&
    //     Array.isArray(data?.weekly_recurrence_days)
    //   ) {
    //     data.weekly_recurrence_days?.forEach((day: string) => {
    //       formData.append('weekly_recurrence_days', day);
    //     });
    //   }

    //   if (data?.recurrence_pattern === 'monthly') {
    //     formData.append(
    //       'monthly_recurrence_day_of_month',
    //       data?.monthly_recurrence_day_of_month
    //     );
    //   }
    // }

    if (editMode && data?.parent_task) {
      formData.append('parent_task', data?.parent_task);
    }

    if (data?.tags && data?.tags?.length > 0) {
      data?.tags?.forEach((tag: any) => {
        formData.append('tags', tag?.tag_name);
      });
    }

    // Convert due_date to string format
    if (data.due_date) {
      const dueDate = new Date(data.due_date);
      formData.append('due_date', dueDate.toString());
    } else {
      formData.append('due_date', 'null'); // Send 'null' as a string
    }

    // Extract only the user IDs for assign_to and convert to JSON string
    if (data.assign_to && data.assign_to?.length > 0) {
      const assignToIds = data.assign_to.map((assignee: any) => assignee._id);
      formData.append('assign_to', JSON.stringify(assignToIds));
    }

    if (data?.attachments && data?.attachments?.length > 0) {
      formData.append('attachments', JSON.stringify(data?.attachments));
    }

    let updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];
    dispatch(duplicateAddTask(formData)).then((result: any) => {
      if (duplicateAddTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          onClose();
          if (!gridView) {
            dispatch(
              getAllTask({
                page: 1,
                sort_field: 'createdAt',
                sort_order: 'desc',
                board_id: boardId,
                pagination: true,
              })
            );
            setOpen(false);
          } else {
            createTask({
              ...result?.payload?.data,
              assign_to: updatedAssigneeObject,
              attachment_count: result?.payload?.data?.attachments?.length,
              comments_count: result?.payload?.data?.comment,
            });
            setOpen(false);
          }
        }
      }
    });
  };

  useEffect(() => {
    // Automatically set "Comments" tab as active when there is no parent task
    if (!task?.parent_task) {
      setActiveTab('Comments');
      setOpenSections({});
      setSectionData({});
      setMylogsSectionData({});
      setmyLogsopenSections({});
      setPayload({
        page: 1,
        items_per_page: 5,
        task_id: '',
        all_user: false,
      });
      sethasMore(true);
      setUpdateddata([]);
      setSkeletonloader(true);
      setTotalActivityData(0);
      setsetsingleActivity({});
      setsingleActivitySkeletonloader({});
      setTotalsingleActivityData({});
      setsingleActivityPayload({});
      setSingleActivityhasMore({});
      setsingleMylogData({});
      setsingleMylogSkeletonloader({});
      setTotalsingleMylogData({});
      setsingleMylogpayload({});
      setSingleMyloghasMore({});
    }
  }, [task]);

  const checkAssigneExist = (assign_id: string) => {
    const index = task?.assign_to?.findIndex(
      (user: any) => user?._id === assign_id
    );
    return index !== -1 ? true : false;
  };

  // const handleTimerClick = (task: any) => {
  //   openModal({
  //     view: (
  //       <div>
  //         <TimerForm
  //           onClose={closeModal}
  //           task_id={task?._id}
  //           boardId={boardId}
  //           taskName={task?.title}
  //         />
  //       </div>
  //     ),
  //     customSize: '600px',
  //   });
  // };

  // Bulk Download
  const downloadFiles = async (files: any, bulkDownload: boolean = false) => {
    try {
      bulkDownload && setBulkDownloadLoader(true);
      // Create an array of axios requests
      const filePromises = files.map((file: any) =>
        axios.get(file?.split(' ')[0], { responseType: 'blob' })
      );

      // Wait for all requests to complete
      const responses = await Promise.all(filePromises);

      responses.forEach((response, index) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.download = files[index]?.split(' ').slice(1).join(' ');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        if (index + 1 === files?.length) {
          bulkDownload && setBulkDownloadLoader(false);
        }
      });
    } catch (error) {
      bulkDownload && setBulkDownloadLoader(false);
      console.error('Error downloading files:', error);
    }
  };

  // handle comment attachement
  const handleAttachmentChange = (event: any) => {
    const newFiles = event?.target?.files;

    checkCommentAttachement(event?.target?.files);

    const previewURLs: any[] = [];
    Object.values(newFiles).forEach((file: any) => {
      Object.assign(file, {
        preview: URL.createObjectURL(file),
      });
      previewURLs.push(file);
    });

    setValueReference.current('comment_attachments', previewURLs, {
      shouldValidate: true,
    });
    const attachementURL =
      previewImageForComment && previewImageForComment !== null
        ? [...previewImageForComment, ...previewURLs]
        : [...previewURLs];
    setPreviewImageForComment(attachementURL);
  };

  // check in comment attachement if any invalide file exits or not
  const checkCommentAttachement = (data: any) => {
    setCommentAttachementInvalid(false);

    if (data?.length > 0) {
      const fileSize = Object.values(data)?.map((file: any) =>
        getFileSize(file)
      );
      const inValidFile = fileSize?.filter(
        (fileInfo) => !checkValidFileSize(fileInfo, 200)
      );
      if (inValidFile?.length > 0) {
        setCommentAttachementInvalid(true);
      }
    }
  };

  useEffect(() => {
    const hasAccessToAllUsers =
      ['agency'].includes(signIn?.role) ||
      (['team_agency', 'team_client'].includes(signIn?.role) &&
        checkPermission('time_tracker', null, 'everyone', signIn?.permission));

    const hasAccessToOwnLogs =
      ['client'].includes(signIn?.role) ||
      (['team_agency', 'team_client'].includes(signIn?.role) &&
        checkPermission('time_tracker', null, 'own', signIn?.permission));

    if (activeTab === 'UserActivity' && hasAccessToAllUsers) {
      dispatch(
        getTimerLogs({
          ...payload,
          task_id: task?._id,
          all_user: true,
        })
      ).then((result: any) => {
        if (getTimerLogs.fulfilled.match(result)) {
          const totaluserActivitycout = result?.payload?.data?.total;
          const userActivityList =
            result?.payload?.data?.time_tracked_day || [];

          setTotalActivityData(totaluserActivitycout);

          if (userActivityList?.length > 0) {
            setSkeletonloader(false);

            const newData =
              payload.page === 1
                ? userActivityList // Replace the data when loading the first page or searching
                : [...updatedData, ...userActivityList]; // Append when scrolling

            setUpdateddata(newData);

            if (totaluserActivitycout > newData?.length) {
              sethasMore(true); // More data available
            } else {
              sethasMore(false); // No more data
            }
          } else {
            // No results for the current search or payload
            sethasMore(false);
          }
        } else {
          sethasMore(false); // Error or no data
        }
        setSkeletonloader(false);
      });
    } else if (activeTab === 'MyLogs' && hasAccessToOwnLogs) {
      dispatch(
        getTimerLogs({ ...payload, task_id: task?._id, all_user: false })
      ).then((result: any) => {
        if (getTimerLogs.fulfilled.match(result)) {
          const totaluserActivitycout = result?.payload?.data?.total;
          const userActivityList =
            result?.payload?.data?.time_tracked_day || [];

          setTotalActivityData(totaluserActivitycout);

          if (userActivityList?.length > 0) {
            setSkeletonloader(false);

            const newData =
              payload.page === 1
                ? userActivityList // Replace the data when loading the first page or searching
                : [...updatedData, ...userActivityList]; // Append when scrolling

            setUpdateddata(newData);

            if (totaluserActivitycout > newData?.length) {
              sethasMore(true); // More data available
            } else {
              sethasMore(false); // No more data
            }
          } else {
            // No results for the current search or payload
            sethasMore(false);
          }
        } else {
          sethasMore(false); // Error or no data
        }
        setSkeletonloader(false);
      });
    }
  }, [activeTab, signIn, dispatch, payload]); // Runs when tab or user data changes

  //Infinite Scroll Handler
  const fetchMoreData = () => {
    // 10px buffer to trigger loading
    if (updatedData?.length < totalActivityData) {
      setPayload((prev: any) => ({
        ...prev,
        page: prev.page + 1, // ✅ Increment page properly
      }));
    } else {
      sethasMore(false); // No more data to load
    }
  };

  const handleScroll = debounce((e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreData();
    }
  }, 300); // Adjust debounce delay as needed

  const fetchMoreSingleActivityData = async (date: string) => {
    const currentPayload = singleActivitypayload[date] || {
      page: 1,
      items_per_page: 10,
      task_id: '',
      date,
      all_user: false,
    };

    if (
      (setsingleActivityData[date]?.length || 0) < totalsingleActivityData[date]
    ) {
      const newPage = currentPayload.page + 1;

      try {
        const response = await dispatch(
          getmyTimerLogs({ ...currentPayload, page: newPage })
        ).unwrap();

        setsetsingleActivity((prev) => ({
          ...prev,
          [date]: [...(prev[date] || []), ...(response?.data?.log_data || [])],
        }));

        setsingleActivityPayload((prev) => ({
          ...prev,
          [date]: { ...currentPayload, page: newPage },
        }));

        // if (
        //   response?.data?.total > (setsingleActivityData[date]?.length || 0)
        // ) {
        //   setSingleActivityhasMore((prev) => ({ ...prev, [date]: true }));
        // } else {
        //   setSingleActivityhasMore((prev) => ({ ...prev, [date]: false }));
        // }
        setSingleActivityhasMore((prev) => ({
          ...prev,
          [date]:
            response?.data?.log_data?.length +
              (setsingleActivityData[date]?.length || 0) <
            response?.data?.total,
        }));
      } catch (error) {
        console.error('Error fetching more data for:', date, error);
        setSingleActivityhasMore((prev) => ({ ...prev, [date]: false }));
      }
    }
  };

  const handleSingleActivityScroll = debounce((date: string, e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreSingleActivityData(date);
    }
  }, 300);

  const toggleSection = async (date: string) => {
    setOpenSections((prev) => ({ ...prev, [date]: !prev[date] }));

    if (!sectionData[date]) {
      try {
        setsingleActivitySkeletonloader((prev) => ({ ...prev, [date]: true }));
        const response = await dispatch(
          getmyTimerLogs({
            page: 1,
            items_per_page: 10,
            task_id: task?._id,
            date,
            all_user: true,
          })
        ).unwrap();

        setSectionData((prev) => ({ ...prev, [date]: response?.data }));
        setsetsingleActivity((prev) => ({
          ...prev,
          [date]: response?.data?.log_data || [],
        }));
        setTotalsingleActivityData((prev) => ({
          ...prev,
          [date]: response?.data?.total || 0,
        }));
        setsingleActivityPayload((prev) => ({
          ...prev,
          [date]: {
            page: 1,
            items_per_page: 10,
            task_id: task?._id,
            date,
            all_user: true,
          },
        }));
        setSingleActivityhasMore((prev) => ({
          ...prev,
          [date]:
            response?.data?.total > (response?.data?.log_data?.length || 0),
        }));
      } catch (error) {
        console.error('Failed to fetch timer logs:', error);
      } finally {
        setsingleActivitySkeletonloader((prev) => ({ ...prev, [date]: false }));
      }
    }
  };

  const fetchMoreMyLogsData = async (date: string) => {
    const currentPayload = singleMylogpayload[date] || {
      page: 1,
      items_per_page: 10,
      task_id: '',
      date,
      all_user: false,
    };

    if ((singleMylogData[date]?.length || 0) < totalsingleMylogData[date]) {
      const newPage = currentPayload.page + 1;

      try {
        const response = await dispatch(
          getmyTimerLogs({ ...currentPayload, page: newPage })
        ).unwrap();

        setsingleMylogData((prev) => ({
          ...prev,
          [date]: [...(prev[date] || []), ...(response?.data?.log_data || [])],
        }));

        setsingleMylogpayload((prev) => ({
          ...prev,
          [date]: { ...currentPayload, page: newPage },
        }));
        setSingleMyloghasMore((prev) => ({
          ...prev,
          [date]:
            response?.data?.log_data?.length +
              (singleMylogData[date]?.length || 0) <
            response?.data?.total,
        }));
      } catch (error) {
        console.error('Error fetching more data for:', date, error);
        setSingleMyloghasMore((prev) => ({ ...prev, [date]: false }));
      }
    }
  };

  const handlemyLogsScroll = debounce((date: string, e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreMyLogsData(date);
    }
  }, 300);

  const myLogstoggleSection = async (date: string) => {
    setmyLogsopenSections((prev) => ({ ...prev, [date]: !prev[date] }));

    if (!mylogssectionData[date]) {
      try {
        setsingleMylogSkeletonloader((prev) => ({ ...prev, [date]: true }));
        const response = await dispatch(
          getmyTimerLogs({
            page: 1,
            items_per_page: 10,
            task_id: task?._id,
            date,
            all_user: false,
          })
        ).unwrap();

        setMylogsSectionData((prev) => ({ ...prev, [date]: response?.data }));
        setsingleMylogData((prev) => ({
          ...prev,
          [date]: response?.data?.log_data || [],
        }));
        setTotalsingleMylogData((prev) => ({
          ...prev,
          [date]: response?.data?.total || 0,
        }));
        setsingleMylogpayload((prev) => ({
          ...prev,
          [date]: {
            page: 1,
            items_per_page: 10,
            task_id: task?._id,
            date,
            all_user: false,
          },
        }));
        setSingleMyloghasMore((prev) => ({
          ...prev,
          [date]:
            response?.data?.total > (response?.data?.log_data?.length || 0),
        }));
      } catch (error) {
        console.error('Failed to fetch timer logs:', error);
      } finally {
        setsingleMylogSkeletonloader((prev) => ({ ...prev, [date]: false }));
      }
    }
  };

  // console.log(sectionData, 'wccqcqcqc');
  const stripHtml = (html: string) => html.replace(/<\/?[^>]+(>|$)/g, '');

  if (
    (Object.keys(task)?.length === 0 || taskData?.getTaskLoading) &&
    editMode
  ) {
    return (
      <div className="flex h-[90vh] items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  } else {
    return (
      <div className="px-6 py-6">
        <Form<TaskFormSchema>
          validationSchema={taskFormSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'onSubmit',
            defaultValues: initialValues,
          }}
          className="text-[14px] text-[#9BA1B9] [&_label]:font-medium"
        >
          {({
            register,
            control,
            formState: { errors },
            setValue,
            setError,
            getValues,
            watch,
            clearErrors,
          }) => (
            (setValueReference.current = setValue),
            (getValueReference.current = getValues),
            (setErrorReference.current = setError),
            (setWatchReference.current = watch),
            (setClearErrorReference.current = clearErrors),
            (
              <div>
                {/* created at and Timer */}
                {!isInboxTaskView && (
                  <div className="flex h-[32px] w-full items-center justify-between">
                    {/* Back Icon and Created On Text */}
                    <div className="flex items-center gap-[16px]">
                      <div
                        className="cursor-pointer"
                        onClick={() => closeDrawer()}
                      >
                        <Image
                          className="text-[#111928]"
                          alt="back"
                          width={10}
                          height={16}
                          src={backIcon}
                        />
                      </div>
                      {/* <span className=" text-[15px] font-medium leading-[17.1px] text-[#374151]">
                        Created on&nbsp;
                        {moment(task?.createdAt).format('DD MMM, YYYY')}
                      </span> */}
                    </div>

                    {/* Right Section with Time Tracking and More Icon */}
                    <div className="flex items-center gap-[16px]">
                      <div className="flex-1">
                        {(task?.reminder_option !== 'no_notify' ||
                          (task?.repeat &&
                            task?.repeat !== 'no_repetition')) && (
                          <span className="text-gray-500">
                            {' '}
                            <div
                              className="flex gap-5"
                              onMouseEnter={() =>
                                setIsReminderPopoverOpen(true)
                              }
                              onMouseLeave={() =>
                                setIsReminderPopoverOpen(false)
                              }
                            >
                              <Popover
                                placement="bottom"
                                className="demo_test w-[300px] gap-2"
                                isOpen={isReminderPopoverOpen}
                                showArrow={false}
                                content={() => (
                                  <div className="flex flex-col items-start gap-5 p-3">
                                    <div className="flex flex-row space-x-4">
                                      <div className="flex flex-col items-start">
                                        <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                          Reminder Time
                                        </span>
                                        <Select
                                          options={reminderOptions}
                                          onChange={(event: any) => {
                                            setSelectedReminder(event);
                                          }}
                                          value={selectedReminder}
                                          className="mt-2 w-auto"
                                          selectClassName="!text-[#141414] poppins_font_number !bg-white"
                                          disabled={isView}
                                        />
                                        {/* {errors?.reminder && (
                    <p className="mt-2 text-sm text-red-600">
                      {errors.reminder.message}
                    </p>
                  )} */}
                                      </div>
                                      <div className="flex flex-col items-start">
                                        <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                          Repeat
                                        </span>
                                        <Select
                                          options={RepeatOptions}
                                          onChange={(event: any) => {
                                            setSelectedRepetition(event);
                                          }}
                                          value={selectedRepetition}
                                          className="mt-2 w-auto"
                                          selectClassName="!text-[#141414] poppins_font_number !bg-white"
                                          disabled={isView}
                                        />
                                      </div>
                                    </div>
                                    {['custom'].includes(
                                      selectedReminder?.value
                                    ) && (
                                      <div className="task_form_date_picker_close_button_hide flex flex-col items-start">
                                        <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                          Select Reminder Date & Time
                                        </span>
                                        <Controller
                                          name="reminder_date"
                                          control={control}
                                          render={({
                                            field: { value, onChange },
                                          }) => (
                                            <DatePicker
                                              selected={value}
                                              placeholderText={
                                                'Select reminder date'
                                              }
                                              onChange={onChange}
                                              selectsStart
                                              startDate={value}
                                              minDate={new Date()}
                                              showTimeSelect
                                              isClearable={true}
                                              popperPlacement="bottom-end"
                                              className="mt-2 w-[430px] bg-[#F9FAFB]"
                                              dateFormat="MMMM d, yyyy h:mm aa"
                                              inputProps={{
                                                inputClassName: 'font-sans', // Custom class for the input
                                              }}
                                              disabled={isView}
                                            />
                                          )}
                                        />
                                        {errors?.reminder_date && (
                                          <p className="mt-2 text-sm text-red-600">
                                            {errors.reminder_date.message}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                )}
                              >
                                <Switch
                                  className="[&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                                  variant="active"
                                  switchClassName={`${
                                    (task?.reminder_option &&
                                      task?.reminder_option !== 'no_notify') ||
                                    (task?.repeat &&
                                      task?.repeat !== 'no_repetition')
                                      ? '!bg-[#362F78]'
                                      : '!bg-white'
                                  }`}
                                  handlerClassName={`${
                                    (task?.reminder_option &&
                                      task?.reminder_option !== 'no_notify') ||
                                    (task?.repeat &&
                                      task?.repeat !== 'no_repetition')
                                      ? '!bg-white'
                                      : '!bg-[#362F78]'
                                  } w-[13px] h-[13px]`}
                                  label="Task reminder"
                                  labelClassName=" text-[14px] leading-[16.8px] text-[#141414]"
                                  labelPlacement="left"
                                  onChange={(e) =>
                                    setIsReminder(e?.target?.checked)
                                  }
                                  checked={
                                    (task?.reminder_option &&
                                      task?.reminder_option !== 'no_notify') ||
                                    (task?.repeat &&
                                      task?.repeat !== 'no_repetition')
                                  }
                                  disabled={isView}
                                />
                              </Popover>
                            </div>
                          </span>
                        )}
                      </div>
                      {editMode &&
                        settingData?.task?.time_tracking?.length > 0 &&
                        checkAssigneExist(signIn?.user?.data?.user?._id) &&
                        !task?.mark_as_done &&
                        (isRunning &&
                        activeTimerData?.task_detail?._id === task?._id ? (
                          <div
                            className="flex h-[32px] w-[100px] cursor-pointer items-center justify-center gap-[7px] rounded-[8px] border border-[#6875F5] transition hover:bg-[#EBF0FF]"
                            onClick={handleStopClick}
                          >
                            <Tooltip
                              className="z-50"
                              size="sm"
                              content={() => (
                                <div className="w-[300px] break-all">
                                  {capitalizeFirstLetter(
                                    activeTimerData?.task_detail?.title
                                  )}
                                </div>
                              )}
                              placement="bottom"
                              color="invert"
                              showArrow
                            >
                              <div>
                                <div className="flex gap-2  p-2">
                                  <FaRegStopCircle
                                    onClick={handleStopClick}
                                    className="h-4 w-4 cursor-pointer text-[#D33D44]"
                                  />
                                  <span className="poppins_font_number">
                                    {formatTime(time)}
                                  </span>
                                </div>
                              </div>
                            </Tooltip>
                          </div>
                        ) : (
                          <div
                            className="flex h-[32px] w-[169px] cursor-pointer items-center justify-center gap-[8px] rounded-[8px] border border-[#6875F5] transition hover:bg-[#EBF0FF]"
                            onClick={() => handleTimerClick(task)}
                          >
                            <Image
                              className="text-[#5850EC]"
                              alt="clock"
                              width={16}
                              height={16}
                              src={Clock}
                            />
                            <span className=" text-[14px] font-medium leading-[19.6px] text-[#5850EC]">
                              Start time tracking
                            </span>
                          </div>
                        ))}

                      {/* Three-Dot Icon */}
                      {!task?.mark_as_done &&
                        !['client'].includes(signIn?.role) && (
                          <Popover
                            placement="bottom"
                            className=" demo_test min-w-[100px] p-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                            content={({ setOpen }) => {
                              return (
                                <div className="p-2 text-gray-900">
                                  {!task?.mark_as_archived && canLeaveTask && (
                                    <div className="cursor-pointer">
                                      <Popover
                                        placement="top-start"
                                        className="demo_test"
                                        content={({ setOpen }) => {
                                          const handleLeaveTaskClick = () => {
                                            dispatch(
                                              postLeaveTask({
                                                task_id: rowData?._id,
                                              })
                                            ).then((result: any) => {
                                              if (
                                                postLeaveTask.fulfilled.match(
                                                  result
                                                )
                                              ) {
                                                if (
                                                  result &&
                                                  result.payload.success ===
                                                    true
                                                ) {
                                                  onClose();
                                                  // agency will there in task listing if leaved task but client task list not
                                                  if (!gridView) {
                                                    dispatch(
                                                      getAllTask({
                                                        ...paginationParams,
                                                        board_id: boardId,
                                                        pagination: true,
                                                      })
                                                    );
                                                  } else {
                                                    updateTask(
                                                      rowData?._id,
                                                      'delete_task',
                                                      {
                                                        section_id:
                                                          task?.status?._id,
                                                      },
                                                      oldTasks,
                                                      oldTasksSections
                                                    );
                                                  }
                                                }
                                              }
                                            });

                                            setOpen(false);
                                          };

                                          return (
                                            <div className="w-56 pb-2 pt-1 text-left rtl:text-right">
                                              <Title
                                                as="h6"
                                                className="mb-0.5 flex items-start gap-2 text-sm text-gray-700 sm:items-center"
                                              >
                                                Leave the task
                                              </Title>
                                              <Text className="mb-2 leading-relaxed text-gray-500">
                                                Are you sure you want to leave
                                                the task?
                                              </Text>
                                              <div className="flex items-center justify-end">
                                                <Button
                                                  size="sm"
                                                  className="me-1.5 h-7"
                                                  onClick={handleLeaveTaskClick}
                                                >
                                                  Yes
                                                </Button>
                                                <Button
                                                  size="sm"
                                                  variant="outline"
                                                  className="h-7"
                                                  onClick={() => setOpen(false)}
                                                >
                                                  No
                                                </Button>
                                              </div>
                                            </div>
                                          );
                                        }}
                                      >
                                        <Button
                                          variant="text"
                                          className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                          disabled={task?.mark_as_archived}
                                        >
                                          {task?.parent_task
                                            ? 'Leave Subtask'
                                            : 'Leave Task'}
                                        </Button>
                                      </Popover>
                                    </div>
                                  )}
                                  {(['agency'].includes(signIn?.role) ||
                                    (['team_agency', 'team_client'].includes(
                                      signIn?.role
                                    ) &&
                                      checkPermission(
                                        'projects',
                                        'tasks',
                                        'update',
                                        signIn?.permission
                                      ))) &&
                                    !task?.mark_as_done && (
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                        onClick={() => {
                                          closeDrawer();
                                          openModal({
                                            view: (
                                              <EditTaskForm
                                                rowData={task}
                                                editMode={true}
                                                onClose={closeModal}
                                                createTask={createTask}
                                                updateTask={updateTask}
                                              />
                                            ),
                                            customSize: '800px',
                                          });
                                          setOpen(false);
                                        }}
                                      >
                                        {task?.parent_task
                                          ? 'Edit Subtask'
                                          : 'Edit Task'}
                                      </Button>
                                    )}

                                  {!task?.mark_as_done &&
                                    (['agency'].includes(signIn?.role) ||
                                      (['team_agency', 'team_client'].includes(
                                        signIn?.role
                                      ) &&
                                        checkPermission(
                                          'projects',
                                          'tasks',
                                          'create',
                                          signIn?.permission
                                        ))) && (
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                        onClick={() => {
                                          if (!duplicateTaskLoading) {
                                            onDuplicateTask(task, setOpen);
                                          }
                                        }}
                                        disabled={duplicateTaskLoading}
                                      >
                                        {task?.parent_task
                                          ? 'Duplicate Subtask'
                                          : 'Duplicate Task'}
                                      </Button>
                                    )}
                                  <div className="w-full border border-[#E5E7EB]"></div>
                                  {!task?.mark_as_done &&
                                    (['agency'].includes(signIn?.role) ||
                                      (['team_client', 'team_agency'].includes(
                                        signIn?.role
                                      ) &&
                                        checkPermission(
                                          'projects',
                                          'tasks',
                                          'delete',
                                          signIn?.permission
                                        ))) && (
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start px-2 py-2.5 text-[#EC221F] hover:bg-gray-100 hover:text-[#EC221F] focus:outline-none dark:hover:bg-gray-50"
                                        onClick={() => {
                                          setShowDeleteConfirmationPopper(true);
                                        }}
                                        disabled={task?.mark_as_archived}
                                      >
                                        {task?.parent_task
                                          ? 'Delete Subtask'
                                          : 'Delete Task'}
                                      </Button>
                                    )}
                                </div>
                              );
                            }}
                          >
                            <ActionIcon
                              title={'More Options'}
                              className="h-4 w-4 !p-0"
                              variant="text"
                            >
                              {' '}
                              <Image
                                alt="more"
                                width={20}
                                height={20}
                                color="#111928"
                                src={morehorizontal} // Replace with your three-dot menu icon asset
                                className="cursor-pointer"
                              />
                            </ActionIcon>
                          </Popover>
                        )}
                    </div>
                  </div>
                )}

                {/* Inbox Task view Actions */}

                {isInboxTaskView && (
                  <div className="my-4 flex h-[32px] w-full items-center justify-start gap-3">
                    <button
                      className="cursor-pointer"
                      onClick={() => closeDrawer()}
                    >
                      <Image
                        className="text-[#111928]"
                        alt="back"
                        width={10}
                        height={16}
                        src={backIcon}
                      />
                    </button>
                    <Link
                      href={
                        task?.board_id
                          ? `${routes.boardDetails(
                              defaultWorkSpace?.name,
                              task?.board_id ?? ''
                            )}?task_id=${task?._id ?? ''}`
                          : ''
                      }
                    >
                      <Button
                        className="flex items-center gap-2 rounded-lg border border-[#E5E7EB] text-black"
                        variant="outline"
                        // onClick={() => {
                        //   if (task?.board_id && task?._id) {
                        //     router.push(
                        //       `${routes.boardDetails(
                        //         defaultWorkSpace?.name,
                        //         task?.board_id ?? ''
                        //       )}?task_id=${task?._id ?? ''}`
                        //     );
                        //   }
                        // }}
                      >
                        Go to task full view{' '}
                        <FaArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                )}

                <SimpleBar
                  className={cn(
                    `overflow-y-auto overflow-x-hidden`,
                    activeTab === 'Comments' &&
                      !task?.mark_as_done &&
                      !task?.mark_as_archived
                      ? 'h-[73vh] 4xl:h-[100vh]'
                      : 'h-[86vh] ',
                    isInboxTaskView && '!h-[100vh]'
                  )}
                >
                  <div className="mb-[20px] ml-0 mr-[20px] mt-[15px]">
                    <span className=" text-[22px] font-bold leading-[30px] text-[#111928]">
                      {capitalizeFirstLetter(task?.title)}
                    </span>
                    <div className="mt-1 flex items-center gap-x-2">
                      <span className="font-['Raleway'] text-[14px] font-medium leading-[14.97px] text-[#111928]">
                        Created:
                      </span>

                      <figure className="relative h-8 w-8 overflow-hidden rounded-full">
                        <Avatar
                          src={
                            task?.assigned_by_profile
                              ? `${process.env.NEXT_PUBLIC_API}/uploads/${task?.assigned_by_profile}`
                              : Profile?.src
                          }
                          name={`${task?.assigned_by_first_name ?? ''} ${
                            task?.assigned_by_last_name ?? ''
                          }`}
                          size="sm"
                          className="bg-[#70C5E0] font-medium text-white"
                        />
                      </figure>

                      <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                        {capitalizeFirstLetter(task?.assigned_by_first_name)}{' '}
                        {capitalizeFirstLetter(task?.assigned_by_last_name)}
                      </span>

                      <span className="text-[16px] leading-[17.1px] text-[#B3B3B3]">
                        |
                      </span>

                      <span className="text-[14px] font-normal leading-[14.97px] text-[#111928]">
                        {moment(task?.createdAt).format('DD MMM, YYYY')}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-5">
                    <div className="grid grid-cols-3 ">
                      <div className=" col-span-1 flex items-center gap-[12px]">
                        <Image
                          // className="text-[#5850EC]"
                          alt="users"
                          width={16}
                          height={16}
                          src={Users}
                        />
                        <span className=" text-base font-medium leading-[17.1px] text-[#374151]">
                          Assignee
                        </span>
                      </div>
                      <div className="col-span-2 flex items-center">
                        <div>
                          {showPopper && (
                            <div>
                              <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                                <div
                                  className="relative overflow-hidden rounded-lg bg-white shadow-lg "
                                  style={{
                                    width: '600px',
                                    height: '475px',
                                  }}
                                >
                                  <AddMembers
                                    onClose={() => setShowPopper(false)}
                                    selectedMembers={selectedMembers}
                                    setSelectedMembers={setSelectedMembers}
                                    formPage={true}
                                    addTaskMember={true}
                                    isView={true}
                                  />
                                </div>
                              </div>
                            </div>
                          )}
                          {/* showing symbol when edit mode and task is completed and no members in task */}
                          {isView && selectedMembers?.length === 0 && (
                            <div className="flex h-[30px] w-[30px] items-center justify-center rounded-full border-[2px] border-dashed p-1">
                              <LuUser2 className="h-[1.2rem] w-[1.2rem]" />
                            </div>
                          )}
                          <div
                            className={cn(
                              'ml-4 flex items-center backdrop-blur-sm backdrop-filter',
                              isDisable ? 'cursor-not-allowed' : ''
                            )}
                            // onClick={() => {
                            //   task?.mark_as_done ? null : setShowPopper(true);
                            // }}
                            onClick={() => {
                              setShowPopper(true);
                            }}
                          >
                            {/* Showing selected members for roles other than 'team_client' */}
                            {signIn?.role !== 'team_client' &&
                              clientTeamAllOptions?.length > 0 &&
                              clientTeamAllOptions
                                ?.filter(
                                  (item) =>
                                    selectedMembers?.includes(
                                      item?.user_id as never
                                    )
                                )
                                ?.slice(0, 3) // Limit to the first 4 members
                                ?.map((item) => (
                                  <figure
                                    key={item?.user_id}
                                    className={cn(
                                      'relative z-10 ml-[-13px] flex h-10 w-10 cursor-pointer items-center rounded-full focus:border-2 focus:border-gray-900',
                                      isDisable ? 'cursor-not-allowed' : ''
                                    )}
                                  >
                                    <Avatar
                                      src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                                      name={displayName(item)}
                                      className="!h-[32px] !w-[32px] bg-[#70C5E0] font-medium text-white"
                                    />
                                  </figure>
                                ))}

                            {/* Showing selected members for 'team_client' */}
                            {editMode &&
                              signIn?.role === 'team_client' &&
                              task?.assign_to
                                ?.slice(0, 3)
                                ?.map((member: any) => (
                                  <figure
                                    key={member?.id}
                                    className="relative z-10 ml-[-13px] h-10 w-10 cursor-pointer rounded-full focus:border-2 focus:border-gray-900"
                                  >
                                    <Avatar
                                      src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                      name={displayName(member)}
                                      className="!h-[32px] !w-[32px] bg-[#70C5E0] font-medium text-white"
                                    />
                                  </figure>
                                ))}

                            {/* Show the "+X" badge if there are more members */}
                            {selectedMembers?.length > 3 && (
                              <div className="poppins_font_number relative flex h-[32px] w-[32px] cursor-pointer items-center justify-center rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]">
                                +{selectedMembers?.length - 3}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-3">
                      <div className=" col-span-1 flex items-center gap-[12px]">
                        <Image
                          // className="text-[#5850EC]"
                          alt="Glyph"
                          width={16}
                          height={16}
                          src={Glyph}
                        />
                        <span className=" text-base font-medium leading-[17.1px] text-[#374151]">
                          Priority
                        </span>
                      </div>
                      {/* <div className="flex h-[32px] w-[150px] items-center">
                        <Controller
                          control={control}
                          name="priority"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              // size="sm"
                              variant="text"
                              value={selectedPriority}
                              onChange={(selectedOption: any) => {
                                setSelectedPriority(selectedOption);
                                setValue('priority', selectedOption?.value);
                                setError('priority', { message: '' });
                                // handleApiCall({ _id: dataa?._id, status: selectedOption?.value })
                              }}
                              options={priorityOptions}
                              disabled={isView}
                              placeholder="Select priority"
                              error={errors?.priority?.message}
                              className={cn(
                                'task_select_dropdown w-[300px] focus:border-white focus:outline-none focus:ring-white',
                                task?.mark_as_done &&
                                  'task_select_dropdown_suffix_icon_remove focus:border-white focus:outline-none focus:ring-white'
                              )}
                              // displayValue={statusValue}
                              // placement="bottom-end"
                              // useContainerWidth={false}
                              dropdownClassName="p-2 gap-1 grid text-red"
                              selectClassName="focus:outline-none focus:border-white focus:ring-white m-0 !p-0"
                              suffix={
                                <PiCaretDownBold className="hidden h-3 w-3" />
                              }
                            />
                          )}
                        />
                      </div> */}
                      <div
                        className={` flex w-fit items-center gap-1 rounded-lg px-2 py-1.5 text-sm font-medium  ${
                          task?.priority === 'high'
                            ? 'bg-[#FFD4C6] text-red-dark'
                            : task?.priority === 'medium'
                              ? 'bg-[#FBF0DE]   text-orange-dark'
                              : 'bg-[#E4F6D6] text-green-dark'
                        }`}
                      >
                        <GoDotFill className="h-4 w-4" />
                        {capitalizeFirstLetter(task?.priority) || 'N/A'}
                      </div>
                    </div>
                    <div className="grid grid-cols-3">
                      <div className=" col-span-1 flex items-center gap-[12px]">
                        <Image
                          // className="text-[#5850EC]"
                          alt="timelapse"
                          width={16}
                          height={16}
                          src={timelapse}
                        />
                        <span className=" text-base font-medium leading-[17.1px] text-[#374151]">
                          Status
                        </span>
                      </div>
                      <div
                        className="col-span-2 flex w-fit items-center gap-1 rounded-md px-2 py-1.5"
                        style={{
                          backgroundColor: sections?.find(
                            (section: any) => section?._id === task?.status?._id
                          )?.color,
                          color: sections?.find(
                            (section: any) => section?._id === task?.status?._id
                          )?.test_color,
                        }}
                      >
                        <GoDotFill className="h-4 w-4" />
                        {task?.status?.section_name}
                      </div>
                      {/* <Controller
                          control={control}
                          name="status"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              // size="sm"
                              variant="text"
                              value={selectedStatus}
                              onChange={(selectedOption: any) => {
                                // console.log("selected status...", selectedOption)
                                setSelectedStatus(selectedOption);
                                setValue('status', selectedOption?.value);
                                setError('status', { message: '' });
                                task?.status?.section_name === 'Completed' &&
                                  setIsDisable(false);
                                // handleApiCall({ _id: dataa?._id, status: selectedOption?.value })
                              }}
                              disabled={isView}
                              options={statusOptions}
                              placeholder="Select status"
                              error={errors?.status?.message}
                              // displayValue={statusValue}
                              // placement="bottom-end"
                              // useContainerWidth={false}
                              className={cn(
                                'task_select_dropdown focus:border-white focus:outline-none focus:ring-white',
                                task?.mark_as_done &&
                                  'task_select_dropdown_suffix_icon_remove focus:border-white focus:outline-none focus:ring-white'
                              )}
                              selectClassName="m-0 focus:outline-none focus:border-white focus:ring-white !p-0"
                              dropdownClassName="p-2 gap-1 grid text-red"
                              suffix={
                                <PiCaretDownBold className="hidden h-3 w-3" />
                              }
                            />
                          )}
                        /> */}
                    </div>
                    <div className="grid grid-cols-3">
                      <div className="flex items-start gap-[12px]">
                        <Image alt="tags" width={15} height={15} src={Tagss} />
                        <span className=" text-base font-medium leading-[17.1px] text-[#374151]">
                          Tags
                        </span>
                      </div>
                      <div className="col-span-2 flex h-auto w-full flex-wrap items-center gap-2 ">
                        {tags && tags.length > 0 ? (
                          <>
                            {tags.slice(0, 5).map((tag, index) => (
                              <div
                                key={index}
                                style={{
                                  backgroundColor: tag.tag_color || '#E4E7EB',
                                }}
                                className="flex items-center gap-2 break-words rounded-lg bg-[#E4E7EB] px-3 py-1 text-sm font-medium capitalize text-black dark:bg-[#2D3748] dark:text-[#CBD5E0]"
                              >
                                {tag?.tag_name.length > 13 ? (
                                  <Tooltip
                                    size="sm"
                                    content={() => (
                                      <div className="max-w-[200px] text-xs">
                                        {tag?.tag_name}
                                      </div>
                                    )}
                                    placement="top"
                                    color="invert"
                                    className="demo_test"
                                  >
                                    <span className="max-w-[120px] truncate">
                                      {tag?.tag_name}
                                    </span>
                                  </Tooltip>
                                ) : (
                                  <span className="max-w-[120px] truncate">
                                    {tag?.tag_name}
                                  </span>
                                )}
                              </div>
                            ))}

                            {tags.length > 5 && (
                              <Popover
                                placement="top"
                                className="demo_test z-[9999] flex !max-w-[400px] flex-wrap gap-2"
                                content={({ setOpen }) => (
                                  <div className="flex !max-w-[400px] flex-wrap overflow-y-auto gap-2">
                                    {tags.map((tag, index) => (
                                      <div
                                        key={index}
                                        style={{
                                          backgroundColor:
                                            tag.tag_color || '#E4E7EB',
                                        }}
                                        className="flex items-center gap-2 break-words rounded-lg bg-[#E4E7EB] px-3 py-1 text-xs font-normal capitalize text-black dark:bg-[#2D3748] dark:text-[#CBD5E0]"
                                      >
                                        {tag?.tag_name.length > 13 ? (
                                          <Tooltip
                                            size="sm"
                                            content={() => (
                                              <div className="max-w-[200px] text-xs">
                                                {tag?.tag_name}
                                              </div>
                                            )}
                                            placement="top"
                                            color="invert"
                                            className="demo_test"
                                          >
                                            <span className="max-w-[120px] truncate">
                                              {tag?.tag_name}
                                            </span>
                                          </Tooltip>
                                        ) : (
                                          <span className="max-w-[120px] truncate">
                                            {tag?.tag_name}
                                          </span>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                )}
                              >
                                <div className="poppins_font_number flex cursor-pointer items-center justify-center gap-1 rounded-lg bg-[#E5E7EB] px-3 py-1 text-[14px] font-medium text-black">
                                  +{tags.length - 5} more
                                </div>
                              </Popover>
                            )}
                          </>
                        ) : (
                          'No tags available'
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-3">
                      <div className=" flex items-center gap-[12px]">
                        <Image
                          // className="text-[#5850EC]"
                          alt="Calendar"
                          width={15}
                          height={15}
                          src={Calendar}
                        />
                        <span className=" text-[16px] font-medium leading-[17.1px] text-[#374151]">
                          Due Date
                        </span>
                      </div>
                      <div className="col-span-2 flex items-center">
                        <span className=" text-[15px] font-medium leading-[17.1px] text-[#374151]">
                          {task?.due_date ? (
                            moment(task?.due_date).format('MMM D, YYYY h:mm A')
                          ) : (
                            <div className="mt-1 flex h-[30px] w-[30px] items-center justify-center rounded-full border-[2px] border-dashed p-1">
                              <PiCalendarBlankLight className="h-[1rem] w-[1rem]" />
                            </div>
                          )}
                        </span>
                      </div>
                    </div>
                    {task?.agenda && (
                      <div className="mt-[30px] w-[576px]">
                        <span className=" text-[16px] font-bold leading-[19.2px] text-[#111928]">
                          Description
                        </span>
                        <SimpleBar className="mt-2 max-h-[78px] w-[576px] overflow-y-auto overflow-x-hidden">
                          <span className=" text-[16px] font-medium leading-[24px] text-[#4B5563]">
                            {stripHtml(task?.agenda)}
                          </span>
                        </SimpleBar>
                      </div>
                    )}
                    {/* First part: Recurring Task */}
                    {!task?.parent_task && (
                      <div className="grid grid-cols-3">
                        <span className=" col-span-1 flex items-center text-[16px] font-bold leading-[19.2px] text-[#111928]">
                          Recurring Task active
                        </span>
                        <Select
                          options={RecurringArray}
                          onChange={(event) =>
                            onChangeRecurring(event, setValue)
                          }
                          value={selectedRecurringOption}
                          className="cols-span-2 w-fit"
                          optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                          selectClassName="!text-[#5850EC]  border-[#6875F5] poppins_font_number focus:border-[#5850EC] hover:border-[#5850EC] !bg-[#F0F2FE]"
                          disabled={isView}
                        />
                      </div>
                    )}
                    {/* <span className="text-gray-500">
                            <div
                              className="flex gap-5"
                              onMouseEnter={() => setIsPopoverOpen(true)}
                              onMouseLeave={() => setIsPopoverOpen(false)}
                            >
                              <div className="flex flex-col items-start gap-5">
                                <div className="">
                                  <div className="flex flex-col gap-5">
                                    
                                    Repeat every and End date
                                    {['daily', 'weekly', 'monthly'].includes(
                                      selectedRecurringOption?.value
                                     ) && (
                                      <div className="flex flex-wrap gap-2">
                                        <div className="w-[145px]">
                                          <span className=" text-[16px] font-medium leading-[17.1px] text-[#374151]">
                                            Starts from
                                          </span>
                                          <Controller
                                            name="recurrence_start_date"
                                            control={control}
                                            render={({
                                              field: { value, onChange },
                                            }) => (
                                              <DatePicker
                                                placeholderText="Select date"
                                                selected={value}
                                                inputProps={{
                                                  inputClassName: 'bg-white',
                                                  error: errors
                                                    ?.recurrence_start_date
                                                    ?.message as string,
                                                }}
                                                onChange={(date: any) => {
                                                  console.log(date);
                                                }}
                                                selectsStart
                                                startDate={value}
                                                // minDate={new Date()}
                                                // maxDate={watch('recurrence_end_date')}
                                                // dateFormat="MMMM dd, yyyy"
                                                className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                                disabled={isView}
                                              />
                                            )}
                                          />
                                        </div>
                                        {selectedRecurringOption?.value ===
                                          'monthly' && (
                                          <div className="w-[104px]">
                                            <span className=" text-[16px] font-medium leading-[17.1px] text-[#374151]">
                                              Select Day
                                            </span>
                                            <div className="mt-2 flex items-center gap-1">
                                              <Controller
                                                name="monthly_recurrence_day_of_month"
                                                control={control}
                                                render={({
                                                  field: { onChange, value },
                                                }) => (
                                                  <Select
                                                    options={monthDate}
                                                    onChange={onChange}
                                                    value={value}
                                                    placeholder="Select date"
                                                    className="w-[68px]"
                                                    optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                                    selectClassName="!text-[#111928] border-[#E5E7EB] font-medium text-sm leading-[19.6px] h-10 border rounded-[10px] font-['Raleway'] focus:border-[#111928] hover:border-[#111928] !bg-white"
                                                    disabled={isView}
                                                  />
                                                )}
                                              />
                                              <p className="font-['Raleway'] text-[12px] font-normal leading-[14.4px] text-[#111928]">
                                                of every month
                                              </p>
                                            </div>
                                            {errors?.monthly_recurrence_day_of_month && (
                                              <p className="mt-2 text-sm text-red-600">
                                                {
                                                  errors
                                                    ?.monthly_recurrence_day_of_month
                                                    ?.message as string
                                                }
                                              </p>
                                            )}
                                          </div>
                                        )}
                                        <div className="w-[130px]">
                                          <span className=" text-[16px] font-medium leading-[17.1px] text-[#374151]">
                                            At Time
                                          </span>
                                          <Controller
                                            name="recurrence_start_at_time"
                                            control={control}
                                            render={({
                                              field: { value, onChange },
                                            }) => (
                                              <DatePicker
                                                placeholderText="Start time"
                                                selected={value}
                                                inputProps={{
                                                  inputClassName: 'bg-white',
                                                  error: errors
                                                    ?.recurrence_start_at_time
                                                    ?.message as string,
                                                }}
                                                selectsStart
                                                startDate={value}
                                                showTimeSelect
                                                onChange={(date: any) => {
                                                  console.log(date);
                                                }}
                                                showTimeSelectOnly
                                                dateFormat="hh:mm aa"
                                                className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                                disabled={isView}
                                              />
                                            )}
                                          />
                                        </div>
                                        {selectedRecurringOption?.value ===
                                          'weekly' && (
                                          <div>
                                            <span className=" text-[16px] font-medium leading-[17.1px] text-[#374151]">
                                              Days of the week
                                            </span>
                                            <div className="mt-2 flex gap-1">
                                              {weekdays.map((day) => (
                                                <Controller
                                                  key={day.value}
                                                  control={control}
                                                  name="weekly_recurrence_days"
                                                  render={({
                                                    field: { value, onChange },
                                                  }) => (
                                                    <label
                                                      className={`flex h-[40px] w-[32px] cursor-pointer items-center justify-center rounded-full border ${
                                                        value?.includes(
                                                          day.value
                                                        )
                                                          ? 'bg-[#EDEBFE] text-[#42389D]'
                                                          : 'bg-white text-[#4B5563]'
                                                      }`}
                                                    >
                                                      <input
                                                        type="checkbox"
                                                        className="hidden"
                                                        checked={value?.includes(
                                                          day.value
                                                        )}
                                                        onChange={(e) => {
                                                          const isChecked =
                                                            e.target.checked;
                                                          const newValues =
                                                            isChecked
                                                              ? [
                                                                  ...(value ||
                                                                    []),
                                                                  day.value,
                                                                ] // Add selected day
                                                              : (
                                                                  value || []
                                                                ).filter(
                                                                  (v: any) =>
                                                                    v !==
                                                                    day.value
                                                                ); // Remove unselected day
                                                          onChange(newValues);
                                                        }}
                                                        disabled={isView}
                                                      />
                                                      {day.name}
                                                    </label>
                                                  )}
                                                />
                                              ))}
                                            </div>
                                            {errors.weekly_recurrence_days && (
                                              <p className="mt-1 text-sm text-red-600">
                                                {
                                                  errors.weekly_recurrence_days
                                                    .message
                                                }
                                              </p>
                                            )}
                                          </div>
                                        )}
                                        {selectedRecurringOption?.value ===
                                          'weekly' && (
                                          <div className="w-full" />
                                        )}
                                        <div className="w-[145px]">
                                          <span className=" text-[16px] font-medium leading-[17.1px] text-[#374151]">
                                            Ends on
                                          </span>
                                          <Controller
                                            name="recurrence_end_date"
                                            control={control}
                                            render={({
                                              field: { value, onChange },
                                            }) => (
                                              <DatePicker
                                                disabled={isView}
                                                placeholderText="Select date"
                                                selected={value}
                                                inputProps={{
                                                  inputClassName: 'bg-white',
                                                  error: errors
                                                    ?.recurrence_end_date
                                                    ?.message as string,
                                                }}
                                                onChange={onChange}
                                                selectsStart
                                                startDate={value}
                                                minDate={
                                                  watch(
                                                    'recurrence_start_date'
                                                  ) == null
                                                    ? new Date()
                                                    : watch(
                                                        'recurrence_start_date'
                                                      )
                                                } // dateFormat="MMMM dd, yyyy"
                                                // dateFormat="MMMM dd, yyyy"
                                                className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                              />
                                            )}
                                          />
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </span> */}
                    {task?.custom_fields?.length > 0 && (
                      <>
                        <span className=" text-base font-bold leading-[19.2px] text-[#111928]">
                          Custom Fields
                        </span>
                        <div className="flex flex-col gap-4">
                          {task?.custom_fields.map((field: any, index: any) => (
                            <div key={index} className="grid grid-cols-3">
                              <span className="col-span-1 text-base font-semibold leading-[17.1px] text-[#374151]">
                                {field.fieldName}
                              </span>
                              <span className="col-span-2 text-base font-medium text-[#374151]">
                                {field.value === null || !field.value
                                  ? 'NA'
                                  : field.value === true
                                    ? 'True'
                                    : field.fieldType === 'date'
                                      ? moment(field.value).format(
                                          'DD MMM, YYYY'
                                        )
                                      : field.value}{' '}
                              </span>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                  <div className="mt-6  gap-[16px]">
                    <div className="flex h-[44px] w-fit items-center gap-1 rounded-[8px] border bg-[#F9FAFB] p-[6px] px-[10px]">
                      {/* Comments Tab */}
                      <span
                        onClick={() => {
                          setActiveTab('Comments');
                          setOpenSections({});
                          setSectionData({});
                          setMylogsSectionData({});
                          setmyLogsopenSections({});
                          setPayload({
                            page: 1,
                            items_per_page: 5,
                            task_id: '',
                            all_user: false,
                          });
                          sethasMore(true);
                          setUpdateddata([]);
                          setSkeletonloader(true);
                          setTotalActivityData(0);
                          setsetsingleActivity({});
                          setsingleActivitySkeletonloader({});
                          setTotalsingleActivityData({});
                          setsingleActivityPayload({});
                          setSingleActivityhasMore({});
                          setsingleMylogData({});
                          setsingleMylogSkeletonloader({});
                          setTotalsingleMylogData({});
                          setsingleMylogpayload({});
                          setSingleMyloghasMore({});
                        }}
                        className={`cursor-pointer px-3 text-[14px] font-medium ${
                          activeTab === 'Comments'
                            ? 'rounded-[8px] border-[1px] border-[#D1D5DB] bg-white py-[6px] text-[#111928]'
                            : 'text-[#4B5563]'
                        }`}
                      >
                        Comments
                      </span>
                      {/* Subtasks Tab (conditionally rendered) */}

                      {!task?.parent_task && (
                        <span
                          onClick={() => {
                            setActiveTab('Subtasks');
                            setOpenSections({});
                            setSectionData({});
                            setMylogsSectionData({});
                            setmyLogsopenSections({});
                            setPayload({
                              page: 1,
                              items_per_page: 5,
                              task_id: '',
                              all_user: false,
                            });
                            sethasMore(true);
                            setUpdateddata([]);
                            setSkeletonloader(true);
                            setTotalActivityData(0);
                            setsetsingleActivity({});
                            setsingleActivitySkeletonloader({});
                            setTotalsingleActivityData({});
                            setsingleActivityPayload({});
                            setSingleActivityhasMore({});
                            setsingleMylogData({});
                            setsingleMylogSkeletonloader({});
                            setTotalsingleMylogData({});
                            setsingleMylogpayload({});
                            setSingleMyloghasMore({});
                          }}
                          className={`cursor-pointer px-3 text-[14px] font-medium ${
                            activeTab === 'Subtasks'
                              ? 'rounded-[8px] border-[1px] border-[#D1D5DB] bg-white py-[6px] text-[#111928]'
                              : 'text-[#4B5563]'
                          }`}
                        >
                          Subtasks
                        </span>
                      )}

                      {/* Attachments Tab */}
                      <span
                        onClick={() => {
                          setActiveTab('Attachments');
                          setOpenSections({});
                          setSectionData({});
                          setMylogsSectionData({});
                          setmyLogsopenSections({});
                          setPayload({
                            page: 1,
                            items_per_page: 5,
                            task_id: '',
                            all_user: false,
                          });
                          sethasMore(true);
                          setUpdateddata([]);
                          setSkeletonloader(true);
                          setTotalActivityData(0);
                          setsetsingleActivity({});
                          setsingleActivitySkeletonloader({});
                          setTotalsingleActivityData({});
                          setsingleActivityPayload({});
                          setSingleActivityhasMore({});
                          setsingleMylogData({});
                          setsingleMylogSkeletonloader({});
                          setTotalsingleMylogData({});
                          setsingleMylogpayload({});
                          setSingleMyloghasMore({});
                        }}
                        className={`cursor-pointer px-3 text-[14px] font-medium ${
                          activeTab === 'Attachments'
                            ? 'rounded-[8px] border-[1px] border-[#D1D5DB] bg-white py-[6px] text-[#111928]'
                            : 'text-[#4B5563]'
                        }`}
                      >
                        Attachments
                      </span>

                      {/* My logs and UserActivity tabs*/}

                      {['agency'].includes(signIn?.role) ||
                      (['team_agency', 'team_client'].includes(signIn?.role) &&
                        checkPermission(
                          'time_tracker',
                          null,
                          'everyone',
                          signIn?.permission
                        )) ? (
                        <span
                          onClick={() => setActiveTab('UserActivity')}
                          className={`cursor-pointer px-3 text-[14px] font-medium ${
                            activeTab === 'UserActivity'
                              ? 'rounded-[8px] border-[1px] border-[#D1D5DB] bg-white py-[6px] text-[#111928]'
                              : 'text-[#4B5563]'
                          }`}
                        >
                          User Activity
                        </span>
                      ) : ['client'].includes(signIn?.role) ||
                        (['team_agency', 'team_client'].includes(
                          signIn?.role
                        ) &&
                          checkPermission(
                            'time_tracker',
                            null,
                            'own',
                            signIn?.permission
                          )) ? (
                        <span
                          onClick={() => setActiveTab('MyLogs')}
                          className={`cursor-pointer px-3 text-[14px] font-medium ${
                            activeTab === 'MyLogs'
                              ? 'rounded-[8px] border-[1px] border-[#D1D5DB] bg-white py-[6px] text-[#111928]'
                              : 'text-[#4B5563]'
                          }`}
                        >
                          My Logs
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-4 w-[576px] border border-[#D1D5DB]"></div>

                    {/* Content Rendering Based on Active Tab */}
                    <div className="mt-4 h-[100px] w-[576px]">
                      {activeTab === 'Comments' && (
                        <div>
                          {' '}
                          <div className="pb-[25px]">
                            <span className=" text-[16px] font-bold leading-[19.2px] text-[#111928]">
                              Comments
                            </span>
                            <SimpleBar
                              className={cn(
                                'mt-2 w-[576px] overflow-y-auto 4xl:max-h-[30vh]',
                                isInboxTaskView
                                  ? 'max-h-[350px]'
                                  : 'max-h-[224px]'
                              )}
                            >
                              {taskData &&
                              taskData?.commentList?.comments?.length > 0
                                ? taskData?.commentList?.comments?.map(
                                    (user: any, index: number) => {
                                      // const isCurrentUser =
                                      //   user?.user_id === signIn?.userProfile?._id;

                                      return (
                                        <Fragment
                                          key={user.user_id + '-' + index}
                                        >
                                          {/* Comment Container */}
                                          <div className={`flex justify-start`}>
                                            <div
                                              className={`min-w-[11rem]  p-4 
                                        `}
                                            >
                                              {/* Name and Timestamp */}
                                              <div className="mb-1 flex items-center  gap-3">
                                                <figure
                                                  key={user?.user_id}
                                                  className="relative z-10 flex-shrink-0 cursor-pointer rounded-full focus:border-2 focus:border-gray-900"
                                                >
                                                  <Avatar
                                                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${user?.user_image}`}
                                                    name={displayName(user)}
                                                    className="!h-[32px] !w-[32px] bg-[#70C5E0] font-medium text-white"
                                                  />
                                                </figure>
                                                <div>
                                                  <span className=" text-[16px] text-sm font-semibold leading-[19.2px] text-[#111928]">
                                                    {user?.first_name
                                                      ? capitalizeFirstLetter(
                                                          user?.first_name
                                                        )
                                                      : '-'}{' '}
                                                    {user?.last_name
                                                      ? capitalizeFirstLetter(
                                                          user?.last_name
                                                        )
                                                      : '-'}
                                                  </span>
                                                </div>
                                                <span className=" text-xs text-[#4B5563]">
                                                  {getRelativeTime(
                                                    user?.createdAt
                                                  )}
                                                </span>
                                              </div>

                                              {/* Comment Text */}
                                              {user.comment && (
                                                <p
                                                  className="ml-1 text-sm font-semibold text-[#4B5563]"
                                                  dangerouslySetInnerHTML={{
                                                    __html:
                                                      updateMessageFormatWithMentionUser(
                                                        user.comment,
                                                        mention_users
                                                      ),
                                                  }}
                                                ></p>
                                              )}

                                              {/* Attachments */}
                                              {user?.attachments?.length >
                                                0 && (
                                                <div className="space-y-2">
                                                  {user.attachments.map(
                                                    (
                                                      image: any,
                                                      index: number
                                                    ) => {
                                                      const fileType =
                                                        getFileType(
                                                          image?.name
                                                        ); // Get the file type
                                                      const color =
                                                        getColor(fileType); // Assuming you have a utility to fetch colors

                                                      return (
                                                        <div
                                                          key={image?._id}
                                                          className="flex w-[530px] items-center justify-between py-2"
                                                        >
                                                          {/* File Information */}
                                                          <div
                                                            className={`flex items-center gap-2 rounded-lg p-2`}
                                                            style={{
                                                              backgroundColor:
                                                                color?.bgColor,
                                                              color:
                                                                color?.textColor,
                                                            }}
                                                          >
                                                            <CustomFileIcons
                                                              fileType={
                                                                fileType
                                                              }
                                                              iconClassName="!w-5 !h-5 text-[#6875F5]"
                                                            />
                                                            <p className=" max-w-[200px] truncate font-sans text-[14px]">
                                                              {image?.name}
                                                            </p>
                                                          </div>

                                                          {/* Download Icon */}
                                                          <div
                                                            onClick={() =>
                                                              downloadFiles([
                                                                `${process.env.NEXT_PUBLIC_IMAGE_URL}/${image?.preview} ${image?.name}`,
                                                              ])
                                                            }
                                                            className="flex cursor-pointer items-center text-gray-500 transition hover:text-gray-900"
                                                          >
                                                            <PiDownloadSimpleBold className="h-5 w-5 text-[#111928]" />
                                                          </div>
                                                        </div>
                                                      );
                                                    }
                                                  )}
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                        </Fragment>
                                      );
                                    }
                                  )
                                : 'No Comments Available'}
                            </SimpleBar>
                          </div>
                        </div>
                      )}
                      {!task?.parent_task && activeTab === 'Subtasks' && (
                        <div>
                          {' '}
                          <span className=" text-[16px] font-bold leading-[19.2px] text-[#111928]">
                            Subtasks ({task?.sub_tasks?.length})
                          </span>
                          <SimpleBar
                            className={cn(
                              ' mt-2 w-[576px] overflow-y-auto overflow-x-hidden pe-3 4xl:max-h-[100vh]',
                              isInboxTaskView
                                ? 'max-h-[350px]'
                                : 'max-h-[246px]'
                            )}
                          >
                            {task?.sub_tasks && task?.sub_tasks?.length > 0
                              ? task?.sub_tasks?.map(
                                  (subtask: any, index: number) => (
                                    <div
                                      className="mt-2 h-auto w-full cursor-pointer gap-[16px] rounded-[8px] border border-[#E5E7EB] px-3 py-2"
                                      key={subtask?.title}
                                      onClick={() => {
                                        if (
                                          isInboxTaskView &&
                                          subtask?.board_id &&
                                          subtask?._id
                                        ) {
                                          router.push(
                                            `${routes.boardDetails(
                                              defaultWorkSpace?.name,
                                              subtask?.board_id ?? ''
                                            )}?task_id=${subtask?._id ?? ''}`
                                          );
                                        } else {
                                          closeDrawer();
                                          openDrawer({
                                            view: (
                                              <ViewTaskFormSideBar
                                                rowData={subtask}
                                                editMode={true}
                                                onClose={closeDrawer}
                                                isView={true}
                                                isInboxTaskView={false}
                                              />
                                            ),
                                            placement: 'right',
                                            customSize: '640px',
                                          });
                                        }
                                      }}
                                    >
                                      <span className=" text-[16px] font-bold leading-[36px] text-[#111928]">
                                        {capitalizeFirstLetter(subtask?.title)}
                                      </span>
                                      <div className="flex h-[55px] w-[576px] gap-6">
                                        <div className="flex flex-col gap-2">
                                          <span className=" text-[12px] leading-[12.83px] text-[#374151]">
                                            Assignee
                                          </span>
                                          <div className="flex items-center justify-center">
                                            {subtask?.assign_to?.length > 0 ? (
                                              <div className="ms-3 flex items-center justify-center">
                                                {/* Show only the first 3 members */}
                                                {subtask?.assign_to
                                                  ?.slice(0, 3)
                                                  ?.map((member: any) => (
                                                    <figure
                                                      key={member?.id}
                                                      className={
                                                        'relative z-10 ml-[-13px] flex h-7 w-7 cursor-pointer items-center rounded-full focus:border-2 focus:border-gray-900'
                                                      }
                                                    >
                                                      <Avatar
                                                        src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                                        name={
                                                          capitalizeFirstLetter(
                                                            member?.first_name
                                                          ) +
                                                          ' ' +
                                                          capitalizeFirstLetter(
                                                            member?.last_name
                                                          )
                                                        }
                                                        size="sm"
                                                        className={
                                                          '!h-7 !w-7 bg-[#70C5E0] font-medium text-white'
                                                        }
                                                      />
                                                    </figure>
                                                  ))}

                                                {/* Show the "+X" badge if there are more members */}
                                                {subtask?.assign_to?.length >
                                                  3 && (
                                                  <div className="poppins_font_number ml-[-10px] flex h-[40px] w-[40px] items-center justify-center rounded-full text-[14px] font-medium text-[#9BA1B9]">
                                                    +
                                                    {subtask?.assign_to
                                                      ?.length - 3}
                                                  </div>
                                                )}
                                              </div>
                                            ) : (
                                              <div className="mt-1 flex h-[30px] w-[30px] items-center justify-center rounded-full border-[2px] border-dashed p-1">
                                                <LuUser2 className="h-[1rem] w-[1rem]" />
                                              </div>
                                            )}
                                          </div>
                                        </div>
                                        <div className="flex flex-col gap-2">
                                          <span className=" text-[12px] leading-[12.83px] text-[#374151]">
                                            Priority
                                          </span>
                                          <div
                                            className={` flex w-[80px] items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-medium  ${
                                              subtask?.priority === 'high'
                                                ? 'bg-[#FFD4C6] text-red-dark'
                                                : subtask?.priority === 'medium'
                                                  ? 'bg-[#FBF0DE]   text-orange-dark'
                                                  : 'bg-[#E4F6D6] text-green-dark'
                                            }`}
                                          >
                                            <GoDotFill className="h-4 w-4" />
                                            {capitalizeFirstLetter(
                                              subtask?.priority
                                            ) || 'N/A'}
                                          </div>{' '}
                                        </div>
                                        <div className="flex flex-col gap-2">
                                          <span className=" text-xs leading-[12.83px] text-[#374151]">
                                            Status
                                          </span>
                                          <div
                                            className=" flex w-[150px] gap-1 rounded-lg px-2 py-1.5 text-xs font-medium"
                                            style={{
                                              backgroundColor:
                                                subtask?.status?.color,
                                              color:
                                                subtask?.status?.test_color,
                                            }}
                                          >
                                            {subtask?.status?.section_name
                                              ?.length > 15 ? (
                                              <Tooltip
                                                size="sm"
                                                content={() => (
                                                  <div className="max-w-[200px] text-xs">
                                                    {
                                                      subtask?.status
                                                        ?.section_name
                                                    }
                                                  </div>
                                                )}
                                                placement="top"
                                                color="invert"
                                                className="demo_test"
                                              >
                                                <div className="flex truncate">
                                                  <GoDotFill className="h-4 w-4" />
                                                  <span className="truncate">
                                                    {
                                                      subtask?.status
                                                        ?.section_name
                                                    }
                                                  </span>
                                                </div>
                                              </Tooltip>
                                            ) : (
                                              <>
                                                <GoDotFill className="h-4 w-4" />
                                                <span className="truncate">
                                                  {
                                                    subtask?.status
                                                      ?.section_name
                                                  }
                                                </span>
                                              </>
                                            )}
                                          </div>
                                        </div>
                                        <div className="flex flex-col gap-2">
                                          <span className=" text-xs leading-[12.83px] text-[#374151]">
                                            Tags
                                          </span>
                                          <div className="flex flex-wrap items-center gap-2">
                                            {subtask?.tags &&
                                            subtask?.tags.length > 0 ? (
                                              <>
                                                {subtask.tags
                                                  .slice(0, 2)
                                                  .map(
                                                    (tag: any, index: any) => (
                                                      <div
                                                        key={index}
                                                        style={{
                                                          backgroundColor:
                                                            tag?.tag_color ||
                                                            '#E4E7EB', // Default color if not provided
                                                        }}
                                                        className="flex w-[70px] items-center gap-2 truncate rounded-lg bg-[#E4E7EB] px-2 py-1.5 text-xs  font-medium capitalize text-black dark:bg-[#2D3748] dark:text-[#CBD5E0]"
                                                      >
                                                        {tag?.tag_name.length >
                                                        9 ? (
                                                          <Tooltip
                                                            size="sm"
                                                            content={() => (
                                                              <div className="max-w-[200px] text-xs">
                                                                {tag?.tag_name}
                                                              </div>
                                                            )}
                                                            placement="top"
                                                            color="invert"
                                                            className="demo_test"
                                                          >
                                                            <p className="w-full truncate">
                                                              {tag?.tag_name}
                                                            </p>
                                                          </Tooltip>
                                                        ) : (
                                                          <p className="w-full truncate">
                                                            {tag?.tag_name}
                                                          </p>
                                                        )}
                                                      </div>
                                                    )
                                                  )}
                                                {subtask.tags.length > 2 && (
                                                  <div className="flex items-center gap-2 break-words rounded-lg bg-[#E4E7EB] px-2 py-1.5  text-xs font-medium capitalize text-[#4B5563] dark:bg-[#2D3748] dark:text-[#CBD5E0]">
                                                    <span className="max-w-[120px] truncate">
                                                      +{subtask.tags.length - 2}
                                                    </span>
                                                  </div>
                                                )}
                                              </>
                                            ) : (
                                              <span className="text-[#4B5563]">
                                                No tags available
                                              </span>
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  )
                                )
                              : 'No Subtask Available'}
                          </SimpleBar>
                        </div>
                      )}
                      {activeTab === 'Attachments' && (
                        <div>
                          {' '}
                          <span className=" text-[16px] font-bold leading-[19.2px] text-[#111928]">
                            Attachments ({task?.attachments?.length})
                          </span>{' '}
                          <SimpleBar
                            className={cn(
                              ' mt-2 w-[576px] overflow-y-auto overflow-x-hidden 4xl:max-h-[100vh]',
                              isInboxTaskView
                                ? 'max-h-[350px]'
                                : 'max-h-[246px]'
                            )}
                          >
                            {previewImage &&
                            previewImage != null &&
                            previewImage?.length > 0
                              ? previewImage?.map(
                                  (image: any, index: number) => {
                                    const fileType = getFileType(image?.name);
                                    const color = getColor(fileType);
                                    return (
                                      <div
                                        className="flex w-[530px] items-center justify-between py-2"
                                        key={image?.name}
                                      >
                                        {/* File Information */}
                                        <div
                                          className={`flex items-center gap-2 rounded-md p-2`}
                                          style={{
                                            backgroundColor: color?.bgColor,
                                            color: color?.textColor,
                                          }}
                                          key={index}
                                        >
                                          <CustomFileIcons
                                            iconClassName="!w-5 !h-5"
                                            key={index}
                                            fileType={fileType}
                                          />
                                          <p className="truncate font-sans text-[14px]">
                                            {image?.name}
                                          </p>
                                        </div>

                                        {/* Download Icon */}
                                        <div
                                          onClick={() =>
                                            downloadFiles([
                                              `${process.env.NEXT_PUBLIC_IMAGE_URL}/${image?.preview} ${image?.name}`,
                                            ])
                                          }
                                          className="flex cursor-pointer items-center text-gray-500 transition hover:text-gray-900"
                                        >
                                          <PiDownloadSimpleBold className="h-5 w-5 text-[#111928]" />
                                        </div>
                                      </div>
                                    );
                                  }
                                )
                              : 'No Attachments Available'}
                          </SimpleBar>
                        </div>
                      )}
                      {activeTab === 'UserActivity' && (
                        <div>
                          <SimpleBar
                            onScrollCapture={handleScroll}
                            className={cn(
                              'mt-2 w-[576px] overflow-y-auto overflow-x-hidden 4xl:max-h-[100vh]',
                              isInboxTaskView
                                ? 'max-h-[350px]'
                                : 'max-h-[246px]'
                            )}
                          >
                            {skeletonLoader ? (
                              <div className="flex min-h-[200px] items-center justify-center">
                                <Spinner size="sm" tag="div" />
                              </div>
                            ) : updatedData?.length > 0 ? (
                              updatedData?.map(
                                (timelog: any, index: number) => (
                                  <div key={index}>
                                    {/* Header Section */}
                                    <div
                                      className={`flex h-[36px] cursor-pointer items-center justify-between gap-[16px] border p-3 ${
                                        openSections[timelog?._id?.date]
                                          ? 'rounded-t-[8px] border-[#E8EBF1] bg-[#F0F2FE]'
                                          : 'mb-2 rounded-[8px] border-[#E7EBF1] bg-[#FFFFFF]'
                                      }`}
                                      onClick={() =>
                                        toggleSection(timelog?._id?.date)
                                      }
                                    >
                                      <div className="flex items-center gap-2">
                                        {openSections[timelog?._id?.date] ? (
                                          <BiChevronUp
                                            size={18}
                                            className="text-[14px] font-normal leading-[16.8px] text-gray-400"
                                          />
                                        ) : (
                                          <BiChevronDown
                                            size={18}
                                            className="text-[14px] font-normal leading-[16.8px] text-gray-400"
                                          />
                                        )}
                                        <span className="font-['Raleway'] text-[14px] font-semibold leading-[16.8px] text-[#000000]">
                                          {timelog?._id?.date ===
                                          new Date().toISOString().split('T')[0]
                                            ? 'Today'
                                            : timelog?._id?.date ===
                                                moment()
                                                  .subtract(1, 'days')
                                                  .format('YYYY-MM-DD')
                                              ? 'Yesterday'
                                              : moment(
                                                  timelog?._id?.date,
                                                  'YYYY-MM-DD'
                                                ).format('DD-MMM')}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2 font-['Raleway'] text-[#000000]">
                                        <span className="text-[14px] font-semibold leading-[16.8px]">
                                          <span className="text-[14px] font-normal leading-[16.8px] text-gray-800">
                                            Total:{' '}
                                          </span>
                                          {convertSecondsToTime(
                                            timelog?.total_time
                                          )}
                                        </span>
                                      </div>
                                    </div>

                                    {/* Collapsible Content with Separate Scroll */}
                                    {openSections[timelog?._id?.date] && (
                                      <SimpleBar
                                        className="mb-2 max-h-[200px] overflow-y-auto bg-white pb-3"
                                        onScrollCapture={(e) =>
                                          handleSingleActivityScroll(
                                            timelog?._id?.date,
                                            e
                                          )
                                        }
                                      >
                                        {singleActivityskeletonLoader[
                                          timelog?._id?.date
                                        ] ? (
                                          <div className="flex min-h-[200px] items-center justify-center">
                                            <Spinner size="sm" tag="div" />
                                          </div>
                                        ) : setsingleActivityData[
                                            timelog?._id?.date
                                          ]?.length > 0 ? (
                                          setsingleActivityData[
                                            timelog?._id?.date
                                          ].map((user: any, index: number) => (
                                            <div
                                              key={index}
                                              className="flex h-[48px] items-center justify-between border border-[#E8EBF1] p-3 shadow-sm first:border-t-0 last:rounded-b-lg last:border-b"
                                            >
                                              <div className="flex items-center gap-x-3">
                                                <figure className="relative h-8 w-8 overflow-hidden rounded-full">
                                                  <Avatar
                                                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${user?.user?.profile_image}`}
                                                    name={`${capitalizeFirstLetter(
                                                      user?.user?.first_name
                                                    )} ${capitalizeFirstLetter(
                                                      user?.user?.last_name
                                                    )}`}
                                                    size="sm"
                                                    className="bg-[#70C5E0] font-medium text-white"
                                                  />
                                                </figure>
                                                <span className="font-['Raleway'] text-[14px] font-semibold leading-[16.8px] text-[#111928]">
                                                  {capitalizeFirstLetter(
                                                    user?.user?.first_name
                                                  )}{' '}
                                                  {capitalizeFirstLetter(
                                                    user?.user?.last_name
                                                  )}
                                                </span>
                                              </div>
                                              <div className="flex items-center">
                                                <span className="text-[14px] font-medium leading-[16.8px] text-[#000000]">
                                                  {convertSecondsToTime(
                                                    user?.total_time
                                                  )}
                                                </span>
                                              </div>
                                            </div>
                                          ))
                                        ) : (
                                          <p className="p-3 text-center text-gray-500">
                                            No data available
                                          </p>
                                        )}

                                        {singleActivityhasMore[
                                          timelog?._id?.date
                                        ] &&
                                          !singleActivityskeletonLoader[
                                            timelog?._id?.date
                                          ] && (
                                            <div className="flex w-full items-center justify-center">
                                              <Button
                                                variant="text"
                                                size="sm"
                                                isLoading={true}
                                                className="flex w-full items-center justify-center"
                                              />
                                            </div>
                                          )}
                                      </SimpleBar>
                                    )}
                                  </div>
                                )
                              )
                            ) : (
                              'No user activity available.'
                            )}
                            {hasMore && (
                              <div className="flex w-full items-center justify-center">
                                <Button
                                  variant="text"
                                  size="sm"
                                  isLoading={true}
                                  className="flex w-full items-center justify-center"
                                />
                              </div>
                            )}
                          </SimpleBar>
                        </div>
                      )}
                      {activeTab === 'MyLogs' && (
                        <div>
                          <SimpleBar
                            onScrollCapture={handleScroll}
                            className={cn(
                              'mt-2 w-[576px] overflow-y-auto overflow-x-hidden 4xl:max-h-[100vh]',
                              isInboxTaskView
                                ? 'max-h-[350px]'
                                : 'max-h-[246px]'
                            )}
                          >
                            {skeletonLoader ? ( // Show loader if main data is loading
                              <div className="flex min-h-[200px] items-center justify-center">
                                <Spinner size="sm" tag="div" />
                              </div>
                            ) : updatedData?.length > 0 ? (
                              updatedData?.map(
                                (timelog: any, index: number) => (
                                  <div key={index}>
                                    {/* Header Section */}
                                    <div
                                      className={`flex h-[36px] cursor-pointer items-center justify-between gap-[16px]  border  p-3 ${
                                        myLogsopenSections[timelog?._id?.date]
                                          ? 'rounded-t-[8px] border-[#E8EBF1] bg-[#F0F2FE]'
                                          : 'mb-2 rounded-[8px] border-[#E7EBF1] bg-[#FFFFFF]'
                                      }`}
                                      onClick={() =>
                                        myLogstoggleSection(timelog?._id?.date)
                                      }
                                    >
                                      <div className="flex items-center gap-2">
                                        {myLogsopenSections[
                                          timelog?._id?.date
                                        ] ? (
                                          <BiChevronUp
                                            size={18}
                                            className="text-[14px] font-normal leading-[16.8px] text-gray-400"
                                          />
                                        ) : (
                                          <BiChevronDown
                                            size={18}
                                            className="text-[14px] font-normal leading-[16.8px] text-gray-400"
                                          />
                                        )}
                                        <span className="font-['Raleway'] text-[14px] font-semibold leading-[16.8px] text-[#000000]">
                                          {timelog?._id?.date ===
                                          new Date().toISOString().split('T')[0]
                                            ? 'Today'
                                            : timelog?._id?.date ===
                                                moment()
                                                  .subtract(1, 'days')
                                                  .format('YYYY-MM-DD')
                                              ? 'Yesterday'
                                              : moment(
                                                  timelog?._id?.date,
                                                  'YYYY-MM-DD'
                                                ).format('DD-MMM')}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2 font-['Raleway'] text-[#000000]">
                                        <span className="text-[14px] font-semibold leading-[16.8px]">
                                          <span className="text-[14px] font-normal leading-[16.8px] text-gray-800">
                                            Total:{' '}
                                          </span>
                                          {convertSecondsToTime(
                                            timelog?.total_time
                                          )}
                                        </span>
                                      </div>
                                    </div>

                                    {/* Collapsible Content */}
                                    {myLogsopenSections[timelog?._id?.date] && (
                                      <SimpleBar
                                        className="mb-2 max-h-[200px] overflow-y-auto bg-white pb-3"
                                        onScrollCapture={(e) =>
                                          handlemyLogsScroll(
                                            timelog?._id?.date,
                                            e
                                          )
                                        }
                                      >
                                        {singleMylogskeletonLoader[
                                          timelog?._id?.date
                                        ] ? (
                                          <div className="flex min-h-[200px] items-center justify-center">
                                            <Spinner size="sm" tag="div" />
                                          </div>
                                        ) : singleMylogData[timelog?._id?.date]
                                            ?.length > 0 ? (
                                          singleMylogData[timelog?._id?.date]
                                            ?.slice()
                                            .reverse()
                                            ?.map(
                                              (
                                                user: any,
                                                index: number,
                                                arr: any[]
                                              ) => {
                                                const formatTime = (
                                                  utcString: string
                                                ) => {
                                                  const date = new Date(
                                                    utcString
                                                  );
                                                  return date.toLocaleTimeString(
                                                    [],
                                                    {
                                                      hour: '2-digit',
                                                      minute: '2-digit',
                                                      hour12: false,
                                                    }
                                                  );
                                                };

                                                return (
                                                  <div
                                                    key={index}
                                                    className="flex h-[48px] min-h-[48px] items-center justify-between border border-[#E8EBF1] px-4 py-2 shadow-sm first:border-t-0 last:rounded-b-lg last:border-b"
                                                  >
                                                    {/* Log Number and Stop Button */}
                                                    <div className="flex items-center gap-x-3">
                                                      <span className="font-['Raleway'] text-[14px] font-semibold leading-[16.8px] text-[#111928]">
                                                        Log {arr.length - index}
                                                      </span>
                                                      {user?.is_clocked_in && (
                                                        <button
                                                          className="flex h-[26px] items-center justify-center gap-[4px] rounded-[4px] bg-[#EC221F0D] px-2 py-1"
                                                          onClick={
                                                            handleStopClick
                                                          }
                                                          type="button"
                                                        >
                                                          <FiStopCircle className="h-[10px] w-[10px] text-[#EC221F]" />
                                                          <span className="font-['Raleway'] text-[10px] font-semibold text-[#EC221F]">
                                                            Stop time tracking
                                                          </span>
                                                        </button>
                                                      )}
                                                    </div>

                                                    {/* Clock In and Out Times */}

                                                    {/* Total Time Display */}
                                                    <div className="flex min-w-[100px] items-center justify-between gap-[140px]">
                                                      <div className="flex min-w-[120px] items-center gap-x-2 text-center">
                                                        <span className="w-[50px] text-center text-[14px] font-medium text-[#4B5563]">
                                                          {formatTime(
                                                            user?.new_log
                                                              ?.clock_in
                                                          )}
                                                        </span>
                                                        <span className="text-[14px] text-[#4B5563]">
                                                          {' '}
                                                          -{' '}
                                                        </span>
                                                        <span className="w-[50px] text-center text-[14px] font-medium text-[#4B5563]">
                                                          {user?.is_clocked_in
                                                            ? '--:--'
                                                            : formatTime(
                                                                user?.new_log
                                                                  ?.clock_out
                                                              )}
                                                        </span>
                                                      </div>
                                                      <span className="text-[14px] font-medium text-[#000000]">
                                                        {convertSecondsToTime(
                                                          user?.new_log
                                                            ?.total_time
                                                        )}
                                                      </span>
                                                    </div>
                                                  </div>
                                                );
                                              }
                                            )
                                        ) : (
                                          <p className="p-3 text-center text-gray-500">
                                            No data available
                                          </p>
                                        )}

                                        {singleMyloghasMore[
                                          timelog?._id?.date
                                        ] &&
                                          !singleMylogskeletonLoader[
                                            timelog?._id?.date
                                          ] && (
                                            <div className="flex w-full items-center justify-center">
                                              <Button
                                                variant="text"
                                                size="sm"
                                                isLoading={true}
                                                className="flex w-full items-center justify-center"
                                              />
                                            </div>
                                          )}
                                      </SimpleBar>
                                    )}
                                  </div>
                                )
                              )
                            ) : (
                              'No logs available.'
                            )}
                            {hasMore && (
                              <div className="flex w-full items-center justify-center">
                                <Button
                                  variant="text"
                                  size="sm"
                                  isLoading={true}
                                  className="flex w-full items-center justify-center"
                                />
                              </div>
                            )}
                          </SimpleBar>
                        </div>
                      )}
                    </div>
                  </div>
                </SimpleBar>
                {activeTab === 'Comments' &&
                  !isInboxTaskView &&
                  !task?.mark_as_done &&
                  !task?.mark_as_archived && (
                    <div className="fixed bottom-4  w-[576px]  rounded-lg border  border-[#D4D4D4] bg-[#F9FAFB]">
                      <div>
                        {/* Preview Area */}
                        {previewImageForComment &&
                          previewImageForComment?.length > 0 && (
                            <div className="mt-1 flex max-h-24 flex-wrap justify-center gap-4 overflow-auto">
                              {previewImageForComment.map(
                                (image: any, index: number) => {
                                  const fileType = getFileType(image?.name); // Get the file type
                                  const color = getColor(fileType);
                                  return (
                                    <div
                                      className="mr-[44px] flex w-[100px] flex-col items-center space-y-2"
                                      key={image?._id || index}
                                    >
                                      <div
                                        className={`flex items-center gap-2 rounded-md p-2`}
                                        style={{
                                          backgroundColor: color?.bgColor,
                                          color: color?.textColor,
                                        }}
                                      >
                                        <CustomFileIcons
                                          fileType={fileType}
                                          iconClassName="!w-5 !h-5"
                                        />
                                        <p className="w-[80px] truncate text-center font-sans text-[14px]">
                                          {image?.name}
                                        </p>
                                        <TrashIcon
                                          className="h-5 w-5 cursor-pointer text-red-500 hover:text-red-700"
                                          onClick={() => {
                                            const updatedFiles =
                                              previewImageForComment.filter(
                                                (file: any) =>
                                                  file?.preview !==
                                                  image?.preview
                                              );
                                            setPreviewImageForComment(
                                              updatedFiles
                                            );
                                            checkCommentAttachement(
                                              updatedFiles
                                            );
                                          }}
                                        />
                                      </div>
                                    </div>
                                  );
                                }
                              )}
                            </div>
                          )}

                        {/* Error Message */}
                        {commentAttachementInvalid && (
                          <p className="mt-2 text-sm text-red-500">
                            {messages.taskCommentAttachementMaxFileSize}
                          </p>
                        )}
                      </div>

                      {/* Input and Actions */}
                      <div className="flex items-center">
                        {/* Hidden File Input */}

                        {/* Mentions Input */}
                        <div className="ml-1 flex-grow">
                          <MentionsInput
                            allowSpaceInQuery
                            allowSuggestionsAboveCursor
                            placeholder="Comment here..."
                            // className="mentions-input w-full rounded-lg border border-gray-300 p-2 text-sm focus:outline-none focus:ring-1 focus:ring-purple-500"
                            className="mentions task-comment"
                            style={mentionStyles}
                            disabled={task?.mark_as_done}
                            onKeyDown={(event: any) =>
                              handleKeyDownForComment(event, setValueReference)
                            }
                            maxLength={300}
                            onChange={(
                              event,
                              newValue,
                              newPlainTextValue,
                              mentions
                            ) => {
                              setCommentText(newPlainTextValue);
                              setMentionUser([...mentionUser, ...mentions]);
                            }}
                            value={commentText}
                          >
                            <Mention
                              trigger="@"
                              data={
                                editMode
                                  ? removeLoginUserFromMentionList(
                                      task?.assign_to
                                    )
                                  : fetchUsers
                              }
                              displayTransform={(id, display) => `@${display} `}
                            />
                          </MentionsInput>
                        </div>
                      </div>
                      <div className="flex items-end justify-end">
                        {/* Send Button */}
                        {editMode && !task?.mark_as_archived && (
                          <Button
                            className="me-2 flex h-9 w-9  items-center justify-center rounded-full bg-[#8C80D2] text-sm text-white"
                            size="sm"
                            disabled={
                              taskData?.addCommentsLoader ||
                              task?.mark_as_done ||
                              (commentText === '' &&
                                previewImageForComment?.length === 0)
                            }
                            onClick={handleSendComment}
                          >
                            {!taskData?.addCommentsLoader ? (
                              <Image
                                src={sendbutton}
                                alt="send"
                                className="h-4 w-4"
                              />
                            ) : (
                              <Spinner size="sm" tag="div" color="white" />
                            )}
                          </Button>
                        )}
                      </div>
                      <input
                        type="file"
                        onChange={handleAttachmentChange}
                        style={{ display: 'none' }}
                        multiple
                        name="attachments"
                        ref={commentAttachmentRef}
                        accept=".doc,.docx,.pdf,.txt,.log,.ini,.rtf,.odt,.epub,.xls,.xlsx,.csv,.ods,.ppt,.pptx,.odp,.key,.jpeg,.jpg,.png,.gif,.bmp,.tiff,.svg,.webp,.eps,.mp4,.avi,.mov,.wmv,.mkv,.flv,.mp3,.wav,.aac,.ogg,.flac,.js,.json,.xml,.html,.htm,.css,.yaml,.sql,.md,.py,.java,.c,.cpp,.psd,.ai,.xd,.fig,.sketch,.indd,.sqlite,.db,.zip,.rar,.7z,.tar.gz,.iso,.ics,.apk,.dmg"
                      />
                      {editMode && !task?.mark_as_done && (
                        <Image
                          // className="text-[#111928]"
                          alt="back"
                          width={12}
                          height={16}
                          src={attachmentsIcon}
                          onClick={() => commentAttachmentRef?.current?.click()}
                          className="mb-3 ml-3 cursor-pointer text-[#9BA1B9] hover:text-[#8C80D2]"
                        />
                        // <ImAttachment
                        //   onClick={() =>
                        //     commentAttachmentRef?.current?.click()
                        //   }
                        //   className="h-6 w-6 cursor-pointer text-[#9BA1B9] hover:text-[#8C80D2]"
                        // />
                      )}
                    </div>
                  )}
              </div>
            )
          )}
        </Form>

        {isPopupOpen && (
          <div className="fixed top-0 flex items-center justify-center">
            <div className="mt-[66px] w-[600px] rounded-lg border border-[#0000001A] bg-white  shadow-lg">
              <TimerForm
                onClose={closePopup}
                task_id={selectedTask?._id}
                boardId={boardId}
                taskName={selectedTask?.title}
              />
            </div>
          </div>
        )}
        {(!task?.mark_as_done ||
          (task?.mark_as_done && !subTaskData?.mark_as_done)) &&
          !subTaskData?.mark_as_archived && (
            <div>
              {showDeleteConfirmationPopper && (
                <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                  <div
                    className="relative overflow-hidden rounded-lg bg-white shadow-lg"
                    style={{ width: '400px' }}
                  >
                    <ConfirmationTaskDeleteModal
                      taskData={subTaskData?.parent_task ? subTaskData : task}
                      onClose={() => {
                        closeModal();
                      }}
                      onDeleteClose={() => {
                        setShowDeleteConfirmationPopper(false);
                      }}
                      updateTask={updateTask}
                      shouldCloseDrawer={shouldCloseDrawer}
                      setSubTaskData={setSubTaskData}
                      defaulttask={rowData}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
      </div>
    );
  }
}
