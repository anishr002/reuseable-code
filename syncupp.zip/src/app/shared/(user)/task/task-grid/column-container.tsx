import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import { DatePicker } from '@/components/ui/datepicker';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import { Text } from '@/components/ui/text';
import '@/layouts/helium/style.css';
import {
  putEditBoardSection,
  updateSectionData,
} from '@/redux/slices/user/task/boardSlice';
import {
  RemoveGetAllTasksData,
  getAllTask,
  postAddTask,
} from '@/redux/slices/user/task/taskSlice';
import cn from '@/utils/class-names';
import { handleKeyDown } from '@/utils/common-functions';
import { SortableContext, useSortable } from '@dnd-kit/sortable';
import subTaskBlackIcon from '@public/assets/svgs/subtask-icon.svg';
import moment from 'moment';
import Image from 'next/image';
import { useEffect, useMemo, useRef, useState } from 'react';
import { HiPlusSm } from 'react-icons/hi';
import { LuTag, LuUserPlus } from 'react-icons/lu';
import {
  PiCalendarBlankLight,
  PiCaretDownBold,
  PiPlusBold,
} from 'react-icons/pi';
import { SlOptions } from 'react-icons/sl';
import InfiniteScroll from 'react-infinite-scroll-component';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon, Button, Input, Popover } from 'rizzui';
import { checkPermission } from '../../roles-permissions/utils';
import AddTaskForm from './add-task-form';
import Addtag from './addtag';
import { ConfirmationSectionDeleteModal } from './delete-section-confirmation-modal';
import TaskCard from './task-card';
import { Column, Id, Task } from './types';

interface Props {
  column: Column;
  tasks: any[];
  deleteColumn: (id: Id) => void;
  updateColumn: (id: Id, title: string) => void;
  createTask: (task: any) => void;
  updateTask: (
    id: any,
    action: any,
    data: any,
    oldTasks: any,
    oldTasksSectionsData: any
  ) => void;
  updateGetAllTasks: (task: any[]) => void;
  getAllTaskLoader?: boolean;
  setGetAllTaskLoader?: any;
  totalSectionData?: any;
  setTotalSectionData?: any;
  taskFilterOptionValue?: string;
  assigneeFilter?: string;
  activeTask?: any | null;
}

function ColumnContainer({
  column,
  tasks,
  deleteColumn,
  updateColumn,
  createTask,
  updateTask,
  updateGetAllTasks,
  getAllTaskLoader,
  setGetAllTaskLoader,
  totalSectionData,
  setTotalSectionData,
  taskFilterOptionValue,
  assigneeFilter,
  activeTask,
}: Props) {
  const { openModal, closeModal } = useModal();
  const { openDrawer, closeDrawer } = useDrawer();
  const dispatch = useDispatch();
  const sectionInputRef = useRef<any>('');
  const [sectionName, setSectionName] = useState(column?.section_name);

  const { boardId, editBoardSectionLoader } = useSelector(
    (state: any) => state?.root?.board
  );
  const taskData = useSelector((state: any) => state?.root?.task);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { loading } = useSelector((state: any) => state?.root?.taskStatus);

  const [isCustomTaskCardVisible, setIsCustomTaskCardVisible] = useState(false);
  const [editMode, setEditMode] = useState(false);

  //Infinite Scroll state
  const [hasMore, sethasMore] = useState(false);

  // reference for task column container
  const tasksContainerRef = useRef<any>(null);

  // console.log("column?.section_name....", column?.section_name, "hasMore....", hasMore, "totalSectionData...", totalSectionData)

  useEffect(() => {
    if (isCustomTaskCardVisible && tasksContainerRef.current) {
      tasksContainerRef?.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isCustomTaskCardVisible]);

  useEffect(() => {
    if (editMode) {
      sectionInputRef.current?.focus();
    }
  }, [editMode]);

  const tasksIds = useMemo(() => {
    return tasks?.map((task) => task?._id);
  }, [tasks]);

  const sectionTotalTaskCount: any =
    (totalSectionData &&
      totalSectionData?.length > 0 &&
      totalSectionData?.find((option: any) => option._id === column?._id)) ||
    {};
  // console.log("Column....", column, "totalSectionData...", totalSectionData, "sectionTotalTaskCount...", sectionTotalTaskCount, "Tasks length...", tasks?.length, "hasMore....", hasMore,)

  useEffect(() => {
    if (loading) {
      sethasMore(false);
    }
  }, [loading]);

  useEffect(() => {
    if (editMode) {
      sectionInputRef.current.focus();
    }
  }, [editMode]);

  useEffect(() => {
    if (sectionTotalTaskCount?.count > tasks?.length) {
      // console.log("We are innn...", column, "activeTask..", activeTask)
      if (activeTask && Object?.keys(activeTask)?.length > 0) {
        // console.log("Task is active...so hasMore false", column, "activeTask..", activeTask)
        sethasMore(false);
      } else {
        // console.log("Task is not active...so hasMore is true", column, "activeTask..", activeTask)
        sethasMore(true);
      }
    } else {
      sethasMore(false);
    }
  }, [sectionTotalTaskCount?.count, tasks?.length]); // don't add activeTask and column dependency

  // useSortable hook combines both the useDraggable and useDroppable hooks to connect elements as both draggable sources and drop targets:
  const {
    setNodeRef,
    attributes,
    listeners,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: column?._id,
    data: {
      type: 'Column',
      column,
    },
    disabled:
      (['team_agency', 'team_client'].includes(signIn?.role)
        ? checkPermission('projects', 'sections', 'update', signIn?.permission)
        : ['agency'].includes(signIn?.role)) &&
      column?.key !== 'completed' &&
      column?.key !== 'archived'
        ? false
        : true,
  });

  //Infinite Scroll Handler
  const fetchMoreData = () => {
    // console.log("Fetch more function....")

    // sethasMore(true); // hide and check
    // Assuming you have some way to track the current page and page size
    if (tasks?.length < sectionTotalTaskCount?.count) {
      // console.log("Fetch more....")
      // get all tasks
      // setGetAllTaskLoader(true);
      dispatch(
        getAllTask({
          // search: debouncedValue,
          pagination: false,
          board_id: boardId,
          filter: taskFilterOptionValue,
          assignee_id: assigneeFilter,
          section_id: column?._id,
          skip: tasks?.length,
          limit: 10,
        })
      ).then((result: any) => {
        if (getAllTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            // console.log("result after fetch more api call", result)
            // setTasks(result?.payload?.data?.activity);
            // setTotalSectionData(result?.payload?.data?.task_counts);

            updateGetAllTasks(result?.payload?.data?.activity);

            const updateArray = [...tasks, ...result?.payload?.data?.activity];
            // console.log("updateArray..", updateArray?.length)

            if (sectionTotalTaskCount?.count > updateArray?.length) {
              // need to change
              sethasMore(true);
            } else {
              sethasMore(false);
            }

            setGetAllTaskLoader(false);
            dispatch(RemoveGetAllTasksData());
          } else {
            sethasMore(false);
          }
          setGetAllTaskLoader(false);
        } else {
          sethasMore(false);
          setGetAllTaskLoader(false);
        }
      });
    } else {
      // console.log("Not Fetch more....")
      sethasMore(false);
    }
  };

  useEffect(() => {
    if (editMode) {
      sectionInputRef.current.focus();
    }
  }, [editMode]);

  // section name edit

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSectionName(event.target.value);
  };

  // keydown event for section title name edit
  const handleKeyDownSectionTitleEvent = (
    event: any,
    sectionInputRef: any,
    setEditMode: any
  ) => {
    // console.log("event", event, event.target.value)

    // Check if the space key is pressed and it's the first character
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }
    if (event.key === 'Enter' && !event.shiftKey && event.target.value !== '') {
      event.preventDefault();

      // old and current section name is same
      if (event.target.value === column?.section_name) {
        setEditMode(false);
        return;
      }

      // api logic
      const payload = {
        board_id: boardId,
        section_id: column?._id,
        section_name: event.target.value,
      };

      dispatch(putEditBoardSection(payload)).then((result: any) => {
        if (putEditBoardSection.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            updateColumn(column?._id, event.target.value);
            dispatch(
              updateSectionData({
                sectionId: column?._id,
                sectionName: event.target.value,
              })
            );
            setEditMode(false);
            // inputRef.current.value = ""
            // dispatch(getAllTask({ board_id: boardId, pagination: false }));
          }
        }
      });
    } else if (
      event.key === 'Enter' &&
      !event.shiftKey &&
      event.target.value === ''
    ) {
      sectionInputRef.current.value = column?.section_name;
      setEditMode(false);
      setSectionName(column?.section_name);
    }
  };

  const style = {
    transition,
    backgroundColor: column?.color,
    // transform: CSS.Transform.toString(transform),
  };

  // for showing border when column is dragging
  if (isDragging) {
    return (
      <div
        ref={setNodeRef}
        style={style}
        className="flex min-h-[calc(100dvh-285px)] min-w-[350px] max-w-[360px] flex-col rounded-3xl border-2 opacity-40"
      ></div>
    );
  }

  return (
    // providing node reference for each column
    <div
      ref={setNodeRef}
      style={style}
      className="kanban-task-tour-step-two min-h-[calc(100dvh-285px)] min-w-[360px] max-w-[360px] rounded-xl p-3"
    >
      {/* {/ Column title /} */}
      <div
        {...attributes}
        {...listeners}
        style={{ touchAction: 'none' }}
        className={cn(
          'text-md flex h-[48px] items-center justify-between gap-3 p-2 font-bold text-black',
          signIn?.role !== 'client' &&
            signIn?.role !== 'team_client' &&
            signIn?.teamMemberRole !== 'team_member' &&
            column?.key !== 'completed' &&
            column?.key !== 'archived' &&
            'cursor-grab'
        )}
      >
        <div className="flex w-full flex-row items-center justify-start gap-2">
          {sectionTotalTaskCount?.count > 0 && (
            <div
              className=" poppins_font_number flex h-[28px] w-[28px] items-center justify-center rounded-full bg-white text-[14px]"
              style={{ color: column?.test_color }}
            >
              {sectionTotalTaskCount?.count}
            </div>
          )}
          {!editMode ? (
            <h3
              className="rizzui-title-h3 montserrat_font_title break-all text-[18px] w-[210px] truncate font-bold leading-[1.5rem]"
              style={{ color: column?.test_color }}
              // onDoubleClick={() => {
              //   if (
              //     column?.key !== 'completed' &&
              //     column?.key !== 'archived' &&
              //     (['team_agency', 'team_client'].includes(signIn?.role)
              //       ? checkPermission(
              //           'projects',
              //           'sections',
              //           'update',
              //           signIn?.permission
              //         )
              //       : ['agency'].includes(signIn?.role))
              //   ) {
              //     setEditMode(true);
              //   }
              // }}
            >
              {column?.section_name}
            </h3>
          ) : (
            <Input
              type="text"
              onKeyDown={handleKeyDown}
              value={sectionName}
              onChange={handleChange}
              onKeyUp={(event: any) =>
                handleKeyDownSectionTitleEvent(
                  event,
                  sectionInputRef,
                  setEditMode
                )
              }
              maxLength={25}
              onBlur={() => {
                setEditMode(false);
                setSectionName(column?.section_name);
              }}
              // label="Title *"
              variant="text"
              placeholder="Write a section name"
              ref={sectionInputRef}
              disabled={editBoardSectionLoader}
              className="placeholder_color w-full [&>label>span]:font-medium"
            />
          )}
        </div>
        {/* {/ plus and 3 dots /} */}
        <div className="flex flex-row items-center justify-start gap-2">
          {(['team_agency', 'team_client'].includes(signIn?.role)
            ? checkPermission('projects', 'tasks', 'create', signIn?.permission)
            : ['agency'].includes(signIn?.role)) &&
            column?.is_deletable && (
              <Button
                variant="text"
                className="p-0"
                onClick={() =>
                  openModal({
                    view: (
                      <AddTaskForm
                        onClose={() => closeModal()}
                        editMode={false}
                        rowData={null}
                        column={column}
                        createTask={createTask}
                      />
                    ),
                    customSize: '800px',
                  })
                }
              >
                <HiPlusSm
                  style={{ color: column?.test_color }}
                  className="h-[26px] w-[26px] cursor-pointer"
                />
              </Button>
            )}
          {column?.is_deletable &&
            (['team_agency', 'team_client'].includes(signIn?.role)
              ? checkPermission(
                  'projects',
                  'sections',
                  'update',
                  signIn?.permission
                ) ||
                checkPermission(
                  'projects',
                  'sections',
                  'delete',
                  signIn?.permission
                )
              : ['agency'].includes(signIn?.role)) && (
              <Popover
                placement="bottom"
                className=" demo_test min-w-[135px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                content={({ setOpen }) => {
                  const handleButtonClick = () => {
                    openModal({
                      view: (
                        <ConfirmationSectionDeleteModal
                          deleteColumn={deleteColumn}
                          column={column}
                        />
                      ),
                      customSize: '400px',
                    });
                    setOpen(false);
                  };

                  return (
                    <div className="text-gray-900">
                      {(['team_agency', 'team_client'].includes(signIn?.role)
                        ? checkPermission(
                            'projects',
                            'sections',
                            'update',
                            signIn?.permission
                          )
                        : ['agency'].includes(signIn?.role)) && (
                        <Button
                          variant="text"
                          className="flex w-full items-center justify-start py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                          onClick={() => {
                            setEditMode(true);
                          }}
                        >
                          Edit Section
                        </Button>
                      )}
                      {(['team_agency', 'team_client'].includes(signIn?.role)
                        ? checkPermission(
                            'projects',
                            'sections',
                            'delete',
                            signIn?.permission
                          )
                        : ['agency'].includes(signIn?.role)) && (
                        <Button
                          variant="text"
                          className="flex w-full items-center justify-start py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                          onClick={handleButtonClick}
                        >
                          Delete Section
                        </Button>
                      )}
                    </div>
                  );
                }}
              >
                <ActionIcon
                  title={'More Options'}
                  className="kanban-task-tour-step-three"
                  variant="text"
                >
                  <SlOptions
                    style={{ color: column?.test_color }}
                    className="cursor-pointer"
                  />
                </ActionIcon>
              </Popover>
            )}
        </div>
      </div>

      {/* {/ Column task container /} */}
      <InfiniteScroll
        dataLength={tasks?.length || 0}
        next={fetchMoreData}
        hasMore={hasMore}
        loader={
          <Button
            variant="text"
            size="lg"
            isLoading={true}
            className="flex h-[10vh] w-full items-center justify-center"
          />
        }
        // className="kanban-infinite-scroll-component"
        height="calc(100dvh - 355px)" // important
      >
        {getAllTaskLoader ? (
          <div className="grid h-full min-h-[128px] flex-grow place-content-center items-center justify-center">
            <Spinner size="xl" />
          </div>
        ) : (
          <SortableContext items={tasksIds}>
            {tasks && (
              <div className="flex flex-col gap-1.5 p-2">
                {(['team_agency', 'team_client'].includes(signIn?.role)
                  ? checkPermission(
                      'projects',
                      'tasks',
                      'create',
                      signIn?.permission
                    )
                  : // ['agency', 'client'].includes(signIn?.role))
                    ['agency'].includes(signIn?.role)) &&
                column?.key !== 'completed' &&
                column?.key !== 'archived' ? (
                  <div className="mb-3 pt-1 text-center">
                    {isCustomTaskCardVisible ? (
                      <>
                        <CustomTaskCard
                          column={column}
                          createTask={createTask}
                          setIsCustomTaskCardVisible={
                            setIsCustomTaskCardVisible
                          }
                        />
                        <div />
                      </>
                    ) : (
                      <Button
                        className="kanban-task-tour-step-four text-md flex w-full items-center gap-2 rounded-lg border border-[#6875F5] bg-[#F6F5FF] p-3 font-bold text-[#5850EC]"
                        onClick={() => setIsCustomTaskCardVisible(true)}
                      >
                        <PiPlusBold className="h-[17px] w-[17px]" /> Add Task
                      </Button>
                    )}
                  </div>
                ) : (
                  <div>
                    {/* {tasks && tasks?.length === 0 &&
                      <div className="py-5 mt-28 text-center lg:py-8">
                        <Empty /> <Text className="mt-3">No Data</Text>
                      </div>
                    } */}
                  </div>
                )}
                {tasks?.map((task) => (
                  <TaskCard
                    updateTask={updateTask}
                    key={task?._id}
                    task={task}
                    createTask={createTask}
                  />
                ))}
              </div>
            )}
            {/* {tasks && tasks?.length > 0 ?
              (tasks?.map((task) => (
                <div key={task?._id} className="px-2 pt-2">
                  <TaskCard
                    updateTask={updateTask}
                    key={task?._id}
                    task={task}
                  />
                </div>
              ))) : (
                <>
                  {(signIn?.role !== 'client' && signIn?.role !== 'team_client' && column?.key !== 'completed' && column?.key !== 'archived') ? (
                    <div className="px-[6px] py-2 text-center ">
                      {
                        isCustomTaskCardVisible ? (
                          <CustomTaskCard column={column} createTask={createTask} setIsCustomTaskCardVisible={setIsCustomTaskCardVisible} />
                        ) : (
                          <Button
                            className='text-[#8C80D2] bg-white rounded-2xl h-[4rem] text-md flex items-center font-bold gap-2 w-full'
                            onClick={() => setIsCustomTaskCardVisible(true)}>
                            <PiPlusBold className='h-[17px] w-[17px]' /> Add Task
                          </Button>
                        )
                      }
                    </div>
                  ) : (
                    <div className="py-5 mt-28 text-center lg:py-8">
                      <Empty /> <Text className="mt-3">No Data</Text>
                    </div>
                  )
                  }
                </>
              )
            } */}
          </SortableContext>
        )}
      </InfiniteScroll>
    </div>
  );
}

export default ColumnContainer;

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E4F6D6]',
    label: (
      <div className="flex items-center  rounded-3xl bg-[#E4F6D6] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="success" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-green-dark">
          Low
        </Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FBF0DE]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FBF0DE] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="warning" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-orange-dark">
          Medium
        </Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFD4C6]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FFD4C6] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="danger" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-red-dark">
          High
        </Text>
      </div>
    ),
  },
];

const CustomTaskCard = ({
  column,
  createTask,
  setIsCustomTaskCardVisible,
}: {
  column: any;
  createTask: (task: Task) => void;
  setIsCustomTaskCardVisible: any;
}) => {
  const [selectedMembers, setSelectedMembers] = useState<any>([]);
  const [subTaskSelectedMembers, setSubTaskSelectedMembers] = useState<any>([]);
  const [selectedtags, setSelectedTags] = useState<any>([]);
  const [subTaskTags, setSubTaskTags] = useState<any>([]);

  const [selectedDueDate, setSelectedDueDate] = useState<any>(null);
  const [subTaskDueDate, setSubTaskDueDate] = useState<any>(null);

  const [selectedStatus, setSelectedStatus] = useState(priorityOptions[0]);
  const [subTaskStatus, setSubTaskStatus] = useState(priorityOptions[0]);

  const [subTaskAdd, setSubTaskAdd] = useState(false);
  const { boardId } = useSelector((state: any) => state?.root?.board);
  const { addTaskStatus } = useSelector((state: any) => state?.root?.task);
  const { members } = useSelector((state: any) => state?.root?.board);
  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const taskData = useSelector((state: any) => state?.root?.task);

  // create input text reference
  const inputRef = useRef<any>(null);
  const subTaskInputRef = useRef<any>(null);

  // Card reference
  const cardRef = useRef<any>(null);

  useEffect(() => {
    inputRef?.current && inputRef?.current?.focus();
    cardRef?.current && cardRef?.current?.focus();

    // Add event listener to detect clicks outside the card
    // const handleClickOutside = (event: any) => {
    //   if (cardRef.current && !cardRef.current.contains(event.target)) {
    //     setIsCustomTaskCardVisible(false);
    //   }
    // };

    // document.addEventListener('mousedown', handleClickOutside);
    // return () => {
    //   document.removeEventListener('mousedown', handleClickOutside);
    // };
  }, []);

  const handleAddMemberClick = (istask: Boolean) => {
    openModal({
      view: (
        <div>
          <AddMembers
            onClose={closeModal}
            selectedMembers={istask ? selectedMembers : subTaskSelectedMembers}
            setSelectedMembers={
              istask ? setSelectedMembers : setSubTaskSelectedMembers
            }
            formPage={true}
            addTaskMember={true}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  const handleAddTag = (isTask: Boolean) => {
    openModal({
      view: (
        <div>
          <Addtag
            onClose={closeModal}
            isAPICall={false}
            selectedtags={isTask ? selectedtags : subTaskTags}
            setSelectedTags={isTask ? setSelectedTags : setSubTaskTags}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  // keydown event for comment text area
  const handleKeyDownEvent = () => {
    // console.log("event", event, event.target.value)

    // Check if the space key is pressed and it's the first character
    // if (event.key === ' ' && event.target.selectionStart === 0) {
    //   event.preventDefault();
    // }
    if (inputRef?.current.value === '') {
      inputRef?.current.focus();
      return;
    }
    if (subTaskAdd && subTaskInputRef?.current?.value === '') {
      subTaskInputRef?.current.focus();
      return;
    }

    if (inputRef?.current.value !== '') {
      // api logic
      const myForm = new FormData();
      myForm.append('title', inputRef?.current.value);
      myForm.append('status', column?._id);
      myForm.append('board_id', boardId);
      myForm.append('priority', selectedStatus?.value);
      myForm.append('due_date', String(selectedDueDate));
      myForm.append('assign_to', JSON.stringify(selectedMembers));
      selectedtags?.length > 0 &&
        selectedtags?.map((tag: any) => {
          myForm.append('tags', tag);
        });

      if (subTaskAdd) {
        const subtasks = {
          title: subTaskInputRef?.current.value,
          status: column?._id,
          board_id: boardId,
          priority: subTaskStatus?.value,
          due_date: String(subTaskDueDate),
          assign_to: subTaskSelectedMembers,
          tags: subTaskTags,
        };
        myForm.append('subtasks', JSON.stringify([subtasks]));
      }
      dispatch(postAddTask(myForm)).then((result: any) => {
        if (postAddTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setIsCustomTaskCardVisible(false);
            createTask({
              ...result.payload.data,
              assign_to: members?.filter(
                (item: any) =>
                  selectedMembers &&
                  selectedMembers?.length > 0 &&
                  selectedMembers?.includes(item?.id)
              ),
            });
          }
        }
      });
    }
  };

  const displayName = (data: any) => {
    let displayName: string =
      data?.first_name?.charAt(0)?.toUpperCase() +
      data?.first_name?.slice(1) +
      ' ' +
      data?.last_name?.charAt(0)?.toUpperCase() +
      data?.last_name?.slice(1);
    return displayName;
  };

  return (
    <div
      ref={cardRef}
      className="task relative min-h-[202px] rounded-3xl border-[1px] border-[#D1D5DB] bg-[#FFFFFF] text-left transition-all duration-300 ease-in-out hover:z-50 hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="flex flex-col gap-4 p-4">
        <Input
          type="text"
          onKeyDown={handleKeyDown}
          maxLength={50}
          variant="text"
          ref={inputRef}
          placeholder="Enter task title"
          className="placeholder_color h-7 w-full [&>label>span]:font-medium"
          inputClassName="text-black h-7"
        />

        <div className="flex flex-wrap items-center justify-start gap-3">
          {selectedMembers && selectedMembers?.length > 0 ? (
            <div className="flex gap-1">
              <div className="ms-[10px] flex">
                {members?.length > 0 &&
                  members
                    ?.filter(
                      (item: any) =>
                        selectedMembers &&
                        selectedMembers?.length > 0 &&
                        selectedMembers?.includes(item?.id)
                    )
                    ?.slice(0, 3)
                    ?.map((item: any) => (
                      <figure
                        key={item?._id}
                        className="relative z-10 -ml-[10px] h-7 w-7 cursor-pointer rounded-full"
                        onClick={() => handleAddMemberClick(true)}
                      >
                        <Avatar
                          src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                          name={displayName(item)}
                          className="!h-7 !w-7 bg-[#70C5E0] font-medium text-white"
                        />
                      </figure>
                    ))}
              </div>
              {selectedMembers?.length > 3 && (
                <div
                  className="poppins_font_number flex h-7 w-7 cursor-pointer items-center justify-center gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]"
                  onClick={() => handleAddMemberClick(true)}
                >
                  +{selectedMembers?.length - 3}
                </div>
              )}
            </div>
          ) : (
            <Button
              variant="text"
              className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
              onClick={() => handleAddMemberClick(true)}
            >
              <LuUserPlus className="h-[14px] w-[14px] text-[#6875F5]" />
            </Button>
          )}
          <Popover
            placement="bottom"
            className=" demo_test min-w-[425px] border-none bg-transparent p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
            content={({ setOpen }) => {
              const handleDateChange = (date: any) => {
                setSelectedDueDate(date);
                setOpen(false);
              };
              return (
                <DatePicker
                  selected={selectedDueDate}
                  inputProps={{}}
                  placeholderText="Select due date"
                  onChange={handleDateChange}
                  selectsStart
                  startDate={selectedDueDate}
                  startOpen={true}
                  minDate={new Date()}
                  showTimeSelect
                  popperPlacement="bottom-start"
                  dateFormat="MMM d, yyyy h:mm aa"
                  inline
                />
              );
            }}
          >
            {selectedDueDate ? (
              <p className="poppins_font_number cursor-pointer text-[13px] font-semibold">
                {moment(selectedDueDate).format('DD MMM YYYY hh:mm A')}
              </p>
            ) : (
              <Button
                variant="text"
                className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
              >
                <PiCalendarBlankLight className="h-[14px] w-[14px] text-[#6875F5]" />
              </Button>
            )}
          </Popover>

          {selectedtags?.length > 0 ? (
            <div className="flex gap-1">
              {selectedtags?.slice(0, 1)?.map((tag: any, index: number) => (
                <div
                  key={index}
                  className="max-w-[100px] cursor-pointer overflow-hidden truncate whitespace-nowrap rounded bg-[#E5E7EB] p-1 text-[14px] font-medium text-[#4B5563]"
                  onClick={() => handleAddTag(true)}
                >
                  <span>{tag}</span>
                </div>
              ))}
              {selectedtags?.length > 1 && (
                <div
                  className="poppins_font_number flex cursor-pointer items-center justify-center gap-1 rounded bg-[#E5E7EB] p-1 text-[14px] font-medium text-[#757575]"
                  onClick={() => handleAddTag(true)}
                >
                  +{selectedtags?.length - 1}
                </div>
              )}
            </div>
          ) : (
            <Button
              variant="text"
              className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
              onClick={() => handleAddTag(true)}
            >
              <LuTag className="h-[14px] w-[14px] text-[#6875F5]" />
            </Button>
          )}
          {/* un comment for sub tsk Add */}
          {/* <Button
            variant="text"
            className="flex h-[28px] w-[28px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
            onClick={() => {
              setSubTaskAdd(!subTaskAdd)
              setSubTaskSelectedMembers([])
              setSubTaskDueDate(null)
              setSubTaskTags([])
              setSubTaskStatus(priorityOptions[0])
            }}
          >
            <Image
              src={subTaskIcon}
              alt="sub task icon"
              width={14}
              height={14}
            />
          </Button> */}

          {/* <IoIosCheckmarkCircleOutline className="ms-auto h-6 w-6 cursor-default text-[#8C80D2]" /> */}
        </div>
        <div className="flex items-center justify-start">
          <Select
            variant="text"
            onChange={(selectedOption: any) => {
              setSelectedStatus(selectedOption);
            }}
            value={priorityOptions?.find(
              (option) => option.value === selectedStatus.value
            )}
            options={priorityOptions}
            placeholder="Select priority"
            className={`h-7 w-[130px] rounded-lg border-[1px] text-sm`}
            selectClassName={`!py-0 h-7 w-[130px] text-sm font-medium ${priorityOptions?.find(
              (option) => option.value === selectedStatus.value
            )?.color}`}
            dropdownClassName="max-h-[150px] overflow-hidden demo_test"
            suffix={<PiCaretDownBold className="h-4 w-4" />}
          />
        </div>

        {subTaskAdd && (
          <>
            <span className="border border-[#E5E7EB]"></span>
            <div className="flex flex-col gap-3 rounded-xl bg-[#F3F4F6] p-3">
              <div className="flex gap-2">
                <Image
                  src={subTaskBlackIcon}
                  alt="sub task icon"
                  width={14}
                  height={14}
                />
                <Input
                  type="text"
                  onKeyDown={handleKeyDown}
                  maxLength={50}
                  variant="text"
                  ref={subTaskInputRef}
                  placeholder="Enter subtask title"
                  className="placeholder_color h-7 w-full [&>label>span]:font-medium"
                  inputClassName="text-black h-7"
                />
              </div>
              <div className="flex flex-wrap items-center justify-start gap-3">
                {subTaskSelectedMembers &&
                subTaskSelectedMembers?.length > 0 ? (
                  <div className="flex gap-1">
                    <div className="ms-[10px] flex">
                      {members?.length > 0 &&
                        members
                          ?.filter(
                            (item: any) =>
                              subTaskSelectedMembers &&
                              subTaskSelectedMembers?.length > 0 &&
                              subTaskSelectedMembers?.includes(item?.id)
                          )
                          ?.slice(0, 3)
                          ?.map((item: any) => (
                            <figure
                              key={item?._id}
                              className="relative z-10 -ml-[10px] h-7 w-7 cursor-pointer rounded-full"
                              onClick={() => handleAddMemberClick(false)}
                            >
                              <Avatar
                                src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                                name={displayName(item)}
                                className="!h-7 !w-7 bg-[#70C5E0] font-medium text-white"
                              />
                            </figure>
                          ))}
                    </div>
                    {subTaskSelectedMembers?.length > 3 && (
                      <div
                        className="poppins_font_number flex h-7 w-7 cursor-pointer items-center justify-center gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]"
                        onClick={() => handleAddMemberClick(false)}
                      >
                        +{subTaskSelectedMembers?.length - 3}
                      </div>
                    )}
                  </div>
                ) : (
                  <Button
                    variant="text"
                    className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
                    onClick={() => handleAddMemberClick(false)}
                  >
                    <LuUserPlus className="h-[14px] w-[14px] text-[#6875F5]" />
                  </Button>
                )}
                <Popover
                  placement="bottom"
                  className=" demo_test min-w-[425px] border-none bg-transparent p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                  content={({ setOpen }) => {
                    const handleDateChange = (date: any) => {
                      setSubTaskDueDate(date);
                      setOpen(false);
                    };
                    return (
                      <DatePicker
                        selected={subTaskDueDate}
                        inputProps={{}}
                        placeholderText="Select due date"
                        onChange={handleDateChange}
                        selectsStart
                        startDate={subTaskDueDate}
                        startOpen={true}
                        minDate={new Date()}
                        showTimeSelect
                        popperPlacement="bottom-start"
                        dateFormat="MMM d, yyyy h:mm aa"
                        inline
                      />
                    );
                  }}
                >
                  {subTaskDueDate ? (
                    <p className="poppins_font_number cursor-pointer text-[13px] font-semibold">
                      {moment(subTaskDueDate).format('DD MMM YYYY hh:mm A')}
                    </p>
                  ) : (
                    <Button
                      variant="text"
                      className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
                    >
                      <PiCalendarBlankLight className="h-[14px] w-[14px] text-[#6875F5]" />
                    </Button>
                  )}
                </Popover>

                {subTaskTags?.length > 0 ? (
                  <div className="flex gap-1">
                    {subTaskTags
                      ?.slice(0, 1)
                      ?.map((tag: any, index: number) => (
                        <div
                          key={index}
                          className="max-w-[100px] cursor-pointer overflow-hidden truncate whitespace-nowrap rounded bg-[#E5E7EB] p-1 text-[14px] font-medium text-[#4B5563]"
                          onClick={() => handleAddTag(false)}
                        >
                          <span>{tag}</span>
                        </div>
                      ))}
                    {subTaskTags?.length > 1 && (
                      <div
                        className="poppins_font_number flex cursor-pointer items-center justify-center gap-1 rounded bg-[#E5E7EB] p-1 text-[14px] font-medium text-[#757575]"
                        onClick={() => handleAddTag(false)}
                      >
                        +{subTaskTags?.length - 1}
                      </div>
                    )}
                  </div>
                ) : (
                  <Button
                    variant="text"
                    className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1"
                    onClick={() => handleAddTag(false)}
                  >
                    <LuTag className="h-[14px] w-[14px] text-[#6875F5]" />
                  </Button>
                )}
              </div>
              <div className="flex items-center justify-start">
                <Select
                  variant="text"
                  onChange={(selectedOption: any) => {
                    setSubTaskStatus(selectedOption);
                  }}
                  value={priorityOptions?.find(
                    (option) => option.value === subTaskStatus.value
                  )}
                  options={priorityOptions}
                  placeholder="Select priority"
                  className={`h-7 w-[130px] rounded-lg border-[1px] text-sm`}
                  selectClassName={`!py-0 h-7 w-[130px] text-sm font-medium ${priorityOptions?.find(
                    (option) => option.value === subTaskStatus.value
                  )?.color}`}
                  dropdownClassName="max-h-[150px] overflow-hidden demo_test"
                  suffix={<PiCaretDownBold className="h-4 w-4" />}
                />
              </div>
            </div>
          </>
        )}

        <div className="flex items-center justify-between gap-3">
          <Button
            className="w-1/2 cursor-pointer rounded-lg border border-[#E5E7EB] bg-white text-sm text-[#141414]"
            size="sm"
            type="button"
            onClick={() => setIsCustomTaskCardVisible(false)}
          >
            Cancel
          </Button>
          <Button
            className="w-1/2 rounded-lg bg-[#8C80D2] text-sm text-white"
            size="sm"
            onClick={() => handleKeyDownEvent()}
            type="button"
            disabled={taskData?.loading}
          >
            {taskData?.loading && (
              <Spinner size="sm" tag="div" className="mr-3" color="white" />
            )}
            Save Task
          </Button>
        </div>
      </div>
    </div>
  );
};
