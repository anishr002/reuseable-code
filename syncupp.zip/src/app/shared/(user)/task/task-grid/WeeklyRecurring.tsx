'use client';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import TailwindSwitch from '@/hooks/tailwindSwitch';
import { addDays, endOfWeek, format, startOfWeek } from 'date-fns';
import { useEffect, useRef, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { ActionIcon, Button } from 'rizzui';
import { z } from 'zod';

// Validation Schema
const schema = z.object({
  weeklyRanges: z.array(
    z.object({
      dueDates: z.array(z.any().nullable().optional()).optional(),
    })
  ),
  selectedDays: z.array(z.string()).nonempty('Select at least one day'),
});

type FormData = z.infer<typeof schema>;

export default function WeeklyRecurring({
  onClose,
  isEachWeek,
  setIsEachWeek,
  selectedDate,
  selectedEndDate,
  selectedDays = [],
  defineValue,
  setWeeklyDates,
  onModalClose,
  isEdit,
  isEditVal,
  setAddDateAgain,
  setIsEachWeekModal,
}: Readonly<{
  onClose: () => void;
  isEachWeek?: boolean;
  setIsEachWeek?: (checked: boolean) => void;
  selectedDate?: Date;
  selectedEndDate?: Date;
  selectedDays?: string[];
  defineValue?: any;
  setWeeklyDates?: any;
  onModalClose?: any;
  isEdit: boolean;
  isEditVal?: any;
  setAddDateAgain?: any;
  setIsEachWeekModal: any;
}>) {
  const { control, handleSubmit, getValues, setValue, reset } =
    useForm<FormData>();
  // const { weeklyRangesArray, replace } = useFieldArray({
  //     control,
  //     name: "weeklyRanges",
  // });
  const setValueRef = useRef<any>(null);
  const [weeklyRangesArray, setWeeklyRangesArray] = useState<
    { dueDates: Date[] }[]
  >([]);

  const [initialValues, setInitialValues] = useState<any>({
    weeklyRanges: [],
    selectedDays,
  });
  useEffect(() => {
    if (selectedDate && selectedEndDate && selectedDays.length) {
      generateWeeklyRanges(selectedDate, selectedEndDate, selectedDays);
    }
  }, [selectedDate, selectedEndDate, selectedDays]);

  useEffect(() => {
    if (
      !Array?.isArray(isEditVal) ||
      isEditVal?.length === 0 ||
      !Array?.isArray(weeklyRangesArray) ||
      weeklyRangesArray?.length === 0
    ) {
      return;
    }

    const updatedWeeklyRanges = weeklyRangesArray?.map((item: any) => {
      const updatedDueDates: (string | undefined)[] =
        item?.dueDates?.map((fieldDate: Date) => {
          const fieldDay = +format(new Date(fieldDate), 'dd');
          const fieldMonth = +format(new Date(fieldDate), 'MM');
          const fieldYear = +format(new Date(fieldDate), 'yyyy');

          const editItem: any = isEditVal?.find(
            (edit: any) =>
              edit?.day === fieldDay &&
              edit?.month === fieldMonth &&
              edit?.year === fieldYear
          );

          return editItem ? editItem?.date : null; // Keep original if no editItem found
        }) || [];

      return { dueDates: updatedDueDates };
    });

    setInitialValues({ weeklyRanges: updatedWeeklyRanges, selectedDays });

    updatedWeeklyRanges.forEach((week, weekIndex) => {
      week?.dueDates?.forEach((dueDate, dateIndex) => {
        setValueRef.current(
          `weeklyRanges.${weekIndex}.dueDates.${dateIndex}`,
          dueDate
        );
      });
    });

    // Reset form with updated values
    reset({ weeklyRanges: updatedWeeklyRanges, selectedDays });
  }, [
    isEditVal,
    weeklyRangesArray,
    setInitialValues,
    selectedDays,
    reset,
    setValue,
  ]);
  useEffect(() => {
    if (
      !Array?.isArray(setAddDateAgain) ||
      setAddDateAgain?.length === 0 ||
      !Array?.isArray(weeklyRangesArray) ||
      weeklyRangesArray?.length === 0
    ) {
      return;
    }

    const updatedWeeklyRanges = weeklyRangesArray?.map((item: any) => {
      const updatedDueDates: (string | undefined)[] =
        item?.dueDates?.map((fieldDate: Date) => {
          const fieldDay = +format(new Date(fieldDate), 'dd');
          const fieldMonth = +format(new Date(fieldDate), 'MM');
          const fieldYear = +format(new Date(fieldDate), 'yyyy');

          const editItem: any = setAddDateAgain?.find(
            (edit: any) =>
              edit?.day === fieldDay &&
              edit?.month === fieldMonth &&
              edit?.year === fieldYear
          );

          return editItem ? editItem?.date : null; // Keep original if no editItem found
        }) || [];

      return { dueDates: updatedDueDates };
    });

    setInitialValues({ weeklyRanges: updatedWeeklyRanges, selectedDays });

    updatedWeeklyRanges.forEach((week, weekIndex) => {
      week?.dueDates?.forEach((dueDate, dateIndex) => {
        setValueRef.current(
          `weeklyRanges.${weekIndex}.dueDates.${dateIndex}`,
          dueDate
        );
      });
    });

    // Reset form with updated values
    reset({ weeklyRanges: updatedWeeklyRanges, selectedDays });
  }, [
    setAddDateAgain,
    weeklyRangesArray,
    setInitialValues,
    selectedDays,
    reset,
    setValue,
  ]);
  const generateWeeklyRanges = (
    startDate: Date,
    endDate: Date,
    selectedDays: string[]
  ) => {
    // Array to collect the weekly ranges with valid due dates
    const weeks: { dueDates: Date[] }[] = [];

    // Start from the provided startDate
    let currentStart = startDate;

    while (currentStart <= endDate) {
      let currentEnd: Date;
      const dayOfWeek = currentStart.getDay(); // 0 = Sunday, 1 = Monday, …, 6 = Saturday

      // For the first range (or any partial week at the start), if startDate is not Monday (1)
      // then the range should be from currentStart to the coming Sunday.
      // Otherwise, for full weeks, the range is Monday to Sunday.
      if (dayOfWeek !== 1) {
        // Calculate days until coming Sunday.
        // Note: if currentStart is Sunday (0) then daysUntilSunday is 0 (so the range is just that day)
        const daysUntilSunday = (7 - dayOfWeek) % 7;
        currentEnd = addDays(currentStart, daysUntilSunday);
      } else {
        // currentStart is Monday – full week range is Monday to Sunday.
        currentEnd = addDays(currentStart, 6);
      }

      // Adjust currentEnd if it goes past the endDate.
      if (currentEnd > endDate) {
        currentEnd = endDate;
      }

      let dueDates: Date[] = [];
      // Iterate over each day in the current range.
      let dayPointer = currentStart;
      while (dayPointer <= currentEnd) {
        // Format the day (using optional chaining) to compare with selected days.
        const formattedDay = format(dayPointer, 'EEEE')?.toLowerCase();
        if (selectedDays?.some((day) => day.toLowerCase() === formattedDay)) {
          dueDates.push(dayPointer);
        }
        dayPointer = addDays(dayPointer, 1);
      }

      // Only add this week if there is at least one valid selected day within the range.
      if (dueDates.length > 0) {
        weeks.push({ dueDates });
      }

      // For the next iteration, if the current range was partial (not starting on a Monday)
      // then we move to the next Monday. Otherwise, currentEnd is Sunday so next day is Monday.
      // (This logic works in both cases.)
      currentStart = addDays(currentEnd, 1);
    }

    setWeeklyRangesArray(weeks);
  };

  const onSubmit = (data: FormData) => {
    const formattedData = data?.weeklyRanges?.flatMap((item1: any, index) => {
      const item2: any = weeklyRangesArray?.[index]; // Get corresponding object from weeklyRangesArray
      if (!item2) return [];

      return item1?.dueDates
        ?.map((dueDate: any, i: number) => {
          const referenceDate = item2?.dueDates?.[i]; // Get corresponding due date from array2

          // Ensure referenceDate is valid
          if (!referenceDate || isNaN(new Date(referenceDate).getTime()))
            return null;

          // Ensure dueDate is valid
          let formattedDueDate = '';
          if (dueDate && !isNaN(new Date(dueDate).getTime())) {
            formattedDueDate = dueDate;
          }

          return {
            date: !!formattedDueDate ? formattedDueDate : '', // Empty string if dueDate is invalid
            day: +format(new Date(referenceDate), 'dd'),
            month: +format(new Date(referenceDate), 'MM'),
            year: +format(new Date(referenceDate), 'yyyy'),
          };
        })
        .filter(Boolean); // Remove null values
    });

    defineValue('recurrence_task_due_date', formattedData);
    setWeeklyDates(formattedData);
    onModalClose();
  };

  return (
    <div className="overflow-y-visible p-6">
      <Form<FormData>
        validationSchema={schema}
        useFormProps={{
          defaultValues: initialValues,
          mode: 'all',
        }}
        // className='h-full flex flex-col justify-between'
        onSubmit={() => console.log('asd')}
      >
        {({
          register,
          control,
          formState: { errors },
          watch,
          handleSubmit,
          trigger,
          setValue,
          formState: { isDirty, isValid },
          clearErrors,
        }) => (
          (setValueRef.current = setValue),
          (
            <>
              <div className="rounded-lg border border-[#E5E7EB] p-4 ">
                <div className="flex justify-between">
                  <TailwindSwitch
                    isRecurringType="weekly"
                    label="Set different Due date for each week"
                    defaultChecked={isEachWeek}
                    onToggle={setIsEachWeek}
                    recurrenceStartDate={selectedDate}
                    recurrenceEndDate={selectedEndDate}
                    editOpen={isEdit}
                    setIsEachWeekModal={setIsEachWeekModal}
                    // selectedDays={watch("weekly_recurrence_days")}
                  />
                  <div>
                    <ActionIcon
                      size="sm"
                      variant="text"
                      onClick={() => {
                        !isEdit && onClose();
                        isEditVal?.length === 0 && onClose();
                        onModalClose();
                      }}
                      className="me-4 p-0 text-black hover:!text-gray-900"
                    >
                      <PiXBold className="h-[20px] w-[20px] " />
                    </ActionIcon>
                  </div>
                </div>
                {weeklyRangesArray?.length > 0 ? (
                  <div className="mt-5 gap-5">
                    <div className="flex max-h-[52vh] flex-wrap gap-4 overflow-y-auto pe-2">
                      {weeklyRangesArray?.map((week: any, index) => (
                        <div key={index} className=" w-full min-w-[33.33%]">
                          <h3 className="mb-3 text-sm  font-semibold text-[#000000]">
                            Week {index + 1} (
                            {format(week?.dueDates?.[0], 'do MMM')} -{' '}
                            {format(
                              endOfWeek(week?.dueDates?.[0], {
                                weekStartsOn: 1,
                              }),
                              'do MMM'
                            )}
                            )
                          </h3>
                          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                            {week?.dueDates?.map(
                              (dueDate: any, dueIndex: any) => (
                                <div key={dueIndex} className="mb-3">
                                  <span className="text-[14px]  font-medium text-[#9BA1B9]">
                                    {format(dueDate, 'do MMM, EEE') ||
                                      'No Date Selected'}
                                  </span>
                                  <Controller
                                    name={`weeklyRanges.${index}.dueDates.${dueIndex}`}
                                    control={control}
                                    render={({ field }) => {
                                      return (
                                        <DatePicker
                                          name={`weeklyRanges.${index}.dueDates.${dueIndex}`}
                                          placeholderText="Due Date"
                                          popperPlacement="auto-end"
                                          selected={field?.value}
                                          showYearDropdown
                                          scrollableYearDropdown
                                          showMonthDropdown
                                          yearDropdownItemNumber={100}
                                          onChange={(date: any) => {
                                            if (!date) return;
                                            setValue(
                                              `weeklyRanges.${index}.dueDates.${dueIndex}` as any,
                                              date
                                            );

                                            clearErrors(
                                              `weeklyRanges.${index}.dueDates.${dueIndex}`
                                            );
                                          }}
                                          showTimeSelect
                                          minDate={dueDate}
                                          popperProps={{
                                            strategy: 'fixed',
                                            modifiers: [
                                              {
                                                name: 'offset',
                                                options: {
                                                  offset: [0, 10], // Adjust the offset as needed
                                                },
                                              },
                                              {
                                                name: 'preventOverflow',
                                                options: {
                                                  boundary: 'viewport', // Ensure it doesn't overflow the viewport
                                                },
                                              },
                                            ],
                                          }}
                                          maxDate={
                                            new Date(
                                              dueDate.getFullYear(),
                                              dueDate.getMonth() + 1,
                                              0
                                            )
                                          }
                                          dateFormat="MMMM d, yyyy h:mm aa"
                                          calendarClassName="w-[420px]"
                                          className="mt-2 w-full border-gray-300 focus:border-primary focus:ring-primary"
                                        />
                                      );
                                    }}
                                  />

                                  {(errors as any)?.weeklyRanges?.[index]
                                    ?.dueDates?.[dueIndex] && (
                                    <p className="mt-1 text-xs text-red-500">
                                      {
                                        (errors as any)?.weeklyRanges?.[index]
                                          ?.dueDates?.[dueIndex]?.message
                                      }
                                    </p>
                                  )}
                                </div>
                              )
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="my-3 flex items-center justify-center break-all text-center">
                    No Data found, Please select different dates
                  </p>
                )}
              </div>
              <div className="mt-6 flex justify-between space-x-3">
                <Button
                  size="lg"
                  className="create-task-form-tour-step-seven h-[42px] w-full flex-1 items-center gap-2 whitespace-nowrap rounded-full border border-[#8C80D2] bg-transparent px-[14px] text-[#8C80D2] marker:flex"
                  onClick={() => {
                    !isEdit && onClose();
                    isEditVal?.length === 0 && onClose();
                    onModalClose();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  className="h-[42px] flex-1 cursor-pointer rounded-full bg-[#8C80D2] text-sm text-white"
                  size="lg"
                  type="submit"
                  onClick={(e) => {
                    e.preventDefault(); // Stop default form behavior
                    handleSubmit((values) => onSubmit(values))();
                  }}
                >
                  Save
                </Button>
              </div>
            </>
          )
        )}
      </Form>
    </div>
  );
}
