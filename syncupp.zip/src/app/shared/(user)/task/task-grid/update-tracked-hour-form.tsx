import { Avatar } from '@/components/ui/avatar';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  calculateTotalTimeInSeconds,
  capitalizeFirstLetter,
  convertSecondsToTimeForManaul,
} from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Controller } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { useModal } from '@/app/shared/modal-views/use-modal';
import {
  trackedTimeTaskHistoryDetails,
  updateDeleteTrackedTime,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import { useSelector, useDispatch } from 'react-redux';
import { CgNotes } from 'react-icons/cg';
import { getTaskById } from '@/redux/slices/user/task/taskSlice';

const UpdateTrackedHourForm = ({ row }: Readonly<{ row: any }>) => {
  const { closeModal } = useModal();
  const dispatch = useDispatch();

  const [showPrivousDate, setShowPrivousDate] = useState(false);
  const [selectedDate, setSelectedDate] = useState<any>(null);

  // create hook form setValue reference
  const setValueReference = useRef<any>();
  const getValuesReference = useRef<any>();

  const { deleteTrackedTimeLoader } = useSelector(
    (state: any) => state?.root?.timeTracking
  );

  console.log(row, 'row');

  const timeTrackingSchema = z.object({
    start_date: z.date().nullable().optional(),
    end_date: z.date().nullable().optional(),
    start_time: z.date().nullable().optional(),
    end_time: z.date().nullable().optional(),
    notes: z.string().max(150).trim().optional(),
    manual_time: z
      .string()
      .regex(/^((\d+h)?\s*(\d+m)?)$/, { message: 'Invalid Format' })
      .nullable()
      .optional(),
  });

  const defaultValues = {
    start_date: moment(row?.new_log?.clock_in).toDate(),
    end_date: moment(row?.new_log?.clock_out).toDate(),
    start_time: moment(row?.new_log?.clock_in).toDate(),
    end_time: moment(row?.new_log?.clock_out).toDate(),
    notes: row?.notes,
    manual_time: convertSecondsToTimeForManaul(
      calculateTotalTimeInSeconds(
        row?.new_log?.clock_in,
        row?.new_log?.clock_out
      )
    ),
  };

  useEffect(() => {
    // createDefaultValues(row);
  }, []);

  const createDefaultValues = (row: any) => {
    const clock_in = moment(row?.new_log?.clock_in).toDate();
    const clock_out = moment(row?.new_log?.clock_out).toDate();

    const isSameDay = moment(clock_in).isSame(moment(clock_out), 'day');

    if (isSameDay) {
      setShowPrivousDate(false);
    } else {
      setShowPrivousDate(true);
    }
  };

  const manualDateChange = (value: any) => {
    resetDateAndTime();

    const timePattern = /^((\d+h)?\s*(\d+m)?)$/;
    // Test if the input matches the expected pattern
    if (!timePattern.test(value)) {
      return;
    }

    const hoursMatch = value.match(/(\d+)h/);
    const minutesMatch = value.match(/(\d+)m/);

    const hours = hoursMatch ? parseInt(hoursMatch[1], 10) : 0;
    const minutes = minutesMatch ? parseInt(minutesMatch[1], 10) : 0;

    const calculatedData = calculateTime(hours, minutes);

    if (calculatedData?.isPreviousDate) {
      if (calculatedData.isSameDay) {
        setValueReference.current('start_time', calculatedData?.date?.toDate());
      } else {
        setShowPrivousDate(true);
        setValueReference.current('start_time', calculatedData?.date?.toDate());
        setValueReference.current('start_date', calculatedData?.date?.toDate());
      }
    } else {
      setShowPrivousDate(false);
      setValueReference.current('end_time', calculatedData?.date?.toDate());
    }
  };

  const resetDateAndTime = () => {
    setShowPrivousDate(false);
    setValueReference.current(
      'start_time',
      moment(defaultValues?.start_time).toDate()
    );
    setValueReference.current('end_time', moment().toDate());
    setValueReference.current('start_date', moment().toDate());
    setValueReference.current('end_date', moment().toDate());
  };

  const calculateTime = (hours: any = 0, minutes: any = 0) => {
    const currentTime = moment(defaultValues?.start_time);

    const updatedTime = moment(currentTime)
      .add(hours, 'hours')
      .add(minutes, 'minutes');

    const currentDate = moment().startOf('day');
    const updatedDate = moment(currentTime)
      .add(hours, 'hours')
      .add(minutes, 'minutes')
      .startOf('day');

    if (updatedDate.isAfter(currentDate)) {
      const date = moment(currentTime)
        .subtract(hours, 'hours')
        .subtract(minutes, 'minutes');

      const isSameDay = moment(date).isSame(moment(), 'day');
      return isSameDay
        ? { date, isPreviousDate: true, isSameDay: true }
        : { date, isPreviousDate: true, isSameDay: false };
    }
    return { date: updatedTime, isPreviousDate: false };
  };

  const onSubmit = (data: any) => {
    const payload = createPayload(data);

    dispatch(updateDeleteTrackedTime({ timerId: row?._id, ...payload })).then(
      (result: any) => {
        if (updateDeleteTrackedTime.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            closeModal();
            dispatch(
              trackedTimeTaskHistoryDetails({
                task_id: row?.task_id?._id,
                sort_field: 'createdAt',
                sort_order: 'desc',
                pagination: true,
              })
            );
            dispatch(getTaskById({ taskId: row?.task_id?._id }));
          }
        }
      }
    );
  };

  // Create payload
  const createPayload = (data: any) => {
    return {
      notes: data?.notes,
      mode: row?.mode,
      event_type: 'update',
      clocking: {
        clock_in: moment(data?.start_time)
          .utc()
          .format(),
        clock_out: moment(data?.end_time)
          .utc()
          .format(),
      },
    };
  };

  const calculateTotalTimeFromDateRage = () => {
    const totalSeconds = calculateTotalTimeInSeconds(
      getValuesReference.current()?.start_time,
      getValuesReference.current()?.end_time
    );
    setValueReference.current(
      'manual_time',
      convertSecondsToTimeForManaul(totalSeconds)
    );
  };

  // Get Min Time
  const getMinTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment(selectedDate).isSame(moment(), 'day')
        ? moment().toDate()
        : moment().endOf('day').toDate();
    }
    return undefined;
  };

  const isToday = (date: any) => {
    const today = moment()?.startOf('day');
    return (
      moment(date).isSame(moment(), 'day') ||
      moment(date).isBefore(today, 'day')
    );
  };

  const onChangeDate = (date: any) => {
    setValueReference.current('start_time', date);
    setValueReference.current('end_time', date);
  };

  return (
    <div className="p-5">
      <div className="space-y-4">
        <div className="mb-4 flex items-center justify-between">
          <span className="montserrat_font_title text-[16px] font-bold leading-[24px] text-[#141414] ">
            Time on task
          </span>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => {
              closeModal();
              dispatch(getTaskById({ taskId: row?.task_id?._id }));
            }}
            className="p-0 text-[#141414] hover:text-[#8C80D2]"
          >
            <PiXBold className="h-[10.96px] w-[10.96px]" />
          </ActionIcon>
        </div>

        <div className="">
          <div className="mb-3 ml-1 flex items-center gap-3">
            <Avatar
              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${row?.user_id?.profile_image}`}
              name={`${capitalizeFirstLetter(
                row?.user_id?.first_name
              )} ${capitalizeFirstLetter(row?.user_id?.last_name)}`}
              className="poppins_font_number bg-[#70C5E0]/[.08] font-bold text-white"
            />
            <p className="font-bold text-black">
              {`${capitalizeFirstLetter(
                row?.user_id?.first_name
              )} ${capitalizeFirstLetter(row?.user_id?.last_name)}`}
            </p>
          </div>
          {/* <hr /> */}

          {/* Timer Form - Start*/}
          <div>
            <Form
              validationSchema={timeTrackingSchema}
              onSubmit={onSubmit}
              useFormProps={{
                mode: 'all',
                defaultValues,
              }}
              //   className="p-4"
            >
              {({
                register,
                control,
                watch,
                setValue,
                getValues,
                clearErrors,
                setError,
                formState: { errors },
              }) => (
                (setValueReference.current = setValue),
                (getValuesReference.current = getValues),
                (
                  <div className="space-y-5">
                    <div className="h-auto w-auto gap-[12px] rounded-[6px] bg-[#F9FAFB] p-[12px]">
                      <div className="mb-2 flex flex-row  items-center justify-items-start gap-[12px]">
                        <div className="">
                          <Controller
                            name="start_time"
                            control={control}
                            render={({ field: { value, onChange } }) => (
                              <DatePicker
                                className="tracker-date-picker"
                                placeholderText="Start time"
                                selected={value}
                                onChange={(event: any) => {
                                  onChange(event);
                                  calculateTotalTimeFromDateRage();
                                }}
                                showTimeSelect
                                showTimeSelectOnly
                                dateFormat="hh:mm aa"
                                inputProps={{
                                  inputClassName: 'poppins_font_number',
                                }}
                              />
                            )}
                          />
                          <p className="mt-1 text-xs text-red">
                            {errors?.start_time?.message as string}
                          </p>
                        </div>
                        <div className="text-[16px] font-bold leading-[21.86px] text-[#1E2026]">
                          <span>-</span>
                        </div>
                        <div className="">
                          <Controller
                            name="end_time"
                            control={control}
                            render={({ field: { value, onChange } }) => (
                              <DatePicker
                                className="tracker-date-picker"
                                placeholderText="End time"
                                selected={value}
                                onChange={(event: any) => {
                                  onChange(event);
                                  calculateTotalTimeFromDateRage();
                                }}
                                showTimeSelect
                                showTimeSelectOnly
                                dateFormat="hh:mm aa"
                                minDate={getMinTime()}
                                inputProps={{
                                  inputClassName: 'poppins_font_number',
                                }}
                              />
                            )}
                          />
                          <p className="mt-1 text-xs text-red">
                            {errors?.end_time?.message as string}
                          </p>
                        </div>
                        <div>
                          <Controller
                            name="start_date"
                            control={control}
                            render={({ field: { value, onChange } }) => (
                              <DatePicker
                                className="tracker-start-date-picker"
                                placeholderText="Start date"
                                selected={value}
                                onChange={(e) => (
                                  onChange(e),
                                  setSelectedDate(e),
                                  onChangeDate(e)
                                )}
                                selectsStart
                                startDate={value}
                                maxDate={moment().toDate()}
                                // showTimeSelect
                                dateFormat="MMM dd, yyyy"
                              />
                            )}
                          />
                          <p className="mt-1 text-xs text-red">
                            {errors?.start_date?.message as string}
                          </p>
                        </div>
                        {showPrivousDate && (
                          <div>
                            <Controller
                              name="end_date"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <DatePicker
                                  className="meeting-date-picker"
                                  placeholderText="End date"
                                  selected={value}
                                  onChange={(e) => onChange(e)}
                                  selectsStart
                                  startDate={value}
                                  dateFormat="MMMM dd, yyyy"
                                />
                              )}
                            />
                            <p className="mt-1 text-xs text-red">
                              {errors?.end_date?.message as string}
                            </p>
                          </div>
                        )}
                      </div>
                      <div className="mb-2 flex items-center gap-2">
                        {/* Timer Tracking - Manual */}
                        <Input
                          type="text"
                          placeholder="Enter time here"
                          className="w-[89%] rounded-xl [&>label>span]:font-medium"
                          {...register('manual_time')}
                          // onBlur={(e) => manualDateChange(e.target.value)}
                          readOnly
                          error={errors?.manual_time?.message as string}
                          inputClassName="poppins_font_number bg-[#FFFFFF]"
                          helperClassName="poppins_font_number"
                          // helperText="Ex: 2h 30m format"
                        />
                      </div>

                      {/* Notes field - Only show when time tracking is manual */}
                      <div className="flex items-center gap-2">
                        {/* <CgNotes className="h-8 w-8" /> */}
                        <Input
                          type="text"
                          placeholder="Enter notes here"
                          className="h-[36px] w-full rounded-[8px] border-[#D4D4D4]"
                          {...register('notes')}
                          // onBlur={(e) => manualDateChange(e.target.value)}
                          error={errors?.notes?.message as string}
                          inputClassName="poppins_font_number bg-[#FFFFFF]"
                          helperClassName="poppins_font_number"
                          // helperText="Ex: 2h 30m format"
                          disabled={deleteTrackedTimeLoader}
                        />
                        <Button
                          type="submit"
                          className="flex h-[36px] w-auto items-center justify-center rounded-[8px] bg-[#7667CF] py-4 text-[14px] font-normal leading-[16.8px] text-[#fff]  hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                          size="sm"
                        >
                          Save
                          {deleteTrackedTimeLoader && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              )}
            </Form>
          </div>
          {/* Timer Form - End*/}
        </div>
      </div>
    </div>
  );
};

export default UpdateTrackedHourForm;
