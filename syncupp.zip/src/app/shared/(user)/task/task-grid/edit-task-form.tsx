'use client';

import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import QuillLoader from '@/components/loader/quill-loader';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import Select from '@/components/ui/select';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { Switch } from '@/components/ui/switch';
import { Text } from '@/components/ui/text';
import { messages } from '@/config/messages';
import { routes } from '@/config/routes';
import '@/layouts/helium/style.css';
import { getSettingData } from '@/redux/slices/user/setting/settingSlice';
import {
  getAllAssignees,
  getMembersByBoardId,
} from '@/redux/slices/user/task/boardSlice';
import {
  duplicateAddTask,
  getAllCommentsById,
  getAllTask,
  getTaskById,
  patchEditTask,
  postAddTask,
} from '@/redux/slices/user/task/taskSlice';
import {
  removeTrackedHourDetails,
  taskTimeTrackedHistory,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import {
  capitalizeFirstLetter,
  checkValidFileSize,
  convertSecondsToTime,
  getColor,
  getFileSize,
  getFileType,
  handleKeyDown,
} from '@/utils/common-functions';
import axios from 'axios';
import moment from 'moment';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useDropzone } from 'react-dropzone';
import { Controller, SubmitHandler } from 'react-hook-form';
import { BiSolidBellRing } from 'react-icons/bi';
import { FiEdit, FiPlus, FiTrash, FiUsers } from 'react-icons/fi';
import { ImAttachment } from 'react-icons/im';
import { IoDuplicateOutline } from 'react-icons/io5';
import { LuBellRing } from 'react-icons/lu';
import { PiCaretDownBold } from 'react-icons/pi';
import { RxCross2 } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import {
  Avatar,
  Badge,
  Button,
  Checkbox,
  Input,
  Popover,
  Radio,
  Textarea,
  Tooltip,
} from 'rizzui';
import { z } from 'zod';
import { checkPermission } from '../../roles-permissions/utils';
import AddTaskForm from './add-task-form';
import { ConfirmationTaskDeleteModal } from './delete-task-confirmation-modal';
import NewSubTaskForm from './new-subtask-form';
import TaskReminder from './task-reminder-model';
import ReactSelect, { components } from 'react-select';
import TailwindSwitch from '@/hooks/tailwindSwitch';
import {
  IoIosCheckmarkCircle,
  IoIosCheckmarkCircleOutline,
  IoIosTimer,
  IoMdAdd,
} from 'react-icons/io';
import backRouteIcon from '@public/assets/svgs/backRouteIcon.svg';
import { putTaskKanbanStatusChange } from '@/redux/slices/user/task/taskStatusSlice';
import Image from 'next/image';
import { createPortal } from 'react-dom';
import WeeklyRecurring from './WeeklyRecurring';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px] w-full" />,
});

interface Status {
  _id: string;
}

interface Assignee {
  _id: string;
}

interface DuplicateTaskSchema {
  _id: string;
  title: string;
  agenda?: string;
  priority: string;
  board_id: string;
  duplicated_from: string;
  status: Status;
  due_date?: string | null;
  assign_to?: Assignee[];
  attachments?: [];
  custom_fields?: any;
  parent_task?: any;
  tags?: any;
  recurrence_pattern?: any;
  recurrence_end_date?: any;
  recurrence_interval?: any;
  weekly_recurrence_days?: any;
  monthly_recurrence_day_of_month?: any;
}

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E4F6D6]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="w-[130px] font-medium text-green-dark">Low</Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FBF0DE]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#FBF0DE] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="warning" renderAsDot />
        <Text className="w-[130px] font-medium text-orange-dark">Medium</Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFD4C6]',
    label: (
      <div className="flex items-center gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="w-[130px] font-medium text-red-dark">High</Text>
      </div>
    ),
  },
];

const RecurringArray = [
  // {
  //   name: 'Does not repeat',
  //   label: 'Does not repeat',
  //   value: '',
  // },
  {
    name: 'Daily',
    label: 'Daily',
    value: 'daily',
  },
  {
    name: 'Weekly',
    label: 'Weekly',
    value: 'weekly',
  },
  {
    name: 'Monthly',
    label: 'Monthly',
    value: 'monthly',
  },
];
const monthDate = [
  { label: '1', value: '1' },
  { label: '2', value: '2' },
  { label: '3', value: '3' },
  { label: '4', value: '4' },
  { label: '5', value: '5' },
  { label: '6', value: '6' },
  { label: '7', value: '7' },
  { label: '8', value: '8' },
  { label: '9', value: '9' },
  { label: '10', value: '10' },
  { label: '11', value: '11' },
  { label: '12', value: '12' },
  { label: '13', value: '13' },
  { label: '14', value: '14' },
  { label: '15', value: '15' },
  { label: '16', value: '16' },
  { label: '17', value: '17' },
  { label: '18', value: '18' },
  { label: '19', value: '19' },
  { label: '20', value: '20' },
  { label: '21', value: '21' },
  { label: '22', value: '22' },
  { label: '23', value: '23' },
  { label: '24', value: '24' },
  { label: '25', value: '25' },
  { label: '26', value: '26' },
  { label: '27', value: '27' },
  { label: '28', value: '28' },
  { label: '29', value: '29' },
  { label: '30', value: '30' },
  { label: '31', value: '31' },
];

const weekdays = [
  { name: 'M', value: 'monday' },
  { name: 'T', value: 'tuesday' },
  { name: 'W', value: 'wednesday' },
  { name: 'T', value: 'thursday' },
  { name: 'F', value: 'friday' },
  { name: 'SA', value: 'saturday' },
  { name: 'S', value: 'sunday' },
];

const reminderOptions = [
  // { value: 'on_due_date', label: 'On due date' },
  { value: 'no_notify', label: "Don't notify" },
  { value: '10_min_before', label: '10 minutes before' },
  { value: '30_min_before', label: '30 minutes before' },
  { value: '1_hour_before', label: '1 hour before' },
  { value: '1_day_before', label: '1 day before' },
  { value: '2_day_before', label: '2 days before' },
  { value: '3_day_before', label: '3 days before' },
  { value: '1_week_before', label: '1 week before' },
  { value: '2_week_before', label: '2 weeks before' },
  { value: 'custom', label: 'Custom' },
];

const RepeatOptions = [
  // { value: 'on_due_date', label: 'On due date' },
  { value: 'no_repetition', label: 'No repetition' },
  {
    value: 'daily',
    label: 'Daily until the task is completed',
  },
  {
    value: 'weekly',
    label: 'Weekly until the task is completed',
  },
];

const customData = [
  { value: 'minutes', label: 'Minutes before' },
  { value: 'hours', label: 'Hours before' },
  { value: 'days', label: 'Days before' },
];

const customStyles = {
  control: (provided: any, state: any) => ({
    ...provided,
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    borderRadius: '8px',
    borderColor: state.isFocused ? 'black' : 'rgb(209 213 219)',
    boxShadow: state.isFocused ? 'none' : 'none', // Ensure no box-shadow on focus
    outline: 'none !important',
    padding: '0 8px',
    transition: 'border-color 0.2s ease',
    '&:hover': {
      borderColor: 'black', // Black border on hover
    },
  }),
  input: (provided: any) => ({
    ...provided,
    border: 'none !important',
    boxShadow: 'none !important',
    outline: 'none !important',
    caretColor: 'rgb(209 213 219)', // Ensures visible text cursor
  }),
  valueContainer: (provided: any) => ({
    ...provided,
    display: 'flex',
    alignItems: 'center',
    padding: '0 8px',
    gap: '8px',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  }),
  placeholder: (provided: any) => ({
    ...provided,
    color: 'rgb(209 213 219)',
    fontSize: '14px',
    fontWeight: '500',
    whiteSpace: 'nowrap',
  }),
  singleValue: (provided: any) => ({
    ...provided,
    fontWeight: '600',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  }),
  multiValue: (provided: any) => ({
    ...provided,
    backgroundColor: '#e1e7ff',
    borderRadius: '12px',
    padding: '2px 6px',
    display: 'flex',
    alignItems: 'center',
  }),
  multiValueLabel: (provided: any) => ({
    ...provided,
    fontSize: '12px',
    fontWeight: '500',
    color: '#4a4a4a',
  }),
  multiValueRemove: (provided: any) => ({
    ...provided,
    color: '#8c80d2',
    cursor: 'pointer',
    ':hover': {
      backgroundColor: '#e0e0e0',
      color: '#4a4a4a',
    },
  }),
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isFocused ? '#f3f4f6' : 'white',
    color: state.isSelected ? '#4a4a4a' : '#000',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: state.isSelected ? '600' : '400',
    ':active': {
      backgroundColor: '#e1e7ff',
    },
  }),
  menu: (provided: any) => ({
    ...provided,
    zIndex: 9999,
    borderRadius: '8px',
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
    marginTop: '4px',
  }),
  dropdownIndicator: (provided: any) => ({
    ...provided,
    color: '#8c80d2',
    ':hover': {
      color: '#4a4a4a',
    },
  }),
  indicatorSeparator: () => ({
    display: 'none !important',
  }),
};

export default function EditTaskForm(props: any) {
  // if we open from table columns in edit or view mode
  const {
    editMode,
    rowData,
    column,
    createTask,
    updateTask,
    setAssigneeFilter,
    setTaskFilterOptionName,
    setTaskFilterOptionValue,
    onClose,
  } = props;

  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const { closeDrawer } = useDrawer();
  const setErrorReference = useRef<any>();
  const setClearErrorReference = useRef<any>();
  const setWatchReference = useRef<any>();
  const modalTaskRef = useRef(null);

  const taskData = useSelector((state: any) => state?.root?.task);
  const task = taskData?.task?.activity ?? {}; // after get task by id data in edit mode

  const [allSubtask, setAllSubtask] = useState<any[]>([]);

  // Update allSubtask when task is available
  useEffect(() => {
    if (Object.keys(task)?.length > 0 && task?.sub_tasks) {
      setAllSubtask(task?.sub_tasks);
    }
  }, [task]);

  const [isEachMonth, setIsEachMonth] = useState(false);
  const [isEachWeek, setIsEachWeek] = useState(false);
  const [isEachWeekModal, setIsEachWeekModal] = useState(false);
  const [recurrenceDueDay, setRecurrenceDueDay] = useState<any>(
    task?.monthly_recurrence_day_of_month
      ? {
          label: String(task?.monthly_recurrence_day_of_month),
          value: String(task?.monthly_recurrence_day_of_month),
        }
      : { label: '1', value: '1' }
  );
  const [defaultRecurrence, setDefaultRecurrence] = useState<any>(
    task?.recurrence_default_due_date
      ? {
          label: String(task?.recurrence_default_due_date),
          value: String(task?.recurrence_default_due_date),
        }
      : { label: '1', value: '1' }
  );

  const signIn = useSelector((state: any) => state?.root?.signIn);
  const {
    gridView,
    paginationParams,
    oldTasks,
    oldTasksSections,
    duplicateTaskLoading,
    loading: taskLoading,
  } = useSelector((state: any) => state?.root?.task);
  const { loading } = useSelector((state: any) => state?.root?.taskStatus);
  const { boardId, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { trackedHourDetails } = useSelector(
    (state: any) => state?.root?.timeTracking
  );
  const { settingData } = useSelector((state: any) => state?.root?.setting);
  const isFirstRender = useRef(true); // Track initial render

  // create hook form setValue reference
  const setValueReference = useRef<any>();
  const getValueReference = useRef<any>();

  // create comment text area setValue reference
  const commentTextAreaReference = useRef<any>();
  const commentAttachmentRef = useRef<HTMLInputElement>(null);
  // const [selectedRecipients, setSelectedRecipients] = useState<any>([]);
  const [selectedRecurringOption, setSelectedRecurringOption] = useState<any>({
    name: '',
    label: '',
    value: '',
  });
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [selectedEndDate, setSelectedEndDate] = useState<any>(null);

  const [selectedReminder, setSelectedReminder] = useState({
    value: 'no_notify',
    label: "Don't notify",
    name: "Don't notify",
  });
  const [selectedRepetition, setSelectedRepetition] = useState({
    value: 'no_repetition',
    label: 'No repetition',
    name: 'No repetition',
  });

  const isToday = (date: any) => {
    const today = moment()?.startOf('day');
    return (
      moment(date).isSame(moment(), 'day') ||
      moment(date).isBefore(today, 'day')
    );
  };
  // Get Min Time
  const getMinTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment(selectedDate).isSame(moment(), 'day')
        ? moment().toDate()
        : moment().endOf('day').toDate();
    }
    return undefined;
  };

  // Get Max Time
  const getMaxTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment().endOf('day').toDate();
    }
    return undefined;
  };

  const MAX_FILE_SIZE = 200 * 1024 * 1024; // 200MB in bytes

  const taskFormSchema = z.object({
    title: z
      .string()
      .min(1, { message: messages.titleIsRequired })
      .max(150, { message: messages.taskTitleLength }),
    agenda: z.string().optional(),
    // attachments: z.any().optional(),
    attachments: z
      .any()
      .optional()

      .refine((files) => {
        if (typeof files === 'string') {
          return true;
        } else if (typeof files === 'object') {
          let checkInvalidFile: any[] = [];
          checkInvalidFile =
            files?.length > 0 &&
            files?.filter((file: any) => {
              return file?.size > MAX_FILE_SIZE;
            });

          return checkInvalidFile?.length > 0 ? false : true;
          // return files?.size <= MAX_FILE_SIZE;
        }
      }, messages.taskAttachementMaxFileSize),
    priority: z.string().optional(),
    due_date: z
      .date()
      .nullable()
      .optional()
      .refine(
        (dueDate) => {
          if (task?.parent_task && task?.parent_task_data?.due_date) {
            return (
              !dueDate ||
              new Date(dueDate) <= new Date(task?.parent_task_data?.due_date)
            );
          }
          return true;
        },
        {
          message: "Due date can't exceed parent due date.",
        }
      ),
    board_id: z.string().optional(),
    status: z.string().min(1, { message: 'Status is required' }),
    assign_to: z.string().optional(),
    comment: z.string().optional(),
    comment_attachments: z.any().optional(),
    mentioned_users: z.any().optional(),
    recurrence_pattern: z.string().nullable().optional(),
    weekly_recurrence_days:
      selectedRecurringOption?.value === 'weekly'
        ? z.array(z.string()).min(1, 'Select at least one day')
        : z.array(z.string()).optional(),
    recurrence_start_at_time:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable() // This allows it to be null
            .refine((val: any) => val !== null, {
              message: messages.recurringStartTimeIsRequried,
            })
        : z.date().nullable().optional(),
    recurrence_start_date:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringStartDateIsRequried,
            })
        : z.date().nullable().optional(),

    recurrence_task_due_date:
      signIn?.userProfile?.agency_setting?.is_custom_recurring &&
      selectedRecurringOption?.value === 'monthly' &&
      isEachMonth
        ? z
            .array(
              z.object({
                index: z.number().optional(),
                month: z.number().min(1).max(12).optional(), // Ensure valid months (1-12)
                year: z.number().min(1900).optional(), // Ensure a reasonable year
                date: z.date().nullable().optional(), // Ensures default null
              })
            )
            .min(1, {
              message:
                'At least one due date is required for monthly recurrence',
            })
            .optional()
        : z
            .array(
              z.object({
                index: z.number().optional(),
                month: z.number().min(1).max(12).optional(), // Ensure valid months (1-12)
                year: z.number().min(1900).optional(), // Ensure a reasonable year
                date: z.any().nullable().optional(), // Ensures default null
                day: z.number().nullable().optional(),
              })
            )
            .optional(),

    recurrence_default_due_date:
      signIn?.userProfile?.agency_setting?.is_custom_recurring &&
      selectedRecurringOption?.value == 'monthly' &&
      !isEachMonth
        ? z
            .object({
              label: z.string(),
              value: z.string(),
            })
            .nullable()
        : z
            .object({
              label: z.string().optional(),
              value: z.string().optional(),
            })
            .optional(),
    due_date_duration:
      selectedRecurringOption?.value !== '' &&
      (!signIn?.userProfile?.agency_setting ||
        signIn?.userProfile?.agency_setting === null ||
        signIn?.userProfile?.agency_setting?.is_custom_recurring === false)
        ? z
            .string()
            .min(1, { message: 'Due date duration is required' })
            .regex(/^[0-9]\d*$/, {
              message: 'Only positive numbers are allowed (e.g., 0, 1, 2, 3)',
            })
            .transform((val) => Number(val))
            .refine((val) => val <= 100, {
              message: 'Maximum allowed value is 100',
            })
        : z.string().optional(),
    // recurrence_interval:
    //   selectedRecurringOption?.value !== ''
    //     ? z
    //         .string()
    //         .min(1, { message: 'Minimum 1 number required' })
    //         .max(2, { message: 'Maximum 2 digits allowed' })
    //         .regex(/^[1-9][0-9]?$/, {
    //           message: 'Only positive integers greater than 0 are allowed',
    //         }) // Excludes 0, only positive integers are allowed
    //     : z.string().optional(),
    board: z.string().optional(),
    recurrence_end_date:
      selectedRecurringOption?.value !== ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringEndDateIsRequried,
            })
        : z.date().nullable().optional(),
    monthly_recurrence_day_of_month:
      selectedRecurringOption?.value === 'monthly'
        ? z
            .object({
              label: z.string(),
              value: z.string(),
            })
            .nullable()
        : z
            .object({
              label: z.string().optional(),
              value: z.string().optional(),
            })
            .optional(),
    reminder: z.string().optional(),
    repeat: z.string().optional(),
    reminder_user:
      selectedReminder?.value !== 'no_notify' ||
      selectedRepetition?.value !== 'no_repetition'
        ? z
            .array(z.string())
            .min(1, { message: 'At least one reminder user is required' })
        : z.array(z.string()).optional(),
    reminder_date:
      selectedReminder?.value === 'custom'
        ? z
            .union([z.date(), z.null()])
            .refine((date) => date !== null && !isNaN(date.getTime()), {
              message: 'Reminder date is required and must be a valid date',
            })
        : z.date().nullable().optional(),
  });
  type TaskFormSchema = z.infer<typeof taskFormSchema>;

  // const [files, setFiles] = useState<any>([]);
  const [commentText, setCommentText] = useState('');
  const [showSubtaskFields, setShowSubtaskFields] = useState(false);

  //set subtask state
  const [subTaskData, setSubTaskData] = useState<any>(null);

  // for assignee open modal
  const [showPopper, setShowPopper] = useState(false);

  // for sub task open modal
  const [showSubTaskModal, setShowSubTaskModal] = useState(false);

  //coustomField data
  const [customFieldData, setCustomFieldData] = useState<any>([]);

  // for delete confirmation open modal
  const [showDeleteConfirmationPopper, setShowDeleteConfirmationPopper] =
    useState(false);

  // for delete confirmation open modal
  const [showTaskReminderPopper, setShowTaskReminderPopper] = useState(false);

  // selected assigness - in ["id", "id"]
  const [selectedMembers, setSelectedMembers] = useState([]);

  // for selected status option
  const [selectedStatus, setSelectedStatus] = useState<any>(null);

  // for selected priority option
  const [selectedPriority, setSelectedPriority] = useState<any>(null);

  // for multiple selected attachment preview - [{}, {}]
  const [previewImage, setPreviewImage] = useState<any>(null);

  // for multiple selected attachement preview for comment
  const [previewImageForComment, setPreviewImageForComment] =
    useState<any>(null);

  // for mark complete button
  const [taskDone, setTaskDone] = useState(false);

  // for leave task
  const [canLeaveTask, setCanLeaveTask] = useState(false);

  // My tracked time
  const [myTimeTracked, setMyTimeTracked] = useState(0);

  // create agenda input reference
  const agendaInputRef = useRef<HTMLTextAreaElement>(null);

  // for get agenda value
  const [agendaValue, setAgendaValue] = useState<string>();

  // bulk download
  const [bulkDownload, setBulkDownload] = useState<any[]>([]);
  const [bulkDownloadLoader, setBulkDownloadLoader] = useState(false);
  const [shouldCloseDrawer, setShouldCloseDrawer] = useState(false);
  const [isDisable, setIsDisable] = useState(false);
  // Comment with mentions
  const [mentionUser, setMentionUser] = useState<any>([]);
  const [tags, setTags] = useState<{ tag_name: string; tag_color?: string }[]>(
    []
  );
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isRecurring, setIsRecurring] = useState(rowData?.recurring ?? false);
  const [isReminder, setIsReminder] = useState(false);

  const MAX_WORDS = 20;
  const MAX_CHARS = 20;

  // Clear error when the input loses focus
  const handleInputBlur = () => {
    setError(null); // Clear the error when the input loses focus
  };
  // Add the onChange validation
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);

    const trimmedValue = value.trim();

    // Validation
    const wordCount = trimmedValue.split(/\s+/).filter(Boolean).length;
    if (trimmedValue === '') {
      setError('Tag cannot be empty.');
    } else if (trimmedValue.length > MAX_CHARS) {
      setError(`Each tag can have a maximum of ${MAX_CHARS} characters.`);
    } else if (
      tags.some(
        (tag) => tag.tag_name.toLowerCase() === trimmedValue.toLowerCase()
      )
    ) {
      setError('This tag already exists.');
    } else {
      setError(null); // No error if the input is valid
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const trimmedValue = inputValue.trim();

      if (trimmedValue !== '' && !error) {
        setTags([...tags, { tag_name: trimmedValue }]);
        setInputValue('');
      }
    }
  };

  // Remove a tag
  const handleRemoveTag = (index: number) => {
    setTags(tags.filter((_, i) => i !== index));
  };

  // for handle comment attachement error
  const [commentAttachementInvalid, setCommentAttachementInvalid] =
    useState(false);

  // Initialize tags from rowData in edit mode
  useEffect(() => {
    if (editMode && task?.tags?.length > 0) {
      setTags(
        task.tags.map((tag: any) => ({
          tag_name: tag.tag_name.trim(),
          tag_color: tag.tag_color,
        }))
      );
    }
  }, [editMode, task]);

  useEffect(() => {
    (!editMode || (editMode && task?.custom_fields?.length === 0)) &&
      dispatch(getSettingData());
  }, [dispatch, editMode, task?.custom_fields]);

  useEffect(() => {
    (!editMode || (editMode && task?.custom_fields?.length === 0)) &&
      dispatch(getSettingData());
  }, [dispatch, editMode, task?.custom_fields]);

  useEffect(() => {
    const filterCustomFields =
      board?.custom_fields?.filter((filed: any) => filed?.isShow) ?? [];
    setCustomFieldData(
      editMode
        ? task?.custom_fields?.length === 0
          ? filterCustomFields
          : task?.custom_fields
        : filterCustomFields
    );
  }, [editMode, board?.custom_fields, task?.custom_fields]);

  useEffect(() => {
    // fetching get task by id and get comments by task id
    if (editMode) {
      setTags([]);
      setPreviewImage(null);
      dispatch(getTaskById({ taskId: rowData?._id })).then((result: any) => {
        if (getTaskById?.fulfilled?.match(result)) {
          if (result && result?.payload?.success === true) {
          } else {
            onClose();
          }
        } else {
          onClose();
        }
      });
      dispatch(taskTimeTrackedHistory(rowData?._id));
      dispatch(getAllCommentsById({ task_id: rowData?._id }));
    } else {
      setMyTimeTracked(0);
      dispatch(removeTrackedHourDetails());
    }
  }, [rowData]);

  useEffect(() => {
    const setRecurrencePattern = RecurringArray?.find(
      (data: any) => data?.value === task?.recurrence_pattern
    );
    if (setRecurrencePattern) {
      setSelectedRecurringOption(setRecurrencePattern);
    } else {
      setSelectedRecurringOption({
        name: 'Does not repeat',
        label: 'Does not repeat',
        value: '',
      });
    }

    if (
      task?.recurrence_task_due_date &&
      task?.recurrence_task_due_date?.length > 0
    ) {
      //   setIsEachMonth(true);
      //   // setSelectedDate(task?.recurrence_start_date);
      //   // setSelectedEndDate(task?.recurrence_end_date);
      // } else {
      //   setIsEachMonth(false);
      //   // setSelectedDate(task?.recurrence_start_date);
      //   // setSelectedEndDate(task?.recurrence_end_date);
      if (task?.recurrence_pattern === 'monthly') {
        setIsEachMonth(true);
      }
      if (task?.recurrence_pattern === 'weekly') {
        setIsEachWeek(true);
      }
      // setSelectedDate(task?.recurrence_start_date);
      // setSelectedEndDate(task?.recurrence_end_date);
    } else {
      if (task?.recurrence_pattern === 'monthly') {
        setIsEachMonth(false);
      }
      if (task?.recurrence_pattern === 'weekly') {
        setIsEachWeek(false);
      }
      // setSelectedDate(task?.recurrence_start_date);
      // setSelectedEndDate(task?.recurrence_end_date);
    }
  }, [task]);

  useEffect(() => {
    const setupdateReminder: any = reminderOptions?.find(
      (data: any) => data?.value === task?.reminder_option
    );
    if (setupdateReminder) {
      setSelectedReminder(setupdateReminder);
    } else {
      setSelectedReminder({
        value: 'no_notify',
        label: "Don't notify",
        name: "Don't notify",
      });
    }
    const selectedRepetOption: any = RepeatOptions?.find(
      (data: any) => data?.value === task?.repeat
    );

    if (selectedRepetOption) {
      setSelectedRepetition(selectedRepetOption);
    } else {
      setSelectedRepetition({
        value: 'no_repetition',
        label: 'No repetition',
        name: 'No repetition',
      });
    }
  }, [task]);

  // On Change Recurring
  const onChangeRecurring = (option: any, setValue: any) => {
    setSelectedRecurringOption(option);
    if (option?.value !== '') {
      setValue('recurrence_pattern', option?.value);
    } else {
      setValue('recurrence_pattern', '');
    }
  };

  //on Change Reminder
  const handleCustomChange = (option: any, setValue: any) => {
    setSelectedReminder(option);
    if (option?.value !== '') {
      setValue('reminder', option?.value);
    } else {
      setValue('reminder', '');
    }
    // if (value.value !== 'custom') {
    //   setCustomValue(30); // Reset custom value
    //   setCustomUnit('minutes'); // Reset unit
    // }
  };

  useEffect(() => {
    if (trackedHourDetails && Object.keys(trackedHourDetails)?.length > 0) {
      trackedHourDetails?.tracked_history?.length > 0 &&
        trackedHourDetails?.tracked_history?.map((data: any) => {
          if (data?.user?._id === signIn?.user?.data?.user?._id) {
            setMyTimeTracked(data?.total_time);
          }
        });
    } else {
      setMyTimeTracked(0);
    }
  }, [signIn?.user?.data?.user?._id, trackedHourDetails]);

  const parseTimeToDate = (timeString: string | null) => {
    if (!timeString) return null;
    const now = new Date(); // Use current date
    const [hours, minutes] = timeString.split(':').map(Number);
    return new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      hours,
      minutes
    );
  };

  // api call for get clients and team member
  useEffect(() => {
    dispatch(getAllAssignees());
    // dispatch(getBoardSectionsById({ board_id: board?._id }));
    boardId && dispatch(getMembersByBoardId({ boardId: boardId }));
  }, []);

  const clientTeamAllOptions: Record<string, any>[] = useMemo(() => {
    return assignees && assignees.length > 0
      ? assignees.map((team: Record<string, any>) => {
          const name = `${capitalizeFirstLetter(
            team?.first_name
          )} ${capitalizeFirstLetter(team?.last_name)}`;
          return { ...team, name };
        })
      : [];
  }, [assignees]);

  const allOption = {
    label: 'Select all',
    value: '*',
    name: 'Select all',
  };

  const allSelectedMembers = useMemo(() => {
    return clientTeamAllOptions.filter(
      (item) => selectedMembers?.includes(item?.user_id as never)
    );
  }, [clientTeamAllOptions, selectedMembers]);
  const assigneeOptions = useMemo(() => {
    return allSelectedMembers && allSelectedMembers.length > 0
      ? allSelectedMembers.map((assignee: Record<string, any>) => ({
          name: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          label: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          value: assignee?.user_id,
          key: assignee,
        }))
      : [];
  }, [allSelectedMembers]);

  const memberOptions = selectedMembers.map((member: any) => ({
    value: member.user_id,
    label: `${member.first_name} ${member.last_name}`,
  }));

  const optionsWithSelectAll = useMemo(() => {
    return [allOption, ...assigneeOptions];
  }, [allOption, assigneeOptions]);

  const mapReminderUserIdsToOptions = useCallback(
    (ids: string[]) =>
      assigneeOptions.filter((option) => ids.includes(option.value)),
    [assigneeOptions]
  );

  const getMonthlyDates = (startDate: Date | null, endDate: Date | null) => {
    if (!startDate || !endDate) return [];

    let currentDate = new Date(
      startDate.getFullYear(),
      startDate.getMonth(),
      1
    );
    const monthlyDates = [];

    while (currentDate <= endDate) {
      monthlyDates.push({
        index: monthlyDates?.length,
        month: currentDate.getMonth() + 1, // 1-based month
        year: currentDate.getFullYear(),
        date: new Date(currentDate),
        isStartMonth:
          currentDate.getMonth() === startDate.getMonth() &&
          currentDate.getFullYear() === startDate.getFullYear(),
        isEndMonth:
          currentDate.getMonth() === endDate.getMonth() &&
          currentDate.getFullYear() === endDate.getFullYear(),
      });

      currentDate.setMonth(currentDate.getMonth() + 1);
    }

    return monthlyDates;
  };
  const [monthlyDates, setMonthlyDates] = useState([]);
  const [weeklyDates, setWeeklyDates] = useState([]);

  // Memoize monthly dates to avoid unnecessary re-renders
  const computedMonthlyDates: any = useMemo(() => {
    return getMonthlyDates(selectedDate, selectedEndDate);
  }, [selectedDate, selectedEndDate]);

  useEffect(() => {
    if (selectedRecurringOption?.value === 'monthly') {
      setMonthlyDates(computedMonthlyDates);
    }
  }, [computedMonthlyDates, selectedRecurringOption]);

  useEffect(() => {
    if (task?.recurrence_pattern === 'weekly') {
      const setDueDate =
        task?.recurrence_task_due_date &&
        task?.recurrence_task_due_date?.length > 0
          ? task?.recurrence_task_due_date?.map((item: any) => ({
              month: item?.month,
              year: item?.year,
              date: item?.date ? moment(item.date).toDate() : null, // Default to null initially
              day: item?.day,
            }))
          : [];
      setValueReference.current('recurrence_task_due_date', setDueDate);
    }
  }, [task?.recurrence_pattern]);

  const initialValues: TaskFormSchema = {
    title: editMode ? task?.title : '',
    agenda: editMode ? task?.agenda : '',
    attachments: '',
    due_date:
      editMode && task?.due_date ? moment(task?.due_date).toDate() : null,
    priority: editMode ? task?.priority : '',
    board_id: editMode ? board?._id : '',
    status: editMode ? task?.status?._id : '',
    assign_to: '',
    comment: '',
    recurrence_pattern: task?.recurrence_pattern
      ? task?.recurrence_pattern
      : '',
    weekly_recurrence_days: task?.weekly_recurrence_days
      ? task?.weekly_recurrence_days
      : [],
    recurrence_end_date: task?.recurrence_end_date
      ? moment(task?.recurrence_end_date).toDate()
      : null,
    recurrence_start_date: task?.recurrence_start_date
      ? moment(task?.recurrence_start_date).toDate()
      : null,
    recurrence_start_at_time: task?.recurrence_time
      ? parseTimeToDate(task?.recurrence_time)
      : null,

    recurrence_task_due_date: isEachMonth
      ? task?.recurrence_task_due_date?.length
        ? task.recurrence_task_due_date.map((item: any) => ({
            month: item?.month,
            year: item?.year,
            date: item?.date ? moment(item.date).toDate() : null, // Convert date
          }))
        : []
      : isEachWeek
        ? task?.recurrence_task_due_date?.length
          ? task?.recurrence_task_due_date.map((item: any) => ({
              month: item?.month,
              year: item?.year,
              date: item?.date ? moment(item.date).toDate() : null, // Convert date
              day: item?.day,
            }))
          : []
        : [],

    recurrence_default_due_date: task?.recurrence_default_due_date
      ? {
          label: String(task?.recurrence_default_due_date),
          value: String(task?.recurrence_default_due_date),
        }
      : { label: '1', value: '1' },

    due_date_duration: task?.due_date_duration
      ? String(task?.due_date_duration)
      : '', // Default as string

    // recurrence_interval:
    //   task?.recurrence_interval > -1 ? String(task?.recurrence_interval) : '',
    // alert_time_unit: meetingDataById?.alert_time_unit ? meetingDataById?.alert_time_unit : {label: '', value: ''},
    monthly_recurrence_day_of_month: task?.monthly_recurrence_day_of_month
      ? {
          label: String(task?.monthly_recurrence_day_of_month),
          value: String(task?.monthly_recurrence_day_of_month),
        }
      : { label: '1', value: '1' },
    reminder: task?.reminder_option ? task?.reminder_option : 'no_notify',
    repeat: task?.repeat ? task?.repeat : 'no_repetition',
    reminder_user: task?.reminder_user || [],
    reminder_date: task?.reminder_date
      ? moment(task?.reminder_date).toDate()
      : null,
    // customValue:
    //   task?.custom_reminder_value > -1
    //     ? String(task?.custom_reminder_value)
    //     : '30',
    // customUnit: task?.custom_reminder_unit
    //   ? {
    //       label: customData.find(
    //         (item) => item.value === task?.custom_reminder_unit
    //       )?.label,
    //       value: String(task?.custom_reminder_unit),
    //     }
    //   : { value: 'minutes', label: 'Minutes before' },
  };
  useEffect(() => {
    if (
      monthlyDates?.length > 0 &&
      (task?.recurrence_pattern === 'monthly' ||
        selectedRecurringOption?.value === 'monthly')
    ) {
      const updatedDates = monthlyDates?.map((item: any) => {
        if (task?.recurrence_pattern !== 'monthly') {
          isFirstRender.current = false;
        }
        const array = isFirstRender.current
          ? task?.recurrence_task_due_date
          : getValueReference?.current('recurrence_task_due_date');
        const existingEntry = array?.find(
          (d: any) => d.month === item?.month && d.year === item?.year
        );

        // Compare selectedDate with task?.recurrence_start_date
        const isSameStartDate =
          selectedDate &&
          task?.recurrence_start_date &&
          moment(selectedDate).isSame(
            moment(task?.recurrence_start_date),
            'day'
          );

        return {
          month: item?.month,
          year: item?.year,
          date:
            isSameStartDate && existingEntry?.date
              ? new Date(existingEntry.date)
              : null, // Reset only if start date changes
        };
      });

      setValueReference.current('recurrence_task_due_date', updatedDates);
      isFirstRender.current = false;
    }
  }, [
    monthlyDates,
    task?.recurrence_task_due_date,
    selectedDate,
    setValueReference,
  ]);

  const [selectedRecipients, setSelectedRecipients] = useState<any>([]);

  useEffect(() => {
    if (task?.reminder_user && assigneeOptions.length > 0) {
      const mappedOptions = mapReminderUserIdsToOptions(task.reminder_user);
      setSelectedRecipients(mappedOptions);
    }
    // We intentionally want to run this when task.reminder_user or assigneeOptions changes.
  }, [task, assigneeOptions, mapReminderUserIdsToOptions]);
  // Auto increase agenda input field
  useEffect(() => {
    if (agendaInputRef.current) {
      agendaInputRef.current.style.height = 'auto';
      agendaInputRef.current.style.overflowY = 'hidden';
      agendaInputRef.current.style.height = `${agendaInputRef.current.scrollHeight}px`;
    }
  }, [agendaValue, task?.agenda]);

  // status dropdown options - dynamic - not included completed and archived
  const statusOptions: Record<string, any>[] =
    sections && sections?.length > 0
      ? sections
          ?.filter(
            (section: Record<string, any>) =>
              section?.key !== 'completed' && section?.key !== 'archived'
          ) // Filter out 'completed' and 'archived' sections
          ?.map((section: Record<string, any>) => {
            return {
              value: section?._id,
              name: capitalizeFirstLetter(section?.section_name),
              label: (
                <div
                  className="flex items-center  gap-2 rounded-3xl px-[15px] py-[8px] text-xs sm:text-sm"
                  style={{ backgroundColor: section?.color }}
                >
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: section?.test_color }}
                  />
                  <div
                    title={section?.section_name} // Tooltip to show full text
                    className="w-[130px] truncate font-medium"
                    style={{ color: section?.test_color }}
                  >
                    {section?.section_name.length > 20
                      ? `${section?.section_name.slice(0, 18)}...`
                      : section?.section_name}
                  </div>
                </div>
              ),
              section: section,
              key: section?.key,
            };
          })
      : [];
  // All status options

  const allStatusOptions: Record<string, any>[] =
    sections && sections?.length > 0
      ? sections?.map((section: Record<string, any>) => {
          return {
            value: section?._id,
            name: capitalizeFirstLetter(section?.section_name),
            label: (
              <div
                className="flex items-center gap-2 rounded-3xl px-[20px] py-[8px] text-xs sm:text-sm"
                style={{ backgroundColor: section?.color }}
              >
                <div
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: section?.test_color }}
                />
                <div
                  className="font-medium"
                  style={{ color: section?.test_color }}
                >
                  {section?.section_name}
                </div>
              </div>
            ),
            section: section,
            key: section?.key,
          };
        })
      : [];

  // If we create a task from particular section in kanban view than i have to select by default column option

  useEffect(() => {
    // in edit mode we have to select bydefault status and priority of particular task and mark complete status
    if (editMode) {
      const assignToMembers =
        (task?.assign_to &&
          task?.assign_to?.length > 0 &&
          task?.assign_to?.map((member: any) => {
            return member?._id;
          })) ||
        [];
      setSelectedMembers(assignToMembers);

      assignToMembers &&
        assignToMembers?.length > 0 &&
        setCanLeaveTask(
          assignToMembers?.includes(signIn?.user?.data?.user?._id)
        );

      if (task?.status) {
        const defaultOption =
          allStatusOptions.find(
            (option: any) => option.value === task?.status?._id
          ) || null;
        setSelectedStatus(defaultOption || allStatusOptions[0]);
      }

      if (task?.priority) {
        const defaultOption =
          priorityOptions.find(
            (option: any) => option.value === task?.priority
          ) || {};
        setSelectedPriority(defaultOption || priorityOptions[0]);
      }

      // set mark_as_done value
      task?.mark_as_done && setTaskDone(task?.mark_as_done);

      // set attchments value need to change
      // let updatedAttachmentArray: Record<string, any>[] = task?.attachments && task?.attachments?.length > 0 ? task?.attachments?.map((file: any) => {
      //     return { preview: file }
      // }) : [];

      // task?.attachments && task?.attachments?.length > 0 && setPreviewImage(updatedAttachmentArray)
      task?.attachments &&
        task?.attachments?.length > 0 &&
        setPreviewImage(task?.attachments);
    }
  }, [task]);

  const validateCustomReminder = (customValue: any, customUnit: any) => {
    const dueDate = setWatchReference.current('due_date');
    if (dueDate) {
      const dueMoment = moment(dueDate);
      let reminderTime: moment.Moment | null = null;

      if (customValue && customUnit?.value) {
        reminderTime = dueMoment.subtract(customValue, customUnit.value);
      }

      if (
        selectedMembers?.length > 0 &&
        reminderTime &&
        reminderTime.isBefore(moment())
      ) {
        setErrorReference.current('reminder', {
          type: 'manual',
          message: 'Reminder time cannot be in the past',
        });
      } else {
        setClearErrorReference.current('reminder');
      }
    }
  };

  useEffect(() => {
    // in create mode we have to select bydefault status option as pendding and priority option as low
    if (!editMode) {
      if (column) {
        const defaultSelectedOption: any =
          (statusOptions &&
            statusOptions?.length > 0 &&
            statusOptions?.find(
              (option: any) => option.value === column?._id
            )) ||
          {};

        // setting value in form state
        defaultSelectedOption
          ? setSelectedStatus(defaultSelectedOption)
          : setSelectedStatus(statusOptions?.[0]);
        setValueReference.current(
          'status',
          defaultSelectedOption
            ? defaultSelectedOption?.value
            : statusOptions[0]?.value,
          { shouldValidate: true }
        );
      } else {
        const defaultPendingOption: any =
          (statusOptions &&
            statusOptions?.length > 0 &&
            statusOptions?.find((option: any) => option?.key === 'pending')) ||
          {};

        // setting value in form state
        defaultPendingOption && Object?.keys(defaultPendingOption)?.length > 0
          ? setSelectedStatus(defaultPendingOption)
          : statusOptions &&
            statusOptions?.length > 0 &&
            setSelectedStatus(statusOptions?.[0] ?? {});
        setValueReference.current(
          'status',
          defaultPendingOption && Object?.keys(defaultPendingOption)?.length > 0
            ? defaultPendingOption?.value
            : statusOptions?.[0]?.value ?? ''
        );
      }
      setSelectedPriority(priorityOptions[0]);
      setValueReference.current('priority', priorityOptions[0]?.value, {
        shouldValidate: true,
      });
    }
  }, []);

  useEffect(() => {
    setIsDisable(
      task?.mark_as_done ||
        (['team_client', 'team_agency', 'client'].includes(signIn?.role) &&
          !(
            editMode &&
            checkPermission('projects', 'tasks', 'update', signIn?.permission)
          ))
    );
  }, [task?.mark_as_done, signIn, editMode]);

  // handle remove member

  const handleRemoveMember = (userId: string) => {
    let removedMemberFiltered =
      (selectedMembers &&
        selectedMembers?.length > 0 &&
        selectedMembers?.filter((member: any, index: number) => {
          if (member !== userId) {
            return member;
          }
        })) ||
      [];

    setSelectedMembers([...removedMemberFiltered]);
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    // Generate preview URLs for valid files
    // const previewURLs = acceptedFiles.map((file: any) => URL.createObjectURL(file));

    const newFiles = [
      ...acceptedFiles.map((file: any) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      ),
    ];

    // Combine previous files with the new files
    const previewURLs =
      previewImage && previewImage !== null
        ? [...previewImage, ...newFiles]
        : [...newFiles];

    // Set the combined list of files
    setValueReference.current('attachments', previewURLs, {
      shouldValidate: true,
    });
    setPreviewImage(previewURLs);

    // // const file = URL.createObjectURL(acceptedFiles[0])
    // // setValue("attachments", acceptedFiles[0])
    // setValueReference.current('attachments', previewURLs)

    // setPreviewImage(previewURLs)
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: {
      // 1. Documents
      'application/msword': ['.doc', '.docx'],
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt', '.log', '.ini'], // Combined duplicates for text/plain
      'application/rtf': ['.rtf'],
      'application/vnd.oasis.opendocument.text': ['.odt'],
      'application/epub+zip': ['.epub'],

      // 2. Spreadsheets
      'application/vnd.ms-excel': ['.xls', '.xlsx'],
      'text/csv': ['.csv'], // Use only one key for CSV
      'application/vnd.oasis.opendocument.spreadsheet': ['.ods'],

      // 3. Presentations
      'application/vnd.ms-powerpoint': ['.ppt', '.pptx'],
      'application/vnd.oasis.opendocument.presentation': ['.odp'],
      'application/x-iwork-keynote-sffkey': ['.key'],

      // 4. Images
      'image/*': [
        '.jpeg',
        '.jpg',
        '.png',
        '.gif',
        '.bmp',
        '.tiff',
        '.svg',
        '.webp',
      ],

      // 5. Videos
      'video/*': ['.mp4', '.avi', '.mov', '.wmv', '.mkv', '.flv'],

      // 6. Audio
      'audio/*': ['.mp3', '.wav', '.aac', '.ogg', '.flac'],

      // 7. Code/Programming
      'application/javascript': ['.js'],
      'application/json': ['.json'],
      'application/xml': ['.xml'],
      'text/html': ['.html', '.htm'],
      'text/css': ['.css'],
      'text/yaml': ['.yaml'],
      'application/sql': ['.sql'],
      'text/markdown': ['.md'],
      'text/x-python': ['.py'],
      'text/x-java-source': ['.java'],
      'text/x-c': ['.c', '.cpp'],

      // 8. Design
      'image/vnd.adobe.photoshop': ['.psd'],
      'application/postscript': ['.ai', '.eps'],
      'application/vnd.adobe.xd': ['.xd'],
      'application/figma': ['.fig'],
      'application/sketch': ['.sketch'],
      'application/x-indesign': ['.indd'],

      // 9. Data/Database
      'application/vnd.sqlite3': ['.sqlite'],
      'application/octet-stream': ['.db'],

      // 10. Compressed Files
      'application/zip': ['.zip', '.rar', '.7z', '.tar.gz', '.iso'],

      // 11. Miscellaneous
      'text/calendar': ['.ics'],
      'application/vnd.android.package-archive': ['.apk'],
      'application/x-apple-diskimage': ['.dmg'],
    },
    // maxSize: 200 * 1024 * 1024, // Maximum file size of 200MB
    multiple: true,
    noClick: true,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps } = useDropzone(dropzoneOptions);

  const onSubmit: SubmitHandler<TaskFormSchema> = (data) => {
    if (commentAttachementInvalid) {
      return;
    }

    const dueDate = setWatchReference.current('due_date');
    const selectedReminderValue = data?.reminder;

    if (selectedReminderValue) {
      const dueMoment = moment(dueDate);
      let reminderTime: moment.Moment | null = null;

      // Determine reminder time based on selected reminder
      if (selectedReminderValue === '10_min_before') {
        reminderTime = dueMoment.subtract(10, 'minutes');
      } else if (selectedReminderValue === '30_min_before') {
        reminderTime = dueMoment.subtract(30, 'minutes');
      } else if (selectedReminderValue === '1_hour_before') {
        reminderTime = dueMoment.subtract(1, 'hour');
      } else if (selectedReminderValue === '1_day_before') {
        reminderTime = dueMoment.subtract(1, 'day');
      } else if (selectedReminderValue === '2_day_before') {
        reminderTime = dueMoment.subtract(2, 'day');
      } else if (selectedReminderValue === '3_day_before') {
        reminderTime = dueMoment.subtract(3, 'day');
      } else if (selectedReminderValue === '1_week_before') {
        reminderTime = dueMoment.subtract(1, 'week');
      } else if (selectedReminderValue === '2_week_before') {
        reminderTime = dueMoment.subtract(2, 'week');
      } else if (selectedReminderValue === 'custom') {
        const reminderDate = data?.reminder_date;
        if (reminderDate) {
          reminderTime = moment(reminderDate);
        }
      }

      // Check if the reminder time is in the past
      if (
        selectedMembers?.length > 0 &&
        reminderTime &&
        reminderTime.isBefore(moment())
      ) {
        // Set the error for reminder if the time is in the past
        setErrorReference.current('reminder', {
          type: 'manual',
          message: 'Reminder time cannot be in the past',
        });
        return; // Stop form submission if the error is triggered
      }
    }

    const formData: Record<string, any> = {
      title: data?.title ?? '',
      agenda: data?.agenda ?? '',
      priority: data?.priority ?? '',
      board_id: board?._id ?? '',
      status: data?.status ?? '',
      due_date: String(data?.due_date), // Convert due_date to string
      comment: data?.comment ?? '',
      custom_fields: JSON.stringify(customFieldData),
      // tags: tags,
    };
    const myForm = new FormData();

    if (
      data.due_date !== null &&
      selectedMembers?.length > 0
      //  &&
      // new Date(data?.due_date).getTime() > new Date().getTime()
    ) {
      formData.reminder_option = data?.reminder ? data?.reminder : null;
      formData.repeat = data?.repeat ? data?.repeat : null;
      if (Array.isArray(data?.reminder_user)) {
        data?.reminder_user?.forEach((userId: string) => {
          myForm.append('reminder_user', userId);
        });
      }

      if (data?.reminder === 'custom') {
        formData.reminder_date = data?.reminder_date
          ? String(data?.reminder_date)
          : null;
      }
    }

    if (!task?.parent_task) {
      formData.isRecurring = true;
    }

    // Add recurrence-related fields only if task?.parent_task is not present
    if (!task?.parent_task && isRecurring) {
      formData.recurrence_pattern = data?.recurrence_pattern
        ? data?.recurrence_pattern
        : null;
      formData.recurrence_end_date = data?.recurrence_end_date
        ? moment(data?.recurrence_end_date).format('DD-MM-YYYY')
        : null;
      if (
        !signIn?.userProfile?.agency_setting ||
        signIn?.userProfile?.agency_setting === null ||
        signIn?.userProfile?.agency_setting?.is_custom_recurring === false
      ) {
        formData.due_date_duration = data?.due_date_duration
          ? Number(data?.due_date_duration)
          : '';
      }

      // formData.recurrence_interval = data?.recurrence_interval
      //   ? Number(data?.recurrence_interval)
      //   : null;
      formData.recurrence_start_date = data?.recurrence_start_date
        ? moment(data?.recurrence_start_date).format('DD-MM-YYYY')
        : null;
      formData.recurrence_time = data?.recurrence_start_at_time
        ? moment(data?.recurrence_start_at_time).format('HH:mm')
        : null;

      if (
        data?.recurrence_pattern === 'weekly' &&
        Array.isArray(data?.weekly_recurrence_days)
      ) {
        data.weekly_recurrence_days?.forEach((day: string) => {
          myForm.append('weekly_recurrence_days', day);
        });
      }

      if (data?.recurrence_pattern === 'monthly') {
        formData.monthly_recurrence_day_of_month =
          data?.monthly_recurrence_day_of_month
            ? Number(data?.monthly_recurrence_day_of_month.value)
            : null;
      }

      if (
        signIn?.userProfile?.agency_setting?.is_custom_recurring &&
        data?.recurrence_pattern === 'monthly' &&
        !isEachMonth
      ) {
        formData.recurrence_default_due_date = data?.recurrence_default_due_date
          ? Number(data?.recurrence_default_due_date.value)
          : null;
      }

      if (
        signIn?.userProfile?.agency_setting?.is_custom_recurring &&
        data?.recurrence_pattern === 'monthly' &&
        isEachMonth
      ) {
        const formattedRecurrenceDates =
          Array?.isArray(data?.recurrence_task_due_date) && isEachMonth
            ? data?.recurrence_task_due_date?.map((item: any) => ({
                month: item?.month,
                year: item?.year,
                date: item?.date ? String(item?.date) : '',
              }))
            : [];

        if (formattedRecurrenceDates.length > 0) {
          formattedRecurrenceDates.forEach((item: any, index: any) => {
            myForm.append(
              `recurrence_task_due_date[${index}][date]`,
              item?.date ?? ''
            );
            myForm.append(
              `recurrence_task_due_date[${index}][year]`,
              item?.year
            );
            myForm.append(
              `recurrence_task_due_date[${index}][month]`,
              item?.month
            );
          });
        }
      }
      if (
        signIn?.userProfile?.agency_setting?.is_custom_recurring &&
        data?.recurrence_pattern === 'weekly' &&
        isEachWeek
      ) {
        const formattedRecurrenceDates =
          Array.isArray(data?.recurrence_task_due_date) && isEachWeek
            ? data?.recurrence_task_due_date
            : [];

        if (formattedRecurrenceDates?.length > 0) {
          formattedRecurrenceDates.forEach((item: any, index: any) => {
            myForm.append(
              `recurrence_task_due_date[${index}][date]`,
              item?.date ?? ''
            );
            myForm.append(
              `recurrence_task_due_date[${index}][year]`,
              item?.year
            );
            myForm.append(
              `recurrence_task_due_date[${index}][month]`,
              item?.month
            );
            myForm.append(`recurrence_task_due_date[${index}][day]`, item?.day);
          });
        }
      }
    }
    // remove key if its null undefined or ""
    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(([_, value]) => {
        if (_ === 'agenda') {
          return value !== undefined;
        }
        return value !== undefined && value !== '';
      })
    );

    tags.forEach((tag) => {
      myForm.append('tags', tag?.tag_name);
    });
    // Add data from the 'formData' object to the FormData
    for (const key in filteredFormData) {
      if (Object.prototype.hasOwnProperty.call(filteredFormData, key)) {
        const value = filteredFormData[key];
        myForm.append(key, value);
      }
    }

    // Mentions user data
    const mentionedUsers =
      mentionUser?.length > 0
        ? Array.from(new Set(mentionUser.map((item: any) => item.id)))
        : [];

    myForm.append('mentioned_users', JSON.stringify(mentionedUsers));

    editMode &&
      task?.parent_task &&
      myForm.append('parent_task', task?.parent_task);

    // add members id in form data [id, id] format
    selectedMembers &&
      selectedMembers?.length > 0 &&
      myForm.append('assign_to', JSON.stringify(selectedMembers));

    // add attachments files in form data

    if (!editMode) {
      previewImage?.length > 0 &&
        previewImage?.map((file: any) => {
          myForm.append('attachments', file);
        });
    } else {
      previewImage?.length > 0 &&
        previewImage?.map((file: any) => {
          if (!file?.preview?.startsWith('blob')) {
            myForm.append('attachments', JSON.stringify(file));
          } else {
            myForm.append('attachments', file);
          }
        });
    }

    // add id of task in form data in edit mode
    if (editMode) {
      myForm.append('_id', task?._id);
    }

    // create a object of selected assignees to update in card of kanban

    const updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];

    if (!editMode) {
      dispatch(postAddTask(myForm)).then((result: any) => {
        if (postAddTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            if (task?.parent_task) {
              openTaskModal({ ...task, _id: task?.parent_task }); // Open modal for parent task
            } else {
              onClose();
            }

            if (!gridView) {
              setTaskFilterOptionValue('');
              setTaskFilterOptionName('All tasks');
              setAssigneeFilter('');
              dispatch(
                getAllTask({
                  page: 1,
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              createTask({
                ...result?.payload?.data,
                assign_to: updatedAssigneeObject,
                attachment_count: result?.payload?.data?.attachments?.length,
                comments_count: result?.payload?.data?.comment,
              });
            }
          }
        }
      });
    } else {
      dispatch(patchEditTask(myForm)).then((result: any) => {
        if (patchEditTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            if (task?.parent_task) {
              openTaskModal({ ...task, _id: task?.parent_task }); // Open modal for parent task
            } else {
              onClose();
            }

            if (!gridView) {
              dispatch(
                getAllTask({
                  ...paginationParams,
                  board_id: boardId,
                  pagination: true,
                })
              );
            } else {
              updateTask(
                task?._id,
                'task_update',
                {
                  oldTaskStatus: task?.status,
                  updated_task: {
                    ...result?.payload?.data,
                    assign_to: updatedAssigneeObject,
                    attachment_count:
                      result?.payload?.data?.attachments?.length,
                    comments_count: result?.payload?.data?.comment,
                    subtask_count: task?.sub_tasks?.length,
                    reminder_option: result?.payload?.data?.reminder_option,
                    custom_reminder_value:
                      result?.payload?.data?.custom_reminder_value,
                    custom_reminder_unit:
                      result?.payload?.data?.custom_reminder_unit,
                  },
                },
                oldTasks,
                oldTasksSections
              );
            }
          }
        }
      });
    }
  };

  const handleMarkSubtaskCompleteClick = (subtask: any) => {
    setTaskDone((prev) => !prev);

    const defaultCompleteOption: any =
      (sections &&
        sections?.length > 0 &&
        sections?.filter((option: any) => {
          if (option?.key === 'completed') {
            return option;
          }
        })) ||
      [];

    editMode &&
      defaultCompleteOption?.length > 0 &&
      dispatch(
        putTaskKanbanStatusChange({
          _id: subtask?._id,
          status: defaultCompleteOption[0]?._id,
        })
      ).then((result: any) => {
        if (putTaskKanbanStatusChange.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            const updatedSubtask = {
              ...subtask,
              status: defaultCompleteOption[0], // Update status in state
              mark_as_done: true,
            };
            // onClose();
            if (!gridView) {
              setAllSubtask((prevSubtasks: any) =>
                prevSubtasks.map((task: any) =>
                  task._id === subtask?._id ? updatedSubtask : task
                )
              );
              // dispatch(
              //   getAllTask({
              //     ...paginationParams,
              //     board_id: boardId,
              //     pagination: true,
              //   })
              // );
            } else {
              setAllSubtask((prevSubtasks: any) =>
                prevSubtasks.map((task: any) =>
                  task._id === subtask?._id ? updatedSubtask : task
                )
              );

              updateTask(
                subtask?._id,
                'complete_status_update',
                {
                  mark_as_done: true,
                  mark_as_archived: false,
                  before_status: subtask?.status,
                  after_status: updatedSubtask,
                },
                oldTasks,
                oldTasksSections
              );
            }
          }
        }
      });
  };

  const handleMarkSubtaskArchive = (subtask: any) => {
    const defaultCompleteOption: any =
      (sections &&
        sections?.length > 0 &&
        sections?.filter((option: any) => {
          if (option?.key === 'archived') {
            return option;
          }
        })) ||
      [];

    editMode &&
      defaultCompleteOption?.length > 0 &&
      dispatch(
        putTaskKanbanStatusChange({
          _id: subtask?._id,
          status: defaultCompleteOption[0]?._id,
        })
      ).then((result: any) => {
        if (putTaskKanbanStatusChange.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            const updatedSubtask = {
              ...subtask,
              status: defaultCompleteOption[0], // Update status in state
              mark_as_archived: true,
              mark_as_done: true,
            };
            // onClose();
            if (!gridView) {
              setAllSubtask((prevSubtasks: any) =>
                prevSubtasks.map((task: any) =>
                  task._id === subtask?._id ? updatedSubtask : task
                )
              );
              // dispatch(
              //   getAllTask({
              //     ...paginationParams,
              //     board_id: boardId,
              //     pagination: true,
              //   })
              // );
            } else {
              setAllSubtask((prevSubtasks: any) =>
                prevSubtasks.map((task: any) =>
                  task._id === subtask?._id ? updatedSubtask : task
                )
              );

              // updateTask(
              //   rowData?._id,
              //   'status_update',
              //   {
              //     mark_as_done: true,
              //     mark_as_archived: true,
              //     before_status: rowData?.status,
              //     after_status: defaultCompleteOption[0],
              //   },
              //   oldTasks,
              //   oldTasksSections
              // );
            }
          }
        }
      });
  };

  //subtask duplicate
  const onSubTaskDuplicateTask: SubmitHandler<DuplicateTaskSchema> = (data) => {
    const formData = new FormData();

    // Append fields to the FormData object
    formData.append('title', data.title);
    if (data?.agenda) {
      formData.append('agenda', data.agenda);
    } else {
      formData.append('agenda', '');
    }
    formData.append('priority', data.priority);
    formData.append('board_id', data.board_id);
    formData.append('status', data.status._id);
    formData.append('duplicated_from', data._id);
    formData.append('custom_fields', JSON.stringify(data?.custom_fields));

    if (editMode && data?.parent_task) {
      formData.append('parent_task', data?.parent_task);
    }

    if (data?.tags && data?.tags?.length > 0) {
      data?.tags?.forEach((tag: any) => {
        formData.append('tags', tag?.tag_name);
      });
    }

    // Convert due_date to string format
    if (data.due_date) {
      const dueDate = new Date(data.due_date);
      formData.append('due_date', dueDate.toString());
    } else {
      formData.append('due_date', 'null'); // Send 'null' as a string
    }

    // Extract only the user IDs for assign_to and convert to JSON string
    if (data.assign_to && data.assign_to?.length > 0) {
      const assignToIds = data.assign_to.map((assignee: any) => assignee._id);
      formData.append('assign_to', JSON.stringify(assignToIds));
    }

    if (data?.attachments && data?.attachments?.length > 0) {
      formData.append('attachments', JSON.stringify(data?.attachments));
    }

    let updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];

    dispatch(duplicateAddTask(formData)).then((result: any) => {
      if (duplicateAddTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          setAllSubtask((prevSubtasks: any) => [
            ...prevSubtasks,
            {
              ...result?.payload?.data,
              parent_task: result?.payload?.data?.parent_task?._id, // Correctly adding parent_task inside the object
            },
          ]);

          if (!gridView) {
            dispatch(
              getAllTask({
                page: 1,
                sort_field: 'createdAt',
                sort_order: 'desc',
                board_id: boardId,
                pagination: true,
              })
            );
          } else {
            updateTask(
              rowData?._id,
              'subtask_count',
              { subtask: rowData },
              oldTasks,
              oldTasksSections
            );
          }
          dispatch(taskTimeTrackedHistory(data?.parent_task));
          dispatch(getAllCommentsById({ task_id: data?.parent_task }));
        }
      }
    });
  };

  const onDuplicateTask: SubmitHandler<DuplicateTaskSchema> = (data) => {
    const formData = new FormData();

    // Append fields to the FormData object
    formData.append('title', data.title);
    if (data?.agenda) {
      formData.append('agenda', data.agenda);
    } else {
      formData.append('agenda', '');
    }
    formData.append('priority', data.priority);
    formData.append('board_id', data.board_id);
    formData.append('status', data.status._id);
    formData.append('duplicated_from', data._id);
    formData.append('custom_fields', JSON.stringify(data?.custom_fields));
    if (data?.recurrence_pattern && data?.recurrence_pattern !== '') {
      formData.append('recurrence_pattern', data?.recurrence_pattern);
      formData.append(
        'recurrence_end_date',
        moment(data?.recurrence_end_date).format('DD-MM-YYYY')
      );
      formData.append('recurrence_interval', data?.recurrence_interval);

      if (data?.recurrence_pattern === 'weekly') {
        formData.append('weekly_recurrence_days', data?.weekly_recurrence_days);
      }

      if (data?.recurrence_pattern === 'monthly') {
        formData.append(
          'monthly_recurrence_day_of_month',
          data?.monthly_recurrence_day_of_month
        );
      }
    }

    if (editMode && data?.parent_task) {
      formData.append('parent_task', data?.parent_task);
    }

    if (data?.tags && data?.tags?.length > 0) {
      data?.tags?.forEach((tag: any) => {
        formData.append('tags', tag?.tag_name);
      });
    }

    // Convert due_date to string format
    if (data.due_date) {
      const dueDate = new Date(data.due_date);
      formData.append('due_date', dueDate.toString());
    } else {
      formData.append('due_date', 'null'); // Send 'null' as a string
    }

    // Extract only the user IDs for assign_to and convert to JSON string
    if (data.assign_to && data.assign_to?.length > 0) {
      const assignToIds = data.assign_to.map((assignee: any) => assignee._id);
      formData.append('assign_to', JSON.stringify(assignToIds));
    }

    if (data?.attachments && data?.attachments?.length > 0) {
      formData.append('attachments', JSON.stringify(data?.attachments));
    }

    let updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];
    dispatch(duplicateAddTask(formData)).then((result: any) => {
      if (duplicateAddTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          if (task?.parent_task) {
            openTaskModal({ ...task, _id: task?.parent_task }); // Open modal for parent task
          } else {
            onClose();
          }

          if (!gridView) {
            dispatch(
              getAllTask({
                page: 1,
                sort_field: 'createdAt',
                sort_order: 'desc',
                board_id: boardId,
                pagination: true,
              })
            );
          } else {
            createTask({
              ...result?.payload?.data,
              assign_to: updatedAssigneeObject,
              attachment_count: result?.payload?.data?.attachments?.length,
              comments_count: result?.payload?.data?.comment,
            });
          }
        }
      }
    });
  };

  // Bulk Download
  const downloadFiles = async (files: any, bulkDownload: boolean = false) => {
    try {
      bulkDownload && setBulkDownloadLoader(true);
      // Create an array of axios requests
      const filePromises = files.map((file: any) =>
        axios.get(file?.split(' ')[0], { responseType: 'blob' })
      );

      // Wait for all requests to complete
      const responses = await Promise.all(filePromises);

      responses.forEach((response, index) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.download = files[index]?.split(' ').slice(1).join(' ');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        if (index + 1 === files?.length) {
          bulkDownload && setBulkDownloadLoader(false);
        }
      });
    } catch (error) {
      bulkDownload && setBulkDownloadLoader(false);
      console.error('Error downloading files:', error);
    }
  };

  const ValueContainer = ({ children, ...props }: any) => {
    const selectedOptions = props.getValue();
    const hasSelections = selectedOptions.length > 0;

    // Determine the placeholder and truncate it if it’s too long during selected state
    let placeholder = props.selectProps.placeholder || 'Select';

    if (
      hasSelections &&
      placeholder === 'Select assignee' &&
      selectedOptions?.length > 0
    ) {
      // Truncate when displaying selected options count
      placeholder = `Select assignee`;
    } else if (hasSelections && placeholder.length > 15) {
      // Truncate if longer than 15 characters during selected state
      placeholder = `${placeholder.substring(0, 15)}...`;
    }

    return (
      <components.ValueContainer {...props}>
        <div className="flex items-center gap-2 whitespace-nowrap">
          {hasSelections ? (
            <div className="font-medium text-[#4a4a4a]">
              {placeholder}{' '}
              <span className="rounded-full bg-[#8c80d2] px-2 py-1 text-xs font-bold text-white">
                {selectedOptions.length.toString().padStart(2, '0')}
              </span>
            </div>
          ) : (
            <span className="text-[#4a4a4a]">{placeholder}</span>
          )}
          {React.cloneElement(children[1])}
        </div>
      </components.ValueContainer>
    );
  };

  const Option = (props: any) => {
    const { data, isSelected, selectOption, getValue } = props;
    const selectedValues = getValue().map((option: any) => option.value);
    const isAllSelected = selectedValues.length === assigneeOptions.length; // Check if all users are selected

    const handleChange = () => {
      if (data.value === allOption.value) {
        // If "Select All" is clicked, toggle selection
        if (isAllSelected) {
          selectOption([]); // Deselect all
        } else {
          selectOption(assigneeOptions); // Select all
        }
      } else {
        selectOption(data);
      }
    };

    return (
      <components.Option {...props}>
        <div
          className="flex cursor-pointer items-center gap-2"
          onClick={handleChange}
        >
          <Checkbox
            label={data.label}
            checked={
              data.value === allOption.value ? isAllSelected : isSelected
            }
            color="info"
            // variant="flat"
            inputClassName="checkbox-color"
            className=" cursor-pointer [&>label>span]:font-medium"
            labelClassName="text-1.20em md:text-1.20em lg:text-1.20em xl:text-1.20em text-gray-700 dark:text-gray-600 cursor-pointer"
          />
        </div>
      </components.Option>
    );
  };

  const handleKeyDateDown = (e: any) => {
    if (
      !/^[0-9]$/.test(e.key) && // Allow only numbers (0-9)
      e.key !== 'Backspace' && // Allow backspace
      e.key !== 'Delete' && // Allow delete
      e.key !== 'ArrowLeft' && // Allow left arrow
      e.key !== 'ArrowRight' && // Allow right arrow
      e.key !== 'Tab' // Allow tab
    ) {
      e.preventDefault();
    }
  };

  const MultiValue = (props: any) => (
    <components.MultiValue {...props}>
      <div className="flex items-center gap-2">
        {/* <img
              src={props.data.profile}
              alt={props.data.label}
              className="h-6 w-6 rounded-full"
            /> */}
        <span>{props.data.label}</span>
      </div>
    </components.MultiValue>
  );

  // check in comment attachement if any invalide file exits or not
  const checkCommentAttachement = (data: any) => {
    setCommentAttachementInvalid(false);

    if (data?.length > 0) {
      const fileSize = Object.values(data)?.map((file: any) =>
        getFileSize(file)
      );
      const inValidFile = fileSize?.filter(
        (fileInfo) => !checkValidFileSize(fileInfo, 200)
      );
      if (inValidFile?.length > 0) {
        setCommentAttachementInvalid(true);
      }
    }
  };

  useEffect(() => {
    if (task?.recurrence_start_date) {
      setSelectedDate(moment(task?.recurrence_start_date).toDate());
    }

    if (task?.recurrence_end_date) {
      setSelectedEndDate(moment(task?.recurrence_end_date).toDate());
    }
  }, [task]);

  const openTaskModal = (taskData: any) => {
    // closeModal(); // Close any existing modal first

    setTimeout(() => {
      openModal({
        view: (
          <EditTaskForm
            rowData={{ ...taskData }} // Ensure a fresh copy is passed
            editMode={true}
            updateTask={updateTask}
            createTask={createTask}
            onClose={closeModal}
          />
        ),
        customSize: '800px',
      });
      setCustomFieldData([]); // set custom field data to []
    }, 100); // Slight delay ensures modal resets completely
  };

  useEffect(() => {
    if (
      !defaultRecurrence ||
      Number(defaultRecurrence?.value) < recurrenceDueDay
    ) {
      setValueReference.current('recurrence_default_due_date', {
        label: String(recurrenceDueDay),
        value: String(recurrenceDueDay),
      });
    }
  }, [recurrenceDueDay, defaultRecurrence, setValueReference]);

  if (
    (Object.keys(task)?.length === 0 || taskData?.getTaskLoading) &&
    editMode
  ) {
    return (
      <div className="flex h-[670px] items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  } else {
    return (
      <div className="max-h-[670px]">
        {/* <div className="mb-3 flex items-center justify-end gap-3">
          {editMode &&
            !task?.mark_as_done &&
            (['agency'].includes(signIn?.role) ||
              (['team_client', 'team_agency'].includes(signIn?.role) &&
                checkPermission(
                  'projects',
                  'tasks',
                  'delete',
                  signIn?.permission
                ))) && (
              <Tooltip
                size="sm"
                content={() => 'Delete Task'}
                placement="bottom"
                color="invert"
                className="z-100"
              >
                <button
                  className="text-red-500 hover:text-red-700"
                  type="button"
                  onClick={() => {
                    setShowDeleteConfirmationPopper(true);
                  }}
                  disabled={task?.mark_as_archived}
                  title={'Delete Task'}
                >
                  <FiTrash size={20} />
                </button>
              </Tooltip>
            )}

          {editMode &&
            !task?.mark_as_done &&
            //  (['agency', 'client'].includes(signIn?.role)
            (['agency'].includes(signIn?.role) ||
              (['team_client', 'team_agency'].includes(signIn?.role) &&
                checkPermission(
                  'projects',
                  'tasks',
                  'create',
                  signIn?.permission
                ))) && (
              <Tooltip
                size="sm"
                content={() => 'Duplicate Task'}
                placement="bottom"
                color="invert"
              >
                <button
                  className={`poppins_font_number flex cursor-pointer items-center justify-start gap-2 text-[14px] font-bold text-[#120425] ${
                    duplicateTaskLoading ? 'cursor-not-allowed opacity-50' : ''
                  }`}
                  type="button"
                  title={'Duplicate Task'}
                  onClick={() => {
                    onDuplicateTask(task);
                  }}
                  disabled={duplicateTaskLoading}
                >
                  <IoDuplicateOutline className="text-[#8C80D2]" size={20} />
                </button>
              </Tooltip>
            )}

          <ActionIcon
            size="sm"
            variant="text"
            onClick={closeModal}
            className="me-4 p-0 text-[#9BA1B9] hover:!text-gray-900"
          >
            <PiXBold className="h-[50px] w-[50px] " />
          </ActionIcon>
        </div> */}
        <Form<TaskFormSchema>
          validationSchema={taskFormSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'all',
            defaultValues: initialValues,
          }}
          className="text-[14px] text-[#9BA1B9] [&_label]:font-medium"
        >
          {({
            register,
            control,
            formState: { errors },
            setValue,
            setError,
            getValues,
            watch,
            clearErrors,
          }) => {
            setValueReference.current = setValue;
            getValueReference.current = getValues;
            (setErrorReference.current = setError),
              (setWatchReference.current = watch);
            setClearErrorReference.current = clearErrors;
            return (
              <div className="p-2">
                <SimpleBar className="max-h-[650px]">
                  <div className="flex  flex-col gap-5 p-5">
                    <div className="flex flex-col items-center justify-between gap-5 sm:flex-row">
                      <div className="flex w-full items-center justify-between gap-5 sm:w-auto sm:justify-normal">
                        {task?.parent_task && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();

                              openTaskModal({
                                ...taskData?.task?.activity,
                                _id: taskData?.task?.activity?.parent_task,
                              }); // Pass parent task
                            }}
                          >
                            <Image
                              src={backRouteIcon}
                              alt="back icon"
                              className="h-6 w-6"
                            />
                          </button>
                        )}
                        <Text className="text-[20px] font-bold text-[#141414]">
                          Edit Task
                        </Text>
                        <Controller
                          control={control}
                          name="board"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              variant="text"
                              value={{
                                value: board?._id,
                                label: capitalizeFirstLetter(
                                  board?.project_name
                                ),
                              }}
                              options={customData}
                              disabled
                              placeholder="Select Board"
                              prefix={<Text>Board :</Text>}
                              suffix={null}
                              className="rounded-lg border-[1.5px] border-[#DDDDDD] bg-[#F9FAFB] p-[1px] text-black "
                              selectClassName="truncate max-w-[250px] focus:outline-none focus:ring-0 focus:border-none disabled:!bg-transparent"
                            />
                          )}
                        />{' '}
                      </div>
                      <div className=" flex w-full items-center justify-between gap-5 sm:w-auto sm:justify-normal">
                        {!task?.parent_task && (
                          <Switch
                            className="[&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                            variant="active"
                            switchClassName={`${
                              isRecurring ? '!bg-[#362F78]' : '!bg-white'
                            }`}
                            handlerClassName={`${
                              isRecurring ? '!bg-white' : '!bg-[#362F78]'
                            }`}
                            label="Recurring Task"
                            name="recurringTask"
                            labelClassName="text-[#141414]"
                            labelPlacement="left"
                            disabled={task?.parent_task}
                            onChange={(e) => {
                              const checked = e?.target?.checked;
                              setIsRecurring(checked);
                              if (checked) {
                                setValue('recurrence_pattern', 'daily');
                                setSelectedRecurringOption({
                                  name: 'Daily',
                                  label: 'Daily',
                                  value: 'daily',
                                });
                              } else {
                                setValue('recurrence_pattern', '');
                                setSelectedRecurringOption({
                                  name: '',
                                  label: '',
                                  value: '',
                                });
                              }
                            }}
                            defaultChecked={isRecurring}
                          />
                        )}
                        <Popover
                          placement="bottom"
                          className="demo_test w-[490px] gap-2"
                          isOpen={isReminder}
                          showArrow={false}
                          content={() => (
                            <div className="flex flex-col items-start gap-5 p-3">
                              <Text className="text-[16px] font-semibold leading-[24px] text-[#141414]">
                                Create reminder
                              </Text>
                              {/* Recipients Field */}
                              <div className="flex flex-col gap-2">
                                {' '}
                                {/* Changed from flex-row to flex-col */}
                                <div className="flex items-center gap-2">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Recipients
                                  </span>
                                  <Controller
                                    control={control}
                                    name="reminder_user"
                                    render={({ field }) => (
                                      <ReactSelect
                                        {...field}
                                        styles={customStyles}
                                        options={optionsWithSelectAll}
                                        isMulti
                                        onChange={(selectedOptions: any) => {
                                          const isAllSelected =
                                            selectedOptions.length ===
                                            assigneeOptions.length + 1; // +1 for "Select All"

                                          if (isAllSelected) {
                                            setValue('reminder_user', []);
                                            setSelectedRecipients([]);
                                            clearErrors('reminder_user');
                                          } else if (
                                            selectedOptions.some(
                                              (option: any) =>
                                                option.value === allOption.value
                                            )
                                          ) {
                                            setValue(
                                              'reminder_user',
                                              assigneeOptions.map(
                                                (option) => option.value
                                              )
                                            );
                                            setSelectedRecipients(
                                              assigneeOptions
                                            );
                                            clearErrors('reminder_user');
                                          } else {
                                            setValue(
                                              'reminder_user',
                                              selectedOptions.map(
                                                (option: any) => option.value
                                              )
                                            );
                                            setSelectedRecipients(
                                              selectedOptions
                                            );
                                            clearErrors('reminder_user');
                                          }
                                        }}
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        components={{
                                          Option,
                                          MultiValue,
                                          ValueContainer,
                                        }}
                                        isClearable={false}
                                        value={selectedRecipients}
                                        className="poppins_font_number react-select-options task-assign w-auto"
                                        classNamePrefix="custom-multi-select"
                                        placeholder="Select assignee"
                                        isDisabled={isDisable}
                                      />
                                    )}
                                  />
                                </div>
                                {/* Ensure the error message is in a block below */}
                                {errors?.reminder_user && (
                                  <p className="text-sm text-red-600">
                                    {errors.reminder_user.message}
                                  </p>
                                )}
                              </div>
                              <div className="flex flex-row space-x-4">
                                <div className="flex flex-col items-start">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Reminder Time
                                  </span>
                                  <Select
                                    options={reminderOptions}
                                    onChange={(event: any) => {
                                      setSelectedReminder(event);
                                      if (event?.value !== '') {
                                        // Set reminder value
                                        setValue('reminder', event?.value);

                                        // If no recipients are selected and the reminder is not "no_notify", set an error
                                        if (
                                          selectedRecipients?.length === 0 &&
                                          event?.value !== 'no_notify'
                                        ) {
                                          setError('reminder_user', {
                                            type: 'manual',
                                            message:
                                              'At least one reminder user is required',
                                          });
                                        } else {
                                          clearErrors('reminder_user');
                                        }

                                        // Check if the reminder is valid based on the due_date
                                        const dueDate = watch('due_date');

                                        if (dueDate) {
                                          // Convert the due date to a moment object for easier manipulation
                                          const dueMoment = moment(dueDate);
                                          let reminderTime: moment.Moment | null =
                                            null;

                                          // Determine reminder time based on selected reminder
                                          if (
                                            event?.value === '10_min_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              10,
                                              'minutes'
                                            );
                                          } else if (
                                            event?.value === '30_min_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              30,
                                              'minutes'
                                            );
                                          } else if (
                                            event?.value === '1_hour_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              1,
                                              'hour'
                                            );
                                          } else if (
                                            event?.value === '1_day_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              1,
                                              'day'
                                            );
                                          } else if (
                                            event?.value === '2_day_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              2,
                                              'day'
                                            );
                                          } else if (
                                            event?.value === '3_day_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              3,
                                              'day'
                                            );
                                          } else if (
                                            event?.value === '1_week_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              1,
                                              'week'
                                            );
                                          } else if (
                                            event?.value === '2_week_before'
                                          ) {
                                            reminderTime = dueMoment.subtract(
                                              2,
                                              'week'
                                            );
                                          } else if (
                                            event?.value === 'custom'
                                          ) {
                                            const reminderDate: any =
                                              watch('reminder_date');

                                            if (reminderDate) {
                                              reminderTime =
                                                moment(reminderDate);
                                            }
                                          }

                                          // Validate reminder time
                                          if (
                                            reminderTime &&
                                            reminderTime.isBefore(moment())
                                          ) {
                                            // If the reminder time is in the past, set an error for reminder
                                            setError('reminder', {
                                              type: 'manual',
                                              message:
                                                'Reminder time cannot be in the past',
                                            });
                                          } else {
                                            // Clear the error if valid
                                            clearErrors('reminder');
                                          }
                                        }
                                      } else {
                                        setValue('reminder', '');
                                        clearErrors('reminder');
                                      }
                                    }}
                                    value={selectedReminder}
                                    className="mt-2 w-[200px]"
                                    selectClassName="!text-[#141414] poppins_font_number !bg-white"
                                    disabled={isDisable}
                                  />
                                  {errors?.reminder && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {errors.reminder.message}
                                    </p>
                                  )}
                                </div>
                                <div className="flex flex-col items-start">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Repeat
                                  </span>
                                  <Select
                                    options={RepeatOptions}
                                    onChange={(event: any) => {
                                      setSelectedRepetition(event);
                                      if (event?.value !== '') {
                                        // Set reminder value
                                        setValue('repeat', event?.value);
                                        if (
                                          selectedRecipients?.length === 0 &&
                                          event?.value !== 'no_repetition'
                                        ) {
                                          setError('reminder_user', {
                                            type: 'manual',
                                            message:
                                              'At least one reminder user is required',
                                          });
                                        } else {
                                          clearErrors('reminder_user');
                                        }
                                      }
                                    }}
                                    value={selectedRepetition}
                                    className="mt-2 w-[256px]"
                                    selectClassName="!text-[#141414] poppins_font_number !bg-white"
                                    disabled={isDisable}
                                  />
                                  {errors?.repeat && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {errors.repeat.message}
                                    </p>
                                  )}
                                </div>
                              </div>
                              {['custom'].includes(selectedReminder?.value) && (
                                <div className="task_form_date_picker_close_button_hide flex flex-col items-start">
                                  <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Select Reminder Date & Time
                                  </span>
                                  <Controller
                                    name="reminder_date"
                                    control={control}
                                    render={({
                                      field: { value, onChange },
                                    }) => (
                                      <DatePicker
                                        selected={value}
                                        placeholderText={'Select reminder date'}
                                        onChange={onChange}
                                        selectsStart
                                        startDate={value}
                                        minDate={new Date()}
                                        showTimeSelect
                                        isClearable={true}
                                        popperPlacement="bottom-end"
                                        className="mt-2 w-[489px] bg-[#F9FAFB]"
                                        dateFormat="MMMM d, yyyy h:mm aa"
                                        inputProps={{
                                          inputClassName: 'font-sans', // Custom class for the input
                                        }}
                                        disabled={isDisable}
                                      />
                                    )}
                                  />
                                  {errors?.reminder_date && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {errors.reminder_date.message}
                                    </p>
                                  )}
                                </div>
                              )}
                              <div className="flex w-[250px] gap-3">
                                <Button
                                  className="cursor-pointer rounded-lg border border-[#E5E7EB] bg-white text-sm text-[#141414]"
                                  size="DEFAULT"
                                  type="button"
                                  onClick={() => {
                                    setIsReminder(false);
                                    // setValue('reminder_date', null);
                                    // setValue('reminder', 'no_notify');
                                    // setSelectedReminder({
                                    //   value: 'no_notify',
                                    //   label: "Don't notify",
                                    //   name: "Don't notify",
                                    // });
                                    // setSelectedRepetition({
                                    //   value: 'no_repetition',
                                    //   label: 'No repetition',
                                    //   name: 'No repetition',
                                    // });
                                    // setValue('repeat', 'no_repetition');
                                    // setValue('reminder_user', []);
                                    // setSelectedRecipients([]);
                                    // clearErrors('reminder');
                                    // clearErrors('repeat');
                                    // clearErrors('reminder_user');
                                  }}
                                >
                                  Cancel
                                </Button>
                                <Button
                                  className="cursor-pointer rounded-lg bg-[#7667CF] text-[14px] font-normal leading-[19.6px] text-[#FFFFFF]"
                                  size="DEFAULT"
                                  type="button"
                                  onClick={() =>
                                    !errors.reminder &&
                                    !errors.repeat &&
                                    !errors.reminder_user &&
                                    setIsReminder(false)
                                  }
                                >
                                  Save reminder
                                </Button>
                              </div>
                            </div>
                          )}
                        >
                          <Switch
                            className="[&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                            variant="active"
                            switchClassName={`${
                              isReminder ? '!bg-[#362F78]' : '!bg-white'
                            }`}
                            handlerClassName={`${
                              isReminder ? '!bg-white' : '!bg-[#362F78]'
                            }`}
                            label="Task reminder"
                            name="taskReminder"
                            labelClassName="text-[#141414]"
                            labelPlacement="left"
                            onChange={(e) => setIsReminder(e?.target?.checked)}
                            checked={isReminder}
                            disabled={
                              selectedMembers?.length === 0 ||
                              watch('due_date') === null ||
                              watch('due_date') === undefined
                            }
                          />
                        </Popover>
                      </div>
                    </div>
                    <div>
                      <span className="text-[14px] font-medium text-[#141414]"></span>
                      <Textarea
                        textareaClassName="text-[#141414] poppins_font_number bg-[#F9FAFB]"
                        className="w-full"
                        onKeyDown={handleKeyDown}
                        placeholder="Add your task title here "
                        {...register('title')}
                        disabled={isDisable}
                        rows={2}
                        error={errors?.title?.message}
                      />
                    </div>
                    <div>
                      <div
                        className={`flex items-center justify-between rounded-lg border-[1px] bg-[#F9FAFB] p-3 text-[#141414] ${
                          isDisable ? 'cursor-not-allowed' : 'cursor-pointer'
                        }`}
                        onClick={() => {
                          isDisable ? null : setShowPopper(true);
                        }}
                      >
                        <div className="flex gap-3">
                          <FiUsers className="h-[20px] w-[20px]" />
                          <span className="rizzui-input-label block text-[14px] font-semibold text-[#4B5563]">
                            Add assignee(s)
                          </span>
                        </div>
                        <IoMdAdd className="h-[16px] w-[16px]" />
                      </div>
                    </div>
                    {signIn?.role !== 'team_client' &&
                      clientTeamAllOptions?.length > 0 &&
                      (() => {
                        // Filter selected members outside the JSX
                        const selectedMember: any =
                          clientTeamAllOptions?.filter(
                            (item) =>
                              selectedMembers?.includes(item?.user_id as never)
                          );
                        return (
                          selectedMember?.length > 0 && (
                            <SimpleBar
                              className={`${
                                selectedMember?.length > 3 ? 'max-h-40' : ''
                              } `}
                            >
                              <div className="rounded-lg border-[1px]">
                                {selectedMember?.map(
                                  (member: any, index: any) => (
                                    <div
                                      key={index}
                                      className={`flex items-center justify-between p-3 text-[#141414] ${
                                        selectedMember.length - 1 !== index &&
                                        'border-b-[1px]'
                                      }`}
                                    >
                                      <div className="flex items-center gap-3">
                                        <Avatar
                                          src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                          name={`${capitalizeFirstLetter(
                                            member?.first_name
                                          )} ${capitalizeFirstLetter(
                                            member?.last_name
                                          )}`}
                                          className="!h-[30px] !w-[30px] text-white"
                                        />
                                        <span className="rizzui-input-label block text-[14px] font-semibold">
                                          {capitalizeFirstLetter(
                                            member?.first_name
                                          )}{' '}
                                          {capitalizeFirstLetter(
                                            member?.last_name
                                          )}
                                        </span>
                                      </div>
                                      {!isDisable && (
                                        <RxCross2
                                          className="h-[20px] w-[20px] cursor-pointer"
                                          onClick={() =>
                                            handleRemoveMember(member?._id)
                                          }
                                        />
                                      )}
                                    </div>
                                  )
                                )}
                              </div>
                            </SimpleBar>
                          )
                        );
                      })()}

                    {editMode &&
                      signIn?.role === 'team_client' &&
                      task?.assign_to?.lenght > 0 && (
                        <SimpleBar
                          className={`${
                            task?.assign_to > 3 ? 'max-h-40' : ''
                          } `}
                        >
                          <div className="rounded-lg border-[1px]">
                            {task?.assign_to?.map((member: any, index: any) => (
                              <div
                                className={`flex items-center justify-between p-3 text-[#141414] ${
                                  selectedMembers?.length - 1 !== index &&
                                  'border-b-[1px]'
                                }`}
                                key={index}
                              >
                                <div className="flex items-center gap-3">
                                  <Avatar
                                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                    name={
                                      capitalizeFirstLetter(
                                        member?.first_name
                                      ) +
                                      ' ' +
                                      capitalizeFirstLetter(member?.last_name)
                                    }
                                    className="!h-[30px] !w-[30px] text-white"
                                  />
                                  <span className="rizzui-input-label block text-[14px] font-semibold">
                                    {capitalizeFirstLetter(member?.first_name) +
                                      ' ' +
                                      capitalizeFirstLetter(member?.last_name)}
                                  </span>
                                </div>
                                {!isDisable && (
                                  <RxCross2
                                    className="h-[20px] w-[20px] cursor-pointer"
                                    onClick={() =>
                                      handleRemoveMember(member?._id)
                                    }
                                  />
                                )}
                              </div>
                            ))}
                          </div>
                        </SimpleBar>
                      )}
                    <div
                      className={`flex flex-col gap-6 sm:flex-row ${
                        error ? 'items-start' : 'items-center'
                      }`}
                    >
                      <div className="w-full">
                        <Controller
                          control={control}
                          name="status"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              // size="sm"
                              variant="text"
                              value={selectedStatus}
                              onChange={(selectedOption: any) => {
                                setSelectedStatus(selectedOption);
                                setValue('status', selectedOption?.value);
                                setError('status', { message: '' });
                                task?.status?.section_name === 'Completed' &&
                                  setIsDisable(false);
                              }}
                              // disabled={
                              //    !editMode ||
                              // task?.mark_as_done ||
                              // !(
                              //   ['agency'].includes(signIn?.role) ||
                              //   task?.assign_to?.some(
                              //     (user: any) =>
                              //       user?._id === signIn?.user?.data?.user?._id
                              //   ) ||
                              //   (['team_agency'].includes(signIn?.role) &&
                              //     checkPermission(
                              //       'projects',
                              //       'tasks',
                              //       'update',
                              //       signIn?.permission
                              //     ))
                              // )
                              // }
                              options={statusOptions}
                              placeholder="Select status"
                              error={errors?.status?.message}
                              selectClassName={`!py-0`}
                              style={{
                                backgroundColor: selectedStatus?.section?.color,
                                pointerEvents: isDisable ? 'none' : 'auto',
                              }}
                              className={`rounded-lg border-[1px]`}
                              suffix={<PiCaretDownBold className="h-3 w-3" />}
                            />
                          )}
                        />
                      </div>
                      <div className="w-full">
                        <Controller
                          control={control}
                          name="priority"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              variant="text"
                              name="priority"
                              value={selectedPriority}
                              onChange={(selectedOption: any) => {
                                setSelectedPriority(selectedOption);
                                setValue('priority', selectedOption?.value);
                                setError('priority', { message: '' });
                              }}
                              options={priorityOptions}
                              // disabled={isDisable}
                              placeholder="Select priority"
                              error={errors?.priority?.message}
                              className={`rounded-lg border-[1px]`}
                              selectClassName={`!py-0 ${priorityOptions?.find(
                                (option) => option.value === value
                              )?.color}`}
                              style={{
                                pointerEvents: isDisable ? 'none' : 'auto',
                              }}
                              suffix={<PiCaretDownBold className="h-3 w-3" />}
                            />
                          )}
                        />
                      </div>

                      <div className="w-full">
                        <Input
                          type="text"
                          inputClassName="text-[#141414] poppins_font_number"
                          className="poppins_font_number flex-1 border-none bg-[#F9FAFB] text-[14px] text-[#141414] focus:outline-none"
                          placeholder=" # Add Tags"
                          value={inputValue}
                          disabled={isDisable}
                          onKeyDown={handleAddTag}
                          onChange={handleInputChange}
                          onBlur={handleInputBlur}
                        />
                        {error && (
                          <span className="mt-1 text-[12px] text-red-500">
                            {error}
                          </span>
                        )}
                      </div>
                    </div>
                    {tags?.length > 0 && (
                      <div className="flex w-full flex-wrap gap-2">
                        {tags?.map((tag, index) => (
                          <div
                            key={index}
                            className="flex max-w-full items-center gap-2 break-words rounded-md bg-[#E4E7EB] px-3 py-1 text-sm font-medium text-[#4A5568] dark:bg-[#2D3748] dark:text-[#CBD5E0]"
                            style={{ backgroundColor: tag?.tag_color }}
                          >
                            <span className="break-all">{tag?.tag_name}</span>
                            {!isDisable && (
                              <RxCross2
                                className="h-4 w-4 cursor-pointer text-[#141414]"
                                onClick={() => handleRemoveTag(index)}
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex justify-between gap-5">
                      <div className=" flex flex-col gap-1 justify-self-end">
                        <span className="text-[14px] font-medium text-[#141414]">
                          Created At
                        </span>
                        <span className="poppins_font_number text-[14px] font-medium  text-[#8C80D2] ">
                          {moment(task?.createdAt).format('MMMM DD, yyyy')}
                        </span>
                      </div>
                      <div className=" flex flex-col gap-1 justify-self-end">
                        <span className="text-[14px] font-medium text-[#141414]">
                          Time Spent
                        </span>
                        <span className="poppins_font_number text-[14px] font-medium text-[#8C80D2]">
                          {convertSecondsToTime(myTimeTracked)}
                        </span>
                      </div>
                      <div className="flex flex-col gap-1 justify-self-end">
                        <span className="text-[14px] font-medium text-[#141414]">
                          Total Time Spent
                        </span>
                        <div className="flex gap-8">
                          <span className="poppins_font_number text-[14px] font-medium text-[#8C80D2] ">
                            {convertSecondsToTime(
                              trackedHourDetails?.task_total_time
                            )}
                          </span>
                          <span className="flex font-semibold text-[#8C80D2] underline">
                            <Link
                              href={routes?.timeTrackTaskDetails(
                                defaultWorkSpace?.name,
                                boardId,
                                rowData?._id
                              )}
                            >
                              View Logs
                            </Link>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="task_form_date_picker_close_button_hide">
                      <span className="text-[14px] font-medium text-[#141414]">
                        Select Due Date & Time
                      </span>
                      <Controller
                        name="due_date"
                        control={control}
                        render={({ field: { value, onChange } }) => (
                          <DatePicker
                            selected={value}
                            className="bg-[#F9FAFB]"
                            inputProps={{
                              inputClassName: 'font-sans', // Custom class for the input
                              color: 'info',
                              error: errors?.due_date?.message,
                            }}
                            placeholderText={
                              !task?.mark_as_done ? 'Select due date' : ''
                            }
                            onChange={onChange}
                            selectsStart
                            startDate={value}
                            minDate={new Date()}
                            disabled={isDisable}
                            showTimeSelect
                            isClearable={true}
                            popperPlacement="bottom-start"
                            dateFormat="MMMM d, yyyy h:mm aa"
                            showYearDropdown
                            scrollableYearDropdown
                            showMonthDropdown
                            yearDropdownItemNumber={100}
                          />
                        )}
                      />
                    </div>

                    <div>
                      <div className="flex flex-wrap gap-4">
                        <div className="flex items-center" {...getRootProps()}>
                          <input
                            {...getInputProps()}
                            ref={commentAttachmentRef}
                          />
                          <Button
                            size="lg"
                            className="h-10 items-center gap-2 whitespace-nowrap rounded-lg border border-[#6875F5] bg-transparent p-3 text-[#6875F5] marker:flex"
                            onClick={() =>
                              commentAttachmentRef?.current?.click()
                            }
                            disabled={isDisable}
                          >
                            <ImAttachment className="h-4 w-4 text-[#6875F5]" />
                            <span className="text-sm"> Attachments</span>
                          </Button>
                        </div>
                        {previewImage &&
                          previewImage != null &&
                          previewImage?.length > 0 &&
                          previewImage?.map((image: any, index: number) => {
                            const fileType = getFileType(image?.name);
                            const color = getColor(fileType);
                            return (
                              <div
                                className={`flex max-h-10 items-center gap-1 rounded-full p-2`}
                                style={{
                                  backgroundColor: color?.bgColor,
                                  color: color?.textColor,
                                }}
                                key={index}
                              >
                                <CustomFileIcons
                                  iconClassName="!w-5 !h-4"
                                  key={index}
                                  fileType={fileType}
                                />
                                <p className="max-w-[200px] truncate !font-sans text-[14px]">
                                  {image?.name}
                                </p>
                                {!isDisable && (
                                  <RxCross2
                                    className="h-4 w-4 cursor-pointer"
                                    onClick={() => {
                                      // filter out removed file from preview image state
                                      const updatedFiles =
                                        previewImage?.length > 0 &&
                                        previewImage?.filter((file: any) => {
                                          if (
                                            file?.preview !== image?.preview
                                          ) {
                                            return file;
                                          }
                                        });
                                      checkCommentAttachement(updatedFiles);
                                      setPreviewImage(updatedFiles);
                                      setValue('attachments', updatedFiles, {
                                        shouldValidate: true,
                                      });
                                    }}
                                  />
                                )}
                              </div>
                            );
                          })}
                      </div>
                      {commentAttachementInvalid && (
                        <p className="pt-1 text-red">
                          {messages.taskAttachementMaxFileSize}
                        </p>
                      )}
                    </div>
                    <span className="border" />
                    <div>
                      <label className="text-[14px] font-semibold text-[#141414]">
                        Description
                      </label>
                      <Controller
                        control={control}
                        name="agenda"
                        render={({ field: { onChange, value } }) => (
                          <QuillEditor
                            value={value}
                            onChange={onChange}
                            onKeyDown={handleKeyDown}
                            placeholder="Add description"
                            readOnly={isDisable}
                            // error={errors?.agenda?.message as string}
                            className="quill-editor-font poppins_font_number col-span-full bg-[#F9FAFB] text-[#141414] [&_.ql-editor]:min-h-[100px]"
                          />
                        )}
                      />
                    </div>
                    {customFieldData?.length > 0 && (
                      <>
                        {customFieldData?.map((field: any, index: number) => {
                          const dropdownOption = field?.options?.map(
                            (option: string) => ({
                              value: option,
                              label: capitalizeFirstLetter(option),
                            })
                          );
                          return (
                            <div key={index}>
                              {field?.fieldType !== 'checkbox' && (
                                <label className="mb-1 text-[14px] font-semibold text-[#141414]">
                                  {capitalizeFirstLetter(field?.fieldName)}
                                </label>
                              )}
                              {field?.fieldType === 'dropdown' ? (
                                <Select
                                  options={dropdownOption}
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e.value,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  value={
                                    customFieldData &&
                                    dropdownOption?.find(
                                      (option: any) =>
                                        option.value ===
                                        customFieldData[index]?.value
                                    )
                                  }
                                  placeholder="Select Field"
                                  className="w-full !text-[#141414]"
                                  selectClassName="!text-[#141414] bg-[#F9FAFB] poppins_font_number"
                                  disabled={isDisable}
                                />
                              ) : field?.fieldType === 'textarea' ? (
                                <Textarea
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e.target.value,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  defaultValue={field?.value}
                                  onKeyDown={handleKeyDown}
                                  className="w-full bg-[#F9FAFB] [&_.rizzui-textarea-field]:!resize-none"
                                  textareaClassName="text-[#141414] poppins_font_number"
                                  disabled={isDisable}
                                />
                              ) : field?.fieldType === 'checkbox' ? (
                                <Checkbox
                                  inputClassName="checkbox-color"
                                  label={capitalizeFirstLetter(
                                    field?.fieldName
                                  )}
                                  checked={field?.value}
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e?.target?.checked,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  className="text-[14px] font-bold"
                                  labelClassName="ml-2 text-[#141414]"
                                  disabled={isDisable}
                                />
                              ) : field?.fieldType === 'date' ? (
                                <DatePicker
                                  className="date-picker bg-[#F9FAFB] text-[#141414]"
                                  inputProps={{
                                    inputClassName: 'poppins_font_number',
                                  }}
                                  selected={
                                    field?.value ? new Date(field?.value) : null
                                  }
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  dateFormat="MMMM dd, yyyy"
                                  disabled={isDisable}
                                />
                              ) : (
                                <Input
                                  type={field?.fieldType}
                                  defaultValue={field?.value}
                                  onChange={(e: any) =>
                                    setCustomFieldData((prevFields: any) => {
                                      const updatedFields = [...prevFields]; // Create a shallow copy of the array
                                      updatedFields[index] = {
                                        ...updatedFields[index],
                                        value: e.target.value,
                                      }; // Update only the target object
                                      return updatedFields; // Return the updated array
                                    })
                                  }
                                  onKeyDown={handleKeyDown}
                                  inputClassName="text-[#141414] poppins_font_number bg-[#F9FAFB]"
                                  className="w-full"
                                  disabled={isDisable}
                                />
                              )}
                            </div>
                          );
                        })}
                      </>
                    )}

                    {allSubtask?.length > 0 && (
                      <div>
                        <span className="mb-2 block text-[14px] font-medium text-[#141414]">
                          Subtasks
                        </span>
                        <div className="max-h-[300px] min-h-[20px] overflow-y-auto">
                          {allSubtask &&
                            allSubtask?.length > 0 &&
                            allSubtask?.map((subtask: any) => {
                              return (
                                <div
                                  className="mb-2 flex  items-center justify-between rounded-md border bg-white px-3 py-2 shadow-sm  hover:bg-gray-50"
                                  key={subtask?._id}
                                >
                                  <div className="flex text-center">
                                    {/* {(!subtask?.mark_as_archived &&
                                      ['agency'].includes(signIn?.role)) ||
                                    (['team_client', 'team_agency'].includes(
                                      signIn?.role
                                    ) &&
                                      checkPermission(
                                        'projects',
                                        'tasks',
                                        'update',
                                        signIn?.permission
                                      )) ? ( */}
                                    <Tooltip
                                      size="sm"
                                      content={() =>
                                        !subtask?.mark_as_done
                                          ? 'Move to completed'
                                          : 'Move to archive'
                                      }
                                      placement="bottom"
                                      color="invert"
                                      className="z-100"
                                    >
                                      <span className="inline-flex">
                                        <button
                                          type="button"
                                          className="view-task-tour-step-one inline-flex px-4 py-2 disabled:cursor-not-allowed"
                                          onClick={() =>
                                            !subtask?.mark_as_done
                                              ? handleMarkSubtaskCompleteClick(
                                                  subtask
                                                )
                                              : handleMarkSubtaskArchive(
                                                  subtask
                                                )
                                          }
                                          // disabled={loading}
                                          disabled={
                                            loading ||
                                            subtask?.mark_as_archived ||
                                            !(
                                              signIn?.role === 'agency' ||
                                              ([
                                                'team_client',
                                                'team_agency',
                                              ].includes(signIn?.role) &&
                                                checkPermission(
                                                  'projects',
                                                  'tasks',
                                                  'update',
                                                  signIn?.permission
                                                ))
                                            )
                                          }
                                        >
                                          {subtask?.mark_as_done ? (
                                            <IoIosCheckmarkCircle className="h-6 w-6 text-[#8C80D2]" />
                                          ) : (
                                            <IoIosCheckmarkCircleOutline className="h-6 w-6 text-[#8C80D2]" />
                                          )}
                                        </button>
                                      </span>
                                    </Tooltip>

                                    {/* ) : (
                                      // Invisible placeholder for consistent alignment
                                      <div
                                        style={{
                                          width: '56px',
                                          height: 24,
                                        }}
                                      />
                                    )} */}
                                  </div>

                                  {/* Subtas */}
                                  <div
                                    className="flex-1 cursor-pointer"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openTaskModal(subtask); // Pass child task
                                    }}
                                  >
                                    <h4 className="poppins_font_number max-w-[164px]  overflow-hidden truncate whitespace-nowrap text-sm font-medium text-gray-800">
                                      {subtask?.title}
                                    </h4>
                                  </div>

                                  {/* Priority */}
                                  <div className="flex-1">
                                    <span
                                      className={`rounded-md px-2 py-1 text-xs font-semibold ${
                                        subtask.priority === 'high'
                                          ? 'bg-[#FFD4C6] text-red-dark'
                                          : subtask.priority === 'medium'
                                            ? 'bg-[#FBF0DE]   text-orange-dark'
                                            : 'bg-[#E4F6D6] text-green-dark'
                                      }`}
                                    >
                                      {capitalizeFirstLetter(
                                        subtask?.priority
                                      ) || 'N/A'}
                                    </span>
                                  </div>
                                  {/* Status */}
                                  <div className="flex-1">
                                    <Tooltip
                                      size="sm"
                                      content={() => (
                                        <div className="max-w-[200px] text-xs">
                                          {subtask?.status?.section_name}
                                        </div>
                                      )}
                                      placement="top"
                                      color="invert"
                                      className="demo_test"
                                    >
                                      <span
                                        className="block w-[120px] overflow-hidden text-ellipsis whitespace-nowrap rounded-md px-2 py-1 text-xs font-semibold"
                                        style={{
                                          backgroundColor:
                                            subtask?.status?.color,
                                          color: subtask?.status?.test_color,
                                        }}
                                      >
                                        {subtask?.status?.section_name}
                                      </span>
                                    </Tooltip>
                                  </div>

                                  {/* Assignee */}
                                  <div className=" flex-1 items-center justify-center">
                                    {subtask?.assign_to?.length > 0 ? (
                                      <div className="ms-3 flex items-center ">
                                        {/* Show only the first 3 members */}
                                        {subtask?.assign_to
                                          ?.slice(0, 3)
                                          ?.map((member: any) => (
                                            <figure
                                              key={member?.id}
                                              className={
                                                'relative z-10 ml-[-13px] flex h-7 w-7 cursor-pointer rounded-full focus:border-2 focus:border-gray-900'
                                              }
                                            >
                                              <Avatar
                                                src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                                name={
                                                  capitalizeFirstLetter(
                                                    member?.first_name
                                                  ) +
                                                  ' ' +
                                                  capitalizeFirstLetter(
                                                    member?.last_name
                                                  )
                                                }
                                                size="sm"
                                                className={
                                                  '!h-7 !w-7 bg-[#70C5E0] font-medium text-white'
                                                }
                                              />
                                            </figure>
                                          ))}

                                        {/* Show the "+X" badge if there are more members */}
                                        {subtask?.assign_to?.length > 3 && (
                                          <div className="poppins_font_number ml-[-10px] flex h-10 w-10 items-center justify-center rounded-full text-[14px] font-medium text-[#9BA1B9]">
                                            +{subtask?.assign_to?.length - 3}
                                          </div>
                                        )}
                                      </div>
                                    ) : (
                                      <div className="flex items-center justify-start gap-2">
                                        <Text className="poppins_font_number text-sm font-semibold text-[#9BA1B9]">
                                          -
                                        </Text>
                                      </div>
                                    )}
                                  </div>

                                  {/* Actions */}
                                  <div className="flex cursor-pointer items-center gap-3">
                                    {/* Placeholder for consistent alignment */}
                                    {!subtask?.mark_as_done &&
                                    !subtask?.mark_as_archived &&
                                    (['agency'].includes(signIn?.role) ||
                                      (['team_client', 'team_agency'].includes(
                                        signIn?.role
                                      ) &&
                                        checkPermission(
                                          'projects',
                                          'tasks',
                                          'delete',
                                          signIn?.permission
                                        ))) ? (
                                      <Tooltip
                                        size="sm"
                                        content={() => 'Delete Sub Task'}
                                        placement="top"
                                        color="invert"
                                      >
                                        <button
                                          className="text-red-500 hover:text-red-700"
                                          type="button"
                                          onClick={() => {
                                            setSubTaskData(subtask);
                                            setShowDeleteConfirmationPopper(
                                              true
                                            );
                                            const closeDrawerCondition =
                                              subtask?.parent_task
                                                ? true
                                                : false;
                                            setShouldCloseDrawer(
                                              closeDrawerCondition
                                            );
                                          }}
                                          // disabled={
                                          //   subtask?.mark_as_archived
                                          // }
                                        >
                                          <FiTrash size={16} />
                                        </button>
                                      </Tooltip>
                                    ) : (
                                      // Invisible placeholder for consistent alignment
                                      <div style={{ width: 16, height: 16 }} />
                                    )}

                                    {!subtask?.mark_as_done &&
                                    !subtask?.mark_as_archived &&
                                    (['agency'].includes(signIn?.role) ||
                                      (['team_agency', 'team_client'].includes(
                                        signIn?.role
                                      ) &&
                                        checkPermission(
                                          'projects',
                                          'tasks',
                                          'create',
                                          signIn?.permission
                                        ))) ? (
                                      <Tooltip
                                        size="sm"
                                        content={() => 'Duplicate Sub Task'}
                                        placement="top"
                                        color="invert"
                                      >
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            if (!duplicateTaskLoading) {
                                              onSubTaskDuplicateTask(subtask);
                                            }
                                          }}
                                          className={`poppins_font_number flex cursor-pointer items-center justify-start gap-2 text-[14px] font-bold text-[#120425] ${
                                            duplicateTaskLoading
                                              ? 'cursor-not-allowed opacity-50'
                                              : ''
                                          }`}
                                        >
                                          <IoDuplicateOutline
                                            className="text-[#8C80D2]"
                                            size={16}
                                          />
                                        </button>
                                      </Tooltip>
                                    ) : (
                                      // Invisible placeholder for consistent alignment
                                      <div style={{ width: 16, height: 16 }} />
                                    )}

                                    {!subtask?.mark_as_done &&
                                    !subtask?.mark_as_archived &&
                                    subtask?.due_date &&
                                    (['agency'].includes(signIn?.role) ||
                                      (['team_agency', 'team_client'].includes(
                                        signIn?.role
                                      ) &&
                                        checkPermission(
                                          'projects',
                                          'tasks',
                                          'create',
                                          signIn?.permission
                                        ))) &&
                                    new Date(subtask?.due_date).getTime() >
                                      new Date().getTime() ? (
                                      <Tooltip
                                        size="sm"
                                        content={() => 'Reminder due date Task'}
                                        placement="top"
                                        color="invert"
                                      >
                                        <button
                                          type="button"
                                          onClick={() => {
                                            if (!taskLoading) {
                                              setSubTaskData(subtask);
                                              setShowTaskReminderPopper(true);
                                              const closeDrawerCondition =
                                                subtask?.parent_task
                                                  ? true
                                                  : false;
                                              setShouldCloseDrawer(
                                                closeDrawerCondition
                                              );
                                            }
                                          }}
                                          className={`poppins_font_number flex cursor-pointer items-center justify-start gap-2 text-[14px] font-bold text-[#120425] ${
                                            taskLoading
                                              ? 'cursor-not-allowed opacity-50'
                                              : ''
                                          }`}
                                        >
                                          {subtask?.reminder_option &&
                                          subtask?.reminder_option !==
                                            'no_notify' ? (
                                            <BiSolidBellRing
                                              className=" text-[#8C80D2]"
                                              size={16}
                                            />
                                          ) : (
                                            <LuBellRing
                                              className=" text-[#8C80D2]"
                                              size={16}
                                            />
                                          )}
                                        </button>
                                      </Tooltip>
                                    ) : (
                                      // Invisible placeholder for consistent alignment
                                      <div style={{ width: 16, height: 16 }} />
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </div>
                    )}
                    {((['team_client', 'team_agency'].includes(signIn?.role) &&
                      checkPermission(
                        'projects',
                        'tasks',
                        'create',
                        signIn?.permission
                      )) ||
                      ['agency'].includes(signIn?.role)) &&
                      !task?.parent_task &&
                      !task?.mark_as_done && (
                        <div>
                          {!showSubtaskFields ? (
                            <Button
                              className="flex gap-2 border border-[#5850EC] bg-transparent text-[#5850EC]"
                              onClick={() => {
                                if (!task?.mark_as_done) {
                                  setShowSubtaskFields(true);

                                  // Scroll to the subtask form after opening
                                  setTimeout(() => {
                                    const formElement =
                                      document.getElementById('subtaskForm');
                                    formElement?.scrollIntoView({
                                      behavior: 'smooth',
                                      block: 'start',
                                    });
                                  }, 100);
                                }
                              }}
                            >
                              <FiPlus className="h-[15px] w-[15px]" />
                              <span>Add Subtask</span>
                            </Button>
                          ) : (
                            <div
                              id="subtaskForm"
                              className="rounded-md border p-5"
                            >
                              <NewSubTaskForm
                                onClose={() => setShowSubtaskFields(false)}
                                editMode={false}
                                rowData={rowData}
                                createTask={createTask}
                                updateTask={updateTask}
                                setAllSubtask={setAllSubtask}
                                allSubtask={allSubtask}
                                parentStatus={watch('status')}
                                parentDueDate={watch('due_date')}
                              />
                            </div>
                          )}
                        </div>
                      )}

                    {isRecurring && (
                      <div className="flex flex-col  gap-5 rounded-lg border border-gray-300 bg-[#F9FAFB] p-3">
                        <div className="flex w-full items-center gap-3">
                          <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                            Setup Recurring Task
                          </span>
                          <Select
                            options={RecurringArray}
                            onChange={(event) => {
                              onChangeRecurring(event, setValue);
                              setMonthlyDates([]);
                              setValue('recurrence_task_due_date', []);
                              setIsEachMonth(false);
                              setIsEachWeek(false);
                            }}
                            value={selectedRecurringOption}
                            className="w-[6.6rem]"
                            optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                            selectClassName="!text-[#5850EC] border-[#5850EC] poppins_font_number focus:border-[#5850EC] hover:border-[#5850EC] !bg-white"
                            disabled={
                              (task?.mark_as_done && !task?.parent_task) ||
                              (['team_client', 'team_agency'].includes(
                                signIn?.role
                              ) &&
                                !(
                                  editMode &&
                                  checkPermission(
                                    'projects',
                                    'tasks',
                                    'update',
                                    signIn?.permission
                                  )
                                )) ||
                              (task?.mark_as_archived && task?.parent_task)
                            }
                          />
                        </div>

                        {/* Repeat every and End date */}
                        {['daily', 'weekly', 'monthly'].includes(
                          selectedRecurringOption?.value
                        ) && (
                          <>
                            <div className="flex flex-col  gap-4 sm:flex-row  sm:flex-wrap">
                              {/* <div className="w-full sm:w-[20%]">
                              <span className="mb-1 text-[14px] font-medium text-[#141414]">
                                Repeat every
                              </span>
                              <Input
                                rounded="DEFAULT"
                                type="number"
                                min={0}
                                inputClassName="poppins_font_number bg-white"
                                className="border-gray-300  text-[#141414] focus:border-primary focus:ring-primary"
                                {...register('recurrence_interval')}
                                // onChange={handleKeyDown}
                                onKeyDown={handleKeyDown}
                                onFocus={(e) =>
                                  e.target.addEventListener(
                                    'wheel',
                                    (e) => e.preventDefault(),
                                    { passive: false }
                                  )
                                }
                                error={
                                  errors?.recurrence_interval?.message as string
                                }
                                disabled={
                                  (task?.mark_as_done && !task?.parent_task) ||
                                  (['team_client', 'team_agency'].includes(
                                    signIn?.role
                                  ) &&
                                    !(
                                      editMode &&
                                      checkPermission(
                                        'projects',
                                        'tasks',
                                        'update',
                                        signIn?.permission
                                      )
                                    )) ||
                                  (task?.mark_as_archived && task?.parent_task)
                                }
                              />
                            </div> */}

                              <div className="w-[145px]">
                                <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  Starts from
                                </span>
                                <Controller
                                  name="recurrence_start_date"
                                  control={control}
                                  render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                      placeholderText="Select date"
                                      selected={value}
                                      showYearDropdown
                                      scrollableYearDropdown
                                      showMonthDropdown
                                      yearDropdownItemNumber={100}
                                      inputProps={{
                                        inputClassName: 'bg-white',
                                        error: errors?.recurrence_start_date
                                          ?.message as string,
                                      }}
                                      onChange={(date: any) => {
                                        setValue('recurrence_start_date', date);
                                        setSelectedDate(date);
                                        clearErrors('recurrence_start_date');
                                        // if (watch('recurrence_start_at_time')) {
                                        //   setValue(
                                        //     'recurrence_start_at_time',
                                        //     null
                                        //   );
                                        // }
                                        setIsEachWeek(false);
                                        setIsEachWeekModal(false);
                                        setValue(
                                          'recurrence_task_due_date',
                                          []
                                        );
                                        if (date) {
                                          const maxAllowedEndDate = new Date(
                                            date
                                          );
                                          maxAllowedEndDate.setFullYear(
                                            maxAllowedEndDate.getFullYear() + 1
                                          );

                                          if (
                                            (watch('recurrence_end_date') ??
                                              new Date(0)) > maxAllowedEndDate
                                          ) {
                                            setValue(
                                              'recurrence_end_date',
                                              maxAllowedEndDate
                                            );
                                          }
                                        }
                                      }}
                                      selectsStart
                                      startDate={value}
                                      minDate={new Date()}
                                      maxDate={watch('recurrence_end_date')}
                                      // dateFormat="MMMM dd, yyyy"
                                      className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                      disabled={
                                        (task?.mark_as_done &&
                                          !task?.parent_task) ||
                                        ([
                                          'team_client',
                                          'team_agency',
                                        ].includes(signIn?.role) &&
                                          !(
                                            editMode &&
                                            checkPermission(
                                              'projects',
                                              'tasks',
                                              'update',
                                              signIn?.permission
                                            )
                                          )) ||
                                        (task?.mark_as_archived &&
                                          task?.parent_task)
                                      }
                                    />
                                  )}
                                />
                              </div>
                              <div className="w-[145px]">
                                <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  Ends on
                                </span>
                                <Controller
                                  name="recurrence_end_date"
                                  control={control}
                                  render={({ field: { value, onChange } }) => {
                                    const startDate =
                                      watch('recurrence_start_date') ||
                                      new Date(); // Ensure a valid date
                                    const maxEndDate = new Date(startDate);
                                    maxEndDate.setFullYear(
                                      maxEndDate.getFullYear() + 1
                                    );

                                    return (
                                      <DatePicker
                                        placeholderText="Select date"
                                        selected={value}
                                        showYearDropdown
                                        scrollableYearDropdown
                                        showMonthDropdown
                                        yearDropdownItemNumber={100}
                                        inputProps={{
                                          inputClassName: 'bg-white',
                                          error: errors?.recurrence_end_date
                                            ?.message as string,
                                        }}
                                        // onChange={onChange}
                                        onChange={(date: any) => {
                                          setIsEachWeek(false);
                                          setValue(
                                            'recurrence_task_due_date',
                                            []
                                          );
                                          setIsEachWeekModal(false);
                                          setValue('recurrence_end_date', date);
                                          setSelectedEndDate(date); // Update local state
                                          clearErrors('recurrence_end_date');
                                          setValue('recurrence_end_date', date); // Update form value
                                        }}
                                        selectsStart
                                        startDate={value}
                                        minDate={startDate}
                                        maxDate={maxEndDate}
                                        className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                        disabled={
                                          (task?.mark_as_done &&
                                            !task?.parent_task) ||
                                          ([
                                            'team_client',
                                            'team_agency',
                                          ].includes(signIn?.role) &&
                                            !(
                                              editMode &&
                                              checkPermission(
                                                'projects',
                                                'tasks',
                                                'update',
                                                signIn?.permission
                                              )
                                            )) ||
                                          (task?.mark_as_archived &&
                                            task?.parent_task)
                                        }
                                      />
                                    );
                                  }}
                                />
                              </div>

                              {selectedRecurringOption?.value === 'monthly' && (
                                <div>
                                  <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Select Day
                                  </span>
                                  <div className="mt-2 flex items-center gap-1">
                                    <Controller
                                      name="monthly_recurrence_day_of_month"
                                      control={control}
                                      render={({
                                        field: { onChange, value },
                                      }) => (
                                        <Select
                                          options={monthDate}
                                          onChange={onChange}
                                          value={value}
                                          placeholder="Select date"
                                          className="w-[68px]"
                                          optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                          selectClassName="!text-[#111928] border-[#E5E7EB] font-medium text-sm leading-[19.6px] h-10 border rounded-[10px] font-['Raleway'] focus:border-[#111928] hover:border-[#111928] !bg-white"
                                          disabled={
                                            (task?.mark_as_done &&
                                              !task?.parent_task) ||
                                            ([
                                              'team_client',
                                              'team_agency',
                                              'client',
                                            ].includes(signIn?.role) &&
                                              !(
                                                editMode &&
                                                checkPermission(
                                                  'projects',
                                                  'tasks',
                                                  'update',
                                                  signIn?.permission
                                                )
                                              )) ||
                                            (task?.mark_as_archived &&
                                              task?.parent_task)
                                          }
                                        />
                                      )}
                                    />
                                    <p className="font-['Raleway'] text-[12px] font-normal leading-[14.4px] text-[#111928]">
                                      of every month
                                    </p>
                                  </div>
                                  {errors?.monthly_recurrence_day_of_month && (
                                    <p className="mt-2 text-sm text-red-600">
                                      {
                                        errors?.monthly_recurrence_day_of_month
                                          ?.message as string
                                      }
                                    </p>
                                  )}
                                </div>
                              )}
                              <div className="w-[145px]">
                                <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  At Time
                                </span>
                                <Controller
                                  name="recurrence_start_at_time"
                                  control={control}
                                  render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                      placeholderText="Start time"
                                      selected={value}
                                      inputProps={{
                                        inputClassName: 'bg-white',
                                        error: errors?.recurrence_start_at_time
                                          ?.message as string,
                                      }}
                                      onChange={(date: any) => {
                                        setValue(
                                          'recurrence_start_at_time',
                                          date
                                        );
                                        clearErrors('recurrence_start_at_time');
                                      }}
                                      selectsStart
                                      startDate={value}
                                      // minTime={getMinTime()}
                                      // maxTime={getMaxTime()}
                                      showTimeSelect
                                      showTimeSelectOnly
                                      dateFormat="hh:mm aa"
                                      className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                      disabled={
                                        (task?.mark_as_done &&
                                          !task?.parent_task) ||
                                        ([
                                          'team_client',
                                          'team_agency',
                                        ].includes(signIn?.role) &&
                                          !(
                                            editMode &&
                                            checkPermission(
                                              'projects',
                                              'tasks',
                                              'update',
                                              signIn?.permission
                                            )
                                          )) ||
                                        (task?.mark_as_archived &&
                                          task?.parent_task)
                                      }
                                    />
                                  )}
                                />
                              </div>
                              {(!signIn?.userProfile?.agency_setting ||
                                signIn?.userProfile?.agency_setting === null ||
                                signIn?.userProfile?.agency_setting
                                  ?.is_custom_recurring === false) && (
                                <div className="w-[145px]">
                                  <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    {' '}
                                    Due Date Duration
                                  </span>
                                  <Input
                                    type="text" // Keep it text to avoid decimal inputs on some browsers
                                    inputClassName="text-black bg-white"
                                    className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                    onKeyDown={handleKeyDateDown}
                                    placeholder="Due in (days)"
                                    {...register('due_date_duration')}
                                    error={errors?.due_date_duration?.message}
                                    disabled={
                                      (task?.mark_as_done &&
                                        !task?.parent_task) ||
                                      (['team_client', 'team_agency'].includes(
                                        signIn?.role
                                      ) &&
                                        !(
                                          editMode &&
                                          checkPermission(
                                            'projects',
                                            'tasks',
                                            'update',
                                            signIn?.permission
                                          )
                                        )) ||
                                      (task?.mark_as_archived &&
                                        task?.parent_task)
                                    }
                                  />
                                </div>
                              )}
                              {selectedRecurringOption?.value === 'weekly' && (
                                <div className="w-[235px]">
                                  <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                    Days of the week
                                  </span>
                                  <div className="mt-2 flex gap-1">
                                    {weekdays.map((day) => (
                                      <Controller
                                        key={day.value}
                                        control={control}
                                        name="weekly_recurrence_days"
                                        render={({
                                          field: { value, onChange },
                                        }) => (
                                          <label
                                            className={`flex h-[40px] w-[32px] cursor-pointer items-center justify-center rounded-full border ${
                                              value?.includes(day.value)
                                                ? 'bg-[#EDEBFE] text-[#42389D]'
                                                : 'bg-white text-[#4B5563]'
                                            }`}
                                          >
                                            <input
                                              type="checkbox"
                                              className="hidden"
                                              checked={value?.includes(
                                                day.value
                                              )}
                                              onChange={(e) => {
                                                setIsEachWeek(false);
                                                setValue(
                                                  'recurrence_task_due_date',
                                                  []
                                                );
                                                setIsEachWeekModal(false);
                                                const isChecked =
                                                  e.target.checked;
                                                const newValues = isChecked
                                                  ? [
                                                      ...(value || []),
                                                      day.value,
                                                    ] // Add selected day
                                                  : (value || []).filter(
                                                      (v: any) =>
                                                        v !== day.value
                                                    ); // Remove unselected day
                                                onChange(newValues);
                                              }}
                                              disabled={
                                                (task?.mark_as_done &&
                                                  !task?.parent_task) ||
                                                ([
                                                  'team_client',
                                                  'team_agency',
                                                  'client',
                                                ].includes(signIn?.role) &&
                                                  !(
                                                    editMode &&
                                                    checkPermission(
                                                      'projects',
                                                      'tasks',
                                                      'update',
                                                      signIn?.permission
                                                    )
                                                  )) ||
                                                (task?.mark_as_archived &&
                                                  task?.parent_task)
                                              }
                                            />
                                            {day.name}
                                          </label>
                                        )}
                                      />
                                    ))}
                                  </div>
                                  {errors.weekly_recurrence_days && (
                                    <p className="mt-1 text-sm text-red-600">
                                      {errors.weekly_recurrence_days.message}
                                    </p>
                                  )}
                                </div>
                              )}

                              {signIn?.userProfile?.agency_setting
                                ?.is_custom_recurring &&
                                selectedRecurringOption?.value ===
                                  'monthly' && (
                                  <div>
                                    <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                      Default due day
                                    </span>
                                    <div className="mt-2 flex items-center gap-1">
                                      <Controller
                                        name="recurrence_default_due_date"
                                        control={control}
                                        render={({
                                          field: { onChange, value },
                                        }) => {
                                          const selectedDay: any =
                                            Number(
                                              watch(
                                                'monthly_recurrence_day_of_month'
                                              )?.value
                                            ) || 1;

                                          setRecurrenceDueDay(selectedDay);
                                          setDefaultRecurrence(
                                            watch('recurrence_default_due_date')
                                          );
                                          return (
                                            <Select
                                              options={monthDate?.filter(
                                                (date) =>
                                                  Number(date.value) >=
                                                  selectedDay
                                              )}
                                              onChange={onChange}
                                              value={value}
                                              placeholder="Select date"
                                              className="w-[68px]"
                                              disabled={
                                                (task?.mark_as_done &&
                                                  !task?.parent_task) ||
                                                ([
                                                  'team_client',
                                                  'team_agency',
                                                ].includes(signIn?.role) &&
                                                  !(
                                                    editMode &&
                                                    checkPermission(
                                                      'projects',
                                                      'tasks',
                                                      'update',
                                                      signIn?.permission
                                                    )
                                                  )) ||
                                                (task?.mark_as_archived &&
                                                  task?.parent_task) ||
                                                isEachMonth
                                              }
                                              optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                              selectClassName={`!text-[#111928] border-[#E5E7EB] font-medium text-sm leading-[19.6px] h-10 border rounded-[10px] font-['Raleway'] focus:border-[#111928] hover:border-[#111928] !bg-white ${
                                                (task?.mark_as_done &&
                                                  !task?.parent_task) ||
                                                ([
                                                  'team_client',
                                                  'team_agency',
                                                ].includes(signIn?.role) &&
                                                  !(
                                                    editMode &&
                                                    checkPermission(
                                                      'projects',
                                                      'tasks',
                                                      'update',
                                                      signIn?.permission
                                                    )
                                                  )) ||
                                                (task?.mark_as_archived &&
                                                  task?.parent_task) ||
                                                isEachMonth
                                                  ? 'opacity-50 cursor-not-allowed'
                                                  : ''
                                              }`}
                                            />
                                          );
                                        }}
                                      />
                                      <p className="font-['Raleway'] text-[12px] font-normal leading-[14.4px] text-[#111928]">
                                        of every month
                                      </p>
                                    </div>
                                    {errors?.recurrence_default_due_date && (
                                      <p className="mt-2 text-sm text-red-600">
                                        {
                                          errors?.recurrence_default_due_date
                                            ?.message as string
                                        }
                                      </p>
                                    )}
                                  </div>
                                )}
                            </div>
                            {signIn?.userProfile?.agency_setting
                              ?.is_custom_recurring &&
                              selectedRecurringOption?.value === 'monthly' && (
                                <div>
                                  <TailwindSwitch
                                    isRecurringType="monthly"
                                    label="Set different Due date & time for each month"
                                    defaultChecked={isEachMonth}
                                    onToggle={setIsEachMonth}
                                    recurrenceStartDate={selectedDate}
                                    recurrenceEndDate={selectedEndDate}
                                  />
                                  {isEachMonth && (
                                    <div className="mt-3 grid w-fit grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-3">
                                      {monthlyDates?.map(
                                        (item: any, index: number) => {
                                          // Ensure the recurrence_task_due_date exists
                                          const recurrenceDates =
                                            watch('recurrence_task_due_date') ||
                                            [];

                                          // Retrieve the selected date for the current index
                                          let rawDate =
                                            recurrenceDates[index]?.date;

                                          // Ensure it's a valid date
                                          const selectedDate = rawDate
                                            ? new Date(rawDate)
                                            : null;

                                          return (
                                            <div key={index} className="mt-2">
                                              <span className="font-['Raleway'] text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                                {new Date(
                                                  item.date
                                                ).toLocaleString('en-US', {
                                                  month: 'short',
                                                  year: 'numeric',
                                                })}
                                              </span>

                                              <Controller
                                                name={`recurrence_task_due_date.${index}.date`}
                                                control={control}
                                                render={({
                                                  field: { value, onChange },
                                                }) => (
                                                  <DatePicker
                                                    placeholderText="Select Due Date"
                                                    popperPlacement="auto-end"
                                                    showYearDropdown
                                                    scrollableYearDropdown
                                                    showMonthDropdown
                                                    yearDropdownItemNumber={100}
                                                    selected={
                                                      selectedDate instanceof
                                                        Date &&
                                                      !isNaN(
                                                        selectedDate.getTime()
                                                      )
                                                        ? selectedDate
                                                        : null
                                                    }
                                                    onChange={(date: any) => {
                                                      const prevDates =
                                                        watch(
                                                          'recurrence_task_due_date'
                                                        ) || [];

                                                      const updatedDates = [
                                                        ...prevDates,
                                                      ]; // Clone the existing array
                                                      updatedDates[index] = {
                                                        month: item?.month,
                                                        year: item?.year,
                                                        date: date || null,
                                                      };

                                                      setValue(
                                                        'recurrence_task_due_date',
                                                        updatedDates,
                                                        {
                                                          shouldValidate: true,
                                                          shouldDirty: true,
                                                        }
                                                      );
                                                    }}
                                                    selectsStart
                                                    startDate={selectedDate}
                                                    showTimeSelect
                                                    minDate={
                                                      item.isStartMonth
                                                        ? new Date(
                                                            item.year,
                                                            item.month - 1,
                                                            watch(
                                                              'recurrence_start_date'
                                                            )?.getDate() || 1
                                                          )
                                                        : new Date(
                                                            item.year,
                                                            item.month - 1,
                                                            1
                                                          )
                                                    }
                                                    maxDate={
                                                      new Date(
                                                        item.year,
                                                        item.month,
                                                        0
                                                      )
                                                    }
                                                    dateFormat="MMM dd, yyyy h:mm aa"
                                                    className="mt-2 border-gray-300 focus:border-primary focus:ring-primary"
                                                    calendarClassName="w-[420px]"
                                                  />
                                                )}
                                              />
                                            </div>
                                          );
                                        }
                                      )}
                                    </div>
                                  )}
                                </div>
                              )}

                            {signIn?.userProfile?.agency_setting
                              ?.is_custom_recurring &&
                              selectedRecurringOption?.value === 'weekly' && (
                                <div className="mt-5">
                                  <div className="flex gap-2 ">
                                    <TailwindSwitch
                                      isRecurringType="weekly"
                                      label="Set different Due date for each week"
                                      defaultChecked={isEachWeek}
                                      onToggle={setIsEachWeek}
                                      recurrenceStartDate={selectedDate}
                                      recurrenceEndDate={selectedEndDate}
                                      selectedDays={watch(
                                        'weekly_recurrence_days'
                                      )}
                                      editOpen={
                                        getValues()?.recurrence_task_due_date
                                          ?.length === 0
                                      }
                                      setIsEachWeekModal={setIsEachWeekModal}
                                    />
                                    {isEachWeek && (
                                      <span
                                        onClick={() =>
                                          isEachWeek && setIsEachWeekModal(true)
                                        }
                                        className="flex h-6 cursor-pointer items-center justify-center text-black"
                                      >
                                        <FiEdit size={20} />
                                      </span>
                                    )}
                                  </div>

                                  {isEachWeekModal &&
                                    createPortal(
                                      <div>
                                        <div className="fixed inset-0 z-[999] flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                                          <div
                                            className="relative overflow-visible rounded-lg bg-white shadow-lg "
                                            style={{ width: '1000px' }}
                                          >
                                            {isEachWeek && (
                                              <WeeklyRecurring
                                                onClose={() => {
                                                  setIsEachWeek(false);
                                                  setIsEachWeekModal(false);
                                                }}
                                                onModalClose={() =>
                                                  setIsEachWeekModal(false)
                                                }
                                                isEachWeek={isEachWeek}
                                                setIsEachWeek={setIsEachWeek}
                                                selectedDate={selectedDate}
                                                selectedEndDate={
                                                  selectedEndDate
                                                }
                                                selectedDays={watch(
                                                  'weekly_recurrence_days'
                                                )}
                                                defineValue={setValue}
                                                setWeeklyDates={setWeeklyDates}
                                                setAddDateAgain={
                                                  getValues()
                                                    ?.recurrence_task_due_date
                                                }
                                                isEdit={true}
                                                isEditVal={
                                                  getValues()
                                                    ?.recurrence_task_due_date ??
                                                  []
                                                }
                                                setIsEachWeekModal={
                                                  setIsEachWeekModal
                                                }
                                              />
                                            )}
                                          </div>
                                        </div>
                                      </div>,
                                      document.body
                                    )}
                                </div>
                              )}
                          </>
                        )}
                      </div>
                    )}

                    <div className="flex gap-6">
                      <Button
                        className="w-1/2 cursor-pointer rounded-lg border border-[#E5E7EB] bg-white text-sm text-[#141414]"
                        size="DEFAULT"
                        type="button"
                        onClick={(e) => {
                          if (task?.parent_task) {
                            e.stopPropagation(); // Prevents event bubbling

                            openTaskModal({
                              ...taskData?.task?.activity,
                              _id: taskData?.task?.activity?.parent_task, // Pass parent task ID
                            });
                          } else {
                            closeModal();
                          }
                        }}
                      >
                        Cancel
                      </Button>
                      {!isDisable && (
                        <Button
                          type="submit"
                          className="w-1/2 cursor-pointer rounded-lg bg-[#8C80D2] text-sm text-white"
                          size="DEFAULT"
                          disabled={taskData?.loading}
                        >
                          Save Changes
                          {taskData?.loading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </SimpleBar>
              </div>
            );
          }}
        </Form>

        <div className="flex items-center gap-3">
          {editMode &&
            (!task?.mark_as_done ||
              (task?.mark_as_done && !subTaskData?.mark_as_done)) &&
            !subTaskData?.mark_as_archived && (
              <div>
                {showDeleteConfirmationPopper && (
                  <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                    <div
                      className="relative overflow-hidden rounded-lg bg-white shadow-lg"
                      style={{ width: '400px' }}
                    >
                      <ConfirmationTaskDeleteModal
                        taskData={subTaskData?.parent_task ? subTaskData : task}
                        onClose={() => {
                          closeModal();
                        }}
                        onDeleteClose={() => {
                          setShowDeleteConfirmationPopper(false);
                        }}
                        updateTask={updateTask}
                        shouldCloseDrawer={shouldCloseDrawer}
                        setSubTaskData={setSubTaskData}
                        defaulttask={rowData}
                        setAllSubtask={setAllSubtask}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
        </div>

        {showPopper && (
          <div>
            <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
              <div
                className="relative overflow-hidden rounded-lg bg-white shadow-lg "
                style={{
                  width: '600px',
                  height: '475px',
                }}
              >
                <AddMembers
                  onClose={() => setShowPopper(false)}
                  selectedMembers={selectedMembers}
                  setSelectedMembers={setSelectedMembers}
                  formPage={true}
                  addTaskMember={true}
                />
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3">
          {editMode &&
            (!task?.mark_as_done ||
              (task?.mark_as_done && !subTaskData?.mark_as_done)) &&
            !subTaskData?.mark_as_archived && (
              <div>
                {showTaskReminderPopper && (
                  <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                    <div
                      className="relative rounded-lg bg-white shadow-lg"
                      style={{ width: '490px' }}
                    >
                      <TaskReminder
                        onClose={closeModal}
                        onTaskReminderClose={() =>
                          setShowTaskReminderPopper(false)
                        }
                        rowData={subTaskData}
                        shouldCloseDrawer={shouldCloseDrawer}
                        setSubTaskData={setSubTaskData}
                        setAllSubtask={setAllSubtask}
                        AssigneeMembers={
                          subTaskData?.assign_to?.map(
                            (assignee: Record<string, any>) => assignee?._id
                          ) || []
                        }
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
        </div>

        {showSubTaskModal && (
          <div>
            <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
              <div
                className="relative overflow-hidden rounded-lg bg-white shadow-lg "
                style={{ width: '800px', height: '800px' }}
              >
                <AddTaskForm
                  onClose={() => setShowSubTaskModal(false)}
                  editMode={false}
                  rowData={rowData}
                  createTask={createTask}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}
