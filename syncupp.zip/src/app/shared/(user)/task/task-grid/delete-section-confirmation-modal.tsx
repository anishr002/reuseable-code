"use client";
import { useDrawer } from "@/app/shared/drawer-views/use-drawer";
import { useModal } from "@/app/shared/modal-views/use-modal";
import Spinner from "@/components/ui/spinner";
import { deleteBoardSectionById, RemoveSection } from "@/redux/slices/user/task/boardSlice";
import { deleteTask, getAllTask } from "@/redux/slices/user/task/taskSlice";
import cn from "@/utils/class-names";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button, Text, Title } from "rizzui";



export function ConfirmationSectionDeleteModal(props: any) {
    const {  deleteColumn, column } = props;
    const dispatch = useDispatch();
    const { closeDrawer } = useDrawer();
    const { openModal, closeModal } = useModal();
    const [forceFullyDelete, setforceFullyDelete] = useState(false)

    const eventSliceData = useSelector((state: any) => state?.root?.event);
    const signIn = useSelector((state: any) => state?.root?.signIn);
    const { calendarView } = useSelector((state: any) => state?.root?.activity);
    const clientSliceData = useSelector((state: any) => state?.root?.client);
    const { gridView, deleteTaskLoader } = useSelector((state: any) => state?.root?.task);
    const { boardId, members, assignees, board, sections, deleteBoardSectionLoader } = useSelector((state: any) => state?.root?.board);

    const handleYesClick = () => {

        dispatch(deleteBoardSectionById({ section_id: column?._id, force_fully_delete : forceFullyDelete })).then((result: any) => {
            if (deleteBoardSectionById.fulfilled.match(result)) {
                if(result?.payload?.data?.force_fully_remove) {
                    setforceFullyDelete(!forceFullyDelete)
                } else if (result && result.payload.success === true) {
                deleteColumn(column?._id);
                dispatch(RemoveSection(column?._id));
                closeModal();
              }
            }
          });
    }

    return (
        <div className="p-6">
            <div className="flex flex-col items-center gap-[6px]">
                <Title
                    as="h6"
                    className="mb-0.5 flex items-start text-sm text-[#8C80D2] sm:items-center"
                >
                    {forceFullyDelete ? "A recurring task will be created in this section." : "Delete the section."}
                </Title>
                <Text className="mb-2 leading-relaxed text-[#9BA1B9]">
                    Are you sure you want to delete the section?
                </Text>
            </div>
            <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
                <div className="flex items-center justify-end gap-2">
                    <Button
                        className="bg-[#8C80D2] text-white @xl:w-auto dark:text-white"
                        disabled={deleteBoardSectionLoader}
                        onClick={handleYesClick}
                    >
                        Yes
                        {deleteBoardSectionLoader && (
                            <Spinner size="sm" tag="div" className="ms-3" color="white" />
                        )}
                    </Button>
                </div>
                <div>
                    <Button
                        variant="outline"
                        className="@xl:w-auto text-[#9BA1B9] dark:hover:border-gray-400"
                        onClick={() => {closeModal();setforceFullyDelete(true)}}
                    >
                        No
                    </Button>
                </div>
            </div>
        </div>
    );
}