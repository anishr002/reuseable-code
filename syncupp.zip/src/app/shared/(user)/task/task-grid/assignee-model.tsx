'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { useRouter } from 'next/navigation';
import { useDispatch, useSelector } from 'react-redux';

import {
  Formik,
  Form,
  Field,
  ErrorMessage,
  FormikProps,
  FieldProps,
  FieldArray,
} from 'formik';
import * as Yup from 'yup';
import { ActionIcon, Button, Input } from 'rizzui';
import { handleKeyDown } from '@/utils/common-functions';
import { PiXBold } from 'react-icons/pi';
import Select from 'react-select';
import { useEffect } from 'react';
import { getboardboarduserlist } from '@/redux/slices/user/task/boardSlice';
import Spinner from '@/components/ui/spinner';

export const AddassigneeModel = (props: any) => {
  const { setFieldValue, values } = props;

  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const router = useRouter();

  // state Selection
  const { boarduserlistData, loading } = useSelector(
    (state: any) => state?.root?.board
  );

  // Dropdown chips options
  const assigneeOptions =
    boarduserlistData?.data && boarduserlistData?.data?.length > 0
      ? boarduserlistData?.data?.map((assigneedata: any) => ({
        label: assigneedata?.user_name,
        value: assigneedata?.user_id,
        key: assigneedata,
      }))
      : [];

  // Filter the options that are not included in values.assignee
  const notIncludedOptions = assigneeOptions.filter(
    (option: any) => !values.assignee.includes(option.value)
  );

  // API call for the users
  useEffect(() => {
    dispatch(getboardboarduserlist());
  }, []);

  // Dropdown style
  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected ? 'white' : 'white',
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  // validation schema
  const assigneeValidationSchema = Yup.object().shape({
    assignee: Yup.array()
      .of(Yup.string().required('Assignee is required'))
      .min(1, 'At least one assignee is required'),
  });

  // Submit Handler
  const handleSubmit = (formdata: any) => {
    console.log([...values?.assignee, ...formdata?.assignee], 'values', 69);
    setFieldValue('assignee', [...values?.assignee, ...formdata?.assignee]);
  };

  // Remove Assignee Handler
  const RemoverHandler = (member: any) => {
    const updatedlist = values?.assignee?.filter(
      (id: any) => id === member?.value
    );
    setFieldValue('assignee', updatedlist);
  };

  return (
    <>
      <div className="flex items-center justify-between ">
        <h3 className="ms-3 p-3"> Add member</h3>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="me-4 p-0 text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>

      {loading ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" />
        </div>
      ) : (
        <>
          <Formik
            initialValues={{ assignee: [] }}
            validationSchema={assigneeValidationSchema}
            onSubmit={handleSubmit}
          // enableReinitialize
          >
            {({ values, isSubmitting, setFieldValue, errors }: any) => (
              // console.log(errors, 'errors', values),
              <Form className="flex flex-grow flex-col @container [&_label]:font-medium">
                <div className="mb-3 w-full">
                  <Select
                    name="assignee"
                    placeholder="Select Assignee"
                    options={notIncludedOptions}
                    isClearable={false}
                    isMulti={true} // Enable multi-selection
                    onChange={(selectedOptions: any) => {
                      const selectedValues = selectedOptions.map(
                        (option: any) => option.value
                      );
                      setFieldValue('assignee', selectedValues);
                    }}
                    classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                    styles={customStyles}
                  />
                  <ErrorMessage
                    name="assignee"
                    component="div"
                    className="mt-0.5 text-xs text-red"
                  />
                </div>

                <Button type="submit">Add Member</Button>
              </Form>
            )}
          </Formik>

          {/* Show a selected members  */}
          {values?.assignee && values?.assignee?.length > 0
            ? assigneeOptions
              .filter((option: any) => values.assignee.includes(option.value))
              .map(
                (member: any, index: number) => (
                  console.log(member, 'member'),
                  (
                    <div
                      className="mx-5 flex items-center justify-between"
                      key={index}
                    >
                      <h5>{member?.key?.user_name}</h5>
                      <div className="flex items-center justify-between">
                        <span>Remove</span>
                        <ActionIcon
                          onClick={() => {
                            RemoverHandler(member);
                          }}
                          size="sm"
                          variant="text"
                          className="me-4 p-0 text-gray-500 hover:!text-gray-900"
                        >
                          <PiXBold className="h-[15px] w-[15px]" />
                        </ActionIcon>
                      </div>
                    </div>
                  )
                )
              )
            : null}
        </>
      )}
    </>
  );
};
