'use client';

import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import React, { useEffect, useState } from 'react';
import ReactSelect, { components } from 'react-select';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox, Input, Text } from 'rizzui';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, Controller } from 'react-hook-form';
import Select from '@/components/ui/select';
import {
  getAllCommentsById,
  getAllTask,
  getTaskById,
  resetAllTaskData,
  setAllTaskData,
  setTaskReminder,
} from '@/redux/slices/user/task/taskSlice';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { taskTimeTrackedHistory } from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import moment from 'moment';
import { DatePicker } from '@/components/ui/datepicker';

const customData = [
  { value: 'minutes', label: 'Minutes before' },
  { value: 'hours', label: 'Hours before' },
  { value: 'days', label: 'Days before' },
];

const reminderOptions = [
  // { value: 'on_due_date', label: 'On due date' },
  { value: 'no_notify', label: "Don't notify" },
  { value: '10_min_before', label: '10 minutes before' },
  { value: '30_min_before', label: '30 minutes before' },
  { value: '1_hour_before', label: '1 hour before' },
  { value: '1_day_before', label: '1 day before' },
  { value: '2_day_before', label: '2 days before' },
  { value: '3_day_before', label: '3 days before' },
  { value: '1_week_before', label: '1 week before' },
  { value: '2_week_before', label: '2 weeks before' },
  { value: 'custom', label: 'Custom' },
];

const RepeatOptions = [
  // { value: 'on_due_date', label: 'On due date' },
  { value: 'no_repetition', label: 'No repetition' },
  {
    value: 'daily',
    label: 'Daily until the task is completed',
  },
  {
    value: 'weekly',
    label: 'Weekly until the task is completed',
  },
];

const customStyles = {
  control: (provided: any, state: any) => ({
    ...provided,
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    borderRadius: '8px',
    borderColor: state.isFocused ? 'black' : 'rgb(209 213 219)',
    boxShadow: state.isFocused ? 'none' : 'none', // Ensure no box-shadow on focus
    outline: 'none !important',
    padding: '0 8px',
    transition: 'border-color 0.2s ease',
    '&:hover': {
      borderColor: 'black', // Black border on hover
    },
  }),
  input: (provided: any) => ({
    ...provided,
    border: 'none !important',
    boxShadow: 'none !important',
    outline: 'none !important',
    caretColor: 'rgb(209 213 219)', // Ensures visible text cursor
  }),
  valueContainer: (provided: any) => ({
    ...provided,
    display: 'flex',
    alignItems: 'center',
    padding: '0 8px',
    gap: '8px',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  }),
  placeholder: (provided: any) => ({
    ...provided,
    color: 'rgb(209 213 219)',
    fontSize: '14px',
    fontWeight: '500',
    whiteSpace: 'nowrap',
  }),
  singleValue: (provided: any) => ({
    ...provided,
    fontWeight: '600',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  }),
  multiValue: (provided: any) => ({
    ...provided,
    backgroundColor: '#e1e7ff',
    borderRadius: '12px',
    padding: '2px 6px',
    display: 'flex',
    alignItems: 'center',
  }),
  multiValueLabel: (provided: any) => ({
    ...provided,
    fontSize: '12px',
    fontWeight: '500',
    color: '#4a4a4a',
  }),
  multiValueRemove: (provided: any) => ({
    ...provided,
    color: '#8c80d2',
    cursor: 'pointer',
    ':hover': {
      backgroundColor: '#e0e0e0',
      color: '#4a4a4a',
    },
  }),
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isFocused ? '#f3f4f6' : 'white',
    color: state.isSelected ? '#4a4a4a' : '#000',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: state.isSelected ? '600' : '400',
    ':active': {
      backgroundColor: '#e1e7ff',
    },
  }),
  menu: (provided: any) => ({
    ...provided,
    zIndex: 9999,
    borderRadius: '8px',
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
    marginTop: '4px',
  }),
  dropdownIndicator: (provided: any) => ({
    ...provided,
    color: '#8c80d2',
    ':hover': {
      color: '#4a4a4a',
    },
  }),
  indicatorSeparator: () => ({
    display: 'none !important',
  }),
};

export default function TaskReminder({
  onClose,
  rowData,
  shouldCloseDrawer,
  onTaskReminderClose,
  setSubTaskData,
  isAllTask = false,
  updateTask,
  isGridTaskView,
  isAllTaskGrid = false,
  AssigneeMembers,
  setAllSubtask,
}: {
  onClose: () => void;
  rowData?: any;
  shouldCloseDrawer?: any;
  onTaskReminderClose?: any;
  setSubTaskData?: any;
  isAllTask?: boolean;
  updateTask?: any;
  isGridTaskView?: any;
  isAllTaskGrid?: any;
  AssigneeMembers?: any;
  setAllSubtask?: any;
}) {
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const [selectedMembers, setSelectedMembers] = useState([]);
  // const [selectedRecipients, setSelectedRecipients] = useState<any>([]);

  console.log(AssigneeMembers, 'rowData12345');
  const { boardId, members, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  const {
    setReminderTaskloading,
    setReminderTaskStatus,
    gridView,
    oldTasks,
    oldTasksSections,
    data,
    allKanbanTasks,
  } = useSelector((state: any) => state?.root?.task);
  const [selectedReminder, setSelectedReminder] = useState({
    value: 'no_notify',
    label: "Don't notify",
  });
  const [selectedRepetition, setSelectedRepetition] = useState({
    value: 'no_repetition',
    label: 'No repetition',
    name: 'No repetition',
  });

  // console.log(isAllTask, data, allKanbanTasks, 'alltaskkk');

  const schema = z.object({
    reminder: z.string().optional(),
    repeat: z.string().optional(),
    reminder_user:
      selectedReminder?.value !== 'no_notify' ||
      selectedRepetition?.value !== 'no_repetition'
        ? z
            .array(z.string())
            .min(1, { message: 'At least one reminder user is required' })
        : z.array(z.string()).optional(),
    reminder_date:
      selectedReminder?.value === 'custom'
        ? z
            .union([z.date(), z.null()])
            .refine((date) => date !== null && !isNaN(date.getTime()), {
              message: 'Reminder date is required and must be a valid date',
            })
        : z.date().nullable().optional(),
  });

  type FormSchema = z.infer<typeof schema>;

  useEffect(() => {
    const assignToMembers =
      (rowData?.assign_to &&
        rowData?.assign_to?.length > 0 &&
        rowData?.assign_to?.map((member: any) => {
          return member?._id;
        })) ||
      [];
    setSelectedMembers(assignToMembers);
  }, [rowData]);
  console.log(assignees, 'assignees345');

  const clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          const team_name =
            capitalizeFirstLetter(team?.first_name) +
            ' ' +
            capitalizeFirstLetter(team?.last_name);
          return { ...team, name: team_name };
        })
      : [];

  const allOption = {
    label: 'Select all',
    value: '*',
    name: 'Select all',
  };
  const assigneeOptions = [
    ...(clientTeamAllOptions && clientTeamAllOptions.length > 0
      ? clientTeamAllOptions
          .filter(
            (member: Record<string, any>) =>
              AssigneeMembers.includes(member.user_id) // Filter by user_id
          )
          .map((assignee: Record<string, any>) => ({
            name: `${capitalizeFirstLetter(
              assignee?.first_name
            )} ${capitalizeFirstLetter(assignee?.last_name)}`,
            label: `${capitalizeFirstLetter(
              assignee?.first_name
            )} ${capitalizeFirstLetter(assignee?.last_name)}`,
            value: assignee?.user_id,
            key: assignee,
          }))
      : []),
  ];

  // 1. Create a helper to map selected IDs to option objects.
  const mapReminderUserIdsToOptions = (ids: string[]) =>
    assigneeOptions.filter((option) => ids.includes(option.value));

  const {
    control,
    register,
    handleSubmit,
    setValue,
    setError,
    watch,
    getValues,
    clearErrors,
    formState: { errors },
  } = useForm<FormSchema>({
    resolver: zodResolver(schema),
    defaultValues: {
      reminder: isAllTask
        ? data?.board_data?.reminder_option || 'no_notify'
        : isAllTaskGrid
          ? allKanbanTasks?.board_data?.reminder_option || 'no_notify'
          : rowData?.reminder_option || 'no_notify',
      repeat: isAllTask
        ? data?.board_data?.repeat || 'no_repetition'
        : isAllTaskGrid
          ? allKanbanTasks?.board_data?.repeat || 'no_repetition'
          : rowData?.repeat || 'no_repetition',
      reminder_user: isAllTask
        ? data?.board_data?.reminder_user || []
        : isAllTaskGrid
          ? allKanbanTasks?.board_data?.reminder_user || []
          : rowData?.reminder_user || [],
      reminder_date:
        isAllTask && data?.board_data?.reminder_date
          ? moment(data?.board_data?.reminder_date).toDate()
          : isAllTaskGrid && allKanbanTasks?.board_data?.reminder_date
            ? moment(allKanbanTasks?.board_data?.reminder_date).toDate()
            : rowData?.reminder_date
              ? moment(rowData?.reminder_date).toDate()
              : null,
    },
  });

  const [selectedRecipients, setSelectedRecipients] = useState<any>(() => {
    const initialIds = isAllTask
      ? data?.board_data?.reminder_user || []
      : isAllTaskGrid
        ? allKanbanTasks?.board_data?.reminder_user || []
        : rowData?.reminder_user || [];
    return mapReminderUserIdsToOptions(initialIds);
  });

  useEffect(() => {
    const selectedReminderOption = isAllTask
      ? reminderOptions?.find(
          (option) => option?.value === data?.board_data?.reminder_option
        )
      : isAllTaskGrid
        ? reminderOptions?.find(
            (option) =>
              option?.value === allKanbanTasks?.board_data?.reminder_option
          )
        : reminderOptions?.find(
            (option) => option?.value === rowData?.reminder_option
          );

    if (selectedReminderOption) {
      setSelectedReminder(selectedReminderOption);
    } else {
      setSelectedReminder({
        value: 'no_notify',
        label: "Don't notify",
      });
    }
  }, [
    isAllTask,
    rowData,
    data,
    allKanbanTasks,
    isAllTaskGrid,
    reminderOptions,
  ]);
  useEffect(() => {
    const selectedRepetOption: any = isAllTask
      ? RepeatOptions?.find(
          (option) => option?.value === data?.board_data?.repeat
        )
      : isAllTaskGrid
        ? RepeatOptions?.find(
            (option) => option?.value === allKanbanTasks?.board_data?.repeat
          )
        : RepeatOptions?.find((option) => option?.value === rowData?.repeat);

    if (selectedRepetOption) {
      setSelectedRepetition(selectedRepetOption);
    } else {
      setSelectedRepetition({
        value: 'no_repetition',
        label: 'No repetition',
        name: 'No repetition',
      });
    }
  }, [isAllTask, rowData, data, allKanbanTasks, isAllTaskGrid, RepeatOptions]);

  const onSubmit = (data: any) => {
    console.log('Form Data:', data);
    if (!isAllTask && !isAllTaskGrid) {
      const dueDate = rowData?.due_date;
      console.log(dueDate, '56777');
      const selectedReminderValue = data?.reminder;

      if (selectedReminderValue) {
        const dueMoment = moment(dueDate);
        let reminderTime: moment.Moment | null = null;

        // Determine reminder time based on selected reminder
        if (selectedReminderValue === '10_min_before') {
          reminderTime = dueMoment.subtract(10, 'minutes');
        } else if (selectedReminderValue === '30_min_before') {
          reminderTime = dueMoment.subtract(30, 'minutes');
        } else if (selectedReminderValue === '1_hour_before') {
          reminderTime = dueMoment.subtract(1, 'hour');
        } else if (selectedReminderValue === '1_day_before') {
          reminderTime = dueMoment.subtract(1, 'day');
        } else if (selectedReminderValue === '2_day_before') {
          reminderTime = dueMoment.subtract(2, 'day');
        } else if (selectedReminderValue === '3_day_before') {
          reminderTime = dueMoment.subtract(3, 'day');
        } else if (selectedReminderValue === '1_week_before') {
          reminderTime = dueMoment.subtract(1, 'week');
        } else if (selectedReminderValue === '2_week_before') {
          reminderTime = dueMoment.subtract(2, 'week');
        } else if (selectedReminderValue === 'custom') {
          const reminderDate = data?.reminder_date;
          if (reminderDate) {
            reminderTime = moment(reminderDate);
          }
        }

        // Check if the reminder time is in the past
        if (reminderTime && reminderTime.isBefore(moment())) {
          // Set the error for reminder if the time is in the past
          setError('reminder', {
            type: 'manual',
            message: 'Reminder time cannot be in the past',
          });
          return; // Stop form submission if the error is triggered
        }
      }
    }
    const reminderTaskData: any = {
      ...(isAllTask || isAllTaskGrid
        ? { board_id: boardId }
        : { task_id: rowData?._id }), // Use board_id for isAllTask or isAllTaskGrid, otherwise use task_id

      reminder_option: data?.reminder,
      repeat: data?.repeat,
      reminder_user: data?.reminder_user,

      // Corrected way to conditionally add reminder_date
      ...(data?.reminder === 'custom' && {
        reminder_date: data?.reminder_date ? String(data?.reminder_date) : null,
      }),
    };

    const updatedAssigneeObject =
      (clientTeamAllOptions &&
        clientTeamAllOptions?.length > 0 &&
        clientTeamAllOptions
          ?.filter((item: Record<string, any>, index: number) => {
            return (
              selectedMembers &&
              selectedMembers.length > 0 &&
              selectedMembers.includes(item?.user_id as never)
            );
          })
          ?.map((item, index) => {
            return { ...item, _id: item?.user_id };
          })) ||
      [];

    console.log(updatedAssigneeObject, 'updatedAssigneeObject');
    dispatch(setTaskReminder(reminderTaskData)).then((result: any) => {
      if (setTaskReminder.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          if (shouldCloseDrawer) {
            onTaskReminderClose();
            setSubTaskData(null);
            // Use your logic here to fetch task details like in useEffect
            // dispatch(getTaskById({ taskId: rowData?.parent_task })).then(
            //   (result: any) => {
            //     if (getTaskById?.fulfilled?.match(result)) {
            //       if (result && result?.payload?.success === true) {
            //         // You can handle success logic here if needed
            //       } else {
            //         onClose();
            //       }
            //     } else {
            //       onClose();
            //     }
            //   }
            // );
            setAllSubtask((prevSubtasks: any) =>
              prevSubtasks.map((subtask: any) =>
                subtask._id === result?.payload?.data?._id
                  ? { ...subtask, ...result?.payload?.data }
                  : subtask
              )
            );

            dispatch(taskTimeTrackedHistory(rowData?.parent_task));
            dispatch(getAllCommentsById({ task_id: rowData?.parent_task }));
            // if (gridView) {
            //   updateTask(
            //     defaulttask?._id,
            //     'decrease_subtask_count',
            //     { subtask: defaulttask },
            //     oldTasks,
            //     oldTasksSections
            //   );
            // }
          } else {
            onClose();
            if (isGridTaskView) {
              console.log(result, oldTasks, oldTasksSections, 'result567');
              // onClose();
              updateTask(
                rowData?._id,
                'task_update',
                {
                  oldTaskStatus: rowData?.status,
                  updated_task: {
                    ...result?.payload?.data,
                    assign_to: updatedAssigneeObject,
                    attachment_count:
                      result?.payload?.data?.attachments?.length,
                    comments_count: result?.payload?.data?.comment,
                    subtask_count: rowData?.sub_task_count,
                  },
                },
                oldTasks,
                oldTasksSections
              );
            } else {
              if (isAllTaskGrid) {
                dispatch(resetAllTaskData()); // ✅ Reset state first

                dispatch(
                  getAllTask({
                    search: '',
                    pagination: false,
                    board_id: boardId,
                    filter: '',
                    assignee_id: '',
                  })
                  // ).then;
                )
                  .unwrap()
                  .then((result: any) => {
                    if (result?.data) {
                      dispatch(setAllTaskData(result.data)); // ✅ Update state
                    }
                  })
                  .catch((error: any) => {
                    console.error('Error fetching all tasks:', error);
                  });
              } else {
                dispatch(
                  getAllTask({
                    page: 1,
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    board_id: boardId,
                    pagination: true,
                  })
                );
              }
            }
          }
        }
      }
    });

    console.log('Reminder Task Data:', reminderTaskData);
  };

  const handleCustomChange = (option: any) => {
    setSelectedReminder(option);

    // Set the value for the reminder field
    if (option?.value !== '') {
      setValue('reminder', option?.value);
      // If no recipients are selected and the reminder is not "no_notify", set an error
      if (selectedRecipients?.length === 0 && option?.value !== 'no_notify') {
        setError('reminder_user', {
          type: 'manual',
          message: 'At least one reminder user is required',
        });
      } else {
        clearErrors('reminder_user');
      }
    } else {
      setValue('reminder', '');
    }

    // Only perform validation if the conditions are met
    if (!isAllTask && !isAllTaskGrid) {
      const dueDate = rowData?.due_date;
      if (dueDate && option?.value) {
        const dueMoment = moment(dueDate);
        let reminderTime: moment.Moment | null = null;

        // Calculate the reminder time based on the selected value
        if (option?.value === '10_min_before') {
          reminderTime = dueMoment.subtract(10, 'minutes');
        } else if (option?.value === '30_min_before') {
          reminderTime = dueMoment.subtract(30, 'minutes');
        } else if (option?.value === '1_hour_before') {
          reminderTime = dueMoment.subtract(1, 'hour');
        } else if (option?.value === '1_day_before') {
          reminderTime = dueMoment.subtract(1, 'day');
        } else if (option?.value === '2_day_before') {
          reminderTime = dueMoment.subtract(2, 'day');
        } else if (option?.value === '3_day_before') {
          reminderTime = dueMoment.subtract(3, 'day');
        } else if (option?.value === '1_week_before') {
          reminderTime = dueMoment.subtract(1, 'week');
        } else if (option?.value === '2_week_before') {
          reminderTime = dueMoment.subtract(2, 'week');
        } else if (option?.value === 'custom') {
          const reminderDate = data?.reminder_date;
          if (reminderDate) {
            reminderTime = moment(reminderDate);
          }
        }

        // Validate if the reminder time is in the past
        if (reminderTime && reminderTime.isBefore(moment())) {
          setError('reminder', {
            type: 'manual',
            message: 'Reminder time cannot be in the past',
          });
        } else {
          clearErrors('reminder'); // Clear the error if the validation passes
        }
      }
    }
  };

  const validateCustomReminder = (customValue: any, customUnit: any) => {
    if (!isAllTask && !isAllTaskGrid) {
      // Only execute if the condition is true
      const dueDate = rowData?.due_date;
      if (dueDate) {
        const dueMoment = moment(dueDate);
        let reminderTime: moment.Moment | null = null;

        if (customValue && customUnit?.value) {
          reminderTime = dueMoment.subtract(customValue, customUnit.value);
        }

        // Validate if the reminder time is in the past
        if (reminderTime && reminderTime.isBefore(moment())) {
          setError('reminder', {
            type: 'manual',
            message: 'Reminder time cannot be in the past',
          });
        } else {
          clearErrors('reminder');
        }
      }
    }
  };

  const optionsWithSelectAll = [allOption, ...assigneeOptions];

  const ValueContainer = ({ children, ...props }: any) => {
    const selectedOptions = props.getValue();
    const hasSelections = selectedOptions.length > 0;

    // Determine the placeholder and truncate it if it’s too long during selected state
    let placeholder = props.selectProps.placeholder || 'Select';

    if (
      hasSelections &&
      placeholder === 'Select assignee' &&
      selectedOptions?.length > 0
    ) {
      // Truncate when displaying selected options count
      placeholder = `Select assignee`;
    } else if (hasSelections && placeholder.length > 15) {
      // Truncate if longer than 15 characters during selected state
      placeholder = `${placeholder.substring(0, 15)}...`;
    }

    return (
      <components.ValueContainer {...props}>
        <div className="flex items-center gap-2 whitespace-nowrap">
          {hasSelections ? (
            <div className="font-medium text-[#4a4a4a]">
              {placeholder}{' '}
              <span className="rounded-full bg-[#8c80d2] px-2 py-1 text-xs font-bold text-white">
                {selectedOptions.length.toString().padStart(2, '0')}
              </span>
            </div>
          ) : (
            <span className="text-[#4a4a4a]">{placeholder}</span>
          )}
          {React.cloneElement(children[1])}
        </div>
      </components.ValueContainer>
    );
  };

  const Option = (props: any) => {
    const { data, isSelected, selectOption, getValue } = props;
    const selectedValues = getValue().map((option: any) => option.value);
    const isAllSelected = selectedValues.length === assigneeOptions.length; // Check if all users are selected

    const handleChange = () => {
      if (data.value === allOption.value) {
        // If "Select All" is clicked, toggle selection
        if (isAllSelected) {
          selectOption([]); // Deselect all
        } else {
          selectOption(assigneeOptions); // Select all
        }
      } else {
        selectOption(data);
      }
    };

    return (
      <components.Option {...props}>
        <div
          className="flex cursor-pointer items-center gap-2"
          onClick={handleChange}
        >
          <Checkbox
            label={data.label}
            checked={
              data.value === allOption.value ? isAllSelected : isSelected
            }
            color="info"
            // variant="flat"
            inputClassName="checkbox-color"
            className=" cursor-pointer [&>label>span]:font-medium"
            labelClassName="text-1.20em md:text-1.20em lg:text-1.20em xl:text-1.20em text-gray-700 dark:text-gray-600 cursor-pointer"
          />
        </div>
      </components.Option>
    );
  };

  console.log(selectedRecipients, assigneeOptions, 'selectedRecipients111111');

  const MultiValue = (props: any) => (
    <components.MultiValue {...props}>
      <div className="flex items-center gap-2">
        {/* <img
            src={props.data.profile}
            alt={props.data.label}
            className="h-6 w-6 rounded-full"
          /> */}
        <span>{props.data.label}</span>
      </div>
    </components.MultiValue>
  );

  console.log(
    selectedReminder,
    isGridTaskView,
    allKanbanTasks,
    isAllTask,
    isAllTaskGrid,
    'selectedReminder2626262662'
  );

  return (
    <div className="px-6 py-6">
      <div className="flex items-center justify-between ">
        <Text className="text-[16px] font-semibold leading-[24px] text-[#141414]">
          Create reminder
        </Text>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={shouldCloseDrawer ? onTaskReminderClose : closeModal}
          className="p-0 text-[#141414] hover:text-[#8C80D2]"
        >
          <PiXBold className="h-[20px] w-[20px] " />
        </ActionIcon>
      </div>
      <div className="mt-4 flex flex-col gap-5">
        <form
          onSubmit={handleSubmit(onSubmit)}
          // className="rounded-md border border-gray-300 p-4"
        >
          {/* Recipients Field */}
          <div className="mb-3">
            <div className="flex items-center gap-2">
              <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                Recipients
              </span>
              <Controller
                control={control}
                name="reminder_user"
                render={({ field }) => (
                  <ReactSelect
                    {...field}
                    styles={customStyles}
                    options={optionsWithSelectAll}
                    isMulti
                    onChange={(selectedOptions: any) => {
                      const isAllSelected =
                        selectedOptions.length === assigneeOptions.length + 1; // +1 for "Select All"

                      if (isAllSelected) {
                        setValue('reminder_user', []);
                        setSelectedRecipients([]);
                        clearErrors('reminder_user');
                      } else if (
                        selectedOptions.some(
                          (option: any) => option.value === allOption.value
                        )
                      ) {
                        setValue(
                          'reminder_user',
                          assigneeOptions.map((option) => option.value)
                        );
                        setSelectedRecipients(assigneeOptions);
                        clearErrors('reminder_user');
                      } else {
                        setValue(
                          'reminder_user',
                          selectedOptions.map((option: any) => option.value)
                        );
                        setSelectedRecipients(selectedOptions);
                        clearErrors('reminder_user');
                      }
                    }}
                    closeMenuOnSelect={false}
                    hideSelectedOptions={false}
                    components={{
                      Option,
                      MultiValue,
                      ValueContainer,
                    }}
                    isClearable={false}
                    value={selectedRecipients}
                    className="poppins_font_number react-select-options task-assign w-auto"
                    classNamePrefix="custom-multi-select"
                    placeholder="Select assignee"
                  />
                )}
              />
            </div>

            {/* Ensure error message is outside the flex container */}
            {errors?.reminder_user && (
              <p className="mt-2 text-sm text-red-600">
                {errors.reminder_user.message}
              </p>
            )}
          </div>

          <div className="flex flex-row space-x-4">
            <div className="mb-5 flex flex-col items-start">
              <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                Reminder Time
              </span>
              <Select
                options={reminderOptions}
                onChange={(event) => handleCustomChange(event)}
                value={selectedReminder}
                // placeholder="Select Field"
                className="mt-2 w-auto"
                selectClassName="!text-[#141414] poppins_font_number !bg-white"
                // disabled={isDisable}
              />
              {errors?.reminder && (
                <p className="mt-2 text-sm text-red-600">
                  {errors.reminder.message}
                </p>
              )}
            </div>
            <div className="flex flex-col items-start">
              <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                Repeat
              </span>
              <Select
                options={RepeatOptions}
                onChange={(event: any) => {
                  setSelectedRepetition(event);
                  if (event?.value !== '') {
                    // Set reminder value
                    setValue('repeat', event?.value);

                    if (
                      selectedRecipients?.length === 0 &&
                      event?.value !== 'no_repetition'
                    ) {
                      setError('reminder_user', {
                        type: 'manual',
                        message: 'At least one recipient is required',
                      });
                    } else {
                      clearErrors('reminder_user');
                    }
                  }
                }}
                value={selectedRepetition}
                className="mt-2 w-auto"
                selectClassName="!text-[#141414] poppins_font_number !bg-white"
              />
              {errors?.repeat && (
                <p className="mt-2 text-sm text-red-600">
                  {errors.repeat.message}
                </p>
              )}
            </div>
          </div>
          {selectedReminder?.value === 'custom' && (
            <div className="task_form_date_picker_close_button_hide mb-3 flex flex-col items-start">
              <span className="text-[14px] font-medium leading-[16.8px] text-[#111928]">
                Select Reminder Date & Time
              </span>
              <Controller
                name="reminder_date"
                control={control}
                render={({ field: { value, onChange } }) => (
                  <DatePicker
                    selected={value}
                    placeholderText={'Select reminder date'}
                    onChange={onChange}
                    selectsStart
                    startDate={value}
                    minDate={new Date()}
                    showTimeSelect
                    isClearable={true}
                    popperPlacement="bottom-end"
                    className="mt-2 w-[430px] bg-[#F9FAFB]"
                    dateFormat="MMMM d, yyyy h:mm aa"
                    inputProps={{
                      inputClassName: 'font-sans', // Custom class for the input
                    }}
                  />
                )}
              />
              {errors?.reminder_date && (
                <p className="mt-2 text-sm text-red-600">
                  {errors.reminder_date.message}
                </p>
              )}
            </div>
          )}

          <div className="flex w-[250px] gap-3">
            <Button
              className="cursor-pointer rounded-lg border border-[#E5E7EB] bg-white text-sm text-[#141414]"
              size="DEFAULT"
              type="button"
              onClick={() => {
                onClose();
                setValue('reminder_date', null);
                setValue('reminder', 'no_notify');
                setSelectedReminder({
                  value: 'no_notify',
                  label: "Don't notify",
                });
                setSelectedRepetition({
                  value: 'no_repetition',
                  label: 'No repetition',
                  name: 'No repetition',
                });
                setValue('repeat', 'no_repetition');
                setValue('reminder_user', []);
                setSelectedRecipients([]);
              }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="cursor-pointer rounded-lg bg-[#7667CF] text-[14px] font-normal leading-[19.6px] text-[#FFFFFF]"
              size="DEFAULT"
              disabled={
                setReminderTaskStatus === 'pending' || setReminderTaskloading
              }
              rounded="pill"
            >
              Save reminder
              {(setReminderTaskStatus === 'pending' ||
                setReminderTaskloading) && (
                <Spinner size="sm" tag="div" className="ms-2" color="white" />
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
