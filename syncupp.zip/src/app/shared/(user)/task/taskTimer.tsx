import { calculateTotalTimeInSeconds, formatTime } from "@/utils/common-functions";
import { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";

const TimerDisplay = () => {
    const [time, setTime] = useState(0);
    const { activeTimerData } = useSelector(
        (state: any) => state?.root?.timeTracking
      );
    useEffect(() => {
      if (Object?.keys(activeTimerData).length > 0) {
  
        setTime(
          calculateTotalTimeInSeconds(
            activeTimerData?.new_log?.clock_in,
            new Date()
          ) * 1000
        );
      }
    }, [activeTimerData, ]);
  
    useEffect(() => {
      const timer = setInterval(() => {
        setTime((prevTime) => prevTime + 1000);
      }, 1000);
      return () => clearInterval(timer);
    }, []);
  
    const displayTime = useMemo(() => formatTime(time), [time]);
  
    return <div>{displayTime}</div>;
  };

export default TimerDisplay;