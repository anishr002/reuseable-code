"use client";
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import { Popover } from '@/components/ui/popover';
import { Title, Text } from '@/components/ui/text';
import { PiCaretDownBold, PiDotsThreeOutlineVerticalFill, PiMapPin, PiXBold } from "react-icons/pi";
import { BsPersonFill } from "react-icons/bs";
import { FaPeopleGroup } from "react-icons/fa6";
import { Tooltip } from '@/components/ui/tooltip';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { MdDateRange, MdOutlineCalendarMonth } from 'react-icons/md';
import { FaUserCircle } from 'react-icons/fa';
import { Badge, Textarea } from 'rizzui';
import { useDispatch, useSelector } from 'react-redux';
import { getAllTask, getTaskById, putTaskStatusChange } from '@/redux/slices/user/task/taskSlice';
import moment from 'moment';
import Select from '@/components/ui/select';
import { useEffect, useState } from 'react';
import Spinner from '@/components/ui/spinner';
import cn from '@/utils/class-names';
import { usePathname } from 'next/navigation';
import AddActivityFormPage from '../../calender/create-edit-event/create-edit-activity-form';
import { getAllActivity } from '@/redux/slices/user/activity/activitySlice';
import SimpleBar from 'simplebar-react';
import { TbCalendarDue } from 'react-icons/tb';
import { getFileType } from '@/utils/common-functions';
import { CustomFileIcons } from '@/app/shared/custom-file-icon';



const statusOptions = [
  {
    value: 'pending',
    name: 'Pending',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="warning" renderAsDot />
        <Text className="font-medium text-orange-dark">Pending</Text>
      </div>
    ),
  },
  {
    value: 'in_progress',
    name: 'In Progress',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color='secondary' renderAsDot />
        <Text className="font-medium text-secondary-dark">In Progress</Text>
      </div>
    ),
  },
  {
    value: 'completed',
    name: 'Completed',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="font-medium text-green-dark">Completed</Text>
      </div>
    ),
  },
];

const meetingStatusOptions = [
  {
    value: 'completed',
    name: 'Completed',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="font-medium text-green-dark">Completed</Text>
      </div>
    ),
  },
  {
    value: 'cancel',
    name: 'Canceled',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="font-medium text-red-dark">Canceled</Text>
      </div>
    ),
  },
];

const defaultOptions = [
  {
    value: 'pending',
    name: 'Pending',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="warning" renderAsDot />
        <Text className="font-medium text-orange-dark">Pending</Text>
      </div>
    ),
  },
  {
    value: 'in_progress',
    name: 'In Progress',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color='secondary' renderAsDot />
        <Text className="font-medium text-secondary-dark">In Progress</Text>
      </div>
    ),
  },
  {
    value: 'completed',
    name: 'Completed',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="font-medium text-green-dark">Completed</Text>
      </div>
    ),
  },
  {
    value: 'overdue',
    name: 'Overdue',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="font-medium text-red-dark">Overdue</Text>
      </div>
    ),
  },
  {
    value: 'cancel',
    name: 'Canceled',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="font-medium text-red-dark">Canceled</Text>
      </div>
    ),
  },
];


function getStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'pending':
      return (
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <Badge color="warning" renderAsDot />
          <Text className="font-medium text-orange-dark">Pending</Text>
        </div>
      );
    case 'completed':
      return (
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <Badge color="success" renderAsDot />
          <Text className="font-medium text-green-dark">Completed</Text>
        </div>
      );
    case 'overdue':
      return (
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <Badge color="danger" renderAsDot />
          <Text className="font-medium text-red-dark">Overdue</Text>
        </div>
      );
    case 'in_progress':
      return (
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <Badge color='secondary' renderAsDot />
          <Text className="font-medium text-secondary-dark">In Progress</Text>
        </div>
      );
    case 'cancel':
      return (
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <Badge color="danger" renderAsDot />
          <Text className="font-medium text-red-dark">Canceled</Text>
        </div>
      );
    default:
      return (
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="font-medium text-gray-600">{status}</Text>
        </div>
      );
  }
}

export default function ViewTaskForm(props: any) {
  const { data, isCalendarViewActivity } = props;
  // console.log("data in task card", data)

  const { openModal, closeModal } = useModal();
  const pathname = usePathname();
  const dispatch = useDispatch();
  const { gridView } = useSelector((state: any) => state?.root?.task);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const taskData = useSelector((state: any) => state?.root?.task);
  const { } = useSelector((state: any) => state?.root?.activity);
  const { calendarView, paginationParams, userReferenceId } = useSelector((state: any) => state?.root?.activity);
  let { page, items_per_page, sort_field, sort_order, search, filter } = paginationParams;
  const { boardId } = useSelector((state: any) => state?.root?.board);


  const [selectedStatus, setSelectedStatus] = useState<any>(null);


  const firstDayOfMonth = moment().startOf('month').format('DD-MM-YYYY');
  const endDayOfMonth = moment().endOf('month').format('DD-MM-YYYY');

  useEffect(() => {
    data && !isCalendarViewActivity && dispatch(getTaskById({ taskId: data?._id })).then((result: any) => {
      if (getTaskById.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
        }
      }
    });
    data && isCalendarViewActivity && dispatch(getTaskById({ taskId: data?.id })).then((result: any) => {
      if (getTaskById.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
        }
      }
    });
  }, [data, dispatch, isCalendarViewActivity]);

  let [dataa] = taskData?.task ?? [{}];

  // function handleEditModal() {
  //   closeModal(),
  //     openModal({
  //       // view: <EventForm event={event} />,
  //       view: <AddActivityFormPage title="Edit Meeting" isViewActivityEdit={true} row={dataa} isTaskModule={false} isClientEdit={pathname.startsWith('/client/details') || pathname.startsWith('/client-team/details')} isClientTeam={pathname.startsWith('/client-team/details')} isTeamEdit={pathname.startsWith('/agency-team/details')} />,
  //       customSize: '1050px',
  //     });
  // }

  const handleEditModal = () => {

    if (pathname?.startsWith('/tasks/board')) {
      closeModal(),
        openModal({
          // view: <EventForm event={event} />,
          view: <AddActivityFormPage title="Edit Task" isViewActivityEdit={true} row={dataa} isTaskModule={true} isClientEdit={pathname.startsWith('/client/details') || pathname.startsWith('/client-team/details')} isClientTeam={pathname.startsWith('/client-team/details')} isTeamEdit={pathname.startsWith('/agency-team/details')} />,
          customSize: '1050px',
        });
    } else {
      closeModal(),
        openModal({
          // view: <EventForm event={event} />,
          view: <AddActivityFormPage title="Edit Meeting" isViewActivityEdit={true} row={dataa} isTaskModule={false} isClientEdit={pathname.startsWith('/client/details') || pathname.startsWith('/client-team/details')} isClientTeam={pathname.startsWith('/client-team/details')} isTeamEdit={pathname.startsWith('/agency-team/details')} />,
          customSize: '1050px',
        });
    }


  }


  useEffect(() => {
    if (dataa?.status) {
      const status = dataa.status;
      const defaultOption = defaultOptions.find(option => option.value === status);
      setSelectedStatus(defaultOption || defaultOptions[0]);
    }
  }, [dataa?.status])


  const handleApiCall = (statusData: Record<string, string>) => {

    dispatch(putTaskStatusChange({ _id: statusData?._id, status: statusData?.status })).then((result: any) => {
      if (putTaskStatusChange.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          closeModal()

          if (gridView && pathname?.startsWith('/tasks/board')) {
            dispatch(getAllTask({ board_id: boardId, pagination: false }))
          } else if (!gridView && pathname?.startsWith('/tasks/board')) {
            dispatch(getAllTask({ page, items_per_page, sort_field, sort_order, search, board_id: boardId, pagination: true }))
          } else if (calendarView && pathname === '/meetings') {
            dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', filter: { date: 'period', start_date: firstDayOfMonth, end_date: endDayOfMonth }, pagination: false }))
          } else if (!calendarView && pathname === '/meetings') {
            dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, filter, pagination: true }))
          } else if (pathname.startsWith('/client/details')) {
            dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, client_id: userReferenceId, filter, pagination: true }))
          } else if (pathname.startsWith('/agency-team/details')) {
            dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, team_id: userReferenceId, filter, pagination: true }))
          } else if (pathname.startsWith('/client-team/details')) {
            dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, client_team_id: userReferenceId, filter, pagination: true }))
          }

        }
      }
    });

  }

  if (!taskData?.task) {
    return (
      <div className='p-10 flex items-center justify-center'>
        <Spinner size="xl" tag='div' className='ms-3' />
      </div>
    )
  } else {
    return (
      <>
        <div className="p-[1.5rem] h-full w-full overflow-y-auto overflow-x-hidden whitespace-pre-wrap">
          <div className="flex items-center">
            <Title as="h3" className="text-xl xl:text-2xl w-full">
              {dataa?.title?.charAt(0)?.toUpperCase() + dataa?.title?.slice(1)}
            </Title>
            <div className='ms-auto flex items-center gap-3'>
              {/* <div>
                {getStatusBadge(dataa?.status)}
              </div>
              {(signIn?.role !== 'client' && signIn?.role !== 'team_client') &&
                <div>
                  {dataa?.activity_type?.name === 'task' &&
                    <Popover
                      placement="bottom"
                      className=" min-w-[135px] px-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100 demo_test"
                      content={({ setOpen }) => (
                        <div className="px-2 text-gray-900">
                          <Button
                            variant="text"
                            onClick={() => handleApiCall({ _id: dataa?._id, status: 'pending' })}
                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                          >
                            Pending
                          </Button>
                          <Button
                            variant="text"
                            onClick={() => handleApiCall({ _id: dataa?._id, status: 'in_progress' })}
                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                          >
                            In Progress
                          </Button>
                          <Button
                            variant="text"
                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                            onClick={() => handleApiCall({ _id: dataa?._id, status: 'overdue' })}
                          >
                            Overdue
                          </Button>
                          <Button
                            variant="text"
                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                            onClick={() => handleApiCall({ _id: dataa?._id, status: 'completed' })}
                          >
                            Complete
                          </Button>
                        </div>
                      )}
                    >
                      <ActionIcon title={'More Options'} variant="text">
                        <PiDotsThreeOutlineVerticalFill className="h-5 w-5 text-gray-500" />
                      </ActionIcon>
                    </Popover>
                  }
                  {(dataa?.activity_type?.name === 'call_meeting' || dataa?.activity_type?.name === 'others') && dataa?.status !== 'completed' && dataa?.status !== 'cancel' &&
                    <Popover
                      placement="bottom"
                      className=" min-w-[135px] px-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100 demo_test"
                      content={({ setOpen }) => (
                        <div className="px-2 text-gray-900">
                          <Button
                            variant="text"
                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                            onClick={() => handleApiCall({ _id: dataa?._id, status: 'completed' })}
                          >
                            Complete
                          </Button>
                          <Button
                            variant="text"
                            className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                            onClick={() => handleApiCall({ _id: dataa?._id, status: 'cancel' })}
                          >
                            Cancel
                          </Button>
                        </div>
                      )}
                    >
                      <ActionIcon title={'More Options'} variant="text">
                        <PiDotsThreeOutlineVerticalFill className="h-5 w-5 text-gray-500" />
                      </ActionIcon>
                    </Popover>
                  }
                </div>
              } */}
              <ActionIcon
                size="sm"
                variant="text"
                onClick={() => closeModal()}
                className="p-0 text-gray-500 hover:!text-gray-900"
              >
                <PiXBold className="h-[18px] w-[18px]" />
              </ActionIcon>
            </div>
          </div>

          <div>
            <div className="mt-[6px] flex flex-col gap-[4px] text-gray-600">
              {dataa && dataa?.activity_type?.name === 'task' && dataa?.tags?.length > 0 &&
                <div>
                  {
                    dataa && dataa?.tags?.length > 0 ? dataa?.tags?.map((valuee: Record<string, string>, index: any) => {
                      return (
                        <div key={index} className='inline-block mb-2 me-2'>
                          <Button
                            size="sm"
                            tag="span"
                            variant="outline"
                            rounded='pill'
                            className="w-auto font-medium"
                            style={{ color: valuee?.color, border: `2px solid ${valuee?.color}` }}
                          // color={statusColors()}
                          // data-color={statusColors()}
                          >
                            {valuee?.name}
                          </Button>
                        </div>
                      )
                    }) : null
                  }
                </div>
              }

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:gap-5 xl:pb-2">
                <div className="flex items-center gap-2">
                  <span className="text-gray-1000 capitalize">Assigned To: </span>
                  <span className="font-medium text-gray-1000 capitalize">
                    {dataa?.assigned_to_name}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-1000 capitalize">Assigned By: </span>
                  <span className="font-medium text-gray-1000 capitalize">
                    {dataa?.assigned_by_name}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:gap-5 xl:pb-2">
                <div className="flex items-center gap-2">
                  <span className=" text-gray-1000 capitalize">Status: </span>
                  {/* <span className="font-medium text-gray-1000 capitalize">
                    {dataa?.client_name}
                  </span> */}
                  {(signIn?.role !== 'client' && signIn?.role !== 'team_client') ? (
                    <div className='w-[9rem]'>
                      {dataa?.activity_type?.name === 'task' ? (
                        <Select
                          // size="sm"
                          variant="text"
                          value={selectedStatus}
                          onChange={(selectedOption: any) => {
                            setSelectedStatus(selectedOption);
                            handleApiCall({ _id: dataa?._id, status: selectedOption?.value })
                          }}
                          options={statusOptions}
                          placeholder="Status"
                          // displayValue={statusValue}
                          // placement="bottom-end"
                          // useContainerWidth={false}
                          dropdownClassName="p-2 gap-1 grid text-red"
                          suffix={<PiCaretDownBold className="h-3 w-3" />}
                        />
                      ) : (
                        <div>
                          {(dataa?.activity_type?.name === 'call_meeting' || dataa?.activity_type?.name === 'others') && dataa?.status !== 'completed' && dataa?.status !== 'cancel' ? (
                            <Select
                              // size="sm"
                              variant="text"
                              value={selectedStatus}
                              onChange={(selectedOption: any) => {
                                setSelectedStatus(selectedOption);
                                handleApiCall({ _id: dataa?._id, status: selectedOption?.value })
                              }}
                              options={meetingStatusOptions}
                              placeholder="Status"
                              // displayValue={statusValue}
                              // placement="bottom-end"
                              // useContainerWidth={false}
                              dropdownClassName="p-2 gap-1 grid text-red"
                              suffix={<PiCaretDownBold className="h-3 w-3" />}
                            />
                          ) : (
                            <div className='w-full'>
                              {getStatusBadge(dataa?.status)}
                            </div>
                          )
                          }
                        </div>
                      )
                      }

                    </div>
                  ) : (
                    <div className='w-full'>
                      {getStatusBadge(dataa?.status)}
                    </div>
                  )
                  }
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-1000 capitalize">Client: </span>
                  <span className="font-medium text-gray-1000 capitalize">
                    {dataa?.client_name ? dataa?.client_name : '-'}
                  </span>
                </div>
              </div>
              {dataa?.activity_type?.name === 'task' &&
                <div className="flex flex-col gap-1">
                  <span className="text-gray-1000 capitalize">Description: </span>
                  {(dataa?.agenda && dataa?.agenda !== "<p><br></p>" && dataa?.agenda !== "undefined") ? (
                    <div className='border-2 rounded-md p-1 [&_.simplebar-content:before]:content-none [&_.simplebar-content:after]:content-none'>
                      <SimpleBar className="max-h-[100px] w-full p-0">
                        <div className="text-gray-1000" dangerouslySetInnerHTML={{ __html: dataa?.agenda }}>

                        </div>
                        {/* <span className="font-medium text-gray-1000 capitalize"> */}
                        {/* {dataa?.agenda && dataa?.agenda?.slice(3, dataa?.agenda?.length - 4)} */}
                        {/* <p dangerouslySetInnerHTML={{ __html: dataa?.agenda }}></p> */}
                        {/* </span> */}
                      </SimpleBar>
                      {/* <Textarea
                          placeholder="Add your internal note and location..."
                          value={dataa?.agenda}
                          disabled
                        // textareaClassName="h-20"
                        // className="col-span-2"
                      /> */}
                    </div>
                  ) : (<span className="font-medium text-gray-1000 capitalize">N/A</span>)
                  }
                </div>
              }

              {(dataa?.activity_type?.name === 'call_meeting' || dataa?.activity_type?.name === 'others') &&
                <div className="flex flex-col gap-1">
                  <span className="text-gray-1000 capitalize">Description: </span>
                  {(dataa?.agenda && dataa?.agenda !== "<p><br></p>" && dataa?.agenda !== "undefined") ? (
                    <div className='border-2 rounded-md p-1 [&_.simplebar-content:before]:content-none [&_.simplebar-content:after]:content-none'>
                      <SimpleBar className="max-h-[100px] w-full">
                        <div className="text-gray-1000 capitalize" dangerouslySetInnerHTML={{ __html: dataa?.agenda }}>

                        </div>
                      </SimpleBar>
                    </div>
                  ) : (<span className="font-medium text-gray-1000 capitalize">N/A</span>)
                  }
                </div>
              }

              {dataa?.activity_type?.name === 'task' &&
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:gap-5 xl:pb-2 mt-[8px]">
                  <div className="flex items-center gap-2" title='Due Date'>
                    <TbCalendarDue className="h-5 w-5" />
                    {/* <span className="font-medium text-gray-1000">:</span> */}
                    <span className="font-medium text-gray-1000">
                      {moment(new Date(dataa?.due_date)).format('MMMM D, YYYY')} at{' '}
                      {moment(new Date(dataa?.due_date)).format('h:mm A')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2" title='Created Date'>
                    <MdDateRange className="h-5 w-5" />
                    {/* <span className="font-medium text-gray-1000">:</span> */}
                    <span className="font-medium text-gray-1000">
                      {moment(new Date(dataa?.createdAt)).format('MMMM D, YYYY')} at{' '}
                      {moment(new Date(dataa?.createdAt)).format('h:mm A')}
                    </span>
                  </div>
                </div>
              }
              {(dataa?.activity_type?.name === 'call_meeting' || dataa?.activity_type?.name === 'others') &&
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:gap-5 xl:pb-2 mt-[8px]">
                  <div className="flex items-center gap-2" title='Start Date & Time'>
                    {/* <TbCalendarDue className="h-5 w-5" /> */}
                    <span className="text-gray-1000 capitalize">Start Date Time:</span>
                    <span className="font-medium text-gray-1000">
                      {moment(new Date(dataa?.due_date)).format('MMMM D, YYYY')} at{' '}
                      {moment(new Date(dataa?.meeting_start_time)).format('h:mm A')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2" title='End Date & Time'>
                    {/* <MdDateRange className="h-5 w-5" /> */}
                    <span className="text-gray-1000 capitalize">End Date Time:</span>
                    <span className="font-medium text-gray-1000">
                      {dataa?.recurring_end_date ? moment(new Date(dataa?.recurring_end_date)).format('MMMM D, YYYY') : moment(new Date(dataa?.due_date)).format('MMMM D, YYYY')} at{' '}
                      {moment(new Date(dataa?.meeting_end_time)).format('h:mm A')}
                    </span>
                  </div>
                </div>
              }

              {dataa?.activity_type?.name === 'task' && dataa?.attachments?.length > 0 &&
                <div className="flex items-center gap-2 mt-[8px]">
                  <span className="text-gray-1000 capitalize">Attachments: </span>
                  {dataa?.attachments && dataa?.attachments?.length > 0 &&
                    dataa?.attachments?.map((file: any, index: any) => {
                      return (<a key={index} href={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${file}`} target='_blank' className="font-medium text-gray-1000">
                        <CustomFileIcons
                          key={index}
                          fileType={getFileType(file)}
                        />
                      </a>)
                    })
                  }
                </div>
              }
              {(dataa?.activity_type?.name === 'call_meeting' || dataa?.activity_type?.name === 'others') &&
                <div className="flex gap-2">
                  <span className=' text-gray-1000 capitalize'>Attendees: </span>
                  <div className='block w-full'>
                    {dataa && dataa?.attendees && dataa?.attendees?.length > 0 ? dataa?.attendees?.map((attendee: any, index: any) => {
                      return (
                        <div key={index} className='inline-block mb-1 me-1'>
                          <Button
                            size="sm"
                            tag="span"
                            variant="outline"
                            rounded='pill'
                            className="w-auto font-medium"
                          // style={{ color: valuee?.color, border: `2px solid ${valuee?.color}` }}
                          // color={statusColors()}
                          // data-color={statusColors()}
                          >
                            {attendee?.email}
                          </Button>
                        </div>
                      )
                    }) : (<span className="font-medium text-gray-1000">N/A</span>)}
                  </div>
                </div>
              }
              {(dataa?.activity_type?.name === 'call_meeting' || dataa?.activity_type?.name === 'others') &&
                <div className="flex flex-col gap-1 mb-[10px]">
                  <span className='text-gray-1000 capitalize'>Internal Note & Location: </span>
                  {dataa?.internal_info ? (
                    <div className='border-2 rounded-md p-1 [&_.simplebar-content:before]:content-none [&_.simplebar-content:after]:content-none'>
                      <SimpleBar className="max-h-[100px] w-full before:p-0">
                        <span className="text-gray-1000">
                          {dataa?.internal_info ?? '-'}
                        </span>
                      </SimpleBar>
                    </div>
                  ) : (<span className="font-medium text-gray-1000">N/A</span>)
                  }
                </div>
              }

            </div>
            {(signIn?.role !== 'client' && signIn?.role !== 'team_client') &&
              <div>
                {(dataa?.status !== 'completed' && dataa?.status !== 'cancel') &&
                  <div className='ms-auto text-end'>
                    <Button
                      className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
                      onClick={handleEditModal}
                    >
                      Edit
                    </Button>
                  </div>
                }
              </div>
            }
          </div>
        </div>
      </>
    );
  }
}



