import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { getAllMyTasks } from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  getAllTask,
  postBulkTasksUpdate,
} from '@/redux/slices/user/task/taskSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { usePathname } from 'next/navigation';
import {
  FiCheckCircle,
  FiFlag,
  FiTrash2,
  FiUserPlus
} from 'react-icons/fi';
import { MdTimelapse } from 'react-icons/md';
import { PiTrashFill } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Popover, Text, Title, Tooltip } from 'rizzui';
import BulkTasksAssigneeUpdateModal from './bulk-tasks-assignee-update-modal';

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E5E7EB]',
    label: (
      <div className="flex h-[30px] w-[100px] items-center justify-center gap-2 rounded-[18.39px] bg-[#E5E7EB] px-6 py-2 text-[13px]">
        <span className="font-semibold text-[#111928]">Low</span>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FFF3B6]',
    label: (
      <div className="flex h-[30px] w-[100px] items-center justify-center gap-2 rounded-[18.39px] bg-[#FFF3B6] px-6 py-2 text-[13px]">
        <span className="font-semibold text-[#9A6F00]">Medium</span>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFEFF1]',
    label: (
      <div className="flex h-[30px] w-[100px] items-center justify-center gap-2 rounded-[18.39px] bg-[#FFEFF1] px-6 py-2 text-[13px]">
        <span className="font-semibold text-[#C92F54]">High</span>
      </div>
    ),
  },
];

const BulkTasksUpdateOptions = ({
  selectedRowKeys,
  setSelectedRowKeys,
}: {
  selectedRowKeys?: any;
  setSelectedRowKeys?: any;
}) => {
  console.log('selectedRowKeys.....', selectedRowKeys);
  const dispatch = useDispatch();
  const { openModal } = useModal();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { sections, boardId } = useSelector((state: any) => state?.root?.board);
  const { paginationParams: allTasksPaginationParams } = useSelector(
    (state: any) => state?.root?.client
  );
  const { postBulkTasksUpdateLoader, paginationParams } = useSelector(
    (state: any) => state.root.task
  );

  console.log(
    'board sections.....',
    sections,
    'paginationParams....',
    paginationParams,
    'allTasksPaginationParams.....',
    allTasksPaginationParams
  );

  // Module check variables
  const isAllTasksModule = usePathname().includes('/my-tasks');
  const isTasksModule = usePathname().includes('/tasks/board');
  console.log('isAllTasksModule.....', isAllTasksModule);
  console.log('isTasksModule.....', isTasksModule);

  // Module parmission check for task update & delete task
  const canUpdateTask =
    ['agency'].includes(signIn?.role) ||
    (['team_agency'].includes(signIn?.role) &&
      checkPermission('projects', 'tasks', 'update', signIn?.permission));
  const canDeleteTask =
    ['agency'].includes(signIn?.role) ||
    (['team_agency'].includes(signIn?.role) &&
      checkPermission('projects', 'tasks', 'delete', signIn?.permission));
  console.log('canUpdateTask.....', canUpdateTask);
  console.log('canDeleteTask.....', canDeleteTask);

  // board status options list
  // status dropdown options - dynamic - not included completed and archived
  const statusOptions: Record<string, any>[] =
    sections && sections?.length > 0
      ? sections
          ?.filter(
            (section: Record<string, any>) =>
              section?.key !== 'completed' && section?.key !== 'archived'
          ) // Filter out 'completed' and 'archived' sections
          ?.map((section: Record<string, any>) => {
            return {
              value: section?._id,
              name: capitalizeFirstLetter(section?.section_name),
              label: (
                <div
                  className="flex items-center gap-2 rounded-3xl px-[15px] py-[8px] text-xs sm:text-sm"
                  style={{ backgroundColor: section?.color }}
                >
                  <div
                    title={section?.section_name} // Tooltip to show full text
                    className="font-medium"
                    style={{ color: section?.test_color }}
                  >
                    {section?.section_name ?? ''}
                  </div>
                </div>
              ),
              section,
              key: section?.key,
            };
          })
      : [];
  console.log('board statusOptions customize.....', statusOptions);

  // handle task bulk update api call function
  const handleTaskBulkUpdate = (
    payload: any,
    action: string,
    setOpen?: any
  ) => {
    console.log('action.....', action, 'payload.....', payload);
    dispatch(
      postBulkTasksUpdate({
        task_ids: selectedRowKeys ?? [],
        ...payload,
      })
    ).then((result: any) => {
      if (postBulkTasksUpdate.fulfilled.match(result)) {
        if (result?.payload?.success === true) {
          if (typeof setOpen === 'function') {
            setOpen(false);
          }
          if (action === 'mark_as_complete' || action === 'mark_as_delete') {
            if (isAllTasksModule) {
              dispatch(
                getAllMyTasks({
                  ...allTasksPaginationParams,
                  page: 1,
                })
              );
            }
          }
          typeof setSelectedRowKeys === 'function' && setSelectedRowKeys([]);
        }
      }
    });
  };

  return (
    <div className="flex min-h-11 max-w-[320px] items-center justify-between gap-2.5 rounded-[10px] bg-[#1F2A37] px-5 py-2.5 md:w-[320px]">
      <div className="text-sm font-normal text-white">{`${
        selectedRowKeys?.length ?? 0
      } task${selectedRowKeys?.length > 1 ? 's' : ''} selected`}</div>
      <div className="flex items-center gap-4">
        {/* Mark as complete button */}
        <Tooltip
          size="sm"
          content={() => (
            <div className="text-[#1F2A37]">{'Mark as completed'}</div>
          )}
          placement="top"
          className="rounded-lg bg-[#F3F4F6]"
          tooltipArrowClassName="!text-[#F3F4F6]"
          color="invert"
        >
          <button
            className="cursor-pointer !bg-none"
            type="button"
            onClick={() =>
              handleTaskBulkUpdate({ mark_as_done: true }, 'mark_as_complete')
            }
            disabled={postBulkTasksUpdateLoader}
          >
            <FiCheckCircle className="h-4 w-4 text-[#F3F4F6]" />
          </button>
        </Tooltip>
        {/* Tasks assignee update button */}
        {canUpdateTask && (
          <Tooltip
            size="sm"
            content={() => (
              <div className="text-[#1F2A37]">{'Assign these tasks'}</div>
            )}
            placement="top"
            className="rounded-lg bg-[#F3F4F6]"
            tooltipArrowClassName="!text-[#F3F4F6]"
            color="invert"
          >
            <button
              className="cursor-pointer !bg-none"
              type="button"
              disabled={postBulkTasksUpdateLoader}
              onClick={() => {
                openModal({
                  view: (
                    <BulkTasksAssigneeUpdateModal
                      selectedRowKeys={selectedRowKeys}
                      setSelectedRowKeys={setSelectedRowKeys}
                      isAllTasksModule={isAllTasksModule}
                    />
                  ),
                  customSize: '600px',
                });
              }}
            >
              <FiUserPlus className="h-4 w-4 text-[#F3F4F6]" />
            </button>
          </Tooltip>
        )}
        {/* Tasks priority update button */}
        {canUpdateTask && (
          <Tooltip
            size="sm"
            content={() => (
              <div className="text-[#1F2A37]">{'Change priority'}</div>
            )}
            placement="top"
            className="rounded-lg bg-[#F3F4F6]"
            tooltipArrowClassName="!text-[#F3F4F6]"
            color="invert"
          >
            <div className="flex items-center justify-center">
              <Popover
                placement="bottom"
                className="demo_test border-none bg-white p-2 shadow-md dark:bg-gray-100"
                content={({ setOpen }) => {
                  return (
                    <div className="flex flex-col gap-2">
                      {priorityOptions?.map((option: any) => (
                        <button
                          key={option?.value}
                          type="button"
                          // disabled={taskLoading}
                          onClick={() =>
                            handleTaskBulkUpdate(
                              { priority: option?.value },
                              'priority_update',
                              setOpen
                            )
                          }
                          disabled={postBulkTasksUpdateLoader}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  );
                }}
              >
                <button
                  className="cursor-pointer !bg-none"
                  type="button"
                  disabled={postBulkTasksUpdateLoader}
                >
                  <FiFlag className="h-4 w-4 text-[#F3F4F6]" />
                </button>
              </Popover>
            </div>
          </Tooltip>
        )}
        {/* Tasks status update button */}
        {!isAllTasksModule && (
          <Tooltip
            size="sm"
            content={() => (
              <div className="text-[#1F2A37]">{'Change status'}</div>
            )}
            placement="top"
            className="rounded-lg bg-[#F3F4F6]"
            tooltipArrowClassName="!text-[#F3F4F6]"
            color="invert"
          >
            <div className="flex items-center justify-center">
              <Popover
                placement="bottom"
                className="demo_test border-none bg-white p-2 shadow-md dark:bg-gray-100"
                content={({ setOpen }) => {
                  return (
                    <div className="flex flex-col gap-2">
                      {statusOptions?.map((option: any) => (
                        <button
                          key={option?.value}
                          type="button"
                          // disabled={taskLoading}
                          onClick={() =>
                            handleTaskBulkUpdate(
                              { status: option?.value },
                              'status_update',
                              setOpen
                            )
                          }
                          disabled={postBulkTasksUpdateLoader}
                        >
                          {option?.label}
                        </button>
                      ))}
                    </div>
                  );
                }}
              >
                <button
                  className="cursor-pointer !bg-none"
                  type="button"
                  disabled={postBulkTasksUpdateLoader}
                >
                  <MdTimelapse className="h-4 w-4 text-[#F3F4F6]" />
                </button>
              </Popover>
            </div>
          </Tooltip>
        )}
        {/* Tasks delete button */}
        {canDeleteTask && (
          <Tooltip
            size="sm"
            content={() => (
              <div className="text-[#1F2A37]">{'Delete these tasks'}</div>
            )}
            placement="top"
            className="rounded-lg bg-[#F3F4F6]"
            tooltipArrowClassName="!text-[#F3F4F6]"
            color="invert"
          >
            <div className="flex items-center justify-center">
              <Popover
                placement="bottom"
                className="demo_test border-none bg-white p-3 shadow-md dark:bg-gray-100"
                content={({ setOpen }) => {
                  return (
                    <div className="w-56 text-left rtl:text-right">
                      <Title
                        as="h6"
                        className="mb-0.5 flex items-start text-sm text-[#111928] sm:items-center"
                      >
                        <PiTrashFill className="me-1 h-[17px] w-[17px] text-[#111928]" />{' '}
                        {`Delete the task${
                          selectedRowKeys?.length > 1 ? 's' : ''
                        }`}
                      </Title>
                      <Text className="mb-3 leading-relaxed text-gray-500">
                        Are you sure you want to delete?
                      </Text>
                      <div className="flex items-center justify-end">
                        <Button
                          size="sm"
                          className="me-1.5 h-7 bg-[#7667CF]"
                          onClick={() =>
                            handleTaskBulkUpdate(
                              { mark_as_delete: true },
                              'mark_as_delete',
                              setOpen
                            )
                          }
                          disabled={postBulkTasksUpdateLoader}
                        >
                          Yes
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7"
                          onClick={() => setOpen(false)}
                        >
                          No
                        </Button>
                      </div>
                    </div>
                  );
                }}
              >
                <button
                  className="cursor-pointer !bg-none"
                  type="button"
                  disabled={postBulkTasksUpdateLoader}
                >
                  <FiTrash2 className="h-4 w-4 text-[#F3F4F6]" />
                </button>
              </Popover>
            </div>
          </Tooltip>
        )}
      </div>
    </div>
  );
};

export default BulkTasksUpdateOptions;
