'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { postBulkTasksUpdate } from '@/redux/slices/user/task/taskSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { useEffect, useState } from 'react';
import { GoPlus } from 'react-icons/go';
import { PiMagnifyingGlassBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Avatar, Input, Text } from 'rizzui';

export default function BulkTasksAssigneeUpdateModal({
  selectedRowKeys,
  setSelectedRowKeys,
  isAllTasksModule = false,
}: Readonly<{
  selectedRowKeys: string[];
  setSelectedRowKeys?: any;
  isAllTasksModule?: boolean;
}>) {
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  // State for selected member IDs
  const [selectedModalMembers, setSelectedModalMembers] = useState<number[]>(
    []
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [selectAll, setSelectAll] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const { postBulkTasksUpdateLoader } = useSelector(
    (state: any) => state.root.task
  );
  const {
    members,
    assignees,
    loading: boardLoading,
  } = useSelector((state: any) => state.root.board);
  console.log('selectedModalMembers..................', selectedModalMembers);
  console.log('assignees..................', assignees);

  // Build options from members
  const getOptionsToSelect = () => {
    if (isAllTasksModule) {
      return Array.isArray(assignees)
        ? assignees.map((member: any) => ({
            label: `${capitalizeFirstLetter(
              member?.first_name
            )} ${capitalizeFirstLetter(member?.last_name)}`,
            value: member?._id,
            profileImage: member?.profile_image,
          }))
        : [];
    } else {
      return Array.isArray(members)
        ? members.map((member: any) => ({
            label: `${capitalizeFirstLetter(
              member?.first_name
            )} ${capitalizeFirstLetter(member?.last_name)}`,
            value: member?.id,
            profileImage: member?.profile_image,
          }))
        : [];
    }
  };

  const options = getOptionsToSelect();

  // Update selectAll whenever selectedModalMembers or options change
  useEffect(() => {
    setSelectAll(
      options?.length > 0 &&
        options.every((option) => selectedModalMembers.includes(option.value))
    );
  }, [selectedModalMembers, options]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value.toLowerCase());
  };

  const handleSelectAllChange = () => {
    if (!selectAll) {
      // Select all
      setSelectedModalMembers(options.map((o) => o.value));
    } else {
      // Deselect all
      setSelectedModalMembers([]);
    }
  };

  const handleCheckboxChange = (value: number) => {
    setSelectedModalMembers((prev) =>
      prev?.includes(value)
        ? prev?.filter((id) => id !== value)
        : [...prev, value]
    );
  };

  const handleAddMemberClick = () => {
    if (selectedModalMembers?.length === 0) {
      setErrorMessage('Please select at least one member.');
      return;
    }
    setErrorMessage('');
    dispatch(
      postBulkTasksUpdate({
        task_ids: selectedRowKeys ?? [],
        assignees: selectedModalMembers ?? [],
      })
    ).then((result: any) => {
      if (postBulkTasksUpdate.fulfilled.match(result)) {
        if (result?.payload?.success === true) {
          closeModal();
          typeof setSelectedRowKeys === 'function' && setSelectedRowKeys([]);
        }
      }
    });
  };

  const filteredOptions =
    options?.filter(
      (option) => option?.label?.toLowerCase().includes(searchTerm)
    ) ?? [];

  return (
    <div className="p-5">
      {boardLoading ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" />
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <Text className="text-[20px] font-bold leading-6 text-[#141414]">
              Update Assignees
            </Text>
            <ActionIcon
              size="sm"
              variant="text"
              onClick={closeModal}
              className="me-4 p-0 text-[#141414] hover:!text-gray-900"
            >
              <PiXBold className="h-[20px] w-[20px]" />
            </ActionIcon>
          </div>

          <div className="mt-4 flex flex-col gap-4">
            <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
              <Input
                type="text"
                placeholder="Search members"
                value={searchTerm}
                onChange={handleSearchChange}
                inputClassName="bg-[#F9FAFB] border border-[#E5E7EB]"
                className="h-10 w-full md:w-[80%]"
                prefix={<PiMagnifyingGlassBold className="h-4 w-4" />}
              />
              <label className="flex items-center text-[#000000] sm:ml-4 md:w-[20%]">
                <Checkbox
                  checked={selectAll}
                  onChange={handleSelectAllChange}
                  className="mr-2 cursor-pointer"
                  inputClassName="checkbox-color"
                />
                Select all
              </label>
            </div>

            {selectedModalMembers.length > 0 && (
              <div className="flex items-center justify-between">
                <p className="text-[16px] font-semibold text-black">
                  {selectAll
                    ? 'All members selected'
                    : `${selectedModalMembers.length} selected`}
                </p>
                <Button
                  disabled={
                    selectedModalMembers.length === 0 ||
                    postBulkTasksUpdateLoader
                  }
                  onClick={handleAddMemberClick}
                  className="flex items-center gap-1 rounded-lg bg-[#7667CF] p-2 text-sm font-normal text-white"
                >
                  <GoPlus className="size-4 font-normal" />{' '}
                  <span>Add selected</span>
                  {postBulkTasksUpdateLoader && (
                    <Spinner size="sm" tag="div" color="white" />
                  )}
                </Button>
              </div>
            )}

            {errorMessage && (
              <Text className="text-red-600">{errorMessage}</Text>
            )}

            <SimpleBar className="max-h-[300px] overflow-y-auto">
              <div className="flex flex-col gap-[7px]">
                {filteredOptions.map((item, idx) => (
                  <div
                    key={item.value}
                    className="flex items-center justify-start gap-4 rounded-lg px-1.5 py-2"
                  >
                    <Checkbox
                      checked={selectedModalMembers.includes(item.value)}
                      onChange={() => handleCheckboxChange(item.value)}
                      className="cursor-pointer"
                      inputClassName="checkbox-color"
                    />
                    <Avatar
                      src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item.profileImage}`}
                      name={item.label}
                      className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white"
                    />
                    <span className="text-[16px] font-medium capitalize text-[#000000]">
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>
            </SimpleBar>
          </div>
        </>
      )}
    </div>
  );
}
