'use client';

import { getBoardSectionsById } from '@/redux/slices/user/task/boardSlice';
import { setGridView } from '@/redux/slices/user/task/taskSlice';
import cn from '@/utils/class-names';
import { FiTable } from 'react-icons/fi';
import { PiListBullets } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';

export default function TasksViewMode({ view }: { view?: string }) {
  const { gridView } = useSelector((state: any) => state?.root?.task);
  const { boardId } = useSelector((state: any) => state?.root?.board);
  const dispatch = useDispatch();

  // List view & Grid view changes
  const handleListView = () => {
    // setTaskFilterOptionValue('');
    // setTaskFilterOptionName('All tasks');
    // setAssigneeFilter('');
    dispatch(setGridView(false));
    dispatch(getBoardSectionsById({ board_id: boardId })); // for fetching new sections
  };

  const handleGridView = () => {
    // setTaskFilterOptionValue('');
    // setTaskFilterOptionName('All tasks');
    // setAssigneeFilter('');
    dispatch(setGridView(true));
  };

  return (
    <div
      className={cn(
        'flex h-[35px] w-[135px] items-center justify-between gap-[5px] rounded-lg border border-[#E5E7EB] bg-white p-1'
      )}
    >
      <button
        type="button"
        className={cn(
          'group flex h-full w-[45%] items-center justify-center gap-1 rounded bg-transparent hover:!bg-transparent',
          !gridView && 'bg-[#E7E5FA]'
        )}
        onClick={handleListView}
      >
        <PiListBullets
          className={cn(
            'h-3.5 w-3.5',
            gridView ? 'text-[#111928]' : 'text-[#362F78]'
          )}
        />
        <span className="text-xs font-medium text-[#111928]">List</span>
      </button>
      <button
        type="button"
        className={cn(
          'group flex h-full w-[55%] items-center justify-center gap-1 rounded bg-transparent hover:!bg-transparent',
          gridView && 'bg-[#E7E5FA]'
        )}
        onClick={handleGridView}
      >
        <FiTable
          className={cn(
            'h-3.5 w-3.5',
            !gridView ? 'text-[#111928]' : 'text-[#362F78]'
          )}
        />
        <span className="text-xs font-medium text-[#111928]">Board</span>
      </button>
    </div>
  );
}
