'use client';

// import AddMembers from '@/app/(hydrogen)/tasks/board/new-board/members-modal';
import AddMembers from '@/app/(hydrogen)/[workspaceName]/tasks/board/new-board/members-modal';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { DatePicker } from '@/components/ui/datepicker';
import { Popover } from '@/components/ui/popover';
import Spinner from '@/components/ui/spinner';
import { HeaderCell } from '@/components/ui/table';
import { ActionIcon, Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import {
  duplicateAddTask,
  getAllTask,
  patchEditTask,
} from '@/redux/slices/user/task/taskSlice';
import { putTaskKanbanStatusChange } from '@/redux/slices/user/task/taskStatusSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import subTaskIcon from '@public/assets/svgs/subtask-icon.svg';
import moment from 'moment';
import Image from 'next/image';
import { useEffect, useMemo, useState } from 'react';
import { FiStopCircle } from 'react-icons/fi';
import { LuTag, LuUser2 } from 'react-icons/lu';
import { PiCalendarBlankLight } from 'react-icons/pi';
import { SlOptions } from 'react-icons/sl';
import { useDispatch, useSelector } from 'react-redux';
import { Input } from 'rizzui';
import { checkPermission } from '../../roles-permissions/utils';
import Addtag from '../task-grid/addtag';
import EditTaskForm from '../task-grid/edit-task-form';
import TaskReminder from '../task-grid/task-reminder-model';
import TimerForm from '../task-grid/timer-form';
import ViewTaskFormSideBar from '../task-grid/view-task-form';
import TimerDisplay from '../taskTimer';

// priority dropdown options
const priorityOptions = [
  {
    value: 'low',
    name: 'Low',
    color: 'bg-[#E5E7EB]',
    label: (
      <div className="flex items-center  rounded-3xl bg-[#E5E7EB] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="success" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-[#111928]">
          Low
        </Text>
      </div>
    ),
  },
  {
    value: 'medium',
    name: 'Medium',
    color: 'bg-[#FFF3B6]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FFF3B6] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="warning" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-[#9A6F00]">
          Medium
        </Text>
      </div>
    ),
  },
  {
    value: 'high',
    name: 'High',
    color: 'bg-[#FFEFF1]',
    label: (
      <div className="flex items-center rounded-3xl  bg-[#FFEFF1] px-2 py-1 text-xs sm:text-sm">
        {/* <Badge color="danger" renderAsDot /> */}
        <Text className="w-[70px] text-center font-medium text-[#C92F54]">
          High
        </Text>
      </div>
    ),
  },
];

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
  handleBoardTaskSelectAll?: any;
};

interface Status {
  _id: string;
}

interface Assignee {
  _id: string;
}

interface DuplicateTaskSchema {
  _id: string;
  title: string;
  agenda?: string;
  priority: string;
  board_id: string;
  duplicated_from: string;
  status: Status;
  due_date?: string | null;
  assign_to?: Assignee[];
  attachments?: [];
  custom_fields?: any;
  parent_task?: any;
  tags?: any;
  recurrence_pattern?: any;
  recurrence_end_date?: any;
  recurrence_interval?: any;
  weekly_recurrence_days?: any;
  monthly_recurrence_day_of_month?: any;
}

function getPriorityStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'low':
      return (
        <div className="flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-[#E5E7EB] px-[20px] py-[8px] text-sm">
          <Text className="font-semibold text-[#111928]">Low</Text>
        </div>
      );
    case 'medium':
      return (
        <div className="flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-[#FFF3B6] px-[20px] py-[8px] text-sm">
          <Text className="font-semibold text-[#9A6F00]">Medium</Text>
        </div>
      );
    case 'high':
      return (
        <div className="flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-[#FFEFF1] px-[20px] py-[8px] text-sm">
          <Text className="font-semibold text-[#C92F54]">High</Text>
        </div>
      );

    default:
      return (
        <div className="flex w-[100px] items-center justify-center gap-2 rounded-3xl bg-gray-300 px-[20px] py-[8px] text-sm">
          <Text className="font-semibold text-gray-600">{status}</Text>
        </div>
      );
  }
}

export const GetColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
  handleBoardTaskSelectAll,
}: Columns) => {
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { boardId, members, assignees, board, sections } = useSelector(
    (state: any) => state?.root?.board
  );
  const {
    paginationParams,
    duplicateTaskLoading,
    setReminderTaskloading,
    loading: taskLoading,
    allTasksLoading,
  } = useSelector((state: any) => state?.root?.task);
  const { openModal, closeModal } = useModal();
  const { openDrawer, closeDrawer } = useDrawer();
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [selectedDueDate, setSelectedDueDate] = useState<any>(null);
  const [showSaveButton, setShowSaveButton] = useState<any>(false); // New state for Save button
  const [isOpenPopOver, setIsOpenPopOver] = useState(false); // New state for Save button
  const [selectedtags, setSelectedTags] = useState<any>([]);

  useEffect(() => {
    setSelectedDueDate(null);
    setShowSaveButton(false);
  }, [isOpenPopOver]);

  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [title, setTitle] = useState<string>('');
  const [error, setError] = useState<string>('');

  let clickTimeout: NodeJS.Timeout | null = null;

  const handleClick = (row: any) => {
    if (clickTimeout) return; // Prevent single-click execution if double-click happens

    clickTimeout = setTimeout(() => {
      openDrawer({
        view: (
          <ViewTaskFormSideBar
            rowData={row}
            editMode={true}
            onClose={closeDrawer}
            isView={true}
            isInboxTaskView={false}
          />
        ),
        placement: 'right',
        customSize: '640px',
      });
      clickTimeout = null;
    }, 300); // Adjust delay if needed
  };

  const handleDoubleClick = (row: any) => {
    if (clickTimeout) {
      clearTimeout(clickTimeout); // Cancel single-click action
      clickTimeout = null;
    }

    setEditingRowId(row?._id); // Set editing row ID
    setTitle(row?.title || ''); // Pre-fill with the existing title
  };
  // Function to handle input change
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = event.target.value.trimStart(); // Prevent leading spaces

    if (newTitle === '') {
      setError('Title cannot be empty.');
    } else if (newTitle.length > 150) {
      setError('Title cannot exceed 150 characters.');
    } else {
      setError(''); // Clear error if valid
    }

    setTitle(newTitle);
  };

  // Function to save the edited title
  const saveTitle = async (taskId: string) => {
    if (error) return; // Prevent saving if there is an error

    if (title.trim()) {
      const formData: any = new FormData();
      formData.append('_id', taskId);
      formData.append('title', title);
      formData.append('action_name', 'date_assignee_update');

      try {
        const result = await dispatch(patchEditTask(formData)).unwrap();

        if (result?.success) {
          await dispatch(
            getAllTask({
              ...paginationParams,
              board_id: boardId,
              pagination: true,
            })
          ).unwrap();

          setEditingRowId(null); // Exit editing mode only after getAllTask completes
        }
      } catch (error) {
        console.error('Error updating task:', error);
      }
    }
  };

  // Function to cancel editing mode
  const cancelEditing = () => {
    setTitle(''); // Reset title
    setError(''); // Clear error
    setEditingRowId(null); // Exit editing mode
  };
  const { loading } = useSelector((state: any) => state?.root?.taskStatus);
  const { settingData } = useSelector((state: any) => state?.root?.setting);
  const { activeTimerData } = useSelector(
    (state: any) => state?.root?.timeTracking
  );
  // find completed section status
  const [completedStatusData]: any = (sections &&
    sections?.length > 0 &&
    sections?.filter((option: any) => {
      if (option?.key === 'completed') {
        return option;
      }
    })) || [{}];

  // find archieved section status
  const [archivedStatusData]: any = (sections &&
    sections?.length > 0 &&
    sections?.filter((option: any) => {
      if (option?.key === 'archived') {
        return option;
      }
    })) || [{}];

  //check date if it is overdue or not

  function checkDate(date: Date, isCompleted: boolean) {
    const inputDate = moment(date);
    const now = moment();

    if (inputDate.isBefore(now) && !isCompleted) {
      return (
        <p className={cn('text-sm font-semibold text-[#C92F54]')}>
          {moment(date)?.format('MMM D, YYYY h:mm A')}
        </p>
      );
    } else {
      return (
        <p
          className={cn(
            'text-sm font-semibold text-black',
            isCompleted && 'text-[#9BA1B9]'
          )}
        >
          {moment(date)?.format('MMM D, YYYY h:mm A')}
        </p>
      );
    }
  }

  const handleTimerClick = (task: any) => {
    openModal({
      view: (
        <div>
          <TimerForm
            onClose={closeModal}
            task_id={task?._id}
            boardId={boardId}
            taskName={task?.title}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  const checkAssigneExist = (task: any, assign_id: string) => {
    const index = task?.assign_to?.findIndex(
      (user: any) => user?._id === assign_id
    );
    return index !== -1 ? true : false;
  };

  const clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          const team_name =
            capitalizeFirstLetter(team?.first_name) +
            ' ' +
            capitalizeFirstLetter(team?.last_name);
          return { ...team, name: team_name };
        })
      : [];

  const onDuplicateTask = (data: any, setOpen: any) => {
    // console.log("form dataa....", data)

    const formData = new FormData();

    // Append fields to the FormData object
    formData.append('title', data.title);
    if (data?.agenda) {
      formData.append('agenda', data.agenda);
    } else {
      formData.append('agenda', '');
    }
    formData.append('priority', data.priority);
    formData.append('board_id', data.board_id);
    formData.append('status', data.status._id);
    formData.append('duplicated_from', data._id);

    // if (data?.recurrence_pattern && data?.recurrence_pattern !== '') {
    //   formData.append('recurrence_pattern', data?.recurrence_pattern);
    //   formData.append(
    //     'recurrence_end_date',
    //     moment(data?.recurrence_end_date).format('DD-MM-YYYY')
    //   );
    //   formData.append('recurrence_interval', data?.recurrence_interval);

    //   if (data?.recurrence_pattern === 'weekly') {
    //     formData.append('weekly_recurrence_days', data?.weekly_recurrence_days);
    //   }

    //   if (data?.recurrence_pattern === 'monthly') {
    //     formData.append(
    //       'monthly_recurrence_day_of_month',
    //       data?.monthly_recurrence_day_of_month
    //     );
    //   }
    // }
    if (data?.parent_task?._id) {
      formData.append('parent_task', data?.parent_task?._id);
    }

    if (data?.tags && data?.tags?.length > 0) {
      data?.tags?.forEach((tag: any) => {
        formData.append('tags', tag?.tag_name);
      });
    }

    if (data?.custom_fields) {
      formData.append('custom_fields', JSON.stringify(data?.custom_fields));
    }

    // Convert due_date to string format
    if (data.due_date) {
      const dueDate = new Date(data.due_date);
      formData.append('due_date', dueDate.toString());
    } else {
      formData.append('due_date', 'null'); // Send 'null' as a string
    }

    // Extract only the user IDs for assign_to and convert to JSON string
    if (data.assign_to && data.assign_to?.length > 0) {
      const assignToIds = data.assign_to.map((assignee: any) => assignee._id);
      formData.append('assign_to', JSON.stringify(assignToIds));
    }

    if (data?.attachments && data?.attachments?.length > 0) {
      formData.append('attachments', JSON.stringify(data?.attachments));
    }

    dispatch(duplicateAddTask(formData)).then((result: any) => {
      if (duplicateAddTask.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          closeDrawer();
          dispatch(
            getAllTask({
              page: 1,
              sort_field: 'createdAt',
              sort_order: 'desc',
              board_id: boardId,
              pagination: true,
            })
          );
          setOpen(false);
        }
      }
    });
  };

  const AssigneeColumn = ({
    teamMembers,
    isTaskCompleted,
    rowData,
    selectedMembers,
  }: {
    teamMembers: any;
    isTaskCompleted: any;
    rowData: any;
    selectedMembers?: any;
  }) => {
    // Memoize the rendered output to prevent unnecessary re-renders
    const renderedTeamMembers = useMemo(() => {
      const displayName = (data: any) => {
        let displayName: string =
          data?.first_name?.charAt(0)?.toUpperCase() +
          data?.first_name?.slice(1) +
          ' ' +
          data?.last_name?.charAt(0)?.toUpperCase() +
          data?.last_name?.slice(1);
        return displayName;
      };

      const handleAddMemberClick = () => {
        if (
          // ['agency', 'client'].includes(signIn?.role)
          ['agency'].includes(signIn?.role) ||
          (['team_agency', 'team_client'].includes(signIn?.role) &&
            checkPermission('projects', 'tasks', 'update', signIn?.permission))
        ) {
          openModal({
            view: (
              <div>
                <AddMembers
                  onClose={closeModal}
                  selectedMembers={selectedMembers}
                  setSelectedMembers={setSelectedMembers}
                  formPage={false}
                  addTaskMember={true}
                  taskId={rowData?._id}
                />
              </div>
            ),
            customSize: '600px',
          });
        }
      };

      if (teamMembers && teamMembers.length > 0) {
        return (
          <button
            type="button"
            onClick={() => {
              handleAddMemberClick();
            }}
            disabled={
              rowData?.mark_as_archived ||
              rowData?.mark_as_done ||
              signIn?.role === 'client' ||
              (['team_agency', 'team_client'].includes(signIn?.role)
                ? !checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  )
                : false)
            }
            className=" ms-[13px] flex flex-row items-center justify-start gap-2"
          >
            <div className="flex flex-row items-center justify-start">
              {teamMembers?.slice(0, 3)?.map((team: any, index: number) => (
                <figure
                  key={`${team?._id}-${index}`}
                  className={cn(
                    'relative z-10 ml-[-13px] h-[32px] w-[32px] rounded-full focus:border-2 focus:border-gray-900',
                    rowData?.mark_as_done
                      ? 'cursor-not-allowed opacity-50'
                      : 'cursor-pointer'
                  )}
                >
                  <Avatar
                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${team?.profile_image}`}
                    name={displayName(team)}
                    className={cn('bg-[#70C5E0] font-medium text-white')}
                    size="sm"
                  />
                </figure>
              ))}
            </div>
            {teamMembers?.length > 3 && (
              <div className="poppins_font_number flex h-8 w-8 cursor-pointer items-center justify-center gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]">
                +{teamMembers?.length - 3}
              </div>
            )}
          </button>
        );
      } else {
        return (
          <Button
            variant="text"
            className="flex h-[32px] w-[32px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#9BA1B9] p-1"
            disabled={isTaskCompleted || signIn?.role === 'team_client'}
            onClick={() => {
              handleAddMemberClick();
            }}
          >
            <LuUser2 className="h-4 w-4 text-[#9BA1B9]" />
          </Button>
        );
      }
    }, [teamMembers]);

    return <div>{renderedTeamMembers}</div>;
  };

  const handleAddTag = (task: any) => {
    openModal({
      view: (
        <div>
          <Addtag
            onClose={closeModal}
            isAPICall={true}
            selectedtags={
              task?.tags && task?.tags?.length > 0
                ? task?.tags?.map((tag: any) => tag?.tag_name)
                : []
            }
            setSelectedTags={setSelectedTags}
            task={task}
            isTable={true}
            paginationParams={paginationParams}
            boardId={boardId}
          />
        </div>
      ),
      customSize: '600px',
    });
  };

  const TagsColumn = ({ tags, task }: { tags: any[]; task: any }) => {
    // Memoize the rendered tags to avoid unnecessary re-renders
    const renderedTags = useMemo(() => {
      if (!tags || tags?.length === 0) {
        return (
          <Button
            type="button"
            variant="text"
            className={`flex h-[28px] w-[28px] ${
              task?.mark_as_done
                ? 'cursor-not-allowed opacity-50'
                : 'cursor-pointer'
            } items-center justify-center rounded-full border-[1.25px] border-dashed border-[#6875F5] p-1`}
            onClick={() => {
              handleAddTag(task);
            }}
            disabled={
              task?.mark_as_archived ||
              task?.mark_as_done ||
              signIn?.role === 'client' ||
              (['team_agency', 'team_client'].includes(signIn?.role)
                ? !checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  )
                : false)
            }
          >
            <LuTag className="h-[14px] w-[14px] text-[#6875F5]" />
          </Button>
        );
      }

      const visibleTags = tags?.slice(0, 3); // Get the first 3 tags
      const remainingTagsCount = tags?.length - visibleTags?.length; // Remaining tags count

      return (
        <button
          className={`flex ${
            task?.mark_as_done
              ? 'cursor-not-allowed opacity-50'
              : 'cursor-pointer'
          } flex-wrap gap-2`}
          onClick={() => {
            handleAddTag(task);
          }}
          type="button"
          disabled={
            task?.mark_as_archived ||
            task?.mark_as_done ||
            signIn?.role === 'client' ||
            (['team_agency', 'team_client'].includes(signIn?.role)
              ? !checkPermission(
                  'projects',
                  'tasks',
                  'update',
                  signIn?.permission
                )
              : false)
          }
        >
          {visibleTags?.length > 0 &&
            visibleTags?.map((tag: any, index: number) => (
              <span
                key={index}
                className="inline-block rounded-full px-3 py-1 text-sm font-semibold capitalize text-black"
                style={{
                  backgroundColor: tag?.tag_color ? tag.tag_color : '#f0f0f0',
                }}
              >
                {tag?.tag_name}
              </span>
            ))}

          {remainingTagsCount > 0 && (
            <span
              className="poppins_font_number inline-block rounded-full px-3 py-1 text-[14px] font-normal capitalize text-black"
              style={{
                backgroundColor: '#f0f0f0',
              }}
            >
              +{remainingTagsCount} more
            </span>
          )}
        </button>
      );
    }, [tags]); // Only re-render when `tags` changes

    return <div>{renderedTags}</div>;
  };
  let filteredData = data?.filter((row) => !row?.mark_as_done) ?? [];

  const taskColumnArray = [
    {
      title: (
        <div className="ps-3.5">
          <Checkbox
            title={'Select All'}
            inputClassName="checkbox-color"
            onChange={handleBoardTaskSelectAll}
            checked={
              checkedItems?.length > 0 &&
              checkedItems?.length === filteredData?.length
            }
            className="cursor-pointer"
          />
        </div>
      ),
      dataIndex: 'checked',
      key: 'checked',
      width: 50,
      render: (_: any, row: any) => (
        <div className="inline-flex ps-3.5">
          {!row?.mark_as_archived && !row?.mark_as_done && (
            <Checkbox
              className="cursor-pointer"
              inputClassName="checkbox-color"
              checked={checkedItems.includes(row?._id)}
              {...(onChecked && { onChange: () => onChecked(row?._id) })}
            />
          )}
        </div>
      ),
    },
    {
      title: (
        <div className={cn(signIn?.role === 'team_client' && 'ps-3.5')}>
          <HeaderCell
            title="Task Id"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'task_id'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('task_id'),
      dataIndex: 'task_id',
      key: 'task_id',
      width: 300,
      render: (_: any, row: any) => (
        <div className="flex w-full items-center justify-between gap-2">
          <div className="flex w-[85%] items-center justify-between gap-2">
            <div
              className={cn(
                'view-task-tour-step-two flex h-full w-[90%]  cursor-pointer justify-start gap-2 break-all p-0 text-start text-[14px] font-semibold normal-case',
                row?.mark_as_done ? 'text-[#9BA1B9]' : 'text-black'
              )}
              onClick={() => handleClick(row)}
            >
              {row?.task_id ? row?.task_id : '-'}
            </div>
          </div>
        </div>
      ),
    },
    {
      title: (
        <div className={cn(signIn?.role === 'team_client' && 'ps-3.5')}>
          <HeaderCell
            title="Task Name"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'title'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('title'),
      dataIndex: 'title',
      key: 'title',
      width: 600,
      render: (_: any, row: any) => (
        <div className="flex w-full items-center justify-between gap-2">
          <div className="flex w-[85%] items-center justify-between gap-2">
            {editingRowId === row?._id ? (
              // Editing Mode - Show Input Field
              <div>
                <Input
                  type="text"
                  value={title}
                  onChange={handleChange}
                  onKeyDown={(event: any) => {
                    if (event.key === 'Enter') {
                      event.preventDefault();
                      saveTitle(row?._id);
                    } else if (event.key === 'Escape') {
                      cancelEditing();
                    }
                  }}
                  onBlur={cancelEditing}
                  placeholder="Edit task title"
                  className="placeholder_color w-full [&>label>span]:font-medium"
                  autoFocus
                  disabled={taskLoading || allTasksLoading}
                />
                {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
              </div>
            ) : (
              <Button
                variant="text"
                className={cn(
                  'view-task-tour-step-two flex h-full w-[90%] cursor-pointer justify-start gap-2 break-all p-0 text-start text-[14px] font-semibold normal-case',
                  row?.mark_as_done ? 'text-[#9BA1B9]' : 'text-black'
                )}
                onClick={() => handleClick(row)}
                onDoubleClick={() => {
                  if (
                    !row?.mark_as_archived &&
                    !row?.mark_as_done &&
                    signIn?.role !== 'client' &&
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : true) // ✅ Allow double-click only if permission is valid
                  ) {
                    handleDoubleClick(row);
                  }
                }}
              >
                {row?.title?.charAt(0)?.toUpperCase() + row?.title?.slice(1)}
              </Button>
            )}
            {activeTimerData?.task_detail?._id === row?._id && (
              <Tooltip
                size="sm"
                content={() => (
                  <span className="poppins_font_number">
                    <TimerDisplay />
                  </span>
                )}
                placement="top"
                color="invert"
              >
                <div className="flex items-center justify-center">
                  <FiStopCircle className="h-6 w-6 cursor-pointer text-[#EC221F]" />
                </div>
              </Tooltip>
            )}
          </div>
          {row?.sub_task_count && row?.sub_task_count !== 0 ? (
            <Tooltip
              size="sm"
              content={() => 'Sub Task'}
              placement="top"
              color="invert"
            >
              <div className=" flex w-[15%] cursor-pointer items-center justify-start gap-2 rounded-lg bg-[#F5F5F5] py-[6px] pe-[6px] ps-[10px] text-[14px] font-semibold text-[#4B5563]">
                <div className="w-[50%]">
                  <Image
                    src={subTaskIcon}
                    alt="sub task icon"
                    width={14}
                    height={14}
                  />
                </div>
                <div className="poppins_font_number w-[50%]">
                  {row?.sub_task_count ?? 0}
                </div>
              </div>
            </Tooltip>
          ) : (
            <></>
          )}
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Assignee"
          // sortable
          // ascending={
          //   sortConfig?.direction === 'asc' && sortConfig?.key === 'assign_to'
          // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('assign_to'),
      dataIndex: 'assign_to',
      key: 'assign_to',
      width: 200,
      render: (_: any, row: any) => {
        return (
          <AssigneeColumn
            rowData={row}
            isTaskCompleted={row?.mark_as_done}
            teamMembers={row?.assign_to}
            selectedMembers={
              row?.assign_to && row?.assign_to?.length > 0
                ? row?.assign_to?.map((member: any) => member?._id)
                : []
            }
          />
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Tags"
          // sortable
          // ascending={sortConfig?.direction === 'asc' && sortConfig?.key === 'tags'}
        />
      ),
      dataIndex: 'tags',
      key: 'tags',
      width: 300,
      render: (_: any, row: any) => <TagsColumn tags={row?.tags} task={row} />,
    },

    {
      title: (
        <HeaderCell
          title="Due Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'due_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('due_date'),
      dataIndex: 'due_date',
      key: 'due_date',
      width: 350,
      render: (_: any, row: any) => {
        const canOpenPopup =
          ['agency'].includes(signIn?.role) ||
          ['team_agency'].includes(signIn?.role);

        return (
          <Text
            className={cn(
              'flex items-center justify-start text-sm font-semibold capitalize'
            )}
          >
            {row?.due_date ? (
              <div>
                <Popover
                  placement="bottom"
                  className="demo_test min-w-[425px] border-none bg-white p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                  content={({ open, setOpen }) => {
                    const originalDueDate = moment.utc(row?.due_date).toDate(); // Store the original due date
                    setIsOpenPopOver(open);
                    const handleDateChange = (date: any) => {
                      setSelectedDueDate(date);
                      setShowSaveButton(
                        moment(date).valueOf() !==
                          moment(originalDueDate).valueOf()
                      );
                      // Enable Save only if the date is different
                    };

                    const handleSaveDate = (setOpen: any) => {
                      if (!selectedDueDate) return;

                      const formData = new FormData();
                      formData.append('_id', row?._id);
                      formData.append('due_date', String(selectedDueDate));
                      formData.append('action_name', 'date_assignee_update');

                      dispatch(patchEditTask(formData)).then((result: any) => {
                        if (
                          patchEditTask.fulfilled.match(result) &&
                          result.payload.success
                        ) {
                          dispatch(
                            getAllTask({
                              ...paginationParams,
                              board_id: boardId,
                              pagination: true,
                            })
                          );
                          setSelectedDueDate(null);
                          setShowSaveButton(false); // Hide Save button after saving
                          setOpen(false);
                        }
                      });
                    };

                    return (
                      <div>
                        <DatePicker
                          selected={
                            selectedDueDate ||
                            moment.utc(row?.due_date).toDate()
                          } // Use customizedDueDate
                          inputProps={{}}
                          placeholderText="Select due date"
                          onChange={handleDateChange}
                          selectsStart
                          startDate={
                            selectedDueDate ||
                            moment.utc(row?.due_date).toDate()
                          } // Prefill with existing due date
                          startOpen={true}
                          minDate={new Date()}
                          showTimeSelect
                          popperPlacement="bottom-start"
                          dateFormat="MMM d, yyyy h:mm aa"
                          noStyle={true} // ✅ Remove styles only for this picker
                          inline
                        />

                        <div className="mr-[20px] flex justify-end">
                          {' '}
                          {/* Right align */}
                          <Button
                            onClick={() => handleSaveDate(setOpen)}
                            rounded="lg"
                            disabled={!showSaveButton || taskLoading} // Disable Save button if date/time is not changed
                            className={`kanban-task-tour-step-one flex h-10 items-center justify-center gap-2 text-sm text-white ${
                              showSaveButton
                                ? 'bg-[#8C80D2]'
                                : 'cursor-not-allowed bg-[#8C80D2]'
                            }`}
                          >
                            Save
                            {taskLoading && (
                              <Spinner
                                size="sm"
                                tag="div"
                                className="ms-3"
                                color="white"
                              />
                            )}
                          </Button>
                        </div>
                      </div>
                    );
                  }}
                >
                  <button
                    className="cursor-not-allowed"
                    type="button"
                    disabled={
                      row?.mark_as_done ||
                      signIn?.role === 'client' ||
                      (['team_agency', 'team_client'].includes(signIn?.role)
                        ? !checkPermission(
                            'projects',
                            'tasks',
                            'update',
                            signIn?.permission
                          )
                        : false)
                    }
                  >
                    {checkDate(
                      moment(row?.due_date)?.toDate(),
                      row?.mark_as_done
                    )}
                  </button>
                </Popover>
              </div>
            ) : (
              <Popover
                placement="bottom"
                className="demo_test min-w-[425px] border-none bg-white p-[16px] dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                content={({ open, setOpen }) => {
                  setIsOpenPopOver(open);

                  const handleDateChange = (date: any) => {
                    setSelectedDueDate(date);
                    setShowSaveButton(moment(date).valueOf());
                  };
                  const saveDateChange = (setOpen: any) => {
                    if (
                      !(
                        selectedDueDate?.getHours() === 0 &&
                        selectedDueDate?.getMinutes() === 0 &&
                        selectedDueDate?.getSeconds() === 0
                      )
                    ) {
                      const formData: any = new FormData();
                      formData.append('_id', row?._id);
                      formData.append('due_date', String(selectedDueDate));
                      formData.append('action_name', 'date_assignee_update');

                      dispatch(patchEditTask(formData)).then((result: any) => {
                        if (patchEditTask.fulfilled.match(result)) {
                          if (result && result.payload.success === true) {
                            dispatch(
                              getAllTask({
                                ...paginationParams,
                                board_id: boardId,
                                pagination: true,
                              })
                            );
                            setSelectedDueDate(null);
                            setShowSaveButton(false);
                            setOpen(false);
                          }
                        }
                      });
                    }
                  };

                  return canOpenPopup ? (
                    <div>
                      <DatePicker
                        selected={selectedDueDate}
                        inputProps={{
                          // label: 'Due Date',
                          color: 'info',
                          // error: errors?.due_date?.message,
                        }}
                        placeholderText="Select due date"
                        onChange={handleDateChange}
                        selectsStart
                        startDate={selectedDueDate}
                        startOpen={true}
                        minDate={new Date()}
                        showTimeSelect
                        popperPlacement="bottom-start"
                        dateFormat="MMMM d, yyyy h:mm aa"
                        inline
                        noStyle={true} // ✅ Remove styles only for this picker
                      />
                      <div className="mr-[20px] flex justify-end">
                        {' '}
                        {/* Right align */}
                        <Button
                          onClick={() => saveDateChange(setOpen)}
                          rounded="lg"
                          disabled={!showSaveButton || taskLoading} // Disable Save button if date/time is not changed
                          className={`kanban-task-tour-step-one flex h-10 items-center justify-center gap-2 text-sm text-white ${
                            showSaveButton
                              ? 'bg-[#8C80D2]'
                              : 'cursor-not-allowed bg-[#8C80D2]'
                          }`}
                        >
                          Save
                          {taskLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </div>
                  ) : null;
                }}
              >
                <Button
                  variant="text"
                  className="flex h-[32px] w-[32px] items-center justify-center rounded-full border-[1.25px] border-dashed border-[#9BA1B9] p-1"
                  disabled={
                    row?.mark_as_done ||
                    signIn?.role === 'client' ||
                    (['team_agency', 'team_client'].includes(signIn?.role)
                      ? !checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )
                      : false)
                  }
                >
                  <PiCalendarBlankLight className="h-4 w-4 text-[#4B5563]" />
                </Button>
              </Popover>
            )}
          </Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Priority"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'priority'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('priority'),
      dataIndex: 'priority',
      key: 'priority',
      width: 150,
      render: (_: any, row: any) => (
        <div>
          <Popover
            placement="top"
            className="demo_test min-w-[140px] border-none bg-white p-2 shadow-md dark:bg-gray-100"
            content={({ setOpen }) => {
              const handlePriorityChange = (priorityValue: string) => {
                // 🛠️ Update Task in API
                if (priorityValue !== row?.priority) {
                  const formData = new FormData();
                  formData.append('_id', row?._id);
                  formData.append('priority', priorityValue);
                  formData.append('action_name', 'date_assignee_update');

                  dispatch(patchEditTask(formData)).then((result: any) => {
                    if (patchEditTask.fulfilled.match(result)) {
                      if (result && result.payload.success === true) {
                        dispatch(
                          getAllTask({
                            ...paginationParams,
                            board_id: boardId,
                            pagination: true,
                          })
                        );
                        setOpen(false);
                      }
                    }
                  });
                }
              };

              return (
                <div className="flex flex-col gap-2">
                  {priorityOptions.map((option: any) => (
                    <button
                      key={option.value}
                      type="button"
                      disabled={taskLoading}
                      onClick={() => handlePriorityChange(option.value)}
                      className={`flex h-7 w-[130px] cursor-pointer items-center justify-center rounded-lg border-[1px] px-4 py-1 text-sm font-medium ${option.color} hover:opacity-80`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              );
            }}
          >
            <button
              className="cursor-pointer"
              type="button"
              disabled={
                row?.mark_as_archived ||
                row?.mark_as_done ||
                signIn?.role === 'client' ||
                (['team_agency', 'team_client'].includes(signIn?.role)
                  ? !checkPermission(
                      'projects',
                      'tasks',
                      'update',
                      signIn?.permission
                    )
                  : false)
              }
            >
              <Text
                className={`flex ${
                  row?.mark_as_done ? '!cursor-not-allowed' : '!cursor-pointer'
                } items-center justify-center`}
              >
                {getPriorityStatusBadge(row?.priority)}
              </Text>{' '}
            </button>
          </Popover>
        </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Status"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 200,
      render: (value: Record<string, any>) => (
        <div
          className="flex items-center justify-start gap-2 rounded-3xl px-[20px] py-[8px] text-sm"
          style={{ backgroundColor: value?.color, maxWidth: '200px' }}
        >
          <div
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: value?.test_color }}
          />
          <Tooltip
            className="demo_test"
            size="sm"
            content={() => value?.section_name}
            placement="top"
            color="invert"
          >
            <div
              className="truncate font-semibold"
              style={{ color: value?.test_color }}
            >
              {value?.section_name}
            </div>
          </Tooltip>
        </div>
      ),
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Action" align="right" />,
      dataIndex: 'action',
      key: 'action',
      width: 70,
      render: (_: string, row: any) => {
        return (
          <div className="flex items-center justify-end">
            <Popover
              placement="top-start"
              className="demo_test flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
              content={({ setOpen }) => {
                const handleTaskStatusChangeClick = () => {
                  if (row?.mark_as_archived) {
                    return;
                  }

                  const newStatus = !row?.mark_as_done
                    ? completedStatusData?._id
                    : archivedStatusData?._id;

                  dispatch(
                    putTaskKanbanStatusChange({
                      _id: row?._id,
                      status: newStatus,
                    })
                  ).then((result: any) => {
                    if (putTaskKanbanStatusChange.fulfilled.match(result)) {
                      if (result?.payload?.success) {
                        dispatch(
                          getAllTask({
                            ...paginationParams,
                            board_id: boardId,
                            pagination: true,
                          })
                        );
                        setOpen(false);
                      }
                    }
                  });
                };

                const isTaskCreateAllowed =
                  ['team_agency', 'team_client'].includes(signIn?.role) &&
                  checkPermission(
                    'projects',
                    'tasks',
                    'create',
                    signIn?.permission
                  );

                const isTaskUpdateAllowed =
                  ['team_agency', 'team_client'].includes(signIn?.role) &&
                  checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  );

                return (
                  <>
                    {/* View Task */}
                    <Button
                      variant="text"
                      className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      onClick={() => {
                        closeDrawer();
                        openDrawer({
                          view: (
                            <ViewTaskFormSideBar
                              rowData={row}
                              editMode={true}
                              onClose={closeDrawer}
                              isView={true}
                              isInboxTaskView={false}
                            />
                          ),
                          placement: 'right',
                          customSize: '640px',
                        });
                      }}
                    >
                      View Task
                    </Button>

                    {/* Edit Task */}
                    {(['agency'].includes(signIn?.role) ||
                      isTaskUpdateAllowed) &&
                      !row?.mark_as_done && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={() => {
                            openModal({
                              view: (
                                <EditTaskForm
                                  rowData={row}
                                  editMode={true}
                                  onClose={closeModal}
                                />
                              ),
                              customSize: '800px',
                            });
                            setOpen(false);
                          }}
                        >
                          Edit Task
                        </Button>
                      )}
                    {/* Reminder due date Task */}
                    {!row?.mark_as_done &&
                      row?.due_date &&
                      row?.assign_to?.length > 0 &&
                      new Date(row?.due_date).getTime() >
                        new Date().getTime() &&
                      (['agency'].includes(signIn?.role) ||
                        isTaskCreateAllowed ||
                        isTaskUpdateAllowed) && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={() => {
                            if (!taskLoading) {
                              openModal({
                                view: (
                                  <TaskReminder
                                    onClose={closeModal}
                                    rowData={row}
                                    AssigneeMembers={
                                      row?.assign_to?.map(
                                        (assignee: Record<string, any>) =>
                                          assignee?._id
                                      ) || []
                                    }

                                    // editMode={true}
                                    // editMode={true}
                                  />
                                ),
                                customSize: '490px',
                              });
                              setOpen(false);
                            }
                          }}
                          disabled={taskLoading}
                        >
                          Reminder due date Task
                        </Button>
                      )}

                    {/* Duplicate Task */}
                    {!row?.mark_as_done &&
                      (['agency'].includes(signIn?.role) ||
                        isTaskCreateAllowed) && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={() => {
                            if (!duplicateTaskLoading) {
                              onDuplicateTask(row, setOpen);
                            }
                          }}
                          disabled={duplicateTaskLoading}
                        >
                          Duplicate Task
                        </Button>
                      )}

                    {/* Start Time Tracking */}
                    {settingData?.task?.time_tracking?.length > 0 &&
                      checkAssigneExist(row, signIn?.user?.data?.user?._id) &&
                      row?.status?.key !== 'archived' &&
                      row?.status?.key !== 'completed' && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={() => {
                            handleTimerClick(row);
                            setOpen(false);
                          }}
                        >
                          Start time tracking
                        </Button>
                      )}

                    {/* Mark as completed or Archived */}
                    {(['agency'].includes(signIn?.role) ||
                      row?.assign_to?.some(
                        (user: any) =>
                          user?._id === signIn?.user?.data?.user?._id
                      ) ||
                      (['team_agency'].includes(signIn?.role) &&
                        checkPermission(
                          'projects',
                          'tasks',
                          'update',
                          signIn?.permission
                        )) ||
                      isTaskUpdateAllowed) &&
                      !row?.mark_as_archived && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={handleTaskStatusChangeClick}
                          disabled={loading}
                        >
                          {row?.mark_as_done
                            ? 'Mark Task as archive'
                            : 'Mark Task as completed'}
                        </Button>
                      )}
                  </>
                );
              }}
            >
              <ActionIcon title="More Options" variant="text">
                <SlOptions className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
              </ActionIcon>
            </Popover>
          </div>
        );
      },
    },
  ];

  return taskColumnArray;
};
