'use client';
import { Button, Text, Title } from 'rizzui';

type ConfirmationModalProps = {
  title: string;
  message: string;
  confirmText: string;
  cancelText?: string;
  onConfirm: () => void;
  onClose: any;
};

export function TemplateConfirmationModal({
  title,
  message,
  confirmText,
  cancelText = 'No',
  onConfirm,
  onClose,
}: ConfirmationModalProps) {

  return (
    <div className="p-6">
      <div className="flex flex-col items-center justify-start gap-4">
        <div className="flex w-full items-center justify-between">
          <Title as="h6" className="text-sm text-[#8C80D2]">
            {title}
          </Title>
        </div>
        <Text className="leading-relaxed text-[#9BA1B9]">{message}</Text>
      </div>
      <div className="grid grid-cols-2 gap-5 pt-5">
        <Button
          className="bg-[#8C80D2] text-white"
          onClick={onConfirm}
        >
          {confirmText}
        </Button>
        <Button variant="outline" className="text-[#9BA1B9]" onClick={(e) => onClose(e)}>
          {cancelText}
        </Button>
      </div>
    </div>
  );
}
