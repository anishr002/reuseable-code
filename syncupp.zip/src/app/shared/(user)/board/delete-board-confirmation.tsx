'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import Spinner from '@/components/ui/spinner';
import {
  deleteBoard,
  postArchiveBoard,
} from '@/redux/slices/user/task/boardSlice';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Text } from 'rizzui';

export function ConfirmationBoardDeleteModal(props: any) {
  const { boardId, updatedData, setUpdateddata, setCheckedBoards } = props;
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const [forceFullyDelete, setforceFullyDelete] = useState(false);

  const { deleteBoardLoader, archiveBoardLoader } = useSelector(
    (state: any) => state?.root?.board
  );

  const handleDeleteBoard = () => {
    if (!forceFullyDelete) {
      dispatch(
        deleteBoard({
          force_fully_remove: false,
          board_id: boardId,
        })
      ).then((result: any) => {
        if (deleteBoard.fulfilled.match(result)) {
          if (result.payload.success === true) {
            console.log(
              result?.payload?.data?.force_fully_remove,
              '1111updatedBoardAfterDelete'
            );
            if (!result?.payload?.data?.force_fully_remove) {
              const updatedBoardAfterDelete =
                (updatedData &&
                  updatedData?.length > 0 &&
                  updatedData?.filter((board: Record<string, any>) => {
                    if (!boardId.includes(board?._id)) {
                      return board;
                    }
                  })) ||
                [];
              setUpdateddata(updatedBoardAfterDelete);
              setCheckedBoards([]); // unselect all boards after successfull api call
              closeModal();
            } else {
              setforceFullyDelete(true);
            }
          }
        }
      });
    } else {
      dispatch(
        deleteBoard({
          force_fully_remove: true,
          board_id: boardId,
        })
      ).then((result: any) => {
        if (deleteBoard.fulfilled.match(result)) {
          console.log('Api response for delete....', result);
          if (result.payload.success === true) {
            const updatedBoardAfterDelete =
              (updatedData &&
                updatedData?.length > 0 &&
                updatedData?.filter((board: Record<string, any>) => {
                  if (!boardId.includes(board?._id)) {
                    return board;
                  }
                })) ||
              [];
            setUpdateddata(updatedBoardAfterDelete);
            setCheckedBoards([]); // unselect all boards after successfull api call
            closeModal();
          }
        }
      });
    }
  };

  const handleArchiveBoard = () => {
    dispatch(
      postArchiveBoard({
        status: 'archived',
        board_id: boardId,
      })
    ).then((result: any) => {
      if (postArchiveBoard.fulfilled.match(result)) {
        console.log('Api response for archive....', result);
        if (result.payload.success === true) {
          const updatedBoardAfterArchive =
            (updatedData &&
              updatedData?.length > 0 &&
              updatedData?.filter((board: Record<string, any>) => {
                if (board._id !== boardId) {
                  return board;
                }
              })) ||
            [];
          setUpdateddata(updatedBoardAfterArchive);
          closeModal();
        }
      }
    });
  };

  return (
    <div className="flex flex-col gap-2.5 p-6">
      <div className="flex flex-col items-center justify-start gap-6 pt-5">
        <Text className="flex text-center text-xl font-bold leading-relaxed text-[#141414]">
          {!forceFullyDelete ? (
            'Are you sure you want to delete these boards?'
          ) : (
            <>
              <p>
                Are you sure you want to delete those boards? It contains{' '}
                <b>tasks and activities</b>
              </p>
              .
            </>
          )}
        </Text>
        <div className="leading-relaxed- rounded-xl bg-[#fbf0f3] px-4 py-3 text-base font-medium text-[#C92F54]">
          Note: Once boards are deleted, they cannot be recovered.
        </div>
      </div>
      <div className="flex w-full items-center justify-center gap-4 pt-5">
        <Button
          variant="outline"
          className="text-[#141414] @xl:w-auto dark:hover:border-[#D4D4D4]"
          onClick={closeModal}
        >
          Cancel
        </Button>
        <Button
          className="bg-[#FA4571] text-white @xl:w-auto dark:text-white"
          disabled={deleteBoardLoader}
          onClick={handleDeleteBoard}
        >
          Confirm delete
          {deleteBoardLoader && (
            <Spinner size="sm" tag="div" className="ms-3" color="white" />
          )}
        </Button>
      </div>
    </div>
  );
}
