'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';

type Columns = {
    data: any[];
    sortConfig?: any;
    handleSelectAll: any;
    checkedItems: string[];
    onDeleteItem: (
        id: string | string[],
        currentPage?: any,
        countPerPage?: number,
        Islastitem?: boolean,
        sortConfig?: Record<string, string>,
        searchTerm?: string
    ) => void;
    onHeaderCellClick: (value: string) => void;
    onChecked?: (id: string) => void;
    currentPage?: number;
    pageSize?: number;
    searchTerm?: string;
};

export const GamificationColumns = ({
    data,
    sortConfig,
    checkedItems,
    onDeleteItem,
    onHeaderCellClick,
    handleSelectAll,
    onChecked,
    currentPage,
    pageSize,
    searchTerm,
}: Columns) => {
    const dispatch = useDispatch();
    const signIn = useSelector((state: any) => state?.root?.signIn);

    const pointType = (type: any) => {
        if(type == 'coupon_purchase') return 'Coupon Purchase';
        return capitalizeFirstLetter(type);
      }

    return [
        (signIn?.role === 'agency') && {
            title: (
                <HeaderCell
                    title="Name"
                    className="text-[#9BA1B9]"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('name'),
            dataIndex: 'user',
            key: 'user',
            width: 150,
            render: (value: any) => (
                <Text className="font-medium text-gray-700 capitalize">
                    {value?.name && value?.name != '' ? value?.name : '-'}
                </Text>
            )
        },
        // {
        //     title: (
        //         <HeaderCell
        //             title="Name"
        //             sortable
        //             ascending={
        //                 sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
        //             }
        //         />
        //     ),
        //     onHeaderCell: () => onHeaderCellClick('name'),
        //     dataIndex: 'user',
        //     key: 'user',
        //     width: 150,
        //     render: (value: any) => (
        //         <Text className="font-medium text-gray-700 capitalize">
        //             {value?.name && value?.name != '' ? value?.name : '-'}
        //         </Text>
        //     )
        // },
        {
            title: (
                <HeaderCell
                    title="Type"
                    className="text-[#9BA1B9]"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'type'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('type'),
            dataIndex: 'type',
            key: 'type',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700 capitalize">
                    {value && value != '' ? pointType(value) : '-'}
                </Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Date"
                    className="text-[#9BA1B9]"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('createdAt'),
            dataIndex: 'createdAt',
            key: 'createdAt',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700 poppins_font_number">
                    {value && value != '' ? moment(value).format('DD MMM, YYYY') : "-"}
                </Text>
            ),
        },


        {
            title: (
                <HeaderCell
                    title="Points"
                    className="text-[#9BA1B9]"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'point'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('point'),
            dataIndex: 'point',
            key: 'point',
            width: 100,
            render: (value: string) => (
                <Text className="font-medium text-gray-700 poppins_font_number">
                    {value && value != '' ? value : '-'}
                </Text>
            ),
        }

    ];
};
