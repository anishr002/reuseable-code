import React from 'react'
import { ActionIcon } from 'rizzui'
import { useModal } from '../../modal-views/use-modal';
import { PiXBold } from 'react-icons/pi';
import Image from 'next/image';
import ReferSuccess from '@public/assets/svgs/ReferSuccess.svg'

export const ReferalSuccess = () => {
    const { openModal, closeModal } = useModal();

    return (
        <div className='space-y-5 p-7'>
            <div className="flex items-center justify-end pe-2">
                <ActionIcon
                    size="sm"
                    variant="text"
                    onClick={() => closeModal()}
                    className="p-0 text-[#141414] hover:!text-gray-900 ml-4"
                >
                    <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
            </div>
            <div className='grid grid-row gap-5 !mt-0'>
                <div className='flex justify-center'>
                    <Image
                        className=''
                        height={60}
                        width={60}
                        src={ReferSuccess}
                        alt={'Referral'}>
                    </Image>
                </div>
                <div className='grid grid-row gap-5 pb-8'>
                    <p className='text-[#141414] font-bold leading-8 text-[24px] text-center'>
                    Thank you! Your bank details have been submitted successfully. 
                    </p>
                    <p className='text-[#141414] font-medium text-[16px] text-center'>
                    We will process your withdrawal within 5–7 business days.
                    </p>
                </div>
            </div>
        </div>
    )
}

