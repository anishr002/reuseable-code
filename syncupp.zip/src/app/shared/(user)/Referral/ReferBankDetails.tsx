import Select from '@/components/ui/select'
import React, { useState } from 'react'
import { Button, Input, Title } from 'rizzui'
import { useModal } from '../../modal-views/use-modal';
import { ReferalSuccess } from './ReferalSuccess';
import { ReferBankDetailSchema } from '@/utils/validators/ReferBankDetailSchema'
// import { Form } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { handleKeyDown } from '@/utils/common-functions';
import { Controller } from 'react-hook-form';
import { any } from 'prop-types';

const initialValues: ReferBankDetailSchema = {
    bank: '',
    accountNumber: '',
    accountName: '',
    ifscCode: '',
};

let bankName = [
    { name: 'HDFC Bank', value: 'HDFC' },
    { name: 'SBI Bank', value: 'sbi' },
]

export const ReferBankDetails = (props: any) => {
    const { openModal, closeModal } = useModal();
    const [isOpen, setOpen] = useState(true)


    const handlesubmit = (data: any) => {
        setOpen(false);
        openModal({
            view: <ReferalSuccess />,
            customSize: "560px",
        });
        console.log(data, "dataaaa")
    }

    return (
        (isOpen && (
            <Form<ReferBankDetailSchema>
                validationSchema={ReferBankDetailSchema}
                onSubmit={handlesubmit}
                useFormProps={{
                    mode: 'all',
                    defaultValues: initialValues,
                }}
            >
                {({ register, control, formState: { errors } }) => (
                    console.log(errors),
                    <div className='space-y-5 p-8'>
                        <div className="mb-8 flex items-center justify-between pe-2">
                            <Title as="h3" className="text-xl text-[#141414] xl:text-2xl break-all">
                                Add Your Bank Details
                            </Title>
                        </div>
                        <div className='grid grid-col gap-6 pb-5 border-b'>
                            <Controller
                                name="bank"
                                control={control}
                                render={({ field: { onChange, value } }) => (

                                    <Select
                                        options={bankName}
                                        placeholder="Select Bank"
                                        className="w-full"
                                        selectClassName=''
                                        optionClassName=''
                                        onChange={onChange}
                                        error={errors?.bank?.message}
                                        getOptionValue={(option) => option?.value}
                                        getOptionDisplayValue={(option: any) => option?.name}
                                        value={value}
                                    />
                                )}>

                            </Controller>
                            <Input
                                type="number"
                                placeholder="Account number"
                                color="info"
                                className="w-full rounded-lg lg:w-[100%] [&>label>span]:font-[400px] [&>label>span]:text-[#141414]"
                                inputClassName="poppins_font_number"
                                onKeyDown={handleKeyDown}
                                {...register('accountNumber')}
                                error={errors.accountNumber?.message}
                            />
                            <Input
                                type="text"
                                placeholder="Account holder’s name"
                                color="info"
                                className="w-full rounded-lg lg:w-[100%] [&>label>span]:font-[400px] [&>label>span]:text-[#141414]"
                                inputClassName="poppins_font_number"
                                onKeyDown={handleKeyDown}
                                {...register('accountName')}
                                error={errors.accountName?.message}

                            />
                            <Input
                                type="number"
                                placeholder="IFSC Code"
                                color="info"
                                className="w-full rounded-lg lg:w-[100%] [&>label>span]:font-[400px] [&>label>span]:text-[#141414]"
                                inputClassName="poppins_font_number"
                                onKeyDown={handleKeyDown}
                                {...register('ifscCode')}
                                error={errors.ifscCode?.message}

                            />

                        </div>
                        <div>
                            <p className='text-[12px] font-medium text-[#141414]'>
                                By adding this bank, account, I confirm that the bank account details provided are accurate and belong to me.
                            </p>
                        </div>
                        <div className='grid sm:grid-cols-2 grid-col'>
                            <div className='grid sm:col-start-2 order-2'>
                                <div className='flex sm:justify-between justify-around'>
                                    <Button
                                        className='!text-black font-400 text-15px bg-white border-[1px] border-[#D4D4D4] rounded-lg'
                                        onClick={() => closeModal()}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        type='submit'
                                        className='!text-white font-400 text-15px bg-[#7667CF] rounded-lg'
                                        
                                    >
                                        Submit & Withdraw
                                    </Button>
                                </div>

                            </div>
                        </div>
                    </div>
                )}

            </Form>
        ))

    )
}


