import React, { useState } from 'react'
import { PiXBold } from 'react-icons/pi'
import { ActionIcon, Button, Title } from 'rizzui'
import { useModal } from '../../modal-views/use-modal';
import { useSelector } from 'react-redux';
import { BsCurrencyRupee } from 'react-icons/bs';
import { ReferBankDetails } from './ReferBankDetails';


export const RedeemConfirmation = (_prop: any) => {

    const { openModal, closeModal } = useModal();
    const [isOpen, setOpen] = useState(true);
    const { loading, refferalstatics } = useSelector(
        (state: any) => state?.root?.referral
    );

    return (
        (isOpen && (<div className='space-y-2 p-6'>
            <div className="mb-8 flex items-center justify-between pe-2">
                <Title as="h3" className="text-xl text-[#141414] xl:text-2xl break-all">
                    Redeem
                </Title>
                <ActionIcon
                    size="sm"
                    variant="text"
                    onClick={() => closeModal()}
                    className="p-0 text-[#141414] hover:!text-gray-900 ml-4"
                >
                    <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
            </div>
            <div className='flex justify-between ps-2'>
                <div className='grid grid-row gap-2 font-600'>
                    <p className='text-[#4B5563] text-[15px]'>Available Cash</p>
                    <p className='text-[#111928]  text-[30px] flex items-center poppins_font_number '>
                        <BsCurrencyRupee />
                        {refferalstatics?.erned_points}</p>
                </div>
                <div className='flex items-end'>
                    <Button
                        className='!text-white font-[400px] text-15px bg-[#7667CF] rounded-lg'
                        onClick={() => {
                            setOpen(false);
                            openModal({
                                view: <ReferBankDetails />,
                                customSize: "600px",
                            });
                        }}
                    >
                        Redeem as Cash
                    </Button>
                </div>
            </div>

        </div>)
        )
    )
}


