'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import {
  capitalizeFirstLetter,
  convertSecondsToTime,
} from '@/utils/common-functions';
import moment from 'moment';
import { useMemo } from 'react';
import { Avatar } from 'rizzui';

type Columns = {
  sortConfig?: any;
  onHeaderCellClick: (value: string) => void;
};

export const timesheetReportsColumns = ({
  onHeaderCellClick,
  sortConfig,
}: Readonly<Columns>) => {

    const TagsColumn = ({ tags }: { tags: any[] }) => {
      // Memoize the rendered tags to avoid unnecessary re-renders
      const renderedTags = useMemo(() => {
        if (!tags || tags?.length === 0) {
          return (
            <div className="text-sm font-semibold text-[#4B5563] ">
              No tags available
            </div>
          );
        }
  
        const visibleTags = tags?.slice(0, 3); // Get the first 3 tags
        const remainingTagsCount = tags?.length - visibleTags?.length; // Remaining tags count
  
        return (
          <div className="flex flex-wrap gap-2">
            {visibleTags?.length > 0 &&
              visibleTags?.map((tag: any, index: number) => (
                <span
                  key={index}
                  className="inline-block rounded-full px-3 py-1 text-sm font-semibold capitalize text-black"
                  style={{
                    backgroundColor: tag?.tag_color ? tag.tag_color : '#f0f0f0',
                  }}
                >
                  {tag?.tag_name}
                </span>
              ))}
  
            {remainingTagsCount > 0 && (
              <span
                className="poppins_font_number inline-block rounded-full px-3 py-1 text-[14px] font-normal capitalize text-black"
                style={{
                  backgroundColor: '#f0f0f0',
                }}
              >
                +{remainingTagsCount} more
              </span>
            )}
          </div>
        );
      }, [tags]); // Only re-render when `tags` changes
  
      return <div>{renderedTags}</div>;
    };

  const reportsColumnArray: any = [
    {
      title: (
        <HeaderCell
          title="Task Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'task_details.title'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('task_details.title'),
      dataIndex: 'title',
      key: 'title',
      width: 500,
      render: (_: any, row: any) => (
        <Text className="poppins_font_number text-[14px] font-semibold text-black">
          {capitalizeFirstLetter(row?.task_details?.title)}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Board"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'board_details.project_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('board_details.project_name'),
      dataIndex: 'board_details',
      key: 'board_details',
      width: 300,
      render: (_: any, row: any) => (
        <div className="flex items-center gap-1">
          {row?.board_details?.board_image ? (
            <Avatar
              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${row?.board_details?.board_image}`}
              name={
                capitalizeFirstLetter(row?.board_details?.project_name) ?? ''
              }
              size="sm"
              className="!h-8 !w-8 bg-[#70C5E0] font-semibold text-white"
            />
          ) : (
            <div
              className="flex !h-8 !w-8 items-center justify-center rounded-full border-white"
              style={{
                backgroundColor: row?.board_details?.board_color,
              }}
            ></div>
          )}
          <span className="ms-3 grid gap-0.5">
            <span className="poppins_font_number break-all text-[15px] font-semibold capitalize text-black">
              {capitalizeFirstLetter(row?.board_details?.project_name)}
            </span>
          </span>
        </div>
      ),
    },

    {
      title: (
        <div>
          <HeaderCell
            title="Assignee Name"
            sortable
            ascending={
              sortConfig?.direction === 'asc' &&
              sortConfig?.key === 'user_details.full_name'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('user_details.full_name'),
      dataIndex: 'user_details',
      key: 'user_details',
      width: 300,
      render: (_: any, row: any) => (
        <Text className="poppins_font_number flex items-start justify-start font-semibold text-black">
          {`${capitalizeFirstLetter(
            row?.user_details?.first_name
          )} ${capitalizeFirstLetter(row?.user_details?.last_name)}`}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Tags"
          // sortable
          // ascending={
          //   sortConfig?.direction === 'asc' && sortConfig?.key === 'assign_to'
          // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('assign_to'),
      dataIndex: 'tags',
      key: 'tags',
      width: 300,
      render: (_: any, row: any) => <TagsColumn tags={row?.task_details?.tags} />
    },
    {
      title: (
        <HeaderCell
          title="Mode"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'mode'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('mode'),
      dataIndex: 'mode',
      key: 'mode',
      width: 200,
      render: (value: any) => (
        <Text className="poppins_font_number flex items-center justify-center font-semibold text-black">
          {capitalizeFirstLetter(value)}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Date"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'new_log.clock_in'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('new_log.clock_in'),
      dataIndex: 'date',
      key: 'date',
      width: 300,
      render: (_: any, row: any) => (
        <Text className="poppins_font_number flex items-center justify-center font-semibold text-black">
          {moment(row?.new_log?.clock_in).format('DD MMM, YYYY')}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Notes"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'notes'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('notes'),
      dataIndex: 'notes',
      key: 'notes',
      width: 400,
      render: (value: any) => (
        <Text className="poppins_font_number flex items-center justify-center break-all font-semibold text-black">
          {value ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Total Hours"
          align="center"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'new_log.total_time'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('new_log.total_time'),
      dataIndex: 'total_time',
      key: 'total_time',
      width: 400,
      render: (_: any, row: any) => (
        <div className="flex items-center justify-center">
          <Text className="poppins_font_number flex items-center justify-center font-semibold text-black">
            {convertSecondsToTime(row?.new_log?.total_time)}
          </Text>
        </div>
      ),
    },
  ];

  return reportsColumnArray;
};
