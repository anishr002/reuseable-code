'use client';

import Spinner from '@/components/ui/spinner';
import { Title } from '@/components/ui/text';
import { SignUpStepper, routes } from '@/config/routes';
import { siteConfig } from '@/config/site.config';
import socket from '@/io';
import {
  clearStepperData,
  goToStep,
  storeStepperData,
} from '@/redux/slices/user/auth/authSlice';
import { setSignInData } from '@/redux/slices/user/auth/signinSlice';
import {
  facebookSignUpUser,
  googleSignUpUser,
} from '@/redux/slices/user/auth/socialSignupSlice';
import { setDefaultWorkspace } from '@/redux/slices/user/workspace/workspaceSlice';
import { initiateRazorpay } from '@/services/paymentService';
import cn from '@/utils/class-names';
import syncuppBanner from '@public/assets/images/syncupp-auth-banner-2.png';
import { GoogleLogin } from '@react-oauth/google';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import FacebookLogin from 'react-facebook-login';
import { toast } from 'react-hot-toast';
import { FaFacebook } from 'react-icons/fa';
import { FcGoogle } from 'react-icons/fc';
import {
  PiArrowLineRight,
  PiFacebookLogo,
  PiGoogleLogo,
  PiUserCirclePlus,
} from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';
import OrSeparation from './or-separation';

export default function AuthWrapperTwo({
  children,
  title,
  isSocialLoginActive = false,
  isSignIn = false,
}: {
  children: React.ReactNode;
  title: React.ReactNode;
  isSocialLoginActive?: boolean;
  isSignIn?: boolean;
}) {
  return (
    <div className="min-h-screen items-center justify-center xl:flex xl:bg-gray-50 ">
      <div className="mx-auto w-full py-2 xl:py-14 2xl:w-[1720px]">
        <div className="rounded-xl bg-white dark:bg-transparent xl:flex dark:xl:bg-gray-100/50">
          <AuthNavBar title={title} />
          <IntroBannerBlock />
          <div className="flex h-[725px] w-full items-center px-4 xl:px-0">
            <div
              className={cn(
                'mx-auto w-full max-w-sm shrink-0 py-16 md:max-w-md md:py-16 xl:px-8 xl:py-10 2xl:max-w-xl 2xl:py-14 3xl:py-20',
                title === 'Sign Up' && 'pt-[18rem]'
              )}
            >
              <Title
                as="h2"
                className="mb-6 text-center text-[26px] font-bold leading-snug md:!leading-normal xl:mb-8 xl:text-start xl:text-3xl xl:text-[28px] 2xl:-mt-1 2xl:text-4xl"
              >
                {title}
              </Title>
              {isSocialLoginActive && (
                <>
                  <SocialAuth isSignIn={isSignIn} />
                  <OrSeparation
                    className="mb-8 dark:before:bg-gray-200 xl:mb-7 dark:[&>span]:bg-[#191919]"
                    title={`OR ${isSignIn ? 'LOGIN' : 'SIGN UP'} WITH`}
                  />
                </>
              )}
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AuthNavLink({
  href,
  children,
}: React.PropsWithChildren<{
  href: string;
}>) {
  const pathname = usePathname();
  function isActive(href: string) {
    if (pathname === href) {
      return true;
    }
    return false;
  }

  return (
    <Link
      href={href}
      className={cn(
        "relative flex items-center gap-x-1.5 text-[15px] font-medium text-gray-700 transition-colors duration-200 before:absolute before:bottom-0 before:start-0 before:h-0.5 before:bg-[#53216F] before:content-[''] hover:text-gray-900 xl:gap-x-2.5 xl:px-6 xl:py-0.5 xl:text-base xl:before:top-0 xl:before:h-full 2xl:px-9 [&>svg]:w-[22px] [&>svg]:shrink-0 xl:[&>svg]:w-6",
        isActive(href) ? 'before:w-full xl:before:w-1' : ' '
      )}
    >
      {children}
    </Link>
  );
}

function AuthNavBar(props: any) {
  return (
    <div className="flex shrink-0 justify-between rounded-bl-xl rounded-tl-xl bg-white px-4 py-4 dark:bg-transparent xl:sticky xl:top-0 xl:w-36 xl:flex-col xl:items-center xl:justify-start xl:px-0 xl:py-14 2xl:w-[184px]">
      <Link href="/" className="mb-1 inline-block max-w-[64px]">
        <Image
          src={siteConfig.logo}
          alt="Isomorphic"
          className="dark:invert"
          width={40}
          height={35}
        />
      </Link>
      <div className="flex space-x-6 xl:w-full xl:flex-col xl:space-x-0 xl:space-y-6 xl:pt-9 2xl:space-y-7 2xl:pt-12 3xl:pt-14">
        {props.title !== 'Set your password' && (
          <AuthNavLink href={routes.signUp}>
            <PiUserCirclePlus className="h-6 w-6" />
            Sign Up
          </AuthNavLink>
        )}
        <AuthNavLink href={routes.signIn}>
          <PiArrowLineRight className="h-[22px] w-[22px]" />
          Sign In
        </AuthNavLink>
      </div>
    </div>
  );
}

export function SocialAuth({ isSignIn = false }: { isSignIn?: boolean }) {
  const facebookAppId =
    process.env.NEXT_PUBLIC_FACEBOOK_APP_ID || '1123503825483323';

  const dispatch = useDispatch();
  const router = useRouter();
  const path = usePathname();
  const { closeModal, openModal } = useModal();
  const socialSignup = useSelector((state: any) => state?.root?.socialSignup);
  const [loader, setLoader] = useState(false);
  const [facebookLogin, setFacebookLogin] = useState(false);
  const handleFacebookClick = () => {
    setFacebookLogin(true);
  };
  const searchParams = useSearchParams();
  const search = searchParams.get('referral');
  const affiliaterefferalcode = searchParams.get('affiliatereferal');
  const affiliateemail = searchParams.get('email');

  const responseFacebook = async (response: any) => {
    setLoader(true);
    // Handle the Facebook login response
    const data = {
      access_token: response.accessToken,
      ...(search && { referral_code: search }),
      ...(affiliaterefferalcode && {
        affiliate_referral_code: affiliaterefferalcode,
      }),
      ...(affiliateemail && {
        affiliate_email: encodeURIComponent(affiliateemail),
      }),
    };
    dispatch(facebookSignUpUser(data)).then(async (result: any) => {
      if (facebookSignUpUser.fulfilled.match(result)) {
        if (result && result?.payload?.success == true) {
          const { user, workspace, token } = result?.payload?.data;

          if (user) {
            if (user.status == 'signup_incomplete') {
              if (path.includes('signin')) {
                router.push(routes.signUp);
              }
              dispatch(clearStepperData());
              dispatch(
                storeStepperData({
                  is_facebook_signup: true,
                  email: user?.email,
                  first_name: user?.first_name,
                  last_name: user?.last_name,
                })
              );
              dispatch(goToStep(SignUpStepper.contactNumberPage));
            } else {
              const loginUserDetailsInWorkspace =
                workspace?.workspace?.members?.find(
                  (data: any) =>
                    data?.user_id == workspace?.workspace?.created_by
                );

              dispatch(clearStepperData());
              dispatch(storeStepperData({ ...user, is_facebook_signup: true }));

              if (!workspace || (workspace && workspace.role == 'agency')) {
                await checkProfileIsComplete(
                  token,
                  user,
                  workspace,
                  result?.payload
                );
              } else {
                if (workspace?.workspace == null) {
                  // User not assign to workspace

                  await checkProfileIsComplete(
                    token,
                    user,
                    workspace?.workspace,
                    result?.payload
                  );
                  return;
                }

                await dispatch(
                  setSignInData({
                    token,
                    workspace,
                    apiResponse: result.payload,
                  })
                );
                dispatch(setDefaultWorkspace(workspace?.workspace));
                socket.disconnect();
                socket.connect();
                if (user?.custom_subscription_plan) {
                  console.log(
                    'custom payment.....',
                    user,
                    user?.custom_subscription_plan
                  );
                  initiateRazorpay(
                    router,
                    routes.dashboard(workspace?.workspace?.name),
                    token,
                    dispatch,
                    user?.custom_subscription_plan,
                    closeModal
                  );
                }
                router.push(routes.dashboard(workspace?.workspace?.name));
              }

              // if (
              //   false &&
              //   !workspace?.workspace?.trial_end_date &&
              //   workspace?.role == 'agency' &&
              //   loginUserDetailsInWorkspace?.status === 'payment_pending'
              // ) {
              //   openModal({
              //     view: <SelectSubscriptionPlanModal title="Choose Your Plan" />,
              //     customSize: '900px',
              //   });
              // } else {
              //   router.push(routes.dashboard(workspace?.workspace?.name));
              // }
            }
            dispatch(goToStep(SignUpStepper.contactNumberPage));
          } else {
            const resultData = result.payload.data;
            if (resultData?.status == 'signup_incomplete') {
              if (path.includes('signin')) {
                router.push(routes.signUp);
              }
              dispatch(clearStepperData());
              dispatch(
                storeStepperData({
                  is_facebook_signup: true,
                  email: resultData?.email,
                  first_name: resultData?.first_name,
                  last_name: resultData?.last_name,
                })
              );
              dispatch(goToStep(SignUpStepper.contactNumberPage));
            } else {
              const loginUserDetailsInWorkspace =
                workspace?.workspace?.members?.find(
                  (data: any) =>
                    data?.user_id == workspace?.workspace?.created_by
                );

              dispatch(clearStepperData());
              dispatch(storeStepperData({ ...user, is_facebook_signup: true }));

              if (!workspace || (workspace && workspace.role == 'agency')) {
                await checkProfileIsComplete(
                  token,
                  user,
                  workspace,
                  result?.payload
                );
              } else {
                if (workspace?.workspace == null) {
                  await checkProfileIsComplete(
                    token,
                    user,
                    workspace?.workspace,
                    result?.payload
                  );
                  // User not assign to workspace
                  toast.error(
                    'You have been not assigned to any workspace, Please Sign up'
                  );
                  return;
                }

                await dispatch(
                  setSignInData({
                    token,
                    workspace,
                    apiResponse: result.payload,
                  })
                );
                socket.disconnect();
                socket.connect();
                dispatch(setDefaultWorkspace(workspace?.workspace));
                if (user?.custom_subscription_plan) {
                  console.log(
                    'custom payment.....',
                    user,
                    user?.custom_subscription_plan
                  );
                  initiateRazorpay(
                    router,
                    routes.dashboard(workspace?.workspace?.name),
                    token,
                    dispatch,
                    user?.custom_subscription_plan,
                    closeModal
                  );
                }
                router.push(routes.dashboard(workspace?.workspace?.name));
              }

              // if (
              //   false &&
              //   !workspace?.workspace?.trial_end_date &&
              //   workspace?.role == 'agency' &&
              //   loginUserDetailsInWorkspace?.status === 'payment_pending'
              // ) {
              //   openModal({
              //     view: <SelectSubscriptionPlanModal title="Choose Your Plan" />,
              //     customSize: '900px',
              //   });
              // } else {
              //   router.push(routes.dashboard(workspace?.workspace?.name));
              // }
            }
          }
        }
        setLoader(false);
      }
    });
  };
  const failureFacebook = async (response: any) => {};

  const checkProfileIsComplete = async (
    token: any,
    user: any,
    workspace: any,
    apiResponse: any
  ) => {
    if (user.first_name == undefined || user.status == 'signup_incomplete') {
      dispatch(goToStep(SignUpStepper.secondSignupPage));
      router.push(routes.signUp);
      return;
    } else if (user.contact_number == undefined) {
      dispatch(goToStep(SignUpStepper.contactNumberPage));
      router.push(routes.signUp);
      return;
    } else if (user.profession_role == undefined) {
      dispatch(goToStep(SignUpStepper.professionPage));
      router.push(routes.signUp);
      return;
    } else if (user.no_of_people == undefined) {
      dispatch(goToStep(SignUpStepper.noOfPeoplePage));
      router.push(routes.signUp);
      return;
    } else if (workspace == undefined || workspace == null) {
      dispatch(goToStep(SignUpStepper.createWorkspacePage));
      router.push(routes.signUp);
      return;
    } else {
      // localStorage.setItem('token', token);
      await dispatch(setSignInData({ token, workspace, apiResponse }));
      await dispatch(setDefaultWorkspace(workspace?.workspace));
      socket.disconnect();
      socket.connect();
      if (user?.custom_subscription_plan) {
        console.log(
          'custom payment.....',
          user,
          user?.custom_subscription_plan
        );
        initiateRazorpay(
          router,
          routes.dashboard(workspace?.workspace?.name),
          token,
          dispatch,
          user?.custom_subscription_plan,
          closeModal
        );
      }
      router.replace(routes.dashboard(workspace?.workspace?.name));
      // }
    }
  };

  return (
    <div className="grid grid-cols-1 gap-4 pb-7 lg:grid-cols-2 xl:gap-5 xl:pb-8">
      <div className="google-button relative flex w-full content-start">
        {/*original google button*/}
        <GoogleLogin
          auto_select={false}
          theme="outline"
          size="large"
          shape="rectangular"
          logo_alignment="left"
          text="continue_with"
          width="261"
          onSuccess={(credentialResponse: any) => {
            const data = {
              signupId: credentialResponse.credential,
              ...(search && { referral_code: search }),
              ...(affiliaterefferalcode && {
                affiliate_referral_code: affiliaterefferalcode,
              }),
              ...(affiliateemail && {
                affiliate_email: encodeURIComponent(affiliateemail),
              }),
            };

            dispatch(googleSignUpUser(data)).then(async (result: any) => {
              if (googleSignUpUser.fulfilled.match(result)) {
                if (result && result.payload.success === true) {
                  const { user, token, workspace } = result.payload.data;

                  // if profile is incomplete
                  if (user) {
                    if (user.status == 'signup_incomplete') {
                      if (path.includes('signin')) {
                        router.push(routes.signUp);
                      }

                      dispatch(clearStepperData());
                      dispatch(
                        storeStepperData({
                          is_google_signup: true,
                          email: user?.email,
                          first_name: user?.first_name,
                          last_name: user?.last_name,
                        })
                      );
                      dispatch(goToStep(SignUpStepper.contactNumberPage));
                    } else {
                      const loginUserDetailsInWorkspace =
                        workspace?.workspace?.members?.find(
                          (data: any) =>
                            data?.user_id == workspace?.workspace?.created_by
                        );

                      dispatch(clearStepperData());
                      dispatch(
                        storeStepperData({ ...user, is_google_signup: true })
                      );

                      if (
                        !workspace ||
                        (workspace && workspace.role == 'agency')
                      ) {
                        await checkProfileIsComplete(
                          token,
                          user,
                          workspace,
                          result?.payload
                        );
                      } else {
                        if (workspace?.workspace == null) {
                          // User not assign to workspace

                          await checkProfileIsComplete(
                            token,
                            user,
                            workspace?.workspace,
                            result?.payload
                          );
                          return;
                        }

                        await dispatch(
                          setSignInData({
                            token,
                            workspace,
                            apiResponse: result.payload,
                          })
                        );
                        dispatch(setDefaultWorkspace(workspace?.workspace));
                        socket.disconnect();
                        socket.connect();
                        if (user?.custom_subscription_plan) {
                          console.log(
                            'custom payment.....',
                            user,
                            user?.custom_subscription_plan
                          );
                          initiateRazorpay(
                            router,
                            routes.dashboard(workspace?.workspace?.name),
                            token,
                            dispatch,
                            user?.custom_subscription_plan,
                            closeModal
                          );
                        }
                        router.push(
                          routes.dashboard(workspace?.workspace?.name)
                        );
                      }
                    }
                  } else {
                    const resultData = result.payload.data;
                    if (resultData?.status == 'signup_incomplete') {
                      if (path.includes('signin')) {
                        router.push(routes.signUp);
                      }
                      dispatch(clearStepperData());
                      dispatch(
                        storeStepperData({
                          is_google_signup: true,
                          email: resultData?.email,
                          first_name: resultData?.first_name,
                          last_name: resultData?.last_name,
                        })
                      );
                      dispatch(goToStep(SignUpStepper.contactNumberPage));
                    } else {
                      const loginUserDetailsInWorkspace =
                        workspace?.workspace?.members?.find(
                          (data: any) =>
                            data?.user_id == workspace?.workspace?.created_by
                        );

                      dispatch(clearStepperData());
                      dispatch(
                        storeStepperData({ ...user, is_google_signup: true })
                      );

                      if (
                        !workspace ||
                        (workspace && workspace.role == 'agency')
                      ) {
                        await checkProfileIsComplete(
                          token,
                          user,
                          workspace,
                          result?.payload
                        );
                      } else {
                        if (workspace?.workspace == null) {
                          await checkProfileIsComplete(
                            token,
                            user,
                            workspace?.workspace,
                            result?.payload
                          );
                          // User not assign to workspace
                          toast.error(
                            'You have been not assigned to any workspace, Please Sign up'
                          );
                          return;
                        }

                        await dispatch(
                          setSignInData({
                            token,
                            workspace,
                            apiResponse: result.payload,
                          })
                        );
                        dispatch(setDefaultWorkspace(workspace?.workspace));
                        socket.disconnect();
                        socket.connect();
                        if (user?.custom_subscription_plan) {
                          console.log(
                            'custom payment.....',
                            user,
                            user?.custom_subscription_plan
                          );
                          initiateRazorpay(
                            router,
                            routes.dashboard(workspace?.workspace?.name),
                            token,
                            dispatch,
                            user?.custom_subscription_plan,
                            closeModal
                          );
                        }
                        router.push(
                          routes.dashboard(workspace?.workspace?.name)
                        );
                      }
                    }
                  }
                }
              }
            });
          }}
          onError={() => {
            console.log('error');
          }}
        />

        <div className="testinggs w-[50%] overflow-hidden">
          <GoogleLogin
            auto_select={false}
            theme="outline"
            size="large"
            shape="rectangular"
            logo_alignment="left"
            text="continue_with"
            width="400 | 200"
            onSuccess={(credentialResponse: any) => {
              const data = {
                signupId: credentialResponse.credential,
                ...(search && { referral_code: search }),
                ...(affiliaterefferalcode && {
                  affiliate_referral_code: affiliaterefferalcode,
                }),
                ...(affiliateemail && {
                  affiliate_email: encodeURIComponent(affiliateemail),
                }),
              };

              dispatch(googleSignUpUser(data)).then((result: any) => {
                if (googleSignUpUser.fulfilled.match(result)) {
                  if (result && result.payload.success === true) {
                    // router.replace(routes.dashboard);
                  }
                }
              });
            }}
            onError={() => {}}
          />
        </div>

        {/*custom button to show*/}
        <div className="absolute left-0 top-0 z-30 w-full cursor-pointer">
          <Button
            variant="outline"
            className="facebook-button small mb-4 h-14 w-full text-wrap border-2 border-[#8C80D2] bg-white text-[16px] font-semibold hover:border-[#8C80D2] "
            rounded="lg"
            disabled={socialSignup.loading && !loader}
          >
            <FcGoogle className="me-2 h-4 w-4 shrink-0" />
            <span className="text-wrap">{`${
              isSignIn ? 'Login' : 'Sign up'
            } with Google`}</span>
            {socialSignup.loading && !loader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
      </div>

      <Button
        variant="outline"
        className="relative mt-4 h-14 w-full border-[#8C80D2]  text-[16px] font-semibold hover:border-[#8C80D2] lg:mt-0"
        rounded="lg"
        disabled={loader}
        onClick={handleFacebookClick}
      >
        <FaFacebook className="me-2 h-6 w-6 shrink-0 text-blue-700" />
        {facebookLogin && (
          <FacebookLogin
            textButton={`${isSignIn ? 'Login' : 'Sign up'} with Facebook`}
            appId={facebookAppId}
            size="small"
            autoLoad={true}
            fields="name,email,first_name,last_name"
            callback={responseFacebook}
            onFailure={failureFacebook}
            cssClass="facebook-button"
          />
        )}
        {!facebookLogin && `${isSignIn ? 'Login' : 'Sign up'} with Facebook`}
        {loader && <Spinner size="sm" tag="div" className="ms-3" />}
      </Button>
    </div>
  );
}

function IntroBannerBlock() {
  return (
    <div className="relative hidden w-[calc(50%-50px)] shrink-0 rounded-lg xl:-my-9 xl:block xl:w-[calc(50%-20px)] 2xl:-my-12 3xl:-my-14">
      <div className="absolute mx-auto h-full w-full overflow-hidden rounded-lg before:absolute before:start-0 before:top-0 before:z-10 before:h-full before:w-full">
        <Image
          fill
          priority
          src={syncuppBanner}
          alt="Syncupp Banner"
          sizes="(max-width: 768px) 100vw"
          className="bg-[#53216F]"
        />
      </div>
    </div>
  );
}

const socialLinks = [
  {
    title: 'Facebook',
    link: 'https://www.facebook.com/',
    icon: <PiFacebookLogo className="h-auto w-6" />,
  },
  {
    title: 'Google',
    link: 'https://www.google.com/',
    icon: <PiGoogleLogo className="h-auto w-6" />,
  },
];

function SocialLinks() {
  return (
    <div className="-mx-2 flex items-center pt-24 text-white xl:-mx-2.5 2xl:pb-5 2xl:pt-40 [&>a>svg]:w-5 xl:[&>a>svg]:w-6">
      {socialLinks?.map((item) => (
        <a
          key={item.title}
          href={item.link}
          title={item.title}
          target="_blank"
          className="mx-2 py-4 text-[16px] font-semibold transition-opacity hover:opacity-80 xl:mx-2.5"
        >
          {item.icon}
        </a>
      ))}
    </div>
  );
}
