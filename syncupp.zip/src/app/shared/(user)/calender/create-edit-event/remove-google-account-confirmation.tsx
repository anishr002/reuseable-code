"use client";
import { useModal } from "@/app/shared/modal-views/use-modal";
import Spinner from "@/components/ui/spinner";
import { deleteGoogleCalendarConfigAccount, getAllGoogleCalendarConfigAccounts, getVerifyGoogleCalendarConfig } from "@/redux/slices/user/activity/activitySlice";
import cn from "@/utils/class-names";
import { PiXBold } from "react-icons/pi";
import { useDispatch, useSelector } from "react-redux";
import { ActionIcon, Button, Text, Title } from "rizzui";


export function ConfirmationRemoveUserModal(props: any) {
    const { user } = props;
    const dispatch = useDispatch();
    const { openModal, closeModal } = useModal();

    const { deleteGoogleCalendarConfigAccountLoader } = useSelector((state: any) => state?.root?.activity);

    const handleDeleteBoard = () => {
        dispatch(deleteGoogleCalendarConfigAccount({
            _id: user?._id ?? ''
        })).then((result: any) => {
            if (deleteGoogleCalendarConfigAccount.fulfilled.match(result)) {
                console.log("Api response for delete....", result);
                if (result.payload.success === true) {
                    dispatch(getVerifyGoogleCalendarConfig());
                    dispatch(getAllGoogleCalendarConfigAccounts()).then((result: any) => {
                        if (getAllGoogleCalendarConfigAccounts.fulfilled.match(result)) {
                            if (result && result.payload.success === true) {
                                // const findSelectedUser = result?.payload?.data && result?.payload?.data?.length > 0 ? result?.payload?.data?.find((user: any) => user.is_selected) : result?.payload?.data[0];
                                // findSelectedUser && setConfiguredUser(findSelectedUser?._id);
                                // setIsConfigured(true);
                            }
                        }
                    });
                    closeModal();
                }
            }
        });
    }


    return (
        <div className="p-6">
            <div className="flex flex-col items-center justify-start gap-4">
                <div className="w-full flex items-center justify-between">
                    <Title
                        as="h6"
                        className="mb-0.5 flex items-center text-sm text-[#8C80D2] sm:items-center"
                    >
                        Confirm Deletion
                    </Title>
                    <ActionIcon
                        size="sm"
                        variant="text"
                        onClick={() => closeModal()}
                        className="p-0 text-gray-500 hover:!text-gray-900"
                    >
                        <PiXBold className="h-[18px] w-[18px]" />
                    </ActionIcon>
                </div>
                <Text className="leading-relaxed text-[#9BA1B9]">
                Are you sure you want to remove the Google Calendar?
                </Text>
            </div>
            <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
                <div className="flex items-center justify-end gap-2">
                    <Button
                        className="bg-[#8C80D2] text-white @xl:w-auto dark:text-white"
                        disabled={deleteGoogleCalendarConfigAccountLoader}
                        onClick={handleDeleteBoard}
                    >
                        Delete
                        {deleteGoogleCalendarConfigAccountLoader && (
                            <Spinner size="sm" tag="div" className="ms-3" color="white" />
                        )}
                    </Button>
                </div>
                <div>
                    <Button
                        variant="outline"
                        className="@xl:w-auto text-[#9BA1B9] dark:hover:border-gray-400"
                        onClick={() => closeModal()}
                    >
                        Cancel
                    </Button>
                </div>
            </div>
        </div>
    );
}