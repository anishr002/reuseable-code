'use client';

import { Button } from '@/components/ui/button';
import { Controller, SubmitHandler, useFormContext } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';
import { useModal } from '@/app/shared/modal-views/use-modal';
import cn from '@/utils/class-names';
import { Input } from '@/components/ui/input';
import dynamic from 'next/dynamic';
import SelectLoader from '@/components/loader/select-loader';
import { useEffect, useState } from 'react';
import { handleKeyDown } from '@/utils/common-functions';
import QuillLoader from '@/components/loader/quill-loader';
import { DatePicker } from '@/components/ui/datepicker';
import { Checkbox } from '@/components/ui/checkbox';
import SelectBox from '@/components/ui/select';
import moment from 'moment';
import {
  AddCallMeetingSchema,
  addCallMeetingSchema,
} from '@/utils/validators/add-activity.schema';
import { Text, Textarea, Title } from 'rizzui';
import { AiOutlineUsergroupAdd } from 'react-icons/ai';
import { GiNotebook } from 'react-icons/gi';
import Select, { components } from 'react-select';
import {
  getActivityById,
  getAllActivity,
  getAssignedActivityConfirmation,
  patchEditActivity,
  postAddActivity,
} from '@/redux/slices/user/activity/activitySlice';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px]" />,
});

export default function AddCallMeetingForm(props: any) {
  const {
    title,
    row,
    isClientModule,
    isClientEdit,
    isTeamEdit,
    clientName,
    clientReferenceId,
    isTeamModule,
    teamName,
    teamReferenceId,
    isAgencyTeam,
    isClientTeam,
    isCalendarCallActivity,
    startDate,
    endDate,
  } = props;
  // console.log("row data....", row);

  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const router = useRouter();

  const [clientId, setClientId] = useState('');
  const [teamId, setTeamId] = useState('');
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const activityData = useSelector((state: any) => state?.root?.activity);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const [loader, setLoader] = useState(false);
  const { calendarView } = useSelector((state: any) => state?.root?.activity);
  const [moduleOptions, setModuleOptions] = useState<any[]>([]);
  const [selectedOption, setSelectedOption] = useState<any[]>([]);
  const [selectedUserOption, setSelectedUserOption] = useState<any[]>([]);
  const [planModuleError, setPlanModuleError] = useState('');

  let attendeesOriginalOptions: any[] = [];

  // const [attendeesOptions, setAttendeesOptions] = useState<any[]>([]);

  // console.log("selected options...", selectedOption)
  // console.log("moduleOptions options...", moduleOptions)

  const [isTextAreaVisible, setTextAreaVisible] = useState(false);

  const handleAddNoteClick = () => {
    setTextAreaVisible((prevVisible) => !prevVisible);
  };

  useEffect(() => {
    isClientModule && clientReferenceId && setClientId(clientReferenceId);
  }, [clientReferenceId, isClientModule]);

  useEffect(() => {
    isTeamModule && teamReferenceId && setTeamId(teamReferenceId);
  }, [teamReferenceId, isTeamModule]);

  useEffect(() => {
    if (signIn && signIn?.teamMemberRole === 'team_member') {
      setTeamId(signIn?.user?.data?.user?.reference_id);
    }
  }, [signIn]);

  // let data = row;

  const initialValues: AddCallMeetingSchema = {
    title: '',
    description: '',
    due_date: new Date(),
    start_time: new Date(),
    end_time: new Date(),
    client: '',
    assigned:
      signIn?.teamMemberRole === 'team_member'
        ? signIn?.user?.data?.user?.name
        : '',
    notes: '',
    done: false,
  };

  useEffect(() => {
    row &&
      dispatch(getActivityById({ activityId: row?._id })).then(
        (result: any) => {
          if (getActivityById.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setClientId(result?.payload?.data[0]?.client_id);
              setTeamId(result?.payload?.data[0]?.assign_to);
            }
          }
        }
      );
  }, [row, dispatch]);

  let [data] = activityData?.activity ?? [{}];

  // const dueee_date = moment(data?.due_date).toDate();
  // console.log("formateedddd", moment(data?.meeting_start_time).format('hh:mm A'))

  // useEffect(() => {
  //   const editSelectedValue: any = [];
  //   moduleOptions && moduleOptions?.length > 0 && moduleOptions?.map((user: any) => {
  //     data && data?.attendees?.length > 0 && data?.attendees?.map((attendeeId: string) => {
  //       if (attendeeId === user?.value) {
  //         editSelectedValue?.push(user)
  //       }
  //     })
  //   }) || []

  //   console.log("editSelectedValue.....", selectedOption)

  //   setSelectedOption(editSelectedValue)

  // }, [moduleOptions])

  // useEffect(() => {
  //   if (signIn && signIn.teamMemberRole === 'team_member') {
  //     const updatedTeamMemberModuleAttendees = moduleOptions.filter((option) => {
  //       return option.value !== signIn.user.data.user.reference_id;
  //     });

  //     setModuleOptions(updatedTeamMemberModuleAttendees);
  //   }
  // }, [signIn]);

  // setTimeout(() => {
  //   if (signIn && signIn.teamMemberRole === 'team_member') {
  //     const updatedTeamMemberModuleAttendees = moduleOptions.filter((option) => {
  //       return option.value !== signIn.user.data.user.reference_id;
  //     });

  //     setModuleOptions(updatedTeamMemberModuleAttendees);
  //   }
  // }, 4000)

  useEffect(() => {
    if (
      moduleOptions &&
      moduleOptions?.length > 0 &&
      data &&
      data?.attendees &&
      data?.attendees?.length > 0
    ) {
      const editSelectedValue = moduleOptions?.filter(
        (user) => data?.attendees?.includes(user?.value)
      );
      setSelectedOption(editSelectedValue);
      // console.log("editSelectedValue.....", selectedOption)
      setSelectedUserOption([...data?.attendees]);
    }
  }, [moduleOptions, data]);

  useEffect(() => {
    if (title === 'Edit Meeting' && data?.internal_info) {
      setTextAreaVisible(true);
    }
  }, [title, data?.internal_info]);

  let defaultValuess = isClientModule
    ? {
        title: data?.title,
        description: data?.agenda,
        // due_date: new Date(data?.due_date),
        due_date: moment(data?.due_date).toDate(),
        start_time: moment(data?.meeting_start_time).toDate(),
        end_time: moment(data?.meeting_end_time).toDate(),
        client: isClientModule ? clientName : data?.client_name,
        notes: data?.internal_info,
        assigned:
          signIn?.teamMemberRole === 'team_member'
            ? signIn?.user?.data?.user?.first_name.charAt(0).toUpperCase() +
              signIn?.user?.data?.user?.first_name.slice(1) +
              ' ' +
              signIn?.user?.data?.user?.last_name.charAt(0).toUpperCase() +
              signIn?.user?.data?.user?.last_name.slice(1)
            : data?.assigned_to_name,
        done: data?.status === 'completed' ? true : false,
      }
    : isTeamModule
      ? {
          title: data?.title,
          description: data?.agenda,
          // due_date: new Date(data?.due_date),
          due_date: moment(data?.due_date).toDate(),
          start_time: moment(data?.meeting_start_time).toDate(),
          end_time: moment(data?.meeting_end_time).toDate(),
          client: data?.client_name,
          notes: data?.internal_info,
          assigned:
            isTeamModule && teamName ? teamName : data?.assigned_to_name,
          done: data?.status === 'completed' ? true : false,
        }
      : isCalendarCallActivity
        ? {
            title: data?.title,
            description: data?.agenda,
            // due_date: new Date(data?.due_date),
            due_date: startDate,
            start_time: startDate,
            end_time: endDate,
            client: data?.client_name,
            notes: data?.internal_info,
            assigned:
              signIn?.teamMemberRole === 'team_member'
                ? signIn?.user?.data?.user?.first_name.charAt(0).toUpperCase() +
                  signIn?.user?.data?.user?.first_name.slice(1) +
                  ' ' +
                  signIn?.user?.data?.user?.last_name.charAt(0).toUpperCase() +
                  signIn?.user?.data?.user?.last_name.slice(1)
                : data?.assigned_to_name,
            done: data?.status === 'completed' ? true : false,
          }
        : {
            title: data?.title,
            description: data?.agenda,
            // due_date: new Date(data?.due_date),
            due_date: moment(data?.due_date).toDate(),
            start_time: moment(data?.meeting_start_time).toDate(),
            end_time: moment(data?.meeting_end_time).toDate(),
            client: data?.client_name,
            notes: data?.internal_info,
            assigned:
              signIn?.teamMemberRole === 'team_member'
                ? signIn?.user?.data?.user?.first_name.charAt(0).toUpperCase() +
                  signIn?.user?.data?.user?.first_name.slice(1) +
                  ' ' +
                  signIn?.user?.data?.user?.last_name.charAt(0).toUpperCase() +
                  signIn?.user?.data?.user?.last_name.slice(1)
                : data?.assigned_to_name,
            done: data?.status === 'completed' ? true : false,
          };

  let clientOptions: Record<string, any>[] = [];
  if (clientSliceData?.clientList && clientSliceData?.clientList?.length > 0) {
    clientOptions = clientSliceData.clientList.map(
      (client: Record<string, any>) => {
        let client_name =
          client?.first_name.charAt(0).toUpperCase() +
          client?.first_name.slice(1) +
          ' ' +
          client?.last_name.charAt(0).toUpperCase() +
          client?.last_name.slice(1);
        return { name: client_name, value: client?.reference_id, key: client };
      }
    );

    // Add default selection option
    clientOptions.unshift({ name: 'Select Client', value: '', key: {} });
  }

  // let clientOptions: Record<string, any>[] = clientSliceData?.clientList && clientSliceData?.clientList?.length > 0 ? clientSliceData?.clientList?.map((client: Record<string, any>) => {
  //   let client_name = client?.first_name.charAt(0).toUpperCase() + client?.first_name.slice(1) + " " + client?.last_name.charAt(0).toUpperCase() + client?.last_name.slice(1);
  //   return { name: client_name, value: client?.reference_id, key: client }
  // }) : [];

  let teamOptions: Record<string, any>[] =
    teamMemberData?.teamList && teamMemberData?.teamList?.length > 0
      ? teamMemberData?.teamList?.map((team: Record<string, any>) => {
          let team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return { name: team_name, value: team?.reference_id, key: team };
        })
      : [];

  let clientMultiOptions: Record<string, any>[] =
    clientSliceData?.clientList && clientSliceData?.clientList?.length > 0
      ? clientSliceData?.clientList?.map((client: Record<string, any>) => {
          let client_name =
            client?.first_name.charAt(0).toUpperCase() +
            client?.first_name.slice(1) +
            ' ' +
            client?.last_name.charAt(0).toUpperCase() +
            client?.last_name.slice(1);
          return {
            label: `${client_name} (${client?.email})`,
            value: client?.reference_id,
          };
        })
      : [];

  let teamMultiOptions: Record<string, any>[] =
    teamMemberData?.teamList && teamMemberData?.teamList?.length > 0
      ? teamMemberData?.teamList?.map((team: Record<string, any>) => {
          let team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return {
            label: `${team_name} (${team?.email})`,
            value: team?.reference_id,
          };
        })
      : [];

  attendeesOriginalOptions = [...clientMultiOptions, ...teamMultiOptions];

  // console.log("attendeesOriginalOptions options...", attendeesOriginalOptions)

  useEffect(() => {
    // const clientTypeOptions = [
    //   { value: 1, label: 'Trail' },
    //   { value: 2, label: 'Paid' },
    //   { value: 3, label: 'Custom' },
    // ];
    // setModuleOptions([ ...clientTypeOptions])

    if (clientMultiOptions && teamMultiOptions) {
      if (signIn && signIn.teamMemberRole === 'team_member') {
        const updatedTeamMemberModuleAttendees = (teamMultiOptions &&
          teamMultiOptions?.filter((option) => {
            return option.value !== signIn.user.data.user.reference_id;
          })) || [...teamMultiOptions];
        setModuleOptions([
          ...clientMultiOptions,
          ...updatedTeamMemberModuleAttendees,
        ]);
      } else {
        setModuleOptions([...clientMultiOptions, ...teamMultiOptions]);
      }
    }
  }, []);

  const handleChange = (selectedOption: any) => {
    // console.log("sellllllllllleeecteed option", selectedOption)
    setSelectedOption(selectedOption);

    let userRefId: any[] = [];

    selectedOption &&
      selectedOption?.length > 0 &&
      selectedOption?.map((user: any) => {
        userRefId?.push(user?.value);
      });

    setSelectedUserOption([...userRefId]);

    // if (!selectedOption || selectedOption.length === 0) {
    //   setPlanModuleError('At least one select module.*');
    // } else {
    //   setPlanModuleError('')
    // }
    // setLoading(false);
  };

  const Option = (props: any) => {
    // console.log("Option props....", props);
    return (
      <div>
        <components.Option {...props}>
          <Checkbox
            label={props.label}
            checked={props.isSelected}
            color="info"
            // variant="flat"
            className=" cursor-pointer [&>label>span]:font-medium"
            labelClassName="text-1.20em md:text-1.20em lg:text-1.20em xl:text-1.20em text-gray-700 dark:text-gray-600 mb-1.5 cursor-pointer"
          />
        </components.Option>
      </div>
    );
  };
  const MultiValue = (props: any) => {
    // console.log("Multivalue props....", props);
    return (
      <components.MultiValue {...props}>
        <span>{props.data.label}</span>
      </components.MultiValue>
    );
  };
  const allOption = {
    label: 'Select all',
    value: '*',
  };

  const optionsWithSelectAll = [allOption, ...moduleOptions];

  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected ? 'white' : 'white',
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  const onSubmit: SubmitHandler<AddCallMeetingSchema> = (dataa) => {
    console.log('Add call meeting form dataa---->', dataa);
    setLoader(true);

    const updatedSelectedUserOptionClientIdRemove =
      (selectedUserOption &&
        selectedUserOption?.length > 0 &&
        selectedUserOption?.filter((userId) => {
          return userId !== clientId;
        })) ||
      [];

    const updatedSelectedUserOptionTeamIdRemove =
      (updatedSelectedUserOptionClientIdRemove &&
        updatedSelectedUserOptionClientIdRemove?.length > 0 &&
        updatedSelectedUserOptionClientIdRemove?.filter((userId) => {
          return userId !== teamId;
        })) ||
      [];

    const formData = {
      title: dataa?.title,
      agenda: dataa?.description,
      due_date: moment(dataa?.due_date).format('DD-MM-YYYY'),
      meeting_start_time: moment.utc(dataa?.start_time).format('HH:mm'),
      meeting_end_time: moment.utc(dataa?.end_time).format('HH:mm'),
      client_id: clientId,
      assign_to: teamId,
      activity_type: 'call_meeting',
      internal_info: dataa?.notes === '' ? null : dataa?.notes,
      mark_as_done: dataa?.done,
      attendees: updatedSelectedUserOptionTeamIdRemove,
    };

    // console.log('Add activity form dataa---->', formData);

    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(
        ([_, value]) => value !== undefined && value !== ''
      )
    );

    // dispatch(getAssignedActivityConfirmation()).then((result: any) => {
    //   if (getAssignedActivityConfirmation.fulfilled.match(result)) {
    //     if (result && result.payload.success === true) {
    //       console.log("result is.....", result)
    //     }
    //   }
    // });

    if (title === 'New Meeting') {
      dispatch(postAddActivity(filteredFormData)).then((result: any) => {
        if (postAddActivity.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setLoader(false);
            closeModal();

            if (title === 'New Meeting' && isClientModule && isAgencyTeam) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  client_id: clientReferenceId,
                  pagination: true,
                })
              );
            } else if (
              title === 'New Meeting' &&
              !isAgencyTeam &&
              !isTeamModule
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  client_team_id: clientReferenceId,
                  pagination: true,
                })
              );
            } else if (
              title === 'New Meeting' &&
              isTeamModule &&
              isAgencyTeam
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  team_id: teamReferenceId,
                  pagination: true,
                })
              );
            } else if (
              (title === 'New Meeting' && !isClientModule) ||
              (title === 'New Meeting' && !isTeamModule)
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                })
              );
            }

            if (calendarView) {
              const firstDayOfMonth = moment()
                .startOf('month')
                .format('DD-MM-YYYY');
              const endDayOfMonth = moment()
                .endOf('month')
                .format('DD-MM-YYYY');
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  filter: {
                    date: 'period',
                    start_date: firstDayOfMonth,
                    end_date: endDayOfMonth,
                  },
                  pagination: false,
                })
              );
            }
          } else {
            setLoader(false);
          }
        }
      });
    } else {
      dispatch(patchEditActivity({ ...filteredFormData, _id: data._id })).then(
        (result: any) => {
          if (patchEditActivity.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setLoader(false);
              closeModal();

              if (title === 'Edit Meeting' && isClientEdit && !isClientTeam) {
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    client_id: clientId,
                    pagination: true,
                  })
                );
              } else if (
                title === 'Edit Meeting' &&
                !isClientEdit &&
                isTeamEdit &&
                !isClientTeam
              ) {
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    team_id: teamId,
                    pagination: true,
                  })
                );
              } else if (
                title === 'Edit Meeting' &&
                isClientEdit &&
                isClientTeam
              ) {
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    client_team_id: clientId,
                    pagination: true,
                  })
                );
              } else if (
                (title === 'Edit Meeting' && !isClientEdit) ||
                (title === 'Edit Meeting' && !isTeamEdit)
              ) {
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    pagination: true,
                  })
                );
              }

              if (calendarView) {
                const firstDayOfMonth = moment()
                  .startOf('month')
                  .format('DD-MM-YYYY');
                const endDayOfMonth = moment()
                  .endOf('month')
                  .format('DD-MM-YYYY');
                dispatch(
                  getAllActivity({
                    sort_field: 'createdAt',
                    sort_order: 'desc',
                    filter: {
                      date: 'period',
                      start_date: firstDayOfMonth,
                      end_date: endDayOfMonth,
                    },
                    pagination: false,
                  })
                );
              }
            } else {
              setLoader(false);
            }
          }
        }
      );
    }
  };

  if (!activityData?.activity && title === 'Edit Meeting') {
    return (
      <div className="mt-[14rem] flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <>
        <Form<AddCallMeetingSchema>
          validationSchema={addCallMeetingSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'all',
            defaultValues: defaultValuess,
          }}
          className="[&_label]:font-medium"
        >
          {({ register, control, formState: { errors } }) => (
            <div className="space-y-5">
              {/* <div className="mb-6 flex items-center justify-between">
                <Title as="h3" className="text-xl xl:text-2xl">
                  {title}
                  New activity
                </Title>
              </div> */}
              <div>
                <div className="grid gap-5">
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    label="Title *"
                    placeholder="Enter title"
                    color="info"
                    className="[&>label>span]:font-medium"
                    {...register('title')}
                    error={errors?.title?.message}
                  />
                  <Controller
                    control={control}
                    name="description"
                    render={({ field: { onChange, value } }) => (
                      <QuillEditor
                        value={value}
                        onChange={onChange}
                        onKeyDown={handleKeyDown}
                        placeholder="Enter description"
                        label="Description"
                        className="col-span-full [&_.ql-editor]:min-h-[100px]"
                        labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                      />
                    )}
                  />
                  <div
                    className={cn(
                      'grid grid-cols-1 items-center gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3'
                    )}
                  >
                    <div>
                      <Controller
                        name="due_date"
                        control={control}
                        render={({ field: { value, onChange } }) => (
                          <DatePicker
                            placeholderText="Select start date"
                            selected={value}
                            inputProps={{
                              label: 'Start Date *',
                              color: 'info',
                              error: errors?.due_date?.message,
                            }}
                            onChange={onChange}
                            selectsStart
                            startDate={value}
                            minDate={new Date()}
                            // showTimeSelect
                            dateFormat="MMMM dd, yyyy"
                          />
                        )}
                      />
                    </div>
                    <div>
                      <Controller
                        name="start_time"
                        control={control}
                        render={({ field: { value, onChange } }) => (
                          <DatePicker
                            placeholderText="Select start time"
                            selected={value}
                            inputProps={{
                              label: 'Start Time *',
                              color: 'info',
                              error: errors?.start_time?.message,
                            }}
                            onChange={onChange}
                            showTimeSelect
                            showTimeSelectOnly
                            dateFormat="hh:mm aa"
                          />
                        )}
                      />
                    </div>
                    <div>
                      <Controller
                        name="end_time"
                        control={control}
                        render={({ field: { value, onChange } }) => (
                          <DatePicker
                            placeholderText="Select end time"
                            selected={value}
                            inputProps={{
                              label: 'End Time *',
                              color: 'info',
                              error: errors?.end_time?.message,
                            }}
                            onChange={onChange}
                            showTimeSelect
                            showTimeSelectOnly
                            dateFormat="hh:mm aa"
                          />
                        )}
                      />
                    </div>
                  </div>
                  {clientSliceData?.loading ? (
                    <SelectLoader />
                  ) : (
                    <Controller
                      control={control}
                      name="client"
                      render={({ field: { onChange, value } }) => (
                        <SelectBox
                          options={clientOptions}
                          onChange={(selectedOption: Record<string, any>) => {
                            onChange(selectedOption?.name);
                            setClientId(selectedOption?.value);
                            let updateAfterClientOption =
                              (attendeesOriginalOptions &&
                                attendeesOriginalOptions?.length > 0 &&
                                attendeesOriginalOptions?.filter(
                                  (option: any, index: any) => {
                                    return (
                                      option?.value !== selectedOption?.value
                                    );
                                  }
                                )) || [...moduleOptions];

                            let updateAfterTeamIdRemoveOption =
                              (updateAfterClientOption &&
                                updateAfterClientOption?.length > 0 &&
                                updateAfterClientOption?.filter(
                                  (option: any, index: any) => {
                                    return option?.value !== teamId;
                                  }
                                )) || [...moduleOptions];

                            setModuleOptions(updateAfterTeamIdRemoveOption);
                            // handleClientChange(selectedOption);
                          }}
                          value={value}
                          placeholder="Select Client"
                          label="Client"
                          error={errors?.client?.message as string}
                          color="info"
                          // getOptionValue={(option) => option.value}
                          disabled={isClientModule || isClientEdit}
                          className="[&>label>span]:font-medium"
                          dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg"
                        />
                      )}
                    />
                  )}
                  {teamMemberData?.loading ? (
                    <SelectLoader />
                  ) : (
                    <Controller
                      control={control}
                      name="assigned"
                      render={({ field: { onChange, value } }) => (
                        <SelectBox
                          options={teamOptions}
                          onChange={(selectedOption: Record<string, any>) => {
                            onChange(selectedOption?.name);
                            setTeamId(selectedOption?.value);

                            let updateAfterAssigneeOption =
                              (attendeesOriginalOptions &&
                                attendeesOriginalOptions?.length > 0 &&
                                attendeesOriginalOptions?.filter(
                                  (option: any, index: any) => {
                                    return (
                                      option?.value !== selectedOption?.value
                                    );
                                  }
                                )) || [...moduleOptions];

                            let updateAfterClientIdRemoveOption =
                              (updateAfterAssigneeOption &&
                                updateAfterAssigneeOption?.length > 0 &&
                                updateAfterAssigneeOption?.filter(
                                  (option: any, index: any) => {
                                    return option?.value !== clientId;
                                  }
                                )) || [...moduleOptions];

                            setModuleOptions(updateAfterClientIdRemoveOption);

                            // handleTeamChange(selectedOption);
                          }}
                          value={
                            signIn?.teamMemberRole === 'team_member'
                              ? signIn?.user?.data?.user?.name
                              : value
                          }
                          placeholder="Select Team member"
                          label="Assigned *"
                          disabled={
                            signIn?.teamMemberRole === 'team_member' ||
                            isTeamModule ||
                            isTeamEdit
                          }
                          error={errors?.assigned?.message as string}
                          color="info"
                          // getOptionValue={(option) => option.value}
                          className="[&>label>span]:font-medium"
                          dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg"
                        />
                      )}
                    />
                  )}
                  <div>
                    <div className="col-span-full sm:col-span-full">
                      <label className="mb-1.5 block text-sm font-medium">
                        Attendees
                      </label>
                      <Select
                        options={optionsWithSelectAll}
                        onChange={(selected: any) => {
                          if (
                            selected !== null &&
                            selected.length > 0 &&
                            selected[selected.length - 1].value ===
                              allOption.value
                          ) {
                            // const filterOptions = moduleOptions?.map((module) => {
                            //   return module?.label
                            // })
                            return handleChange(moduleOptions);
                          }
                          return handleChange(selected);
                        }}
                        value={selectedOption}
                        isMulti
                        // isDisabled={type === 'View' ? true : false}
                        closeMenuOnSelect={false}
                        components={{ Option, MultiValue }}
                        hideSelectedOptions={false}
                        styles={customStyles}
                        classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                      />
                      <div className="mt-0.5 text-xs font-medium text-red">
                        {planModuleError}
                      </div>
                    </div>
                  </div>
                  <span
                    className="flex cursor-pointer items-center gap-2 font-medium"
                    onClick={handleAddNoteClick}
                  >
                    <GiNotebook className="h-[25px] w-[25px]" />
                    <Text>Add Internal Note & Location</Text>
                  </span>
                  {isTextAreaVisible && (
                    <Textarea
                      placeholder="Add your internal note and location..."
                      {...register('notes')}
                      error={errors?.notes?.message as string}
                      // textareaClassName="h-20"
                      // className="col-span-2"
                    />
                  )}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-[20px] pb-5 pt-[0.25rem]">
                  <div>
                    <Button
                      variant="outline"
                      className="@xl:w-auto dark:hover:border-gray-400"
                      onClick={() => closeModal()}
                    >
                      Cancel
                    </Button>
                  </div>
                  <div className="ms-auto flex items-center justify-end gap-2">
                    {title === 'Edit Meeting' && (
                      <Checkbox
                        {...register('done')}
                        label="Mark as done"
                        color="info"
                        variant="flat"
                        className="[&>label>span]:font-medium"
                      />
                    )}
                    <Button
                      type="submit"
                      className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
                      disabled={activityData?.loading && loader}
                    >
                      Save
                      {activityData?.loading && loader && (
                        <Spinner
                          size="sm"
                          tag="div"
                          className="ms-3"
                          color="white"
                        />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </Form>
      </>
    );
  }
}

// export function ConfirmationActivityModal(props: any) {
//   const { data, title, isClientModule, isAgencyTeam, clientReferenceId, teamReferenceId, isTeamModule, isClientEdit, isClientTeam, clientId, isTeamEdit, teamId } = props;
//   const { closeModal } = useModal();
//   const dispatch = useDispatch();
//   const eventSliceData = useSelector((state: any) => state?.root?.event);
//   const signIn = useSelector((state: any) => state?.root?.signIn);
//   const { calendarView } = useSelector((state: any) => state?.root?.activity);
//   const clientSliceData = useSelector((state: any) => state?.root?.client);

//   const handleYesClick = () => {

//     if (title === 'New Activity') {
//       dispatch(postAddActivity(data)).then((result: any) => {
//         if (postAddActivity.fulfilled.match(result)) {
//           if (result && result.payload.success === true) {
//             // setLoader(false);
//             closeModal();

//             if (title === 'New Activity' && isClientModule && isAgencyTeam) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientReferenceId, pagination: true }))
//             } else if (title === 'New Activity' && !isAgencyTeam && !isTeamModule) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: clientReferenceId, pagination: true }))
//             } else if (title === 'New Activity' && isTeamModule && isAgencyTeam) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', team_id: teamReferenceId, pagination: true }))
//             } else if ((title === 'New Activity' && !isClientModule) || (title === 'New Activity' && !isTeamModule)) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', pagination: true }));
//             }

//             if (calendarView) {
//               const firstDayOfMonth = moment().startOf('month').format('DD-MM-YYYY');
//               const endDayOfMonth = moment().endOf('month').format('DD-MM-YYYY');
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', filter: { date: 'period', start_date: firstDayOfMonth, end_date: endDayOfMonth }, pagination: false }))
//             }

//           } else {
//             // setLoader(false);
//           }
//         }
//       });
//     } else {
//       dispatch(patchEditActivity({ ...data, activity_id: data._id })).then((result: any) => {
//         if (patchEditActivity.fulfilled.match(result)) {
//           if (result && result.payload.success === true) {
//             // setLoader(false);
//             closeModal();

//             if (title === 'Edit Activity' && isClientEdit && !isClientTeam) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientId, pagination: true }))
//             } else if (title === 'Edit Activity' && !isClientEdit && isTeamEdit && !isClientTeam) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', team_id: teamId, pagination: true }))
//             } else if (title === 'Edit Activity' && isClientEdit && isClientTeam) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: clientId, pagination: true }))
//             } else if ((title === 'Edit Activity' && !isClientEdit) || (title === 'Edit Activity' && !isTeamEdit)) {
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', pagination: true }));
//             }

//             if (calendarView) {
//               const firstDayOfMonth = moment().startOf('month').format('DD-MM-YYYY');
//               const endDayOfMonth = moment().endOf('month').format('DD-MM-YYYY');
//               dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', filter: { date: 'period', start_date: firstDayOfMonth, end_date: endDayOfMonth }, pagination: false }))
//             }

//           } else {
//             // setLoader(false);
//           }
//         }
//       });
//     }

//   }

//   return (
//     <div className='p-6'>
//       <div className='flex flex-col items-center gap-[6px]'>
//         <Title
//           as="h6"
//           className="mb-0.5 flex items-start text-sm text-gray-700 sm:items-center"
//         >
//           Event is already their on scheduled day.
//         </Title>
//         <Text className="mb-2 leading-relaxed text-gray-500">
//           Are you sure you want to continue?
//         </Text>
//       </div>
//       <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
//         <div className='flex justify-end items-center gap-2'>
//           <Button
//             className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
//             disabled={eventSliceData?.loading}
//             onClick={handleYesClick}
//           >
//             Yes
//             {eventSliceData?.loading && <Spinner size="sm" tag='div' className='ms-3' color='white' />}
//           </Button>
//         </div>
//         <div>
//           <Button
//             variant="outline"
//             className="@xl:w-auto dark:hover:border-gray-400"
//             onClick={() => closeModal()}
//           >
//             No
//           </Button>
//         </div>
//       </div>
//     </div>
//   )
// }
