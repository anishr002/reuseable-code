'use client';

import type { CalendarEvent } from '@/types';
import dayjs from 'dayjs';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Calendar, dayjsLocalizer, Views } from 'react-big-calendar';
// import EventForm from '@/app/shared/event-calendar/event-form';
// import DetailsEvents from '@/app/shared/event-calendar/details-event';
import { useModal } from '@/app/shared/modal-views/use-modal';
import cn from '@/utils/class-names';
import { useDispatch, useSelector } from 'react-redux';
import { getAllActivity } from '@/redux/slices/user/activity/activitySlice';
import moment from 'moment';
import ViewTaskForm from '../../task/create-edit/view-task-form';

const localizer = dayjsLocalizer(dayjs);

// rbc-active -> black button active custom css classes
const calendarToolbarClassName = '[&_.rbc-toolbar]:py-2 [&_.rbc-toolbar_.rbc-toolbar-label]:whitespace-nowrap [&_.rbc-toolbar_.rbc-toolbar-label]:my-2 [&_.rbc-toolbar]:flex [&_.rbc-toolbar]:flex-col [&_.rbc-toolbar]:items-center @[56rem]:[&_.rbc-toolbar]:flex-row [&_.rbc-btn-group_button:hover]:bg-gray-300 [&_.rbc-btn-group_button]:duration-200 [&_.rbc-time-header.rbc-overflowing]:hidden [&_.rbc-btn-group_button.rbc-active:hover]:bg-gray-600 dark:[&_.rbc-btn-group_button.rbc-active:hover]:bg-gray-300 [&_.rbc-btn-group_button.rbc-active:hover]:text-gray-50 dark:[&_.rbc-btn-group_button.rbc-active:hover]:text-gray-900 ';

export default function EventCalendarDayView(props: any) {

  const { title, isClientModule, isClientEdit, clientReferenceId, isTeamModule, isTeamEdit, teamReferenceId, isAgencyTeam, isClientTeam } = props;

  // console.log("title....", title)
  // console.log("isClientModule....", isClientModule)
  // console.log("clientReferenceId....", clientReferenceId)
  // console.log("isClientEdit....", isClientEdit)
  // console.log("isTeamModule....", isTeamModule)
  // console.log("teamReferenceId....", teamReferenceId)
  // console.log("isAgencyTeam....", isAgencyTeam)
  // console.log("isClientTeam....", isClientTeam)
  // console.log("isTeamEdit....", isTeamEdit)

  const { openModal } = useModal();
  const dispatch = useDispatch();
  const activityData = useSelector((state: any) => state?.root?.activity);

  const [events, setEvents] = useState<any[]>([]);


  useEffect(() => {

    if(title === 'New Meeting' && isClientModule && isAgencyTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientReferenceId, given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'New Meeting' && !isAgencyTeam && !isTeamModule) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: clientReferenceId, given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'New Meeting' && isTeamModule && isAgencyTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', team_id: teamReferenceId, given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } else if(((title === 'New Meeting' || title === 'New Task') && !isClientModule) || ((title === 'New Meeting' || title === 'New Task') && !isTeamModule)) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } 

    if(title === 'Edit Meeting' && isClientEdit && !isClientTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientReferenceId, given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'Edit Meeting' && isClientTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: clientReferenceId, given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'Edit Meeting' && isTeamEdit && !isClientTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', team_id: teamReferenceId, given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } else if(((title === 'Edit Meeting' || title === 'Edit Task') && !isClientEdit) || ((title === 'Edit Meeting' || title === 'Edit Task') && !isTeamEdit)) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', given_date: moment().format('DD-MM-YYYY'), pagination: false }))
    } 


  }, [title, dispatch, clientReferenceId, isClientModule, isTeamModule, isTeamEdit, teamReferenceId, isAgencyTeam, isClientTeam, isClientEdit]);



  useEffect(() => {

    const eventData = activityData?.eventCalendarData && activityData?.eventCalendarData?.length > 0 && activityData?.eventCalendarData?.map((dataa: any) => {
      return {
        ...dataa,
        start: new Date(dataa?.start),
        end: new Date(dataa?.end),
      }
    }) || [];

    // console.log("customize event data....", eventData)

    setEvents(eventData)

  }, [activityData?.eventCalendarData]); 



  const handleNavigationApiCall = (date: any) => {

    if(title === 'New Meeting' && isClientModule && isAgencyTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientReferenceId, given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'New Meeting' && !isAgencyTeam && !isTeamModule) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: clientReferenceId, given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'New Meeting' && isTeamModule && isAgencyTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', team_id: teamReferenceId, given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } else if(((title === 'New Meeting' || title === 'New Task') && !isClientModule) || ((title === 'New Meeting' || title === 'New Task') && !isTeamModule)) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } 

    if(title === 'Edit Meeting' && isClientEdit && !isClientTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_id: clientReferenceId, given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'Edit Meeting' && isClientTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: clientReferenceId, given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } else if(title === 'Edit Meeting' && isTeamEdit && !isClientTeam) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', team_id: teamReferenceId, given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } else if(((title === 'Edit Meeting' || title === 'Edit Task') && !isClientEdit) || ((title === 'Edit Meeting' || title === 'Edit Task') && !isTeamEdit)) {
      dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', given_date: moment(date).format('DD-MM-YYYY'), pagination: false }))
    } 

  } 



//   const handleSelectSlot = useCallback(
//     ({ start, end }: { start: Date; end: Date }) => {
//       openModal({
//         view: <EventForm startDate={start} endDate={end} />,
//         customSize: '650px',
//       });
//     },
//     [openModal]
//   );

  const handleSelectEvent = useCallback(
    (event: CalendarEvent) => {
      openModal({
        view: <ViewTaskForm data={event} isCalendarViewActivity={true} />,
        customSize: '700px',
      });
    },
    [openModal]
  );

  const { views, scrollToTime, formats } = useMemo(
    () => ({
      views: {
        day: true,
      },
      scrollToTime: new Date(2023, 10, 27, 6),
      formats: {
        dateFormat: 'D',
        weekdayFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'ddd', culture),
        dayFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'ddd M/D', culture),
        timeGutterFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'hh A', culture),
      },
    }),
    []
  );

  const eventPropGetter = useCallback(
    (event: any) => {
      // console.log(event);
      let style;
      if(event?.status === 'completed') {
        style = {
          backgroundColor: 'green',
        }
      } else if(event?.status === 'cancel') {
        style = {
          backgroundColor: 'red',
        }
      } else if(event?.status === 'pending') {
        style = {
          backgroundColor: 'orange',
        }
      }
      return {
        style: style
      };
    },
    []
  );

  return (
    <div className="@container">
      <Calendar
        localizer={localizer}
        events={events}
        views={views}
        formats={formats}
        defaultView={Views.DAY}
        startAccessor="start"
        endAccessor="end"
        dayLayoutAlgorithm="no-overlap"
        onSelectEvent={handleSelectEvent}
        // onSelectSlot={handleSelectSlot}
        onNavigate={(date) => handleNavigationApiCall(date)}
        eventPropGetter={eventPropGetter}
        selectable
        scrollToTime={scrollToTime}
        className={cn('h-[815px] md:h-[815px]', calendarToolbarClassName)}
      />
    </div>
  );
}
