'use client';

import { Button } from '@/components/ui/button';
import { Controller, SubmitHandler, useFormContext } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { useDispatch, useSelector } from 'react-redux';
import { usePathname, useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';
import { useModal } from '@/app/shared/modal-views/use-modal';
import cn from '@/utils/class-names';
import { Input } from '@/components/ui/input';
import dynamic from 'next/dynamic';
import SelectLoader from '@/components/loader/select-loader';
import { useEffect, useState } from 'react';
import { handleKeyDown } from '@/utils/common-functions';
import {
  AddTaskSchema,
  addTaskSchema,
} from '@/utils/validators/add-task.schema';
import QuillLoader from '@/components/loader/quill-loader';
import { DatePicker } from '@/components/ui/datepicker';
import { Checkbox } from '@/components/ui/checkbox';
import {
  getAllTask,
  getTaskById,
  patchEditTask,
  postAddTask,
  postTagsOptions,
} from '@/redux/slices/user/task/taskSlice';
import Select from '@/components/ui/select';
import moment from 'moment';
import { getAllActivity } from '@/redux/slices/user/activity/activitySlice';
import { PiTagBold, PiXBold } from 'react-icons/pi';
import UploadZone from '@/components/ui/file-upload/upload-zone';
import { getMembersByBoardId } from '@/redux/slices/user/task/boardSlice';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px]" />,
});

export default function AddTaskForm(props: any) {
  const {
    title,
    row,
    isClientEdit,
    isTeamEdit,
    isClientModule,
    clientName,
    clientReferenceId,
    isTeamModule,
    teamName,
    teamReferenceId,
    isAgencyTeam,
    isClientTeam,
  } = props;
  // console.log("row data....", row);

  const dispatch = useDispatch();
  const pathname = usePathname();
  const { closeModal } = useModal();
  const router = useRouter();

  const [clientId, setClientId] = useState('');
  const [teamId, setTeamId] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [files, setFiles] = useState<any>([]);


  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const taskData = useSelector((state: any) => state?.root?.task);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { gridView } = useSelector((state: any) => state?.root?.task);
  const { boardId, members } = useSelector((state: any) => state?.root?.board);

  // console.log("Pathname....", pathname, pathname?.startsWith('/tasks/board'))

  useEffect(() => {
    dispatch(getMembersByBoardId({ boardId: boardId }))
  }, [boardId]);

  useEffect(() => {
    isClientModule && clientReferenceId && setClientId(clientReferenceId);
  }, [clientReferenceId, isClientModule]);

  useEffect(() => {
    isTeamModule && teamReferenceId && setTeamId(teamReferenceId);
  }, [teamReferenceId, isTeamModule]);

  useEffect(() => {
    if (signIn && signIn?.teamMemberRole === 'team_member') {
      setTeamId(signIn?.user?.data?.user?.reference_id);
    }
  }, [signIn]);

  // let data = row;

  const initialValues: AddTaskSchema = {
    title: '',
    description: '',
    tags: [],
    due_date: new Date(),
    client: '',
    assigned:
      signIn?.teamMemberRole === 'team_member'
        ? signIn?.user?.data?.user?.name
        : '',
    done: false,
  };

  useEffect(() => {
    row &&
      dispatch(getTaskById({ taskId: row?._id })).then((result: any) => {
        if (getTaskById.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setClientId(result?.payload?.data[0]?.client_id);
            setTeamId(result?.payload?.data[0]?.assign_to);
          }
        }
      });
  }, [row, dispatch]);

  let [data] = taskData?.task ?? [{}];

  // const dueee_date = moment(data?.due_date).toDate();
  // console.log(dueee_date, "formateedddd", data?.due_date)

  let defaultValuess = isClientModule
    ? {
      title: data?.title,
      description: data?.agenda,
      // due_date: new Date(data?.due_date),
      // tags: data?.tags,
      due_date: moment(data?.due_date).toDate(),
      client: isClientModule ? clientName : data?.client_name,
      assigned:
        signIn?.teamMemberRole === 'team_member'
          ? signIn?.user?.data?.user?.first_name.charAt(0).toUpperCase() +
          signIn?.user?.data?.user?.first_name.slice(1) +
          ' ' +
          signIn?.user?.data?.user?.last_name.charAt(0).toUpperCase() +
          signIn?.user?.data?.user?.last_name.slice(1)
          : data?.assigned_to_name,
      done: data?.status === 'completed' ? true : false,
    }
    : isTeamModule
      ? {
        title: data?.title,
        description: data?.agenda,
        // due_date: new Date(data?.due_date),
        // tags: data?.tags,
        due_date: moment(data?.due_date).toDate(),
        client: data?.client_name,
        assigned:
          isTeamModule && teamName ? teamName : data?.assigned_to_name,
        done: data?.status === 'completed' ? true : false,
      }
      : {
        title: data?.title,
        description: data?.agenda,
        // due_date: new Date(data?.due_date),
        // tags: data?.tags,
        due_date: moment(data?.due_date).toDate(),
        client: data?.client_name,
        assigned:
          signIn?.teamMemberRole === 'team_member'
            ? signIn?.user?.data?.user?.first_name.charAt(0).toUpperCase() +
            signIn?.user?.data?.user?.first_name.slice(1) +
            ' ' +
            signIn?.user?.data?.user?.last_name.charAt(0).toUpperCase() +
            signIn?.user?.data?.user?.last_name.slice(1)
            : data?.assigned_to_name,
        done: data?.status === 'completed' ? true : false,
      };

  useEffect(() => {
    if (title === 'Edit Meeting' || title === 'Edit Task') {
      let customizeTags: string[] = [];
      data &&
        data?.tags?.length > 0 &&
        data?.tags?.map((tag: any, index: any) => {
          customizeTags?.push(tag?.name);
        });
      console.log('customized tags...', customizeTags);
      setTags(customizeTags);

      const fileById =
        data?.attachments && data?.attachments?.length > 0
          ? data?.attachments?.map((file: any) => {
            return {
              name: file?.slice(8),
              preview: `${process.env.NEXT_PUBLIC_IMAGE_URL}/${file}`,
              path: `${process.env.NEXT_PUBLIC_IMAGE_URL}/${file}`,
              size: 2,
            };
          })
          : [];

      setFiles([...fileById]);
    }
  }, [title, data]);


  let clientOptions: Record<string, any>[] = [];
  if (members && members.length > 0) {
    clientOptions = members
      .filter((member: Record<string, any>) => member.role === 'client' || member.role === 'team_client')
      .map((member: Record<string, any>) => ({
        name: member.member_name,
        value: member.reference_id,
        key: member,
      }));

    // Add default selection option
    clientOptions.unshift({ name: "Select Client", value: "", key: {} });
  }

  console.log("clientOptions...", clientOptions)


  // let clientOptions: Record<string, any>[] =
  //   clientSliceData?.clientList && clientSliceData?.clientList?.length > 0
  //     ? clientSliceData?.clientList?.map((client: Record<string, any>) => {
  //         let client_name =
  //           client?.first_name.charAt(0).toUpperCase() +
  //           client?.first_name.slice(1) +
  //           ' ' +
  //           client?.last_name.charAt(0).toUpperCase() +
  //           client?.last_name.slice(1);
  //         return {
  //           name: client_name,
  //           value: client?.reference_id,
  //           key: client,
  //         };
  //       })
  //     : [];

  let teamOptions: Record<string, any>[] = members && members.length > 0
    ? members.filter((member: Record<string, any>) => member.role === 'agency' || member.role === 'team_agency')
      .map((member: Record<string, any>) => ({
        name: member.member_name,
        value: member.reference_id,
        key: member,
      }))
    : [];

  console.log("teamOptions...", teamOptions)

  const onSubmit: SubmitHandler<AddTaskSchema> = (dataa) => {
    // console.log('Add task dataa---->', dataa);

    const formData: Record<string, any> = {
      title: dataa?.title,
      agenda: dataa?.description,
      due_date: String(dataa?.due_date), // Convert due_date to string
      // tags: tags,
      client_id: clientId,
      assign_to: teamId,
      mark_as_done: dataa?.done,
    };

    const filteredFormData = Object.fromEntries(
      Object.entries(formData).filter(
        ([_, value]) => value !== undefined && value !== ''
      )
    );

    const myForm = new FormData();
    // Add data from the 'formData' object to the FormData
    for (const key in filteredFormData) {
      if (Object.prototype.hasOwnProperty.call(filteredFormData, key)) {
        const value = filteredFormData[key];
        myForm.append(key, value);
      }
    }

    tags &&
      tags?.length > 0 &&
      tags.forEach((value, index) => {
        myForm.append('tags', value);
      });

    files &&
      files?.map((file: any) => {
        myForm.append('attachments', file);
      });

    boardId && myForm.append('board_id', boardId);

    if (title === 'Edit Meeting' || title === 'Edit Task') {
      myForm.append('_id', data?._id);
    }

    // console.log("form dataaaa.....",  [...myForm.entries()]);

    // const filteredFormData = Object.fromEntries(
    //   Object.entries(formData).filter(([_, value]) => value !== undefined && value !== '')
    // );

    // console.log('Add task form dataa---->', filteredFormData);

    if (title === 'New Meeting' || title === 'New Task') {
      dispatch(postAddTask(myForm)).then((result: any) => {
        if (postAddTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            closeModal();

            // title === 'New Task' && dispatch(getAllTask({ sort_field: 'createdAt', sort_order: 'desc', pagination: true }));

            if (
              (title === 'New Task' || title === 'New Meeting') &&
              pathname?.startsWith('/tasks/board') &&
              gridView
            ) {
              dispatch(getAllTask({ board_id: boardId, pagination: false }));
              // get tags list
              dispatch(postTagsOptions());
            } else if (
              (title === 'New Task' || title === 'New Meeting') &&
              pathname?.startsWith('/tasks/board') &&
              !gridView
            ) {
              dispatch(
                getAllTask({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                  board_id: boardId,
                })
              );
              // get tags list
              dispatch(postTagsOptions());
            }

            if (title === 'New Meeting' && isClientModule && isAgencyTeam) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  client_id: clientReferenceId,
                  pagination: true,
                })
              );
            } else if (
              title === 'New Meeting' &&
              !isAgencyTeam &&
              !isTeamModule
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  client_team_id: clientReferenceId,
                  pagination: true,
                })
              );
            } else if (
              title === 'New Meeting' &&
              isTeamModule &&
              isAgencyTeam
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  team_id: teamReferenceId,
                  pagination: true,
                })
              );
            } else if (
              (title === 'New Meeting' && !isClientModule) ||
              (title === 'New Meeting' && !isTeamModule)
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                })
              );
            }
          }
        }
      });
    } else {
      dispatch(patchEditTask(myForm)).then((result: any) => {
        if (patchEditTask.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            closeModal();

            // title === 'Edit Task' && dispatch(getAllTask({ sort_field: 'createdAt', sort_order: 'desc', pagination: true }));

            if (
              (title === 'Edit Task' || title === 'Edit Meeting') &&
              pathname?.startsWith('/tasks/board') &&
              gridView
            ) {
              dispatch(getAllTask({ pagination: false, board_id: boardId }));
              // get tags list
              dispatch(postTagsOptions());
            } else if (
              (title === 'Edit Task' || title === 'Edit Meeting') &&
              pathname?.startsWith('/tasks/board') &&
              !gridView
            ) {
              dispatch(
                getAllTask({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  board_id: boardId,
                  pagination: true,
                })
              );
              // get tags list
              dispatch(postTagsOptions());
            }

            if (title === 'Edit Meeting' && isClientEdit && !isClientTeam) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  client_id: clientId,
                  pagination: true,
                })
              );
            } else if (
              title === 'Edit Meeting' &&
              !isClientEdit &&
              isTeamEdit &&
              !isClientTeam
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  team_id: teamId,
                  pagination: true,
                })
              );
            } else if (
              title === 'Edit Meeting' &&
              isClientEdit &&
              isClientTeam
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  client_team_id: clientId,
                  pagination: true,
                })
              );
            } else if (
              (title === 'Edit Meeting' && !isClientEdit) ||
              (title === 'Edit Meeting' && !isTeamEdit)
            ) {
              dispatch(
                getAllActivity({
                  sort_field: 'createdAt',
                  sort_order: 'desc',
                  pagination: true,
                })
              );
            }
          }
        }
      });
    }
  };

  if (!taskData?.task && (title === 'Edit Meeting' || title === 'Edit Task')) {
    return (
      <div className="mt-[14rem] flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  } else {
    return (
      <>
        <Form<AddTaskSchema>
          validationSchema={addTaskSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'all',
            defaultValues: defaultValuess,
          }}
          className="[&_label]:font-medium"
        >
          {({
            register,
            control,
            formState: { errors },
            setValue,
            getValues,
          }) => (
            <div className="space-y-5">
              {/* <div className="mb-6 flex items-center justify-between">
                <Title as="h3" className="text-xl xl:text-2xl">
                  {title}
                  New Task
                </Title>
              </div> */}
              <div>
                <div className="grid gap-5">
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    label="Title *"
                    placeholder="Enter title"
                    color="info"
                    className="[&>label>span]:font-medium"
                    {...register('title')}
                    error={errors?.title?.message}
                  />
                  <Controller
                    control={control}
                    name="description"
                    render={({ field: { onChange, value } }) => (
                      <QuillEditor
                        value={value}
                        onChange={onChange}
                        onKeyDown={handleKeyDown}
                        placeholder="Enter description"
                        label="Description"
                        className="col-span-full [&_.ql-editor]:min-h-[100px]"
                        labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                      />
                    )}
                  />
                  <div>
                    <UploadZone
                      label="Attachments"
                      name="files"
                      setValue={setValue}
                      getValues={getValues}
                      className="col-span-full"
                      files={files}
                      setFiles={setFiles}
                      error={errors?.files?.message as string}
                    />
                  </div>
                  <div>
                    <ItemCrud
                      name="Tags"
                      items={tags}
                      setItems={setTags}
                      register={register}
                      setValue={setValue}
                      errors={errors}
                    />
                  </div>
                  <Controller
                    name="due_date"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <DatePicker
                        selected={value}
                        inputProps={{
                          label: 'Due Date & Time *',
                          color: 'info',
                          error: errors?.due_date?.message,
                        }}
                        placeholderText="Select due date & time"
                        onChange={onChange}
                        selectsStart
                        startDate={value}
                        minDate={new Date()}
                        showTimeSelect
                        popperPlacement="top-start"
                        dateFormat="MMMM d, yyyy h:mm aa"
                      />
                    )}
                  />
                  {clientSliceData?.loading ? (
                    <SelectLoader />
                  ) : (
                    <Controller
                      control={control}
                      name="client"
                      render={({ field: { onChange, value } }) => (
                        <Select
                          options={clientOptions}
                          onChange={(selectedOption: Record<string, any>) => {
                            onChange(selectedOption?.name);
                            setClientId(selectedOption?.value);
                            // handleClientChange(selectedOption);
                          }}
                          value={value}
                          placeholder="Select Client"
                          label="Client"
                          error={errors?.client?.message as string}
                          // clearable
                          color="info"
                          // getOptionValue={(option) => option.value}
                          className="[&>label>span]:font-medium"
                          disabled={isClientModule || isClientEdit}
                          dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg"
                        />
                      )}
                    />
                  )}
                  {teamMemberData?.loading ? (
                    <SelectLoader />
                  ) : (
                    <Controller
                      control={control}
                      name="assigned"
                      render={({ field: { onChange, value } }) => (
                        <Select
                          options={teamOptions}
                          onChange={(selectedOption: Record<string, any>) => {
                            onChange(selectedOption?.name);
                            setTeamId(selectedOption?.value);
                            // handleTeamChange(selectedOption);
                          }}
                          value={
                            signIn?.teamMemberRole === 'team_member'
                              ? signIn?.user?.data?.user?.name
                              : value
                          }
                          placeholder="Select Team member"
                          label="Assigned *"
                          disabled={
                            signIn?.teamMemberRole === 'team_member' ||
                            isTeamModule ||
                            isTeamEdit
                          }
                          error={errors?.assigned?.message as string}
                          color="info"
                          // getOptionValue={(option) => option.value}
                          className="[&>label>span]:font-medium"
                          dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg"
                        />
                      )}
                    />
                  )}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-[20px] pb-5 pt-[0.25rem]">
                  <div>
                    <Button
                      variant="outline"
                      className="@xl:w-auto dark:hover:border-gray-400"
                      onClick={() => closeModal()}
                    >
                      Cancel
                    </Button>
                  </div>
                  <div className="ms-auto flex items-center justify-end gap-2">
                    {(title === 'Edit Meeting' || title === 'Edit Task') && (
                      <Checkbox
                        {...register('done')}
                        label="Mark as done"
                        color="info"
                        variant="flat"
                        className="[&>label>span]:font-medium"
                      />
                    )}
                    <Button
                      type="submit"
                      className="bg-[#53216F] hover:bg-[#8e45b8] @xl:w-auto dark:text-white"
                      disabled={taskData?.loading}
                    >
                      Save
                      {taskData?.loading && (
                        <Spinner
                          size="sm"
                          tag="div"
                          className="ms-3"
                          color="white"
                        />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </Form>
      </>
    );
  }
}

function ItemCrud(props: any): JSX.Element {
  const { name, items, setItems, register, setValue, errors } = props;
  const [itemText, setItemText] = useState<string>('');

  function handleItemAdd(): void {
    if (itemText.trim() !== '') {
      const newItem: string = itemText.trim();

      setItems([...items, newItem]);
      setValue('tags', [...items, newItem]);
      setItemText('');
    }
  }

  function handleItemRemove(text: string): void {
    const updatedItems = items.filter((item: any) => item !== text);
    setItems(updatedItems);
  }

  return (
    <div>
      <div className="flex items-center">
        <Input
          value={itemText}
          onKeyDown={handleKeyDown}
          placeholder={`Enter a ${name}`}
          onChange={(e) => setItemText(e.target.value)}
          prefix={<PiTagBold className="h-4 w-4" />}
          className="w-full [&>label>span]:font-medium"
          color="info"
        // {...register('emailInput')}
        // error={errors?.emailInput?.message}
        />
        <input type="hidden" {...register('tags', { value: items })} />
        <Button
          onClick={handleItemAdd}
          className="ms-4 shrink-0 text-sm @lg:ms-5 dark:bg-gray-100 dark:text-white dark:active:bg-gray-100"
        >
          Add {name}
        </Button>
      </div>

      {items && items?.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {items?.map((text: any, index: any) => (
            <div
              key={index}
              className="flex items-center rounded-full border border-gray-300 py-1 pe-2.5 ps-3 text-sm font-medium text-gray-700"
            >
              {text}
              <button
                onClick={() => handleItemRemove(text)}
                className="ps-2 text-gray-500 hover:text-gray-900"
              >
                <PiXBold className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
