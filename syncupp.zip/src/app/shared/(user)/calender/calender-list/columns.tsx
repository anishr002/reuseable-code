'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Checkbox } from '@/components/ui/checkbox';
import { Tooltip } from '@/components/ui/tooltip';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import DeletePopover from '@/app/shared/delete-popover';
import CustomModalButton from '@/app/shared/custom-modal-button';
import { ActionIcon, Badge, Button, Popover } from 'rizzui';
import { useDispatch, useSelector } from "react-redux";
import moment from 'moment';
import ViewTaskForm from '@/app/shared/(user)/task/create-edit/view-task-form';
import AddActivityFormPage from '../../calender/create-edit-event/create-edit-activity-form';
import { PiXBold } from 'react-icons/pi';
import { MdOutlineDone } from 'react-icons/md';
import ConfirmationPopover from '@/app/shared/confirmation-popover';
import { usePathname } from 'next/navigation';
import { MeetingForm } from '../meeting/meeting-form';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { MeetingDetail } from '../meeting/meeting-detail';
import { Avatar } from '@/components/ui/avatar';
import { Fragment, useMemo } from 'react';
import { checkPermission } from '../../roles-permissions/utils';
import { SlOptions } from 'react-icons/sl';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { getAllActivity, meetingStatusUpdate } from '@/redux/slices/user/activity/activitySlice';
import toast from 'react-hot-toast';


type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

function getStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'pending':
      return (
        <div className="status_pad flex items-center  gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm w-[127px]">
          <Badge className="bg-[#AC2D2D]" renderAsDot />
          <Text className="font-medium text-[#AC2D2D]">Pending</Text>
        </div>
      );
    case 'completed':
      return (
        <div className="status_pad flex items-center  gap-2 rounded-3xl bg-[#E4F6D6] px-[20px] py-[8px] text-xs sm:text-sm w-[127px]">
          <Badge className="bg-[#527C31]" renderAsDot />
          <Text className="font-medium text-[#527C31]">Completed</Text>
        </div>
      );
    case 'overdue':
      return (
        <div className="status_pad flex items-center  gap-2 rounded-3xl bg-[#FFEAC3] px-[20px] py-[8px] text-xs sm:text-sm w-[127px]">
          <Badge className="bg-[#8C6825]" renderAsDot />
          <Text className="font-medium text-[#8C6825]">Overdue</Text>
        </div>
      );
    case 'in_progress':
      return (
        <div className="flex items-center">
          <Badge color="secondary" renderAsDot />
          <Text className=" font-medium text-secondary-dark">
            In Progress
          </Text>
        </div>
      );
    case 'cancel':
      return (
        <div className="status_pad flex items-center  gap-2 rounded-3xl bg-[#FFD4C6] px-[20px] py-[8px] text-xs sm:text-sm w-[127px]">
          <Badge color="danger" renderAsDot />
          <Text className="font-medium text-red-dark">Cancel</Text>
        </div>
      );
    default:
      return (
        <div className="status_pad flex items-center  gap-2 rounded-3xl bg-gray-200 px-[20px] py-[8px] text-xs sm:text-sm w-[127px]">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="font-medium text-gray-600">
            {capitalizeFirstLetter(status)}
          </Text>
        </div>
      );
  }
}

function getActivityName(value: string) {
  switch (value?.toLowerCase()) {
    case 'task':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Task</Text>
        </div>
      );
    case 'call_meeting':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Call meeting</Text>
        </div>
      );
    case 'others':
      return (
        <div className="flex items-center">
          <Text className="font-medium text-gray-700">Others</Text>
        </div>
      );
  }
}

export const GetActivityColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.activity
  );
  let { page, items_per_page, sort_field, sort_order, search, filter } =
    paginationParams;
  const dispatch = useDispatch();
  // console.log("pathname is....", pathname.startsWith('/client/details'))

  const { closeModal } = useModal();
  const { openModal } = useModal();

  const AttendeesColumn = ({ rowData }: { rowData: any }) => {
    const renderAttendees = useMemo(() => {
      return (
        <>
        <div className='flex flex-row gap-2'>

        
          <div className='flex'>
            {rowData?.attendees?.slice(0, 3)?.map((data: any, index: number) => (
              <Fragment key={data._id + '-' + index}>
                <div
                  className="mb-1  relative z-10 ml-[-13px] flex items-center rounded-lg text-[12px] focus-visible:bg-gray-100"
                >
                  <span className="inline-flex items-start justify-center text-gray-500">
                    <Avatar
                      src={
                        data?.profile_image &&
                        `${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${data?.profile_image}`
                      }
                      name={
                        capitalizeFirstLetter(data?.first_name) +
                        ' ' +
                        capitalizeFirstLetter(data?.last_name)
                      }
                      className=" bg-[#70C5E0] font-medium text-[12px] text-white "
                      size='sm'
                    />
                  </span>
                </div>
              </Fragment>
            ))}
            {rowData?.custom_attendees?.map((data: any, index: number) => (
              <Fragment key={data + '-' + index}>
                <div
                  className="mb-1 relative flex items-center gap-2 rounded-lg text-[12px] focus-visible:bg-gray-100"
                >
                  <span className="inline-flex items-center justify-center text-gray-500">
                    <Avatar
                      src={
                        data &&
                        `${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${data}`
                      }
                      name={capitalizeFirstLetter(data)}
                      className="!h-6 !w-6 bg-[#70C5E0] font-medium text-[12px] text-white xl:!h-6 xl:!w-6"
                    />
                  </span>
                </div>
              </Fragment>
            ))}
          </div>
          {rowData?.attendees?.length > 3 && (
              <div className="poppins_font_number flex h-8 w-8 cursor-pointer items-center justify-center  gap-1 rounded-full bg-[#F5F5F5] text-[14px] font-medium text-[#757575]">
                +{rowData?.attendees?.length - 3}
              </div>
            )}
            </div>
        </>
      );
    }, [rowData]);
    return <div>{renderAttendees}</div>;
  };

  return [
    {
      title: (
        <div className="ps-3.5 ">
          <HeaderCell
            className="text-[#4B5563]"
            title="TITLE"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'title'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('title'),
      dataIndex: 'title',
      key: 'title',
      width: 260,
      render: (value: string) => (
        <Text className=" w-72 truncate text-gray-700 font-medium">
          {value?.charAt(0)?.toUpperCase() + value?.slice(1)}
        </Text>
      ),
    },
    {
      title: (
        <div className="ps-3.5">
          <HeaderCell
            className="text-[#4B5563] items-center"
            title="Meet Link"
            sortable
            ascending={
              sortConfig?.direction === "asc" &&
              sortConfig?.key === "google_meeting_data"
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick("google_meeting_data"),
      dataIndex: "google_meeting_data",
      key: "google_meeting_data",
      width: 100,
      render: (value: any) => {
        const meetLink = value?.meet_link;
    
        const handleCopy = () => {
          if (meetLink) {
            navigator.clipboard
              .writeText(meetLink)
              .then(()=>{toast.success('Meeting link copied to clipboard');
              }) 
              .catch((err: any) => console.error("Failed to copy:", err));
          }
        };
    
        return meetLink ? (
          <button
            className="px-2 py-1 bg-[transparent] text-[#6875F5] rounded-lg underline font-medium"
            onClick={handleCopy}
          >
            Copy Link
          </button>
        ) : (
          <span className="text-gray-500 px-5">-</span> // Show "-" if no link is available
        );
      },
    },
    
    {
      title: (
        <HeaderCell
          title="Date"
          className="text-[#4B5563]"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'due_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('due_date'),
      dataIndex: 'meeting_date',
      key: 'meeting_date',
      width: 300,
      render: (value: string) => (
        <Text className=" font-medium text-gray-700">
          {moment(value).format('DD MMM, YYYY')}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          className="text-[#4B5563]"
          title="Attendees"
        // sortable
        // ascending={
        //   sortConfig?.direction === 'asc' &&
        //   sortConfig?.key === 'assign_to.name'
        // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('attendees'),
      dataIndex: 'attendees',
      key: 'attendees',
      width: 200,
      render: (_: any, row: any) => {
        return (<AttendeesColumn rowData={row} />);
      },
    },
    {
      title: (
        <HeaderCell
          className="text-[#4B5563]"
          title="Status"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 180,
      render: (value: any) => getStatusBadge(value),
    },
    // {
    //   // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
    //   title: <HeaderCell title="Actions" className="text-[#4B5563]" />,
    //   dataIndex: 'action',
    //   key: 'action',
    //   width:600,
    //   render: (_: string, row: any) => {
    //     return (
    //       <div>
    //         <div>
    //           <div className="flex items-center gap-3 pe-4">
    //             {(['agency',].includes(signIn?.role) || (['team_agency', 'team_client'].includes(signIn?.role) && checkPermission('meetings', null, 'update', signIn?.permission))) &&
    //               !['completed', 'cancel'].includes(row?.status) && (
    //                 <CustomModalButton
    //                   className="bg-[#E3E1F4] text-[#8C80D2]"
    //                   icon={<PencilIcon className="h-4 w-4" />}
    //                   view={
    //                     <MeetingForm
    //                       title="Edit Meeting"
    //                       row={row}
    //                       isEdit={true}
    //                     />
    //                   }
    //                   customSize="1050px"
    //                   title="Edit Meeting"
    //                 />
    //               )}
    //             <CustomModalButton
    //               className="bg-[#E3E1F4] text-[#8C80D2]"
    //               icon={<EyeIcon className="h-4 w-4" />}
    //               view={<MeetingDetail row={row} />}
    //               customSize="450px"
    //               title="View Meeting"
    //             />
    //             {signIn?.role !== 'client' &&
    //               signIn?.role !== 'team_client' &&
    //               row?.status !== 'completed' &&
    //               row?.status !== 'cancel' && (
    //                 <ConfirmationPopover
    //                   buttonClassName="bg-[#E3E1F4] text-[#8C80D2]"
    //                   title={`Complete the meeting`}
    //                   description={`Are you sure you want to complete the meeting?`}
    //                   action="Complete"
    //                   icon={<MdOutlineDone className="h-4 w-4" />}
    //                   data={row?._id}
    //                   isMeetingModule={pathname?.includes('/meetings')}
    //                   isClientModule={pathname.startsWith('/client/details')}
    //                   isAgencyTeamModule={pathname.startsWith(
    //                     '/agency-team/details'
    //                   )}
    //                   isClientTeamModule={pathname.startsWith(
    //                     '/client-team/details'
    //                   )}
    //                 />
    //               )}
    //             {signIn?.role !== 'client' &&
    //               signIn?.role !== 'team_client' &&
    //               row?.status !== 'completed' &&
    //               row?.status !== 'cancel' && (
    //                 <ConfirmationPopover
    //                   buttonClassName="bg-[#E3E1F4] text-[#8C80D2]"
    //                   title={`Cancel the meeting`}
    //                   description={`Are you sure you want to cancel the meeting?`}
    //                   action="Cancel"
    //                   icon={<PiXBold className="h-4 w-4" />}
    //                   data={row?._id}
    //                   isMeetingModule={pathname?.includes('/meetings')}
    //                   isClientModule={pathname.startsWith('/client/details')}
    //                   isAgencyTeamModule={pathname.startsWith(
    //                     '/agency-team/details'
    //                   )}
    //                   isClientTeamModule={pathname.startsWith(
    //                     '/client-team/details'
    //                   )}
    //                 />
    //               )}
    //           </div>
    //         </div>
    //       </div>
    //     );
    //   },
    // },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Action" align="right" />,
      dataIndex: 'action',
      key: 'action',
      width: 70,
      render: (_: string, row: any) => {
        // function dispatch(arg0: any) {
        //   throw new Error('Function not implemented.');
        // }

        
        return (
          <div className="flex items-center justify-end">
            <Popover
              placement="top-start"
              className="demo_test flex min-w-[135px] flex-col items-start justify-start px-1 text-gray-900"
              content={({ setOpen }) => {

                // const isTaskCreateAllowed =
                //   ['team_agency', 'team_client'].includes(signIn?.role) &&
                //   checkPermission(
                //     'projects',
                //     'tasks',
                //     'create',
                //     signIn?.permission
                //   );


                const handleMeetingStatus = (meetingId: string, status: "completed" | "cancel") => {
                  dispatch(meetingStatusUpdate({ _id: meetingId, status }))
                    .then((result: any) => {
                      console.log(result.payload?.success)
                      if (meetingStatusUpdate.fulfilled.match(result)) {
                        if (result.payload?.success) {
                          dispatch(
                            getAllActivity({
                              page,
                              items_per_page,
                              sort_field,
                              sort_order,
                              search,
                              filter,
                              pagination: true,
                            })
                          );
                        }
                      }
                    })
                    .catch(() => {
                      console.error(`Failed to ${status} the meeting`);
                    });
                  setOpen(false)
                };




                const isTaskUpdateAllowed =
                  ['team_agency', 'team_client'].includes(signIn?.role) &&
                  checkPermission(
                    'projects',
                    'tasks',
                    'update',
                    signIn?.permission
                  );
                return (
                  <>
                    {/* View Task */}
                    <Button
                      variant="text"
                      className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                      onClick={() => {
                        // <MeetingDetail row={row} />
                        openModal({
                          view: (
                            <MeetingDetail 
                              row={row}
                            // editMode={false}
                            // onClose={closeModal}
                            />
                          ),
                          customSize: '500px',
                        });
                        setOpen(false);
                      }}
                    >
                      View Meeting
                    </Button>


                    {(['agency',].includes(signIn?.role) || (['team_agency', 'team_client'].includes(signIn?.role) && checkPermission('meetings', null, 'update', signIn?.permission))) &&
                      !['completed', 'cancel'].includes(row?.status) && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={() => {
                            //   <MeetingForm
                            // title="Edit Meeting"
                            // row={row}
                            // isEdit={true}
                            // />
                            openModal({
                              view: (
                                <MeetingForm
                                  title="Edit Meeting"
                                  row={row}
                                  editMode={true}
                                  isEdit={true}
                                // onClose={closeModal}
                                />
                              ),
                              customSize: '860px',
                            });
                            setOpen(true);
                          }}
                        >
                          Edit Meeting
                        </Button>

                      )}
                    {/* Edit Task */}


                    {signIn?.role !== 'client' &&
                      signIn?.role !== 'team_client' &&
                      row?.status !== 'completed' &&
                      row?.status !== 'cancel' && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          onClick={() => handleMeetingStatus(row?._id, "completed")}

                        // buttonClassName="bg-[#E3E1F4] text-[#8C80D2]"
                        // title={`Complete the meeting`}
                        // description={`Are you sure you want to complete the meeting?`}
                        // action="Complete"
                        // icon={<MdOutlineDone className="h-4 w-4" />}
                        // data={row?._id}
                        // isMeetingModule={pathname?.includes('/meetings')}
                        // isClientModule={pathname.startsWith('/client/details')}
                        // isAgencyTeamModule={pathname.startsWith(
                        //   '/agency-team/details'
                        // )}
                        // isClientTeamModule={pathname.startsWith(
                        //   '/client-team/details'
                        // )}


                        >Completed
                        </Button>
                      )}
                    {signIn?.role !== 'client' &&
                      signIn?.role !== 'team_client' &&
                      row?.status !== 'completed' &&
                      row?.status !== 'cancel' && (
                        <Button
                          variant="text"
                          className="flex h-auto w-full items-start justify-start hover:bg-[#EDEAFE] focus:outline-none"
                          // onClick={() => handleCompleteMeeting(row?._id)}

                          // buttonClassName="bg-[#E3E1F4] text-[#8C80D2]"
                          // title={`Complete the meeting`}
                          // description={`Are you sure you want to complete the meeting?`}
                          // action="Complete"
                          // icon={<MdOutlineDone className="h-4 w-4" />}
                          // data={row?._id}
                          // isMeetingModule={pathname?.includes('/meetings')}
                          // isClientModule={pathname.startsWith('/client/details')}
                          // isAgencyTeamModule={pathname.startsWith(
                          //   '/agency-team/details'
                          // )}
                          // isClientTeamModule={pathname.startsWith(
                          //   '/client-team/details'
                          // )}
                          onClick={() => handleMeetingStatus(row?._id, "cancel")}
                        >Cancel
                        </Button>
                      )}

                  </>
                );
              }}
            >
              <ActionIcon title="More Options" variant="text">
                <SlOptions className="h-5 w-5 cursor-pointer text-[#4B5563] hover:text-[#8C80D2]" />
              </ActionIcon>
            </Popover>
          </div>
        );
      },
    },
  ];
};
