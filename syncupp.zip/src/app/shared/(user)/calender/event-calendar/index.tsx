'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import WidgetCard from '@/components/cards/widget-card';
import Select from '@/components/ui/select';
import {
  getAllActivity,
  getAllGoogleCalendarActivity,
  setCalendarView,
  setEventCalendarData,
  setPaginationDetails,
} from '@/redux/slices/user/activity/activitySlice';
import { emptyDefaultFormData } from '@/redux/slices/user/meeting/meetingSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import dayjs from 'dayjs';
import moment from 'moment';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Calendar, dayjsLocalizer } from 'react-big-calendar';
import { FiCalendar } from 'react-icons/fi';
import { MdOutlineSpaceDashboard } from 'react-icons/md';
import { PiCaretDownBold, PiListBullets } from 'react-icons/pi';
import { RiArrowLeftSLine, RiArrowRightSLine } from 'react-icons/ri';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon, Badge } from 'rizzui';
import { checkPermission } from '../../roles-permissions/utils';
import { MeetingDetail } from '../meeting/meeting-detail';
import { MeetingForm } from '../meeting/meeting-form';

const localizer = dayjsLocalizer(dayjs);
// rbc-active -> black button active
const calendarToolbarClassName =
  '[&_.rbc-toolbar_.rbc-toolbar-label]:whitespace-nowrap [&_.rbc-toolbar_.rbc-toolbar-label]:my-2 [&_.rbc-toolbar]:flex [&_.rbc-toolbar]:flex-col [&_.rbc-toolbar]:items-center @[56rem]:[&_.rbc-toolbar]:flex-row [&_.rbc-btn-group_button:hover]:bg-gray-300 [&_.rbc-btn-group_button]:duration-200 [&_.rbc-btn-group_button.rbc-active:hover]:bg-gray-600 dark:[&_.rbc-btn-group_button.rbc-active:hover]:bg-gray-300 [&_.rbc-btn-group_button.rbc-active:hover]:text-gray-50 dark:[&_.rbc-btn-group_button.rbc-active:hover]:text-gray-900';

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#8c80d2' : 'white',
    color: state.isSelected ? 'white' : 'black',
    padding: '8px',
  }),
};

const calenderFilter = [
  { label: 'Month', value: 'month' },
  { label: 'Week', value: 'week' },
  { label: 'Day', value: 'day' },
];

export default function EventCalendarView({
  isConfigured,
  configuredUser,
  currentGoogleFilterParams,
  setCurrentGoogleFilterParams,
}: {
  isConfigured: Boolean;
  configuredUser: String;
  currentGoogleFilterParams: any;
  setCurrentGoogleFilterParams: any;
}) {
  // const { events } = useEventCalendar();
  const { openModal } = useModal();
  const dispatch = useDispatch();
  const pathname = usePathname();

  const activityData = useSelector((state: any) => state?.root?.activity);
  const { isGoogleCalendarConfig, sameEventCalendarIds } = useSelector(
    (state: any) => state?.root?.activity
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { calendarView } = useSelector((state: any) => state?.root?.activity);

  const [events, setEvents] = useState<any[]>([]);
  const [timeStatusType, setTimeStatusType] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reset, setReset] = useState('');
  const [calenderViewForMeetingForm, setCalenderViewForMeetingForm] = useState(
    calenderFilter[0].value
  );

  const firstDayOfMonth = moment().startOf('month').format('DD-MM-YYYY');
  const endDayOfMonth = moment().endOf('month').format('DD-MM-YYYY');
  const payload = {
    sort_field: 'createdAt',
    sort_order: 'desc',
    filter: {
      date: 'period',
      start_date: firstDayOfMonth,
      end_date: endDayOfMonth,
    },
    pagination: false,
  };

  const [currentFilterParams, setCurrnetFilterParams] = useState<any>(payload);

  console.log('Total events....', events);
  console.log(
    'activityData?.eventCalendarData....',
    activityData?.eventCalendarData
  );
  console.log('configuredUser....', configuredUser);

  useEffect(() => {
    setTimeStatusType('');
  }, [clientSliceData?.agencyId]);

  // initial api call

  async function initialApiCall() {
    apiCalledForGetData(currentFilterParams);

    try {
      // Call both APIs in parallel
      const [activityResult, calendarResult] = await Promise.all([
        dispatch(getAllActivity(currentFilterParams)),
        isGoogleCalendarConfig &&
          configuredUser &&
          configuredUser !== '' &&
          dispatch(
            getAllGoogleCalendarActivity({
              ...currentGoogleFilterParams,
              auth_user_id: configuredUser,
            })
          ),
      ]);

      let mergedData: any = [];

      // Handle the results
      if (getAllActivity.fulfilled.match(activityResult)) {
        console.log('Calendar events data....', activityResult);
        if (activityResult.payload?.response?.success) {
          // customizeEvents(activityResult.payload.response.data);
          // Customize and merge activity data
          mergedData = mergedData.concat(
            activityResult.payload.response.data?.activity_array || []
          );
        }
      }

      if (getAllGoogleCalendarActivity.fulfilled.match(calendarResult)) {
        if (calendarResult.payload?.success) {
          console.log('Event calendar data....', calendarResult.payload.data);

          const updatedEventData =
            calendarResult.payload.data?.map((event: any) => ({
              ...event,
              title: event.summary,
              allDay: false,
              type: 'calendar_event',
              status: 'completed',
            })) || [];

          console.log('updatedEventData...', updatedEventData);
          // Merge Google Calendar events data
          mergedData = mergedData.concat(updatedEventData);

          // dispatch(setEventCalendarData(updatedEventData));
          // setEvents((prevData) => [...prevData, ...updatedEventData]);
        }
      }
      // Dispatch the merged data
      dispatch(setEventCalendarData(mergedData));
    } catch (error) {
      console.error('Error during API calls:', error);
    }
  }

  // Fetching calendar events & google calendar events....
  // Init Hook-
  useEffect(() => {
    initialApiCall();
  }, [
    dispatch,
    signIn?.role,
    clientSliceData?.agencyId,
    isConfigured,
    isGoogleCalendarConfig,
    configuredUser,
  ]);

  async function handleNavigate(newDate: any, view: any, action: any) {
    setEvents([]);

    let startDate, endDate, googlesStartDate, googleEndDate;

    // Determine the start and end dates based on the view
    switch (view) {
      case 'month':
        startDate = moment(newDate).startOf('month').format('DD-MM-YYYY');
        endDate = moment(newDate).endOf('month').format('DD-MM-YYYY');
        googlesStartDate = moment(newDate).startOf('month').utc();
        googleEndDate = moment(newDate).endOf('month').utc();
        break;
      case 'week':
        startDate = moment(newDate).startOf('week').format('DD-MM-YYYY');
        endDate = moment(newDate).endOf('week').format('DD-MM-YYYY');
        googlesStartDate = moment(newDate).startOf('week').utc();
        googleEndDate = moment(newDate).endOf('week').utc();
        break;
      case 'day':
        startDate = moment(newDate).startOf('day').format('DD-MM-YYYY');
        endDate = moment(newDate).endOf('day').format('DD-MM-YYYY');
        googlesStartDate = moment(newDate).startOf('day').utc();
        googleEndDate = moment(newDate).endOf('day').utc();
        break;
      case 'agenda':
        // Define your logic for agenda view if needed
        break;
      default:
        break;
    }

    if (startDate && endDate) {
      const googleCalendarApiPayload = {
        auth_user_id: configuredUser,
        start_date: googlesStartDate,
        end_date: googleEndDate,
      };

      setCurrentGoogleFilterParams(googleCalendarApiPayload);

      apiCalledForGetData({
        sort_field: 'createdAt',
        sort_order: 'desc',
        filter: { date: 'period', start_date: startDate, end_date: endDate },
        pagination: false,
      });

      try {
        const [activityResult, googleCalendarResult] = await Promise.all([
          dispatch(
            getAllActivity({
              sort_field: 'createdAt',
              sort_order: 'desc',
              filter: {
                date: 'period',
                start_date: startDate,
                end_date: endDate,
              },
              pagination: false,
            })
          ),
          isGoogleCalendarConfig &&
            configuredUser &&
            configuredUser !== '' &&
            dispatch(
              getAllGoogleCalendarActivity({
                auth_user_id: configuredUser,
                start_date: googlesStartDate,
                end_date: googleEndDate,
              })
            ),
        ]);

        let mergedData: any = [];

        // Handle the results for the first API call (getAllActivity)
        if (getAllActivity.fulfilled.match(activityResult)) {
          console.log('Calendar events data....', activityResult);
          if (activityResult.payload?.response?.success) {
            // customizeEvents(activityResult.payload.response.data);
            // Customize and merge activity data
            mergedData = mergedData.concat(
              activityResult.payload.response.data?.activity_array || []
            );
          }
        }

        // Handle the results for the second API call (getAllGoogleCalendarActivity)
        if (
          getAllGoogleCalendarActivity.fulfilled.match(googleCalendarResult)
        ) {
          if (googleCalendarResult.payload?.success) {
            console.log(
              'Event calendar data....',
              googleCalendarResult.payload.data
            );

            const updatedEventData =
              googleCalendarResult.payload.data?.map((event: any) => ({
                ...event,
                title: event.summary,
                allDay: false,
                type: 'calendar_event',
                status: 'completed',
              })) || [];

            console.log('updatedEventData...', updatedEventData);
            // Merge Google Calendar events data
            mergedData = mergedData.concat(updatedEventData);

            // dispatch(setEventCalendarData(updatedEventData));
            // setEvents((prevData) => [...prevData, ...updatedEventData]);
          }
        }
        // Dispatch the merged data
        dispatch(setEventCalendarData(mergedData));
      } catch (error) {
        console.error('Error during API calls:', error);
      }
    }
  }

  const apiCalledForGetData = (filterObject: any) => {
    setCurrnetFilterParams(filterObject);
    dispatch(setPaginationDetails(filterObject));
  };

  // customize date format according calendar and set events
  useEffect(() => {
    const eventData =
      (activityData?.eventCalendarData &&
        activityData?.eventCalendarData?.length > 0 &&
        activityData?.eventCalendarData?.map((dataa: any) => {
          if (
            sameEventCalendarIds &&
            !sameEventCalendarIds?.includes(dataa?.id)
          ) {
            return {
              ...dataa,
              start: new Date(dataa?.start),
              end: new Date(dataa?.end),
            };
          }
        })) ||
      [];
    setEvents(eventData);
  }, [activityData?.eventCalendarData]);

  useEffect(() => {
    if (timeStatusType !== '' || startDate !== '' || endDate !== '') {
      setReset('');
    }
  }, [timeStatusType, startDate, endDate]);

  const handleSelectSlot = useCallback(
    ({ start, end }: { start: Date; end: Date }) => {
      if (pathname.includes('/meetings')) {
        if (
          (['agency'].includes(signIn?.role) ||
            (['team_agency', 'team_client'].includes(signIn?.role) &&
              checkPermission(
                'meetings',
                null,
                'create',
                signIn?.permission
              ))) &&
          (calenderViewForMeetingForm === 'month'
            ? moment(moment().startOf('day').toDate()).isSameOrBefore(start)
            : moment().isSameOrBefore(start))
        ) {
          dispatch(emptyDefaultFormData());
          openModal({
            view: (
              <MeetingForm
                title="New Meeting"
                isEdit={false}
                startDate={start}
                endDate={end}
                currentFilterParams={currentFilterParams}
                currentGoogleFilterParams={currentGoogleFilterParams}
                openFromCalender={true}
                currentCalendarView={calenderViewForMeetingForm}
              />
            ),
            customSize: '860px',
          });
        }
      }
    },
    [openModal, signIn?.role]
  );

  // const eventPropGetter = useCallback((event: any) => {
  //   let style;
  //   if (event?.status === 'completed') {
  //     style = {
  //       backgroundColor: '#F6F5FF',
  //       color: '#111928',
  //     };
  //   } else if (event?.status === 'cancel') {
  //     style = {
  //       backgroundColor: 'red',
  //       color: '#111928',
  //     };
  //   } else if (event?.status === 'pending') {
  //     style = {
  //       backgroundColor: '#EBF5FF',
  //       color: '#111928',
  //     };
  //   }
  //   return {
  //     style: style,
  //   };
  // }, []);

  const handleSelectEvent = useCallback(
    (event: any) => {
      // Only Agency and Agnecy Team member which have update permission can edit the meetings
      if (
        (['agency'].includes(signIn?.role) ||
          (['team_agency', 'team_client'].includes(signIn?.role) &&
            checkPermission('meetings', null, 'update', signIn?.permission))) &&
        event?.type !== 'calendar_event' &&
        event?.status === 'pending'
      ) {
        openModal({
          view: (
            <MeetingForm
              title="Update Meeting"
              isEdit={true}
              row={{ ...event, _id: event?.id }}
              currentFilterParams={currentFilterParams}
              currentGoogleFilterParams={currentGoogleFilterParams}
              openFromCalender={true}
            />
          ),
          customSize: '860px',
        });
      } else if (
        event?.type !== 'calendar_event' &&
        event?.status !== 'pending'
      ) {
        openModal({
          view: <MeetingDetail row={{ _id: event?.id }} />,
          customSize: '500px',
        });
      } else if (event?.type === 'calendar_event' && event?.view_link) {
        window.open(event?.view_link, '_blank');
      }
    },
    [openModal]
  );

  const { views, scrollToTime, defaultDate, formats } = useMemo(
    () => ({
      views: {
        month: true,
        week: true,
        day: true,
        agenda: true,
      },
      defaultDate: new Date(),
      scrollToTime: new Date(2023, 10, 27, 6),
      formats: {
        dateFormat: 'D',
        weekdayFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'ddd', culture),
        dayFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'ddd D', culture),
        timeGutterFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'hh A', culture),
      },
    }),
    []
  );

  // Custom Toolbar component
  const CustomToolbar = (toolbar: any) => {
    const [calenderView, SetCalenderView] = useState(calenderFilter[0]);

    const goToBack = () => {
      let view = toolbar.view;
      let mDate = moment(toolbar.date);

      switch (view) {
        case 'month':
          mDate = mDate.subtract(1, 'month');
          break;
        case 'week':
          mDate = mDate.subtract(1, 'week');
          break;
        case 'day':
          mDate = mDate.subtract(1, 'day');
          break;
        default:
          mDate = mDate.subtract(1, 'day');
      }
      toolbar.onNavigate('prev', mDate.toDate());
    };

    const goToNext = () => {
      let view = toolbar.view;
      let mDate = moment(toolbar.date);

      switch (view) {
        case 'month':
          mDate = mDate.add(1, 'month');
          break;
        case 'week':
          mDate = mDate.add(1, 'week');
          break;
        case 'day':
          mDate = mDate.add(1, 'day');
          break;
        default:
          mDate = mDate.add(1, 'day');
      }
      toolbar.onNavigate('next', mDate.toDate());
    };

    const handleViewChange = (event: any) => {
      toolbar.onView(event?.value);
      setCalenderViewForMeetingForm(event?.value);
      if (event?.value === 'month') {
        SetCalenderView({ label: 'Month', value: 'month' });
      } else if (event?.value === 'week') {
        SetCalenderView({ label: 'Week', value: 'week' });
      } else if (event?.value === 'day') {
        SetCalenderView({ label: 'Day', value: 'day' });
      }
    };

    return (
      <div className="flex justify-between p-8">
        <div className="flex items-center gap-3">
          <span className="text-xl font-semibold	text-[#120425]">
            {toolbar.label}
          </span>
          <span className="flex gap-1">
            <button type="button" className="cursor-pointer" onClick={goToBack}>
              <RiArrowLeftSLine className="h-6 w-6 text-[#4B5563]" />
            </button>
            <button type="button" className="cursor-pointer" onClick={goToNext}>
              <RiArrowRightSLine className="h-6 w-6 text-[#4B5563]" />
            </button>
          </span>
        </div>
        <div className="flex gap-3">
          {/* <Select
          className="calender-view-selection poppins_font_number remove_line w-[125px]"
          value={calenderView}
          options={calenderFilter}
          // isClearable={false}
          onChange={handleViewChange}
          styles={customStyles}
        /> */}

          <Select
            onChange={handleViewChange}
            value={calenderView}
            options={calenderFilter}
            placeholder="Select view"
            className="poppins_font_number h-10 w-[125px]"
            selectClassName="text-black"
            optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
            prefix={<FiCalendar className="h-4 w-4" />}
            suffix={<PiCaretDownBold className="h-4 w-4" />}
          />
          <div
            className={cn(
              'flex h-[40px] w-[140px] items-center justify-center rounded-lg bg-[#F3F4F6] p-1'
            )}
          >
            <ActionIcon
              size="sm"
              variant="flat"
              className={cn(
                'group flex w-[45%] items-center justify-center gap-[2px] bg-transparent hover:!bg-transparent',
                !calendarView && 'bg-[#E7E5FA]'
              )}
              onClick={() => dispatch(setCalendarView(false))}
            >
              <PiListBullets
                className={cn(
                  'h-3.5 w-3.5',
                  calendarView ? 'text-black' : 'text-[#362F78]'
                )}
              />
              <span className="text-xs font-medium">List</span>
            </ActionIcon>
            <ActionIcon
              size="sm"
              variant="flat"
              className={cn(
                'group flex w-[55%] items-center justify-center gap-[2px] bg-transparent hover:!bg-transparent',
                calendarView && 'bg-[#E7E5FA]'
              )}
              onClick={() => dispatch(setCalendarView(true))}
            >
              <MdOutlineSpaceDashboard
                className={cn(
                  'h-3.5 w-3.5',
                  !calendarView ? 'text-black' : 'text-[#362F78]'
                )}
              />
              <span className="text-xs font-medium">Board</span>
            </ActionIcon>
          </div>
        </div>
      </div>
    );
  };

  const memoizedToolbar = useMemo(() => CustomToolbar, []);

  const dayPropGetter = (date: any) => {
    const isDefaultDate = date.toDateString() === defaultDate.toDateString();

    return {
      style: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      },
    };
  };

  const CustomHeader = ({ label }: any) => {
    return (
      <div className="fon-semibold text-center text-sm text-[#9BA1B9]">
        {label}
      </div>
    );
  };

  const formatEventTime = (start: Date, end: Date) => {
    return `${moment(start).format('h:mm A')} - ${moment(end).format(
      'h:mm A'
    )}`;
  };

  // Custom event component
  const CustomEvent = ({ event }: any) => {
    console.log(event, 'event');
    const eventTime = formatEventTime(event.start, event.end);
    return (
      <div
        className={cn(
          'flex h-full flex-col gap-[7px] rounded-[6px] px-3 py-[6px] text-black',
          event?.status === 'pending' && 'bg-orange-100',
          event?.status === 'completed' && 'bg-green-100',
          event?.status === 'cancel' && 'bg-red-100',
          event?.type === 'calendar_event' && 'bg-blue-100'
        )}
      >
        <div className="flex items-center justify-start gap-2">
          <Badge
            className={cn(
              'h-2 w-2',
              event?.status === 'pending' && 'bg-orange-500',
              event?.status === 'completed' && 'bg-green-500',
              event?.status === 'cancel' && 'bg-red-500',
              event?.type === 'calendar_event' && 'bg-blue-500'
            )}
            renderAsDot
          />
          <div className="flex w-full max-w-[calc(100%-18px)] items-center justify-between gap-1">
            <div className="max-w-[calc(100%-18px)] truncate text-xs font-medium text-black">
              {capitalizeFirstLetter(event?.title)}
            </div>
            {event?.google_meeting_link &&
              event?.google_meeting_link !== '' && (
                <Link
                  href={event?.google_meeting_link}
                  target="_blank"
                  className="text-xs font-medium text-[#5850EC] underline decoration-[#5850EC]"
                >
                  Join now
                </Link>
              )}
          </div>
        </div>
        <div className="text-xs font-semibold text-black">{eventTime}</div>
      </div>
    );
  };

  return (
    <div className="@container">
      <WidgetCard rounded="lg" title="" className="border-none p-0 lg:p-0">
        <Calendar
          step={60}
          timeslots={1}
          localizer={localizer}
          events={events}
          views={views}
          formats={formats}
          startAccessor="start"
          endAccessor="end"
          dayLayoutAlgorithm="no-overlap"
          onSelectEvent={handleSelectEvent}
          onSelectSlot={handleSelectSlot}
          // eventPropGetter={eventPropGetter}
          onNavigate={handleNavigate}
          dayPropGetter={dayPropGetter}
          selectable
          scrollToTime={scrollToTime}
          defaultDate={defaultDate}
          className={cn(
            'meeting-calender h-[650px] rounded-xl border border-[#E5E7EB]  bg-white md:h-[1000px]',
            calendarToolbarClassName
          )}
          components={{
            toolbar: memoizedToolbar,
            header: CustomHeader,
            event: CustomEvent, // Use the custom event component
          }}
        />
      </WidgetCard>
    </div>
  );
}
