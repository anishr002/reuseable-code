export const RecurringForm = () => {
  return (
    <>
      <div>Model</div>
    </>
  );
};
