'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import { getInstantMeetingLink } from '@/redux/slices/user/meeting/meetingSlice';
import cn from '@/utils/class-names';
import { useEffect } from 'react';
import toast from 'react-hot-toast';
import { FiCopy } from 'react-icons/fi';
import { LuShare2 } from 'react-icons/lu';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import {
    EmailIcon,
    EmailShareButton,
    FacebookIcon,
    FacebookShareButton,
    LinkedinIcon,
    LinkedinShareButton,
    RedditIcon,
    RedditShareButton,
    TelegramIcon,
    TelegramShareButton,
    TwitterIcon,
    TwitterShareButton,
    WhatsappIcon,
    WhatsappShareButton,
} from 'react-share';

export const InstantMeeting = (props: any) => {
    const { title } = props;
    const { closeModal, openModal } = useModal();
    const dispatch = useDispatch();
    const { getMeetingLinkLoading, getMeetingLink } = useSelector((state: any) => state?.root?.meeting);
    const social_share_message: string = 'Here is your meeting link';
    const urlToShareIS = getMeetingLink?.hangoutLink;
    const handleCopyLink = () => {
        navigator.clipboard.writeText(getMeetingLink?.hangoutLink).then(() => {
            toast.success('Meeting link copied to clipboard!');
        });
    };

    useEffect(() => {
        dispatch(getInstantMeetingLink()).then((response: any) => {
            if (!response?.payload?.success) {
                closeModal();
            }
        }).catch(() => {
            closeModal();
        });
    }, []);
    const onhandeclickshere = (urlToShareIS?: any, message?: any) => {
        closeModal();
        openModal({
            view: (
                <div className="m-auto p-4 md:px-7 md:pb-10 md:pt-6">
                    <div className="mb-4 flex items-center justify-between">
                        <Title as="h4" className="text-2xl font-bold text-[#9BA1B9]">
                            Share your referral link
                        </Title>
                        <ActionIcon
                            size="sm"
                            variant="text"
                            onClick={() => closeModal()}
                            className="p-0 text-gray-500 hover:!text-gray-900"
                        >
                            <PiXBold className="h-[18px] w-[18px]" />
                        </ActionIcon>
                    </div>
                    <div className="grid grid-cols-5 sm:grid-cols-7 pt-5 justify-center">
                        <div
                            className='flex justify-center py-1'
                        >
                            <EmailShareButton
                                url={`${urlToShareIS}`}
                                subject={`Sign up to Syncupp using referral link`}
                                body={`Sign up to Syncupp using referral link`}
                            >
                                <EmailIcon size={50} round={true} />
                            </EmailShareButton>
                        </div>

                        <div
                            className='flex justify-center py-1'
                        >
                            <FacebookShareButton url={`${urlToShareIS}`}>
                                <FacebookIcon size={50} round={true} />
                            </FacebookShareButton>
                        </div>
                        <div
                            className='flex justify-center py-1'
                        >
                            <TwitterShareButton url={`${urlToShareIS}`} title={message}>
                                <TwitterIcon size={50} round={true} />
                            </TwitterShareButton>
                        </div>
                        <div
                            className='flex justify-center py-1'
                        >
                            <LinkedinShareButton url={`${urlToShareIS}`} title={message} summary={message}>
                                <LinkedinIcon size={50} round={true} />
                            </LinkedinShareButton>
                        </div>
                        <div
                            className='flex justify-center py-1'
                        >
                            <WhatsappShareButton url={`${urlToShareIS}`} title={message}>
                                <WhatsappIcon size={50} round={true} />
                            </WhatsappShareButton>
                        </div>
                        <div
                            className='flex justify-center py-1'
                        >
                            <TelegramShareButton url={`${urlToShareIS}`} title={message}>
                                <TelegramIcon size={50} round={true} />
                            </TelegramShareButton>
                        </div>
                        <div
                            className='flex justify-center py-1'
                        >
                            <RedditShareButton url={`${urlToShareIS}`} title={message}>
                                <RedditIcon size={50} round={true} />
                            </RedditShareButton>
                        </div>
                    </div>

                </div>
            ),
        });
    };
    return (getMeetingLinkLoading ? <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
    </div> :
        <div className='space-y-6 p-8'>
            {/* Header Section */}
            <div className="flex items-center justify-between mb-4">
                <Title as="h3" className="text-xl font-bold text-gray-800">
                    {title || 'Share meeting details'}
                </Title>
                <ActionIcon
                    size="sm"
                    variant="text"
                    onClick={closeModal}
                    className="text-black hover:text-black"
                >
                    <PiXBold className="h-5 w-5" />
                </ActionIcon>
            </div>

            {/* Content Section */}
            <p className="text-sm font-medium text-center text-[#141414]">
                Copy this link & share it to people you want to join the meeting.
            </p>

            {/* Link Sharing Section */}
            <div className="flex justify-between items-center border border-[#E5E7EB] rounded-md p-0 bg-[#F9FAFB]">
                <input
                    type="text"
                    value={getMeetingLink?.hangoutLink}
                    readOnly
                    className="p-3 flex-grow border-none bg-transparent text-sm text-black outline-none"
                />
                <button
                    onClick={handleCopyLink}
                    className="text-[#7667CF] p-3 hover:text-[#52459b]"
                >
                    <FiCopy className="h-5 w-5" />
                </button>
            </div>
            {/* Action Buttons */}
            <div className="flex justify-center gap-4">
                <Button
                    variant="outline"
                    size="sm"
                    className="border border-[#6875F5] hover:!border-[#6875F5] text-[#5850EC] font-medium p-4 rounded-lg flex items-center gap-2"
                    onClick={() => onhandeclickshere(urlToShareIS, social_share_message)}
                >

                    <LuShare2 className="h-[16px] w-[16px]" />
                    Share invite
                </Button>

                <a
                    href={getMeetingLink?.hangoutLink || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => {
                        if (!getMeetingLink?.hangoutLink) {
                            e.preventDefault(); // Prevent navigation if the link is missing
                            toast.error("Meeting link is not available.");
                        }
                    }}
                // className="w-full h-full flex items-center justify-center"
                >
                    <Button
                        variant="solid"
                        size="sm"
                        className="flex leading-[140%] items-center justify-center rounded-lg bg-[#7667CF] px-6 py-4 text-[14px] font-normal text-[#ffff]"
                    >
                        Join now
                    </Button>
                </a>
            </div>
        </div>
    );
};
