import { useModal } from '@/app/shared/modal-views/use-modal';
import QuillLoader from '@/components/loader/quill-loader';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
// import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title, Text } from '@/components/ui/text';
import { messages } from '@/config/messages';
import { Avatar, Input, Textarea } from 'rizzui';

import {
  getAllActivity,
  getAllGoogleCalendarActivity,
  setEventCalendarData,
} from '@/redux/slices/user/activity/activitySlice';
import {
  addCustomAttendess,
  attendeesList,
  createMeeting,
  createMeetingWithGoogleMeet,
  deleteMeeting,
  emptyDefaultFormData,
  getMeetingById,
  updateMeeting,
} from '@/redux/slices/user/meeting/meetingSlice';
import {
  capitalizeFirstLetter,
  checkValidFileSize,
  getColor,
  getFileSize,
  getFileType,
  handleKeyDown,
} from '@/utils/common-functions';
import { useGoogleLogin } from '@react-oauth/google';
import moment from 'moment';
import dynamic from 'next/dynamic';
import {
  AwaitedReactNode,
  JSXElementConstructor,
  Key,
  ReactElement,
  ReactNode,
  useEffect,
  useRef,
  useState,
} from 'react';
import { Controller } from 'react-hook-form';
import toast from 'react-hot-toast';
import { GoPeople } from 'react-icons/go';
import { LuClock } from 'react-icons/lu';
import {
  MdContentCopy,
  MdLocationPin,
  MdOutlineCalendarToday,
  MdDelete,
} from 'react-icons/md';
import { PiXBold } from 'react-icons/pi';
import { RxCross2 } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import Select from 'react-select';
import ReactSelect from 'react-select/creatable';
import { Radio } from 'rizzui';
import SimpleBar from 'simplebar-react';
import { z } from 'zod';
import { Popover } from '@/components/ui/popover';
import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { ImAttachment } from 'react-icons/im';
import { useDropzone } from 'react-dropzone';
import {
  getAllMyMeetingsdashbord,
  setDashboardEventCalendarData,
} from '@/redux/slices/user/dashboard/dashboardSlice';

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px] w-full" />,
});

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isFocused ? '#EDEAFE' : 'transparent',
    color: state.Focused ? '#362F78' : 'black',
    padding: '8px',
    width: '90%',
    margin: '0 auto',
    borderRadius: '10px',
  }),
  multiValueLabel: (provided: any, { data }: { data: any }) => ({
    ...provided,
    color: data?.isInvalid ? 'red' : 'black',
  }),
};

// const MultiValue = ({ data, removeProps }) => {
//   return (
//     <div className="flex items-center justify-between p-2 border-[1px] rounded-lg bg-white shadow-sm m-1">
//       <div className="flex items-center gap-2">
//         <img
//           src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${data.profile_image}`}
//           alt={data.label}
//           className="h-[30px] w-[30px] rounded-full object-cover"
//         />
//         <span className="text-[14px] font-semibold">{data.label}</span>
//       </div>
//       <RxCross2
//         className="h-[20px] w-[20px] cursor-pointer"
//         onClick={removeProps.onClick}
//       />
//     </div>
//   );
// };

const notificationType = [
  { label: 'Minutes', value: 'min' },
  {
    label: 'Hours',
    value: 'h',
  },
];

const RecurringArray = [
  {
    name: 'Does not repeat',
    label: 'Does not repeat',
    value: '',
  },
  {
    name: 'Daily',
    label: 'Daily',
    value: 'daily',
  },
  {
    name: 'Weekly',
    label: 'Weekly',
    value: 'weekly',
  },
  {
    name: 'Monthly',
    label: 'Monthly',
    value: 'monthly',
  },
];

let monthDate = [
  { label: '1', value: '1' },
  { label: '2', value: '2' },
  { label: '3', value: '3' },
  { label: '4', value: '4' },
  { label: '5', value: '5' },
  { label: '6', value: '6' },
  { label: '7', value: '7' },
  { label: '8', value: '8' },
  { label: '9', value: '9' },
  { label: '10', value: '10' },
  { label: '11', value: '11' },
  { label: '12', value: '12' },
  { label: '13', value: '13' },
  { label: '14', value: '14' },
  { label: '15', value: '15' },
  { label: '16', value: '16' },
  { label: '17', value: '17' },
  { label: '18', value: '18' },
  { label: '19', value: '19' },
  { label: '20', value: '20' },
  { label: '21', value: '21' },
  { label: '22', value: '22' },
  { label: '23', value: '23' },
  { label: '24', value: '24' },
  { label: '25', value: '25' },
  { label: '26', value: '26' },
  { label: '27', value: '27' },
  { label: '28', value: '28' },
  { label: '29', value: '29' },
  { label: '30', value: '30' },
  { label: '31', value: '31' },
];

const weekdays = [
  { name: 'S', value: 'sunday' },
  { name: 'M', value: 'monday' },
  { name: 'T', value: 'tuesday' },
  { name: 'W', value: 'wednesday' },
  { name: 'T', value: 'thursday' },
  { name: 'F', value: 'friday' },
  { name: 'SA', value: 'saturday' },
];

export const MeetingForm = (props: any) => {
  const {
    title,
    row,
    isEdit,
    attendee_id,
    startDate,
    endDate,
    currentFilterParams,
    openFromCalender = false,
    currentGoogleFilterParams,
    currentCalendarView = 'month',
    isDashoardCalender,
    googleAccounts,
    setAllDayEvent,
    setEvents,
  } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const commentAttachmentRef = useRef<HTMLInputElement>(null);
  const [selectedRecurringOption, SetSelectedRecurringOption] = useState<any>({
    name: 'Does not repeat',
    label: 'Does not repeat',
    value: '',
  });
  const [selectedAlertTimeUnit, SetSelectedAlertTimeUnit] = useState<any>({
    label: '',
    value: '',
  });
  const [googleMeetingForm, SetGoogleMeetingForm] = useState<any>({});
  const [alertTimeValue, setAlertTimeValue] = useState<any>();
  const [disabledMeetingTime, setDisabledMeetingTime] =
    useState<boolean>(false);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [allMeeting, setAllMeeting] = useState<boolean>(false);
  const [commentAttachementInvalid, setCommentAttachementInvalid] =
    useState(false);
  const [previewImage, setPreviewImage] = useState<any>(null);

  // console.log("currentFilterParams....", currentFilterParams);
  // console.log("currentGoogleFilterParams....", currentGoogleFilterParams);

  // Form Validation Schema
  const meetingSchema = z.object({
    title: z
      .string()
      .min(1, { message: messages.titleIsRequired })
      .max(100, { message: messages.meetingTitleLength }),
    agenda: z.string().optional(),
    meeting_date: z
      .date()
      .nullable()
      .refine((val) => val !== null, {
        message: messages.startDateIsRequired,
      }),
    meeting_start_time: z
      .date()
      .nullable()
      .refine((val) => val !== null, {
        message: messages.startTimeIsRequired,
      }),
    meeting_end_time: z
      .date()
      .nullable()
      .refine((val) => val !== null, {
        message: messages.endTimeIsRequired,
      }),
    internal_info: z
      .string()
      .max(50, { message: messages.locationMaxlength })
      .optional(),
    attendees: z
      .array(
        z.object({
          _id: z.string().refine(
            (val) => {
              if (val.startsWith('mail:')) {
                // Validate email format after "mail:" prefix
                const email = val.slice(5); // Remove 'mail:' prefix
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email);
              }
              return true; // If it doesn't start with "mail:", no validation is applied
            },
            {
              message: 'Invalid email address',
            }
          ),
        })
      )
      .min(1, messages.attendeesIsRequired),
    all_day: z.boolean().optional(),
    alert_time: (selectedAlertTimeUnit?.value != ''
      ? z.string().min(1, { message: 'Time Unit is required' })
      : z.string().optional()
    ).superRefine((value: any, context: any) => {
      if (selectedAlertTimeUnit?.value == 'min' && value > 60) {
        return context.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Minutes is between 1 and 60',
        });
      }
      if (selectedAlertTimeUnit?.value == 'h' && value > 24) {
        return context.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Hour is between 1 and 24',
        });
      }
      return value;
    }),
    alert_time_unit: z
      .object({ label: z.string().optional(), value: z.string().optional() })
      .optional(),
    recurrence_pattern: z.string().nullable().optional(),
    weekly_recurrence_days:
      selectedRecurringOption?.value == 'weekly'
        ? z.string().min(1, { message: 'Select any one day' })
        : z.string().optional(),
    recurrence_interval:
      selectedRecurringOption?.value != ''
        ? z
            .string()
            .min(1, { message: 'Minimum 1 number enter' })
            .max(2, { message: 'Max 2 digit value allow' })
        : z.string().optional(),
    recurrence_end_date:
      selectedRecurringOption?.value != ''
        ? z
            .date()
            .nullable()
            .refine((val: any) => val !== null, {
              message: messages.recurringEndDateIsRequried,
            })
        : z.date().nullable().optional(),
    monthly_recurrence_day_of_month:
      selectedRecurringOption?.value == 'monthly'
        ? z
            .object({
              label: z.string(),
              value: z.string(),
            })
            .nullable()
        : z
            .object({
              label: z.string().optional(),
              value: z.string().optional(),
            })
            .optional(),
  });

  // Selector
  const {
    attendeesUserList,
    createMeetingLoading,
    updateMeetingLoading,
    getMeetingByIdLoading,
    createMeetingWithGoogleMeetLoading,
    meetingDataById,
    deleteMeetingLoading,
  } = useSelector((state: any) => state?.root?.meeting);

  // create hook form setValue reference
  const setValueReference = useRef<any>();
  const getValuesReference = useRef<any>();
  const setFocusReference = useRef<any>();

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    // Generate preview URLs for valid files
    // const previewURLs = acceptedFiles.map((file: any) => URL.createObjectURL(file));

    const newFiles = [
      ...acceptedFiles.map((file: any) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      ),
    ];

    // Combine previous files with the new files
    const previewURLs =
      previewImage && previewImage !== null
        ? [...previewImage, ...newFiles]
        : [...newFiles];

    // Set the combined list of files
    setValueReference.current('attachments', previewURLs, {
      shouldValidate: true,
    });
    setPreviewImage(previewURLs);

    // // const file = URL.createObjectURL(acceptedFiles[0])
    // // setValue("attachments", acceptedFiles[0])
    // setValueReference.current('attachments', previewURLs)

    // setPreviewImage(previewURLs)
  };
  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: {
      // 1. Documents
      'application/msword': ['.doc', '.docx'],
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt', '.log', '.ini'], // Combined duplicates for text/plain
      'application/rtf': ['.rtf'],
      'application/vnd.oasis.opendocument.text': ['.odt'],
      'application/epub+zip': ['.epub'],

      // 2. Spreadsheets
      'application/vnd.ms-excel': ['.xls', '.xlsx'],
      'text/csv': ['.csv'], // Use only one key for CSV
      'application/vnd.oasis.opendocument.spreadsheet': ['.ods'],

      // 3. Presentations
      'application/vnd.ms-powerpoint': ['.ppt', '.pptx'],
      'application/vnd.oasis.opendocument.presentation': ['.odp'],
      'application/x-iwork-keynote-sffkey': ['.key'],

      // 4. Images
      'image/*': [
        '.jpeg',
        '.jpg',
        '.png',
        '.gif',
        '.bmp',
        '.tiff',
        '.svg',
        '.webp',
      ],

      // 5. Videos
      'video/*': ['.mp4', '.avi', '.mov', '.wmv', '.mkv', '.flv'],

      // 6. Audio
      'audio/*': ['.mp3', '.wav', '.aac', '.ogg', '.flac'],

      // 7. Code/Programming
      'application/javascript': ['.js'],
      'application/json': ['.json'],
      'application/xml': ['.xml'],
      'text/html': ['.html', '.htm'],
      'text/css': ['.css'],
      'text/yaml': ['.yaml'],
      'application/sql': ['.sql'],
      'text/markdown': ['.md'],
      'text/x-python': ['.py'],
      'text/x-java-source': ['.java'],
      'text/x-c': ['.c', '.cpp'],

      // 8. Design
      'image/vnd.adobe.photoshop': ['.psd'],
      'application/postscript': ['.ai', '.eps'],
      'application/vnd.adobe.xd': ['.xd'],
      'application/figma': ['.fig'],
      'application/sketch': ['.sketch'],
      'application/x-indesign': ['.indd'],

      // 9. Data/Database
      'application/vnd.sqlite3': ['.sqlite'],
      'application/octet-stream': ['.db'],

      // 10. Compressed Files
      'application/zip': ['.zip', '.rar', '.7z', '.tar.gz', '.iso'],

      // 11. Miscellaneous
      'text/calendar': ['.ics'],
      'application/vnd.android.package-archive': ['.apk'],
      'application/x-apple-diskimage': ['.dmg'],
    },
    // maxSize: 200 * 1024 * 1024, // Maximum file size of 200MB
    multiple: true,
    noClick: true,
  };

  const { getRootProps, getInputProps } = useDropzone(dropzoneOptions);

  // Date Formate coverter
  const convertDate = (dateString: any) => {
    const utcDate = moment.utc(dateString);
    // Adjust to India time zone without changing the time
    const istDate = utcDate.clone().utcOffset('+05:30', true);
    // Format to fetch the date and time in IST
    const dateInIST = istDate.format('YYYY-MM-DDTHH:mm:ss.SSSZ');
    return new Date(dateInIST);
  };

  useEffect(() => {
    setPreviewImage(meetingDataById?.attachments || null);
  }, [meetingDataById]);

  let defaultValues = {
    title: meetingDataById?.title ? meetingDataById?.title : '',
    agenda: meetingDataById?.agenda ? meetingDataById?.agenda : '',
    meeting_date: meetingDataById?.meeting_date
      ? moment(meetingDataById?.meeting_date).toDate()
      : startDate
        ? moment(startDate).toDate()
        : null,
    meeting_start_time: meetingDataById?.meeting_start_time
      ? moment(meetingDataById.meeting_start_time).toDate()
      : startDate && (currentCalendarView !== 'month' || isDashoardCalender)
        ? moment(startDate).toDate()
        : null,
    meeting_end_time: meetingDataById?.meeting_end_time
      ? moment(meetingDataById?.meeting_end_time).toDate()
      : endDate && (currentCalendarView !== 'month' || isDashoardCalender)
        ? moment(endDate).toDate()
        : null,

    internal_info: meetingDataById?.internal_info
      ? meetingDataById?.internal_info
      : '',
    attendees: meetingDataById?.attendees ? meetingDataById?.attendees : [],
    all_day: meetingDataById?.all_day ? meetingDataById?.all_day : false,
    alert_time: meetingDataById?.alert_time
      ? String(meetingDataById?.alert_time)
      : '',
    recurrence_pattern: meetingDataById?.recurrence_pattern
      ? meetingDataById?.recurrence_pattern
      : '',
    weekly_recurrence_days: meetingDataById?.weekly_recurrence_days
      ? meetingDataById?.weekly_recurrence_days
      : '',
    recurrence_end_date: meetingDataById?.recurrence_end_date
      ? moment(meetingDataById?.recurrence_end_date).toDate()
      : null,
    recurrence_interval:
      meetingDataById?.recurrence_interval > -1
        ? String(meetingDataById?.recurrence_interval)
        : '',
    // alert_time_unit: meetingDataById?.alert_time_unit ? meetingDataById?.alert_time_unit : {label: '', value: ''},
    monthly_recurrence_day_of_month:
      meetingDataById?.monthly_recurrence_day_of_month
        ? {
            label: String(meetingDataById?.monthly_recurrence_day_of_month),
            value: String(meetingDataById?.monthly_recurrence_day_of_month),
          }
        : { label: '1', value: '1' },
  };

  const isToday = (date: any) => {
    const today = moment()?.startOf('day');
    return (
      moment(date).isSame(moment(), 'day') ||
      moment(date).isBefore(today, 'day')
    );
  };

  // Get Min Time
  const getMinTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment(selectedDate).isSame(moment(), 'day')
        ? moment().toDate()
        : moment().endOf('day').toDate();
    }
    return undefined;
  };

  // Get Max Time
  const getMaxTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment().endOf('day').toDate();
    }
    return undefined;
  };

  // Called Attendess Listing API and Get By Id
  useEffect(() => {
    dispatch(emptyDefaultFormData());

    // Pre Add Attendes When Meeting Create From Agency Team Member / Client Memeber / Client Team Memeber Page
    dispatch(attendeesList()).then((result: any) => {
      if (attendeesList.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          if (attendee_id && result?.payload?.data?.length != 0) {
            const defaultAttendee = attendeesUserList?.find(
              (attendee: any) => attendee?._id == attendee_id
            );
            // Set Attendee
            setValueReference.current('attendees', [defaultAttendee]);
          }
        }
      }
    });

    if (row?._id) {
      dispatch(getMeetingById(row?._id)).then((result: any) => {
        if (getMeetingById.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            const [data] = result?.payload?.data;

            data &&
              data?.custom_attendees &&
              data?.custom_attendees?.length > 0 &&
              data?.custom_attendees?.map((user: any) => {
                const newOption = {
                  _id: `mail:${user}`,
                  label: user,
                };
                dispatch(addCustomAttendess(newOption));
              });

            // Set Meeting Date for min max validation
            setSelectedDate(defaultValues?.meeting_date);
          }
        }
      });
    } else {
      setSelectedDate(defaultValues?.meeting_date);
    }
  }, []);

  // Manage Form While Edit The Existing Meeting
  useEffect(() => {
    if (Object.values(meetingDataById)?.length > 0) {
      const setRecurrencePattern = RecurringArray?.find(
        (data: any) => data?.value == meetingDataById?.recurrence_pattern
      );
      if (setRecurrencePattern) {
        SetSelectedRecurringOption(setRecurrencePattern);
      } else {
        SetSelectedRecurringOption({
          name: 'Does not repeat',
          label: 'Does not repeat',
          value: '',
        });
      }

      if (meetingDataById?.alert_time_unit) {
        const setAlertTimeUnit = notificationType?.find(
          (data: any) => data?.value == meetingDataById?.alert_time_unit
        );
        if (setAlertTimeUnit) {
          setValueReference.current('alert_time_unit', setAlertTimeUnit);
          SetSelectedAlertTimeUnit(setAlertTimeUnit);
        }
      } else {
        setValueReference.current('alert_time_unit', { label: '', value: '' });
        SetSelectedAlertTimeUnit({ label: '', value: '' });
      }

      // Disable Meeting Start and End date if All day is selected
      if (meetingDataById?.all_day) setDisabledMeetingTime(true);
    }
  }, [meetingDataById]);

  async function calendarApiCalls(
    currentFilterParams: any,
    currentGoogleFilterParams: any
  ) {
    try {
      const [activityResult, googleCalendarResult] = await Promise.all([
        currentFilterParams && dispatch(getAllActivity(currentFilterParams)),
        currentGoogleFilterParams &&
          currentGoogleFilterParams?.auth_user_id !== '' &&
          dispatch(getAllGoogleCalendarActivity(currentGoogleFilterParams)),
      ]);

      let mergedData: any = [];

      // Handle the results for the first API call (getAllActivity)
      if (getAllActivity.fulfilled.match(activityResult)) {
        console.log('Calendar events data....', activityResult);
        if (activityResult.payload?.response?.success) {
          // customizeEvents(activityResult.payload.response.data);
          // Customize and merge activity data
          mergedData = mergedData.concat(
            activityResult.payload.response.data?.activity_array || []
          );
        }
      }

      // Handle the results for the second API call (getAllGoogleCalendarActivity)
      if (getAllGoogleCalendarActivity.fulfilled.match(googleCalendarResult)) {
        if (googleCalendarResult.payload?.success) {
          console.log(
            'Event calendar data....',
            googleCalendarResult.payload.data
          );

          const updatedEventData =
            googleCalendarResult.payload.data?.map((event: any) => ({
              ...event,
              title: event.summary,
              allDay: false,
              type: 'calendar_event',
              status: 'completed',
            })) || [];

          console.log('updatedEventData...', updatedEventData);
          // Merge Google Calendar events data
          mergedData = mergedData.concat(updatedEventData);

          // dispatch(setEventCalendarData(updatedEventData));
          // setEvents((prevData) => [...prevData, ...updatedEventData]);
        }
      }
      // Dispatch the merged data
      dispatch(setEventCalendarData(mergedData));
    } catch (error) {
      console.error('Error during API calls:', error);
    }
  }

  const onSubmit = (data: any) => {
    if (commentAttachementInvalid) {
      return;
    }
    const payload = createPayload(data);
    const formData = new FormData();

    Object.entries(payload).forEach(([key, value]: any) => {
      if (value !== null && value !== undefined) {
        if (Array.isArray(value)) {
          value.forEach((item: any) => formData.append(`${key}[]`, item));
        } else {
          formData.append(key, value);
        }
      }
    });

    if (!isEdit) {
      previewImage?.length > 0 &&
        previewImage?.map((file: any) => {
          formData.append('attachments', file);
        });
    } else {
      previewImage?.length > 0 &&
        previewImage?.map((file: any) => {
          if (!file?.preview?.startsWith('blob')) {
            formData.append('attachments', file?.preview);
          } else {
            formData.append('attachments', file);
          }
        });
    }

    if (isEdit) {
      formData.append(
        'google_meeting',
        meetingDataById?.google_meeting_data?.meet_link ? 'true' : 'false'
      );
      updateMeetingAPICall(formData, meetingDataById?._id);
      console.log(meetingDataById?._id, 'meetingDataById?._id');
    } else {
      formData.append('google_meeting', 'false');
      createMeetingAPICall(formData);
    }
  };

  // Create Meeting API Called Function
  const createMeetingAPICall = (payload: any) => {
    dispatch(createMeeting(payload)).then(async (result: any) => {
      if (createMeeting.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(emptyDefaultFormData());

          let configureUserId = '';

          if (openFromCalender) {
            calendarApiCalls(currentFilterParams, currentGoogleFilterParams);
          } else if (
            isDashoardCalender &&
            moment(startDate).format('DD-MM-YYYY') ===
              payload.get('meeting_date')
          ) {
            try {
              // Step 1: Fetch meetings
              const activityResult = await dispatch(
                getAllMyMeetingsdashbord({
                  date: payload.get('meeting_date'),
                })
              );

              // Step 2: Fetch Google Calendar events
              const googleCalendarResult =
                configureUserId &&
                configureUserId !== '' &&
                (await dispatch(
                  getAllGoogleCalendarActivity({
                    auth_user_id: configureUserId,
                    start_date: moment().startOf('day').utc(),
                    end_date: moment().endOf('day').utc(),
                  })
                ));

              let mergedData: any = [];

              // Step 3: Merge dashboard meetings
              if (getAllMyMeetingsdashbord.fulfilled.match(activityResult)) {
                if (activityResult.payload?.success) {
                  mergedData = mergedData.concat(
                    activityResult?.payload?.data?.activity_array || []
                  );
                }
              }

              // Step 4: Merge Google Calendar events
              if (
                googleCalendarResult &&
                getAllGoogleCalendarActivity.fulfilled.match(
                  googleCalendarResult
                )
              ) {
                if (googleCalendarResult?.payload?.success) {
                  const updatedEventData =
                    googleCalendarResult?.payload?.data?.map((event: any) => {
                      const startDate: any = new Date(event?.start);
                      const endDate: any = new Date(event?.end);
                      const differenceInMilliseconds = endDate - startDate;
                      const differenceInHours =
                        differenceInMilliseconds / (1000 * 60 * 60);
                      const allDayStatus =
                        (differenceInHours && differenceInHours === 24) ??
                        false;

                      return {
                        ...event,
                        title: event.summary,
                        all_day: allDayStatus,
                        type: 'calendar_event',
                        status: 'completed',
                      };
                    }) || [];

                  mergedData = mergedData.concat(updatedEventData);
                }
              }

              // Step 5: Dispatch merged data to update state
              dispatch(setDashboardEventCalendarData(mergedData));
            } catch (error) {
              console.error('Error during API calls:', error);
            }
          } else {
            dispatch(
              getAllActivity({
                attendee_id,
                pagination: true,
                sort_field: 'createdAt',
                sort_order: 'desc',
              })
            );
          }

          closeModal();
        }
      }
    });
  };

  // Create Meeting With Google Meet
  const createMeetingWithGoogleMeetFn = (payload: any) => {
    dispatch(createMeetingWithGoogleMeet(payload)).then(async (result: any) => {
      if (createMeetingWithGoogleMeet.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(emptyDefaultFormData());
          let configureUserId = '';

          if (openFromCalender) {
            // dispatch(getAllActivity(currentFilterParams));
            calendarApiCalls(currentFilterParams, currentGoogleFilterParams);
          } else if (
            isDashoardCalender &&
            moment(startDate).format('DD-MM-YYYY') ===
              payload.get('meeting_date')
          ) {
            try {
              // Step 1: Fetch meetings
              const activityResult = await dispatch(
                getAllMyMeetingsdashbord({
                  date: payload.get('meeting_date'),
                })
              );

              // Step 2: Fetch Google Calendar events
              const googleCalendarResult =
                configureUserId &&
                configureUserId !== '' &&
                (await dispatch(
                  getAllGoogleCalendarActivity({
                    auth_user_id: configureUserId,
                    start_date: moment().startOf('day').utc(),
                    end_date: moment().endOf('day').utc(),
                  })
                ));

              let mergedData: any = [];

              // Step 3: Merge dashboard meetings
              if (getAllMyMeetingsdashbord.fulfilled.match(activityResult)) {
                if (activityResult.payload?.success) {
                  mergedData = mergedData.concat(
                    activityResult?.payload?.data?.activity_array || []
                  );
                }
              }

              // Step 4: Merge Google Calendar events
              if (
                googleCalendarResult &&
                getAllGoogleCalendarActivity.fulfilled.match(
                  googleCalendarResult
                )
              ) {
                if (googleCalendarResult?.payload?.success) {
                  const updatedEventData =
                    googleCalendarResult?.payload?.data?.map((event: any) => {
                      const startDate: any = new Date(event?.start);
                      const endDate: any = new Date(event?.end);
                      const differenceInMilliseconds = endDate - startDate;
                      const differenceInHours =
                        differenceInMilliseconds / (1000 * 60 * 60);
                      const allDayStatus =
                        (differenceInHours && differenceInHours === 24) ??
                        false;

                      return {
                        ...event,
                        title: event.summary,
                        all_day: allDayStatus,
                        type: 'calendar_event',
                        status: 'completed',
                      };
                    }) || [];

                  mergedData = mergedData.concat(updatedEventData);
                }
              }

              // Step 5: Dispatch merged data to update state
              dispatch(setDashboardEventCalendarData(mergedData));
            } catch (error) {
              console.error('Error during API calls:', error);
            }
          } else {
            dispatch(
              getAllActivity({
                attendee_id,
                pagination: true,
                sort_field: 'createdAt',
                sort_order: 'desc',
              })
            );
          }
          closeModal();
        }
      }
    });
  };

  // Edit Meeting API Called Function
  const updateMeetingAPICall = (payload: any, id: any) => {
    dispatch(updateMeeting({ data: payload, id })).then((result: any) => {
      if (updateMeeting.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(emptyDefaultFormData());

          if (openFromCalender) {
            // dispatch(getAllActivity(currentFilterParams));
            calendarApiCalls(currentFilterParams, currentGoogleFilterParams);
          } else {
            dispatch(
              getAllActivity({
                attendee_id,
                pagination: true,
                sort_field: 'createdAt',
                sort_order: 'desc',
              })
            );
          }
          closeModal();
        }
      }
    });
  };

  // Create Payload
  const createPayload = (data: any) => {
    const attendees = data?.attendees?.map((item: any) => item._id);
    let payload: any = {
      title: data?.title,
      agenda: data?.agenda,
      meeting_date: moment(data?.meeting_date).format('DD-MM-YYYY'),
      meeting_end_time: moment.utc(data?.meeting_end_time).format('HH:mm'),
      meeting_start_time: moment.utc(data?.meeting_start_time).format('HH:mm'),
      attendees: attendees,
      internal_info: data?.internal_info ? data?.internal_info : null,
      alert_time: data?.alert_time ? Number(data?.alert_time) : null,
      alert_time_unit:
        selectedAlertTimeUnit?.value != ''
          ? selectedAlertTimeUnit?.value
          : null,
      all_day: data?.all_day,
      recurrence_pattern: data?.recurrence_pattern
        ? data?.recurrence_pattern
        : null,
      recurrence_end_date: data?.recurrence_end_date
        ? moment(data?.recurrence_end_date).format('DD-MM-YYYY')
        : null,
      recurrence_interval: data?.recurrence_interval
        ? Number(data?.recurrence_interval)
        : null,
    };

    if (data?.recurrence_pattern == 'weekly') {
      payload = {
        ...payload,
        weekly_recurrence_days: data?.weekly_recurrence_days,
      };
    }

    if (data?.recurrence_pattern == 'monthly') {
      payload = {
        ...payload,
        monthly_recurrence_day_of_month: data?.monthly_recurrence_day_of_month
          ? Number(data?.monthly_recurrence_day_of_month?.value)
          : '',
      };
    }

    if (!!data?.alert_time && selectedAlertTimeUnit?.value != '') {
      payload = {
        ...payload,
        alert_time: data?.alert_time ? Number(data?.alert_time) : null,
        alert_time_unit:
          selectedAlertTimeUnit?.value != ''
            ? selectedAlertTimeUnit?.value
            : null,
      };
    } else {
      payload = {
        ...payload,
        alert_time: '',
        alert_time_unit: '',
      };
    }

    return removeUnwantedKey(payload);
  };

  const removeUnwantedKey = (obj: any) => {
    for (const key in obj) {
      if (obj[key] === '') {
        delete obj[key];
      }
    }
    return obj;
  };

  // Google Meeting - Verification
  const googleLogin = useGoogleLogin({
    flow: 'auth-code',
    onSuccess: async (response: any) => {
      createMeetingWithGoogleMeetFn({
        ...googleMeetingForm,
        token: response?.code,
        google_meeting: true,
      });
    },

    onError: (errorResponse) => console.log(errorResponse),
    redirect_uri: process.env.NEXT_PUBLIC_FRONT_LINK,
    scope:
      'profile email https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.events.readonly', // Add scopes as needed
  });

  // Create Google Meeting During Update - Verification
  const googleLoginUpdate = useGoogleLogin({
    flow: 'auth-code',
    onSuccess: async (response: any) => {
      updateMeetingAPICall(
        {
          ...googleMeetingForm,
          token: response?.code,
          google_meeting: true,
        },
        googleMeetingForm?._id
      );
    },

    onError: (errorResponse) => console.log(errorResponse),
    redirect_uri: process.env.NEXT_PUBLIC_FRONT_LINK,
    scope:
      'profile email https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.events.readonly', // Add scopes as needed
  });

  // On Change Recurring
  const onChangeRecurring = (option: any, setValue: any) => {
    SetSelectedRecurringOption(option);
    if (option?.value !== '') {
      setValue('recurrence_pattern', option?.value);
    } else {
      setValue('recurrence_pattern', '');
    }
  };

  // Create Meeting With Google Meeting Link
  const createMeetingWithGoogleLink = async (data: any) => {
    const payload = createPayload(data);
    SetGoogleMeetingForm(payload);
    const google = googleAccounts.find(
      (account:any) => account.is_selected === true
    )
    google?.is_selected === true ?
    createMeetingWithGoogleMeetFn({
      ...payload,
      google_meeting: true,
    }) : 
    googleLogin();
  };

  // Create Meeting With Google Meeting Link During Update Meeting
  const createMeetingWithGoogleLinkDuringUpdate = async (data: any) => {
    const payload = createPayload(data);
    SetGoogleMeetingForm({
      ...payload,
      _id: meetingDataById?._id,
      google_meeting: true,
    });
    googleLoginUpdate();
  };

  // Reset Notification
  const resetNotification = (setValue: any, clearErrors: any) => {
    // SetSelectedAlertTimeUnit({ label: 'Select Time', value: '' });
    setValue('alert_time_unit', { label: '', value: '' });
    setValue('alert_time', '');
    clearErrors('alert_time');
  };

  // On Change - Time Unit Change
  const handleChangeTimeUnitChange = (
    event: any,
    setError?: any,
    clearErrors?: any
  ) => {
    SetSelectedAlertTimeUnit(event);
    if (event.value == 'min' && alertTimeValue > 60) {
      setError('alert_time', {
        type: 'custom',
        message: 'Minutes is between 1 and 60',
      });
    } else if (event.value == 'h' && alertTimeValue > 24) {
      setError('alert_time', {
        type: 'custom',
        message: 'Hour is between 1 and 24',
      });
    } else {
      clearErrors('alert_time');
    }
  };

  const handleCopyToClipboard = async (meetingLink: string) => {
    try {
      await window?.navigator?.clipboard?.writeText(meetingLink);
      toast.success('Meeting link copied to clipboard');
    } catch (error) {
      console.error('Error copying URL:', error);
    }
  };

  // All Day Handle Event
  const handleChangeAllDay = (event: any) => {
    if (event.target.checked) {
      setDisabledMeetingTime(true);
      setValueReference.current(
        'meeting_start_time',
        moment().startOf('day').toDate()
      );
      setValueReference.current(
        'meeting_end_time',
        moment().endOf('day').toDate()
      );
    } else {
      setDisabledMeetingTime(false);
    }
  };

  const startDateSelected = (event: any) => {
    const updatedEndDateAndTime = addOneHour(event);
    setValueReference.current(
      'meeting_end_time',
      new Date(updatedEndDateAndTime)
    );
  };

  // Add 1 Hour Span While Selecting the start date
  const addOneHour = (dateString: any) => {
    const date = moment(dateString);
    const elevenPM = moment(dateString).set({
      hour: 23,
      minute: 0,
      second: 0,
      millisecond: 0,
    });

    let newDate;
    if (date.isSameOrAfter(elevenPM)) {
      newDate = date.endOf('day'); // Set to end of the day
    } else {
      newDate = date.add(1, 'hour');
    }

    return newDate.toString();
  };

  const handleDeleteMeeting = (setOpen: any) => {
    const eventDate = row?.start
      ? moment(row?.start).format('YYYY-MM-DD')
      : null;

    let data = {
      meeting_id: row?._id,
      is_all_delete: meetingDataById?.recurrence_interval ? allMeeting : true,
      ...(eventDate && { meeting_date: eventDate }),
    };

    dispatch(deleteMeeting(data)).then(async (result: any) => {
      if (deleteMeeting.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          setOpen(false);
          closeModal();
          calendarApiCalls(currentFilterParams, currentGoogleFilterParams);
        }
      }
    });
  };

  // check in comment attachement if any invalide file exits or not
  const checkCommentAttachement = (data: any) => {
    setCommentAttachementInvalid(false);

    if (data?.length > 0) {
      const fileSize = Object.values(data)?.map((file: any) =>
        getFileSize(file)
      );
      const inValidFile = fileSize?.filter(
        (fileInfo) => fileInfo?.size && !checkValidFileSize(fileInfo, 200)
      );

      if (inValidFile?.length > 0) {
        setCommentAttachementInvalid(true);
      }
    }
  };
  const meetingDateChange = () => {
    setValueReference.current('meeting_start_time', null);
    setValueReference.current('meeting_end_time', null);
  };

  useEffect(() => {
    if (setFocusReference.current) {
      setTimeout(() => {
        setFocusReference.current('title');
      }, 100); // Small delay ensures React Quill doesn't override focus
    }
  }, []);

  if (getMeetingByIdLoading && !!row?._id) {
    return (
      <div className="mt-[14rem] flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <div className="space-y-3 p-8">
        <div className="mb-6 flex items-center justify-between">
          <Title as="h3" className="text-xl text-[#000000] xl:text-2xl">
            {title}
          </Title>

          <div className="flex items-center gap-6">
            {openFromCalender && isEdit && (
              <Popover
                placement="bottom"
                className="demo_test gap-2"
                content={({ setOpen }) => (
                  <>
                    {meetingDataById?.recurrence_interval ? (
                      <div className="flex w-64 flex-col gap-4 p-4">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Delete Meeting
                        </h3>
                        <div>
                          <Radio
                            label="This Meeting"
                            labelClassName="ml-2.5"
                            inputClassName="checked:!bg-[#8C80D2] checked:!border-[#8C80D2]"
                            checked={!allMeeting}
                            onChange={() => setAllMeeting(false)}
                          />
                        </div>

                        <div>
                          <Radio
                            label="All Recurring Meeting"
                            labelClassName="ml-2.5"
                            inputClassName="checked:!bg-[#8C80D2] checked:!border-[#8C80D2]"
                            checked={allMeeting}
                            onChange={() => setAllMeeting(true)}
                          />
                        </div>
                        <div className="flex items-center gap-4 ">
                          <Button
                            variant="text"
                            // className=" border"
                            // className="@xl:w-auto h-8 text-[#9BA1B9] dark:hover:border-gray-400"
                            className="h-8 rounded-lg border border-gray-300 px-4 py-1 text-gray-600 hover:border-gray-400"
                            onClick={() => setOpen(false)}
                          >
                            Cancel
                          </Button>

                          <Button
                            className="h-8 bg-[#8C80D2] text-white transition-colors duration-200 hover:!bg-[#7567BA] hover:!text-white @xl:w-auto dark:text-white"
                            // className=" border border-[#EC221F] text-[#EC221F] hover:!text-[#EC221F]"
                            variant="text"
                            onClick={() => handleDeleteMeeting(setOpen)}
                            disabled={deleteMeetingLoading}
                          >
                            Delete
                            {deleteMeetingLoading && (
                              <Spinner
                                size="sm"
                                tag="div"
                                className="ms-3"
                                color="white"
                              />
                            )}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="w-56 pb-2 pt-1 text-left rtl:text-right">
                        <Title
                          as="h6"
                          className="mb-0.5 flex items-start gap-2 text-sm text-gray-700 sm:items-center"
                        >
                          <MdDelete className="h-4 w-4" /> Delete the meeting
                        </Title>
                        <Text className="mb-2 leading-relaxed text-gray-500">
                          Are you sure you want to delete the meeting ?
                        </Text>
                        <div className="flex items-center justify-end">
                          <Button
                            size="sm"
                            className="me-1.5 h-7"
                            onClick={() => handleDeleteMeeting(setOpen)}
                          >
                            Yes
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7"
                            onClick={() => setOpen(false)}
                          >
                            No
                          </Button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              >
                <Button
                  variant="text"
                  className="flex h-8 items-center justify-center border border-[#EC221F] px-3 text-[#EC221F] hover:!text-[#EC221F]"
                >
                  Delete
                </Button>
              </Popover>
            )}

            <ActionIcon
              size="sm"
              variant="text"
              onClick={() => (closeModal(), dispatch(emptyDefaultFormData()))}
              className="p-0 text-[#000000]  hover:!text-gray-900"
            >
              <PiXBold className="h-[18px] w-[18px]" />
            </ActionIcon>
          </div>
        </div>
        <div></div>
        <Form
          validationSchema={meetingSchema}
          onSubmit={onSubmit}
          useFormProps={{
            mode: 'all',
            defaultValues: defaultValues,
          }}
        >
          {({
            register,
            setFocus,
            handleSubmit,
            control,
            watch,
            setValue,
            getValues,
            clearErrors,
            setError,
            formState: { errors },
          }) => (
            console.log(errors, 'errors'),
            (setValueReference.current = setValue),
            (getValuesReference.current = getValues),
            (setFocusReference.current = setFocus),
            (
              <div className="space-y-5">
                <SimpleBar className="max-h-[60vh] pe-4">
                  <div className="space-y-2">
                    <div className=" grid grid-cols-1 gap-1 ">
                      <label className="text-[#141414]">Add Title</label>
                      <Textarea
                        placeholder="Add title"
                        rows={2}
                        color="info"
                        className="poppins_font_number w-full  rounded-lg text-[#141414] lg:w-[100%] [&>label>span]:font-medium"
                        textareaClassName="bg-[#F9FAFB]"
                        {...register('title')}
                        onKeyDown={handleKeyDown}
                        error={errors?.title?.message as string}
                      />
                    </div>

                    <div className=" grid w-full grid-cols-1 gap-3  md:grid-cols-2">
                      {/* Meeting Date - Full Width */}
                      <div className="relative w-[100%]">
                        <label className="text-[#141414]">Date & Time</label>
                        <Controller
                          name="meeting_date"
                          control={control}
                          render={({ field: { value, onChange } }) => (
                            <DatePicker
                              className="mt-1 w-full rounded-lg bg-[#F9FAFB] font-medium"
                              placeholderText="Start date"
                              selected={value}
                              inputProps={{
                                prefix: (
                                  <MdOutlineCalendarToday className="h-4 w-4" />
                                ),
                                inputClassName: 'poppins_font_number',
                              }}
                              onChange={(e) => (
                                onChange(e),
                                setSelectedDate(e),
                                meetingDateChange()
                              )}
                              selectsStart
                              startDate={value}
                              minDate={new Date()}
                              dateFormat="MMMM dd, yyyy"
                            />
                          )}
                        />
                        <p className=" min-h-3 text-xs text-red">
                          {errors?.meeting_date?.message as string}
                        </p>
                      </div>

                      <div className="flex w-[100%] flex-row items-center  gap-4 md:mt-6 ">
                        <div className="flex items-center gap-4">
                          {/* Start Time */}
                          <div className="relative w-[50%] md:w-[35%]">
                            <Controller
                              name="meeting_start_time"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <DatePicker
                                  className="rounded-lg !bg-[#F9FAFB] "
                                  placeholderText="Start time"
                                  selected={value}
                                  inputProps={{
                                    prefix: <LuClock className="h-4 w-4" />,
                                    inputClassName:
                                      'poppins_font_number !bg-[#F9FAFB]',
                                  }}
                                  minTime={getMinTime()}
                                  maxTime={getMaxTime()}
                                  onChange={(event: any) => {
                                    onChange(event), startDateSelected(event);
                                  }}
                                  showTimeSelect
                                  showTimeSelectOnly
                                  dateFormat="hh:mm aa"
                                  disabled={disabledMeetingTime}
                                />
                              )}
                            />
                            <p className="mt-1 min-h-3 text-xs text-red">
                              {errors?.meeting_start_time?.message as string}
                            </p>
                          </div>

                          {/* "to" Text */}
                          <div className="pb-4">
                            <span>to</span>
                          </div>

                          {/* End Time */}
                          <div className="w-[50%] md:w-[35%] ">
                            <Controller
                              name="meeting_end_time"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <DatePicker
                                  className="rounded-lg bg-[#F9FAFB] "
                                  placeholderText="End time"
                                  selected={value}
                                  minTime={getMinTime()}
                                  maxTime={getMaxTime()}
                                  onChange={onChange}
                                  showTimeSelect
                                  showTimeSelectOnly
                                  dateFormat="hh:mm aa"
                                  disabled={disabledMeetingTime}
                                  inputProps={{
                                    prefix: <LuClock className="h-4 w-4" />,
                                    inputClassName:
                                      'poppins_font_number !bg-[#F9FAFB]',
                                  }}
                                />
                              )}
                            />
                            <p className="mt-1 min-h-3 text-xs text-red">
                              {errors?.meeting_end_time?.message as string}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-4 ps-1">
                      <div className="flex items-center justify-start gap-3 ">
                        <Checkbox
                          label="All day"
                          {...register('all_day')}
                          onChange={handleChangeAllDay}
                          inputClassName="checkbox-color"
                          className="me-6 text-[#585858]"
                          // text-[#9BA1B9]
                        />
                        <Select
                          className="metting_repeat_select_dropdown w-[165px] rounded-lg"
                          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                          value={selectedRecurringOption}
                          options={RecurringArray}
                          isSearchable={false}
                          // isClearable={false}
                          // optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                          onChange={(event) =>
                            onChangeRecurring(event, setValue)
                          }
                          styles={customStyles}
                          // selectClassName="!text-[#5850EC] border-[#5850EC] poppins_font_number focus:border-[#5850EC] hover:border-[#5850EC] !bg-white"
                        />
                      </div>
                    </div>
                    <div className="grid w-[100%] grid-cols-1 items-center gap-3 md:grid-cols-2 lg:grid-cols-3">
                      {['daily', 'weekly', 'monthly'].includes(
                        selectedRecurringOption?.value
                      ) && (
                        <>
                          <div className="flex flex-col gap-2">
                            <span className=" text-[14px] font-medium text-[#141414]">
                              Repeat every
                            </span>
                            <Input
                              rounded="DEFAULT"
                              type="number"
                              min={0}
                              label={''}
                              color="info"
                              className="poppins_font_number rounded-lg border-gray-300 bg-[#F9FAFB] text-[#141414] focus:border-primary focus:ring-primary"
                              placeholder=""
                              {...register('recurrence_interval')}
                              onChange={handleKeyDown}
                              // onWheel={(e) => e.target.blur()}
                              onFocus={(e) =>
                                e.target.addEventListener(
                                  'wheel',
                                  function (e) {
                                    e.preventDefault();
                                  },
                                  { passive: false }
                                )
                              }
                              // error={errors?.recurrence_interval?.message as string}
                            />
                            <p className=" min-h-3 text-xs text-red">
                              {errors?.recurrence_interval?.message as string}
                            </p>
                          </div>

                          {/* Radion Button for day select */}
                          {selectedRecurringOption?.value == 'weekly' && (
                            <div className="flex flex-col">
                              <div className=" grid-col grid  w-[100%] gap-2">
                                <span className=" text-[14px] font-medium text-[#141414]">
                                  Days of the week
                                </span>
                                <div className=" flex  gap-2">
                                  {weekdays?.map((day: any) => (
                                    <label
                                      key={day?.value}
                                      className={`flex h-7 w-7 cursor-pointer items-center justify-center rounded-full border text-center text-[13px] font-medium ${
                                        watch('weekly_recurrence_days') ===
                                        day?.value
                                          ? ' border-[#EDEBFE] bg-[#EDEBFE] text-[#42389D]'
                                          : 'border-gray-300 bg-white'
                                      }`}
                                    >
                                      <Radio
                                        {...register('weekly_recurrence_days')}
                                        value={day?.value}
                                        className="hidden" // Hides default appearance but keeps functionality
                                      />
                                      {day?.name}
                                    </label>
                                  ))}
                                </div>
                              </div>

                              <p className="mt-1  min-h-3 text-xs text-red">
                                {
                                  errors?.weekly_recurrence_days
                                    ?.message as string
                                }
                              </p>
                            </div>
                          )}
                          {selectedRecurringOption?.value == 'monthly' && (
                            <>
                              <div className="flex flex-col">
                                <label className="mb-1 text-[14px] font-medium text-[#141414]">
                                  Repeat on
                                </label>
                                <Controller
                                  name="monthly_recurrence_day_of_month"
                                  control={control}
                                  render={({ field: { onChange, value } }) => (
                                    <Select
                                      options={monthDate}
                                      onChange={onChange}
                                      value={value}
                                      placeholder="Select Day"
                                      className="metting_attendee_repeat_monthly_select_dropdown w-full"
                                      classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                                      // getOptionValue={(option) => option?.value}
                                      // getOptionLabel={(option) => option?.label}
                                      // styles={customStyles}
                                      // optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                      // selectClassName="!text-[#111928] border-[#E5E7EB]  poppins_font_number bg-[#F9FAFB]"
                                      // disabled={isDisable}
                                    />
                                  )}
                                />
                                <p className="mt-1 min-h-3 text-xs text-red">
                                  {
                                    errors?.monthly_recurrence_day_of_month
                                      ?.message as string
                                  }
                                </p>
                              </div>
                            </>
                          )}

                          {/* Controller End Date */}

                          <div className="flex flex-col gap-2 ">
                            <span className=" text-[14px] font-medium text-[#141414]">
                              End date
                            </span>
                            <Controller
                              name="recurrence_end_date"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <DatePicker
                                  placeholderText="Recurring end date"
                                  selected={value}
                                  // inputProps={{
                                  //   error: errors?.recurrence_end_date
                                  //     ?.message as string,
                                  // }}
                                  onChange={onChange}
                                  selectsStart
                                  startDate={value}
                                  minDate={new Date()}
                                  dateFormat="MMMM dd, yyyy"
                                  className="rounded-lg border-gray-300 bg-[#F9FAFB]  focus:border-primary focus:ring-primary"
                                />
                              )}
                            />
                            <p className=" min-h-3 text-xs text-red">
                              {errors?.recurrence_end_date?.message as string}
                            </p>
                          </div>
                        </>
                      )}
                    </div>
                    {/* <div className=" items-start justify-between lg:flex-row "> */}
                    <div className="me-0 w-full lg:me-6 lg:w-[100%]">
                      {/* Event */}
                      <div>
                        {/* <p className="border-b-[2px] border-[#E3E1F4] text-xl font-bold text-[#8C80D2]">
                        Event details
                         </p> */}

                        {meetingDataById?.google_meeting_data?.meet_link &&
                          isEdit && (
                            <>
                              <div className="mt-0 flex items-center justify-between">
                                <Button
                                  onClick={() =>
                                    window.open(
                                      meetingDataById?.google_meeting_data
                                        ?.meet_link,
                                      '_blank'
                                    )
                                  }
                                  className="flex items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[12px]
                                 font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[240px] lg:text-[16px]"
                                >
                                  Join with Google Meet
                                </Button>
                                <MdContentCopy
                                  className="h-6 w-6 text-[#8C80D2] "
                                  onClick={() =>
                                    handleCopyToClipboard(
                                      meetingDataById?.google_meeting_data
                                        ?.meet_link
                                    )
                                  }
                                />
                              </div>
                              <div className="my-3 ps-1">
                                <p>
                                  {
                                    meetingDataById?.google_meeting_data
                                      ?.meet_link
                                  }
                                </p>
                              </div>
                            </>
                          )}
                      </div>

                      {/* Location */}
                      <div className=" flex items-center">
                        {/* <SlLocationPin className="h-6 w-6 text-[#8C80D2]" /> */}

                        <Input
                          type="text"
                          onKeyDown={handleKeyDown}
                          placeholder="Add location"
                          color="info"
                          className="w-full rounded-lg bg-[#F9FAFB] lg:w-[100%] [&>label>span]:font-medium"
                          {...register('internal_info')}
                          error={errors?.internal_info?.message as string}
                          inputClassName="poppins_font_number"
                          prefix={<MdLocationPin className="h-6 w-6" />}
                        />
                      </div>

                      {/* Add Attendees */}

                      <div className="mt-5 ">
                        <Controller
                          name="attendees"
                          control={control}
                          render={({ field: { onChange, value } }) => (
                            // <Select
                            //   className="react-select-meeting"
                            //   value={value}
                            //   options={attendeesUserList ?? []}
                            //   isClearable={false}
                            //   onChange={onChange}
                            //   isMulti
                            //   closeMenuOnSelect={false}
                            //   hideSelectedOptions={false}
                            //   styles={customStyles}
                            //   getOptionLabel={(option) => option?.label}
                            //   getOptionValue={(option) => option?._id}
                            // />
                            // <ReactSelect
                            //   className="metting_attendee_select_dropdown "
                            //   placeholder={<div className=" ps-2 flex items-center gap-3 font-medium ">
                            //     <GoPeople className='h-4 w-4 ' />
                            //     Add Attendee
                            //   </div>}
                            //   // value={value}
                            //   value={value.map((option: any) => ({
                            //     ...option,
                            //     isInvalid:
                            //       option?._id?.startsWith('mail:') &&
                            //       !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                            //         option._id.slice(5)
                            //       ),
                            //   }))}
                            //   options={attendeesUserList ?? []}
                            //   isClearable={false}
                            //   onChange={onChange}
                            //   isMulti
                            //   closeMenuOnSelect={false}
                            //   hideSelectedOptions={false}
                            //   styles={customStyles}
                            //   getOptionLabel={(option: any) => option?.label}
                            //   getOptionValue={(option: any) => option?._id}
                            //   // Function to handle creation of new options
                            //   onCreateOption={(inputValue: any) => {
                            //     const newOption = {
                            //       _id: `mail:${inputValue}`,
                            //       label: inputValue,
                            //     };
                            //     onChange([...value, newOption]);
                            //     dispatch(addCustomAttendess(newOption));
                            //   }}
                            // />
                            <div>
                              <ReactSelect
                                className="metting_attendee_select_dropdown ps-[1.8px] "
                                classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                                placeholder={
                                  <div className="flex items-center gap-3 ps-2 font-medium">
                                    <GoPeople className="popins_font_number h-4 w-4 font-medium" />
                                    Add Attendee
                                  </div>
                                }
                                value={value.map((option: { _id: string }) => ({
                                  ...option,
                                  isInvalid:
                                    option?._id?.startsWith('mail:') &&
                                    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                                      option._id.slice(5)
                                    ),
                                }))}
                                options={attendeesUserList ?? []}
                                isClearable={false}
                                onChange={onChange}
                                isMulti
                                closeMenuOnSelect={false}
                                hideSelectedOptions={false}
                                styles={{
                                  control: (provided) => ({
                                    ...provided,
                                    minHeight: '50px',
                                    borderRadius: '10px',
                                    padding: '5px',
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                  }),
                                }}
                                getOptionLabel={(option) => option.label}
                                getOptionValue={(option) => option._id}
                                onCreateOption={(inputValue) => {
                                  const newOption = {
                                    _id: `mail:${inputValue}`,
                                    label: inputValue,
                                  };
                                  onChange([...value, newOption]);
                                }}
                              />
                              {value?.length > 0 && (
                                <SimpleBar className="mt-3 max-h-[171px] rounded-lg border-[1px] bg-gray-50 px-2">
                                  {value.map(
                                    (
                                      member: {
                                        _id: Key | null | undefined;
                                        profile_image: any;
                                        first_name: any;
                                        last_name: any;
                                        label:
                                          | string
                                          | number
                                          | bigint
                                          | boolean
                                          | ReactElement<
                                              any,
                                              | string
                                              | JSXElementConstructor<any>
                                            >
                                          | Iterable<ReactNode>
                                          | Promise<AwaitedReactNode>
                                          | null
                                          | undefined;
                                      },
                                      index: number
                                    ) => (
                                      <div
                                        key={member._id}
                                        className={`flex items-center justify-between px-3 py-2 text-[#141414] ${
                                          value.length - 1 !== index
                                            ? 'border-b-[1px]'
                                            : ''
                                        }`}
                                      >
                                        <div className="flex items-center gap-3">
                                          <Avatar
                                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                            className="h-[28px] w-[28px] rounded-full object-cover text-white"
                                            name={`${capitalizeFirstLetter(
                                              member?.first_name
                                            )} ${capitalizeFirstLetter(
                                              member?.last_name
                                            )}`}
                                          />
                                          <span className="text-[14px] font-semibold">
                                            {member.label}
                                          </span>
                                        </div>
                                        <RxCross2
                                          className="h-[20px] w-[20px] cursor-pointer text-black"
                                          onClick={() =>
                                            onChange(
                                              value.filter(
                                                (m: {
                                                  _id: Key | null | undefined;
                                                }) => m._id !== member._id
                                              )
                                            )
                                          }
                                        />
                                      </div>
                                    )
                                  )}
                                </SimpleBar>
                              )}
                            </div>
                          )}
                        />
                        <p className="mt-0.5 min-h-3 text-xs text-red">
                          {errors?.attendees?.message as string}
                        </p>
                      </div>

                      <hr className="my-5 border-t border-[#D1D5DB]" />

                      {/*Description */}
                      <label>Description</label>
                      <div className="mt-2 ">
                        <Controller
                          control={control}
                          name="agenda"
                          render={({ field: { onChange, value } }) => (
                            <QuillEditor
                              value={value}
                              onChange={onChange}
                              onKeyDown={handleKeyDown}
                              placeholder="Add description"
                              label=""
                              className="quill-editor-font poppins_font_number col-span-full rounded-lg bg-[#F9FAFB] text-black  [&_.ql-editor]:min-h-[100px]"
                              labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                            />
                          )}
                        />
                      </div>
                      {/* Attachment */}

                      <div className="mt-4">
                        <div className="flex flex-wrap gap-4">
                          <div
                            className="flex items-center"
                            {...getRootProps()}
                          >
                            <input
                              {...getInputProps()}
                              ref={commentAttachmentRef}
                            />
                            <Button
                              size="lg"
                              className="h-10 items-center gap-2 whitespace-nowrap rounded-lg border border-[#6875F5] bg-transparent p-3 text-[#6875F5] marker:flex"
                              onClick={() =>
                                commentAttachmentRef?.current?.click()
                              }
                              // disabled={isDisable}
                            >
                              <ImAttachment className="h-4 w-4 text-[#6875F5]" />
                              <span className="text-sm"> Attachments</span>
                            </Button>
                          </div>
                          {previewImage &&
                            previewImage != null &&
                            previewImage?.length > 0 &&
                            previewImage?.map((image: any, index: number) => {
                              const fileType = getFileType(image?.name);
                              const color = getColor(fileType);
                              return (
                                <div
                                  className={`flex max-h-10 items-center gap-1 rounded-full p-2`}
                                  style={{
                                    backgroundColor: color?.bgColor,
                                    color: color?.textColor,
                                  }}
                                  key={index}
                                >
                                  <CustomFileIcons
                                    iconClassName="!w-5 !h-4"
                                    key={index}
                                    fileType={fileType}
                                  />
                                  <p className="max-w-[200px] truncate !font-sans text-[14px]">
                                    {image?.name}
                                  </p>
                                  {/* {!isDisable && ( */}
                                  <RxCross2
                                    className="h-4 w-4 cursor-pointer"
                                    onClick={() => {
                                      // filter out removed file from preview image state
                                      const updatedFiles =
                                        previewImage?.length > 0 &&
                                        previewImage?.filter((file: any) => {
                                          if (
                                            file?.preview !== image?.preview
                                          ) {
                                            return file;
                                          }
                                        });
                                      checkCommentAttachement(updatedFiles);
                                      setPreviewImage(updatedFiles);
                                      setValue('attachments', updatedFiles, {
                                        shouldValidate: true,
                                      });
                                    }}
                                  />
                                  {/* )} */}
                                </div>
                              );
                            })}
                        </div>
                        {commentAttachementInvalid && (
                          <p className="pt-1 text-red">
                            {messages.taskAttachementMaxFileSize}
                          </p>
                        )}
                      </div>

                      {/* Notification */}
                      <div className="mt-4 flex flex-col items-start  gap-3 pb-4  sm:flex-row sm:items-center">
                        <div className="flex flex-row items-center justify-between">
                          {/* <GrNotification className="h-6 w-6 text-[#8C80D2]" /> */}
                          <span className=" text-sm text-[#111928]">
                            Notify before
                          </span>
                        </div>
                        <div className="flex flex-row items-center gap-5 ">
                          <div className=" relative w-[30%]">
                            <div>
                              <Input
                                rounded="DEFAULT"
                                type="number"
                                min={0}
                                placeholder=""
                                color="info"
                                className=" rounded-lg border border-[#E5E7EB] [&>label>span]:border-none [&>label>span]:bg-[#F9FAFB] [&>label>span]:font-medium"
                                {...register('alert_time')}
                                onChange={(e) =>
                                  setAlertTimeValue(e.target.value)
                                }
                                inputClassName="poppins_font_number"
                              />
                            </div>
                            <div>
                              <p className="absolute mt-0.5 text-xs text-red">
                                {errors?.alert_time?.message as string}
                              </p>
                            </div>
                          </div>
                          <div className="w-[120px]">
                            <Controller
                              name=""
                              control={control}
                              render={({ field: { onChange, value } }) => (
                                <Select
                                  placeholder="Time"
                                  isSearchable={false}
                                  options={notificationType}
                                  value={selectedAlertTimeUnit}
                                  onChange={(e) =>
                                    handleChangeTimeUnitChange(
                                      e,
                                      setError,
                                      clearErrors
                                    )
                                  }
                                  getOptionValue={(option) => option?.value}
                                  getOptionLabel={(option) => option?.label}
                                  styles={customStyles}
                                  className="react-select-meeting rounded-lg border  border-[#E5E7EB]"
                                  classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                                />
                              )}
                            />
                          </div>
                          <div
                            className="flex cursor-pointer flex-row items-center justify-between"
                            onClick={() =>
                              resetNotification(setValue, clearErrors)
                            }
                          >
                            <PiXBold className=" h-[18px] w-[18px]" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </SimpleBar>

                {/* </div> */}

                <div className="w-[100%] pe-3">
                  {/* Create Button */}
                  {!isEdit && (
                    <>
                      <div className="grid grid-cols-1 items-center  gap-[15px] md:grid-cols-2">
                        <Button
                          type="submit"
                          className="w-[100%] items-center justify-center rounded-lg border-[#7667CF] bg-[#ffffff] px-6 py-4 text-[14px] font-semibold text-[#8C80D2] "
                          disabled={
                            createMeetingLoading ||
                            createMeetingWithGoogleMeetLoading
                          }
                          size="xl"
                        >
                          Create as Event
                          {createMeetingLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>

                        <Button
                          type="submit"
                          disabled={
                            createMeetingWithGoogleMeetLoading ||
                            createMeetingLoading
                          }
                          onClick={handleSubmit(createMeetingWithGoogleLink)}
                          className="flex  w-[100%] items-center justify-center rounded-lg bg-[#7667CF] px-6 py-4 text-[14px] font-semibold text-[#fff] hover:border-2 "
                          size="xl"
                        >
                          Create Meeting
                          {createMeetingWithGoogleMeetLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </>
                  )}

                  {/* Update Button */}
                  {isEdit && (
                    <>
                      <Button
                        type="submit"
                        className="flex w-[100%] items-center justify-center rounded-lg bg-[#7667CF] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                        disabled={
                          updateMeetingLoading ||
                          createMeetingWithGoogleMeetLoading
                        }
                        size="xl"
                      >
                        {!meetingDataById?.google_meeting_data?.meet_link
                          ? 'Save Changes'
                          : 'Update Meeting'}
                        {updateMeetingLoading && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>

                      {/* {!meetingDataById?.google_meeting_data?.meet_link && (
                        <Button
                          type="submit"
                          disabled={
                            createMeetingWithGoogleMeetLoading ||
                            updateMeetingLoading
                          }
                          onClick={handleSubmit(
                            createMeetingWithGoogleLinkDuringUpdate
                          )}
                          className="ml-4 flex  items-center justify-center rounded-lg bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] w-[50%]"
                          size="xl"
                        >
                          Create Meeting
                          {createMeetingWithGoogleMeetLoading && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      )} */}
                    </>
                  )}
                </div>
              </div>
            )
          )}
        </Form>
      </div>
    );
  }
};
