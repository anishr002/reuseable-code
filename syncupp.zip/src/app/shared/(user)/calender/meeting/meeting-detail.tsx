import { CustomFileIcons } from '@/app/shared/custom-file-icon';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Text, Title } from '@/components/ui/text';
import { getMeetingById } from '@/redux/slices/user/meeting/meetingSlice';
import { capitalizeFirstLetter, getColor, getFileType } from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { MdContentCopy } from 'react-icons/md';
import { PiCaretDownBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';
import SimpleBar from 'simplebar-react';

const statusOptions = [
  {
    value: 'pending',
    name: 'Pending',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="warning" renderAsDot />
        <Text className="font-medium text-orange-dark">Pending</Text>
      </div>
    ),
  },
  {
    value: 'in_progress',
    name: 'In Progress',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="secondary" renderAsDot />
        <Text className="font-medium text-secondary-dark">In Progress</Text>
      </div>
    ),
  },
  {
    value: 'completed',
    name: 'Completed',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="success" renderAsDot />
        <Text className="font-medium text-green-dark">Completed</Text>
      </div>
    ),
  },
  {
    value: 'cancel',
    name: 'Cancel',
    label: (
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        <Badge color="danger" renderAsDot />
        <Text className="font-medium text-red-dark">Cancel</Text>
      </div>
    ),
  },
];

export const MeetingDetail = (props: any) => {
  const { row } = props;
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const [selectedStatus, setSelectedStatus] = useState<any>(null);

  const { meetingDataById, getMeetingByIdLoading } = useSelector(
    (state: any) => state?.root?.meeting
  );

  useEffect(() => {
    dispatch(getMeetingById(row?._id));
  }, []);

  useEffect(() => {
    if (meetingDataById) {
      const status = statusOptions?.find(
        (data: any) => data?.value == meetingDataById?.status
      );
      setSelectedStatus(status);
    }
  }, [meetingDataById]);

  const handleCopyToClipboard = async (meetingLink: string) => {
    try {
      await window?.navigator?.clipboard?.writeText(meetingLink);
      toast.success('Meeting link copied to clipboard');
    } catch (error) {
      console.error('Error copying URL:', error);
    }
  };

  console.log(meetingDataById, 'meetingDataById');

  if (getMeetingByIdLoading && row?._id) {
    return (
      <div className="mt-[14rem] flex items-center justify-center px-8 py-4">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <>
        <div className="space-y-5  p-8 ">
          <div className="mb-8 flex items-center justify-between pe-2">
            <Title
              as="h3"
              className="break-all text-xl text-[#141414] xl:text-2xl"
            >
              {/* {capitalizeFirstLetter(meetingDataById?.title)} */}
              Meeting Details
            </Title>
            <ActionIcon
              size="sm"
              variant="text"
              onClick={() => closeModal()}
              className="ml-4 p-0 text-[#141414] hover:!text-gray-900"
            >
              <PiXBold className="h-[18px] w-[18px]" />
            </ActionIcon>
          </div>
          <SimpleBar className="max-h-[60vh] pe-4">
            <div className="space-y-5">
              <div className="flex justify-between ">
                <p className="text-center text-[16px]  text-[#111928]">Title</p>
                <p className=" text-center text-[16px] font-semibold  text-[#111928]">
                  {capitalizeFirstLetter(meetingDataById?.title)}
                </p>
              </div>

              <div className="flex justify-between">
                <p className="text-center text-[16px] text-[#111928]">Date</p>
                <p className="poppins_font_number  text-center font-medium text-[#111928]">
                  {moment(meetingDataById?.meeting_date).format('DD-MM-YYYY')}
                </p>
              </div>
              <div className="flex justify-between">
                <p className="text-center text-[16px] text-[#111928]">Time</p>
                <p className="poppins_font_number text-center text-[16px] font-medium text-[#111928]">
                  {meetingDataById?.all_day ? (
                    'All Day'
                  ) : (
                    <>
                      {moment(meetingDataById?.meeting_start_time).format(
                        'HH:mm'
                      )}{' '}
                      -{' '}
                      {moment(meetingDataById?.meeting_end_time).format(
                        'HH:mm'
                      )}
                    </>
                  )}
                </p>
              </div>
              <div className="flex justify-between">
                <p className="text-left text-[16px] text-[#111928]">Location</p>
                <p className="text-right text-[16px] font-medium text-[#111928]">
                  {meetingDataById?.internal_info
                    ? meetingDataById?.internal_info
                    : '-'}
                </p>
              </div>

              <div className="flex justify-between">
                <p className="text-center text-[#111928]">Status</p>
                <p className="text-center text-[16px]  font-medium text-[#111928]">
                  {selectedStatus?.label}
                </p>
              </div>

              {meetingDataById?.google_meeting_data?.meet_link && (
                <div className="flex justify-between">
                  <p className="text-[#111928] ">Google Meeting Link</p>
                  <p className="text-right text-[16px] font-medium text-[#111928]">
                    <div className="flex items-center">
                      <span className="me-4 ">
                        {meetingDataById?.google_meeting_data?.meet_link}
                      </span>
                      <MdContentCopy
                        className="cursor-pointer"
                        size={16}
                        onClick={() =>
                          handleCopyToClipboard(
                            meetingDataById?.google_meeting_data?.meet_link
                          )
                        }
                      />
                    </div>
                  </p>
                </div>
              )}

              {meetingDataById?.recurrence_pattern && (
                <div className="flex justify-between">
                  <p className="text-center text-[#111928]">Recurring Every</p>
                  <p className="text-center text-[16px] font-medium text-[#111928]">
                    <span className="poppins_font_number">
                      {meetingDataById?.recurrence_interval}{' '}
                    </span>
                    {meetingDataById?.recurrence_pattern == 'daily' && 'Day'}{' '}
                    {meetingDataById?.recurrence_pattern == 'weekly' && 'Week'}{' '}
                    {meetingDataById?.recurrence_pattern == 'monthly' &&
                      'Month'}
                  </p>
                </div>
              )}
              {meetingDataById.recurrence_pattern && (
                <div className="flex justify-between">
                  <p className="text-center text-[#111928]">Recurring Type</p>
                  <p className="text-center text-[16px] font-medium text-[#111928]">
                    {capitalizeFirstLetter(meetingDataById?.recurrence_pattern)}
                  </p>
                </div>
              )}
              {meetingDataById.weekly_recurrence_days &&
                meetingDataById?.recurrence_pattern == 'weekly' && (
                  <div className="flex justify-between">
                    <p className="text-center text-[#111928]">Recurring Day</p>
                    <p className="text-center text-[16px] font-medium text-[#111928]">
                      {capitalizeFirstLetter(
                        meetingDataById?.weekly_recurrence_days
                      )}
                    </p>
                  </div>
                )}
              {meetingDataById.monthly_recurrence_day_of_month > 0 &&
                meetingDataById?.recurrence_pattern == 'monthly' && (
                  <div className="flex justify-between">
                    <p className="text-center text-[#111928]">
                      Recurring Month Day
                    </p>
                    <p className="text-center text-[16px] font-medium text-[#111928]">
                      {meetingDataById?.monthly_recurrence_day_of_month}
                    </p>
                  </div>
                )}
              {meetingDataById.recurrence_end_date && (
                <div className="flex justify-between">
                  <p className="text-center text-[#111928]">
                    Recurring End Date
                  </p>
                  <p className="poppins_font_number text-center text-[16px] font-medium text-[#111928]">
                    {moment(meetingDataById?.recurrence_end_date).format(
                      'DD-MM-YYYY'
                    )}
                  </p>
                </div>
              )}
              <div className="flex flex-col items-center divide-y rounded-lg border border-[#E5E7EB] py-2">
                {meetingDataById?.attendees?.length == 0 ? (
                  <span className="font-medium text-gray-1000">N/A</span>
                ) : (
                  meetingDataById?.attendees?.map((data: any) => {
                    return (
                      <div
                        key={data?._id}
                        className="relative flex w-[100%] items-center gap-4 text-sm focus-visible:bg-gray-100 "
                      >
                        <span className="inline-flex items-center justify-center px-4 py-2 text-gray-500 ">
                          <Avatar
                            src={
                              data?.profile_image &&
                              `${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${data?.profile_image}`
                            }
                            name={
                              !data?.customAttendee
                                ? capitalizeFirstLetter(data?.first_name) +
                                  ' ' +
                                  capitalizeFirstLetter(data?.last_name)
                                : capitalizeFirstLetter(data?.name)
                            }
                            className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white xl:!h-11 xl:!w-11"
                          />
                        </span>

                        <span className="grid gap-0.5">
                          <span className="text-[16px] font-medium text-[#120425]">
                            {!data?.customAttendee
                              ? capitalizeFirstLetter(data?.first_name) +
                                ' ' +
                                capitalizeFirstLetter(data?.last_name)
                              : data?.name}
                          </span>
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="">
                <p className="my-2 text-start text-[#111928]">Description</p>
                <div className="rounded-lg bg-[#F9FAFB] p-3">
                  {' '}
                  {meetingDataById?.agenda &&
                  meetingDataById?.agenda !== '<p><br></p>' &&
                  meetingDataById?.agenda !== 'undefined' ? (
                    <div className="p-1 [&_.simplebar-content:after]:content-none [&_.simplebar-content:before]:content-none">
                      <SimpleBar className="max-h-[100px] w-full p-0">
                        <div
                          className="font-medium "
                          dangerouslySetInnerHTML={{
                            __html: meetingDataById?.agenda,
                          }}
                        ></div>
                      </SimpleBar>
                    </div>
                  ) : (
                    <span className="text-[16px] font-medium capitalize text-[#120425]">
                      N/A
                    </span>
                  )}
                </div>
              </div>

              <div className='flex flex-wrap gap-4'>
                {meetingDataById &&
                  meetingDataById != null &&
                  meetingDataById?.attachments?.length > 0 &&
                  meetingDataById?.attachments?.map((image: any, index: number) => {
                    const fileType = getFileType(image?.name);
                    const color = getColor(fileType);
                    return (
                      <a
                        className={`flex max-h-10 items-center gap-1 rounded-full p-2`}
                        style={{
                          backgroundColor: color?.bgColor,
                          color: color?.textColor,
                        }}
                        key={index}
                        href={`${process.env.NEXT_PUBLIC_API}/${image?.preview}`} target="_blank" rel="noopener noreferrer"
                      >
                        <CustomFileIcons
                          iconClassName="!w-5 !h-4"
                          key={index}
                          fileType={fileType}
                        />
                        <p className="max-w-[200px] truncate !font-sans text-[14px]">
                          {image?.name}
                        </p>
                      </a>
                    );
                  })}
              </div>
            </div>
          </SimpleBar>
          <div className="grid grid-flow-col gap-4 pe-4">
            <Button
              type="button"
              onClick={() => closeModal()}
              className="w-[100%] items-center justify-center rounded-lg border-[#E5E7EB] bg-[#ffffff] px-6 py-4 text-[14px] font-medium text-[#111928]"
            >
              Close
            </Button>
            {meetingDataById?.google_meeting_data?.meet_link && (
              <Button
                type="submit"
                onClick={() =>
                  window.open(
                    meetingDataById?.google_meeting_data?.meet_link,
                    '_blank'
                  )
                }
                className="flex  w-[100%] items-center justify-center rounded-lg bg-[#7667CF] px-6 py-4 text-[14px] font-medium text-[#fff] hover:border-2 "
              >
                Join Now
              </Button>
            )}
          </div>
        </div>
      </>
    );
  }
};
