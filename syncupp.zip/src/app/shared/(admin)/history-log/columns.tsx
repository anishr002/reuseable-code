'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const GetColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {

  return [
    {
      title: (
        <HeaderCell
          title="Admin Name"
        />
      ),
      dataIndex: 'full_name',
      key: 'full_name',
      width: 150,
      render: (value: string, row: any) => {
        return (
          <Text className="font-medium capitalize text-gray-700">{row?.user?.full_name}</Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Email"
        />
      ),
      dataIndex: 'email',
      key: 'email',
      width: 100,
      render: (value: string, row: any) => (
        <Text className="font-medium text-gray-700">{row?.user?.email}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Action"
        />
      ),
      dataIndex: 'action',
      key: 'action',
      width: 300,
      render: (value: any, row: any) => (
        <Text className="font-medium text-gray-700">{row?.action_message}</Text>
      ),
    },
  ];
};
