import React, { useEffect } from 'react';
import Spinner from '@/components/ui/spinner';
import { Input } from '@/components/ui/input';
import Select from '@/components/ui/select';
import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { Form } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { handleKeyDown } from '@/utils/common-functions';
import { routes } from '@/config/routes';
import cn from '@/utils/class-names';
import { Controller } from 'react-hook-form';
import { createAdminForm } from '@/utils/validators/create-admin.schema';
import { useParams, useRouter } from 'next/navigation';
import { getRolesList } from '@/redux/slices/admin/roles-permissions/rolePermissionSlice';
import {
  createAdmin,
  editAdmin,
  getAdminById,
} from '@/redux/slices/admin/admin-management/adminSlice';

const statusOption = [
  {label: "Active" , value: true},
  {label: "Inactive" , value: false}
]

const CreateAdmin = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const router = useRouter();
  const { getRolesListData } = useSelector(
    (state: any) => state?.root?.adminRole
  );
  const { createAdminLoader, editAdminLoader, getAdminByIdData, getAdminByIdLoader } = useSelector(
    (state: any) => state?.root?.adminUser
  );
  const initialValue = {
    first_name: '',
    last_name: '',
    email: '',
    role: '',
    contact_number : '',
    is_active: true,
  };

  const editInitialValue = {
    first_name: getAdminByIdData?.first_name,
    last_name: getAdminByIdData?.last_name,
    email: getAdminByIdData?.email,
    role: getAdminByIdData?.role?._id,
    is_active: getAdminByIdData?.is_active,
    contact_number: getAdminByIdData?.contact_number
  };

  const roleOption = getRolesListData?.map((item: any) => ({
    label: item?.sub_role,
    value: item?._id,
  }));

  useEffect(() => {
    dispatch(getRolesList());
  }, [dispatch]);

  useEffect(() => {
    if (id) {
      dispatch(getAdminById(id));
    }
  }, [id, dispatch]);

  const onSubmit = (data: any) => {
    if (id) {
      dispatch(editAdmin({ ...data, _id: id })).then((result: any) => {
        if (editAdmin.fulfilled.match(result)) {
          if (result.payload.success === true) {
            router.replace(routes.admin.adminManagement);
          }
        }
      });
    } else {
      dispatch(createAdmin(data)).then((result: any) => {
        if (createAdmin.fulfilled.match(result)) {
          if (result.payload.success === true) {
            router.replace(routes.admin.adminManagement);
          }
        }
      });
    }
  };

  if (getAdminByIdLoader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <div>
      <Form
        validationSchema={createAdminForm}
        onSubmit={onSubmit}
        //   resetValues={reset}
        useFormProps={{
          mode: 'all',
          defaultValues: id ? editInitialValue : initialValue,
        }}
        className="placeholder_color [&_label]:font-medium"
      >
        {({ register, control, formState: { errors } }) => (
          <div className="poppins_font_number space-y-5">
            <div
              className={cn(
                'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
              )}
            >
              <div>
                <label className="poppins_font_number text-[14px] font-semibold">
                  First Name *
                </label>

                <Input
                  type="text"
                  onKeyDown={handleKeyDown}
                  color="info"
                  placeholder="Enter First Name"
                  {...register('first_name')}
                  error={errors?.first_name?.message as string}
                />
              </div>

              <div>
                <label className="poppins_font_number text-[14px] font-semibold">
                  Last Name *
                </label>

                <Input
                  type="text"
                  onKeyDown={handleKeyDown}
                  color="info"
                  placeholder="Enter Last Name"
                  {...register('last_name')}
                  error={errors?.last_name?.message as string}
                />
              </div>

              <div>
                <label className="poppins_font_number text-[14px] font-semibold">
                  Email Address *
                </label>
                <Input
                  type="email"
                  onKeyDown={handleKeyDown}
                  color="info"
                  placeholder="Enter Your Email"
                  {...register('email')}
                  error={errors?.email?.message as string}
                  disabled={id ? true : false}
                />
              </div>
              <div>
                <label className="poppins_font_number text-[14px] font-semibold">
                  Role *
                </label>
                <Controller
                  name="role"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <Select
                      options={roleOption}
                      value={roleOption?.find(
                        (option: any) => option.value === value
                      )}
                      onChange={(e: any) => onChange(e.value)}
                      placeholder="Select Role"
                      error={errors?.role?.message as string}
                      className="rounded-xl"
                      optionClassName="capitalize poppins_font_number"
                      selectClassName="capitalize poppins_font_number"
                    />
                  )}
                />
              </div>

              {id && <div>
                <label className="poppins_font_number text-[14px] font-semibold">
                  Status *
                </label>
                <Controller
                  name="is_active"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <Select
                      options={statusOption}
                      onChange={(e: any) => onChange(e.value)}
                      placeholder="Select Status"
                      value={statusOption?.find(
                        (option : any) => option?.value === value
                      )}
                      className="rounded-xl"
                      optionClassName="capitalize poppins_font_number"
                      selectClassName="capitalize poppins_font_number"
                    />
                  )}
                />
              </div>}

              <div>
                <label className="poppins_font_number text-[14px] font-semibold">
                Contact Number
                </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="number"
                    placeholder="Enter Contact Number"
                    color="info"
                    {...register('contact_number')}
                    error={errors.contact_number?.message as string}
                  />
              </div>
            </div>

            {/* save changes button */}
            <div
              className={cn(
                'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
              )}
            >
              <div>
                <Link href={routes.admin.adminManagement}>
                  <Button
                    variant="outline"
                    className="@xl:w-auto dark:hover:border-gray-400"
                  >
                    Cancel
                  </Button>
                </Link>
                <Button
                  type="submit"
                  className="hover:gray-700 ms-3 @xl:w-auto dark:bg-gray-200 dark:text-white"
                  disabled={createAdminLoader || editAdminLoader}
                >
                  {id ? 'Save' : 'Create'}
                  {(createAdminLoader || editAdminLoader) && (
                    <Spinner size="sm" tag="div" className="ms-3" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}
      </Form>
    </div>
  );
};

export default CreateAdmin;
