'use client';

import Link from 'next/link';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import PencilIcon from '@/components/icons/pencil';
import DeletePopover from '@/app/shared/delete-popover';
//import AddClientForm from '../create-edit/add-client-form';
import { Badge, Button } from 'rizzui';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';
import { checkPermission } from '../roles-permissions/utils';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const GetColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
  const roleData = userData?.data?.user?.role;

  return [
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'full_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('full_name'),
      dataIndex: 'full_name',
      key: 'full_name',
      width: 130,
      render: (value: string, row: any) => {
        return (
          <Text className="font-medium capitalize text-gray-700">{value}</Text>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Email"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('email'),
      dataIndex: 'email',
      key: 'email',
      width: 130,
      render: (value: string) => (
        <Text className="font-medium text-gray-700">{value}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Role"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'role'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('role'),
      dataIndex: 'role',
      key: 'role',
      width: 100,
      render: (value: any) => (
        <Text className="font-medium capitalize text-gray-700">{value?.sub_role}</Text>
      ),
    },

    {
      title: (
        <HeaderCell
          title="Contact Number"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'contact_number'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('contact_number'),
      dataIndex: 'contact_number',
      key: 'contact_number',
      width: 100,
      render: (value: any) => (
        <Text className="font-medium text-gray-700">{(value && value !== "") ? value : "-"}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Status"
        />
      ),
      dataIndex: 'is_active',
      key: 'is_active',
      width: 50,
      render: (value: string, row: Record<string, any>) => (
          <div>
            {row?.is_active ? (
                <Text className="font-medium text-green-dark">Active</Text>
            ) : (
                <Text className="font-medium text-red">Inactive</Text>
            )}
          </div>
      ),
    },
    {
      title: <HeaderCell title="Actions" className="opacity-0" />,
      dataIndex: 'action',
      key: 'action',
      width: 50,
      render: (_: string, row: Record<string, string>) => (
        <div className="flex items-center justify-end gap-3 pe-4">
          {(roleData?.sub_role === 'super_admin'
            ? true
            : checkPermission(
                'admin_management',
                'update',
                roleData?.permissions
              )) && (
            <Tooltip
              size="sm"
              content={() => 'Edit'}
              placement="top"
              color="invert"
            >
              <Link href={`${routes.admin.adminManagementEdit}/${row._id}`}>
                <Button
                  size="sm"
                  variant="outline"
                  className="bg-white text-black"
                  aria-label={'View Member'}
                >
                  <PencilIcon className="h-4 w-4" />
                </Button>
              </Link>
            </Tooltip>
          )}
          {(roleData?.sub_role === 'super_admin'
            ? true
            : checkPermission(
                'admin_management',
                'delete',
                roleData?.permissions
              )) && (
            <DeletePopover
              title="Delete the Admin"
              description="Are you sure you want to delete this admin?"
              onDelete={() =>
                onDeleteItem(
                  row._id,
                  currentPage,
                  pageSize,
                  data?.length <= 1 ? true : false,
                  sortConfig,
                  searchTerm
                )
              }
            />
          )}
        </div>
      ),
    },
  ];
};
