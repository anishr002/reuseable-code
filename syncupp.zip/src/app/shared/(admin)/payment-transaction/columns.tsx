'use client';

import PaymentTransactionSublistPage from '@/app/admin/(hydrogen)/payment-transaction/popup-table';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import moment from 'moment';
import { useDispatch } from 'react-redux';
import { Button } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const PaymentTransactionColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const { openModal } = useModal();

  const handleClick = (subscription_id: string, agency_id: string) => {
    openModal({
      view: (
        <PaymentTransactionSublistPage
          subscription_id={subscription_id}
          agency_id={agency_id}
        />
      ),
      customSize: '1050px',
    });
  };

  return [
    // {
    //     title: (
    //         <div className="ps-3.5">
    //             <Checkbox
    //                 title={'Select All'}
    //                 onChange={handleSelectAll}
    //                 checked={checkedItems.length === data.length}
    //                 className="cursor-pointer"
    //             />
    //         </div>
    //     ),
    //     dataIndex: 'checked',
    //     key: 'checked',
    //     width: 50,
    //     render: (_: any, row: any) => (
    //         <div className="inline-flex ps-3.5">
    //             <Checkbox
    //                 className="cursor-pointer"
    //                 checked={checkedItems.includes(row._id)}
    //                 {...(onChecked && { onChange: () => onChecked(row._id) })}
    //             />
    //         </div>
    //     ),
    // },
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'agency.name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('agency.name'),
      dataIndex: 'agency',
      key: 'agency',
      width: 150,
      render: (value: any) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">
          {value?.name && value?.name !== '' ? value?.name : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Super Admin Company"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'agency.company_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('agency.company_name'),
      dataIndex: 'agency',
      key: 'agency',
      width: 200,
      render: (value: any) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">
          {value?.company_name && value?.company_name !== ''
            ? value?.company_name
            : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? moment(value).format('Do MMM, YYYY') : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Form of payment"
          // sortable
          // ascending={
          //     sortConfig?.direction === 'asc' && sortConfig?.key === 'method'
          // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('method'),
      dataIndex: 'method',
      key: 'method',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Subscription plan"
          // sortable
          // ascending={
          //     sortConfig?.direction === 'asc' && sortConfig?.key === 'plan'
          // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('plan'),
      dataIndex: 'plan',
      key: 'plan',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Subscription ID"
          // sortable
          // ascending={
          //     sortConfig?.direction === 'asc' && sortConfig?.key === 'subscription_id'
          // }
        />
      ),
      // onHeaderCell: () => onHeaderCellClick('subscription_id'),
      dataIndex: 'subscription_id',
      key: 'subscription_id',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Amount"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'amount'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('amount'),
      dataIndex: 'amount',
      key: 'amount',
      width: 150,
      render: (value: string, row: any) => (
        <>
          {row?.currency === 'INR' ? (
            <Text className="poppins_font_number font-normal text-gray-700">
              {value && value !== '' ? '₹' + (+value / 100).toFixed(2) : '-'}
            </Text>
          ) : (
            <Text className="poppins_font_number font-normal text-gray-700">
              {value && value !== '' ? '$' + (+value / 100).toFixed(2) : '-'}
            </Text>
          )}
        </>
      ),
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions" />,
      dataIndex: 'action',
      key: 'action',
      width: 100,
      render: (_: string, row: any) => (
        <div className="flex items-center  gap-3 pe-4">
          <Button
            className="w-full"
            onClick={() => {
              handleClick(row?.subscription_id, row?.agency_id);
            }}
          >
            View
            {/* {loadingflag && showloaderflag === row?._id && (
                                    <Spinner size="sm" tag="div" className="ms-3" color="white" />
                                )} */}
          </Button>
        </div>
      ),
    },
  ];
};
