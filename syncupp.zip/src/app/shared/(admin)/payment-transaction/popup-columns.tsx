'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Checkbox } from '@/components/ui/checkbox';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import {
  getAllAgencyagreement,
  updateagreementStatus,
} from '@/redux/slices/user/agreement/agreementSlice';
import { Button, Tooltip } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';
import PaymentTransactionSublistPage from '@/app/admin/(hydrogen)/payment-transaction/popup-table';
import Spinner from '@/components/ui/spinner';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const PaymentSubTransactionColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const { openModal } = useModal();
  const { paymentsubTransactions, loading } = useSelector(
    (state: any) => state?.root?.paymentTransaction
  );

  const handleClick = (subscription_id: string, agency_id: string) => {
    openModal({
      view: (
        <PaymentTransactionSublistPage
          subscription_id={subscription_id}
          agency_id={agency_id}
        />
      ),
      customSize: '1350px',
    });
  };

  return [
    {
      title: (
        <HeaderCell
          title="Name"
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
          }
        />
      ),

      dataIndex: 'agency',
      key: 'agency',
      width: 150,
      render: (value: any) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">
          {value?.name && value?.name !== '' ? value?.name : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Date"
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
          }
        />
      ),
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? moment(value).format('Do MMM, YYYY') : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Form of payment"
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'method'
          }
        />
      ),
      dataIndex: 'method',
      key: 'method',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Amount"
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'amount'
          }
        />
      ),
      dataIndex: 'amount',
      key: 'amount',
      width: 150,
      render: (value: string, row: any) => (
        <>
          {row?.currency === 'INR' ? (
            <Text className="poppins_font_number font-normal text-gray-700">
              {value && value !== '' ? '₹' + (+value / 100).toFixed(2) : '-'}
            </Text>
          ) : (
            <Text className="poppins_font_number font-normal text-gray-700">
              {value && value !== '' ? '$' + (+value / 100).toFixed(2) : '-'}
            </Text>
          )}
        </>
      ),
    },
  ];
};
