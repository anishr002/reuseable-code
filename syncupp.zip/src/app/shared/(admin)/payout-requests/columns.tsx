'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Checkbox } from '@/components/ui/checkbox';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { getAllAgencyagreement, updateagreementStatus } from '@/redux/slices/user/agreement/agreementSlice';
import { Button, Popover, Title, Tooltip } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';
import PaymentTransactionSublistPage from '@/app/admin/(hydrogen)/payment-transaction/popup-table';
import { getrequestedpayouts, payoutapiCall } from '@/redux/slices/admin/payoutRequests/payoutRequestsSlice';
import Spinner from '@/components/ui/spinner';
import { useState } from 'react';
import { FaFileInvoiceDollar } from 'react-icons/fa6';

type Columns = {
    data: any[];
    sortConfig?: any;
    handleSelectAll: any;
    checkedItems: string[];
    onDeleteItem: (id: string | string[], currentPage?: any, countPerPage?: number, Islastitem?: boolean, sortConfig?: Record<string, string>, searchTerm?: string) => void;
    onHeaderCellClick: (value: string) => void;
    onChecked?: (id: string) => void;
    currentPage?: number;
    pageSize?: number;
    searchTerm?: string;
};


export const PayoutColumns = ({
    data,
    sortConfig,
    checkedItems,
    onDeleteItem,
    onHeaderCellClick,
    handleSelectAll,
    onChecked,
    currentPage,
    pageSize,
    searchTerm,
}: Columns) => {

    const dispatch = useDispatch();
    const { openModal } = useModal();
    const { paginationParams, loading, paymentloader } = useSelector((state: any) => state?.root?.payout);
    const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
    const roleData = userData?.data?.user?.role;
    const [selectedIndex, setselectedIndex] = useState(null)

    // console.log(selectedIndex,'selectedIndex')


    const handleClick = (row: any) => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;
        setselectedIndex(row?._id)
        dispatch(payoutapiCall({ id: row?._id })).then((result: any) => {
            if (payoutapiCall.fulfilled.match(result)) {
                // console.log('resultt', result)
                if (result && result.payload.success === true) {
                    dispatch(getrequestedpayouts({ page, items_per_page, sort_field, sort_order, search }));
                }
            }
        })
    }

    return [

        {
            title: (
                <HeaderCell
                    title="Name"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'fullname'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('fullname'),
            dataIndex: 'fullname',
            key: 'fullname',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700 capitalize">{value && value != "" ? value : "-"}</Text>
            ),
        },

        {
            title: (
                <HeaderCell
                    title="Email"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('email'),
            dataIndex: 'email',
            key: 'email',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700">{value && value != "" ? value : "-"}</Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Date"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('createdAt'),
            dataIndex: 'createdAt',
            key: 'createdAt',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700">{value && value != "" ? moment(value).format("Do MMM, YYYY") : "-"}</Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Amount"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'payout_amount'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('payout_amount'),
            dataIndex: 'payout_amount',
            key: 'payout_amount',
            width: 100,
            render: (value: string) => (
                <Text className="font-medium text-gray-700">{value && value != "" ? value : "-"}</Text>
            ),
        },

        {
            title: (
                <HeaderCell
                    title="Status"
                    sortable
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'payout_requested'
                    }
                />
            ),
            onHeaderCell: () => onHeaderCellClick('payout_requested'),
            dataIndex: 'payout_requested',
            key: 'payout_requested',
            width: 100,
            render: (value: any) => (
                // console.log(row, 'row'),
                <Text className="font-medium text-gray-700">{value ? "Unpaid" : "Paid"}</Text>
            ),
        },

        {
            // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
            title: <HeaderCell title="Actions" />,
            dataIndex: 'action',
            key: 'action',
            width: 100,
            render: (_: string, row: any) => (
                <>

                    {row?.payout_requested && roleData?.sub_role === 'super_admin' && <Popover
                        placement="left"
                        className="z-50"
                        content={({ setOpen }) => {
                            return (
                                <div className="w-56 pb-2 pt-1 text-left rtl:text-right">
                                    <Title
                                        as="h6"
                                        className="mb-0.5 flex items-start text-sm text-gray-700 sm:items-center"
                                    >
                                        <FaFileInvoiceDollar className="me-1 h-[17px] w-[17px]" />
                                        Payout Request
                                    </Title>
                                    <Text className="mb-2 leading-relaxed text-gray-500">
                                        Are you sure you want to accept?
                                    </Text>
                                    <div className="flex items-center justify-end">
                                        <Button
                                            size="sm"
                                            className="me-1.5 h-7"
                                            onClick={() => {
                                                setOpen(false);
                                                handleClick(row)
                                            }}
                                        >
                                            Yes
                                        </Button>
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            className="h-7"
                                            onClick={() => setOpen(false)}
                                        >
                                            No
                                        </Button>
                                    </div>
                                </div>
                            );
                        }}
                    >
                        <Button
                            disabled={paymentloader}
                            className="w-full"
                        >
                            Pay
                            {paymentloader && (selectedIndex === row?._id) && (
                                <Spinner size="sm" tag="div" className="ms-3" color="white" />
                            )}
                        </Button>

                    </Popover>}


                    {/* {row?.payout_requested && <div className="flex items-center  gap-3 pe-4">
                        <Button
                            disabled={paymentloader}
                            className="w-full"
                            onClick={() => { handleClick(row) }}
                        >
                            Pay
                            {paymentloader && (selectedIndex === row?._id) && (
                                <Spinner size="sm" tag="div" className="ms-3" color="white" />
                            )}
                        </Button>
                    </div>} */}
                </>
            ),
        },

    ];
}
