"use client";

import { PiXBold } from "react-icons/pi";
import { ActionIcon, Button, Title } from "rizzui";
import { useModal } from "../../modal-views/use-modal";
import Spinner from "@/components/ui/spinner";
import { useDispatch, useSelector } from "react-redux";
import cn from "@/utils/class-names";
import { useEffect, useState } from "react";
import { DatePicker } from "@/components/ui/datepicker";
import moment from "moment";
import { Form } from "@/components/ui/form";
import { Controller, SubmitHandler } from "react-hook-form";
import { z } from "zod";
import { messages } from "@/config/messages";
import { getAllAgency, patchTrialPeriodDate } from "@/redux/slices/admin/agency/agencySlice";

export function TrialDateUpdateModal(props: any) {
    const { data } = props;
    const { closeModal } = useModal();
    const dispatch = useDispatch();
    const { trialDateUpdateLoader, paginationParams } = useSelector((state: any) => state?.root?.adminAgency);


    const trialFormSchema = z.object({
        date: z.date()
            .nullable()
            .refine((val) => val !== null, {
                message: messages.trialEndDateIsRequried
            })
    });

    // console.log("paginationParams.....", paginationParams)


    // generate form types from zod validation schema
    type TrialFormSchema = z.infer<typeof trialFormSchema>;

    const onSubmit: SubmitHandler<TrialFormSchema> = (formData) => {

        dispatch(patchTrialPeriodDate({ agency_id: data?._id, trial_end_date: moment(formData?.date).format('DD-MM-YYYY')})).then((result: any) => {
            if (patchTrialPeriodDate.fulfilled.match(result)) {
                if (result && result.payload.success === true) {
                    dispatch(getAllAgency({...paginationParams}));
                    closeModal();
                }
            }
        });

    }


    return (
        <div className="p-[1.5rem] h-full w-full whitespace-pre-wrap">
            <div className="flex items-center">
                <Title as="h3" className="text-xl xl:text-2xl w-full">
                    Extend Trial Date
                </Title>
                <div className='ms-auto flex items-center gap-3'>

                    <ActionIcon
                        size="sm"
                        variant="text"
                        onClick={() => closeModal()}
                        className="p-0 text-gray-500 hover:!text-gray-900"
                    >
                        <PiXBold className="h-[18px] w-[18px]" />
                    </ActionIcon>
                </div>
            </div>

            <div>
                <Form<TrialFormSchema>
                    validationSchema={trialFormSchema}
                    onSubmit={onSubmit}
                    useFormProps={{
                        mode: 'all',
                        defaultValues: {
                            date: data?.trial_end_date && data?.trial_end_date !== null ? moment(data?.trial_end_date).toDate() : moment().add(2, "days").toDate()
                        },
                    }}
                    className="[&_label]:font-medium text-[#9BA1B9] text-[14px]"
                >
                    {({
                        register,
                        control,
                        formState: { errors },
                    }) => (
                        <div>
                            <div className="mt-[20px] mb-[10px] date_picker_customization">
                            <Controller
                                name="date"
                                control={control}
                                render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                        selected={value}
                                        inputProps={{
                                            // label: 'Due Date',
                                            // color: 'info',
                                            error: errors?.date?.message,
                                        }}
                                        placeholderText="Select Trial end date"
                                        onChange={onChange}
                                        selectsStart
                                        startDate={value}
                                        minDate={new Date()}
                                        showYearDropdown
                                        scrollableYearDropdown
                                        showMonthDropdown
                                        yearDropdownItemNumber={100}
                                        // inline
                                    />
                                )}
                            />
                            </div>
                            <div
                                className={cn(
                                    'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
                                )}
                            >
                                <Button
                                    variant="outline"
                                    className="w-full dark:hover:border-gray-400"
                                    onClick={() => closeModal()}
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="submit"
                                    className="hover:gray-700 ms-3 w-full dark:bg-gray-200 dark:text-white"
                                    disabled={trialDateUpdateLoader}
                                >
                                    Save
                                    {trialDateUpdateLoader && (
                                        <Spinner
                                            size="sm"
                                            tag="div"
                                            className="ms-3"
                                            color="white"
                                        />
                                    )}
                                </Button>
                            </div>
                        </div>
                    )}

                </Form>

            </div>
        </div>
    );
}