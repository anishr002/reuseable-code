'use client';

import DeletePopover from '@/app/shared/delete-popover';
import EyeIcon from '@/components/icons/eye';
import { Checkbox } from '@/components/ui/checkbox';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { routes } from '@/config/routes';
import {
  deleteAgency,
  getAgencyDetails,
  getAllAgency,
} from '@/redux/slices/admin/agency/agencySlice';
import moment from 'moment';
import Link from 'next/link';
import { MdOutlineEditCalendar, MdOutlinePayment } from 'react-icons/md';
import { useDispatch, useSelector } from 'react-redux';
import { Badge, Button, Tooltip } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';
import { checkPermission } from '../roles-permissions/utils';
import ManualPaymentModal from './manual-payment-modal';
import { TrialDateUpdateModal } from './trial-date-update-modal';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const GetColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.adminAgency
  );
  const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
  const roleData = userData?.data?.user?.role;

  const handleSwitchChange = async (
    id: string,
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    try {
      const res = await dispatch(
        deleteAgency({
          agencies: id,
          status: event?.target?.checked ? 'active' : 'inactive',
        })
      );
      if (res.payload.success === true) {
        const reponse = await dispatch(getAllAgency({ ...paginationParams }));
      }
    } catch (error) {
      console.error(error);
    }
  };

  const GetAgencyDetails = async (id: any) => {
    try {
      const res = await dispatch(getAgencyDetails({ _id: id }));
    } catch (error) {
      console.log(error);
    }
  };

  function getStatusBadge(status: string) {
    switch (status?.toLowerCase()) {
      case 'payment_pending':
        return (
          <div className="flex items-center">
            <Badge color="warning" renderAsDot />
            <Text className="ms-2 font-medium text-orange-dark">
              Payment Pending
            </Text>
          </div>
        );
      case 'confirmed':
        return (
          <div className="flex items-center">
            <Badge color="success" renderAsDot />
            <Text className="ms-2 font-medium text-green-dark">Active</Text>
          </div>
        );
      case 'inactive':
        return (
          <div className="flex items-center">
            <Badge color="danger" renderAsDot />
            <Text className="ms-2 font-medium text-red">Inactive</Text>
          </div>
        );
      case 'free_trial':
        return (
          <div className="flex items-center">
            <Badge className="bg-yellow-300" renderAsDot />
            <Text className="ms-2 font-medium text-yellow-300">Free Trial</Text>
          </div>
        );
      case 'subscription_cancelled':
        return (
          <div className="flex items-center">
            <Badge color="danger" renderAsDot />
            <Text className="ms-2 font-medium text-red">
              Subscription Cancelled
            </Text>
          </div>
        );
      default:
        return (
          <div className="flex items-center">
            <Badge renderAsDot className="bg-gray-400" />
            <Text className="ms-2 font-medium text-gray-600">{status}</Text>
          </div>
        );
    }
  }

  const checkboxColumn = {
    title: (
      <div className="ps-3.5">
        <Checkbox
          title={'Select All'}
          onChange={handleSelectAll}
          checked={checkedItems.length === data.length}
          className="cursor-pointer"
        />
      </div>
    ),
    dataIndex: 'checked',
    key: 'checked',
    width: 50,
    render: (_: any, row: any) => (
      <div className="inline-flex ps-3.5">
        <Checkbox
          className="cursor-pointer"
          checked={checkedItems.includes(row._id)}
          {...(onChecked && { onChange: () => onChecked(row._id) })}
        />
      </div>
    ),
  };

  const columns = [
    {
      title: (
        <HeaderCell
          title="First Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'first_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('first_name'),
      dataIndex: 'first_name',
      key: 'first_name',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium capitalize text-gray-700">
          {value && value != '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Last Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'last_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('last_name'),
      dataIndex: 'last_name',
      key: 'last_name',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium capitalize text-gray-700">
          {value && value != '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Mobile Number"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'contact_number'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('contact_number'),
      dataIndex: 'contact_number',
      key: 'contact_number',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium text-gray-700">
          {value && value != '' ? `+${value}` : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Email ID"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('email'),
      dataIndex: 'email',
      key: 'email',
      width: 200,
      render: (value: string) => {
        return (
          <Text className="poppins_font_number font-medium text-gray-700">
            {value && value != '' ? value : '-'}
          </Text>
        );
      },
    },
    // {
    //   title: (
    //     <HeaderCell
    //       title="Workspace"
    //       sortable
    //       ascending={
    //         sortConfig?.direction === 'asc' &&
    //         sortConfig?.key === 'workspace_name'
    //       }
    //     />
    //   ),
    //   onHeaderCell: () => onHeaderCellClick('workspace_name'),
    //   dataIndex: 'workspace_name',
    //   key: 'workspace_name',
    //   width: 200,
    //   render: (value: string) => (
    //     <Text className="font-medium capitalize text-gray-700">
    //       {value && value != '' ? value : '-'}
    //     </Text>
    //   ),
    // },
    {
      title: (
        <HeaderCell
          title="Trial End Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'trial_end_date'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('trial_end_date'),
      dataIndex: 'trial_end_date',
      key: 'trial_end_date',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium text-gray-700">
          {value && (value != '' || value != null)
            ? moment(value).format('Do MMM, YYYY')
            : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Company"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'company_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('company_name'),
      dataIndex: 'company_name',
      key: 'company_name',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium capitalize text-gray-700">
          {value && value != '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Industry"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'profession_role'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('profession_role'),
      dataIndex: 'profession_role',
      key: 'profession_role',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium capitalize text-gray-700">
          {value && value != '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Created Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-medium text-gray-700">
          {value && value != '' ? moment(value).format('Do MMM, YYYY') : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Status"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'status'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('status'),
      dataIndex: 'status',
      key: 'status',
      width: 200,
      render: (value: string, row: Record<string, any>) => (
        <div className="flex ">
          {/* <Text className="font-medium text-gray-700">{value}</Text> */}
          {/* <Switch
              className="[&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
              variant="active"
              onChange={(event) => handleSwitchChange(row?._id, event)}
              disabled={value == 'payment_pending' || row?.is_deleted}
              defaultChecked={value == 'confirmed' ? true : false}
            /> */}
          {row?.is_deleted
            ? getStatusBadge('subscription_cancelled')
            : getStatusBadge(value)}
        </div>
      ),
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions" />,
      dataIndex: 'action',
      key: 'action',
      width: 120,
      render: (_: string, row: Record<string, any>) => (
        <div className="flex items-center gap-3 pe-4">
          <Tooltip
            size="sm"
            content={() => 'View Customer'}
            placement="top"
            color="invert"
          >
            <Link href={routes.admin.agencyView}>
              <Button
                size="sm"
                variant="outline"
                className="bg-white text-black"
                aria-label={'View Member'}
                onClick={() => GetAgencyDetails(row?._id)}
              >
                <EyeIcon className="h-4 w-4" />
              </Button>
            </Link>
          </Tooltip>
          {(roleData?.sub_role === 'super_admin'
            ? true
            : checkPermission('agency', 'update', roleData?.permissions)) &&
          row &&
          row?.trial_end_date &&
          (row?.trial_end_date !== '' || row?.trial_end_date !== null) &&
          !row?.is_deleted ? (
            <>
              <Tooltip
                size="sm"
                content={() => 'Extend Trial Date'}
                placement="top"
                color="invert"
              >
                <Button
                  size="sm"
                  variant="outline"
                  className="bg-white text-black"
                  aria-label={'Extend Trial Date'}
                  onClick={() => {
                    openModal({
                      view: <TrialDateUpdateModal data={row} />,
                      customSize: '450px',
                    });
                  }}
                >
                  <MdOutlineEditCalendar className="h-4 w-4" />
                </Button>
              </Tooltip>
              <Tooltip
                size="sm"
                content={() => 'Manual Payment'}
                placement="top"
                color="invert"
              >
                <Button
                  size="sm"
                  variant="outline"
                  className="bg-white text-black"
                  aria-label={'Manual Payment'}
                  onClick={() => {
                    openModal({
                      view: <ManualPaymentModal data={row} />,
                      customSize: '600px',
                    });
                  }}
                >
                  <MdOutlinePayment className="h-4 w-4" />
                </Button>
              </Tooltip>
            </>
          ) : (
            <>
              {(roleData?.sub_role === 'super_admin'
                ? true
                : checkPermission('agency', 'update', roleData?.permissions)) &&
              ((row &&
                row?.purchased_plan &&
                row?.subscribe_date &&
                (row?.purchased_plan !== '' || row?.purchased_plan !== null) &&
                (row?.subscribe_date !== '' || row?.subscribe_date !== null)) ||
                (row?.manual_subscription_plan &&
                  (row?.manual_subscription_plan !== '' ||
                    row?.manual_subscription_plan !== null))) &&
              !row?.is_deleted ? (
                <Tooltip
                  size="sm"
                  content={() => 'Manual Payment'}
                  placement="top"
                  color="invert"
                >
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-white text-black"
                    aria-label={'Manual Payment'}
                    onClick={() => {
                      openModal({
                        view: <ManualPaymentModal data={row} />,
                        customSize: '600px',
                      });
                    }}
                  >
                    <MdOutlinePayment className="h-4 w-4" />
                  </Button>
                </Tooltip>
              ) : (
                <>
                  {(roleData?.sub_role === 'super_admin'
                    ? true
                    : checkPermission(
                        'agency',
                        'update',
                        roleData?.permissions
                      )) &&
                    row?.status === 'payment_pending' &&
                    (!row?.trial_end_date || row?.trial_end_date === '') && (
                      <>
                        <Tooltip
                          size="sm"
                          content={() => 'Extend Trial Date'}
                          placement="top"
                          color="invert"
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            className="bg-white text-black"
                            aria-label={'Extend Trial Date'}
                            onClick={() => {
                              openModal({
                                view: <TrialDateUpdateModal data={row} />,
                                customSize: '450px',
                              });
                            }}
                          >
                            <MdOutlineEditCalendar className="h-4 w-4" />
                          </Button>
                        </Tooltip>
                        <Tooltip
                          size="sm"
                          content={() => 'Manual Payment'}
                          placement="top"
                          color="invert"
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            className="bg-white text-black"
                            aria-label={'Manual Payment'}
                            onClick={() => {
                              openModal({
                                view: <ManualPaymentModal data={row} />,
                                customSize: '600px',
                              });
                            }}
                          >
                            <MdOutlinePayment className="h-4 w-4" />
                          </Button>
                        </Tooltip>
                      </>
                    )}
                </>
              )}
            </>
          )}
          {(roleData?.sub_role === 'super_admin'
            ? true
            : checkPermission('agency', 'delete', roleData?.permissions)) && (
            <DeletePopover
              title={`Delete the customer`}
              description={`Are you sure you want to delete?`}
              onDelete={() =>
                onDeleteItem(
                  row._id,
                  currentPage,
                  pageSize,
                  data?.length <= 1 ? true : false,
                  sortConfig,
                  searchTerm
                )
              }
            />
          )}
        </div>
      ),
    },
  ];

  (roleData?.sub_role === 'super_admin'
    ? true
    : checkPermission('agency', 'delete', roleData?.permissions)) &&
    columns.unshift(checkboxColumn);

  return columns;
};
