'use client';

import { WidgetCard } from '@/app/admin/(hydrogen)/customer/view/agency-view-profile-form';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import Spinner from '@/components/ui/spinner';
import { messages } from '@/config/messages';
import {
  getAgencyPaymentDetails,
  getAllAgency,
  postAgencyManualPayment,
} from '@/redux/slices/admin/agency/agencySlice';
import {
  clearAgencyWorkspaceData,
  getAgencyWorkspaceList,
  getAllPlanList,
  getSubscriptionPlan,
  removePlanData,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Controller, SubmitHandler } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect from 'react-select';
import { ActionIcon, Button, Text, Title } from 'rizzui';
import { z } from 'zod';
import { useModal } from '../../modal-views/use-modal';
import WorkspaceManagementModal from './workspace-management-modal';

export default function ManualPaymentModal(props: any) {
  const { data, payloadDetails } = props;
  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const { paginationParams, agencyManualPaymentLoader } = useSelector(
    (state: any) => state?.root?.adminAgency
  );
  const { plans, workspaceList } = useSelector(
    (state: any) => state?.root?.subscriptionPlan
  );
  const [agencyData, setAgencyData] = useState<any>({});
  const [agencyDataLoader, setAgencyDataLoader] = useState(true);
  const [standardPlan, setStandardPlan] = useState<any>({
    name: 'Select Plan',
    value: '',
    label: 'Select Plan',
  });
  const [selectedPlanData, setSelectedPlanData] = useState<any>(null);

  // setValue referece for setting values in form
  const setValueReference = useRef<any>();

  useEffect(() => {
    // remove plan data & agency workspace list on first load if have
    dispatch(removePlanData());
    dispatch(clearAgencyWorkspaceData());
  }, [dispatch]);

  useEffect(() => {
    dispatch(getAllPlanList({ mode: 'standard' }));
    if (data && data?._id) {
      // Get workspaces of Agency
      dispatch(getAgencyWorkspaceList({ agency_id: data?._id }));
      dispatch(getAgencyPaymentDetails({ _id: data?._id })).then(
        (result: any) => {
          if (getAgencyPaymentDetails.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              result?.payload?.data && setAgencyData(result?.payload?.data);
              setAgencyDataLoader(false);
            } else {
              setAgencyDataLoader(false);
            }
          } else {
            setAgencyDataLoader(false);
          }
        }
      );
    }
  }, [data]);

  // standard plans options
  let standardPlansOptions: any[] = [];
  plans?.length > 0 &&
    plans?.map((plan: Record<string, any>) => {
      standardPlansOptions.push({
        name: `${capitalizeFirstLetter(plan?.name)} - ${capitalizeFirstLetter(
          plan?.period
        )}`,
        label: `${capitalizeFirstLetter(plan?.name)} - ${capitalizeFirstLetter(
          plan?.period
        )}`,
        value: plan?._id,
      });
    });

  useEffect(() => {
    if (
      agencyData &&
      agencyData?.workspace?.[0]?.pause_subscription_date &&
      (agencyData?.workspace?.[0]?.pause_subscription_date !== '' ||
        agencyData?.workspace?.[0]?.pause_subscription_date !== null)
    ) {
      const plan = standardPlansOptions?.find(
        (plan: Record<string, string>) =>
          plan?.value ===
          agencyData?.agency_detail?.manual_subscription_plan?._id
      );
      console.log('plan in use effect......', plan);
      plan && setStandardPlan(plan);
    }
  }, [agencyData?.workspace]);

  // standard plan selection dropdown css
  const standardPlanSelectionDropdownStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected ? '#8c80d2' : 'white',
      color: state.isSelected ? 'white' : 'black',
    }),
  };

  const manualPaymentFormSchema = z.object({
    plan_id: z.string().min(1, { message: messages.planRequired }),
    date: z
      .date()
      .nullable()
      .refine((val) => val !== null, {
        message: messages?.DateIsRequried,
      }),
  });

  // generate form types from zod validation schema
  type ManualPaymentFormSchema = z.infer<typeof manualPaymentFormSchema>;

  const onSubmit: SubmitHandler<ManualPaymentFormSchema> = (formData) => {
    console.log('Manual payment formData....', formData);

    const payload = {
      agency_id: data?._id,
      plan_id: formData?.plan_id,
      pause_subscription_date: moment(formData?.date).format('DD-MM-YYYY'),
      workspace_members: [],
    };

    console.log('Payload....', payload);

    const isMaxUsers =
      workspaceList?.some(
        (entry: Record<string, any>) =>
          entry?.members?.length > selectedPlanData?.no_of_users
      ) ?? false;

    console.log('isMaxUsers....', isMaxUsers);

    if (
      workspaceList &&
      workspaceList?.length > 0 &&
      workspaceList?.length > selectedPlanData?.workspaces_count
    ) {
      console.log("workspace count more than selected plan's workspace count");
      closeModal();
      openModal({
        view: (
          <div>
            <WorkspaceManagementModal
              title="Manage Workspace & Users"
              selectedPlan={selectedPlanData}
              agencyData={data}
              payload={payload}
            />
          </div>
        ),
        customSize: '900px',
      });
    } else if (isMaxUsers) {
      console.log("users count is more than selected plan's users count");
      closeModal();
      openModal({
        view: (
          <div>
            <WorkspaceManagementModal
              title="Manage Workspace & Users"
              selectedPlan={selectedPlanData}
              agencyData={data}
              payload={payload}
            />
          </div>
        ),
        customSize: '900px',
      });
    } else {
      console.log('Perfect plan to do manual payment');
      dispatch(postAgencyManualPayment(payload)).then((result: any) => {
        if (postAgencyManualPayment.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            dispatch(getAllAgency({ ...paginationParams }));
            closeModal();
          }
        }
      });
    }
  };

  if (agencyDataLoader || Object?.keys(agencyData ?? {})?.length === 0) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    // Setting form data values

    let defaultValues: any = {
      plan_id: '',
      date: moment().add(2, 'days').toDate(),
    };

    if (
      agencyData &&
      agencyData?.workspace?.[0]?.pause_subscription_date &&
      (agencyData?.workspace?.[0]?.pause_subscription_date !== '' ||
        agencyData?.workspace?.[0]?.pause_subscription_date !== null)
    ) {
      console.log('we are setting form data from agency data....', agencyData);
      const plan = standardPlansOptions?.find(
        (plan: Record<string, string>) =>
          plan?.value ===
          agencyData?.agency_detail?.manual_subscription_plan?._id
      );
      console.log('plan......', plan);
      defaultValues = {
        plan_id: plan
          ? agencyData?.agency_detail?.manual_subscription_plan?._id
          : '',
        date:
          new Date(agencyData?.workspace?.[0]?.pause_subscription_date) ??
          moment().add(2, 'days').toDate(),
      };
    }

    return (
      <div className="h-full w-full whitespace-pre-wrap p-[1.5rem]">
        <div className="flex items-center">
          <Title as="h3" className="w-full text-xl xl:text-2xl">
            Manual Payment
          </Title>
          <div className="ms-auto flex items-center gap-3">
            <ActionIcon
              size="sm"
              variant="text"
              onClick={() => closeModal()}
              className="p-0 text-gray-500 hover:!text-gray-900"
            >
              <PiXBold className="h-[18px] w-[18px]" />
            </ActionIcon>
          </div>
        </div>
        {/* Agency details */}
        <div className="mt-[20px]">
          <WidgetCard
            title="Super Admin Information"
            className=""
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex flex-col"
          >
            <div className="mt-2 ps-[6px]">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-bold text-gray-700">Name :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {capitalizeFirstLetter(
                    agencyData?.agency_detail?.first_name
                  ) ?? ''}{' '}
                  {capitalizeFirstLetter(
                    agencyData?.agency_detail?.last_name
                  ) ?? ''}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Email :</span>
                <Text as="p" className="text-base @7xl:text-lg">
                  {agencyData?.agency_detail?.email ?? ''}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Contact No :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light @7xl:text-lg"
                >
                  {agencyData?.agency_detail?.contact_number
                    ? `+${agencyData?.agency_detail?.contact_number}`
                    : ''}
                </Text>
              </span>
            </div>
          </WidgetCard>
          <WidgetCard
            title="Current Plan Information"
            className="mt-[20px]"
            childrenWrapperClass="py-1 px-1 @5xl:py-8 flex grid sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2"
          >
            <div className="mt-2 ps-[6px]">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Plan Name :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {agencyData?.agency_detail?.purchased_plan
                    ? agencyData?.agency_detail?.purchased_plan?.name
                    : agencyData?.agency_detail?.manual_subscription_plan
                      ? agencyData?.agency_detail?.manual_subscription_plan
                          ?.name
                      : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Plan Type :</span>
                <Text as="p" className="text-base capitalize @7xl:text-lg">
                  {agencyData?.agency_detail?.purchased_plan
                    ? agencyData?.agency_detail?.purchased_plan?.period
                    : agencyData?.agency_detail?.manual_subscription_plan
                      ? agencyData?.agency_detail?.manual_subscription_plan
                          ?.period
                      : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">Price :</span>
                <Text
                  as="p"
                  className="poppins_font_number flex gap-1 text-base font-light @7xl:text-lg"
                >
                  {agencyData?.agency_detail?.purchased_plan ? (
                    <span className="poppins_font_number flex gap-1 text-base font-light @7xl:text-lg">
                      {agencyData?.agency_detail?.purchased_plan?.symbol ?? ''}{' '}
                      {(agencyData?.agency_detail?.purchased_plan?.amount ??
                        0) / 100}
                    </span>
                  ) : agencyData?.agency_detail?.manual_subscription_plan ? (
                    <span className="poppins_font_number flex gap-1 text-base font-light @7xl:text-lg">
                      {agencyData?.agency_detail?.manual_subscription_plan
                        ?.symbol ?? ''}{' '}
                      {(agencyData?.agency_detail?.manual_subscription_plan
                        ?.amount ?? 0) / 100}
                    </span>
                  ) : (
                    'N/A'
                  )}
                </Text>
              </span>
            </div>
            <div className="ps-[6px] lg:mt-2 xl:mt-2">
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Total Seats :
                </span>
                <Text
                  as="p"
                  className="poppins_font_number text-base font-light @7xl:text-lg"
                >
                  {agencyData?.agency_detail?.purchased_plan
                    ? agencyData?.agency_detail?.purchased_plan?.no_of_users
                    : agencyData?.agency_detail?.manual_subscription_plan
                      ? agencyData?.agency_detail?.manual_subscription_plan
                          ?.no_of_users
                      : 'N/A'}
                </Text>
              </span>
              <span className="mb-2 flex items-baseline gap-2">
                <span className="font-semibold text-gray-900">
                  Workspaces :
                </span>
                {agencyData?.agency_detail?.purchased_plan?.period !==
                  'lifetime' &&
                agencyData?.agency_detail?.manual_subscription_plan?.period !==
                  'lifetime' ? (
                  <Text
                    as="p"
                    className="poppins_font_number text-base font-light @7xl:text-lg"
                  >
                    {agencyData?.agency_detail?.purchased_plan
                      ? agencyData?.agency_detail?.purchased_plan
                          ?.workspaces_count
                      : agencyData?.agency_detail?.manual_subscription_plan
                        ? agencyData?.agency_detail?.manual_subscription_plan
                            ?.workspaces_count
                        : 'N/A'}
                  </Text>
                ) : (
                  <Text
                    as="p"
                    className="poppins_font_number text-base font-light @7xl:text-lg"
                  >
                    Unlimited
                  </Text>
                )}
              </span>
            </div>
          </WidgetCard>
        </div>

        <div>
          <Form<ManualPaymentFormSchema>
            validationSchema={manualPaymentFormSchema}
            onSubmit={onSubmit}
            useFormProps={{
              mode: 'all',
              defaultValues: defaultValues,
            }}
            className="text-[14px] [&_label]:font-medium"
          >
            {({ control, formState: { errors }, setValue, getValues }) => {
              setValueReference.current = setValue;

              return (
                <div>
                  <div className="flex flex-col gap-1 pt-5">
                    <label htmlFor="Plan" className="text-black">
                      Plan *
                    </label>
                    <ReactSelect
                      options={standardPlansOptions}
                      onChange={(selectedOption: Record<string, any>) => {
                        console.log(
                          'standard plan selectedOption....',
                          selectedOption
                        );
                        if (selectedOption) {
                          setStandardPlan(selectedOption);
                          setValue('plan_id', selectedOption?.value ?? '', {
                            shouldValidate: true,
                          });
                          dispatch(
                            getSubscriptionPlan({
                              planId: selectedOption?.value,
                            })
                          ).then((result: any) => {
                            if (getSubscriptionPlan.fulfilled.match(result)) {
                              if (
                                result?.payload?.success === true &&
                                result?.payload?.data
                              ) {
                                setSelectedPlanData(result?.payload?.data);
                              }
                            }
                          });
                        } else {
                          setStandardPlan({
                            name: 'Select Plan',
                            value: '',
                            label: 'Select Plan',
                          });
                          setValue('plan_id', '', {
                            shouldValidate: true,
                          });
                          setSelectedPlanData(null);
                        }
                      }}
                      value={standardPlan}
                      placeholder="Select Plan"
                      className="poppins_font_number react-select-options w-full font-light"
                      classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                      styles={standardPlanSelectionDropdownStyles}
                      id="task-assign"
                      isClearable={true}
                    />
                    {/* Display error message if validation fails */}
                    {errors?.plan_id?.message && (
                      <div className="pt-[1px] text-[12px] text-[#EE0000]">
                        {errors?.plan_id?.message}
                      </div>
                    )}
                  </div>
                  {standardPlan?.value !== '' && selectedPlanData && (
                    <WidgetCard
                      title="Plan Information"
                      className="mt-[20px]"
                      childrenWrapperClass="py-1 px-1 @5xl:py-8 flex grid sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2"
                    >
                      <div className="mt-2 ps-[6px]">
                        <span className="mb-2 flex items-baseline gap-2">
                          <span className="font-semibold text-gray-900">
                            Plan Name :
                          </span>
                          <Text as="p" className="text-base @7xl:text-lg">
                            {selectedPlanData?.name ?? ''}
                          </Text>
                        </span>
                        <span className="mb-2 flex items-baseline gap-2">
                          <span className="font-semibold text-gray-900">
                            Plan Type :
                          </span>
                          <Text
                            as="p"
                            className="text-base capitalize @7xl:text-lg"
                          >
                            {selectedPlanData?.period ?? ''}
                          </Text>
                        </span>
                        <span className="mb-2 flex items-baseline gap-2">
                          <span className="font-semibold text-gray-900">
                            Price :
                          </span>
                          <Text
                            as="p"
                            className="poppins_font_number text-base font-light @7xl:text-lg"
                          >
                            {selectedPlanData?.symbol ?? '$'}{' '}
                            {selectedPlanData?.amount > 0
                              ? selectedPlanData?.amount / 100
                              : 0}
                          </Text>
                        </span>
                      </div>
                      <div className="ps-[6px] lg:mt-2 xl:mt-2">
                        <span className="mb-2 flex items-baseline gap-2">
                          <span className="font-semibold text-gray-900">
                            Total Seats :
                          </span>
                          <Text
                            as="p"
                            className="poppins_font_number text-base font-light @7xl:text-lg"
                          >
                            {selectedPlanData?.no_of_users ?? 0}
                          </Text>
                        </span>
                        <span className="mb-2 flex items-baseline gap-2">
                          <span className="font-semibold text-gray-900">
                            Workspaces :
                          </span>
                          <Text
                            as="p"
                            className="poppins_font_number text-base font-light capitalize @7xl:text-lg"
                          >
                            {selectedPlanData?.period !== 'lifetime'
                              ? selectedPlanData?.workspaces_count
                              : selectedPlanData?.period === 'lifetime'
                                ? 'Unlimited'
                                : 0}
                          </Text>
                        </span>
                      </div>
                    </WidgetCard>
                  )}
                  <div
                    className={cn(
                      'date_picker_customization mb-[10px]',
                      'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
                    )}
                  >
                    <Controller
                      name="date"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <DatePicker
                          selected={value}
                          inputProps={{
                            label: 'Date *',
                            // color: 'info',
                            error: errors?.date?.message,
                          }}
                          placeholderText="Select date"
                          onChange={onChange}
                          selectsStart
                          startDate={value}
                          minDate={new Date()}
                          showYearDropdown
                          scrollableYearDropdown
                          showMonthDropdown
                          yearDropdownItemNumber={100}
                          // inline
                        />
                      )}
                    />
                  </div>
                  <div
                    className={cn(
                      'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
                    )}
                  >
                    <Button
                      variant="outline"
                      className="w-full dark:hover:border-gray-400"
                      onClick={() => closeModal()}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      className="hover:gray-700 w-full dark:bg-gray-200 dark:text-white"
                      disabled={agencyManualPaymentLoader}
                    >
                      Save
                      {agencyManualPaymentLoader && (
                        <Spinner
                          size="sm"
                          tag="div"
                          className="ms-3"
                          color="white"
                        />
                      )}
                    </Button>
                  </div>
                </div>
              );
            }}
          </Form>
        </div>
      </div>
    );
  }
}
