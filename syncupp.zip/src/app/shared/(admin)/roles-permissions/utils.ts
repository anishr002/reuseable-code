export const PERMISSIONS = {
  Create: 'create',
  Update: 'update',
  Delete: 'delete',
  View: 'view',
};

export const PERMISSIONSDATA = ['create', 'update', 'delete', 'view'];

export const ADMINMODULELIST: any = {
  // dashboard: {
  //     view: false,
  //     is_applicable: false,
  // },
  agency: {
    view: false,
    update: false,
    delete: false,
    is_applicable: false,
  },
  client_review: {
    view: false,
    create: false,
    update: false,
    delete: false,
    is_applicable: false,
  },
  inquiry: {
    view: false,
    delete: false,
    is_applicable: false,
  },
  payment: {
    view: false,
    is_applicable: false,
  },
  faq: {
    view: false,
    create: false,
    update: false,
    delete: false,
    is_applicable: false,
  },
  cms: {
    view: false,
    update: false,
    is_applicable: false,
  },
  coupon_management: {
    view: false,
    create: false,
    update: false,
    delete: false,
    is_applicable: false,
  },
  support_tickets: {
    view: false,
    is_applicable: false,
  },
  // payout_requests:{
  //   view:false,
  //   update: false,
  //   is_applicable: false,
  // },
  roles_permissions: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  admin_management: {
    create: false,
    update: false,
    delete: false,
    view: false,
    is_applicable: false,
  },
  demo_calls: {
    view: false,
    is_applicable: false,
  },
  referral_statistics: {
    view: false,
    is_applicable: false,
  },
};

export const permissions = Object.values(PERMISSIONS).map((permission) => ({
  label: permission,
  value: permission,
}));

export const getCommonModules = (clientModules: any, apiResponse: any) => {
  return Object.fromEntries(
    Object.entries(apiResponse).filter(([key]) => key in clientModules)
  );
};

export const getApplicableMenuItems = (menuItems: any, modules: any) => {
  return menuItems.filter(
    ({ moduleName }: { moduleName: string }) =>
      moduleName === 'dashboard' || modules?.[moduleName]?.is_applicable
  );
};

export const checkPermission = (
  moduleName: string,
  permission: string,
  permissionsList: any
) => {
  // Check if the module exists
  if (!permissionsList?.[moduleName]) {
    return false; // Module not found
  }

  // Check if the permission exists in the module itself (for non-submodule modules)
  if (permissionsList[moduleName].hasOwnProperty(permission)) {
    return permissionsList[moduleName][permission];
  }

  return false; // Permission not found in the module
};

export const getCommonModulesClient = (
  clientModules: any,
  apiResponse: any
) => {
  const filterModules: any = (clientObj: any, apiObj: any) =>
    Object.fromEntries(
      Object.entries(clientObj).flatMap(([key, clientValue]: any) => {
        if (key in apiObj) {
          const apiValue = apiObj[key];
          if (
            typeof clientValue === 'object' &&
            clientValue !== null &&
            typeof apiValue === 'object'
          ) {
            const nestedResult = filterModules(clientValue, apiValue);
            return [[key, nestedResult]];
          }
          return [[key, apiValue]];
        }
        return [];
      })
    );

  return filterModules(clientModules, apiResponse);
};
