import DeletePopover from '@/app/shared/delete-popover';
import UserCog from '@/components/icons/user-cog';
import { Button } from '@/components/ui/button';
import { routes } from '@/config/routes';
import cn from '@/utils/class-names';
import { capitalizeAndJoin } from '@/utils/common-functions';
import Link from 'next/link';
import { Title } from 'rizzui';

interface RoleCardProps {
  key: string;
  canDelete: boolean;
  canEdit: boolean;
  roleName: string;
  data: any;
  deleteRole: (roleId: string) => void;
  roleData: any
  className?: string;
}

export default function RoleCard({
  key,
  canEdit,
  canDelete,
  data,
  roleName,
  className,
  deleteRole,
  roleData
}: Readonly<RoleCardProps>) {
  return (
    <div
      key={key}
      className={cn(
        'border-muted rounded-lg border bg-white p-6 shadow-md poppins_font_number',
        className
      )}
    >
      <header className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <Title className="break-all font-semibold capitalize text-black sm:text-xl poppins_font_number">
            {roleName && capitalizeAndJoin(roleName)}
          </Title>
        </div>

        {(canDelete && roleData?._id !== data?._id)  && (
          <div className="flex items-center space-x-2">
            <DeletePopover
              title={`Delete the role`}
              description={`Are you sure you want to delete this role?`}
              onDelete={() => deleteRole(data?._id)}
            />
          </div>
        )}
      </header>


        <Link href={`${routes.admin.rolePermissionEdit}/${data._id}`}>
          <Button
            disabled={!canEdit || roleData?._id === data?._id}
            className="items-center gap-1 @lg:w-full lg:mt-6"
          >
            <UserCog className="h-5 w-5" />
            Edit Role
          </Button>
        </Link>
      
    </div>
  );
}
