'use client';

import WidgetCard from '@/components/cards/widget-card';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  capitalizeAndJoin,
  capitalizeFirstLetter,
  handleKeyDown,
} from '@/utils/common-functions';
import {
  CreateRoleInput,
  createRoleSchema,
} from '@/utils/validators/create-role.schema';
import React, { useEffect, useState } from 'react';
import { PiCheckBold } from 'react-icons/pi';
import {
  ADMINMODULELIST,
  checkPermission,
  permissions,
  PERMISSIONSDATA,
} from './utils';
import Spinner from '@/components/ui/spinner';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useRouter } from 'next/navigation';
import { routes } from '@/config/routes';
import cn from '@/utils/class-names';
import Link from 'next/link';
import {
  createSubRole,
  editSubRole,
  getSubRoleById,
} from '@/redux/slices/admin/roles-permissions/rolePermissionSlice';

const CreateRole = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const router = useRouter();

  const [modules, setModules] = useState<any>(ADMINMODULELIST);
  const [errorMsg, setErrorMsg] = useState<any>(
    'Please select at least one module permission'
  );

  const {
    getSubRoleByIdData,
    getSubRoleByIdLoader,
    createSubRoleLoader,
    editSubRoleLoader,
  } = useSelector((state: any) => state?.root?.adminRole);
  // const { role, permission } = useSelector((state: any) => state?.root?.signIn);

  const initialValues = {
    roleName: id ? getSubRoleByIdData?.sub_role : '',
  };

  useEffect(() => {
    setModules(ADMINMODULELIST);
  }, []);

  useEffect(() => {
    if (id) {
      dispatch(getSubRoleById(id));
      setErrorMsg(null)
    }

  }, [dispatch, id]);

  useEffect(() => {
    if (id && getSubRoleByIdData) {
      setModules(getSubRoleByIdData?.permissions);
    }
  }, [getSubRoleByIdData, id]);

  const onSubmit = (data: any) => {
    const hasViewPermission = Object?.values(modules)?.some(
      (permissions: any) => permissions['view']
    );
    if (!hasViewPermission) {
      setErrorMsg('Please select at least one module permission');
      return;
    }
    const payload = {
      sub_role: data?.roleName.trim(),
      permissions: updateIsApplicable(modules),
    };

    if (id) {
        dispatch(editSubRole({ ...payload, _id: id })).then((result: any) => {
            if (editSubRole.fulfilled.match(result)) {
                if (result.payload.success === true) {
                    router.replace(routes.admin.rolePermission);
                }
            }
        });
    } else {
        dispatch(createSubRole(payload)).then((result: any) => {
            if (createSubRole.fulfilled.match(result)) {
                if (result.payload.success === true) {
                    router.replace(routes.admin.rolePermission);
                }
            }
        });
    }
  };

  const updateModulePermission = (
    moduleName: string,
    submoduleName: string | null,
    permission: string,
    value: boolean
  ) => {
    if (modules[moduleName] && permission in modules[moduleName]) {
      if (errorMsg) {
        setErrorMsg(null);
      }

      if (['view']?.includes(permission)) {
        if (value) {
          const updatedModules = {
            ...modules,
            [moduleName]: {
              ...modules[moduleName],
              [permission]: value,
            },
          };
          setModules(updatedModules);
          return;
        } else {


          const updatedModules = {
            ...modules,
            [moduleName]: {
              ...modules[moduleName],
              [permission]: value,
            },
          };
          Object.keys(updatedModules[moduleName])?.forEach((key) => {
            updatedModules[moduleName][key] = false;
          });
          setModules(updatedModules);
          const hasViewPermission = Object?.values(updatedModules)?.some(
            (permissions: any) => permissions['view']
          );
          if (!hasViewPermission) {
            setErrorMsg('Please select at least one module permission');
          }
          return;
        }
      } else if (['create', 'update', 'delete']?.includes(permission)) {
        let updatedModules = {
          ...modules,
          [moduleName]: {
            ...modules[moduleName],
            [permission]: value,
          },
        };

        updatedModules = {
          ...updatedModules,
          [moduleName]: {
            ...updatedModules[moduleName],
            view:
              updatedModules[moduleName].create ||
              updatedModules[moduleName].update ||
              updatedModules[moduleName].delete ||
              false,
          },
        };

        const hasViewPermission = Object?.values(updatedModules)?.some(
          (permissions: any) => permissions['view']
        );
        if (!hasViewPermission) {
          setErrorMsg('Please select at least one module permission');
        }
        setModules(updatedModules);
      }
    }
  };

  const isChecked = (
    moduleName: string,
    subModuleName: string | null,
    property: string
  ) => {
    if (modules[moduleName]) {
      // Check for the main module's permission
      if (property in modules[moduleName]) {
        return modules[moduleName][property];
      }
      // Check for sub-module permissions
      if (
        subModuleName &&
        modules?.[moduleName]?.sub_modules?.[subModuleName]
      ) {
        // Check if the property exists within the sub-module
        if (property in modules[moduleName].sub_modules[subModuleName]) {
          return modules[moduleName].sub_modules[subModuleName][property];
        }
      }
    }
    return false; // Return false if no matching permission is found
  };

  const updateIsApplicable = (modules: any) => {
    return Object.fromEntries(
      Object.entries(modules).map(([moduleKey, moduleData]: any) => {
        if (moduleData.sub_modules) {
          // Update each submodule's is_applicable if it exists
          const subModules = Object.fromEntries(
            Object.entries(moduleData.sub_modules).map(
              ([subModuleKey, subModule]: any) => [
                subModuleKey,
                {
                  ...subModule,
                  ...(subModule.hasOwnProperty('is_applicable') && {
                    is_applicable: checkApplicability(subModule) || false,
                  }),
                },
              ]
            )
          );
          return [moduleKey, { ...moduleData, sub_modules: subModules }];
        }

        // Update main module's is_applicable if it exists

        return [
          moduleKey,
          {
            ...moduleData,
            ...(moduleData.hasOwnProperty('is_applicable') && {
              is_applicable: checkApplicability(moduleData) || false,
            }),
          },
        ];
      })
    );
  };

  const checkApplicability = (module: any) =>
    module.create || module.update || module.delete || module.view;

  if (getSubRoleByIdLoader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-7 lg:flex-row poppins_font_number">
      <div className="w-full">
        <WidgetCard rounded="lg" className="col-span-full px-4" title="">
          <Form<CreateRoleInput>
            onSubmit={onSubmit}
            validationSchema={createRoleSchema}
            useFormProps={{
              defaultValues: initialValues,
              mode: 'all',
            }}
            className="flex flex-grow flex-col gap-6 p-2 @container [&_.rizzui-input-label]:font-medium"
          >
            {({ register, formState: { errors, isSubmitted } }) => {
              return (
                <>
                  <div className="flex flex-col gap-4">
                    <div className="flex justify-between">
                      <div className="w-1/2 pr-2">
                        <label
                          htmlFor="roleName"
                          className="text-[14px] font-semibold"
                        >
                          Role Name *
                        </label>
                        <Input
                          id="roleName"
                          placeholder="Enter Role Name"
                          type="text"
                          color="info"
                          onKeyDown={handleKeyDown}
                          {...register('roleName')}
                          className="rounded-xl [&>label>span]:font-medium"
                          inputClassName="poppins_font_number"
                          error={errors?.roleName?.message}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="relative overflow-x-auto">
                    <table className="min-w-full border-collapse">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="break-all border p-2 text-left text-base font-bold">
                            Module
                          </th>
                          {/* <th className="break-all border p-2 text-left text-base font-bold">
                            Sub Module
                          </th> */}

                          {permissions.map(({ label }: { label: any }) => (
                            <th
                              key={label}
                              className="w-1/12 border p-2 text-center text-base font-bold"
                            >
                              {capitalizeFirstLetter(label)}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(() => {
                          if (modules && Object.keys(modules)?.length === 0) {
                            return (
                              <tr>
                                <td
                                  colSpan={permissions.length + 2}
                                  className="p-6 text-center text-gray-500"
                                >
                                  No data available
                                </td>
                              </tr>
                            );
                          }

                          return (
                            modules &&
                            Object.keys(modules)?.map((module: any) => (
                              <React.Fragment key={module}>
                                {/* {modules?.[module]?.sub_modules &&
                                Object.keys(modules?.[module]?.sub_modules)
                                  .length > 0 ? (
                                  Object.keys(
                                    modules[module]?.sub_modules
                                  )?.map((subModuleName, index: number) => (
                                    <tr key={subModuleName}>
                                      {index === 0 && (
                                        <td
                                          rowSpan={
                                            Object.keys(
                                              modules?.[module]?.sub_modules
                                            ).length
                                          }
                                          className="break-all border p-2 text-left text-base font-semibold"
                                        >
                                          {capitalizeAndJoin(module)}
                                        </td>
                                      )}
                                      <td className="break-all border p-2 text-left text-base font-semibold">
                                        {capitalizeAndJoin(subModuleName)}
                                      </td>
                                      {PERMISSIONSDATA.map(
                                        (permissionValue: string) => (
                                          <td
                                            key={permissionValue}
                                            className="border p-2 text-center"
                                          >
                                            {modules?.[module]?.sub_modules?.[
                                              subModuleName
                                            ]?.hasOwnProperty(
                                              permissionValue
                                            ) ? (
                                              <Button
                                                variant="outline"
                                                className="w-full items-center justify-center border bg-white"
                                                onClick={() =>
                                                  updateModulePermission(
                                                    module,
                                                    subModuleName,
                                                    permissionValue,
                                                    !modules[module]
                                                      ?.sub_modules?.[
                                                      subModuleName
                                                    ]?.[permissionValue]
                                                  )
                                                }
                                              >
                                                {isChecked(
                                                  module,
                                                  subModuleName,
                                                  permissionValue
                                                ) ? (
                                                  <PiCheckBold className="h-[14px] w-[14px] md:h-4 md:w-4" />
                                                ) : (
                                                  <span></span>
                                                )}
                                              </Button>
                                            ) : (
                                              <span>-</span>
                                            )}
                                          </td>
                                        )
                                      )}
                                    </tr>
                                  ))
                                ) : ( */}
                                  <tr key={module}>
                                    <td className="break-all border p-2 text-left text-base font-semibold">
                                      {module === 'agency'? 'Customer' : capitalizeAndJoin(module)}
                                    </td>
                                    {/* <td className="break-all border p-2 text-left text-base font-semibold">
                                      -
                                    </td> */}
                                    {PERMISSIONSDATA.map(
                                      (permissionValue: any) => (
                                        <td
                                          key={permissionValue}
                                          className="border p-2 text-center"
                                        >
                                          {modules?.[module]?.hasOwnProperty(
                                            permissionValue
                                          ) ? (
                                            <Button
                                              variant="outline"
                                              className="w-full items-center justify-center border bg-white"
                                              onClick={() =>
                                                updateModulePermission(
                                                  module,
                                                  null,
                                                  permissionValue,
                                                  !modules[module]?.[
                                                    permissionValue
                                                  ]
                                                )
                                              }
                                            >
                                              {isChecked(
                                                module,
                                                null,
                                                permissionValue
                                              ) ? (
                                                <PiCheckBold className="h-[14px] w-[14px] md:h-4 md:w-4" />
                                              ) : (
                                                <span></span>
                                              )}
                                            </Button>
                                          ) : (
                                            <span>-</span>
                                          )}
                                        </td>
                                      )
                                    )}
                                  </tr>
                                {/* )} */}
                              </React.Fragment>
                            ))
                          );
                        })()}
                      </tbody>
                    </table>
                    {isSubmitted && (
                      <p className="mt-0.5 text-xs text-red">{errorMsg}</p>
                    )}
                  </div>
                  <div>
                    <div
                      className={cn(
                        'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
                      )}
                    >
                      <div>
                        <Link href={routes.admin.rolePermission}>
                          <Button
                            variant="outline"
                            className="@xl:w-auto dark:hover:border-gray-400"
                          >
                            Cancel
                          </Button>
                        </Link>

                        <Button
                          type="submit"
                          className="hover:gray-700 ms-3 @xl:w-auto dark:bg-gray-200 dark:text-white"
                          disabled={
                            id ? editSubRoleLoader : createSubRoleLoader
                          }
                        >
                          {id ? 'Save Changes' : 'Create'}
                          {((id && editSubRoleLoader) ||
                            (!id && createSubRoleLoader)) && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </>
              );
            }}
          </Form>
        </WidgetCard>
      </div>
    </div>
  );
};

export default CreateRole;
