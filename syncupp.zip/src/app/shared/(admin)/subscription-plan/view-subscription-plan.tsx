'use client';

import { WidgetCard } from '@/app/admin/(hydrogen)/customer/view/agency-view-profile-form';
import { useModal } from '@/app/shared/modal-views/use-modal';
import SelectLoader from '@/components/loader/select-loader';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  getSubscriptionPlan,
  removePlanData,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import dynamic from 'next/dynamic';
import { useEffect } from 'react';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Badge, Button, Text } from 'rizzui';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

function getStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'active':
      return (
        <div className="flex items-center ps-[13px]">
          <Badge color="success" renderAsDot />
          <Text className="ms-2 font-medium text-green-dark">Active</Text>
        </div>
      );
    case 'inactive':
      return (
        <div className="flex items-center ps-[13px]">
          <Badge color="danger" renderAsDot />
          <Text className="ms-2 font-medium text-red">Inactive</Text>
        </div>
      );
    default:
      return (
        <div className="flex items-center ps-[13px]">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="ms-2 font-medium text-gray-600">{status}</Text>
        </div>
      );
  }
}

export default function ViewSubscriptionPlan(props: any) {
  const { title, row } = props;
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  const { planData, getSubscriptionPlanDataLoader } = useSelector(
    (state: any) => state?.root?.subscriptionPlan
  );

  useEffect(() => {
    row && dispatch(getSubscriptionPlan({ planId: row?._id }));
    return () => {
      dispatch(removePlanData());
    };
  }, [row, dispatch]);

  if (getSubscriptionPlanDataLoader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <div className="space-y-5 p-8">
        <div className="mb-6 flex items-center justify-between">
          <Title as="h3" className="text-xl xl:text-2xl">
            {title}
          </Title>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => closeModal()}
            className="p-0 text-gray-500 hover:!text-gray-900"
          >
            <PiXBold className="h-[18px] w-[18px]" />
          </ActionIcon>
        </div>
        <div className="mt-[20px]">
          <WidgetCard
            // title="Plan Information"
            className="mt-[20px]"
            childrenWrapperClass="py-2 px-3 @5xl:py-8 grid sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2"
          >
            <span className="col-span-2 mb-2 flex items-baseline gap-2">
              <span className="w-[15%] font-semibold text-gray-900">
                Plan Name :
              </span>
              <Text
                as="p"
                className="w-[85%] text-base font-medium capitalize @7xl:text-lg"
              >
                {planData?.name ?? ''}
              </Text>
            </span>
            <span className="col-span-2 mb-2 flex items-baseline gap-2">
              <span className="font-semibold text-gray-900">Plan Status :</span>
              <Text
                as="p"
                className="text-base font-medium capitalize @7xl:text-lg"
              >
                {getStatusBadge(planData?.active ? 'active' : 'inactive')}
              </Text>
            </span>
            <span className="col-span-2 mb-2 flex items-baseline gap-2">
              <span className="w-[15%] font-semibold text-gray-900">
                Description :
              </span>
              <Text
                as="p"
                className="flex w-[85%] gap-1 text-base font-medium @7xl:text-lg"
              >
                {planData?.description ?? 'N/A'}
              </Text>
            </span>
            <span className="col-span-2 mb-2 flex items-baseline gap-2 lg:col-span-1">
              <span className="w-[14.50%] font-semibold text-gray-900 lg:w-[30%]">
                Plan Type :
              </span>
              <Text
                as="p"
                className="w-[70%] text-base font-medium capitalize @7xl:text-lg"
              >
                {planData?.period ?? ''}
              </Text>
            </span>
            <span className="col-span-2 mb-2 flex items-baseline gap-2 lg:col-span-1">
              <span className="w-[15%] font-semibold text-gray-900 lg:w-[55%]">
                Number of users :
              </span>
              <Text
                as="p"
                className="poppins_font_number w-[45%] text-base font-normal @7xl:text-lg"
              >
                {planData?.no_of_users ?? ''}
              </Text>
            </span>
            <span className="col-span-2 mb-2 flex items-baseline gap-2 lg:col-span-1">
              <span className="w-[14.50%] font-semibold text-gray-900 lg:w-[30%]">
                Price :
              </span>
              <Text
                as="p"
                className="poppins_font_number w-[70%] text-base font-normal @7xl:text-lg"
              >
                {planData?.symbol ?? ''} {(planData?.amount ?? 0) / 100}
              </Text>
            </span>
            <span className="col-span-2 mb-2 flex items-baseline gap-2 lg:col-span-1">
              <span className="w-[15%] font-semibold text-gray-900 lg:w-[55%]">
                Number of workspaces :
              </span>
              <Text
                as="p"
                className="poppins_font_number w-[45%] text-base font-normal @7xl:text-lg"
              >
                {planData?.period !== 'lifetime'
                  ? planData?.workspaces_count
                  : planData?.period === 'lifetime'
                    ? 'Unlimited'
                    : ''}
              </Text>
            </span>
            {planData?.plan_category === 'custom' && (
              <span className="col-span-2 mb-2 flex items-baseline gap-2">
                <span className="w-[15%] font-semibold text-gray-900">
                  Allowed Users :
                </span>
                <Text
                  as="p"
                  className="flex w-[85%] flex-wrap gap-1 text-base @7xl:text-lg"
                >
                  {planData &&
                  planData?.allowed_users &&
                  planData?.allowed_users?.length > 0 ? (
                    planData?.allowed_users?.map((user: string, index: any) => {
                      return (
                        <div key={index} className="mb-1 me-1 inline-block">
                          <Button
                            size="sm"
                            tag="span"
                            variant="outline"
                            rounded="pill"
                            className="w-auto font-medium"
                          >
                            {user}
                          </Button>
                        </div>
                      );
                    })
                  ) : (
                    <span className="font-medium text-gray-1000">N/A</span>
                  )}
                </Text>
              </span>
            )}
            {planData?.plan_category === 'custom' && (
              <span className="col-span-2 mb-2 flex items-baseline gap-2">
                <span className="w-[15%] font-semibold text-gray-900">
                  Custom Link :
                </span>
                <Text
                  as="p"
                  className="flex w-[85%] gap-1 text-base @7xl:text-lg"
                >
                  {planData?.custom_link ?? 'N/A'}
                </Text>
              </span>
            )}
          </WidgetCard>
        </div>
      </div>
    );
  }
}
