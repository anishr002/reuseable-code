'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import SelectLoader from '@/components/loader/select-loader';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  addCustomSubscriptionPlan,
  getAllPlanList,
  getAllSubscriptionPlan,
  getSubscriptionPlan,
  removePlanData,
  removePlanListData,
  updateSubscriptionPlan,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  handleKeyDown,
  handleKeyNumberInputDown,
} from '@/utils/common-functions';
import {
  customSubscriptionPlanSchema,
  CustomSubscriptionPlanSchema,
} from '@/utils/validators/custom-subscription-plan.schema';
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import { Controller, SubmitHandler } from 'react-hook-form';
import { MdEmail } from 'react-icons/md';
import { PiCaretDownBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect from 'react-select';
import { Textarea } from 'rizzui';
import OrSeparation from '../../(user)/auth-layout/or-separation';
import {
  currencyOptionsDropdown,
  planTypeOptionsDropdown,
  userCountOptionsDropdown,
} from './subscription-plan-form';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

export default function CustomSubscriptionPlanForm(props: any) {
  const { title, row, isEditMode } = props;
  const dispatch = useDispatch();
  const { closeModal } = useModal();

  const [customPlan, setCustomPlan] = useState<any>({
    name: 'Select Plan',
    value: '',
    label: 'Select Plan',
  });
  const [emails, setEmails] = useState<string[]>([]);
  const [emailError, setEmailError] = useState<string>('');
  const [showWorkspaceCount, setShowWorkspaceCount] = useState(true);

  const {
    loading,
    plans,
    planData,
    paginationParams,
    addSubscriptionPlanLoader,
    updateSubscriptionPlanLoader,
    getSubscriptionPlanDataLoader,
    addCustomSubscriptionPlanLoader,
  } = useSelector((state: any) => state?.root?.subscriptionPlan);

  useEffect(() => {
    // remove plan data on first load if have
    dispatch(removePlanData());
  }, [dispatch]);

  useEffect(() => {
    !isEditMode && dispatch(getAllPlanList({ mode: 'custom' }));
    isEditMode && row && dispatch(getSubscriptionPlan({ planId: row?._id }));
    return () => {
      dispatch(removePlanData());
    };
  }, [row, isEditMode, dispatch]);

  useEffect(() => {
    if (isEditMode && planData && planData?.allowed_users?.length > 0) {
      setEmails([...planData?.allowed_users]);
      setEmailError('');
    }
  }, [isEditMode, planData?.allowed_users]);

  useEffect(() => {
    if (isEditMode && planData?.period === 'lifetime') {
      setShowWorkspaceCount(false);
    } else {
      setShowWorkspaceCount(true);
    }
  }, [planData, isEditMode]);

  const defaultValuess: CustomSubscriptionPlanSchema = {
    plan_name: planData?.name ?? '',
    plan_description: planData?.description ?? '',
    plan_type: planData?.period ?? '',
    user_count: planData?.no_of_users ? String(planData?.no_of_users) : '',
    currency: planData?.currency ?? '',
    price: planData?.amount ? String(planData?.amount / 100) : '',
    workspace_count: planData?.workspaces_count
      ? String(planData?.workspaces_count)
      : '',
  };

  // custom plans options
  let customPlansOptions: Record<string, any>[] = [];
  plans?.length > 0 &&
    plans?.map((plan: Record<string, any>) => {
      customPlansOptions.push({
        name: capitalizeFirstLetter(plan?.name),
        label: capitalizeFirstLetter(plan?.name),
        value: plan?._id,
      });
    });

  // custom plan selection dropdown css
  const customPlanSelectionDropdownStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected ? '#8c80d2' : 'white',
      color: state.isSelected ? 'white' : 'black',
    }),
  };

  const handleCustomPlanChange = (
    selectedOption: Record<string, any>,
    setCustomPlan: any,
    setValue: any
  ) => {
    console.log('selectedOption custom plan.....', selectedOption);
    if (selectedOption) {
      setCustomPlan(selectedOption);
      dispatch(getSubscriptionPlan({ planId: selectedOption?.value })).then(
        (result: any) => {
          if (getSubscriptionPlan.fulfilled.match(result)) {
            if (result?.payload?.success === true && result?.payload?.data) {
              console.log('result in get plan api....', result);
              const plan = result?.payload?.data;
              setValue('plan_name', plan?.name ?? '', { shouldValidate: true });
              setValue('plan_description', plan?.description ?? '', {
                shouldValidate: true,
              });
              setValue('plan_type', plan?.period ?? '', {
                shouldValidate: true,
              });
              setValue(
                'user_count',
                plan?.no_of_users ? String(plan?.no_of_users) : '',
                { shouldValidate: true }
              );
              setValue('currency', plan?.currency ?? '', {
                shouldValidate: true,
              });
              setValue(
                'price',
                plan?.amount ? String(plan?.amount / 100) : '',
                { shouldValidate: true }
              );
              if (plan?.period !== 'lifetime') {
                setValue(
                  'workspace_count',
                  plan?.workspaces_count ? String(plan?.workspaces_count) : '',
                  { shouldValidate: true }
                );
                setShowWorkspaceCount(true);
              } else {
                setShowWorkspaceCount(false);
              }

              if (plan?.allowed_users && plan?.allowed_users?.length > 0) {
                setEmailError('');
                setEmails([...plan?.allowed_users]);
              } else {
                setEmails([]);
              }
            }
          }
        }
      );
    } else {
      setCustomPlan({
        name: 'Select Plan',
        value: '',
        label: 'Select Plan',
      });
      setValue('plan_name', '', { shouldValidate: false });
      setValue('plan_description', '', {
        shouldValidate: false,
      });
      setValue('plan_type', '', {
        shouldValidate: false,
      });
      setValue('user_count', '', { shouldValidate: false });
      setValue('currency', '', {
        shouldValidate: false,
      });
      setValue('price', '', { shouldValidate: false });
      setShowWorkspaceCount(true);
      setValue('workspace_count', '', { shouldValidate: false });
      setEmails([]);
    }
  };

  // for handling number input
  const handleChange = (event: any, setValue: any, type: string) => {
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }
    const value = parseFloat(event.target.value);
    // if (value < 1 || value > 20 || isNaN(value)) {
    //     console.log("Trueee...");
    //     setValue('seats', 0, { shouldValidate: true });
    //     setError('seats', {
    //         message: 'Number must be between 1 and 20'
    //       });
    // } else {
    type === 'price' && setValue('price', value, { shouldValidate: true });
    type === 'workspace_count' &&
      setValue('workspace_count', value, { shouldValidate: true });
    type === 'user_count' &&
      setValue('user_count', value, { shouldValidate: true });
    // }
  };

  const onSubmit: SubmitHandler<CustomSubscriptionPlanSchema> = (data) => {
    console.log(data, '...Subscription plan data');

    if (emailError !== '' || emails?.length === 0) {
      return;
    }

    let payload: any = {
      name: data?.plan_name,
      description: data?.plan_description,
      period: data?.plan_type,
      no_of_users: Number(data?.user_count),
      currency: data?.currency,
      amount: Number(data?.price),
      // workspaces_count: Number(data?.workspace_count),
      ...(data?.plan_type !== 'lifetime' && {
        workspaces_count: Number(data?.workspace_count),
      }),
    };

    if (customPlan?.value !== '') {
      payload.plan_id = customPlan?.value;
    }

    if (emails?.length > 0) {
      payload.allowed_users = emails;
    }

    console.log(payload, '...Subscription plan payload');

    if (!isEditMode) {
      dispatch(addCustomSubscriptionPlan(payload)).then((result: any) => {
        if (addCustomSubscriptionPlan.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            dispatch(removePlanListData());
            dispatch(
              getAllSubscriptionPlan({
                ...paginationParams,
              })
            );
            closeModal();
          }
        }
      });
    } else {
      dispatch(
        updateSubscriptionPlan({ planId: planData?._id, ...payload })
      ).then((result: any) => {
        if (updateSubscriptionPlan.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            dispatch(removePlanListData());
            dispatch(getAllSubscriptionPlan({ ...paginationParams }));
            closeModal();
          }
        }
      });
    }
  };

  if (isEditMode && getSubscriptionPlanDataLoader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <Form<CustomSubscriptionPlanSchema>
        validationSchema={customSubscriptionPlanSchema}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'all',
          defaultValues: defaultValuess,
        }}
        className="date_picker_fonts p-8 [&_label]:font-medium"
      >
        {({
          register,
          control,
          formState: { errors },
          setValue,
          getValues,
        }) => {
          return (
            <div className="space-y-5">
              <div className="mb-6 flex items-center justify-between">
                <Title as="h3" className="text-xl xl:text-2xl">
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-gray-500 hover:!text-gray-900"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>
              <div className={cn('grid grid-cols-1 gap-2')}>
                {!isEditMode && (
                  <div className="flex flex-col gap-1">
                    <label htmlFor="Plan">Plan</label>
                    <ReactSelect
                      options={customPlansOptions}
                      onChange={(selectedOption: Record<string, any>) => {
                        handleCustomPlanChange(
                          selectedOption,
                          setCustomPlan,
                          setValue
                        );
                      }}
                      value={customPlan}
                      placeholder="Select Plan"
                      className="poppins_font_number react-select-options w-full"
                      classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                      styles={customPlanSelectionDropdownStyles}
                      id="task-assign"
                      isClearable={true}
                    />
                  </div>
                )}
                {!isEditMode && (
                  <OrSeparation
                    className="z-0 text-center dark:before:bg-gray-200 dark:[&>span]:bg-[#191919]"
                    title={`OR`}
                    isCenter={true}
                  />
                )}
                <Input
                  onKeyDown={handleKeyDown}
                  type="text"
                  label="Plan Name *"
                  placeholder="Enter Plan Name"
                  color="info"
                  className="[&>label>span]:font-medium"
                  {...register('plan_name')}
                  disabled={customPlan?.value !== ''}
                  error={errors?.plan_name?.message}
                />
                <Textarea
                  onKeyDown={handleKeyDown}
                  label="Description"
                  placeholder="Enter Plan Detail"
                  //   className="[&>label>span]:font-medium"
                  {...register('plan_description')}
                  disabled={customPlan?.value !== ''}
                  error={errors?.plan_description?.message}
                  color="info"
                  textareaClassName="font-[400] poppins_font_number"
                />
                <div
                  className={cn(
                    'grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                  )}
                >
                  <Controller
                    control={control}
                    name="plan_type"
                    render={({ field: { onChange, value } }) => (
                      <Select
                        // size="sm"
                        value={value}
                        onChange={(selectedOption) => {
                          onChange(selectedOption);
                          if (selectedOption === 'lifetime') {
                            setShowWorkspaceCount(false);
                            setValue('workspace_count', '', {
                              shouldValidate: false,
                            });
                          } else {
                            setShowWorkspaceCount(true);
                            setValue('workspace_count', '', {
                              shouldValidate: false,
                            });
                          }
                        }}
                        options={planTypeOptionsDropdown}
                        placeholder="Select Plan"
                        label="Plan Type *"
                        error={errors?.plan_type?.message}
                        getOptionValue={(option) => option?.value}
                        getOptionDisplayValue={(option: any) => option?.name}
                        displayValue={(value) => {
                          const displayValue = planTypeOptionsDropdown?.find(
                            (option: any) => option?.value === value
                          );
                          return displayValue ? displayValue?.name : '';
                        }}
                        dropdownClassName="poppins_font_number"
                        selectClassName="poppins_font_number"
                        disabled={customPlan?.value !== ''}
                        color="info"
                        suffix={<PiCaretDownBold className="h-3 w-3" />}
                      />
                    )}
                  />
                  {/* <Controller
                    control={control}
                    name="user_count"
                    render={({ field: { onChange, value } }) => (
                      <Select
                        // size="sm"
                        value={value}
                        onChange={onChange}
                        options={userCountOptionsDropdown}
                        label="Users *"
                        placeholder="Select number of users"
                        error={errors?.user_count?.message}
                        getOptionValue={(option) => option?.value}
                        getOptionDisplayValue={(option: any) => option?.name}
                        displayValue={(value) => {
                          const displayValue = userCountOptionsDropdown?.find(
                            (option: any) => option?.value === value
                          );
                          return displayValue ? displayValue?.name : '';
                        }}
                        dropdownClassName="poppins_font_number"
                        selectClassName="poppins_font_number"
                        disabled={customPlan?.value !== ''}
                        suffix={<PiCaretDownBold className="h-3 w-3" />}
                      />
                    )}
                  /> */}
                  <Input
                    // rounded="DEFAULT"
                    type="number"
                    min={0}
                    label="Users *"
                    className="[&>label>span]:font-medium"
                    placeholder="Enter number of users"
                    {...register('user_count')}
                    onPaste={(e) => e.preventDefault()}
                    onKeyDown={handleKeyNumberInputDown}
                    onChange={(e) => handleChange(e, setValue, 'user_count')}
                    disabled={customPlan?.value !== ''}
                    color="info"
                    error={errors?.user_count?.message as string}
                  />
                </div>
                <div
                  className={cn(
                    'grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3'
                  )}
                >
                  <Controller
                    control={control}
                    name="currency"
                    render={({ field: { onChange, value } }) => (
                      <Select
                        // size="sm"
                        label="Currency *"
                        value={value}
                        onChange={onChange}
                        options={currencyOptionsDropdown}
                        placeholder="Select Currency"
                        error={errors?.currency?.message}
                        getOptionValue={(option) => option?.value}
                        getOptionDisplayValue={(option: any) => option?.name}
                        displayValue={(value) => {
                          const displayValue = currencyOptionsDropdown?.find(
                            (option: any) => option?.value === value
                          );
                          return displayValue ? displayValue?.name : '';
                        }}
                        dropdownClassName="poppins_font_number"
                        selectClassName="poppins_font_number"
                        color="info"
                        disabled={customPlan?.value !== ''}
                        suffix={<PiCaretDownBold className="h-3 w-3" />}
                      />
                    )}
                  />
                  <Input
                    // rounded="DEFAULT"
                    type="number"
                    min={0}
                    label="Price *"
                    className="[&>label>span]:font-medium"
                    placeholder="Enter Price"
                    {...register('price')}
                    onKeyDown={handleKeyNumberInputDown}
                    onPaste={(e) => e.preventDefault()}
                    onChange={(e) => handleChange(e, setValue, 'price')}
                    disabled={customPlan?.value !== ''}
                    color="info"
                    error={errors?.price?.message as string}
                  />
                  {showWorkspaceCount && (
                    <Input
                      // rounded="DEFAULT"
                      type="number"
                      min={0}
                      label="Workspaces *"
                      className="[&>label>span]:font-medium"
                      placeholder="Enter number of workspace"
                      {...register('workspace_count')}
                      onPaste={(e) => e.preventDefault()}
                      onKeyDown={handleKeyNumberInputDown}
                      onChange={(e) =>
                        handleChange(e, setValue, 'workspace_count')
                      }
                      disabled={customPlan?.value !== ''}
                      color="info"
                      error={errors?.workspace_count?.message as string}
                    />
                  )}
                </div>
                <div>
                  <ItemCrud
                    name="Email"
                    items={emails}
                    setItems={setEmails}
                    emailError={emailError}
                    setEmailError={setEmailError}
                  />
                </div>
              </div>
              <div>
                <div
                  className={cn(
                    'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
                  )}
                >
                  <Button
                    variant="outline"
                    className="@xl:w-auto dark:hover:border-gray-400"
                    onClick={() => closeModal()}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="hover:gray-700 @xl:w-auto dark:bg-gray-200 dark:text-white"
                    disabled={
                      addCustomSubscriptionPlanLoader ||
                      updateSubscriptionPlanLoader
                    }
                    onClick={() => {
                      emails?.length === 0
                        ? setEmailError('At least one user is required')
                        : setEmailError('');
                    }}
                  >
                    Save
                    {(addCustomSubscriptionPlanLoader ||
                      updateSubscriptionPlanLoader) && (
                      <Spinner
                        size="sm"
                        tag="div"
                        className="ms-3"
                        color="white"
                      />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          );
        }}
      </Form>
    );
  }
}

function ItemCrud(props: any): JSX.Element {
  const { name, items, setItems, emailError, setEmailError } = props;
  const [itemText, setItemText] = useState<string>('');

  useEffect(() => {
    if (itemText === '') {
      setEmailError('');
    }
  }, [itemText]);

  // Custom email validation function
  const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  function handleItemAdd(): void {
    if (itemText.trim() !== '') {
      const newItem: string = itemText.trim();

      // Validate email
      if (isValidEmail(newItem)) {
        setItems([...items, newItem]);
        setItemText('');
        setEmailError('');
      } else {
        setEmailError('Please enter a valid email address');
      }
    }
  }

  function handleItemRemove(text: string): void {
    const updatedItems = items?.filter((item: any) => item !== text);
    setItems(updatedItems);
  }

  return (
    <div>
      <div className="flex items-end">
        <Input
          value={itemText}
          onKeyDown={handleKeyDown}
          label="Allowed Users *"
          placeholder={`Enter an ${name}`}
          onChange={(e) => {
            setItemText(e.target.value);
          }}
          prefix={<MdEmail className="h-4 w-4" />}
          className="w-full [&>label>span]:font-medium"
          color="info"
        />
        <Button
          onClick={handleItemAdd}
          className="ms-4 shrink-0 text-sm @lg:ms-5 dark:bg-gray-100 dark:text-white dark:active:bg-gray-100"
        >
          Add {name}
        </Button>
      </div>

      {/* Display error message if validation fails */}
      {emailError && emailError !== '' && (
        <div className="pt-[1px] text-[12px] text-[#EE0000]">{emailError}</div>
      )}

      {items && items?.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {items?.map((text: any, index: any) => (
            <div
              key={index}
              className="flex items-center rounded-full border border-gray-300 py-1 pe-2.5 ps-3 text-sm font-medium text-gray-700"
            >
              {text}
              <button
                onClick={() => handleItemRemove(text)}
                className="ps-2 text-gray-500 hover:text-gray-900"
              >
                <PiXBold className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
