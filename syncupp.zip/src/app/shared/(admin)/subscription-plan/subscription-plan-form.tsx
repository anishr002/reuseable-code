'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import SelectLoader from '@/components/loader/select-loader';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  addSubscriptionPlan,
  getAllSubscriptionPlan,
  getSubscriptionPlan,
  removePlanData,
  removePlanListData,
  updateSubscriptionPlan,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import cn from '@/utils/class-names';
import {
  handleKeyDown,
  handleKeyNumberInputDown,
} from '@/utils/common-functions';
import {
  subscriptionPlanSchema,
  SubscriptionPlanSchema,
} from '@/utils/validators/create-subscription-plan.schema';
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import { Controller, SubmitHandler } from 'react-hook-form';
import { PiCaretDownBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Textarea } from 'rizzui';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

export const planTypeOptionsDropdown: Record<string, string>[] = [
  { name: 'Quarterly', value: 'quarterly' },
  { name: 'Monthly', value: 'monthly' },
  { name: 'Yearly', value: 'yearly' },
  { name: 'Lifetime', value: 'lifetime' },
];

export const userCountOptionsDropdown: Record<string, any>[] = [
  { name: '10', value: '10' },
  { name: '25', value: '25' },
  { name: '50', value: '50' },
  { name: '100', value: '100' },
];

export const currencyOptionsDropdown: Record<string, any>[] = [
  { name: '$ Dollar', value: 'USD' },
  { name: '₹ Rupees', value: 'INR' },
];

export default function SubscriptionPlanForm(props: any) {
  const { title, row, isEditMode } = props;
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const [showWorkspaceCount, setShowWorkspaceCount] = useState(true);

  const {
    loading,
    planData,
    paginationParams,
    addSubscriptionPlanLoader,
    updateSubscriptionPlanLoader,
    getSubscriptionPlanDataLoader,
  } = useSelector((state: any) => state?.root?.subscriptionPlan);

  useEffect(() => {
    row && dispatch(getSubscriptionPlan({ planId: row?._id }));
    return () => {
      dispatch(removePlanData());
    };
  }, [row, dispatch]);

  useEffect(() => {
    if (isEditMode && planData?.period === 'lifetime') {
      setShowWorkspaceCount(false);
    } else {
      setShowWorkspaceCount(true);
    }
  }, [planData, isEditMode]);

  const defaultValuess: SubscriptionPlanSchema = {
    plan_name: planData?.name ?? '',
    plan_description: planData?.description ?? '',
    plan_type: planData?.period ?? '',
    user_count: planData?.no_of_users ? String(planData?.no_of_users) : '',
    currency: planData?.currency ?? '',
    price: planData?.amount ? String(planData?.amount / 100) : '',
    workspace_count: planData?.workspaces_count
      ? String(planData?.workspaces_count)
      : '',
  };

  // for handling number input
  const handleChange = (event: any, setValue: any, type: string) => {
    if (event.key === ' ' && event.target.selectionStart === 0) {
      event.preventDefault();
    }
    const value = parseFloat(event.target.value);
    // if (value < 1 || value > 20 || isNaN(value)) {
    //     console.log("Trueee...");
    //     setValue('seats', 0, { shouldValidate: true });
    //     setError('seats', {
    //         message: 'Number must be between 1 and 20'
    //       });
    // } else {
    type === 'price' && setValue('price', value, { shouldValidate: true });
    type === 'user_count' &&
      setValue('user_count', value, { shouldValidate: true });
    type === 'workspace_count' &&
      setValue('workspace_count', value, { shouldValidate: true });
    // }
  };

  const onSubmit: SubmitHandler<SubscriptionPlanSchema> = (data) => {
    console.log(data, '...Subscription plan data');

    const payload = {
      name: data?.plan_name,
      description: data?.plan_description,
      period: data?.plan_type,
      no_of_users: Number(data?.user_count),
      currency: data?.currency,
      amount: Number(data?.price),
      // workspaces_count: Number(data?.workspace_count),
      ...(data?.plan_type !== 'lifetime' && {
        workspaces_count: Number(data?.workspace_count),
      }),
    };

    console.log(payload, '...Subscription plan payload');

    if (!isEditMode) {
      dispatch(addSubscriptionPlan(payload)).then((result: any) => {
        if (addSubscriptionPlan.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            dispatch(removePlanListData());
            dispatch(
              getAllSubscriptionPlan({
                ...paginationParams,
              })
            );
            closeModal();
          }
        }
      });
    } else {
      dispatch(
        updateSubscriptionPlan({ planId: planData?._id, ...payload })
      ).then((result: any) => {
        if (updateSubscriptionPlan.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            dispatch(removePlanListData());
            dispatch(getAllSubscriptionPlan({ ...paginationParams }));
            closeModal();
          }
        }
      });
    }
  };

  if (isEditMode && getSubscriptionPlanDataLoader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <Form<SubscriptionPlanSchema>
        validationSchema={subscriptionPlanSchema}
        onSubmit={onSubmit}
        useFormProps={{
          mode: 'all',
          defaultValues: defaultValuess,
        }}
        className="date_picker_fonts p-8 [&_label]:font-medium"
      >
        {({ register, control, formState: { errors }, setValue }) => {
          return (
            <div className="space-y-5">
              <div className="mb-6 flex items-center justify-between">
                <Title as="h3" className="text-xl xl:text-2xl">
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-gray-500 hover:!text-gray-900"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>
              <div className={cn('grid grid-cols-1 gap-4')}>
                <Input
                  onKeyDown={handleKeyDown}
                  type="text"
                  label="Plan Name *"
                  placeholder="Enter Plan Name"
                  className="[&>label>span]:font-medium"
                  {...register('plan_name')}
                  error={errors?.plan_name?.message}
                />
                <Textarea
                  onKeyDown={handleKeyDown}
                  label="Description"
                  placeholder="Enter Plan Detail"
                  //   className="[&>label>span]:font-medium"
                  {...register('plan_description')}
                  error={errors?.plan_description?.message}
                  textareaClassName="font-[400] poppins_font_number"
                />
                <div
                  className={cn(
                    'grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                  )}
                >
                  <Controller
                    control={control}
                    name="plan_type"
                    render={({ field: { onChange, value } }) => (
                      <Select
                        // size="sm"
                        value={value}
                        onChange={(selectedOption) => {
                          onChange(selectedOption);
                          if (selectedOption === 'lifetime') {
                            setShowWorkspaceCount(false);
                            setValue('workspace_count', '', {
                              shouldValidate: false,
                            });
                          } else {
                            setShowWorkspaceCount(true);
                            setValue('workspace_count', '', {
                              shouldValidate: false,
                            });
                          }
                        }}
                        options={planTypeOptionsDropdown}
                        placeholder="Select Plan"
                        label="Plan Type *"
                        error={errors?.plan_type?.message}
                        getOptionValue={(option) => option?.value}
                        getOptionDisplayValue={(option: any) => option?.name}
                        displayValue={(value) => {
                          const displayValue = planTypeOptionsDropdown?.find(
                            (option: any) => option?.value === value
                          );
                          return displayValue ? displayValue?.name : '';
                        }}
                        dropdownClassName="poppins_font_number"
                        selectClassName="poppins_font_number"
                        suffix={<PiCaretDownBold className="h-3 w-3" />}
                      />
                    )}
                  />
                  {/* <Controller
                    control={control}
                    name="user_count"
                    render={({ field: { onChange, value } }) => (
                      <Select
                        // size="sm"
                        value={value}
                        onChange={onChange}
                        options={userCountOptionsDropdown}
                        label="Users *"
                        placeholder="Select number of users"
                        error={errors?.user_count?.message}
                        getOptionValue={(option) => option?.value}
                        getOptionDisplayValue={(option: any) => option?.name}
                        displayValue={(value) => {
                          const displayValue = userCountOptionsDropdown?.find(
                            (option: any) => option?.value === value
                          );
                          return displayValue ? displayValue?.name : '';
                        }}
                        dropdownClassName="poppins_font_number"
                        selectClassName="poppins_font_number"
                        suffix={<PiCaretDownBold className="h-3 w-3" />}
                      />
                    )}
                  /> */}
                  <Input
                    // rounded="DEFAULT"
                    type="number"
                    min={0}
                    label="Users *"
                    className="[&>label>span]:font-medium"
                    placeholder="Enter number of users"
                    {...register('user_count')}
                    onKeyDown={handleKeyNumberInputDown}
                    onPaste={(e) => e.preventDefault()}
                    onChange={(e) => handleChange(e, setValue, 'user_count')}
                    error={errors?.user_count?.message as string}
                  />
                </div>
                <div
                  className={cn(
                    'grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3'
                  )}
                >
                  <Controller
                    control={control}
                    name="currency"
                    render={({ field: { onChange, value } }) => (
                      <Select
                        // size="sm"
                        label="Currency *"
                        value={value}
                        onChange={onChange}
                        options={currencyOptionsDropdown}
                        placeholder="Select Currency"
                        error={errors?.currency?.message}
                        getOptionValue={(option) => option?.value}
                        getOptionDisplayValue={(option: any) => option?.name}
                        displayValue={(value) => {
                          const displayValue = currencyOptionsDropdown?.find(
                            (option: any) => option?.value === value
                          );
                          return displayValue ? displayValue?.name : '';
                        }}
                        dropdownClassName="poppins_font_number"
                        selectClassName="poppins_font_number"
                        suffix={<PiCaretDownBold className="h-3 w-3" />}
                      />
                    )}
                  />
                  <Input
                    // rounded="DEFAULT"
                    type="number"
                    min={0}
                    label="Price *"
                    className="[&>label>span]:font-medium"
                    placeholder="Enter Price"
                    {...register('price')}
                    onKeyDown={handleKeyNumberInputDown}
                    onPaste={(e) => e.preventDefault()}
                    onChange={(e) => handleChange(e, setValue, 'price')}
                    error={errors?.price?.message as string}
                  />
                  {showWorkspaceCount && (
                    <Input
                      // rounded="DEFAULT"
                      type="number"
                      min={0}
                      label="Workspaces *"
                      className="[&>label>span]:font-medium"
                      placeholder="Enter number of workspace"
                      {...register('workspace_count')}
                      onPaste={(e) => e.preventDefault()}
                      onKeyDown={handleKeyNumberInputDown}
                      onChange={(e) =>
                        handleChange(e, setValue, 'workspace_count')
                      }
                      error={errors?.workspace_count?.message as string}
                    />
                  )}
                </div>
              </div>
              <div>
                <div
                  className={cn(
                    'grid gap-2 pt-5 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2'
                  )}
                >
                  <Button
                    variant="outline"
                    className="@xl:w-auto dark:hover:border-gray-400"
                    onClick={() => closeModal()}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="hover:gray-700 @xl:w-auto dark:bg-gray-200 dark:text-white"
                    disabled={
                      addSubscriptionPlanLoader || updateSubscriptionPlanLoader
                    }
                  >
                    Save
                    {(addSubscriptionPlanLoader ||
                      updateSubscriptionPlanLoader) && (
                      <Spinner
                        size="sm"
                        tag="div"
                        className="ms-3"
                        color="white"
                      />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          );
        }}
      </Form>
    );
  }
}
