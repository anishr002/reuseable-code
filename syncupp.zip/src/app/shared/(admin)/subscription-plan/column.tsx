'use client';

import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import {
  getAllSubscriptionPlan,
  removePlanListData,
  updateSubscriptionPlan,
} from '@/redux/slices/admin/subscription-plan/subscriptionPlanSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Badge, Switch } from 'rizzui';
import CustomModalButton from '../../custom-modal-button';
import DeletePopover from '../../delete-popover';
import CustomSubscriptionPlanForm from './custom-subscription-plan-form';
import SubscriptionPlanForm from './subscription-plan-form';
import ViewSubscriptionPlan from './view-subscription-plan';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

function getStatusBadge(status: string) {
  switch (status?.toLowerCase()) {
    case 'active':
      return (
        <div className="flex items-center px-5">
          <Badge color="success" renderAsDot />
          <Text className="ms-2 font-medium text-green-dark">Active</Text>
        </div>
      );
    case 'inactive':
      return (
        <div className="flex items-center px-5">
          <Badge color="danger" renderAsDot />
          <Text className="ms-2 font-medium text-red">Inactive</Text>
        </div>
      );
    default:
      return (
        <div className="flex items-center px-5">
          <Badge renderAsDot className="bg-gray-400" />
          <Text className="ms-2 font-medium text-gray-600">{status}</Text>
        </div>
      );
  }
}

export const GetSubscriptionPlanColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const { paginationParams, updateSubscriptionPlanLoader } = useSelector(
    (state: any) => state?.root?.subscriptionPlan
  );
  const dispatch = useDispatch();
  const { userData } = useSelector((state: any) => state?.root?.adminSignIn);
  const roleData = userData?.data?.user?.role;

  // Handle plan status function
  const handleSwitchChange = async (
    id: string,
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    try {
      dispatch(
        updateSubscriptionPlan({
          planId: id,
          active: event?.target?.checked,
          status_update: true,
        })
      ).then((result: any) => {
        if (updateSubscriptionPlan.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            dispatch(removePlanListData());
            dispatch(getAllSubscriptionPlan({ ...paginationParams }));
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  return [
    {
      title: (
        <div className="ps-3.5">
          <HeaderCell
            title="Plan Name"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('name'),
      dataIndex: 'name',
      key: 'name',
      width: 200,
      render: (value: string) => (
        <Text className="ps-4 poppins_font_number font-normal capitalize text-gray-700">
          {value}
        </Text>
      ),
    },
    {
      title: (
        <div className="ps-3.5">
          <HeaderCell
            title="Plan Category"
            sortable
            ascending={
              sortConfig?.direction === 'asc' &&
              sortConfig?.key === 'plan_category'
            }
          />
        </div>
      ),
      onHeaderCell: () => onHeaderCellClick('plan_category'),
      dataIndex: 'plan_category',
      key: 'plan_category',
      width: 200,
      render: (value: string) => (
        <Text className="ps-4 poppins_font_number font-normal capitalize text-gray-700">
          {value}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Plan Type"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'period'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('period'),
      dataIndex: 'period',
      key: 'period',
      width: 200,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">{value}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Users"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'no_of_users'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('no_of_users'),
      dataIndex: 'no_of_users',
      key: 'no_of_users',
      width: 150,
      render: (value: number) => {
        return (
          <>
            {value ? (
              <Text className="poppins_font_number font-normal text-gray-700">
                {value}
              </Text>
            ) : (
              <Text className="poppins_font_number font-normal text-gray-700">
                -
              </Text>
            )}
          </>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Price"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'amount'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('amount'),
      dataIndex: 'amount',
      key: 'amount',
      width: 150,
      render: (_: string, row: any) => {
        return (
          <>
            {row?.amount ? (
              <Text className="poppins_font_number font-normal text-gray-700">
                {row?.symbol} {row?.amount / 100}
              </Text>
            ) : (
              <Text className="poppins_font_number font-normal text-gray-700">
                -
              </Text>
            )}
          </>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Workspaces"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'workspaces_count'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('workspaces_count'),
      dataIndex: 'workspaces_count',
      key: 'workspaces_count',
      width: 150,
      render: (value: number, row: Record<string, any>) => {
        return (
          <>
            {row?.period !== 'lifetime' && value ? (
              <Text className="poppins_font_number font-normal text-gray-700">
                {value}
              </Text>
            ) : row?.period === 'lifetime' ? (
              <Text className="poppins_font_number font-normal text-gray-700">
                Unlimited
              </Text>
            ) : (
              <Text className="poppins_font_number font-normal text-gray-700">
                -
              </Text>
            )}
          </>
        );
      },
    },
    {
      title: (
        <HeaderCell
          title="Status"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'active'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('active'),
      dataIndex: 'active',
      key: 'active',
      width: 200,
      render: (_: string, row: any) => (
          <div className="flex ">
            {/* <Text className="font-medium text-gray-700">{value}</Text> */}
            {roleData?.sub_role === 'super_admin' && (
              <Switch
                className="[&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                variant="active"
                onChange={(event) => handleSwitchChange(row?._id, event)}
                // disabled={updateSubscriptionPlanLoader}
                defaultChecked={row?.active}
              />
            )}
            {getStatusBadge(row?.active ? 'active' : 'inactive')}
          </div>
      ),
    },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions" />,
      dataIndex: 'action',
      key: 'action',
      width: 100,
      render: (_: string, row: any) => {
        return (
          <div className="flex items-center gap-3 pe-4">
            <CustomModalButton
              icon={<EyeIcon className="h-4 w-4" />}
              view={<ViewSubscriptionPlan title="Plan Information" row={row} />}
              customSize="725px"
              title="View Plan"
            />
            {row?.plan_category === 'custom' &&
            roleData?.sub_role === 'super_admin' ? (
              <CustomModalButton
                title="Edit Plan"
                icon={<PencilIcon className="h-4 w-4" />}
                view={
                  <CustomSubscriptionPlanForm
                    title="Edit Plan"
                    row={row}
                    isEditMode={true}
                  />
                }
                customSize="600px"
              />
            ) : (
              <>
                {roleData?.sub_role === 'super_admin' && (
                  <CustomModalButton
                    title="Edit Plan"
                    icon={<PencilIcon className="h-4 w-4" />}
                    view={
                      <SubscriptionPlanForm
                        title="Edit Plan"
                        row={row}
                        isEditMode={true}
                      />
                    }
                    customSize="600px"
                  />
                )}
              </>
            )}

            {roleData?.sub_role === 'super_admin' && (
              <DeletePopover
                title={`Delete the Subscription Plan`}
                description={`Are you sure you want to delete?`}
                onDelete={() =>
                  onDeleteItem(
                    row._id,
                    currentPage,
                    pageSize,
                    data?.length <= 1 ? true : false,
                    sortConfig,
                    searchTerm
                  )
                }
              />
            )}
          </div>
        );
      },
    },
  ];
};
