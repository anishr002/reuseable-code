import React from 'react'
import { PiXBold } from 'react-icons/pi'
import { ActionIcon } from 'rizzui'
import { useModal } from '../../modal-views/use-modal';
import { AgrementFormTypes } from '@/utils/validators/agreement.schema';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import Image from 'next/image';
import SimpleBar from 'simplebar-react';


const ViewAgreement = ({ formValues, scroll }: { formValues: any; scroll?: any }) => {

  const { closeModal, openModal } = useModal();
  const imageUrl =
    typeof formValues?.agreement_logo === "string" &&
      formValues?.agreement_logo.startsWith("uploads/")
      ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${formValues?.agreement_logo}`
      : formValues?.agreement_logo instanceof File
        ? URL.createObjectURL(formValues?.agreement_logo)
        : null;



  const replaceReferences = (content: any, assets: any) => {
    return content?.replace(/\[(Image|Sign|File) Reference: (.*?)\]/g, (match: any, type: any, fileName: any) => {
      const asset = assets?.find((item: any) => item.file_original_name === fileName);
      if (!asset) return match; // If asset not found, keep reference as-is.

      if (type === "Image") {
        return `<img src="${process.env.NEXT_PUBLIC_API}/${asset?.file_name}" alt="${fileName}" style="width: 200px; height: 200px; object-fit: contain;">`;
      } else if (type === "Sign") {
        return `<img src="${process.env.NEXT_PUBLIC_API}/${asset?.file_name}" alt="${fileName}" id="signature-image" style="width: 100px; height: 50px; object-fit: contain;">`;
      } else if (type === "File") {
        return `<a href="${process.env.NEXT_PUBLIC_IMAGE_URL}/${asset?.file_name}" download>${fileName}</a>`;
      }

      return match; // Fallback in case of any issues
    });
  };
  return (

    <div className=' flex flex-col'>
      {scroll ?
        <SimpleBar className='max-h-[480px] pe-4'>
          <div className='p-10 space-y-3'>
            <div className='flex justify-between items-center pb-2'>
              <div>
                {imageUrl ? (
                  <Image
                    alt="img"
                    className="mr-3"
                    src={imageUrl}
                    width={100}
                    height={100}
                  />
                ) : null}
              </div>
              <div className='flex items-end text-[#11181C] font-semibold leading-4 text-sm'>{formValues?.title}</div>
            </div>
            <hr className="border-t-2 py-2 border-[#D1D5DB]" />
            <div className='pb-2 text-black'>
              {formValues?.description}
            </div>
            <div className='pb-2 text-black'>
              {formValues?.agreement_doc?.file_name && (
                <a
                  href={
                    formValues?.agreement_doc?.file_name?.startsWith("uploads/")
                      ? `${process.env.NEXT_PUBLIC_API}/${formValues?.agreement_doc?.file_name}`
                      : "#"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 underline"
                >
                  {formValues?.agreement_doc?.file_name?.startsWith("uploads/")
                    ? `view PDF: ${formValues?.agreement_doc?.file_original_name}`
                    : "PDF File"}
                </a>
              )}
            </div>
            <div className='pb-3 text-black'>
              <div
                className="rendered-content"
                dangerouslySetInnerHTML={{
                  __html:
                    formValues?.body || replaceReferences(formValues?.agreement_content, formValues?.agreement_content_file) || "",
                }}
              />
            </div>
            <hr className="border-t-2 py-2 border-[#D1D5DB]" />
            <div >
              <div className="flex gap-3 items-center pb-3">
                <span className="text-sm font-medium text-[#141414]">
                  Created with
                </span>
                <Image
                  src={syncUppLogo}
                  alt="Syncupp"
                  width={100}
                  height={100}
                  className="h-7 w-[60px]"
                />
              </div>
            </div>
          </div>
        </SimpleBar> :
        <div className='p-10 space-y-3'>
        <div className='flex justify-between items-center pb-2'>
          <div>
            {imageUrl ? (
              <Image
                alt="img"
                className="mr-3"
                src={imageUrl}
                width={100}
                height={100}
              />
            ) : null}
          </div>
          <div className='flex items-end text-[#11181C] font-semibold leading-4 text-sm'>{formValues?.title}</div>
        </div>
        <hr className="border-t-2 py-2 border-[#D1D5DB]" />
        <div className='pb-2 text-black'>
          {formValues?.description}
        </div>
        <div className='pb-2 text-black'>
          {formValues?.agreement_doc?.file_name && (
            <a
              href={
                formValues?.agreement_doc?.file_name?.startsWith("uploads/")
                  ? `${process.env.NEXT_PUBLIC_API}/${formValues?.agreement_doc?.file_name}`
                  : "#"
              }
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-500 underline"
            >
              {formValues?.agreement_doc?.file_name?.startsWith("uploads/")
                ? `view PDF: ${formValues?.agreement_doc?.file_original_name}`
                : "PDF File"}
            </a>
          )}
        </div>
        <div className='pb-3 text-black'>
          <div
            className="rendered-content"
            dangerouslySetInnerHTML={{
              __html:
                formValues?.body || replaceReferences(formValues?.agreement_content, formValues?.agreement_content_file) || "",
            }}
          />
        </div>
        <hr className="border-t-2 py-2 border-[#D1D5DB]" />
        <div >
          <div className="flex gap-3 items-center pb-3">
            <span className="text-sm font-medium text-[#141414]">
              Created with
            </span>
            <Image
              src={syncUppLogo}
              alt="Syncupp"
              width={100}
              height={100}
              className="h-7 w-[60px]"
            />
          </div>
        </div>
      </div>
}
    </div>

  )
}

export default ViewAgreement
