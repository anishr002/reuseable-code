import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getSingleagreement, removeAgreementdetails } from '@/redux/slices/user/agreement/agreementSlice';
import Spinner from '@/components/ui/spinner';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { routes } from '@/config/routes';
import ViewAgreement from './ViewAgreement';
import { RxCross2 } from 'react-icons/rx';


const ViewTemplate = ({ tempId, onClose }: { tempId: any; onClose: any }) => {
    const dispatch = useDispatch();
    const pageHeader = {
        title: 'View Template',
    }
    const { singleAgreementdetails, loading, singleagreementloader } = useSelector((state: any) => state?.root?.agreement);
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace);

    useEffect(() => {
        if (tempId) {
            const obj = {
                _id: tempId,
                isTemplate: true
            };
            dispatch(getSingleagreement(obj));
        }
    }, [tempId]);

    if (singleagreementloader) {
        return (
            <div className='p-10 flex items-center justify-center'>
                <Spinner size="xl" tag='div' />
            </div>
        )
    }
    return (
        <div className='p-10'>
            <CustomePageHeader
                title={pageHeader.title}
                titleClassName="montserrat_font_title"
            >
                <RxCross2
                    className="ml-auto h-8 w-8 text-[#11181C] cursor-pointer"
                    onClick={onClose}
                />
            </CustomePageHeader>

            <ViewAgreement formValues={singleAgreementdetails?.data} scroll={true} />
        </div>
    )
}

export default ViewTemplate
