import React, { useState } from 'react'
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useForm, useFieldArray, SubmitHandler } from 'react-hook-form';
import { messages } from '@/config/messages';
import { useRouter } from 'next/navigation';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';
import { addSigner, createagreement } from '@/redux/slices/user/agreement/agreementSlice';
import { useDispatch } from 'react-redux';
import { any } from 'prop-types';
import { idText } from 'typescript';
import Spinner from "@/components/ui/spinner";


export const AddSigner = ({ file, number, templateData }: any) => {
    const router = useRouter()
    const dispatch = useDispatch()

    const { defaultWorkSpace } = useSelector(
        (state: any) => state?.root?.workspace
    );
    const { agreementId, loading } = useSelector(
        (state: any) => state?.root?.agreement
    );

    interface SignerData {
        emails: { value: string }[];  // Adjust this to use objects for emails with id and value
        // message: string;
    }

    const initialValues: SignerData = {
        emails: [{ value: '' }]
        // , message: '' 
    };

    const {
        register,
        control,
        handleSubmit,
        formState: { errors }
    } = useForm<SignerData>({
        mode: 'onChange',
        defaultValues: initialValues
    });

    // Using useFieldArray to dynamically manage email inputs
    const { fields, append, remove } = useFieldArray({
        control,
        name: 'emails'

    });

    // Handle form submission
    const onSubmit = (data: any) => {
        const signers = data?.emails?.map((signer: any) => signer.value)
        const formData = new FormData();

        formData.append("send", "true");
        file && formData.append("agreement_doc", file);
        formData.append("signers", JSON.stringify(signers))
        templateData && formData.append("template_id", templateData?._id)

        if (!file && !templateData) {
            dispatch(addSigner({ agreementId, signers })).then((result: any) => {
                console.log(result, "result api");
                if (result.payload?.success === true) {
                    router.push(routes.agreement(defaultWorkSpace?.name));
                }
            })
        } else {
            dispatch(createagreement(formData)).then((result: any) => {
                if (createagreement.fulfilled.match(result) && result.payload?.success === true) {
                    router.push(routes.agreement(defaultWorkSpace?.name));
                }
            });
        }
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div>
                <div className='flex flex-col gap-6'>
                    <div className='flex gap-2 items-center text-[#111928] font-bold text-[18px]'>
                        {number && (<span className='bg-[#E5E7EB] rounded-full px-3.5 py-2 poppins_font_number'>2</span>)}
                        <p className='text-[#4B5563] text-[16px] font-semibold'>
                            Add Signee & send invite
                        </p>
                    </div>

                    <div className="flex flex-col gap-2.5 border border-dashed border-[#CBD0DC] bg-[#F8F9FB] p-4 rounded-lg">
                        {fields.map((field, index: number) => (
                            <div key={index} className="">
                                <span className='text-black text-[16px] font-medium poppins_font_number'>
                                    {index + 1} {`Signee's Email`}
                                </span>
                                <div className='w-full flex gap-4'>
                                    <div className='w-[75%]'>
                                        <Input
                                            type="email"
                                            placeholder="Add Email address"
                                            inputClassName='popins_font_number bg-white font-normal text-[16px] text-black'
                                            className=" border-[#E9E9E9] w-full mt-1 rounded-lg relative"
                                            {...register(`emails.${index}.value`, {
                                                required: { value: true, message: messages.emailIsRequired },  // Custom message for required
                                                pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: messages.invalidEmail },  // Custom message for invalid email
                                            })}
                                            error={errors?.emails?.[index]?.value ? errors?.emails[index]?.value?.message : ''}
                                        />

                                    </div>
                                    {fields.length > 1 && (
                                        <div
                                            className='btn w-[25%] bg-transparent text-[#FF3B30] font-normal text-[16px] cursor-pointer pt-4'
                                            onClick={() => remove(index)}
                                        >
                                            Remove Signee
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                        <div className="mt-4">
                            <button
                                type='button'
                                className='bg-white text-[#111928] text-[14px] font-medium border-[#E5E7EB] border-[1px] rounded-lg px-4 py-2'
                                onClick={() => {
                                    if (fields.length < 5) {
                                        append({ value: '' });
                                    }
                                }}
                                disabled={fields.length >= 5}
                            >
                                Add another signee
                            </button>
                        </div>
                    </div>
                    {/* <div>
                        <span className='text-black text-[16px] font-medium'>
                            Message (Optional)
                        </span>
                        <Input
                            type="text"
                            className="border-gray-300 bg-white rounded-lg text-[#141414] mt-2.5"
                            placeholder="Hi, please sign the documents attached."
                            {...register("message")}
                        />
                    </div> */}
                    <div className='flex gap-3'>
                        <Button
                            type='button'
                            onClick={() => {
                                router.push(routes.agreement(defaultWorkSpace?.name));
                            }}
                            className='w-[70px] bg-white text-[#111928] font-normal border-[#E5E7EB] rounded-lg'>
                            Cancel
                        </Button>
                        <Button
                            type='submit'
                            disabled={loading}
                            className='w-auto bg-[#7667CF] text-white font-normal border-[#E5E7EB] rounded-lg'>
                            Send Agreement
                            {loading && (
                                <Spinner size="sm" tag="div" className="ms-3" color="white" />
                            )}
                        </Button>
                    </div>
                </div>
            </div>
        </form>
    );
}
export default AddSigner;

