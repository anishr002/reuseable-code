import React, { useState } from 'react'
import ViewAgreement from './ViewAgreement'
import { ActionIcon } from 'rizzui'
import { PiXBold } from 'react-icons/pi'
import { useModal } from '../../modal-views/use-modal'
import { AgrementFormTypes } from '@/utils/validators/agreement.schema'

const PreviewAgreement = ({ formValues }: { formValues: AgrementFormTypes  }) => {
  const { closeModal, openModal } = useModal();
  const [scroll ,setScroll] =useState<any>(true)

  return (
    <div className='rounded-none'>
      
      <div className="flex items-center justify-end ">
        <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="p-0 text-[#ffffff] ml-6 pb-6 "
        >
          <PiXBold className="h-[28px] w-[28px] bg-[#4B5563]  p-1 rounded-full" />
        </ActionIcon>
      </div>
      <ViewAgreement formValues={formValues} scroll={scroll}  />

    </div>
  )
}

export default PreviewAgreement
