import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { routes } from '@/config/routes';
import { useRouter } from 'next/navigation';
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Button } from '@/components/ui/button';
import cn from '@/utils/class-names';
import { Title } from 'rizzui';
import syncUppLogo from '@public/assets/images/logo_icon.png';
import { setSigner } from '@/redux/slices/user/agreement/agreementSlice';
import { FiUpload } from 'react-icons/fi';
import ChooseTemp from './ChooseTemp';
import { useModal } from '../../modal-views/use-modal';

const pageHeader = {
  title: 'New Agreement',
};

const TemplateSeleceted = ({ templateData, setTemplateData }: any) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { closeModal, openModal } = useModal();

  return (
    <>
      <div>
        <CustomePageHeader
          title={pageHeader.title}
          titleClassName="montserrat_font_title"
          route={routes.agreement(defaultWorkSpace?.name)}
        ></CustomePageHeader>
      </div>
      <div className="h-auto w-full rounded-[10px] bg-white p-4">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-[#E5E7EB] px-3.5  py-2">1</span>
              <p className="text-[16px] font-semibold text-[#4B5563]">
                Create new document or upload a file
              </p>
            </div>
            <p>Template selected</p>
          </div>

          <div className="flex items-center gap-6">
            <div
              className={cn(
                'relative flex h-[188px] w-[280px] flex-col rounded-[20px] border bg-white p-5 shadow-sm'
              )}
            >
              <div className="flex w-full items-start justify-between">
                <div className="relative aspect-square h-[65px] w-[65px] overflow-hidden rounded-[19px] bg-[#F6F6FB] shadow-profilePic">
                  <img
                    src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${templateData?.agreement_logo}`}
                    onError={(
                      event: React.SyntheticEvent<HTMLImageElement, Event>
                    ) => (event.currentTarget.src = syncUppLogo?.src)}
                    className="aspect-auto h-full w-full object-cover"
                    alt={templateData.title}
                  />
                </div>
              </div>
              {/* Template Details */}
              <div className="mt-2">
                <Title
                  as="h1"
                  className="truncate text-[16px] font-bold text-[#111928]"
                >
                  {templateData?.title}
                </Title>
                <p className="line-clamp-2 break-all text-[12px] text-[#4B5563]">
                  {templateData?.description || '\u00A0'}
                </p>
              </div>
            </div>

            <div
              className="flex h-10 cursor-pointer gap-2 rounded-lg bg-[#FDE8E8] p-3"
              onClick={() => {
                openModal({
                  view: (
                    <ChooseTemp
                      closeModal={closeModal}
                      setTemplateData={setTemplateData}
                    />
                  ),
                  customSize: '941px',
                });
              }}
            >
              <FiUpload className="h-4 w-4 text-[#E02424]" />
              <p className="font-semibold text-[#E02424]">
                Remove & select new
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <div>
              <div className="flex gap-3 pt-6">
                <Button
                  type="button"
                  onClick={() => {
                    setTemplateData(null);
                  }}
                  className="w-[70px] rounded-lg border-[#E5E7EB] bg-white font-normal text-[#111928]"
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    dispatch(setSigner(true));
                  }}
                  className="w-auto rounded-lg border-[#E5E7EB] bg-[#7667CF] font-normal text-white"
                >
                  Next: Add signers
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TemplateSeleceted;
