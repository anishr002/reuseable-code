import React, { useState } from 'react'
import { AddSigner } from './AddSigner'

const CreateAgreementSigner = () => {
        const [pagenumber, setPageNumber] = useState(false)
    
  return (
    <div className='space-y-5 px-8 py-10'>
      <AddSigner file={null} number={pagenumber} />
    </div>
  )
}

export default CreateAgreementSigner
