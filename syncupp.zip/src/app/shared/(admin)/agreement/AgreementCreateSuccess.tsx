import React from 'react'
import { ActionIcon, Button } from 'rizzui'
import { useModal } from '../../modal-views/use-modal';
import { PiXBold } from 'react-icons/pi';
import Image from 'next/image';
import ReferSuccess from '@public/assets/svgs/ReferSuccess.svg'
import { useParams, useRouter } from 'next/navigation';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';
import CreateAgreementSigner from './CreateAgreementSigner';


export const AgreementCreateSuccess = () => {
    const { openModal, closeModal } = useModal();
    const router = useRouter()
    const { id } = useParams()
    const { defaultWorkSpace } = useSelector(
        (state: any) => state?.root?.workspace
    );
    return (
        <div>
            <div className='space-y-5 p-7'>
                <div className="flex items-center justify-end pe-2">
                    <ActionIcon
                        size="sm"
                        variant="text"
                        onClick={() => closeModal()}
                        className="p-0 text-[#141414] hover:!text-gray-900 ml-4"
                    >
                        <PiXBold className="h-[18px] w-[18px]" />
                    </ActionIcon>
                </div>
                <div className='grid grid-row gap-5 !mt-0'>
                    <div className='flex justify-center'>
                        <Image
                            className=''
                            height={60}
                            width={60}
                            src={ReferSuccess}
                            alt={'Referral'}>
                        </Image>
                    </div>
                    <div className='grid grid-row gap-5'>
                        <p className='text-[#141414] font-bold leading-8 text-[24px] text-center'>
                            Agreement {id ? "updated"  :"created"} successfully
                        </p>
                        <p className='text-[#141414] font-medium text-[16px] text-center'>
                            Next: Add Signee & send invite
                        </p>
                    </div>
                    <div className='flex gap-3 justify-center mb-3'>
                        <Button
                            type='button'
                            onClick={() => {

                                router.push(routes.agreement(defaultWorkSpace?.name));
                            }}
                            className='w-auto bg-white text-[#111928] font-medium text-[14px] border-[#E5E7EB] rounded-lg'>
                            Go to home
                        </Button>
                        <Button
                            type='button'
                            onClick={() => {
                                openModal({
                                    view: (
                                      <CreateAgreementSigner/>
                                      
                                    ),
                                    customSize: '760px',
                                  });
                            }}
                            className='w-auto bg-[#7667CF] text-white font-normal border-[#E5E7EB] rounded-lg'>
                            Add signee
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}

