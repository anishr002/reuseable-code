'use client';

import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import { routes } from '@/config/routes';
import AgreementPdf from '@public/assets/svgs/AgreementPdf.svg';
import { setShowForm, setSigner, } from '@/redux/slices/user/agreement/agreementSlice';
import Image from 'next/image';
import { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { FaChevronDown } from 'react-icons/fa';
import { FaCircleCheck } from 'react-icons/fa6';
import { LuPlus } from 'react-icons/lu';
import { PiExportBold } from 'react-icons/pi';
import { useSelector } from 'react-redux';
import { Input } from 'rizzui';
import { useRouter } from 'next/navigation';
// import CreateAgreementForm from '../src/app/hydrogen/workspaceName/agreement/create-agreement/main-page';
import CreateAgreementForm from '../../../(hydrogen)/[workspaceName]/agreement/create-agreement/main-page';
import AddSigner from './AddSigner';
import { useDispatch } from 'react-redux';
import { useModal } from '../../modal-views/use-modal';
import { checkPermission } from '../../(user)/roles-permissions/utils';
import ChooseTemp from './ChooseTemp';
import TemplateSeleceted from './TemplateSeleceted';




export const NewAgreement = () => {
    const router = useRouter();
    const { defaultWorkSpace } = useSelector(
        (state: any) => state?.root?.workspace
    );
    const signIn = useSelector((state: any) => state?.root?.signIn);
    const { signer, showForm } = useSelector(
        (state: any) => state?.root?.agreement
    );
    // const [signer,setSigner] = useState(false);
    // const [showForm,setShowForm] = useState(false);
    const [files, setFiles] = useState<File | null>(null);
    const [error, setError] = useState<string>('');
    const { closeModal, openModal } = useModal();
    const [pagenumber, setPageNumber] = useState(true);
    const [templateData, setTemplateData] = useState(null);

    const dispatch = useDispatch();
    const fileAccept = [
        // 'text/csv',
        'application/pdf',
    ];

    const pageHeader = {
        title: 'New Agreement',
    }

    // useDropzone hook to handle file selection and drop
    const handleFileDrop = (acceptedFiles: File[], fileRejections: any[]) => {
        if (fileRejections.length > 0) {
            const oversizedFile = fileRejections.find(
                (file) => file.file.size > 50 * 1024 * 1024
            );
            if (oversizedFile) {
                setError('File size should not exceed 50MB');
                return;
            }
        }

        if (!acceptedFiles || acceptedFiles.length === 0) {
            setError('Only PDF file format is accepted');
            return;
        }
        setFiles(acceptedFiles[0]); // Update the files state
        setError(''); // Clear error on successful file drop
    };

    // Dropzone Options
    const dropzoneOptions: any = {
        // useFsAccessApi: false,
        onDrop: handleFileDrop,
        accept: { 'application/pdf': [] }, // Accept only PDF files
        maxSize: 50 * 1024 * 1024, // Maximum file size of 50MB
        multiple: false,
        noClick: false,
    };


    const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
        useDropzone({
            ...dropzoneOptions,
            onDrop: (acceptedFiles, fileRejections) => handleFileDrop(acceptedFiles, fileRejections),
        });

    console.log('files.....', files);

    return (<>
        {!signer && (!showForm) && !templateData && (<>
            <div>
                <CustomePageHeader
                    title={pageHeader.title}
                    titleClassName="montserrat_font_title"
                    route={routes.agreement(defaultWorkSpace?.name)}
                >
                    {/* <div className='flex gap-3'>
                    <Button
                        type='button'
                        className='bg-white text-[#5850EC] border-[#6875F5] rounded-lg gap-2 text-[14px] font-medium'
                    ><PiExportBold className='h-5 w-5' />
                        Export
                    </Button>
                    <Button
                        type='button'
                        className='bg-[#7667CF] text-white rounded-lg gap-2 text-[14px] font-medium'
                    >
                        Save & Send
                        <FaChevronDown />
                    </Button>
                </div> */}
                </CustomePageHeader>
            </div>
            <div className="w-full h-auto rounded-[10px] bg-white p-4">
                <div className='flex flex-col gap-6'>
                    <div className='flex gap-2 items-center text-[#111928] font-bold text-[18px]'>
                        <span className='bg-[#E5E7EB] rounded-full px-3.5  py-2' >1</span>
                        <p className='text-[#4B5563] text-[16px] font-semibold'>
                            Create new document or upload a file</p>
                    </div>

                    <div className='flex flex-col gap-6'>
                        <div className='grid sm:grid-cols-2 gap-6 '>
                            <Button
                                type='button'
                                className='bg-[#7667CF] text-white rounded-lg gap-2 text-[16px] font-medium w-full'
                                onClick={() => {
                                    dispatch(setShowForm(true));
                                    dispatch(setSigner(true));
                                }}
                            ><LuPlus />

                                Create new agreement
                            </Button>
                            <Button
                                type='button'
                                className='bg-white text-[#5850EC] border-[#6875F5] rounded-lg gap-2 text-[16px] font-medium w-full'
                                onClick={() => {
                                    if (['team_agency'].includes(signIn?.role)
                                        ? checkPermission(
                                            'agreements',
                                            null,
                                            'create',
                                            signIn?.permission
                                        )
                                        : ['agency'].includes(signIn?.role)) {
                                        openModal({
                                            view: (
                                                <ChooseTemp closeModal={closeModal}  setTemplateData={setTemplateData}/>
                                            ),
                                            customSize: '941px',
                                        });
                                    }
                                }}
                            ><LuPlus />

                                Choose from template
                            </Button>
                        </div>
                        <div className='flex  justify-center'>
                            <p className='text-[#4B5563] text-[16px] font-normal flex items-center'>
                                Or
                            </p>
                        </div>
                        <div>
                            <div {...getRootProps()}>
                                <input {...getInputProps()} />
                                <div
                                    className="flex h-auto w-full cursor-pointer flex-col gap-5 rounded-[10px] border border-dashed border-[#B7C2D3] bg-[#F8FAFF] p-4 pb-[16px] pt-[16px]"

                                >
                                    <div className='flex gap-4'>
                                        <div className=" font-medium text-[16px] text-[#292D32]">
                                            Choose a file or drag & drop it here
                                        </div>
                                        <div className="font-medium text-[16px] text-[#1A212F99]">
                                            PDFs only, up to 50MB
                                        </div>
                                    </div>
                                    {files && (
                                        <div className="grid grid-cols-1 gap-4 bg-[#EBF5FF] border-[#D1D5DB] rounded-lg">
                                            <div
                                                className="flex  w-full items-center md:justify-between rounded-xl border border-gray-200 px-3 dark:border-gray-300"
                                            >
                                                <div className='flex items-center gap-6'>
                                                    <div>
                                                        <p className='text-[#1A212F] text-[14px] font-medium'>File uploaded:</p>
                                                    </div>


                                                    <div className='flex items-center py-3 w-full'>
                                                        <Image
                                                            src={AgreementPdf}
                                                            alt={'pdf'}>

                                                        </Image>
                                                        <div className='md:max-w-[calc(100%-20px)] max-w-[calc(100%-200px)]'>
                                                            <p className="poppins_font_number text-[#292D32] font-medium truncate w-[250px] lg:w-[500px] overflow-hidden text-ellipsis whitespace-nowrap ps-2.5">
                                                                {files?.name}
                                                            </p>
                                                            <p className="poppins_font_number md:max-w-[calc(100%-20px)]  text-[#4B5563] font-normal text-[14px] ps-2.5">
                                                                {(files?.size / (1024 * 1024)).toFixed(2)} MB
                                                            </p >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='flex justify-end gap-2 bg-[#3EBF8F1A] text-[#292D32] text-[14px] m-3 p-3 rounded-lg font-medium'>
                                                    <FaCircleCheck className='text-[#3EBF8F] h-5 w-5' />

                                                    Uploaded Completed
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {!files && (
                                        <Button
                                            type='button'
                                            className='w-[120px] bg-white text-[#111928] font-medium gap-2 border-[#E5E7EB] rounded-lg'>
                                            <PiExportBold className='h-5 w-5' />
                                            upload
                                        </Button>
                                    )}

                                    {files && (
                                        <Button
                                            type='button'
                                            className='w-[210px] bg-[#FDE8E8] text-[#E02424] font-medium gap-2 border-[#FDE8E8] rounded-lg'>
                                            <PiExportBold className='h-5 w-5' />
                                            Remove & upload new
                                        </Button>
                                    )}
                                </div>
                            </div>
                            {error !== '' && (
                                <div className="poppins_font_number text-red-600 py-2">{error}</div>
                            )}
                            {files && (
                                <div className='flex gap-3 pt-6'>
                                    <Button
                                        type='button'
                                        onClick={() => {
                                            setFiles(null);
                                            setError('');
                                            router.push(routes.agreement(defaultWorkSpace?.name));
                                        }
                                        }
                                        className='w-[70px] bg-white text-[#111928] font-normal border-[#E5E7EB] rounded-lg'>
                                        Cancel
                                    </Button>
                                    <Button
                                        type='button'
                                        onClick={() => {
                                            dispatch(setSigner(true));
                                        }}
                                        className='w-auto bg-[#7667CF] text-white font-normal border-[#E5E7EB] rounded-lg'>
                                        Next: Add signee
                                    </Button>
                                </div>

                            )}
                        </div>

                    </div>
                </div>
            </div>
        </>
        )}
        {
            templateData&& !signer && !showForm  && (<TemplateSeleceted templateData={templateData} setTemplateData={setTemplateData}/>)
        }
        {
            signer && (!showForm) && (<AddSigner file={files} number={pagenumber} templateData={templateData}/>)
        }
        {
            showForm && (<CreateAgreementForm />)
        }
    </>
    )
}


