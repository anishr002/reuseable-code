import CardSkeleton from '@/components/loader/card-skeleton';
import { createagreementByTemp, getAllTemplate, setSigner } from '@/redux/slices/user/agreement/agreementSlice';
import cn from '@/utils/class-names';
import syncUppLogo from '@public/assets/images/logo_icon.png';
import debounce from 'lodash/debounce';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Empty, Title } from 'rizzui';
import SimpleBar from 'simplebar-react';
import { checkPermission } from '../../(user)/roles-permissions/utils';
import EyeIcon from '@/components/icons/eye';
import Spinner from '@/components/ui/spinner';
import toast from 'react-hot-toast';
import ViewTemplate from './ViewTemplate';

const ChooseTemp = ({ closeModal, setTemplateData }: any) => {

    const signIn = useSelector((state: any) => state?.root?.signIn);
    const [skeletonLoader, setSkeletonLoader] = useState(true);
    const [updatedTemplate, setUpdatedTemplate] = useState<any[]>([]);
    const [viewTemplate, setViewTemplate] = useState<string | null>(null);
    const [hasMore, setHasMore] = useState(true);
    const [payload, setPayload] = useState({
        page: 1,
        items_per_page: 10,
        isPagination: true,
        // sort: selectedBoardSortValue,
        // search: debouncedValue,
    });
    const [selectedTemplate, setSelectedTemplate] = useState<any | null>(null);

    const toggleSelection = (template: any) => {
        setSelectedTemplate((prevSelected: any) => (prevSelected === template?._id ? null : template));
    };

    const [totalTemplateData, setTotalTemplateData] = useState(0);
    const dispatch = useDispatch();
    const { loading, allTemplates } = useSelector(
        (state: any) => state?.root?.agreement
    );
    useEffect(() => {
        dispatch(getAllTemplate(payload)).then((result: any) => {
            if (getAllTemplate.fulfilled.match(result)) {
                const templateList = result?.payload?.data?.agreements || [];
                const totalTemplateCount = result?.payload?.data?.total_template;

                setTotalTemplateData(totalTemplateCount);

                if (templateList.length > 0) {
                    setSkeletonLoader(false);

                    const newData =
                        payload.page === 1
                            ? templateList // Replace the data when loading the first page or searching
                            : [...updatedTemplate, ...templateList]; // Append when scrolling

                    setUpdatedTemplate(newData);

                    if (totalTemplateCount > newData.length) {
                        setHasMore(true); // More data available
                    } else {
                        setHasMore(false); // No more data
                    }
                } else {
                    // No results for the current search or payload
                    setHasMore(false);
                }
            } else {
                setHasMore(false); // Error or no data
            }
            setSkeletonLoader(false);
        });
    }, [payload]);
    const fetchMoreData = () => {
        // 10px buffer to trigger loading
        if (updatedTemplate.length < totalTemplateData) {
            setPayload({
                ...payload,
                page: payload?.page + 1, // Increment skip for next batch
            });
        } else {
            setHasMore(false); // No more data to load
        }
    };

    const handleScroll = debounce((e: any) => {
        const { scrollTop, scrollHeight, clientHeight } = e.target;
        if (scrollHeight - scrollTop <= clientHeight + 50) {
            fetchMoreData();
        }
    }, 300); // Adjust debounce delay as needed

    const onConfirm = (selectedTemplate: string | null) => {
        if (selectedTemplate !== null) {
            setTemplateData(selectedTemplate)
            closeModal();
        } else {
            toast.error("Please select template");
        }
    }; console.log(selectedTemplate, "selectnd")
    return (
        <>
            <div className='py-8 px-6 lg:py-10 lg:px-8'>
                <Title as="h1" className="text-[20px] font-semibold text-[#111928] truncate mb-6">
                    Choose a template
                </Title>
                <SimpleBar onScrollCapture={handleScroll} className="h-[59vh] lg:h-[72vh] 3xl:h-[68vh] pb-4 pr-2">
                    {updatedTemplate?.length > 0 ?
                        <div
                            className={cn(
                                'px-[6px]',
                                ((['team_agency'].includes(signIn?.role)
                                    ? checkPermission(
                                        'agreements',
                                        null,
                                        'view',
                                        signIn?.permission
                                    )
                                    : ['agency'].includes(signIn?.role)) ||
                                    skeletonLoader ||
                                    (updatedTemplate && updatedTemplate?.length > 0)) &&
                                'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6'
                            )}
                        >
                            {skeletonLoader ? (
                                <>
                                    <CardSkeleton />
                                    <CardSkeleton />
                                    <CardSkeleton />
                                    <CardSkeleton />
                                    <CardSkeleton />
                                    <CardSkeleton />
                                </>
                            ) : (
                                <>
                                    {(
                                        ['team_client', 'team_agency'].includes(signIn?.role)
                                            ? checkPermission(
                                                'agreements',
                                                null,
                                                'view',
                                                signIn?.permission
                                            )
                                            : ['agency'].includes(signIn?.role)
                                    ) ?
                                        updatedTemplate.map((template: any) => (
                                            <div key={template._id} onClick={() => toggleSelection(template)}>
                                                <InformationCard
                                                    data={template}
                                                    isSelected={selectedTemplate?._id === template._id}
                                                    setViewTemplate={setViewTemplate}
                                                    viewTemplate={viewTemplate}
                                                />
                                            </div>
                                        ))
                                        : (
                                            <div className="mt-20 flex items-center justify-center">
                                                <Empty />
                                            </div>
                                        )}
                                </>
                            )}
                        </div> : <div className="mt-20 flex items-center justify-center flex-col gap-3">
                            <Empty />
                            <p className='text-xl'>No Templates Available</p>
                        </div>
                    }
                    {(hasMore && loading) && (
                        <div className="flex w-full items-center justify-center">
                            <Button variant="text" size="xl" isLoading={true} />
                        </div>
                    )}
                </SimpleBar>

                {/* Buttons */}
                <div className="mt-6 flex justify-start gap-4">
                    <Button
                        type='button'
                        onClick={() => closeModal()}
                        className='w-[70px] bg-white text-[#111928] font-normal border-[#E5E7EB] rounded-lg'>
                        Cancel
                    </Button>
                    <Button
                        type='button'
                        onClick={() => onConfirm(selectedTemplate)}
                        className='w-auto bg-[#7667CF] text-white font-normal border-[#E5E7EB] rounded-lg'>
                        Confirm
                    </Button>
                </div>
            </div>

            {viewTemplate && (
                <div>
                    <div className="fixed left-0 top-0 z-10 flex max-h-[650px] w-full  items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
                        <div
                            className="relative overflow-hidden rounded-lg bg-white shadow-lg"
                            style={{ width: '900px', minHeight: '630px' }}
                        >
                            {/* Pass the specific ID to ViewTemplate */}
                            <ViewTemplate tempId={viewTemplate} onClose={() => setViewTemplate(null)} />
                        </div>
                    </div>
                </div>
            )}
        </>

    );
};
export default ChooseTemp;
interface InformationCardProps {
    data: {
        _id: string;
        agreement_logo?: string;
        title: string;
        description?: string;

    };
    isSelected: boolean;
    setViewTemplate: any;
    viewTemplate: any;
}

const InformationCard: React.FC<InformationCardProps> = ({ data, isSelected, setViewTemplate, viewTemplate }) => {
    return (
        <div className={cn(
            'relative flex h-[188px] w-auto cursor-pointer flex-col rounded-[20px] border bg-white p-5 shadow-sm hover:border hover:border-[#8C80D2]',
            isSelected ? 'border-[#7667CF] bg-[#F0F5FF]' : ''
        )}>
            <div className="flex w-full justify-between items-start">
                <div className="relative aspect-square h-[65px] w-[65px] overflow-hidden rounded-[19px] bg-[#F6F6FB] shadow-profilePic">
                    <img
                        src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${data?.agreement_logo}`}
                        onError={(event: React.SyntheticEvent<HTMLImageElement, Event>) =>
                            (event.currentTarget.src = syncUppLogo?.src)
                        }
                        className="aspect-auto h-full w-full object-cover"
                        alt={data.title}
                    />
                </div>
                <EyeIcon
                    className="mr-2 h-5 w-5 cursor-pointer"
                    onClick={() => setViewTemplate(data._id)} 
                />

            </div>
            {/* Template Details */}
            <div className="mt-2">
                <Title as="h1" className="text-[16px] font-bold text-[#111928] truncate">
                    {data?.title}
                </Title>
                <p className="text-[12px] text-[#4B5563] break-all line-clamp-2">{data?.description || '\u00A0'}</p>
            </div>
        </div>
    );
};
