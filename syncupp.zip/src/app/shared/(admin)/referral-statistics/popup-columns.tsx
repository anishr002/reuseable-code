'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import moment from 'moment';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const PopupReferralStatisticsColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  return [
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'first_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('first_name'),
      dataIndex: 'first_name',
      key: 'first_name',
      width: 150,
      render: (value: any, row: any) => (
        <>
          {!row?.first_name && !row?.first_name ? (
            <Text className="poppins_font_number font-normal text-gray-700 ms-10">-</Text>
          ) : (
            <div className="flex items-center gap-2">
              <Text className="poppins_font_number font-normal capitalize text-gray-700">
                {row?.first_name && row?.first_name !== ''
                  ? row?.first_name
                  : ''}
              </Text>
              <Text className="poppins_font_number font-normal capitalize text-gray-700">
                {row?.last_name && row?.last_name !== '' ? row?.last_name : ''}
              </Text>
            </div>
          )}
        </>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Email ID"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('email'),
      dataIndex: 'email',
      key: 'email',
      width: 200,
      render: (value: any) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    // {
    //   title: (
    //     <HeaderCell
    //       title="Workspace"
    //       sortable
    //       ascending={
    //         sortConfig?.direction === 'asc' && sortConfig?.key === 'workspace'
    //       }
    //     />
    //   ),
    //   onHeaderCell: () => onHeaderCellClick('workspace'),
    //   dataIndex: 'workspace',
    //   key: 'workspace',
    //   width: 150,
    //   render: (value: string) => (
    //     <Text className="poppins_font_number font-medium text-gray-700">
    //       {value && value !== '' ? value : '-'}
    //     </Text>
    //   ),
    // },
    {
      title: (
        <HeaderCell
          title="Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? moment(value).format('Do MMM, YYYY') : '-'}
        </Text>
      ),
    },
  ];
};
