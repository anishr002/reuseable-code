'use client';

import ReferralStatisticsSublistPage from '@/app/admin/(hydrogen)/referral-statistics/popup-table';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { useDispatch } from 'react-redux';
import { Button } from 'rizzui';
import { useModal } from '../../modal-views/use-modal';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const ReferralStatisticsColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const { openModal } = useModal();

  const handleClick = (referred_by: string) => {
    openModal({
      view: <ReferralStatisticsSublistPage referred_by={referred_by} />,
      customSize: '1050px',
    });
  };

  return [
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'user_name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('user_name'),
      dataIndex: 'user_name',
      key: 'user_name',
      width: 150,
      render: (value: any) => (
        <Text className="poppins_font_number font-normal capitalize text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Email ID"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('email'),
      dataIndex: 'email',
      key: 'email',
      width: 200,
      render: (value: any) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Total Points"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'total_points'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('total_points'),
      dataIndex: 'total_points',
      key: 'total_points',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Total Referrals"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'total_referrals'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('total_referrals'),
      dataIndex: 'total_referrals',
      key: 'total_referrals',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Successfull Signups"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'successful_signups'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('successful_signups'),
      dataIndex: 'successful_signups',
      key: 'successful_signups',
      width: 150,
      render: (value: string) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {value && value !== '' ? value : '-'}
        </Text>
      ),
    },
    // {
    //   title: (
    //     <HeaderCell
    //       title="Date"
    //       sortable
    //       ascending={
    //         sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
    //       }
    //     />
    //   ),
    //   onHeaderCell: () => onHeaderCellClick('createdAt'),
    //   dataIndex: 'createdAt',
    //   key: 'createdAt',
    //   width: 150,
    //   render: (value: string) => (
    //     <Text className="font-medium text-gray-700 poppins_font_number">
    //       {value && value !== '' ? moment(value).format('Do MMM, YYYY') : '-'}
    //     </Text>
    //   ),
    // },
    {
      // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
      title: <HeaderCell title="Actions" />,
      dataIndex: 'action',
      key: 'action',
      width: 100,
      render: (_: string, row: any) => (
        <Button
          className="w-full"
          onClick={(e) => {
            e.stopPropagation();
            handleClick(row?.referred_by);
          }}
        >
          View
        </Button>
      ),
    },
  ];
};
