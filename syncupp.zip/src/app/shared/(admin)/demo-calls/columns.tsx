'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import moment from 'moment';
import { useDispatch } from 'react-redux';
import { useModal } from '../../modal-views/use-modal';
import { capitalizeFirstLetter } from '@/utils/common-functions';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

export const DemoCallsColumns = ({
  data,
  sortConfig,
  checkedItems,
  onDeleteItem,
  onHeaderCellClick,
  handleSelectAll,
  onChecked,
  currentPage,
  pageSize,
  searchTerm,
}: Columns) => {
  const dispatch = useDispatch();
  const { openModal } = useModal();

  return [
    {
      title: (
        <HeaderCell
          title="Name"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('name'),
      dataIndex: 'name',
      key: 'name',
      width: 500,
      render: (_: any, row: any) => (
        <Text className="font-medium capitalize text-gray-700">
          {capitalizeFirstLetter(row?.name)}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Email"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'email'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('email'),
      dataIndex: 'email',
      key: 'email',
      width: 300,
      render: (_: any, row: any) => (
        <Text className="font-medium text-gray-700">{row?.email}</Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="WhatsApp Number"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'whatsapp_no'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('whatsapp_no'),
      dataIndex: 'whatsapp_no',
      key: 'whatsapp_no',
      width: 300,
      render: (_: any, row: any) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          +{row?.whatsapp_no}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Industry"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'selected_industry'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('selected_industry'),
      dataIndex: 'selected_industry',
      key: 'selected_industry',
      width: 400,
      render: (_: any, row: any) => (
        <Text className="font-medium capitalize text-gray-700">
          {capitalizeFirstLetter(row?.selected_industry)}
        </Text>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Team Size"
          sortable
          ascending={
            sortConfig?.direction === 'asc' &&
            sortConfig?.key === 'selected_team_size'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('selected_team_size'),
      dataIndex: 'selected_team_size',
      key: 'selected_team_size',
      width: 400,
      render: (_: any, row: any) => (
        // <div className="flex items-center justify-center">
        <Text className="poppins_font_number font-normal text-gray-700">
          {row?.selected_team_size}
        </Text>
        // </div>
      ),
    },
    {
      title: (
        <HeaderCell
          title="Date"
          sortable
          ascending={
            sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
          }
        />
      ),
      onHeaderCell: () => onHeaderCellClick('createdAt'),
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 300,
      render: (_: any, row: any) => (
        <Text className="poppins_font_number font-normal text-gray-700">
          {moment(row?.createdAt).format('DD MMM, YYYY')}
        </Text>
      ),
    },
  ];
};
