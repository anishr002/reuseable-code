import React from 'react';

function Privacy() {
  return <div>privacy</div>;
}

export default Privacy;
