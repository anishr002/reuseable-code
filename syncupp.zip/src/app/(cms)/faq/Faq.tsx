import React from 'react';

function Faq() {
  return <div>faq</div>;
}

export default Faq;
