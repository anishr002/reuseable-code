import React from 'react';

function TermsConditions() {
  return <div>terms</div>;
}

export default TermsConditions;
