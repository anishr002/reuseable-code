import React from 'react';

function Affiliate() {
  return <div>Affiliate Program</div>;
}

export default Affiliate;
