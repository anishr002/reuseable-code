import React from 'react';

function AffiliateStatistics() {
  return <div>Affiliate Statistics</div>;
}

export default AffiliateStatistics;
