import { metaObject } from '@/config/site.config';
import SharedInvoice from './main-page';

export const metadata = {
  ...metaObject('Invoice'),
};

export default function Page({ params }: { params: { invoiceId: string } }) {
  return (
    <SharedInvoice params={params} />
  );
}


