'use client';

import InvoicePreview from '@/app/shared/(user)/invoice/invoice-preview'
import Spinner from '@/components/ui/spinner';
import axios from 'axios';
import Image from 'next/image';
import React, { useEffect, useState } from 'react'
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import { Button } from '@/components/ui/button';
import { FiDownload } from "react-icons/fi";
import WidgetCard from '@/components/cards/widget-card';
import SimpleBar from 'simplebar-react';
import { Empty } from '@/components/ui/empty';

const SharedInvoice = ({ params }: { params: { invoiceId: string } }) => {

    const [invoiceData, setinvoiceData] = useState({});
    const [apiLoader, setApiLoader] = useState(false);
    const [downloadLoader, setDownloadLoader] = useState(false);

    useEffect(() => {
        if (params.invoiceId) {
            setApiLoader(true)
            axios.get(`${process.env.NEXT_PUBLIC_API}/api/v1/invoice/get/${params.invoiceId}`).then((response: any) => {
                setApiLoader(false);
                if (response?.data?.success) {
                    setinvoiceData(response?.data?.data?.[0]);
                }
            }).catch((error: any) => {
                setApiLoader(false);
            })
        }
    }, [params.invoiceId])

    const downloadInvoice = () => {
        setDownloadLoader(true);
        axios({
            url: `${process.env.NEXT_PUBLIC_API}/api/v1/invoice/download-invoice-public/${params.invoiceId}`,
            method: 'GET',
            headers: { contentType: 'application/pdf' },
        }).then((response: any) => {
            if (response?.data?.success) {
                const uint8Array = new Uint8Array(response?.data?.data?.pdfBuffer.data);
                const blob = new Blob([uint8Array], { type: 'application/pdf' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = `${response?.data?.data?.filename}`;
                link.click();
                setDownloadLoader(false);
            }
        }).catch((error: any) => {
            setDownloadLoader(false);
        })
    }

    if (apiLoader) {
        return (<div className="flex items-center justify-center p-10">
            <Spinner size="xl" tag="div" className="ms-3" />
        </div>)
    }

    return (
        <div>
            <div className='px-5 lg:px-10'>
                <div className='flex justify-between items-center h-[68px]'>
                    <div className='flex items-center'>
                        <Image
                            src={syncUppLogo}
                            alt="Syncupp"
                            width={100}
                            height={100}
                            className="h-[36px] w-[80px]"
                        />
                    </div>
                    <div className='flex items-center gap-4'>
                        <Button
                            onClick={() => window.open('https://www.syncupp.com', '_blank')}
                            variant="outline"
                            className='text-[#6875F5] border-[#6875F5] rounded-lg bg-white text-sm font-medium'>Join syncupp</Button>
                        {Object.keys(invoiceData)?.length > 0 &&

                            <Button
                                className="p-3 rounded-lg flex gap-2 bg-[#7667CF] text-sm font-medium"
                                onClick={downloadInvoice}
                                disabled={downloadLoader}
                            >
                                {downloadLoader &&
                                    <Spinner size="sm" tag="div" className="text-white" />
                                }
                                <FiDownload className="h-4 w-4" />
                                Download
                            </Button>
                        }

                    </div>
                </div>
            </div>
            {
                !apiLoader && Object.keys(invoiceData)?.length === 0 ? <div className="flex items-center justify-center p-10">
                    <Empty text="No Data"
                        textClassName="mt-4 text-base text-gray-500" />
                </div> :
                    <SimpleBar className='overflow-y-auto h-[calc(100vh-70px)] bg-[#F6F6FB]'>
                        <div className='pt-4 lg:pt-16 px-8 lg:px-32'>
                            <WidgetCard rounded="xl" title="" className="mx-8 pt-4">
                                <InvoicePreview data={invoiceData} />
                            </WidgetCard>
                        </div>
                    </SimpleBar>
            }

        </div>
    )
}

export default SharedInvoice
