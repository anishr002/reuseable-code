'use client';

import Spinner from '@/components/ui/spinner';
import axios from 'axios';
import Image from 'next/image';
import React, { useEffect, useState } from 'react';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import { Button } from '@/components/ui/button';
import { FiDownload } from 'react-icons/fi';
import WidgetCard from '@/components/cards/widget-card';
import SimpleBar from 'simplebar-react';
import { Empty } from '@/components/ui/empty';
import ViewAgreement from '@/app/shared/(admin)/agreement/ViewAgreement';

const SharedAgreement = ({ params }: { params: { agreementId: string } }) => {
  const [agreementData, setAgreementdata] = useState({});
  const [apiLoader, setApiLoader] = useState(false);
  const [downloadLoader, setDownloadLoader] = useState(false);

  useEffect(() => {
    if (params.agreementId) {
      setApiLoader(true);
      axios
        .get(
          `${process.env.NEXT_PUBLIC_API}/api/v1/agreement/get-agreement-public/${params.agreementId}`
        )
        .then((response: any) => {
          setApiLoader(false);
          if (response?.data?.success) {
            setAgreementdata(response?.data?.data);
          }
        })
        .catch((error: any) => {
          setApiLoader(false);
        });
    }
  }, [params.agreementId]);

  const downloadAgreement = () => {
    setDownloadLoader(true);
    axios({
      url: `${process.env.NEXT_PUBLIC_API}/api/v1/agreement/download-pdf-public/${params.agreementId}`,
      method: 'GET',
      headers: { contentType: 'application/pdf' },
    })
      .then((response: any) => {
        if (response?.data?.success) {
          const uint8Array = new Uint8Array(
            response?.data?.data?.pdfBuffer.data
          );
          const blob = new Blob([uint8Array], { type: 'application/pdf' });
          const link = document.createElement('a');
          link.href = URL.createObjectURL(blob);
          link.download = `${response?.data?.data?.filename}`;
          link.click();
          setDownloadLoader(false);
        }
      })
      .catch((error: any) => {
        setDownloadLoader(false);
      });
  };

  console.log(agreementData, 'agreementData');

  if (apiLoader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  }

  return (
    <div>
      <div className="px-5 lg:px-10">
        <div className="flex h-[68px] items-center justify-between">
          <div className="flex items-center">
            <Image
              src={syncUppLogo}
              alt="Syncupp"
              width={100}
              height={100}
              className="h-[36px] w-[80px]"
            />
          </div>
          <div className="flex items-center gap-4">
            <Button
              onClick={() => window.open('https://www.syncupp.com', '_blank')}
              variant="outline"
              className="rounded-lg border-[#6875F5] bg-white text-sm font-medium text-[#6875F5]"
            >
              Join syncupp
            </Button>
            {Object.keys(agreementData)?.length > 0 && (
              <Button
                className="flex gap-2 rounded-lg bg-[#7667CF] p-3 text-sm font-medium"
                onClick={downloadAgreement}
                disabled={downloadLoader}
              >
                {downloadLoader && (
                  <Spinner size="sm" tag="div" className="text-white" />
                )}
                <FiDownload className="h-4 w-4" />
                Download
              </Button>
            )}
          </div>
        </div>
      </div>
      {!apiLoader && Object.keys(agreementData)?.length === 0 ? (
        <div className="flex items-center justify-center p-10">
          <Empty text="No Data" textClassName="mt-4 text-base text-gray-500" />
        </div>
      ) : (
        <SimpleBar className="h-[calc(100vh-70px)] overflow-y-auto bg-[#F6F6FB]">
          <div className=" px-8 pb-[30px] pt-[30px] lg:px-32">
            <WidgetCard rounded="xl" title="" className="mx-8 pt-4">
              <ViewAgreement formValues={agreementData} />
            </WidgetCard>
          </div>
        </SimpleBar>
      )}
    </div>
  );
};

export default SharedAgreement;
