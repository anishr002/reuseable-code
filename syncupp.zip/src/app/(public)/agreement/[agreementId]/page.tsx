import { metaObject } from '@/config/site.config';
import SharedAgreement from './main-page';

export const metadata = {
  ...metaObject('Agreement'),
};

export default function Page({ params }: { params: { agreementId: string } }) {
  return <SharedAgreement params={params} />;
}
