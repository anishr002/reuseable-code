"use client";
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import CustomTable from '@/components/common-tables/table';
import { deleteTask } from '@/redux/slices/user/task/taskSlice';
import { GetActivityColumns } from '@/app/shared/(user)/calender/calender-list/columns';
import { RemoveActivityTableData, getAllActivity, setActivityName, setPaginationDetails } from '@/redux/slices/user/activity/activitySlice';
import cn from '@/utils/class-names';
import { Button } from 'rizzui';
import DatePeriodSelectionForm from '@/app/shared/(user)/forms/select-period-form';
import ActivitySelectionForm from '@/app/shared/(user)/forms/activity-selection-form';
import ModalButton from '@/app/shared/modal-button';
import AddActivityFormPage from '@/app/shared/(user)/calender/create-edit-event/create-edit-activity-form';
import { PiPlusBold } from 'react-icons/pi';
import StatusSelectionForm from '@/app/shared/(user)/forms/status-selection-form';
import Select from '@/components/ui/select';
import { DatePicker } from '@/components/ui/datepicker';
import moment from 'moment';

let statusOptionsDropdown: Record<string, any>[] = [
    { name: 'All', value: '' },
    { name: 'Pending', value: 'pending' },
    { name: 'In Progress', value: 'in_progress' },
    { name: 'Overdue', value: 'overdue' },
    { name: 'Completed', value: 'done' },
    { name: 'Cancel', value: 'cancel' },
]

let activityOptions: Record<string, any>[] = [
    { name: 'Task', value: 'task' },
    { name: 'Call meeting', value: 'call_meeting' },
    { name: 'Others', value: 'others' },
]

export default function ClientTeamActivityTablePage(props: any) {

    const { teamId, teamName } = props;


    const dispatch = useDispatch();
    const router = useRouter();
    const signIn = useSelector((state: any) => state?.root?.signIn)
    const clientSliceData = useSelector((state: any) => state?.root?.client);
    const activityData = useSelector((state: any) => state?.root?.activity);
    const { paginationParams } = useSelector((state: any) => state?.root?.activity);

    const [data, setData] = useState([]);
    const [pageSize, setPageSize] = useState<number>(10);
    const [activityType, setActivityType] = useState('');
    const [statusType, setStatusType] = useState('');
    const [period, setPeriod] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [reset, setReset] = useState('');
    const [statusOption, setStatusOption] = useState('');
    const [selectedActivity, setSelectedActivity] = useState('');
    const [startRangeDate, setStartRangeDate] = useState(null);
    const [endRangeDate, setEndRangeDate] = useState(null);

    // console.log("Activity is....", activityData?.activityName)
    // console.log("Activity is....", activityType)
    // console.log("Start date is....", startDate)
    // console.log("End date is....", endDate)

    useEffect(() => {
        dispatch(RemoveActivityTableData())
    }, [dispatch])

    useEffect(() => {
        setData(activityData?.data?.activity)
    }, [activityData?.data])

    const handleStatusChange = (selectedOption: Record<string, any>) => {
        setStatusType(selectedOption?.value)
        // dispatch(setActivityName(selectedOption?.value));

        dispatch(setPaginationDetails({ ...paginationParams, page: 1, filter: { status: selectedOption?.value, activity_type: activityType, date: period, start_date: startDate, end_date: endDate } }))


        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
            if (activityType === '' && endDate === '' && startDate === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: selectedOption?.value }, pagination: true }))
            } else if (endDate === '' && startDate === '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: selectedOption?.value, activity_type: activityType }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: selectedOption?.value, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: selectedOption?.value, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            }
        } else {
            if (activityType === '' && endDate === '' && startDate === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: selectedOption?.value }, pagination: true }))
            } else if (endDate === '' && startDate === '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: selectedOption?.value, activity_type: activityType }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType !== '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: selectedOption?.value, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            } else if (endDate !== '' && startDate !== '' && activityType === '') {
                dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: selectedOption?.value, date: period, start_date: startDate, end_date: endDate }, pagination: true }))
            }

        }


    }

    const handleActivityChange = (selectedOption: Record<string, any>) => {
        setActivityType(selectedOption?.value)
        dispatch(setActivityName(selectedOption?.value));

        dispatch(setPaginationDetails({ ...paginationParams, page: 1, filter: { status: statusType, activity_type: selectedOption?.value, date: period, start_date: startDate, end_date: endDate } }))


        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {

            endDate === '' ?
                dispatch(getAllActivity({ page: 1, sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: statusType, activity_type: selectedOption?.value }, pagination: true }))
                :
                dispatch(getAllActivity({ page: 1, sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: statusType, activity_type: selectedOption?.value, date: period, start_date: startDate, end_date: endDate }, pagination: true }))

        } else {

            endDate === '' ?
                dispatch(getAllActivity({ page: 1, sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: statusType, activity_type: selectedOption?.value }, pagination: true }))
                :
                dispatch(getAllActivity({ page: 1, sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: statusType, activity_type: selectedOption?.value, date: period, start_date: startDate, end_date: endDate }, pagination: true }))

        }


    }

    const handleRangeChange = (dates: any) => {
        const [start, end] = dates;
        setStartRangeDate(start);
        setEndRangeDate(end);
        setStartDate(moment(start).format('DD-MM-YYYY'))
        !!end && setEndDate(moment(end).format('DD-MM-YYYY'))

        dispatch(setPaginationDetails({ ...paginationParams, page: 1, filter: { status: statusType, activity_type: activityType, date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') } }))


        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
            !!end && dispatch(getAllActivity({ page: 1, sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }, pagination: true }))
        } else {
            !!end && dispatch(getAllActivity({ page: 1, sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }, pagination: true }))
        }

        !!end && setPeriod('period')

    };

    // useEffect(() => {
    //     reset === 'reset' && setStatusOption('');
    // }, [reset]);


    useEffect(() => {
        if (activityType !== '' || statusType !== '' || period !== '' || startDate !== '' || endDate !== '') {
            setReset('')
        }
    }, [activityType, statusType, period, startDate, endDate]);


    const handleResetFilters = () => {
        setStatusType('');
        setStatusOption('');
        setActivityType('');
        setSelectedActivity('');
        setPeriod('');
        setStartDate('');
        setEndDate('');
        setStartRangeDate(null);
        setEndRangeDate(null);
        setReset('reset');

        dispatch(getAllActivity({ sort_field: 'createdAt', sort_order: 'desc', client_team_id: teamId, pagination: true }));

    }


    const handleChangePage = async (paginationParams: any) => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;

        dispatch(setPaginationDetails({ ...paginationParams, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate } }))

        const response = signIn?.role !== 'client' && signIn?.role !== 'team_client' ? await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true })) : await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }));
        const { data } = response?.payload;
        const maxPage: number = data?.page_count;

        if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            // await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search }));
            signIn?.role !== 'client' && signIn?.role !== 'team_client' ? await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true })) : await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search, agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }));
            return data?.client
        }
        if (data && data?.client && data?.client?.length !== 0) {
            return data?.client
        }
    };

    const handleDeleteById = async (id: string | string[], currentPage?: any, countPerPage?: number, sortConfig?: Record<string, string>, searchTerm?: string) => {

        // console.log("delete id in main page....", id)

        try {
            const res = typeof id === 'string' ? await dispatch(deleteTask({ taskIdsToDelete: [id] })) : await dispatch(deleteTask({ taskIdsToDelete: id }));
            if (res.payload.success === true) {
                const reponse = signIn?.role !== 'client' && signIn?.role !== 'team_client' ? await dispatch(getAllActivity({ page: currentPage, items_per_page: countPerPage, sort_field: sortConfig?.key, sort_order: sortConfig?.direction, search: searchTerm, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true })) : await dispatch(getAllActivity({ page: currentPage, items_per_page: countPerPage, sort_field: sortConfig?.key, sort_order: sortConfig?.direction, search: searchTerm, agency_id: clientSliceData?.agencyId, client_team_id: teamId, filter: { status: statusType, activity_type: activityType, date: period, start_date: startDate, end_date: endDate }, pagination: true }));
            }
        } catch (error) {
            console.error(error);
        }
    };

    const FilterList = () => {
        return (
            <>
                <Select
                    options={statusOptionsDropdown}
                    onChange={(selectedOption: Record<string, any>) => {
                        setStatusOption(selectedOption?.name);
                        handleStatusChange(selectedOption);
                    }}
                    value={statusOption}
                    placeholder='Select Status'
                    // getOptionValue={(option) => option.value}
                    className="w-full"
                // dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
                />
                {/* <StatusSelectionForm setStatusType={setStatusType} activityType={activityType} startDate={startDate} endDate={endDate} period={period} reset={reset} /> */}

                {/* <DatePeriodSelectionForm setStartDate={setStartDate} setEndDate={setEndDate} statusType={statusType} activityType={activityType} setPeriod={setPeriod} reset={reset} /> */}
                <DatePicker
                    selected={startRangeDate}
                    onChange={handleRangeChange}
                    startDate={startRangeDate}
                    endDate={endRangeDate}
                    // isClearable={true}
                    monthsShown={1}
                    placeholderText="Select Date in a Range"
                    className="w-full"
                    selectsRange
                />
                <Select
                    options={activityOptions}
                    onChange={(selectedOption: Record<string, any>) => {
                        setSelectedActivity(selectedOption?.name);
                        handleActivityChange(selectedOption);
                    }}
                    value={selectedActivity}
                    placeholder='Select Activity'
                    // getOptionValue={(option) => option.value}
                    className="w-full"
                // dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
                />
                {/* <ActivitySelectionForm setActivityType={setActivityType} statusType={statusType} startDate={startDate} endDate={endDate} period={period} reset={reset} /> */}
                <Button
                    className={cn(
                        "w-full text-xs @lg:w-auto sm:text-sm lg:mt-0"
                    )}
                    onClick={handleResetFilters}
                >
                    Reset
                </Button>
                <ModalButton
                    label="Add Meeting"
                    view={<AddActivityFormPage title="New Meeting" isTaskModule={false} isTeamModule={false} isClientModule={true} isAgencyTeam={false} clientId={teamId} clientName={teamName} />}
                    customSize="1050px"
                    className="mt-0 w-full max-h-[800px] overflow-auto bg-[#53216F] hover:bg-[#8e45b8] @lg:w-auto dark:bg-gray-100 dark:text-white dark:hover:bg-gray-200 dark:active:bg-gray-100"
                    icon={<PiPlusBold className="me-1.5 h-[17px] w-[17px]" />}
                />
            </>
        )
    }


    return (
        <>
            <div className='mt-8'>
                <CustomTable
                    data={data}
                    total={(activityData && activityData?.data?.page_count) || 1}
                    loading={activityData && activityData?.loading}
                    pageSize={pageSize}
                    setPageSize={setPageSize}
                    handleDeleteById={handleDeleteById}
                    handleChangePage={handleChangePage}
                    getColumns={GetActivityColumns}
                    filtersList={<FilterList />}
                />
            </div>
        </>
    );
}
