'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import Spinner from '@/components/ui/spinner';
import {
  deleteTeamMember,
  getAllTeamMember,
} from '@/redux/slices/user/team-member/teamSlice';
import cn from '@/utils/class-names';
import { PiTrashFill } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Text, Title } from 'rizzui';

function DeleteModel({
  forsfully,
  id,
  page,
  items_per_page,
  sort_field,
  sort_order,
  search,
  pagination,
  client_id,
}: any) {
  const { openModal, closeModal } = useModal();
  const disptach = useDispatch();
  const { deleteTeamMemberLoader } = useSelector(
    (state: any) => state?.root?.teamMember
  );

  const handleDelete = async () => {
    const res = await disptach(
      deleteTeamMember({
        teamMemberIds: id,
        client_id: client_id,
        force_fully_remove: forsfully,
        client_team: true,
      })
    );
    if (res.payload.success === true) {
      closeModal();
      const reponse = await disptach(
        getAllTeamMember({
          page: page,
          items_per_page: items_per_page,
          sort_field: sort_field,
          sort_order: sort_order,
          search: search,
          pagination: true,
        })
      );
    }
  };

  function handelCAncle() {
    closeModal();
  }

  return (
    <div className="p-6">
      <div className="flex flex-col items-center gap-[6px]">
        <Title
          as="h6"
          className="mb-0.5 flex items-start text-sm text-[#8C80D2] sm:items-center"
        >
          {/* <PiTrashFill className="me-1 h-[17px] w-[17px]" /> */}
          This User have been assigned with Task(s) which are still pending.
        </Title>
        <Text className="mb-2 leading-relaxed text-[#9BA1B9]">
          Are you sure you want to delete?
        </Text>
        {/* <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="p-0 text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon> */}
      </div>
      <div className={cn('grid grid-cols-2 gap-5 pt-5 ')}>
        <div className="flex items-center justify-end gap-2">
          <Button
            className="bg-[#8C80D2] text-white @xl:w-auto dark:text-white"
            onClick={handleDelete}
            disabled={deleteTeamMemberLoader}
          >
            Yes
            {deleteTeamMemberLoader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
        <div>
          <Button
            variant="outline"
            onClick={() => handelCAncle()}
            className="text-[#9BA1B9] @xl:w-auto dark:hover:border-gray-400"
          >
            No
          </Button>
        </div>
      </div>
    </div>
  );
}

export default DeleteModel;
