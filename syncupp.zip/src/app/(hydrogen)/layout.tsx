'use client';
import { useIsMounted } from '@/hooks/use-is-mounted';
import socket from '@/io';
import HeliumLayout from '@/layouts/helium/helium-layout';
import { getActiveTaskTime } from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import WithAuth from '@/utils/private-route-user';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

function DefaultLayout({ children }: { children: React.ReactNode }) {
  const { user } = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const token = localStorage.getItem('token');
  const isMounted = useIsMounted();
  const dispatch = useDispatch();

  useEffect(() => {
    // remove style from body for crm panel only
    // in future, add below css to helium layout files only but not add to auth route
    document.body.style.overflow = 'hidden';
  }, []);

  useEffect(() => {
    // Tab Close
    window.addEventListener('beforeunload', (event) => {
      event.stopPropagation();
      console.log('signIn -- Tab or window is about to be closed');
      if (!!user?.data?.user?._id) {
        console.log('Window close');
        socket.emit('USER_DISCONNECTED', { user_id: user?.data?.user?._id });
      }
    });

    // Tab Change
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        console.log('signIn -- Tab is hidden or minimized');
        if (!!user?.data?.user?._id) {
          socket.emit('USER_DISCONNECTED', { user_id: user?.data?.user?._id });
        }
      } else if (document.visibilityState === 'visible') {
        console.log('signIn -- Tab is active');
        if (!!user?.data?.user?._id && !!defaultWorkSpace?._id && !!token) {
          dispatch(getActiveTaskTime());
          socket.disconnect();
          socket.connect();
          socket.emit('ROOM', {
            id: user?.data?.user?._id,
            workspace_id: defaultWorkSpace?._id,
          });
        }
      }
    });
  }, [defaultWorkSpace?._id, user?.data?.user?._id, token, dispatch]);

  if (!isMounted) {
    return null;
  }

  return <HeliumLayout>{children}</HeliumLayout>;
}

export default WithAuth(DefaultLayout);
