'use client';

import ViewTaskForm from '@/app/shared/(user)/task/create-edit/view-task-form';
import { useDrawer } from '@/app/shared/drawer-views/use-drawer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { ActionIcon } from '@/components/ui/action-icon';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Empty } from '@/components/ui/empty';
import { Popover } from '@/components/ui/popover';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import {
  getAllnotification,
  readnotification,
} from '@/redux/slices/soket/notification/notificationSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import chat_notification_icn_new from '@public/assets/images/chat_notification_icn_new.png';
import check_icn_new from '@public/assets/images/check_icn_new.png';
import filter_icn from '@public/assets/images/fitler_icn.png';
import sort_icn from '@public/assets/images/sort_icn.png';
import * as dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

dayjs.extend(relativeTime);

const meargeNotification = (oldResponse: any, newResponse: any) => {
  for (const key in newResponse) {
    if (oldResponse.hasOwnProperty(key)) {
      oldResponse[key] = [...oldResponse[key], ...newResponse[key]];
    } else {
      oldResponse[key] = newResponse[key];
    }
  }
  return oldResponse;
};

const notificationFilter = [
  {
    name: 'All',
    value: '',
  },
  {
    name: 'Activity',
    value: 'activity',
  },
  {
    name: 'Super Admin',
    value: 'agency',
  },
  {
    name: 'Agreement',
    value: 'agreement',
  },
  {
    name: 'Board',
    value: 'board',
  },
  {
    name: 'Deleted',
    value: 'deleted',
  },
  {
    name: 'General',
    value: 'general',
  },
  {
    name: 'Invoice',
    value: 'invoice',
  },
  {
    name: 'Payment',
    value: 'payment',
  },
  {
    name: 'Referral',
    value: 'referral',
  },
  {
    name: 'Task',
    value: 'task',
  },
];

const notificationSorting = [
  {
    name: 'Newest',
    value: 'sort_order=desc',
  },
  {
    name: 'Oldest',
    value: 'sort_order=asc',
  },
];

export default function Notificationpage() {
  const { openDrawer, closeDrawer } = useDrawer();
  const notification = useSelector((state: any) => state?.root?.notification);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { loading } = useSelector((state: any) => state?.root?.notification);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const [payload, setPalyload] = useState({
    skip: 0,
    limit: 5,
  });
  const [isChecked, setIsChecked] = useState(false);
  const [updatedData, setUpdateddata] = useState<any>({});
  const [viewmoreLoader, setViewMoreloader] = useState(false);
  const [hideviewmorebutton, sethideviewmorebutton] = useState(false);
  const [filterName, setfilterName] = useState({ name: 'All', value: '' });
  const [sortName, setSortName] = useState({
    name: 'Newest',
    value: 'sort_order=desc',
  });

  const { closeModal, openModal } = useModal();
  const router = useRouter();
  const dispatch = useDispatch();

  const getRelativeDate = (date: any) => {
    // Parse the given date using Moment.js
    const givenDate = moment(date);

    // Get today's date and yesterday's date
    const today = moment().startOf('day');
    const yesterday = moment().subtract(1, 'days').startOf('day');

    // Compare the given date with today and yesterday
    if (givenDate.isSame(today, 'day')) {
      return 'Today';
    } else if (givenDate.isSame(yesterday, 'day')) {
      return 'Yesterday';
    } else {
      return givenDate.format('DD-MM-YYYY');
    }
  };

  useEffect(() => {
    dispatch(getAllnotification(payload)).then((result: any) => {
      if (result && result.payload?.data?.notificationList) {
        setViewMoreloader(false);

        const notificationFinal = meargeNotification(
          updatedData,
          result?.payload?.data?.notificationList[0]
        );
        setUpdateddata({
          ...notificationFinal,
        });

        // if (result?.payload?.data?.page_count < 5) {
        sethideviewmorebutton(true);
        // }
      }
    });
  }, [payload]);

  //redirect routes and open popup
  const handleNotificationClick = async (item: any, date: any) => {
    updatedData[date]?.map((notification: any) => {
      if (notification._id === item._id) {
        // Found the matching item, only change its is_read property
        return { ...notification, is_read: true };
      }
      // Return the item unchanged if it doesn't match
      return notification;
    });

    setUpdateddata(updatedData);

    //read notification
    if (!item?.is_read) {
      const res = await dispatch(
        readnotification({ notification_id: item._id })
      );
      if (res?.payload?.success === true) {
        dispatch(getAllnotification(payload)).then((result: any) => {});
      }
    }

    const data = {
      _id: item?.data_reference_id,
    };
    switch (item.type) {
      case 'activity':
        router.push(
          `${routes.meetings(defaultWorkSpace?.name)}?meeting_id=${data?._id}`
        );
        break;
      case 'task':
        router.push(
          `${routes.boardDetails(
            defaultWorkSpace?.name,
            item?.board_data?._id
          )}?task_id=${data?._id}`
        );
        break;
      case 'invoice':
        if (signIn?.role == 'client') {
          router.push(
            routes?.clients?.invoicedetails(
              defaultWorkSpace?.name,
              item?.data_reference_id
            )
          );
        } else {
          router.push(
            routes.invoiceView(defaultWorkSpace?.name, item?.data_reference_id)
          );
        }
        break;
      case 'agreement':
        if (signIn?.role == 'client') {
          router.push(
            routes?.clients.viewagreement(
              defaultWorkSpace?.name,
              item?.data_reference_id
            )
          );
        } else {
          router.push(
            routes.viewAgreement(
              defaultWorkSpace?.name,
              item?.data_reference_id
            )
          );
        }
        break;
      case 'other':
        router.push(routes.meetings(defaultWorkSpace?.name));
        setTimeout(() => {
          openModal({
            view: <ViewTaskForm data={data} />,
            customSize: '700px',
          });
        }, 2000);
        break;

      case 'board':
        router.push(routes.task(defaultWorkSpace?.name));
        break;

      default:
        '';
    }
  };

  const allnotification = async () => {
    setIsChecked(!isChecked);
    const res = await dispatch(readnotification({ notification_id: 'all' }));
    if (res?.payload?.success === true) {
      setIsChecked(false);
      dispatch(getAllnotification({ skip: 0, limit: 5 })).then(
        (result: any) => {
          if (result && result.payload?.data?.notificationList) {
            setUpdateddata(result?.payload?.data?.notificationList[0]);
          }
        }
      );
    }
  };

  const viewAllActivity = () => {
    setViewMoreloader(true);
    setPalyload({
      ...payload,
      skip: payload.skip + 5,
    });
  };
  //api call

  // Filter Notitfication
  const filterNotification = (filterValue: any) => {
    setfilterName(filterValue);
    setUpdateddata({});
    setPalyload((prev) => {
      return {
        ...prev,
        type: filterValue?.value,
      };
    });
  };

  // Sort Notification
  const sortNotification = (sortValue: any) => {
    setSortName(sortValue);
    setUpdateddata({});
    setPalyload((prev) => {
      return {
        ...prev,
        sort: sortValue?.value,
      };
    });
  };

  // Get Avatar Image
  const getAvatarImage = (data: any) => {
    let avatarURL = process.env.NEXT_PUBLIC_IMAGE_URL + '/uploads/';
    if (data?.profile_image) avatarURL += data?.profile_image;
    return avatarURL;
  };

  // Get Avatar Name
  const getAvatarName = (data: any) => {
    let displayName = '';
    if (data?.first_name) displayName += data?.first_name;
    if (data?.last_name) displayName += ' ' + data?.last_name;
    return displayName;
  };

  console.log(notification?.notification, 'notification');
  console.log(updatedData, 'updatedData');

  return (
    <div className="w-full text-left  rtl:text-right">
      <div className="mb-3 flex items-center justify-between ps-6">
        <CustomePageHeader
          title="Notifications"
          titleClassName="montserrat_font_title"
        />
      </div>
      {/* main card start here */}
      <div className="rounded-lg bg-white ">
        {/* filter header sections */}
        <div className="flex flex-col items-center justify-between border-b-2 border-[#E3E1F4] p-4 lg:flex-row">
          {/* filter and sort */}
          <div className="flex w-full flex-row items-start justify-start">
            {/* filter */}
            <div className="">
              <Popover
                placement="bottom"
                className="gap-2"
                content={({ setOpen }) => (
                  <div className="flex w-full flex-col items-start justify-start text-gray-900">
                    {notificationFilter?.map((filter: any) => {
                      return (
                        <div key={filter?.value}>
                          <Button
                            onClick={() => (
                              filterNotification(filter), setOpen(false)
                            )}
                            variant="text"
                            className="flex w-[150px] items-start justify-start  hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                          >
                            {filter?.name}
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                )}
              >
                <ActionIcon className="w-full" title={'Filter'} variant="text">
                  <div className="flex flex-row items-center justify-start">
                    <Image src={filter_icn} alt="Description of the image" />
                    <p className="ms-4 text-sm font-bold text-[#9BA1B9]">
                      {filterName?.name}
                    </p>
                  </div>
                </ActionIcon>
              </Popover>
            </div>
            {/* sort */}
            <div className="">
              <Popover
                placement="bottom"
                className="gap-2"
                content={({ setOpen }) => (
                  <div className="flex w-full flex-col items-start justify-start text-gray-900">
                    {notificationSorting?.map((sort: any) => {
                      return (
                        <div key={sort?.value}>
                          <Button
                            onClick={() => (
                              sortNotification(sort), setOpen(false)
                            )}
                            variant="text"
                            className="flex w-[150px] items-start justify-start  hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                          >
                            {sort?.name}
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                )}
              >
                <ActionIcon title={'Filter'} variant="text" className="w-full">
                  <div className="ms-8 flex w-full flex-row items-center justify-start">
                    <Image src={sort_icn} alt="Description of the image" />
                    <span className="ms-4 text-sm font-bold text-[#9BA1B9]">
                      Sort: {sortName?.name}
                    </span>
                  </div>
                </ActionIcon>
              </Popover>
            </div>
          </div>
          {/* mark all as read */}
          <div className="mt-4 flex w-full justify-start lg:mt-0 lg:justify-end">
            <Checkbox
              inputClassName="checkbox-color"
              label="Mark all as Read"
              onChange={allnotification}
              checked={isChecked}
              className="text-[14px] font-bold text-[#9BA1B9]"
            />
          </div>
        </div>

        {Object.keys(updatedData).length > 0 &&
          Object.keys(updatedData)?.map((notificationDate: any) => {
            return (
              <>
                <div
                  key={notificationDate}
                  className="my-2 flex items-center justify-start border-b-2 border-[#E3E1F4]"
                >
                  <p className="poppins_font_number p-4 text-[20px] font-bold text-[#9BA1B9]">
                    {getRelativeDate(notificationDate)}
                  </p>
                </div>
                {updatedData[notificationDate].length > 0 &&
                  updatedData[notificationDate]?.map(
                    (notificationData: any) => {
                      return (
                        <div
                          className={`cursor-pointer ${
                            notificationData?.is_read
                              ? 'bg-[#F6F6FB]'
                              : 'bg-[#ffffff]'
                          }`}
                          key={notificationData}
                          onClick={() =>
                            handleNotificationClick(
                              notificationData,
                              notificationDate
                            )
                          }
                        >
                          <div className="flex w-full flex-col items-center justify-between p-4">
                            {/* name and overdue */}

                            {notificationData?.type == 'task' && (
                              <>
                                <div className="flex w-full flex-row items-center justify-between">
                                  <div className="flex items-center">
                                    {notificationData?.board_data
                                      ?.board_image ? (
                                      <Avatar
                                        size="sm"
                                        src={
                                          process.env.NEXT_PUBLIC_IMAGE_URL +
                                          '/' +
                                          notificationData?.board_data
                                            ?.board_image
                                        }
                                        name={
                                          notificationData?.board_data
                                            ?.project_name
                                        }
                                        className=" text-white"
                                      />
                                    ) : (
                                      <div
                                        className="flex !h-8 !w-8 items-center justify-center rounded-full border-white"
                                        style={{
                                          backgroundColor:
                                            notificationData?.board_data
                                              ?.board_color,
                                        }}
                                      ></div>
                                    )}
                                    <span className="poppins_font_number ms-2 text-[14px] font-semibold text-[#9BA1B9]">
                                      {' '}
                                      {capitalizeFirstLetter(
                                        notificationData?.board_data
                                          ?.project_name
                                      )}{' '}
                                    </span>
                                  </div>
                                  <div className="flex items-end">
                                    <span className="poppins_font_number text-sm font-semibold text-[#AC2D2D]">
                                      {
                                        notificationData?.section_data
                                          ?.section_name
                                      }
                                    </span>
                                  </div>
                                </div>
                              </>
                            )}

                            {/* title and comments */}
                            <div className="flex w-full flex-col items-center justify-start lg:flex-row lg:justify-between">
                              <div className="mt-4 flex w-full items-start justify-start">
                                <Image src={check_icn_new} alt="check icon" />
                                <p className="poppins_font_number ms-4 break-all text-[20px] font-semibold text-[#000000]">
                                  {notificationData?.message}
                                </p>
                                <span className="poppins_font_number ms-2 text-[14px] font-semibold text-[#9BA1B9]">
                                  {moment(
                                    new Date(notificationData?.createdAt)
                                  ).format('h:mm A')}
                                </span>
                              </div>

                              {notificationData?.type == 'task' && (
                                <div className="mt-4 flex w-full items-start  justify-start lg:mt-0 lg:justify-end">
                                  <div className="flex items-center rounded-full bg-[#8C80D2] px-2 py-1">
                                    <span className="poppins_font_number text-[12px] font-semibold text-white">
                                      {notificationData?.comment_count}
                                    </span>
                                    <Image
                                      src={chat_notification_icn_new}
                                      alt="chat icon"
                                      className="ms-2"
                                      width={8}
                                      height={8}
                                    />
                                  </div>
                                </div>
                              )}
                            </div>
                            {/* end title and comments */}
                            {notificationData?.type == 'task' && (
                              <div className="mt-2 flex w-full flex-row items-start justify-start lg:items-center">
                                <div className="flex items-center justify-start">
                                  <div className="">
                                    <Avatar
                                      src={getAvatarImage(
                                        notificationData?.assigned_by_data
                                      )}
                                      name={getAvatarName(
                                        notificationData?.assigned_by_data
                                      )}
                                      className="text-white"
                                    />
                                  </div>
                                  <div className="ms-2 flex flex-col items-start justify-start gap-2 text-wrap lg:flex-row">
                                    <div>
                                      <p className="poppins_font_number text-[16px] font-semibold text-[#000000] ">
                                        {capitalizeFirstLetter(
                                          notificationData?.assigned_by_data
                                            ?.first_name
                                        )}{' '}
                                        {capitalizeFirstLetter(
                                          notificationData?.assigned_by_data
                                            ?.last_name
                                        )}
                                      </p>
                                    </div>
                                    <div>
                                      <span className="poppins_font_number text-[16px font-medium]">
                                        assigned to{' '}
                                        {
                                          notificationData?.assign_to_data
                                            ?.email
                                        }
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                {/* <div className=" ms-4 h-2 w-2 rounded-full bg-red-600"></div> */}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    }
                  )}
              </>
            );
          })}

        {loading && (
          <div className="flex justify-center py-4">
            <Spinner size="lg" tag="div" className="ms-3" />
          </div>
        )}
        {!loading && hideviewmorebutton && (
          <Link
            href={'#'}
            onClick={viewAllActivity}
            className="-me-6 block px-6 pb-0.5 pt-3 text-center hover:underline"
          >
            <div className="flex">
              Load more
              {viewmoreLoader && (
                <Spinner size="sm" tag="div" className="ms-3" />
              )}
            </div>
          </Link>
        )}

        {!loading && Object.keys(updatedData).length == 0 && (
          <div className="py-4">
            <Empty
              text="No Notification"
              textClassName="mt-4 text-base text-gray-500"
            />
          </div>
        )}
      </div>
    </div>
  );
}
