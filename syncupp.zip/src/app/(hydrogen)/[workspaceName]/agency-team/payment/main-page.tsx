"use client";

import withRoleAuth from "@/AuthGuard/withRoleAuth";
import { useModal } from "@/app/shared/modal-views/use-modal";
import { CustomePageHeader } from "@/components/pageheader/pageheader";
import Spinner from "@/components/ui/spinner";
import { roles } from "@/config/roles";
import { routes } from "@/config/routes";
import { getAllTeamMember, refferalPayment } from "@/redux/slices/user/team-member/teamSlice";
import { initiateRazorpay } from "@/services/clientpaymentService";
import cn from "@/utils/class-names";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button } from "rizzui";


function AgreementTeamPaymentPage() {

    const token = localStorage.getItem('token')

    const router = useRouter();
    const dispatch = useDispatch();
    const { closeModal } = useModal();

    const { addClientteamdetails, refferalStatisticsData, paginationParams } = useSelector((state: any) => state?.root?.teamMember);
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace)

    // const paginationParams = useSelector((state: any) => state?.root?.teamMember?.paginationParams);
    // console.log(addClientteamdetails, 'addClientteamdetails')
    // const { userProfile } = useSelector((state: any) => state?.root?.signIn);
    const { loading } = useSelector((state: any) => state?.root?.payment);

    const [loadingflag, setloadingflag] = useState(false)
    const [selectedValue, setSelectedValue] = useState('option2Value');
    // console.log(selectedValue, 'selectedValue')

    const ClintteamlistAPIcall = async () => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;
        await dispatch(getAllTeamMember({ page, items_per_page, sort_field, sort_order, search, pagination: true }));

    }

    const handleRadioChange = (event: any) => {
        setSelectedValue(event.target.value);
    };


    const handlePaymentApiCall = () => {

        if (selectedValue === 'option1Value') {
            setloadingflag(true)
            dispatch(refferalPayment({ user_id: addClientteamdetails?.data?._id })).then((result: any) => {
                if (refferalPayment.fulfilled.match(result)) {
                    if (result && result.payload.success === true) {
                        dispatch(getAllTeamMember({ sort_field: 'createdAt', sort_order: 'desc', pagination: true }));
                        setloadingflag(false)
                        router.replace(routes?.agency_team(defaultWorkSpace?.name))
                    } else {
                        setloadingflag(false)
                    }
                } else {
                    setloadingflag(false)
                }
            });
        } else {
            initiateRazorpay(router, routes.agency_team(defaultWorkSpace?.name), token, addClientteamdetails?.data?._id, ClintteamlistAPIcall, setloadingflag, closeModal)
        }

    }


    return (
        <>
            <CustomePageHeader title="Payment" route={routes?.agency_team(defaultWorkSpace?.name)} titleClassName='montserrat_font_title' />

            <div
                className={cn(
                    'isomorphic-form mt-[20px] isomorphic-form mx-auto flex w-full max-w-[1536px] flex-grow flex-col @container [&_label.block>span]:font-medium'
                )}
            >
                <div className="items-start @5xl:grid @5xl:grid-cols-12 @5xl:gap-7 @6xl:grid-cols-10 @7xl:gap-10">
                    <div className="gap-4 border-gray-200 @container @5xl:col-span-8 @5xl:border-e @5xl:pb-12 @5xl:pe-7 @6xl:col-span-7 @7xl:pe-12">
                        <div className="flex flex-col gap-4 @xs:gap-7 @5xl:gap-9">
                            {/* <Title as="h4" className="mb-3.5 font-semibold @2xl:mb-5">
                                Payment
                            </Title> */}

                            <div className="rounded-2xl bg-white cursor-pointer" onClick={() => setSelectedValue('option1Value')}>
                                <div className="px-3 py-2">
                                    <input
                                        type="radio"
                                        id="option1"
                                        name="options"
                                        value="option1Value"
                                        checked={selectedValue === "option1Value"}
                                        onChange={handleRadioChange}
                                    />
                                </div>
                                <div className="p-4 @xs:p-6 @2xl:flex @2xl:items-start @2xl:justify-between @2xl:gap-6">
                                    <div className="block @5xl:pe-8">
                                        <div className="mb-2.5 text-base text-[16px] font-semibold text-[#8C80D2]">
                                            Purchase with Referral points
                                        </div>
                                        <div className="text-[14px] font-medium text-[#9BA1B9] flex gap-2">
                                            {/* Comming soon... */}
                                            Referral points : <span className="poppins_font_number text-[#120425]">{refferalStatisticsData?.referral_point}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="rounded-2xl bg-white cursor-pointer" onClick={() => setSelectedValue('option2Value')}>
                                <div className="px-3 py-2">
                                    <input
                                        type="radio"
                                        id="option2"
                                        name="options"
                                        value="option2Value"
                                        checked={selectedValue === "option2Value"}
                                        onChange={handleRadioChange}
                                    />
                                </div>
                                <div className="p-4 @xs:p-6 @2xl:flex @2xl:items-start @2xl:justify-between @2xl:gap-6">
                                    <div className="block @5xl:pe-8">
                                        <div className="mb-2.5 text-base text-[16px] font-semibold text-[#8C80D2]">
                                            Subscription
                                        </div>
                                        <div className="text-[14px] font-medium text-[#9BA1B9] flex gap-2">
                                            Subscription Amount : <span className="poppins_font_number text-[#120425]">{refferalStatisticsData?.payable_amount}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        className={cn(
                            'sticky top-24 mt-8 @5xl:col-span-4 @5xl:mt-0 @6xl:col-span-3 2xl:top-28 rounded-2xl bg-white p-[24px]',

                        )}
                    >
                        <div className="mb-3 text-[18px] font-semibold text-[#8C80D2]">
                            Your Order
                        </div>
                        <div className="rounded-2xl border border-gray-200 p-4 @xs:p-6 @5xl:rounded-none @5xl:border-none @5xl:px-0">
                            <div className="pt-4 @xl:pt-6">
                                <div className="mb-4 flex items-center justify-between last:mb-0 text-[16px] font-medium text-[#9BA1B9]">
                                    {selectedValue === 'option2Value' ? "Subscription Amount" : "Referral Amount"}
                                    <div className="text-[14px] font-medium poppins_font_number text-[#120425]">
                                        {/* {subtotal} */}
                                        {selectedValue === 'option2Value' ? refferalStatisticsData?.payable_amount : refferalStatisticsData?.redeem_required_point}
                                    </div>
                                </div>
                                <div className="flex items-center justify-between border-t border-gray-200 py-4 text-base font-bold text-[#120425]">
                                    Total
                                    <div className="text-[14px] font-medium poppins_font_number text-black">{selectedValue === 'option2Value' ? refferalStatisticsData?.payable_amount : refferalStatisticsData?.redeem_required_point}</div>
                                </div>
                                <Button
                                    disabled={loadingflag}
                                    onClick={handlePaymentApiCall}
                                    type="button"
                                    className="mt-3 w-full bg-[#8C80D2] text-white h-12 text-sm"
                                >
                                    Check out
                                    {loadingflag && <Spinner size="sm" tag='div' className='ms-3' color='white' />}
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default withRoleAuth([roles.agency])(AgreementTeamPaymentPage); 
