'use client';

import withRoleAuth from '@/AuthGuard/withRoleAuth';
import AddTeamMemberForm from '@/app/shared/(user)/agency/agency-team/create-edit/add-team-member-form';
import { GetclientTeamColumns } from '@/app/shared/(user)/agency/agency-team/team-list/columns';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import ImportButton from '@/app/shared/import-button';
import ModalButton from '@/app/shared/modal-button';
import { useModal } from '@/app/shared/modal-views/use-modal';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Select from '@/components/ui/select';
import { roles } from '@/config/roles';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  RemoveTeamMemberTableData,
  deleteTeamMember,
  getAllTeamMember,
  setPagginationParams,
} from '@/redux/slices/user/team-member/teamSlice';
import {
  getStepsByRole,
  teamMemberTourStepsContent,
} from '@/utils/tour-steps/tour-steps';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { PiCaretDownBold, PiPlusBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import DeleteModel from './confirmationPopup';
import cn from '@/utils/class-names';

const pageHeader = {
  title: 'Team',
};

let statusOptionsDropdown: Record<string, any>[] = [
  { name: 'All', value: '' },
  { name: 'Payment Pending', value: 'payment_pending' },
  { name: 'Active', value: 'confirmed' },
  { name: 'Pending', value: 'confirm_pending' },
  { name: 'Requested', value: 'requested' },
  { name: 'Rejected', value: 'rejected' },
];

function TeamDataTablePage() {
  const dispatch = useDispatch();
  const [pageSize, setPageSize] = useState(10);
  const { closeModal, openModal } = useModal();
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const { permission } = useSelector((state: any) => state?.root?.signIn);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  // const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const [data, setData] = useState([]);
  const [statusOption, setStatusOption] = useState('');
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reset, setReset] = useState('');
  const [statusType, setStatusType] = useState('');
  const [sortObject, setSortObject] = useState({});
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    dispatch(RemoveTeamMemberTableData(''));
  }, [dispatch]);

  useEffect(() => {
    setData(teamMemberData?.data?.teamMemberList);
  }, [teamMemberData?.data]);

  useEffect(() => {
    if (
      statusType !== '' ||
      period !== '' ||
      startDate !== '' ||
      endDate !== ''
    ) {
      setReset('');
    }
  }, [statusType, period, startDate, endDate]);

  // Api call for Tour status get
  useEffect(() => {
    // Tour comment
    dispatch(getAllTourStatus());
  }, []);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [teamMemberModuleTourSteps, setTeamMemberModuleTourSteps] = useState(
    []
  );

  // Handle close tour
  const handleCloseTour = () => {
    dispatch(
      updateTourStatus({ team_member: { create_team_member_tour: true } })
    ).then((result: any) => {
      if (updateTourStatus.fulfilled.match(result)) {
        if (result?.payload?.success) {
          setIsTourOpen(false);
          // Tour comment
          dispatch(getAllTourStatus());
        }
      }
    });
  };

  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.team_member &&
      Object?.keys(tourStatusData?.team_member).includes(
        'create_team_member_tour'
      ) &&
      !tourStatusData?.team_member?.create_team_member_tour
    ) {
      setTeamMemberModuleTourSteps([]);
      setIsTourOpen(false);
      const teamMemberTourStepContent = teamMemberTourStepsContent(
        handleCloseTour,
        signIn,
        checkPermission
      );

      const teamMemberModuleTourStep = getStepsByRole(
        teamMemberTourStepContent
      );
      teamMemberModuleTourStep?.length > 0 &&
        setTeamMemberModuleTourSteps(teamMemberModuleTourStep);
      teamMemberModuleTourStep?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData, signIn?.permission]);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    console.log(
      page,
      items_per_page,
      sort_field,
      sort_order,
      search,
      'page, items_per_page, sort_field, sort_order, search'
    );

    setSortObject({ page, items_per_page, sort_field, sort_order, search });

    await dispatch(setPagginationParams(paginationParams));
    const response = await dispatch(
      getAllTeamMember({
        page,
        items_per_page,
        sort_field,
        sort_order,
        filter: {
          status: statusType,
          date: { start_date: startDate, end_date: endDate },
        },
        search,
        pagination: true,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllTeamMember({
          page,
          items_per_page,
          sort_field,
          sort_order,
          filter: {
            status: statusType,
            date: { start_date: startDate, end_date: endDate },
          },
          search,
          pagination: true,
        })
      );
      return data?.teamMemberList;
    }
    if (data && data?.teamMemberList && data?.teamMemberList.length !== 0) {
      return data?.teamMemberList;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      const res = await dispatch(
        deleteTeamMember({ teamMemberIds: id })
        // Work Later
        // deleteTeamMember({ teamMemberIds: id, force_fully_remove: false })
      );

      if (res?.payload?.data?.force_fully_remove === true) {
        openModal({
          view: (
            <DeleteModel
              forsfully={res?.payload?.data?.force_fully_remove}
              id={id}
              page={currentPage}
              items_per_page={countPerPage}
              sort_field={sortConfig?.key}
              sort_order={sortConfig?.direction}
              search={searchTerm}
              pagination={true}
            />
          ),
          customSize: '500px',
        });
      }

      if (res.payload.success && !res.payload.data?.force_fully_remove) {
        const reponse = await dispatch(
          getAllTeamMember({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            filter: {
              status: statusType,
              date: { start_date: startDate, end_date: endDate },
            },
            search: searchTerm,
            pagination: true,
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleStatusChange = (selectedOption: Record<string, any>) => {
    setStatusType(selectedOption?.value);

    if (selectedOption?.value == '') {
      dispatch(
        getAllTeamMember({
          page: 1,
          filter: {
            date: {
              start_date: startDate,
              end_date: endDate,
            },
          },
          ...sortObject,
          pagination: true,
        })
      );
      return;
    }

    dispatch(
      getAllTeamMember({
        page: 1,
        filter: {
          status: selectedOption.value,
          date: {
            start_date: startDate,
            end_date: endDate,
          },
        },
        ...sortObject,
        pagination: true,
      })
    );
  };

  useEffect(() => {
    if (endDate) {
      dispatch(
        getAllTeamMember({
          page: 1,
          ...sortObject,
          filter: {
            status: statusType,
            date: {
              start_date: startDate,
              end_date: endDate,
            },
          },
          pagination: true,
        })
      );
    }
  }, [endDate]);

  const handleResetFilters = () => {
    setStatusType('');
    setStatusOption('');
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setReset('reset');

    dispatch(
      getAllTeamMember({
        sort_field: 'createdAt',
        sort_order: 'desc',
        pagination: true,
        ...sortObject,
        page: 1,
      })
    );
  };

  const FilterList = () => {
    return (
      <>
        <Select
          options={statusOptionsDropdown}
          onChange={(selectedOption: Record<string, any>) => {
            setStatusOption(selectedOption?.name);
            handleStatusChange(selectedOption);
          }}
          value={statusOption}
          placeholder="Select Status"
          // getOptionValue={(option) => option.value}
          className="w-full"
          selectClassName="!text-black"
        // dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
        />
        <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
      </>
    );
  };

  return (
    <>
      <Tour
        steps={teamMemberModuleTourSteps ?? []}
        isOpen={isTourOpen}
        rounded={10}
        closeWithMask={false}
        disableInteraction={true}
        disableKeyboardNavigation={['esc']}
        onRequestClose={handleCloseTour}
        className="poppins_font_number tour-close-button font-semibold text-black"
      />
      <CustomePageHeader
        title={pageHeader.title}
        titleClassName="montserrat_font_title"
      >
        {(['team_agency', 'team_client'].includes(signIn.role)
          ? checkPermission('teams', null, 'create', permission)
          : true) && (
            <div className="relative flex items-center gap-2">
              <Button
                rounded="lg"
                className="team-member-tour-step-one flex h-10 min-w-[150px] w-[220px] items-center justify-start gap-2 bg-[#8C80D2] text-sm text-white"
                onClick={() => {
                  openModal({
                    view: (
                      <AddTeamMemberForm title="New Team Member" isEdit={false} />
                    ),
                    customSize: "600px"
                  });
                  setShowDropdown(false);
                }}
              >
                <PiPlusBold className="h-4 w-4 mr-2" />
                <span>Add Team member</span>
                {/* Dropdown Icon */}
                <div
                  className="absolute right-3 top-1/2 flex h-full -translate-y-1/2 transform cursor-pointer items-center border-l-2 border-gray-400 pl-3"
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent button click
                    setShowDropdown((prev) => !prev); // Toggle dropdown visibility
                  }}
                >
                  <PiCaretDownBold className="h-4 w-4 text-white" />
                </div>
              </Button>
              {/* Dropdown Content */}
              {showDropdown && (
                <>
                  {!defaultWorkSpace?.trial_end_date && (
                    <ImportButton
                      modalBtnLabel="Import File"
                      className="absolute right-0 top-full z-10 mt-2 h-10 w-[200px] rounded-lg !bg-white"
                      isAgencyTeamModule={true}
                      buttonLabel="Import teams in bulk"
                    />
                  )}
                </>
              )}
            </div>
          )}
      </CustomePageHeader>
      <WidgetCard rounded="lg" title="">
        <div className="table_border_remove">
          <CustomTable
            data={data}
            total={teamMemberData && teamMemberData?.data?.page_count}
            loading={teamMemberData && teamMemberData?.loading}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={GetclientTeamColumns}
            scroll={{ x: 1100 }}
            filtersList={<FilterList />}
            moduleName="activity"
            setPeriod={setPeriod}
            setStartDate={setStartDate}
            setEndDate={setEndDate}
            isRangeFilter={true}
            resetValue={reset}
          />
        </div>
      </WidgetCard>
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'teams',
  null,
  'view'
)(TeamDataTablePage);
