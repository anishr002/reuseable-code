
import { metaObject } from '@/config/site.config';
import MyCouponsPage from './main-page';


export const metadata = {
    ...metaObject('Redeemed Coupons'),
};

export default function Page() {
    return (
        <>
            <MyCouponsPage />
        </>
    );
}
