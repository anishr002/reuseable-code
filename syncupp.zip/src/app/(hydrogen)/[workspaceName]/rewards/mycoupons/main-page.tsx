'use client';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import Spinner from '@/components/ui/spinner';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import { getMyCouponsData } from '@/redux/slices/user/cuppons/couponsSlice';
import { couponColor } from '@/utils/common-functions';
import PlaceholderImg from '@public/img_Placeholder.png.png';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { MdContentCopy } from 'react-icons/md';
import { useDispatch, useSelector } from 'react-redux';
import { Empty, Text } from 'rizzui';


function MyCouponsPage() {
  const dispatch = useDispatch();

  const { Cupponlistdetails, loading, MyCupponlistdetails, purchaseloader } =
    useSelector((state: any) => state?.root?.coupon);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  // console.log(Cupponlistdetails, 'Cupponlistdetails', MyCupponlistdetails)

  const [selectedindex, setselectedindex] = useState(null);

  useEffect(() => {
    dispatch(getMyCouponsData());
  }, []);

  //copy link
  const handleCopyToClipboard = async (item: any) => {
    try {
      await window?.navigator?.clipboard?.writeText(item?.couponCode);
      toast.success('Coupon code copied to clipboard');
    } catch (error) {
      console.error('Error copying URL:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <>
      {/* My Coupons list  */}
      <>
        <div className="">
          <CustomePageHeader
            route={routes.rewards(defaultWorkSpace?.name)}
            title="Redeemed Coupons"
            titleClassName="montserrat_font_title"
          />

          <WidgetCard rounded="lg" title="">
            {MyCupponlistdetails?.data &&
            MyCupponlistdetails?.data?.length > 0 ? (
              <div className="grid grid-cols-3 gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 ">
                {MyCupponlistdetails?.data?.map((item: any, index: number) => (
                  <div
                    key={index}
                    className="rounded-[20px] border-[12px] border-[#FBF0DE]"
                  >
                    <div
                      key={index}
                      className="rounded-lg border border-gray-300 bg-white h-full"
                    >
                      <div className="flex justify-end pe-3 pt-3 font-bold text-[#9BA1B9]">
                        <MdContentCopy
                          onClick={() => handleCopyToClipboard(item)}
                          className="h-5 w-5 cursor-pointer"
                        />
                      </div>
                      <a target='_blank' href={item?.siteURL}>
                        <div className="flex items-center justify-start px-3">
                          {item?.brandLogo && item?.brandLogo != '' ? (
                            <Image
                              alt="logo"
                              className="m-3 h-[66px] w-[66px] rounded-full border object-contain	"
                              width="65"
                              height="65"
                              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${item?.brandLogo}`}
                            />
                          ) : (
                            <Image
                              alt="logo"
                              className="m-3 h-[66px] w-[66px] rounded-full border object-contain	"
                              width="65"
                              height="65"
                              src={PlaceholderImg}
                            />
                          )}

                          <div className="ps-3">
                            <p className="text-sm font-bold capitalize text-gray-500 poppins_font_number">
                              {item?.brand}
                            </p>
                            <p className="mt-0.5 text-xl font-bold capitalize text-[#120425] poppins_font_number">
                              {item?.discountTitle}
                            </p>
                          </div>
                        </div>
                      </a>
                      <div className="flex items-center justify-start px-4 pb-3">
                        <div className="font-bold text-[#9BA1B9]">
                          Code : <span className='poppins_font_number'>
                          {item?.couponCode}
                          </span>
                        </div>
                        {/* <div className="text-[#9BA1B9] font-bold">
                                                {moment(item?.createdAt).format("Do MMM. ‘YY")}
                                            </div> */}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mb-5 mt-2 rounded-xl border border-gray-300 py-5 text-center lg:py-8">
                <Empty /> <Text className="mt-3">No Coupons Found</Text>
              </div>
            )}
          </WidgetCard>
        </div>
      </>
    </>
  );
}

export default withRoleAuth([
  roles.agency,
  roles.teamAgency.team_agency
])(MyCouponsPage);
