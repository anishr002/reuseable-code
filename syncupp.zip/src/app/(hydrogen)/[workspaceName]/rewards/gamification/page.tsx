import { metaObject } from '@/config/site.config';
import GamificationPage from './main-page';

export const metadata = {
  ...metaObject('Total Points'),
};

export default function Page() {
  return (
    <>
      <div className="main_card_block">
        <GamificationPage />
      </div>
    </>
  );
}
