"use client";

import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, usePathname, useRouter, useSearchParams } from 'next/navigation';
import CustomTable from '@/components/common-tables/table';
import { AgreementColumns } from '@/app/shared/agreement/columns';
import PageHeader from '@/app/shared/page-header';
import Spinner from '@/components/ui/spinner';
import { GamificationColumns } from '@/app/shared/(user)/gamification/coloumn';
import { getAllGamification, getGamificationpointsDetails, resetdamificationlist } from '@/redux/slices/user/gamification/gamificationSlice';
import RefundIcon from '@/components/icons/refund';
import { Button, Checkbox, Title } from 'rizzui';
import Link from 'next/link';
import cn from '@/utils/class-names';
import { routes } from '@/config/routes';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import ReactSelect, { components } from 'react-select';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import React from 'react';
import Image from 'next/image';
import { getAllAssignees } from '@/redux/slices/user/task/boardSlice';
import { result } from 'lodash';

const pageHeader = {
    title: 'Total Points',
};


// const Statusoptions = [
//     { name: 'All', value: '' },
//     { name: 'Draft', value: 'draft' },
//     { name: 'Sent', value: 'sent' },
//     { name: 'Agreed', value: 'agreed' }
// ]


function GamificationPage() {

    const dispatch = useDispatch();
    const router = useRouter();
    const [pageSize, setPageSize] = useState(10)
    const [reset, setReset] = useState(false);
    const { data, assignees } = useSelector((state: any) => state?.root?.board);
    const [assignee, setAssignee] = useState<any>([]);
    const { Gamificationlistdetails, loading, Gamificationpointsdetails } = useSelector((state: any) => state?.root?.gamification);
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace);
    const signIn = useSelector((state: any) => state?.root?.signIn);
    // console.log(Gamificationpointsdetails, 'Gamificationpointsdetails')
    const [selectedAssignee, setSelectedAssignee] = useState<any>([])
    const searchParams = useSearchParams();
    const pathname = usePathname();
    const user_id = searchParams.get('gamification_id');


    useEffect(() => {
        dispatch(getGamificationpointsDetails({}))
    }, [])

    // Reset table Data
    useEffect(() => {
        dispatch(resetdamificationlist({}))
    }, [])

    useEffect(() => {
        dispatch(getAllAssignees()).then((result: any) => {
            if (result) {
                if (getAllAssignees.fulfilled.match(result)) {
                    if (result?.payload?.success) {
                        setAssignee(result?.payload?.data)
                    };
                }
            }
        })
    }, [dispatch])

    const allOption = {
        label: 'Select all',
        value: '*',
    };


    const assigneeOptions: any = [
        // { name: 'All', value: '', label: 'All' },
        ...(assignees && assignees?.length > 0
            ? assignees?.filter(
                (assignee: Record<string, any>) =>
                    assignee?.role !== "client" && assignee?.role !== "team_client"
            )?.map((assignee: Record<string, any>) => ({
                name: `${capitalizeFirstLetter(
                    assignee?.first_name
                )} ${capitalizeFirstLetter(assignee?.last_name)}`,
                label: `${capitalizeFirstLetter(
                    assignee?.first_name
                )} ${capitalizeFirstLetter(assignee?.last_name)}`,
                value: assignee?._id,
                key: assignee,
            }))
            : []),
    ];

    useEffect(() => {
        if (user_id && assigneeOptions?.length > 0) {
            const selectedUser = assigneeOptions?.filter((option: any) => option?.value === user_id)
            setSelectedAssignee(selectedUser)

            const params = new URLSearchParams(searchParams.toString());
            params.delete("gamification_id");

            router.replace(`${pathname}?${params.toString()}`, { scroll: false });

        }
    }, [user_id])

    const optionsWithSelectAll = [allOption, ...assigneeOptions];

    const customStyles = {
        control: (provided: any, state: any) => ({
            ...provided,
            height: '40px',
            display: 'flex',
            alignItems: 'center',
            borderRadius: '8px',
            borderColor: state.isFocused ? 'black' : 'rgb(209 213 219)',
            boxShadow: state.isFocused ? 'none' : 'none', // Ensure no box-shadow on focus
            outline: 'none !important',
            padding: '0 8px !important',
            transition: 'border-color 0.2s ease',
            '&:hover': {
                borderColor: 'black', // Black border on hover
            },
        }),
        input: (provided: any) => ({
            ...provided,
            border: 'none !important',
            boxShadow: 'none !important',
            padding: '0 8px',
            outline: 'none !important',
            caretColor: 'rgb(209 213 219)', // Ensures visible text cursor
        }),
        valueContainer: (provided: any) => ({
            ...provided,
            display: 'flex',
            alignItems: 'center',
            padding: '0 8px !important',
            gap: '8px',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
        }),
        placeholder: (provided: any) => ({
            ...provided,
            color: 'rgb(209 213 219)',
            fontSize: '14px',
            padding: '0 8px !important',
            fontWeight: '500',
            whiteSpace: 'nowrap',
        }),
        singleValue: (provided: any) => ({
            ...provided,
            fontWeight: '600',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
        }),
        multiValue: (provided: any) => ({
            ...provided,
            backgroundColor: '#e1e7ff',
            borderRadius: '12px',
            padding: '2px 6px',
            display: 'flex',
            alignItems: 'center',
        }),
        multiValueLabel: (provided: any) => ({
            ...provided,
            fontSize: '12px',
            fontWeight: '500',
            color: '#4a4a4a',
        }),
        multiValueRemove: (provided: any) => ({
            ...provided,
            color: '#8c80d2',
            cursor: 'pointer',
            ':hover': {
                backgroundColor: '#e0e0e0',
                color: '#4a4a4a',
            },
        }),
        option: (provided: any, state: any) => ({
            ...provided,
            backgroundColor: state.isFocused ? '#f3f4f6' : 'white',
            color: state.isSelected ? '#4a4a4a' : '#000',
            padding: '8px 12px',
            fontSize: '14px',
            fontWeight: state.isSelected ? '600' : '400',
            ':active': {
                backgroundColor: '#e1e7ff',
            },
        }),
        menu: (provided: any) => ({
            ...provided,
            zIndex: 9999,
            borderRadius: '8px',
            boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
            marginTop: '4px',
        }),
        dropdownIndicator: (provided: any) => ({
            ...provided,
            color: '#8c80d2',
            ':hover': {
                color: '#4a4a4a',
            },
        }),
        indicatorSeparator: () => ({
            display: 'none !important',
        }),
    };

    const Option = (props: any) => {
        const { data, isSelected, selectOption, selectProps, allOptions } = props;
        // Determine if this is the "Select All" option
        const isAllOption = data?.value === allOption?.value;

        // const allOptions = selectProps.allOptions || [];
        const allSelected = selectProps.value?.length === allOptions?.length;

        const handleChange = (e: React.MouseEvent<HTMLDivElement>) => {
            e.stopPropagation();
            if (isAllOption) {
                // If all options are selected, clicking "Select All" will clear selection
                // Otherwise, clicking "Select All" selects all available options.
                if (allSelected) {
                    selectProps.onChange([]);
                } else {
                    selectProps.onChange(allOptions);
                }
            } else {
                // For a normal option, simply call selectOption to add or remove it.
                selectOption(data);
            }
        };

        return (
            <components.Option {...props}>
                <div
                    className="flex cursor-pointer items-center gap-2"
                    onClick={handleChange}
                >
                    <Checkbox
                        label={data?.label}
                        checked={isAllOption ? allSelected : isSelected}
                        color="info"
                        inputClassName="checkbox-color"
                        className="cursor-pointer [&>label>span]:font-medium"
                        labelClassName="text-1.20em md:text-1.20em lg:text-1.20em xl:text-1.20em text-gray-700 dark:text-gray-600 cursor-pointer"
                        onClick={(e) => e.stopPropagation()}
                    />
                </div>
            </components.Option>
        );
    };

    const MultiValue = (props: any) => (
        <components.MultiValue {...props}>
            <div className="flex items-center gap-2">
                {/* <img
                src={props.data.profile}
                alt={props.data.label}
                className="h-6 w-6 rounded-full"
              /> */}
                <span>{props.data.label}</span>
            </div>
        </components.MultiValue>
    );

    const ValueContainer = ({ children, ...props }: any) => {
        const selectedOptions = props.getValue();
        const hasSelections = selectedOptions.length > 0;

        // Determine the placeholder and truncate it if it’s too long during selected state
        let placeholder = props.selectProps.placeholder || 'Select';

        if (
            hasSelections &&
            placeholder === 'Select assignee' &&
            selectedOptions?.length > 0
        ) {
            // Truncate when displaying selected options count
            placeholder = `Select assig...`;
        } else if (hasSelections && placeholder.length > 15) {
            // Truncate if longer than 15 characters during selected state
            placeholder = `${placeholder.substring(0, 15)}...`;
        }

        return (
            <components.ValueContainer {...props}>
                <div className="flex items-center gap-2 whitespace-nowrap">
                    {hasSelections ? (
                        <div className="py-0 ps-2 font-medium text-[#4a4a4a]">
                            {placeholder}{' '}
                            <span className="rounded-full bg-[#8c80d2] px-2 py-1 text-xs font-bold text-white">
                                {selectedOptions.length.toString().padStart(2, '0')}
                            </span>
                        </div>
                    ) : (
                        <span className="py-0 ps-2 text-[#4a4a4a]">{placeholder}</span>
                    )}
                    {React.cloneElement(children[1])}
                </div>
            </components.ValueContainer>
        );
    };

    const handleAssigneeChange = (selectedOptions: any) => {
        const allSelected = selectedOptions?.some(
            (option: any) => option.value === allOption.value
        );

        if (allSelected) {
            const isDeselectingAll =
                selectedAssignee?.length === assigneeOptions?.length;

            if (isDeselectingAll) {
                // Unselect everything
                setSelectedAssignee([]);
                // setAssignee([]);
                dispatch(
                    getAllGamification({
                        assignee_id: [],
                        items_per_page: 10,
                        page: 1,
                        search: "",
                        sort_field: "createdAt",
                        sort_order: "desc",
                        Pagination:true,
                    })
                );
            } else {
                // Select everything
                setSelectedAssignee(assigneeOptions);
                // setAssignee(assigneeOptions?.map((option: any) => option.value));
                dispatch(
                    getAllGamification({
                        items_per_page: 10,
                        page: 1,
                        search: "",
                        sort_field: "createdAt",
                        sort_order: "desc",
                        assignee_id: assigneeOptions?.map((option: any) => option.value),
                        Pagination:true,
                    })
                );
            }
        } else {
            // Normal selection
            const selectedAssigneeIds = selectedOptions?.map(
                (option: any) => option.value
            );
            setSelectedAssignee(selectedOptions);
            // setAssignee(selectedAssigneeIds);
            dispatch(
                getAllGamification({
                    items_per_page: 10,
                    page: 1,
                    search: "",
                    sort_field: "createdAt",
                    sort_order: "desc",
                    assignee_id: selectedAssigneeIds,
                    Pagination:true,
                })
            );
        }
    };



    // const [selectedClient, setselectedClient] = useState<any>(null)
    // const [statusname, setstatusname] = useState<any>(null)
    // const [startRangeDate, setStartRangeDate] = useState<any>(null);
    // const [endRangeDate, setEndRangeDate] = useState<any>(null);

    // useEffect(() => {
    //     let { page, items_per_page, sort_field, sort_order, search } = paginationParams;
    //     dispatch(getAllAgencyagreement({ page, items_per_page, sort_field, sort_order, search, client_id: pathname ? clientSliceData?.reference_id : null, start_date: startRangeDate, end_date: endRangeDate, client_name: selectedClient?.value, status_name: statusname?.value }));
    // }, [statusname, selectedClient, endRangeDate])


    const handleResetFilters = () => {
        // setAssignee([]);
        setSelectedAssignee([]);
        setReset(true);
        dispatch(
            getAllGamification({
                items_per_page: 10,
                page: 1,
                search: "",
                sort_field: "createdAt",
                sort_order: "desc",
                assignee_id: [],
                Pagination:true,
            })
        );
    }



    //Paggination Handler
    const handleChangePage = async (paginationParams: any) => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;
        // await dispatch(setPagginationParams(paginationParams))
        const response = await dispatch(getAllGamification({ page, items_per_page, sort_field, sort_order, search, assignee_id: user_id ? user_id : selectedAssignee?.map((option: any) => option.value) }));
        const { data } = response?.payload;
        const maxPage: number = data?.page_count;

        if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            await dispatch(getAllGamification({ page, items_per_page, sort_field, sort_order, search, assignee_id: user_id ? user_id : selectedAssignee?.map((option: any) => option.value) }));
            return data?.client
        }
        return data?.client
    };

    const GamificationFilter = () => {
        return (
            <>
                <ReactSelect
                    options={optionsWithSelectAll}
                    onChange={(selected: any) => {

                        if (!selected || selected?.length === 0) {
                            return handleAssigneeChange([]);
                        }

                        const isAllSelected = selected?.some(
                            (option: any) => option.value === allOption.value
                        );

                        if (isAllSelected) {
                            const isDeselectingAll =
                                selectedAssignee?.length === assigneeOptions?.length;

                            if (isDeselectingAll) {
                                return handleAssigneeChange([]);
                            }
                            return handleAssigneeChange(assigneeOptions);
                        }

                        return handleAssigneeChange(selected);
                    }}
                    value={selectedAssignee}
                    isMulti
                    closeMenuOnSelect={false}
                    placeholder="Select assignee"
                    className="poppins_font_number react-select-options task-assign w-full"
                    classNamePrefix="custom-multi-select"
                    components={{
                        Option: (props) => (
                            <Option {...props} allOptions={assigneeOptions} />
                        ),
                        MultiValue,
                        ValueContainer,
                    }}
                    hideSelectedOptions={false}
                    styles={customStyles}
                    isClearable={false}
                // allOptions={assigneeOptions}
                />
                <div>
                    <Button
                        className="flex h-[40px] items-center justify-center rounded-3xl bg-[#E3E1F4] px-[40px] text-sm text-[#8C80D2]"
                        onClick={handleResetFilters}
                    >
                        <Image
                            className="mr-2 text-white"
                            alt="reste"
                            width={15}
                            height={15}
                            src={restImg}
                        />
                        Reset
                    </Button>
                </div>
            </>
        )
    }


    return (
        <>
            <div>
                {/* <PageHeader title={pageHeader.title} > */}
                <CustomePageHeader title={pageHeader.title} route={routes.rewards(defaultWorkSpace?.name)} className="montserrat_font_title" >
                    <div className='flex items-center'>
                        <div className="w-72 p-2">
                            <div className="mb-4 flex items-center gap-5">
                                <span
                                    style={{ backgroundColor: '#F5A623' }}
                                    className={cn(
                                        'flex rounded-[14px] p-2.5 text-gray-0 dark:text-gray-900'
                                    )}
                                >
                                    <RefundIcon className="h-auto w-[30px]" />
                                </span>
                                <div className="space-y-2">
                                    <Title
                                        as="h3"
                                        className="mb-1 text-sm text-[#9BA1B9]"
                                    >
                                        Referral Points
                                    </Title>
                                    <div className="flex items-center gap-2">
                                        <p className="text-[#9BA1B9]">Available points :</p>
                                        <p className="poppins_font_number text-sm font-semibold text-gray-900 dark:text-gray-700 2xl:text-[18px] ">
                                            {Gamificationpointsdetails?.data?.available_points && Gamificationpointsdetails?.data?.available_points > 0 ? Gamificationpointsdetails?.data?.available_points : 0}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="w-72 p-2">
                            <div className="mb-4 flex items-center gap-5">
                                <span
                                    style={{ backgroundColor: '#F5A623' }}
                                    className={cn(
                                        'flex rounded-[14px] p-2.5 text-gray-0 dark:text-gray-900'
                                    )}
                                >
                                    <RefundIcon className="h-auto w-[30px]" />
                                </span>
                                <div className="space-y-2">
                                    <div className="flex items-center gap-2">
                                        <p className="text-[#9BA1B9]">Earned points :</p>
                                        <p className="poppins_font_number text-sm font-semibold text-gray-900 dark:text-gray-700 2xl:text-[18px]">
                                            {Gamificationpointsdetails?.data?.earned_points && Gamificationpointsdetails?.data?.earned_points > 0 ? Gamificationpointsdetails?.data?.earned_points : 0}
                                        </p>
                                    </div>
                                    <div className="flex items-center gap-5">
                                        <Link className=' font-semibold capitalize text-blue transition-colors hover:underline' href={routes.coupons(defaultWorkSpace?.name)}>Redeem Coupons</Link>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </CustomePageHeader>
                {/* </PageHeader> */}

                <WidgetCard
                    rounded="lg"
                    title=""
                >
                    <div className="table_border_remove">
                        <CustomTable
                            data={Gamificationlistdetails?.data?.points_history || []}
                            total={Gamificationlistdetails?.data?.page_count || 1}
                            loading={loading}
                            pageSize={pageSize}
                            setPageSize={setPageSize}
                            handleChangePage={handleChangePage}
                            getColumns={GamificationColumns}
                            // filtersList={<AgreementsFilters />}
                            filtersList={['agency'].includes(signIn.role) && <GamificationFilter />}
                            scroll={{ x: 0 }}
                            resetValue={reset}
                            setReset={setReset}

                        />
                    </div>
                </WidgetCard>
            </div>
        </>
    )

}

export default withRoleAuth([roles.agency, roles.teamAgency.team_agency])(GamificationPage); 