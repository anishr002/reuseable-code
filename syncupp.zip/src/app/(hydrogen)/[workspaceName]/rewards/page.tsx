
import { metaObject } from '@/config/site.config';
import RewardsPage from './main-page';


export const metadata = {
    ...metaObject('Rewards'),
};

export default function Page() {
    return (
        <>
            <RewardsPage />
        </>
    );
}
