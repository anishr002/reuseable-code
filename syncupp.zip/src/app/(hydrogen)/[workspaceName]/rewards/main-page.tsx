'use client';

import withRoleAuth from '@/AuthGuard/withRoleAuth';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import Spinner from '@/components/ui/spinner';
import { HeaderCell } from '@/components/ui/table';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import {
  PurchaseCoupons,
  getCouponsData,
  getMyCouponsData,
} from '@/redux/slices/user/cuppons/couponsSlice';
import { getAllGamification } from '@/redux/slices/user/gamification/gamificationSlice';
import { capitalizeFirstLetter, couponColor } from '@/utils/common-functions';
import Starbage from '@public/assets/images/star_bage.svg';
import SubtractImg from '@public/assets/images/subtract_img.svg';
import PlaceholderImg from '@public/img_Placeholder.png.png';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { MdContentCopy } from 'react-icons/md';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Empty, Text } from 'rizzui';
import SimpleBar from 'simplebar-react';

type Columns = {
  data: any[];
  sortConfig?: any;
  handleSelectAll: any;
  checkedItems: string[];
  onDeleteItem: (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    Islastitem?: boolean,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => void;
  onHeaderCellClick: (value: string) => void;
  onChecked?: (id: string) => void;
  currentPage?: number;
  pageSize?: number;
  searchTerm?: string;
};

function RewardsPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { Cupponlistdetails, loading, MyCupponlistdetails, purchaseloader } =
    useSelector((state: any) => state?.root?.coupon);
  const { Gamificationlistdetails, Gamificationpointsdetails } = useSelector(
    (state: any) => state?.root?.gamification
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  const [selectedindex, setselectedindex] = useState(null);

  useEffect(() => {
    dispatch(getCouponsData({ coupon_count: 4 }));
    dispatch(getMyCouponsData());
    dispatch(getAllGamification({ page: 1, items_per_page: 3 }));
  }, []);

  const PurchaseHandler = (item: any) => {
    setselectedindex(item?._id);
    dispatch(PurchaseCoupons({ couponId: item?._id })).then((result: any) => {
      if (PurchaseCoupons.fulfilled.match(result)) {
        // console.log('resultt', result)
        if (result && result.payload.success === true) {
          dispatch(getCouponsData({ coupon_count: 4 }));
          dispatch(getMyCouponsData());
        }
      }
    });
  };

  const pointType = (type: any) => {
    if (type == 'coupon_purchase') return 'Coupon Purchase';
    return capitalizeFirstLetter(type);
  };

  const getColumns = ({
    data,
    sortConfig,
    checkedItems,
    onDeleteItem,
    onHeaderCellClick,
    handleSelectAll,
    onChecked,
    currentPage,
    pageSize,
    searchTerm,
  }: Columns) => {
    return [
      {
        title: (
          <HeaderCell
            title="Name"
            className="text-[14px] font-bold text-[#9BA1B9]"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
            }
          />
        ),
        onHeaderCell: () => onHeaderCellClick('name'),
        dataIndex: 'user',
        key: 'user',
        width: 150,
        render: (user: Record<string, any>) => (
          <div className="flex items-center justify-start gap-2">
            <Text className="poppins_font_number text-[14px] font-semibold text-[#9BA1B9]">
              {capitalizeFirstLetter(user?.first_name)}{' '}
              {capitalizeFirstLetter(user?.last_name)}
            </Text>
          </div>
        ),
      },
      {
        title: (
          <HeaderCell
            title="Type"
            className="text-[14px] font-bold text-[#9BA1B9]"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'type'
            }
          />
        ),
        onHeaderCell: () => onHeaderCellClick('type'),
        dataIndex: 'type',
        key: 'type',
        width: 150,
        render: (type: string) => (
          <div className="flex items-center justify-start gap-2">
            <Text className="poppins_font_number text-[14px] font-semibold text-[#9BA1B9]">
              {pointType(type)}
            </Text>
          </div>
        ),
      },
      {
        title: (
          <HeaderCell
            title="Date"
            className="text-[14px] font-bold text-[#9BA1B9]"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
            }
          />
        ),
        onHeaderCell: () => onHeaderCellClick('createdAt'),
        dataIndex: 'createdAt',
        key: 'createdAt',
        width: 150,
        render: (value: string) => (
          <Text className="poppins_font_number text-[14px] font-semibold text-[#9BA1B9]">
            {value && value != '' ? moment(value).format('Do MMM, YY') : '-'}
          </Text>
        ),
      },
      {
        title: (
          <HeaderCell
            title="Points"
            className="text-[14px] font-bold text-[#9BA1B9]"
            sortable
            ascending={
              sortConfig?.direction === 'asc' && sortConfig?.key === 'point'
            }
          />
        ),
        onHeaderCell: () => onHeaderCellClick('point'),
        dataIndex: 'point',
        key: 'point',
        width: 150,
        render: (point: string) => (
          <div className="flex items-center justify-start gap-2">
            <Text className="poppins_font_number text-[14px] font-semibold text-[#9BA1B9]">
              {point && point != '' ? point : '-'}
            </Text>
          </div>
        ),
      },
    ];
  };

  //copy link
  const handleCopyToClipboard = async (item: any) => {
    try {
      await window?.navigator?.clipboard?.writeText(item?.couponCode);
      toast.success('Coupon code copied to clipboard');
    } catch (error) {
      console.error('Error copying URL:', error);
    }
  };

  const handleChangePage = async (paginationParams: any) => {
    let { sort_field, sort_order } = paginationParams;
    dispatch(
      getAllGamification({
        page: 1,
        items_per_page: 3,
        sort_field,
        sort_order,
        pagination: true,
      })
    );
  };

  return (
    <>
      <CustomePageHeader title="Rewards" titleClassName="montserrat_font_title" />
      <WidgetCard
        rounded="lg"
        title=""
        className="border-none"
      // headerClassName="@2xl"
      >
        <div className="mb-3 flex items-baseline justify-between">
          <div className="text-2xl font-bold text-black">Available Coupons</div>
          <Link
            href={routes.coupons(defaultWorkSpace?.name)}
            className="cursor-pointer p-2 font-semibold text-[#9BA1B9]"
          >
            View All
          </Link>
        </div>

        <div>
          {Cupponlistdetails?.data?.coupon &&
            Cupponlistdetails?.data?.coupon?.length > 0 ? (
            <div className="grid items-center sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4">
              {Cupponlistdetails?.data?.coupon
                ?.slice(0, 4)
                .map((item: any, index: number) => (
                  <>
                    <div key={index} className="relative h-[328px] w-[251px]">
                      <div className={`absolute left-0 top-0 h-[328px] w-[251px] rounded-[20px] ${couponColor(index)}`} />
                      <Image
                        height={306}
                        width={229}
                        alt="subtract"
                        className="absolute left-[11px] top-[11px] h-[306px] w-[229px]"
                        src={SubtractImg}
                      />
                      <div className="absolute left-[91px] top-[192px] text-center text-sm font-bold leading-[14.97px]  text-slate-400 poppins_font_number">
                        {Cupponlistdetails?.data?.require_points} points
                      </div>
                      <div className="absolute left-[44px] top-[126px] text-center text-xl font-bold leading-snug  text-slate-900 poppins_font_number">
                        {item?.discountTitle}
                      </div>
                      <Button
                        disabled={loading}
                        type="button"
                        className="absolute left-[27px] top-[243px] h-[52px] w-[196px] rounded-[26px] bg-indigo-400 text-white shadow"
                        onClick={() => PurchaseHandler(item)}
                      >
                        Redeem Coupon
                        {purchaseloader && selectedindex === item?._id && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                      {/* <div className="left-[65px] top-[262px] absolute text-white text-sm font-semibold  leading-[14.97px] tracking-wide">Redeem Coupon</div> */}
                      <div className="absolute left-[25px] top-[221px] h-[0px] w-[198px] border border-slate-400"></div>
                      {/* <div className="w-[65px] h-[65px] left-[93px] top-[35px] absolute bg-white rounded-full border-2 border-slate-400" /> */}
                      <a target='_blank' href={item?.siteURL} className="">
                        {item?.brandLogo && item?.brandLogo != '' ? (
                          <Image
                            alt="logo"
                            height={65}
                            width={65}
                            className="absolute left-[93px] top-[35px] h-[65px] w-[65px] rounded-full border-2 object-fill"
                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${item?.brandLogo}`}
                          />
                        ) : (
                          <Image
                            alt="logo"
                            height={65}
                            width={65}
                            className="absolute left-[93px] top-[35px] h-[65px] w-[65px] object-fill"
                            src={PlaceholderImg}
                          />
                        )}
                      </a>
                    </div>
                  </>
                ))}
            </div>
          ) : (
            <div className="mb-5 mt-2 rounded-xl border border-gray-300 py-5 text-center lg:py-8">
              <Empty /> <Text className="mt-3">No Coupons Found</Text>
            </div>
          )}
        </div>
      </WidgetCard>

      <div className="mt-5 grid grid-cols-1 lg:grid-cols-3 gap-0 lg:gap-5">
        <WidgetCard
          rounded="lg"
          className="border-none mb-4 lg:mb-0"
          title=""
        // headerClassName="@2xl"
        >
          <div className="mb-5 text-2xl font-bold text-black">
            Redeemed Coupons
          </div>
          <SimpleBar className="mb-2 max-h-[210px]">
            {MyCupponlistdetails?.data &&
              MyCupponlistdetails?.data?.length > 0 ? (
              <div className="grid grid-cols-1 gap-4  ">
                {MyCupponlistdetails?.data?.map((item: any, index: number) => (
                  <div
                    key={index}
                    className="rounded-[20px] border-[12px] border-[#FBF0DE]"
                  >
                    <div
                      key={index}
                      className="rounded-lg border border-gray-300 "
                    >
                      <div className="flex justify-end pe-3 pt-3 font-bold text-[#9BA1B9]">
                        <MdContentCopy
                          onClick={() => handleCopyToClipboard(item)}
                          className="h-5 w-5 cursor-pointer"
                        />
                      </div>
                      <a target='_blank' href={item?.siteURL}>
                        <div className="flex items-center justify-start px-3">
                          {item?.brandLogo && item?.brandLogo != '' ? (
                            <Image
                              alt="logo"
                              className="m-3 h-[66px] w-[66px] rounded-full border object-fill"
                              width="65"
                              height="65"
                              src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${item?.brandLogo}`}
                            />
                          ) : (
                            <Image
                              alt="logo"
                              className="m-3 h-[66px] w-[66px] rounded-full border object-fill"
                              width="65"
                              height="65"
                              src={PlaceholderImg}
                            />
                          )}

                          <div className="ps-3">
                            <p className="text-sm font-bold capitalize text-gray-500 poppins_font_number">
                              {item?.brand}
                            </p>
                            <p className="mt-0.5 text-xl font-bold capitalize text-[#120425] poppins_font_number">
                              {item?.discountTitle}
                            </p>
                          </div>
                        </div>
                      </a>
                      <div className="flex items-center justify-start px-4 pb-3">
                        <div className="font-bold text-[#9BA1B9] poppins_font_number">
                          Code : {item?.couponCode}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mb-5 mt-2 rounded-xl border border-gray-300 py-5 text-center lg:py-8">
                <Empty /> <Text className="mt-3">No Coupons Found</Text>
              </div>
            )}
          </SimpleBar>
          <div className='border-t border-[#E3E1F4]'>
            <Link
              href={routes.mycoupons(defaultWorkSpace?.name)}
              className="cursor-pointer px-2 font-semibold  text-[#9BA1B9]"
            >
              Show All
            </Link>
          </div>
        </WidgetCard>

        <div className="col-span-2">
          <div className="total_point_table_main_block">
            <WidgetCard rounded="lg" title="" className="border-none">
              <div className="table-title flex items-center justify-between">
                <p className="text-[28px] font-bold text-black">Total Points</p>
                <div className="flex items-center justify-start">
                  <Image
                    src={Starbage}
                    className="mr-2"
                    height={25}
                    width={25}
                    alt="start"
                  />
                  <div className="text-2xl font-bold text-black poppins_font_number">
                    {Gamificationlistdetails?.data?.total_points > 0
                      ? Gamificationlistdetails?.data?.total_points
                      : 0}
                  </div>
                </div>
              </div>

              <div className="table_border_remove">
                <CustomTable
                  showPagination={false}
                  data={Gamificationlistdetails?.data?.points_history || []}
                  getColumns={getColumns}
                  scroll={{ x: 0 }}
                  handleChangePage={handleChangePage}
                />
              </div>

              <p className='!p-8'>
                <Link
                  href={routes.gamification(defaultWorkSpace?.name)}
                  className="cursor-pointer font-semibold text-[#9BA1B9]"
                >
                  Show More
                </Link>
              </p>
            </WidgetCard>
          </div>
        </div>
      </div>
    </>
  );
}

export default withRoleAuth([roles.agency, roles.teamAgency.team_agency])(RewardsPage);
