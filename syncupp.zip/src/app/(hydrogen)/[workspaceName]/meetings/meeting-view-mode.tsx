'use client';

import { setCalendarView } from '@/redux/slices/user/activity/activitySlice';
import cn from '@/utils/class-names';
import { MdOutlineSpaceDashboard } from 'react-icons/md';
import { PiListBullets } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon } from 'rizzui';

export default function MeetingsViewMode({ view }: { view?: string }) {
  const { calendarView } = useSelector((state: any) => state?.root?.activity);

  const dispatch = useDispatch();

  // List view & Grid view changes
  const handleListView = () => {
    dispatch(setCalendarView(false));
  };

  const handleCalenderView = () => {
    dispatch(setCalendarView(true));
  };

  return (
    <div
      className={cn(
        'task-list-tour-step-four flex h-[40px] w-[140px] items-center justify-center rounded-lg bg-[#F3F4F6] p-1'
      )}
    >
      <ActionIcon
        size="sm"
        variant="flat"
        className={cn(
          'group flex w-[45%] items-center justify-center gap-[2px] bg-transparent hover:!bg-transparent',
          !calendarView && 'bg-[#E7E5FA]'
        )}
        onClick={handleListView}
      >
        <PiListBullets
          className={cn(
            'h-3.5 w-3.5',
            calendarView ? 'text-black' : 'text-[#362F78]'
          )}
        />
        <span className="text-xs font-medium">List</span>
      </ActionIcon>
      <ActionIcon
        size="sm"
        variant="flat"
        className={cn(
          'group flex w-[55%] items-center justify-center gap-[2px] bg-transparent hover:!bg-transparent',
          calendarView && 'bg-[#E7E5FA]'
        )}
        onClick={handleCalenderView}
      >
        <MdOutlineSpaceDashboard
          className={cn(
            'h-3.5 w-3.5',
            !calendarView ? 'text-black' : 'text-[#362F78]'
          )}
        />
        <span className="text-xs font-medium">Board</span>
      </ActionIcon>
    </div>
  );
}
