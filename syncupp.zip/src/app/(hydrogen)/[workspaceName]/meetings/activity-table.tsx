'use client';
import { GetActivityColumns } from '@/app/shared/(user)/calender/calender-list/columns';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { Button } from '@/components/ui/button';
import Select from '@/components/ui/select';
import {
  getAllActivity,
  setActivityName,
  setCalendarView,
  setPaginationDetails,
} from '@/redux/slices/user/activity/activitySlice';
import {
  deleteTask,
  setTaskPaginationDetails,
} from '@/redux/slices/user/task/taskSlice';
import moment from 'moment';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { RxReset } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import restImg from '@public/assets/images/reset_icon.svg';
import { MdOutlineSpaceDashboard } from 'react-icons/md';
import { ActionIcon } from 'rizzui';
import { PiListBullets } from 'react-icons/pi';
import cn from '@/utils/class-names';

let statusOptionsDropdown: Record<string, any>[] = [
  { name: 'All', value: '' },
  { name: 'Pending', value: 'pending' },
  { name: 'Cancel', value: 'cancel' },
  { name: 'Completed', value: 'done' },
];

export default function ActivityTablePage(props: any) {
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const activityData = useSelector((state: any) => state?.root?.activity);
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.activity
  );

  const [pageSize, setPageSize] = useState<number>(10);
  const [statusType, setStatusType] = useState('');
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reset, setReset] = useState('');
  const [statusOption, setStatusOption] = useState('');
  const { calendarView } = useSelector((state: any) => state?.root?.activity);

  useEffect(() => {
    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      !!endDate &&
        dispatch(
          getAllActivity({
            ...paginationParams,
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            filter: {
              status: statusType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
    } else {
      !!endDate &&
        dispatch(
          getAllActivity({
            ...paginationParams,
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            filter: {
              status: statusType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
    }
  }, [
    dispatch,
    signIn?.role,
    statusType,
    clientSliceData?.agencyId,
    endDate,
    startDate,
    period,
  ]);

  const handleStatusChange = (selectedOption: Record<string, any>) => {
    setStatusType(selectedOption?.value);
    // dispatch(setActivityName(selectedOption?.value));

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        filter: {
          status: selectedOption?.value,
          date: period,
          start_date: startDate,
          end_date: endDate,
        },
      })
    );

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      if (endDate === '' && startDate === '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            filter: { status: selectedOption?.value },
            pagination: true,
          })
        );
      } else if (endDate === '' && startDate === '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            filter: {
              status: selectedOption?.value,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            filter: {
              status: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            filter: {
              status: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      }
    } else {
      if (endDate === '' && startDate === '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            filter: { status: selectedOption?.value },
            pagination: true,
          })
        );
      } else if (endDate === '' && startDate === '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            filter: {
              status: selectedOption?.value,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            filter: {
              status: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '') {
        dispatch(
          getAllActivity({
            ...paginationParams,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            filter: {
              status: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      }
    }
  };

  const handleActivityChange = (selectedOption: Record<string, any>) => {
    dispatch(setActivityName(selectedOption?.value));

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        filter: {
          status: statusType,
          activity_type: selectedOption?.value,
          date: period,
          start_date: startDate,
          end_date: endDate,
        },
      })
    );

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      endDate === ''
        ? dispatch(
            getAllActivity({
              ...paginationParams,
              page: 1,
              sort_field: 'createdAt',
              sort_order: 'desc',
              filter: {
                status: statusType,
                activity_type: selectedOption?.value,
              },
              pagination: true,
            })
          )
        : dispatch(
            getAllActivity({
              ...paginationParams,
              page: 1,
              sort_field: 'createdAt',
              sort_order: 'desc',
              filter: {
                status: statusType,
                activity_type: selectedOption?.value,
                date: period,
                start_date: startDate,
                end_date: endDate,
              },
              pagination: true,
            })
          );
    } else {
      endDate === ''
        ? dispatch(
            getAllActivity({
              ...paginationParams,
              page: 1,
              sort_field: 'createdAt',
              sort_order: 'desc',
              agency_id: clientSliceData?.agencyId,
              filter: {
                status: statusType,
                activity_type: selectedOption?.value,
              },
              pagination: true,
            })
          )
        : dispatch(
            getAllActivity({
              ...paginationParams,
              page: 1,
              sort_field: 'createdAt',
              sort_order: 'desc',
              agency_id: clientSliceData?.agencyId,
              filter: {
                status: statusType,
                activity_type: selectedOption?.value,
                date: period,
                start_date: startDate,
                end_date: endDate,
              },
              pagination: true,
            })
          );
    }
  };

  const handleRangeChange = (dates: any) => {
    const [start, end] = dates;
    // setStartRangeDate(start);
    // setEndRangeDate(end);
    setStartDate(moment(start).format('DD-MM-YYYY'));
    !!end && setEndDate(moment(end).format('DD-MM-YYYY'));

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        filter: {
          status: statusType,
          date: 'period',
          start_date: moment(start).format('DD-MM-YYYY'),
          end_date: moment(end).format('DD-MM-YYYY'),
        },
      })
    );

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      !!end &&
        dispatch(
          getAllActivity({
            ...paginationParams,
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            filter: {
              status: statusType,
              date: 'period',
              start_date: moment(start).format('DD-MM-YYYY'),
              end_date: moment(end).format('DD-MM-YYYY'),
            },
            pagination: true,
          })
        );
    } else {
      !!end &&
        dispatch(
          getAllActivity({
            ...paginationParams,
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            filter: {
              status: statusType,
              date: 'period',
              start_date: moment(start).format('DD-MM-YYYY'),
              end_date: moment(end).format('DD-MM-YYYY'),
            },
            pagination: true,
          })
        );
    }

    !!end && setPeriod('period');
  };

  // useEffect(() => {
  //     reset === 'reset' && setStatusOption('');
  // }, [reset]);

  useEffect(() => {
    setStatusType('');
    setStatusOption('');
    setPeriod('');
    setStartDate('');
    setEndDate('');
    // setStartRangeDate(null);
    // setEndRangeDate(null);
  }, [clientSliceData?.agencyId]);

  useEffect(() => {
    if (
      statusType !== '' ||
      period !== '' ||
      startDate !== '' ||
      endDate !== ''
    ) {
      setReset('');
    }
  }, [statusType, period, startDate, endDate]);

  const handleResetFilters = () => {
    setStatusType('');
    setStatusOption('');
    setPeriod('');
    setStartDate('');
    setEndDate('');
    // setStartRangeDate(null);
    // setEndRangeDate(null);
    setReset('reset');

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      dispatch(
        getAllActivity({
          sort_field: 'createdAt',
          sort_order: 'desc',
          pagination: true,
        })
      );
    } else {
      dispatch(
        getAllActivity({
          sort_field: 'createdAt',
          sort_order: 'desc',
          agency_id: clientSliceData?.agencyId,
          pagination: true,
        })
      );
    }
  };

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        filter: {
          status: statusType,
          date: period,
          start_date: startDate,
          end_date: endDate,
        },
      })
    );

    const response =
      signIn?.role !== 'client' && signIn?.role !== 'team_client'
        ? await dispatch(
            getAllActivity({
              ...paginationParams,
              page,
              items_per_page,
              sort_field,
              sort_order,
              search,
              filter: {
                status: statusType,
                date: period,
                start_date: startDate,
                end_date: endDate,
              },
              pagination: true,
            })
          )
        : await dispatch(
            getAllActivity({
              ...paginationParams,
              page,
              items_per_page,
              sort_field,
              sort_order,
              search,
              filter: {
                status: statusType,
                date: period,
                start_date: startDate,
                end_date: endDate,
              },
              pagination: true,
            })
          );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      // await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search }));
      signIn?.role !== 'client' && signIn?.role !== 'team_client'
        ? await dispatch(
            getAllActivity({
              ...paginationParams,
              page,
              items_per_page,
              sort_field,
              sort_order,
              search,
              filter: {
                status: statusType,
                date: period,
                start_date: startDate,
                end_date: endDate,
              },
              pagination: true,
            })
          )
        : await dispatch(
            getAllActivity({
              ...paginationParams,
              page,
              items_per_page,
              sort_field,
              sort_order,
              search,
              agency_id: clientSliceData?.agencyId,
              filter: {
                status: statusType,
                date: period,
                start_date: startDate,
                end_date: endDate,
              },
              pagination: true,
            })
          );
      return data?.client;
    }
    if (data && data?.client && data?.client?.length !== 0) {
      return data?.client;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    // console.log("delete id in main page....", id)

    try {
      const res =
        typeof id === 'string'
          ? await dispatch(deleteTask({ taskIdsToDelete: [id] }))
          : await dispatch(deleteTask({ taskIdsToDelete: id }));
      if (res.payload.success === true) {
        const reponse =
          signIn?.role !== 'client' && signIn?.role !== 'team_client'
            ? await dispatch(
                getAllActivity({
                  ...paginationParams,
                  page: currentPage,
                  items_per_page: countPerPage,
                  sort_field: sortConfig?.key,
                  sort_order: sortConfig?.direction,
                  search: searchTerm,
                  filter: {
                    status: statusType,
                    date: period,
                    start_date: startDate,
                    end_date: endDate,
                  },
                  pagination: true,
                })
              )
            : await dispatch(
                getAllActivity({
                  ...paginationParams,
                  page: currentPage,
                  items_per_page: countPerPage,
                  sort_field: sortConfig?.key,
                  sort_order: sortConfig?.direction,
                  search: searchTerm,
                  agency_id: clientSliceData?.agencyId,
                  filter: {
                    status: statusType,
                    date: period,
                    start_date: startDate,
                    end_date: endDate,
                  },
                  pagination: true,
                })
              );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const FilterList = () => {
    return (
      <>
        <Select
          options={statusOptionsDropdown}
          onChange={(selectedOption: Record<string, any>) => {
            setStatusOption(selectedOption?.name);
            handleStatusChange(selectedOption);
          }}
          value={statusOption}
          placeholder="Select Status"
          className="w-full"
          selectClassName="text-black"
        />
        <div>
          <Button
            className="flex h-[40px] items-center justify-center rounded-lg border border-[#7667CF] bg-[#ffffff] p-3 text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
      </>
    );
  };

  return (
    <>
      <div className="main_card_block">
        <WidgetCard rounded="lg" title="" className="">
          <div className="table_border_remove">
            <CustomTable
              data={(activityData && activityData?.data?.activity) || []}
              total={(activityData && activityData?.data?.page_count) || 1}
              loading={activityData && activityData?.loading}
              pageSize={pageSize}
              setPageSize={setPageSize}
              handleDeleteById={handleDeleteById}
              handleChangePage={handleChangePage}
              getColumns={GetActivityColumns}
              scroll={{ x: 0 }}
              filtersList={<FilterList />}
              moduleName="activity"
              isMeetingTable={true}
              setPeriod={setPeriod}
              setStartDate={setStartDate}
              setEndDate={setEndDate}
              isRangeFilter={true}
              resetValue={reset}
            />
          </div>
        </WidgetCard>
      </div>
    </>
  );
}
