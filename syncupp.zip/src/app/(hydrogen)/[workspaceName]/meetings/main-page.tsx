'use client';
// import Link from 'next/link';
import { ConfirmationRemoveUserModal } from '@/app/shared/(user)/calender/create-edit-event/remove-google-account-confirmation';
import EventCalendarView from '@/app/shared/(user)/calender/event-calendar';
import { MeetingForm } from '@/app/shared/(user)/calender/meeting/meeting-form';
import { InstantMeeting } from '@/app/shared/(user)/calender/meeting/meeting-instant';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import SelectBox from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import {
  getAllGoogleCalendarConfigAccounts,
  getVerifyGoogleCalendarConfig,
  postGoogleCalendarConfig,
  RemoveGoogleAccountData,
  setCalendarView,
} from '@/redux/slices/user/activity/activitySlice';
import { emptyDefaultFormData } from '@/redux/slices/user/meeting/meetingSlice';
import cn from '@/utils/class-names';
import googleCalendarImage from '@public/assets/svgs/google-calendar.svg';
import { useGoogleLogin } from '@react-oauth/google';
import moment from 'moment';
import Image from 'next/image';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { FaPlus } from 'react-icons/fa';
import {
  PiCaretDownBold,
  PiPlusBold,
  PiXCircleFill
} from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Text } from 'rizzui';
import ActivityTablePage from './activity-table';
import { Popover } from '@/components/ui/popover';

const pageHeader = {
  title: 'Meetings',
};

export default function CalendarMainPage() {
  const { openModal } = useModal();
  const dispatch = useDispatch();
  const { permission, role } = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const taskData = useSelector((state: any) => state?.root?.task);
  const {
    calendarView,
    paginationParams,
    postGoogleCalendarConfigLoader,
    isGoogleCalendarConfig,
    googleAccounts,
  } = useSelector((state: any) => state?.root?.activity);
  const searchParams = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const [isConfigured, setIsConfigured] = useState(false);
  const [configuredUser, setConfiguredUser] = useState('');
  const [configuredUserName, setConfiguredUserName] = useState('');

  // setting google calendar api call payload
  const [currentGoogleFilterParams, setCurrentGoogleFilterParams] =
    useState<any>({});

  // verify configure google calendar or not
  useEffect(() => {
    dispatch(getVerifyGoogleCalendarConfig());
  }, []);

  // Get configured google accounts
  useEffect(() => {
    dispatch(getAllGoogleCalendarConfigAccounts());
    return () => dispatch(RemoveGoogleAccountData());
  }, []);

  useEffect(() => {
    const googleCalendarApiPayload = {
      start_date: moment().startOf('month').utc(),
      end_date: moment().endOf('month').utc(),
    };
    setCurrentGoogleFilterParams(googleCalendarApiPayload);
  }, []);

  // Handle remove google user from calendar
  const handleRemoveGoogleAccount = (user: any) => {
    openModal({
      view: <ConfirmationRemoveUserModal user={user} />,
      customSize: '400px',
    });
  };

  // Google account options.....
  let calenderFilter: Record<string, any>[] =
    googleAccounts && googleAccounts?.length > 0
      ? googleAccounts?.map((user: Record<string, any>) => {
        return {
          value: user?._id,
          name: user?.auth_email,
          label: (
            <div className="flex items-center justify-between gap-2">
              <Text
                className={cn(
                  'poppins_font_number text-[14px] font-medium',
                  configuredUserName === user?.auth_email
                    ? 'text-[#8C80D2]'
                    : 'text-black'
                )}
              >
                {user?.auth_email}
              </Text>
              <PiXCircleFill
                title="Remove User"
                className={cn(
                  'poppins_font_number h-6 w-6 text-[14px] font-medium',
                  configuredUserName === user?.auth_email
                    ? 'text-[#8C80D2] hover:text-black'
                    : 'text-black hover:text-[#8C80D2]'
                )}
                onClick={() => handleRemoveGoogleAccount(user)}
              />
            </div>
          ),
          key: user,
        };
      })
      : [];

  calenderFilter.push({
    value: 'add_new_user',
    name: 'Add New User',
    label: (
      <div className="flex items-center justify-center gap-2">
        <Text
          className={cn(
            'poppins_font_number flex items-center gap-2 text-[14px] font-medium',
            configuredUserName === 'Add New User'
              ? 'text-[#8C80D2]'
              : 'text-black'
          )}
        >
          <FaPlus className="h-3 w-3" /> Add New User
        </Text>
      </div>
    ),
    key: 'add_new_user',
  });

  useEffect(() => {
    if (calenderFilter && calenderFilter?.length > 0) {
      const findSelectedUser =
        calenderFilter && calenderFilter?.length > 0
          ? calenderFilter?.find((user: any) => user.key.is_selected)
          : calenderFilter[0];
      console.log(
        'findSelectedUser....',
        findSelectedUser,
        calenderFilter,
        calenderFilter[0]
      );
      findSelectedUser && setConfiguredUserName(findSelectedUser?.name);
      findSelectedUser && setConfiguredUser(findSelectedUser?.value);
      const googleCalendarApiPayload = {
        auth_user_id: findSelectedUser?.value ?? '',
        start_date: moment().startOf('month').utc(),
        end_date: moment().endOf('month').utc(),
      };
      setCurrentGoogleFilterParams(googleCalendarApiPayload);
    }
  }, [googleAccounts]);

  const handleListView = () => {
    dispatch(setCalendarView(false));
  };

  const handleGridView = () => {
    dispatch(setCalendarView(true));
  };

  const createMeeting = () => {
    dispatch(emptyDefaultFormData());
    openModal({
      view: (
        <MeetingForm
          title="New Meeting"
          isEdit={false}
          openFromCalender={calendarView}
          currentFilterParams={paginationParams}
          currentGoogleFilterParams={currentGoogleFilterParams}
          googleAccounts={googleAccounts}
        />
      ),
      customSize: '860px ', // Fixed modal width
    });
  };
  const startInstantMeeting = () => {
    openModal({
      view: (
        <InstantMeeting
          title="Share meeting details"
        />
      ),
      customSize: '512px ', // Fixed modal width
    });
  };

  // useEffect(() => {
  //   if (searchParams.get('meeting_id')) {
  //     setTimeout(() => {
  //       openModal({
  //         view: <MeetingDetail row={{ _id: searchParams.get('meeting_id') }} />,
  //         customSize: '500px',
  //       });
  //       router.replace(path);
  //     }, 1500);
  //   }
  // }, []);

  const googleLogin = useGoogleLogin({
    flow: 'auth-code',
    scope:
      'profile email https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.events.readonly', // Add scopes as needed
    onSuccess: async (codeResponse) => {
      // expected response type is 'codeResponse'
      console.log('Google response....', codeResponse);

      if (codeResponse && codeResponse?.code) {
        await dispatch(
          postGoogleCalendarConfig({ code: codeResponse?.code })
        ).then((result: any) => {
          if (postGoogleCalendarConfig.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              dispatch(getVerifyGoogleCalendarConfig());
              dispatch(getAllGoogleCalendarConfigAccounts()).then(
                (result: any) => {
                  if (
                    getAllGoogleCalendarConfigAccounts.fulfilled.match(result)
                  ) {
                    if (result && result.payload.success === true) {
                      const findSelectedUser =
                        result?.payload?.data &&
                          result?.payload?.data?.length > 0
                          ? result?.payload?.data?.find(
                            (user: any) => user.is_selected
                          )
                          : result?.payload?.data[0];
                      findSelectedUser &&
                        setConfiguredUser(findSelectedUser?._id);
                      setIsConfigured(true);
                    }
                  }
                }
              );
            }
          }
        });
      }
    },
    onError: (errorResponse) => {
      console.log('Error Response', errorResponse);
    },
  });

  return (
    <>
      <CustomePageHeader
        title={pageHeader?.title}
        titleClassName="montserrat_font_title"
      >
        <div className="flex items-center gap-4 @lg:mt-0">
          <div>
            {!isGoogleCalendarConfig ? (
              <Button
                onClick={googleLogin}
                disabled={postGoogleCalendarConfigLoader}
                className="flex gap-2 rounded-lg border border-[#5850EC] bg-transparent p-3 text-sm font-medium !text-[#5850EC]"
              >
                {/* <FcGoogle className="me-1.5 h-[17px] w-[17px]" /> */}
                <Image
                  className="text-white"
                  alt="reste"
                  width={15}
                  height={15}
                  src={googleCalendarImage}
                />
                Google Calender
                {postGoogleCalendarConfigLoader && (
                  <Spinner
                    size="sm"
                    tag="div"
                    className="ms-3 text-[#5850EC]"
                  // color='white'
                  />
                )}
              </Button>
            ) : (
              <div>
                <SelectBox
                  options={calenderFilter}
                  onChange={(selectedOption: Record<string, any>) => {
                    // console.log("Selected option...", selectedOption)
                    if (selectedOption?.value === 'add_new_user') {
                      googleLogin();
                    } else {
                      setConfiguredUser(selectedOption?.value);
                      setConfiguredUserName(selectedOption?.name);
                    }
                  }}
                  value={configuredUserName}
                  placeholder="Select Google Account"
                  // getOptionValue={(option) => option.label}
                  className=" calender-view-google-account-selection poppins_font_number min-w-[325px]"
                  // rounded='pill'
                  // dropdownClassName="p-1 border w-auto border-gray-100 shadow-lg absolute"
                  prefix={
                    <Image
                      className="mr-2 text-white"
                      alt="reste"
                      width={15}
                      height={15}
                      src={googleCalendarImage}
                    />
                  }
                  suffix={<PiCaretDownBold className="h-4 w-4" />}
                />
              </div>
            )}
          </div>
          {/* {(['team_agency', 'team_client'].includes(role)
            ? checkPermission('meetings', null, 'create', permission)
            : ['agency'].includes(role)) && (
              <Button
                onClick={createMeeting}
                className="flex gap-2 rounded-lg bg-[#8C80D2] p-3 text-sm font-medium"
              >
                <PiPlusBold className="h-4 w-4" />
                New Meeting
              </Button>
            )} */}
          {(['team_agency', 'team_client'].includes(role)
            ? checkPermission('meetings', null, 'create', permission)
            : ['agency'].includes(role)) && (<Popover
              placement="bottom-end"
              className="gap-2 p-2"
              showArrow={false}
              content={({ setOpen }) => (
                <div className="flex w-full flex-col items-start justify-start text-gray-900">
                  <Button
                    onClick={() => {
                      startInstantMeeting();
                      setOpen(false);
                    }}
                    variant="text"
                    className="flex w-full items-start justify-start hover:!text-[#6e55fd]  hover:bg-[#DCD7FE33]  focus:outline-none dark:hover:bg-gray-50"
                  >
                    Start an instant meeting
                  </Button>
                  <Button
                    onClick={() => {
                      createMeeting();
                      setOpen(false);
                    }}
                    variant="text"
                    className="flex w-full items-start justify-start  hover:bg-[#DCD7FE33] hover:!text-[#7667CF] focus:outline-none dark:hover:bg-gray-50"
                  >
                    Create event
                  </Button>
                </div>
              )}>
              <Button
                // onClick={createMeeting}
                className="flex gap-2 rounded-lg bg-[#7667CF] p-3 text-sm font-medium"
              >
                <PiPlusBold className="h-4 w-4" />
                New Meeting
                <PiCaretDownBold className="h-4 w-4" />

              </Button>
            </Popover>)}

        </div>
      </CustomePageHeader>

      {!calendarView ? (
        <ActivityTablePage />
      ) : (
        <EventCalendarView
          isConfigured={isConfigured}
          configuredUser={configuredUser}
          currentGoogleFilterParams={currentGoogleFilterParams}
          setCurrentGoogleFilterParams={setCurrentGoogleFilterParams}
        />
      )}
    </>
  );
}
