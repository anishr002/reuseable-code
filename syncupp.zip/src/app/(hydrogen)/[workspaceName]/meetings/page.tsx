
import { metaObject } from '@/config/site.config';
import CalendarMainPage from './main-page';

export const metadata = {
  ...metaObject('Meetings'),
};

export default function CalenderPage() {
  return (
    <>
        <CalendarMainPage />
    </>
  );
}
