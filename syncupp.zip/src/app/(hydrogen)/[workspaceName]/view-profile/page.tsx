'use client';

import UserViewProfileForm from './view-profile-page';


export default function Page() {
  return (
    <>
      <UserViewProfileForm/>
    </>
  );
}
