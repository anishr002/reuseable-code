'use client';

import SelectLoader from '@/components/loader/select-loader';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { getUserProfile } from '@/redux/slices/user/auth/signinSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import Profile from '@public/dummyprofile.jpg';
import dynamic from 'next/dynamic';
import { usePathname } from 'next/navigation';
import { useEffect } from 'react';
import toast from 'react-hot-toast';
import { PiNotePencilDuotone } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';

const SelectBox = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

import ModalButton from '@/app/shared/modal-button';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { PhoneNumber } from '@/components/ui/phone-input';
import { routes } from '@/config/routes';
import 'src/layouts/helium/style.css';
import { AddressInfoPage } from './address-info-page';
import { CompanyInfoPage } from './company-info-page';
import { PersonalInfoPage } from './personal-info-page';

export default function UserViewProfileForm(props: any) {
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  const pathname = usePathname();
  const data = signIn?.userProfile;

  //refferal link
  let urlToShareIS = `${process.env.NEXT_PUBLIC_FRONT_LINK
    }/signup?affiliatereferal=${signIn?.userProfile?.affiliate_referral_code || ''
    }&email=${encodeURIComponent(signIn?.userProfile?.email) || ''}`;
  // &workspace=${defaultWorkSpace?._id || ''}
  useEffect(() => {
    const pending_profile = localStorage.getItem('profile_pending');

    dispatch(getUserProfile());
    if (
      pending_profile &&
      pending_profile !== 'undefined' &&
      pending_profile !== null &&
      pathname === '/invoice/create'
    ) {
      toast.success('Please complete your profile');
    }
  }, [dispatch]);

  const handleCopyToClipboard = async () => {
    try {
      await window?.navigator?.clipboard?.writeText(urlToShareIS);
      toast.success('Affiliate link copied to clipboard');
    } catch (error) {
      console.error('Error copying URL:', error);
    }
  };

  if (signIn?.getUserProfileStatus === 'pending' || signIn?.loading === true) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" className="ms-3" />
      </div>
    );
  } else {
    return (
      <>
        <CustomePageHeader
          route={routes.dashboard(defaultWorkSpace?.name)}
          title="My Profile"
          titleClassName="montserrat_font_title"
        >
          <div className="mt-4 flex items-center gap-3 @lg:mt-0"></div>
        </CustomePageHeader>

        <WidgetCard rounded="lg" title="" className='h-[73vh]' >
          <div>
            <div className="flex items-center justify-between pb-5">
              <div className="flex flex-col items-center lg:flex-row	lg:items-center">
                <div className="profile_sections mb-4 pr-5 lg:mb-0">
                  <Avatar
                    src={
                      !!data?.profile_image
                        ? `${process.env.NEXT_PUBLIC_IMAGE_URL}` +
                        '/uploads/' +
                        data?.profile_image
                        : Profile?.src
                    }
                    name={
                      capitalizeFirstLetter(data?.first_name as string) +
                      ' ' +
                      capitalizeFirstLetter(data?.last_name as string)
                    }
                    className="bg-[#70C5E0]/[.08] font-bold text-white"
                  />
                </div>
                <div>
                  <div className="text-center text-[24px] font-bold text-[#120425] lg:text-left">
                    {capitalizeFirstLetter(data?.first_name)}{' '}
                    {capitalizeFirstLetter(data?.last_name)}
                  </div>
                  {/* <div className="text-[#9BA1B9] font-semibold text-[16px] lg:text-[20px] text-center lg:text-left mt-2">{data?.bio}</div> */}
                  <div className="poppins_font_number mt-2 text-center text-[16px] font-semibold text-[#9BA1B9] lg:text-left lg:text-[20px]">
                    {data?.address ? data?.address : ''}{' '}
                    {data?.city?.name ||
                      data?.state?.name ||
                      data?.country?.name
                      ? ', '
                      : ''}
                    {data?.city?.name ?? ''}{' '}
                    {data?.state?.name || data?.country?.name ? ', ' : ''}
                    {data?.state?.name ?? ''} {data?.country?.name ? ', ' : ''}
                    {data?.country?.name ?? ''}
                  </div>
                </div>
              </div>
              <div>
                {/* Attendance */}
                {/* <AttendanceTimer /> */}
              </div>
            </div>

            <div className="h-custom_scroll overflow-auto">
              <div className="pe-4">
                {/* Personal Information */}
                <div className="rounded-[23px] border border-[#E3#1F4] p-5">
                  <div className="flex items-center justify-between">
                    <div className="">
                      <p className="text-[16px] font-bold text-[#30273d] lg:text-[20px]">
                        Personal Information
                      </p>
                    </div>
                    {/* Personal information edit button */}
                    <div>
                      <ModalButton
                        label="Edit"
                        view={<PersonalInfoPage title="Profile Setting" />}
                        size="DEFAULT"
                        className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                        icon={
                          <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                        }
                      />
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-1 lg:grid-cols-2">
                    <div>
                      <label className="text-[14px] text-[#9BA1B9] ">
                        First Name
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {capitalizeFirstLetter(data?.first_name ?? '-')}
                      </div>
                    </div>
                    <div className="">
                      <label className="text-[14px] text-[#9BA1B9] ">
                        Last Name
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {capitalizeFirstLetter(data?.last_name ?? '-')}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9] ">
                        Email Address
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.email ?? '-'}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9] ">
                        Phone
                      </label>
                      <div className="mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.contact_number ? (
                          <PhoneNumber
                            value={data?.contact_number}
                            disabled={true}
                            className="display-phone-number poppins_font_number"
                          />
                        ) : (
                          '-'
                        )}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9] ">Bio</label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.bio ? data?.bio : '-'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Company Information */}
                <div className="mt-6 rounded-[23px] border border-[#E3#1F4] p-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[16px] font-bold text-[#120425] lg:text-[20px]">
                        Company Information
                      </p>
                    </div>
                    {/* Company Information edit button */}
                    <div>
                      <div>
                        <ModalButton
                          label="Edit"
                          view={<CompanyInfoPage title="Company Information" />}
                          size="DEFAULT"
                          className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                          icon={
                            <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-1 lg:grid-cols-2">
                    <div>
                      <label className="text-[14px] text-[#9BA1B9] ">
                        Company Name
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.company_name ?? '-'}
                      </div>
                    </div>
                    <div>
                      <label className="text-[14px] text-[#9BA1B9]">
                        Company Website
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.company_website ? data?.company_website : '-'}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9]">
                        Number of Employees
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.no_of_people ?? '-'}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9]">
                        Industry
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.profession_role ?? '-'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Address Information */}
                <div className="mt-6 rounded-[23px] border border-[#E3#1F4] p-5">
                  <div className="flex justify-between	">
                    <div>
                      <p className="text-[16px] font-bold text-[#120425] lg:text-[20px]">
                        General Information
                      </p>
                    </div>
                    {/* Address Information edit button */}
                    <div>
                      <ModalButton
                        label="Edit"
                        view={<AddressInfoPage title="General Information" />}
                        size="DEFAULT"
                        className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                        icon={
                          <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                        }
                      />
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-1 lg:grid-cols-2">
                    <div>
                      <label className="text-[14px] text-[#9BA1B9]">
                        Address
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.address ?? '-'}
                      </div>
                    </div>
                    <div>
                      <label className="text-[14px] text-[#9BA1B9]">
                        Country
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.country?.name ?? '-'}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9]">
                        State
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.state?.name ?? '-'}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9]">City</label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.city?.name ?? '-'}
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="text-[14px] text-[#9BA1B9]">
                        Pincode
                      </label>
                      <div className="poppins_font_number mt-1 text-[18px] font-semibold text-[#120425]">
                        {data?.pincode ?? '-'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Affiliate link */}
                <div className="mt-6 rounded-[23px] border border-[#E3#1F4] p-5">
                  <div className="align-center flex">
                    <div>
                      <p className="text-[20px] font-bold text-[#120425]">
                        Affiliate link
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-start lg:flex-row lg:items-center">
                    <div className="mt-4 w-[200px] lg:w-[90%]">
                      <span className="poppins_font_number mt-1 w-[200px]  break-words text-[18px] text-[#9BA1B9] lg:w-[70%]">
                        {urlToShareIS}
                      </span>
                    </div>
                    <div className="w-[200px] lg:w-[10%]"></div>
                    <Button
                      className="mt-4 w-full bg-[#8C80D2] hover:bg-[#8C80D2] hover:text-white dark:hover:border-[#8C80D2] lg:ms-4 lg:mt-0 lg:w-[200px] "
                      onClick={handleCopyToClipboard}
                    >
                      Copy Link
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </WidgetCard>
      </>
    );
  }
}
