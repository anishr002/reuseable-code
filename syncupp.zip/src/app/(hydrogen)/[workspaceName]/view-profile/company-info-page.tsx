import { useModal } from '@/app/shared/modal-views/use-modal';
import SelectLoader from '@/components/loader/select-loader';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import { messages } from '@/config/messages';
import {
  getUserProfile,
  updateUserProfile,
} from '@/redux/slices/user/auth/signinSlice';
import { handleKeyDown } from '@/utils/common-functions';
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { z } from 'zod';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

const peopleCountOptions = [
  {
    name: 'Just me',
    value: 'Just me',
  },
  {
    name: '2-10',
    value: '2-10',
  },
  {
    name: '11-15',
    value: '11-15',
  },
  {
    name: '16-50',
    value: '16-50',
  },
  {
    name: '51-250',
    value: '51-250',
  },
  {
    name: '251-500',
    value: '251-500',
  },
  {
    name: '501+',
    value: '501+',
  },
  {
    name: "I don't know",
    value: "I don't know",
  },
];

const professionRole = [
  {
    name: 'Super Admin',
    value: 'Agency',
  },
  {
    name: 'Freelancer',
    value: 'Freelancer',
  },
  {
    name: 'Other-Specify',
    value: 'Other-Specify',
  },
];

export const CompanyInfoPage = (props: any) => {
  const { title } = props;
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const [selectedIndustry, setSelectedIndustry] = useState('');
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const data = signIn?.userProfile;

  const initialValues = {
    company_name: data?.company_name ?? '',
    company_website: data?.company_website ?? '',
    no_of_people: data?.no_of_people ?? '',
    profession_role: data?.profession_role
      ? ['Agency', 'Freelancer'].includes(data?.profession_role)
        ? data?.profession_role
        : 'Other-Specify'
      : '',
    profession_role_other: data?.profession_role
      ? !['Agency', 'Freelancer'].includes(data?.profession_role)
        ? data?.profession_role
        : ''
      : '',
    profile_image: data?.profile_image ?? '',
  };
  const companyInformationFormSchema = z.object({
    company_name: z
      .string({ required_error: messages.companyNameRequired })
      .min(1, { message: messages.companyNameRequired })
      .max(30, { message: messages.companyNameLength }),

    company_website: z
      .string()
      .trim()
      .optional()
      .nullable()
      .refine(
        (value) => {
          return (
            !value ||
            /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,4}(:\d{1,5})?(\/[^\s]*)?$/.test(
              value
            )
          );
        },
        {
          message: messages.companyUrlInvalid,
        }
      ),

    no_of_people: z
      .string({ required_error: messages.peopleCountRequired })
      .min(1, { message: messages.peopleCountRequired })
      .max(15, { message: messages.peopleCountMaximumLengthRequired }),
    profession_role: z.string({ required_error: messages.industryRequired }),
    profession_role_other:
      selectedIndustry === 'Other-Specify'
        ? z
            .string({ required_error: messages.industryRequired })
            .min(1, { message: messages.industryRequired })
        : z.string().optional(),
    profile_image: z.any().optional(),
  });

  useEffect(() => {
    if (!data?.profession_role) return;

    if (['Agency', 'Freelancer'].includes(data?.profession_role)) {
      setSelectedIndustry(data?.profession_role);
    } else {
      setSelectedIndustry('Other-Specify');
    }
  }, [data?.profession_role]);

  const onSubmit = (data: any) => {
    const company_url = data?.company_website?.startsWith('http')
      ? data?.company_website
      : !!data?.company_website
        ? `http://${data?.company_website}`
        : '';

    const form: any = new FormData();
    form.append('company_name', data.company_name || '');
    form.append('company_website', company_url || '');
    form.append('no_of_people', data.no_of_people || '');
    form.append('profile_image', data?.profile_image || '');

    if (['Agency', 'Freelancer'].includes(data?.profession_role)) {
      form.append('profession_role', data.profession_role || '');
    } else {
      form.append('profession_role', data.profession_role_other || '');
    }

    dispatch(updateUserProfile(form)).then((result: any) => {
      if (updateUserProfile.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getUserProfile());
          closeModal();
        }
      }
    });
  };

  const onChangeIndustry = (data: any, setValue: any) => {
    setSelectedIndustry(data);
    if (data != 'Other-Specify') setValue('profession_role_other', '');
  };

  return (
    <Form
      validationSchema={companyInformationFormSchema}
      onSubmit={onSubmit}
      useFormProps={{
        defaultValues: initialValues,
        mode: 'all',
      }}
      className="placeholder_color p-10 [&_label]:font-medium"
    >
      {({
        register,
        control,
        formState: { errors, isDirty, isValid },
        setValue,
        setError,
        getValues,
        handleSubmit,
        trigger,
      }) => (
        <div className="space-y-5">
          <div className="mb-6 flex items-center justify-between">
            <Title
              as="h3"
              className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
            >
              {title}
            </Title>
            <ActionIcon
              size="sm"
              variant="text"
              onClick={() => closeModal()}
              className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
            >
              <PiXBold className="h-[18px] w-[18px]" />
            </ActionIcon>
          </div>

          <div
            className={
              'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
            }
          >
            <div>
              <label className="text-[14px] font-semibold text-[#9BA1B9]">
                Company Name *
              </label>
              <Input
                // size={'xl'}
                onKeyDown={handleKeyDown}
                type="text"
                placeholder="Enter Company Name"
                color="info"
                className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                {...register('company_name')}
                error={errors.company_name?.message as string}
              />
            </div>
            <div>
              <label className="text-[14px] font-semibold text-[#9BA1B9]">
                Company Website *
              </label>
              <Input
                // size={'xl'}
                onKeyDown={handleKeyDown}
                type="text"
                placeholder="Enter Company Website"
                color="info"
                className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                {...register('company_website')}
                error={errors.company_website?.message as string}
              />
            </div>

            <div>
              <label className="text-[14px] font-semibold text-[#9BA1B9]">
                Number of Employees *
              </label>
              <Controller
                control={control}
                name="no_of_people"
                render={({ field: { onChange, value } }) => (
                  <Select
                    // size={'xl'}
                    options={peopleCountOptions}
                    onChange={(selectedOption: string) => {
                      onChange(selectedOption);
                    }}
                    value={value}
                    color="info"
                    getOptionValue={(option) => option.value}
                    dropdownClassName="&>label>span]:text-[16px]p-1 border w-12 border-gray-100 shadow-lg"
                    className="font-medium"
                    error={errors?.no_of_people?.message as string}
                  />
                )}
              />
            </div>
            <div>
              <label className="text-[14px] font-semibold text-[#9BA1B9]">
                Industry *
              </label>
              <Controller
                name="profession_role"
                control={control}
                render={({ field: { onChange, value } }) => (
                  <Select
                    // size={'xl'}
                    options={professionRole}
                    onChange={(selectedOption: string) => {
                      onChange(selectedOption),
                        onChangeIndustry(selectedOption, setValue);
                    }}
                    value={value}
                    color="info"
                    getOptionValue={(option) => option.value}
                    dropdownClassName="&>label>span]:text-[16px]p-1 border w-12 border-gray-100 shadow-lg"
                    className="font-medium"
                  />
                )}
              />
            </div>

            <div>
              {selectedIndustry === 'Other-Specify' && (
                <>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Industry *
                  </label>
                  <Input
                    // size={'xl'}
                    onKeyDown={handleKeyDown}
                    type="text"
                    placeholder="Enter Industry Name"
                    color="info"
                    className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('profession_role_other')}
                    error={errors.profession_role_other?.message as string}
                  />
                </>
              )}
            </div>
          </div>
          <div className="mt-2 lg:mt-16">
            <Button
              disabled={signIn.updateloader}
              className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
              type="submit"
              size="xl"
            >
              <span>Save Changes</span>
              {signIn.updateloader && (
                <Spinner size="sm" tag="div" className="ms-3" color="white" />
              )}
            </Button>
          </div>
        </div>
      )}
    </Form>
  );
};
