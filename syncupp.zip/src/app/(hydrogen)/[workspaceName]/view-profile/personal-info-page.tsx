import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { PhoneNumber } from '@/components/ui/phone-input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import { Textarea } from '@/components/ui/textarea';
import {
  getUserProfile,
  updateUserProfile,
} from '@/redux/slices/user/auth/signinSlice';
import { handleKeyDown } from '@/utils/common-functions';
import { personalInfoFormSchema } from '@/utils/validators/agency.schema';
import { useEffect, useRef, useState } from 'react';
import { Controller } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';

import Image from 'next/image';

import TrashIcon from '@/components/icons/trash';
import profile_img_icn from '@public/assets/images/profile_img_icn.png';

export const PersonalInfoPage = (props: any) => {
  const { title } = props;
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [resetImage, setResetImage] = useState(false);
  const [filePreview, SetFilePreview] = useState<any>();
  const [selectedFile, SetSelectedFile] = useState<any>(false);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const data = signIn?.userProfile;

  const initialValues = {
    first_name: data?.first_name ?? '',
    last_name: data?.last_name ?? '',
    email: data?.email ?? '',
    contact_number: data?.contact_number ?? '',
    bio: data?.bio ?? '',
    profile_image: data?.profile_image ?? '',
  };

  useEffect(() => {
    SetFilePreview(data?.profile_image);
  }, [data]);

  const onSubmit = (data: any) => {
    const form: any = new FormData();
    form.append('first_name', data?.first_name || '');
    form.append('last_name', data?.last_name || '');
    form.append('contact_number', data?.contact_number || '');
    form.append('email', data?.email || '');
    form.append('bio', data?.bio || '');
    form.append('profile_image', data?.profile_image || '');

    dispatch(updateUserProfile(form)).then((result: any) => {
      if (updateUserProfile.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getUserProfile());
          closeModal();
        }
      }
    });
  };

  const handleImageChange = (event: any, setValue: any) => {
    const file = event.target.files[0];
    const extension = file?.name?.split('.')?.pop()?.toLowerCase();

    if (file) {
      setValue('profile_image', file);
      SetFilePreview(URL.createObjectURL(file));
      SetSelectedFile(true);
    }
  };

  const removePicture = (setValue: any) => {
    if (selectedFile) {
      SetSelectedFile(false);
      SetFilePreview(data?.profile_image);
      setValue('profile_image', data?.profile_image);
    } else {
      setValue('profile_image', '');
      SetFilePreview(undefined);
      SetSelectedFile(undefined);
    }
  };

  return (
    <>
      <Form
        validationSchema={personalInfoFormSchema}
        onSubmit={onSubmit}
        useFormProps={{
          defaultValues: initialValues,
          mode: 'all',
        }}
        className="placeholder_color p-10 [&_label]:font-medium"
      >
        {({
          register,
          control,
          formState: { errors, isDirty, isValid },
          setValue,
          setError,
          getValues,
          handleSubmit,
          trigger,
        }) => (
          <>
            <div className="space-y-5">
              <div className="mb-6 flex items-center justify-between">
                <Title
                  as="h3"
                  className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
                >
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>

              <div className="flex flex-col items-center justify-start lg:flex-row">
                {/* profile image upload */}

                {!filePreview && (
                  <>
                    <div
                      className="cursor-pointer h-36 w-36 rounded-full border-2 border-dashed border-[#9BA1B9] p-12"
                      onClick={() => imageInputRef?.current?.click()}
                    >
                      <Image
                        src={
                          filePreview
                            ? process.env.NEXT_PUBLIC_IMAGE_URL +
                              '/uploads/' +
                              filePreview
                            : profile_img_icn
                        } // Path to your image
                        alt="Description of image"
                        width={40} // Desired width
                        height={40} // Desired height
                        className="cursor-pointer rounded-md" // Optional Tailwind CSS class
                      />
                    </div>

                    {/* text */}
                    <div className="mt-4 flex flex-col items-center justify-start text-center lg:ms-4 lg:mt-0 lg:items-start lg:text-left">
                      <span className="text-[20px] font-semibold text-[#8C80D2]">
                        Upload your photo
                      </span>
                      <span className="">Let your teammates recognise you</span>
                    </div>
                  </>
                )}

                {filePreview && (
                  <>
                    <div className="cursor-pointer h-36 w-36 rounded-full border-2 border-dashed border-[#9BA1B9] overflow-hidden"
                    onClick={() => imageInputRef?.current?.click()}>
                      <img
                        src={
                          filePreview
                            ? selectedFile
                              ? filePreview
                              : process.env.NEXT_PUBLIC_IMAGE_URL +
                                '/uploads/' +
                                filePreview
                            : process.env.NEXT_PUBLIC_IMAGE_URL +
                              '/uploads/' +
                              data?.profile_image
                        } // Path to your image
                        alt="Profile Image"
                        // width={40} // Desired width
                        // height={40} // Desired height
                        className="cursor-pointer rounded-md w-full h-full" // Optional Tailwind CSS class
                      />
                    </div>
                    <div className="mt-4 flex items-center justify-start text-center lg:ms-4 lg:mt-0 lg:items-start lg:text-left">
                      <Button
                        className="bg-[#8C80D2] text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                        onClick={() => imageInputRef?.current?.click()}
                      >
                        Change Picture
                      </Button>
                      <Button
                        onClick={() => removePicture(setValue)}
                        className="ml-1 bg-[#8C80D2] text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                      >
                        <TrashIcon className="h-4 w-4 cursor-pointer" />
                      </Button>
                    </div>
                  </>
                )}
                <p className="ml-2 text-red-700">{errors?.profile_image?.message as string}</p>
              </div>

              {/* <div>
                <Uploadfile
                  resetImage={resetImage}
                  setResetImage={setResetImage}
                  initialPath={data?.profile_image ? 'uploads/' + data?.profile_image : false}
                  name="profile_image"
                  user={true}
                  readonly={false}
                  setFieldValue={setValue}
                  errors={setError}
                  compontes={true}
                />
              </div> */}

              <input
                {...register('profile_image')}
                type="file"
                onChange={(e) => handleImageChange(e, setValue)}
                accept=".jpeg, .jpg, .png"
                style={{ display: 'none' }}
                ref={imageInputRef}
              />

              <div
                className={
                  'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                }
              >
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    First Name *
                  </label>
                  <Input
                    // size={'xl'}
                    onKeyDown={handleKeyDown}
                    type="text"
                    placeholder="Enter First Name"
                    color="info"
                    className="&>label>span]:text-[16px]  flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425]  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('first_name')}
                    error={errors.first_name?.message as string}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Last Name *
                  </label>

                  <Input
                    // size={'xl'}
                    onKeyDown={handleKeyDown}
                    type="text"
                    placeholder="Enter Last Name"
                    color="info"
                    className="&>label>span]:text-[16px]  flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425]  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('last_name')}
                    error={errors.last_name?.message as string}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Email *
                  </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    // size={'xl'}
                    placeholder="Enter Email address Here..."
                    color="info"
                    className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425]  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('email')}
                    error={errors.email?.message as string}
                    disabled={true}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Phone Number
                  </label>
                  <Controller
                    name="contact_number"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <PhoneNumber
                        country="us"
                        // size={'xl'}
                        className="personal_info_phone_number [&>label>span]:font-medium"
                        value={value}
                        onChange={onChange}
                      />
                    )}
                  />
                </div>
              </div>
              <div>
                <label className="text-[14px] font-semibold text-[#9BA1B9]">
                  Bio
                </label>
                <Textarea
                  onKeyDown={handleKeyDown}
                  placeholder="Enter Bio Here..."
                  maxLength={150}
                  color="info"
                  // size={'xl'}
                  className=" [&_.rizzui-textarea-field]:!resize-none &>label>span>textarea:resize-none &>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425]  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:text-left [&>label>span]:font-semibold"
                  {...register('bio')}
                  error={errors.bio?.message as string}
                />
              </div>
            </div>
            {/* save changes button */}
            <div className="mt-2 lg:mt-16">
              <Button
                disabled={signIn.updateloader}
                className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                type="submit"
                size="xl"
              >
                <span>Save Changes</span>
                {signIn.updateloader && (
                  <Spinner size="sm" tag="div" className="ms-3" color="white" />
                )}
              </Button>
            </div>
          </>
        )}
      </Form>
    </>
  );
};
