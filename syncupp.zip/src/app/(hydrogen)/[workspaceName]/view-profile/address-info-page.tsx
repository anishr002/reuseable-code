import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import {
  getUserProfile,
  updateUserProfile,
} from '@/redux/slices/user/auth/signinSlice';
import {
  RemovecityData,
  getCities,
  getCountry,
  getState,
} from '@/redux/slices/user/client/clientSlice';
import { handleKeyDown, handleKeyPincode } from '@/utils/common-functions';
import { addressInfoFormSchema } from '@/utils/validators/agency.schema';
import { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import Select from 'react-select';

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    cursor: 'pointer',
    backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
    color: state.isSelected ? 'black' : 'black',
    padding: '8px',
  }),
};

const editcustomStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    cursor: 'pointer',
    backgroundColor: state.isFocused ? '#d3e5ff' : 'white', // Light blue when hovered
    color: state.isSelected ? 'black' : 'black',
    padding: '8px',
  }),
  control: (provided: any) => ({
    ...provided,
    backgroundColor: '#fafafa', // Set background color to #fafafa
  }),
};

export const AddressInfoPage = (props: any) => {
  const { title } = props;
  let countryOptions: Record<string, string>[] = [];
  let stateOptions: Record<string, string>[] = [];
  let cityOptions: Record<string, string>[] = [];
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const data = signIn?.userProfile;

  const [selectedCountry, setselectedCountry] = useState<any>();
  const [selectedstate, setselectedstate] = useState<any>();
  const [selectedcity, setselectedcity] = useState<any>();

  const [regionalData, setRegionalData] = useState({
    city: null,
    state: null,
    country: null,
  });

  const initialValues = {
    address: data?.address ?? '',
    city: { label: data?.city?.name, value: data?.city?.name } ?? '',
    state: { label: data?.state?.name, value: data?.state?.name } ?? '',
    country: { label: data?.country?.name, value: data?.country?.name } ?? '',
    pincode: data?.pincode ?? '',
    profile_image: data?.profile_image ?? '',
  };

  useEffect(() => {
    dispatch(getCountry());
    if (data?.country?._id) {
      dispatch(getState({ countryId: data?.country?._id }));
    }
    if (data?.state?._id) {
      dispatch(getCities({ stateId: data?.state?._id }));
    }
  }, []);

  useEffect(() => {
    setselectedCountry({
      label: data?.country?.name,
      value: data?.country?.name,
    });
    setselectedstate({
      label: data?.state?.name,
      value: data?.state?.name,
    });
    setselectedcity({
      label: data?.city?.name,
      value: data?.city?.name,
    });

    setRegionalData({
      ...regionalData,
      city: data?.city?._id,
      state: data?.state?._id,
      country: data?.country?._id,
    });
  }, [signIn?.userProfile]);

  const onSubmit = (data: any) => {
    const form: any = new FormData();
    form.append('address', data?.address || '');
    form.append('pincode', data.pincode || '');
    form.append('city', regionalData?.city || null);
    form.append('state', regionalData.state || null);
    form.append('country', regionalData.country || null);
    form.append('profile_image', data?.profile_image || '');

    dispatch(updateUserProfile(form)).then((result: any) => {
      if (updateUserProfile.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getUserProfile());
          closeModal();
        }
      }
    });
  };

  const countryHandleChange = (selectedOption: any) => {
    setselectedCountry(selectedOption);
    setselectedcity(null);
    setselectedstate(null);

    console.log(selectedOption, 'selectedOption');
    console.log(clientSliceData?.countries, 'clientSliceData?.countries');

    const [countryObj] = clientSliceData?.countries?.filter(
      (country: Record<string, string>) =>
        country?.name === selectedOption?.value
    );

    dispatch(getState({ countryId: countryObj._id }));
    setRegionalData({
      ...regionalData,
      country: countryObj._id,
      state: null,
      city: null,
    });
  };

  const stateHandleChange = (selectedOption: any) => {
    setselectedstate(selectedOption);

    const [stateObj] = clientSliceData?.states?.filter(
      (state: Record<string, string>) => state?.name === selectedOption?.value // console.log(state?.name === selectedOption?.value, 'state', state)
    );
    dispatch(getCities({ stateId: stateObj._id }));
    setRegionalData({ ...regionalData, state: stateObj._id });
  };

  const cityHandleChange = (selectedOption: any) => {
    setselectedcity(selectedOption);
    const [cityObj] = clientSliceData?.cities?.filter(
      (city: Record<string, string>) => city?.name === selectedOption?.value
    );
    setRegionalData({ ...regionalData, city: cityObj._id });
  };

  clientSliceData?.countries !== '' &&
    clientSliceData?.countries?.map((country: Record<string, string>) => {
      countryOptions.push({ label: country?.name, value: country?.name });
    });

  clientSliceData?.states !== '' &&
    clientSliceData?.states?.map((state: Record<string, string>) => {
      stateOptions.push({ label: state?.name, value: state?.name });
    });

  clientSliceData?.cities !== '' &&
    clientSliceData?.cities?.map((city: Record<string, string>) => {
      cityOptions.push({ label: city?.name, value: city?.name });
    });

  return (
    <>
      <Form
        validationSchema={addressInfoFormSchema}
        onSubmit={onSubmit}
        useFormProps={{
          defaultValues: initialValues,
          mode: 'all',
        }}
        className="placeholder_color p-10 [&_label]:font-medium"
      >
        {({
          register,
          control,
          formState: { errors, isDirty, isValid },
          setValue,
        }) => (
          <>
            <div className="space-y-5">
              <div className="mb-6 flex items-center justify-between">
                <Title
                  as="h3"
                  className="text-xl font-normal text-[#9BA1B9] xl:text-2xl"
                >
                  {title}
                </Title>
                <ActionIcon
                  size="sm"
                  variant="text"
                  onClick={() => closeModal()}
                  className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
                >
                  <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>
              </div>

              <div
                className={
                  'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2'
                }
              >
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Address *
                  </label>
                  <Input
                    onKeyDown={handleKeyDown}
                    type="text"
                    placeholder="Enter address Here..."
                    color="info"
                    // size={'xl'}
                    className="&>label>span]:text-[16px] flex w-full justify-center border-[#9BA1B9] text-[16px] font-semibold text-[#120425]  placeholder:text-[16px] placeholder:font-semibold placeholder:text-[#9BA1B9] [&>label>span]:h-[42px] [&>label>span]:text-left [&>label>span]:font-semibold"
                    {...register('address')}
                    error={errors.address?.message as string}
                  />
                </div>

                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Country *
                  </label>
                  <Controller
                    name="country"
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      console.log(value, 'value', 507),
                      (
                        <Select
                          options={countryOptions}
                          value={selectedCountry}
                          onChange={async (selectedOption: any) => {
                            setValue('state', '');
                            setValue('city', '');
                            dispatch(RemovecityData());

                            onChange(selectedOption);
                            countryHandleChange(selectedOption);
                          }}
                          getOptionValue={(option) => option.name}
                          className="h-[50px] border-gray-100 p-1 font-medium"
                          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                          styles={editcustomStyles}
                          maxMenuHeight={150}
                        />
                      )
                    )}
                  />
                  {errors?.country?.message && (
                    <div className="mt-0.5 text-xs font-medium text-red">
                      {errors?.country?.message as string}
                    </div>
                  )}
                </div>
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    State *
                  </label>
                  <Controller
                    name="state"
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      console.log(value, 'value', 507),
                      (
                        <Select
                          options={stateOptions}
                          value={selectedstate}
                          onChange={async (selectedOption: any) => {
                            setValue('city', '');
                            onChange(selectedOption);
                            stateHandleChange(selectedOption);
                          }}
                          getOptionValue={(option) => option.name}
                          className="border-gray-100 p-1 font-medium"
                          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                          isDisabled={stateOptions.length === 0}
                          styles={
                            !(stateOptions.length === 0)
                              ? editcustomStyles
                              : customStyles
                          }
                          maxMenuHeight={150}
                        />
                      )
                    )}
                  />
                  {errors?.state?.message && (
                    <div className="mt-0.5 text-xs font-medium text-red">
                      {errors?.state?.message as string}
                    </div>
                  )}
                </div>
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    City *
                  </label>
                  <Controller
                    name="city"
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      console.log(value, 'value', 507),
                      (
                        <Select
                          options={cityOptions}
                          value={selectedcity}
                          onChange={async (selectedOption: any) => {
                            onChange(selectedOption);
                            cityHandleChange(selectedOption);
                          }}
                          getOptionValue={(option) => option.name}
                          className="border-gray-100 p-1 font-medium"
                          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                          isDisabled={cityOptions.length === 0}
                          styles={
                            !(cityOptions.length === 0)
                              ? editcustomStyles
                              : customStyles
                          }
                          maxMenuHeight={150}
                        />
                      )
                    )}
                  />
                  {errors?.city?.message && (
                    <div className="mt-0.5 text-xs font-medium text-red">
                      {errors?.city?.message as string}
                    </div>
                  )}
                </div>
                <div>
                  <label className="text-[14px] font-semibold text-[#9BA1B9]">
                    Pin Code *
                  </label>
                  <Input
                    onKeyDown={handleKeyPincode}
                    type="text"
                    placeholder="Enter pincode Here..."
                    color="info"
                    className="[&>label>span]:font-medium"
                    {...register('pincode')}
                    error={errors.pincode?.message as string}
                  />
                </div>
              </div>
              <div className="mt-2 lg:mt-16">
                <Button
                  disabled={signIn.updateloader}
                  className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
                  type="submit"
                  size="xl"
                >
                  <span>Save Changes</span>
                  {signIn.updateloader && (
                    <Spinner
                      size="sm"
                      tag="div"
                      className="ms-3"
                      color="white"
                    />
                  )}
                </Button>
              </div>
            </div>
          </>
        )}
      </Form>
    </>
  );
};
