'use client';

import { Title, Text, ActionIcon } from '@/components/ui/text';
import { Button } from '@/components/ui/button';
import { Controller, SubmitHandler } from 'react-hook-form';
import { Form } from '@/components/ui/form';
import { useEffect, useRef, useState } from 'react';
import { routes } from '@/config/routes';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { useMedia } from '@/hooks/use-media';
import { useDispatch, useSelector } from 'react-redux';
import { DatePicker } from '@/components/ui/datepicker';
import {
  capitalizeFirstLetter,
  handleKeyDown,
  parseHTMLContent,
} from '@/utils/common-functions';
import { useRouter, useSearchParams } from 'next/navigation';
import Spinner from '@/components/ui/spinner';
import cn from '@/utils/class-names';
import {
  AgrementFormTypes,
  agrementFormSchema,
} from '@/utils/validators/agreement.schema';
import { Input } from 'rizzui';
import SelectLoader from '@/components/loader/select-loader';
import dynamic from 'next/dynamic';
import QuillLoader from '@/components/loader/quill-loader';
import PageHeader from '@/app/shared/page-header';
import EyeIcon from '@/components/icons/eye';
import {
  createagreement,
  getDropdownclientlist,
  getSingleagreement,
  updateagreement,
} from '@/redux/slices/user/agreement/agreementSlice';
import moment from 'moment';
import type { Metadata } from 'next';
import { FaArrowLeft } from 'react-icons/fa';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import WidgetCard from '@/components/cards/widget-card';
import ReactSelect from 'react-select/creatable';
import { PhoneNumber } from '@/components/ui/phone-input';
import { workspaceCreator } from '@/redux/slices/user/workspace/workspaceSlice';
import Image from 'next/image';
import { useDropzone } from 'react-dropzone';
import imgPlacholder from '@public/assets/images/img_placeholder.svg';
import fileImage from '@public/assets/images/file_img.png';
import TrashIcon from '@/components/icons/trash';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px]" />,
});

const peopleCountOptions = [
  { name: '1-50', value: '1-50' },
  { name: '51-200', value: '51-200' },
  { name: '201-500', value: '201-500' },
  { name: '501-1000', value: '501-1000' },
];

function EditAgreementForm({ params }: { params: { id: string } }) {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const dispatch = useDispatch();
  const router = useRouter();
  const searchParams = useSearchParams();
  const reference_id = searchParams.get('reference');
  const imageref = useRef<any>();

  // state Data selection
  const { user } = useSelector((state: any) => state?.root?.signIn?.user?.data);
  const {
    singleAgreementdetails,
    loading,
    clientlistDetails,
    singleagreementloader,
    dropdownloader,
  } = useSelector((state: any) => state?.root?.agreement);
  const clientSliceData = useSelector((state: any) => state?.root?.client)
    ?.clientProfile;
  const { defaultWorkSpace, workspaceCreatorData } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { role } = useSelector((state: any) => state?.root?.signIn);

  // set dynamic Dropdown options
  // const clientOptions =
  //   clientlistDetails?.data && clientlistDetails?.data?.length > 0
  //     ? clientlistDetails?.data?.map((client: any) => ({
  //       name: client?.client_full_name,
  //       value: client?._id,
  //       key: client,
  //     }))
  //     : [];

  const clientOptions = [
    { label: 'Select Client', value: '', key: {} },
    ...(clientlistDetails?.data && clientlistDetails?.data?.length > 0
      ? clientlistDetails.data.map((client: any) => ({
          label: capitalizeFirstLetter(client?.client_full_name),
          value: client?._id,
          key: client,
        }))
      : []),
  ];

  // state for the Data Management
  const [preview, setpreview] = useState(false);
  const [sendbuttonflag, setsendbuttonflag] = useState<any>(false);
  const [firstRender, setFirstresnder] = useState(true);
  const [buttonclickflag, setbuttonclickflag] = useState<any>(null);
  const [clientInputvalue, setclientInputvalue] = useState<any>(true);
  const [formdata, setformData] = useState({
    title: singleAgreementdetails?.data?.title,
    name: singleAgreementdetails?.data?.receiver
      ? singleAgreementdetails?.data?.first_name +
        singleAgreementdetails?.data?.last_name
      : singleAgreementdetails?.data?.custom_receiver?.name,
    email: singleAgreementdetails?.data?.receiver
      ? singleAgreementdetails?.data?.receiver_email
      : singleAgreementdetails?.data?.custom_receiver?.email,
    address: singleAgreementdetails?.data?.receiver
      ? singleAgreementdetails?.data?.receiver_address
      : singleAgreementdetails?.data?.custom_receiver?.address,
    contact_number: singleAgreementdetails?.data?.receiver
      ? singleAgreementdetails?.data?.receiver_number
      : singleAgreementdetails?.data?.custom_receiver?.contact_number,
    recipient: singleAgreementdetails?.data?.receiver
      ? singleAgreementdetails?.data?.receiver_id
      : singleAgreementdetails?.data?.custom_receiver?._id,
    due_date: singleAgreementdetails?.data?.due_date, // Replace with the actual date in string format
    description: singleAgreementdetails?.data?.agreement_content,
    agreement_logo: singleAgreementdetails?.data?.agreement_logo ?? null,
  });
  const [previewImage, setpreviewImage] = useState<any>(null);
  const [imagesetFlag, setimagesetFlag] = useState<any>(false);

  const [selectedClient, setselectedClient] = useState<any>(
    singleAgreementdetails?.data?.receiver_id
      ? clientOptions.find(
          (option: any) =>
            option.value === singleAgreementdetails?.data?.receiver_id
        )
      : clientOptions.find(
          (option: any) =>
            option.value === singleAgreementdetails?.data?.custom_receiver?._id
        )
  );

  const formattedReceiverAddress = `${
    singleAgreementdetails?.data?.receiver_address
      ? `${singleAgreementdetails.data.receiver_address},`
      : ''
  } ${
    singleAgreementdetails?.data?.receiver_city?.name
      ? `${singleAgreementdetails.data.receiver_city?.name},`
      : ''
  } ${
    singleAgreementdetails?.data?.receiver_state?.name
      ? `${singleAgreementdetails.data.receiver_state?.name},`
      : ''
  } ${
    singleAgreementdetails?.data?.receiver_country?.name
      ? `${singleAgreementdetails.data.receiver_country?.name},`
      : ''
  } ${singleAgreementdetails?.data?.receiver_pincode || ''}`
    .replace(/,\s*$/, '')
    .trim();

  // get today date
  const today = new Date();
  const [dueDate, setDueDate] = useState<Date | null>(
    moment(singleAgreementdetails?.data?.due_date).toDate()
  );

  // Dropdown API Call
  useEffect(() => {
    dispatch(getDropdownclientlist());
  }, [dispatch]);

  useEffect(() => {
    if(singleAgreementdetails?.data?.agreement_logo) {
      setpreviewImage(singleAgreementdetails?.data?.agreement_logo);
    } else {
      setpreviewImage(null);
    }
  }, [singleAgreementdetails]);

  //get single Details API call
  useEffect(() => {
    dispatch(getSingleagreement(params?.id));
  }, [params?.id, dispatch]);

  useEffect(() => {
    if (role) {
      dispatch(workspaceCreator());
    }
  }, [dispatch,role]);

  // useEffect set a form Data
  useEffect(() => {
    if (singleAgreementdetails) {
      setformData({
        title: singleAgreementdetails?.data?.title || '',
        name: singleAgreementdetails?.data?.receiver
          ? singleAgreementdetails?.data?.first_name +
            singleAgreementdetails?.data?.last_name
          : singleAgreementdetails?.data?.custom_receiver?.name,
        email: singleAgreementdetails?.data?.receiver
          ? singleAgreementdetails?.data?.receiver_email
          : singleAgreementdetails?.data?.custom_receiver?.email,
        address: singleAgreementdetails?.data?.receiver
          ? formattedReceiverAddress
          : singleAgreementdetails?.data?.custom_receiver?.address,
        contact_number: singleAgreementdetails?.data?.receiver
          ? singleAgreementdetails?.data?.receiver_number
          : singleAgreementdetails?.data?.custom_receiver?.contact_number,
        recipient: singleAgreementdetails?.data?.receiver
          ? singleAgreementdetails?.data?.receiver_id
          : singleAgreementdetails?.data?.custom_receiver?._id,
        due_date: singleAgreementdetails?.data?.due_date, // Replace with the actual date in string format
        description: singleAgreementdetails?.data?.agreement_content || '',
        agreement_logo: singleAgreementdetails?.data?.agreement_logo ?? null,
      });
      // setDueDate(new Date(singleAgreementdetails?.data?.due_date))
      const parsedDate = moment(
        singleAgreementdetails?.data?.due_date
      ).toDate();
      setDueDate(parsedDate);

      singleAgreementdetails?.data?.receiver_id
        ? setselectedClient(
            clientOptions.find(
              (option: any) =>
                option.value === singleAgreementdetails?.data?.receiver_id
            )
          )
        : setselectedClient(
            clientOptions.find(
              (option: any) =>
                option.value ===
                singleAgreementdetails?.data?.custom_receiver?._id
            )
          );
    }
  }, [singleAgreementdetails]);

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    const file = acceptedFiles[0];
    const fileType = file?.type;

    // Check if the uploaded file is a JPG or PNG image
    if (
      fileType === 'image/jpeg' ||
      fileType === 'image/png' ||
      fileType === 'image/jpg'
    ) {
      const fileUrl = URL.createObjectURL(file);
      // setValue("board_image", file)
      imageref.current('agreement_logo', file, { shouldValidate: true });
      setpreviewImage(fileUrl);
      setimagesetFlag(true);
    } else {
      imageref.current('agreement_logo', file, { shouldValidate: true });
      setpreviewImage(fileImage);
      // Optionally, handle the case where the file is not a JPG or PNG image
      console.error('Invalid file type. Only JPG and PNG images are allowed.');
    }
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    // useFsAccessApi: false,
    onDrop: handleDrop,
    // accept: { 'image/*': [] },
    // maxSize: 6 * 1024 * 1024, // Maximum file size of 10MB
    multiple: false,
    noClick: false,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
    useDropzone(dropzoneOptions);

  // OnSubmit Handler
  const onSubmit: SubmitHandler<AgrementFormTypes> = (data) => {
    const agreementData = {
      client_id: user?._id,
      title: data?.title,
      // receiver: data?.recipient,
      // due_date: moment(data?.due_date).format('DD/MM/YYYY'),
      agreement_content: data?.description,
      send: sendbuttonflag,
      custom_receiver: {
        // name: data?.name,
        // email: data?.email,
        // address: data?.address,
        // contact_number: data?.contact_number,
      },
      agreement_logo: data?.agreement_logo ?? null,
    };

    const createFormData = (agreementData: any) => {
      const formData = new FormData();

      // Append scalar fields
      formData.append('client_id', agreementData.client_id || '');
      formData.append('title', agreementData.title || '');
      formData.append('receiver', agreementData.receiver || '');
      formData.append('due_date', agreementData.due_date || '');
      formData.append(
        'agreement_content',
        agreementData?.agreement_content || ''
      );
      formData.append('send', agreementData.send ? 'true' : 'false'); // Send as string

      // Append nested fields: custom_receiver
      if (agreementData?.custom_receiver) {
        formData.append(
          'custom_receiver[name]',
          agreementData.custom_receiver.name || ''
        );
        formData.append(
          'custom_receiver[email]',
          agreementData.custom_receiver.email || ''
        );
        formData.append(
          'custom_receiver[address]',
          agreementData.custom_receiver.address || ''
        );
        formData.append(
          'custom_receiver[contact_number]',
          agreementData.custom_receiver.contact_number || ''
        );
      }

      // Append file (agreement_logo)
      if (agreementData.agreement_logo) {
        formData.append('agreement_logo', agreementData.agreement_logo);
      } else {
        formData.append('agreement_logo', 'null');
      }

      return formData;
    };

    const formDataPayload = createFormData(agreementData);

    params?.id && formDataPayload?.append('id', params?.id);

    dispatch(updateagreement({ data: formDataPayload, id: params?.id })).then(
      (result: any) => {
        if (updateagreement.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setbuttonclickflag(null);
            reference_id
              ? router.replace(
                  routes.clients.details(
                    defaultWorkSpace?.name,
                    clientSliceData?._id
                  )
                )
              : router.replace(routes.agreement(defaultWorkSpace?.name));
          }
        }
      }
    );
    setsendbuttonflag(false);
  };

  // Send Button Handler
  const SendHandler = () => {
    setsendbuttonflag(true);
    setbuttonclickflag('Send');
  };

  // Dropdown style
  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      cursor: 'pointer',
      backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  // Inside the onChange event handler of the Select component
  const handleClientChange = (e: any, setValue: any) => {
    if (e?.__isNew__ || e?.value == '') {
      setValue('contact_number', '');
      setValue('name', e?.value, { shouldValidate: true });
      setValue('recipient', '');
      setValue('email', '');
      setValue('address', '');

      setclientInputvalue(false);
    } else {
      const formattedAddress = `${e?.key?.address ? `${e.key.address},` : ''} ${
        e?.key?.city?.name ? `${e.key.city.name},` : ''
      } ${e?.key?.state?.name ? `${e.key.state.name},` : ''} ${
        e?.key?.country?.name ? `${e.key.country.name},` : ''
      } ${e?.key?.pincode || ''}`
        .replace(/,\s*$/, '')
        .trim();

      setValue('contact_number', e?.key?.contact_number, {
        shouldValidate: true,
      });
      setValue('recipient', e?.value, { shouldValidate: true });
      setValue('name', e?.label, { shouldValidate: true });
      setValue('address', formattedAddress, { shouldValidate: true });
      setValue('email', e?.key?.email, { shouldValidate: true });

      setclientInputvalue(true);
    }
    setselectedClient(e);
  };

  return (
    <>
      {!singleagreementloader && !dropdownloader ? (
        <div>
          {!preview && (
            <>
              <div>
                <CustomePageHeader
                  title="Edit Agreement"
                  route={routes.agreement(defaultWorkSpace?.name)}
                  titleClassName="montserrat_font_title"
                />
              </div>

              <WidgetCard rounded="lg" title="">
                <Form<AgrementFormTypes>
                  validationSchema={agrementFormSchema}
                  onSubmit={onSubmit}
                  useFormProps={{
                    defaultValues: firstRender
                      ? {
                          title: singleAgreementdetails?.data?.title || '',
                          name: singleAgreementdetails?.data?.receiver
                            ? singleAgreementdetails?.data?.first_name +
                              singleAgreementdetails?.data?.last_name
                            : singleAgreementdetails?.data?.custom_receiver
                                ?.name,
                          email: singleAgreementdetails?.data?.receiver
                            ? singleAgreementdetails?.data?.receiver_email
                            : singleAgreementdetails?.data?.custom_receiver
                                ?.email,
                          address: singleAgreementdetails?.data?.receiver
                            ? formattedReceiverAddress
                            : singleAgreementdetails?.data?.custom_receiver
                                ?.address,
                          contact_number: singleAgreementdetails?.data?.receiver
                            ? singleAgreementdetails?.data?.receiver_number
                            : singleAgreementdetails?.data?.custom_receiver
                                ?.contact_number,
                          recipient: singleAgreementdetails?.data?.receiver
                            ? singleAgreementdetails?.data?.receiver_id
                            : singleAgreementdetails?.data?.custom_receiver
                                ?._id,
                          due_date: singleAgreementdetails?.data?.due_date, // Replace with the actual date in string format
                          description:
                            singleAgreementdetails?.data?.agreement_content ||
                            '',
                          agreement_logo:
                            singleAgreementdetails?.data?.agreement_logo ??
                            null,
                        }
                      : formdata,
                    mode: 'all',
                  }}
                  className=" p-10 [&_label]:font-medium"
                >
                  {({
                    register,
                    control,
                    formState: { errors },
                    watch,
                    trigger,
                    formState: { isDirty, isValid },
                    setValue,
                  }) => (
                    <div className="placeholder_color space-y-5">
                      {/* Image Upload section  */}
                      <div className="mb-5 grid grid-cols-1 items-center">
                        {previewImage ? (
                          <div className="flex items-center justify-start ">
                            <Image
                              alt="img"
                              className="mr-3"
                              src={
                                !imagesetFlag
                                  ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${previewImage}`
                                  : previewImage
                              }
                              width={100}
                              height={100}
                            />
                            <TrashIcon
                              className="ms-4 h-5 w-5 cursor-pointer"
                              onClick={() => {
                                setpreviewImage(null);
                                setValue('agreement_logo', null, {
                                  shouldValidate: true,
                                });
                              }}
                            />
                          </div>
                        ) : (
                          <div {...getRootProps()}>
                            <input {...getInputProps()} />
                            <div
                              className="flex cursor-pointer items-center justify-start"
                              onClick={() => {
                                // open()
                                imageref.current = setValue;
                              }}
                            >
                              <Image
                                alt="img"
                                className="mr-5"
                                src={imgPlacholder}
                                width={44}
                                height={44}
                              />
                              <div className="flex flex-col justify-start ">
                                <div className="font-semibold">
                                  Drag your logo here
                                </div>
                                <div className="font-semibold">
                                  or{' '}
                                  <span className="underline">
                                    select a file
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="mt-0.5 text-xs text-red">
                          {errors && errors?.agreement_logo
                            ? (errors?.agreement_logo?.message as string)
                            : ''}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 items-start gap-4 md:grid-cols-3 xl:gap-5 xl:pb-2">
                        <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          // size={isMedium ? 'lg' : 'xl'}
                          label="Title*"
                          placeholder="Agreement Title"
                          // rounded="pill"
                          color="info"
                          className="w-full  [&>label>span]:font-medium"
                          {...register('title')}
                          error={errors.title?.message}
                          inputClassName="text-black"
                        />
                        {/* <Controller
                          control={control}
                          name="recipient"
                          render={({ field: { onChange, value } }) => (
                            <Select
                              options={clientOptions}
                              onChange={(selectedOption: any) => {
                                setselectedClient(selectedOption);
                                onChange(selectedOption?.name);
                              }}
                              value={value}
                              label="Client*"
                              color="info"
                              // Remove getOptionLabel and getOptionValue props
                              dropdownClassName="p-1 border w-12 border-gray-100 shadow-lg capitalize"
                              className="font-medium capitalize"
                              error={errors?.recipient?.message}
                            />
                          )}
                        /> */}
                        {/* <div className="w-full">
                          <label className="text-[14px] font-semibold text-[#9BA1B9] ">
                            Name *
                          </label>
                          <Controller
                            control={control}
                            name="name"
                            render={({ field: { onChange, value } }) => (
                              <ReactSelect
                                placeholder="Select a client"
                                className="poppins_font_number mt-1.5 w-full font-medium !text-black"
                                value={selectedClient}
                                isDisabled={!!reference_id}
                                options={clientOptions}
                                styles={customStyles}
                                onChange={(e) => {
                                  handleClientChange(e, setValue);
                                }}
                              />
                            )}
                          />
                          {errors?.name?.message && (
                            <span className="mt-0.5 text-xs text-red">
                              {errors?.name?.message}
                            </span>
                          )}
                        </div> */}

                        {/* <Input
                          onKeyDown={handleKeyDown}
                          type="email"
                          label="Email *"
                          disabled={clientInputvalue || !!reference_id}
                          placeholder="Enter email address"
                          // rounded="pill"
                          color="info"
                          className="w-full  [&>label>span]:font-medium"
                          {...register('email')}
                          error={errors.email?.message}
                          inputClassName="text-black"
                        /> */}

                        {/* <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          label="Address *"
                          placeholder="Enter your address"
                          disabled={clientInputvalue || !!reference_id}
                          // value={formdata?.email}
                          // rounded="pill"
                          color="info"
                          className="w-full  [&>label>span]:font-medium"
                          {...register('address')}
                          error={errors.address?.message}
                          inputClassName="text-black"
                        /> */}

                        {/* <Controller
                          name="contact_number"
                          control={control}
                          render={({ field }) => (
                            <PhoneNumber
                              {...field}
                              disabled={clientInputvalue || !!reference_id}
                              label="Phone Number"
                              country="us"
                              // size="lg"
                              className="w-full"
                              value={field.value}
                              labelClassName="text-sm font-semibold text-[#9BA1B9]"
                              placeholder="Enter contact number"
                              onChange={(value) => field.onChange(value)}
                              error={errors.contact_number?.message}
                              inputClassName="text-black"
                            />
                          )}
                        /> */}

                        {/* <div className="flex flex-col">
                          <label
                            htmlFor="due_date"
                            className="mb-1.5 font-medium text-[#9BA1B9] dark:text-gray-600"
                          >
                            Due Date *
                          </label>
                          <Controller
                            name="due_date"
                            control={control}
                            render={({ field: { onChange, value } }) => (
                              <DatePicker
                                selected={dueDate}
                                onChange={(date: Date) => {
                                  setDueDate(date);
                                  onChange(date.toISOString()); // convert date to string
                                }}
                                minDate={today}
                                placeholderText="Select Date"
                                inputProps={{
                                  inputClassName: 'text-black',
                                }}
                              />
                            )}
                          />
                          {errors.due_date && (
                            <span className="mt-0.5 text-xs text-red">
                              {errors.due_date.message}
                            </span>
                          )}
                        </div> */}
                      </div>
                      <div>
                        <Controller
                          control={control}
                          name="description"
                          render={({ field: { onChange, value } }) => (
                            <QuillEditor
                              value={value}
                              onChange={onChange}
                              label="Description *"
                              className="quill-editor-font col-span-full text-black [&_.ql-editor]:min-h-[100px]"
                              labelClassName="font-medium text-[#9BA1B9] dark:text-gray-600 mb-1.5"
                            />
                          )}
                        />
                        {errors.description && (
                          <span className="mt-0.5 text-xs text-red">
                            {errors.description.message}
                          </span>
                        )}
                      </div>

                      <div className="poppins_font_number mb-1.5 mt-5 flex justify-between font-semibold text-black dark:text-gray-600">
                        <ul>
                          <li className="capitalize">
                            {workspaceCreatorData &&
                            Object.keys(workspaceCreatorData).length > 0
                              ? workspaceCreatorData?.data?.first_name +
                                ' ' +
                                workspaceCreatorData?.data?.last_name
                              : user?.first_name + ' ' + user?.last_name}
                          </li>
                          <li>
                            {workspaceCreatorData &&
                            Object.keys(workspaceCreatorData).length > 0
                              ? workspaceCreatorData?.data?.email
                              : user?.email}
                          </li>
                          <li>
                            {workspaceCreatorData &&
                            Object.keys(workspaceCreatorData).length > 0
                              ? workspaceCreatorData?.data?.contact_number
                              : user?.contact_number}
                          </li>
                        </ul>
                        {/* <ul>
                          <li className="capitalize">
                            {watch('recipient')
                              ? selectedClient?.key?.client_full_name
                              : watch('name') || '( Receiver Name )'}
                          </li>
                          <li>
                            {watch('recipient')
                              ? selectedClient?.key?.email
                              : watch('email') || '( Receiver Email )'}
                          </li>
                          <li>
                            {watch('recipient')
                              ? selectedClient?.key?.contact_number
                              : watch('contact_number') || '( Receiver Phone )'}
                          </li>
                        </ul> */}
                      </div>

                      <div className="mt-20 flex justify-end space-x-4 ">
                        {/* <Button
                          type="button"
                          onClick={() => {
                            handlePreview(watch, trigger, isDirty, isValid);
                          }}
                          variant="outline"
                          className="bg-none text-xs hover:bg-[#8e45b8] @xl:w-auto dark:text-white sm:text-sm"
                        >
                          <EyeIcon className="mr-2 h-5 w-5" />
                          Preview
                        </Button> */}
                        <Button
                          type="submit"
                          disabled={loading}
                          onClick={SendHandler}
                          className="h-12 w-48 rounded-3xl bg-[#8C80D2] text-sm text-white"
                        >
                          Send Agreement
                          {loading && buttonclickflag === 'Send' && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                        <Button
                          disabled={loading}
                          onClick={() => {
                            setbuttonclickflag('Save');
                          }}
                          type="submit"
                          className="h-12 w-44 rounded-3xl bg-[#E3E1F4] text-sm text-[#8C80D2]"
                        >
                          Save Draft
                          {loading && buttonclickflag === 'Save' && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    </div>
                  )}
                </Form>
              </WidgetCard>
            </>
          )}

          {/* Priview of Agreement */}
          {preview && (
            <>
              <div className="mt-90 flex justify-end space-x-4">
                <Button
                  type="button"
                  onClick={() => {
                    setpreview(false);
                  }}
                  className="mb-5 bg-none text-xs sm:text-sm"
                >
                  <FaArrowLeft className="me-1.5 h-[17px] w-[17px] bg-[#53216F]" />
                  Back
                </Button>
              </div>
              <h3 className="flex items-center justify-between rounded border-2 border-solid border-gray-300 bg-gray-100 p-3">
                <span>{formdata?.title}</span>
                <span>
                  {formdata?.due_date && formdata?.due_date != ''
                    ? 'Due Date : ' +
                      moment(formdata?.due_date).format('Do MMM. ‘YY')
                    : ''}
                </span>
              </h3>
              <div className="mt-5">
                <div
                  className="break-all"
                  dangerouslySetInnerHTML={{
                    __html: parseHTMLContent(formdata?.description),
                  }}
                />
              </div>

              {/* <div className="mb-1.5 mt-5 flex justify-between font-medium text-gray-700 dark:text-gray-600">
                <ul>
                  <li className="capitalize">{user?.first_name}</li>
                  <li>{user?.email}</li>
                  <li>{user?.contact_number}</li>
                </ul>
                <ul>
                  <li className="capitalize">
                    {selectedClient?.key?.client_full_name &&
                    selectedClient?.key?.client_full_name != ''
                      ? selectedClient?.key?.client_full_name
                      : '( Receiver Name )'}
                  </li>
                  <li>
                    {selectedClient?.key?.email &&
                    selectedClient?.key?.email != ''
                      ? selectedClient?.key?.email
                      : '( Receiver Email )'}
                  </li>
                  <li>
                    {selectedClient?.key?.contact_number &&
                    selectedClient?.key?.contact_number != ''
                      ? selectedClient?.key?.contact_number
                      : '( Receiver Phone )'}
                  </li>
                </ul>
              </div> */}
            </>
          )}
        </div>
      ) : (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" className="ms-3" />
        </div>
      )}
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'agreements',
  null,
  'update'
)(EditAgreementForm);
