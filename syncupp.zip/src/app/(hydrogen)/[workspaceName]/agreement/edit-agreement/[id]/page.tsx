
import { metaObject } from '@/config/site.config';
import EditAgreementForm from './main-page';
import CreateAgreementForm from '../../create-agreement/main-page';



export const metadata = {
    ...metaObject('Edit Agreement'),
};

export default function Page({ params }: { params: { id: string } }) {
    return (
        <>
              <CreateAgreementForm  params={params}/>

            {/* <EditAgreementForm params={params} /> */}
        </>
    );
}
