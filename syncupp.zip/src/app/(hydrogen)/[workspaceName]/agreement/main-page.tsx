'use client';

import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { usePathname, useRouter } from 'next/navigation';
import CustomTable from '@/components/common-tables/table';
import { AgreementColumns } from '@/app/shared/agreement/columns';
import {
  deleteAgencyAgreement,
  getAllAgencyagreement,
  getDropdownclientlist,
  resetAgreementlist,
  setPagginationParams,
  setShowForm,
  setSigner,
  setTemplateView,
} from '@/redux/slices/user/agreement/agreementSlice';
import { ActionIcon, Button } from 'rizzui';
import { PiListBullets, PiPlusBold } from 'react-icons/pi';
import { routes } from '@/config/routes';
import DateFiled from '@/components/controlled-table/date-field';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import WidgetCard from '@/components/cards/widget-card';
import restImg from 'public/assets/images/reset_icon.svg';
import Image from 'next/image';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import moment from 'moment';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import ReactSelect from 'react-select/creatable';
import Link from 'next/link';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { MdOutlineSpaceDashboard } from 'react-icons/md';
import cn from '@/utils/class-names';
import { ChooseAgreementTemplate } from '@/app/shared/agreement/ChooseAgreementTemplate';

const pageHeader = {
  title: 'Agreements',
};

const Statusoptions = [
  { name: 'All', value: '' },
  { name: 'Draft', value: 'draft' },
  { name: 'Sent', value: 'sent' },
  { name: 'Agreed', value: 'agreed' },
  { name: 'Reject', value: 'reject' },
];

function AgreementPage(props: any) {
  const { clientSliceData, clientId } = props;

  const dispatch = useDispatch();
  const router = useRouter();
  const pathname = usePathname().includes('/client/details/');
  const { closeModal } = useModal();
  const [pageSize, setPageSize] = useState(10);


  const { agreementDetails, loading, clientlistDetails, templateView } = useSelector(
    (state: any) => state?.root?.agreement
  );
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.agreement
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const invoiceSliceData = useSelector((state: any) => state?.root?.invoice);
  const signIn = useSelector((state: any) => state?.root?.signIn);

  const [selectedClient, setselectedClient] = useState<any>(null);
  const [statusname, setstatusname] = useState<any>({ name: 'Sent', value: 'sent' });
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);

  // const clientOptions = [
  //   { name: 'Select Client', value: '', key: {} },
  //   ...(clientlistDetails.data && clientlistDetails.data?.length > 0
  //     ? clientlistDetails.data.map((client: any) => ({
  //       name: client?.client_full_name,
  //       value: client?._id,
  //       key: client,
  //     }))
  //     : []),
  // ];

  // Get Dropdown Clients
  useEffect(() => {
    dispatch(resetAgreementlist({}));
    // dispatch(getDropdownclientlist());
  }, [dispatch]);

  useEffect(() => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    dispatch(
      getAllAgencyagreement({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        client_id: pathname ? clientSliceData?._id : null,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date: moment(endRangeDate).format('DD/MM/YYYY'),
        client_name: selectedClient?.value,
        status_name: statusname?.value,
      })
    );
  }, [statusname, selectedClient, endRangeDate]);

  //Paggination Handler
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    await dispatch(setPagginationParams(paginationParams));
    const response = await dispatch(
      getAllAgencyagreement({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        client_id: pathname ? clientSliceData?._id : null,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date: moment(endRangeDate).format('DD/MM/YYYY'),
        client_name: selectedClient?.value,
        status_name: statusname?.value,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllAgencyagreement({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          client_id: pathname ? clientSliceData?._id : null,
          start_date:
            startRangeDate && startRangeDate != null
              ? moment(startRangeDate).format('DD/MM/YYYY')
              : null,
          end_date: moment(endRangeDate).format('DD/MM/YYYY'),
          client_name: selectedClient?.value,
          status_name: statusname?.value,
        })
      );
      return data?.client;
    }
    return data?.client;
  };

  // Delete Handler
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number
  ) => {
    try {
      const res = await dispatch(
        deleteAgencyAgreement({ agreementIdsToDelete: id })
      );
      if (res.payload.success === true) {
        closeModal()
        const reponse = await dispatch(
          getAllAgencyagreement({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: 'createdAt',
            sort_order: 'desc',
            client_id: pathname ? clientSliceData?._id : null,
            start_date:
              startRangeDate && startRangeDate != null
                ? moment(startRangeDate).format('DD/MM/YYYY')
                : null,
            end_date: moment(endRangeDate).format('DD/MM/YYYY'),
            client_name: selectedClient?.value,
            status_name: statusname?.value,
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    setstatusname(null);
    setselectedClient(null);
  };

  // Dropdown style
  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      cursor: 'pointer',
      backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  // Button link
  const linkHref = pathname
    ? `${routes.createAgreement(
      defaultWorkSpace?.name
    )}?reference=${clientSliceData?._id}`
    : routes.createAgreement(defaultWorkSpace?.name);

  // Table Filters
  const AgreementsFilters = () => {
    return (
      <>
        {/* {!pathname && (
          <Select
            className="w-full !text-black"
            onChange={(e) => {
              setselectedClient(e);
            }}
            placeholder="Select a Receiver"
            options={clientOptions}
            value={capitalizeFirstLetter(selectedClient?.name)}
            dropdownClassName="capitalize !text-black"
          // label="Recipient*"
          // color="info"
          />
        )} */}

        {/* {!pathname && <ReactSelect
                    placeholder='Select a Receiver'
                    className="w-full"
                    value={(selectedClient)}
                    options={clientOptions}
                    // isClearable={false}
                    styles={customStyles}
                    onChange={(e) => { setselectedClient(e) }}
                />} */}

        <Select
          className="w-full !text-black"
          onChange={(e) => {
            setstatusname(e);
          }}
          placeholder="Select a Status"
          options={Statusoptions}
          value={statusname?.name}
          dropdownClassName="!text-black"
        // color="info"
        />

        {/* <DateFiled
          className="w-full"
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Select Date in a Range"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        /> */}
        <Button
          type="button"
          className="flex h-[40px] w-[90px] gap-2 items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
          onClick={handleResetFilters}
        >
          <Image
            className="text-white"
            alt="reset_logo"
            width={15}
            height={15}
            src={restImg}
          />
          Reset
        </Button>

        {pathname &&
          (['agency'].includes(signIn?.role) ||
            (['team_agency', 'team_client'].includes(signIn?.role) &&
              checkPermission(
                'agreement',
                null,
                'create',
                signIn?.permission
              ))) && (
            <div className="flex justify-end">
              <Link href={linkHref} className="w-full">
                <Button
                  type="button"
                  className="h-12 w-full rounded-3xl bg-[#8C80D2] text-sm"
                >
                  <PiPlusBold className="me-1.5 h-[17px] w-[17px]" /> Add
                  Agreement
                </Button>
              </Link>
            </div>
          )}
      </>
    );
  };

  if (invoiceSliceData?.loading) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <>
      {/* {loading ? <div className='p-10 flex items-center justify-center'>
                <Spinner size="xl" tag='div' />
            </div> : */}
      <div>
        {!pathname && (<>
          <CustomePageHeader
            title={!pathname ? pageHeader.title : ''}
          // titleClassName="!text-[#111928] text-28px !font-bold"
          >
            {(['agency'].includes(signIn?.role) || ['team_agency'].includes(signIn?.role) && checkPermission('agreements', null, 'create', signIn?.permission)) && (
              <div onClick={() => {
                dispatch(setShowForm(false));
                dispatch(setSigner(false));
              }}>
                <Link href={linkHref} className="w-full">
                  <Button
                    type="button"
                    className="p-3 rounded-lg flex gap-2 bg-[#8C80D2] text-sm"
                  >
                    <PiPlusBold className="h-4 w-4" />
                    New agreement
                  </Button>
                </Link>
              </div>
            )}
          </CustomePageHeader>
          <div
            className={cn(
              'flex h-[40px] w-[224px] items-center justify-center rounded-lg bg-[#F9FAFB] mb-3 p-1'
            )}
          >
            <ActionIcon
              size="sm"
              variant="flat"
              className={cn(
                'group flex w-[115px] items-center justify-center gap-[2px] bg-transparent hover:!bg-transparent text-[#4B5563]',
                !templateView && 'bg-[#FFFFFF] border-[1px] border-[#D1D5DB] text-[#111928]'
              )}
              onClick={() => dispatch(setTemplateView(false))}
            >
              {/* <PiListBullets
                className={cn(
                  'h-3.5 w-3.5',
                  templateview ? 'text-black' : 'text-[#362F78]'
                )}
              /> */}
              <span className="text-sm font-medium">Recently sent</span>
            </ActionIcon>
            <ActionIcon
              size="sm"
              variant="flat"
              className={cn(
                'group flex w-[93px] items-center justify-center gap-[2px] bg-transparent hover:!bg-transparent text-[#4B5563]',
                templateView && 'bg-[#FFFFFF] border-[1px] border-[#D1D5DB] text-[#111928]'
              )}
              onClick={() => dispatch(setTemplateView(true))}
            // onClick={() => setTemplateview(true)}

            >
              {/* <MdOutlineSpaceDashboard
                className={cn(
                  'h-3.5 w-3.5',
                  !templateview ? 'text-black' : 'text-[#362F78]'
                )}
              /> */}
              <span className="text-sm font-medium">Templates</span>
            </ActionIcon>
          </div>
        </>
        )}
        {pathname && (
          <div className="table_border_remove">
            <div className="mt-8">
              <CustomTable
                data={agreementDetails?.data?.agreements || []}
                total={agreementDetails?.data?.page_count || 1}
                loading={loading}
                pageSize={pageSize}
                setPageSize={setPageSize}
                handleDeleteById={handleDeleteById}
                handleChangePage={handleChangePage}
                getColumns={AgreementColumns}
                filtersList={<AgreementsFilters />}
                scroll={{ x: 0 }}
              />
            </div>
          </div>
        )}

        {/* {!pathname && (
          <WidgetCard rounded="lg" title="">
            <div className="table_border_remove">
              <CustomTable
                data={agreementDetails?.data?.agreements || []}
                total={agreementDetails?.data?.page_count || 1}
                loading={loading}
                pageSize={pageSize}
                setPageSize={setPageSize}
                handleDeleteById={handleDeleteById}
                handleChangePage={handleChangePage}
                getColumns={AgreementColumns}
                filtersList={<AgreementsFilters />}
                scroll={{ x: 0 }}
              />
            </div>
          </WidgetCard>
        )} */}
        {!pathname && !templateView && (
          <WidgetCard rounded="lg" title="">
            <div className="table_border_remove">
              <CustomTable
                data={agreementDetails?.data?.agreements || []}
                total={agreementDetails?.data?.page_count || 1}
                loading={loading}
                pageSize={pageSize}
                setPageSize={setPageSize}
                handleDeleteById={handleDeleteById}
                handleChangePage={handleChangePage}
                getColumns={AgreementColumns}
                filtersList={<AgreementsFilters />}
                scroll={{ x: 0 }}
              />
            </div>
          </WidgetCard>
        )}
        {!pathname && templateView && (
          <ChooseAgreementTemplate />
        )
        }

      </div>
      {/* } */}
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'agreements',
  null,
  'view'
)(AgreementPage);
