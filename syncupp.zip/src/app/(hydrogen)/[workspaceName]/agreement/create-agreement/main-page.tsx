'use client';

import { AgreementCreateSuccess } from '@/app/shared/(admin)/agreement/AgreementCreateSuccess';
import PreviewAgreement from '@/app/shared/(admin)/agreement/PreviewAgreement';
import { useModal } from '@/app/shared/modal-views/use-modal';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import EyeIcon from '@/components/icons/eye';
import TrashIcon from '@/components/icons/trash';
import QuillLoader from '@/components/loader/quill-loader';
import SelectLoader from '@/components/loader/select-loader';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import AdvanceQuillEditor from '@/components/ui/advanced-quill-editor';
import { Button } from '@/components/ui/button';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import { PhoneNumber } from '@/components/ui/phone-input';
import Spinner from '@/components/ui/spinner';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import { useMedia } from '@/hooks/use-media';
import {
  createagreement,
  getDropdownclientlist,
  getSingleagreement,
  setagreementId,
  updateagreement,
} from '@/redux/slices/user/agreement/agreementSlice';
import { getDefalutInvoiceImage } from '@/redux/slices/user/setting/settingSlice';
import { workspaceCreator } from '@/redux/slices/user/workspace/workspaceSlice';
import {
  capitalizeFirstLetter,
  handleKeyDown
} from '@/utils/common-functions';
import {
  AgrementFormTypes,
  agrementFormSchema,
} from '@/utils/validators/agreement.schema';
import fileImage from '@public/assets/images/file_img.png';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import fileUploadIcon from '@public/assets/svgs/fileUploadIcon.svg';
import moment from 'moment';
import dynamic from 'next/dynamic';
import Image from 'next/image';
import { useRouter, useSearchParams } from 'next/navigation';
import { any, string } from 'prop-types';
import { useEffect, useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Controller, SubmitHandler } from 'react-hook-form';
import toast from 'react-hot-toast';
import { GrAttachment } from 'react-icons/gr';
import { PiCalendar, PiCaretDownBold, PiImage, PiSignature } from 'react-icons/pi';
import { RxText } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect from 'react-select/creatable';
import { Input, Textarea } from 'rizzui';

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
  ssr: false,
  loading: () => <QuillLoader className="col-span-full h-[143px]" />,
});


function CreateAgreementForm({ params }: { params: { id: string } }) {
  const isMedium = useMedia('(max-width: 1200px)', false);
  const dispatch = useDispatch();
  const router = useRouter();
  const searchParams = useSearchParams();
  const isTemplate = searchParams.get('isTemplate');
  const reference_id = searchParams.get('reference');
  const { user } = useSelector((state: any) => state?.root?.signIn?.user?.data);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const signInRole = signIn?.role === 'team_agency';
  const { clientlistDetails, loading, dropdownloader, singleagreementloader, singleAgreementdetails, setAgreementId } = useSelector(
    (state: any) => state?.root?.agreement
  );
  const [imageSetFlag, setImageSetFlag] = useState<any>(false);
  const { workspaceCreatorData } = useSelector(
    (state: any) => state?.root?.workspace
  );

  useEffect(() => {
    if (isTemplate !== "true" && isTemplate !== null) {
      router.push(routes.agreement(defaultWorkSpace?.name));
    }
  }, [isTemplate]);
  console.log(isTemplate, "singleAgreementdetails");
  const { invoiceLogoURL, getDefalutInvoiceImageLoading } = useSelector(
    (state: any) => state?.root?.setting
  );

  const clientSliceData = useSelector((state: any) => state?.root?.client)
    ?.clientProfile;
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  const { closeModal, openModal } = useModal();

  const [errorMessageImage, setErrorMessageImage] = useState("");
  const [errorMessageFile, setErrorMessageFile] = useState("");
  const imageInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const signatureInputRef = useRef<HTMLInputElement>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [uploadedSignature, setUploadedSignature] = useState<string | null>(null);
  const [showTextInput, setShowTextInput] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [textPreview, setTextPreview] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [showPicker, setShowPicker] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; url: string } | null>(null);
  const [files, setFiles] = useState<File[]>([]); // State to hold the files
  const [fileReferences, setFileReferences] = useState<{ [key: string]: string }>({});
  const [fileState, setFileState] = useState<{ name: string; url: string; actualUrl?: string; editorUrl?: string; } | null>(null);


  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>,
    setState: React.Dispatch<React.SetStateAction<string | null>> | React.Dispatch<React.SetStateAction<{ name: string; url: string } | null>>,
    fileType: "image" | "sign" | "file"
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const imageTypes = ["image/jpeg", "image/png"];
      const fileTypes = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain"];

      const maxSizeInBytes = (fileType === "image" || fileType === "sign") ? 50 * 1024 * 1024 : 200 * 1024 * 1024;
      if (fileType === "image" || fileType === "sign") {
        setErrorMessageImage("");
      } else {
        setErrorMessageFile("");
      }
      // Check file size
      if (file.size > maxSizeInBytes) {
        if (fileType === "image" || fileType === "sign") {
          setErrorMessageImage(`File size should not exceed ${fileType === "image" || fileType === "sign" ? "50MB" : "200MB"}!`);
        } else {
          setErrorMessageFile(`File size should not exceed 200MB!`);
        }
        event.target.value = "";
        return;
      }
      if ((fileType === "image" || fileType === "sign") && imageTypes.includes(file.type)) {
        const reader = new FileReader();
        reader.onload = () => {
          const base64Image = reader.result as string;
          if (fileType === "sign") {
            const base64Sign = base64Image + "#sign"; // Append identifier
            console.log(base64Sign, "signature ref");
            (setState as React.Dispatch<React.SetStateAction<string | null>>)(base64Sign);
          } else {
            (setState as React.Dispatch<React.SetStateAction<string | null>>)(base64Image);
          }

          // Ensure setState receives the correct type
        };
        // reader.onload = () => {
        //   const base64Image = reader.result as string;

        //   if (fileType === "sign") {
        //     // Add a unique identifier to distinguish sign images
        //     const modifiedImage = `<img id="signature-image" src="${base64Image}" />`;
        //     console.log(modifiedImage ,"signature 2");

        //     (setState as React.Dispatch<React.SetStateAction<string | null>>)(modifiedImage);
        //   } else {
        //     (setState as React.Dispatch<React.SetStateAction<string | null>>)(base64Image);
        //   }
        // };
        reader.readAsDataURL(file);
      } else if (fileType === "file" && fileTypes.includes(file.type)) {
        // const blobUrl = URL.createObjectURL(file);

        // (setState as React.Dispatch<React.SetStateAction<{ name: string; url: string } | null>>)({
        //   name: file.name,
        //   url: blobUrl,
        // });
        const blobUrl = URL.createObjectURL(file);
        console.log(blobUrl)
        const response = await fetch(blobUrl);
        const blob = await response.blob();
        const base64String = await blobToBase64(blob);
        // Generate a unique file reference ID
        const uniqueId = `file-${file?.name.trim().replace(/\s+/g, '-')}`;

        // Update state to store the new file reference
        setFileReferences(prev => ({
          ...prev, // Keep existing references
          [uniqueId]: base64String, // Add new reference
        }));
        setFileState({
          name: file.name,
          url: uniqueId, // Store uniqueId (for referencing in editor)
          actualUrl: blobUrl, // Store actual Blob URL (optional)
          editorUrl: base64String,
        });
        console.log("File References:", fileReferences);
        console.log("Generated Unique ID:", uniqueId);
        console.log("Actual Blob URL:", fileState?.editorUrl);

        // Update state with the reference ID instead of the Blob URL
        (setState as React.Dispatch<React.SetStateAction<{ name: string; url: string } | null>>)(
          { name: file.name, url: uniqueId } // Store uniqueId instead of Blob URL

        ), console.log(fileReferences, file.name, uniqueId, "✅ Updated File References in handleFileChange");
        ;

        // Create a new FileReader instance
        // const reader = new FileReader();

        // reader.onload = () => {
        //   const base64blob = reader.result as string; // Get Base64 encoded string
        //   // console.log(base64blob, "File Base64");

        //   (setState as React.Dispatch<React.SetStateAction<{ name: string; url: string } | null>>)(
        //     { name: file.name, url: base64blob }
        //   );
        // };

        // Read file as Base64
        // reader.readAsDataURL(file);
      } else {
        toast.error(
          fileType === "image" || fileType === "sign"
            ? "Only JPG, JPEG, and PNG files are allowed!"
            : "Only PDF, DOCX, and TXT files are allowed!"
        );
        event.target.value = ""; // Reset input
      }
    }
  };
  console.log(uploadedFile, "basefiloleee")


  // Function to handle date selection
  const handleDateChange = (date: Date | [Date | null, Date | null] | null) => {
    if (date instanceof Date) {
      setSelectedDate(date.toISOString().split("T")[0]); // Convert Date to YYYY-MM-DD
    } else if (Array.isArray(date) && date[0] instanceof Date) {
      setSelectedDate(date[0].toISOString().split("T")[0]); // Use first date in range
    } else {
      setSelectedDate(null); // Ensure null instead of undefined
    }
  };

  const handleAddText = () => {
    setShowTextInput(true);
  };

  const handleTextChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTextInput(event.target.value);
  };

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && textInput.trim()) {
      setTextPreview(textInput);
      setTextInput("");
      setShowTextInput(false);
    }
  };
  const handleDragStart = (event: React.DragEvent, type: string | "image" | "sign" | "file", file?: { name: string; url: string }) => {
    if (!event.dataTransfer) return;
    event.dataTransfer.setData("text/plain", type);
  };



  // const handleDragStart = (event: React.DragEvent<HTMLDivElement>, type: "image" | "text" | "date" | "sign" | "file") => {
  //   if (type === "image" && uploadedImage) {
  //     event.dataTransfer.setData("image", uploadedImage);
  //   } else if (type === "sign" && uploadedSignature) {
  //     event.dataTransfer.setData("image", uploadedSignature);
  //   }
  //   else if (type === "text" && textPreview) {
  //     event.dataTransfer.setData("text/plain", textPreview); // Keep text as "text/plain"
  //   } else if (type === "date" && selectedDate) {
  //     event.dataTransfer.setData("application/date", new Date(selectedDate).toDateString()); // Use a custom type
  //   }else if (type === "file" && uploadedFile) {
  //     event.dataTransfer.setData("application/octet-stream", uploadedFile.url); // Store file URL
  //     event.dataTransfer.setData("text/plain", uploadedFile.name); // Store file name
  //   }
  // };


  useEffect(() => {
    if (params?.id) {
      const obj = {
        _id: params?.id,
        isTemplate: Boolean(isTemplate) ?? false
      };
      dispatch(getSingleagreement(obj));
    }
  }, [params?.id]);

  // const clientOptions =
  //   clientlistDetails?.data && clientlistDetails?.data?.length > 0
  //     ? clientlistDetails?.data?.map((client: any) => ({
  //       name: client?.client_full_name,
  //       value: client?._id,
  //       key: client,
  //     }))
  //     : [];

  const clientOptions = [
    { label: 'Select Client', value: '', key: {} },
    ...(clientlistDetails?.data && clientlistDetails?.data?.length > 0
      ? clientlistDetails.data.map((client: any) => ({
        label: capitalizeFirstLetter(client?.client_full_name),
        value: client?._id,
        key: client,
      }))
      : []),
  ];

  // Get Today date
  const today = new Date();

  const [dueDate, setDueDate] = useState<Date | null>(null);
  const [preview, setpreview] = useState(false);
  const [sendbuttonflag, setsendbuttonflag] = useState<boolean>(false);
  const [buttonclickflag, setbuttonclickflag] = useState<any>(null);
  const [clientInputvalue, setclientInputvalue] = useState<any>(params?.id ? true : false);
  const [selectedClient, setselectedClient] = useState<any>(
    reference_id
      ? clientOptions.find((option: any) => option?.key?._id === reference_id)
      : null
  );
  const [previewImage, setpreviewImage] = useState<any>();
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const imageref = useRef<any>();
  const [previewData, setPreviewData] = useState<AgrementFormTypes | null>(null);

  const formattedAddress = `${selectedClient?.key?.address ? `${selectedClient?.key?.address},` : ''
    } ${selectedClient?.key?.city?.name ? `${selectedClient?.key?.city?.name},` : ''
    } ${selectedClient?.key?.state?.name
      ? `${selectedClient?.key?.state?.name},`
      : ''
    } ${selectedClient?.key?.country?.name
      ? `${selectedClient?.key?.country?.name},`
      : ''
    }${selectedClient?.key?.pincode ? `${selectedClient?.key?.pincode},` : ''}`
    .replace(/,\s*$/, '')
    .trim();

  const [formdata, setformData] = useState({
    title: '',
    // name: reference_id ? selectedClient?.key?.client_full_name : '',
    // email: reference_id ? selectedClient?.key?.email : '',
    // address: reference_id ? formattedAddress : '',
    // contact_number: reference_id ? selectedClient?.key?.contact_number : '',
    // recipient: reference_id ? selectedClient?.value : '',
    // due_date: '',
    body: '',
    description: '',
    agreement_logo: invoiceLogoURL?.invoice?.logo
      ? invoiceLogoURL?.invoice?.logo
      : null,
  });

  const formattedReceiverAddress = `${singleAgreementdetails?.data?.receiver_address
    ? `${singleAgreementdetails.data.receiver_address},`
    : ''
    } ${singleAgreementdetails?.data?.receiver_city?.name
      ? `${singleAgreementdetails.data.receiver_city?.name},`
      : ''
    } ${singleAgreementdetails?.data?.receiver_state?.name
      ? `${singleAgreementdetails.data.receiver_state?.name},`
      : ''
    } ${singleAgreementdetails?.data?.receiver_country?.name
      ? `${singleAgreementdetails.data.receiver_country?.name},`
      : ''
    } ${singleAgreementdetails?.data?.receiver_pincode || ''}`
    .replace(/,\s*$/, '')
    .trim();

  // useEffect set a form Data
  useEffect(() => {
    if (params?.id && singleAgreementdetails) {

      setformData({
        title: singleAgreementdetails?.data?.title || '',
        // name: singleAgreementdetails?.data?.receiver
        //   ? singleAgreementdetails?.data?.first_name +
        //   singleAgreementdetails?.data?.last_name
        //   : singleAgreementdetails?.data?.custom_receiver?.name,
        // email: singleAgreementdetails?.data?.receiver
        //   ? singleAgreementdetails?.data?.receiver_email
        //   : singleAgreementdetails?.data?.custom_receiver?.email,
        // address: singleAgreementdetails?.data?.receiver
        //   ? formattedReceiverAddress
        //   : singleAgreementdetails?.data?.custom_receiver?.address,
        // contact_number: singleAgreementdetails?.data?.receiver
        //   ? singleAgreementdetails?.data?.receiver_number
        //   : singleAgreementdetails?.data?.custom_receiver?.contact_number,
        // recipient: singleAgreementdetails?.data?.receiver
        //   ? singleAgreementdetails?.data?.receiver_id
        //   : singleAgreementdetails?.data?.custom_receiver?._id,
        // due_date: singleAgreementdetails?.data?.due_date, // Replace with the actual date in string format
        description: singleAgreementdetails?.data?.description || '',
        body: singleAgreementdetails?.data?.agreement_content || '',
        agreement_logo: singleAgreementdetails?.data?.agreement_logo ?? null,
      });

      const parsedDate = moment(
        singleAgreementdetails?.data?.due_date
      ).toDate();
      setDueDate(parsedDate);

      singleAgreementdetails?.data?.receiver_id
        ? setselectedClient(
          clientOptions.find(
            (option: any) =>
              option.value === singleAgreementdetails?.data?.receiver_id
          )
        )
        : setselectedClient(
          clientOptions.find(
            (option: any) =>
              option.value ===
              singleAgreementdetails?.data?.custom_receiver?._id
          )
        );
      if (singleAgreementdetails?.data?.agreement_logo) {
        setpreviewImage(singleAgreementdetails?.data?.agreement_logo);
      } else {
        setpreviewImage(null);
      }
    }
  }, [singleAgreementdetails, params?.id]);


  useEffect(() => {
    reference_id
      ? setselectedClient(
        clientOptions.find((option: any) => option?.key?._id === reference_id)
      )
      : setselectedClient(null);
  }, [clientlistDetails]);

  useEffect(() => {
    dispatch(getDropdownclientlist());
    dispatch(getDefalutInvoiceImage());
  }, [dispatch]);

  useEffect(() => {
    if (signInRole) {
      dispatch(workspaceCreator());
    }
  }, [dispatch, signInRole]);

  // set a default logo if default logo is in the system
  useEffect(() => {
    if (!params?.id) {
      if (!!invoiceLogoURL?.invoice?.logo) {
        setpreviewImage(invoiceLogoURL?.invoice?.logo);
      } else {
        setpreviewImage(undefined);
      }
    }
  }, [params?.id, invoiceLogoURL]);


  const replaceReferences = (content: any, assets: any) => {
    return content?.replace(/\[(Image|Sign|File) Reference: (.*?)\]/g, (match: any, type: any, fileName: any) => {
      const asset = assets?.find((item: any) => item.file_original_name === fileName);
      if (!asset) return match; // If asset not found, keep reference as-is.

      if (type === "Image") {
        return `<img src="${process.env.NEXT_PUBLIC_IMAGE_URL}/${asset?.file_name}" alt="${fileName}" style="width: 200px; height: 200px; object-fit: contain;">`;
      } else if (type === "Sign") {
        return `<img src="${process.env.NEXT_PUBLIC_IMAGE_URL}/${asset?.file_name}" alt="${fileName}" id="signature-image" style="width: 100px; height: 50px; object-fit: contain;">`;
      } else if (type === "File") {
        return `<a href="${process.env.NEXT_PUBLIC_IMAGE_URL}/${asset?.file_name}" download>${fileName}</a>`;
      }

      return match; // Fallback in case of any issues
    });
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    const file = acceptedFiles[0];
    const fileType = file?.type;

    // Check if the uploaded file is a JPG or PNG image
    if (
      fileType === 'image/jpeg' ||
      fileType === 'image/png' ||
      fileType === 'image/jpg'
    ) {
      const fileUrl = URL.createObjectURL(file);
      // setValue("board_image", file)
      imageref.current('agreement_logo', file, { shouldValidate: true });
      setpreviewImage(fileUrl);
      setImageSetFlag(true);
    } else {
      imageref.current('agreement_logo', file, { shouldValidate: true });
      setpreviewImage(fileImage);
      // Optionally, handle the case where the file is not a JPG or PNG image
      console.error('Invalid file type. Only JPG and PNG images are allowed.');
    }
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    // useFsAccessApi: false,
    onDrop: handleDrop,
    // accept: { 'image/*': [] },
    // maxSize: 6 * 1024 * 1024, // Maximum file size of 10MB
    multiple: false,
    noClick: false,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
    useDropzone(dropzoneOptions);

  function replaceImagesAndFiles(htmlString: string, agreementContentFiles: any[] = []) {
    const imageReferences: { [key: string]: string } = {}; // Store new image references
    // const fileReferences: { [key: string]: string } = {}; // Store new file references
    console.log(fileReferences, imageReferences, "follll");
    const existImage: string[] = [];
    const existFiles: string[] = [];

    // Extract existing uploaded images and files
    // agreementContentFiles.forEach((file) => {
    //   if (/\.(png|jpg|jpeg|gif)$/i.test(file.file_name)) {
    //     existingImages.push(file.file_name);
    //   } else if (/\.(pdf|docx|txt|csv)$/i.test(file.file_name)) {
    //     existingFiles.push(file.file_name);
    //   }
    // });
    // console.log(existingImages,existingFiles,"existingImages")
    // Replace existing images (from server URL) with references
    // htmlString = htmlString.replace(/<img[^>]+src=["']([^"']+)["'][^>]*>/g, (_match, src) => {
    //   const fileName = src.split("/").pop();
    //   if (fileName && existingImages.includes(fileName)) {
    //     return `[Image Reference: ${fileName}]`;
    //   }
    //   return _match; // Keep the original tag if it's not in existingImages
    // });
    htmlString = htmlString.replace(/<img[^>]+src=["'][^"']*\/uploads\/([^"']+)["'][^>]*alt=["']([^"']+)["'][^>]*>/g, (_match, fileName, alt) => {
      const filePath = `uploads/${fileName}`;
      existImage.push(filePath); // Store the existing image path
      return `[Image Reference: ${alt}]`;
    });

    // Replace base64 sign with unique references
    htmlString = htmlString.replace(/<img[^>]+src=["'](data:image[^"']+#sign)["'][^>]*>/g, (_match, src) => {
      // Handling signature images
      const uniqueId = `sign-${Math.random().toString(36).substr(2, 9)}.png`;
      imageReferences[uniqueId] = src;
      return `[Sign Reference: ${uniqueId}]`;
    });

    // Replace base64 images (excluding signatures) with unique references
    htmlString = htmlString.replace(/<img[^>]+src=["'](data:image[^"']+)["'][^>]*>/g, (_match, src) => {
      if (src.includes("#sign")) return _match; // Skip already handled signatures
      const uniqueId = `image-${Math.random().toString(36).substr(2, 9)}.png`;
      imageReferences[uniqueId] = src;
      return `[Image Reference: ${uniqueId}]`;
    });

    // Replace existing files (from server URL) with references
    htmlString = htmlString.replace(/<a[^>]+href=["']([^"']+)["'][^>]*>(.*?)<\/a>/g, (_match, href, text) => {
      const fileName = href.split("/").pop();
      if (fileName && existFiles.includes(fileName)) {
        return `[File Reference: ${fileName}]`;
      }
      return _match; // Keep the original tag if it's not in existingFiles
    });

    // Replace base64 file links with unique references
    htmlString = htmlString.replace(/<a\s+href=["'](file-[^"']+\.pdf)["'][^>]*>(.*?)<\/a>/g, (match: any, href) => {
      let uniqueId: string | undefined = Object.keys(fileReferences).find(key => fileReferences[key] === href);

      console.log(uniqueId, "unique id>>");

      // If not found, do NOT generate a new one. Just return the href.
      if (!uniqueId) {
        return `[File Reference: ${href}]`; // Keep existing reference
      }
      return `[File Reference: ${uniqueId}]`;
    });


    return { htmlString, imageReferences, fileReferences, existImage, existFiles };
  }

  const base64ToFile = (base64: string, filename: string) => {
    const arr = base64.split(",");
    const mime = arr[0].match(/:(.*?);/)?.[1];

    // Remove #sign before decoding (if present)
    const cleanBase64 = arr[1].split("#")[0];

    const bstr = atob(cleanBase64); // Now safe to decode

    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], filename, { type: mime });
  };

  const blobUrlToFile = async (blobUrl: string, filename: string): Promise<File> => {
    const response = await fetch(blobUrl); // Fetch the Blob data
    const blob = await response.blob();   // Convert response to Blob
    return new File([blob], filename, { type: blob.type }); // Create File object
  };
  console.log(singleAgreementdetails?.data, "singleAgreementdetails?.data")
  const appendToFormData = async (
    formData: FormData,
    imageReferences: { [key: string]: string },
    fileReferences: { [key: string]: string },
    existImage: any,
    agreementData: any
  ) => {
    const extractedFiles = new Set(
      [...agreementData?.agreement_content?.matchAll(/uploads\/([\w-]+\.\w+)/g)]?.map(match => `uploads/${match[1]}`)
    );
    const filesInHTML = singleAgreementdetails?.data?.agreement_content_file?.filter((file: any) => extractedFiles.has(file.file_name));


    // Append only existing images that are not new
    filesInHTML?.forEach((file: any) => {
      formData.append("agreement_content_file", file?.file_name);
    });

    existImage.forEach((filePath: any) => {
      formData.append("agreement_content_file", filePath);
    });

    // Append new base64 images as files (ignore if already uploaded)
    Object.entries(imageReferences).forEach(([fileName, base64String]) => {
      const file = base64ToFile(base64String, fileName);
      formData.append("agreement_content_file", file);
    });

    // Append new files from fileReferences (ignore if already uploaded)
    await Promise.all(
      Object.entries(fileReferences).map(async ([fileName, blobUrl]) => {
        const file = await blobUrlToFile(blobUrl, fileName);
        formData.append("agreement_content_file", file);
      })
    );
    return formData;
  };


  // onSubmit Handler
  const onSubmit: SubmitHandler<AgrementFormTypes> = async (data) => {
    console.log(data, "data");
    const agreementContentFiles = params?.id ? singleAgreementdetails?.data?.agreement_content_file : [];
    console.log(data.body, "bodyy")
    const { htmlString, imageReferences, fileReferences, existImage, existFiles } = replaceImagesAndFiles(data.body, agreementContentFiles);

    const agreementData = {
      client_id: user?._id,
      title: data?.title,
      // receiver: data?.recipient,
      // due_date: moment(data?.due_date).format('DD/MM/YYYY'),
      agreement_content: htmlString,
      decription: data?.description,
      send: sendbuttonflag,
      custom_receiver: {
        // name: data?.name,
        // email: data?.email,
        // address: data?.address,
        // contact_number: data?.contact_number,
      },
      agreement_logo: data?.agreement_logo ?? null,
      // ...(reference_id && { client_id: reference_id }),
    };
    console.log(agreementData, "agreementData");

    const formData = new FormData();

    formData.append("title", data?.title); // Add JSON data
    formData.append("agreement_content", htmlString); // Add JSON data
    formData.append("send", "false");
    formData.append("agreement_logo", data?.agreement_logo);
    formData.append("description", data?.description); // Add JSON data

    await appendToFormData(formData, imageReferences, fileReferences, existImage, agreementData);
    if (params?.id) {
      dispatch(updateagreement({ data: formData, id: params.id, isTemplate: (isTemplate === "true") })).then((result: any) => {
        if (result?.payload?.success) {
          if (isTemplate !== "true") {
            dispatch(setagreementId(params?.id));
            openModal({
              view: (
                <AgreementCreateSuccess />
              ),
              customSize: '560px',
            });
          } else {
            router.push(routes.agreement(defaultWorkSpace?.name));
          }
        }
      });
    } else {
      dispatch(createagreement(formData)).then((result: any) => {
        console.log(result, "result");

        const agreementId = result?.payload?.data?.agreement_id;
        if (agreementId) {
          console.log("Agreement ID", agreementId);
          dispatch(setagreementId(agreementId));
          openModal({
            view: (
              <AgreementCreateSuccess />
            ),
            customSize: '560px',
          });
        }
      });
    }
    // const createFormData = (agreementData: any) => {
    //   const formData = new FormData();

    //   formData.append("agreementData", JSON.stringify(agreementData)); // Add JSON data


    //   Object.entries(imageReferences).forEach(([fileName, base64Data]) => {
    //     console.log(formData.append("images[]", JSON.stringify({ fileName, base64Data })), "appenddataa")
    //     formData.append("images[]", JSON.stringify({ fileName, base64Data })); // Store JSON format
    //   });

    //   // Append base64 files separately
    //   Object.entries(fileReferences).forEach(([fileName, base64Data]) => {
    //     formData.append("files[]", JSON.stringify({ fileName, base64Data }));
    //   });

    //   console.log(formData, "formdata");
    //   // Append scalar fields
    //   // formData.append('client_id', agreementData.client_id || '');
    //   // formData.append('title', agreementData.title || '');
    //   // formData.append('receiver', agreementData.receiver || '');
    //   // // formData.append('due_date', agreementData.due_date || '');
    //   // formData.append(
    //   //   'agreement_content',
    //   //   agreementData.agreement_content || ''
    //   // );
    //   // formData.append('send', agreementData.send ? 'true' : 'false'); // Send as string
    //   // formData.append('description', agreementData.description || '');


    //   // Append nested fields: custom_receiver
    //   // if (agreementData.custom_receiver) {
    //   //   formData.append(
    //   //     'custom_receiver[name]',
    //   //     agreementData.custom_receiver.name || ''
    //   //   );
    //   //   formData.append(
    //   //     'custom_receiver[email]',
    //   //     agreementData.custom_receiver.email || ''
    //   //   );
    //   //   formData.append(
    //   //     'custom_receiver[address]',
    //   //     agreementData.custom_receiver.address || ''
    //   //   );
    //   //   formData.append(
    //   //     'custom_receiver[contact_number]',
    //   //     agreementData.custom_receiver.contact_number || ''
    //   //   );
    //   // }

    //   // Append file (agreement_logo)
    //   // if (agreementData.agreement_logo) {
    //   //   formData.append('agreement_logo', agreementData.agreement_logo);
    //   // } else {
    //   //   formData.append('agreement_logo', 'null');
    //   // }

    //   return formData;
    // };

    // const formDataPayload = createFormData(agreementData);
    // if (params?.id) {
    //   params?.id && formDataPayload?.append('id', params?.id);

    //   dispatch(updateagreement({ data: formDataPayload, id: params?.id })).then(
    //     (result: any) => {
    //       if (updateagreement.fulfilled.match(result)) {
    //         if (result && result.payload.success === true) {
    //           setbuttonclickflag(null);
    //           reference_id
    //             ? router.replace(
    //               routes.clients.details(
    //                 defaultWorkSpace?.name,
    //                 clientSliceData?._id
    //               )
    //             )
    //             : router.replace(routes.agreement(defaultWorkSpace?.name));
    //         }
    //       }
    //     }
    //   );
    // } else {
    //   // If in preview mode, dispatch the API call
    //   dispatch(createagreement(formDataPayload)).then((result: any) => {
    //     if (
    //       createagreement.fulfilled.match(result) &&
    //       result.payload.success === true
    //     ) {
    //       setbuttonclickflag(null);
    //       reference_id
    //         ? router.replace(
    //           routes.clients.details(
    //             defaultWorkSpace?.name,
    //             clientSliceData?._id
    //           )
    //         )
    //         : router.replace(routes.agreement(defaultWorkSpace?.name));
    //     }
    //   });
    // }
    setsendbuttonflag(false);
  };

  const SendHandler = () => {
    setsendbuttonflag(true);
    setbuttonclickflag('Send');
  };

  //Preview mode Handler
  const handlePreview = (
    watch: any,
    trigger: any,
    isDirty: any,
    isValid: any
  ) => {
    if (isValid) {
      // Toggle to preview mode
      setpreview(!preview);
      setformData(watch()); // Call custom function if form is completely filled
    } else {
      trigger(); // Otherwise, proceed with default form submission
    }
  };

  // initial value State
  const initialValues: AgrementFormTypes = {
    // name: formdata?.name,
    // email: formdata?.email,
    // address: formdata?.address,
    // contact_number: formdata?.contact_number,
    title: formdata?.title,
    // recipient: formdata?.recipient,
    description: formdata?.description,
    // due_date: formdata?.due_date,
    body: formdata?.body,
    agreement_logo: invoiceLogoURL?.invoice?.logo
      ? invoiceLogoURL?.invoice?.logo
      : null,
  };

  if (dropdownloader) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  // Dropdown style
  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      cursor: 'pointer',
      backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  // Inside the onChange event handler of the Select component
  const handleClientChange = (e: any, setValue: any) => {
    if (e?.__isNew__ || e?.value == '') {
      setValue('contact_number', '');
      setValue('name', e?.value, { shouldValidate: true });
      setValue('recipient', '');
      setValue('email', '');
      setValue('address', '');

      setclientInputvalue(false);
    } else {
      const formattedAddress = `${e?.key?.address ? `${e.key.address},` : ''} ${e?.key?.city?.name ? `${e.key.city.name},` : ''
        } ${e?.key?.state?.name ? `${e.key.state.name},` : ''} ${e?.key?.country?.name ? `${e.key.country.name},` : ''
        } ${e?.key?.pincode || ''}`
        .replace(/,\s*$/, '')
        .trim();

      setValue('contact_number', e?.key?.contact_number, {
        shouldValidate: true,
      });
      setValue('recipient', e?.value, { shouldValidate: true });
      setValue('name', e?.label, { shouldValidate: true });
      setValue('address', formattedAddress, { shouldValidate: true });
      setValue('email', e?.key?.email, { shouldValidate: true });

      setclientInputvalue(true);
    }
    setselectedClient(e);
  };

  return (
    <>
      {/* Agreement forms */}
      {(dropdownloader || singleagreementloader) ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" />
        </div>
      ) : (
        <Form<AgrementFormTypes>
          validationSchema={agrementFormSchema}
          onSubmit={onSubmit}
          useFormProps={{
            defaultValues: params?.id ? {
              title: singleAgreementdetails?.data?.title || '',
              // name: singleAgreementdetails?.data?.receiver
              //   ? singleAgreementdetails?.data?.first_name +
              //   singleAgreementdetails?.data?.last_name
              //   : singleAgreementdetails?.data?.custom_receiver
              //     ?.name,
              // email: singleAgreementdetails?.data?.receiver
              //   ? singleAgreementdetails?.data?.receiver_email
              //   : singleAgreementdetails?.data?.custom_receiver
              //     ?.email,
              // address: singleAgreementdetails?.data?.receiver
              //   ? formattedReceiverAddress
              //   : singleAgreementdetails?.data?.custom_receiver
              //     ?.address,
              // contact_number: singleAgreementdetails?.data?.receiver
              //   ? singleAgreementdetails?.data?.receiver_number
              //   : singleAgreementdetails?.data?.custom_receiver
              //     ?.contact_number,
              // recipient: singleAgreementdetails?.data?.receiver
              //   ? singleAgreementdetails?.data?.receiver_id
              //   : singleAgreementdetails?.data?.custom_receiver
              //     ?._id,
              // due_date: singleAgreementdetails?.data?.due_date, // Replace with the actual date in string format
              body: replaceReferences(singleAgreementdetails?.data?.agreement_content, singleAgreementdetails?.data?.agreement_content_file)
                ||
                '',
              description: singleAgreementdetails?.data?.description || '',
              agreement_logo:
                singleAgreementdetails?.data?.agreement_logo ??
                null,
            } : initialValues,
            mode: 'onChange',
          }}
        >
          {({
            register,
            control,
            formState: { errors },
            watch,
            handleSubmit,
            trigger,
            setValue,
            formState: { isDirty, isValid },
            getValues,
          }) => (
            <>
              <div>
                <CustomePageHeader
                  title={`${params?.id ? `Edit ${Boolean(isTemplate) ? "Template" : "Agreement"}` : "Create Agreement"}`}
                  route={routes.agreement(defaultWorkSpace?.name)}
                  titleClassName="montserrat_font_title"
                >
                  <div className="relative flex items-center justify-end gap-4">
                    <Button
                      disabled={loading}
                      onClick={() => router.push(routes.agreement(defaultWorkSpace?.name))}
                      type="button"
                      className="rounded-lg border border-[#E5E7EB] bg-[#FFFFFF] p-3 text-sm text-[#111928]"
                    >
                      Cancel
                    </Button>
                    <Button
                      disabled={loading}
                      type="button"
                      onClick={() => {
                        // handleSubmit(onSubmit)()
                        // handlePreview(watch, trigger, isDirty, isValid);
                        openModal({
                          view: (
                            <PreviewAgreement formValues={watch()} />
                          ),
                          customSize: '611px',
                        });
                      }}
                      className="text-[#5850EC] rounde-lg text-[14px] px-3 font-medium border-[#6875F5] bg-white"
                    >
                      <EyeIcon className="mr-2 h-5 w-5" />
                      Preview
                    </Button>
                    <Button
                      type="submit"
                      onClick={() => {
                        // setShowDropdown((prev: any) => !prev);
                      }}
                      disabled={loading}
                      // isLoading={loading}
                      className="mr-1 w-auto rounded-[8px] bg-[#7667CF] p-[12px] font-['Raleway'] text-[14px] font-[400] leading-[19.6px] text-white"
                    >
                      <span className="mr-1.5 flex items-center justify-start gap-[inherit]">
                        Save Agreement
                        {loading && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </span>
                      {/* <div>
                      <PiCaretDownBold className="h-4 w-4 text-white" />
                    </div> */}
                    </Button>
                    {/* {showDropdown && (
                      <div className="absolute right-0 top-full z-10 mt-2 flex flex-col items-start gap-[7px] rounded-[8px] !bg-white p-[10px] shadow-lg">
                        <Button
                          type="submit"
                          disabled={loading}
                          onClick={SendHandler}
                          className=" !bg-white   text-[#111928] !border-none disabled:!border-none"
                        >
                          Send Agreement
                          {loading && buttonclickflag === 'Send' && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                        <Button
                          type="submit"
                          disabled={loading}
                          onClick={() => {
                            setbuttonclickflag('Save');
                          }}
                          className=" !bg-white   text-[#111928] !border-none disabled:!border-none"
                        >
                          Save Draft
                          {loading && buttonclickflag === 'Save' && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                        </Button>
                      </div>
                    )} */}
                  </div>
                </CustomePageHeader>
              </div>
              {/* <WidgetCard rounded="lg" title="" className='p-10 [&_label]:font-medium'> */}
              <div className='grid grid-cols-7 gap-6'>
                <div className="flex col-span-5 gap-6">
                  <div className="w-full rounded-[20px] bg-[#E5E7EB] p-4">
                    <div className="flex h-full flex-col gap-4 rounded-[20px] bg-white p-5">
                      <div className="flex justify-between">
                        {/* Image Upload section  */}
                        <div className="mb-5 grid grid-cols-1 items-center">
                          {previewImage ? (
                            <div className="flex items-center justify-start ">
                              <Image
                                alt="img"
                                className="mr-3"
                                src={
                                  !imageSetFlag
                                    ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${previewImage}`
                                    : previewImage
                                }
                                width={100}
                                height={100}
                              />
                              <TrashIcon
                                className="ms-4 h-5 w-5 cursor-pointer"
                                onClick={() => {
                                  setpreviewImage(null);
                                  setValue('agreement_logo', null, {
                                    shouldValidate: true,
                                  });
                                }}
                              />
                            </div>
                          ) : (
                            <div {...getRootProps()}>
                              <input {...getInputProps()} />
                              <div
                                className="flex cursor-pointer flex-col gap-[10px] rounded-[10px] border border-dashed border-[#B7C2D3] bg-[#F8FAFF] p-4"
                                onClick={() => {
                                  // open()
                                  imageref.current = setValue;
                                }}
                              >
                                <div className='flex justify-center w-full'>
                                  <Image
                                    alt="img"
                                    src={fileUploadIcon}
                                    width={20}
                                    height={20}
                                    className='w-5 h-5'
                                  />
                                </div>
                                <div className="font-semibold text-[#111928] text-center">
                                  Add Business Logo (Optional)
                                </div>
                                <div className="font-semibold text-[#4B5563] text-center">
                                  Resolution upto 1080x1080 px.
                                </div>
                                <div className="font-semibold text-[#4B5563] text-center">
                                  PNG, JPEG or JPG file
                                </div>
                              </div>
                            </div>
                          )}
                          <div className="mt-0.5 text-xs text-red">
                            {errors && errors?.agreement_logo
                              ? (errors?.agreement_logo?.message as string)
                              : ''}
                          </div>
                        </div>
                        <div >
                          <div className="flex gap-3 items-center">
                            <span className="text-sm font-medium text-[#141414]">
                              Created with
                            </span>
                            <Image
                              src={syncUppLogo}
                              alt="Syncupp"
                              width={100}
                              height={100}
                              className="h-7 w-[60px]"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="placeholder_color space-y-4">
                        <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          // size={isMedium ? 'lg' : 'xl'}
                          label=" Add Title *"
                          placeholder="Agreement Title"
                          // rounded="pill"
                          color="info"
                          className="w-full  [&>label>span]:font-medium "
                          {...register('title')}
                          error={errors.title?.message}
                          labelClassName='text-[#141414]'
                          inputClassName="text-black bg-[#F3F4F6]"
                        />
                        {/* <div className="w-full">
                          <label className="text-[14px] font-medium text-[#141414] ">
                            Name *
                          </label>
                          <Controller
                            control={control}
                            name="name"
                            render={({ field: { onChange, value } }) => (
                              <ReactSelect
                                placeholder="Select a client"
                                className="poppins_font_number mt-1.5 w-full font-medium !text-black select-bg"
                                value={selectedClient}
                                isDisabled={!!reference_id}
                                options={clientOptions}
                                // isClearable={false}
                                styles={customStyles}
                                onChange={(e) => {
                                  handleClientChange(e, setValue);
                                }}
                              />
                            )}
                          />
                          {errors?.name?.message && (
                            <span className="mt-0.5 text-xs text-red">
                              {errors?.name?.message}
                            </span>
                          )}
                        </div> */}

                        {/* <Input
                          onKeyDown={handleKeyDown}
                          type="email"
                          label="Email *"
                          disabled={clientInputvalue || !!reference_id}
                          placeholder="Enter email address"
                          // value={getValues("email")}
                          // rounded="pill"
                          color="info"
                          className="w-full  [&>label>span]:font-medium "
                          {...register('email')}
                          error={errors.email?.message}
                          inputClassName="text-black bg-[#F3F4F6]"
                          labelClassName='text-[#141414]'
                        /> */}

                        {/* <Input
                          onKeyDown={handleKeyDown}
                          type="text"
                          label="Address *"
                          placeholder="Enter your address"
                          disabled={clientInputvalue || !!reference_id}
                          // value={formdata?.email}
                          // rounded="pill"
                          color="info"
                          className="w-full  [&>label>span]:font-medium"
                          {...register('address')}
                          error={errors.address?.message}
                          inputClassName="text-black bg-[#F3F4F6]"
                          labelClassName='text-[#141414]'
                        /> */}

                        {/* <Controller
                  name="contact_number"
                  control={control}
                  render={({ field }) => (
                    <PhoneNumber
                      {...field}
                      disabled={clientInputvalue || !!reference_id}
                      label="Phone Number *"
                      country="us"
                      // size="DEFAULT"
                      className="[&>label>span]:font-medium "
                      value={field.value}
                      // labelClassName='text-sm font-semibold text-[#9BA1B9]'
                      placeholder="Enter contact number"
                      onChange={(value) => field.onChange(value)}
                      error={errors.contact_number?.message}
                      inputClassName="text-black !bg-[#F3F4F6]"
                      labelClassName='font-medium text-[#141414]'
                    />
                  )}
                /> */}

                        {/* <Controller
                          control={control}
                          name="recipient"
                          render={({ field: { onChange, value } }) => (
                          <Select
                            options={clientOptions}
                            disabled={reference_id ? true : false}
                            onChange={(selectedOption: any) => {
                              setselectedClient(selectedOption);
                              onChange(selectedOption?.name);
                            }}
                            value={(value)}
                            label="Client*"
                            color="info"
                            // Remove getOptionLabel and getOptionValue props
                            dropdownClassName="p-1 border w-12 border-gray-100 shadow-lg capitalize"
                            className="font-medium"
                            error={errors?.recipient?.message}
                          />
                          )}
                          /> */}

                        {/* <div className="flex flex-col">
                          <label
                            htmlFor="due_date"
                            className="mb-1.5 font-medium text-[#141414] dark:text-gray-600"
                          >
                            Due Date *
                          </label>
                          <Controller
                            name="due_date"
                            control={control}
                            render={({ field: { onChange, value } }) => (
                              <DatePicker
                                selected={dueDate}
                                onChange={(date: Date) => {
                                  setDueDate(date);
                                  onChange(date.toISOString()); // convert date to string
                                }}
                                minDate={today}
                                placeholderText="Select Date"
                                className='bg-[#F3F4F6]'
                                inputProps={{
                                  inputClassName: 'text-black ',
                                  labelClassName: 'text-[#141414]'
                                }}
                              />
                            )}
                          />
                          {errors.due_date && (
                            <span className="mt-0.5 text-xs text-red">
                              {errors.due_date.message}
                            </span>
                          )}
                        </div> */}
                        <div>
                          <label className='text-[#141414] font-medium'>Description *</label>
                          <Textarea
                            placeholder="Add Description"
                            rows={4}
                            color="info"
                            className="w-full text-[#141414]  rounded-lg lg:w-[100%] [&>label>span]:font-medium poppins_font_number"
                            textareaClassName="bg-[#F9FAFB]"
                            {...register('description')}
                            onKeyDown={handleKeyDown}

                          />
                          {errors?.description && (
                            <span className="mt-0.5 text-xs text-red">
                              {errors?.description?.message}
                            </span>
                          )}
                        </div>

                        <div className="flex flex-col">
                          <label
                            htmlFor="due_date"
                            className="mb-1.5 font-medium text-[#141414] dark:text-gray-600"
                          >
                            Body *
                          </label>
                          <Controller
                            control={control}
                            name="body"
                            render={({ field: { onChange, value } }) => (
                              <AdvanceQuillEditor
                                value={value}
                                onChange={onChange}
                                uploadedImage={uploadedImage}
                                uploadedSign={uploadedSignature}
                                setUploadedImage={setUploadedImage}
                                setUploadedSign={setUploadedSignature}
                                uploadedText={textPreview}
                                fileState={fileState}
                                setUploadedText={setTextPreview}
                                uploadedDate={selectedDate}
                                setUploadedDate={setSelectedDate}
                                uploadedFile={uploadedFile}
                                setUploadedFile={setUploadedFile}
                                className="quill-editor-font col-span-full text-black [&_.ql-editor]:min-h-[100px] rounded-lg bg-[#F3F4F6]"
                                labelClassName="font-medium text-[#9BA1B9] dark:text-gray-600 mb-1 text-[#141414]"
                              />
                            )}
                          />
                          {errors.body && (
                            <span className="mt-0.5 text-xs text-red">
                              {errors.body.message}
                            </span>
                          )}
                        </div>

                        {/* <div className="poppins_font_number mb-1.5 mt-5 flex justify-between font-medium text-black dark:text-gray-600">
                          <ul>
                            <li className="capitalize">
                              {workspaceCreatorData &&
                                Object.keys(workspaceCreatorData).length > 0
                                ? workspaceCreatorData?.data?.first_name + 
                                ' ' +
                                workspaceCreatorData?.data?.last_name
                                : user?.first_name + ' ' + user?.last_name}
                            </li>
                            <li>
                              {workspaceCreatorData &&
                                Object.keys(workspaceCreatorData).length > 0
                                ? workspaceCreatorData?.data?.email
                                : user?.email}
                            </li>
                            <li>
                              {workspaceCreatorData &&
                                Object.keys(workspaceCreatorData).length > 0
                                ? workspaceCreatorData?.data?.contact_number
                                : user?.contact_number}
                            </li>
                          </ul>
                          <ul>
                            <li className="capitalize">
                              {watch('recipient')
                                ? selectedClient?.key?.client_full_name
                                : watch('name') || '( Receiver Name )'}
                            </li>
                            <li>
                              {watch('recipient')
                                ? selectedClient?.key?.email
                                : watch('email') || '( Receiver Email )'}
                            </li>
                            <li>
                              {watch('recipient')
                                ? selectedClient?.key?.contact_number
                                : watch('contact_number') || '( Receiver Phone )'}
                            </li>
                          </ul>
                        </div> */}

                        {/* <div className="mt-90 flex justify-end space-x-4"> */}
                        {/* <Button
                          type="button"
                          onClick={() => {
                          // handleSubmit(onSubmit)()
                          handlePreview(watch, trigger, isDirty, isValid);
                          }}
                          variant="outline"
                          className="bg-none text-xs sm:text-sm"
                          >
                          <EyeIcon className="mr-2 h-5 w-5" />
                          Preview
                            </Button> */}
                        {/* <Button
                          type="submit"
                          disabled={loading}
                          onClick={SendHandler}
                          className="h-12 w-48 rounded-3xl bg-[#8C80D2] text-sm text-white"
                          >
                          Send Agreement
                          {loading && buttonclickflag === 'Send' && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                          </Button>
                          <Button
                          disabled={loading}
                          onClick={() => {
                            setbuttonclickflag('Save');
                          }}
                          type="submit"
                          className="h-12 w-44 rounded-3xl bg-[#E3E1F4] text-sm text-[#8C80D2]"
                          >
                          Save Draft
                          {loading && buttonclickflag === 'Save' && (
                            <Spinner
                              size="sm"
                              tag="div"
                              className="ms-3"
                              color="white"
                            />
                          )}
                          </Button> */}

                        {/* Add your disabled button here if needed */}
                        {/* </div> */}
                      </div>
                    </div>
                  </div>
                </div>
                <div className='col-span-2'>
                  <div className="w-full h-full rounded-[20px] bg-[#EDEBFE] p-4">
                    <div className='grid grid-row gap-5'>
                      <div className='grid grid-row gap-3 px-4 pt-4 pb-2'>
                        <p className='text-[#111928] text-[18px] font-bold'>Customize your document</p>
                        <p className='text-[#4B5563] text-[12px] font-medium'>Drag & drop fields where you want them to be placed in the document</p>
                      </div>
                      <div className='px-2.5 pt-4 pb-2 grid grid-row gap-3'>
                        <p className='text-[#4B5563] text-[14px] font-normal'>
                          ADD FIELDS
                        </p>
                        <div className='grid grid-row gap-3'>
                          <div className="w-full f-full rounded-lg bg-white p-3 flex flex-col justify-around">
                            <div className='flex justify-between gap-1'>
                              <div className='flex'>
                                <div className='flex items-center'>
                                  <div className='bg-[#E8EDF2] text-[#0D141C] p-3 rounded-lg'>
                                    <PiImage className='h-6 w-6' />
                                  </div>
                                </div>
                                <div className='pe-1 ps-2'>
                                  <p className='text-[#0D141C] text-[16px] font-medium'>Image</p>
                                  <p className='text-[#4F7396] text-[12px] font-normal'>Add a field for your recipient to upload an image</p>
                                </div>
                              </div>
                              <div>
                                <Button
                                  type='button'
                                  onClick={() => {
                                    imageInputRef.current?.click(); // Open file selector
                                  }}
                                  className='text-[#5850EC] rounde-lg text-[14px] px-3 font-medium border-[#6875F5] bg-white'
                                >
                                  Add
                                </Button>
                              </div>
                            </div>
                            <input
                              type="file"
                              ref={imageInputRef}
                              accept="image/jpeg, image/png"
                              className="hidden"
                              onChange={(e) => handleFileChange(e, setUploadedImage, "image")}
                            />
                            {errorMessageImage && <p className="text-red-500 text-sm mt-2">{errorMessageImage}</p>}
                            {uploadedImage && (
                              <div className="mt-4">
                                <p>Preview:</p>

                                <img src={uploadedImage} onDragStart={(e) => { handleDragStart(e, "image") }} alt="Uploaded" className="w-30 h-30 rounded-lg" />
                              </div>
                            )}
                          </div>
                          <div className="w-full f-full rounded-lg bg-white p-3 flex flex-col justify-around">
                            <div className='flex justify-between gap-1'>
                              <div className='flex'>
                                <div className='flex items-center'>
                                  <div className='bg-[#E8EDF2] text-[#0D141C] p-3 rounded-lg'>
                                    <RxText className='h-6 w-6' />
                                  </div>
                                </div>
                                <div className='pe-1 ps-2'>
                                  <p className='text-[#0D141C] text-[16px] font-medium'>Text</p>
                                  <p className='text-[#4F7396] text-[12px] font-normal'>Add a field for your recipient to input text</p>
                                </div>
                              </div>
                              <div>
                                <Button
                                  type='button'
                                  onClick={handleAddText}
                                  className='text-[#5850EC] rounde-lg text-[14px] px-3 font-medium border-[#6875F5] bg-white'
                                >
                                  Add
                                </Button>
                              </div>
                            </div>
                            {showTextInput && (
                              <input
                                type="text"
                                value={textInput}
                                onChange={handleTextChange}
                                onKeyDown={handleKeyPress}
                                className="mt-4 p-2 border border-[#6875F5] text-black rounded-lg"
                                placeholder="Type your text here"
                              />
                            )}
                            {/* Text Preview */}
                            {textPreview && (
                              <div className="mt-4 "
                                draggable
                                onDragStart={(event) => handleDragStart(event, "text")}
                              >
                                {/* <p className="font-medium text-[#0D141C]">Preview:</p> */}
                                <p className="text-[#4F7396] border-gray border-[1px] px-2 py-1 rounded-lg">{textPreview}</p>
                              </div>
                            )}
                          </div>
                          <div className="w-full f-full rounded-lg bg-white p-3 flex flex-col justify-around">
                            <div className='flex justify-between gap-1'>
                              <div className='flex'>
                                <div className='flex items-center'>
                                  <div className='bg-[#E8EDF2] text-[#0D141C] p-3 rounded-lg'>
                                    <PiSignature className='h-6 w-6' />
                                  </div>
                                </div>
                                <div className='pe-1 ps-2'>
                                  <p className='text-[#0D141C] text-[16px] font-medium'>Signature</p>
                                  <p className='text-[#4F7396] text-[12px] font-normal'>Add a field for your recipient to add their signature</p>
                                </div>
                              </div>
                              <div>
                                <Button
                                  type='button'
                                  onClick={() => {
                                    signatureInputRef.current?.click(); // Open file selector
                                  }}
                                  className='text-[#5850EC] rounde-lg text-[14px] px-3 font-medium border-[#6875F5] bg-white'
                                >
                                  Add
                                </Button>
                              </div>
                            </div>
                            <input
                              type="file"
                              ref={signatureInputRef}
                              accept="image/jpeg, image/png"
                              className="hidden"
                              onChange={(e) => handleFileChange(e, setUploadedSignature, "sign")}
                            />
                            {errorMessageImage && <p className="text-red-500 text-sm mt-2">{errorMessageImage}</p>}
                            {uploadedSignature && (
                              <div className="mt-4">
                                <p>Preview:</p>
                                <img src={uploadedSignature} onDragStart={(e) => handleDragStart(e, "sign")} alt="Uploaded" className="w-28 h-14 bg-contain rounded-lg" />
                              </div>
                            )}
                          </div>
                          <div className="w-full f-full rounded-lg bg-white p-3 flex-col flex justify-around">
                            <div className="flex justify-between gap-1">
                              <div className="flex">
                                <div className="flex items-center">
                                  <div className="bg-[#E8EDF2] text-[#0D141C] p-3 rounded-lg">
                                    <PiCalendar className="h-6 w-6" />
                                  </div>
                                </div>
                                <div className="pe-1 ps-2">
                                  <p className="text-[#0D141C] text-[16px] font-medium">Date</p>
                                  <p className="text-[#4F7396] text-[12px] font-normal">
                                    Add a field for your recipient to select a date
                                  </p>
                                </div>
                              </div>
                              <div>
                                <Button
                                  type="button"
                                  onClick={() => setShowPicker(!showPicker)}
                                  className="text-[#5850EC] rounded-lg text-[14px] px-3 font-medium border-[#6875F5] bg-white"
                                >
                                  Add
                                </Button>
                              </div>
                            </div>
                            {showPicker && (
                              <DatePicker
                                value={selectedDate}
                                onChange={(date) => {
                                  setSelectedDate(date); // 'date' is already in 'YYYY-MM-DD' format
                                  setShowPicker(false);
                                }}
                                className="mt-2"
                              />
                            )}
                            {/* Preview Selected Date */}
                            {selectedDate && (
                              <div
                                className="mt-4"
                                draggable
                                onDragStart={(event) => handleDragStart(event, "date")}
                              >
                                <p className="text-[#4F7396] text-center border-gray border-[1px] px-2 py-1 rounded-lg">
                                  {moment(selectedDate).format("DD MMM YYYY")}
                                </p>
                              </div>
                            )}

                          </div>
                          <div className="w-full f-full rounded-lg bg-white p-3 flex flex-col justify-around">
                            <div className='flex justify-between gap-1'>
                              <div className='flex'>
                                <div className='flex items-center'>
                                  <div className='bg-[#E8EDF2] text-[#0D141C] p-3 rounded-lg'>
                                    <GrAttachment className='h-6 w-6' />
                                  </div>
                                </div>
                                <div className='pe-1 ps-2'>
                                  <p className='text-[#0D141C] text-[16px] font-medium'>File</p>
                                  <p className='text-[#4F7396] text-[12px] font-normal'>Add a field for your recipient to select a file</p>
                                </div>
                              </div>
                              <div>
                                <Button
                                  type='button'
                                  onClick={() => {
                                    fileInputRef.current?.click();
                                  }}
                                  className='text-[#5850EC] rounded-lg text-[14px] px-3 font-medium border-[#6875F5] bg-white'
                                >
                                  Add
                                </Button>
                              </div>

                            </div>
                            <input
                              type="file"
                              ref={fileInputRef}
                              accept=".pdf, .docx, .txt"
                              className="hidden"
                              onChange={(e) => handleFileChange(e, setUploadedFile, "file")}
                            />
                            {errorMessageFile && <p className="text-red-500 text-sm mt-2">{errorMessageFile}</p>}
                            {uploadedFile && (
                              <div className="mt-4 p-2 border border-gray-300 rounded-lg bg-gray-100"
                                draggable
                                onDragStart={(e) => handleDragStart(e, "file")}
                              >
                                <p className="text-sm font-medium">Uploaded File: {uploadedFile.name}</p>
                                {uploadedFile.url && (
                                  <>
                                    {uploadedFile.name.endsWith(".txt") ? (
                                      <p className="text-xs text-gray-600">{uploadedFile.url.substring(0, 100)}...</p> // Show first 100 characters
                                    ) : (
                                      <a
                                        href={`${fileState?.actualUrl}`}
                                        target='_blank'
                                        className="text-blue-500 text-sm underline"
                                      >
                                        Open File
                                      </a>
                                    )}
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* </WidgetCard> */}
            </>
          )
          }
        </Form >
      )}
    </>
  );
}

// export default CreateAgreementForm;

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'agreements',
  null,
  'create'
)(CreateAgreementForm);
