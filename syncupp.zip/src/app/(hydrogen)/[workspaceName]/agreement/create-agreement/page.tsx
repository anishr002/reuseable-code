
import { metaObject } from '@/config/site.config';
import CreateAgreementForm from './main-page';
import { NewAgreement } from '@/app/shared/(admin)/agreement/NewAgreement';


export const metadata = {
  ...metaObject('Create Agreement'),
};

export default function Page() {
  return (
    <>
      {/* <CreateAgreementForm /> */}
      <NewAgreement/>
    </>
  );
}
