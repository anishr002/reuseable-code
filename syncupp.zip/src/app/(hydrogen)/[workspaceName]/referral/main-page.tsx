'use client';
import cn from '@/utils/class-names';
import PageHeader from '@/app/shared/page-header';
import MetricCard from '@/components/cards/metric-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Title, Text, ActionIcon } from '@/components/ui/text';
import { register } from 'react-scroll/modules/mixins/scroller';
import { useScrollableSlider } from '@/hooks/use-scrollable-slider';
import { Form } from '@/components/ui/form';
import { handleKeyDown } from '@/utils/common-functions';
import { referralSchema } from '@/utils/validators/refferal.schema';
import { useDispatch, useSelector } from 'react-redux';
import Image from 'next/image';
import Referrals from '@public/assets/svgs/Referral.svg';
import ReferCoin from '@public/assets/svgs/ReferCoin.svg';
import shareReferal from '@public/assets/svgs/ShareReferral.svg';
import joinReferal from '@public/assets/svgs/JoinReferral.svg';
import rewardReferal from '@public/assets/svgs/RewardReferral.svg';
import {
  getAllstatics,
  sendinvition,
} from '@/redux/slices/user/referral/referralSlice';
import {
  EmailShareButton,
  FacebookShareButton,
  LinkedinShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  RedditShareButton,
  TelegramShareButton,
  EmailIcon,
  FacebookIcon,
  LinkedinIcon,
  TwitterIcon,
  WhatsappIcon,
  TelegramIcon,
  RedditIcon,
} from 'react-share';

import Spinner from '@/components/ui/spinner';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { PiTrashFill, PiTrashSimpleFill, PiXBold } from 'react-icons/pi';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { FiCopy } from 'react-icons/fi';
import { GrShareOption } from 'react-icons/gr';
import { LuSend } from 'react-icons/lu';
import { RedeemConfirmation } from '@/app/shared/(user)/Referral/RedeemConfirmation';

const pageHeader = {
  title: 'Referral',
};

function ReferalPage({ className }: { className?: string }) {
  const dispatch = useDispatch();
  const { loading, refferalstatics } = useSelector(
    (state: any) => state?.root?.referral
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { closeModal, openModal } = useModal();
  let urlToShareIS = `${process.env.NEXT_PUBLIC_FRONT_LINK}/signup?referral=${signIn.userProfile.referral_code || ''
    }&workspace=${defaultWorkSpace?._id || ''}`;
  const social_share_message: string = 'Here is your referral link';

  const [initialValues, setInitialValues] = useState({ email: '' });
  //submit event
  const onSubmit = async (data: any, e: any) => {
    const res = await dispatch(sendinvition(data));

    if (res?.payload?.success == true) {
      e.target.reset();
      setInitialValues({ email: '' });
    }
    return res;
  };
  //copy link
  const handleCopyToClipboard = async () => {
    try {
      await window?.navigator?.clipboard?.writeText(urlToShareIS);
      toast.success('Referral link copied to clipboard');
    } catch (error) {
      console.error('Error copying URL:', error);
    }
  };
  const onhandeclickshere = () => {
    //social media icon model
    openModal({
      view: (
        <>
          <div className="m-auto p-4 md:px-7 md:pb-10 md:pt-6">
            <div className="mb-7 flex items-center justify-between">
              <Title as="h4" className="text-2xl font-bold text-[#9BA1B9]">
                Share your referral link
              </Title>
              <ActionIcon
                size="sm"
                variant="text"
                onClick={() => closeModal()}
                className="p-0 text-gray-500 hover:!text-gray-900"
              >
                <PiXBold className="h-[18px] w-[18px]" />
              </ActionIcon>
            </div>
            <div className={cn('grid grid-cols-2 gap-4 pt-5 ')}>
              <div className="pt-3">
                <EmailShareButton
                  url={`${urlToShareIS}`}
                  subject={`Sign up to Syncupp usign referral link`}
                  body={`Sign up to Syncupp usign referral link`}
                >
                  <EmailIcon size={62} round={true} />
                </EmailShareButton>
                &nbsp;&nbsp;
                <FacebookShareButton
                  url={`${urlToShareIS}`}
                //quote={social_share_message}
                >
                  <FacebookIcon size={62} round={true} />
                </FacebookShareButton>
                &nbsp;&nbsp;
                <TwitterShareButton
                  url={`${urlToShareIS}`}
                  title={social_share_message}
                >
                  <TwitterIcon size={62} round={true} />
                </TwitterShareButton>
                &nbsp;&nbsp;
                <LinkedinShareButton
                  url={`${urlToShareIS}`}
                  title={social_share_message}
                  summary={social_share_message}
                >
                  <LinkedinIcon size={62} round={true} />
                </LinkedinShareButton>
                &nbsp;&nbsp;
                <WhatsappShareButton
                  url={`${urlToShareIS}`}
                  title={social_share_message}
                >
                  <WhatsappIcon size={62} round={true} />
                </WhatsappShareButton>
              </div>
              <div className="pt-3">
                <TelegramShareButton
                  url={`${urlToShareIS}`}
                  title={social_share_message}
                >
                  <TelegramIcon size={62} round={true} />
                </TelegramShareButton>
                &nbsp;&nbsp;
                <RedditShareButton
                  url={`${urlToShareIS}`}
                  title={social_share_message}
                >
                  <RedditIcon size={62} round={true} />
                </RedditShareButton>
                &nbsp;&nbsp;
              </div>
            </div>
          </div>
        </>
      ),
    });
  };
  //api call get all static
  useEffect(() => {
    dispatch(getAllstatics());
    // console.log(refferalstatics, 're');
  }, []);

  return (
    <div className='flex flex-col gap-3'>
      {/* <CustomePageHeader title={pageHeader.title} titleClassName="montserrat_font_title"></CustomePageHeader> */}
      <div className='grid grid-col p-4 gap-3'>
        <p className='lg:text-[40px] md:text-[35px] leading-9 text-[30px] font-bold text-black text-center py-5'>
          Earn ₹4500 today with Syncupp  referrals
        </p>
        <div className='w-full flex justify-center'>
          <div className='flex flex-col md:flex-row items-center w-[80%] md:w-[65%] md:items-center md:justify-between '>
            <div className='my-5 w-[78%]'>
              <div className='bg-stroke bg-[#E8E8E8] relative h-2 w-full rounded-2xl'>
                <div className='bg-[#6875F5] flex justify-end absolute top-0 left-0 h-6 w-1/3 rounded-2xl mt-[-8px]'>
                  <div className='bg-white h-4 w-4 m-1 rounded-full'></div>
                </div>
              </div>
            </div>
            <p className='text-[#4B5563] text-[20px]'>3 referrals</p>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-8 p-3">
        <div className="col-span-5 w-full flex-col h-full">
          <div className="block  w-full md:flex h-full">
            <MetricCard
              className={cn(
                'w-full max-w-full h-full justify-between rounded-2xl border-none ',
                className
              )}
              title={''}
              metric={undefined}
            >
              <div className='flex flex-col gap-5 my-3'>
                <Image
                  className=''
                  height={260}
                  width={330}
                  src={Referrals}
                  alt={'Referral'}>
                </Image>
                <div className='flex flex-col gap-6'>
                  <p className="text-[14px] font-medium text-[#141414]">
                    Share your unique referral link
                  </p>
                  <div className="w-full flex-col">
                    <div className="block w-full md:flex md:items-center ">
                      <label className=" block w-full">
                        <Input
                          type="text"
                          prefix="https://"
                          onKeyDown={handleKeyDown}
                          value={urlToShareIS?.replace("https://","")?.replace("http://","")}
                          disabled={true}
                          inputClassName='poppins_font_number font-normal'
                          prefixClassName='text-[#737373] font-medium '
                          // color="text" //removed becuse of the build
                          className="mb-4 md:mb-0 md:me-4 [&>label>span]:!border-[#d6d2f7] [&>label>span]:!border-[2px] [&>label>span]:!bg-white [&>label>span]:font-[400px] [&_input]:bg-white [&_input]:text-[#141414] [&_input]:!text-[14px]"
                        // {...register('title')}
                        // error={errors?.title?.message}
                        />
                      </label>

                    </div>
                  </div>

                  <div className='flex gap-2'>
                    <Button
                      rounded="pill"
                      className="mb-4 w-full font-medium bg-[#7667CF] border-[#B4C6FC] border-[1px] px-0 @xl:w-auto lg:w-[20%] text-white  md:mb-0 md:me-4 flex gap-2 rounded-lg"
                      onClick={handleCopyToClipboard}
                    >
                      <FiCopy /> Copy Link
                    </Button>
                    <Button
                      rounded="pill"
                      className="w-full bg-[#F6F5FF] border-[#B4C6FC] border-[1px] flex gap-2 rounded-lg px-0 text-[#7667CF] @xl:w-auto lg:w-[20%]"
                      onClick={onhandeclickshere}
                    >
                      <GrShareOption /> Share
                    </Button>
                  </div>
                </div>

                <Form<referralSchema>
                  validationSchema={referralSchema}
                  onSubmit={onSubmit}
                  useFormProps={{
                    mode: 'all',
                    defaultValues: initialValues,
                  }}
                  resetValues={initialValues}
                  className=""
                >
                  {({
                    register,

                    control,
                    formState: { errors },
                    setValue,
                    setError,
                    getValues,
                    handleSubmit,
                  }) => {
                    return (
                      <div className="w-full flex flex-col gap-5">
                        <p className="text-[14px] font-medium text-[#141414]">
                          Invite through email
                        </p>
                        <>
                          <div className="w-full flex-col">
                            <div className="block w-full md:flex md:items-baseline md:mb- mb-3 ">
                              <label className="block w-full md:w-[85%]">
                                <Input
                                  type="text"
                                  onKeyDown={handleKeyDown}
                                  placeholder="Enter email address here"
                                  inputClassName="text-[#141414] poppins_font_number font-normal"
                                  labelClassName="border-none"
                                  // color="text" //removed becuse of the build
                                  className="bottom-0 mb-4 relative text-[#8C80D2] md:mb-0 md:me-4 [&>label>span]:!border-[#D4D4D4] [&>label>span]:!border-[2px] [&>label>span]:bg-white [&>label>span]:text-[14px] [&>label>span]:font-[400px] [&_input::placeholder]:text-[#141414] [&_input]:bg-white"
                                  {...register('email')}
                                  error={errors?.email?.message}
                                />

                              </label>


                              <Button
                                className="mb-4 w-full font-medium bg-[#7667CF] border-[#B4C6FC] border-[1px] px-1 @xl:w-auto lg:w-[22%] text-white  md:mb-0 md:me-4 flex gap-2 rounded-lg"
                                type="submit"
                                rounded="pill"
                              >
                                <LuSend />  Send Invite
                                {loading && (
                                  <Spinner
                                    size="sm"
                                    tag="div"
                                    className="ms-3 text-white"
                                  />
                                )}
                              </Button>
                            </div>

                          </div>
                        </>
                      </div>
                    );
                  }}
                </Form>

              </div>
            </MetricCard>
          </div>
        </div>
        {/*right side sections*/}
        <div className="w-full flex flex-col col-span-5 md:col-span-3 gap-5 ">
          <div className="block  w-full md:flex ">
            <MetricCard
              className="w-full rounded-2xl border-none bg-[#362F78]"
              title={''}
              metric={undefined}
            >
              <div className="flex flex-col gap-5">
                <div className="">
                  <span className=" text-[20px] font-medium text-[#FFFFFF]">
                    Your referral stats
                  </span>
                </div>
                <div className="flex flex-col gap-2">
                  <span className="w-[80%] text-[12px] font-600 text-[#D1D5DB] poppins_font_number">
                    Successful signups
                  </span>
                  <span className="w-[20%] text-[20px] font-600 text-[#FFFFFF] poppins_font_number">
                    {refferalstatics?.successful_signups}
                  </span>
                </div>
                <div className="flex flex-row gap-3 items-center">
                  <Image
                    className='h-5 w-5'
                    src={ReferCoin}
                    alt={'Refer coin'}>
                  </Image>
                  <div className="text-[32px] h-7 flex items-center font-600 bg-gradient-to-r text-transparent bg-clip-text from-[#CEB6FF] from-50% to-[#C98FFF] to-50% poppins_font_number">
                    {refferalstatics?.erned_points}
                  </div>
                  <span className="text-[12px] font-[600px] text-[#D1D5DB] poppins_font_number">
                    Total earnings
                  </span>
                </div>
                {refferalstatics?.erned_points > 3000 ? (<div>
                  <Button
                    type='submit'
                    className='w-full rounded-full bg-[#51468f] border-gradient-to-r  from-[#E5E7EB]  to-[#4F479C]'
                    onClick={() => {
                      openModal({
                        view: (
                          <RedeemConfirmation
                            // row={row}
                          // editMode={false}
                          onClose={closeModal}
                          />
                        ),
                        customSize: '460px',
                      });
                    }}
                  >
                    Redeem
                  </Button>
                </div>) : (
                  <div className='w-full flex flex-col gap-3'>
                    <p className='text-white font-medium text-[14px]'>
                      {`You're just {3000 - refferalstatics?.erned_points} points away from redeeming your rewards!`}
                    </p>
                    <div className='my-2 bg-stroke bg-[#DEF7EC] relative h-2 w-full rounded-2xl'>
                      <div className='bg-[#0E9F6E] flex justify-end absolute top-0 left-0 h-2 w-1/3 rounded-2xl'>
                      </div>
                    </div>
                  </div>
                )
                }

                {/* <li className="my-2 flex">
                    <span className="w-[80%] text-[14px]">
                      Available free subscription
                    </span>
                    <span className="w-[20%] text-[14px]">
                      
                    </span>
                  </li>
                  <li className="my-2 flex">
                    <span className="w-[80%] text-[14px]">
                      Used free subscription
                    </span>
                    <span className="w-[20%] text-[14px]">
                     
                    </span>
                  </li>
                  <li className="my-2 flex">
                    <span className="w-[80%] text-[14px]">
                      Total free subscription
                    </span>
                    <span className="w-[20%] text-[14px]">
                      
                    </span>
                  </li> */}
              </div>
            </MetricCard>
          </div>
          <div className='flex flex-col w-full rounded-2xl border-none bg-white'>
            <div className='flex flex-row gap-5 items-center border-b p-5'>
              <Image
                src={shareReferal}
                alt={'share'}
                className='h-10 w-10'
              >
              </Image>
              <div className='flex flex-col gap-2 '>
                <p className='font-[600px] text-[#111928] text-[16px]'>
                  Share your referral link
                </p>
                <p className='text-[#4B5563] font-[400px] text-[16px]'>
                  Invite your friends to join syncupp using your unique referral link
                </p>
              </div>
            </div>
            <div className='flex flex-row gap-5 items-center border-b p-5'>
              <Image
                src={joinReferal}
                alt={'share'}
                className='h-10 w-10'
              >
              </Image>
              <div className='flex flex-col gap-2 '>
                <p className='font-[600px] text-[#111928] text-[16px]'>
                  Your friend joins                    </p>
                <p className='text-[#4B5563] font-[400px] text-[16px]'>
                  When your friend joins Syncupp through your shared link, they become a part of our community.                    </p>
              </div>
            </div>
            <div className='flex flex-row gap-5 items-center p-5'>
              <Image
                src={rewardReferal}
                alt={'share'}
                className='h-10 w-10'
              >
              </Image>
              <div className='flex flex-col gap-2 '>
                <p className='font-[600px] text-[#111928] text-[16px]'>
                  You earn reward                    </p>
                <p className='text-[#4B5563] font-[400px] text-[16px]'>
                  As a token of appreciation, you will receive referral cash of 1500 with each signup..
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default withRoleAuth([roles.agency])(
  ReferalPage
);
