import { metaObject } from '@/config/site.config';
import ReferalPage from './main-page';

export const metadata = {
  ...metaObject('Referral'),
};

export default function Page() {
  return (
    <>
      <ReferalPage />
    </>
  );
}
