'use client';

import { Controller, SubmitHandler } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { useDispatch, useSelector } from 'react-redux';
import { capitalizeFirstLetter, customHandleKeyDown, handleKeyContactDown, handleKeyDown } from '@/utils/common-functions';
import { useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';
import { SupportTicketSchema, supportTicketSchema } from '@/utils/validators/support-ticket.schema';
import { addSupportTicket } from '@/redux/slices/support-ticket/support-ticket-slice';
import { ActionIcon, Textarea, Title } from 'rizzui';
import { PiXBold } from 'react-icons/pi';
import WidgetCard from '@/components/cards/widget-card';

import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { routes } from '@/config/routes';
import { PhoneNumber } from '@/components/ui/phone-input';
import { useRef } from 'react';


const initialValues: SupportTicketSchema = {
    name: '',
    email: '',
    contact_number: '',
    ticket_detail: '',
};

export default function SupportPage(props: any) {

    const { setOpen } = props;

    const dispatch = useDispatch();
    const router = useRouter();
    const signIn = useSelector((state: any) => state?.root?.signIn);
    const { loading } = useSelector((state: any) => state?.root?.support);
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace)

    // Set value reference
    const setValueReference = useRef<any>();

    const token = localStorage?.getItem('token');
    // console.log("token...", !!token)

    // const signInData = signIn?.user?.data?.user;

    const user_name = capitalizeFirstLetter(signIn?.user?.data?.user?.first_name) + " " + capitalizeFirstLetter(signIn?.user?.data?.user?.last_name);

    const formDefaultValues = {
        name: (user_name === "undefined undefined" ? "" : user_name) ?? "",
        email: signIn?.user?.data?.user?.email ?? '',
        contact_number: signIn?.user?.data?.user?.contact_number ?? '',
        ticket_detail: '',
    }


    const onSubmit: SubmitHandler<SupportTicketSchema> = (data) => {

        dispatch(addSupportTicket(data)).then((result: any) => {
            if (addSupportTicket.fulfilled.match(result)) {
                if (result && result.payload.success === true) {
                    setValueReference.current('ticket_detail', '');
                }
            }
        });

    };

    return (
        <>
            <Form<SupportTicketSchema>
                validationSchema={supportTicketSchema}
                onSubmit={onSubmit}
                // resetValues={reset}
                useFormProps={{
                    mode: 'onTouched',
                    defaultValues: formDefaultValues,
                }}
                className=''
            >
                {({ register, control, formState: { errors }, setValue }) => (
                    setValueReference.current = setValue,
                    <div className="p-2">
                        <CustomePageHeader route={routes.dashboard(defaultWorkSpace?.name)} title="Support" titleClassName="montserrat_font_title" />
                        <WidgetCard
                            rounded="lg"
                            title=""
                            className='!border-none mt-[40px]'
                        >
                            <div className='grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-3 mb-5'>
                                <Input
                                    onKeyDown={customHandleKeyDown}
                                    type="text"
                                    label="Name*"
                                    placeholder="Enter Name"
                                    className="[&>label>span]:font-semibold w-full"
                                    {...register('name')}
                                    disabled={!!token}
                                    error={errors.name?.message}
                                    inputClassName='text-black poppins_font_number'
                                />
                            </div>
                            <div className='grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-3 mb-5'>
                                <Input
                                    onKeyDown={handleKeyDown}
                                    type="email"
                                    label="Email Address*"
                                    placeholder="Enter Email Address"
                                    className="[&>label>span]:font-semibold"
                                    {...register('email')}
                                    disabled={!!token}
                                    error={errors?.email?.message}
                                    inputClassName='text-black poppins_font_number'
                                />
                                {/* <Input
                                    onKeyDown={handleKeyContactDown}
                                    type="text"
                                    label="Contact Number"
                                    placeholder="Enter contact number"
                                    className="[&>label>span]:font-semibold"
                                    {...register('contact_number')}
                                    error={errors.contact_number?.message}
                                /> */}
                                <Controller
                                    name="contact_number"
                                    control={control}
                                    render={({ field: { value, onChange } }) => (
                                        <PhoneNumber
                                            country="us"
                                            // size={'xl'}
                                            label="Contact Number"
                                            placeholder="Enter Contact Number"
                                            // onKeyDown={handleKeyContactDown}
                                            // className="[&>label>span]:font-semibold "
                                            className='font-semibold'
                                            value={value}
                                            error={errors.contact_number?.message as string}
                                            onChange={onChange}
                                            inputClassName='text-black poppins_font_number'
                                        />
                                    )}
                                />
                            </div>
                            <div className='mb-5'>
                                <Textarea
                                    onKeyDown={handleKeyDown}
                                    label="Ticket Detail*"
                                    placeholder="Enter Ticket Detail"
                                    className="[&>label>span]:font-semibold w-full"
                                    {...register('ticket_detail')}
                                    error={errors?.ticket_detail?.message}
                                    textareaClassName="text-black poppins_font_number"
                                />
                            </div>
                            <div className='flex justify-end mt-2'>
                                <Button
                                    className="text-sm p-5 w-48 rounded-3xl text-white  bg-[#8C80D2]"
                                    type="submit"
                                    disabled={loading}
                                >
                                    Send
                                    {loading && (
                                        <Spinner size="sm" tag="div" className="ms-3" color="white" />
                                    )}
                                </Button>
                            </div>
                        </WidgetCard>
                    </div>
                )}
            </Form>
        </>
    );
}
