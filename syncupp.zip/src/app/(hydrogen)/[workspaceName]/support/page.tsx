import FileDashboard from '@/app/shared/file/dashboard';
import { metaObject } from '@/config/site.config';
import SupportPage from './main-page';


export const metadata = {
    ...metaObject('Support'),
};


export default function FileDashboardPage() {
    return (
        <>
            {/* <FileDashboard /> */}
            <SupportPage />
        </>
    );
}
