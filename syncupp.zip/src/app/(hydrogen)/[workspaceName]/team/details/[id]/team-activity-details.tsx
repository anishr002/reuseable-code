'use client';
import { GetActivityColumns } from '@/app/shared/(user)/calender/calender-list/columns';
import CustomTable from '@/components/common-tables/table';
import { DatePicker } from '@/components/ui/datepicker';
import Select from '@/components/ui/select';
import {
  getAllActivity,
  setActivityName,
  setPaginationDetails,
} from '@/redux/slices/user/activity/activitySlice';
import { deleteTask } from '@/redux/slices/user/task/taskSlice';
import cn from '@/utils/class-names';
import moment from 'moment';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { RxReset } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';
import restImg from '@public/assets/images/reset_icon.svg';

let statusOptionsDropdown: Record<string, any>[] = [
  { name: 'All', value: '' },
  { name: 'Pending', value: 'pending' },
  { name: 'Cancel', value: 'cancel' },
  { name: 'Completed', value: 'done' },
];

export default function TeamActivityTablePage(props: any) {
  const { teamId } = props;

  const dispatch = useDispatch();
  const router = useRouter();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const activityData = useSelector((state: any) => state?.root?.activity);
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.activity
  );

  const [data, setData] = useState([]);
  const [pageSize, setPageSize] = useState<number>(10);
  const [activityType, setActivityType] = useState('');
  const [statusType, setStatusType] = useState('');
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reset, setReset] = useState('');
  const [statusOption, setStatusOption] = useState('');
  const [selectedActivity, setSelectedActivity] = useState('');
  const [startRangeDate, setStartRangeDate] = useState(null);
  const [endRangeDate, setEndRangeDate] = useState(null);

  useEffect(() => {
    // dispatch(RemoveActivityTableData())
  }, [dispatch]);

  useEffect(() => {
    setData(activityData?.data?.activity);
  }, [activityData?.data]);

  const handleStatusChange = (selectedOption: Record<string, any>) => {
    setStatusType(selectedOption?.value);
    // dispatch(setActivityName(selectedOption?.value));

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        filter: {
          status: selectedOption?.value,
          activity_type: activityType,
          date: period,
          start_date: startDate,
          end_date: endDate,
        },
      })
    );

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      if (activityType === '' && endDate === '' && startDate === '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: { status: selectedOption?.value },
            pagination: true,
          })
        );
      } else if (endDate === '' && startDate === '' && activityType !== '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: selectedOption?.value,
              activity_type: activityType,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '' && activityType !== '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: selectedOption?.value,
              activity_type: activityType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '' && activityType === '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      }
    } else {
      if (activityType === '' && endDate === '' && startDate === '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: { status: selectedOption?.value },
            pagination: true,
          })
        );
      } else if (endDate === '' && startDate === '' && activityType !== '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: selectedOption?.value,
              activity_type: activityType,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '' && activityType !== '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: selectedOption?.value,
              activity_type: activityType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      } else if (endDate !== '' && startDate !== '' && activityType === '') {
        dispatch(
          getAllActivity({
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      }
    }
  };

  const handleActivityChange = (selectedOption: Record<string, any>) => {
    setActivityType(selectedOption?.value);
    dispatch(setActivityName(selectedOption?.value));

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        filter: {
          status: statusType,
          activity_type: selectedOption?.value,
          date: period,
          start_date: startDate,
          end_date: endDate,
        },
      })
    );

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      endDate === ''
        ? dispatch(
          getAllActivity({
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: selectedOption?.value,
            },
            pagination: true,
          })
        )
        : dispatch(
          getAllActivity({
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
    } else {
      endDate === ''
        ? dispatch(
          getAllActivity({
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: selectedOption?.value,
            },
            pagination: true,
          })
        )
        : dispatch(
          getAllActivity({
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: selectedOption?.value,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
    }
  };

  const handleRangeChange = (dates: any) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
    setStartDate(moment(start).format('DD-MM-YYYY'));
    !!end && setEndDate(moment(end).format('DD-MM-YYYY'));

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        filter: {
          status: statusType,
          activity_type: activityType,
          date: 'period',
          start_date: moment(start).format('DD-MM-YYYY'),
          end_date: moment(end).format('DD-MM-YYYY'),
        },
      })
    );

    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      !!end &&
        dispatch(
          getAllActivity({
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: activityType,
              date: 'period',
              start_date: moment(start).format('DD-MM-YYYY'),
              end_date: moment(end).format('DD-MM-YYYY'),
            },
            pagination: true,
          })
        );
    } else {
      !!end &&
        dispatch(
          getAllActivity({
            page: 1,
            sort_field: 'createdAt',
            sort_order: 'desc',
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: activityType,
              date: 'period',
              start_date: moment(start).format('DD-MM-YYYY'),
              end_date: moment(end).format('DD-MM-YYYY'),
            },
            pagination: true,
          })
        );
    }

    !!end && setPeriod('period');
  };

  // useEffect(() => {
  //     reset === 'reset' && setStatusOption('');
  // }, [reset]);

  useEffect(() => {
    setStatusType('');
    setStatusOption('');
    setActivityType('');
    setSelectedActivity('');
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setStartRangeDate(null);
    setEndRangeDate(null);
  }, [clientSliceData?.agencyId]);

  useEffect(() => {
    if (
      activityType !== '' ||
      statusType !== '' ||
      period !== '' ||
      startDate !== '' ||
      endDate !== ''
    ) {
      setReset('');
    }
  }, [activityType, statusType, period, startDate, endDate]);

  const handleResetFilters = () => {
    setStatusType('');
    setStatusOption('');
    setActivityType('');
    setSelectedActivity('');
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setStartRangeDate(null);
    setEndRangeDate(null);
    setReset('reset');

    dispatch(
      getAllActivity({
        sort_field: 'createdAt',
        sort_order: 'desc',
        attendee_id: teamId,
        pagination: true,
      })
    );
  };

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    dispatch(
      setPaginationDetails({
        pageNumber: page,
        itemsPerPageNumber: items_per_page,
      })
    );

    const response =
      signIn?.role !== 'client' && signIn?.role !== 'team_client'
        ? await dispatch(
          getAllActivity({
            page,
            items_per_page,
            sort_field,
            sort_order,
            search,
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: activityType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        )
        : await dispatch(
          getAllActivity({
            page,
            items_per_page,
            sort_field,
            sort_order,
            search,
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: activityType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      // await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search }));
      signIn?.role !== 'client' && signIn?.role !== 'team_client'
        ? await dispatch(
          getAllActivity({
            page,
            items_per_page,
            sort_field,
            sort_order,
            search,
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: activityType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        )
        : await dispatch(
          getAllActivity({
            page,
            items_per_page,
            sort_field,
            sort_order,
            search,
            attendee_id: teamId,
            filter: {
              status: statusType,
              activity_type: activityType,
              date: period,
              start_date: startDate,
              end_date: endDate,
            },
            pagination: true,
          })
        );
      return data?.client;
    }
    if (data && data?.client && data?.client?.length !== 0) {
      return data?.client;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    // console.log("delete id in main page....", id)

    try {
      const res =
        typeof id === 'string'
          ? await dispatch(deleteTask({ taskIdsToDelete: [id] }))
          : await dispatch(deleteTask({ taskIdsToDelete: id }));
      if (res.payload.success === true) {
        const reponse =
          signIn?.role !== 'client' && signIn?.role !== 'team_client'
            ? await dispatch(
              getAllActivity({
                page: currentPage,
                items_per_page: countPerPage,
                sort_field: sortConfig?.key,
                sort_order: sortConfig?.direction,
                search: searchTerm,
                attendee_id: teamId,
                filter: {
                  status: statusType,
                  activity_type: activityType,
                  date: period,
                  start_date: startDate,
                  end_date: endDate,
                },
                pagination: true,
              })
            )
            : await dispatch(
              getAllActivity({
                page: currentPage,
                items_per_page: countPerPage,
                sort_field: sortConfig?.key,
                sort_order: sortConfig?.direction,
                search: searchTerm,
                attendee_id: teamId,
                filter: {
                  status: statusType,
                  activity_type: activityType,
                  date: period,
                  start_date: startDate,
                  end_date: endDate,
                },
                pagination: true,
              })
            );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const FilterList = () => {
    return (
      <>
        <Select
          options={statusOptionsDropdown}
          onChange={(selectedOption: Record<string, any>) => {
            setStatusOption(selectedOption?.name);
            handleStatusChange(selectedOption);
          }}
          value={statusOption}
          placeholder="Select Status"
          className="w-full"
        />
        <DatePicker
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          // isClearable={true}
          monthsShown={1}
          placeholderText="Select Date in a Range"
          className="w-full"
          selectsRange
        />
        <div>
          <Button
            className="flex h-[40px] px-[40px] items-center justify-center rounded-3xl bg-[#E3E1F4] text-sm text-[#8C80D2]"
            onClick={handleResetFilters}
          >
            <Image className='text-white mr-2' alt='reste' width={15} height={15} src={restImg} />
            Reset
          </Button>
        </div>
      </>
    );
  };

  return (
    <>
      <div className="">
        <div className="table_border_remove">
          <CustomTable
            data={data}
            total={(activityData && activityData?.data?.page_count) || 1}
            loading={activityData && activityData?.loading}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={GetActivityColumns}
            filtersList={<FilterList />}
          />
        </div>
      </div>
    </>
  );
}
