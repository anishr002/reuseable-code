'use client';

import { Title } from '@/components/ui/text';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { Link } from 'react-scroll';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { PhoneNumber } from '@/components/ui/phone-input';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { setClientTeamId } from '@/redux/slices/user/client/clientSlice';
import { getTeamMemberProfile } from '@/redux/slices/user/team-member/teamSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import TeamActivityTablePage from './team-activity-details';

const menuItems = [
  {
    label: 'Meetings',
  },
];

const pageHeader = {
  title: 'Team member Details',
};

export default function TeamMemberViewProfileForm(props: any) {
  const { id } = props;
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const router = useRouter();

  const [selectedTask, setSelectedTask] = useState('Meetings');
  const [teamId, setTeamId] = useState('');
  const [profileData, setProfileData] = useState({});

  useEffect(() => {
    id &&
      dispatch(getTeamMemberProfile({ _id: id })).then((result: any) => {
        if (getTeamMemberProfile.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            setProfileData(result?.payload?.data);
            setTeamId(result?.payload?.data?._id);
            dispatch(setClientTeamId(result?.payload?.data?._id));
          }
        }
      });
  }, [id, dispatch]);

  // let [data] = teamMemberData?.teamMemberProfile ?? [{}];

  const handleTaskClick = (task: any) => {
    setSelectedTask(task);
  };

  return (
    <>
      <CustomePageHeader
        title={pageHeader.title}
        route={routes?.team(defaultWorkSpace?.name)}
        titleClassName="montserrat_font_title"
      >
      </CustomePageHeader>

      <InformationCard title="Personal Information" data={profileData} />

      <div className="main_card_block">
        <WidgetCard rounded="lg" title="">
          {/* <div className='tab-padding'>
        {menuItems.map((menu, index) => (
          <Button
            key={index}
            className={cn(
              'group relative cursor-pointer whitespace-nowrap py-2.5 font-medium text-gray-500 before:absolute before:bottom-0 before:left-0 before:z-[1] before:h-0.5  before:bg-gray-1000 before:transition-all hover:text-gray-900',
              menu.label === selectedTask
                ? 'before:visible before:w-full before:opacity-100'
                : 'before:invisible before:w-0 before:opacity-0'
            )}
            variant='text'
            // disabled={menu.label !== selectedTask}
            onClick={() => handleTaskClick(menu.label)}
          >
            <Text
              as="span"
              className={cn(
                "inline-flex rounded-md px-2.5 py-1.5 transition-all duration-200 group-hover:bg-gray-100/70",
                menu.label === selectedTask && 'text-black'
              )}
            >
              {menu.label}
            </Text>
          </Button>
        ))}
      </div> */}
          <div className="">
            {selectedTask === 'Meetings' && (
              <div>
                {teamId === '' ? (
                  <div className="flex items-center justify-center p-10">
                    <Spinner size="xl" tag="div" />
                  </div>
                ) : (
                  <TeamActivityTablePage teamId={teamId} />
                )}
              </div>
            )}
          </div>
        </WidgetCard>
      </div>
    </>
  );
}

function InformationCard({
  title,
  className,
  data,
}: {
  title: string;
  className?: string;
  data?: any;
}) {
  return (
    <div className="pb-5">
      <WidgetCard rounded="lg" title="">
        <Title as="h3" className="text-3xl font-bold text-[#9BA1B9] sm:text-lg">
          {title}
        </Title>
        {title === 'Personal Information' && (
          <div className="mt-3 grid grid-cols-1 items-start gap-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3">
            <ul className="grid gap-3 @3xl:col-span-full @3xl:mb-2 @5xl:col-span-1 @5xl:mb-0">
              <li className="flex items-center gap-3 @3xl:justify-between @5xl:justify-start">
                <span className="text-sm font-semibold text-[#9BA1B9]">
                  Name :
                </span>
                <span className="capitalize text-black poppins_font_number">
                  {data?.first_name
                    ? capitalizeFirstLetter(data?.first_name)
                    : '-'}{' '}
                  {data?.last_name
                    ? capitalizeFirstLetter(data?.last_name)
                    : '-'}
                </span>
              </li>
            </ul>
            <ul className="grid gap-3 @3xl:col-span-full @3xl:mb-2 @5xl:col-span-1 @5xl:mb-0">
              <li className="flex items-center gap-3 @3xl:justify-between @5xl:justify-start">
                <span className="text-sm font-semibold text-[#9BA1B9]">
                  Email :
                </span>
                <span className="text-black poppins_font_number">
                  {data?.email?.toLowerCase() ?? '-'}
                </span>
              </li>
            </ul>
            <ul className="grid gap-3 @3xl:col-span-full @3xl:mb-2 @5xl:col-span-1 @5xl:mb-0">
              <li className="flex items-center gap-3 @3xl:justify-between @5xl:justify-start">
                <span className="text-sm font-semibold text-[#9BA1B9]	">
                  Contact No :
                </span>
                {data?.contact_number ? (
                  <PhoneNumber
                    value={data?.contact_number}
                    disabled={true}
                    className="display-phone-number"
                  />
                ) : (
                  <span className="text-black">-</span>
                )}
              </li>
            </ul>
          </div>
        )}
      </WidgetCard>
    </div>
  );
}
