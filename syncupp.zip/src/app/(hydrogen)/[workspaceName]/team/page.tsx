import { metaObject } from '@/config/site.config';
import TeamDataTablePage from './main-page';

export const metadata = {
  ...metaObject('Team'),
};

export default function Page() {
  return (
    <>
      <div className="main_card_block">
        <TeamDataTablePage />
      </div>
    </>
  );
}
