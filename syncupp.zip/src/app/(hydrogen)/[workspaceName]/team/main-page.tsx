'use client';

import AddTeamMemberForm from '@/app/shared/(user)/client/team/create-edit/add-team-member-form';
import { GetColumns } from '@/app/shared/(user)/client/team/team-list/columns';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import ImportButton from '@/app/shared/import-button';
import { useModal } from '@/app/shared/modal-views/use-modal';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import { roles } from '@/config/roles';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  RemoveTeamMemberTableData,
  deleteClientTeamMember,
  getAllTeamMember,
} from '@/redux/slices/user/team-member/teamSlice';
import {
  getStepsByRole,
  teamMemberTourStepsContent,
} from '@/utils/tour-steps/tour-steps';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { PiCaretDownBold, PiPlusBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import DeleteModel from './confiramtionpopupteam';

const pageHeader = {
  title: 'Team',
};

function TeamDataTablePage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();
  const [pageSize, setPageSize] = useState(10);
  const teamMemberData = useSelector((state: any) => state?.root?.teamMember);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const [showDropdown, setShowDropdown] = useState(false);


  useEffect(() => {
    dispatch(RemoveTeamMemberTableData(''));
  }, [dispatch]);

  // Api call for Tour status get
  useEffect(() => {
    // Tour comment
    dispatch(getAllTourStatus());
  }, [dispatch]);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [teamMemberModuleTourSteps, setTeamMemberModuleTourSteps] = useState(
    []
  );

  // Handle close tour
  const handleCloseTour = () => {
    dispatch(
      updateTourStatus({ team_member: { create_team_member_tour: true } })
    ).then((result: any) => {
      if (updateTourStatus.fulfilled.match(result)) {
        if (result?.payload?.success) {
          setIsTourOpen(false);
          // Tour comment
          dispatch(getAllTourStatus());
        }
      }
    });
  };

  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.team_member &&
      !tourStatusData?.team_member?.create_team_member_tour
    ) {
      setTeamMemberModuleTourSteps([]);
      setIsTourOpen(false);
      const teamMemberTourStepContent = teamMemberTourStepsContent(
        handleCloseTour,
        signIn,
        checkPermission
      );

      const updatedTeamMemberModuleTourSteps = getStepsByRole(
        teamMemberTourStepContent
      );
      updatedTeamMemberModuleTourSteps?.length > 0 &&
        setTeamMemberModuleTourSteps(updatedTeamMemberModuleTourSteps);
      updatedTeamMemberModuleTourSteps?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData, signIn.permission, signIn]);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    const response = await dispatch(
      getAllTeamMember({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        agency_id: clientSliceData?.agencyId,
        pagination: true,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;
    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllTeamMember({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          agency_id: clientSliceData?.agencyId,
          pagination: true,
        })
      );
      return data?.teamMemberList;
    }
    if (data && data?.teamMemberList && data?.teamMemberList.length !== 0) {
      return data?.teamMemberList;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      /* 
       Forcefully client team member is pending
      */

      const res = await dispatch(
        deleteClientTeamMember({
          teamMemberIds: id,
          force_fully_remove: false,
          // agency_id: clientSliceData?.agencyId,
        })
      );

      if (res?.payload?.data?.force_fully_remove === true) {
        openModal({
          view: (
            <DeleteModel
              forsfully={res?.payload?.data?.force_fully_remove}
              id={id}
              page={currentPage}
              items_per_page={countPerPage}
              sort_field={sortConfig?.key}
              sort_order={sortConfig?.direction}
              search={searchTerm}
              pagination={true}
              agency_id={clientSliceData?.agencyId}
            />
          ),
          customSize: '500px',
        });
      }
      console.log(res.payload, 'payload');
      if (res?.payload?.success === true) {
        const reponse = await dispatch(
          getAllTeamMember({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            search: searchTerm,
            agency_id: clientSliceData?.agencyId,
            pagination: true,
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Tour
        steps={teamMemberModuleTourSteps ?? []}
        isOpen={isTourOpen}
        rounded={10}
        closeWithMask={false}
        disableInteraction={true}
        disableKeyboardNavigation={['esc']}
        onRequestClose={handleCloseTour}
        className="poppins_font_number tour-close-button font-semibold text-black"
      />
      <CustomePageHeader
        title={pageHeader.title}
        titleClassName="montserrat_font_title"
      >
        {(['client'].includes(signIn?.role) ||
          (['team_client'].includes(signIn?.role) &&
            checkPermission('teams', null, 'create', signIn?.permission))) && (
            <div className="relative flex items-center gap-2">
              <Button
                rounded="lg"
                className="team-member-tour-step-one flex h-10 min-w-[150px] w-[220px] items-center justify-start gap-2 bg-[#8C80D2] text-sm text-white"
                onClick={() => {
                  openModal({
                    view: (
                      <AddTeamMemberForm title="New Team Member" isEdit={false} />
                    ),
                    customSize: '600px'
                  });
                  setShowDropdown(false);
                }}
              >
                <PiPlusBold className="h-4 w-4 mr-2" />
                <span>Add Team member</span>
                {/* Dropdown Icon */}
                <div
                  className="absolute right-3 top-1/2 flex h-full -translate-y-1/2 transform cursor-pointer items-center border-l-2 border-gray-400 pl-3"
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent button click
                    setShowDropdown((prev) => !prev); // Toggle dropdown visibility
                  }}
                >
                  <PiCaretDownBold className="h-4 w-4 text-white" />
                </div>
              </Button>
              {/* Dropdown Content */}
              {showDropdown && (
                <>
                  {!defaultWorkSpace?.trial_end_date && (
                    <ImportButton
                      modalBtnLabel="Import File"
                      className="absolute right-0 top-full z-10 mt-2 h-10 w-[200px] rounded-lg !bg-white"
                      isClientTeamModule={true}
                      buttonLabel="Import teams in bulk"
                    />
                  )}
                </>
              )}
            </div>
          )}
      </CustomePageHeader>
      <WidgetCard rounded="lg" title="">
        <div className="table_border_remove">
          <CustomTable
            data={teamMemberData && teamMemberData?.data?.teamMemberList}
            total={teamMemberData && teamMemberData?.data?.page_count}
            loading={teamMemberData && teamMemberData?.loading}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={GetColumns}
            scroll={{ x: 1100 }}
          />
        </div>
      </WidgetCard>
    </>
  );
}

export default withRoleAuth(
  [roles.client, roles.teamClient],
  'teams',
  null,
  'view'
)(TeamDataTablePage);
