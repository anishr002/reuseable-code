'use client';

import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { PhoneNumber } from '@/components/ui/phone-input';
import { roles } from '@/config/roles';
import { handleKeyDown } from '@/utils/common-functions';
import { useDropzone } from 'react-dropzone';
import {
  Formik,
  Form,
  Field,
  ErrorMessage,
  FormikProps,
  FieldProps,
  FieldArray,
} from 'formik';
import Image from 'next/image';
import { ActionIcon, Button, Input } from 'rizzui';
import profilePlaceholder from 'public/assets/images/profile_placeholder.svg';
import { useEffect, useRef, useState } from 'react';
import * as Yup from 'yup';
import { messages } from '@/config/messages';
import { PiXBold } from 'react-icons/pi';
import fileUploadIcon from '@public/assets/svgs/fileUploadIcon.svg';
import fileImage from '../../../../../../public/assets/images/file_img.png';
import TrashIcon from '@/components/icons/trash';
import {
  FaAngleDown,
  FaAngleUp,
  FaChevronDown,
  FaChevronUp,
} from 'react-icons/fa';
import ReactSelect from 'react-select';
import { useDispatch } from 'react-redux';
import {
  getCities,
  getCountry,
  getState,
  RemovecityData,
} from '@/redux/slices/user/client/clientSlice';
import dynamic from 'next/dynamic';
import SelectLoader from '@/components/loader/select-loader';
import { useSelector } from 'react-redux';
import Spinner from '@/components/ui/spinner';

// Dropdown style
const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    cursor: 'pointer',
    backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
    color: state.isSelected ? 'black' : 'black',
    padding: '8px',
  }),
  control: (provided: any) => ({
    ...provided,
    borderRadius: '10px', // Rounded corners for the input field
    borderColor: '#E2E8F0', // Light gray border
    boxShadow: 'none', // Remove default box shadow
    '&:hover': {
      borderColor: '#CBD5E0', // Slightly darker border on hover
    },
  }),
  dropdownIndicator: (provided: any) => ({
    ...provided,
    color: '#A0AEC0', // Gray arrow color
    '&:hover': {
      color: '#4A5568', // Darker gray on hover
    },
  }),
  menu: (provided: any) => ({
    ...provided,
    borderRadius: '10px', // Rounded corners for the dropdown menu
    overflow: 'hidden', // Avoid overflow issues with rounded corners
  }),
  singleValue: (provided: any) => ({
    ...provided,
    fontWeight: '500', // Semi-bold for the selected value
  }),
};

const Select = dynamic(() => import('@/components/ui/select'), {
  ssr: false,
  loading: () => <SelectLoader />,
});

function CreateCustomer({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: any;
}) {
  const imageref = useRef<any>();
  const [previewImage, setpreviewImage] = useState<any>();
  const [imagesetFlag, setimagesetFlag] = useState<any>(false);
  const [showBasicInfo, setShowBasicInfo] = useState(true);
  const [showTaxInfo, setShowTaxInfo] = useState(false);
  const [showAddress, setShowAddress] = useState(false);
  const InvoiceLoader = useSelector(
    (state: any) => state?.root?.invoiceform?.cutomerLoading
  );
  const dispatch = useDispatch();
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  console.log(InvoiceLoader, 'InvoiceLoader');

  useEffect(() => {
    dispatch(getCountry());
  }, [dispatch]);
  const [regionalData, setRegionalData] = useState({
    city: '',
    state: '',
    country: '',
  });

  let countryOptions: Record<string, string>[] = [];
  let cityOptions: Record<string, string>[] = [];

  clientSliceData?.countries !== '' &&
    clientSliceData?.countries?.map((country: Record<string, string>) => {
      countryOptions.push({
        name: country?.name,
        value: country?._id,
        label: country?.name,
        _id: country?._id,
      });
    });

  const countryHandleChange = (countryId: string) => {
    console.log('called', countryId);
    const [countryObj] = clientSliceData?.countries?.filter(
      (country: Record<string, string>) => country?._id === countryId
    );
    console.log('countryObj', countryObj);
    dispatch(getState({ countryId })); // Use the ID for API
    dispatch(RemovecityData());
    cityOptions = [];
    setRegionalData({
      ...regionalData,
      country: countryId, // Use the ID here
      state: '',
      city: '',
    });
  };

  console.log(countryOptions, '12333');

  let stateOptions: Record<string, string>[] = [];
  clientSliceData?.states !== '' &&
    clientSliceData?.states?.map((state: Record<string, string>) => {
      stateOptions.push({
        name: state?.name,
        value: state?._id,
        label: state?.name,
        _id: state?._id,
      });
    });

  const stateHandleChange = (stateId: string) => {
    const [stateObj] = clientSliceData?.states?.filter(
      (state: Record<string, string>) => state?._id === stateId
    );
    dispatch(getCities({ stateId })); // Use the ID for API calls
    console.log('stateObj', stateObj);
    setRegionalData({ ...regionalData, state: stateId }); // Update with the ID
  };

  clientSliceData?.cities !== ''
    ? clientSliceData?.cities?.map((city: Record<string, string>) => {
        cityOptions.push({
          name: city?.name,
          value: city?._id,
          label: city?.name,
          _id: city?._id,
        });
      })
    : (cityOptions = []);

  const cityHandleChange = (cityId: string) => {
    const [cityObj] = clientSliceData?.cities?.filter(
      (city: Record<string, string>) => city?._id === cityId
    );
    console.log('cityObj', cityObj);
    setRegionalData({ ...regionalData, city: cityId }); // Update with the ID
  };

  const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/jpg'];
  const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

  const isFile = (value: any) => {
    return value instanceof File;
  };

  const invoiceFormSchema = Yup.object().shape({
    name: Yup.string()
      .required(messages.nameIsRequired)
      .min(1, messages.nameIsRequired)
      .max(30, messages.nameLength),
    clientIndustry: Yup.string()
      .required(messages.clientIndustryIsRequired)
      .min(1, messages.clientIndustryIsRequired)
      .max(30, messages.clientIndustryLength),
    email: Yup.string()
      .required(messages.emailIsRequired)
      .email(messages.invalidEmail),
    contact_number: Yup.string().required(messages.contactRequired),
    create_customer_logo: Yup.mixed()
      .nullable()
      .notRequired()
      .test('fileSize', messages.invoicemaxFileSize, function (value: any) {
        console.log(value && value?.size <= MAX_FILE_SIZE, 18, value);
        if (!value || !isFile(value)) return true; // If no file is provided, it's valid
        return value && value?.size <= MAX_FILE_SIZE;
      })
      .test('fileFormat', messages.InvoiceFileformate, function (value: any) {
        console.log(
          value && ACCEPTED_IMAGE_TYPES.includes(value?.type),
          23,
          value
        );
        if (!value || typeof value === 'string') return true; // If no file is provided, it's valid
        return value && ACCEPTED_IMAGE_TYPES.includes(value?.type);
      }),
    gstin: Yup.string()
      .nullable()
      .notRequired()
      .matches(
        /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/,
        'Invalid GSTIN format'
      ),
    pannumber: Yup.string()
      .nullable()
      .notRequired()
      .matches(
        /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
        'Invalid PAN Number format (e.g., ABCDE1234F)'
      ),
    taxPreference: Yup.string()
      .notRequired() // Make it optional
      .oneOf(['taxable', 'nonTaxable'], 'Invalid tax preference selected'),
    taxId: Yup.string()
      .notRequired() // Make it optional
      .oneOf(
        ['GST', 'VAT'], // Values for taxId field
        'Invalid Tax ID selected'
      ),
    address: Yup.string().optional(),
    city: Yup.string().optional(),
    state: Yup.string().optional(),
    country: Yup.string().optional(),
    pincode: Yup.string().optional(),
  });
  type InvoiceFormInput = Yup.InferType<typeof invoiceFormSchema>;

  // InitialValue Schema
  const initialsValue: InvoiceFormInput = {
    name: '',
    clientIndustry: '',
    email: '',
    contact_number: '',
    create_customer_logo: null,
    gstin: '',
    pannumber: '',
    taxPreference: 'taxable',
    taxId: 'GST', // Default value
    address: '',
    city: '',
    state: '',
    country: '',
    pincode: '',
  };

  const handleInvoiceSubmit = (data: any) => {
    console.log(data, '4555555');
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    const file = acceptedFiles[0];
    const fileType = file?.type;
    // console.log(fileType, 'fileType', file)

    // Check if the uploaded file is a JPG or PNG image
    if (
      fileType === 'image/jpeg' ||
      fileType === 'image/png' ||
      fileType === 'image/jpg'
    ) {
      const fileUrl = URL.createObjectURL(file);
      // setValue("board_image", file)
      imageref.current('create_customer_logo', file);
      setpreviewImage(fileUrl);
    } else {
      imageref.current('create_customer_logo', file);
      setpreviewImage(fileImage);
      // Optionally, handle the case where the file is not a JPG or PNG image
      console.error('Invalid file type. Only JPG and PNG images are allowed.');
    }
  };
  // Dropzone Options
  const dropzoneOptions: any = {
    // useFsAccessApi: false,
    onDrop: handleDrop,
    // accept: { 'image/*': [] },
    // maxSize: 6 * 1024 * 1024, // Maximum file size of 10MB
    multiple: false,
    noClick: false,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
    useDropzone(dropzoneOptions);

  return (
    <div className="px-3 py-6">
      <div className="ml-4 flex items-center justify-between ">
        <p className="px-3  text-[20px] font-bold leading-[30px]  text-[#141414]">
          Add new customer
        </p>
        {/* <ActionIcon
          size="sm"
          variant="text"
          onClick={onClose}
          className="me-4 p-0 text-[#141414] hover:!text-gray-900"
        >
          <PiXBold className="h-[19px] w-[50px] " />
        </ActionIcon> */}
      </div>
      <div className="ml-[25px] mr-[20px] mt-5  border border-[#D1D5DB]"></div>
      <Formik
        initialValues={initialsValue}
        validationSchema={invoiceFormSchema}
        onSubmit={(values, actions) => {
          // Call the parent's onSubmit function
          if (onSubmit) {
            onSubmit(values); // Pass the form data to the parent
          }
          actions.setSubmitting(false);
          // Close the modal only if loading is false
          // if (!InvoiceLoader && onClose) {
          //   onClose();
          // }
        }}
        // enableReinitialize
      >
        {({
          values,
          isSubmitting,
          setFieldValue,
          errors,
          validateForm,
          handleSubmit,
          setErrors,
          setFieldTouched,
          validateField,
          touched,
        }: any) => (
          console.log(errors, '323'),
          (
            <div>
              <Form className="placeholder_color">
                <div
                  className="ml-[4px] flex cursor-pointer items-center justify-between p-[20px]"
                  onClick={() => setShowBasicInfo(!showBasicInfo)}
                >
                  <h2 className=" text-[14px] font-semibold leading-[21px] text-[#141414]">
                    Basic Information
                  </h2>
                  <span>
                    {showBasicInfo ? (
                      <FaChevronDown className="h-[15px] w-[15px]" />
                    ) : (
                      <FaChevronUp className="h-[15px] w-[15px]" />
                    )}
                  </span>
                </div>

                {/* To Input Selection */}

                {showBasicInfo && (
                  <div>
                    <div className="ml-5 mt-2">
                      <div className="grid grid-cols-1 items-center">
                        {previewImage ? (
                          <div className="flex items-center justify-start ">
                            <Image
                              alt="img"
                              className="mr-3"
                              src={previewImage}
                              width={100}
                              height={100}
                            />
                            <TrashIcon
                              className="ms-4 h-5 w-5 cursor-pointer"
                              onClick={() => {
                                setpreviewImage(null);
                                setFieldValue('create_customer_logo', null);
                              }}
                            />
                          </div>
                        ) : (
                          <div {...getRootProps()}>
                            <input {...getInputProps()} />
                            <div
                              className="flex h-auto w-[242px] cursor-pointer flex-col gap-[10px] rounded-[10px] border border-dashed border-[#B7C2D3] bg-[#F8FAFF] p-4 pb-[16px] pt-[16px]"
                              onClick={() => {
                                // open()
                                imageref.current = setFieldValue;
                              }}
                            >
                              <div className="flex w-full justify-center">
                                <Image
                                  alt="img"
                                  // src={imgPlacholder}
                                  src={fileUploadIcon}
                                  width={20}
                                  height={20}
                                  className="h-5 w-5"
                                />
                              </div>
                              <div className="text-center font-semibold text-[#111928]">
                                Add Client Logo
                              </div>
                              <div className="text-center font-semibold text-[#4B5563]">
                                Resolution upto 1080x1080 px.
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="mt-0.5 text-xs text-red">
                          {errors && errors?.create_customer_logo
                            ? errors?.create_customer_logo
                            : ''}
                        </div>
                      </div>
                      {/* <div className="ml-5 mt-5 flex place-items-center justify-start">
                    <Image
                      alt="img"
                      className="mr-5"
                      src={profilePlaceholder}
                      width={55}
                      height={55}
                    />
                  </div> */}
                    </div>
                    <div className="ml-1 grid grid-cols-1 md:grid-cols-2">
                      {/* Name Field */}
                      <div className="m-5">
                        <Field name={`name`} className="w-full">
                          {({ field, meta }: FieldProps) => (
                            <Input
                              {...field}
                              onKeyDown={handleKeyDown}
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              label="Business name *"
                              value={values?.name}
                              placeholder="Enter Business Name"
                              className="w-full"
                              inputClassName="text-black rounded-[10px]"
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="name"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>

                      {/* Client industry Field */}
                      <div className="m-5">
                        <Field name={`clientIndustry`} className="w-full">
                          {({ field, meta }: FieldProps) => (
                            <Input
                              {...field}
                              onKeyDown={handleKeyDown}
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              label="Client Industry *"
                              value={values?.clientIndustry}
                              placeholder="Enter Client Industry"
                              className="w-full"
                              inputClassName="text-black rounded-[10px]"
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="clientIndustry"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>

                      {/* Email Field */}
                      <div className="ml-5 mr-5 mt-1">
                        <Field name={`email`} className="w-full">
                          {({ field, meta }: FieldProps) => (
                            <Input
                              {...field}
                              onKeyDown={handleKeyDown}
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              label="Email address *"
                              value={values?.email}
                              placeholder="www.techorigins.net"
                              className="w-full"
                              inputClassName="text-black rounded-[10px]"
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="email"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>
                      {/* Contact Number Field */}
                      <div className="ml-5 mr-5 mt-1">
                        <Field name="contact_number">
                          {({ field, form }: FieldProps<any>) => (
                            <PhoneNumber
                              {...field}
                              label="Phone number *"
                              country="us"
                              className="w-full"
                              value={values.contact_number}
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              placeholder="Enter contact number"
                              onChange={(e: any) => {
                                setFieldValue('contact_number', e);
                              }}
                              inputClassName="text-black rounded-[10px]"
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="contact_number"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div
                  className="ml-[4px] flex cursor-pointer items-center justify-between pb-[5px] pl-[20px] pr-[20px] pt-[20px]"
                  onClick={() => setShowTaxInfo(!showTaxInfo)}
                >
                  <h2 className=" text-[14px] font-semibold leading-[21px] text-[#141414]">
                    Tax Information <span>(optional)</span>
                  </h2>

                  <span>
                    {showTaxInfo ? (
                      <FaChevronDown className="h-[15px] w-[15px]" />
                    ) : (
                      <FaChevronUp className="h-[15px] w-[15px]" />
                    )}
                  </span>
                </div>
                {showTaxInfo && (
                  <div>
                    <div className="ml-1 grid grid-cols-1 md:grid-cols-2">
                      {/* Business GSTIN Field */}
                      <div className="m-5">
                        <Field name="gstin">
                          {({ field, meta }: FieldProps) => (
                            <Input
                              {...field}
                              label="Business GSTIN"
                              placeholder="Enter your GSTIN (e.g., 27AAAPA1234A1Z5)"
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              className="w-full"
                              inputClassName="text-black rounded-[10px]"
                              type="text"
                              value={values.gstin}
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="gstin"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>

                      {/* Business PAN Number Field */}
                      <div className="m-5">
                        <Field name={`pannumber`} className="w-full">
                          {({ field, meta }: FieldProps) => (
                            <Input
                              {...field}
                              onKeyDown={handleKeyDown}
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              label="Business PAN Number"
                              value={values?.pannumber}
                              placeholder="Enter your PAN Number (e.g., ABCDE1234F)"
                              className="w-full"
                              inputClassName="text-black rounded-[10px]"
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="pannumber"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>

                      {/* Tax Preference Field */}

                      <div className="ml-5 mr-5 mt-1">
                        <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                          Tax Preference
                        </span>
                        <Field name="taxPreference">
                          {({ field, form, meta }: FieldProps) => (
                            <ReactSelect
                              placeholder="Select Tax Preference"
                              className="mt-1 rounded-[10px] text-black"
                              classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                              value={
                                form.values.taxPreference
                                  ? {
                                      label:
                                        form.values.taxPreference === 'taxable'
                                          ? 'Taxable'
                                          : 'Non-Taxable', // Display label
                                      value: form.values.taxPreference, // Value to be stored
                                    }
                                  : null
                              }
                              options={[
                                { value: 'taxable', label: 'Taxable' },
                                { value: 'nonTaxable', label: 'Non-Taxable' },
                              ]}
                              onChange={(option: any) => {
                                form.setFieldValue(
                                  field.name,
                                  option?.value || ''
                                ); // Update Formik value (store the value, not label)
                              }}
                              styles={customStyles}
                            />
                          )}
                        </Field>

                        <ErrorMessage
                          name="taxPreference"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        />
                      </div>

                      {/* Tax ID Field */}

                      <div className="ml-5 mr-5 mt-1">
                        <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                          Tax ID
                        </span>
                        <Field name="taxId">
                          {({ field, form, meta }: FieldProps) => (
                            <ReactSelect
                              placeholder="Select Tax Preference"
                              className="mt-1 rounded-[10px] text-black"
                              classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                              value={
                                form.values.taxId
                                  ? {
                                      label:
                                        form.values.taxId === 'GST'
                                          ? 'GST ( India )'
                                          : 'VAT', // Display label
                                      value: form.values.taxId, // Value to be stored
                                    }
                                  : null
                              }
                              options={[
                                {
                                  value: 'GST',
                                  label: 'GST ( India )',
                                },
                                { value: 'VAT', label: 'VAT' },
                              ]}
                              onChange={(option: any) => {
                                form.setFieldValue(
                                  field.name,
                                  option?.value || ''
                                ); // Update Formik value
                              }}
                              styles={customStyles}
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="taxId"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div
                  className="ml-[4px] flex cursor-pointer items-center justify-between pb-[5px] pl-[20px] pr-[20px] pt-[20px]"
                  onClick={() => setShowAddress(!showAddress)}
                >
                  <h2 className=" text-[14px] font-semibold leading-[21px] text-[#141414]">
                    Address <span>(optional)</span>
                  </h2>

                  <span>
                    {showAddress ? (
                      <FaChevronDown className="h-[15px] w-[15px]" />
                    ) : (
                      <FaChevronUp className="h-[15px] w-[15px]" />
                    )}
                  </span>
                </div>
                {showAddress && (
                  <div>
                    <div className="ml-1 grid grid-cols-1 md:grid-cols-2">
                      {/* Tax Preference Field */}

                      <div className="ml-5 mr-5 mt-1">
                        <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                          Select Country{' '}
                        </span>
                        <Field name="country">
                          {({ field, form, meta }: FieldProps) => (
                            <ReactSelect
                              placeholder="Select Country"
                              className="mt-1 rounded-[10px] text-black"
                              classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                              value={
                                form.values.country
                                  ? countryOptions.find(
                                      (option) =>
                                        option.value === form.values.country
                                    )
                                  : null
                              }
                              options={countryOptions}
                              onChange={(option: any) => {
                                setFieldValue('country', option.value); // Store the ID in the form state
                                countryHandleChange(option.value); // Handle change with ID
                                setFieldValue('state', ''); // Reset state and city
                                setFieldValue('city', '');
                              }}
                              styles={customStyles}
                            />
                          )}
                        </Field>

                        <ErrorMessage
                          name="country"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        />
                      </div>

                      <div className="ml-5 mr-5 mt-1">
                        <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                          State
                        </span>
                        <Field name="state">
                          {({ field, form, meta }: FieldProps) => (
                            <ReactSelect
                              placeholder="Select State"
                              className="mt-1 rounded-[10px] text-black"
                              classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                              value={
                                form.values.state
                                  ? stateOptions.find(
                                      (option) =>
                                        option.value === form.values.state
                                    )
                                  : null
                              }
                              options={stateOptions}
                              onChange={(option: any) => {
                                setFieldValue('state', option.value); // Store the ID in the form state
                                stateHandleChange(option.value); // Pass the ID to handle changes
                              }}
                              isDisabled={stateOptions?.length === 0} // Disable dropdown if no options
                              styles={customStyles}
                            />
                          )}
                        </Field>

                        <ErrorMessage
                          name="state"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        />
                      </div>
                      <div className="ml-5 mr-5 mt-5">
                        <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                          City/Town
                        </span>
                        <Field name="city">
                          {({ field, form, meta }: FieldProps) => (
                            <ReactSelect
                              placeholder="Select City"
                              className="mt-1 rounded-[10px] text-black"
                              classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                              value={
                                form.values.city
                                  ? cityOptions.find(
                                      (option) =>
                                        option.value === form.values.city
                                    )
                                  : null
                              }
                              options={cityOptions}
                              onChange={(option: any) => {
                                setFieldValue('city', option.value); // Store the ID in the form state
                                cityHandleChange(option.value); // Pass the ID to handle changes
                              }}
                              isDisabled={cityOptions.length === 0} // Disable dropdown if no options
                              styles={customStyles}
                            />
                          )}
                        </Field>

                        <ErrorMessage
                          name="city"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        />
                      </div>
                      <div className="ml-5 mr-5 mt-5">
                        <Field name={`pincode`} className="w-full">
                          {({ field, meta }: FieldProps) => (
                            <Input
                              {...field}
                              onKeyDown={handleKeyDown}
                              labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                              label="Postal Code/Zip Code"
                              value={values?.pincode}
                              placeholder="Enter Postal Code/Zip Code"
                              className="w-full"
                              inputClassName="text-black rounded-[10px]"
                            />
                          )}
                        </Field>
                        <ErrorMessage
                          name="pincode"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        />
                      </div>
                    </div>
                    <div className="m-5">
                      <Field name={`address`} className="w-full">
                        {({ field, meta }: FieldProps) => (
                          <Input
                            {...field}
                            onKeyDown={handleKeyDown}
                            labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                            label="Street Address"
                            value={values?.address}
                            placeholder="Enter your address"
                            className="w-full"
                            inputClassName="text-black rounded-[10px]"
                          />
                        )}
                      </Field>
                      <ErrorMessage
                        name="address"
                        component="div"
                        className="mt-0.5 text-xs text-red"
                      />
                    </div>
                  </div>
                )}

                <div className="ml-1 grid grid-cols-1 md:grid-cols-2">
                  {/* Address Field */}

                  {/* Action Buttons - Set to 2 columns */}
                  {/* Action Buttons */}
                  <div className="col-span-2 m-5 grid grid-cols-1 gap-10 md:grid-cols-2">
                    <div className="w-full">
                      <Button
                        variant="outline"
                        className="w-full text-[#111928] dark:hover:border-gray-400"
                        onClick={onClose}
                      >
                        Cancel
                      </Button>
                    </div>
                    <div className="w-full">
                      <Button
                        className="w-full rounded-[8px] bg-[#7667CF] text-white dark:text-white"
                        type="submit"
                        disabled={InvoiceLoader}
                      >
                        Add client
                        {InvoiceLoader && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </Form>
            </div>
          )
        )}
      </Formik>
    </div>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'invoices',
  null,
  'create'
)(CreateCustomer);
