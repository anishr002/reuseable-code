'use client';

import PageHeader from '@/app/shared/page-header';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import CustomTable from '@/components/common-tables/table';
import { InvoiceColumns } from '@/app/shared/(user)/invoice/invoice-list/column';
import { Button } from 'rizzui';
import Link from 'next/link';
import { routes } from '@/config/routes';
import { PiPlusBold } from 'react-icons/pi';
import {
  DeleteInvoice,
  RemoveinvoiceData,
  getAllInvoiceDataTable,
  getInvoiceApi,
  setPagginationParams,
} from '@/redux/slices/user/invoice/invoiceSlice';
import { usePathname, useRouter } from 'next/navigation';
import Select from '@/components/ui/select';
import DatePicker from 'react-datepicker';
import DateFiled from '@/components/controlled-table/date-field';
import cn from '@/utils/class-names';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import moment from 'moment';
import WidgetCard from '@/components/cards/widget-card';
import Image from 'next/image';
import restImg from 'public/assets/images/reset_icon.svg';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { useSetState } from 'react-use';
import ReactSelect from 'react-select';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';

const pageHeader = {
  title: 'Invoices',
};

const Statusoptions = [
  { name: 'All', value: '' },
  { name: 'Draft', value: 'draft' },
  { name: 'Paid', value: 'paid' },
  { name: 'Unpaid', value: 'unpaid' },
  { name: 'Overdue', value: 'overdue' },
];

function InvoiceDataTablePage(props: any) {
  const { clientSliceData } = props;

  const dispatch = useDispatch();
  const router = useRouter();
  const pathname = usePathname().includes('/client/details/');

  const [pageSize, setPageSize] = useState(10);

  const invoiceData = useSelector((state: any) => state?.root?.invoice);
  const invoiceSliceData = useSelector((state: any) => state?.root?.invoice);
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.invoice
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  // console.log(signIn?.role === 'team_agency', 'signIn')

  const [selectedClient, setselectedClient] = useState<any>(null);
  const [statusname, setstatusname] = useState<any>(null);
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);
  // const [searchfilterflag, setsearchfilterflag] = useSetState<any>(false)

  console.log(startRangeDate, endRangeDate, 'endRangeDate');

  // Reset table Data
  useEffect(() => {
    dispatch(RemoveinvoiceData());
  }, []);
  // Client Options
  // const clientOptions = invoiceSliceData?.getInvoiceApidata?.data && invoiceSliceData?.getInvoiceApidata?.data?.length > 0 ? invoiceSliceData?.getInvoiceApidata?.data?.map((client: any) => ({
  //   name: `${client?.client_full_name}(${client.company_name})`,
  //   value: client?._id,
  //   key: client,
  // }))
  //   : [];

  const clientOptions = [
    { name: 'Select customer', value: '', key: {} },
    ...(invoiceSliceData?.getInvoiceApidata?.data &&
    invoiceSliceData?.getInvoiceApidata?.data?.length > 0
      ? invoiceSliceData?.getInvoiceApidata?.data.map((client: any) => ({
          name: client?.client_full_name,
          value: client?._id,
          key: client,
        }))
      : []),
  ];

  // console.log(selectedClient, 'selectedClient')

  // Get Dropdown Clients
  useEffect(() => {
    dispatch(getInvoiceApi());
  }, []);

  useEffect(() => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    dispatch(
      getAllInvoiceDataTable({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        client_id: pathname ? clientSliceData?._id : null,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date:
          endRangeDate && endRangeDate != null
            ? moment(endRangeDate).format('DD/MM/YYYY')
            : null,
        client_name: selectedClient?.value,
        status_name: statusname?.value,
      })
    );
  }, [statusname, selectedClient, endRangeDate]);

  // Status Handler
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    await dispatch(setPagginationParams(paginationParams));
    const response = await dispatch(
      getAllInvoiceDataTable({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        client_id: pathname ? clientSliceData?._id : null,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date:
          endRangeDate && endRangeDate != null
            ? moment(endRangeDate).format('DD/MM/YYYY')
            : null,
        client_name: selectedClient?.value,
        status_name: statusname?.value,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllInvoiceDataTable({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          client_id: pathname ? clientSliceData?._id : null,
          start_date:
            startRangeDate && startRangeDate != null
              ? moment(startRangeDate).format('DD/MM/YYYY')
              : null,
          end_date:
            endRangeDate && endRangeDate != null
              ? moment(endRangeDate).format('DD/MM/YYYY')
              : null,
          client_name: selectedClient?.value,
          status_name: statusname?.value,
        })
      );
      return data?.invoiceList;
    }
    if (data && data?.invoiceList && data?.invoiceList.length !== 0) {
      return data?.invoiceList;
    }
  };

  // Delete handler
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      const res = await dispatch(DeleteInvoice({ invoiceIdsToDelete: id }));
      if (res.payload.success === true) {
        const reponse = await dispatch(
          getAllInvoiceDataTable({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            search: searchTerm,
            client_id: pathname ? clientSliceData?._id : null,
            start_date:
              startRangeDate && startRangeDate != null
                ? moment(startRangeDate).format('DD/MM/YYYY')
                : null,
            end_date:
              endRangeDate && endRangeDate != null
                ? moment(endRangeDate).format('DD/MM/YYYY')
                : null,
            client_name: selectedClient?.value,
            status_name: statusname?.value,
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    setstatusname(null);
    setselectedClient(null);
  };

  // Dropdown style
  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      cursor: 'pointer',
      backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  // Construct the href for the Link component
  const linkHref = pathname
    ? `${routes.invoiceForm(
        defaultWorkSpace?.name
      )}?reference=${clientSliceData?._id}`
    : routes.invoiceForm(defaultWorkSpace?.name);

  // Table Filters

  const InvoicesFilters = () => {
    return (
      <>
        {!pathname && (
          <Select
            className="w-full !text-black"
            onChange={(e) => {
              setselectedClient(e);
            }}
            options={clientOptions}
            value={capitalizeFirstLetter(selectedClient?.name)}
            placeholder="Select customer"
            dropdownClassName="capitalize !text-black"
            // label="Recipient*"
            // color="info"
          />
        )}

        {/* {!pathname && <ReactSelect
          placeholder='Select a Customer'
          className="w-full"
          value={(selectedClient)}
          options={clientOptions}
          // isClearable={false}
          styles={customStyles}
          onChange={(e) => { setselectedClient(e) }}
        />} */}
        <Select
          className="w-full !text-black"
          onChange={(e) => {
            setstatusname(e);
          }}
          placeholder="Select status"
          options={Statusoptions}
          value={statusname?.name}
          dropdownClassName="!text-black"
          // label="Recipient*"
          // color="info"
        />

        <DateFiled
          selected={startRangeDate}
          className="w-full "
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Select date range"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        />

        <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>

        {pathname && signIn?.role === 'agency' && (
          <div className="flex items-center gap-3 @lg:mt-0">
            <Link href={linkHref} className="w-full">
              <Button
                type="button"
                className="h-12 w-full rounded-3xl bg-[#8C80D2] text-sm"
              >
                <PiPlusBold className="me-1.5 h-[17px] w-[17px]" /> Create New
                Invoice{' '}
              </Button>
            </Link>
          </div>
        )}
      </>
    );
  };

  return (
    <>
      {!pathname && (
        <CustomePageHeader
          title={!pathname ? pageHeader.title : ''}
          titleClassName="montserrat_font_title"
        >
          <div className="flex items-center gap-3 @lg:mt-0">
            {(['agency'].includes(signIn?.role) ||
              (['team_agency'].includes(signIn?.role) &&
                checkPermission(
                  'invoices',
                  null,
                  'create',
                  signIn?.permission
                ))) && (
              <Link href={linkHref} className="w-full">
                <Button
                  type="button"
                  // onClick={() => { pathname ? router.push(`${routes.invoiceForm(defaultWorkSpace?.name)}?reference=${clientSliceData?._id}`) : router.push(routes.invoiceForm(defaultWorkSpace?.name)) }}
                  className="h-[40px] w-auto rounded-[8px] bg-[#7667CF] p-[12px]  text-sm"
                >
                  <PiPlusBold className="me-1.5 h-[17px] w-[17px]" /> New
                  invoice
                </Button>
              </Link>
            )}
          </div>
        </CustomePageHeader>
      )}

      {pathname && (
        <div className="table_border_remove">
          <div className="mt-8">
            <CustomTable
              data={invoiceData && invoiceData?.data?.invoiceList}
              total={invoiceData && invoiceData?.data?.page_count}
              loading={invoiceData && invoiceData?.loading}
              pageSize={pageSize}
              setPageSize={setPageSize}
              handleDeleteById={handleDeleteById}
              handleChangePage={handleChangePage}
              getColumns={InvoiceColumns}
              filtersList={<InvoicesFilters />}

              // searchfilterflag={searchfilterflag}

              // scroll={{ x: 0 }}
            />
          </div>
        </div>
      )}

      {!pathname && (
        <WidgetCard rounded="lg" title="" className="">
          <div className="table_border_remove">
            <CustomTable
              data={invoiceData && invoiceData?.data?.invoiceList}
              total={invoiceData && invoiceData?.data?.page_count}
              loading={invoiceData && invoiceData?.loading}
              pageSize={pageSize}
              setPageSize={setPageSize}
              handleDeleteById={handleDeleteById}
              handleChangePage={handleChangePage}
              getColumns={InvoiceColumns}
              filtersList={<InvoicesFilters />}
              // scroll={{ x: 0 }}
            />
          </div>
        </WidgetCard>
      )}
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'invoices',
  null,
  'view'
)(InvoiceDataTablePage);
