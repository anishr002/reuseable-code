'use client';

import Image from 'next/image';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Title, Text } from '@/components/ui/text';
import Table from '@/components/ui/table';
import { siteConfig } from '@/config/site.config';
import { useSelector, useDispatch } from 'react-redux';
import { useEffect, useRef, useState } from 'react';
import { postDownloadInvoice } from '@/redux/slices/user/invoice/invoiceSlice';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { ActionIcon, Button } from 'rizzui';
import { FaArrowLeft } from 'react-icons/fa';
import { routes } from '@/config/routes';
import { getSingleClientinvoice } from '@/redux/slices/user/client/invoice/clientinvoiceSlice';
import Spinner from '@/components/ui/spinner';
import { IoMdDownload } from 'react-icons/io';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import PageHeader from '@/app/shared/page-header';
import { capitalizeFirstLetter, formatAddress } from '@/utils/common-functions';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import SimpleBar from 'simplebar-react';
import { CiExport } from 'react-icons/ci';
import toast from 'react-hot-toast';
import WidgetCard from '@/components/cards/widget-card';
import InvoicePreview from '@/app/shared/(user)/invoice/invoice-preview';

function InvoiceDetails({ params }: { params: { id: string } }) {
  const dispatch = useDispatch();
  const router = useRouter();
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<any>(null);
  const invoiceRef: any = useRef(null);

  const handleClickOutside = (event: any) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowDropdown(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const { singleInvoicedetails, loading } = useSelector(
    (state: any) => state?.root?.clieninvoice
  );
  const IncoiceLoader = useSelector((state: any) => state?.root?.invoice)
    ?.loading;
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  // console.log(singleInvoicedetails, 'singleInvoicedetails')

  const data = singleInvoicedetails?.data?.[0];

  useEffect(() => {
    dispatch(getSingleClientinvoice(params?.id));
  }, [params?.id]);

  const columns = [
    {
      title: (
        <p className="text-left text-[16px] font-bold">Item Descriptions</p>
      ),
      key: 'item',
      width: 600,
      render: (product: any, record: any, index: any) => (
        <>
          {!(record.key === 'totalRow') ? (
            <div className="poppins_font_number">
              <Title
                as="h6"
                className="poppins_font_number mb-0.5 text-sm font-medium"
              >
                {product?.item && product?.item != '' ? product?.item : '-'}
              </Title>
              <Text
                as="p"
                className="poppins_font_number mb-0.5 break-all text-sm"
              >
                {product?.description && product?.description != ''
                  ? product?.description
                  : '-'}
              </Text>
            </div>
          ) : (
            <Title as="h6" className="text-right text-sm font-medium"></Title>
          )}
        </>
      ),
    },
    {
      title: <p className="text-center text-[16px] font-bold">Quantity</p>,
      key: 'qty',
      width: 150,
      render: (product: any, record: any, index: any) => (
        <>
          {!(record.key === 'totalRow') ? (
            <Title
              as="h6"
              className="poppins_font_number mb-0.5 text-center text-sm font-medium"
            >
              {product?.qty && product?.qty != '' ? product?.qty : '-'}
            </Title>
          ) : (
            <Title as="h6" className="text-right text-sm font-medium"></Title>
          )}
        </>
      ),
    },
    {
      title: <p className="text-center text-[16px] font-bold">Rate</p>,
      key: 'rate',
      width: 150,
      render: (product: any, record: any, index: any) => (
        <>
          {!(record.key === 'totalRow') ? (
            <Title
              as="h6"
              className="poppins_font_number mb-0.5 text-center text-sm font-medium"
            >
              {product?.rate && product?.rate != ''
                ? data?.currency_symbol + ' ' + product?.rate
                : '-'}
            </Title>
          ) : (
            <Title as="h6" className="text-right text-sm font-medium"></Title>
          )}
        </>
      ),
    },
    {
      title: <p className="text-center text-[16px] font-bold">Taxes</p>,
      key: 'tax',
      width: 200,
      render: (product: any, record: any, index: any) => (
        <>
          {!(record.key === 'totalRow') ? (
            <Title
              as="h6"
              className="poppins_font_number mb-0.5 text-center text-sm font-medium"
            >
              {product?.tax && product?.tax != '' ? product?.tax + ' %' : '-'}
            </Title>
          ) : (
            <Title className="text-right text-[16px] font-bold text-[#8C80D2]">
              Total Amount :
            </Title>
          )}
        </>
      ),
    },
    {
      title: <p className="text-center text-[16px] font-bold">Amount</p>,
      key: 'amount',
      width: 200,
      render: (product: any, record: any, index: any) => (
        // console.log(product, 'product'),
        <>
          {!(record.key === 'totalRow') ? (
            <Title
              as="h6"
              className="poppins_font_number mb-0.5 text-center text-sm font-medium"
            >
              {product?.amount && product?.amount != ''
                ? data?.currency_symbol + ' ' + product?.amount
                : '-'}
            </Title>
          ) : (
            <div className="">
              <Title className="poppins_font_number poppins_font_number text-center text-[16px] font-bold text-[#8C80D2]">
                {data?.currency_symbol}{' '}
                {data?.total && data?.total != '' ? data?.total : 0}
              </Title>
            </div>
          )}
        </>
      ),
    },
  ];

  // Add an empty object and total row to the data
  const dataWithAdditionalRows = [
    ...(Array.isArray(data?.invoice_content) ? data.invoice_content : []),
    { key: 'totalRow' },
  ];

  function InvoiceDetailsListTable() {
    return (
      <Table
        data={dataWithAdditionalRows}
        columns={columns}
        variant="minimal"
        rowKey={(record) => record.id}
        scroll={{ x: 1100 }}
        className="invoice_table_view mb-4"
      />
    );
  }

  const DownloadInvoice = () => {
    dispatch(postDownloadInvoice({ invoice_id: params?.id }));
  };

  function calculateTotalTax(invoiceContent: any) {
    let total = 0;

    if (
      invoiceContent &&
      Array.isArray(invoiceContent) &&
      invoiceContent.length > 0
    ) {
      for (let index = 0; index < invoiceContent.length; index++) {
        const item: any = invoiceContent[index];
        if (
          item &&
          typeof item.qty === 'number' &&
          typeof item.rate === 'number' &&
          typeof item.tax === 'number'
        ) {
          const itemTotal =
            item.rate * item.qty + ((item.rate * item.qty) / 100) * item.tax;
          total += parseFloat(itemTotal.toFixed(2));
        }
      }
    }

    return total.toFixed(2);
  }

  // Calculate Total After Discount
  function calculateTotalAfterDiscount(invoiceContent: any, discount: number) {
    const total: any = calculateTotalTax(invoiceContent);
    const discountAmount = (total * (discount || 0)) / 100;
    return (total - discountAmount).toFixed(2);
  }

  // Calculate Discount
  function calculateDiscount(invoiceContent: any, discount: number) {
    const total: any = calculateTotalTax(invoiceContent);
    const discountAmount = (total * (discount || 0)) / 100;
    return discountAmount.toFixed(2);
  }

  const copyLinkHandler = (invoiceId: string) => {
    const copyUrl = `${process.env.NEXT_PUBLIC_FRONT_LINK}/invoice/${invoiceId}`;

    navigator.clipboard
      .writeText(copyUrl)
      .then(() => {
        toast.success('Invoice link copied to clipboard!');
        setShowDropdown(false);
      })
      .catch(() => {
        toast.error('Failed to copy link');
        setShowDropdown(false);
      });

    console.log(copyUrl, 'invoiceId');
  };
  // const handlePrint = () => {
  //   if (!invoiceRef.current) return;

  //   const printContent = invoiceRef.current.innerHTML;
  //   const originalContent = document.body.innerHTML;

  //   document.body.innerHTML = printContent;
  //   window.print();
  //   document.body.innerHTML = originalContent;
  // };
  return (
    <>
      {loading ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" className="ms-3" />
        </div>
      ) : (
        <div>
          {/* // <div ref={invoiceRef}> */}
          <CustomePageHeader
            titleClassName="montserrat_font_title"
            route={routes.invoice(defaultWorkSpace?.name)}
            title={`View Invoice`}
          >
            <div
              ref={dropdownRef}
              className="relative flex items-center justify-end gap-3"
            >
              <Button
                type="button"
                rounded="lg"
                className="flex h-10 items-center justify-center gap-2 border border-[#6875F5] !bg-transparent text-sm font-semibold text-[#5850EC]"
                onClick={() => {
                  setShowDropdown((prev) => !prev);
                }}
              >
                <CiExport className="h-4 w-4 text-inherit" />
                Share
              </Button>
              {showDropdown && (
                <div
                  className={`absolute right-0 top-full z-10 mt-2 flex-col items-start gap-[7px] rounded-[8px] !bg-white p-[10px] shadow-lg`}
                >
                  <Button
                    disabled={IncoiceLoader}
                    onClick={DownloadInvoice}
                    className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                  >
                    Download as PDF
                    {IncoiceLoader && (
                      <Spinner
                        size="sm"
                        tag="div"
                        className="ml-2"
                        color="white"
                      />
                    )}
                  </Button>
                  {/* <Button
                    type="button"
                    onClick={() => handlePrint()}
                    className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                    // disabled={Invoiceformloader && !sentstatus}
                  >
                    Print
                  </Button> */}
                  <Button
                    type="button"
                    onClick={() => {
                      copyLinkHandler(data?._id);
                    }}
                    className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                    // disabled={Invoiceformloader && !sentstatus}
                  >
                    Copy link
                  </Button>
                </div>
              )}
            </div>
          </CustomePageHeader>

          <WidgetCard rounded="xl" title="">
            <InvoicePreview data={data} />
          </WidgetCard>
        </div>
      )}
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'invoices',
  null,
  'view'
)(InvoiceDetails);
