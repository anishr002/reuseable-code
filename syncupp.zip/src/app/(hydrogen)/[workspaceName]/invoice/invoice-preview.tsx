'use client';

import { ActionIcon } from 'rizzui';

import { PiXBold } from 'react-icons/pi';

import moment from 'moment';
import Image from 'next/image';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import { formatAddress } from '@/utils/common-functions';
import SimpleBar from 'simplebar-react';

function PreviewInvoice({
  onClose,
  values,
  selectedcureency,
  calculateTotalTax,
  calculateDiscount,
  calculateTotalAfterDiscount,
}: {
  onClose: () => void;
  values: any;
  selectedcureency: any;
  calculateTotalTax: any;
  calculateDiscount: any;
  calculateTotalAfterDiscount: any;
}) {
  console.log(values, 'values1234');
  return (
    <div className="px-6 py-6">
      <div className="flex items-center justify-between ">
        <div>
          <p className=" px-5 pt-5  text-[22px] font-bold leading-[29.26px] text-[#5850EC]">
            Invoice
          </p>
          <p className="mt-1 px-5 text-[13px] font-normal leading-[13.3px] text-[#11181C]">
            No: {values?.invoice_number ? values?.invoice_number : '-'}
          </p>
        </div>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={onClose}
          className="me-4 p-0 text-[#141414] hover:!text-gray-900"
        >
          <PiXBold className="h-[19px] w-[50px] " />
        </ActionIcon>
      </div>
      <div className="mt-2 flex flex-col space-y-1.5 px-5">
        <div className="gap flex items-center gap-12">
          <p className="text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
            Invoice Date
          </p>
          <p className="text-[13px] font-normal leading-[13.6px] text-[#11181C] ">
            {values?.invoice_date
              ? moment(values?.invoice_date).format('DD/MM/YYYY')
              : ' DD/MM/YYYY'}{' '}
          </p>
        </div>
        <div className="flex items-center gap-[66px]">
          <p className="text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
            Due Date
          </p>
          <p className="text-[13px] font-normal leading-[13.6px] text-[#11181C] ">
            {values?.due_date
              ? moment(values?.due_date).format('DD/MM/YYYY')
              : ' DD/MM/YYYY'}{' '}
          </p>
        </div>
      </div>

      <div className="ml-4 mt-5 flex h-auto w-[531px] items-start justify-between rounded-[12px] bg-[#F3F4F6] p-[22px] ">
        <div className="space-y-2">
          <p className="font-inter text-[13px] font-bold leading-[13.3px] text-[#687076]">
            Customer Details
          </p>
          <p className="font-inter text-[13px] font-normal leading-[13.3px]  text-[#11181C] ">
            {values?.name ? values?.name : 'No name available'}
          </p>
          <p className="font-inter text-[13px] font-normal leading-[13.3px]  text-[#11181C] ">
            {values?.email ? values?.email : 'No email available'}
          </p>
          <p className="font-inter text-[13px] font-normal leading-[13.3px]  text-[#11181C] ">
            {values?.contact_number
              ? `+ ${values?.contact_number}`
              : 'No contact number available'}
          </p>
        </div>

        {/* Vertical Line with Rotation */}
        <div className="mt-10 h-[1px] w-[62.03px] rotate-90 border border-[#D1D5DB]"></div>

        <div className="space-y-2">
          <p className="font-inter text-[13px] font-bold leading-[13.3px] text-[#687076]">
            Billing Address
          </p>
          <p className="w-[25vh] whitespace-normal break-words font-inter text-[13px] font-normal leading-[13.3px] text-[#11181C]">
            {values?.address
              ? formatAddress(
                  values?.address,
                  values?.city,
                  values?.state,
                  values?.country,
                  values?.pincode
                )
              : 'No address available'}
          </p>
        </div>
      </div>
      {/* Invoice Table */}
      <div className="ml-4 mt-6 w-[531px]">
        <SimpleBar className="max-h-[210px] overflow-y-auto">
          <table className="w-full border-collapse text-left">
            <thead className="sticky top-0 z-10 bg-[#F0F5FF]">
              <tr className="h-[32px] border border-[#F1F3F5] font-inter text-[13px] font-bold leading-[13.3px] text-[#687076]">
                <th className="border border-[#F1F3F5] p-3 first:rounded-tl-[4px] last:rounded-tr-[4px]">
                  #
                </th>
                <th className="border border-[#F1F3F5] p-3">Item Name</th>
                <th className="border border-[#F1F3F5] p-3">Qty</th>
                <th className="border border-[#F1F3F5] p-3">Unit Price</th>
                <th className="border border-[#F1F3F5] p-3">Tax</th>
                <th className="border border-[#F1F3F5] p-3 last:rounded-tr-[4px]">
                  Total
                </th>
              </tr>
            </thead>
            <tbody>
              {values?.invoice_content?.map((item: any, index: any) => (
                <tr
                  key={index}
                  className="border-b border-[#F1F3F5] font-inter text-[13px] font-normal leading-[13.3px] text-[#11181C]"
                >
                  <td className="p-3">{index + 1}</td>
                  <td className="max-w-[150px] overflow-hidden truncate whitespace-nowrap p-3">
                    {item?.item ? item?.item : '-'}
                  </td>
                  <td className="p-3">{item?.qty ? item?.qty : '-'}</td>
                  <td className="min-w-[80px] whitespace-nowrap p-3">
                    {item?.rate
                      ? `${selectedcureency?.key?.symbol}${item?.rate}`
                      : `${selectedcureency?.key?.symbol}00`}
                  </td>
                  <td className="p-3">
                    {item?.tax
                      ? `${selectedcureency?.key?.symbol}${item?.tax}`
                      : `${selectedcureency?.key?.symbol}00`}{' '}
                    <p className="mt-1 font-inter text-[11px] font-normal leading-[13.3px] text-[#7E868C]">
                      {item?.tax && item.tax > 0 ? 'Taxable' : 'Non-Taxable'}
                    </p>
                  </td>
                  <td className="p-3">
                    {item?.rate && item?.qty
                      ? `${selectedcureency?.key?.symbol}${(
                          item?.rate * item?.qty +
                          (item?.rate * item?.qty * item?.tax) / 100
                        ).toFixed(2)}`
                      : `${selectedcureency?.key?.symbol}00`}{' '}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </SimpleBar>
      </div>

      {/* Invoice Total */}
      <div className="ml-auto mt-[60px] flex w-fit flex-col space-y-2 px-5 text-right">
        <div className="flex w-full items-center justify-between gap-[112px]">
          <p className="font-inter text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
            Subtotal
          </p>
          <p className="text-[13px] font-normal leading-[13.6px] text-black">
            {values?.invoice_content
              ? `${selectedcureency?.key?.symbol}${calculateTotalTax(
                  values?.invoice_content
                )}`
              : '00'}
          </p>
        </div>
        <div className="flex w-full items-center justify-between gap-[112px]">
          <p className="font-inter text-[13px] font-normal leading-[13.6px] text-[#7E868C]">
            Discount
          </p>
          <p className="text-[13px] font-normal leading-[13.6px] text-[#11181C]">
            -
            {values?.invoice_content && values?.discount > 0
              ? `${selectedcureency?.key?.symbol}${calculateDiscount(
                  values?.invoice_content,
                  values?.discount
                )}`
              : '00'}
          </p>
        </div>
        <div className="flex w-full items-center justify-between gap-[112px]">
          <p className="font-inter text-[14px] font-bold leading-[18.62px] text-[#11181C]">
            Grand Total
          </p>
          <p className="font-inter text-[14px] font-bold leading-[18.62px] text-[#5850EC]">
            {selectedcureency?.key?.symbol}{' '}
            {calculateTotalAfterDiscount(
              values.invoice_content,
              values.discount
            )}
          </p>
        </div>
      </div>

      <div className="mt-[70px] px-5 font-inter text-[13px] font-normal leading-[15.96px] text-[#687076]">
        {values?.terms_conditions
          ? values?.terms_conditions
          : `Please pay within 15 days from the date of invoice, overdue
              interest @ 14% will be charged on delayed payments.`}
      </div>

      <div className="mt-3 w-auto border border-[#F1F3F5]"></div>

      <div className="mt-3 flex items-center gap-3 px-5">
        <span className="text-[13px] font-medium leading-[20px] text-[#141414]">
          Created with
        </span>
        <Image
          src={syncUppLogo}
          alt="Syncupp"
          width={100}
          height={100}
          className="h-7 w-[60px]"
        />
      </div>
    </div>
  );
}

export default PreviewInvoice;
