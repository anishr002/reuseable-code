'use client';

import React, { useEffect, useRef, useState } from 'react';
import {
  Formik,
  Form,
  Field,
  ErrorMessage,
  FormikProps,
  FieldProps,
  FieldArray,
} from 'formik';
// import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Title, Text } from '@/components/ui/text';
import { Textarea } from '@/components/ui/textarea';
import { DatePicker } from '@/components/ui/datepicker';
import Select from '@/components/ui/select';
import { FormBlockWrapper } from '@/app/shared/(user)/invoice/invoice-list/form-utils';
import FormFooter, { negMargin } from '@/components/form-footer';
// import {
//   InvoiceFormInput,
//   invoiceFormSchema,
// } from '@/utils/validators/create-invoice.schema';
import { useDispatch, useSelector } from 'react-redux';
import { getUserProfile } from '@/redux/slices/user/auth/signinSlice';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Button, Switch } from 'rizzui';
import Link from 'next/link';
import { routes } from '@/config/routes';
import { FaArrowLeft } from 'react-icons/fa6';
import moment from 'moment';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  PiCaretDownBold,
  PiMinusBold,
  PiPlusBold,
  PiTrashBold,
} from 'react-icons/pi';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  formatAddress,
  handleKeyDown,
  handleKeyDownFor100,
  handleKeyDownForAllowNumber,
  handleKeyDownForInvoiceNumber,
} from '@/utils/common-functions';
import {
  createCustomerapicall,
  updateInvoice,
} from '@/redux/slices/user/invoice/invoicesformSlice';
import {
  getDropdownCurrencylist,
  getInvoiceApi,
  getInvoiceDataByID,
} from '@/redux/slices/user/invoice/invoiceSlice';
import PageHeader from '@/app/shared/page-header';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { useDropzone } from 'react-dropzone';
import TrashIcon from '@/components/icons/trash';
import Image from 'next/image';
import imgPlacholder from 'public/assets/images/img_placeholder.svg';
import profilePlaceholder from 'public/assets/images/profile_placeholder.svg';
import { PhoneNumber } from '@/components/ui/phone-input';
import ReactSelect from 'react-select/creatable';
import fileImage from '../../../../../../../public/assets/images/file_img.png';
import { workspaceCreator } from '@/redux/slices/user/workspace/workspaceSlice';
import syncUppLogo from '@public/assets/svgs/01_logo_new.svg';
import CreateCustomer from '../../create/create-customer';
import { useModal } from '@/app/shared/modal-views/use-modal';
import removeIcon from '@public/assets/images/removeIcon.png';
import fileUploadIcon from '@public/assets/svgs/fileUploadIcon.svg';
import { FiEdit } from 'react-icons/fi';
import * as Yup from 'yup';
import { messages } from '@/config/messages';
import PreviewInvoice from '../../invoice-preview';
import { IoEyeOutline } from 'react-icons/io5';
import { IoIosArrowDown } from 'react-icons/io';
import ItemBulkUpload from '@/app/shared/items-bulk-upload';
import { getAllBoard } from '@/redux/slices/user/task/boardSlice';
import {
  getAllTask,
  RemoveGetAllTasksData,
} from '@/redux/slices/user/task/taskSlice';
import SimpleBar from 'simplebar-react';
import { MdKeyboardArrowRight } from 'react-icons/md';
import { Skeleton } from '@/components/ui/skeleton';
import { AiOutlinePercentage } from 'react-icons/ai';
import { debounce } from 'lodash';

const RecurringArray = [
  // {
  //   name: 'Does not repeat',
  //   label: 'Does not repeat',
  //   value: '',
  // },
  // {
  //   name: 'Daily',
  //   label: 'Daily',
  //   value: 'daily',
  // },
  {
    name: 'Weekly',
    label: 'Weekly',
    value: 'weekly',
  },
  {
    name: 'Monthly',
    label: 'Monthly',
    value: 'monthly',
  },
];
let monthDate = [
  { label: '1', value: '1' },
  { label: '2', value: '2' },
  { label: '3', value: '3' },
  { label: '4', value: '4' },
  { label: '5', value: '5' },
  { label: '6', value: '6' },
  { label: '7', value: '7' },
  { label: '8', value: '8' },
  { label: '9', value: '9' },
  { label: '10', value: '10' },
  { label: '11', value: '11' },
  { label: '12', value: '12' },
  { label: '13', value: '13' },
  { label: '14', value: '14' },
  { label: '15', value: '15' },
  { label: '16', value: '16' },
  { label: '17', value: '17' },
  { label: '18', value: '18' },
  { label: '19', value: '19' },
  { label: '20', value: '20' },
  { label: '21', value: '21' },
  { label: '22', value: '22' },
  { label: '23', value: '23' },
  { label: '24', value: '24' },
  { label: '25', value: '25' },
  { label: '26', value: '26' },
  { label: '27', value: '27' },
  { label: '28', value: '28' },
  { label: '29', value: '29' },
  { label: '30', value: '30' },
  { label: '31', value: '31' },
];

const weekdays = [
  { name: 'M', value: 'monday' },
  { name: 'T', value: 'tuesday' },
  { name: 'W', value: 'wednesday' },
  { name: 'T', value: 'thursday' },
  { name: 'F', value: 'friday' },
  { name: 'SA', value: 'saturday' },
  { name: 'S', value: 'sunday' },
];

function EditInvoice({ params }: { params: { id: string } }) {
  // hooks
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();

  const router = useRouter();
  const logoimageref = useRef<any>();
  const dropdownRef = useRef<any>(null);
  const setValueReference = useRef<any>();
  const [showDropdown, setShowDropdown] = useState(false);
  const [isCustomClient, setIsCustomClient] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [selectedRecurringOption, setSelectedRecurringOption] = useState<any>({
    name: '',
    label: '',
    value: '',
  });

  const searchParams = useSearchParams();
  const reference_id = searchParams.get('reference');

  // Store data selection
  const invoiceSliceData = useSelector((state: any) => state?.root?.invoice);
  const InvoiceLoader = useSelector((state: any) => state?.root?.invoice)
    ?.loading;
  const getinvoiceloader = useSelector((state: any) => state?.root?.invoice)
    ?.getinvoiceloader;
  const updateloader = useSelector(
    (state: any) => state?.root?.invoiceform?.updateInvoiceloading
  );
  const { userProfile, loading, role } = useSelector(
    (state: any) => state?.root?.signIn
  );
  const clientSliceData = useSelector((state: any) => state?.root?.client)
    ?.clientProfile;
  const { defaultWorkSpace, workspaceCreatorData } = useSelector(
    (state: any) => state?.root?.workspace
  );

  // Define State
  const [newlyAddedClient, setNewlyAddedClient] = useState<any>(null);
  const [clientOptions, setClientOptions] = useState<any>([]);
  const [selectedClient, setSelectedClient] = useState<any>(null);
  // const [selectedClient, setselectedClient] = useState<any>(null);
  const [selectedcureency, setselectedcureency] = useState<any>();
  const [sentstatus, setsentStatus] = useState<any>(false);
  const [sendChat, setSendChat] = useState(false);

  const SingleInvoiceData: any =
    invoiceSliceData?.getInvoiceDataByIDdata?.data?.[0];

  const [dueDate, setDueDate] = useState<Date>(
    SingleInvoiceData?.due_date
      ? new Date(SingleInvoiceData?.due_date)
      : new Date()
  );
  const [invoiceformDate, setinvoiceformDate] = useState<Date>(
    SingleInvoiceData?.invoice_date
      ? new Date(SingleInvoiceData?.invoice_date)
      : new Date()
  );
  const [previewImage, setpreviewImage] = useState<any>(
    SingleInvoiceData?.invoice_logo
  );
  const [clientInputvalue, setclientInputvalue] = useState<any>(true);
  const [imagesetFlag, setimagesetFlag] = useState<any>(false);
  const [isOpen, setIsOpen] = useState(false);
  const [hasMore, sethasMore] = useState(true);
  const [payload, setPalyload] = useState({
    skip: 0,
    limit: 10,
    all: false,
    sort: '',
    search: '',
  });
  const [totalBoardData, setTotalBoardData] = useState(0);
  const [skeletonLoader, setSkeletonloader] = useState(true);
  const [updatedData, setUpdateddata] = useState<any[]>([]);
  const [selectedBoard, setSelectedBoard] = useState<any>(null);
  const [taskhasMore, setTaskhasMore] = useState(true);

  const [totalTaskData, setTotalTaskData] = useState(0);
  const [taskskeletonLoader, setTaskSkeletonloader] = useState(true);
  const [taskupdatedData, setTaskUpdateddata] = useState<any[]>([]);
  const taskuploaddropdownRef = useRef<HTMLDivElement>(null);

  const { data, loading: boardLoading } = useSelector(
    (state: any) => state?.root?.board
  );
  const { data: taskData } = useSelector((state: any) => state?.root?.task);
  const { loading: taskLoading } = useSelector(
    (state: any) => state?.root?.task
  );

  console.log(taskData, boardLoading, taskLoading, 'data1234');

  useEffect(() => {
    if (isOpen) {
      dispatch(getAllBoard(payload)).then((result: any) => {
        if (getAllBoard.fulfilled.match(result)) {
          const totalBoardCount = result?.payload?.data?.total_board_count;
          const boardList = result?.payload?.data?.board_list || [];

          setTotalBoardData(totalBoardCount);

          if (boardList?.length > 0) {
            setSkeletonloader(false);

            const newData =
              payload.skip === 0
                ? boardList // Replace the data when loading the first page or searching
                : [...updatedData, ...boardList]; // Append when scrolling

            setUpdateddata(newData);

            if (totalBoardCount > newData?.length) {
              sethasMore(true); // More data available
            } else {
              sethasMore(false); // No more data
            }
          } else {
            // No results for the current search or payload
            sethasMore(false);
          }
        } else {
          sethasMore(false); // Error or no data
        }
        setSkeletonloader(false);
      });
    }
  }, [isOpen, payload]);

  //Infinite Scroll Handler
  const fetchMoreData = () => {
    // 10px buffer to trigger loading
    if (updatedData?.length < totalBoardData) {
      setPalyload({
        ...payload,
        skip: updatedData.length, // Increment skip for next batch
      });
    } else {
      sethasMore(false); // No more data to load
    }
  };

  const handleScroll = debounce((e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreData();
    }
  }, 300); // Adjust debounce delay as needed

  useEffect(() => {
    if (updatedData?.length > 0 && payload?.skip === 0) {
      setSelectedBoard(updatedData[0]); // Select first board by default
    }
  }, [updatedData]);

  const [taskpayload, setTaskPalyload] = useState({
    skip: 0,
    board_id: selectedBoard?._id,
    limit: 10,
    pagination: false,
    isInfinite: true,
  });

  useEffect(() => {
    if (selectedBoard) {
      dispatch(
        getAllTask({ ...taskpayload, board_id: selectedBoard?._id })
      ).then((result: any) => {
        if (getAllTask.fulfilled.match(result)) {
          const totaltaskCount = result?.payload?.data?.totalCount;
          const taskList = result?.payload?.data?.activity || [];

          setTotalTaskData(totaltaskCount);

          if (taskList?.length > 0) {
            setTaskSkeletonloader(false);

            const newData =
              taskpayload.skip === 0
                ? taskList // Replace the data when loading the first page or searching
                : [...taskupdatedData, ...taskList]; // Append when scrolling

            setTaskUpdateddata(newData);

            if (totaltaskCount > newData?.length) {
              setTaskhasMore(true); // More data available
            } else {
              setTaskhasMore(false); // No more data
            }
          } else {
            // No results for the current search or payload
            setTaskhasMore(false);
          }
        } else {
          setTaskhasMore(false); // Error or no data
        }
        setTaskSkeletonloader(false);
      });
    }
  }, [selectedBoard, taskpayload]);

  //Infinite Scroll Handler
  const fetchMoreTaskData = () => {
    // 10px buffer to trigger loading
    console.log(taskupdatedData?.length < totalTaskData, '123445565');
    if (taskupdatedData?.length < totalTaskData) {
      setTaskPalyload({
        ...taskpayload,
        skip: taskupdatedData?.length, // Increment skip for next batch
      });
    } else {
      setTaskhasMore(false); // No more data to load
    }
  };

  const handleTaskScroll = debounce((e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreTaskData();
    }
  }, 300); // Adjust debounce delay as needed

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        taskuploaddropdownRef.current &&
        !taskuploaddropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
        sethasMore(true);
        setPalyload({
          skip: 0,
          limit: 10,
          all: false,
          sort: '',
          search: '',
        });
        setTotalBoardData(0);
        setUpdateddata([]);
        setSkeletonloader(true);
        setTaskSkeletonloader(true);
        setTaskPalyload({
          ...taskpayload,
          skip: 0, // Increment skip for next batch
        });
        setTaskUpdateddata([]);
        setTotalTaskData(0);
        setTaskhasMore(true);
        dispatch(RemoveGetAllTasksData());
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // client dropdown options
  // const clientOptions =
  //   invoiceSliceData?.getInvoiceApidata?.data &&
  //     invoiceSliceData?.getInvoiceApidata?.data?.length > 0
  //     ? invoiceSliceData?.getInvoiceApidata?.data?.map((client: any) => ({
  //       name: `${client?.client_full_name}(${client.company_name})`,
  //       value: client?._id,
  //       key: client,
  //     }))
  //     : [];

  // On Change Recurring
  const onChangeRecurring = (option: any, setValue: any) => {
    setSelectedRecurringOption(option);
    if (option?.value !== '') {
      setValue('recurrence_pattern', option?.value);
    } else {
      setValue('recurrence_pattern', '');
    }
  };

  console.log(SingleInvoiceData, '2344');

  const [isRecurring, setIsRecurring] = useState(false);
  const [showDiscountField, setShowDiscountField] = useState(false);
  const [showTermsField, setShowTermsField] = useState(false);

  useEffect(() => {
    setSelectedRecurringOption({
      name: '',
      label: '',
      value: '',
    });
    setIsRecurring(SingleInvoiceData?.recurring);
    setShowTermsField(SingleInvoiceData?.terms_conditions);
    setShowDiscountField(
      SingleInvoiceData?.discount && SingleInvoiceData?.discount > 0
    );
    const setRecurrencePattern = RecurringArray?.find(
      (data: any) => data?.value === SingleInvoiceData?.recurrence_pattern
    );
    if (setRecurrencePattern) {
      setSelectedRecurringOption(setRecurrencePattern);
    }
  }, [SingleInvoiceData]);

  const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/jpg'];
  const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

  const isFile = (value: any) => {
    return value instanceof File;
  };

  const isToday = (date: any) => {
    const today = moment()?.startOf('day');
    return (
      moment(date).isSame(moment(), 'day') ||
      moment(date).isBefore(today, 'day')
    );
  };

  // Get Min Time
  const getMinTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment(selectedDate).isSame(moment(), 'day')
        ? moment().toDate()
        : moment().endOf('day').toDate();
    }
    return undefined;
  };

  console.log(selectedRecurringOption, 'selectedRecurringOption');

  // Get Max Time
  const getMaxTime = () => {
    if (selectedDate && isToday(selectedDate)) {
      return moment().endOf('day').toDate();
    }
    return undefined;
  };
  const invoiceFormSchema = Yup.object().shape({
    // client_id: Yup.string().required(messages.RecipientIsRequired).trim(),
    client_id: Yup.string().nullable().trim(),
    name: Yup.string()
      .required(messages.nameIsRequired)
      .min(1, messages.nameIsRequired)
      .max(30, messages.nameLength),
    email: Yup.string()
      .required(messages.emailIsRequired)
      .email(messages.invalidEmail),
    address: Yup.string().nullable().trim(),
    city: Yup.string().nullable().trim(),
    state: Yup.string().nullable().trim(),
    country: Yup.string().nullable().trim(),
    pincode: Yup.string().nullable().trim(),

    contact_number: Yup.string().required(messages.contactRequired),
    client_logo: Yup.mixed()
      .nullable()
      .notRequired()
      .test('fileSize', messages.invoicemaxFileSize, function (value: any) {
        console.log(value && value?.size <= MAX_FILE_SIZE, 18, value);
        if (!value || !isFile(value)) return true; // If no file is provided, it's valid
        return value && value?.size <= MAX_FILE_SIZE;
      })
      .test('fileFormat', messages.InvoiceFileformate, function (value: any) {
        console.log(
          value && ACCEPTED_IMAGE_TYPES.includes(value?.type),
          23,
          value
        );
        if (!value || typeof value === 'string') return true; // If no file is provided, it's valid
        return value && ACCEPTED_IMAGE_TYPES.includes(value?.type);
      }),
    invoice_logo: Yup.mixed()
      .nullable()
      .notRequired()
      .test('fileSize', messages.invoicemaxFileSize, function (value: any) {
        console.log(value && value?.size <= MAX_FILE_SIZE, 18, value);
        if (!value || !isFile(value)) return true; // If no file is provided, it's valid
        return value && value?.size <= MAX_FILE_SIZE;
      })
      .test('fileFormat', messages.InvoiceFileformate, function (value: any) {
        console.log(
          value && ACCEPTED_IMAGE_TYPES.includes(value?.type),
          23,
          value
        );
        if (!value || typeof value === 'string') return true; // If no file is provided, it's valid
        return value && ACCEPTED_IMAGE_TYPES.includes(value?.type);
      }),
    invoice_number: Yup.string()
      .required(messages.InvoiceNumberIsRequired)
      .matches(/^[a-zA-Z0-9\-\/]*$/, messages.InvalidInvoiceFormate)
      .min(2, messages.InvoiceNumberIsRequired)
      .max(20, messages.InvoiceNumberMaxLength)
      .trim(),
    invoice_date: Yup.date().required(messages.createDateIsRequired),
    due_date: Yup.date()
      .required(messages.dueDateIsRequired)
      .test(
        'is-after-or-same-date',
        'Due date cannot be earlier than invoice date',
        function (value) {
          const invoiceDate: any = this.resolve(Yup.ref('invoice_date'));

          if (!value || !invoiceDate) return true; // Skip validation if values are missing

          // Convert both to YYYY-MM-DD (ignoring time)
          const dueDateOnly = new Date(value).setHours(0, 0, 0, 0);
          const invoiceDateOnly = new Date(invoiceDate).setHours(0, 0, 0, 0);

          return dueDateOnly >= invoiceDateOnly; // Allow same or later date
        }
      ),
    invoice_content: Yup.array().of(
      Yup.object().shape({
        item: Yup.string()
          .required(messages.itemNameIsRequired)
          .max(50, messages.itemNameLength)
          .trim(),
        // description: Yup.string()
        //   .required(messages.itemDescIsRequired)
        //   .max(500, messages.invoiceDescriptionLength)
        //   .trim(),
        qty: Yup.number()
          .integer(messages.quantytyAllowInteger)
          .required(messages.itemQtyIsRequired)
          .min(1, messages.quantityminDigitLength)
          .max(9999999, messages.quantitymaxDigitLength)
          .test('is-integer', messages.quantytyAllowInteger, (value) =>
            Number.isInteger(value)
          ),
        tax: Yup.number()
          .max(100, messages.maxTaxIsRequired)
          .required(messages.taxIsRequired),
        rate: Yup.number()
          .required(messages.rateIsRequired)
          .min(1, messages.rateIsRequired)
          .max(9999999, messages.ratemaxDigitLength),
        // hsn: Yup.number()
        //   // .required(messages.hsnIsRequired)
        //   .min(1, messages.hsnIsRequired)
        //   .max(999999, messages.hsnmaxDigitLength),
      })
    ),
    memo: Yup.string().trim(),
    termsandcondition: Yup.string().trim(),
    currency: Yup.string()
      .required(messages?.currencyIsrequired)
      .trim(),
    discount: Yup.number()
      .min(0, messages.minDiscountIsRequired)
      .max(100, messages.maxDiscountIsRequired),
    recurrence_pattern: Yup.string().nullable().optional(),
    weekly_recurrence_days:
      selectedRecurringOption?.value === 'weekly'
        ? Yup.array()
            .min(1, 'Select at least one day') // Ensure at least one day is selected
            .required('Select at least one day')
        : Yup.array().optional(),
    // recurrence_interval:
    //   selectedRecurringOption?.value !== ''
    //     ? Yup.string()
    //         .min(1, 'Minimum 1 number required')
    //         .max(2, 'Maximum 2 digits allowed')
    //         .matches(
    //           /^[1-9][0-9]?$/,
    //           'Only positive integers greater than 0 are allowed'
    //         ) // Excludes 0, only positive integers are allowed
    //         .required('Recurrence interval is required')
    //     : Yup.string().optional(),

    recurrence_start_date:
      selectedRecurringOption?.value !== ''
        ? Yup.date()
            .nullable()
            .test(
              'is-not-null',
              messages.recurringStartDateIsRequried,
              (val) => val !== null
            )
        : Yup.date().nullable().optional(),

    recurrence_end_date:
      selectedRecurringOption?.value !== ''
        ? Yup.date()
            .nullable()
            .test(
              'is-not-null',
              messages.recurringEndDateIsRequried,
              (val) => val !== null
            )
        : Yup.date().nullable().optional(),
    recurrence_start_at_time:
      selectedRecurringOption?.value !== ''
        ? Yup.date()
            .nullable() // This allows it to be null
            .test(
              'is-not-null',
              messages.recurringStartTimeIsRequried,
              (val) => val !== null
            )
        : Yup.date().nullable().optional(),

    monthly_recurrence_day_of_month:
      selectedRecurringOption?.value == 'monthly'
        ? Yup.object({
            label: Yup.string(),
            value: Yup.string(),
          }).nullable()
        : Yup.object({
            label: Yup.string().optional(),
            value: Yup.string().optional(),
          }).optional(),
  });

  type InvoiceFormInput = Yup.InferType<typeof invoiceFormSchema>;

  useEffect(() => {
    if (invoiceSliceData?.getInvoiceApidata?.data?.length > 0) {
      const options = invoiceSliceData?.getInvoiceApidata?.data.map(
        (client: any) => ({
          label: capitalizeFirstLetter(client?.client_full_name),
          value: client?._id,
          key: client,
        })
      );
      setClientOptions(options);
    }
  }, [invoiceSliceData]);

  // Currency dropdown options
  const CurrencyOptions =
    invoiceSliceData?.currencylist?.data &&
    invoiceSliceData?.currencylist?.data?.length > 0
      ? invoiceSliceData?.currencylist?.data?.map((currencydata: any) => ({
          name: currencydata?.symbol + ' ' + currencydata?.name,
          value: currencydata?._id,
          key: currencydata,
        }))
      : [];

  // API calls
  useEffect(() => {
    dispatch(getUserProfile());
    dispatch(getDropdownCurrencylist());
  }, []);

  useEffect(() => {
    dispatch(getInvoiceApi());
  }, []);

  // Set State Data
  useEffect(() => {
    if (params.id) {
      dispatch(getInvoiceDataByID({ _id: params.id }));
      SingleInvoiceData?.to?._id
        ? setSelectedClient(
            clientOptions.find(
              (option: any) => option.value === SingleInvoiceData?.to?._id
            )
          )
        : setSelectedClient(
            clientOptions.find(
              (option: any) =>
                option.value === SingleInvoiceData?.custom_client?._id
            )
          );
      setselectedcureency(
        CurrencyOptions.find(
          (option: any) => option.value === SingleInvoiceData?.currency_id
        )
      );
      setIsCustomClient(SingleInvoiceData?.to?.is_custom_client);
    }
  }, [params.id]);

  useEffect(() => {
    if (SingleInvoiceData?.due_date && SingleInvoiceData?.invoice_date) {
      setDueDate(new Date(SingleInvoiceData?.due_date));
      setinvoiceformDate(new Date(SingleInvoiceData?.invoice_date));
      setpreviewImage(SingleInvoiceData?.invoice_logo);
      SingleInvoiceData?.to?._id
        ? setSelectedClient(
            clientOptions.find(
              (option: any) => option.value === SingleInvoiceData?.to?._id
            )
          )
        : setSelectedClient(
            clientOptions.find(
              (option: any) =>
                option.value === SingleInvoiceData?.custom_client?._id
            )
          );
      setselectedcureency(
        CurrencyOptions.find(
          (option: any) => option.value === SingleInvoiceData?.currency_id
        )
      );
    }
  }, [SingleInvoiceData]);

  useEffect(() => {
    if (role === 'team_agency') {
      dispatch(workspaceCreator());
    }
  }, [role]);

  // Total point Calculations
  function calculateTotalTax(invoiceContent: any) {
    let total = 0;

    if (
      invoiceContent &&
      Array.isArray(invoiceContent) &&
      invoiceContent.length > 0
    ) {
      for (let index = 0; index < invoiceContent.length; index++) {
        const item: any = invoiceContent[index];
        if (
          item &&
          typeof item.qty === 'number' &&
          typeof item.rate === 'number' &&
          typeof item.tax === 'number'
        ) {
          const itemTotal =
            item.rate * item.qty + ((item.rate * item.qty) / 100) * item.tax;
          total += parseFloat(itemTotal.toFixed(2));
        }
      }
    }

    return total.toFixed(2);
  }

  console.log(SingleInvoiceData, 'SingleInvoiceData34566');

  const parseTimeToDate = (timeString: string | null) => {
    if (!timeString) return null;
    const now = new Date(); // Use current date
    const [hours, minutes] = timeString.split(':').map(Number);
    return new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      hours,
      minutes
    );
  };

  // form initialvalue schema
  const initialsValue: InvoiceFormInput = {
    name: SingleInvoiceData?.to?.name
      ? SingleInvoiceData?.to?.name
      : SingleInvoiceData?.to?.client_full_name,
    client_logo: SingleInvoiceData?.to?.client_logo
      ? SingleInvoiceData?.to?.client_logo
      : SingleInvoiceData?.custom_client?.client_logo,
    email: SingleInvoiceData?.to?.email
      ? SingleInvoiceData?.to?.email
      : SingleInvoiceData?.custom_client?.email,
    address: SingleInvoiceData?.to?.address
      ? SingleInvoiceData?.to?.address
      : SingleInvoiceData?.custom_client?.address,
    city: SingleInvoiceData?.to?.city?.name,
    pincode: SingleInvoiceData?.to?.pincode,
    state: SingleInvoiceData?.to?.state?.name,
    country: SingleInvoiceData?.to?.country?.name,
    contact_number: SingleInvoiceData?.to?.contact_number
      ? SingleInvoiceData?.to?.contact_number
      : SingleInvoiceData?.custom_client?.contact_number,
    invoice_logo: SingleInvoiceData?.invoice_logo,
    invoice_number: SingleInvoiceData?.invoice_number,
    client_id: SingleInvoiceData?.to?._id,
    due_date: SingleInvoiceData?.due_date
      ? new Date(SingleInvoiceData?.due_date)
      : new Date(),
    invoice_date: SingleInvoiceData?.invoice_date
      ? new Date(SingleInvoiceData?.invoice_date)
      : new Date(),
    invoice_content: SingleInvoiceData?.invoice_content || [],
    memo: SingleInvoiceData?.memo,
    termsandcondition: SingleInvoiceData?.terms_conditions || '',
    currency: SingleInvoiceData?.currency_id,
    discount: SingleInvoiceData?.discount || 0,
    recurrence_pattern: SingleInvoiceData?.recurrence_pattern
      ? SingleInvoiceData?.recurrence_pattern
      : '',
    weekly_recurrence_days: SingleInvoiceData?.weekly_recurrence_days
      ? SingleInvoiceData?.weekly_recurrence_days
      : [],
    recurrence_end_date: SingleInvoiceData?.recurrence_end_date
      ? moment(SingleInvoiceData?.recurrence_end_date).toDate()
      : null,
    recurrence_start_date: SingleInvoiceData?.recurrence_start_date
      ? moment(SingleInvoiceData?.recurrence_start_date).toDate()
      : null,
    recurrence_start_at_time: SingleInvoiceData?.recurrence_time
      ? parseTimeToDate(SingleInvoiceData?.recurrence_time)
      : null,
    // recurrence_interval:
    //   SingleInvoiceData?.recurrence_interval > -1
    //     ? String(SingleInvoiceData?.recurrence_interval)
    //     : '',
    // alert_time_unit: meetingDataById?.alert_time_unit ? meetingDataById?.alert_time_unit : {label: '', value: ''},
    monthly_recurrence_day_of_month:
      SingleInvoiceData?.monthly_recurrence_day_of_month
        ? {
            label: String(SingleInvoiceData?.monthly_recurrence_day_of_month),
            value: String(SingleInvoiceData?.monthly_recurrence_day_of_month),
          }
        : { label: '1', value: '1' },
  };

  // OnSubmit Handler
  const handleSubmit = (values: any) => {
    values.due_date = moment(
      values.due_date,
      'ddd MMM DD YYYY HH:mm:ss'
    ).format('YYYY-MM-DD');
    values.invoice_date = moment(
      values.invoice_date,
      'ddd MMM DD YYYY HH:mm:ss'
    ).format('YYYY-MM-DD');
    values.sent = sentstatus;
    values.invoice_id = params.id;
    // const formData = values
    // formData.invoice_id = params.id,
    const invoice_id = params?.id;

    const custom_client = {
      name: values?.name,
      address: values?.address,
      email: values?.email,
      contact_number: values?.contact_number,
      client_logo: values?.client_logo,
    };

    const formdata: any = new FormData();
    // formdata.append('custom_client', JSON.stringify(custom_client));
    formdata.append('sent', values?.sent);
    formdata.append('sentInChat', sendChat);
    formdata.append('invoice_logo', values?.invoice_logo);
    formdata.append('invoice_number', values?.invoice_number);
    formdata.append('client_id', values?.client_id);
    formdata.append('due_date', values?.due_date);
    formdata.append('invoice_date', values?.invoice_date);
    formdata.append('invoice_content', JSON.stringify(values.invoice_content));
    formdata.append('memo', values?.memo);
    formdata.append('terms_conditions', values?.termsandcondition);
    formdata.append('discount', values?.discount);
    formdata.append('currency', values?.currency);
    formdata.append('invoice_id', invoice_id);

    if (isRecurring) {
      formdata.append('recurrence_pattern', values?.recurrence_pattern || null);
      formdata.append(
        'recurrence_start_date',
        values?.recurrence_start_date
          ? moment(values?.recurrence_start_date).format('DD-MM-YYYY')
          : null
      );
      formdata.append(
        'recurrence_end_date',
        values?.recurrence_end_date
          ? moment(values?.recurrence_end_date).format('DD-MM-YYYY')
          : null
      );
      formdata.append(
        'recurrence_time',
        values?.recurrence_start_at_time
          ? moment(values?.recurrence_start_at_time).format('HH:mm')
          : null
      );
      // formdata.append(
      //   'recurrence_interval',
      //   values?.recurrence_interval ? Number(values?.recurrence_interval) : null
      // );

      if (
        values?.recurrence_pattern === 'weekly' &&
        Array.isArray(values?.weekly_recurrence_days)
      ) {
        values.weekly_recurrence_days.forEach((day: any) => {
          formdata.append('weekly_recurrence_days', day);
        });
      }

      if (values?.recurrence_pattern === 'monthly') {
        formdata.append(
          'monthly_recurrence_day_of_month',
          values?.monthly_recurrence_day_of_month
            ? Number(values?.monthly_recurrence_day_of_month.value)
            : null
        );
      }
    }

    dispatch(updateInvoice({ data: formdata, invoice_id: invoice_id })).then(
      (result: any) => {
        if (updateInvoice.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            router.replace(routes.invoice(defaultWorkSpace?.name));
            reference_id
              ? router.replace(
                  routes.clients.details(
                    defaultWorkSpace?.name,
                    clientSliceData?._id
                  )
                )
              : router.replace(routes.invoice(defaultWorkSpace?.name));
          }
        }
      }
    );
  };

  // OnRecurring Handler
  const handleRecurringSubmit = (values: any) => {
    values.due_date = moment(
      values.due_date,
      'ddd MMM DD YYYY HH:mm:ss'
    ).format('YYYY-MM-DD');
    values.invoice_date = moment(
      values.invoice_date,
      'ddd MMM DD YYYY HH:mm:ss'
    ).format('YYYY-MM-DD');
    values.sent = sentstatus;
    values.invoice_id = params.id;
    // const formData = values
    // formData.invoice_id = params.id,
    const invoice_id = params?.id;

    const formdata: any = new FormData();

    formdata.append('invoice_id', invoice_id);
    formdata.append('isRecurringUpdate', true);

    if (isRecurring) {
      formdata.append('recurrence_pattern', values?.recurrence_pattern || null);
      formdata.append(
        'recurrence_start_date',
        values?.recurrence_start_date
          ? moment(values?.recurrence_start_date).format('DD-MM-YYYY')
          : null
      );
      formdata.append(
        'recurrence_end_date',
        values?.recurrence_end_date
          ? moment(values?.recurrence_end_date).format('DD-MM-YYYY')
          : null
      );
      formdata.append(
        'recurrence_time',
        values?.recurrence_start_at_time
          ? moment(values?.recurrence_start_at_time).format('HH:mm')
          : null
      );
      // formdata.append(
      //   'recurrence_interval',
      //   values?.recurrence_interval ? Number(values?.recurrence_interval) : null
      // );

      if (
        values?.recurrence_pattern === 'weekly' &&
        Array.isArray(values?.weekly_recurrence_days)
      ) {
        values.weekly_recurrence_days.forEach((day: any) => {
          formdata.append('weekly_recurrence_days', day);
        });
      }

      if (values?.recurrence_pattern === 'monthly') {
        formdata.append(
          'monthly_recurrence_day_of_month',
          values?.monthly_recurrence_day_of_month
            ? Number(values?.monthly_recurrence_day_of_month.value)
            : null
        );
      }
    }

    dispatch(updateInvoice({ data: formdata, invoice_id: invoice_id })).then(
      (result: any) => {
        if (updateInvoice.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            router.replace(routes.invoice(defaultWorkSpace?.name));
            reference_id
              ? router.replace(
                  routes.clients.details(
                    defaultWorkSpace?.name,
                    clientSliceData?._id
                  )
                )
              : router.replace(routes.invoice(defaultWorkSpace?.name));
          }
        }
      }
    );
  };

  // // Inside the onChange event handler of the Select component
  // const handleClientChange = (e: any, setFieldValue: any) => {
  //   if (e?.value !== selectedClient?.value) {
  //     // Check if the selected client has changed
  //     setFieldValue('client_id', e?.value);
  //     setselectedClient(e);
  //   }
  // };
  // Dropdown style
  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      cursor: 'pointer',
      backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
      color: state.isSelected ? 'black' : 'black',
      padding: '8px',
    }),
  };

  // Inside the onChange event handler of the Select component
  const handleClientChange = (
    e: any,
    setFieldValue: any,
    validateField: any,
    setFieldTouched: any
  ) => {
    if (e?.__isNew__ || e?.value == '') {
      setFieldValue('contact_number', '', true);
      setFieldValue('client_logo', '', true);
      setFieldValue('name', e?.value, true);
      setFieldValue('client_id', '', true);
      setFieldValue('email', '', true);
      setFieldValue('address', '', true);
      setFieldValue('city', '', true);
      setFieldValue('state', '', true);
      setFieldValue('country', '', true);
      setFieldValue('pincode', '', true);

      setTimeout(() => {
        validateField('name');
        setFieldTouched('address', false, false);
        setFieldValue('city', false, false);
        setFieldValue('state', false, false);
        setFieldValue('country', false, false);
        setFieldValue('pincode', false, false);
        setFieldTouched('email', false, false);
        setFieldTouched('client_logo', false, false);
        setFieldValue('client_id', '', false, false);
      }, 0);
      setclientInputvalue(false);
    } else {
      const formattedAddress = `${
        e?.key?.address && e?.key?.address !== ' ' ? e.key.address + ' ,' : ''
      } ${
        e?.key?.city?.name && e.key.city.name !== ' '
          ? e.key.city.name + ' ,'
          : ''
      } ${
        e?.key?.state?.name && e.key.state.name !== ' '
          ? e.key.state.name + ' ,'
          : ''
      } ${
        e?.key?.country?.name && e.key.country.name !== ' '
          ? e.key.country.name + ' ,'
          : ''
      } ${e?.key?.pincode && e.key.pincode !== ' ' ? e.key.pincode + ' ,' : ''}`
        .replace(/,\s*$/, '')
        .trim();

      setFieldValue('contact_number', e?.key?.contact_number, true);
      // setFieldValue('client_id', e?.value, true);
      setFieldValue('name', e?.label, true);
      setFieldValue('address', e?.key?.address, true);
      setFieldValue('country', e.key.country, true);
      setFieldValue('city', e.key.city, true);
      setFieldValue('state', e?.key?.state, true);
      setFieldValue('pincode', e.key?.pincode, true);
      setFieldValue('email', e?.key?.email, true);
      setFieldValue('client_logo', e?.key?.client_logo, true);
      setFieldValue('client_id', e?.key?._id, true);

      setTimeout(() => {
        validateField('name');
        validateField('email');
        validateField('contact_number');
        validateField('address');
        validateField('client_logo');
        validateField('client_id');
      }, 0);
      setclientInputvalue(true);
    }
    setSelectedClient(e);
  };

  // Inside the onChange event handler of the Select component
  const handleCurrencyChange = (e: any, setFieldValue: any) => {
    if (e?.value !== selectedcureency?.value) {
      // Check if the selected client has changed
      setFieldValue('currency', e?.value);
      setselectedcureency(e);
    }
  };

  // const handleDrop = (acceptedFiles: any) => {
  //   const file = acceptedFiles[0];
  //   const fileType = file?.type;

  //   // Check if the uploaded file is a JPG or PNG image
  //   if (
  //     fileType === 'image/jpeg' ||
  //     fileType === 'image/png' ||
  //     fileType === 'image/jpg'
  //   ) {
  //     const fileUrl = URL.createObjectURL(file);
  //     // setValue("board_image", file)
  //     logoimageref.current('invoice_logo', file);
  //     setpreviewImage(fileUrl);
  //     setimagesetFlag(true);
  //   } else {
  //     setpreviewImage(fileImage);
  //     logoimageref.current('invoice_logo', file);
  //     // Optionally, handle the case where the file is not a JPG or PNG image
  //     console.error('Invalid file type. Only JPG and PNG images are allowed.');
  //   }
  // };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const fileType = file.type;

    // Check if the uploaded file is a JPG or PNG image
    if (
      fileType === 'image/jpeg' ||
      fileType === 'image/png' ||
      fileType === 'image/jpg'
    ) {
      const fileUrl = URL.createObjectURL(file);
      logoimageref.current('invoice_logo', file);
      setpreviewImage(fileUrl);
      setimagesetFlag(true);
    } else {
      setpreviewImage(fileImage);
      logoimageref.current('invoice_logo', file);
      console.error('Invalid file type. Only JPG and PNG images are allowed.');
    }
  };

  // // selected file Handler
  // const handleDrop = (acceptedFiles: any) => {
  //   const file = URL.createObjectURL(acceptedFiles[0])
  //   // setValue("board_image", acceptedFiles[0])
  //   logoimageref.current('invoice_logo', acceptedFiles[0])
  //   setpreviewImage(file)
  //   setimagesetFlag(true)
  // }

  // // Dropzone Options
  // const dropzoneOptions: any = {
  //   onDrop: handleDrop,
  //   // accept: {
  //   //   'image/*': ['.jpeg', '.jpg', '.png'],
  //   // }, // Accept only JPEG and PNG images
  //   // maxSize: 6 * 1024 * 1024, // Maximum file size of 10MB
  //   multiple: false,
  //   noClick: false,
  // };

  // // useDropzone hook to handle file selection and drop
  // const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
  //   useDropzone(dropzoneOptions);

  const generateObjectId = () => {
    return (
      Math.floor(Date.now() / 1000).toString(16) + // Timestamp (8 characters)
      'xxxxxxxxxxxxxxxx'.replace(/[x]/g, () =>
        Math.floor(Math.random() * 16).toString(16)
      )
    );
  };
  // Handle form submission from child component
  // Handle form submission from child component
  const handleAddCustomer = (formData: any) => {
    console.log(formData, 'formData');

    const Myformdata = new FormData();
    // formdata.append('name', values?.name)
    // formdata.append('address', values?.address)
    // formdata.append('email', values?.email)
    // formdata.append('contact_number', values?.contact_number)
    Myformdata.append('name', formData?.name);
    Myformdata.append('email', formData?.email);
    Myformdata.append('client_logo', formData?.create_customer_logo);
    Myformdata.append('address', formData?.address);
    Myformdata.append('contact_number', formData?.contact_number);
    Myformdata.append('industry', formData?.clientIndustry);
    Myformdata.append('gst_number ', formData?.gstin);
    Myformdata.append('pan_number ', formData?.pannumber);
    Myformdata.append('tax_preference', formData?.taxPreference);
    Myformdata.append('tax_id', formData?.taxId);
    Myformdata.append('country', formData?.country);

    Myformdata.append('state', formData?.state);
    Myformdata.append('city', formData?.city);
    Myformdata.append('pincode ', formData?.pincode);

    dispatch(createCustomerapicall(Myformdata)).then((result: any) => {
      if (createCustomerapicall.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getInvoiceApi());
          closeModal();
        }
      }
    });
    setIsEditing(false);

    // const newClientOption = {
    //   label: capitalizeFirstLetter(formData.name),
    //   value: generateObjectId(), // Generate a unique ID if not provided
    //   key: formData,
    // };

    // // Add the new client option to the list
    // setClientOptions((prevOptions: any) => [...prevOptions, newClientOption]);

    // // Set the newly added client as selected
    // setNewlyAddedClient(newClientOption);
  };

  // useEffect(() => {
  //   if (newlyAddedClient) {
  //     setSelectedClient(newlyAddedClient); // Select the newly
  //     // added client
  //     setValueReference.current(
  //       'contact_number',
  //       newlyAddedClient?.key?.contact_number
  //     );
  //     setValueReference.current('client_id', newlyAddedClient?.value);

  //     setValueReference.current('name', newlyAddedClient?.key?.name);
  //     setValueReference.current('address', newlyAddedClient?.key?.address);
  //     setValueReference.current('email', newlyAddedClient?.key?.email);
  //     setValueReference.current(
  //       'client_logo',
  //       newlyAddedClient?.key?.create_customer_logo
  //     );

  //     setNewlyAddedClient(null); // Reset newly added client state
  //   }
  // }, [newlyAddedClient]);

  const handleClickOutside = (event: any) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowDropdown(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Calculate Discount
  function calculateDiscount(invoiceContent: any, discount: number) {
    const total: any = calculateTotalTax(invoiceContent);
    const discountAmount = (total * (discount || 0)) / 100;
    return discountAmount.toFixed(2);
  }

  // Calculate Total After Discount
  function calculateTotalAfterDiscount(invoiceContent: any, discount: number) {
    const total: any = calculateTotalTax(invoiceContent);
    const discountAmount = (total * (discount || 0)) / 100;
    return (total - discountAmount).toFixed(2);
  }

  console.log(selectedClient, clientOptions, 'selectedClient345666');
  const isDisabled = SingleInvoiceData?.status !== 'draft';

  const handleBulkUpload = (data: any[], setFieldValue: any, values: any) => {
    console.log('Received Bulk Data:', data);

    // Map uploaded data to match invoice_content structure
    const formattedData = data.map((row) => ({
      item: row[0] || '', // First column as item name
      tax: row[1] || 1, // Second column as quantity
      qty: row[2] || 0, // Third column as rate
      rate: row[3] || 0, // Fourth column as tax
    }));

    // Update Formik's FieldArray values
    setFieldValue('invoice_content', [
      ...values.invoice_content,
      ...formattedData,
    ]);
  };

  const handleTaskSelection = (task: any, setFieldValue: any, values: any) => {
    const formattedData = [
      {
        item: task?.title, // Task name as item
        qty: 1,
        rate: 1,
        tax: 0,
      },
    ];

    setFieldValue('invoice_content', [
      ...values.invoice_content,
      ...formattedData,
    ]);
    setIsOpen(false);
    dispatch(RemoveGetAllTasksData());
    setSelectedBoard(null);
    sethasMore(true);
    setPalyload({
      skip: 0,
      limit: 10,
      all: false,
      sort: '',
      search: '',
    });
    setTotalBoardData(0);
    setUpdateddata([]);
    setSkeletonloader(true);
    setTaskSkeletonloader(true);
    setTaskPalyload({
      ...taskpayload,
      skip: 0, // Increment skip for next batch
    });
    setTaskUpdateddata([]);
    setTotalTaskData(0);
    setTaskhasMore(true);
  };

  return (
    <>
      {InvoiceLoader || loading || getinvoiceloader ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" className="ms-3" />
        </div>
      ) : (
        <div>
          <Formik
            initialValues={initialsValue}
            validationSchema={invoiceFormSchema}
            onSubmit={isDisabled ? handleRecurringSubmit : handleSubmit}
            // enableReinitialize
          >
            {({
              values,
              isSubmitting,
              setFieldValue,
              errors,
              validateField,
              setFieldTouched,
              setFieldError,
            }: any) => (
              (setValueReference.current = setFieldValue),
              console.log(errors, 'values2345'),
              (
                <div>
                  <Form className="placeholder_color">
                    <div>
                      <CustomePageHeader
                        titleClassName="montserrat_font_title"
                        title="Edit Invoice"
                        route={routes.invoice(defaultWorkSpace?.name)}
                      >
                        {/* Form Submit Buttons  */}
                        <div
                          ref={dropdownRef}
                          className="relative flex items-center justify-end gap-3"
                        >
                          <Button
                            rounded="lg"
                            className="flex h-10 items-center justify-center gap-2 border border-[#6875F5] !bg-transparent text-sm font-semibold text-[#5850EC]"
                            onClick={() => {
                              openModal({
                                view: (
                                  <PreviewInvoice
                                    onClose={closeModal}
                                    values={values}
                                    selectedcureency={selectedcureency}
                                    calculateTotalTax={calculateTotalTax}
                                    calculateDiscount={calculateDiscount}
                                    calculateTotalAfterDiscount={
                                      calculateTotalAfterDiscount
                                    }
                                  />
                                ),
                                customSize: '611px',
                              });
                            }}
                          >
                            {' '}
                            <IoEyeOutline className="h-4 w-4" />
                            Preview
                          </Button>
                          {isDisabled ? (
                            <Button
                              type="submit"
                              // isLoading={isLoading}
                              className="mr-1 h-[40px] w-auto rounded-[8px] bg-[#7667CF] p-[12px]  text-[14px] font-[400] leading-[19.6px] text-white"
                            >
                              <span className="mr-1.5 flex items-center justify-start gap-[inherit]">
                                Update Recurring
                              </span>
                              {updateloader && (
                                <Spinner
                                  size="sm"
                                  tag="div"
                                  className="ml-2"
                                  color="white"
                                />
                              )}
                            </Button>
                          ) : (
                            <div>
                              {' '}
                              <Button
                                type="button"
                                onClick={() => {
                                  setShowDropdown((prev) => !prev);
                                }}
                                // isLoading={isLoading}
                                className="mr-1 h-[40px] w-auto rounded-[8px] bg-[#7667CF] p-[12px]  text-[14px] font-[400] leading-[19.6px] text-white"
                              >
                                <span className="mr-1.5 flex items-center justify-start gap-[inherit]">
                                  Save & Send
                                </span>
                                <div>
                                  <PiCaretDownBold className="h-4 w-4 text-white" />
                                </div>
                              </Button>
                              {showDropdown && (
                                <div
                                  className={`absolute right-0 top-full z-10 mt-2 flex  flex-col items-start  gap-[7px] rounded-[8px] !bg-white p-[10px]  shadow-lg`}
                                >
                                  <Button
                                    type="submit"
                                    onClick={() => {
                                      setsentStatus(true);
                                      setSendChat(false);
                                    }}
                                    // isLoading={isLoading}
                                    className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                                    disabled={
                                      updateloader && sentstatus && !sendChat
                                    }
                                  >
                                    Send to Email
                                    {updateloader &&
                                      sentstatus &&
                                      !sendChat && (
                                        <Spinner
                                          size="sm"
                                          tag="div"
                                          className="ml-2"
                                          color="white"
                                        />
                                      )}
                                  </Button>
                                  {!isCustomClient && (
                                    <Button
                                      type="submit"
                                      onClick={() => {
                                        setsentStatus(true);
                                        setSendChat(true);
                                      }}
                                      // isLoading={isLoading}
                                      className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                                      disabled={
                                        updateloader && sentstatus && sendChat
                                      }
                                    >
                                      Send to Chat
                                      {updateloader &&
                                        sentstatus &&
                                        sendChat && (
                                          <Spinner
                                            size="sm"
                                            tag="div"
                                            className="ml-2"
                                            color="white"
                                          />
                                        )}
                                    </Button>
                                  )}

                                  <Button
                                    type="submit"
                                    onClick={() => {
                                      setsentStatus(false);
                                    }}
                                    // isLoading={isLoading}
                                    className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                                    disabled={updateloader && !sentstatus}
                                  >
                                    Save Draft
                                    {updateloader && !sentstatus && (
                                      <Spinner
                                        size="sm"
                                        tag="div"
                                        className="ml-2"
                                        color="white"
                                      />
                                    )}
                                  </Button>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </CustomePageHeader>
                    </div>
                    {/* Image Upload section  and Schedual */}
                    <div className="mb-[10px] h-auto w-auto gap-[25px] rounded-[10px] border bg-[#FFFFFF]  pl-6 pr-6 pt-5 shadow-sm">
                      <div className="flex items-center justify-between">
                        <span className=" text-base font-semibold leading-[19.2px] text-[#4B5563]">
                          Basic details
                        </span>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-medium text-[#141414]">
                            Created with
                          </span>
                          <Image
                            src={syncUppLogo}
                            alt="Syncupp"
                            width={100}
                            height={100}
                            className="h-7 w-[60px]"
                          />
                        </div>
                      </div>
                      <div className="mb-5 mt-5 grid grid-cols-1 items-center">
                        {previewImage ? (
                          <div className="flex items-center justify-start">
                            <Image
                              alt="invoice_logo"
                              className="mr-3"
                              src={
                                !imagesetFlag
                                  ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${previewImage}`
                                  : previewImage
                              }
                              width={100}
                              height={100}
                            />
                            {!isDisabled && (
                              <TrashIcon
                                className="ms-4 h-5 w-5 cursor-pointer"
                                onClick={() => {
                                  setpreviewImage(null);
                                  setFieldValue('invoice_logo', null);
                                }}
                              />
                            )}
                          </div>
                        ) : (
                          <div>
                            <div
                              // {...getRootProps()}
                              className={
                                isDisabled
                                  ? 'pointer-events-none opacity-50'
                                  : 'w-fit'
                              }
                            >
                              <input
                                // {...getInputProps()}
                                type="file"
                                accept="image/png, image/jpeg, image/jpg"
                                className="hidden"
                                id="file-upload"
                                onChange={handleFileChange}
                                disabled={isDisabled}
                              />
                              <label
                                htmlFor="file-upload"
                                className="flex h-auto w-[242px] cursor-pointer flex-col gap-[10px] rounded-[10px] border border-dashed border-[#B7C2D3] bg-[#F8FAFF] p-4 pb-[16px] pt-[16px]"
                                onClick={() => {
                                  if (!isDisabled) {
                                    logoimageref.current = setFieldValue;
                                  }
                                }}
                              >
                                <div className="flex w-full justify-center">
                                  <Image
                                    alt="img"
                                    src={fileUploadIcon}
                                    width={20}
                                    height={20}
                                    className="h-5 w-5"
                                  />
                                </div>
                                <div className="text-center font-semibold text-[#111928]">
                                  Add Business Logo
                                </div>
                                <div className="text-center font-semibold text-[#4B5563]">
                                  Resolution upto 1080x1080 px.
                                </div>
                                <div className="text-center font-semibold text-[#4B5563]">
                                  PNG or JPEG file
                                </div>
                              </label>
                            </div>
                          </div>
                        )}

                        <div className="mt-0.5 text-xs text-red">
                          {errors && errors?.invoice_logo
                            ? errors?.invoice_logo
                            : ''}
                        </div>
                      </div>
                      <div className="mb-10 grid grid-cols-1 items-baseline gap-5 md:grid-cols-2 lg:grid-cols-4">
                        <div className="">
                          <Field name="invoice_number">
                            {({ field }: any) => (
                              <Input
                                // className='w-full'
                                labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                                {...field}
                                onKeyDown={(e) => {
                                  handleKeyDownForInvoiceNumber(e);
                                }}
                                type="text"
                                label="Invoice Number *"
                                placeholder="Enter invoice number"
                                inputClassName="text-black"
                                disabled={isDisabled}
                                // error={errors.invoice_number}
                              />
                            )}
                          </Field>
                          <ErrorMessage
                            name="invoice_number"
                            component="div"
                            className="mt-0.5 text-xs text-red"
                          />
                        </div>

                        <div className="">
                          <Field name="invoice_date">
                            {({ field }: any) => (
                              <DatePicker
                                {...field}
                                labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                                className="w-full"
                                inputProps={{
                                  label: 'Invoice Date *',
                                  labelClassName:
                                    ' font-normal text-sm leading-[16.8px] text-[#141414]',
                                  inputClassName: 'text-black',
                                }}
                                placeholderText="Select Date"
                                onChange={(date: Date) => {
                                  setinvoiceformDate(date);
                                  setFieldValue('invoice_date', date);
                                }}
                                selected={invoiceformDate} // Set the selected date value
                                disabled={isDisabled}
                              />
                            )}
                          </Field>
                          <ErrorMessage
                            name="invoice_date"
                            component="div"
                            className="mt-0.5 text-xs text-red"
                          />
                        </div>

                        <div className=" ">
                          <Field name="due_date">
                            {({ field }: any) => (
                              <DatePicker
                                {...field}
                                className="w-full"
                                inputProps={{
                                  label: 'Due Date *',
                                  labelClassName:
                                    ' font-normal text-sm leading-[16.8px] text-[#141414]',
                                  inputClassName: 'text-black',
                                  // error: errors?.due_date,
                                }}
                                minDate={invoiceformDate}
                                placeholderText="Select Date"
                                onChange={(date: Date) => {
                                  setDueDate(date);
                                  setFieldValue('due_date', date);
                                  // Update the form field value
                                }}
                                selected={dueDate} // Set the selected date value
                                disabled={isDisabled}
                              />
                            )}
                          </Field>
                          <ErrorMessage
                            name="due_date"
                            component="div"
                            className="mt-0.5 text-xs text-red"
                          />
                        </div>

                        <div>
                          <Field name="currency">
                            {({ field }: FieldProps<any>) => (
                              <Select
                                {...field}
                                labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                                onChange={(e) => {
                                  handleCurrencyChange(e, setFieldValue);
                                }}
                                options={CurrencyOptions}
                                value={selectedcureency?.name}
                                label="Currency*"
                                color="info"
                                className="w-full"
                                selectClassName="!text-black poppins_font_number"
                                dropdownClassName="!text-black poppins_font_number"
                                disabled={isDisabled}
                              />
                            )}
                          </Field>
                          <ErrorMessage
                            name="currency"
                            component="div"
                            className="mt-0.5 text-xs text-red"
                          />
                        </div>
                      </div>
                    </div>
                    {/*Customer details*/}
                    <div className="mb-[10px] h-auto w-auto gap-[25px] rounded-[10px] border bg-[#FFFFFF] p-[30px] shadow-sm">
                      {/* To Input Selection  */}
                      <div>
                        <span className=" text-base font-semibold leading-[19.2px] text-[#4B5563]">
                          Customer details
                        </span>
                        {selectedClient && !isEditing ? (
                          <div className="mt-2 flex items-center gap-5">
                            <div className="relative mt-5 w-full gap-[20px] rounded-[12px] bg-[#E3E9EE] p-[10px] lg:w-[460px]">
                              <div className="flex place-items-center justify-start p-3">
                                <p className="font-dm-sans text-[20px] font-semibold leading-[30px] tracking-[0.5%] text-[#111928]">
                                  Billed To:
                                </p>
                              </div>
                              {/* Edit Icon */}
                              {!isDisabled && (
                                <button
                                  className="absolute right-3 top-3 flex items-center justify-center  p-[8px] hover:bg-[#E5E7EB]"
                                  onClick={() => {
                                    setIsEditing(true);
                                    setSelectedClient(null);
                                    setFieldValue('name', '');
                                    setIsCustomClient(false);
                                  }}
                                  disabled={isDisabled}
                                >
                                  <FiEdit className="text-[18px] text-[#111928]" />
                                </button>
                              )}
                              <div className="px-3 pb-3 pt-0">
                                {values?.client_logo ? (
                                  <Image
                                    alt="img"
                                    className="mb-1"
                                    src={
                                      process.env.NEXT_PUBLIC_IMAGE_URL +
                                      '/' +
                                      values?.client_logo
                                    }
                                    width={40}
                                    height={40}
                                  />
                                ) : (
                                  <Image
                                    alt="img"
                                    className="mb-1"
                                    src={profilePlaceholder}
                                    width={40}
                                    height={40}
                                  />
                                )}

                                <p className="font-dm-sans text-[18px] font-medium leading-[30px] tracking-[0.5%] text-[#111928]">
                                  {capitalizeFirstLetter(values?.name)}
                                </p>
                                <p className="font-dm-sans text-[16px] font-normal leading-[27px] tracking-[0.5%] text-[#111928]">
                                  Address:{' '}
                                  {formatAddress(
                                    values?.address,
                                    values?.city,
                                    values?.state,
                                    values?.country,
                                    values?.pincode
                                  ) || 'No address provided'}
                                </p>
                                <p className="font-dm-sans text-[16px] font-normal leading-[27px] tracking-[0.5%] text-[#111928]">
                                  Email: {values?.email}
                                </p>
                                <p className="font-dm-sans text-[16px] font-normal leading-[27px] tracking-[0.5%] text-[#111928]">
                                  Contact number: {values?.contact_number}
                                </p>
                              </div>
                            </div>
                            <div className="mt-5 w-full gap-[20px] rounded-[12px] bg-[#E5E7EB] p-[10px] lg:w-[460px]">
                              <div className="flex place-items-center justify-start p-3">
                                <p className="font-dm-sans text-[20px] font-semibold leading-[30px] tracking-[0.5%] text-[#111928] ">
                                  Billed by:
                                </p>
                              </div>
                              <div className="px-3 pb-3 pt-0">
                                <Image
                                  alt="img"
                                  className="mb-1"
                                  src={profilePlaceholder}
                                  width={40}
                                  height={40}
                                />
                                <p className="font-dm-sans text-[18px] font-medium leading-[30px] tracking-[0.5%] text-[#111928] ">
                                  {workspaceCreatorData &&
                                  Object.keys(workspaceCreatorData)?.length
                                    ? capitalizeFirstLetter(
                                        workspaceCreatorData?.data?.first_name
                                      ) +
                                      ' ' +
                                      capitalizeFirstLetter(
                                        workspaceCreatorData?.data?.last_name
                                      )
                                    : `${userProfile?.first_name ?? ''} ${
                                        userProfile?.last_name ?? ''
                                      }`}
                                </p>
                                <p className="font-dm-sans text-[16px] font-normal leading-[27px] tracking-[0.5%] text-[#111928]">
                                  Address:{' '}
                                  {workspaceCreatorData &&
                                  Object.keys(workspaceCreatorData)?.length > 0
                                    ? formatAddress(
                                        workspaceCreatorData?.data?.address,
                                        workspaceCreatorData?.data?.city?.name,
                                        workspaceCreatorData?.data?.state?.name,
                                        workspaceCreatorData?.data?.country
                                          ?.name,
                                        workspaceCreatorData?.data?.pincode
                                      )
                                    : `${
                                        userProfile?.address &&
                                        userProfile?.address !== ''
                                          ? userProfile?.address + ' ,'
                                          : ''
                                      } ${
                                        userProfile?.city?.name &&
                                        userProfile?.city?.name !== ''
                                          ? userProfile?.city?.name + ' ,'
                                          : ''
                                      } ${
                                        userProfile?.state?.name &&
                                        userProfile?.state?.name !== ''
                                          ? userProfile?.state?.name + ' ,'
                                          : ''
                                      } ${
                                        userProfile?.country?.name &&
                                        userProfile?.country?.name !== ''
                                          ? userProfile?.country?.name + ' ,'
                                          : ''
                                      } ${
                                        userProfile?.pincode &&
                                        userProfile?.pincode !== ''
                                          ? userProfile?.pincode + ' ,'
                                          : ''
                                      }`}
                                </p>
                                <p className="font-dm-sans text-[16px] font-normal leading-[27px] tracking-[0.5%] text-[#111928]">
                                  Email:{' '}
                                  {workspaceCreatorData &&
                                  Object.keys(workspaceCreatorData)?.length > 0
                                    ? workspaceCreatorData?.data?.email
                                    : `${
                                        userProfile?.email &&
                                        userProfile?.email != ''
                                          ? userProfile?.email
                                          : ''
                                      }`}
                                </p>
                                <p className="font-dm-sans text-[16px] font-normal leading-[27px] tracking-[0.5%] text-[#111928]">
                                  Contact number:{' '}
                                  {workspaceCreatorData &&
                                  Object.keys(workspaceCreatorData)?.length > 0
                                    ? workspaceCreatorData?.data?.contact_number
                                    : userProfile?.contact_number &&
                                        userProfile?.contact_number != ''
                                      ? userProfile?.contact_number
                                      : ''}
                                </p>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="mt-7 flex h-auto w-full flex-wrap items-end gap-3 md:h-[54px] md:flex-nowrap">
                            <div className="w-full md:w-[536px]">
                              <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                                Select Customer
                              </span>
                              <Field name="name">
                                {({ field }: FieldProps<any>) => (
                                  <ReactSelect
                                    placeholder="Select customer"
                                    className="poppins_font_number mt-1.5 w-full text-black"
                                    classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
                                    value={selectedClient}
                                    options={clientOptions}
                                    isDisabled={!!reference_id || isDisabled}
                                    // isClearable={false}
                                    styles={customStyles}
                                    onChange={(e) => {
                                      setIsCustomClient(
                                        e?.key?.is_custom_client
                                      );
                                      handleClientChange(
                                        e,
                                        setFieldValue,
                                        validateField,
                                        setFieldTouched
                                      );
                                      setIsEditing(false);
                                    }}
                                  />
                                )}
                              </Field>
                              <ErrorMessage
                                name="name"
                                component="div"
                                className="absolute mt-0.5 text-xs text-red"
                              />
                            </div>
                            <div>
                              <Button
                                className="h-[36px] w-auto border border-[#6875F5]  text-[14px] font-semibold leading-[19.6px] text-[#5850EC]"
                                variant="outline"
                                type="button"
                                disabled={isDisabled}
                                onClick={() => {
                                  openModal({
                                    view: (
                                      <CreateCustomer
                                        onSubmit={handleAddCustomer}
                                        onClose={closeModal}
                                      />
                                    ),
                                    customSize: '840px',
                                  });
                                }}
                              >
                                Add new customer
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/*Item details*/}
                    <div className="mb-4 h-auto w-full rounded-md border bg-white p-4 shadow-sm lg:p-6">
                      <div>
                        <span className=" text-base font-semibold leading-5 text-gray-600">
                          Item details
                        </span>
                        <div>
                          <FieldArray name="invoice_content">
                            {({ push, remove }) => (
                              <div>
                                <div className="mt-5 flex justify-start gap-3">
                                  <Button
                                    onClick={() =>
                                      push({
                                        item: '',
                                        // description: '',
                                        qty: 1,
                                        rate: 0,
                                        tax: 0,
                                      })
                                    }
                                    type="button"
                                    className="h-9 w-auto rounded-md bg-[#ECEDFF]  text-sm font-semibold leading-5 text-[#42389D]"
                                    disabled={
                                      values.invoice_content.some(
                                        (field: any) =>
                                          Object.values(field).some(
                                            (innerField) => innerField === ''
                                          )
                                      ) || isDisabled
                                    }
                                  >
                                    Add new row
                                  </Button>
                                  <div
                                    className="relative"
                                    ref={taskuploaddropdownRef}
                                  >
                                    <Button
                                      type="button"
                                      className="flex h-9 w-auto items-center rounded-md bg-[#ECEDFF] px-3  text-sm font-semibold leading-5 text-[#42389D]"
                                      disabled={isDisabled}
                                      onClick={() => {
                                        setIsOpen(!isOpen);
                                        if (!isOpen) {
                                          dispatch(RemoveGetAllTasksData());
                                          sethasMore(true);
                                          setPalyload({
                                            skip: 0,
                                            limit: 10,
                                            all: false,
                                            sort: '',
                                            search: '',
                                          });
                                          setTotalBoardData(0);
                                          setUpdateddata([]);
                                          setSkeletonloader(true);
                                          setTaskSkeletonloader(true);
                                          setTaskPalyload({
                                            ...taskpayload,
                                            skip: 0, // Increment skip for next batch
                                          });
                                          setTaskUpdateddata([]);
                                          setTotalTaskData(0);
                                          setTaskhasMore(true);
                                        }
                                      }}
                                    >
                                      Import task as item
                                      <IoIosArrowDown className="ml-2" />
                                    </Button>
                                    {isOpen && (
                                      <div className="absolute left-0 z-50 mt-3 h-auto w-[510px] gap-[16px] rounded-[8px] border border-gray-100 bg-[#FFFFFF] p-[10px] shadow-lg">
                                        <div className="flex">
                                          {/* Boards List */}
                                          <div className="w-1/3 border-r border-[#E5E7EB] pr-2">
                                            <h3 className="mb-2 ml-1  text-[12px] font-semibold leading-[16.8px] text-[#111928]">
                                              Board
                                            </h3>
                                            <SimpleBar
                                              onScrollCapture={handleScroll}
                                              className="max-h-[33vh] overflow-y-auto"
                                            >
                                              {skeletonLoader
                                                ? // Skeleton for boards
                                                  [...Array(5)].map(
                                                    (_, index) => (
                                                      <div
                                                        key={index}
                                                        className="p-2"
                                                      >
                                                        {/* <Skeleton className="mb-1.5 h-4 w-28 rounded" /> */}
                                                        <Skeleton className="h-8 w-full rounded" />
                                                      </div>
                                                    )
                                                  )
                                                : updatedData?.map(
                                                    (board: any) => (
                                                      <div
                                                        key={board._id}
                                                        className={`mb-1 flex cursor-pointer items-center justify-between rounded-md p-2  text-[12px] leading-[16.8px] ${
                                                          selectedBoard?._id ===
                                                          board?._id
                                                            ? 'rounded-[4px] bg-[#DCD7FE]  font-medium text-[#111928]'
                                                            : 'font-medium text-[#111928] hover:bg-[#DCD7FE]'
                                                        }`}
                                                        onClick={() => {
                                                          setSelectedBoard(
                                                            board
                                                          );
                                                          setTaskSkeletonloader(
                                                            true
                                                          );
                                                          setTaskPalyload({
                                                            ...taskpayload,
                                                            skip: 0, // Increment skip for next batch
                                                          });
                                                          setTaskUpdateddata(
                                                            []
                                                          );
                                                          setTotalTaskData(0);
                                                          setTaskhasMore(true);
                                                        }}
                                                      >
                                                        <span className="w-28 truncate">
                                                          {capitalizeFirstLetter(
                                                            board?.project_name
                                                          )}
                                                        </span>
                                                        <MdKeyboardArrowRight className="h-[16px] w-[16px]" />
                                                      </div>
                                                    )
                                                  )}
                                              {hasMore && (
                                                <div className="flex w-full items-center justify-center">
                                                  <Button
                                                    variant="text"
                                                    size="sm"
                                                    isLoading={true}
                                                    className="flex w-full items-center justify-center"
                                                  />
                                                </div>
                                              )}
                                            </SimpleBar>
                                          </div>

                                          {/* Task List */}
                                          <div className="w-2/3 pl-2">
                                            <h3 className="mb-2 ml-1  text-[12px] font-semibold leading-[16.8px] text-[#111928]">
                                              Select Task
                                            </h3>
                                            <SimpleBar
                                              onScrollCapture={handleTaskScroll}
                                              className="max-h-[33vh] overflow-y-auto overflow-x-hidden"
                                              id="task-container"
                                            >
                                              {taskskeletonLoader ? (
                                                // Skeleton for tasks
                                                [...Array(5)].map(
                                                  (_, index) => (
                                                    <div
                                                      key={index}
                                                      className="p-2"
                                                    >
                                                      {/* <Skeleton className="mb-1.5 h-4 w-48 rounded" /> */}
                                                      <Skeleton className="h-8 w-full rounded" />
                                                    </div>
                                                  )
                                                )
                                              ) : taskupdatedData?.length >
                                                0 ? (
                                                taskupdatedData?.map(
                                                  (task: any) => (
                                                    <div
                                                      key={task?._id}
                                                      className="w-[301px] cursor-pointer truncate rounded-md p-2  text-[12px] font-medium leading-[16.8px] text-[#111928] hover:bg-[#DCD7FE]"
                                                      onClick={() =>
                                                        handleTaskSelection(
                                                          task,
                                                          setFieldValue,
                                                          values
                                                        )
                                                      }
                                                    >
                                                      {capitalizeFirstLetter(
                                                        task?.title
                                                      )}
                                                    </div>
                                                  )
                                                )
                                              ) : (
                                                <div className="text-sm text-gray-500">
                                                  No tasks available
                                                </div>
                                              )}
                                              {taskhasMore && (
                                                <div className="flex w-full items-center justify-center">
                                                  <Button
                                                    variant="text"
                                                    size="sm"
                                                    isLoading={true}
                                                    className="flex w-full items-center justify-center"
                                                  />
                                                </div>
                                              )}
                                            </SimpleBar>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  </div>

                                  <Button
                                    className="flex h-9 w-auto items-center rounded-md bg-[#ECEDFF] px-3  text-sm font-semibold leading-5 text-[#42389D]"
                                    onClick={() =>
                                      openModal({
                                        view: (
                                          <ItemBulkUpload
                                            label="Bulk upload Items"
                                            accept="csvAndXls"
                                            multiple={false}
                                            // btnLabel="Import File"
                                            isClientModule={false}
                                            isAgencyTeamModule={false}
                                            isClientTeamModule={false}
                                            isTaskModule={false}
                                            onUpload={(data: any) =>
                                              handleBulkUpload(
                                                data,
                                                setFieldValue,
                                                values
                                              )
                                            }
                                          />
                                        ),
                                        customSize: '616px',
                                      })
                                    }
                                    disabled={isDisabled}
                                  >
                                    Add items in bulk
                                    <IoIosArrowDown className="ml-2" />
                                  </Button>
                                </div>

                                <div className="mt-5 space-y-4 rounded-[4px] border border-[#E5E7EB] bg-[#F3F4F6] p-6">
                                  {values.invoice_content.map(
                                    (content: any, index: any) => (
                                      <div key={index}>
                                        <div className="flex flex-wrap gap-4">
                                          <div className="min-w-[175px] flex-1">
                                            <Field
                                              name={`invoice_content[${index}].item`}
                                            >
                                              {({
                                                field,
                                                meta,
                                              }: FieldProps) => (
                                                <Input
                                                  disabled={isDisabled}
                                                  onKeyDown={handleKeyDown}
                                                  {...field}
                                                  label="Item name *"
                                                  placeholder="Enter Item Name"
                                                  labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                                  inputClassName="text-black rounded-[10px] border border-[#D4D4D4] bg-[#FFFFFF] w-full"
                                                />
                                              )}
                                            </Field>
                                            <ErrorMessage
                                              name={`invoice_content[${index}].item`}
                                              component="div"
                                              className="mt-1 text-xs text-red-500"
                                            />
                                          </div>

                                          <div className="w-36">
                                            <Field
                                              name={`invoice_content[${index}].tax`}
                                            >
                                              {({
                                                field,
                                                meta,
                                              }: FieldProps) => (
                                                <Input
                                                  disabled={isDisabled}
                                                  {...field}
                                                  label="Tax *"
                                                  type="number"
                                                  maxLength={3}
                                                  placeholder="15"
                                                  onKeyDown={(e: any) => {
                                                    handleKeyDownFor100(e);
                                                  }}
                                                  suffix="%"
                                                  labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                                  inputClassName="text-black rounded-[10px] border border-[#D4D4D4] bg-[#FFFFFF] w-full"
                                                />
                                              )}
                                            </Field>
                                            <ErrorMessage
                                              name={`invoice_content[${index}].tax`}
                                              component="div"
                                              className="mt-1 text-xs text-red-500"
                                            />
                                          </div>

                                          <div className="w-20">
                                            <Field
                                              name={`invoice_content[${index}].qty`}
                                            >
                                              {({
                                                field,
                                                meta,
                                              }: FieldProps) => (
                                                <Input
                                                  disabled={isDisabled}
                                                  {...field}
                                                  label="Quantity *"
                                                  type="number"
                                                  min={1}
                                                  placeholder="1"
                                                  labelClassName="text-[#141414]   font-normal text-[14px] leading-[16.8px]"
                                                  onKeyDown={handleKeyDown}
                                                  inputClassName="text-black rounded-[10px] border border-[#D4D4D4] bg-[#FFFFFF] w-full"
                                                  // suffix={
                                                  //   <>
                                                  //     <ActionIcon
                                                  //       title="Decrement"
                                                  //       size="sm"
                                                  //       variant="outline"
                                                  //       className="scale-90 shadow-sm"
                                                  //       onClick={() => {
                                                  //         setFieldValue(
                                                  //           `invoice_content[${index}].qty`,
                                                  //           +values
                                                  //             .invoice_content[
                                                  //             index
                                                  //           ]?.qty > 0
                                                  //             ? +values
                                                  //                 .invoice_content[
                                                  //                 index
                                                  //               ]?.qty - 1
                                                  //             : 0
                                                  //         );
                                                  //       }}
                                                  //     >
                                                  //       <PiMinusBold
                                                  //         className="h-3.5 w-3.5"
                                                  //         strokeWidth={2}
                                                  //       />
                                                  //     </ActionIcon>
                                                  //     <ActionIcon
                                                  //       title="Increment"
                                                  //       size="sm"
                                                  //       variant="outline"
                                                  //       className="scale-90 shadow-sm"
                                                  //       onClick={() => {
                                                  //         setFieldValue(
                                                  //           `invoice_content[${index}].qty`,
                                                  //           +values
                                                  //             .invoice_content[
                                                  //             index
                                                  //           ]?.qty + 1
                                                  //         );
                                                  //       }}
                                                  //     >
                                                  //       <PiPlusBold
                                                  //         className="h-3.5 w-3.5"
                                                  //         strokeWidth={2}
                                                  //       />
                                                  //     </ActionIcon>
                                                  //   </>
                                                  // }
                                                  // suffixClassName="flex gap-1 items-center -me-2"
                                                />
                                              )}
                                            </Field>
                                            <ErrorMessage
                                              name={`invoice_content[${index}].qty`}
                                              component="div"
                                              className="mt-1 text-xs text-red-500"
                                            />
                                          </div>

                                          <div className="w-36">
                                            <Field
                                              name={`invoice_content[${index}].rate`}
                                            >
                                              {({
                                                field,
                                                meta,
                                              }: FieldProps) => (
                                                <Input
                                                  disabled={isDisabled}
                                                  onKeyDown={(event) =>
                                                    handleKeyDownForAllowNumber(
                                                      event,
                                                      7
                                                    )
                                                  }
                                                  {...field}
                                                  label="Rate *"
                                                  type="number"
                                                  prefix={
                                                    selectedcureency?.key
                                                      ?.symbol
                                                  }
                                                  placeholder="100"
                                                  labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                                  inputClassName="text-black rounded-[10px] border border-[#D4D4D4] bg-[#FFFFFF] w-full"
                                                />
                                              )}
                                            </Field>
                                            <ErrorMessage
                                              name={`invoice_content[${index}].rate`}
                                              component="div"
                                              className="mt-1 text-xs text-red-500"
                                            />
                                          </div>

                                          <div className="w-36">
                                            <Input
                                              disabled={isDisabled}
                                              type="text"
                                              label="Total amount due *"
                                              prefix={
                                                selectedcureency?.key?.symbol
                                              }
                                              value={(
                                                values.invoice_content[index]
                                                  ?.rate *
                                                  values.invoice_content[index]
                                                    ?.qty +
                                                ((values.invoice_content[index]
                                                  ?.rate *
                                                  values.invoice_content[index]
                                                    ?.qty) /
                                                  100) *
                                                  values.invoice_content[index]
                                                    ?.tax
                                              ).toFixed(2)}
                                              labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                              inputClassName="text-black rounded-[10px] border border-[#D4D4D4] bg-[#FFFFFF] w-full"
                                              readOnly
                                            />
                                          </div>

                                          {values?.invoice_content?.length !==
                                            1 && (
                                            <div
                                              className="flex h-[84px] items-center justify-center" // Match the height of input fields
                                            >
                                              <button
                                                type="button"
                                                onClick={() => remove(index)}
                                                className="flex items-center justify-center p-2"
                                                disabled={isDisabled}
                                              >
                                                <Image
                                                  src={removeIcon}
                                                  alt="Remove Icon"
                                                  className="h-4 w-4"
                                                />
                                              </button>
                                            </div>
                                          )}
                                        </div>
                                        {/* <div className="mt-3">
                                          <Field
                                            name={`invoice_content[${index}].description`}
                                          >
                                            {({ field, meta }: FieldProps) => (
                                              <Textarea
                                                disabled={isDisabled}
                                                onKeyDown={handleKeyDown}
                                                {...field}
                                                label="Description *"
                                                placeholder="Enter Item Description"
                                                labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                                className="row-start-2 @md:col-span-2 @xl:col-span-3 @xl:row-start-2 @4xl:col-span-4"
                                                textareaClassName="h-20 rounded-[10px] text-black poppins_font_number border border-[#D4D4D4] w-full bg-[#FFFFFF]"
                                              />
                                            )}
                                          </Field>
                                          <ErrorMessage
                                            name={`invoice_content[${index}].description`}
                                            component="div"
                                            className="mt-1 text-xs text-red-500"
                                          />
                                        </div> */}
                                        <div className="mb-6 ml-3 mt-4 w-auto border border-[#D1D5DB]"></div>

                                        <div>
                                          {values?.invoice_content?.length ===
                                            index + 1 && (
                                            <div className="flex items-center justify-between">
                                              {!showDiscountField && (
                                                <Button
                                                  rounded="lg"
                                                  className="flex h-10 items-center justify-center gap-2 border border-[#6875F5] !bg-transparent text-sm font-semibold text-[#5850EC]"
                                                  disabled={isDisabled}
                                                  onClick={() =>
                                                    setShowDiscountField(true)
                                                  }
                                                >
                                                  {' '}
                                                  <AiOutlinePercentage className="h-4 w-4" />
                                                  Add discount
                                                </Button>
                                              )}
                                              {/* Discount Input */}
                                              {showDiscountField && (
                                                <div className="w-[101px]">
                                                  <Field name={`discount`}>
                                                    {({
                                                      field,
                                                    }: FieldProps) => (
                                                      <Input
                                                        disabled={isDisabled}
                                                        {...field}
                                                        label="% Add discount"
                                                        type="number"
                                                        placeholder="0"
                                                        max={100}
                                                        // min={1}
                                                        labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                                        inputClassName="text-black rounded-[10px] border border-[#D4D4D4] bg-[#FFFFFF]"
                                                        suffix="%"
                                                        className="w-full"
                                                      />
                                                    )}
                                                  </Field>
                                                  <ErrorMessage
                                                    name={`discount`}
                                                    component="div"
                                                    className="mt-1 text-xs text-red-500"
                                                  />
                                                </div>
                                              )}

                                              {/* Discount Applied */}
                                              {values.discount > 0 && (
                                                <Text className="text-base font-medium text-red-500">
                                                  Discount applied:{' '}
                                                  {
                                                    selectedcureency?.key
                                                      ?.symbol
                                                  }{' '}
                                                  {calculateDiscount(
                                                    values.invoice_content,
                                                    values.discount
                                                  )}
                                                </Text>
                                              )}

                                              {/* Total Due */}
                                              <Text className="poppins_font_number text-lg font-semibold text-black">
                                                Total due:{' '}
                                                {selectedcureency?.key?.symbol}{' '}
                                                {calculateTotalAfterDiscount(
                                                  values.invoice_content,
                                                  values.discount
                                                )}
                                              </Text>
                                            </div>
                                          )}{' '}
                                        </div>
                                      </div>
                                    )
                                  )}
                                </div>
                              </div>
                            )}
                          </FieldArray>
                        </div>
                      </div>
                    </div>

                    <div className="mb-[10px] h-auto w-auto gap-[25px] rounded-[10px] border bg-[#FFFFFF]  p-[30px] shadow-sm">
                      {/* To Input Selection  */}
                      <div>
                        <span className=" text-base font-semibold leading-[19.2px] text-[#4B5563]">
                          Additional details
                        </span>
                        <div className="mt-5">
                          <Field name={`memo`} className="w-full">
                            {({ field, meta }: FieldProps) => (
                              <Textarea
                                disabled={isDisabled}
                                labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                onKeyDown={handleKeyDown}
                                {...field}
                                label="Add customer notes"
                                placeholder="Add notes"
                                // error={errors?.invoice_content?.[index]?.description}
                                className="row-start-2 @md:col-span-2 @xl:col-span-3 @xl:row-start-2 @4xl:col-span-4"
                                textareaClassName="h-20 text-black poppins_font_number  bg-[#F9FAFB]"
                              />
                            )}
                          </Field>
                          <ErrorMessage
                            name={`memo`}
                            component="div"
                            className="mt-0.5 text-xs text-red"
                          />
                        </div>
                        <div className="mt-5">
                          <span>
                            <Switch
                              className=" create-task-form-tour-step-ten  [&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                              variant="active"
                              switchClassName={`${
                                isRecurring ? '!bg-[#362F78]' : '!bg-white'
                              }`}
                              handlerClassName={`${
                                isRecurring ? '!bg-white' : '!bg-[#362F78]'
                              }`}
                              label="Recurring  invoice"
                              labelClassName="text-[#141414]"
                              labelPlacement="left"
                              onChange={(e) => {
                                const checked = e?.target?.checked;
                                setIsRecurring(checked);
                                if (checked) {
                                  setFieldValue('recurrence_pattern', 'weekly');
                                  setSelectedRecurringOption({
                                    name: 'Weekly',
                                    label: 'Weekly',
                                    value: 'weekly',
                                  });
                                } else {
                                  setFieldValue('recurrence_pattern', '');
                                  setSelectedRecurringOption({
                                    name: '',
                                    label: '',
                                    value: '',
                                  });
                                }
                              }}
                              checked={isRecurring}
                            />
                          </span>
                          {isRecurring && (
                            <div className="mt-4  w-fit rounded-lg border border-gray-300 bg-[#F9FAFB] p-4">
                              {/* First Line */}
                              <div className="mb-4 flex items-center gap-3">
                                <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                  Setup Recurring Invoice
                                </span>
                                <Select
                                  options={RecurringArray}
                                  onChange={(event) =>
                                    onChangeRecurring(event, setFieldValue)
                                  }
                                  value={selectedRecurringOption}
                                  className="w-[6.6rem]"
                                  optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                  selectClassName="!text-[#5850EC] border-[#6875F5] font-medium text-sm leading-[19.6px] h-10  border rounded-[10px]  focus:border-[#5850EC] hover:border-[#5850EC] !bg-white"
                                />
                              </div>

                              {/* Repeat every and End date */}
                              {['daily', 'weekly', 'monthly'].includes(
                                selectedRecurringOption?.value
                              ) && (
                                <div className="flex flex-wrap gap-4 sm:flex-row">
                                  <div className="w-[145px]">
                                    <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                      Starts from
                                    </span>
                                    <DatePicker
                                      selected={values.recurrence_start_date}
                                      onChange={(date) => {
                                        setFieldValue(
                                          'recurrence_start_date',
                                          date
                                        );
                                        setSelectedDate(date);
                                        if (values.recurrence_start_at_time) {
                                          setFieldValue(
                                            'recurrence_start_at_time',
                                            null
                                          ); // Reset time only if needed
                                        }
                                      }}
                                      minDate={new Date()}
                                      maxDate={values?.recurrence_end_date}
                                      placeholderText="Select date"
                                      className="mt-2 rounded-[10px] border-[#E5E7EB] bg-white text-[#111928] focus:border-primary focus:ring-primary"
                                    />
                                    <ErrorMessage
                                      name="recurrence_start_date"
                                      component="p"
                                      className="mt-1 text-sm text-red-600"
                                    />
                                  </div>

                                  {selectedRecurringOption?.value ===
                                    'weekly' && (
                                    <div>
                                      <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                        Days of the week
                                      </span>
                                      <div className="mt-2 flex gap-2">
                                        {weekdays.map((day) => (
                                          <label
                                            key={day.value}
                                            className={`flex h-10 w-10 cursor-pointer items-center justify-center rounded-full border ${
                                              values.weekly_recurrence_days.includes(
                                                day.value
                                              )
                                                ? 'bg-[#EDEBFE] text-[#42389D]'
                                                : 'bg-white text-[#4B5563]'
                                            }`}
                                          >
                                            <Field
                                              type="checkbox"
                                              name="weekly_recurrence_days"
                                              value={day.value}
                                              className="hidden"
                                              onChange={(e: any) => {
                                                const isChecked =
                                                  e.target.checked;
                                                const newValues = isChecked
                                                  ? [
                                                      ...values.weekly_recurrence_days,
                                                      day.value,
                                                    ] // Add
                                                  : values.weekly_recurrence_days.filter(
                                                      (v: any) =>
                                                        v !== day.value
                                                    ); // Remove

                                                setFieldValue(
                                                  'weekly_recurrence_days',
                                                  newValues
                                                );
                                              }}
                                            />
                                            {day.name}
                                          </label>
                                        ))}
                                      </div>
                                      <ErrorMessage
                                        name="weekly_recurrence_days"
                                        component="p"
                                        className="mt-1 text-sm text-red-600"
                                      />
                                    </div>
                                  )}

                                  {selectedRecurringOption?.value ===
                                    'monthly' && (
                                    <div>
                                      <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                        Select Day
                                      </span>
                                      <div className="mt-2 flex items-center gap-1">
                                        <Select
                                          options={monthDate}
                                          onChange={(event) =>
                                            setFieldValue(
                                              'monthly_recurrence_day_of_month',
                                              event
                                            )
                                          }
                                          value={
                                            values.monthly_recurrence_day_of_month
                                          }
                                          placeholder="Select date"
                                          className="w-[68px]"
                                          optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                          selectClassName="!text-[#5850EC] border-[#6875F5] font-medium text-sm leading-[19.6px] h-10 border rounded-[10px]  focus:border-[#5850EC] hover:border-[#5850EC] !bg-white"
                                        />
                                        <p className=" text-[12px] font-normal leading-[14.4px] text-[#111928]">
                                          of every month
                                        </p>
                                      </div>
                                      <ErrorMessage
                                        name="monthly_recurrence_day_of_month"
                                        component="p"
                                        className="mt-1 text-sm text-red-600"
                                      />
                                    </div>
                                  )}
                                  <div className="w-[136px]">
                                    <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                      At Time
                                    </span>
                                    <DatePicker
                                      className="mt-2 rounded-[10px] border-[#E5E7EB] bg-white text-[#111928] focus:border-primary focus:ring-primary"
                                      placeholderText="Start time"
                                      selected={
                                        values.recurrence_start_at_time || null
                                      }
                                      minTime={getMinTime()}
                                      maxTime={getMaxTime()}
                                      onChange={(date) => {
                                        setFieldValue(
                                          'recurrence_start_at_time',
                                          date
                                        );
                                      }}
                                      showTimeSelect
                                      showTimeSelectOnly
                                      dateFormat="hh:mm aa"
                                      // disabled={disabledMeetingTime}
                                    />
                                    <ErrorMessage
                                      name="recurrence_start_at_time"
                                      component="p"
                                      className="mt-1 text-sm text-red-600"
                                    />
                                  </div>
                                  {/* <div className="w-[165px]">
                                    <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                      Repeat every
                                    </span>
                                  
                                    <Field name="recurrence_interval">
                                      {({ field }: any) => (
                                        <Input
                                          // className='w-full'
                                          rounded="DEFAULT"
                                          type="number"
                                          labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                                          {...field}
                                          onKeyDown={handleKeyDown}
                                          min={0}
                                          // placeholder="Enter interval"
                                          inputClassName="bg-white poppins_font_number"
                                          className=" mt-2 rounded-[10px] border-[#E5E7EB] text-[#141414] focus:border-primary focus:ring-primary"

                                          // error={errors.invoice_number}
                                        />
                                      )}
                                    </Field>
                                    <ErrorMessage
                                      name="recurrence_interval"
                                      component="p"
                                      className="mt-1 text-sm text-red-600"
                                    />
                                  </div>

                                  {selectedRecurringOption?.value ===
                                    'weekly' && (
                                    <div>
                                      <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                        Days of the week
                                      </span>
                                      <div className="mt-2 flex gap-2">
                                        {weekdays.map((day) => (
                                          <label
                                            key={day.value}
                                            className={`flex h-10 w-10 cursor-pointer items-center justify-center rounded-full border ${
                                              values.weekly_recurrence_days ===
                                              day.value
                                                ? 'bg-[#EDEBFE] text-[#42389D]'
                                                : 'bg-white text-[#4B5563]'
                                            }`}
                                          >
                                            <Field
                                              type="radio"
                                              name="weekly_recurrence_days"
                                              value={day.value}
                                              className=" hidden"
                                            />
                                            {day.name}
                                          </label>
                                        ))}
                                      </div>
                                      <ErrorMessage
                                        name="weekly_recurrence_days"
                                        component="p"
                                        className="mt-1 text-sm text-red-600"
                                      />
                                    </div>
                                  )} */}

                                  {/* {selectedRecurringOption?.value ===
                                    'monthly' && (
                                    <div>
                                      <label className="text-[14px] font-medium text-[#141414]">
                                        Repeat on
                                      </label>
                                      <Select
                                        options={monthDate}
                                        onChange={(event) =>
                                          setFieldValue(
                                            'monthly_recurrence_day_of_month',
                                            event
                                          )
                                        }
                                        value={
                                          values.monthly_recurrence_day_of_month
                                        }
                                        placeholder="Select date"
                                        optionClassName="hover:bg-[#EDEAFE] hover:text-[#362F78]"
                                        selectClassName="!text-[#5850EC] border-[#6875F5] font-medium text-sm leading-[19.6px] h-10  border rounded-[10px]   focus:border-[#5850EC] hover:border-[#5850EC] !bg-white mt-2"
                                      />
                                      <ErrorMessage
                                        name="monthly_recurrence_day_of_month"
                                        component="p"
                                        className="mt-1 text-sm text-red-600"
                                      />
                                    </div>
                                  )} */}

                                  <div className="w-[145px]">
                                    <span className=" text-[14px] font-medium leading-[16.8px] text-[#111928]">
                                      Ends on
                                    </span>
                                    <DatePicker
                                      selected={values.recurrence_end_date}
                                      onChange={(date) =>
                                        setFieldValue(
                                          'recurrence_end_date',
                                          date
                                        )
                                      }
                                      minDate={
                                        values?.recurrence_start_date == null
                                          ? new Date()
                                          : values?.recurrence_start_date
                                      }
                                      placeholderText="Select date"
                                      className="mt-2 rounded-[10px] border-[#E5E7EB] bg-white text-[#111928] focus:border-primary focus:ring-primary"
                                    />
                                    <ErrorMessage
                                      name="recurrence_end_date"
                                      component="p"
                                      className="mt-1 text-sm text-red-600"
                                    />
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="mt-5">
                          {!showTermsField && (
                            <Button
                              rounded="lg"
                              className="flex h-10 items-center justify-center gap-2 border border-[#6875F5] !bg-transparent text-sm font-semibold text-[#5850EC]"
                              onClick={() => setShowTermsField(true)}
                              disabled={isDisabled}
                            >
                              {' '}
                              Add Terms and Conditions
                            </Button>
                          )}
                          {showTermsField && (
                            <div>
                              {' '}
                              <Field
                                name={`termsandcondition`}
                                className="w-full"
                              >
                                {({ field, meta }: FieldProps) => (
                                  <Textarea
                                    disabled={isDisabled}
                                    labelClassName="text-[#141414]  font-normal text-[14px] leading-[16.8px]"
                                    onKeyDown={handleKeyDown}
                                    {...field}
                                    label="Terms & Conditions"
                                    placeholder="Add terms & conditions"
                                    // error={errors?.invoice_content?.[index]?.description}
                                    className="row-start-2 @md:col-span-2 @xl:col-span-3 @xl:row-start-2 @4xl:col-span-4"
                                    textareaClassName="h-12 text-black poppins_font_number bg-[#F9FAFB]"
                                  />
                                )}
                              </Field>
                              <ErrorMessage
                                name={`termsandcondition`}
                                component="div"
                                className="mt-0.5 text-xs text-red"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </Form>
                </div>
              )
            )}
          </Formik>
        </div>
      )}
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency],
  'invoices',
  null,
  'update'
)(EditInvoice);
