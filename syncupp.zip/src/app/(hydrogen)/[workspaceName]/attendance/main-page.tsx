'use client';

import AttendanceTimer from '@/app/shared/(user)/attendance/attendanceTimer';
import { GetAttendanceColumns } from '@/app/shared/(user)/attendance/columns';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import useAccurateLocation from '@/hooks/use-accurate-location';
import useReverseGeocoding from '@/hooks/use-reverse-geocoding';
import {
  getAllUserAttendance,
  removeUserAttendanceData,
  reportDownload,
  setPagginationParams,
} from '@/redux/slices/user/attendance/attendanceSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import moment from 'moment';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { PiArrowLineDownBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect from 'react-select';

const pageHeader = {
  title: 'Attendance',
};

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#8c80d2' : 'white',
    color: state.isSelected ? 'white' : 'black',
    whiteSpace: 'normal',
    wordBreak: 'break-word',
  }),
};

function AttendanceTablePage() {
  const dispatch = useDispatch();
  const [pageSize, setPageSize] = useState(10);
  const { role, permission } = useSelector((state: any) => state?.root?.signIn);
  const {
    userAttendanceData,
    getAllUserAttendanceLoader,
    reportDownloadLoader,
  } = useSelector((state: any) => state?.root?.attendance);
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState(
    moment().startOf('month').format('DD-MM-YYYY')
  );
  const [endDate, setEndDate] = useState(
    moment().endOf('month').format('DD-MM-YYYY')
  );
  const [reset, setReset] = useState('');
  const [sortObject, setSortObject] = useState({});
  const [assignee, setAssignee] = useState<any>({
    name: 'All',
    value: '',
    label: 'All',
  });

  useEffect(() => {
    dispatch(removeUserAttendanceData());

    return () => {
      dispatch(removeUserAttendanceData());
    };
  }, [dispatch]);

  useEffect(() => {
    if (period !== '' || startDate !== '' || endDate !== '') {
      setReset('');
    }
  }, [period, startDate, endDate]);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    if (sort_field === 'createdAt') {
      sort_field = 'user_details.full_name';
      sort_order = 'asc';
    }

    setSortObject({ page, items_per_page, sort_field, sort_order, search });

    dispatch(setPagginationParams(paginationParams));
    const response = await dispatch(
      getAllUserAttendance({
        page,
        items_per_page,
        sort_field,
        sort_order,
        filter: {
          date: { start_date: startDate, end_date: endDate },
        },
        search,
        pagination: true,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllUserAttendance({
          page,
          items_per_page,
          sort_field,
          sort_order,
          filter: {
            date: { start_date: startDate, end_date: endDate },
          },
          search,
          pagination: true,
        })
      );
      return data?.teamMemberList;
    }
    if (data?.teamMemberList && data?.teamMemberList.length !== 0) {
      return data.teamMemberList;
    }
  };

  useEffect(() => {
    if (endDate) {
      dispatch(
        getAllUserAttendance({
          page: 1,
          ...sortObject,
          filter: {
            date: {
              start_date: startDate,
              end_date: endDate,
            },
          },
          pagination: true,
        })
      );
    }
  }, [dispatch, endDate, sortObject, startDate]);

  // assignee filter logic
  const handleAssigneeChange = (selectedOption: Record<string, any>) => {
    dispatch(
      getAllUserAttendance({
        ...sortObject,
        page: 1,
        filter: {
          date: {
            start_date: startDate,
            end_date: endDate,
          },
        },
        assignee_id: selectedOption?.value,
      })
    );
  };

  //  Reset Filter
  const handleResetFilters = () => {
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setReset('reset');
    setAssignee({
      name: 'All',
      value: '',
      label: 'All',
    });

    dispatch(
      getAllUserAttendance({
        sort_field: 'user_details.full_name',
        sort_order: 'asc',
        filter: {
          date: { start_date: '', end_date: '' },
        },
        pagination: true,
        ...sortObject,
        page: 1,
      })
    );
  };

  const modifyAssignList = (userList: any) => {
    if (userList?.length <= 0) {
      return userList;
    }

    const updateUserList: any[] =
      userList &&
      userList?.length > 0 &&
      userList?.map((data: any) => {
        return {
          ...data,
          label: `${capitalizeFirstLetter(
            data?.first_name
          )} ${capitalizeFirstLetter(data?.last_name)}`,
          value: data?._id,
        };
      });

    updateUserList?.unshift({
      name: 'All',
      value: '',
      label: 'All',
    });
    return updateUserList;
  };

  const FilterList = () => {
    return (
      <>
        {(['agency', 'client'].includes(role) ||
          (['team_agency', 'team_client'].includes(role) &&
            checkPermission('attendance', null, 'everyone', permission))) && (
          <ReactSelect
            options={modifyAssignList(userAttendanceData?.user_list)}
            onChange={(selectedOption: Record<string, any>) => {
              handleAssigneeChange(selectedOption);
              setAssignee(selectedOption);
            }}
            defaultValue={{
              name: 'All',
              value: '',
              label: 'All',
            }}
            value={assignee}
            placeholder="All"
            className="poppins_font_number react-select-options task-assign w-full"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            styles={customStyles}
          />
        )}
        <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
      </>
    );
  };

  //download sheet
  const AttendanceReportDownload = () => {
    // setexelbuttonloadding(true);
    dispatch(
      reportDownload({
        ...sortObject,
        filter: {
          date: {
            start_date: startDate,
            end_date: endDate,
          },
        },
        user_id: assignee?.value,
      })
    )
      .then(async (result: any) => {
        if (reportDownload.fulfilled.match(result)) {
          const blob = await result.payload;

          // Create a URL for the blob data
          const url = window.URL.createObjectURL(
            new Blob([blob], {
              type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            })
          );

          // Create a temporary anchor element
          const a = document.createElement('a');
          a.href = url;

          // Set the filename for the downloaded file
          a.download = 'Attendance Report.xlsx';

          // Programmatically click the anchor element to trigger the download
          a.click();

          // Clean up by revoking the object URL
          window.URL.revokeObjectURL(url);
        }
        console.log(result, 'download sheet');
      })
      .catch((err: any) => {
        // setexelbuttonloadding(false);
      });
  };

  return (
    <>
      <div className="flex items-center justify-between">
        <CustomePageHeader
          title={pageHeader.title}
          titleClassName="montserrat_font_title"
        />
        <div className="flex gap-4">
          {/* <AttendanceTimer /> */}
          <Button
            variant="solid"
            className="w-[30] bg-[hsl(246,46%,92%)] text-[#8C80D2] lg:w-auto"
            onClick={AttendanceReportDownload}
            disabled={reportDownloadLoader}
          >
            <PiArrowLineDownBold className="me-1.5 h-[17px] w-[17px]" />
            Export
            {reportDownloadLoader && (
              <Spinner
                size="sm"
                tag="div"
                className="ms-3 bg-[#E3E1F4] text-[#8C80D2] "
              />
            )}
          </Button>
        </div>
      </div>
      <WidgetCard rounded="lg" title="">
        <div className="table_border_remove">
          <CustomTable
            data={userAttendanceData?.attendance_history}
            total={userAttendanceData?.page_count || 0}
            loading={getAllUserAttendanceLoader}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleChangePage={handleChangePage}
            getColumns={GetAttendanceColumns}
            scroll={{ x: 1100 }}
            filtersList={<FilterList />}
            moduleName="attendance"
            setPeriod={setPeriod}
            setStartDate={setStartDate}
            setEndDate={setEndDate}
            isRangeFilter={true}
            resetValue={reset}
            isaAttendanceDate={true}
          />
        </div>
      </WidgetCard>
    </>
  );
}

export default AttendanceTablePage;
