
import { metaObject } from '@/config/site.config';
import AttendanceDetailsTablePage from './main-page';
import { useParams } from 'next/navigation';

export const metadata = {
    ...metaObject('Attendance Details'),
};

export default function Page({ params }: Readonly<{ params: { userId: string } }>) {
    return (
        <div className='main_card_block'>
            <AttendanceDetailsTablePage params={params} />
        </div>
    );
}
