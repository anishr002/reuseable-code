'use client';

import { GetAttendanceDetailsColumns } from '@/app/shared/(user)/attendance/attendance-details/columns';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { routes } from '@/config/routes';
import { deleteTrackedTime, getUserDetailsAttendance, removeUserDetailsAttendance, setDetailsPagePaginationParams, userReportDownload } from '@/redux/slices/user/attendance/attendanceSlice';
import { getHolidayData } from '@/redux/slices/user/setting/settingSlice';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { PiArrowLineDownBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';

const pageHeader = {
    title: 'Attendance Details',
};

function AttendanceDetailsTablePage({ params }: Readonly<{ params: { userId: string } }>) {
    const dispatch = useDispatch();
    const [pageSize, setPageSize] = useState(10);
    const { userDetailsAttendance,userReportDownloadLoader, getUserDetailsAttendanceLoader, detailsPagePaginationParams } = useSelector((state: any) => state?.root?.attendance);
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace);
    const [period, setPeriod] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [reset, setReset] = useState('');
    const [sortObject, setSortObject] = useState({});
    useEffect(() => {
        dispatch(removeUserDetailsAttendance());

        return () => {
            dispatch(removeUserDetailsAttendance());
        };
    }, [dispatch]);

    useEffect(() => {
        if (
            period !== '' ||
            startDate !== '' ||
            endDate !== ''
        ) {
            setReset('');
        }
    }, [period, startDate, endDate]);

    const handleChangePage = async (paginationParams: any) => {
        let { page, items_per_page, sort_field, sort_order, search } =
            paginationParams;

        sort_field = sort_field === "createdAt" ? 'date' : sort_field;

        setSortObject({ page, items_per_page, sort_field, sort_order, search });
        dispatch(setDetailsPagePaginationParams({ ...detailsPagePaginationParams, ...paginationParams, sort_field  }));
        const response = await dispatch(
            getUserDetailsAttendance({
                page,
                items_per_page,
                sort_field,
                sort_order,
                filter: {
                    date: { start_date: startDate, end_date: endDate },
                },
                user_id: params?.userId,
                search,
                pagination: true,
            })
        );
        const { data } = response?.payload;
        const maxPage: number = data?.page_count;

        if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            await dispatch(
                getUserDetailsAttendance({
                    page,
                    items_per_page,
                    sort_field,
                    sort_order,
                    filter: {
                        date: { start_date: startDate, end_date: endDate },
                    },
                    user_id: params?.userId,
                    search,
                    pagination: true,
                })
            );
            return data?.teamMemberList;
        }
        if (data?.teamMemberList && data?.teamMemberList.length !== 0) {
            return data.teamMemberList;
        };
    };

    useEffect(() => {
        if (endDate) {
            dispatch(
                getUserDetailsAttendance({
                    page: 1,
                    ...sortObject,
                    filter: {
                        date: {
                            start_date: startDate,
                            end_date: endDate,
                        },
                    },
                    user_id: params?.userId,
                    pagination: true,
                })
            );
            dispatch(setDetailsPagePaginationParams({ ...detailsPagePaginationParams, start_date: startDate, end_date: endDate }));
        }
    }, [dispatch, endDate, params?.userId, sortObject, startDate]);

    useEffect(()=>{
        dispatch(getHolidayData())
    },[])

    const handleResetFilters = () => {
        setPeriod('');
        setStartDate('');
        setEndDate('');
        setReset('reset');

        dispatch(
            getUserDetailsAttendance({
                pagination: true,
                ...sortObject,
                page: 1,
                sort_field: 'date',
                sort_order: 'desc',
                user_id: params?.userId,
            })
        );
    };

        //download sheet
        const AttendanceReportDownload = () => {
            dispatch(
              userReportDownload({
                ...sortObject,
                filter: {
                  date: {
                    start_date: startDate,
                    end_date: endDate,
                  },
                },
                user_id: params?.userId
              })
            )
              .then(async (result: any) => {
                if (userReportDownload.fulfilled.match(result)) {
                  const blob = await result.payload;
              
                  // Create a URL for the blob data
                  const url = window.URL.createObjectURL(
                    new Blob([blob], {
                      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    })
                  );
        
                  // Create a temporary anchor element
                  const a = document.createElement('a');
                  a.href = url;
        
                  // Set the filename for the downloaded file
                  a.download = 'attendance_report.xlsx';
        
                  // Programmatically click the anchor element to trigger the download
                  a.click();
        
                  // Clean up by revoking the object URL
                  window.URL.revokeObjectURL(url);
                }
                console.log(result, 'download sheet');
              })
              .catch((err: any) => {
              });
          };


    // Ḍelete the trakced time in task
    const handleDeleteById = async (
        id: string | string[],
        currentPage?: any,
        countPerPage?: number,
        sortConfig?: Record<string, string>,
        searchTerm?: string,
        row?: any
    ) => {
        try {

            // DELETE API CALL
            if (row?.logs && row?.logs?.length === 0) {
                return;
            }
            const filterAttendanceId = row?.logs?.map((log: any) => log?._id);

            const response = await dispatch(deleteTrackedTime({ timerIds: filterAttendanceId, date: row?.date, user_id: params?.userId }));
            console.log(response, 'response');

            await dispatch(
                getUserDetailsAttendance({
                    page: currentPage,
                    items_per_page: countPerPage,
                    sort_field: sortConfig?.key === 'createdAt' ? 'date' : sortConfig?.key,
                    sort_order: sortConfig?.direction,
                    search: searchTerm,
                    filter: {
                        date: { start_date: startDate, end_date: endDate },
                    },
                    user_id: params?.userId,
                    pagination: true,
                })
            );

            //   const res = await dispatch(updateDeleteTrackedTime({ timerId: id, event_type: 'delete' }));

        } catch (error) {
            console.error(error);
        }
    };

    const FilterList = () => {
        return (
            <div>
                <Button
                    className="flex h-[40px] items-center justify-center rounded-3xl bg-[#E3E1F4] px-[40px] text-sm text-[#8C80D2]"
                    onClick={handleResetFilters}
                >
                    <Image
                        className="mr-2 text-white"
                        alt="reste"
                        width={15}
                        height={15}
                        src={restImg}
                    />
                    Reset
                </Button>
            </div>
        );
    };

    return (
        <>
            <CustomePageHeader
                route={routes?.attendance(defaultWorkSpace?.name)}
                title={pageHeader.title}
                titleClassName="montserrat_font_title"
            >
                {/* <div className="mt-4 flex items-center gap-3 @lg:mt-0">
                    <ModalButton
                        label="Add Log"
                        view={<ManageAttendance title="Add Log" logDetails={[]} date={new Date()} user_id={params?.userId} />}
                        size="DEFAULT"
                        className="h-12 w-48 rounded-3xl bg-[#8C80D2] text-sm"
                        icon={<PiPlusBold className="me-1.5 h-[17px] w-[17px]" />}
                    />
                </div>  */}
                        <Button
          variant="solid"
          className="w-[30] bg-[hsl(246,46%,92%)] text-[#8C80D2] lg:w-auto"
          onClick={AttendanceReportDownload}
          disabled={userReportDownloadLoader}
        >
          <PiArrowLineDownBold className="me-1.5 h-[17px] w-[17px]" />
          Export
          {userReportDownloadLoader && ( 
             <Spinner
              size="sm"
              tag="div"
              className="ms-3 bg-[#E3E1F4] text-[#8C80D2] "
            /> )}
          
        </Button>
            </ CustomePageHeader>
            <WidgetCard rounded="lg" title="">
                <div className="table_border_remove">
                    <CustomTable
                        data={userDetailsAttendance?.attendance_history || []}
                        total={userDetailsAttendance?.page_count || 0}
                        loading={getUserDetailsAttendanceLoader}
                        pageSize={pageSize}
                        setPageSize={setPageSize}
                        handleDeleteById={handleDeleteById}
                        handleChangePage={handleChangePage}
                        getColumns={GetAttendanceDetailsColumns}
                        scroll={{ x: 1100 }}
                        filtersList={<FilterList />}
                        moduleName="attendance"
                        setPeriod={setPeriod}
                        setStartDate={setStartDate}
                        setEndDate={setEndDate}
                        isRangeFilter={true}
                        resetValue={reset}
                    />
                </div>
            </WidgetCard>
        </>
    );
}

export default AttendanceDetailsTablePage;
