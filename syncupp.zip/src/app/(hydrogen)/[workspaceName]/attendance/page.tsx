
import { metaObject } from '@/config/site.config';
import AttendanceTablePage from './main-page';

export const metadata = {
    ...metaObject('Attendance'),
};

export default function Page() {
    return (
        <div className='main_card_block'>
            <AttendanceTablePage />
        </div>
    );
}
