'use client';
import { Gantt} from 'gantt-task-react';
import 'gantt-task-react/dist/index.css';

function TestPage() {
  const CustomTooltip = ({ task }:any) => {
    return (
      <div
        style={{
          background: '#fff',
          padding: '10px',
          border: '1px solid #ccc',
        }}
      >
        <p>
          <strong>Task:</strong> {task.name}
        </p>
        <p>
          <strong>Start:</strong> {task.start.toDateString()}
        </p>
        <p>
          <strong>End:</strong> {task.end.toDateString()}
        </p>
        <p>
          <strong>User:</strong> {task?.userName || 'Unknown'}
        </p>
      </div>
    );
  };

  let tasks : any = [
    {
      start: new Date(2020, 1, 1),
      end: new Date(2020, 1, 2),
      name: 'Idea p',
      id: 'Task 0',
      type: 'task',
      progress: 45,
      isDisabled: true,
      styles: {
        progressColor: '#ffbb54',
        progressSelectedColor: '#ff9e0d',
        arrowColor: '#ff4',
      },
      project: 'ABC',
      hideChildren: true,
      userName: 'John Doe',
    },
    {
      start: new Date(2020, 1, 4),
      end: new Date(2020, 1, 6),
      name: 'Idea 1',
      id: 'Task 1',
      type: 'task',
      progress: 45,
      isDisabled: true,
      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
      project: 'ABC',
      hideChildren: false,
      dependencies: ['Task 0'],
      userName: 'Jeni bob',
    },
    {
      start: new Date(2020, 1, 7),
      end: new Date(2020, 1, 10),
      name: 'Idea',
      id: 'Task 2',
      type: 'task',
      progress: 45,
      isDisabled: true,
      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
      project: 'ABC',
      hideChildren: false,
      dependencies: ['Task 0'],
      userName: 'meera',
    },
    {
      start: new Date(2020, 1, 7),
      end: new Date(2020, 1, 10),
      name: 'Idea',
      id: 'Task 2',
      type: 'task',
      progress: 45,
      isDisabled: true,
      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
      project: 'ABC',
      hideChildren: false,
      userName: 'manoj',
    },
    {
      start: new Date(2020, 1, 10),
      end: new Date(2020, 1, 12),
      name: 'Idea',
      id: 'Task 4',
      type: 'task',
      progress: 45,
      isDisabled: true,
      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
      project: 'ABC',
      hideChildren: false,
      userName: 'mahesh',
    },
  ];

  return (
    <div>
      <Gantt tasks={tasks} TooltipContent={CustomTooltip} />
    </div>
  );
}

export default TestPage;
