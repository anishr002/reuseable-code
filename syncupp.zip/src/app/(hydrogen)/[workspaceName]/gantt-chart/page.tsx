import { metaObject } from '@/config/site.config';
import TestPage from './main-page';

export const metadata = {
  ...metaObject('Test'),
};

export default function Page() {
  return (
    <>
      <div className="main_card_block">
        <TestPage />
      </div>
    </>
  );
}
