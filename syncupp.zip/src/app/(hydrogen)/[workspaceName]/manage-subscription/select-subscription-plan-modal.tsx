import { useModal } from '@/app/shared/modal-views/use-modal';
import ArrowIcon from '@/components/icons/arrow';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Text, Title } from '@/components/ui/text';
import { routes } from '@/config/routes';
import { Paymentloader } from '@/redux/slices/payment/paymentSlice';
import { getUserProfile } from '@/redux/slices/user/auth/signinSlice';
import {
  changeSubscriptionplan,
  clearPlanData,
  getPlanDetails,
} from '@/redux/slices/user/manage-plan/ManagePlanSlice';
import {
  getAllBilling,
  getAllcarddata,
  getAllSeats,
} from '@/redux/slices/user/manage-subscription.tsx/SubscriptionSlice';
import { getWorkspaceList } from '@/redux/slices/user/workspace/workspaceSlice';
import { initiateRazorpay } from '@/services/paymentService';
import cn from '@/utils/class-names';
import syncUppLogo from '@public/assets/svgs/plan-syncupp-logo.svg';
import { capitalize } from 'lodash';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { GoChevronRight } from 'react-icons/go';
import { PiCheckCircleFill, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import SelectWorkspaceModal from './select-workspace-modal';

const desiredOrder = ['quarterly', 'monthly', 'yearly', 'lifetime'];

export const periodName: Record<string, string> = {
  quarterly: 'quarter',
  monthly: 'month',
  yearly: 'year',
  lifetime: 'lifetime',
};

export default function SelectSubscriptionPlanModal(props: any) {
  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const router = useRouter();

  const { control, handleSubmit, setValue } = useForm();
  const [selectedPlan, setselectedPlan] = useState<any>('');
  const [customPlanTypes, setCustomPlanTypes] = useState<any>([]);
  const {
    title,
    planexpire,
    openFromManageSubPag = false,
    selectedPlanData,
  } = props;
  const [planType, setPlanType] = useState('');
  const [selectPlanError, setSelectPlanError] = useState('');

  // state Data selection
  const { planList, planTypesData, planListLoading, loading, countryName } =
    useSelector((state: any) => state?.root?.managePlan);
  const paymentSliceData = useSelector((state: any) => state?.root?.payment);
  const { workspaceList } = useSelector((state: any) => state?.root?.workspace);
  const { userProfile } = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);

  const pathname = usePathname().startsWith(
    routes.manageSubcription(defaultWorkSpace?.name)
  );
  const token = localStorage.getItem('token');

  console.log('paymentSliceData?.loading...', paymentSliceData?.loading);

  // workspace list get api call
  useEffect(() => {
    dispatch(getUserProfile());
    dispatch(getWorkspaceList());
  }, [dispatch]);

  useEffect(() => {
    if (openFromManageSubPag && planTypesData && planTypesData?.length > 0) {
      const filterOutLifetimeOption =
        [...planTypesData]
          ?.filter((plan: string) => plan?.toLowerCase() !== 'lifetime')
          ?.sort(
            (a: string, b: string) =>
              desiredOrder?.indexOf(a) - desiredOrder?.indexOf(b)
          ) ?? [];
      setCustomPlanTypes(filterOutLifetimeOption);
    } else if (
      !openFromManageSubPag &&
      planTypesData &&
      planTypesData?.length > 0
    ) {
      const sortedTypeOptions =
        [...planTypesData]?.sort(
          (a: string, b: string) =>
            desiredOrder?.indexOf(a) - desiredOrder?.indexOf(b)
        ) ?? [];
      setCustomPlanTypes(sortedTypeOptions);
    }
  }, [planTypesData, openFromManageSubPag]);

  useEffect(() => {
    if (planType !== '') {
      dispatch(
        getPlanDetails({ plan_type: planType, country: countryName ?? '' })
      );
    } else {
      dispatch(getPlanDetails()).then((result: any) => {
        if (getPlanDetails.fulfilled.match(result)) {
          if (result?.payload?.success === true) {
            if (selectedPlanData && selectedPlanData?.period) {
              setPlanType(selectedPlanData?.period);
            } else if (
              openFromManageSubPag &&
              userProfile?.purchased_plan?.period === 'lifetime'
            ) {
              setPlanType('monthly');
            } else if (
              userProfile?.purchased_plan?._id &&
              userProfile?.purchased_plan?._id !== ''
            ) {
              userProfile?.purchased_plan?.period &&
                setPlanType(userProfile?.purchased_plan?.period);
            } else if (
              userProfile?.manual_subscription_plan?._id &&
              userProfile?.manual_subscription_plan?._id !== ''
            ) {
              userProfile?.manual_subscription_plan?.period &&
                setPlanType(userProfile?.manual_subscription_plan?.period);
            } else {
              setPlanType('quarterly');
            }
          }
        }
      });
    }
  }, [dispatch, planType]);

  useEffect(() => {
    // clear plan data when component unmount
    return () => {
      dispatch(clearPlanData());
    };
  }, [dispatch]);

  console.log('selectedPlan...', selectedPlan);

  // Default selected plan
  useEffect(() => {
    console.log(
      'we are setting plan data...',
      userProfile?.purchased_plan?._id,
      userProfile?.manual_subscription_plan?._id
    );

    if (selectedPlanData && selectedPlanData?._id) {
      setValue('plan', selectedPlanData?._id);
      setselectedPlan(selectedPlanData?._id);
    } else if (
      openFromManageSubPag &&
      userProfile?.purchased_plan?.period === 'lifetime'
    ) {
      setValue('plan', '');
      setselectedPlan('');
    } else if (
      userProfile?.purchased_plan?._id &&
      userProfile?.purchased_plan?._id !== ''
    ) {
      console.log('we are setting purchased plan data...', planList);
      const selectedPurchasedPlan = planList?.find(
        (plan: Record<string, any>) =>
          plan?._id === userProfile?.purchased_plan?._id
      );
      console.log('selectedPurchasedPlan...', selectedPurchasedPlan);

      selectedPurchasedPlan &&
        setValue('plan', userProfile?.purchased_plan?._id);
      selectedPurchasedPlan &&
        setselectedPlan(userProfile?.purchased_plan?._id);
    } else if (
      userProfile?.manual_subscription_plan?._id &&
      userProfile?.manual_subscription_plan?._id !== ''
    ) {
      console.log('we are setting manual plan data...', planList);
      const selectedManualPlan = planList?.find(
        (plan: Record<string, any>) =>
          plan?._id === userProfile?.manual_subscription_plan?._id
      );
      console.log('selectedManualPlan...', selectedManualPlan);

      selectedManualPlan &&
        setValue('plan', userProfile?.manual_subscription_plan?._id);
      selectedManualPlan &&
        setselectedPlan(userProfile?.manual_subscription_plan?._id);
    } else {
      setValue('plan', planList?.[0]?._id);
      setselectedPlan(planList?.[0]?._id);
    }
  }, [planList, userProfile, selectedPlanData]);

  // Handle submit function
  const onSubmit = (data: any) => {
    console.log(data, 'data');

    if (data?.plan === '') {
      setSelectPlanError('Please select a plan.');
      return;
    }
    setSelectPlanError('');

    // Selected plan details
    const [selectedPlanDetails] =
      planList && planList?.length > 0
        ? planList?.filter((plan: any) => plan?._id === data?.plan)
        : [];

    console.log('selectedPlanDetails...', selectedPlanDetails);

    // Agencies created workspace only
    const agencyWorkspaceLength =
      workspaceList && workspaceList?.length > 0
        ? workspaceList?.filter(
            (workspace: Record<string, any>) =>
              workspace?.created_by === signIn?.userProfile?._id
          )
        : [];

    console.log('agencyWorkspaceLength....', agencyWorkspaceLength);
    const isMaxUsersExceed =
      agencyWorkspaceLength?.some(
        (entry: Record<string, any>) =>
          entry?.members?.length > selectedPlanDetails?.no_of_users
      ) ?? false;

    console.log('isMaxUsersExceed....', isMaxUsersExceed);

    const handleWorkspaceManagement = (
      selectedPlanDetails: Record<string, any>,
      openFromManageSubPag: boolean
    ) => {
      closeModal();
      openModal({
        view: (
          <div>
            <SelectWorkspaceModal
              title="Manage Your Subscription Plan"
              selectedPlan={selectedPlanDetails}
              openFromManageSubPag={openFromManageSubPag}
            />
          </div>
        ),
        customSize: '900px',
      });
    };

    if (
      openFromManageSubPag &&
      agencyWorkspaceLength &&
      agencyWorkspaceLength?.length > 0 &&
      agencyWorkspaceLength?.length > selectedPlanDetails?.workspaces_count &&
      userProfile?.purchased_plan?._id !== data?.plan &&
      userProfile?.manual_subscription_plan?._id !== data?.plan
    ) {
      console.log(
        "Change plan and workspace count more than selected plan's workspace count"
      );
      handleWorkspaceManagement(selectedPlanDetails, openFromManageSubPag);
    } else if (
      openFromManageSubPag &&
      isMaxUsersExceed &&
      userProfile?.purchased_plan?._id !== data?.plan &&
      userProfile?.manual_subscription_plan?._id !== data?.plan
    ) {
      console.log(
        "Change plan and users count more than selected plan's users count in any of it's workspaces."
      );
      handleWorkspaceManagement(selectedPlanDetails, openFromManageSubPag);
    } else if (
      !openFromManageSubPag &&
      agencyWorkspaceLength &&
      agencyWorkspaceLength?.length > 0 &&
      agencyWorkspaceLength[0]?.members &&
      agencyWorkspaceLength[0]?.members?.length >
        selectedPlanDetails?.no_of_users
    ) {
      console.log(
        "First time selection of plan and users count is more than selected plan's users count"
      );
      handleWorkspaceManagement(selectedPlanDetails, openFromManageSubPag);
    } else if (
      pathname &&
      openFromManageSubPag &&
      userProfile?.purchased_plan?._id !== data?.plan &&
      userProfile?.manual_subscription_plan?._id !== data?.plan
    ) {
      console.log('Perfect plan to change it.');

      dispatch(
        changeSubscriptionplan({ plan_id: data?.plan, workspace_members: [] })
      ).then((result: any) => {
        if (changeSubscriptionplan.fulfilled.match(result)) {
          // console.log('resultt', result)
          if (result && result.payload.success === true) {
            closeModal();
            dispatch(getUserProfile());
            dispatch(getAllBilling({ pagination: false }));
            dispatch(getAllSeats({ pagination: false }));
            dispatch(getAllcarddata());
            dispatch(getWorkspaceList());
            // initiateRazorpay(router, routes.dashboard, user?.data?.token, dispatch, data?.plan)
          }
        }
      });
    } else if (!openFromManageSubPag) {
      console.log('Perfect plan to select it first time.');

      // closeModal();
      dispatch(Paymentloader(true));
      initiateRazorpay(
        router,
        routes.dashboard(defaultWorkSpace?.name),
        token,
        dispatch,
        data?.plan,
        closeModal
      );
    }
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className=" flex flex-col gap-4 p-6 [&_label]:font-medium"
    >
      <div className="flex items-center justify-between">
        <Title
          as="h3"
          className="text-xl font-medium text-[#9BA1B9] xl:text-2xl"
        >
          {title}
        </Title>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>
      {planTypesData && planTypesData?.length > 0 && (
        <div
          className={cn(
            'flex items-center justify-center',
            customPlanTypes?.length > 0 &&
              customPlanTypes?.includes('yearly') &&
              !customPlanTypes?.includes('lifetime') &&
              'md:ms-[208px]'
          )}
        >
          {customPlanTypes &&
            customPlanTypes?.length > 0 &&
            customPlanTypes?.map((plan: any, index: number) => (
              <Button
                key={plan}
                className={cn(
                  'flex w-[100px] items-center justify-center border px-6 py-4 text-[16px] font-medium',
                  planType === plan
                    ? 'border-[#8C80D2] bg-[#8C80D2] text-white'
                    : 'border-[#8C80D2] bg-white text-[#8C80D2]',
                  index === 0
                    ? 'rounded-l-full border-r-0' // First button
                    : index === customPlanTypes?.length - 1
                      ? 'rounded-r-full border-l-0' // Last button
                      : 'rounded-none border-y' // Middle button
                )}
                onClick={() => setPlanType(plan)}
              >
                {capitalize(plan)}{' '}
              </Button>
            ))}
          {customPlanTypes?.length > 0 &&
            customPlanTypes?.includes('yearly') &&
            !customPlanTypes?.includes('lifetime') && (
              <>
                <ArrowIcon className="mt-11 h-[52px] w-[52px] rotate-[20deg]" />
                <Text className="poppins_font_number -ml-6 mt-1.5 rotate-[13deg] rounded-[8px] p-[6px] text-black">
                  Save 10% with Yearly Plan
                </Text>
              </>
            )}
        </div>
      )}
      <div>
        {planListLoading && (
          <div className="!grid h-full min-h-[128px] flex-grow place-content-center items-center justify-center">
            <Spinner size="xl" />
          </div>
        )}
        {!planListLoading && planList?.length === 0 && (
          <div className="mt-[52px] flex items-center justify-center font-medium">
            No plan available!
          </div>
        )}
        <div className="grid max-h-[400px] grid-cols-1 gap-4 overflow-auto p-6 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3">
          {!planListLoading &&
            planList?.length > 0 &&
            planList?.map((data: any) => (
              <div
                key={data?._id}
                className="w-full"
                onClick={() => {
                  setselectedPlan(data?._id), setValue('plan', data?._id);
                  setSelectPlanError('');
                }}
              >
                <div
                  className={`relative h-[338px] rounded-2xl border shadow-lg transition-all hover:shadow-xl ${
                    selectedPlan === data?._id
                      ? 'border-[#8C80D2] bg-[#F7F6FF]'
                      : 'border-gray-300 bg-white'
                  }`}
                >
                  <div className="absolute right-0 flex justify-end p-3">
                    <Controller
                      name="plan"
                      control={control}
                      defaultValue=""
                      render={({ field }) => (
                        <input
                          className="form-radio"
                          type="radio"
                          {...field}
                          value={data?._id}
                          checked={field.value === data?._id}
                        />
                      )}
                    />
                  </div>
                  <div className="poppins_font_number flex h-full flex-col items-center gap-2 p-6">
                    <Image
                      className="mt-3 h-16 w-16"
                      src={syncUppLogo}
                      alt="Syncupp"
                      width={48}
                      height={48}
                    />
                    <div className="flex-grow"></div>
                    <div className="flex flex-col items-center gap-2">
                      <Title
                        as="h3"
                        className="text-center font-bold text-gray-800"
                      >
                        {data?.name}
                      </Title>
                      <div className="poppins_font_number flex items-center justify-center gap-1 font-medium text-gray-500">
                        <div className="text-xl text-[#8C80D2]">
                          {data?.symbol ?? ''} {(data?.amount ?? 0) / 100}
                        </div>
                        {data?.period && data?.period !== 'lifetime' && (
                          <div className="text-sm">
                            / {periodName[data?.period]}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex-grow"></div>
                    <div className="mt-auto flex w-full flex-col gap-2">
                      <Text className="poppins_font_number w-full" as="p">
                        This plan includes the following:
                      </Text>
                      <div className="poppins_font_number flex w-full items-center justify-start gap-2 text-[#8C80D2]">
                        <PiCheckCircleFill className="h-[18px] w-[18px]" />
                        <div>{data?.no_of_users} Users</div>
                      </div>
                      <div className="poppins_font_number flex w-full items-center justify-start gap-2 text-[#8C80D2]">
                        <PiCheckCircleFill className="h-[18px] w-[18px]" />
                        <div>
                          {data?.period === 'lifetime'
                            ? 'Unlimited'
                            : data?.workspaces_count}{' '}
                          {` Workspace${
                            data?.workspaces_count === 1 ? '' : 's'
                          }`}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
      {selectPlanError && selectPlanError !== '' ? (
        <div className="poppins_font_number ps-8 text-lg text-red-600">
          {selectPlanError}
        </div>
      ) : null}
      <div className="flex justify-end">
        <Button
          disabled={loading || paymentSliceData?.loading}
          className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
          type="submit"
          size="lg"
        >
          <span>Next</span>
          <GoChevronRight className="h-6 w-6" />
          {(loading || paymentSliceData?.loading) && (
            <Spinner size="sm" tag="div" className="ms-3" color="white" />
          )}
        </Button>
      </div>
    </form>
  );
}
