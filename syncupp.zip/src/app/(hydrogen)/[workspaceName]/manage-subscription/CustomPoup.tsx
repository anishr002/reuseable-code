'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import Spinner from '@/components/ui/spinner';
import { getUserProfile } from '@/redux/slices/user/auth/signinSlice';
import {
  RemoveUsersub,
  getAllSeats,
  getAllcarddata,
} from '@/redux/slices/user/manage-subscription.tsx/SubscriptionSlice';
import cn from '@/utils/class-names';
import { PiTrashFill } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Text, Title } from 'rizzui';

function DeleteModel({
  forsfully,
  id,
  page,
  items_per_page,
  sort_field,
  sort_order,
  search,
  pagination,
}: any) {
  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const { RemoveUsersubLoader } = useSelector(
    (state: any) => state?.root?.managesubcription
  );

  const handleDelete = async () => {
    const res = await dispatch(
      RemoveUsersub({ user_id: id, force_fully_remove: forsfully })
    );
    if (res.payload.success === true) {
      closeModal();
      await dispatch(
        getAllSeats({
          page: page,
          items_per_page: items_per_page,
          sort_field: sort_field,
          sort_order: sort_order,
          search: search,
          pagination: pagination,
        })
      );
      dispatch(getAllcarddata());
      dispatch(getUserProfile());
    }
  };

  function handelCAncle() {
    closeModal();
  }

  return (
    <div className="p-6">
      <div className="flex flex-col items-center gap-[6px]">
        <Title
          as="h6"
          className="mb-0.5 flex items-start text-sm text-[#8C80D2] sm:items-center"
        >
          {/* <PiTrashFill className="me-1 h-[17px] w-[17px]" /> */}
          This User have been assigned with Task(s) which are still pending.
        </Title>
        <Text className="mb-2 leading-relaxed text-[#9BA1B9]">
          Are you sure you want to delete?
        </Text>
        {/* <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="p-0 text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon> */}
      </div>
      <div className={cn('grid grid-cols-2 gap-5 pt-5')}>
        <div className="flex items-center justify-end gap-2">
          <Button
            className="bg-[#8C80D2] text-white @xl:w-auto dark:text-white"
            onClick={handleDelete}
            disabled={RemoveUsersubLoader}
          >
            Yes
            {RemoveUsersubLoader && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
        <div>
          <Button
            variant="outline"
            onClick={() => handelCAncle()}
            className="text-[#9BA1B9] @xl:w-auto dark:hover:border-gray-400"
          >
            No
          </Button>
        </div>
      </div>
    </div>
  );
}

export default DeleteModel;
