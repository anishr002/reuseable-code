import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { ActionIcon, Title } from '@/components/ui/text';
import { routes } from '@/config/routes';
import { Paymentloader } from '@/redux/slices/payment/paymentSlice';
import { getUserProfile } from '@/redux/slices/user/auth/signinSlice';
import {
  changeSubscriptionplan,
  postDegradePlan,
} from '@/redux/slices/user/manage-plan/ManagePlanSlice';
import {
  getAllBilling,
  getAllcarddata,
  getAllSeats,
} from '@/redux/slices/user/manage-subscription.tsx/SubscriptionSlice';
import {
  clearWorkspaceMembersDetail,
  getWorkspaceList,
  getWorkspaceMembers,
} from '@/redux/slices/user/workspace/workspaceSlice';
import { initiateRazorpay } from '@/services/paymentService';
import cn from '@/utils/class-names';
import { usePathname, useRouter } from 'next/navigation';
import { Fragment, useEffect, useState } from 'react';
import { GoChevronLeft, GoChevronRight } from 'react-icons/go';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Avatar, Checkbox, CheckboxGroup } from 'rizzui';
import SimpleBar from 'simplebar-react';
import SelectSubscriptionPlanModal from './select-subscription-plan-modal';

interface SelectedWorkspace {
  workspace_id: string;
  members: string[];
}

const roleName: any = {
  agency: 'Super Admin',
  client: 'Client',
  team_client: 'Client Team Member',
  team_agency: 'Team Member',
};

const displayName = (data: any) => {
  let displayName: string =
    data?.first_name?.charAt(0)?.toUpperCase() +
    data?.first_name?.slice(1) +
    ' ' +
    data?.last_name?.charAt(0)?.toUpperCase() +
    data?.last_name?.slice(1);
  return displayName;
};

export default function SelectWorkspaceModal(props: any) {
  const { title, openFromManageSubPag, selectedPlan } = props;
  const { openModal, closeModal } = useModal();
  const dispatch = useDispatch();
  const router = useRouter();

  const maxWorkspaces = selectedPlan?.workspaces_count;
  const maxMembersPerWorkspace = selectedPlan?.no_of_users;

  const [selectedWorkspaces, setSelectedWorkspaces] = useState<
    SelectedWorkspace[]
  >([]);

  const [selectedWorkspaceIds, setSelectedWorkspaceIds] = useState<string[]>(
    []
  );
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);

  const [error, setError] = useState('');

  console.log('selectedWorkspaces...', selectedWorkspaces);
  console.log('selectedWorkspaceIds...', selectedWorkspaceIds);
  console.log('selectedMemberIds...', selectedMemberIds);
  console.log('error...', error);

  // state Data selection

  const { workspaceMembers, defaultWorkSpace, getWorkspaceMembersLoader } =
    useSelector((state: any) => state?.root?.workspace);
  const { userProfile } = useSelector((state: any) => state?.root?.signIn);
  const paymentSliceData = useSelector((state: any) => state?.root?.payment);
  const { loading, postDegradePlanLoader } = useSelector(
    (state: any) => state?.root?.managePlan
  );

  const pathname = usePathname().startsWith(
    routes.manageSubcription(defaultWorkSpace?.name)
  );
  const token = localStorage.getItem('token');

  console.log('paymentSliceData?.loading...', paymentSliceData?.loading);

  // Get workspaces & it's members
  useEffect(() => {
    dispatch(getWorkspaceMembers());
  }, [dispatch]);

  useEffect(() => {
    // clear workspace members data when component unmount
    return () => {
      dispatch(clearWorkspaceMembersDetail());
    };
  }, [dispatch]);

  useEffect(() => {
    const maxUsers =
      selectedWorkspaces &&
      selectedWorkspaces?.length > 0 &&
      selectedWorkspaces?.some(
        (workspace: Record<string, any>) =>
          workspace?.members?.length > maxMembersPerWorkspace
      );
    if (selectedWorkspaces?.length > maxWorkspaces) {
      setError(
        `You can select a maximum of ${maxWorkspaces} workspace${
          maxWorkspaces === 1 ? '' : 's'
        } as per selected plan.`
      );
    } else if (maxUsers) {
      setError(
        `You can select a maximum of ${maxMembersPerWorkspace} seats per workspace.`
      );
    } else {
      setError('');
    }
  }, [selectedWorkspaces, maxWorkspaces, maxMembersPerWorkspace]);

  // Handle workspace selection
  const handleWorkspaceSelection = (
    workspaceId: string,
    isChecked: boolean,
    workspaceMembers: Record<string, any>
  ) => {
    setSelectedWorkspaces((prev) => {
      const existingEntry = prev?.find(
        (entry) => entry?.workspace_id === workspaceId
      );
      if (isChecked) {
        // Collect agency members from the workspaceMembers list
        const agencyMembers = workspaceMembers
          ?.filter(
            (member: Record<string, any>) => member?.role?.name === 'agency'
          )
          ?.map((member: Record<string, any>) => member?.user_id);

        if (!existingEntry) {
          return [
            ...prev,
            { workspace_id: workspaceId, members: agencyMembers ?? [] },
          ];
        }
      } else {
        return prev?.filter((entry) => entry?.workspace_id !== workspaceId);
      }
      return prev;
    });
  };

  // Handle member selection
  const handleMemberSelection = (
    workspaceList: Record<string, any>,
    workspaceId: string,
    memberId: string,
    isChecked: boolean,
    isClient: boolean = false,
    clientId: string = ''
  ) => {
    setSelectedWorkspaces((prev) =>
      prev.map((entry) => {
        if (entry?.workspace_id === workspaceId) {
          let members = [...entry?.members];

          if (isChecked) {
            if (isClient) {
              // Add client and their members
              members = [...members, memberId];
            } else if (clientId) {
              // Add client team member under the client
              if (!members?.includes(clientId)) {
                members?.push(clientId);
              }
              members?.push(memberId);
            } else {
              members?.push(memberId);
            }
          } else {
            if (isClient) {
              // Remove client and their team members
              members = members?.filter(
                (id) =>
                  id !== memberId &&
                  !workspaceList
                    .find((ws: any) => ws?._id === workspaceId)
                    ?.members?.find((m: any) => m?.user_id === memberId)
                    ?.team_members?.map((tm: any) => tm?.user_id)
                    ?.includes(id)
              );
            } else if (clientId) {
              // Remove client team member
              members = members?.filter((id) => id !== memberId);

              // Check if the client has no other team members selected
              const clientTeamMembersSelected = workspaceList
                ?.find((ws: any) => ws?._id === workspaceId)
                ?.members?.find((m: any) => m?.user_id === clientId)
                ?.team_members?.filter(
                  (tm: any) => members?.includes(tm?.user_id)
                );

              if (!clientTeamMembersSelected?.length) {
                members = members?.filter((id) => id !== clientId);
              }
            } else {
              members = members?.filter((id) => id !== memberId);
            }
          }

          return { ...entry, members };
        }
        return entry;
      })
    );
  };

  // handle next button click
  const handleNextClick = () => {
    // Check workspace selection limit
    if (selectedWorkspaces?.length === 0) {
      setError(`Please select at least 1 workspace.`);
      return;
    }

    if (error === '' && !openFromManageSubPag) {
      dispatch(
        postDegradePlan({
          plan_id: selectedPlan?._id,
          selected_workspaces: selectedWorkspaces,
        })
      ).then((result: any) => {
        if (postDegradePlan.fulfilled.match(result)) {
          console.log('postDegradePlan resultt...', result);
          if (result && result?.payload?.success === true) {
            if (!openFromManageSubPag) {
              // closeModal();
              dispatch(Paymentloader(true));
              initiateRazorpay(
                router,
                routes.dashboard(defaultWorkSpace?.name),
                token,
                dispatch,
                selectedPlan?._id,
                closeModal
              );
            }
          }
        }
      });
    } else if (
      error === '' &&
      pathname &&
      openFromManageSubPag &&
      userProfile?.purchased_plan?._id !== selectedPlan?._id &&
      userProfile?.manual_subscription_plan?._id !== selectedPlan?._id
    ) {
      dispatch(
        changeSubscriptionplan({
          plan_id: selectedPlan?._id,
          workspace_members: selectedWorkspaces,
        })
      ).then((result: any) => {
        if (changeSubscriptionplan.fulfilled.match(result)) {
          if (result && result?.payload?.success === true) {
            dispatch(getUserProfile());
            dispatch(getWorkspaceList());
            dispatch(getAllBilling({ pagination: false }));
            dispatch(getAllSeats({ pagination: false }));
            dispatch(getAllcarddata());
            closeModal();
          }
        }
      });
    }
  };

  return (
    <div className="max-h-[750px] overflow-hidden">
      <div className="flex flex-col gap-4 p-8 [&_label]:font-medium">
        <div className="flex items-center justify-between">
          <Title
            as="h3"
            className="text-xl font-medium text-[#9BA1B9] xl:text-2xl"
          >
            {title}
          </Title>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={() => closeModal()}
            className="p-0 text-[#9BA1B9] hover:text-[#8C80D2]"
          >
            <PiXBold className="h-[18px] w-[18px]" />
          </ActionIcon>
        </div>
        <div className="poppins_font_number text-lg text-black">
          {selectedPlan &&
            `${selectedPlan?.name} - Max ${selectedPlan?.workspaces_count} Workspaces and ${selectedPlan?.no_of_users} Users per Workspace`}
        </div>
        {getWorkspaceMembersLoader && workspaceMembers?.length === 0 && (
          <div className="flex h-full w-full items-center justify-center">
            <Spinner size="xl" />
          </div>
        )}
        <div className="grid max-h-[495px] grid-cols-1 gap-2 overflow-auto p-4 md:grid-cols-2">
          {workspaceMembers?.length > 0 &&
            workspaceMembers?.map((workspace: Record<string, any>) => (
              <div key={workspace?._id} className="w-fit pb-2">
                <CheckboxGroup
                  setValues={setSelectedWorkspaceIds}
                  values={selectedWorkspaces?.map(
                    (entry) => entry?.workspace_id
                  )}
                  onChange={(e: any) =>
                    handleWorkspaceSelection(
                      e.target.value,
                      e.target.checked,
                      workspace?.members
                    )
                  }
                >
                  <Checkbox
                    value={workspace?._id}
                    label={
                      <WorkspaceLabel
                        workspace={workspace}
                        selectedPlan={selectedPlan}
                        selectedWorkspaces={selectedWorkspaces}
                      />
                    }
                    // rounded='circle'
                    className="p-2"
                  />
                </CheckboxGroup>
                {selectedWorkspaces?.some(
                  (entry) => entry?.workspace_id === workspace?._id
                ) && (
                  <SimpleBar className="ml-6 mt-2 max-h-[375px] overflow-auto">
                    {workspace?.members?.map(
                      (member: Record<string, any>, index: any) => (
                        <div key={member?.user_id}>
                          <CheckboxGroup
                            values={
                              selectedWorkspaces?.find(
                                (entry) =>
                                  entry?.workspace_id === workspace?._id
                              )?.members || []
                            }
                            setValues={setSelectedMemberIds}
                            onChange={(e: any) =>
                              handleMemberSelection(
                                workspaceMembers,
                                workspace?._id,
                                e.target.value,
                                e.target.checked,
                                member?.role?.name === 'client',
                                member?.role?.name === 'client'
                                  ? member?.user_id
                                  : ''
                              )
                            }
                          >
                            <Checkbox
                              value={member?.user_id}
                              label={
                                <Fragment key={member?.user_id + '-' + index}>
                                  <div className="relative flex items-center rounded-lg text-sm focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg">
                                    <span className="inline-flex items-center justify-center p-2 text-gray-500">
                                      <Avatar
                                        src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${member?.profile_image}`}
                                        name={displayName(member)}
                                        className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white xl:!h-11 xl:!w-11"
                                      />
                                    </span>

                                    <span className="ms-1 grid gap-0.5">
                                      <span className="poppins_font_number font-medium capitalize text-black">
                                        {displayName(member)}
                                      </span>
                                      <span className="text-gray-500">
                                        {member?.role?.name &&
                                          `${roleName[member?.role?.name]}`}
                                      </span>
                                    </span>
                                  </div>
                                </Fragment>
                              }
                              className="p-2"
                              disabled={member?.role?.name === 'agency'} // Disable checkbox if role is "agency"
                            />
                          </CheckboxGroup>
                          {member?.role?.name === 'client' &&
                            selectedWorkspaces
                              .find(
                                (entry) =>
                                  entry?.workspace_id === workspace?._id
                              )
                              ?.members?.includes(member?.user_id) &&
                            member?.team_members && (
                              <div className="ml-4">
                                {member?.team_members?.map(
                                  (
                                    clientTeamMember: Record<string, any>,
                                    index: any
                                  ) => (
                                    <Checkbox
                                      key={clientTeamMember?.user_id}
                                      value={clientTeamMember?.user_id}
                                      label={
                                        <Fragment
                                          key={
                                            clientTeamMember?.user_id +
                                            '-' +
                                            index
                                          }
                                        >
                                          <div className="relative flex items-center rounded-lg text-sm focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg">
                                            <span className="inline-flex items-center justify-center p-2 text-gray-500">
                                              <Avatar
                                                src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${clientTeamMember?.profile_image}`}
                                                name={displayName(
                                                  clientTeamMember
                                                )}
                                                className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white xl:!h-11 xl:!w-11"
                                              />
                                            </span>

                                            <span className="ms-1 grid gap-0.5">
                                              <span className="poppins_font_number font-medium capitalize text-black">
                                                {displayName(clientTeamMember)}
                                              </span>
                                              <span className="text-gray-500">
                                                {clientTeamMember?.role?.name &&
                                                  `${
                                                    roleName[
                                                      clientTeamMember?.role
                                                        ?.name
                                                    ]
                                                  }`}
                                              </span>
                                            </span>
                                          </div>
                                        </Fragment>
                                      }
                                      className="p-2"
                                      onChange={(e: any) =>
                                        handleMemberSelection(
                                          workspaceMembers,
                                          workspace?._id,
                                          e.target.value,
                                          e.target.checked,
                                          false,
                                          member?.user_id
                                        )
                                      }
                                    />
                                  )
                                )}
                              </div>
                            )}
                        </div>
                      )
                    )}
                  </SimpleBar>
                )}
              </div>
            ))}
        </div>
        {error && error !== '' ? (
          <div className="poppins_font_number ps-6 text-lg text-red-600">
            {error}
          </div>
        ) : null}
        <div className="flex justify-between">
          <Button
            className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
            size="lg"
            onClick={() => {
              closeModal();
              openModal({
                view: (
                  <div>
                    <SelectSubscriptionPlanModal
                      title="Manage Your Subscription Plan"
                      openFromManageSubPag={openFromManageSubPag}
                      selectedPlanData={selectedPlan}
                    />
                  </div>
                ),
                customSize: '900px',
              });
            }}
          >
            <GoChevronLeft className="h-6 w-6" />
            <span>Back</span>
          </Button>
          <Button
            disabled={
              postDegradePlanLoader || loading || paymentSliceData?.loading
            }
            className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
            type="submit"
            size="lg"
            onClick={handleNextClick}
          >
            <span>Next</span>
            <GoChevronRight className="h-6 w-6" />
            {(postDegradePlanLoader ||
              loading ||
              paymentSliceData?.loading) && (
              <Spinner size="sm" tag="div" className="ms-3" color="white" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

const WorkspaceLabel = ({
  workspace,
  selectedPlan,
  selectedWorkspaces,
}: {
  workspace: Record<string, any>;
  selectedPlan: Record<string, any>;
  selectedWorkspaces: Record<string, any>;
}) => {
  const totalSeats = selectedPlan?.no_of_users ?? 0;
  const selectedSeats =
    selectedWorkspaces?.find(
      (entry: Record<string, any>) => entry?.workspace_id === workspace?._id
    )?.members?.length ?? 0;

  const calculateSeats = totalSeats - selectedSeats;

  return (
    <div className="flex gap-2 capitalize text-gray-800">
      <span className="poppins_font_number">{workspace?.name}</span>
      <span
        className={cn(
          'poppins_font_number',
          calculateSeats <= 0 && 'text-red-600'
        )}
      >
        {`(${calculateSeats <= 0 ? 0 : calculateSeats} Seats Available)`}
      </span>
    </div>
  );
};
