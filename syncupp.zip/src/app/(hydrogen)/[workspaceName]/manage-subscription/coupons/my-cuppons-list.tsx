'use client';

import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Checkbox } from '@/components/ui/checkbox';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { getAllAgencyagreement, updateagreementStatus } from '@/redux/slices/user/agreement/agreementSlice';
import { Button, Tooltip } from 'rizzui';
import PaymentTransactionSublistPage from '@/app/admin/(hydrogen)/payment-transaction/popup-table';
import Spinner from '@/components/ui/spinner';

type Columns = {
    data: any[];
    sortConfig?: any;
    handleSelectAll: any;
    checkedItems: string[];
    onDeleteItem: (id: string | string[], currentPage?: any, countPerPage?: number, Islastitem?: boolean, sortConfig?: Record<string, string>, searchTerm?: string) => void;
    onHeaderCellClick: (value: string) => void;
    onChecked?: (id: string) => void;
    currentPage?: number;
    pageSize?: number;
    searchTerm?: string;
};


export const CupponsColumns = ({
    data,
    sortConfig,
    checkedItems,
    onDeleteItem,
    onHeaderCellClick,
    handleSelectAll,
    onChecked,
    currentPage,
    pageSize,
    searchTerm,
}: Columns) => {

    const dispatch = useDispatch();

    const { paymentsubTransactions, loading } = useSelector((state: any) => state?.root?.paymentTransaction);

    return [
        {
            title: (
                <HeaderCell
                    title="Name"
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'name'
                    }
                />
            ),

            dataIndex: 'agency',
            key: 'agency',
            width: 150,
            render: (value: any) => (
                <Text className="font-medium text-gray-700 capitalize">{value?.name && value?.name != "" ? value?.name : "-"}</Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Date"
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'createdAt'
                    }
                />
            ),
            dataIndex: 'createdAt',
            key: 'createdAt',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700">{value && value != "" ? moment(value).format("Do MMM. ‘YY") : "-"}</Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Form of payment"
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'method'
                    }
                />
            ),
            dataIndex: 'method',
            key: 'method',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700 capitalize">{value && value != "" ? value : "-"}</Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Order ID"
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'order_id'
                    }
                />
            ),
            dataIndex: 'order_id',
            key: 'order_id',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700">{value && value != "" ? value : "-"}</Text>
            ),
        },
        {
            title: (
                <HeaderCell
                    title="Amount"
                    ascending={
                        sortConfig?.direction === 'asc' && sortConfig?.key === 'amount'
                    }
                />
            ),
            dataIndex: 'amount',
            key: 'amount',
            width: 150,
            render: (value: string) => (
                <Text className="font-medium text-gray-700">{value && value != "" ? "$" + (+value / 100).toFixed(2) : "-"}</Text>
            ),
        },

    ];
}
