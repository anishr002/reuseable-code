
import { metaObject } from '@/config/site.config';
import CouponsPage from './main-page';


export const metadata = {
    ...metaObject('Available Coupons'),
};

export default function Page() {
    return (
        <>
            <CouponsPage />
        </>
    );
}
