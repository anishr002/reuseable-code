'use client';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import {
  PurchaseCoupons,
  getCouponsData,
  updateCouponsList,
} from '@/redux/slices/user/cuppons/couponsSlice';
import { capitalizeFirstLetter, couponColor } from '@/utils/common-functions';
import SubtractImg from '@public/assets/images/subtract_img.svg';
import PlaceholderImg from '@public/img_Placeholder.png.png';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Empty, Text } from 'rizzui';
import backIcon from '@public/assets/images/back_arrow_icon.svg';
import { useRouter } from 'next/navigation';


function CouponsPage() {
  const dispatch = useDispatch();
  const router = useRouter();

  const { Cupponlistdetails, loading, MyCupponlistdetails, purchaseloader } =
    useSelector((state: any) => state?.root?.coupon);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  // console.log(Cupponlistdetails, 'Cupponlistdetails', MyCupponlistdetails)

  const [selectedindex, setselectedindex] = useState(null);

  useEffect(() => {
    dispatch(getCouponsData({ coupon_count: 0 }));
  }, []);

  const PurchaseHandler = (item: any) => {
    setselectedindex(item?._id);
    dispatch(PurchaseCoupons({ couponId: item?._id })).then((result: any) => {
      if (PurchaseCoupons.fulfilled.match(result)) {
        // console.log('resultt', result)
        if (result && result.payload.success === true) {
          dispatch(getCouponsData({ coupon_count: 0 }));
        }
      }
    });
  };


  if (loading) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <>
      {/* <CustomePageHeader
        route={routes.manageSubcription(defaultWorkSpace?.name)}
        title="Available Coupons"
        titleClassName="montserrat_font_title"
      /> */}

      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center justify-start ">
          <div onClick={() =>  (dispatch(updateCouponsList({})),router.back())} className='cursor-pointer'>
            <Image
              src={backIcon}
              alt="back icon"
              className=" h-6 w-6 lg:h-10 lg:w-10"
            />
          </div>
          <label
            className={`montserrat_font_title ms-5 text-[28px] font-bold text-[#9BA1B9] lg:text-[44px]`}
          >
            Available Coupons
          </label>
        </div>
      </div>

      <>
        <WidgetCard rounded="lg" title="">
          {/* Coupons list  */}
          {Cupponlistdetails?.data?.coupon &&
          Cupponlistdetails?.data?.coupon?.length > 0 ? (
            <div className="mb-5 grid gap-4 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4">
              {Cupponlistdetails?.data?.coupon?.map(
                (item: any, index: number) => (
                  <>
                    <div key={index} className="relative h-[328px] w-[251px]">
                      <div className={`absolute left-0 top-0 h-[328px] w-[251px] rounded-[20px] ${couponColor(index)}`} />
                      <Image
                        height={306}
                        width={229}
                        alt="subtract"
                        className="absolute left-[11px] top-[11px] h-[306px] w-[229px]"
                        src={SubtractImg}
                      />
                      <div className="poppins_font_number absolute left-[91px] top-[192px] text-center text-sm font-bold leading-[14.97px]  text-slate-400">
                        {Cupponlistdetails?.data?.require_points} points
                      </div>
                      <div className="absolute left-[44px] top-[126px] text-center text-xl font-bold leading-snug  text-slate-900 poppins_font_number">
                        {capitalizeFirstLetter(item?.discountTitle)}
                      </div>
                      <Button
                        disabled={!item?.isAvailable}
                        type="button"
                        className="absolute left-[27px] top-[243px] h-[52px] w-[196px] rounded-[26px] bg-indigo-400 text-white shadow"
                        onClick={() => PurchaseHandler(item)}
                      >
                        {!item?.isAvailable
                          ? 'Coupon Redeemed'
                          : 'Redeem Coupon'}
                        {purchaseloader && selectedindex === item?._id && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                      {/* <div className="left-[65px] top-[262px] absolute text-white text-sm font-semibold  leading-[14.97px] tracking-wide">Redeem Coupon</div> */}
                      <div className="absolute left-[25px] top-[221px] h-[0px] w-[198px] border border-slate-400"></div>
                      {/* <div className="w-[65px] h-[65px] left-[93px] top-[35px] absolute bg-white rounded-full border-2 border-slate-400" /> */}
                      <a target='_blank' href={item?.siteURL} className="">
                        {item?.brandLogo && item?.brandLogo != '' ? (
                          <Image
                            alt="logo"
                            height={65}
                            width={65}
                            className="absolute left-[93px] top-[35px] h-[65px] w-[65px] rounded-full border-2 object-fill"
                            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${item?.brandLogo}`}
                          />
                        ) : (
                          <Image
                            alt="logo"
                            height={65}
                            width={65}
                            className="absolute left-[93px] top-[35px] h-[65px] w-[65px] object-fill"
                            src={PlaceholderImg}
                          />
                        )}
                      </a>
                    </div>
                  </>
                )
              )}
            </div>
          ) : (
            <div className="mb-5 mt-2 rounded-xl border border-gray-300 py-5 text-center lg:py-8">
              <Empty /> <Text className="mt-3">No Coupons Found</Text>
            </div>
          )}
        </WidgetCard>
      </>
    </>
  );
}

export default withRoleAuth([
  roles.agency,
  roles.teamAgency.team_agency
])(CouponsPage);
