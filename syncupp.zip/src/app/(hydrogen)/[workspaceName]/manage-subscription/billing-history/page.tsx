import BillingHistoryPage from './main-page';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Billing History'),
};

export default function page() {
  return (
    <>
    <div className='main_card_block'>
      <BillingHistoryPage title={'Billing History'} />
    </div>
    </>
  );
}
