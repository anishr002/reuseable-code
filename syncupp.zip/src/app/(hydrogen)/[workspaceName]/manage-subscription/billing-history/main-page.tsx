'use client'

import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { billingColumns } from '@/app/shared/(user)/manage-subscription/billingcoloum';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import SimpleBar from '@/components/ui/simplebar';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import { getAllBilling } from '@/redux/slices/user/manage-subscription.tsx/SubscriptionSlice';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

function BillingHistoryPage(props: any) {
  const { title } = props;
  const disptach = useDispatch();
  const [pageSize, setPageSize] = useState<number>(10);
  const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace)


  const {
    BillinglistDetails,
    loading,
  } = useSelector((state: any) => state?.root?.managesubcription);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    const response = await disptach(
      getAllBilling({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        pagination: true,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await disptach(
        getAllBilling({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          pagination: true,
        })
      );
      return data?.payment_history;
    }
    if (data && data?.payment_history && data?.payment_history?.length !== 0) {
      return data?.payment_history;
    }
  };

  return (
    <>
      <CustomePageHeader title={title} route={routes.manageSubcription(defaultWorkSpace?.name)} titleClassName="montserrat_font_title"></CustomePageHeader>
      <WidgetCard
        rounded="lg"
        className="mt-4"
        title=""
        headerClassName="@2xl "
      >
        <div className="table_border_remove">
            <CustomTable
              data={BillinglistDetails?.data?.payment_history || []}
              total={BillinglistDetails?.data?.page_count}
              loading={loading}
              pageSize={pageSize}
              setPageSize={setPageSize}
              handleChangePage={handleChangePage}
              getColumns={billingColumns}
              scroll={{ x: 0 }}
            />
          </div>
      </WidgetCard>
    </>
  );
}

export default withRoleAuth([roles.agency])(
  BillingHistoryPage
);
