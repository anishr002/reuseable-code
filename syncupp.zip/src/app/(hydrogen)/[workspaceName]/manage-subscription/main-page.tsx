'use client';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { GetColumns } from '@/app/shared/(user)/manage-subscription/manageseatscoloums';
import ModalButton from '@/app/shared/modal-button';
import { useModal } from '@/app/shared/modal-views/use-modal';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Empty } from '@/components/ui/empty';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import socket from '@/io';
import {
  getUserProfile,
  signOutUser,
} from '@/redux/slices/user/auth/signinSlice';
import {
  CancleSubscription,
  RemoveUsersub,
  accountdeactivate,
  getAllBilling,
  getAllSeats,
  getAllcarddata,
} from '@/redux/slices/user/manage-subscription.tsx/SubscriptionSlice';
import MultipleSheetLogo from '@public/assets/svgs/multiple-sheet-logo.svg';
import PlanCheck from '@public/assets/svgs/plan-check.svg';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DeleteModel from './CustomPoup';
import SelectSubscriptionPlanModal, {
  periodName,
} from './select-subscription-plan-modal';

const generateDummyData = (count: any) => {
  const dummyData = [];

  for (let i = 1; i <= count; i++) {
    dummyData.push({
      seat_No: `Seat ${i}`,
      Allocated_To: `User ${i}`,
      user_type: Math.random() > 0.5 ? 'Admin' : 'User',
      status: Math.random() > 0.5 ? 'Active' : 'Inactive',
      _id: i, // Assuming this is a unique identifier for each row
    });
  }

  return dummyData;
};

const limitedPlanDetails = [
  {
    label: 'Unlimited Users',
    value: 'Unlimited Users',
  },
  {
    label: 'Unlimited Workspace',
    value: 'Unlimited Workspace',
  },
  {
    label: 'Unlimited Proposals',
    value: 'Unlimited Proposals',
  },
  {
    label: 'Unlimited Boards',
    value: 'Unlimited Boards',
  },
  {
    label: 'Unlimited Invoices',
    value: 'Unlimited Invoices',
  },
  {
    label: '+ More',
    value: 'more',
  },
];

// Usage example
const dummyDataCount = 10; // You can adjust this based on the number of rows you want
const dummyData = generateDummyData(dummyDataCount);

function SubcripationPage() {
  const {
    BillinglistDetails,
    SeatsData,
    CardData,
    loading,
    pendingaccountdata,
  } = useSelector((state: any) => state?.root?.managesubcription);
  const { userProfile } = useSelector((state: any) => state?.root?.signIn);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();

  const [pageSize, setPageSize] = useState<number>(2);
  const [pageSizeSheet, setPageSizeSheet] = useState<number>(10);

  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    const response = await dispatch(
      getAllBilling({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        pagination: true,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllBilling({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          pagination: true,
        })
      );
      return data?.payment_history;
    }
    if (data && data?.payment_history && data?.payment_history?.length !== 0) {
      return data?.payment_history;
    }
  };

  const handleChangePageSheet = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    const response = await dispatch(
      getAllSeats({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        pagination: true,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllSeats({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          pagination: true,
        })
      );
      return data?.sheets;
    }
    if (data && data?.sheets && data?.sheets?.length !== 0) {
      return data?.sheets;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      let res: any;
      if (id === 'Deactivate') {
        res = await dispatch(accountdeactivate());
        if (res.payload.success === true) {
          dispatch(signOutUser()).then((result: any) => {
            socket.emit('USER_DISCONNECTED', { user_id: userProfile?._id });
            if (signOutUser.fulfilled.match(result)) {
              router.replace(`${routes.signIn}?logout=true`);
            }
          });
        }
        return;
      }

      if (id === 'subscription') {
        res = await dispatch(CancleSubscription());
        if (res.payload.success === true) {
          dispatch(getAllcarddata());
          dispatch(getUserProfile());
        }
      } else {
        res = await dispatch(
          RemoveUsersub({ user_id: id, force_fully_remove: false })
        );
        if (res?.payload?.data?.force_fully_remove === true) {
          openModal({
            view: (
              <DeleteModel
                forsfully={res?.payload?.data?.force_fully_remove}
                id={id}
                page={currentPage}
                items_per_page={countPerPage}
                sort_field={sortConfig?.key}
                sort_order={sortConfig?.direction}
                search={searchTerm}
                pagination={true}
              />
            ),
            customSize: '500px',
          });
        }
      }
      if (res.payload.success === true) {
        // closeModal();
        const reponse = await dispatch(
          getAllSeats({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            search: searchTerm,
            pagination: true,
          })
        );
        dispatch(getAllcarddata());
        dispatch(getUserProfile());
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    dispatch(
      getAllBilling({
        items_per_page: 2,
        page: 1,
        pagination: true,
        search: '',
        sort_field: 'createdAt',
        sort_order: 'desc',
      })
    );
    dispatch(getAllSeats({ pagination: false }));
    dispatch(getAllcarddata());
    dispatch(getUserProfile());
  }, [dispatch]);

  return (
    <>
      <CustomePageHeader
        title="Subscription"
        titleClassName="montserrat_font_title"
      >
        <div className="mt-4 flex items-center gap-3 @lg:mt-0">
          {['agency']?.includes(signIn?.role) &&
            !!userProfile?.purchased_plan &&
            !!userProfile?.subscribe_date &&
            !!userProfile?.subscription_id && (
              <ModalButton
                label="Change Plan"
                view={
                  <SelectSubscriptionPlanModal
                    title="Manage Your Subscription Plan"
                    openFromManageSubPag={true}
                  />
                }
                // size="DEFAULT"
                customSize="900px"
                className="h-12 w-44 rounded-3xl bg-[#E6E5F5] text-sm text-[#8C80D2]"
                // icon={<PiPlusBold className="me-1.5 h-[17px] w-[17px]" />}
              />
            )}
        </div>
      </CustomePageHeader>

      {pendingaccountdata &&
      pendingaccountdata?.data &&
      pendingaccountdata.data?.is_subscription_halted === true ? (
        <div className="mb-3 flex cursor-pointer items-center justify-between gap-4 bg-primary-lighter/10 px-5 py-3  text-red-500  dark:bg-gray-100">
          <p>
            It appears that your subscription payment is pending, possibly due
            to an expired card, please update your payment information here to
            ensure continued access.{' '}
            <span
              className="cursor-pointer underline"
              onClick={() =>
                window.open(
                  `${CardData?.data?.subscription?.short_url}`,
                  '_blank'
                )
              }
            >
              from here
            </span>{' '}
            .
          </p>
        </div>
      ) : (
        ''
      )}

      <div>
        <div className="lg:flex">
          {/* Additinal Seats */}
          <div className="mr-4 w-full rounded-xl border border-gray-200 bg-gray-0 p-5 dark:bg-gray-50 lg:w-[30%] lg:p-7">
            <div className="flex flex-col items-center gap-4">
              <p className="poppins_font_number w-full pb-3 text-center text-[20px] font-bold leading-7">
                {CardData?.data?.subscription_plan?.name
                  ? CardData?.data?.subscription_plan?.name
                  : 'Free Trial'}
              </p>
              {/* Image */}
              <Image
                className="h-auto pb-3"
                src={MultipleSheetLogo}
                alt="Sheet Logo"
                width={114}
                height={206}
              />
              {/* Price */}
              {CardData?.data?.subscription_plan?.amount && (
                <div className="flex pb-3">
                  <p className="poppins_font_number text-xl font-semibold text-[#9BA1B9]">
                    {CardData?.data?.subscription_plan?.symbol ?? '$'}
                  </p>{' '}
                  <p className="poppins_font_number text-4xl font-semibold text-[#120425]">
                    {CardData?.data?.subscription_plan?.amount > 0
                      ? CardData?.data?.subscription_plan?.amount / 100
                      : 0}
                  </p>
                  <p className="flex flex-col justify-end text-xl font-semibold text-[#9BA1B9]">
                    {CardData?.data?.subscription_plan?.period &&
                      CardData?.data?.subscription_plan?.period !==
                        'lifetime' &&
                      `/${
                        periodName[CardData?.data?.subscription_plan?.period]
                      }`}
                  </p>
                </div>
              )}

              {/* Plan details */}
              <div className="flex flex-col pb-3">
                {limitedPlanDetails?.map((data: any) => (
                  <div className="flex" key={data?.label}>
                    {data?.value !== 'more' ? (
                      <Image
                        className="mb-2 mr-2"
                        src={PlanCheck}
                        alt="CheckMark"
                        width={20}
                        height={20}
                      />
                    ) : (
                      <p className="w-[20px]"></p>
                    )}
                    {data?.label === 'Unlimited Users' ? (
                      <>
                        {CardData?.data?.subscription_plan?.no_of_users ? (
                          <p>
                            <span className="poppins_font_number">
                              {CardData?.data?.subscription_plan?.no_of_users ||
                                0}
                            </span>{' '}
                            Users
                          </p>
                        ) : (
                          <p>{data?.label}</p>
                        )}
                      </>
                    ) : data?.label === 'Unlimited Workspace' ? (
                      <>
                        {CardData?.data?.subscription_plan?.workspaces_count &&
                        CardData?.data?.subscription_plan?.period !==
                          'lifetime' ? (
                          <p>
                            <span className="poppins_font_number">
                              {`${
                                CardData?.data?.subscription_plan
                                  ?.workspaces_count || 0
                              }`}{' '}
                            </span>{' '}
                            {` Workspace${
                              CardData?.data?.subscription_plan
                                ?.workspaces_count === 1
                                ? ''
                                : 's'
                            }`}
                          </p>
                        ) : (
                          <>
                            {CardData?.data?.subscription_plan?.period ===
                            'lifetime' ? (
                              <p>{data?.label}</p>
                            ) : (
                              <p>
                                <span className="poppins_font_number">1</span>{' '}
                                Workspace
                              </p>
                            )}
                          </>
                        )}
                      </>
                    ) : (
                      <p>{data?.label}</p>
                    )}
                  </div>
                ))}
              </div>

              {/* Additional seats */}
              {/* <Button
                size="xl"
                className="flex items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
              >
                Buy additional seats
              </Button> */}

              {/* Available seats */}
              {CardData?.data?.subscription_plan && (
                <p className="flex items-center	justify-start	gap-3 pb-3 text-sm font-semibold text-[#9BA1B9]">
                  Available Seats{' '}
                  <span className="poppins_font_number text-xl font-bold text-[#120425]">
                    {CardData?.data?.available_sheets || 0}
                  </span>
                </p>
              )}
            </div>
          </div>

          <div className="mt-4 lg:mt-0 lg:w-[70%]">
            <div className="grid h-full grid-cols-1">
              {/* Upper Div */}
              <div className="mb-4 grid grid-cols-1 lg:grid-cols-2">
                {/* Next Billing */}
                <div className="mb-4 mr-0 grid grid-cols-1 rounded-xl border border-gray-200 bg-gray-0 p-5 dark:bg-gray-50 lg:mb-0 lg:mr-4 lg:p-7">
                  <p className="text-2xl font-bold text-[#9BA1B9]">
                    Next Billing
                  </p>
                  {CardData?.data?.subscription_plan?.amount && (
                    <p className="flex	items-center justify-start gap-3 text-sm text-[#9BA1B9]">
                      Amount{' '}
                      <span className="poppins_font_number text-xl font-bold text-[#120425]">
                        {CardData?.data?.subscription_plan?.symbol ?? '$'}{' '}
                        {CardData?.data?.subscription_plan?.amount > 0
                          ? CardData?.data?.subscription_plan?.amount / 100
                          : 0}
                      </span>
                    </p>
                  )}
                  <p className="flex	items-center justify-start gap-3 text-sm text-[#9BA1B9]">
                    Total Seats{' '}
                    <span className="poppins_font_number text-xl font-bold text-[#120425]">
                      {' '}
                      {CardData?.data?.total_sheets > 0
                        ? CardData?.data?.total_sheets
                        : 0}
                    </span>
                  </p>
                  <p className="flex	items-center justify-start gap-3 text-sm text-[#9BA1B9]">
                    Billing Date{' '}
                    <span className="poppins_font_number text-xl font-bold text-[#120425]">
                      {CardData?.data?.next_billing_date
                        ? moment
                            .unix(CardData?.data?.next_billing_date)
                            .format('DD MMM, YYYY') === 'Invalid date'
                          ? moment(CardData?.data?.next_billing_date).format(
                              'DD MMM, YYYY'
                            )
                          : moment
                              .unix(CardData?.data?.next_billing_date)
                              .format('DD MMM, YYYY')
                        : CardData?.data?.subscription?.charge_at
                          ? moment
                              .unix(CardData?.data?.subscription?.charge_at)
                              .format('DD MMM, YYYY')
                          : '-'}
                    </span>
                  </p>
                </div>

                {/* Total Points */}
                <div className="grid grid-cols-1 rounded-xl border border-gray-200 bg-gray-0 dark:bg-gray-50">
                  <p className="px-5 pt-5 text-2xl font-bold text-[#9BA1B9] lg:px-7 lg:pt-7">
                    Total Points
                  </p>
                  <p className="flex items-center justify-start gap-3 px-5 py-1 text-sm text-[#9BA1B9] lg:px-7 lg:py-0">
                    Available Points{' '}
                    <span className="poppins_font_number text-xl font-bold text-[#120425]">
                      {CardData?.data?.referral_points?.available_points || 0}{' '}
                    </span>
                  </p>
                  <p className="flex items-center justify-start gap-[19px] px-5 py-1 text-sm text-[#9BA1B9] lg:px-7 lg:py-0">
                    Lifetime Points{' '}
                    <span className="poppins_font_number text-xl font-bold text-[#120425]">
                      {CardData?.data?.referral_points?.erned_points || 0}{' '}
                    </span>
                  </p>
                  <p className="border-t border-t-[#E3E1F4] px-5 py-4 lg:px-7 lg:py-6">
                    <Link
                      className="font-semibold capitalize text-[#8C80D2] transition-colors hover:underline"
                      href={routes.coupons(defaultWorkSpace?.name)}
                    >
                      Redeem Coupons
                    </Link>
                  </p>
                </div>
              </div>

              {/* Billing History */}
              <div className="rounded-xl border border-gray-200 bg-gray-0 dark:bg-gray-50">
                <p className="text-bold p-5 text-[28px] text-[#9BA1B9] lg:p-7">
                  Billing History
                </p>
                {BillinglistDetails?.data?.payment_history?.length > 0 &&
                  BillinglistDetails?.data?.payment_history
                    ?.slice(0, 2)
                    ?.map((response: any, key: any) => {
                      return (
                        <div
                          key={response?._id}
                          className="flex justify-between border-t border-t-[#E3E1F4] px-5 py-3 pb-5 lg:px-7"
                        >
                          <div>
                            <p className="text-xl font-bold text-[#120425]">
                              {moment(response?.createdAt).format('MMM')}
                            </p>
                            <p className="poppins_font_number">
                              {moment(response?.createdAt).format(
                                'DD MMM, YYYY'
                              )}
                            </p>
                          </div>
                          <div>
                            <p className="poppins_font_number text-xl font-bold text-[#120425]">
                              {response?.payment_mode === 'payment' && (
                                <>
                                  {response?.currency === 'INR' ? '₹' : '$'}{' '}
                                  {parseFloat(response?.amount) / 100}
                                </>
                              )}
                              {response?.payment_mode === 'manual' && (
                                <>Manual</>
                              )}
                              {response?.payment_mode === 'referral' &&
                                response?.amount}
                              {response?.payment_mode === 'free_trial' && (
                                <>Free Trial</>
                              )}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                {BillinglistDetails?.data?.payment_history?.length === 0 && (
                  <div className="flex items-center justify-center p-10">
                    <Empty
                      text="No Data"
                      textClassName="mt-4 text-base text-gray-500"
                    />
                  </div>
                )}
                <div className="flex justify-between border-t border-t-[#E3E1F5] px-5 py-4 pb-5 lg:px-7">
                  {signIn?.role === roles.agency &&
                    !!userProfile?.purchased_plan &&
                    !!userProfile?.subscribe_date &&
                    !!userProfile?.subscription_id &&
                    CardData?.data?.subscription?.short_url && (
                      <Link
                        className="font-semibold capitalize text-[#8C80D2] transition-colors hover:underline"
                        target="_blank"
                        href={`${CardData?.data?.subscription?.short_url}`}
                      >
                        Change Payment Method
                      </Link>
                    )}
                  <Link
                    className="font-semibold capitalize text-[#8C80D2] transition-colors hover:underline"
                    href={routes.billingHistory(defaultWorkSpace?.name)}
                  >
                    View More
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="main_card_block">
        <WidgetCard
          rounded="lg"
          className="mt-4"
          title=""
          headerClassName="@2xl"
          titleClassName="text-[#9BA1B9] text-bold "
        >
          <div className="table-title">
            <p className="text-[28px] font-semibold text-[#9BA1B9]">
              Manage Seats
            </p>
          </div>

          <div className="table_border_remove">
            <CustomTable
              // data={dummyData}
              data={SeatsData?.data?.sheets || []}
              total={SeatsData?.data?.page_count}
              loading={loading}
              pageSize={pageSizeSheet}
              setPageSize={setPageSizeSheet}
              handleDeleteById={handleDeleteById}
              // handeldeltesub={handleDeleteSub}
              handleChangePage={handleChangePageSheet}
              getColumns={GetColumns}
              scroll={{ x: 0 }}
            />
          </div>
        </WidgetCard>
      </div>
    </>
  );
}

export default withRoleAuth([roles.agency])(SubcripationPage);
