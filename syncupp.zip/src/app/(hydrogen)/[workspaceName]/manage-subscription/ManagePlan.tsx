import { ActionIcon, Title } from '@/components/ui/text';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { PiCurrencyCircleDollar, PiXBold } from 'react-icons/pi';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  changeSubscriptionplan,
  getPlanDetails,
} from '@/redux/slices/user/manage-plan/ManagePlanSlice';
import { useForm, Controller } from 'react-hook-form';
import Spinner from '@/components/ui/spinner';
import { Button } from '@/components/ui/button';
import { usePathname, useRouter } from 'next/navigation';
import { initiateRazorpay } from '@/services/paymentService';
import { routes } from '@/config/routes';
import { getUserProfile } from '@/redux/slices/user/auth/signinSlice';
import {
  getAllBilling,
  getAllSeats,
  getAllcarddata,
} from '@/redux/slices/user/manage-subscription.tsx/SubscriptionSlice';
import cn from '@/utils/class-names';
import { siteConfig } from '@/config/site.config';
import Image from 'next/image';
import syncUppLogo from '@public/assets/svgs/plan-syncupp-logo.svg';

export default function ManagePlan(props: any) {
  const { closeModal } = useModal();
  const dispatch = useDispatch();
  const router = useRouter();

  const { control, handleSubmit, setValue } = useForm();
  const [selectedPlan, setselectedPlan] = useState(undefined);
  const { title, planexpire, openFromManageSubPag = false } = props;

  // state Data selection
  const { planList, planListLoading, loading } = useSelector(
    (state: any) => state?.root?.managePlan
  );
  const { userProfile } = useSelector((state: any) => state?.root?.signIn);
  const { user } = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const pathname = usePathname().startsWith(
    routes.manageSubcription(defaultWorkSpace?.name)
  );
  const token = localStorage.getItem('token');


  // console.log(planList, 'planList', user);
  // console.log(userProfile?.purchased_plan?.plan_type != 'unlimited', 'userProfile', pathname)

  useEffect(() => {
    dispatch(getPlanDetails());
    // dispatch(getUserProfile())
    // setValue('plan', userProfile?.purchased_plan?._id);
  }, [dispatch]);

  useEffect(() => {
    userProfile?.purchased_plan?._id && userProfile?.purchased_plan?._id != ''
      ? setValue('plan', userProfile?.purchased_plan?._id)
      : setValue('plan', planList[0]?._id);
    setselectedPlan(
      userProfile?.purchased_plan?._id && userProfile?.purchased_plan?._id != ''
        ? userProfile?.purchased_plan?._id
        : planList[0]?._id
    );
  }, [planList, userProfile]);

  const onSubmit = (data: any) => {
    // console.log(data, 'data');

    // const filterplandata = planList.filter((data)=>)
    // const filterplandata = planList.filter((plandata: any) => plandata?.plan_id === data?.plan);
    // console.log(filterplandata, 'filterplandata')
    if (pathname && openFromManageSubPag) {
      // console.log(userProfile?._purchased_plan != data?.plan, '47', userProfile?.purchased_plan, data?.plan)
      if (userProfile?.purchased_plan?._id != data?.plan) {
        dispatch(changeSubscriptionplan({ plan_id: data?.plan })).then(
          (result: any) => {
            if (changeSubscriptionplan.fulfilled.match(result)) {
              // console.log('resultt', result)
              if (result && result.payload.success === true) {
                closeModal();
                dispatch(getUserProfile());
                dispatch(getAllBilling({ pagination: false }));
                dispatch(getAllSeats({ pagination: false }));
                dispatch(getAllcarddata());
                // initiateRazorpay(router, routes.dashboard, user?.data?.token, dispatch, data?.plan)
              }
            }
          }
        );
      }
    } else {
      closeModal();
      initiateRazorpay(
        router,
        routes.dashboard(defaultWorkSpace?.name),
        token,
        dispatch,
        data?.plan
      );
    }
  };

  return (
    <>
      <div className="flex justify-end p-4">
        <ActionIcon
          size="sm"
          variant="text"
          onClick={() => closeModal()}
          className="text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="h-[18px] w-[18px]" />
        </ActionIcon>
      </div>
      <div className="mb-3 flex items-center justify-center text-xl font-bold text-[#120425] xl:text-2xl">
        {title}
      </div>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="px-10 pb-10 [&_label]:font-medium"
      >
        <div className="space-y-4">
          {planListLoading && (
            <div className="!grid h-full min-h-[128px] flex-grow place-content-center items-center justify-center">
              <Spinner size="xl" />
            </div>
          )}
          {!planListLoading && planList?.length == 0 && <div>No plan</div>}
          <div className="flex flex-col">
            {!planListLoading &&
              planList?.length > 0 &&
              planList?.map((data: any) => (
                <div
                  key={data?._id}
                  className="mb-2 w-[100%] p-1"
                  onClick={() => (
                    setselectedPlan(data?._id), setValue('plan', data?._id)
                  )}
                >
                  <div
                    className={`w-full rounded-3xl border p-5 ${
                      selectedPlan == data?._id
                        ? 'border-[#8C80D2] bg-[#F7F6FF]'
                        : 'border-[#9BA1B9] bg-[#FFFFFF]'
                    }`}
                  >
                    <div className="flex">
                      <span
                        className={cn(
                          'me-5 flex rounded-[14px] p-1 text-gray-0 dark:text-gray-900'
                        )}
                      >
                        <Image
                          className="me-3 h-auto w-[30px]"
                          src={syncUppLogo}
                          alt="Syncupp"
                          width={30}
                          height={30}
                        />
                      </span>
                      <div className="w-full">
                        <div className="flex content-center justify-between">
                          <Title
                            as="h3"
                            className="mb-1 text-sm	font-bold text-[#9BA1B9] md:text-lg"
                          >
                            {data?.name}
                          </Title>
                          <Controller
                            name="plan"
                            control={control}
                            defaultValue=""
                            render={({ field }) => (
                              <input
                                className="ms-2"
                                type="radio"
                                {...field}
                                value={selectedPlan}
                                checked={field.value === data?._id}
                              />
                            )}
                          />
                        </div>
                        <div className="flex items-center gap-5">
                          <div className="text-gray-500">
                            <span className="rizzui-text-span text-lg font-semibold text-gray-700 md:text-2xl poppins_font_number">
                              {data?.symbol} {data?.amount / 100}
                            </span>{' '}
                            <span className="font-bold text-[#9BA1B9]">
                              / {data?.seat} seat per month
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
        <div className="mt-2">
          <Button
            disabled={loading}
            className="flex w-full items-center justify-center rounded-full bg-[#8C80D2] px-6 py-4 text-[16px] font-semibold text-[#fff] hover:border-2 hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] lg:w-[200px]"
            type="submit"
            size="xl"
          >
            <span>Submit</span>
            {loading && <Spinner size="sm" tag="div" className="ms-3" color="white" />}
          </Button>
        </div>
      </form>
    </>
  );
}
