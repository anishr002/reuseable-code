'use client';
import { useRouter } from 'next/navigation';
import { useState,useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { GetLeadeboardColumns } from '@/app/shared/(user)/leaderboard/columns';
import { useModal } from '@/app/shared/modal-views/use-modal';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { roles } from '@/config/roles';
import { getallleaderbord } from '@/redux/slices/user/dashboard/dashboardSlice';
import restImg from '@public/assets/images/reset_icon.svg';
import moment from 'moment';
import { Button } from 'rizzui';
import Image from 'next/image';

const pageHeader = {
  title: 'Leaderboard',
};

function LeaderBoardPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState(moment().startOf('month').format('YYYY-MM-DD'));
  const [endDate, setEndDate] = useState(moment().endOf('month').format('YYYY-MM-DD'));
  const [reset, setReset] = useState(false);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { leaderborddata, getallleaderbordLoader } = useSelector((state: any) => state?.root?.dashbord);


  const [pageSize, setPageSize] = useState<number>(10);


  useEffect(() => {
    !!endDate &&
      dispatch(
        getallleaderbord({
          page: 1,
          date: { start_date: startDate, end_date: endDate },
          items_per_page: 10,
          search: "",
          sort_field: "totalPoints",
          sort_order: "desc"
        })
      );
  }, [endDate, startDate]);


  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } = paginationParams;

    const response = await dispatch(getallleaderbord({ page, items_per_page, sort_field, sort_order, search, date: { start_date: startDate, end_date: endDate } }));
    const { data } = response?.payload;
    console.log("dataaa......", data)
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(getallleaderbord({ page, items_per_page, sort_field, sort_order, search, date: { start_date: startDate, end_date: endDate } }));
      return data?.leaderboard
    }
    if (data && data?.leaderboard?.length > 0) {
      return data?.leaderboard
    }
  };


  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {

  };
  const handleResetFilters = () => {
    setReset(true);
    setStartDate(moment().startOf('month').format('YYYY-MM-DD'))
    setEndDate(moment().endOf('month').format('YYYY-MM-DD'))
  }

  const LeaderboardFilter = () => {
    return (
      <>
        <Button
          className="flex h-[40px] items-center justify-center rounded-3xl w-[50%] bg-[#E3E1F4] text-sm text-[#8C80D2]"
          onClick={handleResetFilters}
        >
          <Image
            className="mr-2 text-white"
            alt="reste"
            width={15}
            height={15}
            src={restImg}
          />
          Reset
        </Button>
      </>)
  }



  return (
    <>
      <CustomePageHeader title={pageHeader.title} titleClassName="montserrat_font_title" />
      <WidgetCard rounded="lg" title="" className='mt-[40px]'>
        <div className="table_border_remove">
          <CustomTable
            data={(leaderborddata && leaderborddata?.data?.leaderboard) || []}
            total={(leaderborddata && leaderborddata?.data?.page_count) || 1}
            loading={getallleaderbordLoader}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={GetLeadeboardColumns}
            isRangeFilter={['agency'].includes(signIn.role)}
            setPeriod={setPeriod}
            setStartDate={setStartDate}
            setEndDate={setEndDate}
            scroll={{ x: 600 }}
            resetValue={reset}
            setReset={setReset}
            reset={reset}
            filtersList={<LeaderboardFilter/>}
            isaAttendanceDate={true}
          />
        </div>
      </WidgetCard>
    </>
  );
}

export default withRoleAuth([roles.agency, roles.teamAgency.team_agency])(LeaderBoardPage);
