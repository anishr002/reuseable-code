
import { metaObject } from '@/config/site.config';
import LeaderBoardPage from './main-page';

export const metadata = {
  ...metaObject('Leaderboard'),
};

export default function Page() {
  return (
    <div className='main_card_block'>
      <LeaderBoardPage />
    </div>
  );
}
