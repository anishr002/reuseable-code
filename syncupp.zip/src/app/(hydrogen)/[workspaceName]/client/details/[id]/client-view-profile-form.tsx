'use client';

import { Text, Title } from '@/components/ui/text';
import cn from '@/utils/class-names';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { Link } from 'react-scroll';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { PhoneNumber } from '@/components/ui/phone-input';
import Spinner from '@/components/ui/spinner';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import { setActivityUserReferenceId } from '@/redux/slices/user/activity/activitySlice';
import { getClientById, UpdateClientDetails } from '@/redux/slices/user/client/clientSlice';
import { Button } from 'rizzui';
import 'src/layouts/helium/style.css';
import ClientActivityTablePage from './client-activity-details';
import ClientAgreementTablePage from './client-agreement-details';
import ClientInvoiceTablePage from './client-invoice-details';
import { capitalizeFirstLetter, handleKeyDown } from '@/utils/common-functions';
import Image from 'next/image';
import TrashIcon from '@/components/icons/trash';
import fileUploadIcon from '@public/assets/svgs/fileUploadIcon.svg';
import { IoWarningOutline } from 'react-icons/io5';
import { Form } from '@/components/ui/form';
import { ClientDetailsForm, ClientDetailsSchema } from '@/utils/validators/ClientDetails.Schema';
import { UseFormReturn } from 'react-hook-form';
import { Input } from 'rizzui'
import { Controller } from 'react-hook-form';
import Select from '@/components/ui/select';
import { FiEdit } from 'react-icons/fi';





const menuItems = [
  {
    label: 'Meetings',
  },
  {
    label: 'Agreements',
  },
  {
    label: 'Invoices',
  },
];

const pageHeader = {
  title: 'Client Details',
};

function ClientViewProfileForm(props: any) {
  const { id } = props;
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { clientSliceData, loading } = useSelector((state: any) => state?.root?.client);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const router = useRouter();

  const [selectedTask, setSelectedTask] = useState('Meetings');
  const [clientId, setClientId] = useState('');
  const [clientName, setClientName] = useState('');
  // console.log("client name...", clientName)
  const [profileData, setProfileData] = useState<any>({});
  const [imageFile, setImageFile] = useState<any>();
  const [clientRole, SetClientRole] = useState('');
  const [previewImage, setPreviewImage] = useState<any>();
  const [error, setError] = useState('');
  const [client, SetClient] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [taxDetails, setTaxDetails] = useState(false)
  const [gst, setGST] = useState('');

  useEffect(() => {
    // dispatch(resetAgreementlist({}))
    // dispatch(RemoveinvoiceData())
  }, []);

  useEffect(() => {
    if (profileData?.client_logo) {
      const imageUrl = `${process.env.NEXT_PUBLIC_IMAGE_URL}/${profileData?.client_logo}`;
      setPreviewImage(imageUrl);
    }
  }, [profileData]);


  const fetchClientDetails = async (id: string) => {
    if (!id) return;

    try {
      const result = await dispatch(getClientById({ _id: id }));
      console.log(result, "result");
      if (getClientById.fulfilled.match(result) && result.payload?.success) {
        const clientData = result.payload.data;

        setProfileData(clientData);
        setClientId(clientData._id);
        SetClientRole(clientData.user_role);
        SetClient(clientData.role?.name);
        setGST(clientData.gst_number);
        dispatch(setActivityUserReferenceId(clientData._id));

        const fullName = `${clientData.first_name.charAt(0).toUpperCase()}${clientData.first_name.slice(1)} ${clientData.last_name.charAt(0).toUpperCase()}${clientData.last_name.slice(1)}`;
        setClientName(fullName);
      }
    } catch (error) {
      console.error('Error fetching client details:', error);
    }
  };

  useEffect(() => {
    fetchClientDetails(id);
  }, [id, dispatch]);

  // let data = clientSliceData?.clientProfile;

  const handleTaskClick = (task: any) => {
    // dispatch(resetAgreementlist({}))
    // dispatch(RemoveinvoiceData())
    setSelectedTask(task);
  };
  const handleImageChange = (e: any) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        setError('Image size should be less than 50MB.');
        return;
      }
      const validImageTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      if (!validImageTypes.includes(file.type)) {
        setError('Only JPG, JPEG, and PNG formats are allowed.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setError('');
      };
      reader.readAsDataURL(file);
      setImageFile(file);
      setPreviewImage(file);
      handleImageSave(file);
    }
  };

  const taxPreference = [
    { value: 'taxable', name: 'Taxable' },
    { value: 'nonTaxable', name: 'Non-Taxable' },
  ];

  const taxID = [
    { value: 'GST', name: 'GST ( India )' },
    { value: 'VAT', name: 'VAT' },
  ]

  const initialValues: ClientDetailsForm = {
    gst_number: profileData?.gst_number ? profileData?.gst_number : '',
    pan_number: profileData?.pan_number ? profileData?.pan_number : '',
    tax_preference: profileData?.tax_preference ? profileData?.tax_preference : taxPreference[0]?.value,
    tax_id: profileData?.tax_id ? profileData?.tax_id : taxID[0]?.value,
  };

  const handleImageSave = async (file:any) => {
    if (!file) {
      setError('Please select an image to upload.');
      return;
    }

    // Create FormData for image upload
    const formData = new FormData();
    formData.append('client_logo', file);

    try {
      // Dispatch API call with only the image
      dispatch(UpdateClientDetails({ data: formData, id: clientId })).then((result: any) => {
        if (result.payload?.success === true) {
          // router.push(routes.client(defaultWorkSpace?.name));
          fetchClientDetails(id);
        }
      });

    } catch (error) {
      console.error('Error saving image:', error);
    }
  };


  const handlesubmit = (data: any) => {
    console.log(data, "dataaaa");
    console.log(clientId, "clientId");

    // Make sure to exclude the image from the form submit
    const formData = {
      gst_number: data.gst_number,
      pan_number: data.pan_number,
      tax_preference: data.tax_preference,
      tax_id: data.tax_id,
    };

    dispatch(UpdateClientDetails({ data: formData, id: clientId })).then((result: any) => {
      if (result.payload?.success === true) {
        // router.push(routes.client(defaultWorkSpace?.name));
        fetchClientDetails(id);
        setShowForm(false);
      }
    });
  };
  // console.log(profileData, "profileData")
  return (
    <>
      <CustomePageHeader
        title={pageHeader.title}
        route={routes.client(defaultWorkSpace?.name)}
        titleClassName="montserrat_font_title"
      >
        {/* <PageHeader title={pageHeader.title}>
        <div className="mt-4 flex items-center gap-3 @lg:mt-0">
          <Link href={routes.client(defaultWorkSpace?.name)}>
            <Button className="mt-5 w-full bg-none text-xs @lg:w-auto sm:text-sm lg:mt-0">
              <FaArrowLeft className="me-1.5 h-[17px] w-[17px]" />
              Back
            </Button>
          </Link>
        </div>
      </PageHeader> */}
      </CustomePageHeader>
      {
        !loading && client === "client" && (
          <div className="mb-5 mt-5 grid grid-cols-1 items-center">
            {previewImage ? (
              <div className="flex items-center justify-start gap-2.5">
                <div className='rounded-lg relative'>
                <Image
                  alt="img"
                  className="object-contain border-gray-400 "
                  src={previewImage}
                  width={150}
                  height={150}
                />
                </div>
                <span
                  className=" h-6 w-6 cursor-pointer text-[#F05252] font-medium text-xs"
                  onClick={() => {
                    setPreviewImage(null);
                  }}>Remove
                </span>
                  <div className='absolute top-[85px] left-[146px]  cursor-pointer bg-[#73737380] p-[2.86px] text-white rounded-[2.86px]'>
                <FiEdit
                  className="h-4 w-4"
                  onClick={() => {
                    document.getElementById('fileInput')?.click();
                  }}
                >
                </FiEdit>
                </div>
                <input
                  type="file"
                  id="fileInput"
                  accept="image/png, image/jpeg, image/jpg"
                  className="hidden"
                  onChange={handleImageChange}
                />
              </div>
            ) : (<>
              <div className="flex gap-5">
                <div className="w-fit">
                  <input
                    type="file"
                    accept="image/png, image/jpeg, image/jpg"
                    className="hidden"
                    id="file-upload"
                    onChange={handleImageChange}
                  />
                  <label
                    htmlFor="file-upload"
                    className="flex h-auto w-[210px] cursor-pointer flex-col gap-[10px] rounded-[10px] border border-dashed border-[#F98080] bg-[#F8FAFF] p-4 pb-[16px] pt-[16px]"
                    onClick={() => {
                      // logoimageref.current = setFieldValue;
                    }}
                  >
                    <div className="flex w-full justify-center">
                      <Image
                        alt="img"
                        src={fileUploadIcon}
                        width={20}
                        height={20}
                        className="h-5 w-5"
                      />
                    </div>
                    <div className="text-center font-medium text-sm text-[#5850EC]">
                      Add Client Info
                    </div>
                    <div className="text-center font-medium text-xs text-[#4B5563]">
                      Resolution upto 1080x1080 px.
                    </div>
                  </label>
                </div>
                {!previewImage && (
                  <div className='flex justify-center items-center text-[#F05252] gap-2'>
                    <IoWarningOutline className='h-5 w-5' />
                    <p className='text-[#F05252] text-xs font-medium'>No Logo added yet.</p>
                  </div>)
                }
              </div>
              <div className="mt-1 text-xs text-red-500">{error}</div>
            </>
            )}
            {/* <div className="mt-0.5 text-xs text-red">
                          {errors && errors?.invoice_logo
                            ? errors?.invoice_logo
                            : ''}
                        </div> */}
          </div>)
      }
      <div
        className={cn(
          'grid grid-cols-1 gap-6 pb-5 @3xl:gap-10 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3'
        )}
      >
        <InformationCard title="Personal Information" data={profileData} btn={false} />
        <InformationCard title="Company Information" data={profileData} btn={false} />
        <InformationCard title="General Information" data={profileData} btn={false} />
        {!loading && gst && (
          <InformationCard title="Tax Information" data={profileData} btn={true} setShowForm={setShowForm} />
        )}
      </div>
      {(!loading && !showForm && !gst && client === "client") && (
        <div className='pb-5'>
          <div className="flex h-auto w-full cursor-pointer flex-col gap-[10px] rounded-[10px] border border-dashed border-[#F98080] bg-[#F8FAFF] py-5 px-8"
          >
            <div className="font-bold flex gap-5 text-sm text-[#9DA2B5]">
              <p>Tax Information</p>
              <div className='flex justify-center items-center text-[#F05252] gap-2'>
                <IoWarningOutline className='h-5 w-5' />
                <p className='text-[#F05252] text-xs font-medium'>Tax information missing.</p>
              </div>
            </div>
            <div className="font-medium text-sm text-[#5850EC] underline"
              onClick={() => { setShowForm(true) }}
            >
              Add Tax Info
            </div>
          </div>
        </div>
      )}
      {(!loading && client === "client" && showForm) && (
        <div className='pb-5'>
          <WidgetCard rounded="lg" title="">
            <Form<ClientDetailsForm>
              validationSchema={ClientDetailsSchema}
              onSubmit={handlesubmit}
              useFormProps={{
                mode: 'onChange',
                defaultValues: initialValues,
              }}
            >
              {({ register, control, formState: { errors } }) => (<>

                <div className="mb-2 flex items-center justify-between pe-2">
                  <p className='text-[#9DA2B5] font-bold text-sm'>Tax Information</p>
                </div>
                <div>
                  <div className="grid grid-cols-1 md:grid-cols-2">
                    {/* Business GSTIN Field */}
                    <div className="my-5 mr-5">

                      <Input
                        // {...field}
                        onKeyDown={handleKeyDown}
                        {...register('gst_number')}
                        label="Business GSTIN"
                        placeholder="Business GSTIN"
                        labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                        className="w-full"
                        inputClassName="text-black rounded-[10px]"
                        type="text"
                        error={errors?.gst_number?.message}
                      />
                      {/* <ErrorMessage
                          name="gstin"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        /> */}
                    </div>

                    {/* Business PAN Number Field */}
                    <div className="my-5 mr-5">

                      <Input
                        // {...field}
                        onKeyDown={handleKeyDown}
                        labelClassName=" font-normal text-sm leading-[16.8px] text-[#141414]"
                        label="Business PAN Number"
                        error={errors?.pan_number?.message}
                        {...register('pan_number')}
                        placeholder="Business PAN Number"
                        className="w-full"
                        inputClassName="text-black rounded-[10px]"

                      />

                      {/* <ErrorMessage
                          name="pannumber"
                          component="div"
                          className="mt-0.5 text-xs text-red"
                        /> */}
                    </div>

                    {/* Tax Preference Field */}

                    <div className="mr-5 mt-1">
                      <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                        Tax Preference
                      </span>

                      <Controller
                        name="tax_preference"
                        control={control}
                        render={({ field: { onChange, value } }) => (

                          <Select
                            options={taxPreference}
                            className="w-full text-black"
                            onChange={(selectedOption) => onChange(selectedOption)}
                            value={value}
                            getOptionValue={(option: any) => option?.value}
                            getOptionDisplayValue={(option: any) => option?.name}
                            error={errors?.tax_preference?.message}
                          />
                        )}>

                      </Controller>


                      {/* <ErrorMessage
                          name="taxPreference"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        /> */}
                    </div>

                    {/* Tax ID Field */}

                    <div className="mr-5 mt-1">
                      <span className=" text-sm font-normal leading-[16.8px] text-[#141414]">
                        Tax ID
                      </span>

                      <Controller
                        name="tax_id"
                        control={control}
                        render={({ field: { onChange, value } }) => (

                          <Select
                            options={taxID}
                            className="w-full text-black"
                            onChange={(selectedOption) => onChange(selectedOption)}
                            value={value}
                            getOptionValue={(option: any) => option?.value}
                            getOptionDisplayValue={(option: any) => option?.name}
                            error={errors?.tax_id?.message}
                          // options={taxID}
                          // placeholder=""
                          // className="w-full"
                          // selectClassName=''
                          // optionClassName=''
                          // onChange={onChange}

                          // getOptionValue={(option) => option?.value}
                          // getOptionDisplayValue={(option: any) => option?.name}
                          // value={value}
                          />
                        )}>

                      </Controller>

                      {/* <ErrorMessage
                          name="taxId"
                          component="div"
                          className="absolute mt-0.5 text-xs text-red"
                        /> */}
                    </div>
                    <div className="mr-5 mt-1 py-4 flex gap-3">
                      <Button className='bg-[#FFFFFF] border-[#E5E7EB] text-[#111928] font-medium text-sm rounded-lg'
                        onClick={() => { setShowForm(false) }}
                      >
                        Cancel
                      </Button>
                      <Button className='bg-[#7667CF] text-white font-medium text-sm rounded-lg'
                        type='submit'
                        onClick={() => { setTaxDetails(true) }}
                      >
                        Save
                        {loading && (
                          <Spinner
                            size="sm"
                            tag="div"
                            className="ms-3"
                            color="white"
                          />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>


              </>
              )}

            </Form>
          </WidgetCard>
        </div>
      )

      }

      <div className="main_card_block">
        <WidgetCard rounded="lg" title="">
          {clientRole == 'client' && (
            <div className="tab-padding">
              {menuItems?.filter((menu: any) => {
                if (signIn?.role === 'team_agency' && signIn?.teamMemberRole === 'manager') {
                  if (menu.label === 'Meetings') return menu;
                } else {
                  return menu;
                }
              }).map((menu: any, index: number) => (
                <span
                  key={index}
                  className={
                    menu.label === selectedTask
                      ? 'border-8C80D2 border-b py-2.5'
                      : 'py-2.5'
                  }
                >
                  <Button
                    className={cn(
                      'group relative cursor-pointer whitespace-nowrap font-medium text-gray-500 before:absolute before:bottom-0 before:left-0 before:z-[1] before:h-0.5  before:bg-gray-1000 before:transition-all hover:text-gray-900'
                    )}
                    variant="text"
                    // disabled={menu.label !== selectedTask}
                    onClick={() => handleTaskClick(menu.label)}
                  >
                    <Text
                      as="span"
                      className={cn(
                        'inline-flex rounded-md px-2.5 py-1.5 transition-all duration-200 group-hover:bg-gray-100/70',
                        menu.label === selectedTask && 'text-black'
                      )}
                    >
                      {menu.label}
                    </Text>
                  </Button>
                </span>
              ))}
            </div>
          )}

          <div className={clientRole == 'client' ? 'mt-3' : ''}>
            {selectedTask === 'Meetings' && (
              <div>
                {clientId === '' && clientName === '' ? (
                  <div className="flex items-center justify-center p-10">
                    <Spinner size="xl" tag="div" />
                  </div>
                ) : (
                  <ClientActivityTablePage
                    userRole={clientRole}
                    clientId={clientId}
                    clientName={clientName}
                  />
                )}
              </div>
            )}
            {selectedTask === 'Agreements' && (
              <div className="pt-5">
                <ClientAgreementTablePage clientId={clientId} />
              </div>
            )}
            {selectedTask === 'Invoices' && (
              <div className="pt-5">
                <ClientInvoiceTablePage />
              </div>
            )}
          </div>
        </WidgetCard>
      </div>
    </>
  );
}

export default withRoleAuth([roles.agency, roles.teamAgency.team_agency], 'clients', null, 'view')(
  ClientViewProfileForm
);

function InformationCard({
  title,
  className,
  setShowForm,
  data,
  btn,
}: {
  title: string;
  className?: string;
  setShowForm?: any;
  data?: any;
  btn?: any;
}) {
  return (
    <WidgetCard rounded="lg" title="">
      <div className={cn('pb-5', className)}>
        <div className='flex justify-between'>
          <Title as="h3" className="text-3xl font-bold text-[#9BA1B9] sm:text-lg">
            {title}
          </Title>
          {btn && (
            <div
              className='cursor-pointer'
              onClick={() => setShowForm(true)}
            >
              <FiEdit className='h-5 w-5' />
            </div>
          )}
        </div>
        {title === 'Personal Information' && (
          <ul className="mt-4 grid gap-3 @3xl:mt-5">
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Name :
              </span>
              <span className="capitalize text-black poppins_font_number">
                {data?.first_name
                  ? capitalizeFirstLetter(data?.first_name)
                  : '-'}{' '}
                {data?.last_name ? capitalizeFirstLetter(data?.last_name) : '-'}
              </span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Email :
              </span>
              <span className="text-black poppins_font_number">
                {data?.email?.toLowerCase() ?? '-'}
              </span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Contact No :
              </span>
              {data?.contact_number ? (
                <PhoneNumber
                  value={data?.contact_number}
                  disabled={true}
                  className="display-phone-number poppins_font_number"
                />
              ) : (
                <span className="text-black">-</span>
              )}
            </li>
          </ul>
        )}
        {title === 'Company Information' && (
          <ul className="mt-4 grid gap-3 @3xl:mt-5">
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Name :
              </span>
              <span className="capitalize text-black poppins_font_number">
                {data?.company_name ?? '-'}
              </span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                URL&nbsp;:
              </span>
              <span className="w-[15rem] truncate text-black">
                <a href={data?.company_website ?? '-'} target="_blank" className='poppins_font_number'>
                  {data?.company_website ?? '-'}
                </a>
              </span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Industry :
              </span>
              <span className="text-black poppins_font_number">{data?.industry ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Employee :
              </span>
              <span className="text-black poppins_font_number">{data?.no_of_people ?? '-'}</span>
            </li>
          </ul>
        )}
        {title === 'General Information' && (
          <ul className="mt-4 grid gap-3 @3xl:mt-5">
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Address :
              </span>
              <span className="text-black poppins_font_number">{data?.address ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                City :
              </span>
              <span className="text-black">{data?.city?.name ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                State :
              </span>
              <span className="text-black poppins_font_number">{data?.state?.name ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Country :
              </span>
              <span className="text-black poppins_font_number">{data?.country?.name ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Pincode :
              </span>
              <span className="text-black poppins_font_number">{data?.pincode ?? '-'}</span>
            </li>
          </ul>
        )}
        {title === 'Tax Information' && (
          <ul className="mt-4 grid gap-3 @3xl:mt-5">
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Business GSTIN :
              </span>
              <span className="text-black poppins_font_number">{data?.gst_number ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                PAN Number :
              </span>
              <span className="text-black">{data?.pan_number ? `**********` : '-'}
              </span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Tax Preference:
              </span>
              <span className="text-black poppins_font_number">{data?.tax_preference ?? '-'}</span>
            </li>
            <li className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[#9BA1B9]	">
                Tax ID:
              </span>
              <span className="text-black poppins_font_number">{data?.tax_id ?? '-'}</span>
            </li>
          </ul>
        )}
      </div>
    </WidgetCard>
  );
}
