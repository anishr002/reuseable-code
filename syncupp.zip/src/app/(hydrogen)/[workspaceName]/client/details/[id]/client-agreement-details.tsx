import AgreementPage from "@/app/(hydrogen)/[workspaceName]/agreement/main-page";
import { useDispatch, useSelector } from "react-redux";

export default function ClientAgreementTablePage(props: any) {
    const { clientId } = props
    const dispatch = useDispatch()

    const clientSliceData = useSelector((state: any) => state?.root?.client)?.clientProfile;
    // console.log(clientSliceData, 'clientSliceData')

    return (
        <>
            <AgreementPage clientId={clientId} clientSliceData={clientSliceData} />
        </>
    )
}
