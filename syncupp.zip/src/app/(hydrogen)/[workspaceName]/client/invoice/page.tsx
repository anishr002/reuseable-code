
import { metaObject } from '@/config/site.config';
import InvoicePage from './main-page';

export const metadata = {
    ...metaObject('Invoices'),
};

export default function Page() {
    return (
        <>
            <div className='main_card_block'>
                <InvoicePage />
            </div>
        </>
    );
}
