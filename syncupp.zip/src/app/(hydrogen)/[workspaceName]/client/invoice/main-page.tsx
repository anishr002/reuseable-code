'use client';

import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import CustomTable from '@/components/common-tables/table';
import { AgreementColumns } from '@/app/shared/agreement/columns';
import PageHeader from '@/app/shared/page-header';
import { Button } from 'rizzui';
import Select from '@/components/ui/select';
import DateFiled from '@/components/controlled-table/date-field';
import { PiPlusBold } from 'react-icons/pi';
import {
  RemoveinvoiceData,
  getAllclientinvoice,
  setPagginationParams,
} from '@/redux/slices/user/client/invoice/clientinvoiceSlice';
import { ClientInvoiceColumns } from '@/app/shared/(user)/client/invoice/columns';
import cn from '@/utils/class-names';
import { roles } from '@/config/roles';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import moment from 'moment';
import restImg from 'public/assets/images/reset_icon.svg';
import Image from 'next/image';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';

const pageHeader = {
  title: 'Invoices',
};

const Statusoptions = [
  { name: 'All', value: '' },
  // { name: 'Draft', value: 'draft' },
  { name: 'Paid', value: 'paid' },
  { name: 'Unpaid', value: 'unpaid' },
  { name: 'Overdue', value: 'overdue' },
];

function InvoicePage() {
  const dispatch = useDispatch();
  const router = useRouter();

  const { invoiceDetails, loading } = useSelector(
    (state: any) => state?.root?.clieninvoice
  );
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.clieninvoice
  );
  // console.log(invoiceDetails, 'invoiceDetails')

  const [pageSize, setPageSize] = useState(10);
  const [statusname, setstatusname] = useState<any>(null);
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);

  useEffect(() => {
    dispatch(RemoveinvoiceData());
  }, []);

  useEffect(() => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    dispatch(
      getAllclientinvoice({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        agency_id: clientSliceData?.agencyId,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date:
          endRangeDate && endRangeDate != null
            ? moment(endRangeDate).format('DD/MM/YYYY')
            : null,
        status_name: statusname?.value,
      })
    );
  }, [statusname, endRangeDate]);

  //Paggination Handler
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    await dispatch(setPagginationParams(paginationParams));
    const response = await dispatch(
      getAllclientinvoice({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        agency_id: clientSliceData?.agencyId,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date:
          endRangeDate && endRangeDate != null
            ? moment(endRangeDate).format('DD/MM/YYYY')
            : null,
        status_name: statusname?.value,
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;
    // console.log(maxPage, 'maxPage')

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllclientinvoice({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          agency_id: clientSliceData?.agencyId,
          start_date:
            startRangeDate && startRangeDate != null
              ? moment(startRangeDate).format('DD/MM/YYYY')
              : null,
          end_date:
            endRangeDate && endRangeDate != null
              ? moment(endRangeDate).format('DD/MM/YYYY')
              : null,
          status_name: statusname?.value,
        })
      );
      return data?.client;
    }
    return data?.client;
  };

  // Delete Handler
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number
  ) => {
    // try {
    //     const res = await dispatch(deleteAgencyAgreement({ agreementIdsToDelete: id }));
    //     if (res.payload.success === true) {
    //         const reponse = await dispatch(getAllAgencyagreement({ page: currentPage, items_per_page: countPerPage, sort_field: 'createdAt', sort_order: 'desc' }));
    //     }
    // } catch (error) {
    //     console.error(error);
    // }
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    setstatusname(null);
  };

  // Table Filters

  const InvoicesFilters = () => {
    return (
      <>
        <Select
          className="w-full !text-black"
          onChange={(e) => {
            setstatusname(e);
          }}
          placeholder="Select status"
          options={Statusoptions}
          value={statusname?.name}
          // label="Recipient*"
          color="info"
          dropdownClassName="!text-black"
        />

        <DateFiled
          className="w-full"
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Select date range"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        />

        {/* <Button
                    className={cn(
                        "text-xs @lg:w-auto sm:text-sm lg:mt-0"
                    )}
                    onClick={handleResetFilters}
                >
                    Reset
                </Button> */}
        <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
      </>
    );
  };

  return (
    <>
      {/* <h1>Aggrement</h1> */}
      {/* <PageHeader title={pageHeader.title} /> */}
      <CustomePageHeader
        title={pageHeader.title}
        titleClassName="montserrat_font_title"
      />

      <WidgetCard rounded="lg" title="">
        <div className="table_border_remove">
          <CustomTable
            data={invoiceDetails?.data?.invoiceList || []}
            total={invoiceDetails?.data?.page_count || 1}
            loading={loading}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={ClientInvoiceColumns}
            scroll={{ x: 0 }}
            filtersList={<InvoicesFilters />}
          />
        </div>
      </WidgetCard>
    </>
  );
}

export default withRoleAuth([roles.client])(InvoicePage);
