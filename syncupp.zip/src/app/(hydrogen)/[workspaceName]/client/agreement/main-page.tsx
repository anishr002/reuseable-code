'use client';

import { AgreementColumns } from '@/app/shared/(user)/agreement/columns';
import { useModal } from '@/app/shared/modal-views/use-modal';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import DateFiled from '@/components/controlled-table/date-field';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import Select from '@/components/ui/select';
import { roles } from '@/config/roles';
import { deleteAgencyAgreement } from '@/redux/slices/user/agreement/agreementSlice';
import {
  getAllclientagreement,
  resetAgreementlist,
  setPagginationParams,
} from '@/redux/slices/user/client/agreement/clientAgreementSlice';
import moment from 'moment';
import Image from 'next/image';
import restImg from 'public/assets/images/reset_icon.svg';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

const pageHeader = {
  title: 'Agreements',
};

const Statusoptions = [
  { name: 'All', value: '' },
  // { name: 'Draft', value: 'draft' },
  { name: 'Pending', value: 'sent' },
  { name: 'Agreed', value: 'agreed' },
  { name: 'Reject', value: 'reject' },

];

function AgreementPage() {
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const { agreementDetails, loading } = useSelector(
    (state: any) => state?.root?.clienAgreement
  );
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { paginationParams } = useSelector(
    (state: any) => state?.root?.clienAgreement
  );

  const [pageSize, setPageSize] = useState(10);

  const [statusname, setstatusname] = useState<any>(null);
  const [startRangeDate, setStartRangeDate] = useState<any>(null);
  const [endRangeDate, setEndRangeDate] = useState<any>(null);

  useEffect(() => {
    dispatch(resetAgreementlist({}));
  }, []);

  useEffect(() => {
    let { page, items_per_page, sort_field, sort_order, search  } =
      paginationParams;
    dispatch(
      getAllclientagreement({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        agency_id: clientSliceData?.agencyId,
        start_date:
          startRangeDate && startRangeDate != null
            ? moment(startRangeDate).format('DD/MM/YYYY')
            : null,
        end_date:
          endRangeDate && endRangeDate != null
            ? moment(endRangeDate).format('DD/MM/YYYY')
            : null,
        status_name: statusname?.value,
      })
    );
  }, [statusname, endRangeDate]);

  //Paggination Handler
  console.log(statusname,"clientSliceData")
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;
    await dispatch(setPagginationParams(paginationParams));
    const response = await dispatch(
      getAllclientagreement({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        agency_id: clientSliceData?.agencyId,
        status_name: statusname?.value,
        
      })
    );
    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllclientagreement({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          agency_id: clientSliceData?.agencyId,
          status_name: statusname?.value,

        })
      );
      return data?.client;
    }
    return data?.client;
  };

  // Delete Handler
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number
  ) => {
    try {
      closeModal();
      const res = await dispatch(
        deleteAgencyAgreement({
          agencies: id,
          is_deleted: true,
          agency_id: clientSliceData?.agencyId,
        })
      );
      if (res.payload.success === true) {
        const reponse = await dispatch(
          getAllclientagreement({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: 'createdAt',
            sort_order: 'desc',
            agency_id: clientSliceData?.agencyId,
            status_name: statusname?.value,

          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;
    setStartRangeDate(start);
    setEndRangeDate(end);
  };

  const handleResetFilters = () => {
    setEndRangeDate(null);
    setStartRangeDate(null);
    setstatusname(null);
  };

  // Table Filters

  const AgreementsFilters = () => {
    return (
      <>
        <Select
          className="w-full !text-black"
          onChange={(e) => {
            setstatusname(e);
          }}
          options={Statusoptions}
          value={statusname?.name}
          placeholder="Select a Status"
          dropdownClassName="!text-black"
        />

        {/* <DateFiled
          className="w-full"
          selected={startRangeDate}
          onChange={handleRangeChange}
          startDate={startRangeDate}
          endDate={endRangeDate}
          placeholderText="Select Date in a Range"
          selectsRange
          shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
          inputProps={{
            clearable: true,
            onClear: () => {
              setStartRangeDate(null);
              setEndRangeDate(null);
            },
          }}
        /> */}
        {/* <Button
                    className={cn(
                        "text-xs @lg:w-auto sm:text-sm lg:mt-0"
                    )}
                    onClick={handleResetFilters}
                >
                    Reset
                </Button> */}
        <Button
          className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
          onClick={handleResetFilters}
        >
          <Image
            className="mr-2 text-white"
            alt="reste"
            width={15}
            height={15}
            src={restImg}
          />
          Reset
        </Button>
      </>
    );
  };

  return (
    <>
      {/* <h1>Aggrement</h1> */}
      <CustomePageHeader
        title={pageHeader.title}
      // titleClassName="!text-[#111928] text-28px !font-bold"
      />
      <WidgetCard rounded="lg" title="">
        <div className="table_border_remove">
          <CustomTable
            data={agreementDetails?.data?.agreements || []}
            total={agreementDetails?.data?.page_count || 1}
            loading={loading}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={AgreementColumns}
            filtersList={<AgreementsFilters />}
            scroll={{ x: 0 }}
          />
        </div>
      </WidgetCard>
    </>
  );
}

export default withRoleAuth([roles.client])(AgreementPage);
