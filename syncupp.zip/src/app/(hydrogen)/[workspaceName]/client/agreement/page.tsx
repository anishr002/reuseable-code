
import { metaObject } from '@/config/site.config';
import AgreementPage from './main-page';

export const metadata = {
    ...metaObject('Agreements'),
};

export default function Page() {
    return (
        <>
            <div className='main_card_block'>
                <AgreementPage />
            </div>
        </>
    );
}
