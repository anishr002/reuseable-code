'use client';
import ViewAgreement from '@/app/shared/(admin)/agreement/ViewAgreement';
import pageHeader from '@/app/shared/page-header';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import Spinner from '@/components/ui/spinner';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import { downloadAgreement } from '@/redux/slices/user/agreement/agreementSlice';
import {
  clientAgreementchangeStatus,
  getSingleClientAgreement,
} from '@/redux/slices/user/client/agreement/clientAgreementSlice';
import { parseHTMLContent } from '@/utils/common-functions';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import toast from 'react-hot-toast';
import { CiExport } from 'react-icons/ci';
import { FaArrowLeft } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

function AgreementDetailsPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const dispatch = useDispatch();
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<any>(null);

  const handleClickOutside = (event: any) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowDropdown(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  const pageHeader = {
    title: 'View Agreement',
  };

  const { singleAgreementdetails, loading } = useSelector(
    (state: any) => state?.root?.clienAgreement
  );
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  useEffect(() => {
    dispatch(getSingleClientAgreement(params?.id));
  }, [params?.id, dispatch]);

  const AcceptAgreementHandler = (status: string) => {
    dispatch(clientAgreementchangeStatus({ id: params?.id, status })).then(
      (result: any) => {
        if (clientAgreementchangeStatus.fulfilled.match(result)) {
          // console.log('resultt', result)
          if (result && result.payload.success === true) {
            router.push(routes.clients.agreement(defaultWorkSpace?.name));
          }
        }
      }
    );
  };

  const copyLinkHandler = (agreementId: string) => {
    const copyUrl = `${process.env.NEXT_PUBLIC_FRONT_LINK}/agreement/${agreementId}`;

    navigator.clipboard
      .writeText(copyUrl)
      .then(() => {
        toast.success('Agreement link copied to clipboard!');
        setShowDropdown(false);
      })
      .catch(() => {
        toast.error('Failed to copy link');
        setShowDropdown(false);
      });

    console.log(copyUrl, 'agreementId');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between pb-2">
        <CustomePageHeader
          title={pageHeader.title}
          titleClassName="montserrat_font_title"
          route={routes.clients.agreement(defaultWorkSpace?.name)}
        ></CustomePageHeader>

        <div ref={dropdownRef} className=" flex items-center gap-2">
          {/* <Button
            type="button"
            onClick={() => {
              dispatch(downloadAgreement(params?.id));
              // setOpen(false);
            }}
            disabled={loading} className=" rounded-lg bg-white border-[#E5E7EB] text-[#111928] text-sm"
          >
            Download
          </Button> */}
          <div className='relative'>
            <Button
              type="button"
              rounded="lg"
              className="flex h-10 items-center justify-center gap-2 border border-[#6875F5] !bg-transparent text-sm font-semibold text-[#5850EC]"
              onClick={() => {
                setShowDropdown((prev) => !prev);
              }}
            >
              <CiExport className="h-4 w-4 text-inherit" />
              Share
            </Button>
            {showDropdown && (
              <div
                className={`absolute right-0 top-full z-10 mt-2 flex-col items-start gap-[7px] rounded-[8px] !bg-white p-[10px] shadow-lg`}
              >
                <Button
                  disabled={loading}
                  onClick={() => {
                    dispatch(downloadAgreement(params?.id));
                    // setOpen(false);
                  }}
                  className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                >
                  Download as PDF
                  {loading && (
                    <Spinner size="sm" tag="div" className="ml-2" color="white" />
                  )}
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    copyLinkHandler(params?.id);
                  }}
                  className="flex items-center whitespace-nowrap !bg-white  text-[#111928]"
                // disabled={Invoiceformloader && !sentstatus}
                >
                  Copy link
                </Button>
              </div>
            )}
          </div>

          {singleAgreementdetails?.data?.status != 'agreed' &&
            singleAgreementdetails?.data?.status != 'reject' && (
              <Button
                type="button"
                onClick={() => AcceptAgreementHandler('reject')}
                className=" rounded-lg border-[#EC221F] bg-white text-sm text-[#EC221F]"
              >
                Reject
              </Button>
            )}
          {singleAgreementdetails?.data?.status != 'agreed' &&
            singleAgreementdetails?.data?.status != 'reject' && (
              <Button
                type="button"
                onClick={() => AcceptAgreementHandler('agreed')}
                className=" rounded-lg bg-[#7667CF]  text-sm text-white"
              >
                Accept
              </Button>
            )}
        </div>
      </div>
      <div className="border-1 rounded-3xl border-[#DDDDDD] bg-white">
        <ViewAgreement formValues={singleAgreementdetails?.data} />
      </div>
      {/* <div className="mt-90 mb-3 flex justify-between space-x-4"> */}
      {/* {singleAgreementdetails?.data?.agreement_logo && (
          <Image
            alt="img"
            className="mr-3"
            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${singleAgreementdetails?.data?.agreement_logo}`}
            width={100}
            height={100}
          />
        )} */}
      {/* <div className='flex items-center gap-2'>
          {singleAgreementdetails?.data?.status != 'agreed' && (
            <Button
              type="button"
              onClick={AcceptAgreementHandler}
              className="h-12 w-36 rounded-3xl bg-[#8C80D2] text-sm"
            >
              Accept
            </Button>
          )}
          <Link href={routes.clients.agreement(defaultWorkSpace?.name)}>
            <Button
              type="button"
              // onClick={() => { router.push(`/agreement`) }}
              className="h-12 w-36 rounded-3xl bg-[#E3E1F4] text-sm text-[8C80D2]"
            >
              Back
            </Button>
          </Link>
        </div> */}
      {/* </div> */}
      {/* <h3 className="flex items-center justify-between rounded border-2 border-solid border-gray-300 bg-gray-100 p-3 !text-black">
        <span>{singleAgreementdetails?.data?.title}</span>
        <span>
          {singleAgreementdetails?.data?.due_date &&
            singleAgreementdetails?.data?.due_date != ''
            ? 'Due Date : ' +
            moment(singleAgreementdetails?.data?.due_date).format(
              'DD MMM, YYYY'
            )
            : ''}
        </span>
      </h3> */}
      {/* <div className='mt-5' dangerouslySetInnerHTML={{ __html: singleAgreementdetails?.data?.agreement_content }} /> */}
      {/* <div className="mt-5">
        <div
          className="break-all"
          dangerouslySetInnerHTML={{
            __html: parseHTMLContent(
              singleAgreementdetails?.data?.agreement_content
            ),
          }}
        />
      </div> */}
      {/* <div className="poppins_font_number mb-1.5 mt-5 flex justify-between font-medium text-black dark:text-gray-600">
        <ul>
          <li className="capitalize">
            {singleAgreementdetails?.data?.sender_first_name &&
              singleAgreementdetails?.data?.sender_first_name != ''
              ? singleAgreementdetails?.data?.sender_first_name
              : '[Sender Name]'}
          </li>
          <li>
            {singleAgreementdetails?.data?.sender_email &&
              singleAgreementdetails?.data?.sender_email != ''
              ? singleAgreementdetails?.data?.sender_email
              : '[Sender Email]'}
          </li>
          <li>
            {singleAgreementdetails?.data?.sender_number &&
              singleAgreementdetails?.data?.sender_number != ''
              ? singleAgreementdetails?.data?.sender_number
              : '[Sender Phone]'}
          </li>
        </ul>
        <ul>
          <li className="capitalize">
            {singleAgreementdetails?.data?.receiver &&
              singleAgreementdetails?.data?.receiver != ''
              ? singleAgreementdetails?.data?.receiver
              : '[Receiver Name]'}
          </li>
          <li>
            {singleAgreementdetails?.data?.receiver_email &&
              singleAgreementdetails?.data?.receiver_email != ''
              ? singleAgreementdetails?.data?.receiver_email
              : '[Receiver Email]'}
          </li>
          <li>
            {singleAgreementdetails?.data?.receiver_number &&
              singleAgreementdetails?.data?.receiver_number != ''
              ? singleAgreementdetails?.data?.receiver_number
              : '[Receiver Phone]'}
          </li>
        </ul>
      </div> */}
    </>
  );
}

export default withRoleAuth([roles.client])(AgreementDetailsPage);
