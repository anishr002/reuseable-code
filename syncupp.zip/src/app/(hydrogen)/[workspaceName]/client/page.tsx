
import { metaObject } from '@/config/site.config';
import ClientPage from './main-page';

export const metadata = {
  ...metaObject('Clients'),
};

export default function Page() {
  return (
    <>
      <div className='main_card_block'>
        <ClientPage />
      </div>
    </>
  );
}
