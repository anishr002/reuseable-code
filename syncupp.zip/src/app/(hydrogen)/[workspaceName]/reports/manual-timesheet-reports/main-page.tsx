'use client';
// import { GetColumns } from '@/app/shared/(user)/my-tasks/column';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Select from '@/components/ui/select';
import { setPagginationParams } from '@/redux/slices/user/client/clientSlice';
import {
  getAllAssignees,
  getAllBoard,
} from '@/redux/slices/user/task/boardSlice';
import {
  getAllTask,
  RemoveGetAllTasksData,
  taskTimerStartAndStop,
} from '@/redux/slices/user/task/taskSlice';
import {
  calculateTotalTimeInSeconds,
  capitalizeFirstLetter,
  convertSecondsToTime,
  convertSecondsToTimeForManaul,
  handleKeyDown,
} from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import ReactSelect from 'react-select';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { timesheetReportsColumns } from '@/app/shared/(user)/reports/timesheetColumn';
import { PiArrowLineDownBold, PiMagnifyingGlassBold } from 'react-icons/pi';
import {
  getAllTimesheetReports,
  getAllTimesheetTask,
  removegetAllTimesheetReportsData,
  timesheetReportsdownload,
} from '@/redux/slices/user/reports/reportsSlice';
import Spinner from '@/components/ui/spinner';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { Controller } from 'react-hook-form';
import { DatePicker } from '@/components/ui/datepicker';
import { Form } from '@/components/ui/form';
import { z } from 'zod';
import moment from 'moment';
import { Avatar, Empty, Input, Text } from 'rizzui';
import { taskTimeTrackedHistory } from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import backIcon from '@public/assets/images/back_arrow_icon.svg';
import { useDebouncedValue } from '@/hooks/use-debounce';
import DateFiled from '@/components/controlled-table/date-field';
import { throttle } from 'lodash';

const pageHeader = {
  title: 'Time Entries',
};

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#8c80d2' : 'white',
    color: state.isSelected ? 'white' : 'black',
    whiteSpace: 'normal', // Allow text to wrap
    wordBreak: 'break-word', // Break long words if necessary
  }),
};

export default function ManualTimesheetReportsPage() {
  const dispatch = useDispatch();
  const { userProfile, permission, role } = useSelector(
    (state: any) => state?.root?.signIn
  );

  const [page, setPage] = useState(0);
  const [isFetching, setIsFetching] = useState(false);

  const [taskHasMore, setTaskHasMore] = useState(true); // ✅ Track if more data exists
  const [timesheetList, setTimesheetList] = useState<any[]>([]);
  const [timeSheetpage, setTimeSheetpage] = useState(1);

  const lastPageRef = useRef(timeSheetpage);

  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false); // ✅ Local loading state
  const [isFetchingMore, setIsFetchingMore] = useState(false); // Scroll loading
  // Search value
  const [searchTerm, setSearchTerm] = useState<string>('');
  const debouncedValue = useDebouncedValue<string>(searchTerm, 1000);
  const [isResetting, setIsResetting] = useState<boolean>(false); // Track reset state

  console.log(timeSheetpage, 'timeSheetpage11111111111111');

  const [startRangeDate, setStartRangeDate] = useState<Date | null>(new Date());
  const [endRangeDate, setEndRangeDate] = useState<Date | null>(new Date());
  const { assignees } = useSelector((state: any) => state?.root?.board);

  const onSearchClear = () => {
    setSearchTerm('');
    setIsFetchingMore(false);
    setTimeSheetpage(1);
    setTotalPages(1);

    // ✅ Scroll back to top
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const onSearchChange = (event: any) => {
    setSearchTerm(event?.target?.value);
  };

  const tableContainerRef = useRef<HTMLDivElement>(null);
  const isFetchingMoreRef = useRef(false); // Track fetching status

  const setValueReference = useRef<any>();
  const getValuesReference = useRef<any>();
  const resetReference = useRef<any>();

  const [tasksOptions, setTasksOptions] = useState<any>([]);
  const [menuIsOpen, setMenuIsOpen] = useState(false); // ✅ Keep menu open

  const [TaskName, setTaskName] = useState<any>(null);
  const [statusValue, setStatusValue] = useState('');
  const [boardName, setBoardName] = useState<any>(null);
  const [boardOptions, setBoardOptions] = useState<any>([]);
  const [skip, setskip] = useState(0);
  const [baordLoading, setbaordLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true); // If more data is available
  const [boardValue, setBoardValue] = useState('');

  // Assignee options
  const assigneeOptions = assignees?.length
    ? assignees.map((assignee: Record<string, any>) => ({
        name: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        label: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        value: assignee?._id,
      }))
    : [];
  const [assignee, setAssignee] = useState<any>(null);
  const [assigneeLoaded, setAssigneeLoaded] = useState(false); // New state

  const router = useRouter();

  const { timeSheetdata } = useSelector((state: any) => state?.root?.reports);
  const { taskTimerStartAndStopLoader } = useSelector(
    (state: any) => state?.root?.task
  );

  const defaultValues = {
    board_id: '', // Default empty value
    task_id: '', // Default empty value
    start_date: moment().toDate(),
    end_date: moment().toDate(),
    start_time: moment().toDate(),
    end_time: moment().toDate(),
    manual_time: convertSecondsToTimeForManaul(
      calculateTotalTimeInSeconds(moment().toDate(), moment().toDate())
    ),
    notes: '',
  };

  const timeTrackingSchema = z.object({
    board_id: z.string().min(1, 'Board is required'),
    task_id: z.string().min(1, 'Task is required'),
    start_date: z.date().nullable().optional(),
    end_date: z.date().nullable().optional(),
    start_time: z.date().nullable().optional(),
    end_time: z.date().nullable().optional(),
    notes: z.string().max(150).trim().optional(),
    manual_time: z
      .string()
      .regex(/^((\d+h)?\s*(\d+m)?)$/, { message: 'Invalid Format' })
      .nullable()
      .optional(),
  });

  // useEffect(() => {
  //   if (period !== '' || startDate !== '' || endDate !== '') {
  //     setReset(true);
  //   }
  // }, [period, startDate, endDate]);

  useEffect(() => {
    // Get all the assignees list
    dispatch(getAllAssignees());
  }, [dispatch]);

  useEffect(() => {
    if (assigneeOptions?.length > 0 && !assigneeLoaded) {
      setAssignee(
        assigneeOptions?.find(
          (option: any) => option.value === userProfile?._id
        ) || null
      );
      setAssigneeLoaded(true); // Prevent infinite loop
    }
  }, [assigneeOptions, userProfile, assigneeLoaded]);

  useEffect(() => {
    if (boardValue !== '') {
      setPage(0);
      setTaskHasMore(true); // ✅ Reset `hasMore` on board change
      fetchTasks(0); // ✅ Load first batch without clearing previous options
    }
  }, [boardValue]);

  const fetchTasks = (skipValue: number) => {
    if (isFetching) return; // ✅ Prevent duplicate calls
    setIsFetching(true);

    dispatch(
      getAllTask({
        limit: 50,
        skip: skipValue,
        board_id: boardValue,
        isInfinite: true,
        pagination: false,
        isManualTimeSheet: true,
      })
    ).then((res: any) => {
      const newTasks = res?.payload?.data?.activity || [];

      if (newTasks.length > 0) {
        setTasksOptions((prevOptions: any) => [
          ...prevOptions,
          ...newTasks.map((task: Record<string, any>) => ({
            name: capitalizeFirstLetter(task?.title),
            label: capitalizeFirstLetter(task?.title),
            value: task?._id,
          })),
        ]);
      }

      // ✅ Update `taskHasMore` only if more data exists
      setTaskHasMore(newTasks.length === 50); // If less than 10, assume no more data

      setPage(skipValue + 50); // ✅ Increment pagination
      setIsFetching(false);
    });
  };

  useEffect(() => {
    if (startRangeDate && endRangeDate && assigneeLoaded) {
      console.log('Fetching timesheets...');
      fetchTimesheets(1, true);
    }
  }, [debouncedValue, startRangeDate, endRangeDate, assignee]);

  const fetchTimesheets = async (pageNum: number, reset = false) => {
    if (
      loading ||
      isFetchingMoreRef.current ||
      (pageNum > totalPages && pageNum !== 1)
    )
      return;

    if (pageNum === 1) {
      setLoading(true); // Show spinner only on first load
    } else {
      setIsFetchingMore(true); // Show "Loading..." text for scroll load
      isFetchingMoreRef.current = true;
    }

    try {
      const res = await dispatch(
        getAllTimesheetReports({
          page: pageNum,
          items_per_page: 10,
          sort_field: 'createdAt',
          sort_order: 'desc',
          search: isResetting ? '' : debouncedValue,
          filter: {
            start_date: startRangeDate
              ? moment(startRangeDate).format('DD-MM-YYYY')
              : moment().format('DD-MM-YYYY'),
            end_date: endRangeDate
              ? moment(endRangeDate).format('DD-MM-YYYY')
              : moment().format('DD-MM-YYYY'),
          },
          board_id: '',
          assignee_id: assignee?.value,
          task_id: '',
          // isTodayTimesheet: true,
        })
      ).unwrap();

      if (res?.data?.activity) {
        setTimesheetList((prev) =>
          reset ? res.data.activity : [...prev, ...res.data.activity]
        );
        setTotalPages(res.data.page_count || 1);
      }
    } catch (error) {
      console.error('Error fetching timesheets:', error);
    } finally {
      if (pageNum === 1) {
        setLoading(false); // Stop loading spinner after first load
      } else {
        setIsFetchingMore(false); // Stop "Loading..." text after scroll
        isFetchingMoreRef.current = false; // Reset fetching status
      }
    }
  };

  const handleScroll = useCallback(
    throttle(() => {
      if (!tableContainerRef.current) return;
      const { scrollTop, scrollHeight, clientHeight } =
        tableContainerRef.current;

      if (
        scrollTop + clientHeight >= scrollHeight - 20 &&
        timeSheetpage < totalPages &&
        !isFetchingMoreRef.current // Use ref to prevent duplicate calls
      ) {
        setTimeSheetpage((prev) => prev + 1);
      }
    }, 500), // Throttle every 500ms
    [timeSheetpage, totalPages]
  );

  useEffect(() => {
    if (
      timeSheetpage > 1 &&
      timeSheetpage <= totalPages &&
      !isFetchingMoreRef.current
    ) {
      fetchTimesheets(timeSheetpage);
    }
  }, [timeSheetpage]);

  // Fetch Boards Function
  const fetchBoards = async () => {
    if (baordLoading || !hasMore) return; // Prevent duplicate calls

    setbaordLoading(true);
    dispatch(getAllBoard({ all: false, limit: 50, skip }))
      .then((result: any) => {
        if (getAllBoard.fulfilled.match(result) && result.payload?.success) {
          const newBoards = result.payload.data.board_list.map(
            (board: any) => ({
              name:
                board.project_name.charAt(0).toUpperCase() +
                board.project_name.slice(1),
              value: board._id,
              label:
                board.project_name.charAt(0).toUpperCase() +
                board.project_name.slice(1),
            })
          );

          setBoardOptions((prev: any) => [...prev, ...newBoards]); // Append new data
          setskip(skip + 50); // Update skip for next call
          setHasMore(newBoards.length === 50); // If < 10, no more data
        }
      })
      .finally(() => setbaordLoading(false));
  };

  // Initial Fetch on Component Mount
  useEffect(() => {
    fetchBoards();
  }, []);

  // Handle Scroll Event in ReactSelect
  const handleMenuScroll = (event: any) => {
    const { target } = event;
    if (target.scrollHeight - target.scrollTop <= target.clientHeight + 10) {
      fetchBoards(); // Fetch next set of boards on scroll
    }
  };

  const handleBoardChange = (selectedOption: Record<string, any>) => {
    setBoardValue(selectedOption?.value);
    // ✅ Reset task selection
    setTaskName(null);

    // ✅ Clear previous task options and fetch new ones
    setTasksOptions([]);
    setPage(0);
    setTaskHasMore(true); // Reset pagination
    setStatusValue('');
  };

  const handleTaskFilterChange = (selectedOption: Record<string, any>) => {
    setStatusValue(selectedOption?.value);
  };

  const calculateTotalTimeFromDateRage = () => {
    const totalSeconds = calculateTotalTimeInSeconds(
      getValuesReference.current()?.start_time,
      getValuesReference.current()?.end_time
    );
    setValueReference.current(
      'manual_time',
      convertSecondsToTimeForManaul(totalSeconds)
    );
  };
  const onChangeDate = (date: any) => {
    setValueReference.current('start_time', date);
    setValueReference.current('end_time', date);
  };

  const resetAllStates = () => {
    setPage(0);
    setIsFetching(false);
    setTaskHasMore(true);
    setTasksOptions([]);
    setBoardValue('');
    setMenuIsOpen(false);
    setTaskName(null);
    setStatusValue('');
    setBoardName(null);
    // setBoardOptions([]);
    setskip(0);
    setbaordLoading(false);
    setHasMore(true);
    // setTimesheetList([]);
    setIsFetchingMore(false);
    // setLoading(false);
    setTimeSheetpage(1);
    setTotalPages(1);

    // Reset React Hook Form fields
    if (resetReference.current) {
      resetReference.current();
    }

    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const manualSaveTime = async (payload: any) => {
    try {
      const result = await dispatch(taskTimerStartAndStop(payload)).unwrap();
      if (result?.success) {
        resetAllStates(); // ✅ Reset all states

        const res = await dispatch(
          getAllTimesheetReports({
            page: 1,
            items_per_page: 10,
            sort_field: 'createdAt',
            sort_order: 'desc',
            search: isResetting ? '' : debouncedValue,
            filter: {
              start_date: startRangeDate
                ? moment(startRangeDate).format('DD-MM-YYYY')
                : moment().format('DD-MM-YYYY'),
              end_date: endRangeDate
                ? moment(endRangeDate).format('DD-MM-YYYY')
                : moment().format('DD-MM-YYYY'),
            },
            board_id: '',
            assignee_id: assignee?.value,
            task_id: '',
            // isTodayTimesheet: true,
          })
        ).unwrap();

        if (res?.data?.activity) {
          setTimesheetList((prev) => {
            const updatedList = [...res.data.activity]; // ✅ Ensure fresh data is added first

            // ✅ Only add previous data if it's not already in the new response
            prev.forEach((existingItem) => {
              if (
                !res.data.activity.some(
                  (newItem: any) => newItem.id === existingItem.id
                )
              ) {
                updatedList.push(existingItem);
              }
            });

            return updatedList;
          });

          setTotalPages(res.data.page_count || 1);
        }
      }
    } catch (error) {
      console.error('Error in manualSaveTime:', error);
    }
  };

  console.log(boardValue, 'boardValue12344444');

  const onSubmit = (data: any) => {
    const payload = createPayload(data);
    console.log(payload, 'payload123333');
    manualSaveTime(payload);
  };

  // Create payload
  const createPayload = (data: any) => {
    return {
      clocking: {
        clock_in: moment(data?.start_time)
          .utc()
          .format(),
        clock_out: moment(data?.end_time)
          .utc()
          .format(),
      },
      mode: 'manual',
      notes: data?.notes,
      task_id: data?.task_id, // Default empty value
    };
  };

  const handleRangeChange = (dates: [Date | null, Date | null]) => {
    const [start, end] = dates;

    setIsFetchingMore(false);
    setTimeSheetpage(1);
    setTotalPages(1);

    // ✅ Scroll back to top
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }

    setStartRangeDate(start);

    if (start && !end) {
      setEndRangeDate(null); // Reset end date when a new start date is selected
    } else {
      setEndRangeDate(end);
    }
  };

  // Reset Filter
  const handleResetFilters = () => {
    setAssignee(
      assigneeOptions.find((option: any) => option.value === userProfile?._id)
    );
    setStartRangeDate(new Date());
    setEndRangeDate(new Date());
    setSearchTerm('');
    setIsResetting(true); // ✅ Activate reset flag

    setIsFetchingMore(false);
    setTimeSheetpage(1);
    setTotalPages(1);

    // ✅ Scroll back to top
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }

    setTimeout(() => setIsResetting(false), 1000);
  };

  return (
    <div>
      <CustomePageHeader
        title={pageHeader?.title}
        titleClassName="montserrat_font_title"
        isTimesheet={true}
      />
      <WidgetCard rounded="lg" className="mt-2 h-auto" title="">
        <div>
          <Form
            validationSchema={timeTrackingSchema}
            onSubmit={onSubmit}
            useFormProps={{ mode: 'all', defaultValues }}
          >
            {({
              register,
              control,
              watch,
              setValue,
              getValues,
              clearErrors,
              setError,
              formState: { errors },
              reset,
            }) => (
              (setValueReference.current = setValue),
              (getValuesReference.current = getValues),
              (resetReference.current = reset),
              (
                <div className="flex flex-wrap items-baseline gap-4">
                  <div>
                    <ReactSelect
                      options={boardOptions}
                      onChange={(selectedOption: any) => {
                        setBoardName(selectedOption);
                        setBoardValue(selectedOption.value);
                        setValue('board_id', selectedOption.value); // ✅ Set value for validation
                        clearErrors('board_id'); // ✅ Clear error on valid selection
                        handleBoardChange(selectedOption);
                      }}
                      placeholder="Select Board"
                      value={boardName}
                      className="poppins_font_number react-select-options task-assign mb-1 w-[200px]"
                      classNamePrefix="custom-multi-select"
                      styles={{
                        ...customStyles,
                        menuPortal: (base) => ({ ...base, zIndex: 9999 }), // ✅ Increase z-index
                      }}
                      menuPortalTarget={document.body} // ✅ Ensures dropdown renders outside parent div
                      menuPlacement="auto" // ✅ Adjust placement dynamically
                      onMenuScrollToBottom={handleMenuScroll} // Fetch on Scroll
                      isLoading={baordLoading} // Show loading indicator
                    />
                    {errors.board_id && (
                      <span className="text-sm text-red-500">
                        {errors.board_id.message}
                      </span>
                    )}
                  </div>
                  <div>
                    <ReactSelect
                      options={tasksOptions}
                      onChange={(selectedOption: Record<string, any>) => {
                        setTaskName(selectedOption);
                        setValue('task_id', selectedOption.value); // ✅ Set value for validation
                        clearErrors('task_id'); // ✅ Clear error on valid selection
                        handleTaskFilterChange(selectedOption);
                      }}
                      placeholder="Select Task"
                      className="poppins_font_number react-select-options task-assign mb-1 w-[200px]"
                      classNamePrefix="custom-multi-select"
                      styles={{
                        ...customStyles,
                        menuPortal: (base) => ({ ...base, zIndex: 9999 }), // ✅ Increase z-index
                      }}
                      menuPortalTarget={document.body} // ✅ Ensures dropdown renders outside parent div
                      menuPlacement="auto" // ✅ Adjust placement dynamically
                      value={TaskName}
                      onMenuOpen={() => setMenuIsOpen(true)}
                      onMenuClose={() => setMenuIsOpen(false)}
                      menuIsOpen={menuIsOpen}
                      onMenuScrollToBottom={() => {
                        if (taskHasMore) {
                          fetchTasks(page);
                        }
                      }}
                      isDisabled={boardValue === '' || isFetching} // ✅ Disable if boardValue is empty
                    />
                    {errors.task_id && (
                      <span className="text-sm text-red-500">
                        {errors.task_id.message}
                      </span>
                    )}
                  </div>

                  <Controller
                    name="start_time"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <DatePicker
                        className="meeting-date-picker w-[150px]"
                        placeholderText="Start time"
                        selected={value}
                        onChange={(event: any) => {
                          onChange(event);

                          calculateTotalTimeFromDateRage();
                        }}
                        showTimeSelect
                        showTimeSelectOnly
                        dateFormat="hh:mm aa"
                      />
                    )}
                  />
                  <div>
                    <span>-</span>
                  </div>
                  <Controller
                    name="end_time"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <DatePicker
                        className="meeting-date-picker w-[150px]"
                        placeholderText="End time"
                        selected={value}
                        onChange={(event: any) => {
                          onChange(event);
                          calculateTotalTimeFromDateRage();
                        }}
                        showTimeSelect
                        showTimeSelectOnly
                        dateFormat="hh:mm aa"
                        minTime={watch('start_time') || new Date()} // Restrict selection based on start_time
                        maxTime={new Date(new Date().setHours(23, 59))} // ✅ Convert to Date properly
                        disabled={!watch('start_time')} // Disable if start_time is not selected
                      />
                    )}
                  />
                  <Controller
                    name="start_date"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <DatePicker
                        className="meeting-date-picker w-[150px]"
                        placeholderText="Start date"
                        selected={value}
                        onChange={(e) => {
                          onChange(e);
                          onChangeDate(e);
                        }}
                        selectsStart
                        startDate={value}
                        maxDate={new Date()}
                        dateFormat="MMMM dd, yyyy"
                        disabled
                      />
                    )}
                  />
                  <Input
                    type="text"
                    readOnly
                    placeholder="Time here"
                    className="poppins_font_number date_picker_fonts w-[120px] rounded-xl text-black"
                    {...register('manual_time')}
                    error={errors?.manual_time?.message as string}
                  />
                  <Button
                    type="submit"
                    className="flex h-[36px] w-auto items-center justify-center rounded-[8px] bg-[#7667CF] py-4 text-[14px] font-normal leading-[16.8px] text-[#fff]  hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                    size="sm"
                  >
                    ADD
                    {taskTimerStartAndStopLoader && (
                      <Spinner size="sm" tag="div" color="white" />
                    )}
                  </Button>
                </div>
              )
            )}
          </Form>
        </div>
      </WidgetCard>

      <WidgetCard rounded="lg" className="mt-2" title="">
        <div className="placeholder_color mb-3 flex flex-wrap gap-2 md:gap-4">
          <Input
            type="search"
            placeholder="Search by anything"
            value={searchTerm}
            onClear={onSearchClear}
            onChange={onSearchChange}
            onKeyDown={handleKeyDown}
            inputClassName="h-[41px] poppins_font_number"
            clearable={true}
            prefix={<PiMagnifyingGlassBold className="h-4 w-4" />}
          />
          <DateFiled
            className="w-full "
            selected={startRangeDate}
            onChange={handleRangeChange}
            startDate={startRangeDate}
            endDate={endRangeDate}
            placeholderText="Select Date in a Range"
            selectsRange
            shouldCloseOnSelect={false} // Keep the date picker open after selecting a date
            isTimesheet={true}
          />
          {(['agency'].includes(role) ||
            (['team_agency', 'team_client'].includes(role) &&
              checkPermission(
                'reports',
                'timesheet_reports',
                'everyone',
                permission
              ))) && (
            <ReactSelect
              options={assigneeOptions}
              onChange={(selectedOption: Record<string, any>) => {
                setAssignee(selectedOption);
                setIsFetchingMore(false);
                setTimeSheetpage(1);
                setTotalPages(1);

                // ✅ Scroll back to top
                if (tableContainerRef.current) {
                  tableContainerRef.current.scrollTo({
                    top: 0,
                    behavior: 'smooth',
                  });
                }
              }}
              value={assignee}
              placeholder="Assigned to"
              className="poppins_font_number react-select-options h-[40px] w-[248px] text-black"
              classNamePrefix="custom-multi-select " // ✅ Apply scoped styles
              styles={{
                ...customStyles,
                menuPortal: (base) => ({ ...base, zIndex: 9999 }), // ✅ Increase z-index
              }}
              menuPortalTarget={document.body} // ✅ Ensures dropdown renders outside parent div
              menuPlacement="auto" // ✅ Adjust placement dynamically
            />
          )}
          <div className="w-full md:w-auto">
            <Button
              className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
              onClick={handleResetFilters}
            >
              <Image
                className="mr-2 text-white"
                alt="reste"
                width={15}
                height={15}
                src={restImg}
              />
              Reset
            </Button>
          </div>
        </div>
        <div
          ref={tableContainerRef}
          className="[&_.rc-table-placeholder_.rc-table-expanded-row-fixed>div] max-h-[243px]  overflow-y-auto text-sm shadow-sm [&_.rc-table-placeholder_.rc-table-expanded-row-fixed>div]:justify-center [&_.rc-table-row:last-child_td.rc-table-cell]:border-b-0 [&_thead.rc-table-thead]:rounded-[4px] [&_thead.rc-table-thead]:border-t-0 [&_thead.rc-table-thead]:bg-[#F9FAFB]"
          onScroll={handleScroll}
        >
          <div className="w-full min-w-[1100px]">
            {/* Sticky Table Header */}
            <div className="sticky top-0 z-10 mb-2 grid h-[42px] grid-cols-[3fr_2fr_2fr_1fr] items-center bg-gray-100 px-4 font-semibold text-[#4B5563]">
              <div className="ml-3 cursor-pointer text-left">Task Name</div>
              <div className="ml-3 cursor-pointer text-left">Board</div>
              <div className="ml-3 cursor-pointer text-left">Assignee Name</div>
              <div className="mr-3 cursor-pointer pr-4 text-right">
                Total Hours
              </div>
            </div>

            {/* Initial Loading (Spinner) */}
            {loading ? (
              <div className="grid min-h-[244px] place-content-center">
                <Spinner size="xl" />
              </div>
            ) : timesheetList?.length === 0 ? (
              // No Data Message
              <div className="flex min-h-[244px] flex-col justify-center text-center ">
                <Empty />
                <Text className="mt-3">No Data</Text>
              </div>
            ) : (
              <>
                {/* Table Body */}
                {timesheetList?.map((row: any, index: number) => (
                  <div
                    key={index}
                    className="grid grid-cols-[3fr_2fr_2fr_1fr] items-center border-b border-gray-200 px-4 py-4 text-gray-700"
                  >
                    <div className="poppins_font_number ml-3 text-[14px] font-semibold text-[#120425]">
                      {capitalizeFirstLetter(row?.task_details?.title)}
                    </div>
                    <div className="ml-3 flex items-center gap-2">
                      {row?.board_details?.board_image ? (
                        <Avatar
                          src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${row?.board_details?.board_image}`}
                          name={
                            capitalizeFirstLetter(
                              row?.board_details?.project_name
                            ) ?? ''
                          }
                          size="sm"
                          className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white"
                        />
                      ) : (
                        <div
                          className="flex !h-8 !w-8 items-center justify-center rounded-full border-white"
                          style={{
                            backgroundColor: row?.board_details?.board_color,
                          }}
                        ></div>
                      )}
                      <span className="poppins_font_number text-[15px] font-semibold capitalize text-black">
                        {capitalizeFirstLetter(
                          row?.board_details?.project_name
                        )}
                      </span>
                    </div>
                    <div className="poppins_font_number ml-3 font-semibold text-gray-700">
                      {capitalizeFirstLetter(row?.user_details?.first_name)}{' '}
                      {capitalizeFirstLetter(row?.user_details?.last_name)}
                    </div>
                    <div className="poppins_font_number mr-4 text-right font-medium text-gray-700">
                      {convertSecondsToTime(row?.new_log?.total_time)}
                    </div>
                  </div>
                ))}

                {/* Fetching More Data (Loading Text) */}
                {isFetchingMore && (
                  <div className="flex items-center justify-center py-4">
                    <Spinner size="sm" className="h-6 w-6 text-gray-500" />
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </WidgetCard>

      <div className="mr-[7px] mt-[15px]  flex justify-end px-4 py-3 text-lg font-semibold text-gray-700">
        Total time:{' '}
        <span className="poppins_font_number text-lg font-semibold text-gray-700">
          {' '}
          &nbsp;
          {timeSheetdata?.total_time ? timeSheetdata?.total_time : '00:00:00'}
        </span>
      </div>
    </div>
  );
}
