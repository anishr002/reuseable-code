import { metaObject } from '@/config/site.config';
import ManualTimesheetReportsPage from './main-page';

export const metadata = {
  ...metaObject('Reports'),
};

export default function Page() {
  return (
    <div className="main_card_block">
      <ManualTimesheetReportsPage />
    </div>
  );
}
