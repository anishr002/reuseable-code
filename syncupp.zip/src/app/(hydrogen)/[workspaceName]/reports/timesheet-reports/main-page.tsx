'use client';
// import { GetColumns } from '@/app/shared/(user)/my-tasks/column';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Select from '@/components/ui/select';
import { setPagginationParams } from '@/redux/slices/user/client/clientSlice';
import { getAllBoard } from '@/redux/slices/user/task/boardSlice';
import { RemoveGetAllTasksData } from '@/redux/slices/user/task/taskSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import ReactSelect from 'react-select';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { timesheetReportsColumns } from '@/app/shared/(user)/reports/timesheetColumn';
import { PiArrowLineDownBold } from 'react-icons/pi';
import {
  getAllTimesheetReports,
  getAllTimesheetTask,
  removegetAllTimesheetReportsData,
  timesheetReportsdownload,
} from '@/redux/slices/user/reports/reportsSlice';
import Spinner from '@/components/ui/spinner';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { getAllMyTasks } from '@/redux/slices/user/dashboard/dashboardSlice';

const pageHeader = {
  title: 'Report',
};

const customStyles = {
  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#8c80d2' : 'white',
    color: state.isSelected ? 'white' : 'black',
    whiteSpace: 'normal', // Allow text to wrap
    wordBreak: 'break-word', // Break long words if necessary
  }),
};

export default function TimesheetReportsPage() {
  const dispatch = useDispatch();
  const { tasksData } = useSelector((state: any) => state?.root?.dashbord);

  const [page, setPage] = useState(1);
  const [isFetching, setIsFetching] = useState(false);
  const [tasksOptions, setTasksOptions] = useState([
    { name: 'All', value: '', label: 'All' },
  ]);
  const [menuIsOpen, setMenuIsOpen] = useState(false); // ✅ Keep menu open

  const [TaskName, setTaskName] = useState<any>({
    name: 'All Tasks',
    value: '',
    label: 'All Tasks',
  });

  const [statusValue, setStatusValue] = useState('');
  const [boardName, setBoardName] = useState<any>({
    name: 'All Boards',
    value: '',
    label: 'All Boards',
  });
  const [exelbuttonloading, setexelbuttonloadding] = useState<any>(false);
  const [boardValue, setBoardValue] = useState('');
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [assignee, setAssignee] = useState<any>({
    name: 'Assigned to',
    value: '',
    label: 'Assigned to',
  });
  const [reset, setReset] = useState(false);
  const [sortObject, setSortObject] = useState({});
  const searchParams = useSearchParams();
  const router = useRouter();
  const path = usePathname();

  console.log(tasksData, 'tasksData1233333');

  const { loading, timeSheetdata } = useSelector(
    (state: any) => state?.root?.reports
  );
  const { data } = useSelector((state: any) => state?.root?.board);
  const { paginationParams } = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);

  const [pageSize, setPageSize] = useState<number>(10);

  useEffect(() => {
    if (period !== '' || startDate !== '' || endDate !== '') {
      setReset(true);
    }
  }, [period, startDate, endDate]);

  useEffect(() => {
    fetchTasks(1); // Load first page of tasks
  }, []);

  const fetchTasks = (pageNum: number) => {
    if (isFetching) return; // Prevent multiple calls
    setIsFetching(true);

    dispatch(
      getAllTimesheetTask({
        items_per_page: 200, // Load in chunks of 10
        page: pageNum,
      })
    ).then((res: any) => {
      if (res?.payload?.data?.task_list?.length > 0) {
        setTasksOptions((prevOptions) => [
          ...prevOptions,
          ...res.payload.data?.task_list?.map((task: Record<string, any>) => ({
            name: capitalizeFirstLetter(task?.title),
            label: capitalizeFirstLetter(task?.title),
            value: task?._id,
          })),
        ]);
        setPage(pageNum + 1); // Increment page for next fetch
      }
      setIsFetching(false);
    });
  };

  useEffect(() => {
    if (
      boardValue !== '' ||
      assignee?.value !== '' ||
      startDate !== '' ||
      endDate !== ''
    ) {
      setReset(false);
      //When filter change the pagination params store in redux.
      dispatch(
        setPagginationParams({
          ...paginationParams,
          filter: {
            start_date: startDate,
            end_date: endDate,
          },
          board_id: boardValue,
          assignee_id: assignee?.value,
          task_id: statusValue,
        })
      );
    }
  }, [boardValue, assignee?.value, startDate, endDate]);

  useEffect(() => {
    // Get all boards api
    // dispatch(getAllBoard({ all: true }));

    // Remove tasks module page data from redux
    dispatch(RemoveGetAllTasksData());

    // Remove Tasks data on ummount page
    return () => {
      dispatch(removegetAllTimesheetReportsData());
    };
  }, [dispatch]);

  // Table api call logic
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    setSortObject({ page, items_per_page, sort_field, sort_order, search });

    dispatch(
      setPagginationParams({
        ...paginationParams,
        filter: {
          start_date: startDate,
          end_date: endDate,
        },
        board_id: searchParams.get('board_id')
          ? searchParams.get('board_id')
          : boardValue,
        assignee_id: assignee?.value,
        task_id: statusValue,
      })
    );

    const response = await dispatch(
      getAllTimesheetReports({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        filter: {
          start_date: startDate,
          end_date: endDate,
        },
        board_id: searchParams.get('board_id')
          ? searchParams.get('board_id')
          : boardValue,
        assignee_id: assignee?.value,
        task_id: statusValue,
      })
    );

    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllTimesheetReports({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          filter: {
            start_date: startDate,
            end_date: endDate,
          },
          board_id: searchParams.get('board_id')
            ? searchParams.get('board_id')
            : boardValue,
          assignee_id: assignee?.value,
          task_id: statusValue,
        })
      );
      return data?.activity;
    }
    if (data && data?.activity && data?.activity?.length !== 0) {
      return data?.activity;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    console.log('delete function called.');
  };

  // Filters logic

  // Board options....
  let boardOptions: Record<string, any>[] = [
    { name: 'All Boards', value: '', label: 'All Boards' },
  ];

  data &&
    data?.board_list?.length > 0 &&
    data?.board_list?.map((board: Record<string, any>) => {
      const board_name =
        board?.project_name.charAt(0).toUpperCase() +
        board?.project_name.slice(1);
      boardOptions.push({
        name: board_name,
        value: board?._id,
        label: board_name,
      });
    });

  useEffect(() => {
    dispatch(getAllBoard({ all: true })).then((result: any) => {
      if (getAllBoard.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          const updatedBoardOptions = [
            { name: 'All Boards', value: '', label: 'All Boards' },
            ...result.payload.data.board_list.map(
              (board: Record<string, any>) => ({
                name:
                  board.project_name.charAt(0).toUpperCase() +
                  board.project_name.slice(1),
                value: board._id,
                label:
                  board.project_name.charAt(0).toUpperCase() +
                  board.project_name.slice(1),
              })
            ),
          ];

          // Update boardOptions dynamically
          boardOptions = updatedBoardOptions;

          // Update boardName and boardValue based on searchParams
          const filterValue = searchParams.get('board_id') ?? '';
          const selectedOption =
            updatedBoardOptions.find(
              (option) => option.value === filterValue
            ) || updatedBoardOptions[0]; // Default to 'All Boards'
          setBoardValue(filterValue);
          setBoardName(selectedOption);

          // Replace the route if needed
          router.replace(path);
        }
      }
    });
  }, []);

  const handleBoardChange = (selectedOption: Record<string, any>) => {
    setBoardValue(selectedOption?.value);

    dispatch(
      getAllTimesheetReports({
        ...sortObject,
        page: 1,
        filter: {
          start_date: startDate,
          end_date: endDate,
        },
        board_id: selectedOption?.value,
        assignee_id: assignee?.value,
        task_id: statusValue,
      })
    );
  };

  const handleTaskFilterChange = (selectedOption: Record<string, any>) => {
    setStatusValue(selectedOption?.value);

    dispatch(
      getAllTimesheetReports({
        ...sortObject,
        page: 1,
        filter: {
          start_date: startDate,
          end_date: endDate,
        },
        board_id: boardValue,
        assignee_id: assignee?.value,
        task_id: selectedOption?.value,
      })
    );
  };

  useEffect(() => {
    !!endDate &&
      dispatch(
        getAllTimesheetReports({
          ...sortObject,
          page: 1,
          filter: {
            start_date: startDate,
            end_date: endDate,
          },
          board_id: boardValue,
          assignee_id: assignee?.value,
          task_id: statusValue,
        })
      );
  }, [endDate, startDate]);

  const handleAssigneeChange = (selectedOption: Record<string, any>) => {
    // setStatusValue(selectedOption?.value);

    dispatch(
      getAllTimesheetReports({
        ...sortObject,
        page: 1,
        filter: {
          start_date: startDate,
          end_date: endDate,
        },
        board_id: boardValue,
        assignee_id: selectedOption?.value,
        task_id: statusValue,
      })
    );
  };

  const handleResetFilters = () => {
    setTaskName({
      name: 'All Tasks',
      value: '',
      label: 'All Tasks',
    });
    setStatusValue('');
    setBoardName({
      name: 'All Boards',
      value: '',
      label: 'All Boards',
    });
    setBoardValue('');
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setAssignee({ name: 'Assigned to', value: '', label: 'Assigned to' });

    setReset(true);

    dispatch(
      getAllTimesheetReports({
        ...sortObject,
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        search: '',
        filter: '',
        board_id: '',
        assignee_id: '',
        task_id: '',
      })
    );
  };

  const assigneeOptions = [{ name: 'All', value: '', label: 'All' }];
  timeSheetdata?.users?.length > 0 &&
    timeSheetdata?.users?.map((assignee: Record<string, any>) => {
      assigneeOptions.push({
        name: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        label: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        value: assignee?._id,
      });
    });

  // const tasksOptions = [{ name: 'All', value: '', label: 'All' }];
  // tasksData?.activity?.length > 0 &&
  //   tasksData?.activity?.map((task: Record<string, any>) => {
  //     tasksOptions.push({
  //       name: `${capitalizeFirstLetter(task?.title)}`,
  //       label: `${capitalizeFirstLetter(task?.title)} `,
  //       value: task?._id,
  //     });
  //   });

  // My Tasks Table Filters
  const ReportsFilter = () => {
    return (
      <>
        <ReactSelect
          options={boardOptions}
          onChange={(selectedOption: Record<string, any>) => {
            setBoardName(selectedOption);
            setBoardValue(selectedOption.value);
            handleBoardChange(selectedOption);
          }}
          value={boardName}
          placeholder="Select Board"
          className="poppins_font_number react-select-options task-assign w-full"
          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
          styles={customStyles}
        />
        <ReactSelect
          options={tasksOptions}
          onChange={(selectedOption: Record<string, any>) => {
            setTaskName(selectedOption);
            handleTaskFilterChange(selectedOption);
          }}
          value={TaskName}
          placeholder="Select Task"
          className="poppins_font_number react-select-options task-assign w-full"
          classNamePrefix="custom-multi-select"
          styles={customStyles}
          onMenuOpen={() => setMenuIsOpen(true)} // Keep track of menu state
          onMenuClose={() => setMenuIsOpen(false)}
          menuIsOpen={menuIsOpen} // Prevent closing while fetching
          onMenuScrollToBottom={() => fetchTasks(page)}
        />
        {(['agency', 'client'].includes(signIn.role) ||
          (['team_agency', 'team_client'].includes(signIn.role) &&
            checkPermission(
              'reports',
              'timesheet_reports',
              'everyone',
              signIn?.permission
            ))) && (
          <ReactSelect
            options={assigneeOptions}
            onChange={(selectedOption: Record<string, any>) => {
              handleAssigneeChange(selectedOption);
              setAssignee(selectedOption);
            }}
            value={assignee}
            placeholder="Assigned to"
            className="poppins_font_number react-select-options task-assign w-full"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            styles={customStyles}
          />
        )}
        <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
      </>
    );
  };

  //download sheet
  const timesheetReportDownload = () => {
    setexelbuttonloadding(true);
    dispatch(
      timesheetReportsdownload({
        ...sortObject,
        filter: {
          start_date: startDate,
          end_date: endDate,
        },
        board_id: boardValue,
        assignee_id: assignee?.value,
        task_id: statusValue,
      })
    )
      .then(async (result: any) => {
        if (timesheetReportsdownload.fulfilled.match(result)) {
          const blob = await result.payload;
          setexelbuttonloadding(false);
          // Create a URL for the blob data
          const url = window.URL.createObjectURL(
            new Blob([blob], {
              type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            })
          );

          // Create a temporary anchor element
          const a = document.createElement('a');
          a.href = url;

          // Set the filename for the downloaded file
          a.download = 'timesheet_report.xlsx';

          // Programmatically click the anchor element to trigger the download
          a.click();

          // Clean up by revoking the object URL
          window.URL.revokeObjectURL(url);
        }
        console.log(result, 'download sheet');
      })
      .catch((err: any) => {
        setexelbuttonloadding(false);
      });
  };

  return (
    <>
      <CustomePageHeader
        title={pageHeader?.title}
        titleClassName="montserrat_font_title"
        isTimesheet={true}
      >
        <Button
          variant="solid"
          className="w-[30] bg-[#E3E1F4] text-[#8C80D2] lg:w-auto"
          onClick={timesheetReportDownload}
          disabled={exelbuttonloading}
        >
          <PiArrowLineDownBold className="me-1.5 h-[17px] w-[17px]" />
          Export
          {exelbuttonloading && (
            <Spinner
              size="sm"
              tag="div"
              className="ms-3 bg-[#E3E1F4] text-[#8C80D2] "
              // style={{ color: '#8C80D2' }}
            />
          )}
        </Button>
      </CustomePageHeader>
      <WidgetCard rounded="lg" className="mt-2" title="">
        <div className="table_border_remove">
          <CustomTable
            data={(timeSheetdata && timeSheetdata?.activity) ?? []}
            total={(timeSheetdata && timeSheetdata?.page_count) ?? 1}
            loading={loading ?? false}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={timesheetReportsColumns}
            scroll={{ x: 1100 }}
            filtersList={<ReportsFilter />}
            reset={reset}
            setReset={setReset}
            ismyTask={true}
            setPeriod={setPeriod}
            setStartDate={setStartDate}
            setEndDate={setEndDate}
            isRangeFilter={true}
            resetValue={reset}
          />
        </div>
      </WidgetCard>
    </>
  );
}
