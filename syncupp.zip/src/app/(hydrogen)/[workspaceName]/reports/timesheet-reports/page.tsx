import { metaObject } from '@/config/site.config';
import TimesheetReportsPage from './main-page';

export const metadata = {
  ...metaObject('Reports'),
};

export default function Page() {
  return (
    <div className="main_card_block">
      <TimesheetReportsPage />
    </div>
  );
}
