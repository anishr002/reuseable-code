'use client';

import { ManageCalendarId } from '@/app/shared/(user)/setting/manage-calendar-id';
import ManageWorkspaceImage from '@/app/shared/(user)/setting/manage-workspace-image';
import ModalButton from '@/app/shared/modal-button';
import WidgetCard from '@/components/cards/widget-card';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import Spinner from '@/components/ui/spinner';
import {
  getDefalutInvoiceImage,
  setEditValue,
} from '@/redux/slices/user/setting/settingSlice';
import attendanceImg from '@public/assets/images/attendanceImg.jpg';
import holidayImg from '@public/assets/images/holiday.png';
import pabblyImage from '@public/assets/images/pabbly.png';
import taskIDImg from '@public/assets/images/task_id.png';
import zaiperImage from '@public/assets/images/zapier.png';
import googleCalendarImage from '@public/assets/svgs/google-calendar.svg';
import syncUppLogo from '@public/assets/svgs/syncupp-new-logo.svg';

import HolidayCompo from '@/app/shared/(user)/setting/Holiday';
import AttendanceConfig from '@/app/shared/(user)/setting/attendance-config';
import TaskIdPrefix from '@/app/shared/(user)/setting/task-id-prefix';
import TimeTrackingSetting from '@/app/shared/(user)/setting/time-tracking-setting';
import {
  getVerifyGoogleCalendarConfig,
  postGoogleCalendarConfig,
} from '@/redux/slices/user/activity/activitySlice';
import chronometer from '@public/assets/images/chronometer.png';
import { useGoogleLogin } from '@react-oauth/google';
import Image from 'next/image';
import { useEffect } from 'react';
import { FaExternalLinkAlt } from 'react-icons/fa';
import { IoIosSettings } from 'react-icons/io';
import { PiNotePencilDuotone } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'rizzui';

function SupportPage() {
  const dispatch = useDispatch();
  const { invoiceLogoURL, getDefalutInvoiceImageLoading } = useSelector(
    (state: any) => state?.root?.setting
  );
  const { postGoogleCalendarConfigLoader, isGoogleCalendarConfig } =
    useSelector((state: any) => state?.root?.activity);
  const signIn = useSelector((state: any) => state?.root?.signIn);

  useEffect(() => {
    dispatch(getDefalutInvoiceImage());
    dispatch(setEditValue(null));
  }, []);

  // verify configure google calendar or not
  useEffect(() => {
    dispatch(getVerifyGoogleCalendarConfig());
  }, []);

  const googleLogin = useGoogleLogin({
    flow: 'auth-code',
    scope:
      'profile email https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.events.readonly', // Add scopes as needed
    onSuccess: async (codeResponse) => {
      // expected response type is 'codeResponse'
      console.log('Google response....', codeResponse);

      if (codeResponse && codeResponse?.code) {
        await dispatch(
          postGoogleCalendarConfig({ code: codeResponse?.code })
        ).then((result: any) => {
          if (postGoogleCalendarConfig.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              dispatch(getVerifyGoogleCalendarConfig());
            }
          }
        });
      }
    },
    onError: (errorResponse) => {
      console.log('Error Response', errorResponse);
    },
  });

  if (getDefalutInvoiceImageLoading) {
    return (
      <>
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" className="ms-3" />
        </div>
      </>
    );
  }
  return (
    <>
      <CustomePageHeader
        title="Settings"
        titleClassName="montserrat_font_title"
      />
      <div className="grid grid-cols-2 gap-2">
        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center gap-5 lg:flex-row lg:items-center">
              <div className="profile_sections mb-4 lg:mb-0">
                <img
                  src={
                    `${process.env.NEXT_PUBLIC_IMAGE_URL}` +
                    '/' +
                    invoiceLogoURL?.invoice?.logo
                  }
                  alt={''}
                  width={40}
                  height={40}
                  className="rounded-full bg-[#70C5E0]/[.08] font-bold text-white"
                  onError={(event: any) => {
                    event.target.src = syncUppLogo?.src;
                  }}
                />
              </div>
              <div className="mb-4 w-full flex-1 lg:mb-0">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Manage Workspace Logo
                </div>
              </div>
              <div>
                <ModalButton
                  label="Edit"
                  view={<ManageWorkspaceImage title="Manage Workspace Image" />}
                  size="DEFAULT"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                  }
                />
              </div>
            </div>
          </WidgetCard>
        )}
        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={chronometer}
                  alt="time tracking"
                  width={60}
                  height={60}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Time Tracking
                </div>
              </div>
              <div>
                <ModalButton
                  label="Edit"
                  view={<TimeTrackingSetting title="Time Tracking" />}
                  customSize="500px"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                  }
                />
              </div>
            </div>
          </WidgetCard>
        )}
        <WidgetCard className="mt-2" rounded="lg" title="">
          <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
            <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
              <Image
                src={googleCalendarImage}
                alt="Google calendar"
                width={60}
                height={60}
                className="font-bold text-white"
              />
            </div>
            <div className="w-full flex-1">
              <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                Manage Google Calendar
              </div>
            </div>
            <div>
              {isGoogleCalendarConfig ? (
                <ModalButton
                  label="Edit"
                  view={<ManageCalendarId title="Google Calendar Events" />}
                  customSize="500px"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                  }
                />
              ) : (
                <Button
                  onClick={googleLogin}
                  disabled={postGoogleCalendarConfigLoader}
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                >
                  <IoIosSettings className="mr-1 h-[20px] w-[20px]" />
                  Configure
                  {postGoogleCalendarConfigLoader && (
                    <Spinner
                      size="sm"
                      tag="div"
                      className="ms-3 text-[#8C80D2]"
                      // color='white'
                    />
                  )}
                </Button>
              )}
            </div>
          </div>
        </WidgetCard>
        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={zaiperImage}
                  alt="Zapier"
                  width={60}
                  height={60}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Zapier
                </div>
              </div>
              <div>
                <Button
                  onClick={() =>
                    window.open('https://zapier.com/app/login', '_blank')
                  }
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                >
                  <FaExternalLinkAlt className="mr-1 h-[18px] w-[18px]" />
                  Configure
                </Button>
              </div>
            </div>
          </WidgetCard>
        )}
        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={pabblyImage}
                  alt="Pabbly"
                  width={60}
                  height={60}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Pabbly
                </div>
              </div>
              <div>
                <Button
                  onClick={() =>
                    window.open('https://accounts.pabbly.com/login', '_blank')
                  }
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                >
                  <FaExternalLinkAlt className="mr-1 h-[18px] w-[18px]" />
                  Configure
                </Button>
              </div>
            </div>
          </WidgetCard>
        )}

        {/* {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={customFieldImg}
                  alt="customefiled-img"
                  width={100}
                  height={100}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Custom Fields
                </div>
              </div>
              <div>
                <ModalButton
                  label="Edit"
                  view={<CustomFieldSetting title="Custom Fields" />}
                  customSize="700px"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                  }
                />
              </div>
            </div>
          </WidgetCard>
        )} */}

        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={attendanceImg}
                  alt="attendance-img"
                  width={100}
                  height={100}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Attendance
                </div>
              </div>
              <div>
                <ModalButton
                  label="Edit"
                  view={<AttendanceConfig title="Attendance Config" />}
                  customSize="500px"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                  }
                />
              </div>
            </div>
          </WidgetCard>
        )}
        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={holidayImg}
                  alt="attendance-img"
                  width={100}
                  height={100}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Holiday Management
                </div>
              </div>
              <div onClick={() => dispatch(setEditValue(null))}>
                <ModalButton
                  label="Edit"
                  view={<HolidayCompo title="Holiday Management" />}
                  customSize="1100px"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px] " />
                  }
                />
              </div>
            </div>
          </WidgetCard>
        )}

        {signIn?.role === 'agency' && (
          <WidgetCard className="mt-2" rounded="lg" title="">
            <div className="mb-2 flex flex-col items-center justify-center gap-5 lg:flex-row lg:items-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-[#70C5E0]/[.08] ">
                <Image
                  src={taskIDImg}
                  alt="taskid-img"
                  width={100}
                  height={100}
                  className="font-bold text-white"
                />
              </div>
              <div className="w-full flex-1">
                <div className="text-center text-[24px] font-bold leading-[25px] text-[#120425] lg:text-left">
                  Task Id Prefix
                </div>
              </div>
              <div>
                <ModalButton
                  label="Edit"
                  view={<TaskIdPrefix title="Task Id Prefix" />}
                  customSize="500px"
                  className="mt-0 flex w-full items-center justify-center rounded-full bg-[#E3E1F4] px-6 py-4 text-[16px] font-semibold text-[#8C80D2] hover:border-2 hover:border-[#8C80D2] hover:bg-white "
                  icon={
                    <PiNotePencilDuotone className="mr-1 h-[20px] w-[20px]" />
                  }
                />
              </div>
            </div>
          </WidgetCard>
        )}
      </div>
    </>
  );
}

// export default withRoleAuth([roles.agency])(SupportPage);
export default SupportPage;
