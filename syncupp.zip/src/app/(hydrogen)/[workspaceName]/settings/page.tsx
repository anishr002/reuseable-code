import { metaObject } from '@/config/site.config';
import SupportPage from './main-page';

export const metadata = {
  ...metaObject('Settings'),
};

export default function Page() {
  return (
    <>
      <SupportPage />
    </>
  );
}
