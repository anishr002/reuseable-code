'use client';
import { routes } from '@/config/routes';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import Spinner from '@/components/ui/spinner';

export default function WorkspaceName() {
  const router = useRouter();
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  useEffect(() => {
    router.push(routes.dashboard(defaultWorkSpace?.name));
  }, []);

  return (
    <>
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    </>
  );
}