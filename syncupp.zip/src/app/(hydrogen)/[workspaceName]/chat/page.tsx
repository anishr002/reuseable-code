import ChatInbox from '@/app/shared/(user)/chat/inbox';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Chat'),
};

export default function Page() {
  return (
    <div>
      {/* className="chat_inner_scroll" */}
      <ChatInbox />
    </div>
  );
}
