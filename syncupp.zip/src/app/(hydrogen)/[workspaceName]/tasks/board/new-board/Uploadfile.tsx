// ** React Imports
import TrashIcon from '@/components/icons/trash';
import UploadIcon from '@/components/shape/upload';
import { useState, Fragment, memo } from 'react';
import Profile from '@public/dummyprofile.jpg';

// ** Reactstrap Imports
//import { Card, CardBody } from "reactstrap";

// ** Third Party Imports
import { useDropzone } from 'react-dropzone';
import { Button } from 'rizzui';
//import { FileText, X, DownloadCloud, UploadCloud } from "react-feather";

interface FileUploaderProps {
  resetImage?: any,
  setResetImage?: any
  setFieldValue: any;
  name: string;
  initialPath: any;
  readonly: boolean;
  errors: any;
  user: boolean; // You might want to replace this with the correct type
  compontes: any;
}

const FileUploader: React.FC<FileUploaderProps> = (props) => {
  // ** State
  const {
    resetImage,
    setResetImage,
    setFieldValue,
    name,
    initialPath,
    readonly,
    user,
    errors,
    compontes,
    ...inputProps
  } = props;
  const [files, setFiles] = useState<any[]>([]); // You might want to replace 'any' with a more specific type
  const [initialPaths, setinitialPaths] = useState(initialPath);
  const { getRootProps, getInputProps } = useDropzone({
    multiple: false,
    accept: { 'image/*': [] },
    onDrop: (acceptedFiles) => {
      setFiles(
        acceptedFiles.map((file) => {
          setFieldValue(name, file);
          errors(name, {
            type: '',
            message: '',
          });
          return Object.assign(file, {
            preview: URL.createObjectURL(file),
          });
        })
      );
    },
  });

  const removeimage = () => {
    setFieldValue(name, '');
    setFiles([]);
    setinitialPaths(undefined);
  };

  return (
    <div className="ddd col-span-2 flex h-full items-center gap-5 pt-2">
      {!readonly ? (
        // <div
        //   {...getRootProps({
        //     className: `relative  h-20 w-20 rounded-full border-[1.8px] ${
        //       readonly ? 'cursor-not-allowed' : 'cursor-pointer'
        //     } `,
        //   })}
        // >
          <div
          {...getRootProps({
            className: `${
              readonly ? 'cursor-not-allowed' : 'cursor-pointer'
            } `,
          })}
        >
          <input {...getInputProps({ ...inputProps })} />
          <div className="flex h-full flex-col items-center justify-center gap-2">
            {/* <UploadIcon className="size-6"></UploadIcon>
            <p className="pt-1 text-center text-xs ">Select or drag file </p> */}
            <Button>Add Picture</Button>
          </div>
        </div>
      ) : (
        ''
      )}

      {files && files.length > 0 ? (
        <div className="flex h-[150px] w-[150px] items-center justify-center">
          {files.map((file, index) => {
            return (
              <Fragment key={index}>
                {file?.preview ? (
                  <img
                    src={
                      file?.preview
                        ? file.preview
                        : `${process.env.NEXT_PUBLIC_IMAGE_URL}/${initialPaths}`
                    }
                    alt={`Preview ${index + 1}`}
                    // style={{ height: '250px', width: '250px' }}
                    className="h-full w-full"
                  />
                ) : (
                  ''
                )}
              </Fragment>
            );
          })}
        </div>
      ) : initialPaths ? (
        <div className="flex h-[150px] w-[150px] items-center justify-center">
          <img
            src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${initialPaths}`}
            className="h-full w-full"
            alt={Profile?.src}
          />
        </div>
      ) : (
        compontes && (
          <div className="flex h-[150px] w-[150px] items-center justify-center">
            <img
              src={Profile?.src}
              className="h-full w-full"
              alt={Profile?.src}
            />
          </div>
        )
      )}
      {!readonly && (files.length > 0 || !!initialPaths) ? (
        <TrashIcon className="h-4 w-4 cursor-pointer" onClick={removeimage} />
      ) : (
        ''
      )}
    </div>
  );
};

export default memo(FileUploader);
