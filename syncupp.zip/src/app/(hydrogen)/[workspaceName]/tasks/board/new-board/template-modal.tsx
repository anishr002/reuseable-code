'use client';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Button } from '@/components/ui/button';
import { Popover } from '@/components/ui/popover';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { Title } from '@/components/ui/text';
import '@/layouts/helium/style.css';
import {
  deleteTemplate,
  getTemplateGroup,
  getTemplateList,
} from '@/redux/slices/user/template/templateSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import { useEffect, useState } from 'react';
import { FaPlus } from 'react-icons/fa6';
import { PiPlusBold, PiXBold } from 'react-icons/pi';
import { SlOptionsVertical } from 'react-icons/sl';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon } from 'rizzui';
import AddTemplateModal from './add-template-modal';
import newTemplate from '@public/assets/images/newTemplate.png';

export const ChooseTemplate = ({
  selectedTemplateData,
  setSelectedTemplateData,
  onClose,
}: any) => {
  const dispatch = useDispatch();
  const {
    getTemplateGroupData,
    gettemplateListData,
    getTemplateGroupLoader,
    getTemplateListLoader,
    deletetemplateLoader,
  } = useSelector((state: any) => state?.root?.template);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [tamplateAdd, setTamplateAdd] = useState(false);
  const { closeModal } = useModal();
  const [isView, setIsView] = useState(false);
  const [templateData, setTemplateData] = useState(null);
  const [groupAdd, setGroupAdd] = useState(false);

  useEffect(() => {
    dispatch(getTemplateGroup()).then((result: any) => {
      if (getTemplateGroup.fulfilled.match(result)) {
        if (
          result &&
          result.payload.success === true &&
          result.payload?.data?.groupList?.length > 0
        ) {
          dispatch(
            getTemplateList(
              selectedTemplateData?.group_name
                ? selectedTemplateData?.group_name
                : result.payload?.data?.groupList?.[0]
            )
          );
          setSelectedItem(
            selectedTemplateData?.group_name
              ? selectedTemplateData?.group_name
              : result.payload?.data?.groupList?.[0]
          );
        }
      }
    });
  }, [dispatch]);

  const handleSidebarMenu = (menu: string) => {
    setSelectedItem(menu);
    dispatch(getTemplateList(menu));
  };

  const handleDelete = (template: any) => {
    setSelectedTemplateData(null);
    dispatch(deleteTemplate(template?._id)).then((result: any) => {
      if (deleteTemplate.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          dispatch(getTemplateList(selectedItem));
        }
      }
    });
  };

  return (
    <div className="min-h-[630px]">
      <div className="flex items-center justify-between py-2">
        <h4 className="montserrat_font_title ms-3 p-3 text-[#111928] leading-[100%]">
          {' '}
          Select Template
        </h4>
        <ActionIcon
          size="sm"
          variant="text"
          // onClick={() => closeModal()}
          onClick={onClose}
          className="me-4 p-0 text-[#0B0B0B]"
        >
          <PiXBold className="h-6 w-6 " />
        </ActionIcon>
      </div>
      {/* <SimpleBar className="max-h-[531px]"> */}
      <>
        {getTemplateGroupLoader ? (
          <div className="flex items-center justify-center p-10">
            <Spinner size="xl" tag="div" />
          </div>
        ) : (
          <div className="flex min-h-[561px] bg-[#FAFAFA]">
            <div className='py-5 pe-3 ps-6 w-[30%]'>
            <aside className="relative w-full rounded-[5px] bg-[#F5F5F7] text-black h-full">
              <SimpleBar className="max-h-[540px] p-4 ">
                <ul className="space-y-2">
                  {getTemplateGroupData?.groupList?.map((item: string) => (
                    <>
                      <li
                        className={`text-md poppins_font_number cursor-pointer rounded text-[#1E1E1E] p-2 font-medium hover:text-[#6875F5] ${
                          selectedItem === item && ' text-[#6875F5]'
                        }`}
                        onClick={() => handleSidebarMenu(item)}
                      >
                        {capitalizeFirstLetter(item)}
                      </li>
                    </>
                  ))}
                </ul>
              </SimpleBar>
              <div className="absolute bottom-0 mt-6 w-full border-gray-300 p-4">
                <Button
                  type="button"
                  className="w-full rounded-lg bg-[#7667CF] !px-3 py-2 text-sm font-medium text-white hover:bg-[#7362c3]"
                  onClick={() => {
                    setIsView(false);
                    setTamplateAdd(true);
                    setTemplateData(null);
                    setGroupAdd(true);
                  }}
                >
                  <PiPlusBold className="me-1.5 h-3 w-3" /> Add Industry
                </Button>
              </div>
            </aside>
            </div>

            {/* Main Content for Template Listing */}
            <main className="flex-1 rounded-br-xl bg-gray-50 pe-4">
              {getTemplateListLoader ? (
                <div className="flex h-full w-full items-center justify-center p-10">
                  <Spinner size="xl" tag="div" />
                </div>
              ) : (
                <div className="max-h-[600px]  overflow-y-auto  p-4">
                  <h2 className="poppins_font_number mb-4 text-2xl font-bold text-black">
                    {capitalizeFirstLetter(selectedItem)}
                  </h2>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-2">
                    {/* Template Cards */}
                    <div
                      className="flex cursor-pointer justify-center rounded-lg border border-gray-200 bg-gray-0 p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg"
                      onClick={() => {
                        setIsView(false);
                        setTamplateAdd(true);
                        setTemplateData(null);
                        setGroupAdd(false);
                      }}
                    >
                      <Title
                        as="h4"
                        className="my-1 flex items-center gap-2 text-sm font-medium text-[#8C80D2]"
                      >
                        <FaPlus />
                        <span className="poppins_font_number">
                          New Template
                        </span>
                      </Title>
                    </div>
                    {gettemplateListData?.templates?.map((template: any) => (
                      <div
                        className={`relative flex cursor-pointer flex-col items-center justify-center rounded-lg border p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg
                        ${
                          template?._id === selectedTemplateData?._id
                            ? 'border-[#8C80D2] bg-[#EAE6FF]'
                            : 'border-gray-200 bg-gray-0'
                        }`}
                        key={template?._id}
                        onClick={() => {
                          // setSelectedTemplateData(template);
                          // closeModal();
                          setIsView(true);
                          // setOpen(false);
                          setTamplateAdd(true);
                          setTemplateData(template);
                          setGroupAdd(false);
                        }}
                      >
                        <Title
                          as="h4"
                          className="poppins_font_number my-1 mr-4 overflow-hidden break-all text-center text-sm font-medium text-gray-800"
                        >
                          {capitalizeFirstLetter(template?.template_name)}
                        </Title>
                        {/* Image Section */}
                        <img
                          src={
                            template?.img
                              ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${template?.img}`
                              : newTemplate?.src
                          }
                          alt={'Template Preview'}
                          className="mt-3 aspect-auto h-32 w-full rounded-md object-cover"
                        />

                        {/* Popover and Options */}
                        {!template?.is_default && (
                          <div className="flex w-full items-start justify-between">
                            <Popover
                              placement="bottom"
                              className=" demo_test min-w-[100px] p-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                              content={({ setOpen }) => {
                                return (
                                  <div className="p-2 text-gray-900">
                                    {/* <Button
                                    variant="text"
                                    className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setIsView(true);
                                      setOpen(false);
                                      setTamplateAdd(true);
                                      setTemplateData(template);
                                      setGroupAdd(false);
                                    }}
                                  >
                                    View
                                  </Button> */}

                                    <>
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setIsView(false);
                                          setOpen(false);
                                          setTamplateAdd(true);
                                          setTemplateData(template);
                                          setGroupAdd(false);
                                        }}
                                      >
                                        Edit
                                      </Button>
                                      <Button
                                        variant="text"
                                        className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleDelete(template);
                                        }}
                                        disabled={deletetemplateLoader}
                                      >
                                        Delete
                                      </Button>
                                    </>
                                  </div>
                                );
                              }}
                            >
                              <ActionIcon
                                title={'More Options'}
                                className="absolute right-2 top-3 pb-2 text-gray-600 hover:text-gray-800 "
                                variant="text"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <SlOptionsVertical
                                  width={18}
                                  height={18}
                                  className="cursor-pointer"
                                />
                              </ActionIcon>
                            </Popover>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </main>
          </div>
        )}

        {tamplateAdd && (
          <div>
            <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
              <div
                className="relative overflow-hidden rounded-lg bg-white shadow-lg "
                style={{ width: '900px', height: '630px' }}
              >
                <AddTemplateModal
                  setTamplateAdd={setTamplateAdd}
                  isView={isView}
                  groupAdd={groupAdd}
                  groupName={selectedItem}
                  templateData={templateData}
                  setSelectedItem={setSelectedItem}
                  setSelectedTemplateData={setSelectedTemplateData}
                  onClose={onClose}
                />
              </div>
            </div>
          </div>
        )}
        {/* </SimpleBar> */}
      </>
    </div>
  );
};
