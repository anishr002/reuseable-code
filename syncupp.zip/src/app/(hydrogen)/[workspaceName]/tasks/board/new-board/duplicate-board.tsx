'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import Spinner from '@/components/ui/spinner';
import { postDuplicateBoard } from '@/redux/slices/user/task/boardSlice';
import { useEffect, useState } from 'react';
import { PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox, Switch } from 'rizzui';

export default function DuplicateBoard({
  boards,
  setPalyload,
  setUpdateddata,
  setSkeletonloader,
  searchValue,
  sortValue,
  setCheckedBoards,
}: {
  boards: any;
  setPalyload: any;
  setUpdateddata: any;
  setSkeletonloader: any;
  searchValue?: any;
  sortValue?: any;
  setCheckedBoards?: any;
}) {
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const [workspaces, setWorkspaces] = useState<any>([]);
  const [includeTasks, setIncludeTasks] = useState(false);
  const [includeTaskAssignees, setIncludeTaskAssignees] = useState(false);
  const [includeTaskAttachments, setIncludeTaskAttachments] = useState(false);
  const [includeBoardAssignees, setIncludeBoardAssignees] = useState(false);

  // New states for sub-tasks
  const [includeSubTasks, setIncludeSubTasks] = useState(false);
  const [includeSubTaskAssignees, setIncludeSubTaskAssignees] = useState(false);
  const [includeSubTaskAttachments, setIncludeSubTaskAttachments] =
    useState(false);
  const [error, setError] = useState('');

  const { duplicateBoardloading } = useSelector(
    (state: any) => state?.root?.board
  );
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { workspaceList, defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  console.log('board_idssss......', boards);
  console.log('workspaces......', workspaces);
  console.log('defaultWorkSpace......', defaultWorkSpace);
  console.log('error......', error);

  useEffect(() => {
    if (agencyWorkspaces?.length > 0 && workspaces?.length > 0) {
      setError('');
    }
  }, [workspaces]);

  // Agency workspace list
  const agencyWorkspaces =
    workspaceList && workspaceList?.length > 0
      ? workspaceList?.filter(
          (workspace: Record<string, any>) =>
            workspace?.created_by === signIn?.userProfile?._id ||
            workspace?._id === defaultWorkSpace?._id
        )
      : [];
  console.log('agencyWorkspaces......', agencyWorkspaces);

  // Duplicate board api call function
  const handleDuplicateBoard = () => {
    // If user doesn't select workspace then throw error.
    if (agencyWorkspaces?.length > 0 && workspaces?.length === 0) {
      setError('Please select at least one workspace.');
      return;
    }
    // If there is an error then don't proceed further.
    if (error && error !== '') {
      return;
    }

    const duplicationOptions = {
      board_ids: boards ?? [],
      workspace_ids: workspaces ?? [],
      include_tasks: includeTasks,
      include_task_assignees: includeTaskAssignees,
      include_task_attachments: includeTaskAttachments,
      include_board_assignees: includeBoardAssignees,
      include_sub_tasks: includeSubTasks,
      include_sub_tasks_assignees: includeSubTaskAssignees,
      include_sub_tasks_attachments: includeSubTaskAttachments,
    };

    // Call your duplicate board function here and pass duplicationOptions as data.
    console.log('Duplicating board with options:', duplicationOptions);

    dispatch(postDuplicateBoard(duplicationOptions)).then((result: any) => {
      if (postDuplicateBoard.fulfilled.match(result)) {
        if (result && result?.payload?.success === true) {
          setCheckedBoards([]); // unselect all boards after successfull api call
          closeModal();
          // dispatch(getAllBoard({ all: false, limit: 10, skip: 0, sort: '' }));
          setUpdateddata([]);
          setSkeletonloader(true);
          setPalyload({
            skip: 0,
            limit: 20,
            all: false,
            sort: sortValue ?? '',
            search: searchValue ?? '',
          });
        }
      }
    });
  };
  return (
    <div className="flex flex-col justify-start gap-5 p-7">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex flex-col justify-start gap-5">
          {boards?.length > 1 && (
            <div className="text-xs font-medium uppercase text-[#636363]">
              {boards?.length ?? 0} boards selected to be duplicated
            </div>
          )}
          {agencyWorkspaces && agencyWorkspaces?.length > 0 && (
            <>
              <div className="text-[16px] font-semibold leading-5 text-[#141414]">
                Select Workspaces to duplicate to
              </div>
              <div className="flex flex-row flex-wrap items-center justify-start gap-5">
                {agencyWorkspaces?.map(
                  (workspace: Record<string, any>, index: number) => {
                    return (
                      <Checkbox
                        key={index}
                        label={workspace?.name}
                        inputClassName="checkbox-color"
                        labelClassName="text-sm font-medium text-[#4B5563] capitalize"
                        checked={workspaces?.includes(workspace?._id)}
                        onChange={(e) => {
                          if (workspaces?.includes(workspace?._id)) {
                            const updatedWorkspaceIds =
                              workspaces && workspaces?.length > 0
                                ? workspaces?.filter(
                                    (workspaceId: string) =>
                                      workspaceId !== workspace?._id
                                  )
                                : [];
                            setWorkspaces(updatedWorkspaceIds);
                          } else {
                            setWorkspaces((prev: any) => [
                              ...prev,
                              workspace?._id,
                            ]);
                          }
                        }}
                      />
                    );
                  }
                )}
              </div>
              {error && error !== '' ? (
                <div className="text-sm font-medium text-red-600">{error}</div>
              ) : null}
            </>
          )}
        </div>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={closeModal}
          className="text-gray-500 hover:!text-gray-900"
        >
          <PiXBold className="size-[18px] text-[#141414]" />
        </ActionIcon>
      </div>
      <div className="border border-[#E5E7EB]" />
      {/* Body */}
      <>
        <div className="text-sm font-semibold text-[#656565]">
          Choose Custom Fields to Duplicate
        </div>
        <div className="flex flex-col gap-1">
          <Switch
            label="Include Board Assignees"
            labelClassName="text-sm font-medium text-[#4B5563]"
            className="checkbox-color"
            checked={includeBoardAssignees}
            onChange={() => {
              const newValue = !includeBoardAssignees;
              setIncludeBoardAssignees(newValue);
              if (!newValue) {
                setIncludeTaskAssignees(false);
                setIncludeTaskAttachments(false);
                setIncludeSubTaskAssignees(false);
                setIncludeSubTaskAttachments(false);
              }
            }}
          />

          <Switch
            label="Include Tasks"
            labelClassName="text-sm font-medium text-[#4B5563]"
            className="checkbox-color"
            checked={includeTasks}
            onChange={() => {
              const newIncludeTasks = !includeTasks;
              setIncludeTasks(newIncludeTasks);
              if (!newIncludeTasks) {
                setIncludeTaskAssignees(false);
                setIncludeTaskAttachments(false);
                setIncludeSubTasks(false);
                setIncludeSubTaskAssignees(false);
                setIncludeSubTaskAttachments(false);
              }
            }}
          />
          {includeTasks && (
            <div className="flex flex-col gap-3 rounded-lg bg-[#F9FAFB] px-4 py-3">
              <Checkbox
                label="Include Task Assignees"
                labelClassName="text-sm font-medium text-[#4B5563]"
                inputClassName="checkbox-color"
                checked={includeTaskAssignees}
                onChange={() => setIncludeTaskAssignees(!includeTaskAssignees)}
                disabled={!includeTasks || !includeBoardAssignees}
              />

              <Checkbox
                label="Include Task Attachments"
                labelClassName="text-sm font-medium text-[#4B5563]"
                inputClassName="checkbox-color"
                checked={includeTaskAttachments}
                onChange={() =>
                  setIncludeTaskAttachments(!includeTaskAttachments)
                }
                disabled={!includeTasks || !includeBoardAssignees}
              />
            </div>
          )}
          {/* Sub-task options */}
          <Switch
            label="Include Sub-Tasks"
            labelClassName="text-sm font-medium text-[#4B5563]"
            className="checkbox-color"
            checked={includeSubTasks}
            onChange={() => {
              const newIncludeSubTasks = !includeSubTasks;
              setIncludeSubTasks(newIncludeSubTasks);
              if (!newIncludeSubTasks) {
                setIncludeSubTaskAssignees(false);
                setIncludeSubTaskAttachments(false);
              }
            }}
            disabled={!includeTasks}
          />
          {includeSubTasks && (
            <div className="flex flex-col gap-3 rounded-lg bg-[#F9FAFB] px-4 py-3">
              <Checkbox
                label="Include Sub-Task Assignees"
                inputClassName="checkbox-color"
                labelClassName="text-sm font-medium text-[#4B5563]"
                checked={includeSubTaskAssignees}
                onChange={() =>
                  setIncludeSubTaskAssignees(!includeSubTaskAssignees)
                }
                disabled={!includeSubTasks || !includeBoardAssignees}
              />

              <Checkbox
                label="Include Sub-Task Attachments"
                labelClassName="text-sm font-medium text-[#4B5563]"
                inputClassName="checkbox-color"
                checked={includeSubTaskAttachments}
                onChange={() =>
                  setIncludeSubTaskAttachments(!includeSubTaskAttachments)
                }
                disabled={!includeSubTasks || !includeBoardAssignees}
              />
            </div>
          )}
        </div>
      </>
      {/* Footer */}
      <div className="flex items-center justify-between gap-2">
        <Button
          variant="outline"
          className="w-auto text-[#141414]"
          onClick={closeModal}
        >
          Cancel
        </Button>
        <Button
          className="hover:border-1 flex w-full items-center justify-center rounded-lg bg-[#7667CF] px-4 py-2 text-[13px] font-semibold text-[#ffff] sm:w-auto"
          type="button"
          onClick={handleDuplicateBoard}
          disabled={duplicateBoardloading}
        >
          <span>{`Confirm & duplicate board${
            boards?.length > 1 ? 's' : ''
          }`}</span>
          {duplicateBoardloading && (
            <Spinner size="sm" tag="div" className="ms-2" color="white" />
          )}
        </Button>
      </div>
    </div>
  );
}
