'use client';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';
import AddBoardForm from './add-board-form';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { roles } from '@/config/roles';
import { CustomePageHeader } from '@/components/pageheader/pageheader';

const pageHeader = {
  title: 'New Board',
};

function Page() {
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  return (
    <>
      <CustomePageHeader
        title={pageHeader.title}
        route={routes.task(defaultWorkSpace?.name)}
        titleClassName="montserrat_font_title"
      />
      <AddBoardForm />
    </>
  );
}

export default withRoleAuth(
  [roles.agency, roles.teamAgency.team_agency, roles.teamClient],
  'projects',
  'boards',
  'create'
)(Page);
