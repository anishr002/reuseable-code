"use client"
import { useModal } from "@/app/shared/modal-views/use-modal";
import { getboardImages } from "@/redux/slices/user/task/boardSlice";
import cn from "@/utils/class-names";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { PiXBold } from "react-icons/pi";
import { useDispatch, useSelector } from "react-redux";
import { ActionIcon, Title } from "rizzui";
import SimpleBar from "@/components/ui/simplebar";
import Spinner from "@/components/ui/spinner";
import "@/layouts/helium/style.css";


export const ChoosePicture = (props: any) => {

    const { setValue, setPreviewImage } = props

    const { openModal, closeModal } = useModal();
    const dispatch = useDispatch()
    const router = useRouter()

    const { boardImagesData, loading } = useSelector((state: any) => state?.root?.board);
    console.log(boardImagesData?.data, 'boardImagesData')


    useEffect(() => {
        dispatch(getboardImages())
    }, [])


    const ImageSelectionHandler = (image: any) => {
        setPreviewImage(`${process.env.NEXT_PUBLIC_IMAGE_URL}/${image}`)
        setValue('board_image', image, { shouldValidate: true })
        closeModal()
    }

    return (
        <>
            <div className="flex justify-between items-center ">
                <h3 className="ms-3 p-3 text-[#8C80D2] montserrat_font_title"> Select Image</h3>
                <ActionIcon
                    size="sm"
                    variant="text"
                    onClick={() => closeModal()}
                    className="p-0 me-4 text-gray-500 hover:!text-gray-900"
                >
                    <PiXBold className="h-[18px] w-[18px]" />
                </ActionIcon>

            </div>
            <SimpleBar className="max-h-[350px]">

                {
                    loading ? (
                        <div className="flex items-center justify-center p-10">
                            <Spinner size="xl" tag="div" />
                        </div>
                    ) : (
                        <div className="flex flex-wrap">
                            {boardImagesData?.data && boardImagesData.data.length > 0 ? (
                                boardImagesData.data.map((image: string, index: number) => (
                                    <div key={index} className="p-2">
                                        <div className="p-5 m-3 w-[140px] h-[140px] flex justify-center items-center border cursor-pointer" onClick={() => { ImageSelectionHandler(image) }}>
                                            <Image
                                                className="rounded-full shadow-lg w-[100%] h-[100%] object-cover"
                                                src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${image}`}
                                                alt={`Image ${index}`}
                                                height={100}
                                                width={100}
                                            />
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <p className="w-full p-10 text-[15px] font-semibold text-center">Oops! It looks like there are no images available at the moment.</p>
                            )}
                        </div>
                    )
                }
            </SimpleBar>
        </>
    )
}