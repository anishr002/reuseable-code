'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import {
  createtemplate,
  editTemplate,
  getTemplateById,
  getTemplateGroup,
  getTemplateList,
} from '@/redux/slices/user/template/templateSlice';
import { handleKeyDown } from '@/utils/common-functions';
import React, { useEffect } from 'react';
import { useFieldArray, useForm } from 'react-hook-form';
import { PiPlusBold, PiTrashBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon } from 'rizzui';
import newTemplate from '@public/assets/images/newTemplate.png';
import { useModal } from '@/app/shared/modal-views/use-modal';

interface AddTemplateModalProps {
  setTamplateAdd: any;
  isView: boolean;
  groupAdd: boolean;
  groupName: String;
  templateData: any;
  setSelectedItem: any;
  setSelectedTemplateData: any;
  onClose?: any;
}

interface Section {
  section: string; // Match the nested field you want to use
}

interface FormData {
  template_name: string;
  group_name: any;
  section_names: Section[]; // Array of sections
}

const AddTemplateModal: React.FC<AddTemplateModalProps> = ({
  setTamplateAdd,
  isView,
  groupAdd,
  groupName,
  templateData,
  setSelectedItem,
  setSelectedTemplateData,
  onClose,
}) => {
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const {
    createTemplateLoader,
    getTemplateByIdData,
    getTemplateByIdLoader,
    editTemplateLoader,
  } = useSelector((state: any) => state?.root?.template);
  const {
    register,
    formState: { errors },
    control,
    handleSubmit,
    reset,
  } = useForm<FormData>({
    mode: 'onChange',
    defaultValues: {
      template_name:
        templateData && getTemplateByIdData?.template_name
          ? getTemplateByIdData?.template_name
          : '',
      group_name: !groupAdd
        ? groupName
        : templateData && getTemplateByIdData?.group_name
          ? getTemplateByIdData?.group_name
          : '',
      section_names:
        templateData && getTemplateByIdData?.section_names
          ? getTemplateByIdData?.section_names?.map((data: string) => ({
              section: data,
            }))
          : [{ section: '' }], // Default value for `useFieldArray`
    },
  });

  const { fields, append, remove } = useFieldArray({
    name: 'section_names',
    control,
  });

  useEffect(() => {
    if (getTemplateByIdData && templateData) {
      reset({
        template_name:
          templateData && getTemplateByIdData?.template_name
            ? getTemplateByIdData?.template_name
            : '',
        group_name: !groupAdd
          ? groupName
          : templateData && getTemplateByIdData?.group_name
            ? getTemplateByIdData?.group_name
            : '',
        section_names:
          templateData && getTemplateByIdData?.section_names
            ? getTemplateByIdData?.section_names?.map((data: string) => ({
                section: data,
              }))
            : [{ section: '' }], // Default value for `useFieldArray`
      });
    }
  }, [templateData, reset, groupAdd, groupName, getTemplateByIdData]);

  useEffect(() => {
    if (templateData) {
      dispatch(getTemplateById(templateData?._id));
    }
  }, [dispatch, templateData]);

  const onSubmit = (data: any) => {
    if (!isView && !templateData) {
      data.section_names = data?.section_names?.map(
        (item: any) => item.section
      );
      dispatch(createtemplate(data)).then((result: any) => {
        if (createtemplate.fulfilled.match(result)) {
          if (result && result.payload.success === true) {
            if (groupAdd) {
              dispatch(getTemplateGroup()).then((result: any) => {
                if (getTemplateGroup.fulfilled.match(result)) {
                  if (
                    result &&
                    result.payload.success === true &&
                    result.payload?.data?.groupList?.length > 0
                  ) {
                    dispatch(
                      getTemplateList(result.payload?.data?.groupList?.[0])
                    );
                    setSelectedItem(result.payload?.data?.groupList?.[0]);
                  }
                }
              });
            } else {
              dispatch(getTemplateList(groupName));
            }

            setTamplateAdd(false);
          }
        }
      });
    } else {
      data.section_names = data?.section_names?.map(
        (item: any) => item.section
      );
      dispatch(editTemplate({ ...data, _id: templateData?._id })).then(
        (result: any) => {
          if (editTemplate.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              dispatch(getTemplateList(groupName));
              setTamplateAdd(false);
            }
          }
        }
      );
    }
  };

  return (
    <div className="max-h-[500px] p-5 ">
      {getTemplateByIdLoader ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" />
        </div>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="flex items-center justify-between px-2">
            <p className="montserrat_font_title text-[23px] font-bold text-[#9BA1B9]">
              {' '}
              {isView
                ? 'Template Details'
                : templateData
                  ? 'Edit Template'
                  : `Add ${groupAdd ? 'Industry & Template' : 'Template'}`}
            </p>
            {!isView ? (
              <div className={'flex items-center justify-end space-x-4 pt-5'}>
                <Button
                  type="button"
                  className="h-[42px] w-auto rounded-[8px] border border-gray-300  text-sm text-[#141414]"
                  onClick={() => setTamplateAdd(false)}
                  // rounded="pill"
                  variant="outline"
                >
                  Cancel
                </Button>
                <Button
                  className="hover:border-1 flex w-auto items-center justify-center rounded-[8px] bg-[#8C80D2] px-4 py-2 text-[#fff] hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                  type="submit"
                  disabled={createTemplateLoader || editTemplateLoader}
                >
                  <span>
                    {!templateData ? 'Create template' : 'Save template'}
                  </span>
                  {(createTemplateLoader || editTemplateLoader) && (
                    <Spinner
                      size="sm"
                      tag="div"
                      className="ms-3"
                      color="white"
                    />
                  )}
                </Button>
              </div>
            ) : (
              <ActionIcon
                size="sm"
                variant="text"
                onClick={() => setTamplateAdd(false)}
                className="p-0 text-[#9BA1B9] hover:!text-gray-900"
              >
                <PiXBold className="h-[50px] w-[50px] " />
              </ActionIcon>
            )}
          </div>
          <div className="mt-2 max-h-[565px] overflow-y-auto p-2 text-[14px] text-[#9BA1B9] [&_label]:font-medium">
            <div className="flex flex-col gap-4">
              {groupAdd && (
                <div>
                  <Input
                    inputClassName="text-black poppins_font_number bg-white"
                    className="w-full"
                    onKeyDown={handleKeyDown}
                    placeholder="Enter Industry Name"
                    {...register(`group_name`, {
                      required: 'Industry Name is required.',
                      setValueAs: (value) => value.trim(),
                      maxLength: {
                        value: 20,
                        message: 'Group Name maximum length is 20.',
                      },
                    })}
                    error={errors?.group_name?.message as string | undefined}
                    disabled={isView}
                    label="Industry Name"
                  />
                </div>
              )}
              <div>
                <Input
                  inputClassName="text-black poppins_font_number bg-white"
                  className="w-full"
                  onKeyDown={handleKeyDown}
                  placeholder="Enter Template Name"
                  {...register(`template_name`, {
                    required: 'Template Name is required.',
                    setValueAs: (value) => value.trim(),
                    maxLength: {
                      value: 100,
                      message: 'Template Name maximum length is 100.',
                    },
                  })}
                  disabled={isView}
                  error={errors?.template_name?.message}
                  label="Template Name"
                />
              </div>
              {isView && (
                <div>
                  <img
                    src={
                      getTemplateByIdData?.img
                        ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${getTemplateByIdData?.img}`
                        : newTemplate?.src
                    }
                    alt={'Template Preview'}
                    className="mb-3 aspect-auto w-full rounded-md object-cover"
                  />
                </div>
              )}

              {!isView &&
                fields?.map((field: any, index: number) => {
                  return (
                    <div key={index} className="flex gap-5">
                      <Input
                        inputClassName="text-black poppins_font_number bg-white"
                        className="w-full"
                        onKeyDown={handleKeyDown}
                        placeholder="Enter Section Name"
                        {...register(`section_names.${index}.section`, {
                          required: 'Section Name is required.',
                          setValueAs: (value) => value.trim(),
                          maxLength: {
                            value: 20,
                            message: 'Section Name maximum length is 20.',
                          },
                          validate: (value) => {
                            // Collect all other section names excluding the current one
                            const otherSections = fields
                              .filter((_, i) => i !== index)
                              .map((f) => f.section.toLowerCase());
                            console.log(
                              !otherSections.includes(value.toLowerCase()),
                              otherSections,
                              value,
                              '123'
                            );
                            // Check if the current value (case-insensitive) is unique
                            return (
                              !otherSections.includes(value.toLowerCase()) ||
                              'Section Name must be unique.'
                            );
                          },
                        })}
                        disabled={isView}
                        defaultValue={field.value} // Populates default value
                        error={errors?.section_names?.[index]?.section?.message}
                        label="Section Name"
                      />
                      {!isView && (
                        <div
                          className={`flex gap-5 ${
                            errors?.section_names?.[index]?.section?.message
                              ? 'items-center'
                              : 'items-end'
                          } `}
                        >
                          {fields?.length - 1 === index && (
                            <Button
                              type="button"
                              className="hover:border-1 flex items-center justify-center rounded-[8px] bg-[#8C80D2] px-4 py-2 text-[13px] font-semibold text-[#fff] hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                              onClick={async () => {
                                append({ section: '' });
                              }}
                            >
                              <PiPlusBold className="me-1.5 h-4 w-4" /> Add
                            </Button>
                          )}
                          {fields?.length > 1 && (
                            <Button
                              type="button"
                              className="hover:border-1 flex w-full items-center justify-center rounded-[8px] bg-[#8C80D2] px-4 py-2 text-[13px] font-semibold text-[#fff] hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2] sm:w-auto"
                              onClick={() => remove(index)}
                            >
                              <PiTrashBold className="me-1 h-[18px] w-[18px]" />{' '}
                              Remove
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}

              <div>
                {isView && (
                  <div className="flex gap-4">
                    <Button
                      className="hover:border-1 flex w-auto items-center justify-center rounded-[8px] bg-[#8C80D2] px-4 py-2  text-[#fff] hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                      type="button"
                      onClick={() => setTamplateAdd(false)}
                    >
                      <span>Back</span>
                    </Button>
                    <Button
                      className="hover:border-1 flex w-auto items-center justify-center rounded-[8px] bg-[#8C80D2] px-4 py-2  text-[#fff] hover:border-[#8C80D2] hover:bg-white hover:text-[#8C80D2]"
                      type="button"
                      onClick={() => {
                        onClose();
                        setSelectedTemplateData(templateData);
                        setTamplateAdd(false);
                      }}
                    >
                      <span>Select</span>
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};

export default AddTemplateModal;
