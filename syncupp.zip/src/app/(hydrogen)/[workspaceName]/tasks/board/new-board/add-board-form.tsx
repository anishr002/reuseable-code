'use client';

import { TemplateConfirmationModal } from '@/app/shared/(user)/board/template-confirmation';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import CustomFieldSetting from '@/app/shared/(user)/setting/custom-field-setting';
import { useModal } from '@/app/shared/modal-views/use-modal';
import TrashIcon from '@/components/icons/trash';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import Spinner from '@/components/ui/spinner';
import { Switch } from '@/components/ui/switch';
import '@/layouts/helium/style.css';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import { getSettingData } from '@/redux/slices/user/setting/settingSlice';
import {
  getAllAssignees,
  postAddBoard,
} from '@/redux/slices/user/task/boardSlice';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  displayRole,
  handleKeyDown,
} from '@/utils/common-functions';
import {
  createBoardFormTourStepsContent,
  getStepsByRole,
} from '@/utils/tour-steps/tour-steps';
import {
  AddBoardSchema,
  addBoardSchema,
} from '@/utils/validators/add-board.schema';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Fragment, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useDropzone } from 'react-dropzone';
import { SubmitHandler } from 'react-hook-form';
import { CiImageOn } from 'react-icons/ci';
import { FiPlus } from 'react-icons/fi';
import { PiXBold } from 'react-icons/pi';
import { RxCross2 } from 'react-icons/rx';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import { ActionIcon, Input, Textarea } from 'rizzui';
import SimpleBar from 'simplebar-react';
import AddMembers from './members-modal';
import { ChoosePicture } from './picture-model';
import { ChooseTemplate } from './template-modal';

export default function AddBoardForm({
  onClose,
  setUpdateddata,
  setSkeletonloader,
  setPalyload,
  sortValue,
  searchValue,
}: {
  onClose?: () => void;
  setUpdateddata?: any;
  setSkeletonloader?: any;
  setPalyload?: any;
  sortValue?: any;
  searchValue?: any;
}) {
  const dispatch = useDispatch();
  const router = useRouter();
  const { closeModal, openModal } = useModal();
  const imageref = useRef<any>();
  const inputRef = useRef<HTMLInputElement>(null);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const [showAddMemberModal, setshowAddMemberModal] = useState(false);
  const [showAddTemplateModal, setshowAddTemplateModal] = useState(false);

  const { addBoardStatus, assignees } = useSelector(
    (state: any) => state?.root?.board
  );
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { settingData } = useSelector((state: any) => state?.root?.setting);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isConfirmationTemplateModalOpen, setIsConfirmationTemplateModalOpen] =
    useState(false);

  const [selectedMembers, setSelectedMembers] = useState([]);
  const [selectedMembersError, setSelectedMembersError] = useState('');
  const [previewImage, setPreviewImage] = useState<any>('');
  const [showCustomFieldsModal, setShowCustomFieldsModal] = useState(false);

  const [customFields, setCustomFields] = useState([]);

  console.log('customFields.....', customFields);

  useEffect(() => {
    if (selectedMembers?.length > 0) {
      setSelectedMembersError('');
    }
  }, [selectedMembers]);

  // Api call for Tour status get
  useEffect(() => {
    // Tour comment
    dispatch(getAllTourStatus());
    dispatch(getSettingData());
  }, [dispatch]);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [createBoardFormTourSteps, setCreateBoardFormTourSteps] = useState([]);
  const [selectedTemplateData, setSelectedTemplateData] = useState<any>(null);
  const [isModalShow, setIsModalShow] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // Handle close tour
  const handleCloseTour = () => {
    dispatch(updateTourStatus({ board: { create_board_tour: true } })).then(
      (result: any) => {
        if (updateTourStatus.fulfilled.match(result)) {
          if (result?.payload?.success) {
            setIsTourOpen(false);
            // Tour comment
            dispatch(getAllTourStatus());
          }
        }
      }
    );
  };
  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.board &&
      !tourStatusData?.board?.create_board_tour
    ) {
      setCreateBoardFormTourSteps([]);
      setIsTourOpen(false);
      const createBoardFormTourStepContent = createBoardFormTourStepsContent(
        handleCloseTour,
        signIn,
        checkPermission
      );

      const updatedAddBoardCardTourSteps = getStepsByRole(
        createBoardFormTourStepContent
      );
      updatedAddBoardCardTourSteps?.length > 0 &&
        setCreateBoardFormTourSteps(updatedAddBoardCardTourSteps);
      updatedAddBoardCardTourSteps?.length > 0 && setIsTourOpen(true);
    }
  }, [tourStatusData, signIn?.permission]);

  // api call for get clients and team member
  useEffect(() => {
    dispatch(getAllAssignees());
  }, []);

  // client and team members options
  let clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          let team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return { ...team, name: team_name };
        })
      : [];

  console.log(clientTeamAllOptions, '34555');
  const displayName = (data: any) => {
    let displayName: string =
      data?.first_name?.charAt(0)?.toUpperCase() +
      data?.first_name?.slice(1) +
      ' ' +
      data?.last_name?.charAt(0)?.toUpperCase() +
      data?.last_name?.slice(1);
    return displayName;
  };

  const initialValues: AddBoardSchema = {
    project_name: '',
    description: '',
    board_image: '',
    members: selectedMembers ?? [],
  };

  const handleAddMemberClick = () => {
    openModal({
      view: (
        <AddMembers
          onClose={closeModal}
          selectedMembers={selectedMembers}
          setSelectedMembers={setSelectedMembers}
          formPage={true}
        />
      ),
      customSize: '600px',
    });
  };

  const handleSaveClick = () => {
    if (selectedMembers?.length === 0) {
      setSelectedMembersError('At least one Team member is required');
      return;
    }
  };

  const ChooseTemplatehandler = () => {
    setIsTemplateModalOpen(false);
    setshowAddTemplateModal(true);
    // openModal({
    //   view: (
    //     <>
    //       <ChooseTemplate
    //         setSelectedTemplateData={setSelectedTemplateData}
    //         selectedTemplateData={selectedTemplateData}
    //       />
    //     </>
    //   ),
    //   customSize: '900px',
    // });
  };

  const confirmationModalShow = () => {
    openModal({
      view: (
        <TemplateConfirmationModal
          title=""
          message="Do you want to skip this confirmation for future?"
          confirmText="Yes"
          cancelText="No"
          onConfirm={() => {
            closeModal();
            setIsModalShow(true);
            setIsModalOpen(true);
          }}
          onClose={() => {
            closeModal();
            setIsModalShow(false);
            setIsModalOpen(true);
          }}
        />
      ),
      customSize: '400px',
    });
  };

  const onSubmit: SubmitHandler<AddBoardSchema> = (data) => {
    console.log('Add Board Data.........', data);

    if (selectedMembers?.length === 0) {
      return;
    }

    if (
      !selectedTemplateData &&
      !isModalOpen &&
      !settingData?.is_future_decision_allowed
    ) {
      // openModal({
      //   view: (
      //     <TemplateConfirmationModal
      //       title="Template Confirmation"
      //       message="Are you sure you don't want to proceed with the template?"
      //       confirmText="Yes"
      //       cancelText="Choose Template"
      //       onConfirm={() => {
      //         closeModal();
      //         confirmationModalShow();
      //       }}
      //       onClose={ChooseTemplatehandler}
      //     />
      //   ),
      //   customSize: '400px',
      // });
      setIsTemplateModalOpen(true);
      return;
    }

    const formData: any = new FormData();

    // Append form data
    formData.append('project_name', data?.project_name);
    formData.append('description', data?.description);
    formData.append('members', JSON.stringify(selectedMembers));
    if (!settingData?.is_future_decision_allowed) {
      formData.append('is_future_decision_allowed', isModalShow);
    }

    if (selectedTemplateData) {
      formData.append('template_id', selectedTemplateData?._id);
    }

    // Append image file if available
    if (data?.board_image) {
      formData.append('board_image', data.board_image);
    }

    // Append if custom fields added
    if (customFields && customFields?.length > 0) {
      formData.append('custom_fields', JSON.stringify(customFields));
    }

    dispatch(postAddBoard(formData)).then((result: any) => {
      if (postAddBoard.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          // router.replace(routes.task(defaultWorkSpace?.name));
          if (onClose) {
            onClose(); // Safely invoke onClose only if it is defined
          }
          setUpdateddata([]);
          setSkeletonloader(true);
          setPalyload({
            skip: 0,
            limit: 20,
            all: false,
            sort: sortValue ?? '',
            search: searchValue ?? '',
          });
        }
      }
    });
  };

  // Write file upload logic
  const ChooseImagehandler = (setValue: any) => {
    openModal({
      view: (
        <>
          <ChoosePicture
            setPreviewImage={setPreviewImage}
            setValue={setValue}
          />
        </>
      ),
      customSize: '550px',
    });
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    const file = URL.createObjectURL(acceptedFiles[0]);
    // setValue("board_image", acceptedFiles[0])
    imageref.current('board_image', acceptedFiles[0], { shouldValidate: true });

    setPreviewImage(file);
  };

  // Function to trigger the click event on the hidden file input
  const handleAddPictureButtonClick = () => {
    const inputElement = inputRef.current;
    if (inputElement) {
      inputElement.click();
    }
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    useFsAccessApi: false,
    onDrop: handleDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png'],
    }, // Accept only JPEG and PNG images
    maxSize: 10 * 1024 * 1024, // Maximum file size of 10MB
    multiple: false,
    noClick: true,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
    useDropzone(dropzoneOptions);

  const handleClearMember = (userId: string) => {
    if (!selectedMembers) return;

    const updatedMembers = selectedMembers.filter((id) => id !== userId);
    setSelectedMembers(updatedMembers); // Update your state here
  };

  return (
    <div className="px-3 py-6">
      <div className="flex items-center justify-between ">
        <p className="max-w-[300px] overflow-hidden truncate whitespace-nowrap px-3  text-[24px] font-medium text-[#141414]">
          New Board
        </p>
        <ActionIcon
          size="sm"
          variant="text"
          onClick={onClose}
          className="me-4 p-0 text-[#141414] hover:!text-gray-900"
        >
          <PiXBold className="h-[19px] w-[50px] " />
        </ActionIcon>
      </div>
      <Form<AddBoardSchema>
        validationSchema={addBoardSchema}
        onSubmit={onSubmit}
        useFormProps={{
          defaultValues: initialValues,
          mode: 'onSubmit',
        }}
        className="mt-4 rounded-lg bg-white px-[15px] [&_label]:text-[14px] [&_label]:font-bold"
      >
        {({
          register,
          formState: { errors },
          setValue,
          getValues,
          setError,
        }) => {
          imageref.current = setValue;
          return (
            <div>
              {/* The Tour component */}
              <Tour
                steps={createBoardFormTourSteps ?? []}
                isOpen={isTourOpen}
                rounded={10}
                closeWithMask={false}
                disableInteraction={true}
                disableKeyboardNavigation={['esc']}
                onRequestClose={handleCloseTour}
                className="poppins_font_number tour-close-button font-semibold text-black"
                scrollDuration={50}
                scrollOffset={5}
              />
              <div className="mt-5 space-y-5">
                <div className="create-board-form-tour-step-three flex items-center gap-[24px]">
                  {/* <span
                    className="rizzui-input-label mb-4 block text-[14px]"
                    style={{ fontWeight: '700' }}
                  >
                    Cover Photo
                  </span> */}
                  {previewImage &&
                  previewImage != null &&
                  previewImage != '' ? (
                    <>
                      <div className="flex items-center justify-start">
                        {' '}
                        <Image
                          className="h-[80px] w-[80px] rounded-[8px] border border-gray-300 bg-transparent object-cover"
                          alt="logo"
                          src={previewImage}
                          width={80}
                          height={80}
                        />
                        <TrashIcon
                          className="ms-4 h-5 w-5 cursor-pointer"
                          onClick={() => {
                            setPreviewImage(null);
                            setValue('board_image', null);
                          }}
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div
                        className="flex cursor-pointer items-center justify-start"
                        onClick={handleAddPictureButtonClick}
                      >
                        <CiImageOn
                          width={80} // Desired width
                          height={80} // Desired height
                          className="h-[80px] w-[80px] rounded-[8px] border-2 border-dashed border-gray-300 bg-transparent object-cover"
                        />
                        {/* <Image
                          src={profile_img_icn} // Path to your image
                          alt="Description of image"
                          width={80} // Desired width
                          height={80} // Desired height
                          className="h-[80px] w-[80px] rounded-[8px] border-2 border-dashed border-gray-300 bg-transparent object-cover"
                        /> */}
                      </div>
                    </>
                  )}
                  <div className="flex flex-wrap">
                    <div {...getRootProps()}>
                      <input {...getInputProps()} ref={inputRef} />
                      <Button
                        type="button"
                        // rounded="pill"
                        className="h-[36px] rounded-[8px] border border-[#D4D4D4] bg-white px-4 py-2  text-sm text-[#141414] transition-shadow duration-200 hover:bg-gray-100"
                        onClick={handleAddPictureButtonClick}
                      >
                        Upload Cover image
                      </Button>
                    </div>
                    {/* <Button
                      type="button"
                      rounded="pill"
                      className="mt-2 flex h-12 w-44 items-center gap-2 border-2 border-[#8C80D2] bg-transparent text-sm text-[#8C80D2]"
                      onClick={() => {
                        ChooseImagehandler(setValue);
                      }}
                    >
                      <CiImageOn /> Choose Picture
                    </Button> */}
                  </div>
                </div>
                <p className="text-red">
                  {String(errors.board_image?.message || '')}
                </p>

                <div className="create-board-form-tour-step-one flex flex-col gap-4">
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    label="Board name *"
                    placeholder="Enter Board name"
                    // className="[&>label>span]:font-medium"
                    {...register('project_name')}
                    error={errors?.project_name?.message as string}
                    inputClassName="font-normal text-[14px]  text-[#141414] leading-[16.8px]"
                    labelClassName="font-normal text-[14px]  text-[#141414] leading-[16.8px]"
                  />
                  <Textarea
                    placeholder="Add Board description here..."
                    {...register('description')}
                    error={errors?.description?.message as string}
                    label="Description (Optional)"
                    textareaClassName="font-normal  text-[14px] text-[#141414] leading-[16.8px] bg-[#F9FAFB]"
                    labelClassName="font-normal  text-[14px] text-[#141414] leading-[16.8px]"
                  />
                </div>
                <div className="create-board-form-tour-step-two flex flex-col gap-1">
                  <div className="flex justify-between">
                    <span
                      className=" text-sm font-normal text-[#141414]"
                      // style={{ margin: '0px', fontWeight: '700' }}
                    >
                      Assign To *
                    </span>
                    <div
                      // onClick={handleAddMemberClick}
                      onClick={() => {
                        setshowAddMemberModal(true);
                      }}
                      className="cursor-pointer"
                    >
                      <div className="flex h-[30px] w-[30px] items-center justify-center rounded-[8px] border border-[#D4D4D4] text-[#141414]">
                        <FiPlus className="h-[15px] w-[15px]" />
                      </div>
                    </div>
                  </div>
                  <div
                    className={`${
                      selectedMembers?.length > 0
                        ? 'mt-3 rounded-lg border border-gray-300'
                        : ''
                    }`}
                  >
                    {clientTeamAllOptions &&
                      clientTeamAllOptions?.length > 0 && (
                        <SimpleBar
                          className={`${
                            selectedMembers?.length > 3
                              ? 'max-h-36 overflow-y-auto' // Adjust the height as needed for 3 items
                              : ''
                          } `}
                        >
                          {clientTeamAllOptions
                            ?.filter(
                              (item: Record<string, any>, index: number) => {
                                return (
                                  selectedMembers &&
                                  selectedMembers.length > 0 &&
                                  selectedMembers.includes(
                                    item?.user_id as never
                                  )
                                );
                              }
                            )
                            ?.map((item, index) => (
                              <Fragment key={item.user_name + '-' + index}>
                                <div className="relative my-0.5 flex h-12 items-center border-b border-gray-300 px-2 py-2 text-sm last:border-0 focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg">
                                  {/* Avatar and text container */}
                                  <div className="flex items-center space-x-3">
                                    <span className="inline-flex items-center justify-center p-2 text-gray-500">
                                      <Avatar
                                        src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                                        name={displayName(item)}
                                        className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white xl:!h-9 xl:!w-9"
                                      />
                                    </span>

                                    <span className="grid gap-0.5">
                                      <span className=" text-sm font-medium capitalize leading-[16.8px] text-[#111928]">
                                        {item.user_name}
                                      </span>
                                      <span className=" text-xs font-normal leading-[14.4px] text-[#4B5563]">
                                        {displayRole(
                                          item?.role,
                                          item?.sub_role
                                        )}
                                      </span>
                                    </span>
                                  </div>

                                  {/* Clear icon container */}
                                  <div className="absolute right-3">
                                    <button
                                      onClick={() =>
                                        handleClearMember(item?.user_id)
                                      }
                                      className="text-[#141414] hover:text-gray-600 focus:outline-none"
                                    >
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke="currentColor"
                                        className="h-5 w-5"
                                      >
                                        <path
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                          strokeWidth="2"
                                          d="M6 18L18 6M6 6l12 12"
                                        />
                                      </svg>
                                    </button>
                                  </div>
                                </div>
                              </Fragment>
                            ))}
                        </SimpleBar>
                      )}
                  </div>

                  <p className="pt-2 text-red">
                    {String(selectedMembersError || '')}
                  </p>
                </div>
                <div className="border border-[#D4D4D4]"></div>
                <div className="create-board-form-tour-step-four ">
                  {/* <span
                    className="rizzui-input-label mb-4 block text-[14px]"
                    style={{ fontWeight: '700' }}
                  >
                    Template
                  </span> */}

                  <div
                    className="flex h-[44px] w-full cursor-pointer flex-wrap items-center justify-between gap-6 rounded-lg border border-[#F9FAFB] bg-[#F9FAFB] pr-2"
                    // onClick={() => {
                    //   setshowAddTemplateModal(true);
                    // }}
                  >
                    <div>
                      <button
                        type="button"
                        className="ml-[10px]  text-[14px] font-medium leading-[16.8px] text-[#141414]"
                        // onClick={ChooseTemplatehandler}
                      >
                        {/* <CgFileDocument />  */}
                        Choose a Template
                      </button>
                    </div>
                    <Switch
                      className="create-task-form-tour-step-ten border-none shadow-none [&>label>span.transition]:shrink-0 [&>label>span]:font-medium"
                      variant="active"
                      switchClassName={`${
                        selectedTemplateData
                          ? '!bg-[#362F78] border-[#D1D5DB]'
                          : '!bg-white border-[#D1D5DB]'
                      }`}
                      handlerClassName={`${
                        selectedTemplateData
                          ? '!bg-white border-[#D1D5DB]'
                          : '!bg-[#362F78] border-[#D1D5DB]'
                      }`}
                      labelClassName="text-[#141414]"
                      labelPlacement="left"
                      checked={!!selectedTemplateData}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setshowAddTemplateModal(true);
                        } else {
                          setSelectedTemplateData(null);
                          setshowAddTemplateModal(false);
                        }
                      }}
                    />
                  </div>
                  {selectedTemplateData && (
                    <div className="mt-4 flex h-12 items-center gap-2 rounded-[8px] border border-[#EDEAFE] bg-[#EDEAFE] p-3">
                      <h3 className=" text-[14px] font-bold leading-[16.8px] text-[#362F78]">
                        {capitalizeFirstLetter(
                          selectedTemplateData?.template_name
                        )}
                      </h3>
                      <RxCross2
                        className="ml-auto h-5 w-5 cursor-pointer"
                        onClick={() => {
                          setSelectedTemplateData(null);
                          setshowAddTemplateModal(false); // Turn off switch when removing template
                        }}
                      />
                    </div>
                  )}
                </div>

                {/* Add Custom Field button */}
                <div className="border border-[#D4D4D4]" />
                <div className="flex flex-col items-start gap-2">
                  <div
                    className="text-sm font-normal text-[#141414]"
                    // style={{ margin: '0px', fontWeight: '700' }}
                  >
                    Custom Fields
                  </div>
                  <Button
                    className="flex w-auto gap-2 border border-[#5850EC] bg-transparent text-[#5850EC]"
                    type="button"
                    onClick={() => {
                      setShowCustomFieldsModal(true);
                    }}
                  >
                    <FiPlus className="size-4" />
                    <span>Add Custom Fields</span>
                  </Button>
                </div>
                {customFields && customFields?.length > 0 && (
                  <div className="flex w-full flex-wrap items-center justify-start gap-4">
                    {customFields?.map((field: any, index: number) => (
                      <button
                        key={index}
                        type="button"
                        className="flex h-12 items-center gap-3 rounded-[8px] border border-[#EDEAFE] bg-[#EDEAFE] p-3"
                        onClick={() => {
                          setShowCustomFieldsModal(true);
                        }}
                      >
                        <h3 className=" text-[14px] font-bold leading-[16.8px] text-[#362F78]">
                          {capitalizeFirstLetter(field?.fieldName)}
                        </h3>
                        <RxCross2
                          className="ml-auto h-5 w-5 cursor-pointer"
                          onClick={(e: any) => {
                            e.stopPropagation();
                            const updatedCustomFields = [...customFields];
                            updatedCustomFields?.splice(index, 1);
                            setCustomFields(updatedCustomFields ?? []);
                          }}
                        />
                      </button>
                    ))}
                  </div>
                )}
                <div
                  className={cn('flex items-center justify-end space-x-4 pt-5')}
                >
                  <Button
                    type="button"
                    className="h-[42px] w-auto rounded-[8px] border border-gray-300  text-sm text-[#141414]"
                    onClick={onClose}
                    // rounded="pill"
                    variant="outline"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className={`flex h-[42px] 
                    w-auto items-center justify-center rounded-[8px] bg-[#7667CF]  text-sm text-white`}
                    disabled={addBoardStatus === 'pending'}
                    // rounded="pill"
                    onClick={handleSaveClick}
                  >
                    Create Project{' '}
                    {addBoardStatus === 'pending' && (
                      <Spinner
                        size="sm"
                        tag="div"
                        className="ms-3"
                        color="white"
                      />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          );
        }}
      </Form>
      {showAddMemberModal && (
        <div>
          <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-hidden rounded-lg bg-white shadow-lg "
              style={{ width: '547px', height: '475px' }}
            >
              {showAddMemberModal && (
                <AddMembers
                  onClose={() => setshowAddMemberModal(false)}
                  selectedMembers={selectedMembers}
                  setSelectedMembers={setSelectedMembers}
                  formPage={true}
                />
              )}
            </div>
          </div>
        </div>
      )}
      {showAddTemplateModal && (
        <div>
          <div className="fixed left-0 top-0 z-10 flex min-h-[630px] w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-hidden rounded-lg bg-white shadow-lg "
              style={{ width: '900px', minHeight: '630px' }}
            >
              {showAddTemplateModal && (
                <ChooseTemplate
                  onClose={() => setshowAddTemplateModal(false)}
                  setSelectedTemplateData={setSelectedTemplateData}
                  selectedTemplateData={selectedTemplateData}
                />
              )}
            </div>
          </div>
        </div>
      )}
      {isTemplateModalOpen && (
        <div>
          <div className="fixed left-0 top-0 z-10 flex min-h-[630px] w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-hidden rounded-lg bg-white shadow-lg "
              style={{ width: 'auto' }}
            >
              <TemplateConfirmationModal
                title="Template Confirmation"
                message="Are you sure you don't want to proceed with the template?"
                confirmText="Yes"
                cancelText="Choose Template"
                onConfirm={() => {
                  setIsTemplateModalOpen(false);
                  setIsConfirmationTemplateModalOpen(true);
                }}
                onClose={ChooseTemplatehandler}
              />
            </div>
          </div>
        </div>
      )}
      {isConfirmationTemplateModalOpen && (
        <div>
          <div className="fixed left-0 top-0 z-10 flex min-h-[630px] w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-hidden rounded-lg bg-white shadow-lg "
              style={{ width: 'auto' }}
            >
              <TemplateConfirmationModal
                title=""
                message="Do you want to skip this confirmation for future?"
                confirmText="Yes"
                cancelText="No"
                onConfirm={() => {
                  setIsConfirmationTemplateModalOpen(false);
                  setIsModalShow(true);
                  setIsModalOpen(true);
                }}
                onClose={() => {
                  setIsConfirmationTemplateModalOpen(false);
                  setIsModalShow(false);
                  setIsModalOpen(true);
                }}
              />
            </div>
          </div>
        </div>
      )}
      {/* Custom fields modal */}
      {showCustomFieldsModal &&
        createPortal(
          <div className="fixed inset-0 z-[999] flex items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
            <div
              className="relative overflow-visible rounded-lg bg-white shadow-lg"
              style={{ width: '700px' }}
            >
              <CustomFieldSetting
                onClose={() => setShowCustomFieldsModal(false)}
                title="Custom Fields"
                customFields={customFields}
                setCustomFields={setCustomFields}
              />
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}
