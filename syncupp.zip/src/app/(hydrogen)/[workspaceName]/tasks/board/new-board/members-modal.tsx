'use client';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { ActionIcon } from '@/components/ui/action-icon';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import SimpleBar from '@/components/ui/simplebar';
import Spinner from '@/components/ui/spinner';
import { getAllMyTasks } from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  getMembersByBoardId,
  patchEditBoard,
} from '@/redux/slices/user/task/boardSlice';
import { patchEditTask } from '@/redux/slices/user/task/taskSlice';
import { Fragment, useEffect, useState } from 'react';
import { FaPlus } from 'react-icons/fa';
import { PiMagnifyingGlassBold, PiXBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import { Avatar, Input, Text } from 'rizzui';

export default function AddMembers({
  onClose,
  selectedMembers,
  setSelectedMembers,
  formPage,
  addTaskMember,
  taskId,
  updateTask,
  isView,
  isAddTaskForm = false,
  moduleName,
  isInlineCreating = false,
  onUpdateInlineTaskField,
}: {
  onClose: () => void;
  selectedMembers: any[];
  setSelectedMembers: any;
  formPage?: boolean;
  addTaskMember?: boolean;
  taskId?: string;
  isView?: any;
  updateTask?: (
    id: string,
    action: string,
    data: any,
    oldTasks: any,
    oldTasksSectionsData: any
  ) => void;
  isAddTaskForm?: boolean;
  moduleName?: string;
  isInlineCreating?: boolean;
  onUpdateInlineTaskField?: any;
}) {
  const dispatch = useDispatch();
  const { closeModal } = useModal();
  const [selectedModalMembers, setSelectedModalMembers] =
    useState(selectedMembers);
  const [selectedOption, setSelectedOption] = useState<any[]>([]);
  const [errorMessage, setErrorMessage] = useState('');
  const paginationParamsClient = useSelector(
    (state: any) => state?.root?.client?.paginationParams
  );
  const {
    gridView,
    paginationParams,
    oldTasks,
    oldTasksSections,
    loading: taskLoading,
  } = useSelector((state: any) => state?.root?.task);
  const {
    boardId,
    editBoardStatus,
    assignees,
    members,
    boardMembers,
    removeBoardMemberLoader,
    loading,
  } = useSelector((state: any) => state?.root?.board);
  const signIn = useSelector((state: any) => state?.root?.signIn);

  let clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          let team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return { label: team_name, value: team?.user_id, key: team };
        })
      : [];
  let boardMemberClientTeamAllOptions: Record<string, any>[] =
    members && members?.length > 0
      ? members?.map((team: Record<string, any>) => {
          let team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return { label: team_name, value: team?.id, key: team };
        })
      : [];
  const boardMemberClientTeamAllOptionsForAddTask: Record<string, any>[] =
    boardMembers && boardMembers?.length > 0
      ? boardMembers?.map((team: Record<string, any>) => {
          let team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return { label: team_name, value: team?.id, key: team };
        })
      : [];

  const [searchTerm, setSearchTerm] = useState('');
  const [selectAll, setSelectAll] = useState(false);

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value.toLowerCase());
  };
  console.log(addTaskMember, formPage, isAddTaskForm, 'taskLoading');
  const handleSelectAllChange = () => {
    const optionsToSelect = getOptionsToSelect();
    const allMemberIds = optionsToSelect.map((option) => option.value);

    const skippedMembers = optionsToSelect
      .filter((option) => {
        if (!(addTaskMember || formPage)) {
          return !(
            signIn?.user?.data?.user?._id !== option?.key?.user_id &&
            (signIn?.role === 'client'
              ? option?.key?.role.toLowerCase() !== 'agency'
              : true) &&
            (signIn?.role === 'client' && option?.key?.role === 'team_client'
              ? option?.key?.client_id === signIn?.user?.data?.user?._id
              : true) &&
            (signIn?.role === 'client' && option?.key?.role === 'client'
              ? false
              : true)
          );
        }
        return false; // If addTaskMember is true, do not skip any members
      })
      .map((option) => option?.value);

    if (!selectAll) {
      // Select all eligible members
      const filteredMemberIds = allMemberIds.filter(
        (id) => !skippedMembers.includes(id)
      );
      const newSelectedMembers = [
        ...selectedModalMembers,
        ...filteredMemberIds,
      ];
      setSelectedModalMembers(newSelectedMembers);
      setSelectedOption(
        optionsToSelect.filter((option) =>
          newSelectedMembers.includes(option.value)
        )
      );
    } else {
      // Deselect all eligible members
      const filteredMemberIds = allMemberIds.filter(
        (id) => !skippedMembers.includes(id)
      );
      const newSelectedMembers = selectedModalMembers.filter(
        (id) => !filteredMemberIds.includes(id)
      );
      setSelectedModalMembers(newSelectedMembers);
      setSelectedOption(
        optionsToSelect.filter((option) =>
          newSelectedMembers.includes(option.value)
        )
      );
    }

    setSelectAll(!selectAll);
  };

  useEffect(() => {
    const optionsToSelect = getOptionsToSelect();
    setSelectAll(
      optionsToSelect.length > 0 &&
        optionsToSelect.every((option) =>
          selectedModalMembers.includes(option.value)
        )
    );
  }, [selectedModalMembers]);
  const handleCheckboxChange = (value: any) => {
    if (selectedModalMembers.includes(value)) {
      setSelectedModalMembers(
        selectedModalMembers.filter((id) => id !== value)
      );
    } else {
      setSelectedModalMembers([...selectedModalMembers, value]);
    }

    // Check if all checkboxes are selected
    const optionsToSelect = getOptionsToSelect();
    if (
      optionsToSelect.every((option) =>
        selectedModalMembers.includes(option.value)
      )
    ) {
      setSelectAll(true);
    } else {
      setSelectAll(false);
    }
  };

  const displayName = (data: any) => {
    let displayName: string =
      data?.first_name?.charAt(0)?.toUpperCase() +
      data?.first_name?.slice(1) +
      ' ' +
      data?.last_name?.charAt(0)?.toUpperCase() +
      data?.last_name?.slice(1);
    return displayName;
  };

  const getOptionsToSelect = () => {
    if (addTaskMember) {
      return !isAddTaskForm
        ? boardMemberClientTeamAllOptions
        : boardMemberClientTeamAllOptionsForAddTask;
    } else {
      return clientTeamAllOptions;
    }
  };

  const handleAddMemberClick = () => {
    if (!selectedModalMembers || selectedModalMembers.length === 0) {
      setErrorMessage('Please select at least one member.');
      return;
    }
    setErrorMessage('');
    let updatedMemberArray = [...selectedModalMembers];
    if (formPage) {
      setSelectedModalMembers(updatedMemberArray);
      setSelectedMembers([...updatedMemberArray]);

      setSelectedOption([]);

      onClose();

      // if(addTaskMember) {
      //     onClose();
      // }
    } else {
      // if i added task members
      if (addTaskMember) {
        // if inline task create
        if (isInlineCreating && typeof onUpdateInlineTaskField === 'function') {
          const assigneeData = (assignees ?? []).filter((assignee: any) =>
            selectedModalMembers.includes(assignee?._id)
          );

          onUpdateInlineTaskField(taskId, 'assign_to', assigneeData ?? []);
          onClose();
          setSelectedOption([]);
          return;
        }

        // api call for direct add assignee
        const formData: any = new FormData();
        formData.append('_id', taskId);
        formData.append('assign_to', JSON.stringify(updatedMemberArray));
        formData.append('action_name', 'date_assignee_update');

        dispatch(patchEditTask(formData)).then((result: any) => {
          if (patchEditTask.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              // setSelectedMembers([...updatedMemberArray]) // comment out when direct edit in task view
              let customizedAssignees: Record<string, any>[] =
                getOptionsToSelect()
                  .filter((option) => updatedMemberArray.includes(option.value))
                  .map((team: Record<string, any>) => {
                    return { ...team?.key, _id: team?.key?.id };
                  });

              setSelectedModalMembers(updatedMemberArray);
              // put grid view logic here
              !gridView
                ? moduleName === 'my-tasks'
                  ? dispatch(getAllMyTasks({ ...paginationParamsClient }))
                  : null
                : updateTask &&
                  taskId &&
                  updateTask(
                    taskId,
                    'assignee_update',
                    customizedAssignees,
                    oldTasks,
                    oldTasksSections
                  );
              onClose();
              setSelectedOption([]);
            }
          }
        });
      } else {
        const formData: any = new FormData();
        formData.append('members', JSON.stringify(updatedMemberArray));
        formData.append('only_member_update', 'true');
        formData.append('_id', boardId);

        dispatch(patchEditBoard(formData)).then((result: any) => {
          if (patchEditBoard.fulfilled.match(result)) {
            if (result && result.payload.success === true) {
              setSelectedMembers([...updatedMemberArray]);
              setSelectedModalMembers(updatedMemberArray);
              setSelectedOption([]);
              dispatch(getMembersByBoardId({ boardId: boardId }));
              onClose();
            }
          }
        });
      }
    }
  };
  const filteredOptions = getOptionsToSelect().filter((option) =>
    option.label.toLowerCase().includes(searchTerm)
  );
  return (
    <>
      {loading && addTaskMember ? (
        <div className="flex items-center justify-center p-10">
          <Spinner size="xl" tag="div" />
        </div>
      ) : (
        <div className="p-5">
          <div className="flex items-center justify-between">
            <Text className="text-[20px] font-bold leading-6 text-[#141414]">
              Add Member
            </Text>
            <ActionIcon
              size="sm"
              variant="text"
              onClick={onClose}
              className="me-4 p-0 text-[#141414] hover:!text-gray-900"
            >
              <PiXBold className="h-[20px] w-[20px]" />
            </ActionIcon>
          </div>

          <div className="mt-4 flex flex-col gap-4">
            <div className="flex flex-col items-start justify-between sm:flex-row sm:items-center">
              <Input
                type="text"
                placeholder="Search members"
                value={searchTerm}
                onChange={handleSearchChange}
                inputClassName="bg-[#F9FAFB]"
                className="h-10 w-full text-black md:w-[80%]"
                prefix={<PiMagnifyingGlassBold className="h-4 w-4" />}
              />
              {(['agency', 'client'].includes(signIn?.role) ||
                (['team_agency', 'team_client'].includes(signIn.role)
                  ? checkPermission(
                      'projects',
                      'boards',
                      'update',
                      signIn?.permission
                    )
                  : false)) &&
                !isView && (
                  <label className="mt-2 flex w-full items-center justify-end text-[#000000] sm:ml-4 sm:mt-0 md:w-[20%]">
                    <Checkbox
                      inputClassName="checkbox-color cursor-pointer!"
                      checked={selectAll}
                      onChange={handleSelectAllChange}
                      className="mr-2 cursor-pointer"
                    />
                    Select all
                  </label>
                )}
            </div>
            {selectedModalMembers.length > 0 && (
              <div className="flex items-center justify-between">
                <p className="montserrat_font_title  text-[16px] font-semibold text-black">
                  {selectAll
                    ? `All members selected`
                    : `${selectedModalMembers.length} selected`}
                </p>
                {(['agency', 'client'].includes(signIn?.role) ||
                  (['team_agency', 'team_client'].includes(signIn.role)
                    ? checkPermission(
                        'projects',
                        'boards',
                        'update',
                        signIn?.permission
                      )
                    : false)) &&
                  !isView && (
                    <Button
                      disabled={
                        selectedModalMembers.length === 0 ||
                        loading ||
                        taskLoading
                      }
                      onClick={handleAddMemberClick}
                      className="rounded-pill bg-[#8C80D2] px-4 py-2 text-white"
                    >
                      <FaPlus className="me-2 h-3 w-3" /> Add selected{' '}
                      {(loading || taskLoading) && (
                        <Spinner
                          size="sm"
                          tag="div"
                          className="ms-3"
                          color="white"
                        />
                      )}
                    </Button>
                  )}
              </div>
            )}
            <SimpleBar className="mt-0 max-h-[300px] overflow-y-auto">
              <div className="flex flex-col">
                {filteredOptions.map((item: any, index) => (
                  <Fragment key={item?.key?.user_name + '-' + index}>
                    <div className="relative mt-2 flex items-center gap-2 rounded-lg px-3 py-0 text-sm focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg">
                      <Checkbox
                        inputClassName="checkbox-color cursor-pointer"
                        checked={selectedModalMembers.includes(item.value)}
                        onChange={() => handleCheckboxChange(item.value)}
                        className="mr-2 cursor-pointer"
                        size="DEFAULT"
                        disabled={
                          isView ||
                          (!(addTaskMember || formPage) &&
                            !(
                              signIn?.user?.data?.user?._id !==
                                item?.key?.user_id &&
                              (signIn?.role === 'client'
                                ? item?.key?.role.toLowerCase() !== 'agency'
                                : true) &&
                              (signIn?.role === 'client' &&
                              item?.key?.role === 'team_client'
                                ? item?.key?.client_id ===
                                  signIn?.user?.data?.user?._id
                                : true) &&
                              (signIn?.role === 'client' &&
                              item?.key?.role === 'client'
                                ? false
                                : true)
                            ))
                        }
                      />

                      <span className="inline-flex items-center justify-center p-2 text-gray-500">
                        <Avatar
                          src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.key?.profile_image}`}
                          name={displayName(item?.key)}
                          className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white"
                        />
                      </span>
                      <span className="grid gap-0.5">
                        <span className="text-[16px] font-medium capitalize text-[#000000] dark:text-gray-700">
                          {item?.label}
                        </span>
                      </span>
                    </div>
                  </Fragment>
                ))}
              </div>
            </SimpleBar>
          </div>
        </div>
      )}
    </>
  );
}
