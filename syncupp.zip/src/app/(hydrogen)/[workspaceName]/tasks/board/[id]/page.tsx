import TaskPage from '@/app/shared/(user)/tasks';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Tasks'),
};

export default function Page({ params }: { params: { id: string } }) {
  return <TaskPage params={params} />;
}
