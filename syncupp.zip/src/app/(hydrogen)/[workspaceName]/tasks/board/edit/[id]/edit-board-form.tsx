'use client';

import { useModal } from '@/app/shared/modal-views/use-modal';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import Spinner from '@/components/ui/spinner';
import {
  getAllAssignees,
  getBoardById,
  patchEditBoard,
  RemoveSingleBoardData,
} from '@/redux/slices/user/task/boardSlice';
import cn from '@/utils/class-names';
import {
  capitalizeFirstLetter,
  displayRole,
  handleKeyDown,
} from '@/utils/common-functions';
import {
  AddBoardSchema,
  addBoardSchema,
} from '@/utils/validators/add-board.schema';
import { useRouter } from 'next/navigation';
import { Fragment, useEffect, useRef, useState } from 'react';
import { SubmitHandler } from 'react-hook-form';
import { FiPlus } from 'react-icons/fi';
import { useDispatch, useSelector } from 'react-redux';
import { ActionIcon, Input, Textarea } from 'rizzui';
// import Uploadfile from '@/app/(hydrogen)/tasks/board/new-board/Uploadfile';
// import AddMembers from '@/app/(hydrogen)/tasks/board/new-board/members-modal';
import CustomFieldSetting from '@/app/shared/(user)/setting/custom-field-setting';
import TrashIcon from '@/components/icons/trash';
import '@/layouts/helium/style.css';
import { createPortal } from 'react-dom';
import { useDropzone } from 'react-dropzone';
import { CiImageOn } from 'react-icons/ci';
import { PiXBold } from 'react-icons/pi';
import { RxCross2 } from 'react-icons/rx';
import SimpleBar from 'simplebar-react';
import AddMembers from '../../new-board/members-modal';
import { ChoosePicture } from '../../new-board/picture-model';

export default function EditBoardForm({
  onClose,
  params,
  setUpdateddata,
  setSkeletonloader,
  setPalyload,
  sortValue,
  searchValue,
}: {
  params: { id: string };
  onClose: () => void;
  setUpdateddata?: any;
  setSkeletonloader?: any;
  setPalyload?: any;
  sortValue?: any;
  searchValue?: any;
}) {
  const dispatch = useDispatch();
  const { closeModal, openModal } = useModal();
  const router = useRouter();
  const imageref = useRef<any>();
  const inputRef = useRef<HTMLInputElement>(null);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { board, editBoardStatus, getBoardStatus, assignees, loading } =
    useSelector((state: any) => state?.root?.board);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const [showAddMemberModal, setshowAddMemberModal] = useState(false);

  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [selectedMembersError, setSelectedMembersError] = useState('');
  const [previewImage, setPreviewImage] = useState<any>('');

  const [showCustomFieldsModal, setShowCustomFieldsModal] = useState(false);
  const [customFields, setCustomFields] = useState([]);
  console.log('customFields.....', customFields);
  console.log('board.....', board);

  // console.log("previewImage....", previewImage)

  // console.log("selectedMembers.....", selectedMembers)
  // console.log("Object.keys(board)?.length.....", Object.keys(board)?.length)
  // console.log("board.....", board, getBoardStatus, board && Object.keys(board)?.length > 0)

  // Api call for get board by id

  useEffect(() => {
    // Dispatch to remove previous single board data
    setSelectedMembers([]);
    setPreviewImage('');
    dispatch(RemoveSingleBoardData());

    if (params?.id) {
      dispatch(getBoardById({ boardId: params?.id }));
    }
  }, [params?.id, dispatch]);

  useEffect(() => {
    if (board) {
      // Populate members and image from fetched board data
      const members =
        board?.members?.map((member: any) => member?.member_id) || [];
      setSelectedMembers(members);

      const boardImage = board?.board_image
        ? `${process.env.NEXT_PUBLIC_IMAGE_URL}/${board?.board_image}`
        : '';
      setPreviewImage(boardImage);
    }
  }, [board]);

  // custom fields set if has
  useEffect(() => {
    if (board?.custom_fields && board?.custom_fields?.length > 0) {
      setCustomFields(board?.custom_fields ?? []);
    }
  }, [board]);

  useEffect(() => {
    if (selectedMembers?.length > 0) {
      setSelectedMembersError('');
    }
  }, [selectedMembers]);

  // api call for get clients and team member

  useEffect(() => {
    dispatch(getAllAssignees());
  }, []);

  // client and team members options

  const clientTeamAllOptions: Record<string, any>[] =
    assignees && assignees?.length > 0
      ? assignees?.map((team: Record<string, any>) => {
          const team_name =
            team?.first_name.charAt(0).toUpperCase() +
            team?.first_name.slice(1) +
            ' ' +
            team?.last_name.charAt(0).toUpperCase() +
            team?.last_name.slice(1);
          return { ...team, name: team_name };
        })
      : [];

  const displayName = (data: any) => {
    const displayName: string =
      data?.first_name?.charAt(0)?.toUpperCase() +
      data?.first_name?.slice(1) +
      ' ' +
      data?.last_name?.charAt(0)?.toUpperCase() +
      data?.last_name?.slice(1);
    return displayName;
  };

  const initialValues: AddBoardSchema = {
    project_name:
      board?.project_name?.charAt(0)?.toUpperCase() +
      board?.project_name?.slice(1),
    description: board?.description ?? '',
    board_image: board?.board_image ?? '',
    members: [],
  };

  const handleAddMemberClick = () => {
    openModal({
      view: (
        <AddMembers
          onClose={closeModal}
          selectedMembers={selectedMembers}
          setSelectedMembers={setSelectedMembers}
          formPage={true}
        />
      ),
      customSize: '600px',
    });
  };

  const handleSaveClick = () => {
    if (selectedMembers?.length === 0) {
      setSelectedMembersError('At least one Team member is required');
      return;
    }
  };

  const onSubmit: SubmitHandler<AddBoardSchema> = (data) => {
    console.log('Add Board Data.........', data);

    if (selectedMembers?.length === 0) {
      return;
    }

    const formData: any = new FormData();

    // Append form data
    formData.append('_id', params?.id);
    formData.append('project_name', data?.project_name);
    formData.append('description', data?.description);
    formData.append('members', JSON.stringify(selectedMembers));
    formData.append('only_member_update', 'false');

    // Append image file if available
    if (data?.board_image) {
      formData.append('board_image', data.board_image || '');
    }

    // Append if custom fields added
    if (customFields && customFields?.length > 0) {
      formData.append('custom_fields', JSON.stringify(customFields));
    }

    dispatch(patchEditBoard(formData)).then((result: any) => {
      if (patchEditBoard.fulfilled.match(result)) {
        if (result && result.payload.success === true) {
          // router.replace(routes.task(defaultWorkSpace?.name));
          if (onClose) {
            onClose(); // Safely invoke onClose only if it is defined
          }
          setUpdateddata([]);
          setSkeletonloader(true);
          setPalyload({
            skip: 0,
            limit: 20,
            all: false,
            sort: sortValue ?? '',
            search: searchValue ?? '',
          });
        }
      }
    });
  };

  // Write file upload logic
  const ChooseImagehandler = (setValue: any) => {
    openModal({
      view: (
        <>
          <ChoosePicture
            setPreviewImage={setPreviewImage}
            setValue={setValue}
          />
        </>
      ),
      customSize: '550px',
    });
  };

  // Function to trigger the click event on the hidden file input
  const handleAddPictureButtonClick = () => {
    const inputElement = inputRef.current;
    if (inputElement) {
      inputElement.click();
    }
  };

  // selected file Handler
  const handleDrop = (acceptedFiles: any) => {
    const file = URL.createObjectURL(acceptedFiles[0]);
    // setValue("board_image", acceptedFiles[0])
    imageref.current('board_image', acceptedFiles[0], { shouldValidate: true });

    setPreviewImage(file);
  };

  const handleClearMember = (userId: string) => {
    if (!selectedMembers) return;

    const updatedMembers = selectedMembers.filter((id) => id !== userId);
    setSelectedMembers(updatedMembers); // Update your state here
  };

  // Dropzone Options
  const dropzoneOptions: any = {
    onDrop: handleDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png'],
    }, // Accept only JPEG and PNG images
    maxSize: 10 * 1024 * 1024, // Maximum file size of 10MB
    multiple: false,
    noClick: true,
  };

  // useDropzone hook to handle file selection and drop
  const { getRootProps, getInputProps, isDragActive, isDragReject, open } =
    useDropzone(dropzoneOptions);

  if (
    getBoardStatus === 'pending' &&
    board &&
    Object.keys(board)?.length === 0
  ) {
    return (
      <div className="flex items-center justify-center p-10">
        <Spinner size="xl" tag="div" />
      </div>
    );
  } else {
    return (
      <div className="px-3 py-6">
        <div className="flex items-center justify-between ">
          <p className="max-w-[300px] overflow-hidden truncate whitespace-nowrap px-3  text-[24px] font-medium text-[#141414]">
            Edit Board
          </p>
          <ActionIcon
            size="sm"
            variant="text"
            onClick={onClose}
            className="me-4 p-0 text-[#141414] hover:!text-gray-900"
          >
            <PiXBold className="h-[19px] w-[50px] " />
          </ActionIcon>
        </div>
        <Form<AddBoardSchema>
          validationSchema={addBoardSchema}
          onSubmit={onSubmit}
          useFormProps={{
            defaultValues: initialValues,
            mode: 'all',
          }}
          className=" mt-4 rounded-lg bg-white px-[15px] [&_label]:text-[14px] [&_label]:font-bold"
        >
          {({
            register,
            formState: { errors },
            setValue,
            getValues,
            setError,
          }) => (
            (imageref.current = setValue),
            (
              <div className="mt-5 space-y-5">
                <div className="flex items-center gap-[24px]">
                  {/* <span
                    className="rizzui-input-label mb-4 block text-[14px]"
                    style={{ fontWeight: '700' }}
                  >
                    Cover Photo
                  </span> */}
                  {previewImage &&
                  previewImage != null &&
                  previewImage != '' ? (
                    <>
                      <div className="flex items-center justify-start">
                        {' '}
                        <img
                          className="h-[80px] w-[80px] rounded-[8px] border border-gray-300 bg-transparent object-cover"
                          alt="logo"
                          src={previewImage}
                        />
                        <TrashIcon
                          className="ms-4 h-5 w-5 cursor-pointer"
                          onClick={() => {
                            setPreviewImage(null);
                            setValue('board_image', null);
                          }}
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div
                        className="flex cursor-pointer items-center justify-start"
                        onClick={handleAddPictureButtonClick}
                      >
                        <CiImageOn
                          width={80} // Desired width
                          height={80} // Desired height
                          className="h-[80px] w-[80px] rounded-[8px] border-2 border-dashed border-gray-300 bg-transparent object-cover"
                        />
                      </div>
                    </>
                  )}
                  <div className="flex flex-wrap">
                    <div {...getRootProps()}>
                      <input {...getInputProps()} ref={inputRef} />
                      <Button
                        type="button"
                        // rounded="pill"
                        className="h-[36px] rounded-[8px] border border-[#D4D4D4] bg-white px-4 py-2  text-sm text-[#141414] transition-shadow duration-200 hover:bg-gray-100"
                        onClick={handleAddPictureButtonClick}
                      >
                        Upload Cover image
                      </Button>
                    </div>
                    {/* <Button
                      type="button"
                      rounded="pill"
                      className="mt-2 flex h-12 w-44 items-center gap-2 border-2 border-[#8C80D2] bg-transparent text-sm text-[#8C80D2]"
                      onClick={() => {
                        ChooseImagehandler(setValue);
                      }}
                    >
                      <CiImageOn /> Choose Picture
                    </Button> */}
                  </div>
                </div>
                <p className="text-red">
                  {String(errors.board_image?.message || '')}
                </p>
                <div className="flex flex-col gap-4">
                  <Input
                    type="text"
                    onKeyDown={handleKeyDown}
                    label="Board name *"
                    placeholder="Enter Board name"
                    // className="[&>label>span]:font-medium"
                    {...register('project_name')}
                    error={errors?.project_name?.message as string}
                    inputClassName="font-normal  text-[14px] text-[#141414] leading-[16.8px]"
                    labelClassName="font-normal  text-[14px] text-[#141414] leading-[16.8px]"
                  />
                  <Textarea
                    placeholder="Add Board description here..."
                    {...register('description')}
                    error={errors?.description?.message as string}
                    label="Description (Optional)"
                    textareaClassName="font-normal  text-[14px] text-[#141414] leading-[16.8px] bg-[#F9FAFB]"
                    labelClassName="font-normal  text-[14px] text-[#141414] leading-[16.8px]"
                    // textareaClassName="h-20"
                    // className="col-span-2"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <div className="flex justify-between">
                    <span className=" text-sm font-normal  text-[#141414]">
                      Assign To *
                    </span>
                    <div
                      // onClick={handleAddMemberClick}
                      onClick={() => {
                        setshowAddMemberModal(true);
                      }}
                      className="cursor-pointer"
                    >
                      <div className="flex h-[30px] w-[30px] items-center justify-center rounded-[8px] border border-[#D4D4D4] text-[#141414]">
                        <FiPlus className="h-[15px] w-[15px]" />
                      </div>
                    </div>
                  </div>
                  <div
                    className={`${
                      selectedMembers?.length > 0
                        ? 'mt-3 rounded-lg border border-gray-300'
                        : ''
                    }`}
                  >
                    {clientTeamAllOptions &&
                      clientTeamAllOptions?.length > 0 && (
                        <SimpleBar
                          className={`${
                            selectedMembers?.length > 3
                              ? 'max-h-36 overflow-y-auto' // Adjust the height as needed for 3 items
                              : ''
                          } `}
                        >
                          {clientTeamAllOptions
                            ?.filter((item) => {
                              return (
                                selectedMembers &&
                                selectedMembers.length > 0 &&
                                selectedMembers.includes(item?.user_id as any)
                              );
                            })
                            ?.map((item, index) => (
                              <Fragment key={item.user_name + '-' + index}>
                                <div className="relative my-0.5 flex h-12 items-center border-b border-gray-300 px-2 py-2 text-sm last:border-0 focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg">
                                  <div className="flex items-center space-x-3">
                                    <span className="inline-flex items-center justify-center p-2 text-gray-500">
                                      <Avatar
                                        src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/uploads/${item?.profile_image}`}
                                        name={displayName(item)}
                                        className="!h-8 !w-8 bg-[#70C5E0] font-medium text-white xl:!h-9 xl:!w-9"
                                      />
                                    </span>

                                    <span className="grid gap-0.5">
                                      <span className=" text-sm font-medium capitalize leading-[16.8px] text-[#111928]">
                                        {item.user_name}
                                      </span>
                                      <span className=" text-xs font-normal leading-[14.4px] text-[#4B5563]">
                                        {displayRole(
                                          item?.role,
                                          item?.sub_role
                                        )}
                                      </span>
                                    </span>
                                  </div>
                                  <div className="absolute right-3">
                                    <button
                                      onClick={() =>
                                        handleClearMember(item?.user_id)
                                      }
                                      className="text-[#141414] hover:text-gray-600 focus:outline-none"
                                    >
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke="currentColor"
                                        className="h-5 w-5"
                                      >
                                        <path
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                          strokeWidth="2"
                                          d="M6 18L18 6M6 6l12 12"
                                        />
                                      </svg>
                                    </button>
                                  </div>
                                </div>
                              </Fragment>
                            ))}
                        </SimpleBar>
                      )}
                  </div>
                  <p className="pt-2 font-medium text-red-400">
                    {String(selectedMembersError || '')}
                  </p>
                </div>
                {/* <div>
                            <span
                                className="rizzui-input-label mb-1.5 block text-sm"
                                style={{ margin: '0px', fontWeight: '500' }}
                            >
                                Cover Photo
                            </span>
                            <Uploadfile
                                initialPath={board?.board_image ?? false}
                                name="board_image"
                                readonly={false}
                                user={true}
                                setFieldValue={setValue}
                                errors={setError}
                                compontes={false}
                            />
                            <p className='pt-2 font-medium text-red-400' >
                                {String(errors.board_image?.message || '')}
                            </p>
                        </div> */}

                {/* Add Custom Field button */}
                <div className="border border-[#D4D4D4]" />
                <div className="flex flex-col items-start gap-2">
                  <div
                    className="text-sm font-normal text-[#141414]"
                    // style={{ margin: '0px', fontWeight: '700' }}
                  >
                    Custom Fields
                  </div>
                  <Button
                    className="flex w-auto gap-2 border border-[#5850EC] bg-transparent text-[#5850EC]"
                    type="button"
                    onClick={() => {
                      setShowCustomFieldsModal(true);
                    }}
                  >
                    <FiPlus className="size-4" />
                    <span>Add Custom Fields</span>
                  </Button>
                </div>
                {customFields && customFields?.length > 0 && (
                  <div className='w-full flex flex-wrap items-center justify-start gap-4'>
                    {customFields?.map((field: any, index: number) => (
                      <button
                        key={index}
                        type="button"
                        className="flex h-12 items-center gap-3 rounded-[8px] border border-[#EDEAFE] bg-[#EDEAFE] p-3"
                        onClick={() => {
                          setShowCustomFieldsModal(true);
                        }}
                      >
                        <h3 className=" text-[14px] font-bold leading-[16.8px] text-[#362F78]">
                          {capitalizeFirstLetter(field?.fieldName)}
                        </h3>
                        <RxCross2
                          className="ml-auto h-5 w-5 cursor-pointer"
                          onClick={(e: any) => {
                            e.stopPropagation();
                            const updatedCustomFields = [...customFields];
                            updatedCustomFields?.splice(index, 1);
                            setCustomFields(updatedCustomFields ?? []);
                          }}
                        />
                      </button>
                    ))}
                  </div>
                )}

                <div
                  className={cn('flex items-center justify-end space-x-4 pt-5')}
                >
                  <Button
                    type="button"
                    className="h-[42px] w-auto rounded-[8px] border border-gray-300  text-sm text-[#141414]"
                    onClick={onClose}
                    // rounded="pill"
                    variant="outline"
                  >
                    Cancel
                  </Button>{' '}
                  <Button
                    type="submit"
                    className={`flex
                      h-[42px]
                    w-auto items-center justify-center rounded-[8px] bg-[#7667CF]  text-sm text-white`}
                    // className="h-12 w-44 bg-[#8C80D2] text-sm text-white"
                    disabled={editBoardStatus === 'pending'}
                    // rounded="pill"
                    onClick={handleSaveClick}
                  >
                    Update Project
                    {editBoardStatus === 'pending' && (
                      <Spinner
                        size="sm"
                        tag="div"
                        className="ms-3"
                        color="white"
                      />
                    )}
                  </Button>
                </div>
              </div>
            )
          )}
        </Form>
        {showAddMemberModal && (
          <div>
            <div className="fixed left-0 top-0 z-10 flex h-full w-full items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
              <div
                className="relative overflow-hidden rounded-lg bg-white shadow-lg "
                style={{ width: '547px', height: '475px' }}
              >
                {showAddMemberModal && (
                  <AddMembers
                    onClose={() => setshowAddMemberModal(false)}
                    selectedMembers={selectedMembers}
                    setSelectedMembers={setSelectedMembers}
                    formPage={true}
                  />
                )}
              </div>
            </div>
          </div>
        )}
        {/* Custom fields modal */}
        {showCustomFieldsModal &&
          createPortal(
            <div className="demo_test fixed inset-0 flex items-center justify-center overflow-auto backdrop-blur-sm backdrop-filter">
              <div
                className="relative overflow-visible rounded-lg bg-white shadow-lg"
                style={{ width: '700px' }}
              >
                <CustomFieldSetting
                  onClose={() => setShowCustomFieldsModal(false)}
                  title="Custom Fields"
                  customFields={customFields}
                  setCustomFields={setCustomFields}
                />
              </div>
            </div>,
            document.body
          )}
      </div>
    );
  }
}
