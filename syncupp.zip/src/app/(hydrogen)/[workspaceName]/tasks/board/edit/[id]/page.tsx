"use client";
// import Link from 'next/link';
import withRoleAuth from '@/AuthGuard/withRoleAuth';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { roles } from '@/config/roles';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';
import EditBoardForm from './edit-board-form';


const pageHeader = {
    title: 'Edit Board',
  };
  
  function Page({ params }: { params: { id: string } }) {
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace)

  
    return (
      <>
        {/* <PageHeader title={pageHeader.title}>
        <div className="mt-4 flex items-center gap-3 @lg:mt-0">
          <Link href={routes?.task}>
            <Button className="mt-5 w-full bg-none text-xs @lg:w-auto sm:text-sm lg:mt-0">
              <FaArrowLeft className="me-1.5 h-[17px] w-[17px]" />
              Back
            </Button>
          </Link>
        </div>
        </PageHeader> */}
        <CustomePageHeader title={pageHeader.title} route={routes.task(defaultWorkSpace?.name)} titleClassName='montserrat_font_title' />
        {/* <EditBoardForm params={params} /> */}
      </>
    );
  }
  
  export default withRoleAuth([roles.agency, roles.teamAgency.team_agency, roles.teamClient], 'projects', 'boards', 'update')(Page); 
  