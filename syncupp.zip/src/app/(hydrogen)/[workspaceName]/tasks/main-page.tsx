'use client';
import { ConfirmationBoardDeleteModal } from '@/app/shared/(user)/board/delete-board-confirmation';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import { useModal } from '@/app/shared/modal-views/use-modal';
// import Link from 'next/link';
import CardSkeleton from '@/components/loader/card-skeleton';
import Select from '@/components/ui/select';
import { routes } from '@/config/routes';
import { useDebouncedValue } from '@/hooks/use-debounce';
import '@/layouts/helium/style.css';
import {
  getAllTourStatus,
  updateTourStatus,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  RemoveBoardData,
  RemoveBoardListData,
  getAllBoard,
  postArchiveBoard,
  putBoardPinStatusChange,
  setSearchTerm,
  setSelectedBoardSortName,
  setSelectedBoardSortValue,
  updateBoardOrder,
} from '@/redux/slices/user/task/boardSlice';
import { RemoveGetAllTasksData } from '@/redux/slices/user/task/taskSlice';
import cn from '@/utils/class-names';
import { handleKeyDown } from '@/utils/common-functions';
import {
  addBoardCardTourStepsContent,
  boardListTourStepsContent,
  getStepsByRole,
} from '@/utils/tour-steps/tour-steps';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import { arrayMove, useSortable } from '@dnd-kit/sortable';
import arrowright from '@public/assets/images/arrowright.png';
import syncUppLogo from '@public/assets/images/logo_icon.png';
import Pinned from '@public/assets/images/pinned.png';
import debounce from 'lodash/debounce';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useRef, useState } from 'react';
import { BsPinAngleFill } from 'react-icons/bs';
import { FiCopy, FiPlus } from 'react-icons/fi';
import { PiMagnifyingGlassBold } from 'react-icons/pi';
import { RiDeleteBinLine } from 'react-icons/ri';
import { SlOptions } from 'react-icons/sl';
import { useDispatch, useSelector } from 'react-redux';
import Tour from 'reactour';
import {
  ActionIcon,
  Button,
  Checkbox,
  Empty,
  Input,
  Popover,
  Title,
} from 'rizzui';
import SimpleBar from 'simplebar-react';
import EditBoardForm from './board/edit/[id]/edit-board-form';
import AddBoardForm from './board/new-board/add-board-form';
import DuplicateBoard from './board/new-board/duplicate-board';

const pageHeader = {
  title: 'Your Boards',
};

let boardSortOptions: Record<string, any>[] = [
  { name: 'Newest', value: 'newest' },
  { name: 'Oldest', value: 'oldest' },
  { name: 'A-Z', value: 'asc' },
  { name: 'Z-A', value: 'desc' },
  { name: 'Archived', value: 'archived' },
];

export default function MainPage() {
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { tourStatusData } = useSelector((state: any) => state?.root?.dashbord);
  const { selectedBoardSortName, selectedBoardSortValue, searchTerm } =
    useSelector((state: any) => state?.root?.board);
  const [updatedData, setUpdateddata] = useState<any[]>([]);
  const [totalBoardData, setTotalBoardData] = useState(0);
  const [skeletonLoader, setSkeletonloader] = useState(true);
  const [checkedBoards, setCheckedBoards] = useState<any>([]);
  const [activeBoard, setActiveBoard] = useState<any | null>(null);
  const allBoardIds = updatedData.map((item: any) => item._id);

  const { openModal, closeModal } = useModal();
  // const [selectedBoardSortName, setSelectedBoardSortName] = useState<any>('');
  // const [selectedBoardSortValue, setSelectedBoardSortValue] = useState<any>('');
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );

  // Search value
  // const [searchTerm, setSearchTerm] = useState<string>('');
  const debouncedValue = useDebouncedValue<string>(searchTerm, 1000);

  //Infinite Scroll state
  const [hasMore, sethasMore] = useState(true);

  const [payload, setPalyload] = useState({
    skip: 0,
    limit: 20,
    all: false,
    sort: selectedBoardSortValue,
    search: debouncedValue,
  });

  let defaultBoard = {
    _id: '1',
    project_name: 'New Board',
  };

  useEffect(() => {
    dispatch(RemoveBoardData({}));
  }, []);

  // Api call for Tour status get
  useEffect(() => {
    // Tour comment
    dispatch(getAllTourStatus());
  }, []);

  // Tour Integration
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [tourType, setTourType] = useState('');
  const [addBoardCardTourSteps, setAddBoardCardTourSteps] = useState([]);

  // Handle close tour
  const handleCloseTour = (boardTourType: any) => {
    if (boardTourType === 'add_board_card_tour') {
      dispatch(updateTourStatus({ board: { add_board_card_tour: true } })).then(
        (result: any) => {
          if (updateTourStatus.fulfilled.match(result)) {
            if (result?.payload?.success) {
              setIsTourOpen(false);
              // Tour comment
              dispatch(getAllTourStatus());
            }
          }
        }
      );
    } else if (boardTourType === 'board_list_tour') {
      dispatch(updateTourStatus({ board: { board_list_tour: true } })).then(
        (result: any) => {
          if (updateTourStatus.fulfilled.match(result)) {
            if (result?.payload?.success) {
              setIsTourOpen(false);
              // Tour comment
              dispatch(getAllTourStatus());
            }
          }
        }
      );
    }
  };

  useEffect(() => {
    if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.board &&
      Object?.keys(tourStatusData?.board).includes('add_board_card_tour') &&
      !tourStatusData?.board?.add_board_card_tour
    ) {
      setAddBoardCardTourSteps([]);
      setIsTourOpen(false);
      const addBoardCardTourStepContent = addBoardCardTourStepsContent(
        handleCloseTour,
        'add_board_card_tour',
        signIn,
        checkPermission
      );

      const updatedAddBoardCardTourSteps = getStepsByRole(
        addBoardCardTourStepContent
      );
      updatedAddBoardCardTourSteps?.length > 0 &&
        setAddBoardCardTourSteps(updatedAddBoardCardTourSteps);
      updatedAddBoardCardTourSteps?.length > 0 && setIsTourOpen(true);
      setTourType('add_board_card_tour');
    } else if (
      tourStatusData &&
      tourStatusData?.role &&
      tourStatusData?.board &&
      Object?.keys(tourStatusData?.board).includes('board_list_tour') &&
      !tourStatusData?.board?.board_list_tour &&
      updatedData?.length > 0
    ) {
      setAddBoardCardTourSteps([]);
      setIsTourOpen(false);
      const boardListTourStepContent = boardListTourStepsContent(
        handleCloseTour,
        'board_list_tour',
        signIn,
        checkPermission
      );

      const updatedboardListTourSteps = getStepsByRole(
        boardListTourStepContent
      );
      updatedboardListTourSteps?.length > 0 &&
        setAddBoardCardTourSteps(updatedboardListTourSteps);
      updatedboardListTourSteps?.length > 0 && setIsTourOpen(true);
      setTourType('board_list_tour');
    }
  }, [tourStatusData, updatedData, signIn?.permission]);

  // Sort filter

  const handleSortFilter = (sortValue: string) => {
    setUpdateddata([]);
    setSkeletonloader(true);
    setPalyload({
      skip: 0,
      limit: 20,
      all: false,
      sort: sortValue,
      search: debouncedValue,
    });
  };

  const handleClearSortFilter = () => {
    setUpdateddata([]);
    setSkeletonloader(true);
    dispatch(setSelectedBoardSortValue(''));
    dispatch(setSelectedBoardSortName(''));
    setPalyload({
      skip: 0,
      limit: 20,
      all: false,
      sort: '',
      search: debouncedValue,
    });
    setCheckedBoards([]); // Deselect all Boards
  };

  // Remove tasks data from redux
  useEffect(() => {
    dispatch(RemoveGetAllTasksData());
  }, []);

  // Search value set with one second of debounce
  useEffect(() => {
    setUpdateddata([]);
    setSkeletonloader(true);
    setPalyload({
      skip: 0,
      limit: 20,
      all: false,
      sort: selectedBoardSortValue,
      search: debouncedValue,
    });
  }, [debouncedValue]);

  // Infinite Scroll

  useEffect(() => {
    dispatch(getAllBoard(payload)).then((result: any) => {
      if (getAllBoard.fulfilled.match(result)) {
        const totalBoardCount = result?.payload?.data?.total_board_count;
        const boardList = result?.payload?.data?.board_list || [];

        setTotalBoardData(totalBoardCount);

        if (boardList.length > 0) {
          setSkeletonloader(false);

          const newData =
            payload.skip === 0
              ? boardList // Replace the data when loading the first page or searching
              : [...updatedData, ...boardList]; // Append when scrolling

          setUpdateddata(newData);

          if (totalBoardCount > newData.length) {
            sethasMore(true); // More data available
          } else {
            sethasMore(false); // No more data
          }
        } else {
          // No results for the current search or payload
          sethasMore(false);
        }
      } else {
        sethasMore(false); // Error or no data
      }
      setSkeletonloader(false);
    });
  }, [payload]);

  //Infinite Scroll Handler
  const fetchMoreData = () => {
    // 10px buffer to trigger loading
    if (updatedData.length < totalBoardData) {
      setPalyload({
        ...payload,
        skip: updatedData.length, // Increment skip for next batch
      });
    } else {
      sethasMore(false); // No more data to load
    }
  };

  const handleScroll = debounce((e: any) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      fetchMoreData();
    }
  }, 300); // Adjust debounce delay as needed
  const onSearchClear = () => {
    dispatch(setSearchTerm(''));
    setCheckedBoards([]); // Deselect all Boards
  };

  const onSearchChange = (event: any) => {
    dispatch(setSearchTerm(event?.target?.value));
    setCheckedBoards([]); // Deselect all Boards
  };

  // for dnd context props
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 10,
      },
    })
  );

  const onDragStart = (event: any) => {
    console.log(event, 'onDragStart');
    // set active task first when drag start
    if (event.active.data.current?.type === 'Board') {
      setActiveBoard(event.active.data.current.data);
      return;
    }
  };

  const onDragEnd = useCallback((event: any) => {
    const { active, over } = event;

    if (!over) return;
    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    if (active.id !== over?.id) {
      // let activeIndex, draggedBoard,targetBoard, overIndex: any;
      setUpdateddata((data: any) => {
        if (!data) return data; // Ensure data exists

        const activeIndex = data.findIndex((t: any) => t._id === activeId);
        const overIndex = data.findIndex((t: any) => t._id === overId);

        const draggedBoard = data[overIndex];
        const targetBoard = data[activeIndex];

        console.log(
          activeIndex,
          overIndex,
          draggedBoard,
          targetBoard,
          'targetBoard'
        );

        // Ensure pinned boards stay in pinned section and unpinned stay in unpinned section
        if (
          draggedBoard?.is_pinned !== targetBoard?.is_pinned ||
          activeIndex === -1 ||
          overIndex == -1
        )
          return [...data];

        const payload = {
          board_id: activeId,
          order: overIndex + 1,
        };
        dispatch(updateBoardOrder(payload));
        return arrayMove([...data], activeIndex, overIndex);
      });
    }
    setActiveBoard(null);
  }, []);

  const onDragCancel = useCallback(() => {
    setActiveBoard(null);
  }, []);

  const handleSelectAll = (e: any) => {
    if (e.target.checked) {
      setCheckedBoards(allBoardIds); // Select all
    } else {
      setCheckedBoards([]); // Deselect all
    }
  };

  return (
    <>
      {/* The Tour component */}
      <Tour
        steps={addBoardCardTourSteps ?? []}
        isOpen={isTourOpen}
        rounded={10}
        closeWithMask={false}
        disableInteraction={true}
        disableKeyboardNavigation={['esc']}
        onRequestClose={() => handleCloseTour(tourType)}
        className="poppins_font_number tour-close-button font-semibold text-black"
        scrollDuration={50}
        scrollOffset={5}
      />
      <div className="mb-5 flex flex-wrap items-center justify-between gap-4">
        {/* Search and Sort Section */}
        <div className="flex flex-wrap items-center gap-4">
          {/* Search Bar */}
          <Input
            className="w-full focus:ring-2 focus:ring-[#8C80D2] sm:w-[15rem]"
            placeholder="Search by name"
            value={searchTerm}
            onClear={onSearchClear}
            onChange={onSearchChange}
            onKeyDown={handleKeyDown}
            inputClassName="h-[40px] bg-white  text-[#111928]"
            clearable={true}
            prefix={<PiMagnifyingGlassBold className="text-[#111928]" />}
          />
          {/* Sort Dropdown */}
          <Select
            className="board-list-tour-step-four w-[8rem] text-gray-600 sm:w-[8rem]"
            value={selectedBoardSortName}
            onChange={(selectedOption: any) => {
              dispatch(setSelectedBoardSortName(selectedOption?.name));
              dispatch(setSelectedBoardSortValue(selectedOption?.value));
              handleSortFilter(selectedOption?.value);
              setCheckedBoards([]); // Deselect all Boards
            }}
            placeholder="Sort"
            clearable={true}
            onClear={handleClearSortFilter}
            options={boardSortOptions}
            selectClassName="text-[#111928] bg-white"
            suffixClassName={selectedBoardSortValue !== '' ? 'hidden' : ''}
          />
        </div>
        <div className="flex flex-wrap gap-4">
          {/* Button Section */}
          <Link href={routes.myTasks(defaultWorkSpace?.name)}>
            <Button className="flex items-center justify-between rounded-md bg-[#7667CF] px-6 py-2 text-sm font-medium text-white shadow-md transition-colors hover:bg-[#7a6acb]">
              <span>Go to All Tasks</span>
              <span className="ml-2 flex justify-end">
                <Image
                  src={arrowright}
                  alt="not found"
                  className="h-4 w-4" // Adjust size as needed
                />
              </span>
            </Button>
          </Link>
        </div>
      </div>
      {checkedBoards?.length > 0 && (
        <div className="mb-4 flex items-center gap-3 px-1.5">
          <Checkbox
            inputClassName="checkbox-color"
            label="Select all"
            labelClassName="text-sm font-medium text-[#5850EC]"
            className="!cursor-pointer"
            onChange={handleSelectAll}
            checked={checkedBoards?.length === allBoardIds?.length}
          />
          <div className="h-6 border-[1px] border-r border-[#C9CCCF]"></div>
          <div className="text-sm font-normal leading-[140%] text-black">
            {checkedBoards?.length}{' '}
            {checkedBoards?.length === 1 ? 'board' : 'boards'} selected
          </div>
          {(['agency'].includes(signIn?.role) ||
            (['team_agency'].includes(signIn?.role) &&
              checkPermission(
                'projects',
                'boards',
                'create',
                signIn?.permission
              ))) && (
            <Button
              className="gap-2 rounded-md border-[#6875F5] bg-[#F0F5FF] text-sm font-semibold text-[#5850EC]"
              onClick={() => {
                openModal({
                  view: (
                    <>
                      <DuplicateBoard
                        boards={checkedBoards ?? []}
                        setPalyload={setPalyload}
                        setUpdateddata={setUpdateddata}
                        setSkeletonloader={setSkeletonloader}
                        sortValue={selectedBoardSortValue}
                        searchValue={debouncedValue}
                        setCheckedBoards={setCheckedBoards}
                      />
                    </>
                  ),
                  customSize: '563px',
                });
              }}
            >
              <FiCopy className="h-4 w-4" />
              Duplicate
            </Button>
          )}
          <Button
            className="gap-2 rounded-md border-[#C92F5480] bg-[#FDEEEC] text-sm font-semibold text-[#C92F54]"
            onClick={() => {
              openModal({
                view: (
                  <ConfirmationBoardDeleteModal
                    boardId={checkedBoards}
                    updatedData={updatedData}
                    setUpdateddata={setUpdateddata}
                    setCheckedBoards={setCheckedBoards}
                  />
                ),
                customSize: '600px',
              });
            }}
          >
            <RiDeleteBinLine className="h-4 w-4" />
            Delete
          </Button>
          <Button
            className="border-[#D4D4D4] bg-white text-sm font-semibold text-black"
            onClick={() => {
              setCheckedBoards([]);
            }}
          >
            Cancel
          </Button>
        </div>
      )}
      <SimpleBar
        onScrollCapture={handleScroll}
        className="h-[59vh] lg:h-[76vh] 3xl:h-[80vh]"
      >
        <DndContext
          sensors={sensors}
          onDragStart={onDragStart}
          onDragEnd={onDragEnd}
          onDragCancel={onDragCancel}
          // onDragOver={onDragOver}
        >
          <div
            className={cn(
              'px-[6px]',
              ((['team_agency', 'team_client']?.includes(signIn?.role)
                ? checkPermission(
                    'projects',
                    'boards',
                    'create',
                    signIn?.permission
                  )
                : ['agency'].includes(signIn?.role)) ||
                skeletonLoader ||
                (updatedData && updatedData?.length > 0)) &&
                'grid grid-cols-1 gap-4 px-[6px]  md:grid-cols-2  lg:grid-cols-3  xl:grid-cols-4 2xl:grid-cols-4 3xl:grid-cols-5  4xl:grid-cols-6 '
            )}
          >
            {(['team_client', 'team_agency'].includes(signIn?.role)
              ? checkPermission(
                  'projects',
                  'boards',
                  'create',
                  signIn?.permission
                )
              : ['agency']?.includes(signIn?.role)) && (
              <div className="add-board-card-tour-step-one">
                <InformationCard
                  key={defaultBoard?._id}
                  data={defaultBoard}
                  isNewBoard={true}
                  setPalyload={setPalyload}
                  updatedData={updatedData}
                  checkedBoards={checkedBoards}
                  setCheckedBoards={setCheckedBoards}
                  setUpdateddata={setUpdateddata}
                  setSkeletonloader={setSkeletonloader}
                  debouncedValue={debouncedValue}
                  selectedBoardSortValue={selectedBoardSortValue}
                />
              </div>
            )}

            {skeletonLoader ? (
              <>
                <CardSkeleton />
                <CardSkeleton />
                <CardSkeleton />
                <CardSkeleton />
                <CardSkeleton />
                <CardSkeleton />
                <CardSkeleton />
              </>
            ) : (
              <>
                {(
                  ['team_client', 'team_agency'].includes(signIn?.role)
                    ? checkPermission(
                        'projects',
                        'boards',
                        'create',
                        signIn?.permission
                      )
                    : ['agency'].includes(signIn?.role)
                ) ? (
                  <>
                    {updatedData &&
                      updatedData?.length > 0 &&
                      updatedData
                        // ?.slice() // Create a copy of the array to avoid mutating the original array
                        // .sort(
                        //   (a: Record<string, any>, b: Record<string, any>) => {
                        //     // Sort the array based on the is_pinned property
                        //     if (a.is_pinned && !b.is_pinned) {
                        //       return -1; // Board 'a' comes before board 'b'
                        //     } else if (!a.is_pinned && b.is_pinned) {
                        //       return 1; // Board 'b' comes before board 'a'
                        //     } else {
                        //       return 0; // No change in order
                        //     }
                        //   }
                        // )
                        ?.map((board: Record<string, any>, index: number) => {
                          return (
                            <div
                              key={index}
                              className="board-list-tour-step-one"
                            >
                              <InformationCard
                                key={board?._id}
                                data={board}
                                setPalyload={setPalyload}
                                updatedData={updatedData}
                                setUpdateddata={setUpdateddata}
                                checkedBoards={checkedBoards}
                                setCheckedBoards={setCheckedBoards}
                                setSkeletonloader={setSkeletonloader}
                                debouncedValue={debouncedValue}
                                selectedBoardSortValue={selectedBoardSortValue}
                              />
                            </div>
                          );
                        })}
                  </>
                ) : (
                  <>
                    {updatedData && updatedData?.length > 0 ? (
                      updatedData
                        // ?.slice() // Create a copy of the array to avoid mutating the original array
                        // .sort(
                        //   (a: Record<string, any>, b: Record<string, any>) => {
                        //     // Sort the array based on the is_pinned property
                        //     if (a.is_pinned && !b.is_pinned) {
                        //       return -1; // Board 'a' comes before board 'b'
                        //     } else if (!a.is_pinned && b.is_pinned) {
                        //       return 1; // Board 'b' comes before board 'a'
                        //     } else {
                        //       return 0; // No change in order
                        //     }
                        //   }
                        // )
                        ?.map((board: Record<string, any>, index: number) => {
                          return (
                            <div
                              key={index}
                              className="board-list-tour-step-one"
                            >
                              <InformationCard
                                key={board?._id}
                                data={board}
                                setPalyload={setPalyload}
                                updatedData={updatedData}
                                setUpdateddata={setUpdateddata}
                                checkedBoards={checkedBoards}
                                setCheckedBoards={setCheckedBoards}
                                setSkeletonloader={setSkeletonloader}
                                debouncedValue={debouncedValue}
                                selectedBoardSortValue={selectedBoardSortValue}
                              />
                            </div>
                          );
                        })
                    ) : (
                      <div className="mt-20 flex items-center justify-center">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <Empty />{' '}
                          <p className="mt-3 w-full text-center text-[15px] font-semibold">
                            {searchTerm !== '' || selectedBoardSortValue !== ''
                              ? 'No Board Found.'
                              : 'You currently don’t have any boards assigned to you.'}
                          </p>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </div>
          {hasMore && (
            <div className="flex w-full items-center justify-center">
              <Button
                variant="text"
                size="xl"
                isLoading={true}
                className="flex w-full items-center justify-center"
              />
            </div>
          )}
          <DragOverlay>
            {activeBoard ? (
              <div className="dragging-overlay">
                <InformationCard
                  data={activeBoard}
                  // isNewBoard={false}
                  // setPalyload={setPalyload}
                  // updatedData={updatedData}
                  // setUpdateddata={setUpdateddata}
                  // checkedBoards={checkedBoards}
                  // setCheckedBoards={setCheckedBoards}
                  // setSkeletonloader={setSkeletonloader}
                  // debouncedValue={debouncedValue}
                  // selectedBoardSortValue={selectedBoardSortValue}
                />
              </div>
            ) : null}
          </DragOverlay>
        </DndContext>
      </SimpleBar>{' '}
    </>
  );
}

function InformationCard({
  key,
  className,
  data,
  isNewBoard,
  setPalyload,
  updatedData,
  setUpdateddata,
  checkedBoards,
  setCheckedBoards,
  setSkeletonloader,
  debouncedValue,
  selectedBoardSortValue,
}: Readonly<{
  key?: string;
  className?: string;
  data?: any;
  isNewBoard?: boolean;
  setPalyload?: any;
  updatedData?: any;
  setUpdateddata?: any;
  checkedBoards?: any;
  setCheckedBoards?: any;
  setSkeletonloader?: any;
  debouncedValue?: any;
  selectedBoardSortValue?: any;
}>) {
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const router = useRouter();
  const dragCardRef = useRef<HTMLDivElement>(null);

  const { editBoardPinStatusChange, deleteBoardLoader, archiveBoardLoader } =
    useSelector((state: any) => state?.root?.board);
  const { setNodeRef, attributes, listeners, transition, isDragging } =
    useSortable({
      id: data?._id,
      data: {
        type: 'Board',
        data,
      },
      disabled:
        (debouncedValue !== '' || selectedBoardSortValue !== '') && true,
    });

  const style = {
    transition,
  };

  if (isDragging) {
    return (
      <div
        ref={setNodeRef}
        style={style}
        className="relative flex h-[180px] min-h-[100px] w-full cursor-grab items-center rounded-3xl border-2 border-gray-400 p-3 text-left"
      />
    );
  }
  const handlePinClick = (data: Record<string, any>) => {
    dispatch(
      putBoardPinStatusChange({
        is_pinned: !data?.is_pinned,
        board_id: data?._id,
      })
    ).then((result: any) => {
      if (putBoardPinStatusChange.fulfilled.match(result)) {
        if (result.payload.success === true) {
          const updatedBoardList = () => {
            let pinnedBoards: any[] = [];
            let unpinnedBoards: any[] = [];
            let targetBoard: any = null;

            // Separate pinned and unpinned boards & find the target board
            updatedData?.forEach((board: any) => {
              if (board?._id === data?._id) {
                targetBoard = { ...board, is_pinned: !board?.is_pinned }; // Toggle pin state
              } else if (board?.is_pinned) {
                pinnedBoards.push(board);
              } else {
                unpinnedBoards.push(board);
              }
            });

            return targetBoard?.is_pinned
              ? [targetBoard, ...pinnedBoards, ...unpinnedBoards]
              : [...pinnedBoards, targetBoard, ...unpinnedBoards];
          };
          setUpdateddata(updatedBoardList());
        }
      }
    });
  };

  const handleCheckboxChange = (boardId: string, e: any) => {
    if (e.target.checked) {
      setCheckedBoards((prev: any) => [...prev, boardId]);
    } else {
      setCheckedBoards((prev: any) =>
        prev.filter((id: string) => id !== boardId)
      );
    }
  };

  return (
    <div ref={dragCardRef}>
      <div
        ref={setNodeRef}
        style={style}
        {...attributes}
        {...listeners}
        className={cn(
          'relative flex h-[188px] w-auto cursor-pointer  flex-col items-center justify-center rounded-[20px] border bg-white p-5 shadow-sm hover:border hover:border-[#8C80D2] @3xl:p-7', // Added relative class
          className
        )}
      >
        {!isNewBoard && (
          <>
            <div className="absolute left-4 top-2 p-2">
              {data?.board_status?.name !== 'archived' && data?.is_pinned && (
                <Button
                  variant="text"
                  className="board-list-tour-step-two h-0  cursor-pointer !bg-white p-0"
                  disabled={editBoardPinStatusChange === 'pending'}
                  onClick={() => handlePinClick(data)}
                >
                  {data?.is_pinned ? (
                    <BsPinAngleFill
                      width={16}
                      height={16}
                      className="text-[#3F83F8]"
                    />
                  ) : (
                    <Image src={Pinned} alt="Pin Icon" width={16} height={16} />
                  )}
                </Button>
              )}
            </div>
            <div
              className={cn(
                'absolute top-3 z-10 flex h-5 items-center gap-1 pr-2 pt-1',
                signIn?.role === 'agency' ? 'right-2' : 'right-3'
              )}
            >
              {checkedBoards?.length > 0 && (
                <Checkbox
                  inputClassName="checkbox-color"
                  title={'Select All'}
                  onChange={(e) => handleCheckboxChange(data?._id, e)}
                  checked={!!checkedBoards.includes(data?._id)}
                  className="me-1 cursor-pointer"
                />
              )}

              {!(checkedBoards?.length > 0) && (
                <>
                  {data?.board_status?.name === 'active' ? (
                    <Popover
                      placement="bottom"
                      className=" demo_test min-w-[100px] p-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                      content={({ setOpen }) => {
                        const handleButtonClick = (action: string) => {
                          if (action === 'delete' || action === 'duplicate') {
                            setCheckedBoards((prev: any) => [
                              ...prev,
                              data?._id,
                            ]);
                            setOpen(false);
                          } else if (
                            action === 'archived' ||
                            action === 'active'
                          ) {
                            dispatch(
                              postArchiveBoard({
                                status: action,
                                board_id: data?._id,
                              })
                            ).then((result: any) => {
                              if (postArchiveBoard.fulfilled.match(result)) {
                                console.log(
                                  'Api response for archive....',
                                  result
                                );
                                if (result.payload.success === true) {
                                  const updatedBoardAfterArchive =
                                    (updatedData &&
                                      updatedData?.length > 0 &&
                                      updatedData?.filter(
                                        (board: Record<string, any>) => {
                                          if (board._id !== data?._id) {
                                            return board;
                                          }
                                        }
                                      )) ||
                                    [];
                                  setUpdateddata(updatedBoardAfterArchive);
                                  setOpen(false);
                                }
                              }
                            });
                          }
                        };
                        return (
                          <div className="p-2 text-gray-900">
                            <Button
                              variant="text"
                              disabled={editBoardPinStatusChange === 'pending'}
                              className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                              onClick={() => handlePinClick(data)}
                            >
                              {data?.is_pinned ? 'Unpin' : 'Pin'}
                            </Button>
                            {(['agency'].includes(signIn?.role) ||
                              (['team_agency'].includes(signIn?.role) &&
                                checkPermission(
                                  'projects',
                                  'boards',
                                  'update',
                                  signIn?.permission
                                ))) && (
                              <>
                                <Button
                                  variant="text"
                                  className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                  onClick={() => {
                                    openModal({
                                      view: (
                                        <div>
                                          <EditBoardForm
                                            onClose={closeModal}
                                            params={{ id: data?._id }}
                                            setUpdateddata={setUpdateddata}
                                            setSkeletonloader={
                                              setSkeletonloader
                                            }
                                            setPalyload={setPalyload}
                                            sortValue={selectedBoardSortValue}
                                            searchValue={debouncedValue}
                                          />
                                        </div>
                                      ),
                                      customSize: '600px',
                                    });
                                  }}
                                >
                                  Edit
                                </Button>
                                <Button
                                  variant="text"
                                  className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                  onClick={() => handleButtonClick('archived')}
                                  disabled={archiveBoardLoader}
                                >
                                  Archive
                                </Button>
                              </>
                            )}
                            {(['agency'].includes(signIn?.role) ||
                              (['team_agency'].includes(signIn?.role) &&
                                checkPermission(
                                  'projects',
                                  'boards',
                                  'delete',
                                  signIn?.permission
                                ))) && (
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => handleButtonClick('delete')}
                                disabled={deleteBoardLoader}
                              >
                                Delete
                              </Button>
                            )}
                            {(['agency'].includes(signIn?.role) ||
                              (['team_agency'].includes(signIn?.role) &&
                                checkPermission(
                                  'projects',
                                  'boards',
                                  'create',
                                  signIn?.permission
                                ))) && (
                              <Button
                                variant="text"
                                className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                onClick={() => handleButtonClick('duplicate')}
                                // disabled={deleteBoardLoader}
                              >
                                Duplicate
                              </Button>
                            )}
                          </div>
                        );
                      }}
                    >
                      <ActionIcon
                        title={'More Options'}
                        className="board-list-tour-step-three h-4 w-4 !p-0"
                        variant="text"
                      >
                        <SlOptions className="size-4 cursor-pointer" />
                      </ActionIcon>
                    </Popover>
                  ) : (
                    <>
                      {(['agency'].includes(signIn?.role) ||
                        (['team_agency'].includes(signIn?.role) &&
                          checkPermission(
                            'projects',
                            'boards',
                            'update',
                            signIn?.permission
                          ))) && (
                        <Popover
                          placement="bottom"
                          className=" demo_test min-w-[100px] p-0 dark:bg-gray-100 [&>svg]:dark:fill-gray-100"
                          content={({ setOpen }) => {
                            const handleButtonClick = (action: string) => {
                              if (
                                action === 'archived' ||
                                action === 'active'
                              ) {
                                dispatch(
                                  postArchiveBoard({
                                    status: action,
                                    board_id: data?._id,
                                  })
                                ).then((result: any) => {
                                  if (
                                    postArchiveBoard.fulfilled.match(result)
                                  ) {
                                    console.log(
                                      'Api response for archive....',
                                      result
                                    );
                                    if (result.payload.success === true) {
                                      const updatedBoardAfterArchive =
                                        (updatedData &&
                                          updatedData?.length > 0 &&
                                          updatedData?.filter(
                                            (board: Record<string, any>) => {
                                              if (board._id !== data?._id) {
                                                return board;
                                              }
                                            }
                                          )) ||
                                        [];
                                      setUpdateddata(updatedBoardAfterArchive);
                                      setOpen(false);
                                    }
                                  }
                                });
                              }
                            };
                            return (
                              <div className="p-2 text-gray-900">
                                <Button
                                  variant="text"
                                  className="flex w-full items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
                                  onClick={() => handleButtonClick('active')}
                                  disabled={archiveBoardLoader}
                                >
                                  Unarchive
                                </Button>
                              </div>
                            );
                          }}
                        >
                          <ActionIcon
                            title={'More Options'}
                            className="board-list-tour-step-three h-4 w-4 !p-0"
                            variant="text"
                          >
                            <SlOptions className="size-4 cursor-pointer" />
                          </ActionIcon>
                        </Popover>
                      )}
                    </>
                  )}
                </>
              )}
            </div>
          </>
        )}
        <Link
          className={` flex h-full w-full items-center ${
            isNewBoard ? 'mt-8 justify-center' : 'mt-7 justify-start'
          }`}
          href={
            isNewBoard
              ? '#' // Use a valid placeholder URL
              : routes.boardDetails(defaultWorkSpace?.name, data?._id)
          }
          onClick={() => {
            if (isNewBoard) {
              openModal({
                view: (
                  <div>
                    <AddBoardForm
                      onClose={closeModal}
                      setUpdateddata={setUpdateddata}
                      setSkeletonloader={setSkeletonloader}
                      setPalyload={setPalyload}
                      sortValue={selectedBoardSortValue}
                      searchValue={debouncedValue}
                    />
                  </div>
                ),
                customSize: '600px',
              });
              dispatch(RemoveBoardListData());
            } else {
              dispatch(RemoveBoardListData());
            }
          }}
        >
          <div
            className={`flex cursor-pointer flex-col justify-center ${
              isNewBoard ? 'items-center' : 'items-start'
            }`}
          >
            {isNewBoard ? (
              <div className="flex h-[60px] w-[60px] items-center justify-center rounded-full border-white bg-[#F0F5FF]">
                <FiPlus className="h-[30px] w-[30px] text-[#6875F5]" />
              </div>
            ) : !data?.board_image ? (
              <div
                className="flex h-[65px] w-[65px] items-center justify-center rounded-[19px] border-white"
                style={{ backgroundColor: data?.board_color }}
              ></div>
            ) : (
              <div className="relative aspect-square h-[65px] w-[65px] overflow-hidden rounded-[19px] border-white bg-[#F6F6FB] shadow-profilePic">
                <img
                  src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${data?.board_image}`}
                  alt={data?.project_name}
                  onError={(event: any) => {
                    event.target.src = syncUppLogo?.src;
                  }}
                  className="aspect-auto h-full w-full object-cover"
                />
              </div>
            )}
            <Title
              as="h1"
              className={cn(
                isNewBoard ? 'leading-[22.4px]' : '',
                'break-all text-center text-base font-semibold',
                isNewBoard
                  ? 'text-[16px] text-[#6875F5]'
                  : 'text-[16px] font-bold text-[#111928]',
                'max-w-[210px] overflow-hidden truncate text-ellipsis whitespace-nowrap'
              )}
            >
              {data?.project_name?.charAt(0)?.toUpperCase() +
                data?.project_name?.slice(1)}
            </Title>

            {/* Description container with consistent height */}
            <div
              className="line-clamp-2 max-w-[233px] text-[12px] font-[400] leading-[16.8px] text-[#4B5563] sm:max-w-[300px] md:max-w-[350px] lg:max-w-[450px] xl:max-w-[600px]"
              style={{
                display: '-webkit-box',
                WebkitBoxOrient: 'vertical',
                WebkitLineClamp: 2,
                overflow: 'hidden',
                wordBreak: 'break-word', // Ensures long words break properly
                overflowWrap: 'break-word', // Ensures wrapping for long strings
                minHeight: '34px', // Consistent height for description (2 lines * line height)
              }}
            >
              <div>
                {
                  data?.description ||
                    '\u00A0' /* Non-breaking space for empty description */
                }
              </div>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
}
